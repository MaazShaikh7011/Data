package com.opl.jns.published.utils.common;

import io.swagger.v3.oas.annotations.media.*;

import jakarta.validation.constraints.*;
import java.io.*;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 * 
 * @author Maaz Shaikh
 *
 */
public class PublishResponse extends CommonResponse implements Serializable {


	@NotNull
	@Schema(example = "2023-05-05 16:12:10")
	private String timestamp;

	@NotNull
	@Size(min = 0, max = 100)
	private String token;

	public void setStatusAndMessageAndSuccess(String message,Integer status,Boolean success){
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public PublishResponse(){

	}
	public PublishResponse(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}
	public PublishResponse(String message, Object data, Integer status) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
	}

	public PublishResponse(String message, Object data, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public PublishResponse(String message, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}


	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
