package com.opl.jns.published.utils.common;

import io.swagger.v3.oas.annotations.media.*;

import jakarta.validation.constraints.*;
import java.io.Serializable;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 * 
 * @author harshit
 *
 */
public class RegCommonResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	@NotNull
	@Size(min = 0, max = 255)
	private String message;

	//private Object data;

	@NotNull
	private Integer status;

	@NotNull
	@Schema(allowableValues = { "True", "False" })
	private Boolean success;

	public RegCommonResponse(){

	}
	public RegCommonResponse(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}

	public RegCommonResponse(String message, Object data, Integer status) {
		super();
		this.message = message;
		//this.data = data;
		this.status = status;
	}

	public RegCommonResponse(String message, Object data, Integer status, Boolean success) {
		super();
		this.message = message;
		//this.data = data;
		this.status = status;
		this.success = success;
	}

	public RegCommonResponse(String message, Integer status, Boolean success) {
		super();
		this.message = message;
		this.status = status;
		this.success = success;
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/*public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}*/

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}
	@Override
	public String toString() {
		return "CommonResponse [message=" + message + ", status=" + status + ", success=" + success
				+ "]";
	}
}
