package com.opl.jns.published.utils.common;

public class CommonConstant {

	public static final String BANK_SHORT_CODE="ICI|SBI|HDFC|MAHARASHTRA|CENTRAL|CANARA|UBI|BOB|BOI|IOB|PNB|UCO|IB|PSB|PNB1";
	public static final String BANK_SHORT_CODE_NAME = "ICI-ICICI Bank India, SBI-State Bankof India, HDFC-HDFC Bank India,"
			+ "MAHARASHTRA-Bank of Maharashtra India, CENTRAL-Central Bank of India, CANARA-Canara Bank,"
			+ "UBI-Union Bankof India, BOB-Bank of Baroda India, BOI-Bank of India,"
			+ "IOB-Indian Overseas Bank, PNB-Punjab National Bank India, UCO-UCO Bank India,"
			+ "IB-Indian Bank, PSB-Punjab and Sind Bank,PNB1-Punjab National Bank India1";
}
