package com.opl.jns.published.utils.common;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 * 
 * @author Maaz Shaikh
 *
 */
public class RegistryResponseV2 extends RegCommonResponse implements Serializable {

	@NotNull
	@Schema(example = "2023-05-05 16:12:10")
	private String timestamp;

	@NotNull
	@Size(min = 0, max = 100)
	private String token;

	public void setStatusAndMessageAndSuccess(String message,Integer status,Boolean success){
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponseV2(){

	}
	public RegistryResponseV2(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}
	public RegistryResponseV2(String message, Object data, Integer status) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
	}

	public RegistryResponseV2(String message, Object data, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponseV2(String message, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}



	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
