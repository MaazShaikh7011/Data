package com.opl.jns.published.utils.enums;

public enum EnrollStageMaster {

	CREATED(1, "Created"), 
	OTP_VERIFICATION(2, "OTP Verification"),
	ACCOUNT_HOLDER_SELECTION(3, "Account Holder Selection"), 
	APPLICATION_FORM(4, "Application Form"),
	PREMIUM_DEDUCTION(5, "Premium Deduction"), 
	COMPLETED(6, "Completed"),
	EXPIRED(7, "Expired"),
	REJECTED(8, "Rejected"),
	PREMIUM_DEDUCTION_FAILED(15, "Premium Deduction Failed");

	private int stageId;
	private String stageName;

	EnrollStageMaster(int stageId, String stageName) {
		this.stageId = stageId;
		this.stageName = stageName;
	}

	public static EnrollStageMaster getStageMasterByStageId(int stageId) {
		for (EnrollStageMaster c : EnrollStageMaster.values()) {
			if (c.stageId == stageId) {
				return c;
			}
		}
		return null;
	}

	public int getStageId() {
		return this.stageId;
	}

	public String getStageName() {
		return this.stageName;
	}

}
