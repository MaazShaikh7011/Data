package com.opl.jns.published.utils.config;

import java.util.ArrayList;
import java.util.List;

import com.opl.jns.published.utils.common.OPLUtils;

public class PhaseMode {

//	private static String BANK_LIST = "14,15,16,17";

	public static boolean checkPhase2Enroll(long orgId) {
		String bankList = System.getenv("ENROLL_PHASE_2_BANK_LIST");
//		String bankList = BANK_LIST;
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return false;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(","))
			list.add(Long.parseLong(s));
		return list.contains(orgId);
	}
	
	public static boolean checkPhase2Claim(long orgId) {
		String bankList = System.getenv("CLAIM_PHASE_2_BANK_LIST");
//		String bankList = BANK_LIST;
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return false;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(","))
			list.add(Long.parseLong(s));
		return list.contains(orgId);
	}

//	public static void main(String[] args) {
//		System.out.println(checkPhase2(16));
//		System.out.println(checkPhase2(18));
//		System.out.println(checkPhase2(1));
//		System.out.println(checkPhase2(45));
//		System.out.println(checkPhase2(71));
//		System.out.println(checkPhase2(14));
//	}

}
