package com.opl.jns.published.utils.common;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ApiResponse {

	private Long userId;
	private String message;
	private Integer status;
	private boolean isAuthenticate;
	private Long userType;
	private Long userOrgId;
	private Long userBranchId;
	private Long userRoleId;
	private Integer lastBusinessTypeId;
	private String email;
	private String mobile;
	private String name;
	private String publicKey;
	private String privateKey;
	
	@JsonProperty("meta-data")
	@JsonAlias({"metadata"})
	private String metadata;
	

	public ApiResponse(){

	}

	public ApiResponse(Integer status, String message) {
		this.status = status;
		this.message = message;
	}


	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public boolean isAuthenticate() {
		return isAuthenticate;
	}

	public void setAuthenticate(boolean authenticate) {
		isAuthenticate = authenticate;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public Long getUserBranchId() {
		return userBranchId;
	}

	public void setUserBranchId(Long userBranchId) {
		this.userBranchId = userBranchId;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public Integer getLastBusinessTypeId() {
		return lastBusinessTypeId;
	}

	public void setLastBusinessTypeId(Integer lastBusinessTypeId) {
		this.lastBusinessTypeId = lastBusinessTypeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}
	
	
}
