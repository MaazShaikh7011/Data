package com.opl.jns.published.utils.enums;

public enum ApplicationStatus {

	ENROLL_IN_PROGRESS(1, "Enroll In Progress"),
	ENROLL_COMPLETED(2, "Enroll Completed"),
	ENROLL_REJECTED(3, "Enroll Rejected"),
	// ENROLL_EXPIRED(4, "Enroll Expired"),
	CLAIM_IN_PROGRESS(5, "Claim In Progress"),
	CLAIM_SEND_TO_INSURER(6, "Claim Send to Insurer"),
	CLAIM_SEND_BACK_BY_INSURER(7, "Claim Send back by insurer"),
	CLAIM_REJECTED(8, "Claim Rejected"),
	CLAIM_HOLD(9, "Claim Hold"),
	CLAIM_ACCEPTED(10, "Claim Accpeted");

	private Integer id;
	private String value;

	private ApplicationStatus(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ApplicationStatus fromId(Integer v) {
		for (ApplicationStatus c : ApplicationStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ApplicationStatus[] getAll() {
		return ApplicationStatus.values();
	}

}
