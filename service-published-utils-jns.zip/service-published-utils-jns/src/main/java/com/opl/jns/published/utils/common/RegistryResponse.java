package com.opl.jns.published.utils.common;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 * 
 * @author Maaz Shaikh
 *
 */
public class RegistryResponse extends RegCommonResponse implements Serializable {


	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(notes = "timeStamp", example = "yyyy-MM-dd HH:mm:ss", required = true)
	private LocalDateTime timestamp;

	@NotNull
	@Size(min = 0, max = 100)
	private String token;

	public void setStatusAndMessageAndSuccess(String message,Integer status,Boolean success){
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponse(){

	}
	public RegistryResponse(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}
	public RegistryResponse(String message, Object data, Integer status) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
	}

	public RegistryResponse(String message, Object data, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponse(String message, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}
	
	public RegistryResponse(String message, Integer status, Boolean success,String token, LocalDateTime timeStamp) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
		this.setToken(token);
		this.setTimestamp(timeStamp);
	}


	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
