package com.opl.jns.published.utils.common;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Convert;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Arrays;
import java.util.Base64;

@Convert
public class EncryptionUtils implements AttributeConverter<String, String> {
	private static final String ALGORITHM = "AES";
	private static final String KEY = "C@p!ta@W0rld#AES";
	private static final String SECRET = "26f1ac75f77c22ebc66e2359c13ea9955ebd5e2bd7fbe50e5b3ac2977a772302";

	private static final Logger logger = (Logger) LoggerFactory.getLogger(EncryptionUtils.class);

	public String convertToDatabaseColumn(String plainText) {
		// do some encryption
		try {
			if (!OPLUtils.isObjectNullOrEmpty(plainText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.ENCRYPT_MODE, key);

				byte[] cleartext = plainText.getBytes(StandardCharsets.UTF_8);
				byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(Hex.encodeHex(ciphertextBytes));
			}
		} catch (Exception e) {
			logger.error("error while encrypting data : " + plainText, e);
		}
		return null;
	}

	public String convertToEntityAttribute(String encryptedText) {
		// do some decryption
		try {
			if (!OPLUtils.isObjectNullOrEmpty(encryptedText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.DECRYPT_MODE, key);

				// byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(cipher.doFinal(Hex.decodeHex(encryptedText.toCharArray())));
			}
		} catch (Exception e) {
			logger.error("error while decrypting data : " + encryptedText, e);
		}
		return null;
	}

	/**
	 * this method for decription with secret key
	 * 
	 * @param encryptedText
	 * @return
	 */
	public String decriptWithKey(String encryptedText) {
		// do some decryption
		try {
			if (!OPLUtils.isObjectNullOrEmpty(encryptedText)) {
				byte[] keyBytes = Arrays.copyOf(SECRET.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.DECRYPT_MODE, key);

				// byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(cipher.doFinal(Hex.decodeHex(encryptedText.toCharArray())));
			}
		} catch (Exception e) {
			logger.error("error while decrypting data : " + encryptedText, e);
		}
		return null;
	}

	public String encryptionWithKey(String plainText) {
		// do some encryption
		try {
			if (!OPLUtils.isObjectNullOrEmpty(plainText)) {
				byte[] keyBytes = Arrays.copyOf(SECRET.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.ENCRYPT_MODE, key);

				byte[] cleartext = plainText.getBytes(StandardCharsets.UTF_8);
				byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(Hex.encodeHex(ciphertextBytes));
			}
		} catch (Exception e) {
			logger.error("error while encrypting data : {}" + plainText, e);
		}
		return null;
	}

	/**
	 * AES Decrypt with Front end
	 * @param cipherText
	 * @return
	 * @throws DigestException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws InvalidAlgorithmParameterException
	 * @throws InvalidKeyException
	 */
	public static String decryptText(String cipherText) throws DigestException, NoSuchAlgorithmException, NoSuchPaddingException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException, InvalidKeyException {
		String decryptedText = null;
		byte[] cipherData = Base64.getDecoder().decode(cipherText);
		byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);

		final byte[][] keyAndIV = GenerateKeyAndIV(32, 16, 1, saltData, SECRET.getBytes(StandardCharsets.UTF_8), MessageDigest.getInstance("MD5"));
		SecretKeySpec key = new SecretKeySpec(keyAndIV[0], "AES");
		IvParameterSpec iv = new IvParameterSpec(keyAndIV[1]);

		byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
		Cipher aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
		aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
		byte[] decryptedData = aesCBC.doFinal(encrypted);
		decryptedText = new String(decryptedData, StandardCharsets.UTF_8);
		return decryptedText;
	}

	private static byte[][] GenerateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password, MessageDigest md) throws DigestException {

		int digestLength = md.getDigestLength();
		int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
		byte[] generatedData = new byte[requiredLength];
		int generatedLength = 0;

		md.reset();

		// Repeat process until sufficient data has been generated
		while (generatedLength < keyLength + ivLength) {

			// Digest data (last digest if available, password data, salt if available)
			if (generatedLength > 0)
				md.update(generatedData, generatedLength - digestLength, digestLength);
			md.update(password);
			if (salt != null)
				md.update(salt, 0, 8);
			md.digest(generatedData, generatedLength, digestLength);

			// additional rounds
			for (int i = 1; i < iterations; i++) {
				md.update(generatedData, generatedLength, digestLength);
				md.digest(generatedData, generatedLength, digestLength);
			}

			generatedLength += digestLength;
		}

		// Copy key and IV into separate byte arrays
		byte[][] result = new byte[2][];
		result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
		if (ivLength > 0)
			result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);

		return result;
	}

	/**
	 * AES Encrypt Front end
	 * @param plainText
	 * @return
	 */
	public static String encryptText(String plainText) {
		FileReader cryptoMinJs = null;
		EncryptionRequest result = new EncryptionRequest();
		try {
			// For Local use
//			cryptoMinJs = new FileReader(new File(EncryptionUtils.class.getClassLoader().getResource("crypto-js.min.js").getFile()));
			// For server use
			cryptoMinJs = new FileReader("/apps/services/common/crypto-js.min.js");

			ScriptEngineManager factory = new ScriptEngineManager();
			ScriptEngine engine = factory.getEngineByName("JavaScript");
			engine.put("result", result);
			String js = "enc=CryptoJS.AES.encrypt('" + plainText + "','" + SECRET + "'); result.setValue(enc);";
			engine.eval(cryptoMinJs);
			engine.eval(js);
		} catch (FileNotFoundException e) {
			logger.error("File not found exception"+e.getMessage());
		} catch (ScriptException e) {
			logger.error("Script convert exception"+e.getMessage());
		}

		return result.getValue();

	}
}