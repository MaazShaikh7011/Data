package com.opl.jns.published.utils.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opl.jns.published.utils.enums.SchemeMaster;

public class OPLUtils {

	private static final Logger logger = LoggerFactory.getLogger(OPLUtils.class);

	public static final String REQUEST_HEADER_AUTHENTICATE = "ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo";
	public static final String REQUEST_HEADER_AUTHENTICATE_VALUE = "true";
	public static final Long OTHER_CHANNEL = 1l;
	public static final String BANK_CALL_RESTRICTION_ORG_LIST = "BANK_CALL_RESTRICTION_ORG_LIST";
	public static final String OPT_OUT_CALL_RESTRICTION_ORG_LIST = "OPT_OUT_CALL_RESTRICTION_ORG_LIST";
	public static final String PUSH_ENROLLMENT_CALL_RESTRICTION_ORG_LIST = "PUSH_ENROLLMENT_CALL_RESTRICTION_ORG_LIST";
	public static final String PUSH_CLAIM_CALL_RESTRICTION_ORG_LIST = "PUSH_CLAIM_CALL_RESTRICTION_ORG_LIST";
	public static final String CLAIM_PUSH_SEND_DOCUMENT_NULL = "CLAIM_PUSH_SEND_DOCUMENT_NULL";
	public static final String SKIP_TO_UPDATE_PUSH_ENROLL_BANK = "SKIP_TO_UPDATE_PUSH_ENROLL_BANK";
	public static final String ENROLLMENT_COI_SET_NULL = "ENROLLMENT_COI_SET_NULL";
	public static final String NOMINEE_UPDATE_CALL_RESTRICTION_ORG_LIST = "NOMINEE_UPDATE_CALL_RESTRICTION_ORG_LIST";

	public static boolean isListNullOrEmpty(Collection<?> data) {
		return (data == null || data.isEmpty());
	}

	public static String isStringEmpty(String value) {
		value = value.trim();
		if (value.isEmpty() || value == null || "undefined".equals(value) || "null".equals(value) || "".equals(value)) {
			return "";
		}
		return value;
	}

	public static boolean isObjectNullOrEmpty(Object value) {
		return (value == null
				|| (value instanceof String s
						? (s.isEmpty() || "".equals(s.trim()) || "null".equals(value)
								|| "undefined".equals(value))
						: false));
	}

	public static boolean isObjectNullOrEmptyOrDash(Object value) {
		return (value == null || (value instanceof String s
				? (s.isEmpty() || "".equals(s.trim()) || "null".equals(value)
						|| "-".equals(value) || "undefined".equals(value))
				: false));
	}

	public static boolean isObjectListNull(Object... args) {
		for (Object object : args) {
			boolean flag = false;
			if (object instanceof List list) {
				flag = isListNullOrEmpty(list);
				if (flag)
					return true;
				else
					continue;
			}
			flag = isObjectNullOrEmpty(object);
			if (flag)
				return true;
		}
		return false;
	}

	public static Double getPMTCalculationByLoanAmt(double roi, double tenure, double circularLoanAmount) {
		return roi / (1.0D - Math.pow(1.0D + roi, -tenure)) * circularLoanAmount * 12.0D;
	}

	public static Double convertRoundOffValue(Double finalLoanAmountNew) {
		// logger.info("ENTER CONVERT RounfOFF Value======>"+finalLoanAmountNew);
		// THIS IS USE FOR BEFORE VALE DIGIT 3 IS BASED ON 500 CONDITION EX. 4714415.0
		// RES.4714000.0

		Double finalEligibleValue;
		Long firstDgt;
		if (finalLoanAmountNew != null) {
			String s1 = String.valueOf(finalLoanAmountNew);
			s1 = s1.substring(0, s1.indexOf('.'));
			Long val = 0l;
			Long l1 = 0l;
			String s2 = s1;

			val = Long.parseLong(s2);
			if (val > 3) {
				s2 = String.valueOf(val);
//		                    logger.info("ACTUAL VALUE------->"+s2);
				if (s2.length() > 3) {

					l1 = Long.parseLong(s2.substring(s2.length() - 3));
					if (l1 > 500) {
						s2 = s2.substring(0, s2.length() - 3);
						firstDgt = Long.parseLong(s2);
//		                    logger.info("IF VALUE IS MORE THEN--(500)----->>>>>" + firstDgt);
						firstDgt++;
					} else {
						s2 = s2.substring(0, s2.length() - 3);
						firstDgt = Long.parseLong(s2);
						// firstDgt = Long.parseLong(s2);
//		                    logger.info("IF VALUE IS Less THEN---(500)---->>>>>" + firstDgt);
					}

					s1 = firstDgt.toString() + "000";
					finalEligibleValue = Double.parseDouble(s1);
//		        logger.info("FINAL ACTUAL VALUE AFTER ROUNDOFF---->>>>>" + finalEligibleValue);
					return finalEligibleValue;
				}
			}
		}
		return finalLoanAmountNew;
	}
	
	/**
	 * Accepts double value like 14.55 and return 10 and if 15 than 20
	 * 
	 * @param finalLoanAmountNew
	 * @return
	 */
	public static Double convertRoundOffValueToTen(Double finalLoanAmountNew) {

		Double finalEligibleValue;
		Long firstDgt;
		if (finalLoanAmountNew != null) {

			String s1 = String.valueOf(finalLoanAmountNew);
			s1 = s1.substring(0, s1.indexOf('.'));

			Long val = 0l;
			Long l1 = 0l;
			String s2 = s1;

			val = Long.parseLong(s2);
			if (val > 1) {
				s2 = String.valueOf(val);
				if (s2.length() > 1) {

					l1 = Long.parseLong(s2.substring(s2.length() - 1));

					if (l1 > 4) {
						s2 = s2.substring(0, s2.length() - 1);
						firstDgt = Long.parseLong(s2);
						firstDgt++;
					} else {
						s2 = s2.substring(0, s2.length() - 1);
						firstDgt = Long.parseLong(s2);
					}

					s1 = firstDgt.toString() + "0";
					finalEligibleValue = Double.parseDouble(s1);
					return finalEligibleValue;
				}
			}
		}
		return finalLoanAmountNew;
	}
	
	public static boolean isNumeric(String strNum) {
		if (isObjectNullOrEmpty(strNum)) {
			return false;
		}
		try {
			Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}
	
	public static String generateUUIDOfLength20() {
		return UUID.randomUUID().toString().replace("-","").substring(0,20);
	}
	
	public static Long getApplicationIdFromUrn(String urn) {
		try {
			return Long.valueOf(urn.split("-")[4]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Long getSchemeIdFromUrn(String urn) {
		try {
			String schemeName = urn.split("-")[1];
			return SchemeMaster.getByCode(schemeName).getId();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static boolean isOptOutCall(long orgId) {
		String bankList = System.getenv(OPT_OUT_CALL_RESTRICTION_ORG_LIST);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return !list.contains(orgId);
	}
	
	public static boolean isPushEnrollmentCall(long orgId,long source) {
		String bankList = System.getenv(PUSH_ENROLLMENT_CALL_RESTRICTION_ORG_LIST);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return list.contains(orgId) ? (source!=OTHER_CHANNEL ? true : false) : true;
	}
	
	public static boolean isPushClaimCall(long orgId,long source) {
		String bankList = System.getenv(PUSH_CLAIM_CALL_RESTRICTION_ORG_LIST);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return list.contains(orgId) ? (source!=OTHER_CHANNEL ? true : false) : true;
	}
	
	public static boolean isBankCall(long orgId,long source) {
		String bankList = System.getenv(BANK_CALL_RESTRICTION_ORG_LIST);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return list.contains(orgId) ? (source!=OTHER_CHANNEL ? true : false) : true;
	}
	
	public static boolean isSetClaimDocumentByte(long orgId) {
		String bankList = System.getenv(CLAIM_PUSH_SEND_DOCUMENT_NULL);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return !list.contains(orgId);
	}
	
	public static boolean isSkipToUpdatePushEnrollBank(long orgId) {
		String bankList = System.getenv(SKIP_TO_UPDATE_PUSH_ENROLL_BANK);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return !list.contains(orgId);
	}
	
	public static boolean isSetCoiNull(long orgId) {
		String bankList = System.getenv(ENROLLMENT_COI_SET_NULL);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return list.contains(orgId);
	}
	
	public static boolean isNomineeUpdateCall(long orgId) {
		String bankList = System.getenv(NOMINEE_UPDATE_CALL_RESTRICTION_ORG_LIST);
		if (OPLUtils.isObjectNullOrEmpty(bankList)) {
			return true;
		}
		List<Long> list = new ArrayList<Long>();
		for (String s : bankList.split(",")) {
			list.add(Long.parseLong(s));
		}
		return !list.contains(orgId);
	}

}
