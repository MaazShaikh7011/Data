package com.opl.jns.published.utils.enums;

public enum SchemeMaster {
	ALL_SCHEME(-1L, -1L, "All Scheme", "All", -1),
	PMSBY(1L, 1L, "Pradhan Mantri Suraksha Bima Yojana", "PMSBY", 1),
	PMJJBY(2L, 1L, "Pradhan Mantri Jeevan Jyoti Bima Yojana", "PMJJBY", 1);

	private final Long id;
	private final Long loanMasterId;
	private final String name;
	private final String shortName;
	private final Integer bussinessTypeId;

	private SchemeMaster(Long id, Long loanMasterId, String name, String shortName, Integer bussinessTypeId) {
		this.id = id;
		this.loanMasterId = loanMasterId;
		this.name = name;
		this.shortName = shortName;
		this.bussinessTypeId = bussinessTypeId;
	}

	public Long getId() {
		return id;
	}


	public String getName() {
		return name;
	}

	public String getShortName() {
		return shortName;
	}


	public static SchemeMaster getById(Long v) {
		for (SchemeMaster c : SchemeMaster.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static SchemeMaster getByCode(String v) {
		for (SchemeMaster c : SchemeMaster.values()) {
			if (c.shortName.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SchemeMaster[] getAll() {
		return SchemeMaster.values();
	}

	public Long getLoanMasterId() {
		return loanMasterId;
	}

	public Integer getBussinessTypeId() {
		return bussinessTypeId;
	}


}
