package com.opl.jns.published.utils.common.sbi;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class SBIEncryptedRequest implements Serializable {

	private static final long serialVersionUID = -7894008183348211426L;

	@JsonProperty("REQUEST_REFERENCE_NUMBER")
	private String requestRefNumber;

	@JsonProperty("REQUEST")
	private String request;

	@JsonProperty("DIGI_SIGN")
	private String digiSign;

	private String accessToken;
	private String secretKey;
	
	
	public SBIEncryptedRequest() {
		super();
	}
	public SBIEncryptedRequest(String requestRefNumber, String request, String digiSign, String accessToken,
			String secretKey) {
		super();
		this.requestRefNumber = requestRefNumber;
		this.request = request;
		this.digiSign = digiSign;
		this.accessToken = accessToken;
		this.secretKey = secretKey;
	}
	public String getRequestRefNumber() {
		return requestRefNumber;
	}
	public void setRequestRefNumber(String requestRefNumber) {
		this.requestRefNumber = requestRefNumber;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getDigiSign() {
		return digiSign;
	}
	public void setDigiSign(String digiSign) {
		this.digiSign = digiSign;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getSecretKey() {
		return secretKey;
	}
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	
}
