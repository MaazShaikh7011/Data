package com.opl.jns.published.utils.common;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import jakarta.xml.bind.DatatypeConverter;

import com.opl.jns.published.utils.common.sbi.SBIEncryptedRequest;


public class SBIEncryptionUtils {
	private static final String PAYLOAD_ENCRYPT_ALGO = "AES/GCM/NoPadding";
	private static final String KEY_ENCRYPT_ALGO = "RSA/ECB/OAEPPadding";
	private static final int TAG_LENGTH_BIT = 128;
	private static final String AES_ALGO = "AES";
	private static final String RSA = "RSA";
	private static final String SHA_256_RSA_ALGO = "SHA256withRSA";
	private static final String X_509 = "X.509";
	private static final Charset UTF_8 = StandardCharsets.UTF_8;

	/***
	 * ENCRYPT PAYLOAD USING SECRET KEY AND IV
	 * @param request
	 * @param key
	 * @param iv
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String payloadEncrypt(byte[] request, byte[] key, byte[] iv)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(PAYLOAD_ENCRYPT_ALGO);
		SecretKeySpec keySpec = new SecretKeySpec(key, AES_ALGO);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
		byte[] cipherText = cipher.doFinal(request);
		return Base64.getEncoder().encodeToString(cipherText);
	}

	/**
	 * SIGN PAYLOAD DATA USING JANSURAKSHA PRIVATE KEY
	 * @param input
	 * @param privateKey
	 * @return
	 * @throws Exception
	 */
	private String signPayloadData(String input, String privateKey) throws Exception {
		// Remove markers and new line characters in private key
		String realPK = privateKey
				.replace("-----END PRIVATE KEY-----", "")
				.replace("-----BEGIN PRIVATE KEY-----", "")
				.replace("\n", "")
				.replace("\r", "");

		byte[] b1 = Base64.getDecoder().decode(realPK);

		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
		KeyFactory kf = KeyFactory.getInstance(RSA);

		Signature privateSignature = Signature.getInstance(SHA_256_RSA_ALGO);
		privateSignature.initSign(kf.generatePrivate(spec));
		privateSignature.update(input.getBytes(UTF_8));
		byte[] s = privateSignature.sign();
		return Base64.getEncoder().encodeToString(s).replaceAll("\r\n", "");
		 
	}

	/**
	 * ENCRYPT SECERET KEY USING SBI PUBLIC KEY
	 * @param text
	 * @param publicKeyStr
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws CertificateException
	 * @throws InvalidKeyException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String encryptUsingPublic(byte[] text, String publicKeyStr) throws NoSuchAlgorithmException, NoSuchPaddingException, CertificateException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(KEY_ENCRYPT_ALGO);
		PublicKey publicKey = getPublicKey(publicKeyStr);
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] cipherText = cipher.doFinal(text);
		return Base64.getEncoder().encodeToString(cipherText);
	}

	/**
	 * Public Key String to Generate Public Certificate. 
	 * @param publickeyCert
	 * @return
	 * @throws CertificateException
	 */
	private static PublicKey getPublicKey(String publickeyCert) throws CertificateException {
		CertificateFactory certFactory = CertificateFactory.getInstance(X_509);
		InputStream in = new ByteArrayInputStream(publickeyCert.getBytes());
		X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(in);
		return certificate.getPublicKey();
	}

	/**
	 * GENERATE REFERENCE NUMBER
	 * @param orgCode
	 * @return
	 */
	private String gnerateReferenceNumber(String orgCode) {
		Date date = new Date();
		return orgCode + "JK" + getTimestampFormat(date, "YYDDD") + getTimestampFormat(date, "hhMMsss")
				+ UUID.randomUUID().toString().replace("-", "").substring(0, 8);
	}

	public String generateSequenceNumber(Integer value) {
		return "%08d".formatted(value);
	}

	private String getTimestampFormat(Date date, String format) {
		return new SimpleDateFormat(format).format(date);
	}

	private byte[] getIVFromAESKey(byte[] encoded) {
		return Arrays.copyOfRange(encoded, 0, 12);
	}

	/**
	 * Prepare Encrypted Request for SBI Gen6 Encryption
	 * @param plainRequest
	 * @param pvtKey
	 * @param pubKey
	 * @param orgCode
	 * @return
	 * @throws Exception
	 */
	public SBIEncryptedRequest prepareRequest(Object plainRequest, String pvtKey, String pubKey,String orgCode)
			throws Exception {

		// CLASS DATA TO STRING
		String request = MultipleJSONObjectHelper.getStringfromObject(plainRequest);

		String key = UUID.randomUUID().toString().replace("-", "");

		byte[] iv = getIVFromAESKey(key.getBytes());

		// GENERATE REFENRENCE NUMBER
		String referenceNo = gnerateReferenceNumber(orgCode);

		// PAYLOAS ENCRYPT
		String payloadEncrypt = payloadEncrypt(request.getBytes(), key.getBytes(), iv);

		// SIGN PAYLOAD
		String signSHA256RSA = signPayloadData(request, pvtKey);

		// ENCRYPT KEY USING PUBLIC CERTIFICATE
		String encryptUsingPublic = encryptUsingPublic(key.getBytes(), pubKey);

		// MAPPING ENCRYPTED DATA TO CLASS
		return new SBIEncryptedRequest(referenceNo, payloadEncrypt, signSHA256RSA, encryptUsingPublic, key);
	}

	/**
	 * SBI Decryption
	 * @param response
	 * @param referenceNumber
	 * @return
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidAlgorithmParameterException
	 */
	public String decrypt(String response, String referenceNumber) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
	
		byte[] iv = getIVFromAESKey(referenceNumber.getBytes());
		return decryptRequestBody(Base64.getDecoder().decode(response), referenceNumber.getBytes(), iv);
	}
	
	/**
	 * Decrypt Decrypted Response
	 * @param cipherText
	 * @param key
	 * @param iv
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private String decryptRequestBody(byte[] cipherText, byte[] key, byte[] iv)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		Cipher cipher = Cipher.getInstance(PAYLOAD_ENCRYPT_ALGO);
		SecretKeySpec keySpec = new SecretKeySpec(key, AES_ALGO);
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
		byte[] decryptedText = cipher.doFinal(cipherText);

		return new String(decryptedText);
	}
	
	/**
	 * Decrypt Access Token and find Secret Key 
	 * @param encdata
	 * @return
	 */
	public String RSADecrypt(String encdata,String privateKey) {
		String data = "";
		try {

			byte[] privebase64decKey = Base64.getDecoder().decode(privateKey);
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privebase64decKey);
			KeyFactory keyFactory = KeyFactory.getInstance(RSA);
			PrivateKey privaKey = keyFactory.generatePrivate(keySpec);

			Cipher cipher = Cipher.getInstance(KEY_ENCRYPT_ALGO);
			cipher.init(Cipher.DECRYPT_MODE, privaKey);
			byte[] dataByte = Base64.getDecoder().decode(encdata);
			data = new String(cipher.doFinal(dataByte));
		}

		catch (Exception e) {
			return "X-JavaError" + " " + e.getMessage();
		}
		return data;
	}
	
	/**
	 * Verify DIGI Sign with Plain Response
	 * @param data
	 * @param signature
	 * @return
	 */
	public static boolean digiSignVerify(String data, String signature,String publicKey) {

		try {
			String base64publickey = getPublicKeyDecrypt(publicKey);
			byte[] base64decpublivKey = Base64.getDecoder().decode(base64publickey);
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(base64decpublivKey);
			KeyFactory keyFactory = KeyFactory.getInstance(RSA);
			PublicKey pubKey = keyFactory.generatePublic(keySpec);
			Signature privateSignature = Signature.getInstance(SHA_256_RSA_ALGO);
			privateSignature.initVerify(pubKey);
			privateSignature.update(data.getBytes());
			byte[] y = Base64.getDecoder().decode(signature);
			;
			boolean bool = privateSignature.verify(y);
			if (bool) {
				//"Signature Verified";
				return true;
			} else {
				//"Signature failed";
				return false;
			}			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Bank Public Key to Verify Digi Sign 
	 * @param certPath
	 * @return
	 */
	public static String getPublicKeyDecrypt(String publicKeyStr)
	{
		try {			
			PublicKey publicKey = getPublicKey(publicKeyStr);
			byte[] pk = publicKey.getEncoded();
			return DatatypeConverter.printBase64Binary(pk);
		} catch (Exception e) {
			return "X-JavaError" + " " + e.toString();
		}
   	}
}
