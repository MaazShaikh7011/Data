package com.opl.jns.ddregistry.api.model.updateClaimStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UpdateClaimStatusProxy {

	private String claimReferenceId;
	private String urn;
	private Integer claimStatus;
	private Integer reason;
	private TransactionDetailsProxy transactionDetails;
}