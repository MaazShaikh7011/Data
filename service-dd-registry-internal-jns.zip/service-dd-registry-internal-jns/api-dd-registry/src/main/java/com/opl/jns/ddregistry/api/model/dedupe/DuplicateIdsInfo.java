package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DuplicateIdsInfo {

//	@JsonProperty("kycId1")
	private KycId kycId1;
	
//	@JsonProperty("kycId2")
	private KycId kycId2;

}
