package com.opl.jns.ddregistry.api.model.dedupe;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DedupApiResponse extends CommonDedupApiResponse{
	
    @JsonProperty("duplicate_ids_info")
    private DuplicateIdsInfo duplicateIdsInfo;

    @JsonProperty("records")
    private List<Record> records;

}