package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DedupApiResProxy {

    private Boolean success;
    private Integer status;
    private String message;
    private String timestamp;
    private String token;
    private ApiData data;

    public DedupApiResProxy(Integer status, String message) {
        this.status = status;
        this.message = message;
    }
}
