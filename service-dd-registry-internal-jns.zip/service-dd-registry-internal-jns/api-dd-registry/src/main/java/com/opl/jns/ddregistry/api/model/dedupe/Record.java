package com.opl.jns.ddregistry.api.model.dedupe;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"urn",
"id",
"enrollment_date",
"full_name",
"dob",
"pan",
"voterid",
"passport",
"drivingl",
"aadhar",
"org_id",
"insurer_id",
"match_ratio"
})
@Generated("jsonschema2pojo")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Record {

	@JsonProperty("urn")
	private String urn;
	@JsonProperty("id")
	private Integer id;
	@JsonProperty("enrollment_date")
	private String enrollmentDate;
	@JsonProperty("full_name")
	private String fullName;
	@JsonProperty("dob")
	private String dob;
	@JsonProperty("pan")
	private String pan;
	@JsonProperty("voterid")
	private String voterid;
	@JsonProperty("passport")
	private String passport;
	@JsonProperty("drivingl")
	private String drivingl;
	@JsonProperty("aadhar")
	private String aadhar;
	@JsonProperty("org_id")
	private Long orgId;
	@JsonProperty("insurer_id")
	private Long insurerId;
	@JsonProperty("match_ratio")
	private Double matchRatio;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	@JsonProperty("urn")
	public String getUrn() {
	return urn;
	}

	@JsonProperty("urn")
	public void setUrn(String urn) {
	this.urn = urn;
	}

	@JsonProperty("id")
	public Integer getId() {
	return id;
	}

	@JsonProperty("id")
	public void setId(Integer id) {
	this.id = id;
	}

	@JsonProperty("enrollment_date")
	public String getEnrollmentDate() {
	return enrollmentDate;
	}

	@JsonProperty("enrollment_date")
	public void setEnrollmentDate(String enrollmentDate) {
	this.enrollmentDate = enrollmentDate;
	}

	@JsonProperty("full_name")
	public String getFullName() {
	return fullName;
	}

	@JsonProperty("full_name")
	public void setFullName(String fullName) {
	this.fullName = fullName;
	}

	@JsonProperty("dob")
	public String getDob() {
	return dob;
	}

	@JsonProperty("dob")
	public void setDob(String dob) {
	this.dob = dob;
	}

	@JsonProperty("pan")
	public String getPan() {
	return pan;
	}

	@JsonProperty("pan")
	public void setPan(String pan) {
	this.pan = pan;
	}

	@JsonProperty("voterid")
	public String getVoterid() {
	return voterid;
	}

	@JsonProperty("voterid")
	public void setVoterid(String voterid) {
	this.voterid = voterid;
	}

	@JsonProperty("passport")
	public String getPassport() {
	return passport;
	}

	
	@JsonProperty("passport")
	public void setPassport(String passport) {
	this.passport = passport;
	}

	@JsonProperty("drivingl")
	public String getDrivingl() {
	return drivingl;
	}

	@JsonProperty("drivingl")
	public void setDrivingl(String drivingl) {
	this.drivingl = drivingl;
	}

	@JsonProperty("aadhar")
	public String getAadhar() {
	return aadhar;
	}

	@JsonProperty("aadhar")
	public void setAadhar(String aadhar) {
	this.aadhar = aadhar;
	}

	@JsonProperty("org_id")
	public Long getOrgId() {
	return orgId;
	}

	@JsonProperty("org_id")
	public void setOrgId(Long orgId) {
	this.orgId = orgId;
	}

	@JsonProperty("insurer_id")
	public Long getInsurerId() {
	return insurerId;
	}

	@JsonProperty("insurer_id")
	public void setInsurerId(Long insurerId) {
	this.insurerId = insurerId;
	}

	@JsonProperty("match_ratio")
	public Double getMatchRatio() {
	return matchRatio;
	}

	@JsonProperty("match_ratio")
	public void setMatchRatio(Double matchRatio) {
	this.matchRatio = matchRatio;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}
	
}