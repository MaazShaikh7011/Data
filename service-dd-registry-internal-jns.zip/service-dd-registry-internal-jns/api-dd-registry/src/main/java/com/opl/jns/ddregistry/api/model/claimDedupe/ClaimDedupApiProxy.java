package com.opl.jns.ddregistry.api.model.claimDedupe;

import com.opl.jns.ddregistry.api.model.dedupe.DedupApiReqProxy;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDedupApiProxy extends DedupApiReqProxy {

    private Integer claimTypeId;
    private String enrollmentDate;
    private String dateOfDeath;
    private String dateOfAccident;
    private String isNameMatch;
}
