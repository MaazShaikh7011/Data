package com.opl.jns.ddregistry.api.model.updateClaimStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UpdateClaimStatusResponse {

	private String message;
	private Integer status;

	public UpdateClaimStatusResponse(Integer status, String message) {
		this.message = message;
		this.status = status;
	}
}