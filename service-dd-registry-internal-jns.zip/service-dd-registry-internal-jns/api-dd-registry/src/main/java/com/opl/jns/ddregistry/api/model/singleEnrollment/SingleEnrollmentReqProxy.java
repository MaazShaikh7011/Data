package com.opl.jns.ddregistry.api.model.singleEnrollment;

import com.opl.jns.ddregistry.api.model.dedupe.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SingleEnrollmentReqProxy {

	private String urn;
	private String source;
	private String scheme;
	private CustomerDetails customerDetails;
	private KycDetails kycDetails;
	private PolicyDetails policyDetails;
	private Long orgId;
	private Integer enrollStatus;
}
