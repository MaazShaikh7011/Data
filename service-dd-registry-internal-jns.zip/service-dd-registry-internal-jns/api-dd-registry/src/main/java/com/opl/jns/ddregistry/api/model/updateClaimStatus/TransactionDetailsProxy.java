package com.opl.jns.ddregistry.api.model.updateClaimStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TransactionDetailsProxy {

	private String transactionTimeStamp;
	private Long transactionAmount;
	private String transactionUTR;
}