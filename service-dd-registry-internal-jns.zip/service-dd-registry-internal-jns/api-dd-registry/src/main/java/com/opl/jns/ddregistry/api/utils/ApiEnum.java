package com.opl.jns.ddregistry.api.utils;

public enum ApiEnum {

    DE_DUP(1L,"dedupe"),
    SINGLE_ENROLLMENT(2L,"singleEnrollment"),
    UPDATE_ENROLLMENT_STATUS(3L,"updateEnrollmentStatus"),
	CLAIM_DE_DUPE(4L,"claimDedupe"),
	PUSH_CLAIM(5L,"pushClaim"),
	UPDATE_CLAIM_STATUS(6L,"updateClaimStatus");

    Long apiId;

    private String name;

    ApiEnum(Long id,String name){
        this.apiId = id;
        this.name = name;
    }

    public Long getApiId() {
        return apiId;
    }
}
