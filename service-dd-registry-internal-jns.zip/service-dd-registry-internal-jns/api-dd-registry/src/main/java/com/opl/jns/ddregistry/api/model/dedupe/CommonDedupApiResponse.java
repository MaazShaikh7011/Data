package com.opl.jns.ddregistry.api.model.dedupe;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommonDedupApiResponse {

    @JsonProperty("isDup")
    public Boolean isDup;

    @JsonProperty("status")
    public Integer status;

    @JsonProperty("txn_token")
    public String txnToken;

    @JsonProperty("message")
    public String message;

    @JsonProperty("matchesWith")
    public String matchesWith;

    @JsonProperty("total_duplicated_entries")
    public Integer totalDuplicatedEntries;

}