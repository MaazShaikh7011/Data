package com.opl.jns.ddregistry.api.model.dedupe;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"status", "message", "flag", "duplicateFound"})

public class DedupeResponse {

    @JsonProperty("status")
    private Integer status;
    @JsonProperty("message")
    private String message;
    @JsonProperty("flag")
    private Boolean flag;
    @JsonProperty("duplicateFound")
    private String duplicateFound;

    public DedupeResponse(int status, String message) {
        this.status = status;
        this.message = message;
    }

}
