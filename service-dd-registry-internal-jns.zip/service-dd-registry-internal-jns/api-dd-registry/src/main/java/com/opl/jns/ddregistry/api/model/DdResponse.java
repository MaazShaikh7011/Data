package com.opl.jns.ddregistry.api.model;

import lombok.*;

/**
 * @author - Maaz Shaikh
 * @Date - 9/18/2023
 */
@Getter
@Setter
public class DdResponse {

    int status;
    String response;

    String request;

    String failureReason;

}
