package com.opl.jns.ddregistry.api.model.dedupe;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"urn",
"id",
"claim_ref_id",
"full_name",
"org_id",
"insurer_id",
"date_of_incident",
"date_of_death",
"sum_insured",
"claim_amount",
"passed_amount",
"rejection_counts",
"matched_with"
})
@Generated("jsonschema2pojo")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimRecord {

	@JsonProperty("urn")
	private String urn;
	@JsonProperty("id")
	private Integer id;
	@JsonProperty("claim_ref_id")
	private String claimRefId;
	@JsonProperty("full_name")
	private String fullName;
	@JsonProperty("org_id")
	private Long orgId;
	@JsonProperty("insurer_id")
	private Long insurerId;
	@JsonProperty("date_of_incident")
	private String dateOfIncident;
	@JsonProperty("date_of_death")
	private String dateOfDeath;
	@JsonProperty("sum_insured")
	private Long sumInsured;
	@JsonProperty("claim_amount")
	private Long claimAmount;
	@JsonProperty("passed_amount")
	private Long passedAmount;
	@JsonProperty("rejection_counts")
	private Long rejectionCounts;
	@JsonProperty("matched_with")
	private String matchedWith;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}
	
}