package com.opl.jns.ddregistry.api.model.dedupe;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDedupApiResponse extends CommonDedupApiResponse{
	
    @JsonProperty("reqest_time")
    private String reqestTime;

    @JsonProperty("req_process_time")
    private Double reqProcessTime;
	
    @JsonProperty("duplicate_ids_info")
    private DuplicateIdsInfo duplicateIdsInfo;

    @JsonProperty("records")
    private List<ClaimRecord> records;
    
    public ClaimDedupApiResponse(Integer status,String message) {
        this.message = message;
        this.status = status;
    }
    
	public ClaimDedupApiResponse(Boolean isDup, String message) {
		super();
		this.isDup = isDup;
		this.message = message;
	}

}