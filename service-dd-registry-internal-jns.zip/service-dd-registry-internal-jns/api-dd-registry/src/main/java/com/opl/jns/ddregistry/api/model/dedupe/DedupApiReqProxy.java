package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DedupApiReqProxy {

    private String kycId1;
    private String kycIdValue1;
    private String kycId2;
    private String kycIdValue2;
    private String ckycNumber;
    private String gender;
    private String firstName;
    private String middleName;
    private String lastName;
    private String fatherHusbandName;
    private String mob;
    private Integer pincode;
    private Long orgId;
    private Long insurerOrgId;
    private String dob;
    private String bankCode;
    private String accNo;
    private String scheme;
    private String accountStatus;
    private String type;
    private String cif;
    private String urn;
    private String claimReferenceId;
    private String firNo;
    private String firDate;
    private String panchnamaNo;
    private String panchnamaDate;
    private String postMortemReportNo;
    private String postMortemReportDate;
    private String deathOrdisabilityCertificateReportNo;
    private String deathOrdisabilityCertificateReportDate;
    private String documentReceivingDate;
}
