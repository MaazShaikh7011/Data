package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerDetails {

	private String dob;
	private String gender;
	private String accountHolderName;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fatherHusbandName;
	private Long orgId;
	private String custIfsc;
	private String accountNumber;
	private String cif;
	
}
