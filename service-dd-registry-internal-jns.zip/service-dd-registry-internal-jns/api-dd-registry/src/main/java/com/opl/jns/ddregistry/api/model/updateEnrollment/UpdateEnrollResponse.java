package com.opl.jns.ddregistry.api.model.updateEnrollment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UpdateEnrollResponse {

	private String message;
	private Integer status;
	private Boolean success;
	private String timestamp;
	private String reqProcTime;

	public UpdateEnrollResponse(String message, Integer status) {
		this.message = message;
		this.status = status;
	}
}
