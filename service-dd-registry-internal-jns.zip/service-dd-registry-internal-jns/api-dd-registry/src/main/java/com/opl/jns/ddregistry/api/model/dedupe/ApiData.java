package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApiData {

	private String isMatched;
	private String matchesWith;
	private String bankName;
	private String message;
	
	
	public ApiData(String isMatched, String message) {
		super();
		this.isMatched = isMatched;
		this.message = message;
	}
	
	
	
}
