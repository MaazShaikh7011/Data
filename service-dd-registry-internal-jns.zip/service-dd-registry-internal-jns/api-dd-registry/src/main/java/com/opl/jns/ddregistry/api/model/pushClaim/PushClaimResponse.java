package com.opl.jns.ddregistry.api.model.pushClaim;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class PushClaimResponse {

	private String message;
	private String claimRefId;
	private Integer status;
	private String timestamp;
	private String token;
	private String reqProcTime;

    public PushClaimResponse(Integer status,String message) {
        this.message = message;
        this.status = status;
    }
}