package com.opl.jns.ddregistry.api.model.claimDedupe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.ddregistry.api.model.dedupe.DedupApiResponse;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDedupResponse extends DedupApiResponse {

    @JsonProperty("reqest_time")
    private String reqestTime;

    @JsonProperty("req_process_time")
    private Double reqProcessTime;
    
}