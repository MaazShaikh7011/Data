package com.opl.jns.ddregistry.api.model.pushClaim;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PushClaimProxy {

	private String claimReferenceId;
	private String urn;
	private String scheme;
	private String gender;
	private String applicantAccNo;
	private Long orgId;
	private String applicantDob;
	private Long insurerOrgId;
	private String masterPolicyNumber;
	private String applicantfirstName;
	private String applicantmiddleName;
	private String applicantlastName;
	private String dateofDeath;
	private String dateofAccident;
	private Integer claimStatusId;
	private String claimType;
	private String claimDate;
	private String enrollmentDate;
}