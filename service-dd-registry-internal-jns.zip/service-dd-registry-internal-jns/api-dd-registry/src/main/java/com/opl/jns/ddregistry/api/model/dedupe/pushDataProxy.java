package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class pushDataProxy {

	private Integer page;
	private Integer count;
	private Boolean isUpdateStatusPush;
	private Boolean isSingleEnrollmentAndUpdateStatusPush;

}
