package com.opl.jns.ddregistry.api.model.singleEnrollment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SingleEnrollmentRequest extends SingleEnrollmentReqProxy{

	private long applicationId;

}
