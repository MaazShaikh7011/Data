package com.opl.jns.ddregistry.api.model.singleEnrollment;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SingleEnrollmentResponse {

    private String message;
    private Integer status;
    private String timestamp;
    private String token;
    private String reqProcTime;

    public SingleEnrollmentResponse(Integer status,String message) {
        this.message = message;
        this.status = status;
    }
}