package com.opl.jns.ddregistry.api.model.updateEnrollment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateEnrollReqProxy {

	private String urn;
	private Integer status;
	private String reason;
	private String dateOfEnrollment;
	
}
