package com.opl.jns.ddregistry.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeOutConfig  {

	private Integer readTimeOut;
	private Integer conTimeOut;
}
