package com.opl.jns.ddregistry.api.model.dedupe;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class KycDetails {

	private String kycId1;
	private String kycIdValue1;
	private String kycId2;
	private String kycIdValue2;
	private String panNumber;
	private String aadhaarNumber;
	private String ckyc;
	private String ckycNumber;
}
