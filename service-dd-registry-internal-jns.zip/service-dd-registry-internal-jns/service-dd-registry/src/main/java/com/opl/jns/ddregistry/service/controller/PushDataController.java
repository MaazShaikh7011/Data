package com.opl.jns.ddregistry.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.ddregistry.api.model.dedupe.pushDataProxy;
import com.opl.jns.ddregistry.service.service.PushDataService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PushDataController {

	private static final String SUCCESS = " Success Data ";
	
	@Autowired
	PushDataService pushDataService;
	
	@PostMapping(value = "/pushData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<com.opl.jns.utils.common.CommonResponse> pushData(@RequestBody pushDataProxy request) {
        try {
            log.info("Enter in push app -->");
            return new ResponseEntity<>(pushDataService.pushData(request),HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get stage details ------>", e);
            return new ResponseEntity<com.opl.jns.utils.common.CommonResponse>(com.opl.jns.utils.common.CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
	
}
