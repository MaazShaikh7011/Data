package com.opl.jns.ddregistry.service.controller;

import com.opl.jns.config.utils.*;
import com.opl.jns.ddregistry.service.service.*;
import com.opl.jns.utils.common.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/audit")
public class AuditDetailController {

    @Autowired
    private AuditDetailService auditDetailService;


    @GetMapping(value = "/getDDRegistryReqRes/{auditId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getDDRegistryReqRes(@PathVariable("auditId") Long auditId) {
        try {
            log.info("Enter In getDDRegistryReqRes() auditId -> ({})", auditId);
            return new ResponseEntity<>(auditDetailService.getDDRegistryReqRes(auditId), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch DD Registry Req Res --->", e);
            return new ResponseEntity<>(new CommonResponse("Something went wrong", false,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    @GetMapping("/apiList")
    public ResponseEntity<?> fetchApiList() {
        try {
            log.info("Enter In fetchApiList()");
            return new ResponseEntity<>(auditDetailService.fetchApiList(), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Saved Registry Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


}
