package com.opl.jns.ddregistry.service.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "api_master", indexes = { })
public class ApiMaster implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_DD_REGISTRY, name = "api_master_seq_gen", sequenceName = "api_master_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "url")
    private String url;

    @Column(name = "header_config")
    private String headerConfig;

    @Column(name = "timeout_config")
    private String timeOutConfig;

}
