package com.opl.jns.ddregistry.service.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "api_storage_dec", indexes = { })
public class APIStorage implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_storage_dec_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_DD_REGISTRY, name = "api_storage_dec_seq_gen", sequenceName = "api_storage_dec_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "log_audit_id", nullable = true)
	private Long logAudit;

	@Column(name = "storage_id", nullable = true)
	private String storageId;

	@Column(name = "success", nullable = true)
	private Boolean success;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	public APIStorage() {
		super();
		this.createdDate = new Date();
		this.success = false;
	}

}
