package com.opl.jns.ddregistry.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.ddregistry.service.domain.APIStorage;

@Repository
public interface PayloadAuditRepository extends JpaRepository<APIStorage, Long> {
    APIStorage findByLogAudit(Long auditId);

}