package com.opl.jns.ddregistry.service.service;

import com.opl.jns.utils.common.*;

import java.util.*;

public interface AuditDetailService {

	void auditLog(Long applicationId, Long orgId, Long apiId, String request, String response, String failureReason,
			Date createdDate, Integer responseStatus,String referenceId, String accountNo, String cif, String urn, Date modifiedDate);


	CommonResponse fetchApiList();

	CommonResponse getDDRegistryReqRes(Long auditId);
}
