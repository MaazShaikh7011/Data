package com.opl.jns.ddregistry.service.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit", indexes = {
		@Index(columnList = "log_audit_id", name = DBNameConstant.JNS_DD_REGISTRY+ "_payload_audit_log_audit_id_idx"),
})
public class PayloadAuditBack implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payload_audit_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_DD_REGISTRY, name = "payload_audit_seq_gen", sequenceName = "payload_audit_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "log_audit_id", nullable = true)
	private Long logAudit;

	@Column(name = "storage_id", nullable = true)
	private String storageId;

	@Column(name = "success", nullable = true)
	private Boolean success;

//	@Column(name = "type_id", nullable = true)
//	private Integer typeId;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	public PayloadAuditBack() {
		super();
		this.createdDate = new Date();
		this.success = false;
	}

}
