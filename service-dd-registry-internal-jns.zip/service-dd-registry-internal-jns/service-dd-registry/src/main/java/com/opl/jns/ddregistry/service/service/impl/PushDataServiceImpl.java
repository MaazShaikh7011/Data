package com.opl.jns.ddregistry.service.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.opl.jns.ddregistry.api.model.dedupe.pushDataProxy;
import com.opl.jns.ddregistry.api.model.singleEnrollment.SingleEnrollmentResponse;
import com.opl.jns.ddregistry.api.model.updateEnrollment.UpdateEnrollResponse;
import com.opl.jns.ddregistry.service.service.DedupService;
import com.opl.jns.ddregistry.service.service.PushDataService;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PushDataServiceImpl implements PushDataService {

	@Autowired
	DedupService dedupService;

	@Autowired
	ApplicationMasterOtherDetailsRepositoryV3 otherDetailsRepositoryV3;

	@Autowired
	ApplicationMasterRepositoryV3 applicationMasterRepositoryV3;

	@Autowired
	DeDupeRegistryUtility deDupeRegistryUtility;

	@Override
	public CommonResponse pushData(pushDataProxy request) {
		if (request.getIsSingleEnrollmentAndUpdateStatusPush() == Boolean.TRUE) {
			/** push single enrollment */
			pushSingleEnrollment(request);
		}
		
		if(request.getIsUpdateStatusPush()==Boolean.TRUE) {
			/** push update status */
			pushUpdateStatus(request);	
		}

		return new CommonResponse(CommonErrorMsg.Enrollment.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
	}
	
	public void pushSingleEnrollment(pushDataProxy request) {
		Page<Long> ids = otherDetailsRepositoryV3
		.getIdsByIsDedupePushFalse(PageRequest.of(request.getPage(), request.getCount()));
//		List<Long> ids = Arrays.asList(293965505l);
		if (!ids.isEmpty()) {
			log.info("FOUND TOTAL APPLICATION WHICH NOT PUSHED IN DD REGISTRY--------------->" + ids.getSize());
			for (Long applicationId : ids) {
				rePushSingleEnrollmentApplication(applicationId, null);
			}
		}
	}
	
	public void pushUpdateStatus(pushDataProxy request) {
//		List<Long> idsStatus = Arrays.asList(293965505l);
		Page<Long> idsStatus = otherDetailsRepositoryV3
		.getIdsByIsDedupeStatusPushFalse(PageRequest.of(request.getPage(), request.getCount()));
		if (!idsStatus.isEmpty()) {
			log.info("FOUND TOTAL APPLICATION WHICH NOT PUSHED IN DD REGISTRY--------------->" + idsStatus.getSize());
			for (Long applicationId : idsStatus) {
				rePushUpdateEnrollmentStatusApplication(applicationId);
			}
		}
	}

	/**
	 * first run this method and push single Enrollment
	 * 
	 * Push Data on Python
	 * 
	 * @param x2
	 */
	@Async
	public void rePushSingleEnrollmentApplication(Long id, ApplicationMasterV3 appMaster) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(appMaster))
				appMaster = applicationMasterRepositoryV3.findByIdAndIsActiveTrue(id);
			log.info("ENTER IN REGISTRY PUSHED APPLICATION -------------->" + appMaster.getId());
			if (Boolean.TRUE.equals(appMaster.getIsActive())
					&& EnrollStageMaster.COMPLETED.getStageId() == appMaster.getStageId()) {
				SingleEnrollmentResponse callSingleEnrollmentRequest = deDupeRegistryUtility
						.callSingleEnrollmentRequest(id, appMaster);
				if (!OPLUtils.isObjectNullOrEmpty(callSingleEnrollmentRequest)) {
					if (!OPLUtils.isObjectNullOrEmpty(callSingleEnrollmentRequest.getStatus())
							&& callSingleEnrollmentRequest.getStatus() == HttpStatus.OK.value()) {
						log.info("SUCCESSFULLY REGISTRY PUSHED APPLICATION -------------->" + appMaster.getId());
						otherDetailsRepositoryV3.updateIsDDPushFlag(id);
					} else {
						log.info("APPLICATION ID -->" + appMaster.getId() + " --- RE-PUSHED IN REGISTRY ---> "
								+ callSingleEnrollmentRequest.getStatus());
					}
				} else {
					log.info("APPLICATION ID -->" + appMaster.getId() + " --- SINGLE ENROLLMENT RESPONSE NULL ---> ");
				}
			} else {
				log.info("APPLICATION ID -->" + appMaster.getId()
						+ " --- APPLICATION ISACTIVE IS FALSE OR NOT COMPLETED ---> ");
			}
		} catch (Exception e) {
			log.error("Single Enrollment Data Error -->", e);
		}
	}

	/**
	 * first run this method and previous push single Enrollment data status check
	 * if valid or not
	 */
	@Async
	public void rePushUpdateEnrollmentStatusApplication(Long id) {
		Optional<ApplicationMasterV3> findById = applicationMasterRepositoryV3.findById(id);
		if (findById.isPresent()) {
			ApplicationMasterV3 appMaster = findById.get();
			log.info("ENTER IN REGISTRY PUSHED STATUS APPLICATION -------------->" + appMaster.getId());
			if (appMaster.getIsActive() && EnrollStageMaster.COMPLETED.getStageId() == appMaster.getStageId()) {
				try {
					UpdateEnrollResponse updateEnrollResponse = deDupeRegistryUtility.callUpdateEnrollmentStatus(id, appMaster, ApplicationStatus.ENROLL_COMPLETED);
					if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse)) {
						if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus())
								&& updateEnrollResponse.getStatus() == HttpStatus.OK.value()) {
							log.info("SUCCESSFULLY REGISTRY PUSHED STATUS APPLICATION -------------->"
									+ appMaster.getId());
							otherDetailsRepositoryV3.updateIsDDStatusPushFlag(id);
						} else if (updateEnrollResponse.getStatus() == HttpStatus.ACCEPTED.value()
								&& "No matching URN Found in the data".equals(updateEnrollResponse.getMessage())) {
							log.info("APPLICATION ID -->" + appMaster.getId() + " --- RE-PUSHED IN REGISTRY ---> "
									+ updateEnrollResponse.getStatus());
							rePushSingleEnrollmentApplication(id, appMaster);
						} else {
							log.error("NOT STATUS FOUND --------------->STATUS -->" + updateEnrollResponse.getStatus()
									+ "---MSG---" + updateEnrollResponse.getMessage());
						}
					} else {
						log.error("RESPONSE NULL OR EMPTY -------------->" + appMaster.getId());
					}
				} catch (Exception e) {
					log.error("update update enrollment Status Error -->", e);
				}

			}
		}

	}

}
