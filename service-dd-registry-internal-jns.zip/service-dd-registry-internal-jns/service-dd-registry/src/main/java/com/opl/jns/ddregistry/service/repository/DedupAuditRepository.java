package com.opl.jns.ddregistry.service.repository;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.ddregistry.service.domain.*;

public interface DedupAuditRepository extends JpaRepository<DedupApiAudit, Long> {

}
