package com.opl.jns.ddregistry.service.repository;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.ddregistry.service.domain.*;

public interface ApiMasterRepository extends JpaRepository<ApiMaster, Long> {

    ApiMaster findByIdAndIsActiveTrue(Long id);

}
