package com.opl.jns.ddregistry.service.service;

import com.opl.jns.ddregistry.api.model.dedupe.pushDataProxy;
import com.opl.jns.utils.common.CommonResponse;

public interface PushDataService {

	CommonResponse pushData(pushDataProxy request);

}
