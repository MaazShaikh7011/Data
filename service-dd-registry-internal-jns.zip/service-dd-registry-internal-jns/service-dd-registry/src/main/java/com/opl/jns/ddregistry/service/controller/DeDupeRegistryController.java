package com.opl.jns.ddregistry.service.controller;

import com.opl.jns.ddregistry.api.model.claimDedupe.ClaimDedupApiProxy;
import com.opl.jns.ddregistry.api.model.dedupe.*;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimProxy;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimResponse;
import com.opl.jns.ddregistry.api.model.singleEnrollment.*;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusProxy;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusResponse;
import com.opl.jns.ddregistry.api.model.updateEnrollment.*;
import com.opl.jns.ddregistry.service.service.*;
import com.opl.jns.utils.common.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class DeDupeRegistryController {

    private static final String SUCCESS = " Success Data ";

    @Autowired
    DedupService dedupService;

    @PostMapping(value = "/singleEnrollment", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> singleEnrollment(@RequestBody SingleEnrollmentRequest request) {
        try {
            SingleEnrollmentResponse apiResponse = dedupService.singleEnrollment(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<CommonResponse>(new CommonResponse(apiResponse, SUCCESS, HttpStatus.OK.value()), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.info(" error while singleEnrollment service ==> {} ", e);
        }
        return new ResponseEntity<CommonResponse>(new CommonResponse(null, " response is null please try Again. ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/checkDedupe", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> checkDedupe(@RequestBody DedupApiReqProxy request) {
        try {
            DedupApiResProxy apiResponse = dedupService.checkDedupe(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<CommonResponse>(new CommonResponse(apiResponse.getData(), apiResponse.getMessage(), apiResponse.getStatus()), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.info(" error while checkDedupe service ==> {} ", e);
        }
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setData(new ApiData());
        return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
    }

    @PostMapping(value = "/updateEnrollmentStatus", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> updateEnrollmentStatus(@RequestBody UpdateEnrollRequest request) {
        try {

            UpdateEnrollResponse apiResponse = dedupService.updateEnrollmentStatus(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<CommonResponse>(new CommonResponse(apiResponse, apiResponse.getMessage(), apiResponse.getStatus()), HttpStatus.OK);
            } else {
                return new ResponseEntity<CommonResponse>(new CommonResponse(null, " response is null please try Again. ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.info(" error while updateEnrollmentStatus service ==> {} ", e);
        }
        CommonResponse commonResponse = new CommonResponse();
        return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
    }

    @PostMapping(value = "/claimDedupe", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> claimDedupe(@RequestBody ClaimDedupApiProxy request) {
        try {
            ClaimDedupApiResponse apiResponse = dedupService.claimDedupe(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<>(new CommonResponse(apiResponse, SUCCESS, apiResponse.getStatus()), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.info(" error while claimDedupe service ==> {} ", e);
        }
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setData(new ApiData());
        return new ResponseEntity<>(commonResponse, HttpStatus.OK);
    }
    
    @PostMapping(value = "/pushClaim", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> pushClaim(@RequestBody PushClaimProxy request) {
        try {

        	PushClaimResponse apiResponse = dedupService.pushClaim(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<>(new CommonResponse(apiResponse, apiResponse.getMessage(), apiResponse.getStatus()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new CommonResponse(null, " response is null please try Again. ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.info(" error while pushClaim service ==> {} ", e);
        }
        CommonResponse commonResponse = new CommonResponse();
        return new ResponseEntity<>(commonResponse, HttpStatus.OK);
    }
    
    @PostMapping(value = "/updateClaimStatus", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> updateClaimStatus(@RequestBody UpdateClaimStatusProxy request) {
        try {

        	UpdateClaimStatusResponse apiResponse = dedupService.updateClaimStatus(request);
            if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
                return new ResponseEntity<>(new CommonResponse(apiResponse, apiResponse.getMessage(), apiResponse.getStatus()), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new CommonResponse(null, " response is null please try Again. ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.info(" error while updateClaimStatus service ==> {} ", e);
        }
        CommonResponse commonResponse = new CommonResponse();
        return new ResponseEntity<>(commonResponse, HttpStatus.OK);
    }
}
