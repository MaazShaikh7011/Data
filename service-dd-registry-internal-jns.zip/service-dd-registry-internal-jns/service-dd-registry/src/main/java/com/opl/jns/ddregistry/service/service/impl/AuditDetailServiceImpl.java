package com.opl.jns.ddregistry.service.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.jns.ddregistry.service.domain.APILogs;
import com.opl.jns.ddregistry.service.domain.APIStorage;
import com.opl.jns.ddregistry.service.model.PayLoadProxy;
import com.opl.jns.ddregistry.service.repository.ApiAuditRepository;
import com.opl.jns.ddregistry.service.repository.ApiMasterRepository;
import com.opl.jns.ddregistry.service.repository.AuditDetailRepository;
import com.opl.jns.ddregistry.service.repository.PayloadAuditRepository;
import com.opl.jns.ddregistry.service.service.AuditDetailService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;
import com.opl.jns.utils.constant.DBNameConstant;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class AuditDetailServiceImpl implements AuditDetailService {

	@Autowired
	private ApiAuditRepository auditRepo;

	@Autowired
	private AuditDetailRepository auditDetailRepo;

	@Autowired
	private ApiMasterRepository apiRepo;

	@Autowired
	private BucketStorageUtils bucketStorageUtils;

	@Autowired
	private PayloadAuditRepository payloadAuditRepository;

	@Async
	@Override
	public void auditLog(Long applicationId, Long orgId, Long apiId, String request, String response,
			String failureReason, Date createdDate, Integer responseStatus,String referenceId, String accountNo, String cif, String urn, Date modifiedDate) {
		try {
			APILogs audits = new APILogs();
			audits.setCreatedDate(createdDate);
			audits.setApiId(apiId);
			audits.setApplicationId(applicationId);
			audits.setFailureReason(failureReason);
			audits.setIsActive(Boolean.TRUE);
			audits.setOrgId(orgId);
			audits.setModifiedDate(modifiedDate);
			audits.setResponseCode(responseStatus);
			audits.setResponseTime(modifiedDate.getTime() - createdDate.getTime());
			audits.setAccountNumber(accountNo);
			audits.setCif(cif);
			audits.setUrn(urn);
			audits = auditRepo.save(audits);
			updateBucketLogs(audits.getId(), request, response,referenceId);
		} catch (Exception e) {
			log.error("Exception while saving audit logs ----------->", e);
		}
	}

	public String getValue() {
		return System.getenv("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");
	}

	public void updateBucketLogs(Long auditId, String request, String response,String referenceId) {
		APIStorage reqResAudit = new APIStorage();
		reqResAudit.setLogAudit(auditId);
		reqResAudit.setStorageId(referenceId);
		reqResAudit.setSuccess(false);

		PayLoadProxy loadProxy = new PayLoadProxy();
		loadProxy.setRequest(request);
		loadProxy.setResponse(response);
		loadProxy.setReferenceId(referenceId);
		loadProxy.setLogAuditId(auditId);
		String upload = bucketStorageUtils.upload(getValue(), loadProxy, referenceId);
		if (!OPLUtils.isObjectNullOrEmpty(upload)) {
			reqResAudit.setSuccess(true);
		}
		payloadAuditRepository.save(reqResAudit);
	}


	@Override
	public CommonResponse getDDRegistryReqRes(Long auditId) {
		APIStorage findByLogAudit = payloadAuditRepository.findByLogAudit(auditId);
		if (!OPLUtils.isObjectNullOrEmpty(findByLogAudit)) {
			HttpHeaders headers = new HttpHeaders();
//			headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
			headers.set("req_auth", "true");
			headers.add("Accept", "application/json");
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			Map<String, Object> map = new HashMap<>();
			map.put("reqLogAuditId", auditId);
			String url = URLConfig.fetchURL(URLMaster.DD_REGISTRY) + "/opl/bucket/deseriablize/" + findByLogAudit.getStorageId();
			System.err.println(url);
			Map<String, Object> body = new RestTemplate().exchange(url, HttpMethod.GET, entity, Map.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(body)) {
				map.put("plainRequest", !OPLUtils.isObjectNullOrEmpty(body.get("request")) ? body.get("request").toString() : null);
				map.put("plainResponse", !OPLUtils.isObjectNullOrEmpty(body.get("response")) ? body.get("response").toString() : null);
				map.put("referenceId", !OPLUtils.isObjectNullOrEmpty(body.get("referenceId")) ? body.get("referenceId").toString() : null);
			}
			return new CommonResponse(map, "Successfully Get Data", HttpStatus.OK.value());
		}
		return new CommonResponse("Successfully Get Data", HttpStatus.NO_CONTENT.value());
	}

	@Override
	public CommonResponse fetchApiList() {
		try {
			return new CommonResponse("successfully get Data", apiRepo.findAll(), HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting while get fetchApiList", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
}