package com.opl.jns.ddregistry.service.service.impl;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.ddregistry.api.model.claimDedupe.ClaimDedupApiProxy;
import com.opl.jns.ddregistry.api.model.dedupe.ApiData;
import com.opl.jns.ddregistry.api.model.dedupe.ClaimDedupApiResponse;
import com.opl.jns.ddregistry.api.model.dedupe.DedupApiReqProxy;
import com.opl.jns.ddregistry.api.model.dedupe.DedupApiResProxy;
import com.opl.jns.ddregistry.api.model.dedupe.DedupApiResponse;
import com.opl.jns.ddregistry.api.model.dedupe.KycDetails;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimProxy;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimResponse;
import com.opl.jns.ddregistry.api.model.singleEnrollment.SingleEnrollmentRequest;
import com.opl.jns.ddregistry.api.model.singleEnrollment.SingleEnrollmentResponse;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusProxy;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusResponse;
import com.opl.jns.ddregistry.api.model.updateEnrollment.UpdateEnrollRequest;
import com.opl.jns.ddregistry.api.model.updateEnrollment.UpdateEnrollResponse;
import com.opl.jns.ddregistry.api.utils.ApiEnum;
import com.opl.jns.ddregistry.service.domain.ApiMaster;
import com.opl.jns.ddregistry.service.domain.DedupApiAudit;
import com.opl.jns.ddregistry.service.repository.ApiMasterRepository;
import com.opl.jns.ddregistry.service.repository.DedupAuditRepository;
import com.opl.jns.ddregistry.service.service.DedupService;
import com.opl.jns.ddregistry.service.service.HttpUtility;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DedupServiceImpl implements DedupService {

	public static final String CONFIG_NOT_FOUND = "config not found";

	public static final String DD = "DD_";
	public static final Integer UNIQUE_CASE_337 = 337;
	public static final Integer UNIQUE_CASE_338 = 338;
	
	@Autowired
	private HttpUtility httpUtility;

	@Autowired
	private ApiMasterRepository apiMasterRepository;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private DedupAuditRepository dedupAuditRepository;

	public DedupApiResProxy checkDedupe(DedupApiReqProxy dedupeRequest) {
		log.info("ENTER IN CHECKDEDUPE API FOR -----> " + dedupeRequest.getOrgId());
		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.DE_DUP.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new DedupApiResProxy(HttpStatus.BAD_REQUEST.value(), CONFIG_NOT_FOUND);
		}

		DedupApiResProxy dedupApiResProxy = new DedupApiResProxy();
		DedupApiAudit dedupApiAudit = new DedupApiAudit();
		try {
			/* COPY THE REQUEST FOR SAVING*/
			BeanUtils.copyProperties(dedupeRequest,dedupApiAudit);

			/* CALLING API */
			String referenceId = DD + OPLUtils.generateUUID();
			dedupApiAudit.setReferenceId(referenceId);
			DedupApiResponse apiResponse = httpUtility.callServices(req, null, dedupeRequest.getOrgId(), dedupeRequest,referenceId, dedupeRequest.getAccNo(), dedupeRequest.getCif(), dedupeRequest.getUrn(), DedupApiResponse.class);
			if(!OPLUtils.isObjectNullOrEmpty(apiResponse) && !OPLUtils.isObjectNullOrEmpty(apiResponse.getStatus())) {
				/* CHECK STATUS IS NULL OR NOT*/

				dedupApiAudit.setIsDup(apiResponse.getIsDup());
				dedupApiAudit.setMessage(apiResponse.getMessage());
				dedupApiAudit.setMatchesWith(apiResponse.getMatchesWith());

				//			log.info("apiResponse from python : {} ", apiResponse);
				ApiData apiData = new ApiData();
				if (Boolean.TRUE.equals(apiResponse.getIsDup())) {
					log.info("APIRESPONSE.GETISDUP() FROM PYTHON ------> {}", apiResponse.getIsDup());
					if (!OPLUtils.isObjectListNull(apiResponse.getRecords())) {
						Long orgId = (null == apiResponse.getRecords().get(0).getOrgId()) ? dedupeRequest.getOrgId()
								: apiResponse.getRecords().get(0).getOrgId();
						String organizationName = usersClient.getOrganizationName(orgId);
						apiData.setBankName(organizationName);
					}
					apiData.setIsMatched("Y");
					apiData.setMatchesWith(apiResponse.getMatchesWith());
					dedupApiResProxy.setStatus(HttpStatus.OK.value());
				} else if((apiResponse.getStatus() == HttpStatus.MULTI_STATUS.value() || apiResponse.getStatus() == HttpStatus.ALREADY_REPORTED.value())
						&& !apiResponse.getIsDup()) {
					log.info("IS_DE-DUPE is FALSE from the python api for account number - {} and org -{}", dedupeRequest.getAccNo(), dedupeRequest.getOrgId());
					apiData.setIsMatched("N");
					dedupApiResProxy.setStatus(HttpStatus.NO_CONTENT.value());
				}else{
					dedupApiResProxy.setStatus(HttpStatus.BAD_REQUEST.value());
				}
				dedupApiResProxy.setData(apiData);
				dedupApiResProxy.setSuccess(dedupApiResProxy.getStatus() == HttpStatus.OK.value());
				dedupApiResProxy.setMessage(apiResponse.getMessage());

			}else{
				dedupApiAudit.setMessage("de-dupe registry response is null");
				dedupApiResProxy.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				dedupApiResProxy.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}

			log.info(" <--- Exit from checkDedupe ---> ");

		}catch (Exception e){
			dedupApiAudit.setMessage("Exception while calling python API : "+e.getLocalizedMessage());
			log.error("Exception while calling python API for Dedupe : ",e);
		}finally {
			dedupApiAudit.setCreatedDate(new Date());
			dedupAuditRepository.save(dedupApiAudit);
		}
		return dedupApiResProxy;
	}

	public SingleEnrollmentResponse singleEnrollment(SingleEnrollmentRequest singleEnrollmentRequest) {
		log.info(" <--- Enter in singleEnrollment Api ---> ");

		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.SINGLE_ENROLLMENT.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new SingleEnrollmentResponse(HttpStatus.BAD_REQUEST.value(), CONFIG_NOT_FOUND);
		}

		/* CALLING API */
		String referenceId = DD + OPLUtils.generateUUID();
		KycDetails kycDetails = singleEnrollmentRequest.getKycDetails();
		if(kycDetails != null && OPLUtils.isObjectNullOrEmpty(kycDetails.getKycIdValue2())) {
			kycDetails.setKycId2(null);
		}
		SingleEnrollmentResponse apiResponse = httpUtility.callServices(req, singleEnrollmentRequest.getApplicationId(),
				singleEnrollmentRequest.getOrgId(), singleEnrollmentRequest,referenceId, singleEnrollmentRequest.getCustomerDetails().getAccountNumber(), singleEnrollmentRequest.getCustomerDetails().getCif(), singleEnrollmentRequest.getUrn(), SingleEnrollmentResponse.class);
		if (OPLUtils.isObjectNullOrEmpty(apiResponse)) {
			log.info("Response is not success for SingleEnrollment from python api for applicationId [{}] ",
					singleEnrollmentRequest.getApplicationId());
		}

		log.info(" <--- Exit from singleEnrollment  ---> ");
		return apiResponse;
	}

	public UpdateEnrollResponse updateEnrollmentStatus(UpdateEnrollRequest updateEnrollRequest) {
		log.info(" <--- Enter in updateEnrollmentStatus ---> ");

		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.UPDATE_ENROLLMENT_STATUS.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new UpdateEnrollResponse(CONFIG_NOT_FOUND, HttpStatus.BAD_REQUEST.value());
		}

		/* CALLING API */
		String referenceId = DD + OPLUtils.generateUUID();
		UpdateEnrollResponse updateEnrollResponse = httpUtility.callServices(req,
				updateEnrollRequest.getApplicationId(), updateEnrollRequest.getOrgId(), updateEnrollRequest,referenceId,
				null, null, updateEnrollRequest.getUrn(), UpdateEnrollResponse.class);
		if (OPLUtils.isObjectNullOrEmpty(updateEnrollResponse)) {
			log.info("Response is not success for SingleEnrollment from python api for applicationId [{}] ",
					updateEnrollRequest.getApplicationId());
		}

		log.info(" <--- Exit from updateEnrollmentStatus  ---> ");
		return updateEnrollResponse;
	}
	
	
	public ClaimDedupApiResponse claimDedupe(ClaimDedupApiProxy claimDedupeRequest) {
		log.info("ENTER IN CLAIMDEDUPE API FOR -----> " + claimDedupeRequest.getOrgId());
		ClaimDedupApiResponse apiResponse = null;
		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.CLAIM_DE_DUPE.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new ClaimDedupApiResponse(HttpStatus.BAD_REQUEST.value(), CONFIG_NOT_FOUND);
		}

		DedupApiAudit dedupApiAudit = new DedupApiAudit();
		try {
			/* COPY THE REQUEST FOR SAVING*/
			BeanUtils.copyProperties(claimDedupeRequest,dedupApiAudit);

			/* CALLING API */
			String referenceId = DD + OPLUtils.generateUUID();
			dedupApiAudit.setReferenceId(referenceId);
			apiResponse = httpUtility.callServices(req, null, claimDedupeRequest.getOrgId(), claimDedupeRequest,referenceId, claimDedupeRequest.getAccNo(), claimDedupeRequest.getCif(), claimDedupeRequest.getUrn(), ClaimDedupApiResponse.class);
			if(!OPLUtils.isObjectNullOrEmpty(apiResponse) && !OPLUtils.isObjectNullOrEmpty(apiResponse.getStatus())) {
				dedupApiAudit.setIsDup(apiResponse.getIsDup());
				dedupApiAudit.setMessage(apiResponse.getMessage());
				dedupApiAudit.setMatchesWith(apiResponse.getMatchesWith());
			}else{
				dedupApiAudit.setMessage("claimDedupe registry response is null");
			}

			log.info(" <--- Exit from claimDedupe ---> ");

		}catch (Exception e){
			dedupApiAudit.setMessage("Exception while calling python API : "+e.getLocalizedMessage());
			log.error("Exception while calling python API for claimDedupe : ",e);
		}finally {
			dedupApiAudit.setCreatedDate(new Date());
			dedupAuditRepository.save(dedupApiAudit);
		}
		return apiResponse;
	}

	@Override
	public PushClaimResponse pushClaim(PushClaimProxy pushClaimProxy) {
		log.info(" <--- Enter in pushClaim Api ---> ");

		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.PUSH_CLAIM.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new PushClaimResponse(HttpStatus.BAD_REQUEST.value(), CONFIG_NOT_FOUND);
		}
		/* CALLING API */
		String referenceId = DD + OPLUtils.generateUUID();
		PushClaimResponse apiResponse = httpUtility.callServices(req, null,
				pushClaimProxy.getOrgId().longValue(), pushClaimProxy,referenceId, pushClaimProxy.getApplicantAccNo(), null, pushClaimProxy.getUrn(), PushClaimResponse.class);
		if (OPLUtils.isObjectNullOrEmpty(apiResponse)) {
			log.info("Response is not success for pushClaim from python api for accountNo [{}] ",
					pushClaimProxy.getApplicantAccNo());
		}

		log.info(" <--- Exit from pushClaim  ---> ");
		return apiResponse;
	}

	@Override
	public UpdateClaimStatusResponse updateClaimStatus(UpdateClaimStatusProxy request) {
		log.info(" <--- Enter in updateClaimStatus Api ---> ");

		/* GETTING API CONFIGURATION */
		ApiMaster req = apiMasterRepository.findByIdAndIsActiveTrue(ApiEnum.UPDATE_CLAIM_STATUS.getApiId());
		if (OPLUtils.isObjectNullOrEmpty(req)) {
			return new UpdateClaimStatusResponse(HttpStatus.BAD_REQUEST.value(), CONFIG_NOT_FOUND);
		}
		/* CALLING API */
		String referenceId = DD + OPLUtils.generateUUID();
		UpdateClaimStatusResponse apiResponse = httpUtility.callServices(req, null,
				null, request,referenceId, null, null, request.getUrn(), UpdateClaimStatusResponse.class);
		if (OPLUtils.isObjectNullOrEmpty(apiResponse)) {
			log.info("Response is not success for updateClaimStatus from python api for urn [{}] ",
					request.getUrn());
		}

		log.info(" <--- Exit from updateClaimStatus  ---> ");
		return apiResponse;
	}
	
	
}
