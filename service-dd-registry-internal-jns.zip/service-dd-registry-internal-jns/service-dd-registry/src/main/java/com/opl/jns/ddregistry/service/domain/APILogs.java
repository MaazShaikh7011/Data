package com.opl.jns.ddregistry.service.domain;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.*;
import lombok.*;

import javax.persistence.*;
import java.util.*;

/**
 * @author - Maaz Shaikh
 * @Date - 18/06/2023
 */
@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "api_logs_dec")
@NoArgsConstructor
public class APILogs {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_logs_dec_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_DD_REGISTRY, name = "api_logs_dec_seq_gen", sequenceName = "api_logs_dec_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "user_id", nullable = true)
	private String userId;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "failure_reason", length = 2000, nullable = true)
	private String failureReason;

	@Column(name = "api_id", nullable = false)
	private Long apiId;

	@Column(name = "response_code", nullable = true)
	private Integer responseCode;

	@Column(name = "response_time", nullable = true)
	private Long responseTime;

	@Column(name = "created_date", nullable = false)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Convert(converter = AESOracle.class)
	@Column(name = "account_number", nullable = true)
	private String accountNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "cif", nullable = true)
	private String cif;

	@Column(name = "urn", nullable = true)
	private String urn;

}
