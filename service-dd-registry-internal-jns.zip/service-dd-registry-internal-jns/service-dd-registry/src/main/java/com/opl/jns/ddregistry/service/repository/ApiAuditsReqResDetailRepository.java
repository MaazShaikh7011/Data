package com.opl.jns.ddregistry.service.repository;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.ddregistry.service.domain.*;

public interface ApiAuditsReqResDetailRepository extends JpaRepository<ApiAuditsReqResDetail, Long> {


}
