package com.opl.jns.ddregistry.service.service;

import com.opl.jns.ddregistry.service.domain.*;


public interface HttpUtility {
    <T> T callServices(ApiMaster req, Long applicationId, Long orgId, Object commonRequest,String referenceId, String accountNo, String cif, String urn, Class<T> respClass);
}
