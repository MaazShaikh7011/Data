package com.opl.jns.ddregistry.service.domain;

import com.opl.jns.utils.common.*;
import com.opl.jns.utils.constant.*;
import lombok.*;

import javax.persistence.*;
import java.util.*;

/**
 * @author - Maaz Shaikh
 * @Date - 18/06/2023
 */
@Entity
@Table(name = "dedupe_audit_log")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class DedupApiAudit {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dedupe_audit_log_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_DD_REGISTRY, name = "dedupe_audit_log_seq_gen", sequenceName = "dedupe_audit_log_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "reference_id")
    private String referenceId;
    @Column(name = "type")
    private String type;
    @Column(name = "cif")
    @Convert(converter = AESOracle.class)
    private String cif;
    @Column(name = "urn")
    private String urn;
    @Column(name = "bank_code")
    private String bankCode;
    @Column(name = "scheme")
    private String scheme;
    @Column(name = "kyc_id1")
    private String kycId1;
    @Column(name = "kyc_id_value1")
    @Convert(converter = AESOracle.class)
    private String kycIdValue1;
    @Column(name = "kyc_id2")
    private String kycId2;
    @Column(name = "kyc_id_value2")
    @Convert(converter = AESOracle.class)
    private String kycIdValue2;
    @Column(name = "ckyc_number")
    @Convert(converter = AESOracle.class)
    private String ckycNumber;
    @Column(name = "gender")
    @Convert(converter = AESOracle.class)
    private String gender;
    @Column(name = "first_name")
    @Convert(converter = AESOracle.class)
    private String firstName;
    @Column(name = "middle_name")
    @Convert(converter = AESOracle.class)
    private String middleName;
    @Column(name = "last_name")
    @Convert(converter = AESOracle.class)
    private String lastName;
    @Column(name = "father_husband_name")
    @Convert(converter = AESOracle.class)
    private String fatherHusbandName;
    @Column(name = "mob")
    @Convert(converter = AESOracle.class)
    private String mob;
    @Column(name = "pincode")
    private Integer pincode;
    @Column(name = "org_id")
    private Long orgId;
    @Column(name = "insurer_org_id")
    private Long insurerOrgId;
    @Column(name = "dob")
    @Convert(converter = AESOracle.class)
    private String dob;
    @Column(name = "acc_no")
    @Convert(converter = AESOracle.class)
    private String accNo;
    @Column(name = "account_status")
    private String accountStatus;
    @Column(name = "is_dup")
    private Boolean isDup;
    @Column(name = "message")
    private String message;
    @Column(name = "matches_with")
    private String matchesWith;
    @Column(name = "created_date")
    private Date createdDate;


}
