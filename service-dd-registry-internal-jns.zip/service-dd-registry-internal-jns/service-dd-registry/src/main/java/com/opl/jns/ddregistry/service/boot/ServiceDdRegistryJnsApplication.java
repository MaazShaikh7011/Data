package com.opl.jns.ddregistry.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;


@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableAsync
public class ServiceDdRegistryJnsApplication {
    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) {
        SpringApplication.run(ServiceDdRegistryJnsApplication.class, args);
    }


    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

    @Bean
    public UsersClient userClient() {
        UsersClient userClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(userClient);
        return userClient;
    }

}
