package com.opl.jns.ddregistry.service.service.impl;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;

import javax.net.ssl.SSLException;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.ddregistry.api.model.DdResponse;
import com.opl.jns.ddregistry.api.model.TimeOutConfig;
import com.opl.jns.ddregistry.service.domain.ApiMaster;
import com.opl.jns.ddregistry.service.service.AuditDetailService;
import com.opl.jns.ddregistry.service.service.HttpUtility;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HttpUtilityImpl implements HttpUtility {

	@Autowired
	private AuditDetailService auditDetailService;

	private static void setTimeout(ApiMaster req, RestTemplate restTemplate) {
		if (!OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig())) {
			try {
				TimeOutConfig timeOutConfig = MultipleJSONObjectHelper.getObjectFromString(req.getTimeOutConfig(),
						TimeOutConfig.class);
				((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
						.setReadTimeout(timeOutConfig.getReadTimeOut() * 1000);
				((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory())
						.setConnectTimeout(timeOutConfig.getConTimeOut() * 1000);
			} catch (IOException e) {
				log.error(" Error  while fetching readtimeout for req ==>{} and error is ", req, e);
			}
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public <T> T callServices(ApiMaster req, Long applicationId, Long orgId, Object commonRequest,String referenceId, String accountNo, String cif, String urn, Class<T> respClass) {
		Date curruntDate = new Date();
		DdResponse apiData = new DdResponse();
		try {
			/* SET ALL HEADERS */
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			Map<String, Object> headersMap = MultipleJSONObjectHelper.getMapFromString(req.getHeaderConfig());
			headers.setAll(headersMap.entrySet().stream()
					.collect(Collectors.toMap(Map.Entry::getKey, e -> String.valueOf(e.getValue()))));
			HttpEntity<Object> entity = new HttpEntity<>(commonRequest, headers);

			apiData.setRequest(MultipleJSONObjectHelper.getStringfromObject(entity));
//			log.info("URL is :[{}]", req.getUrl());
//			log.info("Encrypted Request is :{}", apiData.getRequest());

			RestTemplate restTemplate = new RestTemplate();

			/* SET TIMEOUT CONFIG */
			setTimeout(req, restTemplate);

			/* API CALL */
			ResponseEntity<String> exchange = restTemplate.exchange(req.getUrl(), HttpMethod.POST, entity,
					String.class);
			apiData.setStatus(exchange.getStatusCodeValue());
			apiData.setResponse(exchange.getBody());
//			log.info("Response from python : {}", apiData.getResponse());
			log.info(
					"RESPONSE STATUS ----------- [{}] ---------- FOR API ------- [{}] RECEIVED FROM URL ---------- [{}] ",
					apiData.getStatus(), req.getName(), req.getUrl());
			return MultipleJSONObjectHelper.getObjectFromString(exchange.getBody(), respClass);
		} catch (HttpStatusCodeException e) {
			log.error("STATUS CODE RECEIVED IN EXCEPTION [{}] ===> ", e.getStatusCode().value());
			log.error("HTTP STATUS CODE EXCEPTION --->  ", e);
			ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders())
					.body(e.getResponseBodyAsString());
			apiData.setStatus(resp.getStatusCodeValue());
			apiData.setResponse(resp.getBody());
		} catch (ResourceAccessException http) {
			log.error("HTTP RESOURCE ACCESS EXCEPTION --->  ", http);
			if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
				apiData.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
				apiData.setResponse(http.getCause().getLocalizedMessage());
			}
		} catch (IOException e) {
			log.error("EXCEPTION IN CONVERT STRING OBJECT --> ", e);
			apiData.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			apiData.setFailureReason("Exception in converting the request :" + e.getLocalizedMessage());
		} catch (Exception e) {
			log.error("Exception while calling de-dupe registry API : ", e);
			apiData.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			apiData.setFailureReason(e.getMessage());
		} finally {
			/* AUDITING */
			auditDetailService.auditLog(applicationId, orgId, req.getId(), apiData.getRequest(), apiData.getResponse(),
					apiData.getFailureReason(), curruntDate, apiData.getStatus(),referenceId, accountNo, cif, urn, new Date());
		}
		log.info("RESPONSE STATUS ----------- [{}] ---------- FOR API ------- [{}] RECEIVED FROM URL ---------- [{}] ",
				apiData.getStatus(), req.getName(), req.getUrl());
		return null;
	}
}
