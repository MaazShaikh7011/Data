package com.opl.jns.ddregistry.service.service;

import com.opl.jns.ddregistry.api.model.claimDedupe.ClaimDedupApiProxy;
import com.opl.jns.ddregistry.api.model.dedupe.*;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimProxy;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimResponse;
import com.opl.jns.ddregistry.api.model.singleEnrollment.*;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusProxy;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusResponse;
import com.opl.jns.ddregistry.api.model.updateEnrollment.*;

public interface DedupService {

    DedupApiResProxy checkDedupe(DedupApiReqProxy dedupeRequest);

    SingleEnrollmentResponse singleEnrollment(SingleEnrollmentRequest singleEnrollmentRequest);

    UpdateEnrollResponse updateEnrollmentStatus(UpdateEnrollRequest updateEnrollRequest);
    
    ClaimDedupApiResponse claimDedupe(ClaimDedupApiProxy claimDedupeRequest);
    
    PushClaimResponse pushClaim(PushClaimProxy pushClaimProxy);

	UpdateClaimStatusResponse updateClaimStatus(UpdateClaimStatusProxy request);
}
