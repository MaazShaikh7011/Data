package com.opl.jns.ddregistry.service.repository;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.ddregistry.service.domain.*;

public interface ApiAuditRepository extends JpaRepository<APILogs, Long> {
    APILogs findFirstByIdOrderByIdDesc(Long id);
}
