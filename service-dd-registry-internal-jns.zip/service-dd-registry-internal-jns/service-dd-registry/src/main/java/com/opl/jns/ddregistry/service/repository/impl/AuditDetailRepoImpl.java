package com.opl.jns.ddregistry.service.repository.impl;

import com.opl.jns.ddregistry.service.repository.*;
import com.opl.jns.utils.common.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import javax.persistence.*;
import java.sql.*;

@Repository
@Slf4j
public class AuditDetailRepoImpl implements AuditDetailRepository {

    @Qualifier("emFR")
    @Autowired
    EntityManager entityManager;


    @Override
    public String fetchTotalCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }

    @Override
    public String fetchList(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }


}

