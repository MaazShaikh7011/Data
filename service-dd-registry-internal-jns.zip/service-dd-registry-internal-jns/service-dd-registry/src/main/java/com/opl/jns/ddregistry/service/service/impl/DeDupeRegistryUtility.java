package com.opl.jns.ddregistry.service.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ddregistry.api.model.dedupe.CustomerDetails;
import com.opl.jns.ddregistry.api.model.dedupe.KycDetails;
import com.opl.jns.ddregistry.api.model.dedupe.PolicyDetails;
import com.opl.jns.ddregistry.api.model.singleEnrollment.SingleEnrollmentRequest;
import com.opl.jns.ddregistry.api.model.singleEnrollment.SingleEnrollmentResponse;
import com.opl.jns.ddregistry.api.model.updateEnrollment.UpdateEnrollRequest;
import com.opl.jns.ddregistry.api.model.updateEnrollment.UpdateEnrollResponse;
import com.opl.jns.ddregistry.service.service.DedupService;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TransactionType;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author sandip.bhetariya
 *
 */
@Slf4j
@Service
public class DeDupeRegistryUtility {

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private DedupService dedupService;

	public UpdateEnrollResponse callUpdateEnrollmentStatus(Long applicationId,ApplicationMasterV3 applicationMaster, ApplicationStatus applicationStatus) throws Exception {
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster))
				applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
			
			UpdateEnrollRequest enrollRequest = new UpdateEnrollRequest();
			enrollRequest.setApplicationId(applicationMaster.getId());
			enrollRequest.setUrn(applicationMaster.getUrn());
			enrollRequest.setStatus(applicationStatus.getId());
			enrollRequest.setReason(applicationStatus.getValue());
			enrollRequest.setDateOfEnrollment(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getEnrollmentDate())
					? com.opl.jns.ere.utils.CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss
							.format(applicationMaster.getEnrollmentDate())
					: null);

			UpdateEnrollResponse updateEnrollmentStatus = dedupService.updateEnrollmentStatus(enrollRequest);
			if (!OPLUtils.isObjectNullOrEmpty(updateEnrollmentStatus)
					&& !OPLUtils.isObjectNullOrEmpty(updateEnrollmentStatus.getStatus())
					&& (updateEnrollmentStatus.getStatus() == HttpStatus.OK.value()
							|| updateEnrollmentStatus.getStatus() == HttpStatus.ACCEPTED.value())) {
				return updateEnrollmentStatus;
			}
		return null;
	}

	public SingleEnrollmentResponse callSingleEnrollmentRequest(Long applicationId,
			ApplicationMasterV3 applicationMaster) throws Exception {
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster))
				applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);

			SingleEnrollmentRequest enrollmentRequest = getSingleEnrollmentReq(applicationMaster);
			SingleEnrollmentResponse singleEnrollment = dedupService.singleEnrollment(enrollmentRequest);
			if (!OPLUtils.isObjectNullOrEmpty(singleEnrollment)
					&& !OPLUtils.isObjectNullOrEmpty(singleEnrollment.getStatus())
					&& (singleEnrollment.getStatus() == HttpStatus.OK.value()
							|| singleEnrollment.getStatus() == HttpStatus.ACCEPTED.value())) {
				return singleEnrollment;
			}
		return null;
	}

	public static SingleEnrollmentRequest getSingleEnrollmentReq(ApplicationMasterV3 masterV3) {
		SingleEnrollmentRequest enrollmentRequest = new SingleEnrollmentRequest();
		enrollmentRequest.setApplicationId(masterV3.getId());
		enrollmentRequest.setUrn(masterV3.getUrn());
		enrollmentRequest
				.setSource(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicationMasterOtherDetails().getSource())
						? Source.fromId(masterV3.getApplicationMasterOtherDetails().getSource()).getValue()
						: null);
		enrollmentRequest.setScheme(SchemeMaster.getById(masterV3.getSchemeId().longValue()).getShortName());
		enrollmentRequest.setOrgId(masterV3.getOrgId());
		enrollmentRequest.setEnrollStatus(ApplicationStatus.ENROLL_COMPLETED.getId());

		CustomerDetails customerDetails = new CustomerDetails();
		customerDetails.setDob(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getDob())
				? com.opl.jns.ere.utils.CommonUtils.sdf_dd_MM_yyyy.format(masterV3.getApplicantInfo().getDob())
				: null);
		customerDetails.setGender(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getGenderId())
				? Gender.fromId(masterV3.getApplicantInfo().getGenderId()).getBankValue()
				: null);
		customerDetails.setAccountHolderName(masterV3.getApplicantInfo().getName());
		customerDetails.setFirstName(masterV3.getApplicantInfo().getFirstName());
		customerDetails.setMiddleName(masterV3.getApplicantInfo().getMiddleName());
		customerDetails.setLastName(masterV3.getApplicantInfo().getLastName());
		customerDetails.setFatherHusbandName(masterV3.getApplicantInfo().getFatherHusbandName());
		customerDetails.setOrgId(masterV3.getOrgId());
		customerDetails.setCustIfsc(masterV3.getApplicantInfo().getIfsc());
		customerDetails.setAccountNumber(masterV3.getAccountNumber());
		customerDetails.setCif(masterV3.getCif());
		enrollmentRequest.setCustomerDetails(customerDetails);

		KycDetails kycDetails = new KycDetails();
		kycDetails.setKycId1(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getKycId1())
				? masterV3.getApplicantInfo().getKycId1().toUpperCase()
				: null);
		kycDetails.setKycIdValue1(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getKycIdNumber1())
				? masterV3.getApplicantInfo().getKycIdNumber1().toUpperCase()
				: null);
		if (!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getKycId2())
				&& !OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getKycIdNumber2())) {
			kycDetails.setKycId2(masterV3.getApplicantInfo().getKycId2().toUpperCase());
			kycDetails.setKycIdValue2(masterV3.getApplicantInfo().getKycIdNumber2().toUpperCase());
		}
		kycDetails.setPanNumber(!OPLUtils.isObjectNullOrEmpty(masterV3.getApplicantInfo().getPan())
				? masterV3.getApplicantInfo().getPan().toUpperCase()
				: null);
		kycDetails.setAadhaarNumber(masterV3.getApplicantInfo().getAadhaar());
		kycDetails.setCkyc(masterV3.getApplicantInfo().getCkyc());
		kycDetails.setCkycNumber(masterV3.getApplicantInfo().getCkycNumber());
		enrollmentRequest.setKycDetails(kycDetails);

		PolicyDetails policyDetails = new PolicyDetails();
		policyDetails
				.setPolicyPeriod(!OPLUtils.isObjectNullOrEmpty(masterV3.getLastTransactionDetails().getInsurerMaster())
						? masterV3.getLastTransactionDetails().getInsurerMaster().getYear()
						: null);
		policyDetails.setInsurerOrgId(masterV3.getInsurerOrgId());
		policyDetails.setMasterPolicyNumber(masterV3.getLastTransactionDetails().getMasterPolicyNo());
		policyDetails.setDateOfEnrollment(!OPLUtils.isObjectNullOrEmpty(masterV3.getEnrollmentDate())
				? com.opl.jns.ere.utils.CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(masterV3.getEnrollmentDate())
				: null);
		policyDetails.setTransactionType(!OPLUtils.isObjectNullOrEmpty(masterV3.getLastTransactionDetails().getType())
				? TransactionType.fromId(masterV3.getLastTransactionDetails().getType()).getValue()
				: null);
		enrollmentRequest.setPolicyDetails(policyDetails);
		return enrollmentRequest;
	}

}
