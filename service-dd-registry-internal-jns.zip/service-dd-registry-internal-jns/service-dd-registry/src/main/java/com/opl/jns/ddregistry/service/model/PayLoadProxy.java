package com.opl.jns.ddregistry.service.model;

import java.io.*;

public class PayLoadProxy implements Serializable {

	private static final long serialVersionUID = -231629146676600555L;
	private String request;
	private String response;

	private Long logAuditId;

	private String referenceId;

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Long getLogAuditId() {
		return logAuditId;
	}

	public void setLogAuditId(Long logAuditId) {
		this.logAuditId = logAuditId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

}
