package com.opl.jns.ddregistry.service.repository;

public interface AuditDetailRepository {

    String fetchTotalCount(String query);

    String fetchList(String query);

}
