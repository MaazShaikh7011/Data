package com.opl.jns.ddregistry.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.ddregistry.api.model.claimDedupe.ClaimDedupApiProxy;
import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimProxy;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusProxy;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DedupeRegistryClient {
    
    private String baseUrlStr;
	private RestTemplate restTemplate;

	private static final String CLAIM_DE_DUPE = "/claimDedupe";
    private static final String PUSH_CLAIM = "/pushClaim";
    private static final String UPDATE_CLAIM_STATUS = "/updateClaimStatus";
    
    //private static final String SINGLE_ENROLLMENT = "/singleEnrollment";
    //private static final String CHECK_DE_DUPE = "/checkDedupe";
    //private static final String UPDATE_ENROLLMENT_STATUS = "/updateEnrollmentStatus";
    

    public DedupeRegistryClient() {
    }

    public DedupeRegistryClient(String baseUrlStr) {
        super();
        this.baseUrlStr = baseUrlStr;
        this.restTemplate = new RestTemplate();
    }

	public CommonResponse callClaimDedupeRequest(ClaimDedupApiProxy dedupRequest) {
		String url = baseUrlStr.concat(CLAIM_DE_DUPE);
//		String url = "http://localhost:8070/dd/registry/jns/claimDedupe";
      log.info("Enter in calling  callClaimDedupeRequest Api -------------------->{}", url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			headers.setContentType(MediaType.APPLICATION_JSON);
			log.info("callClaimDedupeRequest Data For -->" + url);
			HttpEntity<ClaimDedupApiProxy> entity = new HttpEntity<>(dedupRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class) .getBody();
		} catch (Exception e) {
			log.error("Exception While calling api :: ", e);
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
	
	public CommonResponse callPushClaimRequest(PushClaimProxy pushClaimProxy) {
		String url = baseUrlStr.concat(PUSH_CLAIM);
//		String url = "http://localhost:8070/dd/registry/jns/pushClaim";
      log.info("Enter in calling  callPushClaimRequest Api -------------------->{}", url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			headers.setContentType(MediaType.APPLICATION_JSON);
			log.info("callPushClaimRequest Data For -->" + url);
			HttpEntity<PushClaimProxy> entity = new HttpEntity<>(pushClaimProxy, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class) .getBody();
		} catch (Exception e) {
			log.error("Exception While calling api :: ", e);
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
	
	public CommonResponse callUpdateClaimStatusRequest(UpdateClaimStatusProxy claimStatusProxy) {
		String url = baseUrlStr.concat(UPDATE_CLAIM_STATUS);
//		String url = "http://localhost:8070/dd/registry/jns/updateClaimStatus";
      log.info("Enter in calling  callUpdateClaimStatusRequest Api -------------------->{}", url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			headers.setContentType(MediaType.APPLICATION_JSON);
			log.info("callUpdateClaimStatusRequest Data For -->" + url);
			HttpEntity<UpdateClaimStatusProxy> entity = new HttpEntity<>(claimStatusProxy, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class) .getBody();
		} catch (Exception e) {
			log.error("Exception While calling api :: ", e);
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
//    public CommonResponse singleEnrollment(SingleEnrollmentRequest enrollmentRequest) {
//        String url = baseUrlStr.concat(SINGLE_ENROLLMENT);
//        log.info("Enter in calling  singleEnrollment Api -------------------->{}", url);
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.set("req_auth", "true");
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<SingleEnrollmentRequest> entity = new HttpEntity<>(enrollmentRequest, headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
//        } catch (Exception e) {
//            log.error("Exception While calling  singleEnrollment Api :: ", e);
//            return null;
//        }
//    }
//
//    public CommonResponse checkDedupe(DedupApiReqProxy dedupRequest) {
//        String url = baseUrlStr.concat(CHECK_DE_DUPE);
//        log.info("Enter in calling  checkDedupe Api -------------------->{}", url);
//        try {
//
//            HttpHeaders headers = new HttpHeaders();
//            headers.set("req_auth", "true");
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<DedupApiReqProxy> entity = new HttpEntity<>(dedupRequest, headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
//        } catch (Exception e) {
//            log.error("Exception While calling  checkDedupe Api :: ", e);
//            return null;
//        }
//    }

//    public CommonResponse updateEnrollmentStatus(UpdateEnrollRequest updateEnrollRequest) {
//        String url = baseUrlStr.concat(UPDATE_ENROLLMENT_STATUS);
//        log.info("Enter in calling  updateEnrollmentStatus Api -------------------->{}", url);
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.set("req_auth", "true");
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<UpdateEnrollRequest> entity = new HttpEntity<>(updateEnrollRequest, headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
//        } catch (Exception e) {
//            log.error("Exception While calling  updateEnrollmentStatus Api :: ", e);
//            return null;
//        }
//    }
    
/*public CommonResponse callUpdateEnrollmentStatus(UpdateEnrollRequest enrollRequest) {
	String url = baseUrlStr.concat(UPDATE_ENROLLMENT_STATUS);
	log.info("Enter in calling  callUpdateEnrollmentStatus Api -------------------->{}", url);
	try {
		HttpHeaders headers = new HttpHeaders();
		headers.set("req_auth", "true");
		headers.setContentType(MediaType.APPLICATION_JSON);
		log.info("callUpdateEnrollmentStatus Data For -->" + url);
		HttpEntity<UpdateEnrollRequest> entity = new HttpEntity<>(enrollRequest, headers);
		return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		
	} catch (Exception e) {
		log.error("Exception While calling api :: ", e);
	}
	return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
}
    
	public CommonResponse callCheckDedupeRequest(DedupApiReqProxy dedupRequest) {
		String url = baseUrlStr.concat(CHECK_DE_DUPE);
      log.info("Enter in calling  callCheckDedupeRequest Api -------------------->{}", url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			headers.setContentType(MediaType.APPLICATION_JSON);
			log.info("callCheckDedupeRequest Data For -->" + url);
			HttpEntity<DedupApiReqProxy> entity = new HttpEntity<>(dedupRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class) .getBody();
		} catch (Exception e) {
			log.error("Exception While calling api :: ", e);
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
	
	
	public CommonResponse callSingleEnrollmentRequest(SingleEnrollmentRequest singleEnrollmentRequest) {
		String url = baseUrlStr.concat(SINGLE_ENROLLMENT);
	    log.info("Enter in calling  callSingleEnrollmentRequest Api -------------------->{}", url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			headers.setContentType(MediaType.APPLICATION_JSON);
			log.info("callSingleEnrollmentRequest Data For -->" + url);
			HttpEntity<SingleEnrollmentRequest> entity = new HttpEntity<>(singleEnrollmentRequest, headers);
			CommonResponse response = restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class)
					.getBody();
			if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
					&& response.getStatus() == 200) {
				return response;
			}
		} catch (Exception e) {
			log.error("Exception While calling api :: ", e);
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}*/
	
}
