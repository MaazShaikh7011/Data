package com.opl.jns.notification.service.service;

import com.opl.jns.notification.api.model.systemNotification.*;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface SystemNotifyService {

    /**
     * SEND SYSTEM NOTIFICATION
     * */
    public SystemNotifyResponse sendSystemNotification(SystemNotifyRequest request);

    /**
     * FETCH ALL READ AND UN READ SYSTEM NOTIFICATION
     * */
    public SystemNotifyResponse fetchAllSystemNotification(Long toId);

    /**
     * READ SYSTEM NOTIFICATION
     * */
    public void readSystemNotification(Long notificationId);

}
