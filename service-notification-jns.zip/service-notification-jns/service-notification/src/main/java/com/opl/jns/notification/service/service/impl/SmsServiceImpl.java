package com.opl.jns.notification.service.service.impl;

import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.notification.service.domain.LoanType;
import com.opl.jns.notification.service.domain.NotificationMaster;
import com.opl.jns.notification.service.domain.NotificationTemplate;
import com.opl.jns.notification.service.repository.NotificationMasterRepository;
import com.opl.jns.notification.service.service.SmsService;
import com.opl.jns.notification.service.utils.Utils;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.notification.provider.enums.ContentType;
import com.opl.notification.provider.model.NotificationMasterRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
import com.opl.notification.provider.service.NotificationService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Map.Entry;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Service
@Transactional
@Slf4j
public class SmsServiceImpl implements SmsService {
    @Autowired
    private Configuration fmConfiguration;

    @Autowired
    private NotificationService notificationProviderService;

    @Autowired
    private NotificationMasterRepository notiMasterRepo;

    @Override
    public SMSResponse sendSMS(SMSRequest smsRequest) {
        SMSResponse response = new SMSResponse();
        String message = null;
        smsRequest.setPhoneNumberStr(StringUtils.arrayToDelimitedString(smsRequest.getPhoneNumber(),","));

        /* CONVERT EMAIL INTO XXX FORMAT */
        for (Entry<String, Object> map : smsRequest.getParameters().entrySet()) {
            if (map.getValue() != null) {
                map.setValue(convertEmailToXxx(map.getValue().toString()));
            }
        }

        /* GETTING TEMPLATE ORG AND LOAN TYPE WISE */
        NotificationTemplateRequest templateReq = getNotificationTemplateForSmsAndSystemNotification(smsRequest.getMasterId(),smsRequest.getUserOrgId(), smsRequest.getLoanTypeId());

        /* MAPPED THE VALUES OF KEYS IN TEMPLATE  */
        if (!OPLUtils.isObjectNullOrEmpty(templateReq) && !OPLUtils.isObjectNullOrEmpty(templateReq.getIsWorking()) && Boolean.TRUE.equals(templateReq.getIsWorking())) {
            smsRequest.setSmsTemplateInString(templateReq.getNotificationTemplate());
            smsRequest.setTemplateId(templateReq.getId());
            smsRequest.setDltId(templateReq.getDltId());
            smsRequest.setDefaultConfigKey(templateReq.getMasterReq().getDefaultConfigKey());
            message = mapKeysToTemplate(smsRequest);
            if (!OPLUtils.isObjectNullOrEmpty(message)) {
                smsRequest.setMappedMessage(message);
            }else{
                response.setMessage("Exception while mapping the values in templates");
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return response;
            }
        } else {
            log.error("SMS Master or Template  is not active for Master ID [{}] While sending SMS to [{}]", smsRequest.getMasterId(), smsRequest.getPhoneNumberStr());
            response.setMessage("SMS template not found or template is not active");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* SEND SMS */
        notificationProviderService.processSms(smsRequest);
        response.setMessage("SMS submitted");
        response.setStatus(HttpStatus.OK.value());
        return response;
    }

    /**
     * Map parameter to template using ftl
     * */
    private String mapKeysToTemplate(SMSRequest smsRequest) {
        try {
            if (com.opl.notification.provider.enums.ContentType.TEMPLATE.equals(smsRequest.getTemplate())) {
                if (!OPLUtils.isObjectNullOrEmpty(smsRequest.getTemplateName())) {
                    smsRequest.setTemplateName(smsRequest.getMasterId() + " MasterId_SMS_TEMPLATE");
                }
                return FreeMarkerTemplateUtils.processTemplateIntoString(new Template(smsRequest.getTemplateName(), smsRequest.getSmsTemplateInString(), fmConfiguration), smsRequest.getParameters());
            } else if (ContentType.CONTENT.equals(smsRequest.getTemplate())) {
                return smsRequest.getContent();
            }
        } catch (TemplateException | IOException e) {
            log.error("Exception in parsing SMS template : ", e);
        }
        return null;
    }

    /**
     * CONVERT EMAIL TO ABCDXXX@GXXX.COM
     * */
    private static String convertEmailToXxx(String email) {
        try {
            if (email.contains("@") && email.contains(".")) {
                String[] split = email.split("@");
                String[] split2 = split[1].split("\\.");
                String firstPart = split[0];
                String secPart = split2[0];

                String result = null;

                if (firstPart.length() > 5) {
                    result = firstPart.substring(0, 5).concat("xxx");
                } else {
                    result = firstPart;
                }

                if (secPart.length() > 5) {
                    if (split[1].substring(secPart.length()).length() > 5) {
                        int length = split2[split2.length - 1].length() - 4;
                        result = result.concat("@").concat(secPart).concat("xxx");
                        if (length > 0) {
                            result = result.concat(split2[split2.length - 1].substring(split2[split2.length - 1].length() - 4));
                        } else {
                            result = result.concat(split2[split2.length - 1]);
                        }
                    } else {
                        result = result.concat("@").concat(secPart.substring(0, 5)).concat("xxx").concat(split[1].substring(secPart.length()));
                    }
                } else {
                    // make condition of split2.lenght
                    if (split[1].substring(secPart.length()).length() > 5) {
                        int length = split2[split2.length - 1].length() - 4;
                        result = result.concat("@").concat(secPart).concat("xxx");
                        if (length > 0) {
                            result = result.concat(split2[split2.length - 1].substring(split2[split2.length - 1].length() - 4));
                        } else {
                            result = result.concat(split2[split2.length - 1]);
                        }
                    } else {
                        result = result.concat("@").concat(secPart).concat(split[1].substring(secPart.length()));
                    }

                }

                return result;
            }
            return email;
        } catch (Exception e) {
            log.error("Exception in masking email " + email + "And error  is :" + e);
            return email;
        }
    }


    /** GET NOTIFICATION TEMPLATE BASED ON MASTER ID , USER ORG ID ,LOAN TYPE ID  */
    public NotificationTemplateRequest getNotificationTemplateForSmsAndSystemNotification(Long masterId,Long userOrgId, Integer loanType) {
        NotificationMaster master = notiMasterRepo.findByMasterIdAndIsActiveIsTrue(masterId);
        if (master != null && master.getNotificationTemplate() != null && !master.getNotificationTemplate().isEmpty()) {
            NotificationTemplateRequest defaultTempReq = new NotificationTemplateRequest();
            NotificationTemplateRequest tempReqForOrg = new NotificationTemplateRequest();
            NotificationTemplateRequest tempReqForLoanType = new NotificationTemplateRequest();
            NotificationMasterRequest masterReq = new NotificationMasterRequest();
            for (NotificationTemplate temp : master.getNotificationTemplate()) {

                /* GETTING TEMPLATE LOAN TYPE WISE */
                if (Boolean.TRUE.equals(master.getIsEditable() && loanType != null && temp.getLoanType() != null) && !temp.getLoanType().isEmpty()) {
                    for (LoanType loan : temp.getLoanType()) {
                        if (loan != null && loan.getLoanTypeId().equals(loanType)) {
                            Utils.selectTemplateForSmsAndSystem(tempReqForLoanType, masterReq, temp);
                        }
                    }
                }

                /* GETTING TEMPLATE ORGANISATION WISE */
                if (Boolean.TRUE.equals(master.getIsEditable() && userOrgId != null && temp.getUserOrg() != null) && !temp.getUserOrg().isEmpty()) {
                    for (UserOrganizationMasterV3 org : temp.getUserOrg()) {
                        if (org != null && org.getOrgId().equals(userOrgId)) {
                            Utils.selectTemplateForSmsAndSystem(tempReqForOrg, masterReq, temp);
                        }
                    }
                }

                /* IF TEMPLATE NOT GET FROM ORG WISE AND LOAN TYPE WISE THEN ITS SEND DEFAULT TEMPLATE */
                if (tempReqForLoanType.getNotificationTemplate() == null && tempReqForOrg.getNotificationTemplate() == null) {
                    Utils.selectTemplateForSmsAndSystem(defaultTempReq, masterReq, temp);
                }
            }
            if (tempReqForLoanType.getId() != null && tempReqForOrg.getId() != null && tempReqForLoanType.getId().equals(tempReqForOrg.getId()) && tempReqForLoanType.getNotificationTemplate() != null && tempReqForOrg.getNotificationTemplate() != null) {
                return tempReqForLoanType;
            } else {
                if (tempReqForLoanType.getId() != null && tempReqForOrg.getId() == null) {
                    return tempReqForLoanType;
                } else if (tempReqForOrg.getId() != null && tempReqForLoanType.getId() == null) {
                    return tempReqForOrg;
                } else {
                    return defaultTempReq;
                }
            }
        } else {
            return null;
        }
    }
}
