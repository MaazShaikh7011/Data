package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Entity
@Setter
@Getter
@Table(name = "notification_type", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION)
@NamedQuery(name = "NotificationType.findAll", query = "SELECT n FROM NotificationType n")
public class NotificationType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_type_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_type_seq_gen", sequenceName = "notification_type_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "IS_ACTIVE")
    private String isActive;

    @Column(name = "MODIFIED_BY")
    private Long modifiedBy;

    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;

    @Column(name = "NOTIFICATION_TYPE_DESC")
    private String notificationTypeDesc;

    @Column(name = "NOTIFICATION_TYPE_NAME")
    private String notificationTypeName;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "id")
    private List<NotificationTemplate> notificationTemplates;

    public NotificationType() {
        //Do Nothing because of X and Y.
    }

}