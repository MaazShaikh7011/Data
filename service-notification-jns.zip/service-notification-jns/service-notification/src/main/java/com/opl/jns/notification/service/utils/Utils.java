package com.opl.jns.notification.service.utils;

import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.service.domain.NotificationTemplate;
import com.opl.notification.provider.model.NotificationMasterRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.BeanUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Slf4j
public class Utils {

    public static final String NOTIFICATION_SERVICE_EXECUTED_SUCCESSFULLY = "Notification Service executed successfully";
    public static final String SMS_REJECTED_CAUSE_ONCE_ALREADY_SENT_TODAY = "SMS Rejected cause once already sent today";
    public static final List<String> URLS_BRFORE_LOGIN = new ArrayList<String>(1);
    public static final String REJECT_EMAIL_TEMPLATE_ONCE_SENT_IN_A_DAY = "reject_email_template_once_sent_in_a_day";
    public static final String REJECT_SMS_ONCE_SENT_IN_A_DAY = "reject_sms_once_sent_in_a_day";
    public static final String EMAIL_REJECTED_CAUSE_ONCE_SENT_IN_A_DAY = "Email Rejected cause once sent in a day";
    public static final String FROM = "from";


    static {
        URLS_BRFORE_LOGIN.add("/notification/error".toLowerCase());
    }



    public static String printLogs(String to, NotificationType type) {
        return "---TO ---" + to + "---NOTIFICATION_TYPE---" + type.getName() + "----";
    }

    public static Long getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        SecureRandom rand = new SecureRandom();
        int number = rand.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return Long.valueOf(number);
    }


    public static Object printFieldsForValue(Object obj, Map<String, Object> data) throws Exception {
        if (obj != null) {
            if (obj.getClass().isArray()) {
                // Do nothing because of X and Y.
            }
        } else {
            return obj;
        }
        if (obj instanceof Map map) {

            Set<Object> keySet = map.keySet();
            for (Object key : keySet) {
                map.put(key,printFieldsForValue(map.get(key), data));
            }
        } else if (obj instanceof String string) {
            obj = StringEscapeUtils.escapeXml(string.replace("--", ""));
            return obj;
        } else {
            if (obj.getClass().getName().startsWith("com.opl")) {
                Field[] fields = obj.getClass().getDeclaredFields();
                for (Field field : fields) {
                    if ((field.getModifiers() & Modifier.STATIC) == Modifier.STATIC) {
                        // Do nothing because of X and Y.
                    } else {
                        field.setAccessible(true);
                        Object value = field.get(obj);
                        field.set(obj, printFieldsForValue(value, data));
                    }
                }
            }
        }
        return obj;
    }

    public static void selectTemplateForSmsAndSystem(NotificationTemplateRequest tempReqForLoanType, NotificationMasterRequest masterReq, NotificationTemplate temp) {
        BeanUtils.copyProperties(temp.getNotificationMaster(), masterReq);
        BeanUtils.copyProperties(temp, tempReqForLoanType);
        tempReqForLoanType.setMasterReq(masterReq);
    }
    public static String unscapeHtmlFtlTags(String content) {
        return StringEscapeUtils.unescapeHtml(StringEscapeUtils.unescapeXml(content.replace("&nbsp;", " ")));
    }
}
