package com.opl.jns.notification.service.service.impl;

import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.notification.api.model.systemNotification.SystemNotificationMessage;
import com.opl.jns.notification.api.model.systemNotification.SystemNotifyRequest;
import com.opl.jns.notification.api.model.systemNotification.SystemNotifyResponse;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.service.domain.LoanType;
import com.opl.jns.notification.service.domain.NotificationMaster;
import com.opl.jns.notification.service.domain.NotificationTemplate;
import com.opl.jns.notification.service.domain.SystemNotificationLog;
import com.opl.jns.notification.service.repository.NotificationMasterRepository;
import com.opl.jns.notification.service.repository.SystemNotificationLogRepository;
import com.opl.jns.notification.service.service.SystemNotifyService;
import com.opl.jns.notification.service.utils.Utils;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.notification.provider.model.CommonPayLoadProxy;
import com.opl.notification.provider.model.NotificationMasterRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import com.opl.notification.provider.service.NotificationAuditService;
import com.opl.notification.provider.utils.NotificationUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Service
@Transactional
@Slf4j
public class SystemNotifyServiceImpl implements SystemNotifyService {

    @Autowired
    private Configuration fmConfiguration;

    @Autowired
    private SystemNotificationLogRepository logRepository;

    @Autowired
    private NotificationAuditService auditService;

    @Autowired
    private NotificationMasterRepository notiMasterRepo;


    /**
     * SEND SYSTEM NOTIFICATION
     * */
    @Override
    public SystemNotifyResponse sendSystemNotification(SystemNotifyRequest request) {
        SystemNotifyResponse response = new SystemNotifyResponse();
        for (String toUserId : request.getToUserId()) {
            Long to = Long.valueOf(toUserId);
            Date curruntDate = new Date();

            /* GETTING SYSTEM NOTIFICATION TEMPLATE */
            NotificationTemplateRequest templateReq = getNotificationTemplateForSmsAndSystemNotification(request.getMasterId(), request.getUserOrgId(), request.getLoanTypeId());
            if (!OPLUtils.isObjectNullOrEmpty(templateReq) && templateReq.getIsWorking() != null && templateReq.getIsWorking()) {
                request.setSystemNotificationTemplateInString(templateReq.getNotificationTemplate());
                request.setTemplateName(templateReq.getTemplateName());
            } else {
                log.error("System notification template is not active for Master ID [{}] While sending TO UserId to [{}]", request.getMasterId(), request.getToUserId());
                response.setMessage("System notification template is not found or template is not active");
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                return response;
            }

            /* CHECK HEAR IF SELECTED TEMPLATE HAVE ONCE SENT IN A DAY OR NOT */
            boolean isSent = rejectSelectedNotificationOnceSentInaDay(toUserId, templateReq, to, curruntDate);
            if (isSent) {
                response.setMessage("System notification rejected cause once sent today");
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                return response;
            }

            /* MAPPED THE KEYS AND VALUES INTO TEMPLATE */
            String message = mapKeysToTemplate(request, fmConfiguration);
            if (OPLUtils.isObjectNullOrEmpty(message)) {
                response.setMessage("Exception while mapping the values in templates");
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                return response;
            }

            /* SAVE FOR SYSTEM NOTIFICATION */
            SystemNotificationLog sysLog = new SystemNotificationLog();
            sysLog.setFromUserId(request.getFromUserId());
            sysLog.setToUserId(to);
            sysLog.setSendDate(curruntDate);
            sysLog.setTemplateId(templateReq.getId());
            sysLog.setRelatedApplicationId(request.getRelatedApplicationId());
            sysLog.setRead(false);
            sysLog.setActive(true);
            sysLog = logRepository.save(sysLog);

            // update here payload
            auditService.updateBucketLogsForSystemNotification(sysLog.getId(), message);
        }
        response.setMessage("Notification Saved Successfully");
        response.setStatus(HttpStatus.OK.value());
        return response;
    }

    public static String mapKeysToTemplate(SystemNotifyRequest sysRequest, Configuration fmConfiguration) {
        try {
            return FreeMarkerTemplateUtils.processTemplateIntoString(new Template(sysRequest.getTemplateName(), sysRequest.getSystemNotificationTemplateInString(), fmConfiguration), sysRequest.getParameters());
        } catch (TemplateException | IOException e) {
            log.error("Exception while parsing the System notification Template :", e);
            return null;
        }
    }

    /* FOR SMS AND SYSTEM NOTIFICATION */
    public NotificationTemplateRequest getNotificationTemplateForSmsAndSystemNotification(Long masterId,Long userOrgId, Integer loanType) {
        log.info("----------getting notification templates for master id : {}", masterId);
        NotificationMaster master = notiMasterRepo.findByMasterIdAndIsActiveIsTrue(masterId);
        if (master != null && master.getNotificationTemplate() != null && !master.getNotificationTemplate().isEmpty()) {
            NotificationTemplateRequest defaultTempReq = new NotificationTemplateRequest();
            NotificationTemplateRequest tempReqForOrg = new NotificationTemplateRequest();
            NotificationTemplateRequest tempReqForLoanType = new NotificationTemplateRequest();
            NotificationMasterRequest masterReq = new NotificationMasterRequest();
            for (NotificationTemplate temp : master.getNotificationTemplate()) {

                /* GETTING TEMPLATE LOAN TYPE WISE */
                if (Boolean.TRUE.equals(master.getIsEditable() && loanType != null && temp.getLoanType() != null) && !temp.getLoanType().isEmpty()) {
                    for (LoanType loan : temp.getLoanType()) {
                        if (loan != null && loan.getLoanTypeId().equals(loanType)) {
                            Utils.selectTemplateForSmsAndSystem(tempReqForLoanType, masterReq, temp);
                        }
                    }
                }

                /* GETTING TEMPLATE ORGANISATION WISE */
                if (Boolean.TRUE.equals(master.getIsEditable() && userOrgId != null && temp.getUserOrg() != null) && !temp.getUserOrg().isEmpty()) {
                    for (UserOrganizationMasterV3 org : temp.getUserOrg()) {
                        if (org != null && org.getOrgId().equals(userOrgId)) {
                            Utils.selectTemplateForSmsAndSystem(tempReqForOrg, masterReq, temp);
                        }
                    }
                }

                /* IF TEMPLATE NOT GET FROM ORG WISE AND LOAN TYPE WISE THEN ITS SEND DEFAULT TEMPLATE */
                if (tempReqForLoanType.getNotificationTemplate() == null && tempReqForOrg.getNotificationTemplate() == null) {
                    Utils.selectTemplateForSmsAndSystem(defaultTempReq, masterReq, temp);
                }
            }
            if (tempReqForLoanType.getId() != null && tempReqForOrg.getId() != null && tempReqForLoanType.getId().equals(tempReqForOrg.getId()) && tempReqForLoanType.getNotificationTemplate() != null && tempReqForOrg.getNotificationTemplate() != null) {
                return tempReqForLoanType;
            } else {
                if (tempReqForLoanType.getId() != null && tempReqForOrg.getId() == null) {
                    return tempReqForLoanType;
                } else if (tempReqForOrg.getId() != null && tempReqForLoanType.getId() == null) {
                    return tempReqForOrg;
                } else {
                    return defaultTempReq;
                }
            }
        } else {
            return null;
        }
    }
    /**
     * FETCH ALL READ AND UN READ SYSTEM NOTIFICATION
     * */
    @Override
    public SystemNotifyResponse fetchAllSystemNotification(Long toId) {
        List<SystemNotificationLog> allNotification = logRepository.findAllByToUserIdAndIsActiveTrue(toId);
        if (!OPLUtils.isListNullOrEmpty(allNotification)) {
            SystemNotifyResponse response = new SystemNotifyResponse();
            int unReadCount = (int) allNotification.stream().filter(x -> !x.isRead()).count();
            response.setAllCount(allNotification.size());
            response.setUnReadCount(unReadCount);
            List<SystemNotificationMessage> messageList = new ArrayList<>();
            SystemNotificationMessage systemNotificationMessage = null;
            CommonPayLoadProxy commonPayLoadProxy = null;
            for (SystemNotificationLog log : allNotification) {
                // fetch message from bucket
                commonPayLoadProxy = auditService.fetchMessageFromBucket(log.getId(), NotificationType.SYSTEM.getTypeId().intValue());
                if (!OPLUtils.isObjectNullOrEmpty(commonPayLoadProxy)) {
                    systemNotificationMessage = new SystemNotificationMessage(log.getId(), commonPayLoadProxy.getNotificationMessage(), log.isRead());
                    messageList.add(systemNotificationMessage);
                }
            }
            response.setMessages(messageList);
            return response;
        }
        return null;
    }

    /**
     * READ SYSTEM NOTIFICATION
     * */
    @Override
    public void readSystemNotification(Long notificationId) {
        SystemNotificationLog systemMsg = logRepository.findByIdAndIsActiveTrue(notificationId);
        systemMsg.setRead(true);
        systemMsg.setReadDate(new Date());
        logRepository.save(systemMsg);
    }

    /** FIND ONCE SYSTEM NOTIFICATION SEND TO THIS USER OR NOT*/
    private boolean rejectSelectedNotificationOnceSentInaDay(String toUserId, NotificationTemplateRequest templateReq, Long to, Date curruntDate) {
        String basicConfigValue = NotificationUtils.getBasicConfigByKey("reject_system_notification_once_sent_in_a_day");
        if (!OPLUtils.isObjectNullOrEmpty(basicConfigValue)) {
            String[] templateList = basicConfigValue.split(",");
            for (String tem : templateList) {
                if (Long.valueOf(tem).equals(templateReq.getId()) && !OPLUtils.isObjectNullOrEmpty(toUserId)) {
                    SystemNotificationLog noti = logRepository.findFirstByToUserIdAndTemplateIdAndIsActiveTrueOrderByIdDesc(to, templateReq.getId());
                    if (!OPLUtils.isObjectNullOrEmpty(noti)) {
                        long dayDiff = TimeUnit.DAYS.convert(curruntDate.getTime() - noti.getSendDate().getTime(), TimeUnit.MILLISECONDS);
                        if (dayDiff == 0) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }
}
