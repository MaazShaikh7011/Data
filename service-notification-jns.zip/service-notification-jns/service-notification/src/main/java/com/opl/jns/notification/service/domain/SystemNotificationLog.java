package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "system_notification_log", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION,
        indexes = {
                @Index(columnList = "to_user_id,is_active,is_read", name = DBNameConstant.JNS_NOTIFICATION + "SYS_LOG_to_act_read")
        })
@NamedQuery(name = "SystemNotificationLog.findAll", query = "SELECT n FROM SystemNotificationLog n")
public class SystemNotificationLog implements Serializable {
    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "system_notification_log_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "system_notification_log_seq_gen", sequenceName = "system_notification_log_seq_gen", allocationSize = 1)
    private Long id;
    @Column(name = "to_user_id", nullable = false)
    private Long toUserId;
    @Column(name = "from_user_id", nullable = false)
    private Long fromUserId;
    @Column(name = "related_application_id")
    private Long relatedApplicationId;
    @Column(name = "template_id")
    private Long templateId;
    @Column(name = "is_read")
    private boolean isRead = false;
    @Column(name = "send_date")
    private Date sendDate;
    @Column(name = "read_date")
    private Date readDate;
    @Column(name = "is_active")
    private boolean isActive = true;


}
