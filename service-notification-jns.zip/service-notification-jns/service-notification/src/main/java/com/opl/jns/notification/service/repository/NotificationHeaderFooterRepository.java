package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.NotificationHeaderFooter;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationHeaderFooterRepository extends JpaRepository<NotificationHeaderFooter, Long> {


}
