package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_cust_care_details_master", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION, indexes = {})
public class NotificationCustCareMaster implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_cust_care_details_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_cust_care_details_master_seq_gen", sequenceName = "notification_cust_care_details_master_seq_gen", allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "cust_care_number")
    private String custCareNumber;

    @Column(name = "cust_care_email_id")
    private String custCareEmailId;

    @Column(name = "org_name")
    private String orgName;

    @Column(name = "is_active")
    private Boolean isActive;
}
