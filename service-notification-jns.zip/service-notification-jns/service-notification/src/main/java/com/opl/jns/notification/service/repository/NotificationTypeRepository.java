package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.NotificationType;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationTypeRepository extends JpaRepository<NotificationType, Long> {


}
