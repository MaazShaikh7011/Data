package com.opl.jns.notification.service.vo;

import com.opl.notification.provider.model.NotificationMasterRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class NotificationEmailSubjectRequest {

    private Long subjectId;

    private NotificationTemplateRequest template;

    private String subject;

    private String description;

    private Boolean isActive;

    private Date createdDate;

    private Date modifiedDate;

    private Long modifiedBy;

    private Long createdBy;

    private NotificationMasterRequest masterRequest;

}
