package com.opl.jns.notification.service.service.impl;

import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.notification.service.domain.LoanType;
import com.opl.jns.notification.service.domain.NotificationEmailSubject;
import com.opl.jns.notification.service.domain.NotificationMaster;
import com.opl.jns.notification.service.repository.NotificationEmailRejectDumpRepository;
import com.opl.jns.notification.service.repository.NotificationMasterRepository;
import com.opl.jns.notification.service.service.MailService;
import com.opl.jns.notification.service.utils.Utils;
import com.opl.jns.notification.service.utils.Validator;
import com.opl.jns.notification.service.vo.NotificationEmailSubjectRequest;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.notification.provider.enums.ContentType;
import com.opl.notification.provider.model.NotificationMasterRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
import com.opl.notification.provider.service.NotificationService;
import com.opl.notification.provider.utils.NotificationUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Slf4j
@Service
@Transactional
public class MailServiceImpl implements MailService {


    @Autowired
    private NotificationMasterRepository notificationMasterRepository;

    @Autowired
    private Configuration fmConfiguration;

    @Autowired
    private NotificationEmailRejectDumpRepository notificationEmailRejectDumpRepository;

    @Autowired
    private NotificationService notificationProviderService;

    /**
     * SEND EMAIL OF REQUEST MASTER ID TO GIVEN EMAIL
     * */
    @Override
    public EmailResponse sendEmail(EmailRequest emailRequest) {
        EmailResponse response = new EmailResponse();

         /* GETTING TEMPLATE BY LOAN AND USER ORG ID*/
        if (!OPLUtils.isObjectNullOrEmpty(emailRequest.getTemplate()) && emailRequest.getTemplate().equals(ContentType.TEMPLATE)) {
            NotificationEmailSubjectRequest subject = getNotificationTemplateForEmail(emailRequest.getMasterId(), emailRequest.getUserOrgId(), emailRequest.getLoanTypeId());

            /* READING SUBJECT WITH DYNAMIC KEYS */
            if (Boolean.TRUE.equals(subject != null && subject.getTemplate() != null && subject.getTemplate().getIsWorking()) && !OPLUtils.isObjectNullOrEmpty(subject.getSubject())) {
                String mappedSubject = readEmailSubject(subject, emailRequest);
                if (OPLUtils.isObjectNullOrEmpty(mappedSubject)) {
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    response.setMessage("Error while mapping the values against key in subject");
                    return response;
                }
                emailRequest.setSubject(mappedSubject);
                emailRequest.setTemplateId(subject.getTemplate().getId());
                emailRequest.setSubjectId(subject.getSubjectId());
                emailRequest.setMasterId(subject.getMasterRequest().getMasterId());
                emailRequest.setDefaultConfigKey(subject.getMasterRequest().getDefaultConfigKey());
                emailRequest.setTemplateRequest(subject.getTemplate());
            } else {
                log.error("Email is not active or Subject not found for Master ID [{}] While sending email to [{}]", emailRequest.getMasterId(), emailRequest.getToEmailStr());
                response.setMessage("Email Subject not found or template is not active");
                response.setStatus(HttpStatus.BAD_REQUEST.value());
                return response;
            }
        }

        /* MAPPED THE KEYS AND VALUES INTO TEMPLATE */
        String message = mapKeysToTemplateForEmail(emailRequest);
        if(!OPLUtils.isObjectNullOrEmpty(message)){
            emailRequest.setEmailContent(message);
        }else{
            response.setMessage("Exception while mapping the values in templates");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* SET BCC EMAIL IN EMAIL */
        Boolean isBccActive = !OPLUtils.isObjectNullOrEmpty(emailRequest.getTemplateRequest().getIsBccActive()) ? emailRequest.getTemplateRequest().getIsBccActive() : Boolean.FALSE;
        String[] bcc = getBcc(isBccActive, emailRequest.getTemplateRequest().getBccEmail(), emailRequest.getBcc());
        emailRequest.setBccStr(StringUtils.arrayToCommaDelimitedString(bcc));
        emailRequest.setBcc(bcc);

        /* SET CC EMAIL IN EMAIL */
        String[] cc = getCc(emailRequest.getCc());
        emailRequest.setCcStr(StringUtils.arrayToCommaDelimitedString(cc));
        emailRequest.setCc(cc);

        /* SET FROM EMAIL */
        emailRequest.setFromEmail(NotificationUtils.getBasicConfigByKey(Utils.FROM));

        /* SEND EMAIL */
        notificationProviderService.processEmail(emailRequest);
        response.setMessage("Notification submitted to provider");
        response.setStatus(HttpStatus.OK.value());
        return response;
    }

    /**
     * GET NOTIFICATION TEMPLATE BASED ON MASTER ID , USER ORG ID ,LOAN TYPE ID
     * */
    @Override
    public NotificationEmailSubjectRequest getNotificationTemplateForEmail(Long masterId, Long userOrgId, Integer loanType) {
        NotificationMaster master = notificationMasterRepository.findByMasterIdAndIsActiveIsTrue(masterId);
        if (master != null && master.getNotificationEmailSubjects() != null && !master.getNotificationEmailSubjects().isEmpty()) {
            NotificationEmailSubjectRequest subjRequest = new NotificationEmailSubjectRequest();
            NotificationEmailSubjectRequest subjRequestForLoan = new NotificationEmailSubjectRequest();
            NotificationEmailSubjectRequest subjRequestForOrg = new NotificationEmailSubjectRequest();

            NotificationTemplateRequest tempReq = new NotificationTemplateRequest();
            NotificationMasterRequest masterReq = new NotificationMasterRequest();

            for (NotificationEmailSubject subjects : master.getNotificationEmailSubjects()) {

                /* FETCHING TEMPLATE BASED ON LOAN TYPE */
                if (Boolean.TRUE.equals(master.getIsEditable() && loanType != null && subjects.getLoanType() != null) && !subjects.getLoanType().isEmpty()) {
                    for (LoanType loan : subjects.getLoanType()) {
                        if (loan != null && loan.getLoanTypeId().equals(loanType)) {
                            selectTemplateForEmail(subjRequestForLoan, tempReq, masterReq, subjects);
                            break;
                        }
                    }
                }

                /* GETTING TEMPLATE AND SUBJECT ORGANISATION WISE */
                if (Boolean.TRUE.equals(master.getIsEditable() && userOrgId != null && subjects.getUserOrg() != null) && !subjects.getUserOrg().isEmpty()) {
                    for (UserOrganizationMasterV3 org : subjects.getUserOrg()) {
                        if (org != null && org.getOrgId().equals(userOrgId)) {
                            selectTemplateForEmail(subjRequestForOrg, tempReq, masterReq, subjects);
                            break;
                        }
                    }
                }

                /* IF TEMPLATE NOT FOUND FROM ORG WISE AND LOAN TYPE WISE THEN ITS SEND DEFAULT TEMPLATE */
                if (subjRequestForLoan.getTemplate() == null && subjRequestForOrg.getTemplate() == null) {
                    selectTemplateForEmail(subjRequest, tempReq, masterReq, subjects);
                }
            }
            if (subjRequestForLoan.getSubjectId() != null && subjRequestForOrg.getSubjectId() != null && subjRequestForLoan.getSubjectId().equals(subjRequestForOrg.getSubjectId()) && subjRequestForLoan.getTemplate() != null && subjRequestForOrg.getTemplate() != null) {
                return subjRequestForLoan;
            } else {
                if (subjRequestForLoan.getSubjectId() != null && subjRequestForOrg.getSubjectId() == null) {
                    return subjRequestForLoan;
                } else if (subjRequestForOrg.getSubjectId() != null && subjRequestForLoan.getSubjectId() == null) {
                    return subjRequestForOrg;
                } else {
                    return subjRequest;
                }
            }
        } else {
            return null;
        }

    }

    /**
     * READ EMAIL SUBJECT AND BIND VALUE ON IT IF EXISTS USING FREEMARKER
     * */
    private String readEmailSubject(NotificationEmailSubjectRequest subj, EmailRequest request) {
        if (subj.getSubject().contains("${")) {
            try {
                Template temForSubj = new Template(subj.getTemplate().getTemplateName(), new StringReader(subj.getSubject()), fmConfiguration);
                Writer out = new StringWriter();
                temForSubj.process(request.getParameters(), out);
                return out.toString();
            } catch (IOException | TemplateException e) {
                log.error("Exception while mapping the dynamic key into subject");
                return null;
            }
        } else {
            return subj.getSubject();
        }

    }

    /**
     * READ EMAIL BODY AND BIND VALUE ON IT USING FREEMARKER
     * */
    private String mapKeysToTemplateForEmail(EmailRequest emailRequest) {
        try {
            if(!OPLUtils.isObjectNullOrEmpty(emailRequest.getTemplate())) {
                if (com.opl.notification.provider.enums.ContentType.TEMPLATE.equals(emailRequest.getTemplate())) {
                    StringBuilder sb = new StringBuilder();
                    /* UN-SCAPE CHARACTER */
                    sb.replace(0, sb.length(), Utils.unscapeHtmlFtlTags(emailRequest.getTemplateRequest().getNotificationTemplate()));

                    Template t2 = new Template(emailRequest.getTemplateRequest().getTemplateName(), new StringReader(sb.toString()), fmConfiguration);
                    Writer out = new StringWriter();
                    emailRequest.setParameters((Map<String, Object>) Utils.printFieldsForValue(emailRequest.getParameters(), null));
                    t2.process(emailRequest.getParameters(), out);
                    return out.toString();
                } else if (ContentType.CONTENT.equals(emailRequest.getTemplate())) {
                    return emailRequest.getContent();
                }
            }else{
                log.error("Content-Type is null for sending email of Master Id [{}] for to [{}]",emailRequest.getMasterId(),emailRequest.getToEmailStr());
            }
        } catch (Exception e) {
            log.error("Exception in parsing template for sending email of Master Id [{}] for to [{}]",emailRequest.getMasterId(),emailRequest.getToEmailStr());
            log.error("Exception in parsing template : ", e);
        }
        return null;
    }

    /**
     * SELECT TEMPLATE
     * */
    private void selectTemplateForEmail(NotificationEmailSubjectRequest subjectReq, NotificationTemplateRequest tempReq, NotificationMasterRequest masterReq, NotificationEmailSubject subjects) {
        BeanUtils.copyProperties(subjects, subjectReq);
        BeanUtils.copyProperties(subjects.getTemplateId(), tempReq);
        BeanUtils.copyProperties(subjects.getNotificationMaster(), masterReq);
        if (OPLUtils.isObjectNullOrEmpty(subjects.getTemplateId().getIsSinglePageTemplate()) || !subjects.getTemplateId().getIsSinglePageTemplate()) {
            String builder = subjects.getTemplateId().getNotificationHeader().getTemplate() +
                    subjects.getTemplateId().getNotificationTemplate() +
                    subjects.getTemplateId().getNotificationFooter().getTemplate();
            tempReq.setNotificationTemplate(builder);
        } else {
            tempReq.setNotificationTemplate(subjects.getTemplateId().getNotificationTemplate());
        }
        subjectReq.setMasterRequest(masterReq);
        subjectReq.setTemplate(tempReq);
    }

    /**
     * GET VALID EMAIL ID FOR BCC FROM REQUESTED AND GIVEN IN TEMPLATE CONFIGURATION
     * */
    private String[] getBcc(boolean isBccActive,String bccEmails, String[] requestedBccEmails) {
        List<String> bccList = new ArrayList<>();
        if (!OPLUtils.isObjectNullOrEmpty(bccEmails) && isBccActive) {
            for (String bccEmail : bccEmails.split(",")) {
                if (Boolean.TRUE.equals(Validator.validateEmail(bccEmail)) && Boolean.FALSE.equals(validateRejectEmail(bccEmail))) {
                    bccList.add(bccEmail);
                }
            }
        }

        if (!OPLUtils.isObjectNullOrEmpty(requestedBccEmails)) {
            for (String bccEmail : requestedBccEmails) {
                if (Boolean.TRUE.equals(Validator.validateEmail(bccEmail)) && Boolean.FALSE.equals(validateRejectEmail(bccEmail))) {
                    bccList.add(bccEmail);
                }
            }
        }
        if (!bccList.isEmpty()) {
            return  bccList.toArray(new String[0]);
        }
        return null;
    }

    /**
     * GET VALID EMAIL ID FOR CC FROM REQUESTED
     * */
    private String [] getCc(String [] cc) {
        if (!OPLUtils.isObjectNullOrEmpty(cc) && cc.length > 0 ) {
            List<String> ccList = new ArrayList<>();
            for (int i = 0; i < cc.length; i++) {
                if (cc[i] != null && Boolean.TRUE.equals(Validator.validateEmail(cc[i])) && Boolean.FALSE.equals(validateRejectEmail(cc[i]))) {
                    ccList.add(cc[i]);
                }
            }

            if (!ccList.isEmpty()) {
                return Arrays.copyOf(ccList.toArray(), ccList.toArray().length, String[].class);
            } else {
                return null;
            }
        }
        return null;
    }

    /**
     * FETCH EMAIL COUNT FOR CHECKING REJECTION EMAILS
     * */
    private Boolean validateRejectEmail(String email) {
        Long count = notificationEmailRejectDumpRepository.countByEmailIdAndIsActiveTrue(email);
        return !OPLUtils.isObjectNullOrEmpty(count) && count > 0;
    }
}


