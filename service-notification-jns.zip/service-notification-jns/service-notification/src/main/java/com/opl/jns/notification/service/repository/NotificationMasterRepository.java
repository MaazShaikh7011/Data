package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.NotificationMaster;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationMasterRepository extends JpaRepository<NotificationMaster, Long> {

    @Cacheable(value = "NOTIFICATION_MASTER_FIND_BY_ID_IS_ACTIVE")
    public NotificationMaster findByMasterIdAndIsActiveIsTrue(Long masterId);


}
