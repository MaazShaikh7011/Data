package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.SystemNotificationLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface SystemNotificationLogRepository extends JpaRepository<SystemNotificationLog, Long> {
    // send
    SystemNotificationLog findFirstByToUserIdAndTemplateIdAndIsActiveTrueOrderByIdDesc(Long toUserId, Long templateId);
    // read
    List<SystemNotificationLog> findAllByToUserIdAndIsActiveTrue(Long toUserId);

    SystemNotificationLog findByIdAndIsActiveTrue(Long id);

}
