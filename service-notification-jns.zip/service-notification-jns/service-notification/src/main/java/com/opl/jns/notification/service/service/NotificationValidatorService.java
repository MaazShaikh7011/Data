package com.opl.jns.notification.service.service;

import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.NotificationResponse;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationValidatorService {

    /**
     * VALIDATE REQUEST AND SEND NOTIFICATION BASES ON TYPE
     * */
    public NotificationResponse sendNotification(NotificationRequest notificationRequest);
}
