package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "loan_type", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION)
public class LoanType {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "loan_type_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "loan_type_seq_gen", sequenceName = "loan_type_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "loan_type_name")
    private String loanTypeName;

    @Column(name = "loan_type_id")
    private Integer loanTypeId;

    @Column(name = "buisness_type_id")
    private Integer buisnessTypeId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "is_active")
    private Boolean isActive;

}
