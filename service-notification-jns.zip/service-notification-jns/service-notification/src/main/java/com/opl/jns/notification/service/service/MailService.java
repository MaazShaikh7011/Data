package com.opl.jns.notification.service.service;

import com.opl.jns.notification.service.vo.NotificationEmailSubjectRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface MailService {

    /**
     * SEND EMAIL OF REQUEST MASTER ID TO GIVEN EMAIL
     * */
    public EmailResponse sendEmail(EmailRequest emailRequest);

    /**
     * GET NOTIFICATION TEMPLATE BASED ON MASTER ID , USER ORG ID ,LOAN TYPE ID
     * */
    public NotificationEmailSubjectRequest getNotificationTemplateForEmail(Long masterId, Long userOrgId, Integer loanType);

}
