package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_email_reject_dump", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION, indexes = {
})
public class NotificationEmailRejectDump {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_email_reject_dump_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_email_reject_dump_seq_gen", sequenceName = "notification_email_reject_dump_seq_gen", allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_date")
    private Date createdDate;


}
