package com.opl.jns.notification.service.boot;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableDiscoveryClient
public class NotificationApplication {

    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(NotificationApplication.class, args);
    }

    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

}
