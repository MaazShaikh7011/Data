package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.NotificationTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate, Long> {

    @Query("SELECT id FROM NotificationTemplate where notificationMaster.id=:masterId")
    List<Long> getTemplateListBasedOnMasterId(@Param("masterId") Long masterId);

}
