package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_master", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION, indexes = {
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "NOTI_TEMPLATE_MASTER_ACT", columnList = "id,is_active")
})
public class NotificationMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_master_seq_gen", sequenceName = "notification_master_seq_gen", allocationSize = 1)
    @Column(name = "id")
    private Long masterId;

    @Column(name = "notification_name")
    private String notificationName;

    @Column(name = "notification_desc")
    private String notificationDesc;

    @Column(name = "is_editable")
    private Boolean isEditable;

    @Column(name = "default_config_key")
    private String defaultConfigKey;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "created_by")
    private Long createdBy;

    @OneToMany(mappedBy = "notificationMaster", fetch = FetchType.LAZY)
    private List<NotificationEmailSubject> notificationEmailSubjects;

    @OneToMany(targetEntity = NotificationTemplate.class
            , mappedBy = "notificationMaster", fetch = FetchType.LAZY)
    private List<NotificationTemplate> notificationTemplate;


}
