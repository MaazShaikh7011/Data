package com.opl.jns.notification.service.domain;

import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_email_subject", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION, indexes = {
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "_SUBJ_MASTER_IDX", columnList = "notification_master_id"),
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "_SUBJ_TEMPLATE_IDX", columnList = "template_id")
})
public class NotificationEmailSubject {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_email_subject_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_email_subject_seq_gen", sequenceName = "notification_email_subject_seq_gen", allocationSize = 1)
    @Column(name = "subject_id")
    private Long subjectId;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "template_id")
    private NotificationTemplate templateId;

    @Column(name = "subject")
    private String subject;

    @Column(name = "description")
    private String description;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "created_by")
    private Long createdBy;

    @ManyToOne(targetEntity = NotificationMaster.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "notification_master_id")
    private NotificationMaster notificationMaster;

    @ManyToMany(targetEntity = UserOrganizationMasterV3.class,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinTable(
            name = "notification_email_subject_bank_relation",
            joinColumns = @JoinColumn(name = "subject_id"),
            inverseJoinColumns = @JoinColumn(name = "user_org_id"))
    private List<UserOrganizationMasterV3> userOrg;

    @ManyToMany(targetEntity = LoanType.class,
            cascade = {CascadeType.MERGE, CascadeType.PERSIST},
            fetch = FetchType.LAZY)
    @JoinTable(name = "notification_email_subject_loan_relation",
            joinColumns = @JoinColumn(name = "subject_id"),
            inverseJoinColumns = @JoinColumn(name = "loan_type_id"))
    private List<LoanType> loanType;


}
