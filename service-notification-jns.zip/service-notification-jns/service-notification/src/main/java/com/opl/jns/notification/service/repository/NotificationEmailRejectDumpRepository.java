package com.opl.jns.notification.service.repository;

import com.opl.jns.notification.service.domain.NotificationEmailRejectDump;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationEmailRejectDumpRepository extends JpaRepository<NotificationEmailRejectDump, Long> {
    public Long countByEmailIdAndIsActiveTrue(String email);
}
