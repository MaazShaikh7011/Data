package com.opl.jns.notification.service.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_template", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION, indexes = {
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "_TMPL_HEADER_IDX", columnList = "notification_header"),
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "_TMPL_FOOTER_IDX", columnList = "notification_footer"),
        @Index(name = DBNameConstant.JNS_NOTIFICATION + "_TMPL_MASTER_IDX", columnList = "notification_master_id")
})
@NamedQuery(name = "NotificationTemplate.findAll", query = "SELECT n FROM NotificationTemplate n")
public class NotificationTemplate implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_template_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_template_seq_gen", sequenceName = "notification_template_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Column(name = "CREATED_DATE")
    private Timestamp createdDate;

    @Column(name = "IS_ACTIVE")
    private String isActive;

    @Column(name = "is_working")
    private Boolean isWorking;

    @Column(name = "MODIFIED_BY")
    private Long modifiedBy;

    @Column(name = "MODIFIED_DATE")
    private Timestamp modifiedDate;

    @Column(name = "TEMPLATE_NAME")
    private String templateName;

    @Column(name = "NOTIFICATION_TEMPLATE")
    private String notificationTemplate;

    @OneToOne(fetch = FetchType.LAZY, targetEntity = NotificationHeaderFooter.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "notification_header")
    private NotificationHeaderFooter notificationHeader;

    @OneToOne(fetch = FetchType.LAZY, targetEntity = NotificationHeaderFooter.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "notification_footer")
    private NotificationHeaderFooter notificationFooter;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "NOTIFICATION_TYPE_ID")
    private NotificationType notificationType;

    @Column(name = "ORGANIZATION_ID")
    private Long organizationId;

    @Column(name = "ALIAS")
    private String alias;

    @Column(name = "is_bcc_active")
    private Boolean isBccActive;

    @Column(name = "bcc_email")
    private String bccEmail;

    @Column(name = "is_single_page_design")
    private Boolean isSinglePageTemplate;

    @Column(name = "is_work_with_old_flow")
    private Boolean isWorkWithOldFlow;

    @ManyToMany(targetEntity = UserOrganizationMasterV3.class,
            cascade = {CascadeType.PERSIST, CascadeType.MERGE},
            fetch = FetchType.LAZY)
    @JoinTable(
            name = "notification_template_bank_relation",
            joinColumns = @JoinColumn(name = "template_id"),
            inverseJoinColumns = @JoinColumn(name = "user_org_id"))
    private List<UserOrganizationMasterV3> userOrg;

    @ManyToMany(targetEntity = LoanType.class,
            cascade = {CascadeType.MERGE, CascadeType.PERSIST},
            fetch = FetchType.LAZY)
    @JoinTable(name = "notification_template_loan_type_relation",
            joinColumns = @JoinColumn(name = "template_id"),
            inverseJoinColumns = @JoinColumn(name = "loan_type_id"))
    private List<LoanType> loanType;


    @ManyToOne(targetEntity = NotificationMaster.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "notification_master_id")
    private NotificationMaster notificationMaster;

    @Column(name = "notification_description")
    private String notificationDescription;

    @Column(name = "dlt_id")
    private Long dltId;


    public NotificationTemplate() {
        // Do nothing because of X and Y.
    }


}