package com.opl.jns.notification.service.service.impl;


import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.NotificationResponse;
import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.model.systemNotification.SystemNotifyRequest;
import com.opl.jns.notification.api.model.systemNotification.SystemNotifyResponse;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.service.domain.NotificationCustCareMaster;
import com.opl.jns.notification.service.repository.NotificationCustCareMasterRepo;
import com.opl.jns.notification.service.repository.NotificationEmailRejectDumpRepository;
import com.opl.jns.notification.service.repository.NotificationTemplateRepository;
import com.opl.jns.notification.service.service.MailService;
import com.opl.jns.notification.service.service.NotificationValidatorService;
import com.opl.jns.notification.service.service.SmsService;
import com.opl.jns.notification.service.service.SystemNotifyService;
import com.opl.jns.notification.service.utils.Utils;
import com.opl.jns.notification.service.utils.Validator;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.notification.provider.domain.NotificationLogs;
import com.opl.notification.provider.model.BasicConfigurationRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
import com.opl.notification.provider.repository.NotificationLogsRepository;
import com.opl.notification.provider.utils.NotificationUtils;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Slf4j
@Service
@Transactional
public class NotificationValidatorServiceImpl implements NotificationValidatorService {


    @Autowired
    private MailService mailService;

    @Autowired
    private SmsService smsService;

    @Autowired
    private SystemNotifyService systemNotifyService;

    @Autowired
    private NotificationTemplateRepository notificationTemplateRepository;

    @Autowired
    private NotificationLogsRepository notificationLogsRepo;

    @Autowired
    private NotificationCustCareMasterRepo notificationCustCareMasterRepo;

    @Autowired
    private NotificationEmailRejectDumpRepository notificationEmailRejectDumpRepository;


    /**
     * VALIDATE BASIC NOTIFICATION REQUEST FOR ALL TYPE OF NOTIFICATION
     * */
    private static NotificationResponse validateNotificationRequest(NotificationResponse response, Notification request) {
        if (OPLUtils.isObjectNullOrEmpty(request.getType())) {
            response.setMessage("Notification Type can not be null");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (OPLUtils.isObjectNullOrEmpty(request.getTo())) {
            response.setMessage("To ids can not be null");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (OPLUtils.isObjectNullOrEmpty(request.getContentType())) {
            response.setMessage("Requested notification is not contain ContentType TEMPLATE OR CONTENT");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (!request.getContentType().equals(ContentType.TEMPLATE) && !request.getContentType().equals(ContentType.CONTENT)) {
            response.setMessage("Requested notification is not contain ContentType TEMPLATE OR CONTENT");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (request.getContentType() == ContentType.TEMPLATE && request.getMasterId() == null) {
            response.setMessage("Master Id can not be null");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }
        return null;
    }


    /**
     * VALIDATE REQUEST AND SEND NOTIFICATION BASES ON TYPE
     * */
    @Override
    public NotificationResponse sendNotification(NotificationRequest notificationRequest) {
        NotificationResponse response = new NotificationResponse();
        NotificationResponse validateResp = null;
        boolean isSentOnce = false;
        for (Notification request : notificationRequest.getNotifications()) {

            /* VALIDATING REQUEST */
            validateResp = validateNotificationRequest(response, request);
            if (!OPLUtils.isObjectNullOrEmpty(validateResp)) {
                return validateResp;
            }

            String templateIdsToCheck = null;
            switch (request.getType()) {
                case EMAIL:
                    EmailRequest emailRequest = new EmailRequest();

                    /* VALIDATE TO EMAIL */
                    List<String> validateTo = new ArrayList<>();
                    for (String to : request.getTo()) {
                        if (Boolean.TRUE.equals(Validator.validateEmail(to)) && Boolean.FALSE.equals(validateRejectEmail(to))) {
                            validateTo.add(to);
                        }
                    }
                    if (validateTo.isEmpty()) {
                        response.setMessage("Valid to email ids are not found");
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    /* REJECT NOTIFICATION ONCE SEND IN A DAY */
                    templateIdsToCheck = NotificationUtils.getBasicConfigByKey(Utils.REJECT_EMAIL_TEMPLATE_ONCE_SENT_IN_A_DAY);
                    if (!OPLUtils.isObjectNullOrEmpty(templateIdsToCheck)) {
                        isSentOnce = isNotificationSent(NotificationType.EMAIL, templateIdsToCheck, emailRequest.getToEmail(), emailRequest.getMasterId());
                        if (isSentOnce) {
                            response.setMessage(Utils.EMAIL_REJECTED_CAUSE_ONCE_SENT_IN_A_DAY);
                            response.setStatus(HttpStatus.BAD_REQUEST.value());
                            return response;
                        }
                    }

                    emailRequest.setToEmail(Arrays.copyOf(validateTo.toArray(), validateTo.size(), String[].class));
                    emailRequest.setToEmailStr(Arrays.toString(emailRequest.getToEmail()));
                    if (!OPLUtils.isObjectNullOrEmpty(request.getContentType())) {
                        emailRequest.setTemplate(com.opl.notification.provider.enums.ContentType.valueOf(request.getContentType().name()));
                        if (request.getContentType() == ContentType.CONTENT && request.getSubject() != null) {
                            emailRequest.setContent(request.getContent());
                            emailRequest.setSubject(String.valueOf(request.getSubject()));
                        }
                    }
                    emailRequest.setLoanTypeId(request.getLoanTypeId());
                    emailRequest.setUserOrgId(request.getUserOrgId());
                    emailRequest.setMasterId(request.getMasterId());
                    emailRequest.setCc(request.getCc());
                    emailRequest.setSourceType(request.getSourceType());
                    emailRequest.setSourceId(request.getSourceId());

                    /* VALIDATE TYPE WISE REQUEST AND EXECUTE NOTIFICATION -  GETTING VALUES FROM APPLICATION PROPERTY */
                    emailRequest.setParameters(upendPropertiesInParam(request.getParameters(), NotificationType.EMAIL.getTypeId().intValue()));
                    emailRequest.setCc(request.getCc());
                    emailRequest.setContentInBytes(request.getContentInBytes());
                    emailRequest.setFileName(request.getFileName());
                    emailRequest.setBcc(request.getBcc());

                    /* APPEND ATTACHMENT TO REQUEST */
                    List<ContentAttachment> contentAttachments = request.getContentAttachments();
                    if (!OPLUtils.isObjectNullOrEmpty(contentAttachments) && !contentAttachments.isEmpty()) {
                        List<com.opl.notification.provider.model.email.ContentAttachment> attachementList = new ArrayList<>(contentAttachments.size());
                        contentAttachments.forEach(x -> {
                            com.opl.notification.provider.model.email.ContentAttachment attamentReq = new com.opl.notification.provider.model.email.ContentAttachment();
                            BeanUtils.copyProperties(x, attamentReq);
                            attachementList.add(attamentReq);
                        });
                        emailRequest.setContentAttachments(attachementList);
                    }

                    EmailResponse emailResponse = mailService.sendEmail(emailRequest);
                    response.setMessage(emailResponse.getMessage());
                    response.setSentMessage(emailResponse.getEmailMessage());
                    response.setStatus(emailResponse.getStatus());
                    break;

                case SMS:
                    SMSRequest smsRequest = new SMSRequest();

                    /* VALIDATE MOBILE NUMBER */
                    if (OPLUtils.isObjectNullOrEmpty(request.getTo())) {
                        response.setMessage("valid phone number not found");
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    List<String> phoneNumberList = new ArrayList<>();
                    for (String phone : request.getTo()) {
                        if (Boolean.TRUE.equals(Validator.validateMobile(phone))) {
                            phoneNumberList.add(phone);
                        }
                    }

                    if (!phoneNumberList.isEmpty()) {
                        smsRequest.setPhoneNumber(Arrays.copyOf(phoneNumberList.toArray(), phoneNumberList.size(), String[].class));
                    } else {
                        response.setMessage("valid phone number not found");
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    /* REJECT NOTIFICATION ONCE SEND IN A DAY  */
                    templateIdsToCheck = NotificationUtils.getBasicConfigByKey(Utils.REJECT_SMS_ONCE_SENT_IN_A_DAY);
                    isSentOnce = isNotificationSent(NotificationType.SMS, templateIdsToCheck, smsRequest.getPhoneNumber(), smsRequest.getMasterId());
                    if (isSentOnce) {
                        response.setMessage(Utils.SMS_REJECTED_CAUSE_ONCE_ALREADY_SENT_TODAY);
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    /* CHECK DYNAMIC PARAMETERS LENGTH */
                    for (String Parameter : request.getParameters().keySet()) {
                        if (!OPLUtils.isObjectNullOrEmpty(request.getParameters().get(Parameter)) && request.getParameters().get(Parameter).toString().length() > 30) {
                            log.info("Parameter Length Exceed 30 Characters param name {} and value : {}", Parameter, request.getParameters().get(Parameter).toString());
                            response.setMessage(Parameter + " Parameter Length Exceed 30 Characters");
                            response.setStatus(HttpStatus.BAD_REQUEST.value());
                            return response;
                        }
                    }

                    /* VALIDATE TYPE WISE REQUEST AND EXECUTE NOTIFICATION*/
                    smsRequest.setParameters(upendPropertiesInParam(request.getParameters(), NotificationType.SMS.getTypeId().intValue()));
                    smsRequest.setTemplateId(request.getTemplateId());
                    smsRequest.setLoanTypeId(request.getLoanTypeId());
                    smsRequest.setUserOrgId(request.getUserOrgId());
                    smsRequest.setMasterId(request.getMasterId());
                    smsRequest.setPhoneNumber(request.getTo());
                    smsRequest.setSourceType(request.getSourceType());
                    smsRequest.setSourceId(request.getSourceId());
                    if (!OPLUtils.isObjectNullOrEmpty(request.getContentType())) {
                        smsRequest.setTemplate(com.opl.notification.provider.enums.ContentType.valueOf(request.getContentType().name()));
                        if (request.getContentType().equals(ContentType.CONTENT) && request.getContent() != null) {
                            smsRequest.setContent(request.getContent());
                        }
                    }

                    SMSResponse smsResponse = smsService.sendSMS(smsRequest);
                    response.setMessage(smsResponse.getMessage());
                    response.setSentMessage(smsResponse.getSmsMessage());
                    response.setStatus(smsResponse.getStatus());
                    log.info(Utils.NOTIFICATION_SERVICE_EXECUTED_SUCCESSFULLY);
                    break;

                case SYSTEM:
                    SystemNotifyRequest notifyRequest = new SystemNotifyRequest();

                    /* VALIDATE REQUEST*/
                    if (OPLUtils.isObjectNullOrEmpty(request.getFrom())) {
                        response.setMessage("from User Id can not be null");
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    /* REJECT NOTIFICATION ONCE SEND IN A DAY  */
                    templateIdsToCheck = NotificationUtils.getBasicConfigByKey(Utils.REJECT_SMS_ONCE_SENT_IN_A_DAY);
                    isSentOnce = isNotificationSent(NotificationType.SMS, templateIdsToCheck, request.getTo(), request.getMasterId());
                    if (isSentOnce) {
                        response.setMessage(Utils.SMS_REJECTED_CAUSE_ONCE_ALREADY_SENT_TODAY);
                        response.setStatus(HttpStatus.BAD_REQUEST.value());
                        return response;
                    }

                    notifyRequest.setToUserId(request.getTo());
                    notifyRequest.setFromUserId(request.getFrom());
                    notifyRequest.setLoanTypeId(request.getLoanTypeId());
                    notifyRequest.setUserOrgId(request.getUserOrgId());
                    notifyRequest.setMasterId(request.getMasterId());
                    notifyRequest.setFromName(notificationRequest.getFromName());
                    notifyRequest.setTemplate(request.getContentType());
                    notifyRequest.setSourceType(request.getSourceType());

                    /* GETTING VALUES FROM APPLICATION PROPERTY */
                    notifyRequest.setParameters(upendPropertiesInParam(request.getParameters(), NotificationType.SYSTEM.getTypeId().intValue()));

                    SystemNotifyResponse notifyResponse = systemNotifyService.sendSystemNotification(notifyRequest);
                    response.setMessage(notifyResponse.getMessage());
                    response.setStatus(notifyResponse.getStatus());
                    log.info(Utils.NOTIFICATION_SERVICE_EXECUTED_SUCCESSFULLY);
                    break;
                default:
                    break;
            }
        }
        return response;
    }
    /** GET COUNT OF SENT EMAIL OF SPECIFIC MASTER IDS FOR REJECTION  */
    private Boolean validateRejectEmail(String email) {
        Long count = notificationEmailRejectDumpRepository.countByEmailIdAndIsActiveTrue(email);
        return !OPLUtils.isObjectNullOrEmpty(count) && count > 0;
    }

    /** UPEND SUPPORT EMAIL AND MOBILE NUMBER TO PARAMETERS */
    private Map<String, Object> upendPropertiesInParam(Map<String, Object> parameters, int type) {
        if (OPLUtils.isObjectNullOrEmpty(parameters) || (!OPLUtils.isObjectNullOrEmpty(parameters) && parameters.isEmpty())) {
            parameters = new HashMap<>();
        }

        List<BasicConfigurationRequest> allBasicConfig = NotificationUtils.getAllBasicConfig();
        for (BasicConfigurationRequest basicConf : allBasicConfig) {
            parameters.put(basicConf.getPropName(), basicConf.getPropValue());
        }

        if (parameters.containsKey("orgId")) {
            Long orgId = Long.valueOf(parameters.get("orgId").toString());
            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                NotificationCustCareMaster careMaster = notificationCustCareMasterRepo.findByOrgId(orgId);
                if(!OPLUtils.isObjectNullOrEmpty(careMaster)) {
                    if (NotificationType.EMAIL.getTypeId().intValue() == type) {
                        parameters.put("bankContactNumber", careMaster.getCustCareNumber());
                        parameters.put("bankEmailId", careMaster.getCustCareEmailId());
                    }
                    parameters.put("bankName", careMaster.getOrgName().replace("&", "and"));
                }else {
                    parameters.put("bankContactNumber", " - ");
                    parameters.put("bankEmailId", " - ");
                    parameters.put("bankName", " - ");
                }
            }

        }


        return parameters;
    }

    /**
     * FIND ONCE EMAIL/SMS SEND TO THIS USER OR NOT
     */
    private boolean isNotificationSent(NotificationType type, String templateListStr, String[] to, Long masterId) {
        Date currentDate = new Date();
        boolean isSent = false;

        List<String> templateLIsFromAppProp = Arrays.asList(templateListStr.split(","));
        List<Long> templateIds = notificationTemplateRepository.getTemplateListBasedOnMasterId(masterId);
        for (String tem : templateLIsFromAppProp) {
            for (Long templateId : templateIds) {
                if (Long.valueOf(tem).equals(templateId)) {
                    for (String stTo : to) {
                        if (!OPLUtils.isObjectNullOrEmpty(stTo)) {
                            NotificationLogs noti = this.notificationLogsRepo.findFirstByNotificationTypeIdAndMasterIdAndToOrderByIdDesc(type.getTypeId(), masterId, stTo);
                            if (!OPLUtils.isObjectNullOrEmpty(noti)) {
                                long dayDiff = TimeUnit.DAYS.convert(currentDate.getTime() - noti.getCreatedDate().getTime(), TimeUnit.MILLISECONDS);
                                if (dayDiff == 0) {
                                    isSent = true;
                                }
                            }
                        }
                    }
                }
            }

        }
        return isSent;
    }
}