package com.opl.jns.notification.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_header_footer", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION)
public class NotificationHeaderFooter {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_header_footer_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_NOTIFICATION, name = "notification_header_footer_seq_gen", sequenceName = "notification_header_footer_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "template")
    private String template;

    @Column(name = "template_type")
    private String templateType;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "modified_date")
    private Timestamp modifiedDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "is_active")
    private String isActive;

}
