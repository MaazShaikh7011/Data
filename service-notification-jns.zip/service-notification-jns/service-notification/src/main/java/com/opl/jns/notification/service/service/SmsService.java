package com.opl.jns.notification.service.service;

import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface SmsService {

    public SMSResponse sendSMS(SMSRequest smsRequest);

}
