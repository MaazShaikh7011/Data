package com.opl.jns.notification.service.controller;

import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.notification.api.exception.NotificationException;
import com.opl.jns.notification.api.model.NotificationCommonRes;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.NotificationResponse;
import com.opl.jns.notification.api.model.systemNotification.SystemNotifyResponse;
import com.opl.jns.notification.service.service.NotificationValidatorService;
import com.opl.jns.notification.service.service.SystemNotifyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@RestController
@Slf4j
public class NotificationRestController {

    @Autowired
    private NotificationValidatorService notificationValidatorService;

    @Autowired
    private SystemNotifyService systemNotifyService;


    /** API FOR SEND ALL TYPE OF NOTIFICATION */
    @SkipInterceptor
    @PostMapping(value = "/send", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public NotificationResponse sendSimpleMail(@RequestBody NotificationRequest notificationRequest) throws NotificationException {
        if (!notificationRequest.getNotifications().isEmpty()) {
            log.info(" To [{}] ========== Type [{}] ========== MasterId [{}]", notificationRequest.getNotifications().getFirst().getTo()[0],notificationRequest.getNotifications().getFirst().getType().getName(),notificationRequest.getNotifications().getFirst().getMasterId());
            if(notificationRequest.getNotifications().getFirst().getContentAttachments() != null && !notificationRequest.getNotifications().getFirst().getContentAttachments().isEmpty()) {
            	log.info("Attachment Size ==== {}", null != notificationRequest.getNotifications().getFirst().getContentAttachments() ? notificationRequest.getNotifications().getFirst().getContentAttachments().size() : null);
            }
        }
        try {
            return notificationValidatorService.sendNotification(notificationRequest);
        } catch (Exception e) {
            log.error("Exception while sending notification : ", e);
            return new NotificationResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Notification not sent because " + e.getMessage(), false);
        }
    }


    /** API FOR FETCH ALL SYSTEM NOTIFICATION */
    @SkipInterceptor
    @GetMapping("/fetchSystemNotification/{toId}")
    public SystemNotifyResponse fetchSystemNotification(@PathVariable Long toId) throws NotificationException {
        try {
            return systemNotifyService.fetchAllSystemNotification(toId);
        } catch (Exception e) {
            log.error("Exception while fetching the system notification message : ", e);
            return new SystemNotifyResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Notification not sent cause " + e.getMessage());
        }
    }

    /** API FOR READ SYSTEM NOTIFICATION */
    @SkipInterceptor
    @GetMapping("/readSystemNotification/{notificationId}")
    public NotificationCommonRes readSystemNotification(@PathVariable("notificationId") Long toId) throws NotificationException {
        try {
            systemNotifyService.readSystemNotification(toId);
            return new NotificationCommonRes(HttpStatus.OK.value(), "read");
        } catch (Exception e) {
            log.error("Exception while reading the system notification message : ", e);
            return new NotificationCommonRes(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Notification not send cause of " + e.getMessage());
        }
    }

}