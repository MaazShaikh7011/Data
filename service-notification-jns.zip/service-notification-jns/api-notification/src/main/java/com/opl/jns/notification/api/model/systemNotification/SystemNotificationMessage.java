package com.opl.jns.notification.api.model.systemNotification;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 10/16/2023
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class SystemNotificationMessage {

    private Long id;
    private String message;
    private boolean isRead;


}
