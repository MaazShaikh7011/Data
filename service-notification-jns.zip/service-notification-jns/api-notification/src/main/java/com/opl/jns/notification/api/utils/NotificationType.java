package com.opl.jns.notification.api.utils;
/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
public enum NotificationType {

    /**
     * To Set notification Type to Email
     */
    EMAIL(1L, "EMAIL"),

    /**
     * To Set notification Type to SMS
     */
    SMS(2L, "SMS"),

    /**
     * To Set notification Type to System Notification
     */
    SYSTEM(3L, "SYSTEM");

    Long typeId;
    String name;

    NotificationType(Long typeId, String name) {
        this.typeId = typeId;
        this.name = name;
    }

    public static NotificationType fromId(Long v) {
        for (NotificationType c : NotificationType.values()) {
            if (c.typeId.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public Long getTypeId() {
        return this.typeId;
    }

    public String getName() {
        return this.name;
    }


}
