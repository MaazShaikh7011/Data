package com.opl.jns.notification.api.model.systemNotification;

import java.util.Map;

import com.opl.jns.notification.api.utils.ContentType;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SystemNotifyRequest {

    private String message;
    private String[] toUserId;
    private String fromName;

    private Map<String, Object> parameters;
    private ContentType template;
    private Long fromUserId;
    private Long masterId;
    private Long userOrgId;
    private Long relatedApplicationId;
    private Integer loanTypeId;

    private String templateName;

    private String systemNotificationTemplateInString;
    private Long sourceType;


}
