package com.opl.jns.notification.api.model;


import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.*;

/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
@Setter
@Getter
public class Notification implements Serializable {

    private static final long serialVersionUID = -9151646917155081519L;

    private NotificationType type;
    private String[] to;
    private String[] cc;
    private Long from;
    private ContentType contentType;
    private String content;
    private String title;
    private Object subject;
    private Long templateId;
    private Map<String, Object> parameters = new HashMap<String, Object>();
    private String fileName;
    private String fileFormat;
    private byte[] contentInBytes;
    private Long readSysNotifId;
    private Boolean readStatusSysNotif;
    private List<ContentAttachment> contentAttachments = new ArrayList<>();
    private String[] bcc;
    private String status;
    private Date createdDate;
    protected Long emailSubjectId;

    private Integer loanTypeId;
    private Long userOrgId;
    private Long masterId;
    private Long sourceType;
    private Integer sourceId;

    public Notification() {
        super();
    }

    public Notification(Long masterId, ContentType contentType, Long templateId, String[] to, NotificationType type, Long orgId, Long sourceType, Map<String, Object> parameters) {
        super();
        this.masterId = masterId;
        this.contentType = contentType;
        this.templateId = templateId;
        this.to = to;
        this.type = type;
        this.parameters = parameters;
        this.userOrgId = orgId;
        this.sourceType = sourceType;
    }

    public Notification(Long masterId, ContentType contentType, Long templateId, String[] to, NotificationType type, Map<String, Object> parameters, String[] cc, String[] bcc, List<ContentAttachment> contentAttachments) {
        super();
        this.masterId = masterId;
        this.contentType = contentType;
        this.templateId = templateId;
        this.to = to;
        this.type = type;
        this.parameters = parameters;
        if (cc != null) {
            this.cc = cc;
        } else {
            this.cc = null;
        }
        if (bcc != null) {
            this.bcc = bcc;
        } else {
            this.bcc = null;
        }
        this.contentAttachments = contentAttachments;
    }

    public Notification(Long masterId, ContentType contentType, Long templateId, String[] to, NotificationType type, Map<String, Object> parameters, String[] cc, String[] bcc) {
        super();
        this.type = type;
        this.to = to;
        this.contentType = contentType;
        this.templateId = templateId;
        this.parameters = parameters;
        if (cc != null) {
            this.cc = cc;
        } else {
            this.cc = null;
        }
        if (bcc != null) {
            this.bcc = bcc;
        } else {
            this.bcc = null;
        }
        this.masterId = masterId;
    }

    public Notification(Long masterId, ContentType contentType, Long templateId, String[] to, NotificationType type, Map<String, Object> parameter, Long fromId) {
        super();
        this.masterId = masterId;
        this.contentType = contentType;
        this.templateId = templateId;
        this.to = to;
        this.type = type;
        this.parameters = parameter;
        this.from = fromId;
    }


}
