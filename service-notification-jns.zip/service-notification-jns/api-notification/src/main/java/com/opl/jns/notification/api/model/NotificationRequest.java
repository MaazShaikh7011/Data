package com.opl.jns.notification.api.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest implements Serializable {

    private static final long serialVersionUID = 1571195060508109481L;
    private String clientRefId;
    private List<Notification> notifications = new ArrayList<>();
    private String fromName;

    public void addNotification(Notification notification) {
        this.notifications.add(notification);
    }


}
