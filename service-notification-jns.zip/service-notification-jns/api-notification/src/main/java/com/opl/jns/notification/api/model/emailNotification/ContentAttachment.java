package com.opl.jns.notification.api.model.emailNotification;

/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
public class ContentAttachment {

    private String fileName;

    private byte[] contentInByte;

    public ContentAttachment() {
        super();
    }

    public ContentAttachment(String fileName, byte[] contentInByte) {
        super();
        this.fileName = fileName;
        this.contentInByte = contentInByte;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getContentInByte() {
        return contentInByte;
    }

    public void setContentInByte(byte[] contentInByte) {
        this.contentInByte = contentInByte;
    }

}
