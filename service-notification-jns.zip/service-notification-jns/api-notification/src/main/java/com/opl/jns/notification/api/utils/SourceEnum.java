package com.opl.jns.notification.api.utils;
/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
public enum SourceEnum {
    OTHER_CHANNEL(1, "Enrolment through other channel"),
	JANSURAKSHA(2, "JanSuraksha Portal"),
	LED(3, "Legacy Data"),
	JANSURAKSHA_DIY(4, "JanSuraksha Portal DIY"),
	E_SHARUM(5, "E-SHARUM");

    private Integer id;
    private String value;

    private SourceEnum(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static SourceEnum fromId(Integer v) {
        for (SourceEnum c : SourceEnum.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        return null;
    }

    public static SourceEnum[] getAll() {
        return SourceEnum.values();
    }
}
