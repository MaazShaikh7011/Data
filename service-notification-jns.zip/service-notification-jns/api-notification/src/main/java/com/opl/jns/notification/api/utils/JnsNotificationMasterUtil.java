package com.opl.jns.notification.api.utils;
/**
 * @author Krunal Prajapati
 * @since 07-03-2023
 */
public class JnsNotificationMasterUtil {


    public static final Long EMAIL_CUST_ENROLLMENT_SUCESS = 1L;

    public static final Long SMS_CUST_ENROLLMENT_SUCESS_PMSBY = 2L;

    public static final Long EMAIL_CUST_CLAIM_REGISTRATION_SUCESS = 3L;

    public static final Long SMS_CUST_CLAIM_REGISTRATION_SUCESS_PMSBY = 4L;

    public static final Long EMAIL_CUST_CLAIM_SETTLEMENT_SUCESS = 5L;

    public static final Long SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMSBY = 6L;

    public static final Long EMAIL_CUST_BO_LOGIN_SUCESS = 7L;

    public static final Long SMS_CUST_CLAIM_REGISTRATION_SUCESS_PMJJBY = 8L;

    public static final Long EMAIL_CUST_OPT_OUT_SUCCESS = 9L;

    public static final Long EMAIL_CUST_NOMINEE_UPDATE = 10L;

    public static final Long BANK_COUNTS_REPORTS = 11L;

    public static final Long SMS_CUST_FORGOT_USERNAME_OTP = 12L;

    public static final Long SMS_CUST_FORGOT_USERNAME_SEND = 13L;

//    public static final Long REGISTRATION_OTP = 12L;

//    public static final Long LOGIN_OTP = 13L;

    public static final Long FORGOT_PASSWORD_OTP = 14L;
    public static final Long ENROLLMENT_CONSENT_OTP = 15L;
    public static final Long UPDATE_EMAIL_OTP = 16L;
    public static final Long UPDATE_PASSWORD_OTP = 17L;
    public static final Long REGISTRATION_OTP_SMS = 18L;
    public static final Long LOGIN_OTP_SMS = 19L;
    
    public static final Long SMS_CUST_ENROLLMENT_CONSENT_DIY_OTP = 20L;
    
    public static final Long OPT_OUT_OTP = 21L;
    public static final Long OPT_OUT_OTP_SMS = 22L;
    
    public static final Long SMS_CUST_ENROLLMENT_SUCESS_PMJJBY = 23L;
    public static final Long SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMJJBY = 24L;
    public static final Long FORGOT_PASSWORD_SMS = 25L;


    // Grievance OTP master
    public static final Long SMS_MOBILE_VERIFICATION_GRIEVANCE = 26L;
    public static final Long SMS_GRIEVANCE_REGISTRATION = 27L;
    public static final Long SMS_GRIEVANCE_RESOLUTION = 28L;
}
