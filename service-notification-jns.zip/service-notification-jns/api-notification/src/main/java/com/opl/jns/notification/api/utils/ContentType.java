package com.opl.jns.notification.api.utils;
/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
public enum ContentType {

    CONTENT, TEMPLATE

}
