package com.opl.jns.notification.api.model.systemNotification;

import java.util.List;

import com.opl.jns.notification.api.model.NotificationCommonRes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class SystemNotifyResponse extends NotificationCommonRes {

    private int allCount;
    private int unReadCount;
    private List<SystemNotificationMessage> messages;

    public SystemNotifyResponse(Integer status, String message) {
        this.setStatus(status);
        this.setMessage(message);
    }

}
