package com.opl.jns.notification.client;

import java.util.List;
import java.util.Map;

import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.NotificationResponse;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Maaz Shaikh
 * @since 07-03-2023
 */
@Slf4j
public class NotificationClient {
    private static final String SEND_EMAIL_NOTIFICATION = "/send";

    private final String notificationBaseUrl;
    private final RestTemplate restTemplate;

    public NotificationClient(String notificationBaseUrl) {
        this.notificationBaseUrl = notificationBaseUrl;
        restTemplate = new RestTemplate();

    }

    public static void setClient(HttpHeaders headers) {
        headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.add("Accept", "application/json");
    }

    @Async
    public void send(NotificationRequest request){
        String url = notificationBaseUrl.concat(SEND_EMAIL_NOTIFICATION);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            setClient(headers);
            HttpEntity<NotificationRequest> entity = new HttpEntity<>(request, headers);
            restTemplate.exchange(url, HttpMethod.POST, entity, NotificationResponse.class).getBody();
        } catch (Exception e) {
            log.error("Notification Service Error", e);
        }
    }

    public NotificationResponse sendNotification(NotificationRequest request){
        String url = notificationBaseUrl.concat(SEND_EMAIL_NOTIFICATION);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            setClient(headers);
            HttpEntity<NotificationRequest> entity = new HttpEntity<>(request, headers);
           return restTemplate.exchange(url, HttpMethod.POST, entity, NotificationResponse.class).getBody();
        } catch (Exception e) {
            log.error("Notification Service Error", e);
        }
        return null;
    }



    /** PREPARE REQUEST FOR SMS OR EMAIL ONLY*/
    public static Notification prepareRequestForSmsOrEmail(String[] to, Map<String, Object> parameters, Long masterId, List<ContentAttachment> contentAttachments, NotificationType type, Long orgId, Long sourceType) {
    	Notification notification = new Notification(masterId,ContentType.TEMPLATE,null,to,type,orgId,sourceType,parameters);
    	if(!OPLUtils.isListNullOrEmpty(contentAttachments)) {
    		notification.setContentAttachments(contentAttachments);
    	}
        return notification;
    }


}