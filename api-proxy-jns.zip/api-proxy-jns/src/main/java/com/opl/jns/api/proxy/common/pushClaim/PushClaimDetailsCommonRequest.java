package com.opl.jns.api.proxy.common.pushClaim;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.utils.constant.CommonConstant;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PushClaimDetailsCommonRequest extends CommonRequest {

	@Hidden
	private Long userId;

	/** SBI USE ONLY **/
	@Hidden
	@JsonProperty("SOURCE_ID")
	private String sourceId;

	@NotNull
	private Long claimReferenceId;

	@NotNull
	@Size(min = 1, max = 100)
	private String masterPolicyNumber;

	@NotNull
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMJJBY|PMSBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid schemeName.")
	private String schemeName;

	@NotNull
	@Size(min = 3, max = 17)
	private String customerAccountNumber;

	@NotNull
	@Size(min = 2, max = 50)
	private String customerBankname;

	@NotNull
	@Size(min = 11, max = 11)
	private String customerIFSC;

	@NotNull
	@Size(min = 1, max = 300)
	private String accountHolderName;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "dob", example = "yyyy-MM-dd", required = true)
	private LocalDate dob;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid gender.")
	private String gender;

	@NotNull
	@Size(min = 2, max = 17)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited","136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Pattern(regexp = "556|132|115|190|146|142|101|143|58|136|111|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
	private String insurerCode;

	@NotNull
	@Size(min = 2, max = 30)
	@Schema(allowableValues = CommonConstant.BANK_SHORT_CODE_NAME)
	@Pattern(regexp = CommonConstant.BANK_SHORT_CODE, flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
	public String bankCode;

	@NotNull
	@Size(min = 2, max = 30)
	private String branchCode;

	@NotNull
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String bankBranchEmailId;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String emailID;

	@NotNull
	@Size(min = 2, max = 500)
	private String addressline1;

	@Size(min = 2, max = 500)
	private String addressline2;

	@NotNull
	@Schema(example = "382350 Note:@Size(min = 6, max = 6) ")	
	private String pincode;

	@NotNull
	@Size(min = 2, max = 200)
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	private String state;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	private String kycID1number;

	@JsonProperty("pan")
	@Schema(allowableValues = { "YES", "NO"})
	private String pan;

	@Size(min = 10, max = 10)
	private String panNumber;

	@JsonProperty("aadhaar")
	@Schema(allowableValues = { "YES", "NO"})
	private String aadhaar;

	@Size(min = 12, max = 12)
	private String aadhaarNumber;

	@JsonProperty("ckyc")
	@Schema(allowableValues = { "YES", "NO"})
	private String ckyc;

	@Size(min = 14, max = 15)
	private String ckycNumber;

	@NotNull
	@Size(min = 1, max = 300)
	private String nomineeName;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = "yyyy-MM-dd", required = true)
	private LocalDate nomineeDateOfBirth;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid nomineeGender.")
	private String nomineeGender;

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String nomineeMobileNumber;

	@NotNull
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Nominee Relationship. Please check relationshipOfNominee.")
	@Size(min = 1, max = 50)
	private String relationshipOfNominee;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String nomineeEmailId;

	@NotNull
	@Size(min = 2, max = 500)
	private String addressofNominee;

	@Size(min = 1, max = 300)
	private String correctNomineeName;

	@Size(min = 1, max = 300)
	private String nameofGuardian;

	@Size(min = 2, max = 500)
	private String addressOfGuardian;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Size(min = 1, max = 50)
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Guardian Relationship. Please check relationShipOfGuardian.")
	private String relationShipOfGuardian;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String guardianEmailId;

	@Size(min = 1, max = 300)
	private String claimantName;

	@Size(min = 2, max = 500)
	private String claimantAddress;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "claimantDateOfBirth", example = "yyyy-MM-dd", required = true)
	private LocalDate claimantDateOfBirth;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Claimant Relationship. Please check relationshipOfClaimant.")
	private String relationshipOfClaimant;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String claimantMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String claimantEmailId;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "claimantKYC1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String claimantKYC1;

	@NotNull
	@Size(min = 1, max = 100)
	private String claimantKYCNumber1;

	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Size(min = 1, max = 25)
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "claimantKYC2 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String claimantKYC2;

	@Size(min = 1, max = 100)
	private String claimantKycNumber2;

	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid claimantGender.")
	private String claimantGender;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "dateOfAccident", example = "yyyy-MM-dd", required = true)
	private LocalDate dateOfAccident;

	@NotNull
	@Schema(example = "HH:mm:ss")
	private String timeOfAccident;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" })
	@Pattern(regexp = "Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid day of accident Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday")
	private String dayOfAccident;

	@NotNull
	private String placeOfOccurence;

	@NotNull
	@Size(min = 1, max = 100)
	@Schema(allowableValues = { "Death", "Disability" })
	@Pattern(regexp = "Disability|Death", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid natureOfAccident: Disability OR Death")
	private String natureOfAccident;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@ApiModelProperty(notes = "dateOfDeath", example = "yyyy-MM-dd HH:mm:ss", required = true)
	private LocalDateTime dateOfDeath;

	@Size(min = 1, max = 100)
	@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental death within 30 days of lien period",
			"Suicide" })
	private String causeOfDeath;

	@NotNull
	@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental", "Suicide" })
	@Size(min = 1, max = 100)
	private String causeOfDeathDisability;

	@NotNull
	@Schema(allowableValues = { "Partial permanent", "Total permanent" })
	@Size(min = 1, max = 100)
	@Pattern(regexp = "Partial permanent|Total permanent", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid typeOfDisability :Partial permanent OR Total permanent")
	private String typeOfDisability;

	@NotNull
	@Size(min = 3, max = 17)
	private String claimantBankAccountNumber;

	@NotNull
	@Size(min = 2, max = 50)
	private String claimantBankName;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message = "Enter valid IFSc")
	private String claimantBranchIFSC;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Schema(example = "2024-01-01 - DataType:string($date)")
	@ApiModelProperty(notes = "premDebitDate", example = "yyyy-MM-dd", required = true)
	private LocalDate premDebitDate;

	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Schema(example = "2024-01-01 - DataType:string($date)")
	@ApiModelProperty(notes = "premRemitDate", example = "yyyy-MM-dd", required = true)
	private LocalDate premRemitDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Schema(example = "2024-01-01 - DataType:string($date)")
	@ApiModelProperty(notes = "dateOfLodgingClaim", example = "yyyy-MM-dd", required = true)
	private LocalDate dateOfLodgingClaim;

//	@NotNull
	public List<Document> documents;

	public PushClaimDetailsCommonRequest clone() throws CloneNotSupportedException {
		return (PushClaimDetailsCommonRequest) super.clone();
	}

}
