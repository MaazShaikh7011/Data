package com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank;

import com.opl.jns.api.proxy.common.APIResponseV3;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PushClaimStatustoBankResV3 extends APIResponseV3 {

}
