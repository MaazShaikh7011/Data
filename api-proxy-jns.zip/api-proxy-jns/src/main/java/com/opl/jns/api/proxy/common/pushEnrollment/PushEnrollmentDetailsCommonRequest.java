package com.opl.jns.api.proxy.common.pushEnrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.utils.constant.CommonConstant;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class PushEnrollmentDetailsCommonRequest extends CommonRequest implements Serializable, Cloneable {

	private static final long serialVersionUID = 123434657577684L;
	
	@Hidden
	private String referenceId;

	@NotNull
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
	@Schema(example = "2023")
	private String policyYear;

	@Size(min = 2, max = 17)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited","136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Pattern(regexp = "556|132|115|190|146|142|101|143|58|136|111|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
	private String insurerCode;

	@NotNull
	@Size(min = 1, max = 35)
	private String transactionUTR;

	@NotNull
	@Schema(example = "2024-01-01 05:06:00 - DataType:string($date-time)")
	private String transactionTimeStamp;

	@NotNull
	private Double transactionAmount;

	@NotNull
	@Schema(example = "2024-01-01 05:06:00 - DataType:string($date-time)")
	private String firstEnrollmentDate;

	@NotNull
	@Size(min = 2, max = 50)
	@Schema(allowableValues = { "Other Channel", "Assisted" })
	@Pattern(regexp = "Other Channel|Assisted", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid source.")
	private String source;

	@NotNull
	@Size(min = 2, max = 50)
	@Schema(allowableValues = { "DIY", "Assisted" })
	@Pattern(regexp = "DIY|Assisted|Other Channel", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid mode.")
	private String mode;

	@NotNull
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "N=New Enrollment" })
	@Pattern(regexp = "N", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid transactionType.")
	private String transactionType;

	@NotNull
	@Size(min = 1, max = 100)
	private String masterPolicyNumber;

	@NotNull
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMJJBY|PMSBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid schemeName.")
	private String schemeName;

	@NotNull
	@Size(min = 2, max = 30)
	private String branchCode;

	@NotNull
	@Size(min = 2, max = 30)
	@Schema(allowableValues = CommonConstant.BANK_SHORT_CODE_NAME)
	@Pattern(regexp = CommonConstant.BANK_SHORT_CODE, flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
	public String bankCode;

	@NotNull
	@Schema(allowableValues = { "Yes" })
	@Pattern(regexp = "Yes", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid consentForAutoDebit.")
	private String consentForAutoDebit;

	@NotNull
	private String userId1;

	private String userId2;

	@NotNull
	@Schema(allowableValues = { "BC", "ATM", "MB", "EB", "SMS", "WHATSAPP", "BRANCH", "TAB", "CSP", "WEBSITE",
			"MISSCALL", "DBU", "Branch Assisted", "From Legacy", "DIY Web", "DIY Mobile" })
	@Size(min = 1, max = 50)
	@Pattern(regexp = "BC|ATM|MB|EB|SMS|WHATSAPP|BRANCH|TAB|CSP|WEBSITE|MISSCALL|DBU|Branch Assisted|From Legacy|DIY Web|DIY Mobile", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Channel.")
	private String channelId;

	@NotNull
	@Size(min = 5, max = 50)
	@Schema(allowableValues = { "Rural", "Urban" })
	@Pattern(regexp = "Rural|Urban", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid ruralUrban.")
	private String ruralUrban;

	@NotNull
	@Size(min = 3, max = 17)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	@NotNull
	@Size(min = 3, max = 17)
	private String cif;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message = "Enter valid IFSc")
	private String customerIFSC;

	@NotNull
	@Size(min = 1, max = 300)
	private String accountHolderName;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid gender.")
	private String gender;

	@NotNull
	@Size(min = 1, max = 150)
	private String fatherHusbandName;

	@NotNull
	@Schema(example = "2024-01-01 - DataType:string($date)")
	private String dob;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber;// 2 time found

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	private String addressLine1;

	@Size(min = 2, max = 500)
	private String addressLine2;

	@NotNull
	@Size(min = 2, max = 200)
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	private String state;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6, message = "Invalid Pincode. Value must be of 6-digits.")
//	@Min(value = 100000, message = "Invalid Pincode. Value must be of 6-digits.")
//	@Max(value = 999999, message = "Invalid Pincode. Value must be of 6-digits.")
	private String pincode;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	private String kycID1Number;

	@JsonProperty("pan")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 2, max = 3)
	private String pan;

	@Size(min = 10, max = 10)
	private String panNumber;

	@JsonProperty("aadhaar")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 2, max = 3)
	private String aadhaar;

	@Size(min = 12, max = 12)
	private String aadhaarNumber;

	@JsonProperty("disabilityStatus")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 1, max = 3)
	private String disabilityStatus;

	@Size(min = 2, max = 200)
	private String disabilityDetails;

	private String applicantOccupation;

	@NotNull
	@Size(min = 1, max = 300)
	private String nomineeName;

	@NotNull
	@Schema(example = "2024-01-01 - DataType:string($date)")
	private String nomineeDateOfBirth;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String nomineeMobileNumber;

	@NotNull
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Nominee Relationship. Please check relationshipOfNominee.")
	private String relationshipOfNominee;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String nomineeEmailId;

	@NotNull
	@Size(min = 2, max = 500)
	private String addressofNominee;

	@Size(min = 1, max = 300)
	private String nameofGuardian;

	@Size(min = 2, max = 500)
	private String addressOfGuardian;

	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Guardian Relationship. Please check relationShipOfGuardian.")
	private String relationShipOfGuardian;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String guardianEmailId;

	private CoiDocumentDetailsProxy COI;
	
	private Boolean isFromScheduler;

	public PushEnrollmentDetailsCommonRequest clone() throws CloneNotSupportedException {
		return (PushEnrollmentDetailsCommonRequest) super.clone();
	}

}
