package com.opl.jns.api.proxy.insurer.v1.Webhook.UpdateClaimStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimStatusWebhook implements Serializable {
	
	private final static long serialVersionUID = -3063362276402351168L;
	
	private Long orgId;
	private Long applicationId;
	private Long userId;

    @NotNull
    @Min(value = 1, message = "can not be 0")
    public String claimId;

    @NotNull
    @Min(value = 1,message = "can not be 0")
    public Long claimReferenceId;

    @NotNull
    @NotEmpty
    @Size(min = 21,max = 32)
    public String urn;

    @NotNull
    @Min(6)
    @Max(6)
    @Schema(allowableValues ={"6"},description = "6 - Received from Bank")
    public Integer claimStatus;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String remarks;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String message;
    
	@NotNull
	private String token;

    @Valid
    @NotNull
    public List<Document> documents;

	public ClaimStatusWebhook(String claimId, Long claimReferenceId, @NotEmpty String urn, Integer claimStatus) {
		super();
		this.claimId = claimId;
		this.claimReferenceId=claimReferenceId;
		this.urn = urn;
		this.claimStatus = claimStatus;
	}
    
    
    

}