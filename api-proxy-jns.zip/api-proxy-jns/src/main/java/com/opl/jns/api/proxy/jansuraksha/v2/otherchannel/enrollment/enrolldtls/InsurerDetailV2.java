package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.InsurerDetailV1;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class InsurerDetailV2 extends InsurerDetailV1 {

	private final static long serialVersionUID = 5330824133439128615L;

}
