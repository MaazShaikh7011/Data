package com.opl.jns.api.proxy.insurer.PushClaim;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.ToString;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import java.io.Serializable;

@Data
@ToString
@JsonPropertyOrder({ "message", "status", "success", "flag" ,"timeStamp"})
public class PushClaimDetailsResponse extends APIResponseV3 implements Serializable {
	private static final long serialVersionUID = 1L;

}
