package com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.io.Serializable;

@Data
public class DocumentDetailsProxy1_1 extends DocumentDetailsProxy implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @NotNull
    private Long documentId;

    private String message;

    private Boolean success;
}
