package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor
public class ClaimDocumentResProxy extends APIResponseV3 {

    public ClaimDocumentResProxy(Integer status, String message, Boolean success, String token, LocalDateTime timeStamp) {
        super(status, message, success,token,timeStamp);
    }

    public ClaimDocumentResProxy(Integer status, String message, Boolean success) {
        super(status, message,success);

    }


}
