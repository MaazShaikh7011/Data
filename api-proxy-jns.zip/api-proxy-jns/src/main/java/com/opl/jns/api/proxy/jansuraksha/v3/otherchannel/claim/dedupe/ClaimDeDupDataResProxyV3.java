package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.io.Serializable;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString
public class ClaimDeDupDataResProxyV3 implements Serializable {

	private final static long serialVersionUID = -2203711281033421811L;

	@NotNull
	@Schema(allowableValues = { "True", "False" })
	public Boolean dedupeCheck;

	public ClaimDedupMatchWithResProxyV3 isMatchWith;

	
	
	

}
