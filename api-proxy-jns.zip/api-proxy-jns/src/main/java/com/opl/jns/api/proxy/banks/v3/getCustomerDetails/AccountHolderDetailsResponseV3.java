package com.opl.jns.api.proxy.banks.v3.getCustomerDetails;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.AccountHolderDetailsResponseV2;
import com.opl.jns.api.proxy.utils.APIUtils;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountHolderDetailsResponseV3 extends AccountHolderDetailsResponseV2 {
	
	@Hidden
	@JsonProperty("firstName")
	private String firstName;

	@Hidden
	@JsonProperty("middleName")
	private String middleName;
	
	@Hidden
	@JsonProperty("lastName")
	private String lastName;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("dob")
	@ApiModelProperty(notes = "dob", example = APIUtils.YYYY_MM_DD, required = true)
	private LocalDate dob;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "Invalid Email format. Email ID must be between 5 to 255 alphanumeric characters.")
	@JsonProperty("emailId")
	private String emailId;

	@JsonProperty("applicantOccupation")
	private String applicantOccupation;

	@Size(min = 1, max = 300, message = "Invalid nomineeName. Enter valid nomineeName.")
	@JsonProperty("nomineeName")
	private String nomineeName;
	
	@Hidden
	@JsonProperty("nomineeFirstName")
	private String nomineeFirstName;

	@Hidden
	@JsonProperty("nomineeMiddleName")
	private String nomineeMiddleName;

	@Hidden
	@JsonProperty("nomineeLastName")
	private String nomineeLastName;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = APIUtils.YYYY_MM_DD, required = true)
	@Schema(example = "13/06/2000")
	@JsonProperty("nomineeDateOfBirth")
	private LocalDate nomineeDateOfBirth;
	
	@Hidden
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationOfNominee")
	private String relationOfNominee;
	
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipOfNominee")
	private String relationshipOfNominee;
	
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;
	
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("nomineeEmailId")
	private String nomineeEmailId;
	
	@Size(min = 2,max = 500)
	@JsonProperty("addressofNominee")
	private String addressofNominee;

	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipOfGuardian")
	private String relationshipOfGuardian;
	
	@Hidden
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;

	@Size(min = 1, max = 50)
	@JsonProperty("bcReferralId")
	private String bcReferralId;

	@Hidden
	@JsonProperty("consentForAutoDebit")
	private String consentForAutoDebit;

	@Schema(allowableValues ={"Yes"})
	@Pattern(regexp = "Yes", flags = Pattern.Flag.CASE_INSENSITIVE, message = "consentForAutoDebit must be : Yes")
	@JsonProperty("consentForautodebit")
	private String consentForautodebit;
	
	@Hidden
	@JsonProperty("cityLGDCode")
	private Long cityLGDCode;

	@Hidden
	@JsonProperty("districtLGDCode")
	private Long districtLGDCode;

	@Hidden
	@JsonProperty("stateLGDCode")
	private Long stateLGDCode;
	
	@Hidden
	@JsonProperty("nomineeAddressLine1")
	private String nomineeAddressLine1;

	@Hidden
	@JsonProperty("nomineeAddressLine2")
	private String nomineeAddressLine2;

	@Hidden
	@JsonProperty("nomineePincode")
	private Integer nomineePincode;

	@Hidden
	@JsonProperty("nomineeCity")
	private String nomineeCity;

	@Hidden
	@JsonProperty("nomineeCityLGDCode")
	private Long nomineeCityLGDCode;

	@Hidden
	@JsonProperty("nomineeDistrict")
	private String nomineeDistrict;

	@Hidden
	@JsonProperty("nomineeDistrictLGDCode")
	private Long nomineeDistrictLGDCode;

	@Hidden
	@JsonProperty("nomineeState")
	private String nomineeState;

	@Hidden
	@JsonProperty("nomineeStateLGDCode")
	private Long nomineeStateLGDCode;
	
	@Hidden
	@JsonProperty("kycID2")
	private String kycID2;

	@Hidden
	@JsonProperty("kycID2number")
	private String kycID2number;
	
	@Hidden
	@JsonProperty("emailAddress")
	private String emailAddress;
	
	@Hidden
	@JsonProperty("ckyc")
	private String ckyc;

	@Hidden
	@JsonProperty("ckycNumber")
	private String ckycNumber;
	
	@Hidden
	@JsonProperty("nomineeEmailAddress")
	private String nomineeEmailAddress;
	
	@Hidden
	@JsonProperty("ruralUrban")
	private String ruralUrban;
	
	@Hidden
	@JsonProperty("nomineemobileNumber")
	private String nomineemobileNumber;
	
}
