package com.opl.jns.api.proxy.banks.v2.premiumDeduction;

import java.time.LocalDateTime;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.utils.APIUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
@JsonPropertyOrder({ "status", "message", "flag", "debitStatus","transactionUTR", "transactionTimeSTamp", "transactionTimeSTamp",
		"premiumAmount", "transactionAmount", "comment" })
public class PremiumDeductionResponseV2 extends APIResponseV2 {

	@NotNull(message = "Transaction UTR of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 35, message = "Invalid Transaction UTR. Value must be between 1 to 35 alphanumeric characters.")
	@JsonProperty("transactionUTR")
	private String transactionUTR;

	@NotNull(message = "transactionTimeStamp of the selected A/C holder is not found in the Bank CBS.")
	@Schema(example = "13/06/2023 05:06:00")
	@JsonProperty("transactionTimeStamp")
	private String transactionTimeStamp;

	@NotNull(message = "transactionAmount of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("transactionAmount")
	private String transactionAmount;

	@Size(min = 0, max = 255)
	@JsonProperty("comment")
	private String comment;
	
	@Hidden
	@JsonProperty("token")
	private String token;
	
	@NotNull
	@Schema(allowableValues ={"true","false"})
	@JsonProperty("flag")
	private Boolean flag;
	
	@Hidden
	@JsonProperty("timestamp")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timestamp;
	
	@Hidden
	@JsonProperty("success")
	private Boolean success;
	
	public PremiumDeductionResponseV2() {
		super();
	}

	public PremiumDeductionResponseV2(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
