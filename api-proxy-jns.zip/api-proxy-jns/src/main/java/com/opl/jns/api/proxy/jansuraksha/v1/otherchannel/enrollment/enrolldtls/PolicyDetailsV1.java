package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PolicyDetailsV1 implements Serializable {

	private final static long serialVersionUID = -4672372169318974444L;

	@Size(min = 1, max = 35)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_PATTERN, message = "Enter valid transactionUTR")
	public String transactionUTR;

	@Schema(example = "2023-05-05 16:12:10")
	public String transactionTimeStamp;

	public Long transactionAmount;

	@Size(min = 1, max = 100)
	public String masterPolicyNumber;

	public String insurerCode;

	@Schema(example = "2023-05-05 16:12:10")
	public String dateOfEnrollment;
}