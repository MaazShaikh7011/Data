package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.common.APIResponseV3;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "message", "status", "success", "timeStamp", "token", "data" })
public class ClaimDetailsResProxyV3 extends APIResponseV3 implements Serializable {

	private static final long serialVersionUID = -3112185730517060959L;

	@NotNull
	private ClaimDetailDataProxyV3 data;

	public ClaimDetailsResProxyV3() {
		super();
	}

	public ClaimDetailsResProxyV3(int status,String message, Boolean success) {
		super(status,message, success);
	}

	public ClaimDetailsResProxyV3(String message, ClaimDetailDataProxyV3 data, int status) {
		this.setMessage(message);
		this.data = data;
		this.setStatus(status);

	}

	public ClaimDetailsResProxyV3(String message, ClaimDetailDataProxyV3 claimDeDupProxy, int status, Boolean success) {
		super(status,message, success,null);
		this.data = claimDeDupProxy;
	}
}