package com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author - Maaz Shaikh
 * @Date - 3/4/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimResponse extends CommonResponse {
    private ClaimProxy data;
}
