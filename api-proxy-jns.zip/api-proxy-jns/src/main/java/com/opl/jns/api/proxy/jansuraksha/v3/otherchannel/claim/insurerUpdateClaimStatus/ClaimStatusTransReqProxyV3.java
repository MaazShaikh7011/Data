package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClaimStatusTransReqProxyV3 implements Serializable {

	private final static long serialVersionUID = 1175522787349167241L;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "transactionTimeStamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime transactionTimeStamp;

	public Double transactionAmount;

	@Size(min = 1, max = 35)
	public String transactionUTR;
//

}