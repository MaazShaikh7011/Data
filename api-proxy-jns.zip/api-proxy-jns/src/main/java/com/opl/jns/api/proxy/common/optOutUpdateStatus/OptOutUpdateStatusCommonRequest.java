package com.opl.jns.api.proxy.common.optOutUpdateStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class OptOutUpdateStatusCommonRequest extends CommonRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	private LocalDateTime effectiveDate;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	private LocalDateTime requestDate;

	public OptOutUpdateStatusCommonRequest clone() throws CloneNotSupportedException {
		return (OptOutUpdateStatusCommonRequest)super.clone();
	}
}
