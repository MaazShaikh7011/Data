package com.opl.jns.api.proxy.jansuraksha.v1.others;

public class Test {

}
