package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EnrollmentReqProxyV3 extends RegistryReqProxy {

	private final static long serialVersionUID = -4357839815853867628L;

	@Valid
	@NotNull
	public CustomerDetailsV3 customerDetails;

	@Valid
	@NotNull
	public KycDetailsV3 kycDetails;

	@Valid
	@NotNull
	public NomineeDetailsV3 nomineeDetails;

	public GuardianDetailsV3 guardianDetails;

	@Valid
	@NotNull
	public OtherDetailsV3 otherDetails;

}