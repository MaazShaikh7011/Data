package com.opl.jns.api.proxy.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class APIEncryptResponse implements Serializable {

	private static final long serialVersionUID = 1622417197852116828L;

	@JsonProperty("meta-data")
	@JsonAlias({"metadata"})
	private String metadata;

}
