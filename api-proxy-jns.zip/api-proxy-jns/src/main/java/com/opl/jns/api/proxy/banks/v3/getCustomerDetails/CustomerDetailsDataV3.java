package com.opl.jns.api.proxy.banks.v3.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerDetailsDataV3 extends APIResponseV3 {

	@Valid
	@JsonProperty("accountHolderDetails")
	private AccountHolderDetailsResponseV3 accountHolderDetails;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;
	
	public CustomerDetailsDataV3() {
		super();
	}

	public CustomerDetailsDataV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
