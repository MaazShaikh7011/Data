package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.statusupdate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimStatusReqProxyV2 implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	@Min(1)
	private Long claimReferenceId;

	@NotNull
	@NotEmpty
	@Size(min = 21, max = 32)
	private String urn;

	@NotNull
	@NotEmpty
	@Size(min = 1, max = 100)
	private String claimId;

	@NotNull
	@Min(8)
	@Max(11)
	@Schema(allowableValues = { "11", "7", "8",
			"10" }, description = "11 - In Process,7 - Query,8 - Claim Repudiated ,10 - Claim Approved")
	private int claimStatus;

	private String insurerStatus;

	private String reason;

	private ClaimTransProxyV2 transactionDetails;
}
