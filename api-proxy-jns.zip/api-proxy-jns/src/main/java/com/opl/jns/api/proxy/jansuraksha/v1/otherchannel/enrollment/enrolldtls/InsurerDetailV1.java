package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.opl.jns.utils.common.PatternUtils;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurerDetailV1 implements Serializable {

	private final static long serialVersionUID = 5330820133439128615L;
	public String year;
	public String code;

//		@Size(min = 3, max = 17)
//	    public String accountNumber;
	//
	//
//		@Size(min = 11, max = 11)
//		@Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message="Enter valid IFSc")
//	    public String ifsc;
	@Size(min = 1, max = 100)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_PATTERN, message = "Enter valid masterPolicyNumber")
	public String masterPolicyNumber;

}