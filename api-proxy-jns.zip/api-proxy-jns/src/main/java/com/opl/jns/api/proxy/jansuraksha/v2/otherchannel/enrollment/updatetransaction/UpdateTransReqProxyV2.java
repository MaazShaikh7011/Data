package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UpdateTransReqProxyV2 extends UpdateTransReqProxyV1 {

	private final static long serialVersionUID = 1175522786349167241L;
	
	@NotNull
	@Schema(example = "2023-05-05 16:12:10")
	public String transactionTimeStamp;
	
	@NotNull
	@Schema(allowableValues = { "1", "2" }, description = "1:New Enrolment,2:Renewal")
	@Pattern(regexp = "1|2", flags = Pattern.Flag.CASE_INSENSITIVE, message = "TransactionType must be : 1:New Enrolment or 2:Renewal")
	public String transactionType;
	
	@NotNull
	public String insurerCode;
	
	public String insurerIFSC;

	public String insurerAccountNumber;
	
	@Hidden
	@JsonProperty("token")
	private String token;

}
