package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.*;

import java.io.Serial;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class ClaimDeDupResProxyV3 extends APIResponseV3 {

	@Serial
	private static final long serialVersionUID = 639396976679078097L;

	private ClaimDeDupDataResProxyV3 data;


	public ClaimDeDupResProxyV3(String message, Integer status, Boolean success,String token, LocalDateTime timeStamp,ClaimDeDupDataResProxyV3 data) {
		super(status,message,success,token,timeStamp);
		this.data = data;
	}

	public ClaimDeDupResProxyV3(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}

	public ClaimDeDupResProxyV3(String message, ClaimDeDupDataResProxyV3 data, Integer status, Boolean success) {
		super(status,message,success);
		this.data = data;
	}
	public ClaimDeDupResProxyV3(Integer status, String message, Boolean success, String token) {
		super(status,message,success,token);
	}

}