package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateStatusReqProxyV3 extends RegistryReqProxy {

	private final static long serialVersionUID = 1175522787349167251L;
	
	@NotNull
	@Size(min = 3, max = 17)
	private String accountNumber;
	
	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate dob;
	
	@NotNull
	@Size(min = 3, max = 17)
	private String cif;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;
	
	@NotNull
	@Schema(allowableValues = { "6", "7", "8","9" }, 
	description = "6:Opt-Out,7:Account Inactive,8:Insufficient Balance,9:Account Holder Deceased")
	public Integer accountStatus;

	@Size(min = 0, max = 255)
	public String reason;

	@NotNull
	public String token;

}
