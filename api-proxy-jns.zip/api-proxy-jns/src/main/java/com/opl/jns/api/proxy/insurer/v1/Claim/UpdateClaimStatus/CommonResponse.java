package com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus;

import com.opl.jns.api.proxy.common.APIResponseV1;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class CommonResponse extends APIResponseV1 implements Serializable {

    private static final long serialVersionUID = 1L;

    private Object data;


    public CommonResponse() {

    }

    public CommonResponse(String message, Integer status) {
        super();
        this.setMessage(message);
        this.setStatus(status);
    }

    public CommonResponse(String message, Object data, Integer status) {
        super();
        this.data = data;
        this.setMessage(message);
        this.setStatus(status);
    }

    public CommonResponse(String message, Object data, Integer status, Boolean success) {
        super();
        this.setMessage(message);
        this.data = data;
        this.setStatus(status);
        this.setSuccess(success);
    }

    public CommonResponse(String message, Integer status, Boolean success) {
        super();
        this.setMessage(message);
        this.setStatus(status);
        this.setSuccess(success);
    }

}
