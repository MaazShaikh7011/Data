package com.opl.jns.api.proxy.banks.v3.pushClaim;

import com.opl.jns.api.proxy.common.pushClaim.PushClaimDetailsCommonResponse;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PushClaimDetailsResponseV3 extends PushClaimDetailsCommonResponse {

}