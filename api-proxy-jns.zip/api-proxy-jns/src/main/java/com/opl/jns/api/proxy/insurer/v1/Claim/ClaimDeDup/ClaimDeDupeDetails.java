package com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup;


import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDeDupeDetails implements Serializable {

	@NotNull
    @Size(min = 21,max = 32)
    public String urn;

	@NotNull
	@ApiModelProperty(notes = "intimationDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    public String intimationDate;

    @NotNull
    @Schema(allowableValues ={"1","2"},description = "1 : Death,2: Disability")
    public Long type;

    @NotNull
    @Schema(allowableValues ={"6","11","7","8","10"},description = "6 - Received from Bank,11 - In Process,7 - Query,8 - Claim Repudiated ,10 - Claim Approved")
    public Long claimStatus;
    
    @NotNull
	@ApiModelProperty(notes = "dateOfLoss", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    public String dateOfLoss;
   
    @NotNull
    @Size(min = 2,max = 50)
    public String beneficiaryName;

    @NotNull
    @Size(min = 2,max = 100)
    public String beneficiaryBank;
    private final static long serialVersionUID = 1083988607005075259L;

}