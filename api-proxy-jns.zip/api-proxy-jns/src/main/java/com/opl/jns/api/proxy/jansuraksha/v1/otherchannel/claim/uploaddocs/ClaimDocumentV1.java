package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDocumentV1  implements Serializable {

	private static final long serialVersionUID = 145465468L;

	@NotNull
	@NotEmpty
	private String documentType;

	@NotNull
	@Schema(allowableValues = {"4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"}, description = "Review Example Description : documentList >>> documentId >>> Enum ")
	private Long documentId;

	@NotNull
	@NotEmpty
	@Schema(description = "pdf")
	private String contentType;

	@NotNull
	@NotEmpty
	@Schema(description = "byte")
	private String document;

}
