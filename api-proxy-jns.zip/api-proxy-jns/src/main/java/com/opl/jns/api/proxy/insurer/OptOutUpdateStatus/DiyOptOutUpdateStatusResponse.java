package com.opl.jns.api.proxy.insurer.OptOutUpdateStatus;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class DiyOptOutUpdateStatusResponse extends APIResponseV3 implements Serializable {
	
	private static final long serialVersionUID = 1L;

}
