package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt;

public class Test {

}
