package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.CustomerDetailsV1;
import com.opl.jns.api.proxy.utils.FieldsMaster;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerDetailsV3  extends CustomerDetailsV1 implements Serializable {

	private final static long serialVersionUID = 2729134690963093267L;

	@NotNull
	@Size(min = 11, max = 11)
	@Schema(example = "XXXX000000")
	private String customerIFSC;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = FieldsMaster.YYYY_MM_DD, required = true)
	public LocalDate dob;

//	@NotNull
//	@Schema(example = "382350")
//	@Size(min = 6, max = 6)
//	public String pincode;

//	@Schema(allowableValues = { "YES", "NO", })
//	@Pattern(regexp = "Y|N", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid disabilityStatus")
//	public String disabilityStatus;

//	@Size(min = 2, max = 200)
//	public String disabilityDetails;
	
	
	@Schema(allowableValues = { "YES", "NO", })
	@Pattern(regexp = "YES|NO", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid disabilityStatus")
	public String disabilityStatus;

	@Size(min = 1, max = 300)
	public String applicantOccupation;

}
