package com.opl.jns.api.proxy.banks.v3.physicalVerification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.AccountHoldersDetailV3;
import com.opl.jns.api.proxy.common.APIResponseV3;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@JsonPropertyOrder({ "status", "message", "flag", "accountHolderDetails" })
@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PhysicalVerificationResponseV3 extends APIResponseV3 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 813567856651L;
	@Valid
	@JsonProperty("accountHolderDetails")
	private List<AccountHoldersDetailV3> accountHolderDetails;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;
	
	public PhysicalVerificationResponseV3() {
		super();
	}

	public PhysicalVerificationResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
