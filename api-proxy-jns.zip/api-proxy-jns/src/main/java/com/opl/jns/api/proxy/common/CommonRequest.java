package com.opl.jns.api.proxy.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rohit.prajapati
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class CommonRequest {

	@Hidden
	private Long applicationId;

	@Hidden
	private Boolean isInsurer;
	
	/**
	 * TO HANDLE FAILED RETRY PUSH SCENARIO IN THE PUSH SCHEDULER SERVICE
	 */
	@Hidden
	private Boolean isFailedRetry;

	@Hidden
	public Long claimRefId;

	@Hidden
	@JsonProperty("SOURCE_ID")
	private String sourceId;

	@Hidden
	private Long orgId;

//	@NotNull
	@JsonProperty("token")
	@Schema(example = "JNS0132407120407014ca855f91 -Note:token* must not be null.")
	@Size(min = 1, max = 300)
	private String token;
	
	@Hidden
	private Long commonUserId;

	@Hidden
	@JsonProperty("storageId")
	private Long storageId;
	
	public CommonRequest(Long applicationId, Long orgId) {
		super();
		this.applicationId = applicationId;
		this.orgId = orgId;
	}
	
}
