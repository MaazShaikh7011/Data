package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe;

import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString
public class ClaimDedupMatchWithResProxyV3 {
	

	@NotNull
    @Size(min = 31,max = 32)
    public String urn;

	@NotNull
//	@ApiModelProperty(notes = "intimationDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	@Schema(example = APIUtils.YYYY_MM_DD)
    public String intimationDate;

    @NotNull
    @Schema(allowableValues ={"1","2"},description = "1 : Death,2: Disability")
    public Long type;

    @NotNull
    @Schema(allowableValues ={"11","7","8","10"},description = "11 - In process,7 - Queried ,8 - Rejected,10 - Approved")
    public Long claimStatus;
    
    @NotNull
//	@ApiModelProperty(notes = "dateOfLoss", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
    @Schema(example = "2000-08-08 15:24:58")
    public String dateOfLoss;
   
//    @NotNull
//    @Size(min = 2,max = 50)
//    public String beneficiaryName;

    @NotNull
    @Size(min = 2,max = 100)
    public String beneficiaryBank;

}
