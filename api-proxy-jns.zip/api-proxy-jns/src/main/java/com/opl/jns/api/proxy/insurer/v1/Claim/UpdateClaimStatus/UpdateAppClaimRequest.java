package com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/***
 * 
 * @author paresh.radadiya
 * @Date : 04/03/2023
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
//@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UpdateAppClaimRequest implements Serializable {
	
	private static final long serialVersionUID = 1111111L;
	
	@NotNull
	@Schema(required = true)
	@Min(value = 1,message = "can not be 0")
	private Long claimReferenceId;
	
	@JsonDeserialize(using = JsonStringDeserializer.class)
	@NotNull
	@Size(min = 21, max = 32)
	private String urn;
	@NotNull
//	@Schema(name="claimStatus",description = "Claim Status Enum {6 - Received from Bank *,11 - In Process *,7 - Query *,8 - Claim Repudiated *, 10 - Claim Approved *}")
	@Schema(allowableValues ={"6","11","7","8","10"},description = "6 - Received from Bank,11 - In Process,7 - Query,8 - Claim Repudiated ,10 - Claim Approved")
	@Min(value = 1,message = "can not be 0")
	private Integer claimStatus;
	
	@JsonDeserialize(using = JsonStringDeserializer.class)
	@Min(value = 1, message = "can not be 0")
	private Integer reason;
	
	@JsonDeserialize(using = JsonStringDeserializer.class)
	@NotNull
	@Size(min = 1, max = 100 ,message = "can not be 0")
	private String claimId;
	
	private String insurerStatus;
    
	@JsonDeserialize(using = JsonStringDeserializer.class)
	@Size(min = 1, max = 35)
	private String transactionUTR;
	
	//@JsonDeserialize(using = JsonStringDeserializer.class)
	@Schema(pattern = "2023-05-05 16:12:10")
	@JsonSerialize(using = LocalDateTimeSerializer.class)
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	private LocalDateTime dateOfTransaction;
	
	@Min(value = 1,message = "can not be 0")
	private Double amountOfTransaction;
}
