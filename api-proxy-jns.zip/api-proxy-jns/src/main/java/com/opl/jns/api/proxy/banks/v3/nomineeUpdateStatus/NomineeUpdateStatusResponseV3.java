package com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.nomineeUpdateStatus.NomineeUpdateStatusCommonResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message","sucess", "token", "timeStamp" })
public class NomineeUpdateStatusResponseV3 extends NomineeUpdateStatusCommonResponse {
    
}