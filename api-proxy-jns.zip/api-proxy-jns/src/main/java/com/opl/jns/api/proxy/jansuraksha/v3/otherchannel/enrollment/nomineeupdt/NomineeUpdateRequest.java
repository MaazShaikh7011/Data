package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NomineeUpdateRequest extends RegistryReqProxy {

	private static final long serialVersionUID = 6094945304511529421L;
	
	@NotNull
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
	@Size(min = 3, max = 17)
	private String accountNumber;

	@NotNull
	@JsonProperty("nomineeUpdateFlag")
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "YES" })
	@Pattern(regexp = "YES", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid nomineeUpdateFlag.")
	private String  nomineeUpdateFlag;

	@NotNull
	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid accountHolderName")
	private String accountHolderName;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate  dob;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message = "Enter valid IFSC")
	private String customerIFSC;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	private String gender;

	@NotNull
	@Size(min = 1, max = 150)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid fatherHusbandName")
	private String fatherHusbandName;

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber; // 2 time found

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine1")
	private String addressLine1;

	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine2")
	private String addressLine2;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid city")
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid district")
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	private String state;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	private String pincode;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	private String kycID1Number;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "firstEnrollmentDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime firstEnrollmentDate;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "policyInceptionDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime policyInceptionDate;

	@NotNull
	@Size(min = 1, max = 300)
	private String nomineeName;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate  nomineeDateOfBirth;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String nomineeMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String nomineeEmailId;

	@NotNull
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Nominee Relationship. Please check Nominee relationship.")
	private String relationshipOfNominee;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressofNominee")
	private String addressofNominee;

	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid guradianName")
	private String nameofGuardian;

	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressOfGuardian")
	private String addressOfGuardian;

	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Guardian Relationship. Please check Guardian relationship.")
	private String relationShipOfGuardian;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String guardianEmailId;

	@NotNull
	@Schema(allowableValues = { "BC", "ATM", "MB", "EB", "SMS", "WHATSAPP", "BRANCH", "TAB", "CSP", "WEBSITE",
			"MISSCALL", "DBU" })
	@Size(min = 1, max = 50)
	@Pattern(regexp = "BC|ATM|MB|EB|SMS|WHATSAPP|BRANCH|TAB|CSP|WEBSITE|MISSCALL|DBU", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Channel.")
	private String channelId;

	@NotNull
	private String userId1;

}
