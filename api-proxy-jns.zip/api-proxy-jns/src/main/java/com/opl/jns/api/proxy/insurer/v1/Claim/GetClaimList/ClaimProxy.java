package com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 3/4/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimProxy implements Serializable {
	
	@NotNull
    private Long claimReferenceId;
    
    @NotNull
	@Size(min = 21, max = 32)
    private String urn;
    
    @NotNull
    @Schema(allowableValues ={"PMJJBY","PMSBY"})
    private String schemeName;
    
    
    private Integer schemeId;
}
