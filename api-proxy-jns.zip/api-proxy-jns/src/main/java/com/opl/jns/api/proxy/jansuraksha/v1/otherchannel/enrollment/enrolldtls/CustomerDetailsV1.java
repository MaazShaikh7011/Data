package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDetailsV1 implements Serializable {

	private final static long serialVersionUID = 2729134690963093267L;

	@NotNull
	@Size(min = 3, max = 17)
	public String accountNumber;

	@NotNull
	@Size(min = 3, max = 17)
	public String cif;	

	@NotNull
	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid accountHolderName")
	public String accountHolderName;

	@NotNull
	@Size(min = 1, max = 150)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid fatherHusbandName")
	public String fatherHusbandName;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	public String gender;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	public String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	public String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine1")
	public String addressLine1;

	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine2")
	public String addressLine2;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid city")
	public String city;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid district")
	public String district;

	@NotNull
	@Size(min = 2, max = 200)
	public String state;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	public String pincode;


	@Size(min = 2, max = 200)
	public String disabilityDetails;

}