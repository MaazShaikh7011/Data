package com.opl.jns.api.proxy.common.pushClaim;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;

@Data
public class PushClaimDetailsCommonResponse extends APIResponseV3 {

}