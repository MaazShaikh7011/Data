package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.OtherDetailsV1;
import com.opl.jns.utils.common.PatternUtils;
import com.opl.jns.utils.constant.CommonConstant;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OtherDetailsV3 extends OtherDetailsV1 implements Serializable {

	private final static long serialVersionUID = 9220963440239073079L;

	@NotNull
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMSBY|PMJJBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Scheme Name.")
	public String schemeName;
	
	@NotNull
	@Size(min = 1, max = 30)
	@Schema(allowableValues = CommonConstant.BANK_SHORT_CODE_NAME)
	@Pattern(regexp = CommonConstant.BANK_SHORT_CODE, flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
	public String bankCode;
	
	@Size(min = 2, max = 30)
	@Pattern(regexp = PatternUtils.BRANCH_CODE_PATTERN, message = "Enter valid Branch Code")
	public String branchCode;

	@NotNull
	@Schema(allowableValues = { "BC", "ATM", "MB", "EB", "SMS", "WHATSAPP", "BRANCH","TAB", "CSP", "WEBSITE", "MISSCALL" ,"DBU"})
	@Size(min = 1, max = 50)	
	@Pattern(regexp = "BC|ATM|MB|EB|SMS|WHATSAPP|BRANCH|TAB|CSP|WEBSITE|MISSCALL|DBU", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Channel.")
	public String channelId;
	
	@NotNull
	public String userId1;


}