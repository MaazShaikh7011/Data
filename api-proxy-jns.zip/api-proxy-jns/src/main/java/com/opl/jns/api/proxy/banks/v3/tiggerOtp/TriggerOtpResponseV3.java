package com.opl.jns.api.proxy.banks.v3.tiggerOtp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.APIResponseV3;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "flag", "mobileNumber" })
public class TriggerOtpResponseV3 extends APIResponseV3 {

	@NotNull(message = "Mobile Number of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("mobileNumber")
	@Size(min = 10, max = 10)
	private String mobileNumber;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;

	public TriggerOtpResponseV3() {
		super();
	}

	public TriggerOtpResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}