package com.opl.jns.api.proxy.banks.v2.triggerOtp;

import java.time.LocalDateTime;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.utils.APIUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "flag", "mobileNumber" })
public class TriggerOtpResponseV2 extends APIResponseV2 {

	@NotNull(message = "Mobile Number of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("mobileNumber")
	@Size(min = 10, max = 10)
	private String mobileNumber;
	
	@Hidden
	@JsonProperty("token")
	private String token;
	
	@NotNull
	@Schema(allowableValues ={"true","false"})
	@JsonProperty("flag")
	private Boolean flag;
	
	@Hidden
	@JsonProperty("timestamp")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timestamp;
	
	@Hidden
	@JsonProperty("success")
	private Boolean success;

	public TriggerOtpResponseV2() {
		super();
	}

	public TriggerOtpResponseV2(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}