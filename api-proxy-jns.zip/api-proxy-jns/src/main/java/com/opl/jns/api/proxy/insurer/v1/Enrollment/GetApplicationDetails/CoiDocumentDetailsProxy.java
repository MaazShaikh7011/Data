package com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationDetails;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CoiDocumentDetailsProxy {

	@NotNull
	@Schema( description = "coi")
	private String documentType;
	@NotNull
	@Schema( description = "pdf")
	private String contentType;
	@NotNull
	private byte[] document;	
}
