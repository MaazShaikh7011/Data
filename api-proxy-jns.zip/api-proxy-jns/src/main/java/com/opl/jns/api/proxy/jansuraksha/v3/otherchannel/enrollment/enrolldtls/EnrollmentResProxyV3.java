package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.opl.jns.api.proxy.common.APIResponseV3;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serial;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EnrollmentResProxyV3 extends APIResponseV3 {

	@Serial
	private static final long serialVersionUID = 1L;

	@NotNull
	@Size(min = 31, max = 32)
	public String urn;


	public EnrollmentResProxyV3(String message, Integer status, Boolean success) {
		super(status,message,  success);
	}

	public EnrollmentResProxyV3(String message, Integer status) {
		super(status,message);
	}

	public EnrollmentResProxyV3(String message, Integer status, Boolean success, String urn) {
		super(status,message,success);
		this.urn = urn;
	}

}