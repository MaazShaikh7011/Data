package com.opl.jns.api.proxy.jansuraksha.v2;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Response400V2 implements Serializable {

	private static final long serialVersionUID = 8175555024375812674L;

	@Hidden
    public static final String PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"status\":400,\"success\":false}";

//    // for webhook
    @Hidden
    public static final String WB_PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"status\":400,\"success\":false}";

    @Schema(example = "It seems that request is not properly formed.")
    private String message;

    @Schema(example = "400")
    private Integer status;

    @Schema(example = "false")
    private Boolean success;

    @NotNull
    @JsonProperty("timestamp")
    @JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime timestamp;
    
    @NotNull
	@Size(min = 0, max = 100)
	@JsonProperty("token")
	private String token;

}
