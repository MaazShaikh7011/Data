package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.statusupdate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClaimTransProxyV2 implements Serializable {

	private final static long serialVersionUID = 1175522787349167241L;

	@Schema(example = "2023-05-05 16:12:10")
	public String transactionTimeStamp;

	public Double transactionAmount;

	@Size(min = 1, max = 35)
	public String transactionUTR;

}