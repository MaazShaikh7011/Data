package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClaimDeDupReqProxyV3 extends CommonRequest {

	private final static long serialVersionUID = -9020492356609251905L;

	@NotNull
	@Size(min = 31, max = 32)
	public String urn;

	@NotNull
	public Long claimReferenceId;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "hospitalisationDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime hospitalisationDate;

	@Size(min = 2, max = 100)
	public String firNo;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "firDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime firDate;

	@Size(min = 2, max = 100)
	public String panchnamaNo;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "panchnamaDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime panchnamaDate;

	@Size(min = 2, max = 100)
	public String postMortemReportNo;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "postMortemReportDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime postMortemReportDate;

	@Size(min = 2, max = 100)
	public String deathordisabilitycertificateReportNo;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "deathordisabilityCertificateReportDate", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime deathordisabilityCertificateReportDate;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "documentReceivingDate", example = FieldsMaster.YYYY_MM_DD, required = true)
	public LocalDate documentReceivingDate;

}
