package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.CustomerDetailsV1;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Range;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerDetailsV2 extends CustomerDetailsV1 {

	private final static long serialVersionUID = 2729134690963093267L;
	

	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid firstName")
	public String firstName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid middleName")
	public String middleName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid lastName")
	public String lastName;	

	@NotNull
	@Schema(example = "13/06/1993")
	public String dob;

	@Range(min = 0, max = 99999999)
	public Long cityLGDCode;
	
	@Range(min = 0, max = 99999999)
	public Long districtLGDCode;

	@Range(min = 0, max = 99999999)
	public Long stateLGDCode;		
	
	@Schema(allowableValues = { "Y", "N", })
	@Pattern(regexp = "Y|N", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid disabilityStatus")
	public String disabilityStatus;



	
}
