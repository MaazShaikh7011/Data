package com.opl.jns.api.proxy.common;

import java.time.LocalDateTime;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.utils.APIUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "message", "status", "success", "timeStamp" })
public class APIResponseV3 extends MainResponse {

	@NotNull(message = "success must not be null.")
	@JsonProperty("success")
	@Schema(allowableValues = { "True", "False" })
	private Boolean success;

	@NotNull(message = "timestamp must not be null.")
	@JsonProperty("timestamp")
	@JsonAlias({"timeStamp"})
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timestamp;

	public APIResponseV3() {
		super();
	}

	public APIResponseV3(Integer status, String message, Boolean success) {
		super(message, status);
		this.success = success;
	}

	public APIResponseV3(Integer status, String message, Boolean success, String token, LocalDateTime timestamp) {
		super(message, status, token);
		this.success = success;
		this.timestamp = timestamp;
	}

	public APIResponseV3(Integer status, String message, Boolean success, String token) {
		super(message, status, token);
		this.success = success;
	}

	public APIResponseV3(Integer status, String message) {
		super(message, status);
	}

	public void setStatusAndMessageAndSuccess(String message, Integer status, Boolean success) {
		super.setMessage(message);
		super.setStatus(status);
		this.setSuccess(success);
	}

}
