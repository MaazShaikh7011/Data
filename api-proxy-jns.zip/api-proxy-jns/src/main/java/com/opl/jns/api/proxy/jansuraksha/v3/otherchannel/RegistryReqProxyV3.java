package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RegistryReqProxyV3 extends RegistryReqProxy {

	private static final long serialVersionUID = -4252439611275187617L;

	@NotNull
	public String token;

}
