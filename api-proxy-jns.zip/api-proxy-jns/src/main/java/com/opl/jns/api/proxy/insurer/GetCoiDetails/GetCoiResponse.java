package com.opl.jns.api.proxy.insurer.GetCoiDetails;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@ToString
public class GetCoiResponse extends APIResponseV3 implements Serializable {

	private final static long serialVersionUID = 1175522787349167243L;

	@NotNull(message = "accountHolderName is not found")
	@Size(min = 1, max = 300)
	private String accountHolderName;

	@NotNull(message = "dob is not found")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = APIUtils.YYYY_MM_DD, required = true)
	private LocalDate dob;

	@Size(min = 10, max = 10,message = "Invalid mobileNumber. Value must be 10 characters.")
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber;

	@NotNull(message = "addressline1 is not found")
	@Size(min = 2, max = 500,message = "Invalid addressline1. Value must be between 2 to 500 characters.")
	private String addressline1;

	@Size(min = 2, max = 500,message = "Invalid addressline2. Value must be between 2 to 500 characters.")
	private String addressline2;

	@NotNull(message = "city is not found")
	@Size(min = 2, max = 200,message = "Invalid city. Value must be between 2 to 200 characters.")
	private String city;

	@NotNull(message = "district is not found")
	@Size(min = 2, max = 200,message = "Invalid district. Value must be between 2 to 200 characters.")
	private String district;

	@NotNull(message = "state is not found")
	@Size(min = 2, max = 200,message = "Invalid state. Value must be between 2 to 200 characters.")
	private String state;

	@NotNull(message = "pincode is not found")
	@Schema(example = "382350")
	@Min(value = 100000, message = "Invalid Pincode. Value must be of 6-digits.")
	@Max(value = 999999, message = "Invalid Pincode. Value must be of 6-digits.")
	private Integer pincode;

	@NotNull(message = "kycID1 is not found")
	@Size(min = 1, max = 25,message = "Invalid kycID1. Value must be between 1 to 25 characters.")
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	private String kycID1;

	@NotNull(message = "kycID1number is not found")
	@Size(min = 1, max = 100,message = "Invalid kycID1number. Value must be between 1 to 100 characters.")
	private String kycID1number;

	@NotNull
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "firstEnrollmentDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime firstEnrollmentDate;

	@NotNull(message = "nomineeName is not found")
	@Size(min = 1, max = 300,message = "Invalid nomineeName. Value must be between 1 to 300 characters.")
	private String nomineeName;

	@NotNull(message = "nomineeDateOfBirth is not found")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD)
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = APIUtils.YYYY_MM_DD, required = true)
	public LocalDate nomineeDateOfBirth;

	@NotNull
	@Size(min = 1, max = 300,message = "Invalid nameofGuardian. Value must be between 1 to 300 characters.")
	public String nameofGuardian;

	@NotNull
	@Size(min = 1, max = 50,message = "Invalid relationshipOfGuardian. Value must be between 1 to 50 characters.")
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	public String relationshipOfGuardian;

	public GetCoiResponse(Integer status, String message, Boolean flag, String token) {
		super(status, message, flag,token);
	}

	public GetCoiResponse() {
		super();
	}
	

}
