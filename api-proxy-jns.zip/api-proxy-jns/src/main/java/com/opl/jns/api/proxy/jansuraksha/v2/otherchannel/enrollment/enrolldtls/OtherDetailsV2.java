package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.OtherDetailsV1;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OtherDetailsV2 extends OtherDetailsV1 implements Serializable {

	private final static long serialVersionUID = 9220968540239073079L;	
	
	@NotNull
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMSBY|PMJJBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Scheme")
	public String scheme;

	@NotNull
	public String bankCode;	
	
	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.BRANCH_CODE_PATTERN, message = "Enter valid Branch Code")
	public String branchCode;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = PatternUtils.IFSC_PATTERN, message = "Enter valid IFSc")
	public String branchIFSC;
	
	public String channelId;
	
	@NotNull
	@Size(min = 1, max = 10)
	public String ruralUrban;	
	
	public String userId1;

}