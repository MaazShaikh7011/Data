package com.opl.jns.api.proxy.insurer.v1.Webhook.UpdateClaimStatus;

import com.opl.jns.api.proxy.common.APIResponseV1;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class ClaimStatusResponse extends APIResponseV1 implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer status;

    public ClaimStatusResponse() {

    }

    public ClaimStatusResponse(String message, Integer status) {
        super();
        this.setMessage(message);
        this.status = status;
    }

    public ClaimStatusResponse(String message, Integer status, Boolean success) {
        super();
        this.setMessage(message);
        this.status = status;
        this.setSuccess(success);
    }

}
