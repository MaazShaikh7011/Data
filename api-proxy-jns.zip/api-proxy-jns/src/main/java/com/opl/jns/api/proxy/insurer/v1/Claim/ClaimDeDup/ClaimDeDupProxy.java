package com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDeDupProxy implements Serializable {

    @NotNull
    @Schema(allowableValues = { "True", "False" })
    public Boolean dedupeCheck;
    public ClaimDeDupeDetails isMatchWith;
    private final static long serialVersionUID = -2203711281033421811L;

}