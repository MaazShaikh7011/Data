package com.opl.jns.api.proxy.banks.v3.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.banks.v2.getCustomerDetails.AccountHolderDetailsV2;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountHolderDetailsV3 extends AccountHolderDetailsV2 {

	@JsonProperty("dob")
	private String dob;

	@JsonProperty("emailId")
	private String emailId;

	@JsonProperty("applicantOccupation")
	private String applicantOccupation;

	@JsonProperty("nomineeName")
	private String nomineeName;

	@JsonProperty("nomineeDateOfBirth")
	private String nomineeDateOfBirth;
	
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;
	
	@JsonProperty("nomineeEmailId")
	private String nomineeEmailId;
	
	@JsonProperty("addressofNominee")
	private String addressofNominee;

	@JsonProperty("relationshipOfGuardian")
	private String relationshipOfGuardian;

	@JsonProperty("bcReferralId")
	private String bcReferralId;
	
	@JsonProperty("consentforautodebit")
	private String consentforautodebit;

}
