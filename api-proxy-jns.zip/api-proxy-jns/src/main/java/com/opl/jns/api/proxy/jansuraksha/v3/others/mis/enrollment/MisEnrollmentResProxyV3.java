package com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serial;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MisEnrollmentResProxyV3 extends APIResponseV3 {

    @Serial
    private static final long serialVersionUID = 1L;

    private Long dmsStorageId;

    public MisEnrollmentResProxyV3(Integer status,String message, Boolean success) {
        super(status,message, success);
    }

    public MisEnrollmentResProxyV3(String message, Integer status) {
        super(status,message);
    }

    public MisEnrollmentResProxyV3(String message, Object data, Integer status, Boolean success) {
        super(status,message, success);
    }

    public MisEnrollmentResProxyV3(String message, Object data, Integer status) {
        super(status,message);
    }

    public MisEnrollmentResProxyV3(String message, Integer status, Boolean success, Long dmsStorageId) {
        super(status,message,success);
        this.dmsStorageId = dmsStorageId;
    }
}
