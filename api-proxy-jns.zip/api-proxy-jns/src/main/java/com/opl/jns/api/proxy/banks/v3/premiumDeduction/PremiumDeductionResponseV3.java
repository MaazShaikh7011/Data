package com.opl.jns.api.proxy.banks.v3.premiumDeduction;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
@JsonPropertyOrder({ "status", "message", "flag", "debitStatus","transactionUTR", "transactionTimeSTamp", "transactionTimeSTamp",
		"premiumAmount", "transactionAmount", "comment" })
public class PremiumDeductionResponseV3 extends APIResponseV3 {

	@NotNull(message = "debitStatus of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("debitStatus")
	@Pattern(regexp = "1|2|3|4|5|6|7|8", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid debit status.")
	@Schema(allowableValues =  {"1,2,3,4,5,6,7,8" }, description = "1-Successful Debit, 2-Error (Due to API failure), 3-Balance insufficient, 4-Account Closed, 5-Account Dormant,6-Account Frozen, 7-No debit Account, 8-No debit due to other reason")
	private String debitStatus;
	
	@NotNull(message = "Transaction UTR of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 35, message = "Invalid Transaction UTR. Value must be between 1 to 35 alphanumeric characters.")
	@JsonProperty("transactionUTR")
	private String transactionUTR;

	@NotNull(message = "transactionTimeStamp of the selected A/C holder is not found in the Bank CBS.")
	@Schema(example = "2024-01-01 05:06:00 - DataType:string($date-time)")
	@JsonProperty("transactionTimeStamp")
	private String transactionTimeStamp;

	@NotNull(message = "transactionAmount of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("transactionAmount")
	private String transactionAmount;

	@Size(min = 0, max = 255)
	@JsonProperty("comment")
	private String comment;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;
	
	public PremiumDeductionResponseV3() {
		super();
	}

	public PremiumDeductionResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
