package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.GuardianDetailsV1;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GuardianDetailsV3 extends GuardianDetailsV1 implements Serializable {

	private final static long serialVersionUID = -4654729453217893182L;

	@NotNull
	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid guradianName	")
	public String guradianName;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid address")
	public String addressofGuardian;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	public String emailId;

}
