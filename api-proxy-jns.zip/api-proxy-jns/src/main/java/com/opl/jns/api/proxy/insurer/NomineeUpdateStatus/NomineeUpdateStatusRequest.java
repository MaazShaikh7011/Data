package com.opl.jns.api.proxy.insurer.NomineeUpdateStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.nomineeUpdateStatus.NomineeUpdateStatusCommonRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class NomineeUpdateStatusRequest extends NomineeUpdateStatusCommonRequest implements Serializable, Cloneable {

}
