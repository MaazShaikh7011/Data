package com.opl.jns.api.proxy.banks.v3.getPolicyDetails;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.utils.FieldsMaster;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PolicyDetailsResponseV3 extends APIResponseV3 {

	@NotNull(message = "customerIFSC of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX,message = "Invalid Account Holder Name. Value must be between 11 to 11 characters.")
	@Schema(example = "XXXX000000")
	@JsonProperty("customerIFSC")
	private String customerIFSC;

	@NotNull(message = "accountHolderName of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = FieldsMaster.ACC_HOLERNAME_MIN, max = FieldsMaster.ACC_HOLERNAME_MAX,message = "Invalid Account Holder Name. Value must be between 1 to 300 characters.")
	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@NotNull(message = "gender of the selected A/C holder is not found in the Bank CBS.")
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid gender.")
	@JsonProperty("gender")
	private String gender;

	@NotNull(message = "fatherHusbandName of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 150,message = "Invalid fatherHusbandName. Value must be between 1 to 150 characters.")
	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;

	@NotNull(message = "dob of the selected A/C holder is not found in the Bank CBS.")
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	private LocalDate dob;

	//@NotNull(message = "mobileNumber of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 10, max = 10,message = "Invalid mobileNumber. Value must be of 10-digits.")
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@Size(min = 5, max = 255,message = "Invalid emailId. Value must be between 5 to 255 characters.")
	@Schema(example = "xyz@gmail.com")
	@JsonProperty("emailId")
	private String emailId;

	@NotNull(message = "addressline1 of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 500,message = "Invalid addressline1. Value must be between 2 to 500 characters.")
	@JsonProperty("addressline1")
	private String addressline1;

	@Size(min = 2, max = 500,message = "Invalid addressline2. Value must be between 2 to 500 characters.")
	@JsonProperty("addressline2")
	private String addressline2;

	@NotNull(message = "city of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200,message = "Invalid city. Value must be between 2 to 200 characters.")
	@JsonProperty("city")
	private String city;

	@NotNull(message = "district of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200,message = "Invalid district. Value must be between 2 to 200 characters.")
	@JsonProperty("district")
	private String district;

	@NotNull(message = "state of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200,message = "Invalid state. Value must be between 2 to 200 characters.")
	@JsonProperty("state")
	private String state;

	@NotNull(message = "pincode of the selected A/C holder is not found in the Bank CBS.")
	@Min(value = 100000, message = "Invalid Pincode. Value must be of 6-digits.")
	@Max(value = 999999, message = "Invalid Pincode. Value must be of 6-digits.")
	@JsonProperty("pincode")
	private Long pincode;

	@NotNull(message = "kycID1 of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 25,message = "Invalid kycID1. Value must be between 1 to 25 characters.")
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@JsonProperty("kycID1")
	private String kycID1;

	@NotNull(message = "kycID1number of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 100,message = "Invalid kycID1number. Value must be between 1 to 100 characters.")
	@JsonProperty("kycID1number")
	private String kycID1number;

	@JsonProperty("pan")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 2, max = 3,message = "Invalid pan. Value must be between 2 to 3 characters.")
	private String pan;

	@Size(min = 10, max = 10,message = "Invalid panNumber. Value must be between 10 to 10 characters.")
	private String panNumber;

	@JsonProperty("aadhaar")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 2, max = 3,message = "Invalid aadhaar. Value must be between 2 to 3 characters.")
	private String aadhaar;

	@Size(min = 12, max = 12,message = "Invalid aadhaarNumber. Value must be between 12 to 12 characters.")
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;

	@JsonProperty("ckyc")
	@Schema(allowableValues = { "YES", "NO"})
	@Size(min = 2, max = 3,message = "Invalid ckyc. Value must be between 2 to 3 characters.")
	private String ckyc;

	@Size(min = 14, max = 15,message = "Invalid ckycNumber. Value must be between 14 to 15 characters.")
	@JsonProperty("ckycNumber")
	private String ckycNumber;

	@NotNull(message = "firstEnrollmentDate of the selected A/C holder is not found in the Bank CBS.")
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	private LocalDateTime firstEnrollmentDate;

	@Size(min = 1, max = 300,message = "Invalid nomineeName. Value must be between 1 to 300 characters.")
	@JsonProperty("nomineeName")
	private String nomineeName;

	@JsonProperty("nomineeDateOfBirth")
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	private LocalDate nomineeDateOfBirth;

	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@Size(min = 10, max = 10,message = "Invalid nomineeMobileNumber. Value must be between 10 to 10 characters.")
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;

	@Size(min = 1, max = 50,message = "Invalid relationshipOfNominee. Value must be between 1 to 50 characters.")
	@JsonProperty("relationshipOfNominee")
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Nominee Relationship. Please check relationshipOfNominee.")
	private String relationshipOfNominee;

	@Size(min = 5, max = 255,message = "Invalid nomineeEmailId. Value must be between 5 to 255 characters.")
	@JsonProperty("nomineeEmailId")
	@Schema(example = "xyz@gmail.com")
	private String nomineeEmailId;

	@Size(min = 2, max = 500,message = "Invalid addressofNominee. Value must be between 2 to 500 characters.")
	@JsonProperty("addressofNominee")
	private String addressofNominee;

	@Size(min = 1, max = 300,message = "Invalid nameofGuardian. Value must be between 1 to 300 characters.")
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	@Size(min = 2, max = 500,message = "Invalid addressofGuardian. Value must be between 2 to 500 characters.")
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	@JsonProperty("relationshipofGuardian")
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Guardian Relationship. Please check relationShipOfGuardian.")
	private String relationshipofGuardian;

	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@Size(min = 10, max = 10,message = "Invalid guardianMobileNumber. Value must be between 10 to 10 characters.")
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255,message = "Invalid guardianEmailId. Value must be between 2 to 255 characters.")
	@JsonProperty("guardianEmailId")
	@Schema(example = "xyz@gmail.com")
	private String guardianEmailId;

	@Size(min = 1, max = 35,message = "Invalid transactionUTR. Value must be between 1 to 35 characters.")
	private String transactionUTR;

	public Double transactionAmount;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	private LocalDateTime transactionTimestamp;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;

	public PolicyDetailsResponseV3() {
		super();
	}

	public PolicyDetailsResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}}
