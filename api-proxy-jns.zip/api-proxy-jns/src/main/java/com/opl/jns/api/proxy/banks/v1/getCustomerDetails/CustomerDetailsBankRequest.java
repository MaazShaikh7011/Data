package com.opl.jns.api.proxy.banks.v1.getCustomerDetails;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDetailsBankRequest {

	private String accountNumber;
	private String cif;
	private String urn;
	/** SBI USE ONLY **/
	@JsonProperty("SOURCE_ID")
	private String sourceId;
	@JsonProperty("token")
	private String token;

}
