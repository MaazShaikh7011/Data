package com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MisEnrollmentReqV3 extends RegistryReqProxy {

	private final static long serialVersionUID = -4357839815853867628L;

	@NotNull
	@Schema(allowableValues = { "ENROLL", "RENEWAL" })
	@Pattern(regexp = "ENROLL|RENEWAL", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid type.")
	public String type;

	@NotNull
	@JsonFormat(
		pattern = "yyyy-MM-dd HH:mm:ss"
	)
	public LocalDateTime fromDate;

	@NotNull
	@JsonFormat(
		pattern = "yyyy-MM-dd HH:mm:ss"
	)
	public LocalDateTime toDate;

	@NotNull
	public List<DistrictWiseData> districtList;

	@Hidden
	private Long orgId;
	@Hidden
	private Long userId;
	@Hidden
	private Long storageId;

	@Hidden
	private String bankName;
	@Hidden
	private String bankShortName;
	@Hidden
	private String bankCode;
	@Hidden
	private String bankCategory;

	@Hidden
	private Long PMSBYInsurerOrgId;
	@Hidden
	private String PMSBYInsurerName;
	@Hidden
	private String PMSBYInsurerCode;

	@Hidden
	private Long PMJJBYInsurerOrgId;
	@Hidden
	private String PMJJBYInsurerName;
	@Hidden
	private String PMJJBYInsurerCode;

}