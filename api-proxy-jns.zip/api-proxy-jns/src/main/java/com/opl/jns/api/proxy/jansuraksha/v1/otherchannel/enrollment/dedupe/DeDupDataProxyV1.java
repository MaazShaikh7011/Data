package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.dedupe;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
//@Builder(toBuilder = true)
@SuperBuilder
public class DeDupDataProxyV1 implements Serializable {

	private static final long serialVersionUID = -4342542232341L;

	@NotNull
	@Schema(allowableValues = { "Y", "N" })
	public String isMatched;
	@NotNull
	@Size(min = 0, max = 32)
	public String matchWith;
	@NotNull
	@Size(min = 0, max = 100)
	public String bankName;

}
