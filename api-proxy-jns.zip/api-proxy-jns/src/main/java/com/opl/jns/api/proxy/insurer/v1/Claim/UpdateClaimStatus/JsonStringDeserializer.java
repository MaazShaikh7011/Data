package com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

public class JsonStringDeserializer extends JsonDeserializer<String> {

    @Override
    public String deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        JsonNode node = jsonParser.readValueAsTree();
        String nodeText = node.asText();
        // todo: isBlank or isEmpty depending on your needs
        if (nodeText.isEmpty()) {
            return null;
        }
        return nodeText;
    }
}