package com.opl.jns.api.proxy.jansuraksha.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 *
 * @author harshit
 */
@Setter
@Getter
@ToString
public class RegCommonResponse extends APIResponseV3 implements Serializable {

    private static final long serialVersionUID = 1L;
    @NotNull
    @Size(min = 0, max = 255)
    private String message;
    
    @NotNull
    private Integer status;

	@NotNull
	@Schema(allowableValues = {"True", "False"})
	@JsonProperty("success")
	private Boolean success;
	
	@Hidden
//	@JsonProperty("token")
	private String token;

    public RegCommonResponse() {

    }

    public RegCommonResponse(String message, Integer status) {
        super();
        this.message = message;
        this.status = status;
    }

    public RegCommonResponse(String message, Object data, Integer status) {
        super();
        this.message = message;
        //this.data = data;
        this.status = status;
    }

    public RegCommonResponse(String message, Object data, Integer status, Boolean success) {
        super();
        this.message = message;
        //this.data = data;
        this.status = status;
        this.success = success;
    }

    public RegCommonResponse(String message, Integer status, Boolean success) {
        super();
        this.message = message;
        this.status = status;
        this.success = success;
    }

}
