package com.opl.jns.api.proxy.banks.v2.getCustomerDetails;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.AccountHolderDetailsResponseV2;
import com.opl.jns.api.proxy.common.APIResponseV2;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerDetailsDataV2 extends APIResponseV2 {

	@Valid
	@JsonProperty("accountHolderDetails")
	private AccountHolderDetailsResponseV2 accountHolderDetails;
	
	@Hidden
	@JsonProperty("token")
	private String token;

	@Hidden
	@JsonProperty("timestamp")
	private LocalDateTime timestamp;
	
	public CustomerDetailsDataV2() {
		super();
	}

	public CustomerDetailsDataV2(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
