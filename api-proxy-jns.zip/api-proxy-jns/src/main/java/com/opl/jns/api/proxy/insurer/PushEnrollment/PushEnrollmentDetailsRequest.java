package com.opl.jns.api.proxy.insurer.PushEnrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.pushEnrollment.PushEnrollmentDetailsCommonRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class PushEnrollmentDetailsRequest extends PushEnrollmentDetailsCommonRequest implements Serializable, Cloneable {

    /* INTERNAL USE ONLY */

    private Integer failureCount;

}
