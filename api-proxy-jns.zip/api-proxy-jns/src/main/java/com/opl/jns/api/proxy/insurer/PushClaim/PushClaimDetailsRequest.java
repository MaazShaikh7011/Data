package com.opl.jns.api.proxy.insurer.PushClaim;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.pushClaim.PushClaimDetailsCommonRequest;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PushClaimDetailsRequest extends PushClaimDetailsCommonRequest implements Serializable, Cloneable  {

}
