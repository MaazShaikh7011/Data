package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.common.RegCommonResponse;
import com.opl.jns.api.proxy.utils.APIUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 *
 * @author Maaz Shaikh
 *
 */
public class RegistryResponse extends RegCommonResponse implements Serializable {

	@NotNull
	@Size(min = 0, max = 100)
	private String token;
	
	@Hidden
	@NotNull
	@JsonProperty("timeStamp")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "timeStamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;
	
	@NotNull
    @JsonProperty("timestamp")
    @JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime timestamp;

	public void setStatusAndMessageAndSuccess(String message,Integer status,Boolean success){
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponse(){

	}
	public RegistryResponse(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}
	public RegistryResponse(String message, Object data, Integer status) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
	}

	public RegistryResponse(String message, Object data, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		//this.setData(data);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponse(String message, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

	public RegistryResponse(String message, Integer status, Boolean success, String token, LocalDateTime timestamp) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
		this.setToken(token);
		this.setTimestamp(timestamp);
	}

	public RegistryResponse(String message, Integer status, Boolean success, String token) {
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
		this.setToken(token);
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
