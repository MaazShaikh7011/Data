package com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 3/4/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDetailsProxy implements Serializable {

    private static final long serialVersionUID = 1L;


    @NotNull
	@Size(min = 21, max = 32)
    private String urn;
    
    @NotNull
    private Long claimReferenceId;
    
    @NotNull
    @Schema(allowableValues ={"PMJJBY","PMSBY"})
    private String schemeName;
    private Long schemeId;
    
    
    @NotNull
    @Size(min = 3, max = 17)
    private String customerAccountNumber;
    
    
    @NotNull
    @Size(min = 5, max = 100)
    private String customerBankname;
    

    @NotNull
    @Size(min = 11, max = 11)
    private String customerIFSC;
    
    @NotNull
	@Size(min = 1, max = 300)
    private String accountHolderName;
    
    @NotNull
    @Schema(example = "2024-01-01 - DataType:string($date)")
    private String dob;
    
    @NotNull
    @Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
    private String gender;
    
    @NotNull
	@Size(min = 3, max = 17)
    private String cif;
    
    @NotNull
    @Size(min = 1, max = 100)
    private String masterPolicyNumber;
    
    @NotNull
    @Schema(example = "2023-05-05 16:12:10")
    private String dateOfEnrollment;
    
    @NotNull
    @Size(min = 3, max = 10)
    private String bankCode;
    
    @NotNull
    @Size(min = 2, max = 100)
    private String branchName;
    
    
    
    
    @NotNull
	@Size(min = 1, max = 50)
    private String firstName;
    
    
	@Size(min = 1, max = 50)
    private String middleName;
    
    
	@Size(min = 1, max = 50)
    private String lastName;
    
	
	@NotNull
	@Size(min = 1, max = 150)
    private String fatherHusbandName;
    
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String mobileNumber;
	

    @Size(min = 5, max = 255)
    //@Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email not format")
    @Schema(example = "xyz@gmail.com")
    private String emailID;
	
	@NotNull
	@Size(min = 2, max = 500)
    private String addressline1;
	
	
	@Size(min = 2, max = 500)
    private String addressline2;
	
	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
    private Integer pincode;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String city;
	
	@Size(min = 1, max = 8)
    private String cityLGDCode;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String district;
	
	@Size(min = 1, max = 8)
    private String districtLGDCode;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String state;
	
	@Size(min = 1, max = 8)
    private String stateLGDCode;
	
	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
    private String kycID1;
	
	@NotNull
	@Size(min = 1, max = 100)
    private String kycID1number;
	
	@Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
	@Size(min = 1, max = 25)
    private String kycID2;
	
	@Size(min = 1, max = 100)
    private String kycID2number;
	
//	 @NotNull
//	@Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
//	@Size(min = 1, max = 25)
//    private String kycID3;
//	
//	@NotNull
//	@Size(min = 1, max = 100)
//    private String kycID3number;
	
	@Schema(allowableValues ={"true","false"})
    private Boolean pan;
    
    @Size(min = 10, max = 10)
    private String panNumber;
    
    @Schema(allowableValues ={"true","false"})
    private Boolean aadhaar;
    
    @Size(min = 12, max = 12)
    private String aadhaarNumber;
    
    @Schema(allowableValues ={"true","false"})
    private Boolean ckyc;
    
    @Size(min = 14, max = 15)
    private String ckycNumber;
    
    @NotNull
    @Size(min = 1, max = 50)
    private String nomineeFirstName;
    
    @Size(min = 1, max = 50)
    private String nomineeMiddleName;
    
    @Size(min = 1, max = 50)
    private String nomineeLastName;
    

    @NotNull
    @Schema(example = "1993-06-06")
    private String nomineeDateOfBirth;
    
    @NotNull
    @Size(min = 10, max = 10)
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String nomineeMobileNumber;
    
    
    @Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    //@Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email not format")
    private String nomineeEmailId;
    
    @NotNull
    @Size(min = 5, max = 200)
    private String nomineeAddressline1;
    
    
    @Size(min = 5, max = 200)
    private String nomineeAddressline2;
    
    @NotNull
    @Schema(example = "382350")
    @Size(min = 6, max = 6)
    private String nomineePincode;
    
    @NotNull
    @Size(min = 2, max = 200)
    private String nomineeCity;
	
	@Size(min = 1, max = 8)
    private String nomineeCityLGDCode;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String nomineeDistrict;
	
	@Size(min = 1, max = 8)
    private String nomineeDistrictLGDCode;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String nomineeState;
	
	@Size(min = 1, max = 8)
    private String nomineeStateLGDCode;
    
	

    @NotNull
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    private String relationOfNominee;
    
    
    @NotNull
    @Size(min = 1, max = 50)
    private String correctNomineeFirstName;
    
    
    @Size(min = 1, max = 50)
    private String correctnomineeMiddleName;
    
    
    @Size(min = 1, max = 50)
    private String correctnomineeLastName;
    
    
    @NotNull
    @Size(min = 1, max = 50)
    private String nameofGuardian;
    
    @NotNull
    @Size(min = 2, max = 200)
    private String addressOfGuardian;
    
    @NotNull
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    private String relationShipOfGuardian;
    
	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String guardianMobileNumber;
    
    
	@Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    //@Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email not format")
    private String guardianEmailId;
    
	@NotNull
    @Size(min = 1, max = 50)
    private String claimantFirstName;
    
    @Size(min = 1, max = 50)
    private String claimantMiddleName;
    
    @Size(min = 1, max = 50)
    private String claimantLastName;
    
    @NotNull
    @Schema(example = "1993-06-06")
    private String claimantDateOfBirth;
    @NotNull
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    private String relationOfClaimant;
    
    @NotNull
    @Size(min = 10, max = 10)
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String claimantMobileNumber;
    
    @NotNull
	@Size(min = 1, max = 25)
    @Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
    private String claimantKYC1;
    
    @NotNull
	@Size(min = 1, max = 100)
    private String claimantKYCNumber1;
    
    @Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
	@Size(min = 1, max = 25)
    private String claimantKYC2;
    
    
	@Size(min = 1, max = 100)
    private String claimantKycNumber2;
	
	@NotNull
	@Schema(example = "1993-06-06")
    private String dateOfAccident;
	
	@NotNull
	@Schema(example = "HH:mm:ss")
    private String timeOfAccident;
	
	@NotNull
	@Size(min = 1, max = 25)
    @Schema(allowableValues ={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"})
    private String dayOfAccident;
	
	@NotNull
    private String placeOfAccident;
	@NotNull
    private String natureOfAccident;
	@NotNull
	@Schema(example = "2023-05-05 16:12:10")
    private String dateOfDeath;
	@NotNull
    private String causeOfDeath;
	
	@NotNull
	private String causeOfDeathDisability;
	  
	@NotNull
	@Schema(allowableValues ={"Partial Disability","Total Disability"})
	private String typeOfDisability;
	    
	    
    
    
    
    
    
    
    
    
    @NotNull
	@Size(min = 3, max = 17)
    private String claimantBankAccount;
    
    @NotNull
    private String claimantBank;
    
    @NotNull
	@Size(min = 11, max = 11)
    @Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message="Enter valid IFSc")
    private String claimantIFSC;
    
  

    @NotNull
    @Schema(example = "1993-06-06")
    private String premDebitDate;
    
    @NotNull
    @Schema(example = "1993-06-06")
    private String premRemitDate;
    
    

}
