package com.opl.jns.api.proxy.jansuraksha.common;

import com.opl.jns.api.proxy.common.CommonRequest;
import lombok.Data;

import java.io.Serializable;

@Data
public class RegistryReqProxy  extends CommonRequest implements Serializable {

	private static final long serialVersionUID = 639956830848185125L;

}
