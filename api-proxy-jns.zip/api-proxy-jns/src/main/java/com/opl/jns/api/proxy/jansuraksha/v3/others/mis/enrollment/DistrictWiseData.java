package com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DistrictWiseData implements Serializable {

    private static final long serialVersionUID = -3404528755655149761L;

    @NotNull
    public String districtCode;

    @NotNull
    public Pmsby pmsby;

    @NotNull
    public Pmjjby pmjjby;
}
