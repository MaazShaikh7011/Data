package com.opl.jns.api.proxy.banks.v3.pushEnrollment;

import com.opl.jns.api.proxy.common.pushEnrollment.PushEnrollmentDetailsCommonResponse;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PushEnrollmentDetailsResponseV3 extends PushEnrollmentDetailsCommonResponse {

}
