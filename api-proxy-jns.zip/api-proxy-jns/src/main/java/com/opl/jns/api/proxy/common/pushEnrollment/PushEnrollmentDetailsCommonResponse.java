package com.opl.jns.api.proxy.common.pushEnrollment;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;

@Data
public class PushEnrollmentDetailsCommonResponse extends APIResponseV3 {

}
