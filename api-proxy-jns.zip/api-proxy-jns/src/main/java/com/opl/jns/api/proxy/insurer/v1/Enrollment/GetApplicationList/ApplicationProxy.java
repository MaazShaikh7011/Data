package com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 3/6/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ApplicationProxy implements Serializable {
	
	@NotNull
    private Long applicationReferenceId;
    
    @NotNull
	@Size(min = 21, max = 32)
    private String urn;
    
    @NotNull
    @Schema(allowableValues ={"PMJJBY","PMSBY"})
    private String schemeName;
    
    @NotNull
    private Integer schemeId;

    public ApplicationProxy(Long applicationReferenceId, Integer schemeId, String urn) {
        this.applicationReferenceId = applicationReferenceId;
        this.urn = urn;
        this.schemeId = schemeId;
    }
}
