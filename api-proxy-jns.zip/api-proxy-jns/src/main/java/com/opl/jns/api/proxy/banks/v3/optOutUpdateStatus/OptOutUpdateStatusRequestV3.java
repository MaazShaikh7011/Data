package com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.optOutUpdateStatus.OptOutUpdateStatusCommonRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class OptOutUpdateStatusRequestV3 extends OptOutUpdateStatusCommonRequest {

}
