package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.KycDetailsV1;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class KycDetailsV3 extends KycDetailsV1 implements Serializable {

    private final static long serialVersionUID = 2117216721498264230L; 


}