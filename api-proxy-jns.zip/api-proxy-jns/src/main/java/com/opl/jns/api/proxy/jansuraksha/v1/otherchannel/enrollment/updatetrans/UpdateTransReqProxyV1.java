package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.utils.common.PatternUtils;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class UpdateTransReqProxyV1 extends RegistryReqProxy {

	private final static long serialVersionUID = 1175522787349167241L;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;

	@NotNull
	public Double transactionAmount;

	@NotNull
	@Size(min = 1, max = 100)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_PATTERN, message = "Enter valid masterPolicyNumber")
	public String masterPolicyNumber;

	
	@Size(min = 1, max = 35)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_PATTERN, message = "Enter valid transactionUTR")
	public String transactionUTR;

}