package com.opl.jns.api.proxy.banks.v3.verifyOtp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.common.APIResponseV3;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "status", "message", "flag", "accountHolderDetails" })
@Data
@EqualsAndHashCode(callSuper = false)
public class VerifyOtpApiResponseV3 extends APIResponseV3 implements Serializable {

	private static final long serialVersionUID = 545468798461L;

	@Valid
	@JsonProperty("accountHolderDetails")
	public List<AccountHoldersDetailV3> accountHolderDetails;
	
	@Hidden
	@JsonProperty("flag")
	private Boolean flag;

	public VerifyOtpApiResponseV3() {
		super();
	}

	public VerifyOtpApiResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}