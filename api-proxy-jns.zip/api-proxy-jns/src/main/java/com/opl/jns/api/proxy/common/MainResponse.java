package com.opl.jns.api.proxy.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MainResponse {

	@NotNull
	@Size(min = 0, max = 255)
	@JsonProperty("message")
	private String message;

	@NotNull
	@Schema(example = "200")
	@JsonProperty("status")
	private Integer status;

	@NotNull
	@Size(min = 0, max = 100)
	@JsonProperty("token")
	private String token;

	@Hidden
	@JsonProperty("flag")
	@Schema(allowableValues = { "True", "False" })
	private Boolean flag;

	public MainResponse(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}

	public MainResponse() {
		super();
	}

	public MainResponse(String message, Integer status, String token) {
		super();
		this.message = message;
		this.status = status;
		this.token = token;
	}

}
