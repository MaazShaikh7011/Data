package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class DeDupResProxyV2 extends APIResponseV2 {

	private static final long serialVersionUID = -2091803156199092885L;

	private DeDupDataProxyV2 data;
	
	@Hidden
	@NotNull
	@JsonProperty("flag")
	private Boolean flag;

	public DeDupResProxyV2(String message, int status, Boolean success) {
		super(status,message, success);
	}

	public DeDupResProxyV2(String message, DeDupDataProxyV2 deDupProxy, int status, Boolean success) {
		super(status,message,  success);
		this.data = deDupProxy;
	}
}