package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serial;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class UpdateStatusResProxyV3 extends APIResponseV3 {

	@Serial
	private static final long serialVersionUID = -7495030234502198729L;

	public UpdateStatusResProxyV3(String message, Integer status) {
		super(status,message);
	}

	public UpdateStatusResProxyV3(Integer status,String message, Boolean success) {
		super(status,message, success);
	}
	
	public UpdateStatusResProxyV3() {
		super();
	}

}