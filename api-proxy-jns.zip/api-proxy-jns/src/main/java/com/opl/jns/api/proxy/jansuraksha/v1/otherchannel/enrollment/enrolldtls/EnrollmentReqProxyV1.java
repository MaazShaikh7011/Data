package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EnrollmentReqProxyV1 extends RegistryReqProxy {

	private final static long serialVersionUID = -4357839815853867628L;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;
	public CustomerDetailsV1 customerDetails;
	public KycDetailsV1 kycDetails;
	public GuardianDetailsV1 guardianDetails;
	public NomineeDetailsV1 nomineeDetails;
	public List<InsurerDetailV1> insurerDetails;
	public PolicyDetailsV1 policyDetails;
	public OtherDetailsV1 otherDetails;

}