package com.opl.jns.api.proxy.banks.v1.getCustomerDetails;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.banks.v2.getCustomerDetails.AccountHolderDetailsResponseV1;
import com.opl.jns.api.proxy.utils.APIUtils;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountHolderDetailsResponseV2 extends AccountHolderDetailsResponseV1 {

	@Size(min = 1, max = 50, message = "Invalid First Name. Value must be between 1 to 50 characters.")
	@JsonProperty("firstName")
	private String firstName;

	@Size(min = 1, max = 50, message = "Invalid Middle Name. Value must be between 1 to 50 characters.")
	@JsonProperty("middleName")
	private String middleName;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@JsonProperty("dob")
	@Schema(example = "13/06/1993")
	@ApiModelProperty(notes = "dob", example = APIUtils.DD_MM_YYYY, required = true)
	private LocalDate dob;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = APIUtils.DD_MM_YYYY, required = true)
	@Schema(example = "13/06/2000")
	@JsonProperty("nomineeDateOfBirth")
	private LocalDate nomineeDateOfBirth;

	@Size(min = 1, max = 50, message = "Invalid Last Name. Value must be between 1 to 50 characters.")
	@JsonProperty("lastName")
	private String lastName;
	
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "Invalid Email format. Email ID must be between 5 to 255 alphanumeric characters.")
	@JsonProperty("emailAddress")
	private String emailAddress;

	@Min(value = 1, message = "Invalid City LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid City LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("cityLGDCode")
	private Long cityLGDCode;

	@Min(value = 1, message = "Invalid District LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid District LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("districtLGDCode")
	private Long districtLGDCode;

	@Min(value = 1, message = "Invalid State LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid State LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("stateLGDCode")
	private Long stateLGDCode;

	@Size(min = 1, max = 25, message = "KYC ID2 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@JsonProperty("kycID2")
	private String kycID2;

	@Size(min = 1, max = 100, message = "Invalid kycID2number.  Value must be between 1 to 100 digits.")
	@JsonProperty("kycID2number")
	private String kycID2number;

	@Schema(allowableValues ={"YES","NO"})
	@JsonProperty("ckyc")
	@Pattern(regexp = "Yes|No", flags = Pattern.Flag.CASE_INSENSITIVE, message = "CKYC must be : Yes or No")
	private String ckyc;

	@Size(min = 14, max = 15, message = "Invalid CKYC Number. Value must be between 14 to 15 digits.")
	@JsonProperty("ckycNumber")
	private String ckycNumber;

	@Size(min = 1, max = 50)
	@JsonProperty("nomineeFirstName")
	private String nomineeFirstName;

	@Size(min = 1, max = 50)
	@JsonProperty("nomineeMiddleName")
	private String nomineeMiddleName;

	@Size(min = 1, max = 50)
	@JsonProperty("nomineeLastName")
	private String nomineeLastName;

	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationOfNominee")
	private String relationOfNominee;

	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;

	@Pattern(regexp = "^[6789]\\d{9}",message = "Invalid nominee mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("nomineemobileNumber")
	private String nomineemobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("nomineeEmailAddress")
	private String nomineeEmailAddress;

	@Size(min = 2,max = 200)
	@JsonProperty("nomineeAddressLine1")
	private String nomineeAddressLine1;

	@Size(min = 2,max = 200)
	@JsonProperty("nomineeAddressLine2")
	private String nomineeAddressLine2;

	@Schema(example = "380001")
	@Min(value = 100000, message = "Invalid Nominee Pincode. Value must be of 6-digits.")
	@Max(value = 999999, message = "Invalid Nominee Pincode. Value must be of 6-digits.")
	@JsonProperty("nomineePincode")
	private Integer nomineePincode;

	@Size(min = 2,max = 200)
	@JsonProperty("nomineeCity")
	private String nomineeCity;

	@Min(value = 1, message = "Invalid Nominee City LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid Nominee City LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("nomineeCityLGDCode")
	private Long nomineeCityLGDCode;

	@Size(min = 2,max = 200)
	@JsonProperty("nomineeDistrict")
	private String nomineeDistrict;

	@Min(value = 1, message = "Invalid Nominee District LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid Nominee District LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("nomineeDistrictLGDCode")
	private Long nomineeDistrictLGDCode;

	@Size(min = 2,max = 200)
	@JsonProperty("nomineeState")
	private String nomineeState;

	@Min(value = 1, message = "Invalid Nominee State LGD Code.  Value must be between 1 to 8 digits.")
	@Max(value = 99999999, message = "Invalid Nominee State LGD Code.  Value must be between 1 to 8 digits.")
	@JsonProperty("nomineeStateLGDCode")
	private Long nomineeStateLGDCode;

	@Schema(allowableValues ={"Yes"})
	@Pattern(regexp = "Yes", flags = Pattern.Flag.CASE_INSENSITIVE, message = "consentForAutoDebit must be : Yes")
	@JsonProperty("consentForautodebit")
	private String consentForautodebit;

	@Size(min = 1, max = 10, message = "Invalid RuralUrban. Value must be between 1 to 10 characters.")
	@JsonProperty("ruralUrban")
	private String ruralUrban;
}
