package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatestatus;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate.UpdateStatusReqProxyV1;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateStatusReqProxyV2 extends UpdateStatusReqProxyV1 {

	private final static long serialVersionUID = 1175522787349169651L;
	
	@NotNull
	@Schema(allowableValues = { "6", "7", "8",
			"9" }, description = "6:Opt-Out,7:Account Inactive,8:Insufficient Balance,9:Account Holder Deceased")
	public Integer status;

	@Hidden
//	@JsonProperty("token")
	private String token;

}
