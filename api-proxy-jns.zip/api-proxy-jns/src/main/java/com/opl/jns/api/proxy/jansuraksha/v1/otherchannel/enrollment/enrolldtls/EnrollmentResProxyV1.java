package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class EnrollmentResProxyV1 extends APIResponseV2 {

	private static final long serialVersionUID = 1L;

	private EnrollmentDataResProxyV1 data;
}