package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.dedupe.DeDupReqProxyV1;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class DeDupReqProxyV2 extends DeDupReqProxyV1 {

	private final static long serialVersionUID = -9020492356609251905L;

}
