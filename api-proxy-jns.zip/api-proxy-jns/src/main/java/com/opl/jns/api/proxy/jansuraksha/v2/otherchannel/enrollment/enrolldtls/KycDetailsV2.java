package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.KycDetailsV1;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class KycDetailsV2 extends KycDetailsV1 {

	private final static long serialVersionUID = 2117216421498264230L;
	

	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID2 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Size(min = 1, max = 25)
	public String kycId2;

	@Size(min = 1, max = 100)
	public String kycIdValue2;
	

	@Schema(allowableValues = { "Y", "N", })
	@Pattern(regexp = "Y|N", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid ckyc")
	public String ckyc;

	@Size(min = 14, max = 15)
	public String ckycNumber;


}