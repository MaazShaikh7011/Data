package com.opl.jns.api.proxy.common.pushClaim;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Document implements Serializable {

    @NotNull
//    @Min(1)
    @Schema(allowableValues = {"4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"}, description = "Review Example Description : documentList >>> documentId >>> Enum")
    public Long documentId;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String documentType;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    @Schema(allowableValues ={"pdf"},description = "pdf")
    public String contentType;

    @NotNull
    @NotEmpty
    public byte[] document;

    private final static long serialVersionUID = -2484884962226128489L;

}
