package com.opl.jns.api.proxy.utils;


public enum YesNo {


	YES(1, "Yes","Y"),
	NO(2, "No","N");
		

	private Integer id;
	private String value;
	private final String shortName;

	private YesNo(Integer id, String value, String shortName) {
		this.id = id;
		this.value = value;
		this.shortName = shortName;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getShortName() {
		return shortName;
	}

	public static YesNo fromId(Integer v) {
		for (YesNo c : YesNo.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static YesNo fromShortName(String v) {
		for (YesNo c : YesNo.values()) {
			if (c.shortName.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	public static YesNo fromValue(String v) {
		for (YesNo c : YesNo.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static YesNo[] getAll() {
		return YesNo.values();
	}


}
