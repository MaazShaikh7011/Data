package com.opl.jns.api.proxy.insurer.Exception;

/**
 * @author - Maaz Shaikh
 * @Date - 3/9/2023
 */
public class WebhookApiException extends Exception{
    public WebhookApiException(String message){
        super(message);
    }
    public WebhookApiException(Exception e){
        super(e);
    }
}
