package com.opl.jns.api.proxy.utils;

public class FieldsMaster {

	public static final int URN_MIN = 31;
	public static final int URN_MAX = 32;
	public static final String URN_SAMPLE = "JNS-XXXXXX-XX-XX-XXXXXXXXXXX-XXX";

	public static final int ACC_NUM_MIN = 3;
	public static final int ACC_NUM_MAX = 17;
	public static final String ACC_NUM_SAMPLE = "11111111111";

	public static final int IFSC_NUM_MIN = 11;
	public static final int IFSC_NUM_MAX = 11;
	public static final String IFSC_NUM_SAMPLE = "XXXX000000";

	public static final int CIF_MIN = 3;
	public static final int CIF_MAX = 17;

	public static final int PAN_MIN = 10;
	public static final int PAN_MAX = 10;
	public static final String PAN_SAMPLE = "XXXXX0000X";

	public static final int AADHAR_MIN = 10;
	public static final int AADHAR_MAX = 17;
	public static final String AADHAR_SAMPLE = "000000000000";
	
	public static final int ACC_HOLERNAME_MIN = 1;
	public static final int ACC_HOLERNAME_MAX = 300;
	
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String BANK_SHORT_CODE = "ICI|SBI|HDFC|MAHARASHTRA|CENTRAL|CANARA|UBI|BOB|BOI|IOB|PNB|UCO|IB|PSB|PNB1";
	public static final String BANK_SHORT_CODE_NAME = "ICI-ICICI Bank India, SBI-State Bankof India, HDFC-HDFC Bank India,MAHARASHTRA-Bank of Maharashtra India, CENTRAL-Central Bank of India, CANARA-Canara Bank,UBI-Union Bankof India, BOB-Bank of Baroda India, BOI-Bank of India,IOB-Indian Overseas Bank, PNB-Punjab National Bank India, UCO-UCO Bank India,IB-Indian Bank, PSB-Punjab and Sind Bank,PNB1-Punjab National Bank India1";
	
	private FieldsMaster() {
		super();
	}

	
}
