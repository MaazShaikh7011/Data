package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.NomineeDetailsV1;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NomineeDetailsV3 extends NomineeDetailsV1 implements Serializable {

	private final static long serialVersionUID = -8594198717148041924L;

	@NotNull
	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid nomineeName")
	public String nomineeName;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = FieldsMaster.YYYY_MM_DD, required = true)
	public LocalDate dob;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	public String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine1")
	public String addressOfNominee;

}
