package com.opl.jns.api.proxy.insurer.GetCoiDetails;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;

@Data
public class GetCoiRequest extends CommonRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull
	@Size(min = 3, max = 17)
	private String accountNumber;
    
    @NotNull
	@Size(min = 3, max = 17)
    private String cif;
    
	@NotNull
	@Size(min = 31, max = 32)
    private String urn;
    
//    @NotNull
    @JsonFormat(pattern = APIUtils.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = APIUtils.YYYY_MM_DD, required = true)
    private LocalDate dob;
    
//    @NotNull
//    private String token;

}