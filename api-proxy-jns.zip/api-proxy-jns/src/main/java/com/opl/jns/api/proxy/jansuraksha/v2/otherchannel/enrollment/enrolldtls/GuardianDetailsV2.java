package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.GuardianDetailsV1;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GuardianDetailsV2 extends GuardianDetailsV1 {

	private final static long serialVersionUID = -465472955217893182L;
	
	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid firstName")
	public String firstName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid middleName")
	public String middleName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid lastName")
	public String lastName;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid address")
	public String address;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	public String pincode;


	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	public String email;
	
	@NotNull
	@Size(min = 2, max = 200)
	public String state;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid city")
	public String city;

	@NotNull
	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid district")
	public String district;
}
