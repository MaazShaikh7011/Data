package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;

/***
 * 
 */
public class ClaimDetailsResProxyV2 extends APIResponseV2{

	@Hidden
	@NotNull
	@JsonProperty("flag")
	private Boolean flag;
	
	
	public ClaimDetailsResProxyV2(String message, int status) {
		super(status, message);
	}


	public ClaimDetailsResProxyV2(String message, int status, Boolean success) {
		super(status, message, success);
	}


}
