package com.opl.jns.api.proxy.banks.v1.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountHolderDetails {

	@JsonProperty("cif")
	private String cif;
	
	@JsonProperty("customerAccountNumber")
	private String customerAccountNumber;
	
	@JsonProperty("customerIFSC")
	private String customerIFSC;
	
	@JsonProperty("accountHolderName")
	private String accountHolderName;
	
	@JsonProperty("dob")
	private String dob;
	
	@JsonProperty("gender")
	private String gender;
	
	@JsonProperty("firstName")
	private String firstName;
	
	@JsonProperty("middleName")
	private String middleName;
	
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;
	
	@JsonProperty("mobileNumber")
	private String mobileNumber;
	
	@JsonProperty("emailAddress")
	private String emailAddress;
	
	@JsonProperty("addressline1")
	private String addressline1;
	
	@JsonProperty("addressline2")
	private String addressline2;
	
	@JsonProperty("pincode")
	private String pincode;
	
	@JsonProperty("city")
	private String city;
	
	@JsonProperty("cityLGDCode")
	private String cityLGDCode;
	
	@JsonProperty("district")
	private String district;
	
	@JsonProperty("districtLGDCode")
	private String districtLGDCode;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("stateLGDCode")
	private String stateLGDCode;
	
	@JsonProperty("kycID1")
	private String kycID1;
	
	@JsonProperty("kycID1number")
	private String kycID1number;
	
	@JsonProperty("kycID2")
	private String kycID2;
	
	@JsonProperty("kycID2number")
	private String kycID2number;
	
	@JsonProperty("pan")
	private String pan;
	
	@JsonProperty("panNumber")
	private String panNumber;
	
	@JsonProperty("aadhaar")
	private String aadhaar;
	
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;
	
	@JsonProperty("ckyc")
	private String ckyc;
	
	@JsonProperty("ckycNumber")
	private String ckycNumber;
	
	@JsonProperty("nomineeFirstName")
	private String nomineeFirstName;
	
	@JsonProperty("nomineeMiddleName")
	private String nomineeMiddleName;
	
	@JsonProperty("nomineeLastName")
	private String nomineeLastName;
	
	@JsonProperty("nomineeDateOfBirth")
	private String nomineeDateOfBirth;
	
	@JsonProperty("relationOfNominee")
	private String relationOfNominee;
	
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;
	
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;
	
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;
	
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;
	
	@JsonProperty("guardianEmailId")
	private String guardianEmailId;
	
	@JsonProperty("nomineepan")
	private String nomineepan;
	
	@JsonProperty("nomineepanNumber")
	private String nomineepanNumber;
	
	@JsonProperty("nomineeaadhaar")
	private String nomineeaadhaar;
	
	@JsonProperty("nomineeaadhaarNumber")
	private String nomineeaadhaarNumber;
	
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;
	
	@JsonProperty("nomineeEmailAddress")
	private String nomineeEmailAddress;
	
	@JsonProperty("nomineeAddressLine1")
	private String nomineeAddressLine1;
	
	@JsonProperty("nomineeAddressLine2")
	private String nomineeAddressLine2;
	
	@JsonProperty("nomineePincode")
	private String nomineePincode;
	
	@JsonProperty("nomineeCity")
	private String nomineeCity;
	
	@JsonProperty("nomineeCityLGDCode")
	private String nomineeCityLGDCode;
	
	@JsonProperty("nomineeDistrict")
	private String nomineeDistrict;
	
	@JsonProperty("nomineeDistrictLGDCode")
	private String nomineeDistrictLGDCode;
	
	@JsonProperty("nomineeState")
	private String nomineeState;
	
	@JsonProperty("nomineeStateLGDCode")
	private String nomineeStateLGDCode;
	
	@JsonProperty("consentForENACH")
	private String consentForENACH;
	
	@JsonProperty("dateOfAutoDebit")
	private String dateOfAutoDebit;
	
	@JsonProperty("ruralUrban")
	private String ruralUrban;
}
