package com.opl.jns.api.proxy.banks.v2.premiumDeduction;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "cif", "customerAccountNumber", "insurerCode", "userId", "branchCode", "scheme", "premiumAmount",
		"urn", "mode" })
public class PremiumDeductionRequestV2 extends CommonRequest {

	@NotNull
	@Size(min = 3, max = 17)
	@JsonProperty("cif")
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	@JsonProperty("customerAccountNumber")
	private String customerAccountNumber;

	@NotNull
	@Size(min = 2, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Pattern(regexp = "556|132|115|190|146|142|101|58|143|111|136|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid insurer Code.")
	@JsonProperty("insurerCode")
	private String insurerCode;

	@NotNull
	@Size(min = 1, max = 50)
	@JsonProperty("userId")
	@Schema(example = "25412")
	private String userId;

	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.BRANCH_CODE_PATTERN, message = "Invalid Branch Code")
	@Schema(example = "2541")
	@JsonProperty("branchCode")
	private String branchCode;

	@NotNull
	@Schema(allowableValues ={"PMJJBY","PMSBY"})
	@JsonProperty("scheme")
	private String scheme;

	@NotNull
	@JsonProperty("premiumAmount")
	private Double premiumAmount;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	@JsonProperty("urn")
	private String urn;
	
	@Size(min = 3, max = 25)
	@Schema(allowableValues ={"DIY","Assisted"})
	@JsonProperty("mode")
	private String mode;
	
	/** SBI USE ONLY **/
	@Hidden
	@JsonProperty("SOURCE_ID")
	private String sourceId;
	
	@Hidden
	@JsonProperty("token")
	private String token;
}
