package com.opl.jns.api.proxy.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class APIResponseV1 {
    @NotNull
    @Size(min = 0, max = 255)
    private String message;

    @NotNull
    private Integer status;

    @NotNull
    @Schema(allowableValues = {"True", "False"})
    private Boolean success;

}
