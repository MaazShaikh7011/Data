package com.opl.jns.api.proxy.banks.v3.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = false)
public class CustomerDetailsResponseV3 extends APIResponseV3 {

	@JsonProperty("accountHolderDetails")
	private AccountHolderDetailsV3 accountHolderDetails;
	
	public CustomerDetailsResponseV3() {
		super();
	}

	public CustomerDetailsResponseV3(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
