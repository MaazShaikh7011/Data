//package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//import com.opl.jns.api.proxy.jansuraksha.common.RegCommonResponse;
//import io.swagger.annotations.ApiModelProperty;
//
//import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Size;
//import java.io.Serializable;
//import java.time.LocalDateTime;
//
//public class RegistryResponse extends RegCommonResponse  implements Serializable {
//    @NotNull
//    @JsonFormat(
//            pattern = "yyyy-MM-dd HH:mm:ss"
//    )
//    @ApiModelProperty(
//            notes = "timeStamp",
//            example = "yyyy-MM-dd HH:mm:ss",
//            required = true
//    )
//    private LocalDateTime timestamp;
//    @NotNull
//    @Size(
//            min = 0,
//            max = 100
//    )
//    private String token;
//
//    public void setStatusAndMessageAndSuccess(String message, Integer status, Boolean success) {
//        this.setMessage(message);
//        this.setStatus(status);
//        this.setSuccess(success);
//    }
//
//    public RegistryResponse() {
//    }
//
//    public RegistryResponse(String message, Integer status) {
//        this.setMessage(message);
//        this.setStatus(status);
//    }
//
//    public RegistryResponse(String message, Object data, Integer status) {
//        this.setMessage(message);
//        this.setStatus(status);
//    }
//
//    public RegistryResponse(String message, Object data, Integer status, Boolean success) {
//        this.setMessage(message);
//        this.setStatus(status);
//        this.setSuccess(success);
//    }
//
//    public RegistryResponse(String message, Integer status, Boolean success) {
//        this.setMessage(message);
//        this.setStatus(status);
//        this.setSuccess(success);
//    }
//
//    public RegistryResponse(String message, Integer status, Boolean success, String token, LocalDateTime timeStamp) {
//        this.setMessage(message);
//        this.setStatus(status);
//        this.setSuccess(success);
//        this.setToken(token);
//        this.setTimestamp(timeStamp);
//    }
//
//    public RegistryResponse(String message, Integer status, Boolean success, String token) {
//        this.setMessage(message);
//        this.setStatus(status);
//        this.setSuccess(success);
//        this.setToken(token);
//    }
//
//    public LocalDateTime getTimestamp() {
//        return this.timestamp;
//    }
//
//    public void setTimestamp(LocalDateTime timestamp) {
//        this.timestamp = timestamp;
//    }
//
//    public String getToken() {
//        return this.token;
//    }
//
//    public void setToken(String token) {
//        this.token = token;
//    }
//}
