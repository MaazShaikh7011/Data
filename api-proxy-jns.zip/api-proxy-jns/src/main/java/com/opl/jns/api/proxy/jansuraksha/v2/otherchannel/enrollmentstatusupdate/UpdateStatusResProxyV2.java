package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollmentstatusupdate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate.UpdateStatusResProxyV1;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class UpdateStatusResProxyV2 extends UpdateStatusResProxyV1 {

	@Hidden
	@NotNull
	@JsonProperty("flag")
	private Boolean flag;
	public UpdateStatusResProxyV2(String message, Integer status) {
		super(message, status);
	}

	public UpdateStatusResProxyV2(String message, Integer status, Boolean success) {
		super(message, status, success);
	}

	private static final long serialVersionUID = 1L;
}