package com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class UploadedDocumentsDetailsProxy1_1 implements Serializable {

	private static final long serialVersionUID = 1L;
	@NotNull
	private Long claimReferenceId;
	@NotNull
	@Size(min = 21, max = 32)
	private String urn;
	@NotNull
	private List<DocumentDetailsProxy1_1> documentList;

}
