package com.opl.jns.api.proxy.banks.v2.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = false)
public class CustomerDetailsResponseV2 extends APIResponseV2 {

	@JsonProperty("accountHolderDetails")
	private AccountHolderDetailsV2 accountHolderDetails;

	public CustomerDetailsResponseV2() {
		super();
	}

	public CustomerDetailsResponseV2(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
