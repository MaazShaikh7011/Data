package com.opl.jns.api.proxy.insurer.UpdateDocQuery;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.CommonRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClaimStatusWebhook extends CommonRequest implements Serializable, Cloneable {
	
	private final static long serialVersionUID = -3063362276402351168L;
	
    @NotNull
    @Size(min = 1,max = 100)
    @Min(value = 1, message = "can not be 0")
    public String claimId;

    @NotNull
    @Min(value = 1,message = "can not be 0")
    public Long claimReferenceId;

    @NotNull
    @NotEmpty
    @Size(min = 31,max = 32)
    public String urn;

    @NotNull
    @Min(1)
    @Max(51)
    @Schema(allowableValues ={"7","8","10","11"},description = "7 - Queried ,8 - Rejected,10 - Approved,11 - In process")
    public Integer claimStatus;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String remarks;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String message;
    
	@NotNull
	private String token;

//    @Valid
    @NotNull
    public List<Document> documents;

	public ClaimStatusWebhook(String claimId, Long claimReferenceId, @NotEmpty String urn, Integer claimStatus) {
		super();
		this.claimId = claimId;
		this.claimReferenceId=claimReferenceId;
		this.urn = urn;
		this.claimStatus = claimStatus;
	}
    
	public ClaimStatusWebhook clone() throws CloneNotSupportedException {
		return (ClaimStatusWebhook) super.clone();
	}
    

}