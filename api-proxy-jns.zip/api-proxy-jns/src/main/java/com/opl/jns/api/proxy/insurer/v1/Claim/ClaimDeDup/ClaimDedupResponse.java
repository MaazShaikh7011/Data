package com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDedupResponse extends CommonResponse {
    /**
	 * 
	 */
	private static final long serialVersionUID = -702525101981744183L;
	private ClaimDeDupProxy data;
}
