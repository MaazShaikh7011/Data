package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serial;

/**
 * @author ravi.thummar Date : 14-06-2023
 */

@Data
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class UpdateTransResProxyV3  extends APIResponseV3 {

	@Serial
	private static final long serialVersionUID = 12342334234L;

	private COIDocsProxyV3 coi;

	public UpdateTransResProxyV3(String message, Integer status) {
		super();
		this.setMessage(message);
		this.setStatus(status);
	}

	public UpdateTransResProxyV3(Integer status,String message,boolean flag) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		super.setSuccess(flag);
	}


	public UpdateTransResProxyV3(String message, COIDocsProxyV3 coi, Integer status) {
		super();
		this.setMessage(message);
		this.coi = coi;
		this.setStatus(status);
	}

	public UpdateTransResProxyV3(String message, COIDocsProxyV3 coi, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.coi = coi;
		this.setStatus(status);
		this.setSuccess(success);
	}

	public UpdateTransResProxyV3(String message, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.setStatus(status);
		this.setSuccess(success);
	}

}
