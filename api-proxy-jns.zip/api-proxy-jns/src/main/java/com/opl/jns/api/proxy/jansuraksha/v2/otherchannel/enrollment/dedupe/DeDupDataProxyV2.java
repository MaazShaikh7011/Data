package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.dedupe.DeDupDataProxyV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
public class DeDupDataProxyV2 extends DeDupDataProxyV1 {

	private static final long serialVersionUID = -4342542232341L;

}
