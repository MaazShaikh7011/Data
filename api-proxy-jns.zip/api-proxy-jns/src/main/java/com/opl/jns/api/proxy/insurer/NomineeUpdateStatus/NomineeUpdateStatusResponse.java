package com.opl.jns.api.proxy.insurer.NomineeUpdateStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

import java.time.LocalDateTime;


@Data
@ToString
@JsonPropertyOrder({ "status", "message","sucess", "token", "timeStamp" })
public class NomineeUpdateStatusResponse {

	private static final long serialVersionUID = 1L;

	@NotNull
	private Integer status;

	@NotNull
	@Size(min = 0, max = 255)
	private String message;

//	private Object data;

	@NotNull
	@Schema(allowableValues = { "True", "False" })
	private Boolean success;

//	@NotNull
//	@Schema(allowableValues = { "True", "False" })
//	private Boolean flag;

	@NotNull
	private String token;

	@NotNull
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;
}