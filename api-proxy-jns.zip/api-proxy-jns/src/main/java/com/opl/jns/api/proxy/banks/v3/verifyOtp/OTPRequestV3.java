package com.opl.jns.api.proxy.banks.v3.verifyOtp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author rohit.prajapati
 */

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OTPRequestV3 extends CommonRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;
	
	@NotNull
	@Schema(example = "2024-01-01 - DataType:string($date)")
	private String dob;
	
	@NotNull
	@Size(min = 6, max = 6)
	private String verifyVerificationcode;
	
	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
	
	@Hidden
	private String signVerifiedByBank;
	
	/** SBI USE ONLY **/
	@Hidden
	@JsonProperty("SOURCE_ID")
	private String sourceId;

	public OTPRequestV3() {
		super();
	}

	@Builder
	public OTPRequestV3(Long applicationId, Long orgId, String accountNumber, String dob, String verifyVerificationcode,
			 String urn, String signVerifiedByBank) {
		super(applicationId, orgId);
		this.accountNumber = accountNumber;
		this.dob = dob;
		this.verifyVerificationcode = verifyVerificationcode;
		this.urn = urn;
		this.signVerifiedByBank = signVerifiedByBank;
	}

}
