package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class UpdateStatusReqProxyV1 extends RegistryReqProxy {

	private final static long serialVersionUID = 1175522787349167251L;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;

	@Size(min = 0, max = 255)
	public String reason;

}
