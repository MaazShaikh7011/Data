package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString
public class ClaimDetailDataProxyV3 {

	@NotNull
	@Min(1)
	private Long claimReferenceId;
}
