package com.opl.jns.api.proxy.common.optOutUpdateStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message","success", "token", "timeStamp" })
public class OptOutUpdateStatusCommonResponse extends APIResponseV3 {
	
}
