package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimUploadDocsReqProxyV3 extends RegistryReqProxy {

	private static final long serialVersionUID = 156432424234654L;

	@NotNull
	@NotEmpty
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
	@Min(value = 1, message = "can not be 0")
	private Long claimReferenceId;

	@Size(min = 0, max = 255)
	private String remarks;

//	@NotNull
	@Valid
	private List<ClaimDocumentV3> documentList;

}
