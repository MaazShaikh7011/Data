package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimUploadDocsReqProxyV1 extends RegistryReqProxy implements Serializable {

	private static final long serialVersionUID = 1564654L;

	@NotNull
	@NotEmpty
	@Size(min = 21, max = 50)
	private String urn;

	@NotNull
	@Min(value = 1, message = "can not be 0")
	private Long claimReferenceId;

	@Size(min = 0, max = 255)
	private String remarks;

//	@NotNull
	@Valid
	private List<ClaimDocumentV1> documentList;

}
