package com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode

public class DocumentDetailsProxy implements Serializable {

	private static final long serialVersionUID = 1L;
	@NotNull
	@Size(min = 0, max = 255)
	@Schema(maxLength = 100)
    private String documentType;
	
//	@Schema(maxLength = 30, description = "Applicant ,Co-Applicant")
//    private String type;
	@NotNull
	@Schema(maxLength = 50, description = "pdf")
    private String contentType;
	@NotNull
    private byte[] document;
}
