//package com.opl.jns.api.proxy.banks.v1.getCustomerDetails;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.opl.jns.api.proxy.common.APIResponse;
//import jakarta.validation.Valid;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//@JsonInclude(JsonInclude.Include.NON_EMPTY)
//public class CustomerDetailsData extends APIResponse {
//
//	@Valid
//	@JsonProperty("accountHolderDetails")
//	private AccountHolderDetailsResponseV2 accountHolderDetails;
//
//	public CustomerDetailsData() {
//		super();
//	}
//
//	public CustomerDetailsData(Integer status, String message, Boolean flag) {
//		super(status, message, flag);
//	}
//
//}
