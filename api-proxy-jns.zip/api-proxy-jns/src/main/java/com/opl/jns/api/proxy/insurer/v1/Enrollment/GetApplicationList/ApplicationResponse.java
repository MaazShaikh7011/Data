package com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * @author - Maaz Shaikh
 * @Date - 3/4/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ApplicationResponse extends CommonResponse {

    List<ApplicationProxy> data;

}
