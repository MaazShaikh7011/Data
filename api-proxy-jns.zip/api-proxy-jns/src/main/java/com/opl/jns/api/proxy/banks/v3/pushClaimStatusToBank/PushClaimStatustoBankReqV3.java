package com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank;

import com.opl.jns.api.proxy.common.CommonRequest;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.io.Serializable;

@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class PushClaimStatustoBankReqV3 extends CommonRequest implements Serializable, Cloneable {
	
	private static final long serialVersionUID = 1L;

	@NotNull
	@Min(1)
	private Long claimReferenceId;

	
	@NotNull
	@Size(min = 31,max = 32)
	private String urn;

	@NotNull
	@Size(min = 1,max = 50)
    @Schema(allowableValues ={"7","8","10","11"},description = "7 - Queried ,8 - Rejected,10 - Approved,11 - In process")
	private Integer claimStatus;
	
	private String insurerStatus;
	
	@NotNull
	@Schema(allowableValues  ={ "1", "2", "3",	"4", "5", "6", "7", "8"}, description ="Review Example Description reason >>> Enum")
	private Integer reason;
	
	@NotNull
	@Size(min = 1,max = 100)
	private String claimId;

	private UpdateTransactionRequestV3 transactionDetails;
	
//	
//	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
//	@JsonProperty("accountNumber")
//	private String accountNumber;
	
	public PushClaimStatustoBankReqV3 clone() throws CloneNotSupportedException {
		return (PushClaimStatustoBankReqV3) super.clone();
	}
}
