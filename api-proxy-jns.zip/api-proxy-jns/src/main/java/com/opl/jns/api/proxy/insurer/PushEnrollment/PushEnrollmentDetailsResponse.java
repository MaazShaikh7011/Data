package com.opl.jns.api.proxy.insurer.PushEnrollment;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;


@Data
public class PushEnrollmentDetailsResponse extends APIResponseV3 {

}

