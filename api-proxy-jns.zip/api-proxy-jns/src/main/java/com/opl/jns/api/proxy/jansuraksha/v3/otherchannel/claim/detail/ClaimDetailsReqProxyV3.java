package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.details.ClaimDetailsReqProxyV1;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.api.proxy.utils.YesNo;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class ClaimDetailsReqProxyV3 extends ClaimDetailsReqProxyV1 {

	private static final long serialVersionUID = -5968650250041476263L;

	@NotNull
	@NotEmpty
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
	@Size(min = 2, max = 30)
	@Pattern(regexp = PatternUtils.BRANCH_CODE_PATTERN, message = "Enter valid Branch Code")
	public String branchCode;

	@NotNull
	@Size(min = 2, max = 100)
	public String branchName;

	@NotNull
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String bankBranchEmailId;
	
	@NotNull
	@Size(min = 3, max = 17)
	public String cif;

	@NotNull
	@Size(min = 5, max = 6)
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMSBY|PMJJBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Scheme Name.")
	private String schemeName;

	@NotNull
	@Schema(allowableValues = { "ICI-ICICI Bank India", "SBI-State Bankof India", "HDFC-HDFC Bank India",
			"MAHARASHTRA-Bank of Maharashtra India", "CENTRAL-Central Bank of India", "CANARA-Canara Bank",
			"UBI-Union Bankof India", "BOB-Bank of Baroda India", "BOI-Bank of India",
			"IOB-Indian Overseas Bank", "PNB-Punjab National Bank India", "UCO-UCO Bank India",
			"IB-Indian Bank", "PSB-Punjab and Sind Bank" })
	@Pattern(regexp = "ICI|SBI|HDFC|MAHARASHTRA|CENTRAL|CANARA|UBI|BOB|BOI|IOB|PNB|UCO|IB|PSB", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
	@Size(min = 1, max = 30)
	private String bankCode;

	@NotNull
	@Size(min = 3, max = 17)
	private String customerAccountNumber;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = PatternUtils.IFSC_PATTERN, message = "Invalid IFSC. Enter valid IFSC.")
	private String customerIFSC;

	@NotNull
	@Size(min = 1, max = 300)
	private String accountHolderName;
	
	@NotNull
	@Size(min = 1, max = 150)
	private String fatherHusbandName;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dob", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate dob;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	private String gender;

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	private String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	private String addressline1;

	@Size(min = 2, max = 500)
	private String addressline2;

	@NotNull
	@Schema(example = "382350")
	@Min(value = 100000, message = "Invalid Pincode. Value must be of 6-digits.")
	@Max(value = 999999, message = "Invalid Pincode. Value must be of 6-digits.")
	private Integer pincode;

	@NotNull
	@Size(min = 2, max = 200)
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	private String state;

	@NotNull
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Size(min = 1, max = 25)
	public String kycId1;

	@NotNull
	@Size(min = 1, max = 100)
	public String kycID1number;

	@JsonProperty("pan")
	private YesNo pan;

	@Size(min = 10, max = 10)
	@Pattern(regexp = PatternUtils.PAN_PATTERN, message = "Enter valid pan Number")
	private String panNumber;

	@JsonProperty("aadhaar")
	private YesNo aadhaar;

	@Size(min = 12, max = 12)
	private String aadhaarNumber;

	@JsonProperty("ckyc")
	public YesNo ckyc;

	@Size(min = 14, max = 15)
	public String ckycNumber;

	@NotNull
	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid nomineeName")
	private String nomineeName;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "nomineeDateOfBirth", example = FieldsMaster.YYYY_MM_DD, required = true)
	public LocalDate nomineeDateOfBirth;
	
	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	private String nomineeGender;

	@NotNull
	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid addressLine1")
	public String addressOfNominee;

	@NotNull
	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Nominee Relationship. Please check Nominee relationship.")
	public String relationshipOfNominee;

	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid correctNomineeName")
	private String correctNomineeName;

	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid nameofGuardian")
	public String nameofGuardian;

	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid address")
	public String addressofGuardian;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Size(min = 1, max = 50)
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Guardian Relationship. Please check Guardian relationship.")
	public String relationShipOfGuardian;

	@Size(min = 1, max = 300)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid claimantName")
	private String claimantName;

	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "claimantDateOfBirth", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate claimantDateOfBirth;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Claimant Relationship. Please check Claimant relationship.")
	@Size(min = 1, max = 50)
	private String relationshipOfClaimant;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String claimantMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "claimantEmailId not in format")
	private String claimantEmailId;

	@Size(min = 2, max = 500)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid address")
	public String claimantAddress;

	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	public String claimantGender;

	@Pattern(regexp = "Natural Death/Non Accidental|Accidental death within 30 days of lien period|Suicide", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid causeOfDeath: Natural Death/Non Accidental,Accidental death within 30 days of lien period,Suicide")
	@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental death within 30 days of lien period","Suicide" })
	private String causeOfDeath;
	
	@Pattern(regexp = "Natural Death/Non Accidental|Accidental|Suicide", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid cause Of Death Disability: Natural Death/Non Accidental,Accidental,Suicide")
	@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental", "Suicide" })
	private String causeOfDeathDisability;
	
	@Pattern(regexp = "Partial permanent|Total permanent", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid type of disability :Partial permanent OR Total permanent")
	@Schema(allowableValues = { "Partial permanent", "Total permanent" })
	private String typeOfDisability;


	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "dateOfAccident", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate dateOfAccident;
	
	@Schema(example = "HH:mm:ss")
	@Pattern(regexp = PatternUtils.TIME_PATTERN, message = "Invalid timeOfAccident format, must be HH:mm:ss")
	private String timeOfAccident;

	
	private String placeOfOccurence;
	
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "dateOfDeath", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime dateOfDeath;

	@NotNull
	@Size(min = 3, max = 17)
	private String claimantBankAccountNumber;

	@NotNull
	@Size(min = 2, max = 50)
	private String claimantBankName;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = PatternUtils.IFSC_PATTERN, message = "Enter valid IFSc")
	private String claimantBranchIFSC;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "premDebitDate", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate premDebitDate;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "premRemitDate", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate premRemitDate;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD)
	@ApiModelProperty(notes = "DateOfLoadingClaim", example = FieldsMaster.YYYY_MM_DD, required = true)
	private LocalDate dateOfLodgingClaim;
	
//	@NotNull
//	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
//    @ApiModelProperty(notes = "firstEnrollmentDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
//	private LocalDateTime firstEnrollmentDate;
	
	@NotNull
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Size(min = 2, max = 17)
	@Pattern(regexp = "556|132|115|190|146|142|101|143|58|136|111|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
	public String insurerCode;
	
	@NotNull
	public String token;


}
