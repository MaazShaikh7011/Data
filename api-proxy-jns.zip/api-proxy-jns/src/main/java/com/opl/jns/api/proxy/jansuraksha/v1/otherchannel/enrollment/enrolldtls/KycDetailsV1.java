package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class KycDetailsV1 implements Serializable {

	private final static long serialVersionUID = 2117216721498264230L;

	@NotNull
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Size(min = 1, max = 25)
	public String kycId1;

	@NotNull
	@Size(min = 1, max = 100)
	public String kycIdValue1;


	@Size(min = 10, max = 10)
	public String panNumber;

	@Size(min = 12, max = 12)
	public String aadhaarNumber;

}