package com.opl.jns.api.proxy.insurer.UpdateDocQuery;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class PushClaimStatustoInsurerRes extends APIResponseV3 implements Serializable  {
	
    private static final long serialVersionUID = 1L;

    public PushClaimStatustoInsurerRes(String message,Integer status){
        super(status, message);
    }

    public PushClaimStatustoInsurerRes(String message,Integer status,Boolean success ){
        super(status, message,success);
    }
}
