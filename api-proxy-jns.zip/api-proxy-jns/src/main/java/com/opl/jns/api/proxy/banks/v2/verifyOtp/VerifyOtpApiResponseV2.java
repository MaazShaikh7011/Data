package com.opl.jns.api.proxy.banks.v2.verifyOtp;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.utils.APIUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "status", "message", "flag", "accountHolderDetails" })
@Data
@EqualsAndHashCode(callSuper = false)
public class VerifyOtpApiResponseV2 extends APIResponseV2 implements Serializable {

	private static final long serialVersionUID = 545468798461L;

	@Valid
	@JsonProperty("accountHolderDetails")
	public List<AccountHoldersDetailV2> accountHolderDetails;
	
	@Hidden
	@JsonProperty("token")
	private String token;
	
	@NotNull
	@Schema(allowableValues ={"true","false"})
	@JsonProperty("flag")
	private Boolean flag;
	
	@Hidden
	@JsonProperty("timestamp")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "timestamp", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timestamp;
	
	@Hidden
	@JsonProperty("success")
	private Boolean success;

	public VerifyOtpApiResponseV2() {
		super();
	}

	public VerifyOtpApiResponseV2(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}