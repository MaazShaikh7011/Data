package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus;

import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serial;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString
public class ClaimStatusUpdateResProxyV3 extends APIResponseV3 {

	@Serial
	private static final long serialVersionUID = -2118048602852128769L;

	public ClaimStatusUpdateResProxyV3(String message,Boolean success, Integer status) {
		super(status,message, success);
	}

	public ClaimStatusUpdateResProxyV3(String message, Integer status) {
		super(status,message);
	}

	public ClaimStatusUpdateResProxyV3() {
		super();
	}


}
