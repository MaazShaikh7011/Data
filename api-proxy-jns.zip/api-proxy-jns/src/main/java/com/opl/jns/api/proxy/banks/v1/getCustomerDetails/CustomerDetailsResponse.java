//package com.opl.jns.api.proxy.banks.v1.getCustomerDetails;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.opl.jns.api.proxy.common.APIResponse;
//import io.swagger.v3.oas.annotations.media.Schema;
//import jakarta.validation.constraints.NotNull;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//
//@Data
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@EqualsAndHashCode(callSuper = false)
//public class CustomerDetailsResponse extends APIResponse {
//
//	@JsonProperty("accountHolderDetails")
//	private AccountHolderDetails accountHolderDetails;
//
//	@NotNull
//	@Schema(allowableValues = {"True", "False"})
//	@JsonProperty("flag")
//	private Boolean flag;
//
//	public CustomerDetailsResponse() {
//		super();
//	}
//
//	public CustomerDetailsResponse(Integer status, String message, Boolean flag) {
//		super(status, message, flag);
//	}
//
//}
