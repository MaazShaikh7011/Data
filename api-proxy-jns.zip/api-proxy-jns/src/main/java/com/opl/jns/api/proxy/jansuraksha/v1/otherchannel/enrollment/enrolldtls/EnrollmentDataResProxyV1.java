package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnrollmentDataResProxyV1 implements Serializable {

	private final static long serialVersionUID = 6208189995076386414L;

	@NotNull
	@Schema(allowableValues = { "True", "False" })
	public Boolean deDupeStatus;
	@NotNull
	@Size(min = 0, max = 255)
	public String deDupeMsg;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;
}