package com.opl.jns.api.proxy.banks.v3.getAccHolderList;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.utils.APIUtils;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AccHolderDetailsV3 {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	@NotNull
	@Size(min = FieldsMaster.ACC_HOLERNAME_MIN, max = FieldsMaster.ACC_HOLERNAME_MAX)
	private String accountHolderName;

	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	private String urn;

	@NotNull
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "policyInceptionDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime policyInceptionDate;

	@NotNull
	@Size(min = 5, max = 6)
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	private String scheme;

	public AccHolderDetailsV3() {
		super();
	}

}
