package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.COIDocsProxyV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString
@NoArgsConstructor
public class COIDocsProxyV3 extends COIDocsProxyV1 {

	private static final long serialVersionUID = 4400745662685144324L;
	

	public COIDocsProxyV3(String documentType, String contentType, byte[] document) {
		super(documentType, contentType, document);
	}
}
