package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UpdateTransReqProxyV3 extends UpdateTransReqProxyV1 {

	private final static long serialVersionUID = 1175522787349167241L;


	@NotNull
	@Schema(allowableValues =  {"1,2,3,4,5,6,7,8" }, description = """
			1-Successful Debit,\
			2-Error (Due to API failure) ,\
			3-Balance insufficient, \
			4-Account Closed, \
			5-Account Dormant,\
			6-Account Frozen, \
			7-No debit Account, \
			8-No debit due to other reason\
			""")
	@Pattern(regexp = "1|2|3|4|5|6|7|8", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid debit status.")
	private String debitStatus;
	
	
	@JsonFormat(pattern = FieldsMaster.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "transactionTimeStamp", example = FieldsMaster.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime transactionTimeStamp;
	
	@NotNull
	@Size(min = 2, max = 17)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Pattern(regexp = "556|132|115|190|146|142|101|143|58|136|111|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
	public String insurerCode;
	
	@NotNull
	@Schema(allowableValues = { "1" }, description = "1:New Enrolment")
	@Pattern(regexp = "1", flags = Pattern.Flag.CASE_INSENSITIVE, message = "TransactionType must be : 1:New Enrolment")
	public String transactionType;
	
//	@NotNull
//	public String token;

}
