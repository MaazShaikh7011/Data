package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.EnrollmentDataResProxyV1;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
public class EnrollmentDataResProxyV2 extends EnrollmentDataResProxyV1 {

	private final static long serialVersionUID = 6208189995076386314L;

	public EnrollmentDataResProxyV2(Boolean deDupeStatus, String deDupeMsg, String urn) {
		super(deDupeStatus, deDupeMsg, urn);
	}

}