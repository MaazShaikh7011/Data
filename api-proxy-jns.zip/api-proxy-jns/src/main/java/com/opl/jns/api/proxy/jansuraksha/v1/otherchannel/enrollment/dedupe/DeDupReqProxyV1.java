package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.dedupe;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DeDupReqProxyV1 extends RegistryReqProxy {

	private final static long serialVersionUID = -9020492356609251905L;

	@NotNull
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Size(min = 1, max = 25)
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	public String kycId1;

	@NotNull
	@Size(min = 1, max = 100)
	public String kycIdValue1;

	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Size(min = 1, max = 25)
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC ID2 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	public String kycId2;

	@Size(min = 1, max = 100)
	public String kycIdValue2;

	@Size(min = 14, max = 15)
	public String ckycNumber;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@Pattern(regexp = "M|F|T", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	public String gender;

	@NotNull
	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid firstName")
	public String firstName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid middleName")
	public String middleName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid lastName")
	public String lastName;

	@NotNull
	@Size(min = 1, max = 150)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid fatherHusbandName")
	public String fatherHusbandName;

	// @NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	public String mob;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	public String pincode;

	@NotNull
	@Schema(example = "13/06/2000")
	public String dob;

	@NotNull
	public String bankCode;

	@NotNull
	@Size(min = 3, max = 17)
	public String accNo;

	@NotNull
	@Schema(allowableValues = { "PMJJBY", "PMSBY" })
	@Pattern(regexp = "PMSBY|PMJJBY", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Scheme")
	public String scheme;

	@NotNull
	@Schema(allowableValues = { "A", "I" }, description = "A:Active,I:INACTIVE")
	@Pattern(regexp = "A|I", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid account status")
	public String accountStatus;

	@NotNull
	@Schema(allowableValues = { "E", "C", "R" }, description = "E:ENROLLMENT,C:CLAIM,R:Renewal")
	@Pattern(regexp = "E|C|R", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid type")
	public String type;

	@NotNull
	@Size(min = 3, max = 17)
	public String cif;

	@Size(min = 21, max = 32)
	public String urn;

	@Hidden
	private String token;

}