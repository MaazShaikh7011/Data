package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs;

public class Test {

}
