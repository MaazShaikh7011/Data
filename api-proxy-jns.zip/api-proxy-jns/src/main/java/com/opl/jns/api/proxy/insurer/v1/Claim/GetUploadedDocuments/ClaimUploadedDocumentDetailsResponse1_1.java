package com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@NoArgsConstructor
@ToString
public class ClaimUploadedDocumentDetailsResponse1_1 extends CommonResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private UploadedDocumentsDetailsProxy1_1 data;
}
