package com.opl.jns.api.proxy.banks.v3.pushEnrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.pushEnrollment.PushEnrollmentDetailsCommonRequest;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class PushEnrollmentDetailsRequestV3 extends PushEnrollmentDetailsCommonRequest {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    /* INTERNAL USE ONLY */
	@Hidden
    private Integer failureCount;


}
