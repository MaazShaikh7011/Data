package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.details.ClaimDetailsReqProxyV1;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDetailsReqProxyV2 extends ClaimDetailsReqProxyV1 implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotNull
	@NotEmpty
	private String urn;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid correctNomineeFirstName")
	private String correctNomineeFirstName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid correctnomineeMiddleName")
	private String correctnomineeMiddleName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid correctnomineeLastName")
	private String correctnomineeLastName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid claimantFirstName")
	private String claimantFirstName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid claimantMiddleName")
	private String claimantMiddleName;

	@Size(min = 1, max = 50)
	@Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED, message = "Enter valid claimantLastName")
	private String claimantLastName;

	@Schema(example = "1993-06-06")
	private String claimantDateOfBirth;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Pattern(regexp = "Father|Mother|Son|Daughter|Uncle|Aunt|Brother|Sister|Grand father|Wife|Nephew|Niece|Husband|Grand mother|Grand son|Grand daughter|Mother in law|Father in law|Brother in law|Sister in law|Others", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Invalid Claimant Relationship. Please check Claimant relationship.")
	private String relationOfClaimant;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String claimantMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	@Pattern(regexp = "[a-z0-9]+@[a-z]+\\.[a-z]{2,3}", message = "email not in format")
	private String claimantEmailId;

	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "claimantKYC2 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Size(min = 1, max = 25)
	private String claimantKYC2;

	@Size(min = 1, max = 100)
	private String claimantKycNumber2;

	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid claimantAddressLine1")
	private String claimantAddressLine1;

	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid claimantAddressLine2")
	private String claimantAddressLine2;

	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid claimantCity")
	private String claimantCity;

	@Size(min = 2, max = 200)
	@Pattern(regexp = PatternUtils.ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN, message = "Enter valid claimantDistrict")
	private String claimantDistrict;

	@Size(min = 2, max = 200)
	private String claimantState;

	@Schema(example = "382350")
	@Min(100000)
	@Max(999999)
	private Integer claimantPincode;

	@Schema(example = "1993-06-06")
	private String dateOfAccident;
	
	@Schema(example = "HH:mm:ss")
	private String timeOfAccident;

	private String placeOfAccident;

	@Pattern(regexp = "Disability|Death", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid nature of accident: Disability OR Death")
	@Schema(allowableValues = { "Disability", "Death" })
	private String natureOfAccident;

	@Schema(example = "2023-05-05 16:12:10")
	private String dateOfDeath;

	@Pattern(regexp = "Death|Accidental death within 30 days of lien period", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid causeOfDeath disability Death|Accidental death within 30 days of lien period")
	@Schema(allowableValues = { "Death|Accidental death within 30 days of lien period" })
	private String causeOfDeath;

	@Pattern(regexp = "Accidental", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid cause Of Death Disability disability Accidental")
	@Schema(allowableValues = { "Accidental" })
	private String causeOfDeathDisability;


	@NotNull
	@Size(min = 3, max = 17)
	private String claimantBankAccount;

	@NotNull
	@Size(min = 2, max = 100)
	private String claimantBank;

	@NotNull
	@Size(min = 11, max = 11)
	@Pattern(regexp = PatternUtils.IFSC_PATTERN, message = "Enter valid IFSc")
	private String claimantIFSC;
	
	@Hidden
//	@JsonProperty("token")
	private String token;

}
