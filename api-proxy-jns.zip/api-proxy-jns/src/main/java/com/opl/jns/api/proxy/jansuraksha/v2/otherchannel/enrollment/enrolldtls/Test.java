package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

public class Test {

}
