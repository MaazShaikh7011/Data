package com.opl.jns.api.proxy.jansuraksha.v2.others;

public class Test {

}
