package com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author - Maaz Shaikh
 * @Date - 3/4/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDetailsResponse extends CommonResponse {

    ClaimDetailsProxy data;

}
