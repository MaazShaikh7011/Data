package com.opl.jns.api.proxy.banks.v2.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import com.opl.jns.utils.common.PatternUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AccountHolderDetailsResponseV1 {


	@NotNull(message = "CIF of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX, message = "Invalid CIF. Value must be between 3 to 17 digits.")
	@JsonProperty("cif")
	private String cif;

	@NotNull(message = "CustomerIFSC of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX, message = "Invalid IFSC. Value must be of 11-digits.")
	@Pattern(regexp = PatternUtils.IFSC_PATTERN, message = "Invalid IFSC")
	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
	@JsonProperty("customerIFSC")
	private String customerIFSC;

	@NotNull(message = "AccountHolderName of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 300, message = "Invalid Account Holder Name. Value must be between 1 to 300 characters.")
	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@NotNull(message = "Gender of the selected A/C holder is not found in the Bank CBS.")
	@Pattern(regexp = "[MFT]", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	@Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
	@JsonProperty("gender")
	private String gender;

	@NotNull
	@Size(min = 1, max = 150, message = "Invalid Father/Husband Name. Value must be between 1 to 150 characters.")
	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;

	@Size(min = 10, max = 10, message = "Invalid Mobile Number. Mobile Number must be of 10-digits.")
	@Pattern(regexp = PatternUtils.MOBILE_NO_PATTERN, message = "Invalid Mobile Number. Mobile Number must be of 10-digits.")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@NotNull(message = "Addressline1 of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 500, message = "Invalid Addressline1. Value must be between 2 to 500 alphanumeric characters.")
	@JsonProperty("addressline1")
	private String addressline1;

	@Size(min = 2, max = 500, message = "Invalid addressline2. Value must be between 2 to 500 alphanumeric characters.")
	@JsonProperty("addressline2")
	private String addressline2;

	@NotNull(message = "Pincode of the selected A/C holder is not found in the Bank CBS.")
	@Min(value = 100000, message = "Invalid Pincode. Value must be of 6-digits.")
	@Max(value = 999999, message = "Invalid Pincode. Value must be of 6-digits.")
	@Schema(example = "382350")
	@JsonProperty("pincode")
	private Long pincode;

	@NotNull(message = "City of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200, message = "Invalid City. Value must be between 2 to 200 characters.")
	@JsonProperty("city")
	private String city;

	@NotNull(message = "District of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200, message = "Invalid District. Value must be between 2 to 200 characters.")
	@JsonProperty("district")
	private String district;

	@NotNull(message = "State of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 2, max = 200, message = "Invalid State. Value must be between 2 to 200 characters.")
	@JsonProperty("state")
	private String state;

	@NotNull(message = "KYC ID1 of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 25, message = "KYC ID1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@JsonProperty("kycID1")
	private String kycID1;

	@NotNull(message = "KYC ID1 Number of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 100, message = "Invalid kycID1number.  Value must be between 1 to 100 digits.")
	@JsonProperty("kycID1number")
	private String kycID1number;

	@JsonProperty("pan")
	@Pattern(regexp = "Yes|No|N|Y", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Pan must be : Yes or No")
	private String pan;

	@Schema(example = FieldsMaster.PAN_SAMPLE)
	@Size(min = FieldsMaster.PAN_MIN, max = FieldsMaster.PAN_MAX, message = "Invalid Pan Number. Pan Number must be a 10-character alphanumeric value.")
	@Pattern(regexp = PatternUtils.PAN_PATTERN, message = "Invalid Pan Number. Pan Number must be a 10-character alphanumeric value.")
	@JsonProperty("panNumber")
	private String panNumber;

	@JsonProperty("aadhaar")
	@Pattern(regexp = "Yes|No|N|Y", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Aadhaar must be : Yes or No")
	private String aadhaar;

	@Size(min = 12, max = 12, message = "Invalid Aadhaar Number. Value must be of 12-digits.")
	@JsonProperty("aadhaarNumber")
	@Pattern(regexp = PatternUtils.AADHAR_PATTERN, message = "Invalid Aadhaar Number. Value must be of 12-digits.")
	private String aadhaarNumber;

	@Size(min = 1, max = 300)
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	@Size(min = 2, max = 500)
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	@Pattern(regexp = "^[6789]\\d{9}",message = "Invalid Guardian mobile number. Value must be of 10-digits.")
	@Size(min = 10,max = 10)
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("guardianEmailId")
	private String guardianEmailId;


}

