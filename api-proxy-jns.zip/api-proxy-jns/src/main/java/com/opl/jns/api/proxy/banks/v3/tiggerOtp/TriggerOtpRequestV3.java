package com.opl.jns.api.proxy.banks.v3.tiggerOtp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.utils.FieldsMaster;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "accountNumber", "dob", "urn" })
public class TriggerOtpRequestV3 extends CommonRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@JsonProperty("accountNumber")
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	@NotNull
	@JsonProperty("dob")
	@Schema(example = "2024-01-01 - DataType:string($date)")
	private String dob;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@JsonProperty("urn")
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;

	/** SBI USE ONLY **/
	@Hidden
	@JsonProperty("SOURCE_ID")
	private String sourceId;
}
