package com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GetClaimDocumentRequest implements Serializable {

    private static final long serialVersionUID = 1111111L;

    @NotNull
    @Schema(required = true)
	@Min(value = 1,message = "can not be 0")
    private Long claimReferenceId;


    @Schema(allowableValues = {
			"4 - Signed and dully filled Claim cum discharge Form *",
			"5 - Death Certificate *",
			"6 - Hospital Discharge Summary *",
			"7 - Certificate issued by last attending Registered Medical Practitioner *",
			"8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *",
			"9 - FIR/Panchnama *",
			"10 - Hospital Records with deceased complete details *",
			"11 - KYC of Insured member *",
			"12 - KYC of Nominee/Claimant *",
			"13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *",
			"14 - Nominee Death Certificate *",
			"15 - Legal Heir Certificate *",
			"16 - Others *",
			"17 - Disability Certificate issued by Civil Surgeon *",
			"18 - Hospital records supporting the disability *",
			"19 - Checklist  *",
			"20 - Copy of Passbook of Insured *",
			"21 - Post mortem Report *",
			"22 - Aadhar/PAN of Nominee/Claimant *",
			"23 - Aadhar/PAN of Insured Member *"},
            description = "This is an optional parameter. It is used fetch specific document(s) from list of document for respective application by providing respective documentid(s) in parameter. Note : * indicates mandatory document, which would be always available for any application.")
    private List<Long> documentId;
}
