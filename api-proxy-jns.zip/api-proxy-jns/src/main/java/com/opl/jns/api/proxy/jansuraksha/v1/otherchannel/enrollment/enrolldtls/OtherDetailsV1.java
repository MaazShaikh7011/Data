package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author - Maaz Shaikh
 * @Date - 05/08/2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtherDetailsV1 implements Serializable {

	private final static long serialVersionUID = 9220963440239073079L;



	@NotNull
	@Schema(allowableValues = { "Yes" })
	@Pattern(regexp = "Yes", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Consent for Auto- debit must be : Yes")
	public String consentForAutoDebit;
	
	public String userId2;


}