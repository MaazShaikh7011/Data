package com.opl.jns.api.proxy.banks.v2.getCustomerDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.AccountHolderDetails;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountHolderDetailsV2 extends AccountHolderDetails {

	@JsonProperty("cif")
	private String cif;

	@JsonProperty("customerIFSC")
	private String customerIFSC;

	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;

	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@JsonProperty("addressline1")
	private String addressline1;

	@JsonProperty("addressline2")
	private String addressline2;

	@JsonProperty("pincode")
	private String pincode;

	@JsonProperty("city")
	private String city;

	@JsonProperty("district")
	private String district;

	@JsonProperty("state")
	private String state;

	@JsonProperty("kycID1")
	private String kycID1;

	@JsonProperty("kycID1number")
	private String kycID1number;

	@JsonProperty("pan")
	private String pan;

	@JsonProperty("panNumber")
	private String panNumber;

	@JsonProperty("aadhaar")
	private String aadhaar;

	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;

	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;

	@JsonProperty("guardianEmailId")
	private String guardianEmailId;
	
	@JsonProperty("consentForAutoDebit")
	private String consentForAutoDebit;
}
