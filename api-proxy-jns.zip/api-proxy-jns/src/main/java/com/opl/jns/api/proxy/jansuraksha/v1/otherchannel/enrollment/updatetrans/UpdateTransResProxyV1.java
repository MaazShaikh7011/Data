package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class UpdateTransResProxyV1 extends RegistryResponse {

	private static final long serialVersionUID = 1L;
	private COIDocsProxyV1 coi;

	public UpdateTransResProxyV1(String message, Integer status) {
		super(message, status);
	}

	public UpdateTransResProxyV1(String message, COIDocsProxyV1 coi, Integer status) {
		super(message, status);
		this.coi = coi;
	}

	public UpdateTransResProxyV1(String message, COIDocsProxyV1 coi, Integer status, Boolean success) {
		super(message, status, success);
		this.coi = coi;
	}

	public UpdateTransResProxyV1(String message, Integer status, Boolean success) {
		super(message, status, success);
	}
}