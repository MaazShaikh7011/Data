package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author ravi.thummar Date : 14-06-2023
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateTransResProxyV2 extends APIResponseV2 {
	private static final long serialVersionUID = 1L;

	private COIDocsProxyV2 coi;
	
	@Hidden
	@NotNull
	@JsonProperty("flag")
	private Boolean flag;

	public UpdateTransResProxyV2(String message, Integer status) {
		super(status,message);
	}

	public UpdateTransResProxyV2(String message, COIDocsProxyV2 coi, Integer status) {
		super(status,message);
		this.coi = coi;
	}

	public UpdateTransResProxyV2(String message, COIDocsProxyV2 coi, Integer status, Boolean success) {
		super(status,message,success);
		this.coi = coi;
	}

	public UpdateTransResProxyV2(String message, Integer status, Boolean success) {
		super(status,message,success);
	}
}
