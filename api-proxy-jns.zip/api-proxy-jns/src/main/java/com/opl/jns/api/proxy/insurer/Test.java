package com.opl.jns.api.proxy.insurer;

public class Test {

}
