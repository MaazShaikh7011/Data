package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.details;

import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDetailsReqProxyV1 extends RegistryReqProxy implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	@Pattern(regexp = "YES|NO", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid nomineeNameCorrection YES|NO")
	@Schema(allowableValues = { "YES", "NO" })
	private String nomineeNameCorrection;

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String nomineeMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "nomineeEmailId not in format")
	private String nomineeEmailId;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String guardianMobileNumber;
	               

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "guardianEmailId not in format")
	private String guardianEmailId;

	@NotNull
	@Pattern(regexp = "YES|NO", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid isNomineePredeceased YES|NO")
	@Schema(allowableValues = { "YES", "NO" })
	private String isNomineePredeceased;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String claimantMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	@Pattern(regexp = PatternUtils.EMAIL_PATTERN, message = "claimantEmailId not in format")
	private String claimantEmailId;

	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	@Pattern(regexp = "AADHAR|PAN|VOTERID|DRIVINGL|PASSPORT|MGNREGA", flags = Pattern.Flag.CASE_INSENSITIVE, message = "claimantKYC1 must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA")
	private String claimantKYC1;

	@NotNull
	@Size(min = 1, max = 100)
	private String claimantKYCNumber1;
	
	@Size(min = 1, max = 25)
	@Pattern(regexp = "Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid day of accident Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday")
	@Schema(allowableValues = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" })
	private String dayOfAccident;

	@Pattern(regexp = "Disability|Death", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid nature of accident: Disability OR Death")
	@Schema(allowableValues = { "Disability", "Death" })
	private String natureOfAccident;

	@Pattern(regexp = "Partial Disability|Total Disability", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid type of disability :Partial Disability OR Total Disability")
	@Schema(allowableValues = { "Partial Disability", "Total Disability" })
	private String typeOfDisability;

}
