package com.opl.jns.api.proxy.banks.v1;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class Response400 {

	@Schema(example = "It seems that request is not properly formed.")
	private String message;

	@Schema(example = "400")
	private Integer status;

	@Schema(example = "false")
	private Boolean success;

	@Hidden
	@Schema(example = "false")
	private Boolean flag;


	@Hidden
	public static final String PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"status\":400,\"success\":false}";

	// for webhook
	@Hidden
	public static final String WB_PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"status\":400,\"success\":false}";

}
