package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.uploaddocs.ClaimDocumentV1;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class ClaimDocumentV3 extends ClaimDocumentV1 implements Serializable {

	private static final long serialVersionUID = 14546234325468L;
	
	@Hidden
	private String token;

}
