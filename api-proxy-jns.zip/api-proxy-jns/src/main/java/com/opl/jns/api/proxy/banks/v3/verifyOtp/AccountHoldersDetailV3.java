package com.opl.jns.api.proxy.banks.v3.verifyOtp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.api.proxy.utils.FieldsMaster;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
        "accountHolderName",
        "cif",
        "dob",
        "gender",
        "PMJJBYexists",
        "PMSBYexists",
        "KYCUpdated"
})

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountHoldersDetailV3 {

	@NotNull(message = "Account Holder Name of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = 1, max = 300,message = "Invalid Account Holder Name. Value must be between 1 to 300 characters.")
    private String accountHolderName;
	
	@NotNull(message = "CIF of the selected A/C holder is not found in the Bank CBS.")
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX,message = "Invalid CIF. Value must be between 3 to 17 digits.")
    private String cif;
	
	@NotNull(message = "DOB of the selected A/C holder is not found in the Bank CBS.")
	@Schema(example = "2024-01-01 - DataType:string($date)")
    private String dob;
	
	@NotNull(message = "Gender of the selected A/C holder is not found in the Bank CBS.")
	@Pattern(regexp = "[MFT]", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Gender must be: M for Male, F for Female, or T for Transgender.")
	@Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
    private String gender;
	
	@NotNull(message = "PMJJBY exists of the selected A/C holder is not found in the Bank CBS.")
	@Pattern(regexp = "Yes|No|N|Y", flags = Pattern.Flag.CASE_INSENSITIVE, message = "PMJJBY exists must be : Yes or No")
	@Schema(allowableValues ={"YES","NO","N","Y"})
    @JsonProperty("PMJJBYexists")
    private String PMJJBYexists;
	
	@NotNull(message = "PMSBY exists of the selected A/C holder is not found in the Bank CBS.")
	@Pattern(regexp = "Yes|No|N|Y", flags = Pattern.Flag.CASE_INSENSITIVE, message = "PMSBY exists must be : Yes or No")
	@Schema(allowableValues ={"YES","NO","N","Y"})
    @JsonProperty("PMSBYexists")
    private String PMSBYexists;
	
	@NotNull(message = "KYC updated exists of the selected A/C holder is not found in the Bank CBS.")
	@Pattern(regexp = "Yes|No|N|Y", flags = Pattern.Flag.CASE_INSENSITIVE, message = "KYC updated exists must be : Yes or No")
	@Schema(allowableValues ={"YES","NO","N","Y"})
    @JsonProperty("KYCUpdated")
    private String KYCUpdated;
}

