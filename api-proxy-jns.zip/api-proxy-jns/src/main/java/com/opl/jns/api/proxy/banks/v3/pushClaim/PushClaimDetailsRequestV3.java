package com.opl.jns.api.proxy.banks.v3.pushClaim;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.pushClaim.PushClaimDetailsCommonRequest;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PushClaimDetailsRequestV3 extends PushClaimDetailsCommonRequest {

}
