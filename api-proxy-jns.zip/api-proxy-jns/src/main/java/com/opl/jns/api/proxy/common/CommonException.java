package com.opl.jns.api.proxy.common;

/**
 * @author - Maaz Shaikh
 * @Date - 3/9/2023
 */
public class CommonException extends Exception {
	public CommonException(String message) {
		super(message);
	}

	public CommonException(Exception e) {
		super(e);
	}
}
