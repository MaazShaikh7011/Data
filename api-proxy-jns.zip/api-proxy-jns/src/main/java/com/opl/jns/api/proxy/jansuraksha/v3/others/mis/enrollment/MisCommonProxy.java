package com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MisCommonProxy implements Serializable {

    private static final long serialVersionUID = 1723204863326348631L;

    @NotNull
    public Long elgSvngAccHldr;

    @NotNull
    public Long elgPMJDYHldr;

    @NotNull
    public Long ruralMale;

    @NotNull
    public Long ruralFemale;

    @NotNull
    public Long ruralTransG;

    @NotNull
    public Long urbanFemale;

    @NotNull
    public Long urbanMale;

    @NotNull
    public Long urbanTransG;

    @NotNull
    public Long totalEnrolment;

    @NotNull
    public Long prmclctdruralMale;

    @NotNull
    public Long prmclctdruralFemale;

    @NotNull
    public Long prmclctdruralTransG;

    @NotNull
    public Long prmclctdurbanFemale;

    @NotNull
    public Long prmclctdurbanMale;

    @NotNull
    public Long prmclctdurbanTransG;

    @NotNull
    public Long totalPrmclctdNwErollment;

    @NotNull
    public Long recordsTransmittedToInsurer;

    @NotNull
    public Long premiumPaidToInsurer;

    @NotNull
    public Long aadharSeeded;

    @NotNull
    public Long mobileSeeded;

    @NotNull
    public Long emailSeeded;

    @NotNull
    public Long pmjdyEnrolled;

    @NotNull
    public Long mgnregaEnrolled;

    @NotNull
    public Long mudraEnrolled;

    @NotNull
    public Long kccEnrolled;

    @NotNull
    public Long otherSchemeEnrolled;

    public Long insufficientAcHolders;

    @NotNull
    public Caste caste;

    @NotNull
    public Long nomineeAvlb;

    @NotNull
    public Long frshEnrol1JuneCrrntYear;

    @NotNull
    public Long renewals1JuneCrrntYear;

    public Long prmdebitedRs;
}
