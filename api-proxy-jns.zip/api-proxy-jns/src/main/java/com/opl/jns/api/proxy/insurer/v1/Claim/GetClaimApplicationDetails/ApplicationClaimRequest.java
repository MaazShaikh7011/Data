package com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

/***
 * 
 * @author paresh.radadiya
 * @Date : 04/03/2023
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ApplicationClaimRequest {
	
	private static final long serialVersionUID = 1111111L;

	@NotNull(message = "can not be null or empty")
	@Min(value = 1,message = "can not be 0")
	private Long claimReferenceId;

}
