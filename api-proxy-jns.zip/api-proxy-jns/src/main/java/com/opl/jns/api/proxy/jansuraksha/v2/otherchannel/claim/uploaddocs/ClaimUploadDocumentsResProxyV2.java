package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.common.APIResponseV2;

public class ClaimUploadDocumentsResProxyV2 extends APIResponseV2{

	public ClaimUploadDocumentsResProxyV2(String message, int status) {
		super(status, message);
	}

	public ClaimUploadDocumentsResProxyV2(String message, int status, Boolean success) {
		super(status, message,success);
	}

}
