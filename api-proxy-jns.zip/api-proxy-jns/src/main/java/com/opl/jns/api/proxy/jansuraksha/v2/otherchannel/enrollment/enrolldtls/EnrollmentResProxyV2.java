package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV2;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class EnrollmentResProxyV2 extends APIResponseV2 {

	private static final long serialVersionUID = 1L;
	private EnrollmentDataResProxyV2 data;
	
	@Hidden
	@NotNull
	@JsonProperty("flag")
	private Boolean flag;


	public EnrollmentResProxyV2(int status,String message, EnrollmentDataResProxyV2 applicationMasterProxy,  Boolean success) {
		super( status,message, success);
		this.data = applicationMasterProxy;
	}

	public EnrollmentResProxyV2(String message, int status, Boolean success) {
		super( status,message, success);
	}

	public EnrollmentResProxyV2(String message, EnrollmentDataResProxyV2 data, Integer status, Boolean success) {
		super( status,message, success);
		this.data = data;
	}
}