package com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate;

import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString
@NoArgsConstructor
public class UpdateStatusResProxyV1 extends APIResponseV2 {

	private static final long serialVersionUID = 1123131L;

	public UpdateStatusResProxyV1(String message, Integer status) {
		super(status,message);
	}

	public UpdateStatusResProxyV1(String message, Integer status, Boolean success) {
		super(status,message,success);
	}

}