package com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author maaz.shaikh
 * @Date 5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClaimDeDupRequest implements Serializable {

	@NotNull
	public Long claimReferenceId;

	@NotNull
	@Size(min = 21, max = 32)
	public String urn;

	@Schema(example = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "hospitalisationDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime hospitalisationDate;

	@Size(min = 2, max = 100)
	public String firNo;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "firDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime firDate;

	@Size(min = 2, max = 100)
	public String panchnamaNo;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "panchnamaDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime panchnamaDate;

	@Size(min = 2, max = 100)
	public String postMortemReportNo;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "postMortemReportDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime postMortemReportDate;

	@Size(min = 2, max = 100)
	public String deathCertificateReportNo;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "deathCertificateReportDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	public LocalDateTime deathCertificateReportDate;

	@JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
	@ApiModelProperty(notes = "documentReceivingDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime documentReceivingDate;

	private final static long serialVersionUID = 4408957659517392075L;

}