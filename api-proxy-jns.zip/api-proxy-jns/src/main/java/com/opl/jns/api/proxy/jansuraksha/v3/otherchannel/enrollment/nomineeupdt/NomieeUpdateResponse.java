package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt;

import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.COIDocsProxyV3;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class NomieeUpdateResponse extends APIResponseV3 {

	private static final long serialVersionUID = -7496530234502198729L;

	@NotNull
	private COIDocsProxyV3 COI;

	public NomieeUpdateResponse(Integer status,String message, boolean flag) {
		super(status,message, flag);
	}

	public NomieeUpdateResponse(String message,Integer status) {
		super(status,message);
	}

	public NomieeUpdateResponse(String message, COIDocsProxyV3 COI, Integer status, Boolean success) {
		super();
		this.setMessage(message);
		this.COI = COI;
		this.setStatus(status);
		this.setSuccess(success);
	}
	
	public NomieeUpdateResponse() {
		super();
	}



}

