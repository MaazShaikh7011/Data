package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.COIDocsProxyV1;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString
public class COIDocsProxyV2 extends COIDocsProxyV1 {

	private static final long serialVersionUID = 24342343242341L;

	public COIDocsProxyV2(String documentType, String contentType, byte[] document) {
		super(documentType, contentType, document);
	}

}
