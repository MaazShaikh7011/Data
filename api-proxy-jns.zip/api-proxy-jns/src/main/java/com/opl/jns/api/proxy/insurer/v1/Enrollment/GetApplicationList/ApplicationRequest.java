package com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.api.proxy.utils.APIUtils;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

/***
 *
 * @author paresh.radadiya
 * @Date : 04/03/2023
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ApplicationRequest {

    private static final long serialVersionUID = 1111111L;

    @NotNull
    @JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "fromDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime fromDate;

    @NotNull
    @JsonFormat(pattern = APIUtils.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "toDate", example = APIUtils.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime toDate;
}
