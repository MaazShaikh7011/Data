package com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus;

import com.opl.jns.api.proxy.common.nomineeUpdateStatus.NomineeUpdateStatusCommonRequest;
import lombok.Data;

@Data
public class NomineeUpdateStatusRequestV3 extends NomineeUpdateStatusCommonRequest {

}
