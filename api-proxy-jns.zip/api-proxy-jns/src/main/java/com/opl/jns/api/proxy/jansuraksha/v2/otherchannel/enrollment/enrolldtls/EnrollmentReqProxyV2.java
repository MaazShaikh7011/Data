package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EnrollmentReqProxyV2 extends RegistryReqProxy {

	private final static long serialVersionUID = -4357839815853867628L;

	@Size(min = 21, max = 32)
	public String urn;

	@Valid
	@NotNull
	public CustomerDetailsV2 customerDetails;

	@Valid
	@NotNull
	public KycDetailsV2 kycDetails;

	@Valid
	@NotNull
	public NomineeDetailsV2 nomineeDetails;

	public GuardianDetailsV2 guardianDetails;

	@Valid
	public List<InsurerDetailV2> insurerDetails;

	@Valid
	public PolicyDetailsV2 policyDetails;

	@Valid
	@NotNull
	public OtherDetailsV2 otherDetails;

}