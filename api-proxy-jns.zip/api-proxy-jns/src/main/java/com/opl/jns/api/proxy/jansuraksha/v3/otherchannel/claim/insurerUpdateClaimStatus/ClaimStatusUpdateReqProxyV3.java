package com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus;

import com.opl.jns.api.proxy.common.CommonRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimStatusUpdateReqProxyV3 extends CommonRequest {

	private static final long serialVersionUID = 6913543652183533551L;

	@NotNull
//	@Min(1)
	private Long claimReferenceId;

	@NotNull
	@NotEmpty
	@Size(min = 31, max = 32)
	private String urn;

	@NotNull
//	@Size(min = 1, max = 50)
	@Schema(allowableValues = { "11", "7", "8",
			"10" }, description = "11 - In process,7 - Queried ,8 - Rejected,10 - Approved")
	private Integer claimStatus;

	@NotNull
	@NotEmpty
	@Size(min = 1, max = 100)
	private String claimId;

	@Schema(allowableValues  ={ "1", "2", "3",	"4", "5", "6", "7", "8"}, description ="Review Example Description reason >>> Enum")
	private Integer reason;

	private String insurerStatus;

	private ClaimStatusTransReqProxyV3 transactionDetails;

}
