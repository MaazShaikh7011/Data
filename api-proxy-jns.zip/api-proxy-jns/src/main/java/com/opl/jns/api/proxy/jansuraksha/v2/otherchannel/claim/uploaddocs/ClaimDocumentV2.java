package com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.uploaddocs.ClaimDocumentV1;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class ClaimDocumentV2 extends ClaimDocumentV1 implements Serializable {

	private static final long serialVersionUID = 145465468L;

}
