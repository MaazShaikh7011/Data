package com.opl.jns.api.proxy.common.nomineeUpdateStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.api.proxy.common.APIResponseV3;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message","sucess", "token", "timeStamp" })
public class NomineeUpdateStatusCommonResponse extends APIResponseV3 {
	
	public NomineeUpdateStatusCommonResponse() {
		super();
	}

	public NomineeUpdateStatusCommonResponse(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}
}