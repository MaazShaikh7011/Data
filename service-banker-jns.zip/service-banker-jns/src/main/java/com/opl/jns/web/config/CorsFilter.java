package com.opl.jns.web.config;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.opl.jns.utils.config.CorsFilterUtils;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class CorsFilter implements Filter {

	private static final String OPTIONS = "OPTIONS";
	private static final String TRACE = "TRACE";

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) res;
		HttpServletRequest request = (HttpServletRequest) req;
		boolean result = CorsFilterUtils.setHeader(response, request);
		if (!result) {
			chain.doFilter(req, res);
		}
	}

	public void init(FilterConfig filterConfig) {
		// Do nothing because of X and Y.
	}

	public void destroy() {
		// Do nothing because of X and Y.
	}

}
