package com.opl.sqs_test.controller;

import com.opl.sqs_test.proxy.CommonRequest;
import com.opl.sqs_test.service.SQSProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class RestApiController {

    @Autowired
    SQSProducer producer;

    @PostMapping("publishToSqs")
    public ResponseEntity postToSqs(@RequestBody CommonRequest commonRequest){
        return new ResponseEntity(producer.produce(commonRequest),HttpStatus.OK);
    }


}
