package com.opl.sqs_test.service;

import com.opl.sqs_test.proxy.CommonRequest;
import io.awspring.cloud.sqs.annotation.SqsListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SQSListner {

////	@SqsListener(value = "QA_PUSH_APPLICATION_QUEUE", deletionPolicy = SqsMessageDeletionPolicy.NEVER)
//	@SqsListener("JANSURAKSHA_PROD_SQS_BANK_IND")
////	@SqsListener("#{'${com.jansuraksha.queues}'.split(',')}")
//	public void pushEnrollment(CommonRequest request) {
//		log.info("================== [{}] =========[{}]=================================",request.getOrgId(),request.getApplicationId());
////		acknowledgment.acknowledge().isDone();
//	}
//
////	@SqsListener("#{'${com.jansuraksha.queues}'.split(',')}")
////	public void pushEnrollments(PushEnrollmentDetailsRequest pushEnrollDtlsReq) {
////		try {
////			System.out.println("---------------------------------------- " + pushEnrollDtlsReq.getOrgId()
////					+ " ----------------------------------------------------------------------");
////			log.info(MultipleJSONObjectHelper.getStringfromObject(pushEnrollDtlsReq));
////			System.out.println(
////					"--------------------------------------------------------------------------------------------------------------");
////		} catch (Exception e) {
////			e.printStackTrace();
////		}
////		return;
////	}
//
//	private String printLogs(Long applicationId, Long orgId, String refId) {
//		return " APPLICATIONID: " + applicationId + " AND ORGID: " + orgId + " AND REF ID: " + refId;
//	}


//    @SqsListener("JANSURAKSHA_PROD_SQS_BANK_IND")
    @SqsListener("#{'${com.jansuraksha.queues}'.split(',')}")
    public void  listen(CommonRequest pushEnrollDtlsReq){
        log.info("Received OrdId : [{}] And AplicationId [{}]",pushEnrollDtlsReq.getOrgId(),pushEnrollDtlsReq.getApplicationId());

    }

}
