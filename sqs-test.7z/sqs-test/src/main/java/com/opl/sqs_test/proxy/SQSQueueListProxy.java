package com.opl.sqs_test.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SQSQueueListProxy implements Serializable {

	private static final long serialVersionUID = -6022426402472908782L;

	private List<SQSQueueMsgProxy> queueMsgProxies;

	public SQSQueueMsgProxy filter(Long orgId) {
		Optional<SQSQueueMsgProxy> srBucketPrx = queueMsgProxies.stream()
				.filter(a -> Objects.equals(a.getOrgId(), orgId)).findFirst();
		return srBucketPrx.orElse(null);
	}

}
