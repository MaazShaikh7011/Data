//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.opl.sqs_test.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

public class OPLUtils {
    private static final Logger logger = LoggerFactory.getLogger(OPLUtils.class);
    public static final String REQUEST_HEADER_AUTHENTICATE = "ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo";
    public static final String REQUEST_HEADER_AUTHENTICATE_VALUE = "true";
    public static final Long OTHER_CHANNEL = 1L;

    public OPLUtils() {
    }

    public static boolean isListNullOrEmpty(Collection<?> data) {
        return data == null || data.isEmpty();
    }

    public static String isStringEmpty(String value) {
        value = value.trim();
        return !value.isEmpty() && value != null && !"undefined".equals(value) && !"null".equals(value) && !"".equals(value) ? value : "";
    }

    public static boolean isObjectNullOrEmpty(Object value) {
        boolean var10000;
        if (value != null) {
            label36: {
                if (value instanceof String) {
                    String s = (String)value;
                    if (s.isEmpty() || "".equals(s.trim()) || "null".equals(value) || "undefined".equals(value)) {
                        break label36;
                    }
                }

                var10000 = false;
                return var10000;
            }
        }

        var10000 = true;
        return var10000;
    }

    public static boolean isObjectNullOrEmptyOrDash(Object value) {
        boolean var10000;
        if (value != null) {
            label39: {
                if (value instanceof String) {
                    String s = (String)value;
                    if (s.isEmpty() || "".equals(s.trim()) || "null".equals(value) || "-".equals(value) || "undefined".equals(value)) {
                        break label39;
                    }
                }

                var10000 = false;
                return var10000;
            }
        }

        var10000 = true;
        return var10000;
    }

    public static boolean isObjectListNull(Object... args) {
        Object[] var1 = args;
        int var2 = args.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            Object object = var1[var3];
            boolean flag = false;
            if (object instanceof List list) {
                flag = isListNullOrEmpty(list);
                if (flag) {
                    return true;
                }
            } else {
                flag = isObjectNullOrEmpty(object);
                if (flag) {
                    return true;
                }
            }
        }

        return false;
    }

    public static Double getPMTCalculationByLoanAmt(double roi, double tenure, double circularLoanAmount) {
        return roi / (1.0 - Math.pow(1.0 + roi, -tenure)) * circularLoanAmount * 12.0;
    }

    public static Double convertRoundOffValue(Double finalLoanAmountNew) {
        if (finalLoanAmountNew != null) {
            String s1 = String.valueOf(finalLoanAmountNew);
            s1 = s1.substring(0, s1.indexOf(46));
            Long val = 0L;
            Long l1 = 0L;
            String s2 = s1;
            val = Long.parseLong(s2);
            if (val > 3L) {
                s2 = String.valueOf(val);
                if (s2.length() > 3) {
                    l1 = Long.parseLong(s2.substring(s2.length() - 3));
                    Long firstDgt;
                    if (l1 > 500L) {
                        s2 = s2.substring(0, s2.length() - 3);
                        firstDgt = Long.parseLong(s2);
                        firstDgt = firstDgt + 1L;
                    } else {
                        s2 = s2.substring(0, s2.length() - 3);
                        firstDgt = Long.parseLong(s2);
                    }

                    s1 = firstDgt.toString() + "000";
                    Double finalEligibleValue = Double.parseDouble(s1);
                    return finalEligibleValue;
                }
            }
        }

        return finalLoanAmountNew;
    }

    public static Double convertRoundOffValueToTen(Double finalLoanAmountNew) {
        if (finalLoanAmountNew != null) {
            String s1 = String.valueOf(finalLoanAmountNew);
            s1 = s1.substring(0, s1.indexOf(46));
            Long val = 0L;
            Long l1 = 0L;
            String s2 = s1;
            val = Long.parseLong(s2);
            if (val > 1L) {
                s2 = String.valueOf(val);
                if (s2.length() > 1) {
                    l1 = Long.parseLong(s2.substring(s2.length() - 1));
                    Long firstDgt;
                    if (l1 > 4L) {
                        s2 = s2.substring(0, s2.length() - 1);
                        firstDgt = Long.parseLong(s2);
                        firstDgt = firstDgt + 1L;
                    } else {
                        s2 = s2.substring(0, s2.length() - 1);
                        firstDgt = Long.parseLong(s2);
                    }

                    s1 = firstDgt.toString() + "0";
                    Double finalEligibleValue = Double.parseDouble(s1);
                    return finalEligibleValue;
                }
            }
        }

        return finalLoanAmountNew;
    }

    public static boolean isNumeric(String strNum) {
        if (isObjectNullOrEmpty(strNum)) {
            return false;
        } else {
            try {
                Double.parseDouble(strNum);
                return true;
            } catch (NumberFormatException var2) {
                return false;
            }
        }
    }

    public static String generateUUID() {
        return UUID.randomUUID().toString();
    }

    public static String generateUUIDOfLength20() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 20);
    }

}
