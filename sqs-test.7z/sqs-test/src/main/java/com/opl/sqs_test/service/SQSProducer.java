package com.opl.sqs_test.service;

import com.opl.sqs_test.proxy.CommonRequest;
import com.opl.sqs_test.proxy.SQSQueueListProxy;
import com.opl.sqs_test.proxy.SQSQueueMsgProxy;
import com.opl.sqs_test.utils.OPLUtils;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.security.Provider;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Component
@Slf4j
public class SQSProducer {

	@Autowired
	private SQSQueueListProxy queueListProxy;

	@Autowired
	private SqsTemplate sqsTemplate;

	/**
	 * PRODUCE DATA IN AWS SQS
	 *
	 * @param pushEnrollDtlsReq
	 * @param
	 * @param
	 * @return
	 */
	public boolean produce(CommonRequest pushEnrollDtlsReq) {
		try {
			Long orgId = pushEnrollDtlsReq.getOrgId();
			String token= generateToken(orgId);
			String generateRef = "SQS_TEST_WH_API_"+token;
			pushEnrollDtlsReq.setToken(token);
			pushEnrollDtlsReq.setReferenceId(generateRef);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				log.error("PUSH ENROLLMENT BANK DETAILS NOT FOUND ----->");
				return false;
			}
			SQSQueueMsgProxy queue = queueListProxy.filter(orgId);
			if (OPLUtils.isObjectNullOrEmpty(queue)) {
				queue = queueListProxy.filter(-1l);
			}
//			log.info("Pushing data on Queue : {}",queue.getName());
//			if (OPLUtils.isObjectNullOrEmpty(queue)) {
//				log.error("PUSH ENROLLMENT AWS SQS NOT FOUND BY ORGNIZATION ID OR -1 ----->");
//				return false;
//			}
//			log.info("PUSH ENROLLMENT URL ----------------> " + queue.getUrl());
//			System.out.println(MultipleJSONObjectHelper.getStringfromObject(pushEnrollDtlsReq));
//			-- old
//			queue.getQueueMsgTemplate().convertAndSend(queue.getUrl(), pushEnrollDtlsReq);
//			SQSQueueMsgProxy finalQueue = queue;
			SQSQueueMsgProxy finalQueue = queue;
			log.info("pushing data on queue : {}",finalQueue.getName());
//			sqsTemplate.send(to -> to.queue("JANSURAKSHA_PROD_SQS_BANK_IND").payload(pushEnrollDtlsReq));
			sqsTemplate.send(to -> to.queue(finalQueue.getName()).payload(pushEnrollDtlsReq));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("PUSH ENROLLMENT EXCEPTION AWS SQS: ", e);
			return  false;
		}
	}

	public static String getTimestampFormat(Date date, String format) {
		return new SimpleDateFormat(format).format(date);
	}

	/**GENERATE TOKEN*/
	public static String generateToken(Long orgId) {
		java.util.Date date = new Date();
		return "JNS" + String.format("%03d", orgId) +getTimestampFormat(date, "YYMMdd") + getTimestampFormat(date, "hhMMsss")
				+ UUID.randomUUID().toString().replace("-", "").substring(0, 8);
	}

}
