package com.opl.jns.dms.service.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.dms.api.model.AnsProductDocumentResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.service.domain.ProductDocumentMappingV3;
import com.opl.jns.dms.service.repository.ProductDocumentMappingRepositoryV3;
import com.opl.jns.dms.service.repository.ProductStorageRepositoryV3;
import com.opl.jns.dms.service.service.ProductDocumentMappingServiceV3;
import com.opl.jns.utils.common.OPLUtils;

@Service
@Transactional
public class ProductDocumentMappingServiceImplV3 implements ProductDocumentMappingServiceV3 {
	
	private final Logger logger = LoggerFactory.getLogger(ProductDocumentMappingServiceImplV3.class);

    @Autowired
    private ProductDocumentMappingRepositoryV3 proDocMapRepo;
    
    @Autowired
  	private ProductStorageRepositoryV3 productStorageRepository;

    @Override
    public ProductDocumentMappingV3 getProductDocumentMappingById(Long id) {
    	logger.info("Product Document id  ::::: {}",id);
        return proDocMapRepo.findById(id).orElse(null);
    }
    
    @Override
    public List<AnsProductDocumentResponse> getDocumentsByOtherTrackingId(DocumentRequest docRequest) {
    	try {
    		List<ProductDocumentMappingV3> docMapList = proDocMapRepo.getByProductMappingId(docRequest.getProMapIds());
        	// CONVERT PRODUCT DOCUMENTS TO RESPONSE LIST
            List<AnsProductDocumentResponse> resList = convert(docMapList);
            for(AnsProductDocumentResponse res : resList) {
                // CHECK ID CHILD PRODUCT DOCUMENTS IS AVAILABLE OR NOT
                List<ProductDocumentMappingV3> childDocMapList = docMapList.stream().filter(a -> res.getDocId().equals(a.getDocumentMaster().getParentId()))
                        .collect(Collectors.toList());
                if(!childDocMapList.isEmpty()) {
                    res.setChild(Boolean.TRUE);
                    if(!OPLUtils.isObjectNullOrEmpty(docRequest.getOtherTrackingId())) {
                        //List<StorageDetailsResponse> storageList = getStorageList(childDocMapList.stream().map(a -> a.getId()).collect(Collectors.toList()), docRequest.getApplicationId(), docRequest.getCoApplicantId());
                        List<StorageDetailsResponse> storageList = productStorageRepository.listDocumentApplicantInStorageDetailsByOtherId(docRequest.getOtherTrackingId(), childDocMapList.stream().map(a -> a.getId()).collect(Collectors.toList()));
                        if (!storageList.isEmpty()) {
                            res.setFileList(storageList);
                            res.setChildProDocMapId(storageList.stream().map(a -> a.getProductMappingId()).findFirst().orElse(null));
                        }
                        res.setChildList(convert(childDocMapList));
                    }
                } else {
                    res.setChild(Boolean.FALSE);
                    // SET UPLOAD FILE STORAGE DETAILS
                    if(!OPLUtils.isObjectNullOrEmpty(docRequest.getOtherTrackingId())) {
                        List<Long> docMapId = new ArrayList<>();
                        docMapId.add(res.getProDocMapId());
                        res.setFileList(productStorageRepository.listDocumentApplicantInStorageDetailsByOtherId(docRequest.getOtherTrackingId(), docMapId));
                    }
                }
            }
            return resList;
		} catch (Exception e) {
			logger.error("Exception while get documents list by other tracking id ");
		}
    	return Collections.emptyList();
    }
    
    private List<AnsProductDocumentResponse> convert(List<ProductDocumentMappingV3> docMapList) {
        if(!docMapList.isEmpty()) {
            List<AnsProductDocumentResponse> resList = new ArrayList<>(docMapList.size());
            AnsProductDocumentResponse res = null;
            for(ProductDocumentMappingV3 docMap : docMapList) {
                res = new AnsProductDocumentResponse();
                res.setProDocMapId(docMap.getId());
                res.setDocId(docMap.getDocumentMaster().getId());
                res.setDocumentName(docMap.getDocumentMaster().getName());
                res.setIsMandatory(docMap.isMandatory());
                res.setGroupId(docMap.getGroupId());
                res.setTitleName(docMap.getTitleName());
                res.setIsMultiple(docMap.getIsMultiple());
                resList.add(res);
            }
            return resList;
        }
        return Collections.emptyList();
    }

	@Override
	public List<AnsProductDocumentResponse>  fetchDocMappingList(Long typeId) throws IOException {
		List<ProductDocumentMappingV3> docMappingList = proDocMapRepo.findByTypeMasterIdAndIsActive(typeId,true);
		if(!OPLUtils.isObjectListNull(docMappingList)) {
			return convert(docMappingList);
		}
		return Collections.emptyList();
	}
	
}
