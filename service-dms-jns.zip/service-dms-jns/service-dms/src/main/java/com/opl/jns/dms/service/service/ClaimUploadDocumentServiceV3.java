package com.opl.jns.dms.service.service;

public interface ClaimUploadDocumentServiceV3 {

	Long findTypeIdByDisabilityTypeIdAndSchemeId(Long disabilityTypeId, Long schemeId);
		
}
