package com.opl.jns.dms.service.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3Object;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.dms.api.model.AnsProductDocumentResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.MultipartObjectRequest;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.model.ZipRequest;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.service.domain.ProductDocumentMappingV3;
import com.opl.jns.dms.service.domain.ProductStorageDetailsV3;
import com.opl.jns.dms.service.service.ProductDocumentMappingServiceV3;
import com.opl.jns.dms.service.service.ProductStorageServiceV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/v3")
public class ProductDocumentUploadControllerV3 {

	@Autowired
	private ProductStorageServiceV3 productStorageService;

	@Autowired
	private ProductDocumentMappingServiceV3 productDocumentMappingService;

	@Autowired
	private ConfigProperties configProperties;

	private static final String INVALID_REQUEST_MSG = "Invalid Request {}";
	private static final String INVALID_REQUEST = "Invalid Request !";
	private static final String COULD_NOT_PARSE_JSON_MSG = "Could Not Parse Json {}";

	private static final Logger logger = LoggerFactory.getLogger(ProductDocumentUploadControllerV3.class);
	private static final String DOCUMENT_UPLOADED_SUCCESSFULLY = "Document Uploaded Successfully";
	private static final String YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_TYPE_NOT_MATCHED = "Your Document couldn't be uploaded. Document Type Not Matched! {}";
	private static final String YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_SIZE_NOT_MATCHED = "Your Document couldn't be uploaded. Document Size Not Matched! {}";
	private static final String DOCUMENT_TYPE_NOT_MATCHED = "Document Type Not Matched";
	private static final String DOCUMENT_SIZE_NOT_MATCHED = "Document Size Not Matched";
	private static final String SUCCESSFULLY_LISTED = "Successfully Listed";

	@PostMapping(value = "/pingDms")
	public ResponseEntity<String> pingDms( HttpServletResponse response) {
		logger.info("Enter in /uploadFile with");
		return new ResponseEntity<String>("Success Ping", HttpStatus.OK);
	}
	
	@PostMapping(value = "/uploadFile")
	public ResponseEntity<DocumentResponse> uploadDocument(@RequestPart("uploadRequest") String documentRequestString,
														   @RequestPart("file") MultipartFile multipartFiles,
														   @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		// logger.info("Enter in /uploadFile with {}",documentRequestString);
		logger.info("Enter in /uploadFile with");
		DocumentRequest documentRequest = null;
		DocumentResponse documentResponse = testingMode();
		if(!OPLUtils.isObjectNullOrEmpty(documentResponse)){
			return new ResponseEntity<>(documentResponse, HttpStatus.OK);
		}
		documentResponse = new DocumentResponse();
		try {
			documentRequest = MultipleJSONObjectHelper.getObject(documentRequestString, DocumentRequest.class);
			boolean result = productStorageService.validateRequest(documentRequest);
			if (result) {
				// logger.warn(CommonUtil.INVALID_REQUEST_MSG, documentRequest);
				logger.warn(INVALID_REQUEST_MSG);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			logger.info("documentRequest.getProductDocumentMappingId() ::: {}" + documentRequest.getProductDocumentMappingId() + " name  :: {}" + documentRequest.getOriginalFileName());

			if (OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId()) || OPLUtils.isObjectNullOrEmpty(documentRequest.getOriginalFileName())) {
				// logger.warn(CommonUtil.INVALID_REQUEST_MSG, documentRequest);
				logger.warn(INVALID_REQUEST_MSG);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			// validate document
			boolean isFileValidate = productStorageService.validateDocument(multipartFiles, documentRequest);
//            if (isFileValidate) {
//                ProductStorageDetails productStorageDetails = productStorageService.saveFile(documentRequest.getOriginalFileName(), multipartFiles.getBytes(), documentRequest);
//                StorageDetailsResponse storageDetailsResponse = productStorageService.addStorageDetails(documentRequest, productStorageDetails);
//                documentResponse.setData(storageDetailsResponse);
//                documentResponse.setStatus(HttpStatus.OK.value());
//                documentResponse.setMessage(DOCUMENT_UPLOADED_SUCCESSFULLY);
//                return new ResponseEntity<>(documentResponse, HttpStatus.OK);
//            } else {
//                logger.warn(YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_TYPE_NOT_MATCHED, documentRequest);
//                documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
//                documentResponse.setMessage(DOCUMENT_TYPE_NOT_MATCHED);
//                return new ResponseEntity<>(documentResponse, HttpStatus.OK);
//            }

			// validate document
			ProductDocumentMappingV3 productDocumentMapping = productDocumentMappingService.getProductDocumentMappingById(documentRequest.getProductDocumentMappingId());
			boolean isFileBig = productStorageService.validateDocumentSize(multipartFiles, productDocumentMapping.getDocumentMaster().getSize());
			if (isFileBig && isFileValidate) {
				documentRequest.setDocumentId(productDocumentMapping.getDocumentMaster().getId());
				ProductStorageDetailsV3 productStorageDetails = productStorageService.saveFile(multipartFiles.getBytes(), documentRequest, multipartFiles.getSize());
				StorageDetailsResponse storageDetailsResponse = productStorageService.addStorageDetails(documentRequest, productStorageDetails, authClientResponse);
				documentResponse.setData(storageDetailsResponse);
				documentResponse.setStatus(HttpStatus.OK.value());
				documentResponse.setMessage(DOCUMENT_UPLOADED_SUCCESSFULLY);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
			} else if (!isFileBig) {
				logger.warn(YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_SIZE_NOT_MATCHED, documentRequest);
				documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				documentResponse.setMessage(DOCUMENT_SIZE_NOT_MATCHED);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
//			} else if (!isFileValidate) {
			} else {
				logger.warn(YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_TYPE_NOT_MATCHED, documentRequest);
				documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				documentResponse.setMessage(DOCUMENT_TYPE_NOT_MATCHED);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
			}
//			else {
//				logger.warn(INVALID_REQUEST, documentRequest);
//				documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
//				documentResponse.setMessage(INVALID_REQUEST);
//				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
//			}


		} catch (IOException e) {
			logger.error("Could Not Parse Json in /uploadFile {}", e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}
	
	@SkipInterceptor
	@PostMapping(value = "/uploadGrievanceFile")
	public ResponseEntity<DocumentResponse> uploadGrievanceFile(@RequestPart("uploadRequest") String documentRequestString,
														   @RequestPart("file") MultipartFile multipartFiles) {
		// logger.info("Enter in /uploadFile with {}",documentRequestString);
		logger.info("Enter in /uploadGrievanceFile with");
		DocumentRequest documentRequest = null;
		DocumentResponse documentResponse = testingMode();
		if(!OPLUtils.isObjectNullOrEmpty(documentResponse)){
			return new ResponseEntity<>(documentResponse, HttpStatus.OK);
		}
		documentResponse = new DocumentResponse();
		try {
			documentRequest = MultipleJSONObjectHelper.getObject(documentRequestString, DocumentRequest.class);

			logger.info("documentRequest.getProductDocumentMappingId() ::: {}" + documentRequest.getProductDocumentMappingId() + " name  :: {}" + documentRequest.getOriginalFileName());

			if (OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId()) || OPLUtils.isObjectNullOrEmpty(documentRequest.getOriginalFileName())) {
				logger.warn(INVALID_REQUEST_MSG);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			boolean isFileValidate = productStorageService.validateDocument(multipartFiles, documentRequest);
			// validate document
			ProductDocumentMappingV3 productDocumentMapping = productDocumentMappingService.getProductDocumentMappingById(documentRequest.getProductDocumentMappingId());
			boolean isFileBig = productStorageService.validateDocumentSize(multipartFiles, productDocumentMapping.getDocumentMaster().getSize());
			if (isFileBig && isFileValidate) {
				documentRequest.setDocumentId(productDocumentMapping.getDocumentMaster().getId());
				ProductStorageDetailsV3 productStorageDetails = productStorageService.saveFile(multipartFiles.getBytes(), documentRequest, multipartFiles.getSize());
				AuthClientResponse authClientResponse = new AuthClientResponse();
				StorageDetailsResponse storageDetailsResponse = productStorageService.addStorageDetails(documentRequest, productStorageDetails, authClientResponse);
				documentResponse.setData(storageDetailsResponse);
				documentResponse.setStatus(HttpStatus.OK.value());
				documentResponse.setMessage(DOCUMENT_UPLOADED_SUCCESSFULLY);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
			} else if (!isFileBig) {
				logger.warn(YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_SIZE_NOT_MATCHED, documentRequest);
				documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				documentResponse.setMessage(DOCUMENT_SIZE_NOT_MATCHED);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
			} else {
				logger.warn(YOUR_DOCUMENT_COULD_NOT_BE_UPLOADED_DOCUMENT_TYPE_NOT_MATCHED, documentRequest);
				documentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				documentResponse.setMessage(DOCUMENT_TYPE_NOT_MATCHED);
				return new ResponseEntity<>(documentResponse, HttpStatus.OK);
			}

		} catch (IOException e) {
			logger.error("Could Not Parse Json in /uploadFile {}", e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}
	
	@PostMapping(value = "/uploadMultipleFileWithDocMappingIds")
	public ResponseEntity<DocumentResponse> uploadMultipleFileWithDocMappingIds(@RequestBody List<MultipartObjectRequest> multiPartObjList,
													        @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		logger.info("Enter in /uploadMultipleFileWithDocMappingIds with {}");
		try {
			if(OPLUtils.isObjectListNull(multiPartObjList)) {
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<StorageDetailsResponse> response = new ArrayList<>(multiPartObjList.size());
			for (MultipartObjectRequest objReq : multiPartObjList) {
				DocumentRequest documentRequest = objReq.getJsonString();
				byte[] bytes = Base64.getDecoder().decode(objReq.getMultiPartFile());
 				MockMultipartFile multiPartFile = new MockMultipartFile(documentRequest.getDocName(),documentRequest.getDocName().replaceAll(" ","_") +".pdf","application/pdf",bytes);
	        	documentRequest.setUserType(DocumentAlias.UERT_TYPE_APPLICANT);
				boolean result = productStorageService.validateRequest(documentRequest);
				if (result) {
					logger.warn(INVALID_REQUEST_MSG, documentRequest);
					return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
				}

				if (OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId())) {
					logger.warn(INVALID_REQUEST_MSG, documentRequest);
					return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
				}
				// validate document

				documentRequest.setOriginalFileName(multiPartFile.getOriginalFilename());
				boolean isFileValidate = productStorageService.validateDocument(multiPartFile, documentRequest);
				if (isFileValidate) {
					productStorageService.updateProductStorageDocument(documentRequest.getApplicationId(),documentRequest.getClaimId(),documentRequest.getProductDocumentMappingId(),documentRequest.getDocumentId());
					ProductStorageDetailsV3 productStorageDetails = productStorageService.saveFile(multiPartFile.getBytes(), documentRequest, multiPartFile.getSize());
					response.add(productStorageService.addStorageDetails(documentRequest, productStorageDetails, authClientResponse).setStatus(HttpStatus.OK.value()));
				} else {
					response.add(new StorageDetailsResponse(HttpStatus.BAD_REQUEST.value(), multiPartFile.getOriginalFilename(), "File size is long"));
				}
				 
			}
			return new ResponseEntity<>(new DocumentResponse("Success", HttpStatus.OK.value(), response), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Could Not Parse Json in /uploadFile {}", e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/listProductDocument/BankUser", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocumentResponse> listDocumentForBankUser(@RequestBody DocumentRequest documentRequest) {
		// logger.info("Enter in /listProductDocument with {}",documentRequest);
		logger.info("Enter in /listProductDocument with");
		boolean result = productStorageService.validateRequest(documentRequest);
		if (result) {
			// logger.warn("Invalid Request {}", documentRequest);
			logger.warn("Invalid Request");
			return new ResponseEntity<>(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		if (OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId())) {
			// logger.warn("Invalid Request {}", documentRequest);
			logger.warn("Invalid Request");
			return new ResponseEntity<>(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		} else {
			DocumentResponse documentResponse = null;
			if ("applicant".equals(documentRequest.getUserType())) {
				documentResponse = productStorageService.listOfApplicantForBankUser(documentRequest.getApplicationId(), documentRequest.getProductDocumentMappingId());
			}
			if (documentResponse != null) {
				documentResponse.setMessage(SUCCESSFULLY_LISTED);
				documentResponse.setStatus(HttpStatus.OK.value());
			}
			return new ResponseEntity<>(documentResponse, HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/deleteUplodedFile", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocumentResponse> deleteDocuemnt(@RequestBody String productStorageDetailsId) {
		// logger.info("Enter in /deleteProduct with {}",productStorageDetailsId);
		logger.info("Enter in /deleteProduct with" + productStorageDetailsId);
		try {
			Long id = MultipleJSONObjectHelper.getNestedObject(productStorageDetailsId, "id", Long.class);
			if (!OPLUtils.isObjectNullOrEmpty(id)) {
				int rowUpdated = productStorageService.deleteDocument(id);
				if (rowUpdated > 0) {
					// logger.warn("Successfully Deleted {}", id);
					logger.warn("Successfully Deleted {}");
					return new ResponseEntity<>(new DocumentResponse("Successfully Deleted", HttpStatus.OK.value()), HttpStatus.OK);
				} else {
					// logger.warn("Product Document Storage id wrong or not present {}", id);
					logger.warn("Product Document Storage id wrong or not present {}");
					return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
				}
			} else {
				// logger.warn(INVALID_REQUEST_MSG, id);
				logger.warn(INVALID_REQUEST_MSG);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
		} catch (IOException e) {
			logger.error(COULD_NOT_PARSE_JSON_MSG, e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/removeDocument", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocumentResponse> removeDocument(@RequestBody Long claimId) {
		logger.info("Enter in /removeDocument with" + claimId);
		try {
			if (!OPLUtils.isObjectNullOrEmpty(claimId)) {

				return new ResponseEntity<>(productStorageService.removeDocument(claimId), HttpStatus.OK);
			} else {
				logger.warn(INVALID_REQUEST_MSG);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(COULD_NOT_PARSE_JSON_MSG, e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}

	/**
	 * Zip file controller
	 */

	@PostMapping(value = "/getDocumentZip", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> downloadResolution(@RequestBody ZipRequest zipRequest, HttpServletResponse response) throws IOException {
		logger.info("Enter in Generate ZIp new================================================================================================================");
		if (OPLUtils.isObjectNullOrEmpty(zipRequest.getApplicationId())) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}

		String filePath = productStorageService.getDocumentZip(zipRequest);

		if (filePath == null) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		// logger.info("Filepath--------------->" + filePath);
		byte[] readBytes = Files.readAllBytes(Paths.get(filePath));
		File file = new File(filePath);
		if (file.exists()) {
			boolean flag = file.delete();
			logger.info("file.delete() status : " + flag);
		}
		return new ResponseEntity<>(readBytes, HttpStatus.OK);
	}


	@GetMapping(value = "/productDownloadDocuments/{id}")
	public ResponseEntity<Resource> productDownloadDocuments(@PathVariable String id) {
		logger.info("Enter in /productDownloadDocument with {}", id);
		if (OPLUtils.isObjectNullOrEmpty(id)) {
			logger.info("Invalid Request id not present");
			return new ResponseEntity(new DocumentResponse("Invalid Request id not present", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		Base64.Decoder decoder = Base64.getDecoder();
		String decryptedKey = new String(decoder.decode(id));
		// boolean isAuthenticated =
		// productStorageService.authenticateBeforeDownloadDocument(Integer.valueOf(decryptedLoginToken),Long.valueOf(decryptedKey));
		// if (isAuthenticated) {
		S3Object s3Object = productStorageService.downloadFileFromStorageId(Long.valueOf(decryptedKey));
		if (!OPLUtils.isObjectNullOrEmpty(s3Object)) {
			String mimeType = null;
			InputStreamResource inputStreamResource = new InputStreamResource(s3Object.getObjectContent());
			String filename = s3Object.getKey().replaceAll("resources/", "");
			mimeType = s3Object.getObjectMetadata().getContentType();
			if (OPLUtils.isObjectNullOrEmpty(mimeType)) {
				logger.info("in if conditions setting default mime type");
				mimeType = "text/html";
			}
			// logger.info("getting document id {} mimeType {}",id,mimeType);
			logger.info("getting document id");
			return ResponseEntity.ok().header("Content-Disposition", "attachment; filename=" + filename).contentLength(s3Object.getObjectMetadata().getContentLength()).contentType(MediaType.parseMediaType(mimeType))
					.body(inputStreamResource);
		} else {
			return new ResponseEntity(new DocumentResponse("File not found", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		/*
		 * }else{ logger.info("Invalid Request token present"); return new ResponseEntity(new
		 * DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK); }
		 */
	}

	@PostMapping(value = "/downloadDocumentByProductDocumentMappingId")
	public ResponseEntity<Resource> downloadDocumentByProductDocumentMappingId(@RequestBody ZipRequest zipreq) {
		logger.info("Enter in /downloadDocumentByProductDocumentMappingId with {} {}", zipreq.getApplicationId(),zipreq.getProposalId());
		if (OPLUtils.isObjectNullOrEmpty(zipreq.getApplicationId())) {
			logger.info("applicationId not present");
			return new ResponseEntity(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		if (OPLUtils.isObjectNullOrEmpty(zipreq.getProductDocumentMappingId())) {
			logger.info("productDocumentMappingId not present");
			return new ResponseEntity(new DocumentResponse("Invalid Request id not present", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		S3Object s3Object = productStorageService.downloadDocumentByProductDocumentMappingId(zipreq.getApplicationId(), zipreq.getProductDocumentMappingId(), zipreq.getCoAppId(),zipreq.getProposalId());
		if (!OPLUtils.isObjectNullOrEmpty(s3Object)) {
			String mimeType = null;
			InputStreamResource inputStreamResource = new InputStreamResource(s3Object.getObjectContent());
			String filename = s3Object.getKey().replaceAll("resources/", "");
			mimeType = s3Object.getObjectMetadata().getContentType();
			if (OPLUtils.isObjectNullOrEmpty(mimeType)) {
				logger.info("in if conditions setting default mime type");
				mimeType = "text/html";
			}
			// logger.info("getting document id {} mimeType {}",id,mimeType);
			logger.info("getting document mimeType {}", mimeType);
			logger.info("FileNAME===>", filename);
			return ResponseEntity.ok().header("Content-Disposition", "attachment; filename=" + filename).contentLength(s3Object.getObjectMetadata().getContentLength()).contentType(MediaType.parseMediaType(mimeType))
					.body(inputStreamResource);
		} else {
			return new ResponseEntity(new DocumentResponse("File not found", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

	}

	@PostMapping(value = "/downloadDocumentByDocumentMappingId")
	public ResponseEntity<Resource> downloadDocumentByDocumentMappingId(@RequestBody ZipRequest zipreq) {
		logger.info("Enter in /productDownloadDocument with {}", zipreq.getApplicationId());
		if (OPLUtils.isObjectNullOrEmpty(zipreq.getApplicationId())) {
			logger.info("applicationId not present");
			return new ResponseEntity(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		if (OPLUtils.isObjectNullOrEmpty(zipreq.getProductDocumentMappingId())) {
			logger.info("productDocumentMappingId not present");
			return new ResponseEntity(new DocumentResponse("Invalid Request id not present", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		S3Object s3Object = productStorageService.downloadDocumentByDocumentMappingId(zipreq.getApplicationId(),zipreq.getClaimId(), zipreq.getProductDocumentMappingId());
		if (!OPLUtils.isObjectNullOrEmpty(s3Object)) {
			String mimeType = null;
			InputStreamResource inputStreamResource = new InputStreamResource(s3Object.getObjectContent());
			String filename = s3Object.getKey().replaceAll("resources/", "");
			mimeType = s3Object.getObjectMetadata().getContentType();
			if (OPLUtils.isObjectNullOrEmpty(mimeType)) {
				logger.info("in if conditions setting default mime type");
				mimeType = "text/html";
			}
			// logger.info("getting document id {} mimeType {}",id,mimeType);
			logger.info("getting document mimeType {}", mimeType);
			logger.info("FileNAME===>", filename);
			return ResponseEntity.ok().header("Content-Disposition", "attachment; filename=" + filename).contentLength(s3Object.getObjectMetadata().getContentLength()).contentType(MediaType.parseMediaType(mimeType))
					.body(inputStreamResource);
		} else {
			return new ResponseEntity(new DocumentResponse("File not found", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

	}

	@PostMapping(value = "/downloadAll", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> downloadAll(@RequestBody ZipRequest zipreq, HttpServletResponse response) throws IOException {
		logger.info("Enter in Generate ZIp new================================================================================================================");
		String filePath = productStorageService.createZIPForAll(zipreq.getApplicationId(), zipreq.getProductDocumentMappingIds(), zipreq.getCoAppId(), zipreq.getClaimIds(),zipreq.getProposalId());

		if (filePath == null) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		byte[] byte_array = new byte[10];
		if (filePath.equals("empty")) {			
			return new ResponseEntity<>(byte_array, HttpStatus.NO_CONTENT);
		}
		// logger.info("Filepath--------------->" + filePath);
		byte[] readBytes = Files.readAllBytes(Paths.get(filePath));
		File file = new File(filePath);
		if (file.exists()) {
			boolean flag = file.delete();
			logger.info("file.delete() status : " + flag);
		}
		return new ResponseEntity<>(readBytes, HttpStatus.OK);
	}

	private DocumentResponse testingMode() {
//		if (configProperties.getValue(LoadTestingEnum.TESTING_MODE_ON_OFF.getKey()).equals(LoadTestingEnum.TESTING_MODE.getKey())) {
//			DocumentResponse documentResponse = new DocumentResponse();
//			StorageDetailsResponse storageDetailsResponse = new StorageDetailsResponse();
//
//			storageDetailsResponse.setId(5l);
//			storageDetailsResponse.setFilePath("Encfilename.txt");
//			storageDetailsResponse.setOriginalFileName("Encfilename.txt");
//			storageDetailsResponse.setIsUploadFrom(1);
//
//			documentResponse.setData(storageDetailsResponse);
//			documentResponse.setStatus(HttpStatus.OK.value());
//			documentResponse.setMessage("Document Uploaded Successfully");
//			return documentResponse;
//		}
		return null;
	}
	
	@PostMapping(value = "/uploadMultipleFile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<DocumentResponse> uploadMultipleFile(@RequestParam("file") MultipartFile[] multipartFiles,
															   @RequestParam("uploadRequest") String documentRequestString,
															   @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		logger.info("Enter in /uploadMultipleFile with {}", documentRequestString);
		DocumentRequest documentRequest = null;
		DocumentResponse documentResponse = testingMode();
		if(!OPLUtils.isObjectNullOrEmpty(documentResponse)){
			return new ResponseEntity<>(documentResponse, HttpStatus.OK);
		}
		try {
			documentRequest = MultipleJSONObjectHelper.getObject(documentRequestString, DocumentRequest.class);
			boolean result = productStorageService.validateRequest(documentRequest);

			if (result) {
				logger.warn(INVALID_REQUEST_MSG, documentRequest);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			if (OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId())) {
				logger.warn(INVALID_REQUEST_MSG, documentRequest);
				return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			// validate document
			List<StorageDetailsResponse> response = new ArrayList<>(multipartFiles.length);
			for (MultipartFile multipartFile : multipartFiles) {
				documentRequest.setOriginalFileName(multipartFile.getOriginalFilename());
				boolean isFileValidate = productStorageService.validateDocument(multipartFile, documentRequest);
				if (isFileValidate) {
					ProductStorageDetailsV3 productStorageDetails = productStorageService.saveFile(multipartFile.getBytes(), documentRequest, multipartFile.getSize());
					response.add(productStorageService.addStorageDetails(documentRequest, productStorageDetails, authClientResponse).setStatus(HttpStatus.OK.value()));
				} else {
					response.add(new StorageDetailsResponse(HttpStatus.BAD_REQUEST.value(), multipartFile.getOriginalFilename(), "File size is long"));
				}
			}
			return new ResponseEntity<>(new DocumentResponse("Success", HttpStatus.OK.value(), response), HttpStatus.OK);
		} catch (IOException e) {
			logger.error("Could Not Parse Json in /uploadFile {}", e);
			return new ResponseEntity<>(new DocumentResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}
	
	@PostMapping(value = "/getDocumentsByOtherTrackingId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocumentResponse> getDocumentsByOtherTrackingId(@RequestBody DocumentRequest documentRequest) {
		logger.info("Enter in /getDocumentsByOtherTrackingId with");
		try {
			if (OPLUtils.isObjectListNull(documentRequest.getProMapIds())) {
				logger.info("ProductId is null or empty !!");
				return new ResponseEntity<>(new DocumentResponse("Request paramater is null or empty !!", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<AnsProductDocumentResponse> documentsByApplicantType = productDocumentMappingService.getDocumentsByOtherTrackingId(documentRequest);
			if (documentsByApplicantType != null && !documentsByApplicantType.isEmpty()) {
				return new ResponseEntity<>(new DocumentResponse("Transferred Successfully", HttpStatus.OK.value(), documentsByApplicantType), HttpStatus.OK);
			}
			return new ResponseEntity<>(new DocumentResponse("No documents master found !!", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			logger.info("Exception while get documents master list ----> ", e);
			return new ResponseEntity<>(new DocumentResponse("The application has encountered some error, please try again later!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(value = "/downloadCoAppbureauZip", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> downloadCoAppbureauZip(@RequestBody ZipRequest zipreq, HttpServletResponse response) throws IOException {
		logger.info("Enter in Generate ZIp new================================================================================================================");
		String filePath = productStorageService.downloadCoAppbureauZip(zipreq.getApplicationId(), zipreq.getProductDocumentMappingIds(), zipreq.getCoAppId());

		if (filePath == null) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		byte[] byte_array = new byte[10];
		if (filePath.equals("empty")) {
			return new ResponseEntity<>(byte_array, HttpStatus.NO_CONTENT);
		}
		// logger.info("Filepath--------------->" + filePath);
		byte[] readBytes = Files.readAllBytes(Paths.get(filePath));
		File file = new File(filePath);
		if (file.exists()) {
			boolean flag = file.delete();
			logger.info("file.delete() status : " + flag);
		}
		return new ResponseEntity<>(readBytes, HttpStatus.OK);
	}

}
