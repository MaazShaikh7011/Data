package com.opl.jns.dms.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Created by Krunal on 11-07-23.
 */
@Getter
@Setter
@AllArgsConstructor 
@NoArgsConstructor 
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "user_storage_details")
public class UserStorageDetailsV3 implements Serializable{

    private static final long serialVersionUID = 3859661696802725341L;
  
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_storage_details_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_DMS, name = "user_storage_details_seq_gen", sequenceName = "user_storage_details_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "user_document_mapping_id")
    private Long userDocumentMappingId;

    @Column(name = "original_file_name")
    private String originalFileName;

    @Column(name = "encrypted_file_name")
    private String encryptedFileName;

    @Column(name = "local_file_path")
    private String localFilePath;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "is_file_uploaded_aws")
    private boolean isFileUploadedAws;

    @Column(name = "is_file_save_local")
    private boolean isFileSaveLocal;

    @Column(name = "version")
    private double version;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "created_by")
    private long createdBy;

    @Column(name = "modified_by")
    private long modifiedBy;

  
}
