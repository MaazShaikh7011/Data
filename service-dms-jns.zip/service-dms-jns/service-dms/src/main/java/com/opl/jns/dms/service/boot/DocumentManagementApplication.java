package com.opl.jns.dms.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableScheduling
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableDiscoveryClient
public class DocumentManagementApplication {

    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(DocumentManagementApplication.class, args);
    }

    @Bean
    public AmazonS3 amazonS3() {
        AmazonS3 amazonS3 = AmazonS3ClientBuilder.defaultClient();
        applicationContext.getAutowireCapableBeanFactory().autowireBean(amazonS3);
        return amazonS3;
    }

    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

//    @Bean
//    public AnsLogsClient clientLogs() {
//        AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
//        applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//        return ansLogsClient;
//    } 
}
