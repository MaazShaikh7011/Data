package com.opl.jns.dms.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.dms.service.domain.TypeMasterV3;


public interface TypeMasterRepositoryV3 extends JpaRepository<TypeMasterV3, Long>{

	TypeMasterV3 findByTypeIdAndSchemeId(Long disabilityTypeId, Long schemeId);

	
}
