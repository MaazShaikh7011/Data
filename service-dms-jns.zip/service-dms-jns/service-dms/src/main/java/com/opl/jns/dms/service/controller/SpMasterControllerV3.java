package com.opl.jns.dms.service.controller;


import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.dms.api.model.CommonRequest;
import com.opl.jns.dms.service.service.SpMasterServiceV3;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

@RestController
@RequestMapping("/v3")
public class SpMasterControllerV3 {

	@Autowired
	private SpMasterServiceV3 spMasterService;
	
	private static final Logger logger = LoggerFactory.getLogger(SpMasterControllerV3.class);
	
	/**
	 * FETCH ENUM MASTER LIST BY REQUESTED NAME
	 * 
	 * @param request
	 * @param authClientResponse
	 * @return OLD : getCommonList
	 */
	@PostMapping(value = "/fetchMasterData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchMasterData(@RequestBody CommonRequest request,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			String commonList = spMasterService.fetchMasterData(request.getListKey(),
					request.getWhereClause(), authClientResponse.getUserId());
			if (OPLUtils.isObjectNullOrEmpty(commonList)) {  
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems system has not found details by requested details",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, commonList, HttpStatus.OK.value(), true),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception while fetch common master list  ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	@GetMapping("/ping")
	public ResponseEntity<Object> ping() {
		logger.info("CHECK SERVICE STATUS =====================>");
		Map<String, Object> obj = new HashMap<>();
		obj.put("status", HttpStatus.OK.value());
		obj.put("message", "Service is working fine!!");
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
}
