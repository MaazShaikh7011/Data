package com.opl.jns.dms.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Created by Krunal on 03-July-23.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "product_storage_details")
public class ProductStorageDetailsV3 implements Serializable {

	private static final long serialVersionUID = 3859661696802725341L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_storage_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_DMS, name = "product_storage_details_seq_gen", sequenceName = "product_storage_details_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "application_id")
	private Long applicationId;

	@Column(name = "claim_id")
	private Long claimId;

	@Column(name = "proposal_mapping_id")
	private Long proposalMappingId;

	@Column(name = "co_applicant_detail_id")
	private Long coApplicantId;

	@Column(name = "guarantor_detail_id")
	private Long guarantorId;

	@Column(name = "director_id")
	private Long directorId;

	@Column(name = "other_tracking_id")
	private Long otherTrackingId;

	@Column(name = "original_file_name")
	private String originalFileName;

	@Column(name = "product_document_mapping_id")
	private Long productDocumentMappingId;

	@Column(name = "encrypted_file_name")
	private String encryptedFileName;

	@Column(name = "local_file_path")
	private String localFilePath;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "is_file_uploaded_aws")
	private Boolean isFileUploadedAws;

	@Column(name = "is_file_save_local")
	private Boolean isFileSaveLocal;

	@Column(name = "version")
	private double version;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "created_by")
	private long createdBy;

	@Column(name = "modified_by")
	private long modifiedBy;

	// 14 Aug For DDR Uploads(harshit)
	@Column(name = "is_upload_from")
	private Integer isUploadFrom;

	@Column(name = "module_master_id")
	private Long moduleMasterId;

	@Column(name = "document_id")
	private Long documentId;

	@Column(name = "doc_name")
	private String docName;

	@Column(name = "file_size")
	private Long fileSize;


	// constructor
	public ProductStorageDetailsV3(Long coApplicantId, String originalFileName, String encryptedFileName) {
		this.coApplicantId = coApplicantId;
		this.originalFileName = originalFileName;
		this.encryptedFileName = encryptedFileName;
	}


}
