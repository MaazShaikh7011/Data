package com.opl.jns.dms.service.util;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class ContentTypeUtil {


    private ContentTypeUtil() {
        // Do nothing because of X and Y.
    }

    public static Integer UPLOAD_IN_FOLDER = 1; // for KMS algorithm Applied

    public static Map<String, String> getContentType(String type) {
        Map<String, String> contentTypeMap = new HashMap<>();
        StringTokenizer tokenizer = new StringTokenizer(type, ",");
        while (tokenizer.hasMoreTokens()) {
            switch (tokenizer.nextToken()) {
                case "jpg":
                    contentTypeMap.put("jpg", "image/jpeg");
                    break;
                case "jpeg":
                    contentTypeMap.put("jpeg", "image/jpeg");
                    break;
                case "png":
                    contentTypeMap.put("png", "image/png");
                    break;
                case DmsUtils.EXCEL:
                    contentTypeMap.put(DmsUtils.EXCEL, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                    //added zip because tika return zip in sometime
                    contentTypeMap.put("zip", DmsUtils.APPLICATION_ZIP);
                    contentTypeMap.put("excel-new", "application/x-tika-ooxml");
                    break;
                case "excel-xls":
                    contentTypeMap.put(DmsUtils.EXCEL, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                    contentTypeMap.put("excel-xls", "application/vnd.ms-excel");
                    //added zip because tika return zip in sometime
                    contentTypeMap.put("zip", DmsUtils.APPLICATION_ZIP);
                    contentTypeMap.put("excel-new", "application/x-tika-ooxml");
                    break;
                case "doc":
                    contentTypeMap.put("doc", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                    break;
                case "ppt":
                    contentTypeMap.put("ppt", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
                    break;
                case "pdf":
                    contentTypeMap.put("pdf", "application/pdf");
                    break;
                case "xml":
                    contentTypeMap.put("xml", DmsUtils.APPLICATION_XML);
                    break;
                case "html":
                    contentTypeMap.put("html", DmsUtils.TEXT_HTML);
                    break;
                case "video":
                    contentTypeMap.put("mp4", "video/mp4");
                    contentTypeMap.put("mov", "video/quicktime");
                    contentTypeMap.put("avi", "video/x-msvideo");
                    break;
                case "zip":
                    contentTypeMap.put("zip", DmsUtils.APPLICATION_ZIP);
                    break;
                case "html-xml":
                    contentTypeMap.put("xml", "xml");
                    contentTypeMap.put(DmsUtils.APPLICATION_XML, DmsUtils.APPLICATION_XML);
                    contentTypeMap.put("html", "html");
                    contentTypeMap.put(DmsUtils.TEXT_HTML, DmsUtils.TEXT_HTML);
                    contentTypeMap.put("application/html", "application/html");
                    contentTypeMap.put("application/xhtml+xml", "application/xhtml+xml");
                    contentTypeMap.put("xhtml+xml", "xhtml+xml");
                    contentTypeMap.put("xhtml", "xhtml");
                    break;
                case "doc-rtf":
                    contentTypeMap.put("doc-rtf", "application/rtf");
                    break;
                case "csv":
                    contentTypeMap.put("csv",DmsUtils.TEXT_CSV);
                    break;
                case "txt":
                    contentTypeMap.put("txt", DmsUtils.TEXT_PLIAN);
                    break;
                default:
                    break;
            }
        }
        return contentTypeMap;
    }
}

