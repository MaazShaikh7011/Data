package com.opl.jns.dms.service.util;
//package com.opl.jns.common.service.dms.util;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.security.DigestException;
//import java.security.InvalidAlgorithmParameterException;
//import java.security.InvalidKeyException;
//import java.security.MessageDigest;
//import java.security.NoSuchAlgorithmException;
//import java.util.Arrays;
//import java.util.Base64;
//
//import javax.crypto.BadPaddingException;
//import javax.crypto.Cipher;
//import javax.crypto.IllegalBlockSizeException;
//import javax.crypto.NoSuchPaddingException;
//import javax.crypto.spec.IvParameterSpec;
//import javax.crypto.spec.SecretKeySpec;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import sun.misc.BASE64Decoder;
//
///**
// * Created by dhaval on 25-Oct-17.
// */
//public class KeyDecryption {
//
//	private static String decodedAccessKey = null;
//	private static String decodedSecretKey = null;
//	private static final String MESSAGE_DIGEST = "MD5";
//	private static final String ALGORITHM = "AES";
//	private static final String CIPHER = "AES/CBC/PKCS5Padding";
//	private static final String SECRET = "26f1ac75f77c22ebc66e2359c13ea9955ebd5e2bd7fbe50e5b3ac2977a772302";
//
//	private static final Logger logger = LoggerFactory.getLogger(KeyDecryption.class);
//
//	private KeyDecryption() {
//		// Do nothing because of X and Y.
//	}
//
//	public static String decryptKey(String key) {
//		// if (key.length() > 16) {
//		// String cipher = key.substring(16);
//		BASE64Decoder decoder = new BASE64Decoder();
//		try {
//			return new String(decoder.decodeBuffer(key));
//		} catch (IOException e) {
//			logger.error("Could not decrypt key", e);
//		}
//		// }
//		return null;
//	}
//
//	public static String getDecryptedAccessKey(String key) {
//		if (null == decodedAccessKey) {
//			decodedAccessKey = decryptKey(key);
//			return decodedAccessKey;
//		} else {
//			return decodedAccessKey;
//		}
//	}
//
//	public static String getDecryptedSecretKey(String key) {
//		if (null == decodedSecretKey) {
//			decodedSecretKey = decryptKey(key);
//			return decodedSecretKey;
//		} else {
//			return decodedSecretKey;
//		}
//	}
//
//	public static String decryptStorageId(String cipherText) {
//		String decryptedText = null;
//		int keyLength = 32;
//		int ivLength = 16;
//		byte[] password = SECRET.getBytes(StandardCharsets.UTF_8);
//		byte[] cipherData = Base64.getDecoder().decode(cipherText);
//		byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);
//		MessageDigest md5 = null;
//		try {
//			md5 = MessageDigest.getInstance(MESSAGE_DIGEST);			
//			int digestLength = md5.getDigestLength();
//			int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
//			byte[] generatedData = new byte[requiredLength];
//			int generatedLength = 0;
//			md5.reset();
//
//			while (generatedLength < keyLength + ivLength) {
//				if (generatedLength > 0)
//					md5.update(generatedData, generatedLength - digestLength, digestLength);
//				md5.update(password);
//				if (saltData != null)
//					md5.update(saltData, 0, 8);
//				md5.digest(generatedData, generatedLength, digestLength);
//				for (int i = 1; i <= 1; i++) {
//					md5.update(generatedData, generatedLength, digestLength);
//					md5.digest(generatedData, generatedLength, digestLength);
//				}
//				generatedLength += digestLength;
//			}
//			SecretKeySpec key = new SecretKeySpec(Arrays.copyOfRange(generatedData, 0, keyLength), ALGORITHM);
//			IvParameterSpec iv = new IvParameterSpec(
//					Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength));
//
//			byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
//			Cipher aesCBC = Cipher.getInstance(CIPHER);
//			aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
//			byte[] decryptedData = aesCBC.doFinal(encrypted);
//			decryptedText = new String(decryptedData, StandardCharsets.UTF_8);			
//		}
//		catch (NoSuchAlgorithmException|InvalidAlgorithmParameterException|InvalidKeyException|NoSuchPaddingException|BadPaddingException|DigestException|IllegalBlockSizeException e)
//		{	
//			logger.error("exception", e);
////			e.printStackTrace();
//		}
//		return decryptedText;
//	}
//
//}
