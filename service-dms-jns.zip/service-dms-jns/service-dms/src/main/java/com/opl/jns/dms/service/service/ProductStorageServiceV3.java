package com.opl.jns.dms.service.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3Object;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.model.ZipRequest;
import com.opl.jns.dms.service.domain.ProductStorageDetailsV3;

/**
 * Created by Krunal on 03-July-23.
 */
public interface ProductStorageServiceV3 {

    public StorageDetailsResponse addStorageDetails(DocumentRequest documentRequest, ProductStorageDetailsV3 productStorageDetails, AuthClientResponse authClientResponse);

    public ProductStorageDetailsV3 saveFile(byte[] bytes, DocumentRequest documentRequest, Long fileSize);

    public int deleteDocument(Long documentId);

    public DocumentResponse removeDocument(Long claimId);

    public DocumentResponse listOfApplicantForBankUser(Long id, Long productDocumentMappingId);

    public boolean validateRequest(DocumentRequest documentRequest);

    public boolean validateDocument(MultipartFile multipart, DocumentRequest documentRequest);

    public boolean validateDocumentSize(MultipartFile multipart,double fileSize);

    public S3Object downloadFileFromStorageId(Long storageId);
    
    public String getDocumentZip(ZipRequest zipRequest);

    public S3Object downloadDocumentByProductDocumentMappingId(Long applicationId,Long productDocumentMappingId,List<Long> coApplicantIds,Long proposalId);
   
    public S3Object downloadDocumentByDocumentMappingId(Long applicationId,Long claimId,Long productDocumentMappingId);
    
    public String createZIPForAll(Long applicationId,List<Long> productMappingIds,List<Long> coAppId, List<Long> profileIds,Long proposalId);
    
    public String downloadCoAppbureauZip(Long applicationId, List<Long> productDocumentMappingIds, List<Long> coAppId);

	public void updateProductStorageDocument(Long applicationId, Long claimId, Long productDocumentMappingId,
			Long documentId);
    
}
