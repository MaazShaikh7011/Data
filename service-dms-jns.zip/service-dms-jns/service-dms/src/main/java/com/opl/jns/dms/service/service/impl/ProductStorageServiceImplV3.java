package com.opl.jns.dms.service.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.io.FilenameUtils;
import org.apache.tika.detect.Detector;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
//import org.xml.sax.SAXException;


import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectId;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.model.ZipRequest;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.service.domain.ProductDocumentMappingV3;
import com.opl.jns.dms.service.domain.ProductStorageDetailsV3;
import com.opl.jns.dms.service.repository.ProductStorageRepositoryV3;
import com.opl.jns.dms.service.service.ProductDocumentMappingServiceV3;
import com.opl.jns.dms.service.service.ProductStorageServiceV3;
import com.opl.jns.dms.service.util.ContentTypeUtil;
import com.opl.jns.utils.common.OPLUtils;

/**
 * Created by dhaval on 15-Apr-17.
 */
@Service
@Transactional
public class ProductStorageServiceImplV3 implements ProductStorageServiceV3 {

	public static final String APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String ERROR_MESSAGE = "Error Message:    {}";
	@Autowired
	private ProductStorageRepositoryV3 productStorageRepository;

	@Autowired
	private Environment environment;

	@Autowired
	private ProductDocumentMappingServiceV3 productDocumentMappingService;

	@Autowired
	private AmazonS3 amzonS3;

	private final Logger logger = LoggerFactory.getLogger(ProductStorageServiceImplV3.class);

	private static final String DOCUMENT_PARSE_ERROR_IN_SERVER_SIDE_VALIDATION = "Document Parse Error in Server Side Validation {}";
	private static final String EXCEPTION = "Exception : ";

    private static String OS = System.getProperty("os.name").toLowerCase();

	protected static final String PROPERTY_NAME_ACCESS_KEY = "cw.aws.config.accessKey";
	protected static final String PROPERTY_NAME_SECRET_KEY = "cw.aws.config.secretKey";
	protected static final String PROPERTY_NAME_BUCKET_NAME = "cw.aws.config.bucketName";

	protected static final String PROPERTY_NAME_LOCAL_FILE_PATH = "cw.dms.localFilePath";
	protected static final String PROPERTY_NAME_S3_URL = "cw.aws.config.s3.url";
	protected static final String PROPERTY_NAME_S3_FOLDER_NAME = "cw.aws.config.folderName";
	
	private static final String EXIT_WITH_VALIDATE_REQUEST = "Exit with validateRequest() {}";
	private static final String EXIT_WITH_SET_VERSION_OF_CO_APPLICANT = "Exit with setVersionOfCoApplicant() {}";
	private static final String EXIT_WITH_SET_VERSION_OF_APPLICANT = "Exit with setVersionOfApplicant() {}";
	
	private SecureRandom r = new SecureRandom();
	public static final String MD5 = "MD5";
	
//	protected static final String SFTP_BUCKET_NAME = "cw.aws.config.sftp.bucketName";
//	protected static final String SFTP_BUCKET_URL = "cw.aws.config.sftp.bucketUrl";
//	protected static final String MCA_DIRECTORY = "cw.aws.sftp.mca.directory";
//	protected static final String DMS_MCA_DIRECTORY = "cw.dms.mca.directory";
//	protected static final String PROPERTY_NAME_S3_FOLDER_NAME_FOR_MCA = "cw.aws.config.mca.folderName";
//	protected static final String PROPERTY_NAME_EXPIRY_TIME = "cw.aws.config.expirytime";

	
	@Override
	public StorageDetailsResponse addStorageDetails(DocumentRequest documentRequest, ProductStorageDetailsV3 productStorageDetails, AuthClientResponse authClientResponse) {
		// logger.info("Entering in addStorageDetails() {} ", documentRequest, productStorageDetails);
		logger.info("Entering in addStorageDetails()");
		BeanUtils.copyProperties(documentRequest, productStorageDetails);
		productStorageDetails.setCreatedDate(new Date());
		productStorageDetails.setModifiedDate(new Date());
		productStorageDetails.setIsActive(true);
		productStorageDetails.setDocName(documentRequest.getDocName());
		productStorageDetails.setDocumentId(documentRequest.getDocumentId());
		productStorageDetails.setCreatedBy(OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserId()) ? 0 : authClientResponse.getUserId());
		if (DocumentAlias.UERT_TYPE_APPLICANT.equals(documentRequest.getUserType())) {
			setVersionOfApplicant(productStorageDetails);
		} else if (DocumentAlias.UERT_TYPE_CO_APPLICANT.equals(documentRequest.getUserType())) {
			setVersionOfCoApplicant(productStorageDetails);
		} else if (DocumentAlias.UERT_TYPE_OTHER_TRACKING.equals(documentRequest.getUserType())) {
			setVersionOfOtherTracking(productStorageDetails);
		} else if (DocumentAlias.UERT_TYPE_GUARANTOR.equals(documentRequest.getUserType())) {
			setVersionOfGuarantor(productStorageDetails);
		} else if (DocumentAlias.UERT_TYPE_DIRECTOR.equals(documentRequest.getUserType())) {
			setVersionOfDirector(productStorageDetails);
		} else if (DocumentAlias.USER_TYPE_APPLICANT_PROFILE.equals(documentRequest.getUserType())) {
			setVersionOfProfileApplicant(productStorageDetails);
		}
		
		if(!OPLUtils.isObjectNullOrEmpty(documentRequest) && !OPLUtils.isObjectNullOrEmpty(documentRequest.getProductDocumentMappingId())) {
			if(DocumentAlias.CIBIL_REPORT_MSME_COMPANY == documentRequest.getProductDocumentMappingId()) 
				productStorageRepository.inActiveMsmeCibilRecords(documentRequest.getProductDocumentMappingId() ,documentRequest.getApplicationId());	
			else if(DocumentAlias.CIBIL_REPORT_MSME_CONSUMER == documentRequest.getProductDocumentMappingId())
				productStorageRepository.inActiveIndividualCibilRecords(documentRequest.getProductDocumentMappingId() ,documentRequest.getApplicationId(), documentRequest.getCoApplicantId());
		}
		
		ProductStorageDetailsV3 sd = productStorageRepository.save(productStorageDetails);
		StorageDetailsResponse storageDetailsResponse = new StorageDetailsResponse();
		storageDetailsResponse.setId(sd.getId());
		storageDetailsResponse.setFilePath(sd.getEncryptedFileName());
		storageDetailsResponse.setOriginalFileName(sd.getOriginalFileName());
		storageDetailsResponse.setIsUploadFrom(sd.getIsUploadFrom());
		// logger.info("Exit in addStorageDetails() {}", productStorageDetails);
		logger.info("Exit in addStorageDetails()");
		return storageDetailsResponse;
	}
	
	public void setVersionOfApplicant(ProductStorageDetailsV3 productStorageDetails) {
		// logger.info("Entering in setVersionOfApplicant() {}", productStorageDetails);
		// logger.info("Entering in setVersionOfApplicant()");
		Long count = productStorageRepository.getCountOfApplicant(productStorageDetails.getApplicationId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfApplicant(productStorageDetails.getApplicationId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				// logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				// logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			// logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, 1);
		}
	}


	public void setVersionOfProfileApplicant(ProductStorageDetailsV3 productStorageDetails) {
		logger.info("Entering in setVersionOfProfileApplicant()");
		Long count = productStorageRepository.getCountOfProfileApplicant(productStorageDetails.getClaimId(), productStorageDetails.getModuleMasterId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfProfileApplicant(productStorageDetails.getClaimId(), productStorageDetails.getModuleMasterId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			logger.info(EXIT_WITH_SET_VERSION_OF_APPLICANT, 1);
		}
	}
	
	
	public void setVersionOfOtherTracking(ProductStorageDetailsV3 productStorageDetails) {
		// logger.info("Entering in setVersionOfOtherTracking() {}", productStorageDetails);
		logger.info("Entering in setVersionOfOtherTracking()");
		Long count = productStorageRepository.getCountOfOtherTracking(productStorageDetails.getOtherTrackingId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfOtherTrackingId(productStorageDetails.getOtherTrackingId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
		}
	}


	public void setVersionOfCoApplicant(ProductStorageDetailsV3 productStorageDetails) {
		// logger.info("Entering in setVersionOfCoApplicant() {}", productStorageDetails);
		logger.info("Entering in setVersionOfCoApplicant()");
		Long count = productStorageRepository.getCountOfCoApplication(productStorageDetails.getCoApplicantId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfCoApplicant(productStorageDetails.getCoApplicantId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
		}
	}

	public void setVersionOfGuarantor(ProductStorageDetailsV3 productStorageDetails) {
		// logger.info("Entering in setVersionOfGuarantor() {}", productStorageDetails);
		logger.info("Entering in setVersionOfGuarantor()");
		Long count = productStorageRepository.getCountOfGuarantor(productStorageDetails.getGuarantorId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfGuarantor(productStorageDetails.getGuarantorId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
		}
	}

	public void setVersionOfDirector(ProductStorageDetailsV3 productStorageDetails) {
		// logger.info("Entering in setVersionOfGuarantor() {}", productStorageDetails);
		logger.info("Entering in setVersionOfGuarantor()");
		Long count = productStorageRepository.getCountOfDirectorId(productStorageDetails.getDirectorId(), productStorageDetails.getProductDocumentMappingId());
		if (count > 0) {
			Long maxVersion = productStorageRepository.getMaxOfDirector(productStorageDetails.getDirectorId(), productStorageDetails.getProductDocumentMappingId());
			if (!OPLUtils.isObjectNullOrEmpty(maxVersion)) {
				productStorageDetails.setVersion((maxVersion + 1));
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, maxVersion + 1);
			} else {
				productStorageDetails.setVersion(1);
				logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
			}
		} else {
			productStorageDetails.setVersion(1);
			logger.info(EXIT_WITH_SET_VERSION_OF_CO_APPLICANT, 1);
		}
	}

	public String encryptFileName(String fileName) {
		// logger.info("Entering in encryptFileName() {}", fileName);
		// logger.info("Entering in encryptFileName()");
		String[] file = fileName.split("\\.");
		String extension = file[(file.length - 1)];
		String fileFullName = "";
		if (file.length > 2) {
			for (int i = 0; i < file.length - 1; i++) {
				fileFullName += file[i];
			}
		}
		byte[] unencodedFile = fileFullName.getBytes();
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance(MD5);
		} catch (Exception e) {
			logger.error("Error While Encrypting File Name", e);
		}
		StringBuffer buf = new StringBuffer();
		if (md != null) {
			md.reset();
			md.update(unencodedFile);
			byte[] encodedFile = md.digest();
			for (int i = 0; i < encodedFile.length; i++) {
				if (((int) encodedFile[i] & 0xff) < 0x10) {
					buf.append("0");
				}
				buf.append(Long.toString((int) encodedFile[i] & 0xff, 16));
			}
		}
		String encryptedFileName = (buf.toString()).concat(String.valueOf(this.r.nextInt()));
		// logger.info("Exit with encryptFileName() {}", encryptedFileName + "." + extension);
		// logger.info("Exit with encryptFileName()");
		return encryptedFileName + "." + extension;
	}

	public boolean saveFileOnAWS(String fileName, byte[] bytes, String encryptedFileName) {
		// logger.info("Entering in saveFileOnAWS() {}", encryptedFileName);
		// logger.info("Entering in saveFileOnAWS()");
		String keyName = "";
		String contentType = "";
		// Create the file on amazon server
		InputStream is = new ByteArrayInputStream(bytes);
		keyName = environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName;
		String ext = FilenameUtils.getExtension(encryptedFileName);
		if (ext.equalsIgnoreCase("jpg")) {
			contentType = "image/jpeg";
		} else if (ext.equalsIgnoreCase("jpeg")) {
			contentType = "image/jpeg";
		} else if (ext.equalsIgnoreCase("png")) {
			contentType = "image/png";
		} else if (ext.equalsIgnoreCase("pdf")) {
			contentType = "application/pdf";
		} else if (ext.equalsIgnoreCase("docx")) {
			contentType = "application/msword";
		} else if (ext.equalsIgnoreCase("pptx")) {
			contentType = "application/vnd.ms-powerpoint";
		} else if (ext.equalsIgnoreCase("xlsx")) {
			contentType = APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET;
		} else if (ext.equalsIgnoreCase("mp4")) {
			contentType = "video/mp4";
		}
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType(contentType);
		metadata.setContentLength(bytes.length);
		try {
			amzonS3.putObject(new PutObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), keyName, is, metadata).withCannedAcl(CannedAccessControlList.Private));
		} catch (AmazonServiceException ase) {
			logger.info("Caught an AmazonServiceException, which " + "means your request made it " + "to Amazon S3, but was rejected with an error response" + " for some reason.");
			logger.info(ERROR_MESSAGE, ase.getMessage());
			logger.info("HTTP Status Code: {}", ase.getStatusCode());
			logger.info("AWS Error Code:   {}", ase.getErrorCode());
			logger.info("Error Type:       {}", ase.getErrorType());
			logger.info("Request ID:       {}", ase.getRequestId());
			logger.error("ERROR WHILE saveFileOnAWS() ---- AmazonServiceException ---> ", ase);
			return false;
		} catch (AmazonClientException ace) {
			logger.info("Caught an AmazonClientException, which " + "means the client encountered " + "an internal error while trying to " + "communicate with S3, " + "such as not being able to access the network.");
			logger.info("Error Message: {}", ace.getMessage());
			logger.error("ERROR WHILE saveFileOnAWS() ---- AmazonClientException ---> ", ace);
			return false;
		}
		// logger.info("File uploaded at s3 file name -> " + fileName + " amazon s3 path -> " + keyName);
		// logger.info("File uploaded at s3 file name");
		return true;
	}

	@Override
	public ProductStorageDetailsV3 saveFile(byte[] bytes, DocumentRequest documentRequest, Long fileSize) {
		// logger.info("Entering in saveFile() {}", fileName, documentRequest);
		// logger.info("Entering in saveFile()");
		documentRequest.setOriginalFileName(documentRequest.getOriginalFileName().replaceAll("/", ""));
		String encryptedFileName = encryptFileName(documentRequest.getOriginalFileName());
		ProductStorageDetailsV3 productStorageDetails = saveFileOnLocal(documentRequest.getOriginalFileName(), bytes, documentRequest);
		if (productStorageDetails.getIsFileSaveLocal().booleanValue()) {
			productStorageDetails.setIsFileUploadedAws(saveFileOnAWS(documentRequest.getOriginalFileName(), bytes, encryptedFileName));
		} else {
			productStorageDetails.setIsFileUploadedAws(false);
		}
		productStorageDetails.setEncryptedFileName(encryptedFileName);
		productStorageDetails.setFileSize(fileSize);
		// 14 Aug For DDR Uploads(harshit)
		productStorageDetails.setIsUploadFrom(documentRequest.getIsUploadFrom());
		// logger.info("Exit with saveFile() {},", productStorageDetails);
		// logger.info("Exit with saveFile()");
		return productStorageDetails;
	}


	public ProductStorageDetailsV3 saveFileOnLocal(String fileName, byte[] bytes, DocumentRequest documentRequest) {
		// logger.info("Entering in saveFileOnLocal() {},{}", fileName, documentRequest);
		logger.info("Entering in saveFileOnLocal()");
		ProductStorageDetailsV3 productStorageDetails = new ProductStorageDetailsV3();
		String localPath;
		String storeFileName = null;
		String extension = null;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		StringTokenizer tokenizer = new StringTokenizer(fileName, ".");
		localPath = environment.getProperty(PROPERTY_NAME_LOCAL_FILE_PATH);
		File file = new File(localPath);
		if (!file.exists()) {
			file.mkdirs();
		}
		storeFileName = tokenizer.nextToken();
		extension = tokenizer.nextToken();
		String date = format.format(new Date()).trim();
		date = date.replaceAll("-", "_");
		date = date.replaceAll(":", "-");
		date = date.trim();
		storeFileName += "_" + date + "." + extension;
		storeFileName = storeFileName.trim();
		try {
//			storeFileName = storeFileName.replaceAll("/", "~#&");
			Path path = Paths.get(localPath + storeFileName);
//			storeFileName = storeFileName.replaceAll("~#&", "/");
			Files.write(path, bytes);
			productStorageDetails.setIsFileSaveLocal(true);
			productStorageDetails.setLocalFilePath(localPath + storeFileName);
			productStorageDetails.setIsUploadFrom(documentRequest.getIsUploadFrom());
			// logger.info("Exit with saveFileOnLocal() {}", productStorageDetails);
			logger.info("Exit with saveFileOnLocal()");
		} catch (IOException e) {
			productStorageDetails.setIsFileSaveLocal(false);
			productStorageDetails.setIsUploadFrom(documentRequest.getIsUploadFrom());
			logger.error("file not saved in local! because : ", e);
		}
		return productStorageDetails;
	}

	@Override
	public int deleteDocument(Long documentId) {
		// logger.info("Entering in saveFileOnLocal() {}", documentId);
		logger.info("Entering in saveFileOnLocal()");
		int rowUpdated = productStorageRepository.deleteDocument(documentId,new Date());
		// logger.info("Exit with saveFileOnLocal() {}", rowUpdated);
		logger.info("Exit with saveFileOnLocal()");
		return rowUpdated;
	}

	@Override
	public DocumentResponse removeDocument(Long claimId) {
		productStorageRepository.removeDocument(claimId, new Date());
		return new DocumentResponse("Successfully Deleted", HttpStatus.OK.value());
	}

	@Override
	public DocumentResponse listOfApplicantForBankUser(Long id, Long productDocumentMappingId) {
		// logger.info("Entering in listOfApplicantForBankUser() {},{} ", id, productDocumentMappingId);
		logger.info("Entering in listOfApplicantForBankUser()");
		String setPath = environment.getProperty(PROPERTY_NAME_S3_URL) + environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME);
		List<StorageDetailsResponse> storageDetailsList = productStorageRepository.listDocumentApplicantForBankUser(id, productDocumentMappingId);
		for (StorageDetailsResponse detailsResponse : storageDetailsList) {
			detailsResponse.setFilePath(setPath + detailsResponse.getFilePath());
		}
		DocumentResponse documentResponse = new DocumentResponse();
		documentResponse.setDataList(storageDetailsList);
		// logger.info("Exit with listOfApplicantForBankUser() {} ", documentResponse);
		logger.info("Exit with listOfApplicantForBankUser()");
		return documentResponse;
	}

	@Override
	public boolean validateRequest(DocumentRequest documentRequest) {
		// logger.info("Entering in validateRequest() {} ", documentRequest);
		logger.info("Entering in validateRequest()");
		boolean result = false;
		if (!OPLUtils.isObjectNullOrEmpty(documentRequest.getUserType())) {
			switch (documentRequest.getUserType()) {
			case DocumentAlias.UERT_TYPE_APPLICANT:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getApplicationId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.UERT_TYPE_CO_APPLICANT:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getCoApplicantId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.UERT_TYPE_GUARANTOR:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getGuarantorId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case "corpCoApplicant":
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getCoApplicantId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.UERT_TYPE_DIRECTOR:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getDirectorId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.UERT_TYPE_OTHER_TRACKING:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getOtherTrackingId());
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.UERT_TYPE_USER:
				result = false;
				// logger.info(EXIT_WITH_VALIDATE_REQUEST, result);
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			case DocumentAlias.USER_TYPE_APPLICANT_PROFILE:
				result = OPLUtils.isObjectNullOrEmpty(documentRequest.getClaimId());
				if (result)
					result = OPLUtils.isObjectNullOrEmpty(documentRequest.getModuleMasterId());
				logger.info(EXIT_WITH_VALIDATE_REQUEST);
				break;
			default:
				result = true;
				break;
			}
		} else {
			result = true;
		}
		return result;
	}
	
	public String serverSideValidation(MultipartFile multipart, DocumentRequest documentRequest) {
		// logger.info("Entering in serverSideValidation() ");
		String contentType = null;
		try {
			InputStream is = null;
			byte[] bytes = multipart.getBytes();
			is = new ByteArrayInputStream(bytes);
			AutoDetectParser parser = new AutoDetectParser();
			Detector detector = parser.getDetector();
			Metadata md = new Metadata();
			md.add(Metadata.RESOURCE_NAME_KEY, multipart.getOriginalFilename());
			MediaType mediaType = detector.detect(is, md);
			contentType = mediaType.toString();
			// logger.info("ContentType ==>>>",contentType);
			// logger.info("File Name ==>>>",documentRequest.getOriginalFileName());
			if ("application/x-tika-ooxml".equals(contentType)) {
				// logger.info("Enter in application/x-tika-ooxml ==>>>");
				ParseContext context = new ParseContext();
				BodyContentHandler handler = new BodyContentHandler();
				parser.parse(is, handler, md, context);
				contentType = md.get("Content-Type");
			} else if ("application/octet-stream".equalsIgnoreCase(contentType)) {
				// logger.info("Enter in application/octet-stream ==>>>");
				String[] file = documentRequest.getOriginalFileName().split("\\.");
				String extension = file[(file.length - 1)];
				if (extension.equalsIgnoreCase("xml")) {
					contentType = "application/xml";
				}
			} else if ("text/plain".equalsIgnoreCase(contentType)) {
				// logger.info("Enter in text/plain ==>>>");
				String[] file = documentRequest.getOriginalFileName().split("\\.");
				String extension = file[(file.length - 1)];
				if (extension.equalsIgnoreCase("xml")) {
					contentType = "application/xml";
				} else if (extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("xls")) {
					contentType = APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET;
				}
			} else if ("application/vnd.ms-excel".equalsIgnoreCase(contentType) || OPLUtils.isObjectNullOrEmpty(contentType)) {
				// logger.info("Enter in application/vnd.ms-excel ==>>>");
				String[] file = documentRequest.getOriginalFileName().split("\\.");
				String extension = file[(file.length - 1)];
				if (extension.equalsIgnoreCase("xml")) {
					contentType = "application/xml";
				} else if (extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("xls")) {
					contentType = APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET;
				}

			}
			// logger.info("ContentType",contentType);
//			else if ("application/msword".equalsIgnoreCase(contentType)) {
//				String[] file = documentRequest.getOriginalFileName().split("\\.");
//				String extension = file[(file.length - 1)];
//				if (extension.equalsIgnoreCase("xml")) {
//					contentType = "application/xml";
//				} else if (extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("xls")) {
//					contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
//				}
//			}
		} catch (IOException |  TikaException e) {
			logger.error(DOCUMENT_PARSE_ERROR_IN_SERVER_SIDE_VALIDATION, e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// logger.info("Exit with serverSideValidation() {}", contentType);
		// logger.info("Exit with serverSideValidation()");
		return contentType;
	}

	@Override
	public boolean validateDocument(MultipartFile multipart, DocumentRequest documentRequest) {
		// logger.info("Entering in validateDocument() {} ", documentRequest);
		String contentType = serverSideValidation(multipart, documentRequest);
		if (contentType != null) {
			ProductDocumentMappingV3 productDocumentMapping = productDocumentMappingService.getProductDocumentMappingById(documentRequest.getProductDocumentMappingId());
			// logger.info("productDocumentMapping ::::::{}", productDocumentMapping);

			// return false for file extension not matched
			if (Boolean.FALSE.equals(validateDocumentExtension(multipart, productDocumentMapping))) {
				logger.info("Document extension not matched.");
				return false;
			}

			Map<String, String> map = ContentTypeUtil.getContentType(productDocumentMapping.getDocumentMaster().getType());
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if (contentType.equalsIgnoreCase(entry.getValue())) {
					// logger.info("Document match with :" + entry.getKey() + " Content Type for : " + documentRequest);
					// logger.info("Document match with");
					return true;
//					boolean isFileBig = validateDocumentSize(multipart, productDocumentMapping.getDocumentMaster().getSize());
//					if (isFileBig) {
//						logger.info("Exit with validateDocument() {}", "false");
//						return false;
//					} else {
//						logger.info("Exit with validateDocument() {}", "true");
//						return true;
//					}
				}
			}
		}
		return false;
	}

	private Boolean validateDocumentExtension(MultipartFile multipart, ProductDocumentMappingV3 productDocumentMapping) {
		//skipping validation for original file name and extension in case of byte Array
		if (Boolean.TRUE.equals(productDocumentMapping.isSkipExtension())) {
			return true;
		}

		logger.info("CHECKING validateDocumentExtension...");
		String fileExtension = FilenameUtils.getExtension(multipart.getOriginalFilename());
		logger.info("FETCHED EXTENSION ::: {}", fileExtension);
		for (String extension : productDocumentMapping.getDocumentMaster().getType().split(",")) {
			if (fileExtension.equalsIgnoreCase(extension)) {
				logger.info("Document extension matched.");
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean validateDocumentSize(MultipartFile multipart, double fileSize) {
		// logger.info("Entering in validateDocumentSize() {} ", fileSize);
		// logger.info("Entering in validateDocumentSize()");
		double fileSizeInKB = multipart.getSize() / 1024d;
		double fileSizeInMB = fileSizeInKB / 1024;
		if (fileSizeInMB > fileSize) {
			// logger.info("Exit with validateDocumentSize() {}", fileSizeInMB);
			// logger.info("Exit with validateDocumentSize()");
			return false;
		} else {
			// logger.info("Exit with validateDocumentSize() {}", fileSizeInMB);
			// logger.info("Exit with validateDocumentSize()");
			return true;
		}
	}

	@Override
	public S3Object downloadFileFromStorageId(Long storageId) {
		S3Object s3object = null;
		try {
			String encryptedFileName = productStorageRepository.getEncryptedFileNameFromStorageId(storageId);
			s3object = amzonS3.getObject(new GetObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName));
			// logger.info("Downloading File with Storage Id : " + storageId);
			logger.info("Downloading File with Storage Id");
			return s3object;

		} catch (AmazonServiceException ase) {
			logger.info("Caught an AmazonServiceException from GET requests, rejected reasons:");
			logger.info(ERROR_MESSAGE, ase.getMessage());
			logger.info("HTTP Status Code: {}", ase.getStatusCode());
			logger.info("AWS Error Code:   {}", ase.getErrorCode());
			logger.info("Error Type:       {}", ase.getErrorType());
			logger.info("Request ID:       {}", ase.getRequestId());
			logger.error("ERROR WHILE downloadFileFromStorageId() ---- AmazonServiceException ---> ", ase);
			return s3object;
		} catch (AmazonClientException ace) {
			logger.info("Caught an AmazonClientException: ");
			logger.info("Error Message: {}", ace.getMessage());
			logger.error("ERROR WHILE downloadFileFromStorageId() ---- AmazonClientException ---> ", ace);
			return s3object;
		}
	}

	/**
	 * zip file implementation Nilay
	 */
	@Override
	public String getDocumentZip(ZipRequest zipRequest) {
//		Long applicationId, List<Long> productMappingIdList, List<Long> coAppId, List<Long> profileIds
		List<StorageDetailsResponse> list = null;
		if (!OPLUtils.isObjectNullOrEmpty(zipRequest.getApplicationId()) && !OPLUtils.isObjectNullOrEmpty(zipRequest.getClaimId()) && OPLUtils.isListNullOrEmpty(zipRequest.getProductDocumentMappingIds())) {
			list = productStorageRepository.findAllByApplicationIdAndClaimId(zipRequest.getApplicationId(),zipRequest.getClaimId());
		}
//		else if (!OPLUtils.isObjectNullOrEmpty(zipRequest.getApplicationId()) && !OPLUtils.isObjectNullOrEmpty(zipRequest.getClaimId()) && !OPLUtils.isListNullOrEmpty(zipRequest.getProductDocumentMappingIds())) {
//			list = productStorageRepository.findAllByApplicationIdAndClaimIdAndProductMappingIds(zipRequest.getApplicationId(),zipRequest.getClaimId(),zipRequest.getProductDocumentMappingIds());
//		}
		
		else {
			list = productStorageRepository.listDocumentByPrductDocumentMappingIds(zipRequest.getApplicationId(), zipRequest.getProductDocumentMappingIds(), zipRequest.getCoAppId());
			if (!OPLUtils.isListNullOrEmpty(zipRequest.getClaimIds())) {
				logger.info("Profile Id found for ApplicationId", zipRequest.getClaimIds());
				List<StorageDetailsResponse> listByProfileId = productStorageRepository.listDocumentByClaimIdAndPrductDocumentMappingIds(zipRequest.getClaimIds(), zipRequest.getProductDocumentMappingIds());
				if (!OPLUtils.isListNullOrEmpty(listByProfileId)) {
					list.addAll(listByProfileId);
				}
			}
		}

		if (OPLUtils.isListNullOrEmpty(list)) {
			return null;
		}

		String dirName = zipRequest.getApplicationId() + "_uploads";
		File dir = new File(dirName);
		if (!dir.exists() && !dir.mkdir()) {
			// logger.info("Something goes wrong while creting Folder named===>{}", dirName);
			logger.info("Something goes wrong while creating Folder named :");
			return null;
		}

		int i = 0;
		for (StorageDetailsResponse storageDet : list) {
			try {
				String fileName = dirName + "/" + storageDet.getOriginalFileName().substring(0, storageDet.getOriginalFileName().lastIndexOf(".")) + "_" + i + "." + getExtensionFromFileName(storageDet.getOriginalFileName());
				File fileToWrite = new File(fileName);
				logger.info("fileName===>{}", fileName);
				S3ObjectId id = new S3ObjectId(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + storageDet.getFilePath());
				S3Object object = amzonS3.getObject(new GetObjectRequest(id));
				InputStream in = object.getObjectContent();
				byte[] buf = new byte[1024];
				OutputStream out = new FileOutputStream(fileToWrite);
				int count = 0;
				while ((count = in.read(buf)) != -1) {
					if (Thread.interrupted()) {
						try {
							throw new InterruptedException();
						} catch (InterruptedException e) {
							logger.error(EXCEPTION, e);
							Thread.currentThread().interrupt();
						}
					}
					out.write(buf, 0, count);
				}
				out.close();
				in.close();
				i++;
			} catch (IOException e) {
				logger.error(EXCEPTION, e);
			}
		}
		if (isMac()) {
		} else if (isUnix() || isWindows()) {
			try {
				Boolean flag;
				System.out.println(dir.getAbsolutePath());
				String tempDirName = "zip -r " + dirName + ".zip  " + dirName;
				Process process = Runtime.getRuntime().exec(tempDirName.split(" "));
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					logger.info(line + "\n");
				}
				logger.info("list" + line);
				process.waitFor();
				if (dir.exists()) {
					for (File file : dir.listFiles()) {
						flag = file.delete();
					}
					flag = dir.delete();
				}
				dir = new File(dirName + ".zip");
				String absoluteFilePath = dir.getAbsolutePath();
				byte[] b = Files.readAllBytes(Paths.get(absoluteFilePath));
				return absoluteFilePath;
			} catch (IOException | InterruptedException e) {
				logger.error(EXCEPTION, e);
				Thread.currentThread().interrupt();
			}
		} else if (isSolaris()) {
			logger.info("This is Solaris");
		} else {
			logger.info("Your OS is not support!!");
		}
		return null;
	}

	private String getExtensionFromFileName(String fileName) {
		String[] file = fileName.split("\\.");
		return file[(file.length - 1)];
	}

	public static boolean isWindows() {
		return (OS.indexOf("win") >= 0);
	}

	public static boolean isMac() {
		return (OS.indexOf("mac") >= 0);
	}

	public static boolean isUnix() {
		return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0);
	}

	public static boolean isSolaris() {
		return (OS.indexOf("sunos") >= 0);
	}

	@Override
	public S3Object downloadDocumentByProductDocumentMappingId(Long applicationId, Long productDocumentMappingId, List<Long> coApplicantIds,Long proposalId) {
		S3Object s3object = null;
		try {
//			String encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationIdAndProposalId(applicationId, productDocumentMappingId, coApplicantIds,proposalId);
////			if(OPLUtils.isObjectNullOrEmpty(encryptedFileName))
////				encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationId(applicationId, productDocumentMappingId, coApplicantIds);
//			logger.info("encryptedFileName :::" + encryptedFileName);
//			s3object = amzonS3.getObject(new GetObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName));
//			return s3object;
			String encryptedFileName = null;
			if(OPLUtils.isListNullOrEmpty(coApplicantIds)) {
				encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationId(applicationId, productDocumentMappingId);
			} else {
				encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationIdAndCoAppIds(applicationId, productDocumentMappingId, coApplicantIds);
			}
			logger.info("encryptedFileName :::" + encryptedFileName);
			s3object = amzonS3.getObject(new GetObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName));
			return s3object;
		} catch (AmazonServiceException ase) {
			logger.info("Caught an AmazonServiceException from GET requests, rejected reasons:");
			logger.info(ERROR_MESSAGE, ase.getMessage());
			logger.info("HTTP Status Code: {}", ase.getStatusCode());
			logger.info("AWS Error Code:   {}", ase.getErrorCode());
			logger.info("Error Type:       {}", ase.getErrorType());
			logger.info("Request ID:       {}", ase.getRequestId());
			logger.error("ERROR WHILE downloadDocumentByProductDocumentMappingId() ---- AmazonServiceException ---> ", ase);
			return s3object;
		} catch (AmazonClientException ace) {
			logger.info("Caught an AmazonClientException: ");
			logger.info("Error Message: {}", ace.getMessage());
			logger.error("ERROR WHILE downloadDocumentByProductDocumentMappingId() ---- AmazonClientException ---> ", ace);
			return s3object;
		}
	}

	@Override
	public S3Object downloadDocumentByDocumentMappingId(Long applicationId,Long claimId, Long productDocumentMappingId) {
		S3Object s3object = null;
		try {
			String encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationIdANDClaimIdANDDocMappingId(applicationId,claimId, productDocumentMappingId);
			logger.info("encryptedFileName :::" + encryptedFileName);
			s3object = amzonS3.getObject(new GetObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName));
			return s3object;

		} catch (AmazonServiceException ase) {
			logger.info("Caught an AmazonServiceException from GET requests, rejected reasons:");
			logger.info(ERROR_MESSAGE, ase.getMessage());
			logger.info("HTTP Status Code: {}", ase.getStatusCode());
			logger.info("AWS Error Code:   {}", ase.getErrorCode());
			logger.info("Error Type:       {}", ase.getErrorType());
			logger.info("Request ID:       {}", ase.getRequestId());
			logger.error("ERROR WHILE downloadDocumentByDocumentMappingId() ---- AmazonServiceException ---> ", ase);
			return s3object;
		} catch (AmazonClientException ace) {
			logger.info("Caught an AmazonClientException: ");
			logger.info("Error Message: {}", ace.getMessage());
			logger.error("ERROR WHILE downloadDocumentByDocumentMappingId() ---- AmazonClientException ---> ", ace);
			return s3object;
		}
	}

	@Override
	public String createZIPForAll(Long applicationId, List<Long> productMappingIds, List<Long> coAppId, List<Long> profileIds,Long proposalId) {
		List<ProductStorageDetailsV3> productStorage = new ArrayList<>();
		List<ProductStorageDetailsV3> productStorageForApplicationform = new ArrayList<>();
		List<StorageDetailsResponse> stoResList = new ArrayList<>();

		
		StorageDetailsResponse stoRes = null;
		if (productMappingIds.contains(678l)) {
			Pageable pageable = PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC, "id"));
			productStorage = productStorageRepository.getCamReport(applicationId, 678l,pageable);
			productMappingIds.remove(678l);
			for (ProductStorageDetailsV3 prodetail : productStorage) {
				stoRes = new StorageDetailsResponse();
				stoRes.setFilePath(prodetail.getEncryptedFileName());
				stoRes.setId(prodetail.getId());
				stoRes.setOriginalFileName(prodetail.getOriginalFileName());
				stoResList.add(stoRes);
			}

		}
		if (productMappingIds.contains(740l)) {
			Pageable pageable = PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC,"id"));
			productStorageForApplicationform = productStorageRepository.getApplicationForm(applicationId, 740l, pageable);
			productMappingIds.remove(740l);
			for (ProductStorageDetailsV3 prodetail : productStorageForApplicationform) {
				stoRes = new StorageDetailsResponse();
				stoRes.setFilePath(prodetail.getEncryptedFileName());
				stoRes.setId(prodetail.getId());
				stoRes.setOriginalFileName(prodetail.getOriginalFileName());
				stoResList.add(stoRes);
			}
		}
		
		if (productMappingIds.contains(764l)) {
			Pageable pageable = PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC,"id"));
			List<ProductStorageDetailsV3> acknowledgementLetterDoc = productStorageRepository.getAcknowledgementDocument(applicationId, 764l, pageable);
		     productMappingIds.remove(764l);
			for(ProductStorageDetailsV3 prodDetail : acknowledgementLetterDoc) {
				 stoRes = new StorageDetailsResponse();
				 stoRes.setFilePath(prodDetail.getEncryptedFileName());
			     stoRes.setId(prodDetail.getId());
				 stoRes.setOriginalFileName(prodDetail.getOriginalFileName());
				 stoResList.add(stoRes);	
			}
		}
		
		if (productMappingIds.contains(575l) || productMappingIds.contains(365l)) {
			productStorage = productStorageRepository.getBueraueReport(applicationId, 575l, productMappingIds.contains(365l) ? 365l :0l);
			productMappingIds.remove(575l);
			productMappingIds.remove(365l);
			for (ProductStorageDetailsV3 prodetail : productStorage) {
				stoRes = new StorageDetailsResponse();
				stoRes.setFilePath(prodetail.getEncryptedFileName());
				stoRes.setId(prodetail.getId());
				stoRes.setOriginalFileName(prodetail.getOriginalFileName());
				stoResList.add(stoRes);
			}
		}
		
		if (productMappingIds.contains(778l)) {
			Pageable pageable = PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC,"id"));
			productStorage = productStorageRepository.getCamReport(applicationId, 778l,pageable);
			productMappingIds.remove(778l);
			for (ProductStorageDetailsV3 prodetail : productStorage) {
				stoRes = new StorageDetailsResponse();
				stoRes.setFilePath(prodetail.getEncryptedFileName());
				stoRes.setId(prodetail.getId());
				stoRes.setOriginalFileName(prodetail.getOriginalFileName());
				stoResList.add(stoRes);
			}

		}
	
		
		List<StorageDetailsResponse> list = productStorageRepository.listDocumentByPrductDocumentMappingIdsByProposalId(applicationId, productMappingIds, coAppId,proposalId);

//		if(OPLUtils.isListNullOrEmpty(list)) {
//			list = productStorageRepository.listDocumentByPrductDocumentMappingIds(applicationId, productMappingIds, coAppId);
//			
//		}
		
//		Long profileId = productStorageRepository.getProfileIdByAppId(applicationId);
		if (!OPLUtils.isListNullOrEmpty(profileIds)) {
			logger.info("Profile Id found for ApplicationId", +applicationId);
			List<StorageDetailsResponse> listByProfileId = productStorageRepository.listDocumentByClaimIdAndPrductDocumentMappingIds(profileIds, productMappingIds);
			if (!OPLUtils.isListNullOrEmpty(listByProfileId)) {
				list.addAll(listByProfileId);
			}
		}
		if (!OPLUtils.isListNullOrEmpty(stoResList)) {
			for (StorageDetailsResponse res : stoResList) {
				list.add(res);
			}
		}
		if (OPLUtils.isListNullOrEmpty(list)) {
			return "empty";
		}
		String dirName = applicationId + "_uploads";
		File dir = new File(dirName);
		if (!dir.exists() && !dir.mkdir()) {
			// logger.info("Something goes wrong while creting Folder named===>{}", dirName);
			logger.info("Something goes wrong while creating Folder named :");
			return null;
		}
		int i = 0;

		for (StorageDetailsResponse storageDet : list) {
			try {
				String fileName = dirName + "/" + storageDet.getOriginalFileName().substring(0, storageDet.getOriginalFileName().lastIndexOf(".")) + "_" + i + "." + getExtensionFromFileName(storageDet.getOriginalFileName());
				File fileToWrite = new File(fileName);
				logger.info("fileName===>{}", fileName);
				S3ObjectId id = new S3ObjectId(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_BUCKET_NAME) + storageDet.getFilePath());
				S3Object object = amzonS3.getObject(new GetObjectRequest(id));
				InputStream in = object.getObjectContent();
				byte[] buf = new byte[1024];
				try(OutputStream out = new FileOutputStream(fileToWrite)) {
					int count = 0;
					while ((count = in.read(buf)) != -1) {
						if (Thread.interrupted()) {
							try {
								throw new InterruptedException();
							} catch (InterruptedException e) {
								logger.error(EXCEPTION, e);
								Thread.currentThread().interrupt();
							}
						}
						out.write(buf, 0, count);
					}
					out.close();
				}
				in.close();
				i++;
			} catch (IOException e) {
				logger.error(EXCEPTION, e);
			}
		}
		if (isMac()) {
		} else if (isUnix() || isWindows()) {
			try {
				Boolean flag;
				String tempDirName = "zip -r " + dirName + ".zip  " + dirName;
				Process process = Runtime.getRuntime().exec(tempDirName.split(" "));
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					logger.info(line + "\n");
				}
				logger.info("list" + line);
				process.waitFor();
				if (dir.exists()) {
					for (File file : dir.listFiles()) {
						flag = file.delete();
					}
					flag = dir.delete();
				}
				dir = new File(dirName + ".zip");
				String absoluteFilePath = dir.getAbsolutePath();
				byte[] b = Files.readAllBytes(Paths.get(absoluteFilePath));
				return absoluteFilePath;
			} catch (IOException | InterruptedException e) {
				logger.error(EXCEPTION, e);
				Thread.currentThread().interrupt();
			}
		} else if (isSolaris()) {
			logger.info("This is Solaris");
		} else {
			logger.info("Your OS is not support!!");
		}
		return null;
	}

	@Override
	public String downloadCoAppbureauZip(Long applicationId, List<Long> productDocumentMappingIds, List<Long> coAppId) {
		List<StorageDetailsResponse> list = productStorageRepository.listDocumentByPrductDocumentMappingIdsAndCoApplicantId(productDocumentMappingIds, coAppId);
		if (OPLUtils.isListNullOrEmpty(list)) {
			return "empty";
		}
		String dirName = applicationId + "_uploads";
		File dir = new File(dirName);
		if (!dir.exists() && !dir.mkdir()) {
			logger.info("Something goes wrong while creating Folder named :");
			return null;
		}
		int i = 0;

		for (StorageDetailsResponse storageDet : list) {
			try {
				String fileName = dirName + "/" + storageDet.getOriginalFileName().substring(0, storageDet.getOriginalFileName().lastIndexOf(".")) + "_" + i + "." + getExtensionFromFileName(storageDet.getOriginalFileName());
				File fileToWrite = new File(fileName);
				logger.info("fileName===>{}", fileName);
				S3ObjectId id = new S3ObjectId(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + storageDet.getFilePath());
				S3Object object = amzonS3.getObject(new GetObjectRequest(id));
				InputStream in = object.getObjectContent();
				byte[] buf = new byte[1024];
				try(OutputStream out = new FileOutputStream(fileToWrite)) {
					int count = 0;
					while ((count = in.read(buf)) != -1) {
						if (Thread.interrupted()) {
							try {
								throw new InterruptedException();
							} catch (InterruptedException e) {
								logger.error(EXCEPTION, e);
								Thread.currentThread().interrupt();
							}
						}
						out.write(buf, 0, count);
					}
					out.close();
				}
				in.close();
				i++;
			} catch (IOException e) {
				logger.error(EXCEPTION, e);
			}
		}
		if (isMac()) {
		} else if (isUnix() || isWindows()) {
			try {
				Boolean flag;
				String tempDirName = "zip -r " + dirName + ".zip  " + dirName;
				Process process = Runtime.getRuntime().exec(tempDirName);
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					logger.info(line + "\n");
				}
				logger.info("list" + line);
				process.waitFor();
				if (dir.exists()) {
					for (File file : dir.listFiles()) {
						flag = file.delete();
					}
					flag = dir.delete();
				}
				dir = new File(dirName + ".zip");
				String absoluteFilePath = dir.getAbsolutePath();
				byte[] b = Files.readAllBytes(Paths.get(absoluteFilePath));
				return absoluteFilePath;
			} catch (IOException | InterruptedException e) {
				logger.error(EXCEPTION, e);
				Thread.currentThread().interrupt();
			}
		} else if (isSolaris()) {
			logger.info("This is Solaris");
		} else {
			logger.info("Your OS is not support!!");
		}
		return null;
	}

	@Override
	public void updateProductStorageDocument(Long applicationId, Long claimId, Long productDocumentMappingId,
			Long documentId) {
		 productStorageRepository.updateProductStorageDocument(applicationId,claimId,productDocumentMappingId,documentId);
	}
	
	
}
