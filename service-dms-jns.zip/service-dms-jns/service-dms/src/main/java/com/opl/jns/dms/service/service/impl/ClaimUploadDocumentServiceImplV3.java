package com.opl.jns.dms.service.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.dms.service.domain.TypeMasterV3;
import com.opl.jns.dms.service.repository.TypeMasterRepositoryV3;
import com.opl.jns.dms.service.service.ClaimUploadDocumentServiceV3;
import com.opl.jns.utils.common.OPLUtils;

@Service
public class ClaimUploadDocumentServiceImplV3 implements ClaimUploadDocumentServiceV3{

	@Autowired
	private TypeMasterRepositoryV3 typeMasterRepository;
	
	@Override
	public Long findTypeIdByDisabilityTypeIdAndSchemeId(Long disabilityTypeId, Long schemeId) {

		TypeMasterV3 typeMaster = typeMasterRepository.findByTypeIdAndSchemeId(disabilityTypeId,schemeId);
		if(!OPLUtils.isObjectNullOrEmpty(typeMaster)) {
			return typeMaster.getId();
		}
		return null;
	}

}
