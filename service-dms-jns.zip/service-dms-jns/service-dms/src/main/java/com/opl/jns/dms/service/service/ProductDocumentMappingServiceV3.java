package com.opl.jns.dms.service.service;

import java.io.IOException;
import java.util.List;

import com.opl.jns.dms.api.model.AnsProductDocumentResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.service.domain.ProductDocumentMappingV3;

/**
 * Created by Krunal on 03-July-23.
 */
public interface ProductDocumentMappingServiceV3 {

    public ProductDocumentMappingV3 getProductDocumentMappingById(Long id);
    
    public List<AnsProductDocumentResponse> getDocumentsByOtherTrackingId(DocumentRequest docRequest);

	public List<AnsProductDocumentResponse> fetchDocMappingList(Long typeId) throws IOException;
}
