package com.opl.jns.dms.service.service;

import java.io.IOException;

public interface SpMasterServiceV3 {
	
	public String fetchMasterData(String listKey, String whereClause, Long userId) throws IOException;
	
}
