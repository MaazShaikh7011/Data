package com.opl.jns.dms.service.service.impl;

import java.io.IOException;
import java.sql.Clob;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.dms.service.repository.UserStorageRepositoryV3;
import com.opl.jns.dms.service.service.SpMasterServiceV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

@Service
@Transactional
public class SpMasterServiceImplV3 implements SpMasterServiceV3 {
	
	@Autowired
	private UserStorageRepositoryV3 repository;
		
	@Override
    public String fetchMasterData(String listKey, String whereClause, Long userId) throws IOException {
		
		
		  Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(whereClause);
		  String data = null;
		  if(listKey.equalsIgnoreCase("documentList")) {
			  data = OPLUtils.readClob((Clob) repository.getDocumentList(mapFromString.get("applicationId"),mapFromString.get("claimId"),mapFromString.get("typeId"),mapFromString.get("schemeId")));
		  }
		  else if(listKey.equalsIgnoreCase("getUplodedDocumentList")) {
			data = repository.getUplodedDocumentList(mapFromString.get("applicationId"),mapFromString.get("claimId"));
		  }
		 if(!OPLUtils.isObjectNullOrEmpty(data)) {
			 return data;
		 }
		    return null;
		    
    }
}
