package com.opl.jns.dms.service.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.service.domain.ProductStorageDetailsV3;

/**
 * Created by dhaval on 15-Apr-17.
 */
public interface ProductStorageRepositoryV3 extends JpaRepository<ProductStorageDetailsV3,Integer> {

    //for applicant
    @Query("select count(*) from ProductStorageDetailsV3 app where app.applicationId=:applicationId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getCountOfApplicant(@Param("applicationId") Long applicationId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query("select max (app.version) from ProductStorageDetailsV3 app where app.applicationId=:applicationId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getMaxOfApplicant(@Param("applicationId") Long applicationId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    //for Profile applicant
    @Query("select count(*) from ProductStorageDetailsV3 app where app.claimId=:claimId and app.moduleMasterId=:moduleMasterId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getCountOfProfileApplicant(@Param("claimId") Long claimId,@Param("moduleMasterId")Long moduleMasterId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query("select max (app.version) from ProductStorageDetailsV3 app where app.claimId=:claimId and app.moduleMasterId=:moduleMasterId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getMaxOfProfileApplicant(@Param("claimId") Long claimId,@Param("moduleMasterId")Long moduleMasterId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    //for Co-Applicant
    @Query("select count(*) from ProductStorageDetailsV3 app where app.coApplicantId=:coApplicantId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getCountOfCoApplication(@Param("coApplicantId") Long coApplicantId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    @Query("select count(*) from ProductStorageDetailsV3 app where app.otherTrackingId=:otherTrackingId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getCountOfOtherTracking(@Param("otherTrackingId") Long otherTrackingId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query("select max (app.version) from ProductStorageDetailsV3 app where app.coApplicantId=:coApplicantId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getMaxOfCoApplicant(@Param("coApplicantId") Long coApplicantId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    @Query("select max (app.version) from ProductStorageDetailsV3 app where app.otherTrackingId=:otherTrackingId and app.productDocumentMappingId=:productDocumentMappingId")
    public Long getMaxOfOtherTrackingId(@Param("otherTrackingId") Long otherTrackingId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    //for guarantor
    @Query("select count(*) from ProductStorageDetailsV3 app where app.guarantorId=:guarantorId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getCountOfGuarantor(@Param("guarantorId") Long guarantorId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    //for director
    @Query("select count(*) from ProductStorageDetailsV3 app where app.directorId=:directorId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getCountOfDirectorId(@Param("directorId") Long directorId, @Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query("select max(app.version) from ProductStorageDetailsV3 app where app.guarantorId=:guarantorId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getMaxOfGuarantor(@Param("guarantorId") Long guarantorId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    @Query("select max(app.version) from ProductStorageDetailsV3 app where app.directorId=:directorId and app.productDocumentMappingId =:productDocumentMappingId")
    public Long getMaxOfDirector(@Param("directorId") Long directorId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update ProductStorageDetailsV3 sd set sd.isActive=false, sd.modifiedDate=:currentDate where sd.id =:id")
    int deleteDocument(@Param("id") Long id,@Param("currentDate") Date currentDate);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update ProductStorageDetailsV3 sd set sd.isActive=false, sd.modifiedDate=:currentDate where sd.claimId =:id")
    int removeDocument(@Param("id") Long id,@Param("currentDate") Date currentDate);
    
    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName,app.createdDate,app.isActive) from ProductStorageDetailsV3 app where app.applicationId=:applicationId and app.productDocumentMappingId=:productDocumentMappingId and isFileUploadedAws=true")
    public List<StorageDetailsResponse> listDocumentApplicantForBankUser(@Param("applicationId") Long applicationId, @Param("productDocumentMappingId") Long productDocumentMappingId);
    
    @Query("select app.encryptedFileName from ProductStorageDetailsV3 app where app.id=:storageId")
    public String getEncryptedFileNameFromStorageId(@Param("storageId") Long storageId);

    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetailsV3 app where (app.applicationId=:applicationId and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true) or (app.coApplicantId in (:coApplicantId) and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true)")
    public List<StorageDetailsResponse> listDocumentByPrductDocumentMappingIds(@Param("applicationId") Long applicationId, @Param("productDocumentMappingIds") List<Long> productDocumentMappingIds,@Param("coApplicantId") List<Long> coApplicantId);

    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetailsV3 app where app.applicationId=:applicationId and app.claimId=:claimId and isActive=true and isFileUploadedAws=true")
    public List<StorageDetailsResponse> findAllByApplicationIdAndClaimId(@Param("applicationId") Long applicationId,@Param("claimId") Long claimId);
    
    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetailsV3 app where app.applicationId=:applicationId and app.claimId=:claimId and isActive=true and isFileUploadedAws=true and app.productDocumentMappingId in (:productDocumentMappingIds) ")
    public List<StorageDetailsResponse> findAllByApplicationIdAndClaimIdAndProductMappingIds(@Param("applicationId") Long applicationId,@Param("claimId") Long claimId,@Param("productDocumentMappingIds") List<Long> productDocumentMappingIds);
    
//  @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetails app where (app.applicationId=:applicationId and app.proposalMappingId=:proposalMappingId and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true) or (app.coApplicantId in (:coApplicantId) and app.proposalMappingId=:proposalMappingId and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true)")
    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetailsV3 app where (app.applicationId=:applicationId or app.coApplicantId in (:coApplicantId)) and app.proposalMappingId=:proposalMappingId and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true")
    public List<StorageDetailsResponse> listDocumentByPrductDocumentMappingIdsByProposalId(@Param("applicationId") Long applicationId, @Param("productDocumentMappingIds") List<Long> productDocumentMappingIds,@Param("coApplicantId") List<Long> coApplicantId,@Param("proposalMappingId") Long proposalMappingId);

    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) from ProductStorageDetailsV3 app where app.claimId IN(:claimIds) and app.productDocumentMappingId in (:productDocumentMappingIds) and isActive=true and isFileUploadedAws=true and app.coApplicantId is null")
    public List<StorageDetailsResponse> listDocumentByClaimIdAndPrductDocumentMappingIds(@Param("claimIds") List<Long> claimIds, @Param("productDocumentMappingIds") List<Long> productDocumentMappingIds);
    
    @Query("SELECT app.encryptedFileName FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.productDocumentMappingId=:productDocumentMappingId AND app.isActive=true AND app.isFileUploadedAws=true AND app.coApplicantId is null")
    public String getEncryptedFileNameFromApplicationId(@Param("applicationId") Long applicationId,@Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query("SELECT app.encryptedFileName FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.coApplicantId in (:coApplicantId) AND app.productDocumentMappingId=:productDocumentMappingId AND app.isActive=true AND app.isFileUploadedAws=true")
    public String getEncryptedFileNameFromApplicationIdAndCoAppIds(@Param("applicationId") Long applicationId,@Param("productDocumentMappingId") Long productDocumentMappingId,@Param("coApplicantId") List<Long> coApplicantId);
    
    @Query("SELECT app.encryptedFileName FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.claimId=:claimId AND app.productDocumentMappingId=:productDocumentMappingId AND isActive=TRUE AND isFileUploadedAws=TRUE")
    public String getEncryptedFileNameFromApplicationIdANDClaimIdANDDocMappingId(@Param("applicationId") Long applicationId,@Param("claimId") Long claimId,@Param("productDocumentMappingId") Long productDocumentMappingId);

    @Query(value="SELECT app FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.productDocumentMappingId=:productDocumentMappingId AND app.isActive=true AND app.isFileUploadedAws=true")
    public List<ProductStorageDetailsV3> getCamReport(@Param("applicationId") Long applicationId,@Param("productDocumentMappingId") Long productDocumentMappingId, Pageable page);
    
    @Query(value="SELECT app FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.productDocumentMappingId IN(:individualDocumentMappingId, :commrcialDocMapId) AND app.isActive=true AND app.isFileUploadedAws=true")
    public List<ProductStorageDetailsV3> getBueraueReport(@Param("applicationId") Long applicationId, @Param("individualDocumentMappingId") Long individualDocumentMappingId, @Param("commrcialDocMapId") Long commrcialDocMapId);

    @Query(value="SELECT app FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.productDocumentMappingId=:productDocumentMappingId AND app.isActive=true AND app.isFileUploadedAws=true")
    public List<ProductStorageDetailsV3> getApplicationForm(@Param("applicationId") Long applicationId,@Param("productDocumentMappingId") Long productDocumentMappingId, Pageable page);

    @Query(value="SELECT app FROM ProductStorageDetailsV3 app WHERE app.applicationId=:applicationId AND app.productDocumentMappingId=:productDocumentMappingId AND app.isActive=true AND app.isFileUploadedAws=true")
    public List<ProductStorageDetailsV3> getAcknowledgementDocument(@Param("applicationId") Long applicationId,@Param("productDocumentMappingId") Long productDocumentMappingId, Pageable page);
    
    @Modifying
    @Query(value="UPDATE ProductStorageDetailsV3 PSD SET PSD.isActive = FALSE WHERE PSD.proposalMappingId = :productDocumentMappingId AND PSD.applicationId = :applicationId AND PSD.coApplicantId IS NULL")
	public void inActiveMsmeCibilRecords(Long productDocumentMappingId, Long applicationId);
    
    @Modifying
    @Query(value="UPDATE ProductStorageDetailsV3 PSD SET PSD.isActive = FALSE WHERE PSD.proposalMappingId = :productDocumentMappingId AND PSD.applicationId = :applicationId AND PSD.coApplicantId = :coApplicantId AND PSD.coApplicantId IS NOT NULL")
	public void inActiveIndividualCibilRecords(Long productDocumentMappingId, Long applicationId, Long coApplicantId);
    
    @Query("select new com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.productDocumentMappingId, app.docName, app.coApplicantId, app.otherTrackingId) from ProductStorageDetailsV3 app where app.otherTrackingId=:otherTrackingId and app.productDocumentMappingId IN (:proDocIds) and isActive=true and isFileUploadedAws=true")
    public List<StorageDetailsResponse> listDocumentApplicantInStorageDetailsByOtherId(@Param("otherTrackingId") Long otherTrackingId, @Param("proDocIds") List<Long> proDocIds);
    
 // listDocumentByPrductDocumentMappingId for coAppCibil 
    @Query("SELECT NEW com.opl.jns.dms.api.model.StorageDetailsResponse(app.id,app.originalFileName,app.encryptedFileName) FROM ProductStorageDetailsV3 app WHERE app.coApplicantId IN (:coApplicantId) AND app.coApplicantId IS NOT NULL AND app.productDocumentMappingId IN (:productDocumentMappingIds) AND isActive=TRUE AND isFileUploadedAws=TRUE")
    public List<StorageDetailsResponse> listDocumentByPrductDocumentMappingIdsAndCoApplicantId(@Param("productDocumentMappingIds") List<Long> productDocumentMappingIds,@Param("coApplicantId") List<Long> coApplicantId);

    @Modifying
    @Query(value="UPDATE ProductStorageDetailsV3 PSD SET PSD.isActive = FALSE WHERE PSD.productDocumentMappingId = :productDocumentMappingId AND PSD.applicationId = :applicationId AND PSD.claimId = :claimId AND PSD.documentId = :documentId")
	public void updateProductStorageDocument(Long applicationId, Long claimId, Long productDocumentMappingId,
			Long documentId);

}
