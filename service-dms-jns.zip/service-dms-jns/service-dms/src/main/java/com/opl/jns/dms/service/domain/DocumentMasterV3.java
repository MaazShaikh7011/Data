package com.opl.jns.dms.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Created by Krunal on 15-Apr-17.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "document_master")
public class DocumentMasterV3 implements Serializable{

    private static final long serialVersionUID = 3859661696802725341L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "document_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_DMS, name = "document_master_seq_gen", sequenceName = "document_master_seq_gen", allocationSize = 1)
    private Long id;
    
    @Column(name = "name")
    private String name;

    @Column(name = "type")
    private String type;

    @Column(name = "size_")
    private double size;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "parent_id")
    private Long parentId;
    
}
