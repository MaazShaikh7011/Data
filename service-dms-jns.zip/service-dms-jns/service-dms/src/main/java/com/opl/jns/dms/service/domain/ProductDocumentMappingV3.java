package com.opl.jns.dms.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Created by Krunal on 03-July-23.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "product_document_mapping")
public class ProductDocumentMappingV3 implements Serializable{

    private static final long serialVersionUID = 3859661696802725341L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_document_mapping_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_DMS, name = "product_document_mapping_seq_gen", sequenceName = "product_document_mapping_seq_gen", allocationSize = 1)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "document_id")
    private DocumentMasterV3 documentMaster;

    @ManyToOne
    @JoinColumn(name = "type_id")
    private TypeMasterV3 typeMaster;

    @Column(name = "is_mandatory")
    private boolean isMandatory;

    @Column(name = "limit")
    private Integer limit;

    @Column(name = "group_id")
    private Integer groupId;

    @Column(name = "title_name")
    private String titleName;

    @Column(name = "is_multiple")
    private Boolean isMultiple;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "applicant_type")
    private Integer applicantType;

    //keep true in case you are passing byte Array
    @Column(name = "is_skip_extension")
    private boolean isSkipExtension;

}
