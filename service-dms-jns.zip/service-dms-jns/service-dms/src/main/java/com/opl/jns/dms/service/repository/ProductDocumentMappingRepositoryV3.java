package com.opl.jns.dms.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.dms.api.model.ProductDocumentResponse;
import com.opl.jns.dms.service.domain.ProductDocumentMappingV3;

public interface ProductDocumentMappingRepositoryV3 extends JpaRepository<ProductDocumentMappingV3, Long>{

    @Query("select new com.opl.jns.dms.api.model.ProductDocumentResponse(pdm.id,dm.name,dm.type,pdm.isMandatory,pdm.limit) from ProductDocumentMappingV3 pdm, DocumentMasterV3 dm where pdm.documentMaster.id = dm.id and pdm.typeMaster.id=:typeId")
    public List<ProductDocumentResponse> list(@Param("typeId") Long typeId);

    public List<ProductDocumentMappingV3> findByTypeMasterIdAndIsActive(Long typeId, Boolean isActive);
    
    @Query("select pdm from ProductDocumentMappingV3 pdm where pdm.id IN (:productMapIds)")
    public List<ProductDocumentMappingV3> getByProductMappingId(@Param("productMapIds") List<Long> productMapIds);
}
