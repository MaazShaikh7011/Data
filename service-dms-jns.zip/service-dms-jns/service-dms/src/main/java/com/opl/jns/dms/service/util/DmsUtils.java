package com.opl.jns.dms.service.util;

public class DmsUtils {

    public static final String APPLICATION_XML = "application/xml";
    public static final String TEXT_HTML = "text/html";
    public static final String EXCEL = "excel";
    public static final String APPLICATION_ZIP = "application/zip";
    public static final String TEXT_CSV = "text/csv";
    public static final String TEXT_PLIAN = "text/plain";
}
