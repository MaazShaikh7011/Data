package com.opl.jns.dms.service.scheduler;
/*
 * package com.opl.jns.common.service.dms.scheduler;
 * 
 * import java.io.File; import java.util.Date; import java.util.List;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.scheduling.annotation.Scheduled; import
 * org.springframework.stereotype.Component;
 * 
 * import com.opl.jns.common.service.dms.domain.ProductStorageDetails; import
 * com.opl.jns.common.service.dms.domain.SchedulerAudit; import
 * com.opl.jns.common.service.dms.domain.UserStorageDetails; import
 * com.opl.jns.common.service.dms.repository.ProductStorageRepository; import
 * com.opl.jns.common.service.dms.repository.UserStorageRepository; import
 * com.opl.jns.common.service.dms.service.ProductStorageService; import
 * com.opl.jns.common.service.dms.service.SchedulerAuditService; import
 * com.opl.jns.common.service.dms.service.UserStorageService;
 * 
 *//**
	 * Created by dhaval on 21-Apr-17.
	 *//*
		 * @Component public class ScheduledTasks {
		 * 
		 * @Autowired private ProductStorageRepository productStorageRepository;
		 * 
		 * @Autowired private ProductStorageService productStorageService;
		 * 
		 * @Autowired private UserStorageRepository userStorageRepository;
		 * 
		 * @Autowired private UserStorageService userStorageService;
		 * 
		 * @Autowired private SchedulerAuditService schedulerAuditService;
		 * 
		 * private static final String EXCEPTION = "Exception : ";
		 * 
		 * private static final Logger log =
		 * LoggerFactory.getLogger(ScheduledTasks.class); private static final String
		 * AWS_PRODUCT_UPLOAD = "AWS_PRODUCT_UPLOAD"; private static final String
		 * AWS_USER_UPLOAD = "AWS_USER_UPLOAD";
		 * 
		 * @Scheduled(fixedDelayString = "${cw.dms.scheduler.timeout}") public void
		 * run() { //product scheduler int counter = 0; List<ProductStorageDetails>
		 * productStorageDetailsList =
		 * productStorageRepository.findByIsFileUploadedAws(false); SchedulerAudit
		 * schedulerAudit = null; if (productStorageDetailsList.size() > 0) { try {
		 * log.info(productStorageDetailsList.size() + " Object founds to upload"); for
		 * (ProductStorageDetails productStorageDetails : productStorageDetailsList) {
		 * boolean isFileSaved =
		 * productStorageService.saveFileFromLocalToAws(productStorageDetails); if
		 * (isFileSaved) { counter += 1; log.info("file Uploaded Successfully {}",
		 * productStorageDetails); boolean isDeleted =
		 * deleteFileFromLocal(productStorageDetails.getLocalFilePath());
		 * log.info(isDeleted ? " File deleted from local" :
		 * "Failed to delete file from local:: " +
		 * productStorageDetails.getLocalFilePath()); } else {
		 * log.info("file not Uploaded {}", productStorageDetails); } } schedulerAudit =
		 * new SchedulerAudit(AWS_PRODUCT_UPLOAD, new Date(),
		 * productStorageDetailsList.size(), counter, (productStorageDetailsList.size()
		 * - counter), true, ""); } catch (Exception e) { log.error(EXCEPTION, e);
		 * schedulerAudit = new SchedulerAudit(AWS_PRODUCT_UPLOAD, new Date(),
		 * productStorageDetailsList.size(), counter, (productStorageDetailsList.size()
		 * - counter), false, e.toString()); } } else { schedulerAudit = new
		 * SchedulerAudit(AWS_PRODUCT_UPLOAD, new Date(), 0, 0, 0, true, ""); }
		 * schedulerAuditService.save(schedulerAudit);
		 * 
		 * //user scheduler counter = 0; List<UserStorageDetails> userStorageDetailsList
		 * = userStorageRepository.findByIsFileUploadedAws(false); if
		 * (userStorageDetailsList.size() > 0) { try {
		 * log.info(userStorageDetailsList.size() + " Objects Found of User Upload");
		 * for (UserStorageDetails userStorageDetails : userStorageDetailsList) {
		 * boolean isFileSaved =
		 * userStorageService.saveFileFromLocalToAws(userStorageDetails); if
		 * (isFileSaved) { counter += 1; log.info("File Upload {}", userStorageDetails);
		 * } else { log.info("File not Upload {}", userStorageDetails); } }
		 * schedulerAudit = new SchedulerAudit(AWS_USER_UPLOAD, new Date(),
		 * userStorageDetailsList.size(), counter, (userStorageDetailsList.size() -
		 * counter), true, ""); } catch (Exception e) { log.error(EXCEPTION, e);
		 * schedulerAudit = new SchedulerAudit(AWS_USER_UPLOAD, new Date(),
		 * userStorageDetailsList.size(), counter, (userStorageDetailsList.size() -
		 * counter), true, e.toString()); } } else { schedulerAudit = new
		 * SchedulerAudit(AWS_USER_UPLOAD, new Date(), 0, 0, 0, true, ""); }
		 * schedulerAuditService.save(schedulerAudit); }
		 * 
		 * private boolean deleteFileFromLocal(String filePath){
		 * 
		 * try { File file = new File(filePath); if(file.exists()){ return
		 * file.delete(); } } catch (Exception e) {
		 * log.error("Error while deleting file:: " + filePath); } return false; } }
		 */