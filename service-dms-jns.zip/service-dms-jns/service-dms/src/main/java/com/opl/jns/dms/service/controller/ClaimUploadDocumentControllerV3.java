package com.opl.jns.dms.service.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.dms.api.model.AnsProductDocumentResponse;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.service.service.ClaimUploadDocumentServiceV3;
import com.opl.jns.dms.service.service.ProductDocumentMappingServiceV3;
import com.opl.jns.utils.common.OPLUtils;

@RestController
@RequestMapping("/v3")
public class ClaimUploadDocumentControllerV3 {

	@Autowired
	private ClaimUploadDocumentServiceV3 claimUploadDocumentService;

	@Autowired
	private ProductDocumentMappingServiceV3 docMappingService;
	
	private static final Logger logger = LoggerFactory.getLogger(ClaimUploadDocumentControllerV3.class);
	
	
	@PostMapping(value = "/findTypeIdByDisabilityTypeIdAndSchemeId", consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DocumentResponse> findTypeIdByDisabilityTypeIdAndSchemeId(@RequestBody DocumentRequest documentRequest) throws IOException{
		
		logger.info("Enter in /findTypeIdByDisabilityTypeIdAndSchemeId =============>");		
		if(OPLUtils.isObjectNullOrEmpty(documentRequest)) {
			logger.warn("Invalid Request");
			return new ResponseEntity<>(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		if(!OPLUtils.isObjectNullOrEmpty(documentRequest.getSchemeId()) && !OPLUtils.isObjectNullOrEmpty(documentRequest.getDisabilityTypeId()))
		{	
		Long typeId = claimUploadDocumentService.findTypeIdByDisabilityTypeIdAndSchemeId(Long.valueOf(documentRequest.getDisabilityTypeId()),Long.valueOf(documentRequest.getSchemeId()));
		if(!OPLUtils.isObjectNullOrEmpty(typeId) && !OPLUtils.isObjectNullOrEmpty(documentRequest.getApplicationId())) {
			
			logger.info("Successfully get Type Id");
			List<AnsProductDocumentResponse> fetchDocMappingList = docMappingService.fetchDocMappingList(typeId);
	        if(!OPLUtils.isListNullOrEmpty(fetchDocMappingList)) {
	        	return new ResponseEntity<>(new DocumentResponse("Successfully get Type Id",HttpStatus.OK.value(),fetchDocMappingList), HttpStatus.OK);	
	        }
	        return new ResponseEntity<>(new DocumentResponse("Data Not Found",HttpStatus.NOT_FOUND.value(),null), HttpStatus.OK);
		}else {
			logger.info("Invalid Request");
			return new ResponseEntity<>(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);	
			}
		}
		else {
			logger.info("Invalid Request");
			return new ResponseEntity<>(new DocumentResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}
	
}
