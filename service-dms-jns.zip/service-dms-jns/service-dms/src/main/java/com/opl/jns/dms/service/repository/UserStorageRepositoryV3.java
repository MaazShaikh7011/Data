package com.opl.jns.dms.service.repository;

import java.sql.Clob;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.dms.service.domain.UserStorageDetailsV3;

/**
 * Created by krunal on 11-07-23.
 */
public interface UserStorageRepositoryV3 extends JpaRepository<UserStorageDetailsV3,Long>{

	@Query(value = """
			SELECT json_arrayagg(JSON_OBJECT('docName' value psd.doc_name,'productDocumentMappingId' value psd.product_document_mapping_id,'applicationId' value psd.application_id,'claimId' value  psd.claim_id , 'originalFileName' value psd.original_file_name))
			FROM JNS_DMS.product_storage_details psd WHERE psd.application_id =:applicationId AND psd.claim_id =:claimId AND is_active = 1\
			""", nativeQuery = true)
	String getUplodedDocumentList(@Param("applicationId") Object applicationId, @Param("claimId") Object claimId);

	@Query(value = "SELECT json_arrayagg(JSON_OBJECT('docMappingId' value pdm.id, 'docType' value tm.type, 'isMultiple' value pdm.is_multiple, 'isMandatory' value pdm.is_mandatory, 'titleName' value pdm.title_name, 'otherDocName' value psd.doc_name, 'selectedDocMappingId' value (CASE WHEN psd.id IS NOT NULL THEN pdm.id ELSE NULL END), 'documentName' value dm.name  ,'groupId' value pdm.group_id ,'id' value psd.id , 'docId' value dm.id, 'fileSize' value psd.file_size, 'uplodedFileName' value psd.original_file_name)RETURNING CLOB)\r\n"
			+ "					FROM JNS_DMS.type_master tm\r\n"
			+ "					INNER JOIN JNS_DMS.product_document_mapping pdm ON pdm.type_id = tm.id AND pdm.is_active = 1 \r\n"
			+ "					INNER JOIN JNS_DMS.document_master dm ON dm.id = pdm.document_id AND dm.is_active = 1 \r\n"
			+ "					LEFT JOIN JNS_DMS.product_storage_details psd ON psd.application_id =:applicationId AND psd.claim_id =:claimId AND psd.product_document_mapping_id = pdm.id AND psd.is_active = 1\r\n"
			+ "					WHERE tm.is_active= 1 AND tm.scheme_id =:schemeId AND tm.type_id =:typeId ", nativeQuery = true)
	Clob getDocumentList(@Param("applicationId") Object applicationId, @Param("claimId") Object claimId,@Param("typeId") Object typeId, @Param("schemeId") Object schemeId);
	
}
