UPDATE document_management.document_master SET type = 'excel,xlsx,xls' WHERE type = 'excel';

UPDATE document_management.document_master SET type = 'excel,excel-xls,xlsx,xls' WHERE type = 'excel,excel-xls';
