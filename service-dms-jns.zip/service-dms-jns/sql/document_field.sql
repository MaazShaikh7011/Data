INSERT INTO `document_management`.`document_master` (`id`, `name`, `type`, `size`, `created_date`, `modified_date`, `created_by`, `modified_by`, `is_active`, `parent_id`) 
VALUES (650, 'Tenure break up/ Bonafide certificate/ fee structure', 'jpeg,pdf,png,tiff', '2', '2022-12-15 17:18:50', '2022-12-15 17:18:52', NULL, NULL, TRUE, NULL); 

INSERT INTO `document_management`.`product_document_mapping` (`id`, `document_id`, `product_id`, `is_mandatory`, `limit`, `created_date`, `modified_date`, `created_by`, `modified_by`, `is_active`, `applicant_type`) 
VALUES (768, '650', '18', TRUE, NULL, '2022-12-15 17:21:14', '2022-12-15 17:21:14', NULL, NULL, TRUE, '1');
