package com.opl.jns.dms.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;


public class MultipartObjectRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -27976894118503038L;

	private String multiPartFile;
	
	private DocumentRequest jsonString;

	public String getMultiPartFile() {
		return multiPartFile;
	}

	public void setMultiPartFile(String multiPartFile) {
		this.multiPartFile = multiPartFile;
	}

	public DocumentRequest getJsonString() {
		return jsonString;
	}

	public void setJsonString(DocumentRequest jsonString) {
		this.jsonString = jsonString;
	}
	
	public  MultipartObjectRequest(){};
	public  MultipartObjectRequest(String multiPartFile, DocumentRequest jsonString){
	        this.multiPartFile = multiPartFile;
	        this.jsonString = jsonString;
	    }
	
}
