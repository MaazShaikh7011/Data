package com.opl.jns.dms.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonRequest {
    private Long paginationFROM;
    private Long paginationTO;
    private String filterJSON;
    private String listKey;
    private String whereClause;
	public Long getPaginationFROM() {
		return paginationFROM;
	}
	public void setPaginationFROM(Long paginationFROM) {
		this.paginationFROM = paginationFROM;
	}
	public Long getPaginationTO() {
		return paginationTO;
	}
	public void setPaginationTO(Long paginationTO) {
		this.paginationTO = paginationTO;
	}
	public String getFilterJSON() {
		return filterJSON;
	}
	public void setFilterJSON(String filterJSON) {
		this.filterJSON = filterJSON;
	}
	public String getListKey() {
		return listKey;
	}
	public void setListKey(String listKey) {
		this.listKey = listKey;
	}
	public String getWhereClause() {
		return whereClause;
	}
	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}
    
	
    
}
