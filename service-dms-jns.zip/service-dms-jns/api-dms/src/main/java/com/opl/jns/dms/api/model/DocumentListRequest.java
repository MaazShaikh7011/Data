package com.opl.jns.dms.api.model;

import com.opl.jns.utils.common.*;

import java.io.*;

/**
 * @author - Maaz Shaikh
 * @Date - 7/11/2023
 */


public class DocumentListRequest {

    private Integer typeId;
    private Integer schemeId;
    private Long applicationId;
    private Long claimId;

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Integer getSchemeId() {
        return schemeId;
    }

    public void setSchemeId(Integer schemeId) {
        this.schemeId = schemeId;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public Long getClaimId() {
        return claimId;
    }

    public void setClaimId(Long claimId) {
        this.claimId = claimId;
    }
    public  DocumentListRequest(){};
    public  DocumentListRequest(Integer typeId,Integer schemeId,Long applicationId,Long claimId){
        this.typeId=typeId;
        this.schemeId = schemeId;
        this.applicationId = applicationId;
        this.claimId = claimId;
    }

//   public String getInStringFormat() throws IOException {
//       return MultipleJSONObjectHelper.getStringfromObject(this);
//    }
}
