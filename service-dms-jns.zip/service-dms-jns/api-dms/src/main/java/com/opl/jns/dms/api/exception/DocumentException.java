package com.opl.jns.dms.api.exception;

public class DocumentException extends Exception {

	private static final long serialVersionUID = 1L;

	public DocumentException() {
    }

    public DocumentException(String message) {
        super(message);
    }
}
