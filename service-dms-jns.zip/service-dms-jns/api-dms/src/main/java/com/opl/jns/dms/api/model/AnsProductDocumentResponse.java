package com.opl.jns.dms.api.model;

import java.util.List;

public class AnsProductDocumentResponse {

    private Long docId;
    private Long proDocMapId;
    private String documentName;
    private Boolean isChild;
    private Long childProDocMapId;
    private List<AnsProductDocumentResponse> childList;
    private List<StorageDetailsResponse> fileList;
    private Boolean isMandatory;
    private Boolean isActive;
    private Integer groupId;
    private String titleName;
    private Boolean isMultiple;

    public Long getProDocMapId() {
        return proDocMapId;
    }

    public void setProDocMapId(Long proDocMapId) {
        this.proDocMapId = proDocMapId;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public Boolean getChild() {
        return isChild;
    }

    public void setChild(Boolean child) {
        isChild = child;
    }

    public Long getChildProDocMapId() {
        return childProDocMapId;
    }

    public void setChildProDocMapId(Long childProDocMapId) {
        this.childProDocMapId = childProDocMapId;
    }

    public List<AnsProductDocumentResponse> getChildList() {
        return childList;
    }

    public void setChildList(List<AnsProductDocumentResponse> childList) {
        this.childList = childList;
    }

    public List<StorageDetailsResponse> getFileList() {
        return fileList;
    }

    public void setFileList(List<StorageDetailsResponse> fileList) {
        this.fileList = fileList;
    }

    public Long getDocId() {
        return docId;
    }

    public void setDocId(Long docId) {
        this.docId = docId;
    }

	public Boolean getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(Boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getTitleName() {
        return titleName;
    }

    public void setTitleName(String titleName) {
        this.titleName = titleName;
    }

    public Boolean getIsMultiple() {
        return isMultiple;
    }

    public void setIsMultiple(Boolean isMultiple) {
        this.isMultiple = isMultiple;
    }
}
