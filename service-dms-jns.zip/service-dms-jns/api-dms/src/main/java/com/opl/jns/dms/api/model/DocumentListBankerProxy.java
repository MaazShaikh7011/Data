package com.opl.jns.dms.api.model;

import java.util.ArrayList;
import java.util.List;

public class DocumentListBankerProxy {

    private List<AnsProductDocumentResponse> applicantList = new ArrayList<>();

    private List<AnsProductDocumentResponse> coApplicantList = new ArrayList<>();

    private Integer schemeId;

    private Long orgId;

    public DocumentListBankerProxy() {
    }

    public DocumentListBankerProxy(List<AnsProductDocumentResponse> applicantList, List<AnsProductDocumentResponse> coApplicantList, Integer schemeId, Long orgId) {
        this.applicantList = applicantList;
        this.coApplicantList = coApplicantList;
        this.schemeId = schemeId;
        this.orgId = orgId;
    }

    public DocumentListBankerProxy(List<AnsProductDocumentResponse> applicantList, List<AnsProductDocumentResponse> coApplicantList) {
        this.applicantList = applicantList;
        this.coApplicantList = coApplicantList;
    }

    public List<AnsProductDocumentResponse> getApplicantList() {
        return applicantList;
    }

    public void setApplicantList(List<AnsProductDocumentResponse> applicantList) {
        this.applicantList = applicantList;
    }

    public List<AnsProductDocumentResponse> getCoApplicantList() {
        return coApplicantList;
    }

    public void setCoApplicantList(List<AnsProductDocumentResponse> coApplicantList) {
        this.coApplicantList = coApplicantList;
    }

    public Integer getSchemeId() {
        return schemeId;
    }

    public void setSchemeId(Integer schemeId) {
        this.schemeId = schemeId;
    }

    public Long getOrgId() {
        return orgId;
    }

    public void setOrgId(Long orgId) {
        this.orgId = orgId;
    }
}
