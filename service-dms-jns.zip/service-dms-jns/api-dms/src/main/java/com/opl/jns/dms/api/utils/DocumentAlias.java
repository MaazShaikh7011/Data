package com.opl.jns.dms.api.utils;

/**
 * Created by dhaval on 13-May-17.
 */
public class DocumentAlias {

	public static interface ApplicantType {
		public static final Integer APPLICANT = 1;
		public static final Integer CO_APPLICANT = 2;
		public static final Integer BOTH = 3;
	}

	private DocumentAlias(){
		// Do nothing because of X and Y.
	}
	public static final String UERT_TYPE_APPLICANT = "applicant";
	public static final String UERT_TYPE_CO_APPLICANT = "coApplicant";
	public static final String UERT_TYPE_OTHER_TRACKING = "otherTracking";
	public static final String UERT_TYPE_GUARANTOR = "guarantor";
	public static final String UERT_TYPE_USER = "user";
	public static final String UERT_TYPE_DIRECTOR = "director";
	public static final String USER_TYPE_APPLICANT_PROFILE = "profile_applicant";
	
	
	
	public static final Long ITR_XML_UPLOAD_REPORTS = 623l;
	public static final Long ITR_PDF_UPLOAD_REPORTS = 624l;
	public static final Long CORPORATE_ITR_XML = 358l;
	public static final Long CORPORATE_ITR_PDF = 406l;
	public static final Long RETAIL_ITR_PDF = 407l;
	public static final Long RETAIL_ITR_XML = 408l;
	public static final Long ITR_PERFIOS_ZIP = 586l;
	
	public static final Long WORKING_CAPITAL_BANK_STATEMENT = 354l;
	public static final Long TERM_LOAN_BANK_STATEMENT = 295l;
	public static final Long WCTL_LOAN_BANK_STATEMENT = 395l;
	
	
	public static final Long PROOF_OF_RESIDENCE = 640l;
	public static final Long DRIVING_LICENCE = 641l;
	public static final Long INCOME_CERTIFICATE = 642l;
	
	public static final Long CIBIL_REPORT_MSME_CONSUMER = 575l;
	public static final Long CIBIL_REPORT_MSME_COMPANY = 365l;
	public static final Long CIBIL_SOFTPING_CONSUMER = 592l;
	public static final Long CIBIL_REPORT_HUF_COMMERCIAL = 530l;

	public static final Long VOTER_CARD = 720l;
	public static final Long FAILED_VOTER_CARD = 743l;
	public static final Long AADHAR_CARD = 679l;
	public static final Long FAILED_AADHAR_CARD = 742l;
	
	public static final int WC_CMA=7;	    
	public static final int TL_CMA=34;	    
	public static final int WCTL_CMA=373;	    
	public static final Long WCTL_CMA_DOC=373L;
	public static final int USL_CMA = 327;	

}