DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spGetProductByUserIdAndBusinessTypeId`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetProductByUserIdAndBusinessTypeId`(IN userId BIGINT, IN businessTypeId INT, IN typeId INT)
BEGIN

	SELECT user_role_id, user_org_id, branch_id INTO @userRoleId, @userOrgId, @branchId FROM users.users WHERE user_id = userId;

	SET @fetchBusinessQuery =  CONCAT(" SELECT
		JSON_ARRAYAGG(JSON_OBJECT('userId', temp.userId, 'businessTypeId', temp.businessTypeId, 'businessTypeName', temp.businessTypeName, 'roleId', 
		temp.roleId,'imgPath', temp.imgPath, 'schemeId', temp.schemeId, 'schemeName', temp.schemeName, 'routingPath', temp.routingPath)) INTO @businessTypeList
		FROM (SELECT
		pm.user_id AS userId, pm.business_type_id AS businessTypeId, btm.display_name AS businessTypeName, pm.user_role_id AS roleId,btm.img_path AS imgPath,
		schm.id AS schemeId, schm.name AS schemeName, btm.path AS routingPath
		FROM users.user_role_product_mapping pm 
		INNER JOIN users.business_master btm ON btm.business_type_master_id = pm.business_type_id
		INNER JOIN users.users u ON u.user_id = pm.user_id
		INNER JOIN users.`scheme_master` schm ON schm.id = pm.`scheme_id` AND pm.is_active = TRUE
		AND pm.user_id = ", userId);
-- 	AND schm.is_active = TRUE
	IF (businessTypeId IS NULL OR businessTypeId < 1) THEN
		SET @fetchBusinessQuery = CONCAT(@fetchBusinessQuery, " AND btm.is_active = TRUE GROUP BY pm.business_type_id ORDER BY btm.order_id ASC) temp");
	ELSE
		SET @fetchBusinessQuery = CONCAT(@fetchBusinessQuery, " and pm.business_type_id = ", businessTypeId ," ORDER BY schm.order_id ASC) temp");
	END IF;
	
	
	-- INSERT INTO `temp`(`val`,`val2`) VALUES("@fetchBusinessQuery", @fetchBusinessQuery);
-- 	select @fetchBusinessQuery;
	PREPARE qry FROM @fetchBusinessQuery;
	EXECUTE qry;
	
	
	SET @userJson = '[]';
	IF (JSON_LENGTH(@businessTypeList) > 0) THEN
		
		SET @lmts = 0;
		WHILE @lmts < JSON_LENGTH(@businessTypeList) DO
			
			SET @appObj = JSON_EXTRACT(@businessTypeList,CONCAT('$[', @lmts ,']'));
			SELECT JSON_EXTRACT(@appObj,'$.userId') INTO @userId;
			SELECT JSON_EXTRACT(@appObj,'$.businessTypeId') INTO @businessTypeId;
			SELECT JSON_EXTRACT(@appObj,'$.businessTypeName') INTO @businessTypeName;
			SELECT JSON_EXTRACT(@appObj,'$.roleId') INTO @roleId;
			SELECT JSON_EXTRACT(@appObj,'$.imgPath') INTO @imgPath;
			SELECT JSON_EXTRACT(@appObj,'$.schemeId') INTO @schemeId;
			SELECT JSON_EXTRACT(@appObj,'$.schemeName') INTO @schemeName;
			SELECT JSON_EXTRACT(@appObj,'$.routingPath') INTO @routingPath;
			
			IF ((businessTypeId IS NULL OR businessTypeId < 1) AND typeId != 1) THEN
				SET @schemeId = NULL;
				SELECT GROUP_CONCAT(urpm.scheme_id) INTO @schemeId FROM users.user_role_product_mapping urpm WHERE user_id = userId AND is_active = TRUE AND scheme_id != -1;
			END IF;
			
			IF (@businessTypeId IS NOT NULL AND (@businessTypeId = '-1' OR @businessTypeId = -1)) THEN
				SET @tempId = @businessTypeId;
				SET @businessTypeId = NULL;
			END IF;
			
-- 			typeId = 1 --> getTopbarURL      typeId = 2 --> getProductURL       typeId = 3 --> getSchemeURL
			IF typeId != 1 THEN
				CALL users.spGetTotalAndPendingCount(@businessTypeId, @schemeId, @userOrgId, @branchId, @userId, @roleId, @totalCount, @totalPendingCount);  -- businessId, schemeTypeId, orgId , branchId, userRoleId, totalCount, pandingCount		
			ELSE
				SET @totalCount = NULL;
				SET @totalPendingCount = NULL;
			END IF;

			IF (@businessTypeId IS NULL) THEN
				SET @businessTypeId = @tempId;
				IF typeId != 1 THEN
					SET @schemeId = @tempId;
				END IF;
			END IF;
			
			SELECT JSON_ARRAYAGG(JSON_OBJECT("userId",@userId, "businessTypeId",@businessTypeId,"businessTypeName", JSON_UNQUOTE(@businessTypeName), 
							"roleId", @roleId ,"imgPath", JSON_UNQUOTE(@imgPath), "schemeId", @schemeId, "schemeName", JSON_UNQUOTE(@schemeName),
							"totalCount", @totalCount, "totalPendingCount", @totalPendingCount, "routingPath", JSON_UNQUOTE(@routingPath))) INTO @result;
			
			SET @userJson = JSON_MERGE_PRESERVE(@userJson, @result);			
			
			SET @countAppObj = NULL;
			SET @countResult = NULL;
			SET @result = NULL;
			SET @appObj = NULL;
			SET @appValues = NULL;
			SET @userId = NULL;
			SET @businessTypeId = NULL;
			SET @businessTypeName = NULL;
			SET @imgPath = NULL;
			SET @schemeId = NULL;
			SET @schemeName = NULL;
			SET @totalCount = NULL; 
			SET @totalPendingCount= NULL;
			SET @tempId = NULL;
			SET @lmts = @lmts + 1;
			
		END WHILE;
	END IF;
	
	SELECT @userJson;

END$$

DELIMITER ;