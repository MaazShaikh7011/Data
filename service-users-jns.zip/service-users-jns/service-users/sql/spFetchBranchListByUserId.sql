DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spFetchBranchListByUserId`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spFetchBranchListByUserId`(IN inUserId INT, IN inSchemeId INT, OUT branchResult LONGTEXT, OUT orgResult BIGINT)
BEGIN

	SELECT `user_id`, `user_role_id`,`user_type_id`,`branch_id`,`user_org_id` 
	INTO @varUserId, @varUserRoleId, @varUserTypeID, @varBranchId, @varUserOrgId
	FROM`users`.`users` WHERE `user_id` = inUserId;
	
	-- if (inSchemeId is not null) then
-- 		select `business_type_id` into @inBusinessTypeId from `users`.`scheme_master` where `id` = inSchemeId;
-- 	end if;
	
	IF (@varUserTypeID = 2) THEN
		-- HO, ADMIN MAKER, ADMIN CHECKER
		IF (@varUserRoleId = 5 OR @varUserRoleId = 10 OR @varUserRoleId = 11) THEN
			SELECT @varUserOrgId INTO @orgResult;
			SET orgResult = @orgResult;			
			SET branchResult = NULL;
			
		-- BRANCH MAKER, BRANCH CHECKER
		ELSEIF (@varUserRoleId = 8 OR @varUserRoleId = 9) THEN
			SET orgResult = NULL;
			SET branchResult = CONCAT('(',@varBranchId,')');
			
		-- RO, ZO, LHO
		ELSEIF (@varUserRoleId = 13 OR @varUserRoleId = 14 OR @varUserRoleId = 15) THEN
			SET @query =  " SELECT DISTINCT bp.`branch_id` AS branchIdList FROM `users`.`branch_product_mapping` bp 
			INNER JOIN `users`.`branch_master` bm ON bm.`id` = bp.`branch_id` AND bm.`branch_type` = 1
			WHERE bp.is_active = TRUE ";
			
			-- RO
			IF (@varUserRoleId = 13) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_ro_id` = @varBranchId ");
			-- ZO
			ELSEIF (@varUserRoleId = 14) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_zo_id` = @varBranchId ");
			-- LHO
			ELSEIF (@varUserRoleId = 15) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_lho_id` = @varBranchId ");
			END IF;
			
			IF (inSchemeId IS NOT NULL) THEN			
				SET @query = CONCAT(@query, " AND bp.`sch_type_id` = ", inSchemeId);
			END IF;	
					
			SET @mainQuery = CONCAT(" SELECT JSON_ARRAYAGG(tmp.branchIdList) INTO @branchIdList FROM ( ",@query," ) tmp ");
	
			PREPARE cntstmt FROM @mainQuery;
			EXECUTE cntstmt;
			SELECT REPLACE(REPLACE(@branchIdList,'[','('),']',')') INTO @branchResult;
			SET orgResult = NULL;
			SET branchResult = @branchResult;
			
		END IF;
	END IF;
END$$

DELIMITER ;