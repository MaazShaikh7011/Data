DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `sp_Fetch_ULB_list`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `sp_Fetch_ULB_list`(IN createdBy BIGINT, IN userId BIGINT)
BEGIN
	SELECT u.user_type_id, u.user_role_id INTO @userTypeId, @userRoleId FROM users.users u WHERE u.user_id = userId;

	IF @userTypeId IS NOT NULL THEN
		SET @whereClause = " WHERE urpm.scheme_id = 11 AND us.`user_type_id` = 8 ";
		
		IF @userTypeId != 4 THEN 
			IF @userRoleId = 28 THEN
				SET @whereClause = CONCAT(@whereClause, " AND us.`user_id` IN(SELECT uum.user_id FROM users.ulb_user_mapping uum WHERE uum.state_code = (SELECT um.state_code FROM users.ulb_user_mapping um WHERE um.user_id = ",userId," LIMIT 1)) ");
			ELSE
				SET @whereClause = CONCAT(@whereClause, " AND 1=2 ");
			END IF;
		END IF;
		
			SET @qry = CONCAT(" SELECT JSON_ARRAYAGG(JSON_OBJECT(
				'userId',us.user_id,
				'roleId',us.`user_role_id`,
				'firstName',`decValue`(us.`first_name`),
				'email',decValue(us.`email`),
				'mobile',decValue(us.`mobile`),
				'createdDate',us.`created_date`, 
				'isActive',CASE WHEN us.`is_active` THEN 'true' ELSE 'false' END,
				'totalApp',(SELECT COUNT(app.application_id) FROM `loan_application_details`.`nulm_ulb_mapping` app 
						WHERE app.`ulb_code` = uum.ulb_code),
				'totalAmount',(SELECT SUM(app.loan_amount) FROM `loan_application_details`.`nulm_ulb_mapping` app 
						WHERE app.`ulb_code` = uum.ulb_code),
				'ulbDetails',CONCAT(udm.`ulb_name` ,' (',udm.`ulb_lgd_code`,')'),
				'ulbName',udm.`ulb_name`,
				'ulbCode',udm.`ulb_lgd_code`,
				'stateName',LS.`state_name_english`,
				'roleName',URM.`display_name`
				 )) AS result
				FROM users.users us
				INNER JOIN users.`user_role_master` URM ON URM.`role_id` = us.`user_role_id`
				INNER JOIN users.user_role_product_mapping urpm ON urpm.user_id = us.user_id
				INNER JOIN users.`ulb_user_mapping` uum ON uum.user_id = us.user_id
				INNER JOIN `one_form`.`lgd_state` LS ON LS.`state_code` = uum.`state_code` 
				LEFT JOIN `users`.`ulb_district_mapping` udm ON udm.`ulb_lgd_code` = uum.`ulb_code` 
				 ", @whereClause ," ORDER BY us.user_id DESC ");
				 
-- 			select @qry;
			PREPARE stmt FROM @qry;
			EXECUTE stmt;
	ELSE
		SELECT NULL AS result;
	END IF;
	
			
-- 			us.created_by = createdBy AND AND us.`user_role_id` = 27
	
	END$$

DELIMITER ;