DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spGetTotalAndPendingCount`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetTotalAndPendingCount`(IN businessId BIGINT, IN schemeTypeId TEXT, IN orgId BIGINT, IN branchId BIGINT, IN userId BIGINT, IN roleId BIGINT, OUT totalCountOut INT, OUT totalPendingCountOut INT)
BEGIN

	SET totalCountOut = 0;
	SET totalPendingCountOut = 0;

	IF (businessId IS NULL) THEN
		SET totalCountOut = 0;
		SET totalPendingCountOut = 0;
	ELSE
		SET @whareClause = ' WHERE 1=1 ';

		IF (businessId IS NOT NULL) THEN
			SET @businessTypeColumn = CONCAT(" AND bp.`business_type_id` = ", businessId);
		ELSE
			SET @businessTypeColumn = " ";
		END IF;

		IF (schemeTypeId IS NOT NULL) THEN
			SET @schemeTypeColumn = CONCAT(" AND bp.`sch_type_id` IN( ", schemeTypeId,") ");
		ELSE
			SET @schemeTypeColumn = " ";
		END IF;

		IF (roleId = 5 OR roleId = 10 OR roleId = 11) THEN
			SET @whareClause = CONCAT(@whareClause,' AND pdt.org_id = ', orgId);
		ELSEIF (roleId = 8 OR roleId = 9) THEN
			SET @whareClause = CONCAT(@whareClause,' AND pdt.branch_id = ', branchId);
		ELSEIF (roleId = 13 OR roleId = 14 OR roleId = 15) THEN
			SET @query = " select GROUP_CONCAT(DISTINCT bp.`branch_id`) INTO @branchIdList from `users`.`branch_product_mapping` bp
			INNER JOIN `users`.`branch_master` bm on bm.`id` = bp.`branch_id` and bm.`branch_type` = 1
			where bp.is_active = true ";

			IF (roleId = 13) THEN
			  SET @query = CONCAT(@query, " AND bp.`branch_ro_id`= ", branchId, @businessTypeColumn, @schemeTypeColumn);
			END IF;

			IF (roleId = 14) THEN
			  SET @query = CONCAT(@query, " AND bp.`branch_zo_id`= ", branchId, @businessTypeColumn, @schemeTypeColumn);
			END IF;

			IF (roleId = 15) THEN
			  SET @query = CONCAT(@query, " AND bp.`branch_lho_id`= ", branchId, @businessTypeColumn, @schemeTypeColumn);
			END IF;
			
			-- IF (schemeTypeId IS NOT NULL) THEN
-- 				SET @query = CONCAT(@query, " AND bp.`sch_type_id` IN( ", schemeTypeId,") ");
-- 			ELSE 
-- 				SET @query = CONCAT(@query, " AND bp.`sch_type_id` IN (SELECT `id` FROM `scheme_master` WHERE `business_type_id` = " , businessId , ") ");
-- 			END IF;
			PREPARE cntstmt FROM @query;
			EXECUTE cntstmt;
			
-- 			INSERT INTO `users`.`temp`(`val`,`val2`) VALUES("business", @branchIdList);
			
			IF (@branchIdList IS NOT NULL) THEN
				SET @whareClause = CONCAT(@whareClause,' AND pdt.branch_id IN(', @branchIdList ,') ');
			ELSE
				SET @whareClause = CONCAT(@whareClause,' AND 1 = 2 ');
			END IF;


			-- CALL users.spFetchBranchListByUserIdSchemeBusiness(userId, schemeId, businessId, @branchId, @orgId);
-- 			
-- 			IF @branchId IS NOT NULL THEN
-- 				SET @whareClause = CONCAT(@whareClause,' AND pdt.branch_id IN(', @branchId ,')');
-- 			ELSEIF @orgId IS NOT NULL THEN
-- 				SET @whareClause = CONCAT(@whareClause,' AND pdt.org_id = ', @orgId );
-- 			ELSE
-- 				SET @whareClause = CONCAT(@whareClause,' AND 1 = 2 ');
-- 			END IF;
		
		END IF;


		
		IF (schemeTypeId IS NOT NULL) THEN
			SET @whareClause = CONCAT(@whareClause,' AND pdt.sch_type_id IN(', JSON_UNQUOTE(schemeTypeId),')');
		END IF;

		IF (businessId = 9 OR businessId = 5) THEN
			SET @whareClause  = CONCAT(@whareClause, ' AND pdt.scheme_ineligible = FALSE ');
		END IF;
		
		IF (businessId = 11 OR businessId = 12) THEN
			SET @whareClause  = CONCAT(@whareClause, ' AND pdt.is_redirected = FALSE ');
		END IF;
		
		SELECT schema_table_name, journey_stage_id INTO @proposalTable, @journeyStageId FROM banker_report.proposal_table_names WHERE business_type_id = businessId LIMIT 1;			
		
		SET @totalCountQuery = CONCAT('SELECT 
		SUM((CASE WHEN (pdt.proposal_id IS NOT NULL) THEN 1 ELSE 0 END)),
		SUM((CASE WHEN (ivm.id IS NULL) THEN 1 ELSE 0 END)) into @totalCount,@totalPendingCount
		FROM ', @proposalTable,
		' pdt LEFT JOIN loan_application_details.proposal_view_mapping ivm ON ivm.is_viewed = TRUE AND ivm.proposal_id = pdt.proposal_id AND ivm.user_id = ',userId, 
		@whareClause ,' AND pdt.proposal_status_id IS NOT NULL AND pdt.journey_completion_date IS NOT NULL AND pdt.is_active = TRUE '); 
		
-- 		INSERT INTO `users`.`temp`(`val`,`val2`) VALUES(businessId, @totalCountQuery);
		
		-- select @totalCountQuery;
		PREPARE totalCountQuery FROM @totalCountQuery;
		EXECUTE totalCountQuery;
		
	END IF;
	
	IF @totalCount IS NOT NULL THEN
		SET totalCountOut = @totalCount;
		SET totalPendingCountOut = @totalPendingCount;
	ELSE
		SET totalCountOut = 0;
		SET totalPendingCountOut = 0;
	END IF;


END$$

DELIMITER ;