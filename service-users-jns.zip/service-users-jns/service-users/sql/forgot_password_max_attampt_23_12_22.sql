ALTER TABLE `ans_config`.`api_restrict_audit`   
	ADD COLUMN `email` VARCHAR(255) NULL AFTER `value`;

INSERT INTO `ans_config`.`api_restrict_config` (`minutes`, `max_attempt`, `api_code`, `messages`) VALUES ('5', '10', 'FORGOT_PASSWORD_LINK', 'You have maximum 10 number of attempt only.');
