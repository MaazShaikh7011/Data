package com.opl.jns.users.service.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.users.service.service.OfflineConfigServiceV3;


@Service
@Transactional
public class OfflineConfigServiceImplV3 implements OfflineConfigServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(OfflineConfigServiceImplV3.class.getName());

//	@Autowired
//	private OfflineConfigurationRepositoryV3 offlineConfigRepository;
//
//	@Autowired
//	private OfflineConfigurationAuditRepositoryV3 offlineConfigurationAuditRepository;
//
//	@Override
//	public List<OfflineConfigurationProxy> get(int schemeId, long orgId) {
//		try {
//			List<OfflineConfiguration> offlineConfigList = offlineConfigRepository
//					.findBySchemeMasterIdAndOrganisationMasterUserOrgId(Long.valueOf(schemeId), orgId);
//			if(OPLUtils.isListNullOrEmpty(offlineConfigList)) {
//				logger.info("No data found");
//				return null;
//			}
//			List<OfflineConfigurationProxy> offlineConfigurationProxyList = new ArrayList<>(offlineConfigList.size());
//			OfflineConfigurationProxy configurationProxy = null;
//			for(OfflineConfiguration offlineConfig : offlineConfigList) {
//				configurationProxy = new OfflineConfigurationProxy();
//				BeanUtils.copyProperties(offlineConfig, configurationProxy);
//				configurationProxy.setSchemeId(offlineConfig.getSchemeMaster().getId());
//				configurationProxy.setSchemeName(offlineConfig.getSchemeMaster().getName());
//				configurationProxy.setOrgId(offlineConfig.getOrganisationMaster().getUserOrgId());
//				configurationProxy.setOrgName(offlineConfig.getOrganisationMaster().getDisplayOrgName());
//				offlineConfigurationProxyList.add(configurationProxy);
//			}
//			return offlineConfigurationProxyList;
//		} catch (Exception e) {
//			logger.error("Exception while fetch offline configuration by schemeid and orgid ", e);
//		}
//		return null;
//	}
//
//	@Override
//	public UserCommonRes update(OfflineConfigurationProxy configurationProxy) {
//		try {
//			OfflineConfiguration offlineConfig = offlineConfigRepository
//					.findBySchemeMasterIdAndOrganisationMasterUserOrgIdAndTypeId(configurationProxy.getSchemeId(), configurationProxy.getOrgId(), configurationProxy.getTypeId());
//			if(offlineConfig == null) {
//				return new UserCommonRes("Invalid Request, Request parameter is not valid for this request !!",
//						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//			offlineConfig.setIsActive(configurationProxy.getIsActive());
//			offlineConfig.setModifiedDate(new Date());
//			offlineConfig.setModifiedBy(configurationProxy.getModifiedBy());
//			offlineConfig =	offlineConfigRepository.save(offlineConfig);
//
//			OfflineConfigurationAudit configAudit = new OfflineConfigurationAudit();
//			configAudit.setConfiguration(offlineConfig);
//			configAudit.setIsActive(configurationProxy.getIsActive());
//			configAudit.setOrganisationMaster(offlineConfig.getOrganisationMaster());
//			configAudit.setSchemeMaster(offlineConfig.getSchemeMaster());
//			configAudit.setModifiedDate(new Date());
//			configAudit.setTypeId(offlineConfig.getTypeId());
//			configAudit.setModifiedBy(configurationProxy.getModifiedBy());
//			offlineConfigurationAuditRepository.save(configAudit);
//
//			return new UserCommonRes("Successfully updated",
//					HttpStatus.OK.value(), Boolean.TRUE);
//		} catch (Exception e) {
//			logger.info("exit getOfflineConfigByScheme() {}", e);
//			return new UserCommonRes("The application has encountered some error, please try after some time",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
//	}
//
//	@Override
//	public List<OfflineConfigurationProxy> getAudit(int schemeId, long orgId) {
//		try {
//			List<OfflineConfigurationAudit> offlineConfigList = offlineConfigurationAuditRepository
//					.findBySchemeMasterIdAndOrganisationMasterUserOrgId(Long.valueOf(schemeId), orgId);
//			if(offlineConfigList.isEmpty()) {
//				return Collections.emptyList();
//			}
//			List<OfflineConfigurationProxy> configurationProxies = new ArrayList<>(offlineConfigList.size());
//			OfflineConfigurationProxy configurationProxy = null;
//			for(OfflineConfigurationAudit offlineConfigAudit : offlineConfigList) {
//				configurationProxy = new OfflineConfigurationProxy();
//				BeanUtils.copyProperties(offlineConfigAudit, configurationProxy);
//				configurationProxy.setSchemeId(offlineConfigAudit.getSchemeMaster().getId());
//				configurationProxy.setSchemeName(offlineConfigAudit.getSchemeMaster().getName());
//				configurationProxy.setOrgId(offlineConfigAudit.getOrganisationMaster().getUserOrgId());
//				configurationProxy.setOrgName(offlineConfigAudit.getOrganisationMaster().getDisplayOrgName());
//				if(offlineConfigAudit.getModifiedBy() != null) {
//					configurationProxy.setModifiedBy(offlineConfigAudit.getModifiedBy());
//					configurationProxy.setModifiedByName(offlineConfigAudit.getModifiedBy().toString());
//				}
//				configurationProxies.add(configurationProxy);
//			}
//			return configurationProxies;
//		} catch (Exception e) {
//			logger.error("Exception while fetch offline configuration audit by schemeid and orgid ", e);
//		}
//		return Collections.emptyList();
//	}
//
//	@Override
//	public Boolean checkOfflineConfigrationOrgId(Long schemeId, Long orgId, Integer typeId) {
//		logger.info("Offline configration started.......");
//		try {
//			Boolean orgIdIsActive = false;
//			OfflineConfiguration offlineConfig = offlineConfigRepository.findBySchemeMasterIdAndOrganisationMasterUserOrgIdAndIsActiveAndTypeId(schemeId,orgId,Boolean.TRUE, typeId);
//			if(!OPLUtils.isObjectNullOrEmpty(offlineConfig)){
//					orgIdIsActive = true;
//			}
//			return orgIdIsActive;
//
//		}catch (Exception e) {
//			logger.error("Exception while fetch details orgId configuration by schemeid and orgid ", e);
//			return null;
//		}
//	}
}
