package com.opl.jns.users.service.controller;

import java.util.List;
import java.util.Set;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.api.model.UserCommonRes;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.users.service.service.BranchMasterServiceV3;
import com.opl.jns.utils.common.OPLUtils;

/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class BranchControllerV3 {

	
	private static final Logger logger = LoggerFactory.getLogger(BranchControllerV3.class.getName());

	@Autowired
	private BranchMasterServiceV3 branchService;

	@PostMapping(value = "/get/branchListBasedOnCityOrStateOrOrgId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getBranchListBasedOnCityOrStateOrOrgId(@RequestBody BranchBasicDetailsRequest branchBasicDetailsRequest, HttpServletRequest request) {
		try {
			List<BranchBasicDetailsRequest> branchBasicDetailsRequestList = branchService.getBranchListBasedOnCityOrStateOrOrgId(branchBasicDetailsRequest);
			if (!OPLUtils.isListNullOrEmpty(branchBasicDetailsRequestList)) {
				return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.DATA_LIST_FOUND, HttpStatus.OK.value(), Boolean.TRUE, branchBasicDetailsRequestList), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

	@GetMapping(value = "/get/{branchID}")
	public ResponseEntity<UserCommonRes> get(@PathVariable Long branchID) {
		try {
			BranchBasicDetailsRequest details = branchService.get(branchID);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@PostMapping(value = "/get/getBranchByListId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchByListId(@RequestBody Set<Long> ids) {
		try {
			List<BranchBasicDetailsRequest> details = branchService.getBranchByListId(ids);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("getBranchByListId--",e);
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping(value = "/get/searchBranchListBasedOnCodeOrName", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> searchBranchListBasedOnCodeOrName(@RequestBody BranchBasicDetailsRequest branchBasicDetailsRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			Long userId = authClientResponse.getUserId();
			Long userOrgId = authClientResponse.getUserOrgId();
			if (userId == null && userOrgId == null) {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}
			branchBasicDetailsRequest.setBranchId(authClientResponse.getUserBranchId());
			List<BranchBasicDetailsRequest> branchBasicDetailsRequestList = branchService.searchBranchListBasedOnCodeOrName(branchBasicDetailsRequest, userId, userOrgId);
			if (!OPLUtils.isListNullOrEmpty(branchBasicDetailsRequestList)) {
				return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.DATA_LIST_FOUND, HttpStatus.OK.value(), Boolean.TRUE, branchBasicDetailsRequestList), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}
	
	// for admin-Panel
	@PostMapping(value = "/get/searchBranchListFromCodeOrName", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> searchBranchListFromCodeOrName(@RequestBody BranchBasicDetailsRequest branchBasicDetailsRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			Long userId = authClientResponse.getUserId();
			if (userId == null || OPLUtils.isObjectNullOrEmpty(branchBasicDetailsRequest.getOrgId())) {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}
			List<BranchBasicDetailsRequest> branchBasicDetailsRequestList = branchService.searchBranchListBasedOnCodeOrName(branchBasicDetailsRequest, userId, branchBasicDetailsRequest.getOrgId());
			if (!OPLUtils.isListNullOrEmpty(branchBasicDetailsRequestList)) {
				return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.DATA_LIST_FOUND, HttpStatus.OK.value(), Boolean.TRUE, branchBasicDetailsRequestList), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}


	@GetMapping(value = "/getBranchByScheme/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchByScheme(@PathVariable Long schemeId,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			List<BranchBasicDetailsRequest> details = branchService.getBranchByScheme(authClientResponse.getUserOrgId(),schemeId);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping(value = "/getBranchByCode/{schemeId}/{orgId}/{branchCode}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchCode(@PathVariable Long schemeId,@PathVariable Long orgId,@PathVariable String branchCode,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
		
			BranchBasicDetailsRequest details = branchService.getBranchCode(schemeId,orgId,branchCode);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@GetMapping(value = "/getBranchByScheme/{schemeId}/{orgId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchByScheme(@PathVariable Long schemeId,@PathVariable Long orgId) {
		try {
			List<BranchBasicDetailsRequest> details = branchService.getBranchByScheme(orgId,schemeId);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@PostMapping(value = "/get/filterBranchList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> searchBranchList(@RequestBody BranchBasicDetailsRequest branchBasicDetailsRequest) {
		try {						
			if (OPLUtils.isObjectNullOrEmpty(branchBasicDetailsRequest.getOrgId()) && OPLUtils.isObjectNullOrEmpty(branchBasicDetailsRequest.getSchTypeId())) {
				return new ResponseEntity<>(new UserResponse("Invalid request,Org or scheme Id not found in request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}			
			List<BranchBasicDetailsRequest> branchBasicDetailsRequestList = branchService.filterBranchList(branchBasicDetailsRequest);
			if (!OPLUtils.isListNullOrEmpty(branchBasicDetailsRequestList)) {
				return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.DATA_LIST_FOUND, HttpStatus.OK.value(), Boolean.TRUE, branchBasicDetailsRequestList), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}
			
		} catch (Exception e) {
			logger.info("Exception While get branch list ===>"+ e);
			return new ResponseEntity<>(new UserResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

	@GetMapping(value = "/getBranchByCodeAndIfscAndOrgId/{code}/{ifsc}/{orgId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchByCodeAndIfscAndOrgId(@PathVariable String code, @PathVariable String ifsc,@PathVariable Long orgId) {
		try {
			BranchBasicDetailsRequest details = branchService.getBranchByCodeAndIfscAndOrgId(code, ifsc, orgId);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes(HttpStatus.NO_CONTENT.getReasonPhrase(),HttpStatus.NO_CONTENT.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/getBranchDetailsRoZOByCodeAndIfscAndOrgId/{code}/{ifsc}/{orgId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserCommonRes> getBranchByCodeAndIfscAndOrgId(@PathVariable String code, @PathVariable String ifsc,@PathVariable Long orgId,@PathVariable Long schemeId) {
		try {
			BranchBasicDetailsRequest details = branchService.getBranchDetailsRoZOByCodeAndIfscAndOrgId(code, ifsc,orgId,schemeId);
			if (details == null) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes(HttpStatus.NO_CONTENT.getReasonPhrase(),HttpStatus.NO_CONTENT.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), details), HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
