package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.users.service.domain.SchemeMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface SchemeMasterRepositoryV3 extends JpaRepository<SchemeMaster, Long> {

		Boolean existsByIdAndIsActiveTrue(Long schemeId);
}
