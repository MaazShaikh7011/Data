package com.opl.jns.users.service.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/v3/offlineConfig")
@RestController
public class OfflineConfigurationControllerV3 {

	private static final Logger logger = LoggerFactory.getLogger(OfflineConfigurationControllerV3.class.getName());

//	@Autowired
//	private OfflineConfigServiceV3 offlineService;

//	@SkipInterceptor
//	@RequestMapping(value = "/get/{schemeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserCommonRes> get(@PathVariable("schemeId") Integer schemeId,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//		try {
//			Long userOrgId = authClientResponse.getUserOrgId();
//			if (userOrgId == null) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("Invalid Request, Bank Id not found from your session",
//								HttpStatus.BAD_REQUEST.value()),
//						HttpStatus.OK);
//			}
//			List<OfflineConfigurationProxy> config = offlineService.get(schemeId,
//					userOrgId);
//			if (OPLUtils.isListNullOrEmpty(config)) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("No data found", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			} else {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), config), HttpStatus.OK);
//			}
//			new UserCommonRes("No data found", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//
//		} catch (Exception e) {
//			return new ResponseEntity<UserCommonRes>(
//					new UserCommonRes("The application has encountered some error, please try after some time",
//							HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}

//	@SkipInterceptor
//	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserCommonRes> update(@RequestBody OfflineConfigurationProxy configurationProxy,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//		try {
//			Long userOrgId = authClientResponse.getUserOrgId();
//			if (userOrgId == null) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("Invalid Request, Bank Id not found from your session",
//								HttpStatus.BAD_REQUEST.value()),
//						HttpStatus.OK);
//			}
//			configurationProxy.setOrgId(userOrgId);
//			configurationProxy.setModifiedBy(authClientResponse.getUserId());
//			if (configurationProxy.getSchemeId() == null || configurationProxy.getIsActive() == null || OPLUtils.isObjectNullOrEmpty(configurationProxy.getTypeId())) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("Invalid Request, Request parameter is not valid for this request !!",
//								HttpStatus.BAD_REQUEST.value()),
//						HttpStatus.OK);
//			}
//
//			return new ResponseEntity<UserCommonRes>(offlineService.update(configurationProxy), HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("Exception while update offline flag ", e);
//			return new ResponseEntity<UserCommonRes>(
//					new UserCommonRes("The application has encountered some error, please try after some time",
//							HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//
//	}
	
//	@RequestMapping(value = "/getAudit/{schemeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserCommonRes> getAudit(@PathVariable("schemeId") Integer schemeId,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//		try {
//			Long userOrgId = authClientResponse.getUserOrgId();
//			if (userOrgId == null) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("Invalid Request, Bank Id not found from your session",
//								HttpStatus.BAD_REQUEST.value()),
//						HttpStatus.OK);
//			}
//			return new ResponseEntity<UserCommonRes>(
//					new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), offlineService.getAudit(schemeId,
//							userOrgId)), HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<UserCommonRes>(
//					new UserCommonRes("The application has encountered some error, please try after some time",
//							HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	
//	@RequestMapping(value = "/checkOfflineConfigByOrgDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserCommonRes> checkOfflineConfigrationOrgIdDetails(@RequestBody OfflineConfigurationProxy configurationProxy) {
//		try {
//			logger.info("Enter In Offline Configuration By Org");
//			if(configurationProxy.getOrgId() == null || configurationProxy.getSchemeId() == null || configurationProxy.getTypeId() == null) {
//				return new ResponseEntity<UserCommonRes>(
//						new UserCommonRes("OrgId or shcmeId or typeId should not be null or empty.",
//								HttpStatus.BAD_REQUEST.value()),
//						HttpStatus.OK);
//			}
//
//			Boolean orgIsActive =  offlineService.checkOfflineConfigrationOrgId(configurationProxy.getSchemeId(),configurationProxy.getOrgId(), configurationProxy.getTypeId());
//			return new ResponseEntity<UserCommonRes>(new UserCommonRes("Its seems this bank has disabled offline application process.", orgIsActive, HttpStatus.OK.value(), orgIsActive), HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("Exception while update offline flag ", e);
//			return new ResponseEntity<UserCommonRes>(
//					new UserCommonRes("The application has encountered some error, please try after some time",
//							HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//
//	}
}
