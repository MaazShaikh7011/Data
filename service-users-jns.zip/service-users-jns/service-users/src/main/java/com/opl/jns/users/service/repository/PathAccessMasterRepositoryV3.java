package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.users.service.domain.PathAccessMaster;

/**
 * @author sandip.bhetariya
 *
 */
@Repository
public interface PathAccessMasterRepositoryV3  extends JpaRepository<PathAccessMaster, Long>{
}
