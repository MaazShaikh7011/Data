package com.opl.jns.users.service.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.api.model.LgdStateResponse;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.service.domain.BranchMaster;
import com.opl.jns.users.service.domain.UserOrganisationMaster;
import com.opl.jns.users.service.repository.BranchMasterRepositoryV3;
import com.opl.jns.users.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.users.service.service.BranchMasterServiceV3;
import com.opl.jns.utils.common.OPLUtils;

/**
 * @author sandip.bhetariya
 *
 */
@Service
@Transactional
public class BranchMasterServiceImplV3 implements BranchMasterServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(BranchMasterServiceImplV3.class.getName());

	@Autowired
	private BranchMasterRepositoryV3 branchRepository;

	@Autowired
	private OneFormClient oneFormClient;

	@Autowired
	private UserOrganisationMasterRepositoryV3 userOrganisationMasterRepository;

	@Override
	public List<BranchBasicDetailsRequest> getBranchListBasedOnCityOrStateOrOrgId(BranchBasicDetailsRequest branchRequest) throws Exception {
		// TODO Auto-generated method stub
		logger.info("entry in getBranchListBasedOnCityOrStateOrOrgId()");
		//		List<BranchMaster> branchList = branchRepository.getBranchListBasedOnCityOrStateOrOrgId();
		List<BranchBasicDetailsRequest> branchRespList = new ArrayList<BranchBasicDetailsRequest>();
		List<BranchMaster> branchList = new ArrayList<>();

		/**
		 * get list using orgid , stateid, cityid and SchTypeId
		 */
		UserOrganisationMaster userOrganisationMaster = null;
		if (!OPLUtils.isObjectNullOrEmpty(branchRequest.getOrgId()) && !OPLUtils.isObjectNullOrEmpty(branchRequest.getSchTypeId())) {
			userOrganisationMaster = userOrganisationMasterRepository.findByUserOrgId(branchRequest.getOrgId());
			branchList = branchRepository.getBranchListBasedOnCityOrStateOrOrgId(branchRequest.getOrgId(), branchRequest.getSchTypeId());
		}

		if(!OPLUtils.isListNullOrEmpty(branchList)) {
			for (BranchMaster branchMaster : branchList) {
				BranchBasicDetailsRequest branchBasicDetailsRequest = new BranchBasicDetailsRequest();
				BeanUtils.copyProperties(branchMaster, branchBasicDetailsRequest);
				if (!OPLUtils.isObjectNullOrEmpty(userOrganisationMaster)) {
					branchBasicDetailsRequest.setShortLogoUrl(!OPLUtils.isObjectNullOrEmpty(userOrganisationMaster.getImagePath()) ? userOrganisationMaster.getImagePath() : null);
					branchBasicDetailsRequest.setLargeLogoUrl(!OPLUtils.isObjectNullOrEmpty(userOrganisationMaster.getLargeLogoUrl()) ? userOrganisationMaster.getLargeLogoUrl() : null);
				}
				branchRespList.add(branchBasicDetailsRequest);
			}
		}

		logger.info("exit in getBranchListBasedOnCityOrStateOrOrgId()");
		return branchRespList;
	}

	@Override
	public BranchBasicDetailsRequest get(Long branchId) throws Exception {
		Optional<BranchMaster> branchMaster = branchRepository.findById(branchId);
		BranchBasicDetailsRequest branchBasicDetailsRequest = new BranchBasicDetailsRequest();
		if (branchMaster.isPresent()) {
			BeanUtils.copyProperties(branchMaster.get(), branchBasicDetailsRequest);
		}
		if (!OPLUtils.isObjectNullOrEmpty(branchBasicDetailsRequest)) {
			if (!OPLUtils.isObjectNullOrEmpty(branchMaster.get().getOrgId()) && !OPLUtils.isObjectNullOrEmpty(branchMaster.get().getOrgId().getUserOrgId())
					&& !OPLUtils.isObjectNullOrEmpty(branchMaster.get().getOrgId().getDisplayOrgName())) {
				branchBasicDetailsRequest.setBankName(branchMaster.get().getOrgId().getDisplayOrgName());
				branchBasicDetailsRequest.setOrgId(branchMaster.get().getOrgId().getUserOrgId());
			}

			// get city details from OneFormCLient using branch city id
			if (branchBasicDetailsRequest.getCityId() != 0 && branchBasicDetailsRequest.getCityId() != null) {
				LgdDistrictStateResponse cityMasterResponse = oneFormClient.getLgdCityByCityId(Long.valueOf(branchBasicDetailsRequest.getCityId()));

				if (!OPLUtils.isObjectNullOrEmpty(cityMasterResponse)) {
					branchBasicDetailsRequest.setCityName(cityMasterResponse.getDistrictName());
					branchBasicDetailsRequest.setCityValue(cityMasterResponse.getDistrictName());
				} else {
					logger.info(" City Details Not Found By cityId (getInPrincipleDetails) ----->");
				}
			} else {
				logger.info(" City Id is null (getInPrincipleDetails) ");
			}

			// get State details from OneFormCLient using branch State id
			if (branchBasicDetailsRequest.getStateId() != 0 && branchBasicDetailsRequest.getStateId() != null) {
				LgdStateResponse stateMasterResponse = oneFormClient.getLgdStateByStateId(Long.valueOf(branchBasicDetailsRequest.getStateId()));

				if (!OPLUtils.isObjectNullOrEmpty(stateMasterResponse)) {
					branchBasicDetailsRequest.setStateName(stateMasterResponse.getStateName());
					branchBasicDetailsRequest.setStateValue(stateMasterResponse.getStateName());
				} else {
					logger.info("State Details Not Found By stateID (getInPrincipleDetails) ----->ID:- " + branchBasicDetailsRequest.getStateId());
				}
			} else {
				logger.info("State Id is null (getInPrincipleDetails) ");
			}
		}

		return branchBasicDetailsRequest;
	}

	@Override
	public List<BranchBasicDetailsRequest> searchBranchListBasedOnCodeOrName(BranchBasicDetailsRequest branchRequest, Long userId, Long userOrgId) throws Exception {
		logger.info("in searchBranchListBasedOnCodeOrName()");
		List<BranchBasicDetailsRequest> branchRespList = new ArrayList<BranchBasicDetailsRequest>();
		List<BranchMaster> branchList = new ArrayList<>();

		if (!OPLUtils.isObjectNullOrEmpty(branchRequest) && !OPLUtils.isObjectNullOrEmpty(branchRequest.getName()) && !OPLUtils.isObjectNullOrEmpty(branchRequest.getSchTypeId()))
		//        	&& !OPLUtils.isObjectNullOrEmpty(branchRequest.getBranchId())
		{
			branchList = branchRepository.searchBranchListBasedOnCodeOrName(branchRequest.getName(), userOrgId, branchRequest.getSchTypeId(), !OPLUtils.isObjectNullOrEmpty(branchRequest.getBranchId()) ? branchRequest.getBranchId() : 0);
		}
		for (BranchMaster branchMaster : branchList) {
			BranchBasicDetailsRequest branchBasicDetailsRequest = new BranchBasicDetailsRequest();
			BeanUtils.copyProperties(branchMaster, branchBasicDetailsRequest);
			branchRespList.add(branchBasicDetailsRequest);
		}

		logger.info("exit searchBranchListBasedOnCodeOrName()");
		return branchRespList;
	}

	public List<BranchBasicDetailsRequest> getBranchByScheme(Long orgId, Long schemeId) {
		try {
			List<BranchBasicDetailsRequest> branchRequests = branchRepository.getBranchByIds(orgId, schemeId);
			return !OPLUtils.isListNullOrEmpty(branchRequests) ? branchRequests : Collections.emptyList();
		} catch (Exception e) {
			logger.info("exit getBranchByScheme() {}", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<BranchBasicDetailsRequest> getBranchByListId(Set<Long> ids) throws Exception {
		logger.info("in getBranchByListId()");
		List<Long> branchIds = new ArrayList<>();
		for (Object abcd : ids) {
			if (!OPLUtils.isObjectNullOrEmpty(abcd))
				branchIds.add(Long.valueOf(abcd.toString()));
		}

		List<BranchBasicDetailsRequest> resLst = new ArrayList<>();
		List<BranchMaster> findAllById = branchRepository.findAllById(branchIds);
		for (BranchMaster branch : findAllById) {
			BranchBasicDetailsRequest branchBasicDetailsRequest = new BranchBasicDetailsRequest();
			BeanUtils.copyProperties(branch, branchBasicDetailsRequest);
			resLst.add(branchBasicDetailsRequest);
		}
		logger.info("exit getBranchByListId()");
		return resLst;
	}

	@Override
	public BranchBasicDetailsRequest getBranchCode(Long schemeId, Long orgId, String branchCode) {
		logger.info("in getBranchCode()");
		BranchBasicDetailsRequest branchBasicDetailsRequest = null;
		List<BranchBasicDetailsRequest> branchBasedOnCode = branchRepository.getBranchBasedOnCode(branchCode, orgId, schemeId);
		if (!OPLUtils.isListNullOrEmpty(branchBasedOnCode)) {
			branchBasicDetailsRequest = branchBasedOnCode.get(0);
		}
		logger.info("exit getBranchCode()");
		return branchBasicDetailsRequest;
	}

	/*
	 * filter branch List based on branch name , ifsc code and pincode
	 */
	@Override
	public List<BranchBasicDetailsRequest> filterBranchList(BranchBasicDetailsRequest branchRequest) throws Exception {
		logger.info("Enter the filterBranchList based name,Ifsc code And Pincode");
		try {
			List<BranchMaster> branchList = null;
			if (!OPLUtils.isObjectNullOrEmpty(branchRequest.getOrgId()) && !OPLUtils.isObjectNullOrEmpty(branchRequest.getStateId())) {
				branchList = branchRepository.serachBranchListBasedOnState(branchRequest.getName(), branchRequest.getStateId(), branchRequest.getOrgId(), branchRequest.getSchTypeId());
			} else {
				branchList = branchRepository.searchBranchListBasedOnCodeOrName(branchRequest.getName(), branchRequest.getOrgId(), branchRequest.getSchTypeId());
			}
			if (!OPLUtils.isListNullOrEmpty(branchList)) {
				String shortImagePath = userOrganisationMasterRepository.getShortImageByOrgId(branchRequest.getOrgId());
				List<BranchBasicDetailsRequest> branchDetailReqList = new ArrayList<>();
				for (BranchMaster branchMaster : branchList) {
					BranchBasicDetailsRequest request = new BranchBasicDetailsRequest();
					BeanUtils.copyProperties(branchMaster, request);
					if (!OPLUtils.isObjectNullOrEmpty(shortImagePath)) {
						request.setShortLogoUrl(shortImagePath);
					}
					branchDetailReqList.add(request);
				}
				return branchDetailReqList;
			}
			return Collections.emptyList();

		} catch (Exception e) {
			logger.error("exception while get the branch List----------------------->", e);
			return Collections.emptyList();
		}

	}

	@Override
	public BranchBasicDetailsRequest getBranchByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId) {
		try {
			return branchRepository.getBranchByCodeAndIfscAndOrgId(code, ifsc, orgId);
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public BranchBasicDetailsRequest getBranchDetailsRoZOByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId,Long schemeId) {
		try {
			 BranchBasicDetailsRequest branchDetailsByCodeAndIfscAndOrgId = branchRepository.getBranchDetailsByCodeAndIfscAndOrgId(code, ifsc, orgId,schemeId);
			 if(!OPLUtils.isObjectNullOrEmpty(branchDetailsByCodeAndIfscAndOrgId)) {
				 return branchDetailsByCodeAndIfscAndOrgId;
			 }
		} catch (Exception e) {
			return null;
		}
		return null;
	}
}
