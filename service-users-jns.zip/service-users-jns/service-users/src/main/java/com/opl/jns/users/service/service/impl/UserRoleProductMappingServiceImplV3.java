package com.opl.jns.users.service.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.opl.jns.users.api.model.UserRoleProductMapProxy;
import com.opl.jns.users.service.domain.BusinessMaster;
import com.opl.jns.users.service.domain.SchemeMaster;
import com.opl.jns.users.service.domain.UserRoleProductMapping;
import com.opl.jns.users.service.repository.BusinessMasterRepositoryV3;
import com.opl.jns.users.service.repository.SchemeMasterRepositoryV3;
import com.opl.jns.users.service.repository.UserRoleProductMappingRepositoryV3;
import com.opl.jns.users.service.service.UserRoleProductMappingServiceV3;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class UserRoleProductMappingServiceImplV3 implements UserRoleProductMappingServiceV3 {

	@Autowired
	private UserRoleProductMappingRepositoryV3 mappingRepository;
	
	@Autowired
	private BusinessMasterRepositoryV3 businessMasterRepository;
	@Autowired
	private SchemeMasterRepositoryV3 schemeMasterRepository;

	
	@Override
	public String getSchemeByUserIdBusinessId(Long userId, Long businessType, Integer type) {
		try {
			return mappingRepository.spGetProductByUserIdAndBusinessTypeId(userId, businessType, type);
		} catch (Exception e) {
			if(OPLUtils.isObjectNullOrEmpty(businessType)) {
				log.error("Error is getting while get Product userId => {}", userId);
			} else {
				log.error("Error is getting while get Scheme userId => {}", userId,"   businessId => {}", businessType);
			}
			return null;
		}
	}
	
	@Override
	public List<UserRoleProductMapProxy> listRoleByUserId(Long userId) {
		List<UserRoleProductMapping> mappingList = mappingRepository.list(userId);
		if (mappingList != null && mappingList.size() > 0) {// check if null
			List<UserRoleProductMapProxy> responseList = new ArrayList<>(mappingList.size());
			for (UserRoleProductMapping mapping : mappingList) {
				UserRoleProductMapProxy response = new UserRoleProductMapProxy();
				BeanUtils.copyProperties(mapping, response);
				response.setRoleId(mapping.getUserRoleMaster().getRoleId());
				response.setUserId(mapping.getUser().getUserId());
				BusinessMaster bsMaster = businessMasterRepository.findById(mapping.getBusinessTypeId().intValue());
				response.setBusinessTypeId(mapping.getBusinessTypeId());
				response.setBusinessTypeName(bsMaster.getDisplayName());
				response.setImgPath(bsMaster.getImgPath());
				response.setRoutingPath(bsMaster.getPath());
				response.setSequence(bsMaster.getSequence());
				responseList.add(response);
			}
			responseList.sort(Comparator.comparing(userRoleProductMapProxy -> userRoleProductMapProxy.getSequence()));
			return responseList;
		} else {
			return null;
		}
	}

	@Override
	public List<UserRoleProductMapProxy> listRoleByUserIdAndBusinessType(Long userId,Long businessTypeId) {
		List<UserRoleProductMapping> mappingList = mappingRepository.listScheme(userId, businessTypeId);
		if (mappingList != null && mappingList.size() > 0) {// check if null
			List<UserRoleProductMapProxy> responseList = new ArrayList<>();
			for (UserRoleProductMapping mapping : mappingList) {
				UserRoleProductMapProxy response = new UserRoleProductMapProxy();
				BeanUtils.copyProperties(mapping, response);
				response.setRoleId(mapping.getUserRoleMaster().getRoleId());
				response.setUserId(mapping.getUser().getUserId());
				BusinessMaster bsMaster = businessMasterRepository.findById(mapping.getBusinessTypeId().intValue());
				response.setBusinessTypeId(mapping.getBusinessTypeId());
				response.setSchemeId(mapping.getSchemeId());
				response.setBusinessTypeName(bsMaster.getDisplayName());
				response.setImgPath(bsMaster.getImgPath());
				response.setRoutingPath(bsMaster.getPath());
				SchemeMaster schemeMasterData = schemeMasterRepository.getById(mapping.getSchemeId());
				response.setSchemeName(schemeMasterData.getName());
				response.setSchemeImgPath(schemeMasterData.getImgPath());
				response.setSchemeRoutingPath(schemeMasterData.getPath());
				responseList.add(response);
			}
			return responseList;
		} else {
			return null;
		}
	}

	@Override
	public List<UserRoleProductMapProxy> schemeByUserId(Long userId) {
		List<UserRoleProductMapping> mappingList = mappingRepository.listSchemes(userId);
		if (mappingList != null && mappingList.size() > 0) {// check if null
			List<UserRoleProductMapProxy> responseList = new ArrayList<>();
			for (UserRoleProductMapping mapping : mappingList) {
				UserRoleProductMapProxy response = new UserRoleProductMapProxy();
				BeanUtils.copyProperties(mapping, response);
				response.setRoleId(mapping.getUserRoleMaster().getRoleId());
				response.setUserId(mapping.getUser().getUserId());
				BusinessMaster bsMaster = businessMasterRepository.findById(mapping.getBusinessTypeId().intValue());
				response.setBusinessTypeId(mapping.getBusinessTypeId());
				response.setSchemeId(mapping.getSchemeId());
				response.setBusinessTypeName(bsMaster.getDisplayName());
				response.setImgPath(bsMaster.getImgPath());
				response.setRoutingPath(bsMaster.getPath());
				SchemeMaster schemeMasterData = schemeMasterRepository.getById(mapping.getSchemeId());
				response.setSchemeName(schemeMasterData.getName());
				response.setSchemeImgPath(schemeMasterData.getImgPath());
				response.setSchemeRoutingPath(schemeMasterData.getPath());
				responseList.add(response);
			}
			return responseList;
		} else {
			return null;
		}
	}

}
