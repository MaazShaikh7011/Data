package com.opl.jns.users.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "campaign_master")
public class CampaignMaster implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "campaign_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "campaign_master_seq_gen", sequenceName = "campaign_master_seq", allocationSize = 1)
	private Long id;

	@Column(name = "campaign_url", columnDefinition = "varchar(15) default ''")
	private String campaignUrl;

	@Column(name = "name", columnDefinition = "varchar(100) default ''")
	private String name;

	@ManyToOne
	@JoinColumn(name = "org_id",referencedColumnName = "user_org_id")
	private UserOrganisationMaster organisationMaster;

	/**
	 * 1. Market Place    2. Bank Specific    3. Both
	 */
	@Column(name = "campaign_type")
	private Integer campaignType;

	@Column(name = "image_url", columnDefinition = "varchar(100) default ''")
	private String imageUrl;

	@Column(name = "sub_domain_url", columnDefinition = "varchar(50) default ''")
	private String subDomainUrl;

	@Column(name = "is_coming_soon")
	private Boolean isComingSoon;

	@Column(name = "css_name", columnDefinition = "varchar(50) default ''")
	private String cssName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
	
	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "created_by")
	private Long createdBy;

	@Column(name = "is_active")
	private Boolean isActive;

	@Lob
	@Column(name = "configuration")
	private String configuration;

	public CampaignMaster(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "CampaignMaster{" +
				"id=" + id +
				'}';
	}
}
