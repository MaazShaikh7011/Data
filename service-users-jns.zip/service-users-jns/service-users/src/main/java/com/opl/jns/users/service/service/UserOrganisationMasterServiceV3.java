package com.opl.jns.users.service.service;

import java.util.List;
import java.util.Map;

import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.api.model.UserOrganisationPdfGenarateRequestResponse;

public interface UserOrganisationMasterServiceV3 {

	public List<UserOrganisationMasterResponse> getAll(Integer orgType);
	
	public UserOrganisationMasterResponse getById(Long orgId);

	String getOrganizationName(Long orgId);

//	public  List<UserOrganisationMasterResponse> getAllOfflineOrgByOrgTypeBySchemeId(Integer orgType, Long schemeId) throws Exception;
	public  List<Long> getAllInActiveOrgList();

//	public Boolean checkOrgStatusByOrgIdAndSchemeIdAndCampainType(Long orgId, Long schemeId, Integer campainType) throws Exception;
	
//	public UserResponse getLenderMaster(String locale) throws Exception;
	
	public List<Map<String, Object>> getOrgMasterListByUserTypeId(Long userTypeId,Long schemeId);
	
	public List<Map<Long, String>> getOrganisationMstListByUserTypeId(Long userTypeId);

	public UserOrganisationPdfGenarateRequestResponse getOrganizationDetailsForPDF(UserOrganisationPdfGenarateRequestResponse genarateRequest) throws Exception;

	public List<UserOrganisationMasterResponse> getOrganizationDetailsByOrgIds(UserOrganisationPdfGenarateRequestResponse genarateRequest) throws Exception;
}
