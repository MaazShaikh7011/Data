package com.opl.jns.users.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.users.service.domain.UserTypeMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface UserTypeMasterRepositoryV3  extends JpaRepository<UserTypeMaster, Long> {
	
	public List<UserTypeMaster> findByIsActive(Boolean isActive);
	
	public List<UserTypeMaster> findByIsDisplayOnLogin(Boolean isDisplayOnLogin);
	
	public List<UserTypeMaster> findByIsActiveAndIsDisplayOnLogin(Boolean isActive, Boolean isDisplayOnLogin);

}
