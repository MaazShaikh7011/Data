package com.opl.jns.users.service.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.otp.api.exception.OTPException;
import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.otp.client.OTPClient;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.SignUpRequest;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.domain.User;
import com.opl.jns.users.service.domain.UserPasswordChangeLog;
import com.opl.jns.users.service.domain.UserTypeMaster;
import com.opl.jns.users.service.repository.UserPasswordChangeLogRepositoryV3;
import com.opl.jns.users.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.users.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.users.service.repository.UsersRepositoryV3;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.users.service.service.SignUpServiceV3;
import com.opl.jns.users.service.service.UsersServiceV3;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class SignUpServiceImplV3 implements SignUpServiceV3 {

	@Autowired
	private UsersRepositoryV3 usersRepository;

	@Autowired
	private OTPClient otpClient;

	@Autowired
	private UsersServiceV3 usersService;

	@Autowired
	private UserPasswordChangeLogRepositoryV3 passwordChangeLogRepository;
	
	@Autowired
	private AuthClient authClient;

	@Autowired
	UserRoleMasterRepositoryV3 userRoleMasterRepository;

	@Autowired
	UserTypeMasterRepositoryV3 userTypeMasterRepository;

	@Autowired
	LoginServiceV3 loginService;

	public static final Long MARKET_PLACE = 1L;

	@Override
	public CommonResponse signup(SignUpRequest signUpReq) throws UserException {
		log.info("Entry in signup()");
		// CHECK MOBILE NUMBER IS EXIST OR NOT IN REQUEST USER TYPE
		User users = usersRepository.findByMobileAndUserTypeMasterId(signUpReq.getMobile(), signUpReq.getUserType());
		if (users == null) {
			users = new User();
			users.setMobile(signUpReq.getMobile());
			users.setUsername(signUpReq.getName());
			users.setCreatedDate(new Date());
		} else {
			// CHECK IF USER HAS VERIFIED OTP OR NOT
			if (users.getIsActive() && users.getOtpVerified()) {
				return new CommonResponse("Mobile Number already in use.Please try another.", users.getUserId(),
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			users.setModifiedBy(users.getUserId());
			users.setModifiedDate(new Date());
		}
		users.setIsActive(Boolean.FALSE);
		users.setOtpVerified(Boolean.FALSE);
		users.setUserRoleId(userRoleMasterRepository.findByRoleId(com.opl.jns.utils.enums.UserRoleMaster.BORROWER.getId()));
		users.setUserTypeMaster(userTypeMasterRepository.getById(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()));
		users.setSignUpDate(new Date());
		users.setTermsAccepted(signUpReq.getIsTermsAccepted());
		users = usersRepository.save(users);
		signUpReq.setUserId(users.getUserId());

		// SAVE CAMPAIGN CODE WHILE REGISTRATION̥
//		try {
//			CampaignUserMappingProxy campaignUserMappingProxy = new CampaignUserMappingProxy();
//			campaignUserMappingProxy.setUserId(users.getUserId());
//			campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(signUpReq.getCampaignMasterId() != null ? signUpReq.getCampaignMasterId() : MARKET_PLACE));
//			campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy);
//
////			if (!OPLUtils.isObjectNullOrEmpty(signUpReq.getCampaignCode())) {
////				CampaignRequest campaignRequest = new CampaignRequest();
////				campaignRequest.setUserId(users.getUserId());
////				campaignRequest.setCode(signUpReq.getCampaignCode());
////				campaignRequest.setType(signUpReq.getCampaignType());
////				campaignDetailService.save(campaignRequest);
////			}
//		} catch (Exception e) {
//			throw new UserException("Exception while Save Campaign Details");
//		}
		log.info("user signup details saved. {} ", users);

		if (sendMobileOTP(signUpReq)) {
			log.info("exit form forRegistrationProcess()");
			return new CommonResponse("Please enter OTP", users.getUserId(), HttpStatus.OK.value(),
					Boolean.TRUE);
		}
		log.info("exit form forRegistrationProcess()");
		throw new UserException("Exception Send OTP to registered user mobile number");
	}

	public CommonResponse diySignup(SignUpRequest signUpRequest) {
		try {
			boolean checkMobile = usersService.checkMobile(signUpRequest.getMobile(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());

			if (checkMobile) {
	            log.error("Mobile number found in database");
	            return new CommonResponse("Mobile Number is already registered with a User.", HttpStatus.BAD_REQUEST.value(),Boolean.FALSE);
	        }
			
			User user = usersRepository.findByEmailAndUserTypeMasterId(signUpRequest.getEmail(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
			if (OPLUtils.isObjectNullOrEmpty(user)) {
				user = usersRepository.findOneByUsernameAndUserTypeMasterId(signUpRequest.getUsername(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
			}
			if (OPLUtils.isObjectNullOrEmpty(user)) {
//				CREATE USER IF NOT EXISTS USERNAME
				user = saveUserDetails(signUpRequest);
				if (!OPLUtils.isObjectNullOrEmpty(user)) {
					log.info("Successfully User Created", user.getUsername());
					return new CommonResponse("Successfully Created", user.getUserId(), HttpStatus.OK.value(), Boolean.TRUE);
				}
			} else {
				return new CommonResponse("Already Exists User", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
			}

		} catch (Exception e) {
			log.error("Exception is getting while DIY SignUp & Login", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
	}
	
	public CommonResponse checkMobile(SignUpRequest signUpRequest) {
		try {
			boolean checkMobile = usersService.checkMobile(signUpRequest.getMobile(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());

			if (checkMobile) {
	            log.error("Mobile number found in database");
	            return new CommonResponse("Mobile Number is already registered with a User.", HttpStatus.BAD_REQUEST.value(),Boolean.FALSE);
	        }

		} catch (Exception e) {
			log.error("Exception is getting while checkMobile", e);
		}
		return new CommonResponse("this is unique mobile number", null, HttpStatus.OK.value(), Boolean.TRUE);
	}

	private User saveUserDetails(SignUpRequest signUpRequest) {
		User user = new User();
		user.setPassword(DigestUtils.md5DigestAsHex(signUpRequest.getPassword().getBytes()));
		user.setCreatedDate(new Date());
		user.setSignUpDate(new Date());
		user.setUsername(signUpRequest.getUsername().toLowerCase());
		user.setEmail(signUpRequest.getEmail());
		user.setMobile(OPLUtils.getValidMobileNumber(signUpRequest.getMobile()));
		user.setIsActive(Boolean.TRUE);
		user.setOtpVerified(Boolean.TRUE);
		user.setTermsAccepted(Boolean.TRUE);
		user.setPassChanged(Boolean.TRUE);
		user.setUserRoleId(userRoleMasterRepository.findByRoleId(com.opl.jns.utils.enums.UserRoleMaster.BORROWER.getId()));
		user.setUserTypeMaster(userTypeMasterRepository.findById(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()).get());
		return usersRepository.saveAndFlush(user);
	}

	@Override
	public boolean sendMobileOTP(SignUpRequest usersRequest) {
		log.info("entry in sendOTP()");
		try {
			OTPRequest request = new OTPRequest();
			request.setMobileNo(usersRequest.getMobile());
			request.setRequestType(usersRequest.getOtpType());
			request.setMasterId(usersRequest.getUserId());
			request.setEmailId(usersRequest.getEmail());
			request.setNotificationMasterId(usersRequest.getNotificationMasterId());
			OTPResponse otpResponse = otpClient.sendOTP(request);
			log.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			return otpResponse.getStatus() != null && otpResponse.getStatus().equals(200);

		} catch (OTPException e) {
			log.error("Error while OTP send ", e);
		}
		log.info("exit form sendOTP()");
		return false;
	}

	/**
	 * UserId, OtpType, OTP
	 * 
	 * @param signupRequest
	 * @return
	 */
	@Override
	public CommonResponse verifyOTP(SignUpRequest signupRequest) {

		User users = usersRepository.findById(signupRequest.getUserId()).orElse(null);
		if (users == null) {
			return new CommonResponse("Invalid Request, UserId is not valid", HttpStatus.BAD_REQUEST.value(),
					Boolean.FALSE);
		}
		
		if (signupRequest.getOtpType() == 1) {
			if(OPLUtils.isObjectNullOrEmpty(signupRequest.getMobile()) || !users.getMobile().equalsIgnoreCase(signupRequest.getMobile())) {
				return new CommonResponse("Its seems we found wrong mobile number in request, please refresh page and register again", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
		}
		else if(signupRequest.getOtpType() == 3)
		{
//			if(!OPLUtils.isObjectNullOrEmpty(signupRequest.getMobile()) &&!users.getMobile().equalsIgnoreCase(signupRequest.getMobile())) {
//				return new CommonResponse("Its seems we found wrong mobile number in request, please refresh page and register again", HttpStatus.BAD_REQUEST.value(),
//						Boolean.FALSE);
//			}
//			else
//				if(!OPLUtils.isObjectNullOrEmpty(signupRequest.getEmail()) &&  !users.getEmail().equalsIgnoreCase(signupRequest.getEmail())) {
//				
//					return new CommonResponse("Its seems we found wrong email address in request, please refresh page and register again", HttpStatus.BAD_REQUEST.value(),
//							Boolean.FALSE);	
//			}
		}
		else {
			log.info("Request Email -----------------> " + signupRequest.getEmail());
			log.info("User Email -----------------> " + users.getEmail());
			if((OPLUtils.isObjectNullOrEmpty(signupRequest.getEmail()) ||  (!OPLUtils.isObjectNullOrEmpty(users.getEmail()) && !users.getEmail().equalsIgnoreCase(signupRequest.getEmail()))) && signupRequest.getOtpType()!=2) {
				return new CommonResponse("Its seems we found wrong email address in request, please refresh page and register again", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
		}
		

		log.info("entry in validateOTP()");
		OTPRequest request = new OTPRequest();
		request.setMasterId(signupRequest.getUserId());
		request.setEmailId(users.getEmail());
		request.setMobileNo(users.getMobile());
		if(signupRequest.getOtpType().equals(UsersUtils.REGISTRATION_SMS)) {
			request.setOtpOn(1);
		}
		else if(signupRequest.getOtpType().equals(UsersUtils.LOGIN_EMAIL)) {
			request.setOtpOn(2);
		}
		else if(signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) {
			request.setEmailId(signupRequest.getEmail());
			request.setMobileNo(signupRequest.getMobile());
			if(!OPLUtils.isObjectNullOrEmpty(request.getEmailId()) && !OPLUtils.isObjectNullOrEmpty(request.getMobileNo())) {
				request.setOtpOn(1);	
			}
			else {
				if(!OPLUtils.isObjectNullOrEmpty(request.getEmailId())) {
					request.setOtpOn(2);
				}else {
					request.setOtpOn(1);	
				}
			}
			
		}
		request.setRequestType(signupRequest.getOtpType());
		request.setOtp(signupRequest.getOtp());
		
		if(signupRequest.getOtpType() == 2) {
			request.setEmailId(signupRequest.getEmail());
		}
		
		/*if(configProperties.getValue(LoadTestingEnum.TESTING_MODE_ON_OFF.getKey()).equals(LoadTestingEnum.TESTING_MODE.getKey())) {
			if (signupRequest.getOtpType() == 1) {
				users.setOtpVerified(Boolean.TRUE);
			} else {
				users.setEmailVerified(Boolean.TRUE);
				// NEED TO GENERATE TOKEN ------------------------------------------------->
			}
			usersRepository.save(users);
			return new CommonResponse("OTP is Verified Successfully", HttpStatus.OK.value(), Boolean.TRUE);
		}*/
		try {
			OTPResponse otpResponse = otpClient.verifyOTP(request);
			log.info("otpResponse :- " + otpResponse.toString());
			if (otpResponse.getStatus() == 200) {
				if (signupRequest.getOtpType() == 1 || signupRequest.getOtpType() == 3) {
					users.setOtpVerified(Boolean.TRUE);
					users.setIsActive(Boolean.TRUE);
				}
				if(signupRequest.getOtpType() == 2) {
					if(!OPLUtils.isObjectNullOrEmpty(signupRequest.getEmail())) {						
						users.setEmail(signupRequest.getEmail());
					}
					users.setEmailVerified(Boolean.TRUE);
					users.setIsActive(Boolean.TRUE);
				}
				usersRepository.save(users);
				return new CommonResponse(((signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) ? "Verification Code" : "Verification Code") + " is Verified Successfully", HttpStatus.OK.value(), Boolean.TRUE);
			} else if (otpResponse.getStatus() == 400 || otpResponse.getStatus() == 409) {
				return new CommonResponse("Please enter valid " + ((signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) ? "Verification Code" : "Verification Code") , HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} catch (OTPException e) {
			log.error("error while calling OTP client for validating OTP... ", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	@Override
	public CommonResponse grienvanceVerifyOTP(SignUpRequest signupRequest) {
		log.info("entry in validateOTP()");
		OTPRequest request = new OTPRequest();
		request.setMasterId(signupRequest.getUserId());
		request.setEmailId(signupRequest.getEmail());
		request.setMobileNo(signupRequest.getMobile());
		if(signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) {
			request.setEmailId(signupRequest.getEmail());
			request.setMobileNo(signupRequest.getMobile());
			if(!OPLUtils.isObjectNullOrEmpty(request.getEmailId()) && !OPLUtils.isObjectNullOrEmpty(request.getMobileNo())) {
				request.setOtpOn(1);	
			}
			else {
				if(!OPLUtils.isObjectNullOrEmpty(request.getEmailId())) {
					request.setOtpOn(2);
				}else {
					request.setOtpOn(1);	
				}
			}
			
		}
		request.setRequestType(signupRequest.getOtpType());
		request.setOtp(signupRequest.getOtp());
		
		try {
			OTPResponse otpResponse = otpClient.verifyOTP(request);
			log.info("otpResponse :- " + otpResponse.toString());
			if (otpResponse.getStatus() == 200) {
				return new CommonResponse(((signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) ? "Verification Code" : "Verification Code") + " is Verified Successfully", HttpStatus.OK.value(), Boolean.TRUE);
			} else if (otpResponse.getStatus() == 400 || otpResponse.getStatus() == 409) {
				return new CommonResponse("Please enter valid " + ((signupRequest.getOtpType().equals(UsersUtils.MOBILE_CONSENT_SMS)) ? "Verification Code" : "Verification Code") , HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} catch (OTPException e) {
			log.error("error while calling OTP client for validating OTP... ", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	
	@Override
	public CommonResponse sendEmailOTP(SignUpRequest usersRequest) {
		try {
			User users = usersRepository.findById(usersRequest.getUserId()).orElse(null);
			if (users == null) {
				return new CommonResponse("Invalid Request, UserId is not valid", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			Long userCount = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrueAndUserIdNot(usersRequest.getEmail(),
					users.getUserTypeMaster().getId(), users.getUserId());
			if (userCount > 0) {
				return new CommonResponse("Email address already in use.Please try another.",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
//			users.setEmail(usersRequest.getEmail());
			usersRepository.save(users);
			OTPRequest request = new OTPRequest();
			request.setMobileNo(usersRequest.getMobile());
			request.setRequestType(usersRequest.getOtpType());
			request.setMasterId(usersRequest.getUserId());
			request.setEmailId(usersRequest.getEmail());
			request.setName(users.getUsername());
			request.setNotificationMasterId(usersRequest.getNotificationMasterId()); 
			OTPResponse otpResponse = otpClient.sendEmailOTP(request);
			log.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			if (otpResponse != null && otpResponse.getStatus() == 200) {
				return new CommonResponse("Email sent successfully for Verification Code ", HttpStatus.OK.value(),
						Boolean.TRUE);
			}
		} catch (OTPException e) {
			log.error("Error while OTP send {}", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}


	
	@Override
	public CommonResponse skipForEmailVerification(UsersRequest usersRequest) {
		try {
			User user = usersRepository.findById(usersRequest.getUserId()).orElse(null);
			if (user == null) {
				return new CommonResponse("Invalid Request, UserId is not valid", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			user.setIsActive(Boolean.TRUE);
			user.setModifiedDate(new Date());
//			user.setCampaignMaster(new CampaignMaster(usersRequest.getCampaignMasterId() != null ? usersRequest.getCampaignMasterId() : MARKET_PLACE));
			usersRepository.save(user);

			//SET CAMPAIGN USER MAPPING
//			CampaignUserMappingProxy campaignUserMappingProxy = new CampaignUserMappingProxy();
//			campaignUserMappingProxy.setUserId(user.getUserId());
//			campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(user.getCampaignMaster().getId()));
//			campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy);

			usersRequest.setMobile(user.getMobile());
			usersRequest.setUserType(user.getUserTypeMaster().getId());
			return new CommonResponse("Skip Successfully", HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("error while skip for email verification while signup process... ", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	

	@Override
	public CommonResponse setPassword(UsersRequest usersRequest) {
		try {
//			User user = usersRepository.findById(usersRequest.getUserId()).orElse(null);
			User user = usersRepository.findByUserId(usersRequest.getUserId());
			if (user == null) {
				return new CommonResponse("Invalid Request, UserId is not valid", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}

//			if (!user.getOtpVerified() || !user.getEmailVerified()) {
//				return new CommonResponse(
//						"It seems you haven’t verified your email address. Please verify your email and then set password!",
//						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
			if (!user.getOtpVerified()) {
				return new CommonResponse(
						"It seems you haven’t verified your email address. Please verify your email and then set password!",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			// UPDATE PASSWORD
			String password = user.getPassword();
			String password1 = user.getPassword1();
			user.setPassword2(password1);
			user.setPassword1(password);
			String encryptedNewPassword = DigestUtils.md5DigestAsHex(usersRequest.getPassword().getBytes());
			user.setPassword(encryptedNewPassword);
			user.setModifiedBy(user.getUserId());
			user.setModifiedDate(new Date());
			user.setIsActive(Boolean.TRUE);
			user.setPassChanged(Boolean.TRUE);
			user.setIsActive(Boolean.TRUE);
			//save campaign in user table
//			user.setCampaignMaster(new CampaignMaster(usersRequest.getCampaignMasterId() != null ? usersRequest.getCampaignMasterId() : MARKET_PLACE));
			usersRepository.save(user);

			//SET CAMPAIGN USER MAPPING
//			CampaignUserMappingProxy campaignUserMappingProxy = new CampaignUserMappingProxy();
//			campaignUserMappingProxy.setUserId(user.getUserId());
//			campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(user.getCampaignMaster().getId()));
//			campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy);

			// SAVE PASSWORD CHANGE AUDIT LOGS
			UserPasswordChangeLog passwordLog = new UserPasswordChangeLog();
			passwordLog.setUserId(user);
			passwordLog.setPassword(user.getPassword());
			passwordLog.setCreatedOn(new Date());
			passwordChangeLogRepository.save(passwordLog);

			// SEND NOTIFICATION
//			userNotificationUtils.sendNotificationOnSignUp(user.getEmail(), user.getMobile(), user.getUserId());
			
			usersRequest.setEmail(user.getEmail());
			usersRequest.setPassword(usersRequest.getPassword());
			usersRequest.setUserType(user.getUserTypeMaster().getId());

			return new CommonResponse("Password Set Successfully", HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("error while calling OTP client for validating OTP... ", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	public AuthResponse callAuthClient(UsersRequest usersRequest) {
		AuthRequest req = new AuthRequest();
		if(usersRequest.getEmail() == null || usersRequest.getPassword() == null) {
			req.setUsername(AuthCredentialUtils.setUserName(usersRequest.getMobile(), false));
			req.setPassword(AuthCredentialUtils.TEMP_PP);
		} else {
			req.setUsername(AuthCredentialUtils.setUserName(usersRequest.getEmail(), true));
			req.setPassword(usersRequest.getPassword());
		}
		req.setUserIp(usersRequest.getRemoteAddr());
		req.setUserTypeId(usersRequest.getUserType());
		req.setUserBrowser(usersRequest.getBrowserName());
		req.setBrowserVersion(usersRequest.getBrowserVersion());
		req.setDevice(usersRequest.getDevice());
		req.setDeviceType(usersRequest.getDeviceType());
		req.setDeviceOs(usersRequest.getDeviceOs());
		req.setDeviceOsVersion(usersRequest.getDeviceOsVersion());
		req.setUserAgent(usersRequest.getUserAgent());
		req.setCampaignMasterId(usersRequest.getCampaignMasterId() != null ? usersRequest.getCampaignMasterId() : MARKET_PLACE);
//		req.setCampaignCode(usersRequest.getCampaignCode());
		AuthResponse response = authClient.getRefreshToken(req);
		if (response != null && response.getStatus() == 200) {
			response.setStatus(HttpStatus.OK.value());
			response.setMessage("Login Successful");
			return response;
		} else {
			if (response != null) {
				response.setStatus(
						response.getStatus() != null ? response.getStatus() : HttpStatus.UNAUTHORIZED.value());
				response.setMessage(
						response.getMessage() != null ? response.getMessage() : "E-Mail ID or Password is invalid");
			} else {
				response = new AuthResponse();
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.setMessage("E-Mail ID or Password is invalid");
			}
			return response;
		}
	}
	
	
//	public CommonResponse getFacilitatorTokens(FacilitatorTokenReq facilitatorTokenReq) {
//		try {
//			//facilitatorsUserMappingRepo
//			User user = null;
//			if(facilitatorTokenReq.getApplicationId() != null) {
//				FacilitatorsUserMapping map = facilitatorsUserMappingRepo.findByApplicationId(facilitatorTokenReq.getApplicationId());
//				if(map == null) {
//					return new CommonResponse("Invalid Request, ApplicationId is wrong for this user!!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//				}
//				user = usersRepository.findById(map.getUserId()).orElse(null);
//			} else if (facilitatorTokenReq.getUserId() != null) {
//				user = usersRepository.findById(facilitatorTokenReq.getUserId()).orElse(null);
//			} else {
//				user = usersRepository.findById(facilitatorTokenReq.getFacilitatorId()).orElse(null);
//			}
//			if(user == null) {
//				return new CommonResponse("Invalid Request, User not found from records!!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//
//			UsersRequest usersRequest = new UsersRequest();
//			usersRequest.setUserId(user.getUserId());
//			//usersRequest.setEmail(user.getEmail());
//			usersRequest.setMobile(user.getMobile());
//			// usersRequest.setPassword(user.getPassword());
//			usersRequest.setUserType(user.getUserTypeMaster().getId());
//			AuthResponse callAuthClient = callAuthClient(usersRequest);
//			if(callAuthClient.getStatus() == HttpStatus.OK.value()) {
//				return new CommonResponse("Get Tokens Successfully!!", callAuthClient, HttpStatus.OK.value(), Boolean.TRUE);
//			}
//		} catch (Exception e) {
//			log.error("Exception while get Facilitator Token ",e);
//		}
//		return new CommonResponse("The application has encountered some error, please try after some time!!",  HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//	}

//	@Override
//	public CommonResponse preScreenSignUp(UsersRequest usersRequest) {
//		try{
//			User user = usersRepository.findByMobileAndUserTypeMasterId(usersRequest.getMobile(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
//			if(OPLUtils.isObjectNullOrEmpty(user) && !OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())) {
//				user = usersRepository.findByEmailAndUserTypeMasterId(usersRequest.getEmail(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
//			}
//
//			if(OPLUtils.isObjectNullOrEmpty(user) && usersRequest.getRequiredAutoRegistration()) {
//				user = usersRepository.findByMobileAndUserTypeMasterId(usersRequest.getMobile(), com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
//				user = OPLUtils.isObjectNullOrEmpty(user) ? new User() : user;
//				createUser(user, usersRequest);
//			}
//			if(OPLUtils.isObjectNullOrEmpty(user)) {
//				return new CommonResponse("User details not found at given mobile or email.", HttpStatus.OK.value(),Boolean.FALSE);
//			}
//			BeanUtils.copyProperties(user,usersRequest, "campaignMasterId");
//
////			if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getCampaignMasterId())) {
////				CommonResponse campaignMasterRes = campaignMasterService.getByCampaignId(usersRequest.getCampaignMasterId());
////				if (!OPLUtils.isObjectNullOrEmpty(campaignMasterRes)) {
////					CampaignMasterProxy campaignMasterProxy = MultipleJSONObjectHelper.getObjectFromObject(campaignMasterRes.getData(), CampaignMasterProxy.class);
////					usersRequest.setCampaignMasterProxy(campaignMasterProxy);
////				}
////			}
//			return new CommonResponse("successfully get user", usersRequest, HttpStatus.OK.value(),Boolean.TRUE);
//		} catch (Exception e){
//			log.info("error is getting while get user",e);
//			return new CommonResponse("This application has encountered some error, please try after sometimes.",HttpStatus.INTERNAL_SERVER_ERROR.value());
//		}
//	}

	private void createUser(User user, UsersRequest usersRequest) throws Exception {
		log.info("============================ ENTER IN createUser() ============================");
		user.setCreatedDate(new Date());
		user.setSignUpDate(new Date());
		user.setMobile(usersRequest.getMobile());
		if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())) {
			user.setEmail(usersRequest.getEmail());
			user.setPassword(DigestUtils.md5DigestAsHex(usersRequest.getPassword().getBytes()));
		}
		user.setIsActive(Boolean.TRUE);
		user.setOtpVerified(Boolean.TRUE);
		user.setUserTypeMaster(new UserTypeMaster(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()));
		user.setSignUpDate(new Date());
		user.setTermsAccepted(Boolean.TRUE);
		user = usersRepository.save(user);

		// SAVE CAMPAIGN CODE WHILE REGISTRATION
//		try {
//			CampaignUserMappingProxy campaignUserMappingProxy = new CampaignUserMappingProxy();
//			campaignUserMappingProxy.setUserId(user.getUserId());
//			campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(!OPLUtils.isObjectNullOrEmpty(usersRequest.getCampaignMasterId()) ? usersRequest.getCampaignMasterId() : MARKET_PLACE));
//			CommonResponse commonResponse = campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy);
//			if (OPLUtils.isObjectNullOrEmpty(commonResponse) || OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus() != HttpStatus.OK.value())) {
//				log.info("CampaignUserMapping not Save");
//			}
//		} catch (Exception e) {
//			log.error("Exception while Save Campaign Details -------------> " + e.getMessage());
//			throw e;
//		}
		log.info("============================ EXIT FROM createUser() ============================");
	}
	
	@Override
	public CommonResponse sendMobileEmailOTP(SignUpRequest usersRequest) {
		try {
			User users = usersRepository.findById(usersRequest.getUserId()).orElse(null);
			if (users == null) {
				return new CommonResponse("Invalid Request, UserId is not valid", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			
//			Long userCount = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrueAndUserIdNot(usersRequest.getEmail(),
//					users.getUserTypeMaster().getId(), users.getUserId());
//			if (userCount == 0) {
//				return new CommonResponse("Email not found.Please try another.",
//						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
			
			OTPRequest request = new OTPRequest();
			request.setMobileNo(usersRequest.getMobile());
			request.setRequestType(usersRequest.getOtpType());
			request.setMasterId(usersRequest.getUserId());
			request.setEmailId(usersRequest.getEmail());
			request.setName(users.getUsername());
			request.setNotificationMasterId(usersRequest.getNotificationMasterId());
			request.setScheme(SchemeMaster.getById(usersRequest.getSchemeId()).getShortName());

			request.setSmsNotiMasterId(OPLUtils.isObjectNullOrEmpty(usersRequest.getSmsNotiMasterId()) ? null :usersRequest.getSmsNotiMasterId());
			request.setEmailNotiMasterId(OPLUtils.isObjectNullOrEmpty(usersRequest.getEmailNotiMasterId()) ? null :usersRequest.getEmailNotiMasterId());;
			OTPResponse otpResponse = otpClient.sendConsentOTPonMobileEmail(request);
			log.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			if (otpResponse.getData() != null && otpResponse.getStatus() == 200) {
				return new CommonResponse(otpResponse.getData(),"Email Sent Successfully For OTP Verification", HttpStatus.OK.value());
			}
		} catch (OTPException e) {
			log.error("Error while OTP send {}", e);
		}
		return new CommonResponse("The application has encountered some error, please try after some time!!",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

}
