package com.opl.jns.users.service.domain;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "insurer_org_mapping",indexes = {
		@Index(columnList = "scheme_id,is_active",name = DBNameConstant.JNS_USERS+"_ins_org_mpg_scheme_id_is_active")
})
public class InsureOrgMapping {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "insurer_org_mapping_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "insurer_org_mapping_seq_gen", sequenceName = "insurer_org_mapping_seq", allocationSize = 1)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "scheme_id")
	private SchemeMaster schemeMaster;
	
	@ManyToOne
	@JoinColumn(name = "org_id",referencedColumnName = "user_org_id")
	private UserOrganisationMaster userOrganisationMaster;
	
	@Column(name = "is_active")
	private Boolean isActive;

}
