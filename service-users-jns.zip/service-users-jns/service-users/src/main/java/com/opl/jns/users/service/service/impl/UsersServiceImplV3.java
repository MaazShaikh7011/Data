package com.opl.jns.users.service.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.api.model.LgdStateResponse;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.otp.api.exception.OTPException;
import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.otp.client.OTPClient;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.BankUserDetailReq;
import com.opl.jns.users.api.model.BankUserDetailRes;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.api.model.UserNotificationDetailsReq;
import com.opl.jns.users.api.model.UserNotificationDetailsRes;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.model.UserTypeRequest;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.domain.PathAccessRoleMapping;
import com.opl.jns.users.service.domain.User;
import com.opl.jns.users.service.domain.UserPasswordChangeLog;
import com.opl.jns.users.service.domain.UserTypeMaster;
import com.opl.jns.users.service.repository.CommonRepository;
import com.opl.jns.users.service.repository.PathAccessRoleMappingRepositoryV3;
import com.opl.jns.users.service.repository.SchemeMasterRepositoryV3;
import com.opl.jns.users.service.repository.UserPasswordChangeLogRepositoryV3;
import com.opl.jns.users.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.users.service.repository.UsersRepositoryV3;
import com.opl.jns.users.service.service.BranchMasterServiceV3;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.users.service.service.UserOrganisationMasterServiceV3;
import com.opl.jns.users.service.service.UsersServiceV3;
import com.opl.jns.users.service.utils.UserNotificationUtils;
import com.opl.jns.utils.common.AESEncryptionUtilitySBI;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.UserRoleMaster;
// for qa
//import com.opl.jns.common.api.notification.utils.NotificationAlias;
/**
 * @author sandip.bhetariya
 *
 */
@Service
@Transactional
public class UsersServiceImplV3 implements UsersServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(UsersServiceImplV3.class.getName());
	private static final String EMAIL_VERIFICATION_URL_KEY = "emailVerification.url";
	private static final String EMAIL_VERIFICATION_FS_URL_KEY = "emailVerification.url.fs";
	private static final String EMAIL_ADDRESS_FROM = "emailAddress.from";
	@Value("${cw.user.resend.email.one.day.count}")
	private String oneDayCount;
	@Autowired
	private UsersRepositoryV3 usersRepository;

	@Autowired
	private OTPClient otpClient;

//	@Autowired
//	private CampaignDetailService campaignDetailService;

//	@Autowired
//	private ForgotPassAuditRepositoryV3 forgotPassAuditRepo;

	@Autowired
	private LoginServiceV3 loginService;

	@Autowired
	private Environment environment;

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private UserNotificationUtils userNotificationUtils;

	@Autowired
	private UserPasswordChangeLogRepositoryV3 passwordChangeLogRepository;

	@Autowired
	private UserOrganisationMasterServiceV3 organisationMasterService;

	@Autowired
	private BranchMasterServiceV3 branchMasterService;

	@Autowired
	private UserTypeMasterRepositoryV3 userTypeMasterRepo;

	@Autowired
	private OneFormClient oneFormClient;

//	@Autowired
//	private FacilitatorsUserMappingRepoV3 facilitatorsUserMappingRepo;

	@Autowired
	private SchemeMasterRepositoryV3 schemeMasterRepository;

	@Autowired
	private PathAccessRoleMappingRepositoryV3 pathAccessRoleMappingRepository;

	@Autowired
	CommonRepository commonRepository;

	public UsersRequest getUserDetailByMobileOrEmail(String mobileNumber, String email, Long userId, Long userTypeId) {

		try {
			User user = null;
			if (!OPLUtils.isObjectNullOrEmpty(email) && !OPLUtils.isObjectNullOrEmpty(userTypeId)) {
				user = usersRepository.findByEmailAndUserTypeMasterId(email, userTypeId);
			}
			if (!OPLUtils.isObjectNullOrEmpty(mobileNumber) && !OPLUtils.isObjectNullOrEmpty(userTypeId)) {
				user = usersRepository.findByMobileAndUserTypeMasterId(mobileNumber, userTypeId);
			}
			if (!OPLUtils.isObjectNullOrEmpty(userId)) {
				user = usersRepository.findById(userId).get();
			}
			if (user == null) {
				return null;
			}
			UsersRequest userRequest = new UsersRequest();
			BeanUtils.copyProperties(user, userRequest);
			userRequest.setUserType(user.getUserTypeMaster().getId());
			userRequest.setFirstName(user.getFirstName() != null ? user.getFirstName() : "");
			userRequest.setLastName(user.getLastName() != null ? user.getLastName() : "");
			userRequest.setId(user.getUserId());
			userRequest.setOtpVerified(user.getOtpVerified());
			userRequest.setUserRoleId(user.getUserRoleId() != null ? user.getUserRoleId().getRoleId() : null);
			userRequest.setUserRoleIdString(user.getUserRoleId() != null ? user.getUserRoleId().getDisplayName() : null);
			userRequest.setIsPasswordSet(!OPLUtils.isObjectNullOrEmpty(user.getPassword()));
			userRequest.setEmailVerified(user.getEmailVerified());
			userRequest.setPassword(null);
			userRequest.setUserName(user.getUsername());
			userRequest.setBranchId(!OPLUtils.isObjectNullOrEmpty(user.getBranchId()) ? user.getBranchId().getId() : null);
			userRequest.setUserOrgId(!OPLUtils.isObjectNullOrEmpty(user.getUserOrgId()) ? user.getUserOrgId().getUserOrgId() : null);
			if (!OPLUtils.isObjectNullOrEmpty(user.getUserOrgId())) {
				userRequest.setUserOrgName(user.getUserOrgId().getDisplayOrgName());
			}
//			userRequest.setLastLoginDate(usersRepository.getLastLoginDate(userId, PageRequest.of(0, 1)));
			if (user.getCampaignMaster() != null) {
				userRequest.setCampaignMasterId(user.getCampaignMaster().getId());
			}
			return userRequest;
		} catch (Exception ex) {
			logger.error("error while get user detail by email or mobile ==> ", ex);
		}
		return null;
	}

	public boolean checkEmailAddress(String email, Long userTypeId) {
		try {
			Long checkEmail = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrue(email, userTypeId);
			return checkEmail > 0 ? true : false;
		} catch (Exception ex) {
			logger.error("error while get user detail by email or mobile", ex);
		}
		return false;
	}

	public boolean checkEmailAddressAfterRegister(String email, Long userTypeId, Long userId) {
		try {
			Long checkEmail = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrueAndUserIdNot(email, userTypeId, userId);
			return checkEmail > 0 ? true : false;
		} catch (Exception ex) {
			logger.error("error while get user detail by email or mobile", ex);
		}
		return false;
	}

	public boolean checkMobile(String mobileNumber, Long userTypeId) {
		try {
			Long checkMobileExist = usersRepository.countByMobileAndUserTypeMasterIdAndIsActiveTrue(mobileNumber, userTypeId);
			return checkMobileExist > 0 ? true : false;
		} catch (Exception ex) {
			logger.error("error while get user detail by email or mobile", ex);
		}
		return false;
	}

	public boolean checkEmailMobileNumber(String email, String mobileNumber, Long userTypeId) {
		logger.info("entry in checkEmailMobileNumber()");
		Long checkMobile = usersRepository.countByMobileAndUserTypeMasterIdAndIsActiveTrue(mobileNumber, userTypeId);
		boolean checkMobileExist = checkMobile > 0 ? true : false;
		if (checkEmailAddress(email, userTypeId) && checkMobileExist) {
			logger.info("Email and mobile already exist");
			return true;
		} else if (checkMobileExist) {
			logger.info("Mobile exist");
			return true;
		} else if (checkEmailAddress(email, userTypeId) && !checkMobileExist) {
			logger.info("exit form checkEmailMobileNumber() with true");
			return false;
		} else {
			return false;
		}
	}

	public UsersRequest forRegistrationProcess(UsersRequest usersRequest) throws UserException {
		logger.info("entry in forRegistrationProcess()");
		usersRequest.setEmail(usersRequest.getEmail().trim());
		User existingUser = usersRepository.findByEmailAndUserTypeMasterId(usersRequest.getEmail(),
				usersRequest.getUserType());
		if (existingUser == null) {
			existingUser = new User();
			existingUser.setEmail(usersRequest.getEmail());
			existingUser.setCreatedDate(new Date());
		} else {
			existingUser.setModifiedBy(existingUser.getUserId());
			existingUser.setModifiedDate(new Date());
		}
		if (!usersRequest.getMobile().equals(existingUser.getMobile())) {
			existingUser.setMobile(usersRequest.getMobile().replaceAll(" ", ""));
			existingUser.setOtpVerified(false);
		}
		existingUser.setUserTypeMaster(new UserTypeMaster(usersRequest.getUserType()));
		existingUser.setSignUpDate(new Date());
		existingUser.setTermsAccepted(usersRequest.isTermsAccepted());
		existingUser.setUsername(usersRequest.getUserName());
		// Set User basic details
		existingUser.setFirstName(usersRequest.getFirstName());
		existingUser.setLastName(usersRequest.getLastName());
		existingUser.setMiddleName(usersRequest.getMiddleName());

//		try {
//			BeanUtils.copyProperties(usersRepository.save(existingUser), usersRequest);
//			usersRequest.setOtpVerified(existingUser.isOtpVerified());
//			if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getCampaignCode())) {
//				try {
//					CampaignRequest campaignRequest = new CampaignRequest();
//					campaignRequest.setUserId(usersRequest.getId());
//					campaignRequest.setCode(usersRequest.getCampaignCode());
//					campaignRequest.setType(usersRequest.getCampaignType());
//					campaignDetailService.save(campaignRequest);
//				} catch (Exception e) {
//					logger.warn("Error while Saving campaign {}", e);
//				}
//			}
//		} catch (DataIntegrityViolationException e) {
//			throw new UserException("email already exist");
//		}
		usersRequest.setPassword(null);
		logger.info("user signup details saved. {} ", existingUser);

		if (existingUser.getOtpVerified() == false) {
			OTPResponse sendOTP = sendOTP(usersRequest, UsersUtils.OTP_REQUEST_SIGNUP_TYPE, null,116L);
			if (sendOTP == null) {
				usersRequest.setOtpStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			} else {
				usersRequest.setOtpStatus(sendOTP.getStatus());
//				if (sendOTP.getStatus().equals(200)) {
//					usersRequest.setOtpStatus(sendOTP.getStatus());
////                    usersRequest.setOtpVerified(true);
//				} else {
//					usersRequest.setOtpStatus(sendOTP.getStatus());
//				}
			}
			logger.info("OTP status:{}", (sendOTP != null ? sendOTP : null));
		}
		logger.info("exit form forRegistrationProcess()");
		return usersRequest;
	}

	public OTPResponse sendOTP(UsersRequest usersRequest, int otpRequestType, NotificationType notificationType,
			Long notificationMasterId) {
		logger.info("entry in sendOTP()");
		OTPResponse otpResponse = new OTPResponse();
		try {
			OTPRequest request = new OTPRequest();
			request.setMobileNo(usersRequest.getMobile());
			request.setRequestType(otpRequestType);
			request.setMasterId(usersRequest.getUserId());
			request.setEmailId(usersRequest.getEmail());
			request.setNotificationMasterId(notificationMasterId);
			request.setSource(!OPLUtils.isObjectNullOrEmpty(usersRequest.getUserRoleId()) && usersRequest.getUserRoleId().equals(UserRoleMaster.BORROWER.getId()) ? 4 : 2);
			if (notificationType.equals(NotificationType.SMS)) {
				otpResponse = otpClient.sendOTP(request);
			} else if (notificationType.equals(NotificationType.EMAIL)) {
				otpResponse = otpClient.sendEmailOTP(request);
			}
			logger.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			return otpResponse;

		} catch (OTPException e) {
			logger.error("Error while OTP send ", e);
		}
		logger.info("exit form sendOTP()");
		return null;
	}

	public boolean resendOTP(UsersRequest usersRequest) {
		logger.info("entry in resendOTP()");
		Optional<User> findById = usersRepository.findById(usersRequest.getId());
		if(findById.isEmpty()) {
			logger.info("exit form resendOTP()");
			return false;
		}
		User existingUser = findById.get();
		if (!existingUser.getOtpVerified()) {
			BeanUtils.copyProperties(existingUser, usersRequest);
			OTPResponse isOtpSent = sendOTP(usersRequest, UsersUtils.OTP_REQUEST_SIGNUP_TYPE, NotificationType.SMS,
					116L);
			logger.info("OTP sent..{}", isOtpSent);
			logger.info("exit form resendOTP()");
			return isOtpSent != null && !isOtpSent.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		logger.info("exit form resendOTP()");
		return false;
	}

	public ResponseEntity<UserResponse> sendOtpOnEmailMobileUpdate(UsersRequest usersRequest) {
		logger.info("entry in sendOtpOnEmailMobileUpdate()");
		Optional<User> findById = usersRepository.findById(usersRequest.getId());
		if(findById.isEmpty()) {
			return new ResponseEntity<>(
					new UserResponse("Unable to send OTP as invalid user details.", HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		User existingUser = findById.get();
		OTPResponse isOtpSent = new OTPResponse();
		if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())) {
			if (checkMobile(usersRequest.getMobile(), existingUser.getUserTypeMaster().getId())) {
				logger.info("mobile number already exists with other user");
				logger.info("exit form sendOtpOnEmailMobileUpdate()");
				return new ResponseEntity<>(new UserResponse("Mobile number already exists with other user.",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			BeanUtils.copyProperties(existingUser, usersRequest, "mobile");
			isOtpSent = sendOTP(usersRequest, UsersUtils.OTP_REQUEST_UPDATE_MOBILE_TYPE, NotificationType.SMS,
					116L);

		} else if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())) {
			if (checkEmailAddressAfterRegister(usersRequest.getEmail(), existingUser.getUserTypeMaster().getId(),
					usersRequest.getId())) {
				logger.info("Email address is already exists with other user");
				logger.info("exit form sendOtpOnEmailMobileUpdate()");
				return new ResponseEntity<>(new UserResponse("Email address is already exists with other user.",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			BeanUtils.copyProperties(existingUser, usersRequest, "email");
			isOtpSent = sendOTP(usersRequest, UsersUtils.OTP_REQUEST_EMAIL_TYPE, NotificationType.EMAIL, 749L);
		}
		logger.info("OTP sent..{}", isOtpSent);
		logger.info("exit form sendOtpOnEmailMobileUpdate()");
		if (isOtpSent != null && !isOtpSent.getStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR.value())) {
			return new ResponseEntity<>(new UserResponse("OTP Successfully sent.", HttpStatus.OK.value()),
					HttpStatus.OK);
		}
		return new ResponseEntity<>(
				new UserResponse("Unable to send OTP as invalid user details.", HttpStatus.BAD_REQUEST.value()),
				HttpStatus.OK);
	}

//	public void saveCampaign(Long userId, String code, String type) throws UserException {
//		try {
//			// Inactivating by UserId
////			campaignDetailService.inActiveCampaign(userId);
//			// Saving new Campaign
////			CampaignRequest campaignRequest = new CampaignRequest();
////			campaignRequest.setUserId(userId);
////			campaignRequest.setCode(code);
////			campaignRequest.setType(type);
////			campaignDetailService.save(campaignRequest);
//		} catch (Exception e) {
//			logger.error("Error while Saving Campaign {}", e);
//			throw new UserException("Error while Saving Campaign");
//		}
//	}

	public String generateEncryptString(Date signUp, String email, Long userTypeId) {
		logger.info("generateEncryptString=================>{}", signUp);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
		Date parsedDate;
		String signUpDate = null;
		try {
			parsedDate = sdf.parse(signUp.toString());
			SimpleDateFormat print = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			signUpDate = print.format(parsedDate);
		} catch (ParseException e1) {
			logger.error("Error while parsing date :: ", e1);
		}
		String stringToEncrypt = email + "$" + signUpDate + "$" + UsersUtils.EMAIL_VERIFICATION_URL + "$" + userTypeId;
		String finalString = "";
		try {
			finalString = AESEncryptionUtilitySBI.encrypt(stringToEncrypt, true);
		} catch (Exception e) {
			logger.error("Error while encrypt url for email verification == ", e);
		}
		return finalString;
	}

	public UsersRequest validateOtp(Long id, String otpValue, String fsLoanParam, boolean fi,
			Integer otpVerificationType) {
		Optional<User> findById = usersRepository.findById(id);
		UsersRequest response = new UsersRequest();
		if (findById.isPresent()) {
			User user = findById.get();
			response.setId(user.getUserId());
			response.setEmail(user.getEmail());
			response.setEmailVerified(user.getEmailVerified());
			response.setMobile(user.getMobile());
			response.setOtpOn(otpVerificationType);
			response.setSignUpDate(user.getSignUpDate());
			response.setOtp(otpValue);
			response.setUserType(user.getUserTypeMaster().getId());
			OTPResponse otpResponse = loginService.validateOTP(response, UsersUtils.OTP_REQUEST_SIGNUP_TYPE);
			if (otpResponse.getStatus() == HttpStatus.OK.value()) {
				if (!OPLUtils.isObjectNullOrEmpty(otpVerificationType)
						&& otpVerificationType == UsersUtils.OTP_REQUEST_EMAIL_TYPE) {
					user.setEmailVerified(true);
				} else {
					user.setOtpVerified(true);
				}
				user.setModifiedDate(new Date());
				user.setModifiedBy(user.getUserId());
				usersRepository.save(user);

				// check UserType if FS
				String name = user.getFirstName() + " " + user.getLastName();
				if (!user.getUserTypeMaster().getId().equals(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId())
						&& !user.getEmailVerified()) {
					String stringToEncrypt = user.getEmail() + "$" + user.getSignUpDate() + "$"
							+ UsersUtils.EMAIL_VERIFICATION_URL + "$" + user.getUserTypeMaster().getId();
				sendVerificationEmail(user, null,
							emailParameters(user.getEmail(), name, stringToEncrypt, fsLoanParam, fi, false, null), 43L);
					logger.info("verification email status");
				}

				if (!OPLUtils.isObjectNullOrEmpty(otpVerificationType)
						&& otpVerificationType == UsersUtils.OTP_REQUEST_EMAIL_TYPE) {
					response.setEmailVerified(true);
				} else {
					response.setOtpVerified(true);
					Map<String, Object> emailParameters = new HashMap<>();

					emailParameters.put("fs_email", (!OPLUtils.isObjectNullOrEmpty(name)) ? name : user.getEmail());
					if (user.getUserTypeMaster().getId()
							.equals(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId())) {
						sendVerificationEmail(user, null, emailParameters,
								10L);
					}
				}
				logger.info("exit form validateOtp()");
				return response;
			} else if (otpResponse.getStatus() == HttpStatus.CONFLICT.value()) {
				logger.info("Invalid OTP. & exit form validateOtp()");
				if (!OPLUtils.isObjectNullOrEmpty(otpVerificationType)
						&& otpVerificationType == UsersUtils.OTP_REQUEST_EMAIL_TYPE) {
					response.setEmailVerified(false);
				} else {
					response.setOtpVerified(false);
				}
				return response;
			} else {
				logger.info("Invalid OTP. & exit form validateOtp()");
				if (!OPLUtils.isObjectNullOrEmpty(otpVerificationType)
						&& otpVerificationType == UsersUtils.OTP_REQUEST_EMAIL_TYPE) {
					response.setEmailVerified(false);
				} else {
					response.setEmailVerified(false);
					response.setOtpVerified(false);
				}
				return response;
			}
		}
		if (!OPLUtils.isObjectNullOrEmpty(otpVerificationType)
				&& otpVerificationType == UsersUtils.OTP_REQUEST_EMAIL_TYPE) {
			response.setEmailVerified(false);
		} else {
			response.setOtpVerified(false);
		}
		return response;
	}

	public Map<String, Object> emailParameters(String email, String name, String stringToEncrypt, String fsLoanParam,
			boolean fi, boolean fsVerificationLink, String originDomain) {
		logger.info("entry in emailParameters()");
		String encryptedUrl = "";
		String fsLoanDetails = "";
		try {
			encryptedUrl = AESEncryptionUtilitySBI.encrypt(stringToEncrypt, true);
			if (fsLoanParam != null) {
				fsLoanDetails = "&lp=" + fsLoanParam;
			}
			if (fi) {
				fsLoanDetails = "&fi=" + fi;
			}
		} catch (Exception e1) {
			logger.error("Error while encrypt ", e1);
		}
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("user_name", name);
		emailParameters.put("email_address", email);
		if (fsVerificationLink) {
			emailParameters.put("link", originDomain + environment.getRequiredProperty(EMAIL_VERIFICATION_FS_URL_KEY)
					+ "?id=" + encryptedUrl + fsLoanDetails);
		} else {
			emailParameters.put("link", originDomain + environment.getRequiredProperty(EMAIL_VERIFICATION_URL_KEY)
					+ "?id=" + encryptedUrl + fsLoanDetails);
		}

		logger.info("exit form emailParameters()");
		return emailParameters;
	}

	public void sendVerificationEmail(User user, Object emailSubject,
			Map<String, Object> emailParameters, Long masterId) {
		logger.info("entry in sendVerificationEmail()");
		String[] to = { user.getEmail() };
		NotificationRequest notificationRequest = new NotificationRequest();

		notificationRequest.setClientRefId(user.getUserId().toString());
		Notification notification = new Notification();
		notification.setMasterId(masterId);
		notification.setContentType(ContentType.TEMPLATE);
		notification.setSubject(emailSubject);
		notification.setTo(to);
		notification.setType(NotificationType.EMAIL);
		notification.setParameters(emailParameters);

		notificationRequest.addNotification(notification);
		 notificationClient.send(notificationRequest);		
	}

	public UsersRequest savePasswordChangeLog(UsersRequest usersRequest) {

		logger.info("enter in savePasswordChangeLog()");
		User user = usersRepository.findByEmailAndUserTypeMasterId(usersRequest.getEmail(), usersRequest.getUserType());
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			// Change log
			UserPasswordChangeLog passwordLog = new UserPasswordChangeLog();
			passwordLog.setUserId(user);
			passwordLog.setPassword(user.getPassword());
			passwordLog.setCreatedOn(new Date());
			passwordChangeLogRepository.save(passwordLog);
			
			user.setPasswordResetDate(new Date());
			usersRepository.save(user);
//			userNotificationUtils.sendNotificationOnSignUp(usersRequest.getEmail(), usersRequest.getMobile(),
//					usersRequest.getUserId());
			return usersRequest;

		} else {
			logger.info("exit form savePasswordChangeLog()");
			return null;
		}
	}

	public Boolean isSamePassword(UsersRequest usersRequest) {

		User user = usersRepository.findByMobileAndUserTypeMasterId(usersRequest.getMobile(),
				usersRequest.getUserType());
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			String password = usersRequest.getPassword();
			String encryptedPassword = DigestUtils.md5DigestAsHex(password.getBytes());
			String currentPassword = user.getPassword();
			String password1 = user.getPassword1();
			String password2 = user.getPassword2();
			if ((null != currentPassword && currentPassword.equals(encryptedPassword))
					|| (null != password1 && password1.equals(encryptedPassword))
					|| (null != password2 && password2.equals(encryptedPassword))) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		} else {
			logger.info("User not found.");
			return Boolean.FALSE;
		}
	}
	
	public Boolean isSamePasswordForBorrower(UsersRequest usersRequest) {

		User user = usersRepository.findByUserId(usersRequest.getUserId());
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			String password = usersRequest.getPassword();
			String encryptedPassword = DigestUtils.md5DigestAsHex(password.getBytes());
			String currentPassword = user.getPassword();
			String password1 = user.getPassword1();
			String password2 = user.getPassword2();
			if ((null != currentPassword && currentPassword.equals(encryptedPassword))
					|| (null != password1 && password1.equals(encryptedPassword))
					|| (null != password2 && password2.equals(encryptedPassword))) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		} else {
			logger.info("User not found.");
			return Boolean.FALSE;
		}
	}

//	public boolean setLastCampaignCode(UsersRequest usersRequest) {
//		User user = usersRepository.getOne(usersRequest.getUserId());
//		if (!OPLUtils.isObjectNullOrEmpty(user)) {
////			user.setCampaignCode(usersRequest.getCampaignCode());
//			usersRepository.save(user);
//			return true;
//		}
//		return false;
//	}

	public boolean inactiveUserSessionByUserId(Long userId) {
		try {
			usersRepository.inactiveUserSessionByUserId(userId);
			return true;
		} catch (Exception e) {
			logger.error("Exception while Inactive User Session By UserId ------> " + userId, e);
		}
		return false;
	}

	public UsersRequest saveLastThreePassword(UsersRequest usersRequest) {
		User user = usersRepository.findByEmailAndUserTypeMasterId(usersRequest.getEmail(), usersRequest.getUserType());
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getOldPassword()) && (!DigestUtils
					.md5DigestAsHex(usersRequest.getOldPassword().getBytes()).equals(user.getPassword()))) {

				logger.info("Old Password does not match.");
				return null;

			}
			String password = user.getPassword();
			String password1 = user.getPassword1();
			user.setPassword2(password1);
			user.setPassword1(password);
			String encryptedNewPassword = DigestUtils.md5DigestAsHex(usersRequest.getPassword().getBytes());
			user.setPassword(encryptedNewPassword);
			user.setModifiedBy(user.getUserId());
			user.setModifiedDate(new Date());
			user.setIsActive(true);
			user.setPassChanged(true);
			BeanUtils.copyProperties(usersRepository.save(user), usersRequest);
			usersRequest.setUserType(user.getUserTypeMaster().getId());
			usersRequest.setUserId(user.getUserId());
			return usersRequest;
		} else {
			logger.info("User not found/Old Password does not match.");
			return null;
		}
	}

	public Boolean userIsLocked(UsersRequest userRequest) {

		Boolean isLocked = Boolean.FALSE;
		if (!OPLUtils.isObjectNullOrEmpty(userRequest.getEmail())) {
			Long emailAddressLock = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrue(userRequest.getEmail(), userRequest.getUserType());
			isLocked = emailAddressLock > 0 ? true : false;
		} else if (!OPLUtils.isObjectNullOrEmpty(userRequest.getMobile())) {
			Long checkMobileNumberLock = usersRepository.countByMobileAndUserTypeMasterIdAndIsActiveTrue(userRequest.getMobile(), userRequest.getUserType());
			isLocked = checkMobileNumberLock > 0 ? true : false;
		}
		return isLocked;
	}

	/**
	 * FETCH ALL USER TYPE MASTER LIST BASED ON IS_ACTIVE OR IS_DISPLAY_ON_LOGIN OR
	 * ALL
	 */
	@Override
	public List<UserTypeRequest> getUserTypeMasterList(UserTypeRequest request) {

		List<UserTypeMaster> domainList = null;
		if (request.getIsActive() != null && request.getIsDisplayOnLogin() != null) { // FETCH LIST BY ISACTIVE AND
																						// ISDISPLAYLOGIN FIELD
			domainList = userTypeMasterRepo.findByIsActiveAndIsDisplayOnLogin(request.getIsActive(),
					request.getIsDisplayOnLogin());
		} else if (request.getIsActive() != null) { // FETCH LIST BY ISACTIVE FIELD
			domainList = userTypeMasterRepo.findByIsActive(request.getIsActive());
		} else if (request.getIsDisplayOnLogin() != null) { // FETCH LIST BY ISDISPLAYLOGIN FIELD
			domainList = userTypeMasterRepo.findByIsDisplayOnLogin(request.getIsDisplayOnLogin());
		} else { // FETCH ALL LIST
			domainList = userTypeMasterRepo.findAll();
		}

		if (domainList == null || domainList.size() == 0) {
			return Collections.emptyList();
		}
		List<UserTypeRequest> resList = new ArrayList<>(domainList.size());
		UserTypeRequest res = null;
		for (UserTypeMaster domain : domainList) {
			res = new UserTypeRequest();
			BeanUtils.copyProperties(domain, res);
			resList.add(res);
		}
		return resList;
	}

//	@Cacheable(value = "getAllValidations")
//	public String getAllValidations(Long businessType) throws Exception {
//		List<Map<String, Object>> list = usersRepository.getAllValidationsOpt(businessType);
//		List<ValidationProxy> validationProxies = MultipleJSONObjectHelper.getListOfObjects(MultipleJSONObjectHelper.getStringfromListOfObject(list), null, ValidationProxy.class);
//
//		List<ValidationModuleMstr> moduleMstrs = new ArrayList<>();
//		Map<Long, List<ValidationProxy>> groupedModules = validationProxies.stream().collect(Collectors.groupingBy(ValidationProxy::getModuleId));
//		groupedModules.forEach((moduleId, groupedModuleList) -> {
//			ValidationModuleMstr mstr = new ValidationModuleMstr();
//			mstr.setModule(groupedModuleList.get(0).getModuleName());
//			Map<Long, List<ValidationProxy>> groupedFields = groupedModuleList.stream().collect(Collectors.groupingBy(ValidationProxy::getFieldId));
//			List<ValidationFieldMstr> fldMstrs = new ArrayList<>();
//
//			groupedFields.forEach((fieldId, fldList) -> {
//				ValidationFieldMstr fieldMstr = new ValidationFieldMstr();
//				fieldMstr.setLabel(fldList.get(0).getFieldName());
//				fieldMstr.setModuleid(moduleId);
//				List<ValidationsMstr> validationsMstrs = new ArrayList<>();
//				fldList.forEach(fld -> {
//					ValidationsMstr validMstr = new ValidationsMstr();
//					validMstr.setKey(fld.getValue());
//					validMstr.setValue(fld.getValidationValue());
//					validMstr.setErrorMassage(fld.getErrorMessage());
//					validationsMstrs.add(validMstr);
//				});
//				fieldMstr.setValidations(validationsMstrs);
//				fldMstrs.add(fieldMstr);
//
//			});
//			mstr.setFieldList(fldMstrs);
//			moduleMstrs.add(mstr);
//		});
//		return MultipleJSONObjectHelper.getStringfromListOfObject(moduleMstrs);
//	}

//	public String getMenuForBanker(Integer schemeId, Long userId) {
//		Long roleId = usersRepository.getOne(userId).getUserRoleId().getRoleId();
//		return usersRepository.getMenuForBanker(schemeId, roleId);
//	}

	public String getAllMenuForBanker(Long userId) {
//		return usersRepository.getAllMenuForBanker(userId);
		return commonRepository.getMenuListByUserId(userId);
	}

	@Override
	public List<String> getUserPermissions(UsersRequest usersRequest) {
		try {

			if (usersRequest.getSchemeId() != 0l) {
				if (!schemeMasterRepository.existsByIdAndIsActiveTrue(usersRequest.getSchemeId())) {
					Long userRoleId = Long.parseLong(usersRequest.getUserRoleIdString());
//					Integer loanTypeId = Integer.parseInt((usersRequest.getLoanTypeIdString()));
					return usersRepository.getUserPermissionsForInactiveScheme(userRoleId, usersRequest.getSchemeId(),
							usersRequest.getUserOrgId());
				}
			}

			Long userRoleId = Long.parseLong(usersRequest.getUserRoleIdString());
//			Integer loanTypeId = Integer.parseInt((usersRequest.getLoanTypeIdString()));
			return usersRepository.getUserPermissions(userRoleId, usersRequest.getSchemeId(),
					usersRequest.getUserOrgId());
		} catch (Exception e) {
			logger.error("Error while get user permissions []", e);
			return Collections.emptyList();
		}
	}

	@Override
	public UserResponse sendEmailForForgotPassword(String email, String originDomain, Long userTypeId,Long notiMasterId) {

		User user = null;
		if (userTypeId != null) {
			user = usersRepository.findByEmailAndUserTypeMasterId(email, userTypeId);
		} else {
			// USER TYPE IS MANDATORY TO FOUND USER OBJECT OTHERWISE DUBLICATE ERROR CAN BE
			// FOUND
//			user = usersRepository.findOneByEmail(email);
		}
		if (user == null) {
			logger.info("Invalid Email Address Found, Kindly enter valid email address -----> " + email);
			return new UserResponse("Invalid Request,  Email Address is not valid", HttpStatus.BAD_REQUEST.value(),
					Boolean.FALSE);
		}

		if (!user.getIsActive()) {
			logger.info("Email address is not active currently -----> " + email);
			return new UserResponse(
					"Password reset instructions have been e-mailed to you. Please check in your registered e-mail",
					HttpStatus.OK.value(), Boolean.TRUE);
		}

		// LAST MODIFIED BY HARSHIT FOR 5 TIME FORGOT PASSWORD ONLY ON SINGLE DAY
//		ForgotPassAudit forgotPassAudit = new ForgotPassAudit();
		Boolean status = Boolean.FALSE;
		String msg = "";

		try {

//			forgotPassAudit.setUserId(user.getUserId());
//			forgotPassAudit.setCreatedDate(new Date());

			// CHECK LIMITED TIME TO ATTEMPT FORGOT PASSWORD
//			Integer dayCount = 5;
//			if (oneDayCount != null) {
//				dayCount = Integer.parseInt(oneDayCount);
//			}
//			Long countForOneDay = forgotPassAuditRepo.countForOneDayAudit(user.getUserId());
//			if (countForOneDay > dayCount) {
//				msg = "Reached Maximum Attempt : " + countForOneDay;
//				return new UserResponse("You have reached maximum attempt to forgot password on single day, Please try again tomorrow!!", HttpStatus.OK.value(), Boolean.FALSE);
//			}

//			String stringToEncrypt = user.getEmail() + "$" + user.getSignUpDate() + "$" + UsersUtils.CHANGE_PASSWORD_URL
//					+ "$" + user.getUserTypeMaster().getId();
//			status = sendVerificationEmail(user, null, null, emailParameters(user.getEmail(), user.getEmail(),
//					stringToEncrypt, null, false, false, originDomain), 44L);
//			if (status) {
//			msg = "Successfully Sent Mail!!";
//			return new UserResponse(
//					"Password reset instructions have been e-mailed to you. Please check in your registered e-mail",
//					HttpStatus.OK.value(), Boolean.TRUE);
//		} else {
//			msg = "Error while sent call Notification client";
//			return new UserResponse("The application has encountered some error, please try after some times!!",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}

			logger.info("exit form sendEmailForForgotPassword()");
//			user.setEmail(user.getEmail());
//			usersRepository.save(user);
			OTPRequest request = new OTPRequest();
			request.setMobileNo(user.getMobile());
			request.setRequestType(2);
			request.setMasterId(user.getUserId());
			request.setEmailId(user.getEmail());
			request.setName(user.getUsername());
			request.setNotificationMasterId(notiMasterId);
			OTPResponse otpResponse = otpClient.sendEmailOTP(request);
			logger.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			if (otpResponse != null && otpResponse.getStatus() == 200) {
				return new UserResponse("Password reset instructions have been e-mailed to you. Please check in your registered e-mail",HttpStatus.OK.value(),
						Boolean.TRUE,request);
			}else {
				return new UserResponse("The application has encountered some error, please try after some times!!",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}
			
		} catch (Exception e) {
			logger.error("Exception while Forgot Password ===============>", e);
			msg = e.getMessage();
			return new UserResponse("The application has encountered some error, please try after some times!!",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		} finally {
			logger.info(msg);
//			forgotPassAudit.setIsSuccess(status);
//			forgotPassAudit.setMessage(msg);
//			forgotPassAudit.setModifiedDate(new Date());
//			forgotPassAudit.setEmail(email);
//			forgotPassAuditRepo.save(forgotPassAudit);
		}
	}

	@Override
	public Boolean updateRoleAndBusinessTypeId(Long userRoleId, Integer lastBusinessTypeId, Long userId) {
		return usersRepository.updateRoleIdAndBusinessTypeId(userRoleId, lastBusinessTypeId, userId) > 0;
	}

	@Override
	public UserNotificationDetailsRes getUserNotificationDetails(UserNotificationDetailsReq notiDetailsReq)
			throws Exception {
		UserNotificationDetailsRes detailsRes = new UserNotificationDetailsRes();
		if (notiDetailsReq.getUserId() != null) {
			detailsRes.setUsersDetailsRes(getUserDetailByMobileOrEmail(null, null, notiDetailsReq.getUserId(), null));
		}
		if (notiDetailsReq.getUserOrgId() != null) {
			detailsRes.setOrgDetailsRes(organisationMasterService.getById(notiDetailsReq.getUserOrgId()));
		}
		if (notiDetailsReq.getUserBranchId() != null) {
			BranchBasicDetailsRequest branchDetailsReq = branchMasterService.get(notiDetailsReq.getUserBranchId());
			if (branchDetailsReq != null) {
				String cityName = null;
				String state = null;

				// get city details from OneFormCLient using branch city id
				if (branchDetailsReq.getCityId() != null) {
					LgdDistrictStateResponse cityMasterResponse = oneFormClient
							.getLgdCityByCityId(Long.valueOf(branchDetailsReq.getCityId()));
					if (!OPLUtils.isObjectNullOrEmpty(cityMasterResponse)) {
						cityName = cityMasterResponse.getDistrictName();
					} else {
						logger.info(" City Details Not Found By cityId  ----->");
					}
				} else {
					logger.info(" City Id is null ");
				}

				// get State details from OneFormCLient using branch State id
				if (branchDetailsReq.getStateId() != null) {
					LgdStateResponse stateMasterResponse = oneFormClient
							.getLgdStateByStateId(Long.valueOf(branchDetailsReq.getStateId()));
					if (!OPLUtils.isObjectNullOrEmpty(stateMasterResponse)) {
						state = stateMasterResponse.getStateName();
					} else {
						logger.info(" State Details Not Found By stateID (getInPrincipleDetails) ----->ID:- "
								+ branchDetailsReq.getStateId());
					}
				} else {
					logger.info(" State Id is null (getInPrincipleDetails) ");
				}
				branchDetailsReq.setCityName(cityName);
				branchDetailsReq.setStateName(state);
				detailsRes.setBranchDetailsRes(branchDetailsReq);
			}
		}

		return detailsRes;
	}

	@Override
	public UsersRequest getEmailMobile(Long userId) {
		logger.info("entry in getEmailMobile()");
		Optional<User> findById = usersRepository.findById(userId);
		if (findById.isPresent()) {
			User existingUser = findById.get();
			UsersRequest request = new UsersRequest();
			request.setId(existingUser.getUserId());
			request.setEmail(existingUser.getEmail());
			request.setMobile(existingUser.getMobile());
			logger.info("exit form getEmailMobile()");
			return request;
		}
		logger.info("exit form getEmailMobile()");
		return null;
	}

	@Override
	public List<BankUserDetailRes> getUserDetailsByOrgIdBranchIdRoleId(BankUserDetailReq bankUserDetailReq) {
		logger.info("Enter in getUserDetailsByOrgIdBranchIdRoleId()");
		try {
			List<User> user = null;
			if (bankUserDetailReq.getBranchId() != null) {
				user = usersRepository.getUserListBySchmeIdAndUserRoleIdAndBranchId(bankUserDetailReq.getReqRoleIds(),
						bankUserDetailReq.getSchemeId(), bankUserDetailReq.getOrgId(), bankUserDetailReq.getBranchId());
			} else {
				user = usersRepository.getUserListBySchmeIdAndUserRoleId(bankUserDetailReq.getReqRoleIds(),
						bankUserDetailReq.getSchemeId(), bankUserDetailReq.getOrgId());
			}
			if (user != null) {
				List<BankUserDetailRes> userList = new ArrayList<>();
				for (User users : user) {
					BankUserDetailRes ur = new BankUserDetailRes();
					ur.setUserId(users.getUserId());
					ur.setEmail(users.getEmail());
					ur.setMobile(users.getMobile());
					ur.setSchemeId(bankUserDetailReq.getSchemeId());
					if (users.getUserOrgId() != null) {
						ur.setOrgId(users.getUserOrgId().getUserOrgId());
					}
					ur.setUserRoleId(users.getUserRoleId().getRoleId());
					ur.setName(users.getFirstName() + " "
							+ (!OPLUtils.isObjectNullOrEmpty(users.getMiddleName()) ? users.getMiddleName() + " " : "")
							+ users.getLastName());
					userList.add(ur);
				}
				return userList;
			}
			return Collections.emptyList();
		} catch (Exception e) {
			logger.error("exception while get the user data----------------------->", e);
			return Collections.emptyList();
		}
	}

	@Override
	public Boolean updateEmailMobile(UsersRequest usersRequest) {
		Optional<User> findById = usersRepository.findById(usersRequest.getId());
		if (findById.isPresent()) {
			User userObj = findById.get();
			if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()))
				userObj.setMobile(usersRequest.getMobile());
			else if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())) {
				userObj.setEmail(usersRequest.getEmail());
				userObj.setEmailVerified(Boolean.TRUE);
			}

			userObj.setModifiedDate(new Date());
			userObj.setModifiedBy(usersRequest.getId());
			usersRepository.save(userObj);
			return true;
		}
		return false;
	}

//	@Override
//	public void updateFacilitatorUser(FacilitatorReq facilitatorReq) {
//		FacilitatorsUserMapping mapping = new FacilitatorsUserMapping();
//		mapping.setFacilitatorId(facilitatorReq.getFacilitatorId());
//		mapping.setUserId(facilitatorReq.getUserId());
//		mapping.setApplicationId(facilitatorReq.getApplicationId());
//		facilitatorsUserMappingRepo.save(mapping);
//	}

//	@Override
//	public UsersRequest registerUserByFacilitator(UsersRequest usersRequest) throws Exception {
//		logger.info("entry in regiterUserByFacilitator()");
//		usersRequest.setEmail(usersRequest.getEmail().trim());
//		usersRequest.setMobile(usersRequest.getMobile().trim());
//		User existingUser = usersRepository.findOneByMobile(usersRequest.getMobile());
//		if (existingUser == null) {
//			existingUser = new User();
//			existingUser.setEmail(usersRequest.getEmail());
//			existingUser.setCreatedDate(new Date());
//		} else {
//			existingUser.setModifiedBy(existingUser.getUserId());
//			existingUser.setModifiedDate(new Date());
//		}
//		if (!usersRequest.getMobile().equals(existingUser.getMobile())) {
//			existingUser.setMobile(usersRequest.getMobile().replaceAll(" ", ""));
//			existingUser.setOtpVerified(false);
//		}
//		existingUser.setIsActive(Boolean.TRUE);
//		existingUser.setUserTypeMaster(new UserTypeMaster(usersRequest.getUserType()));
//		existingUser.setSignUpDate(new Date());
//		try {
//			BeanUtils.copyProperties(usersRepository.save(existingUser), usersRequest);
//		} catch (DataIntegrityViolationException e) {
//			throw new UserException("email already exist");
//		}
//
//		logger.info("exit form registerUserByFacilitator()");
//		return usersRequest;
//	}

	@Override
	public boolean isCurrentPasswordWrong(UsersRequest usersRequest) {
		User user = usersRepository.findByEmailAndUserTypeMasterId(usersRequest.getEmail(), usersRequest.getUserType());
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			String password = usersRequest.getOldPassword();
			String encryptedPassword = DigestUtils.md5DigestAsHex(password.getBytes());
			String currentPassword = user.getPassword();

			if (null == currentPassword || !currentPassword.equals(encryptedPassword)) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		} else {
			logger.info("User not found.");
			return Boolean.FALSE;
		}
	}

	@Override
	public List<UsersRequest> getUserDetailsByListOfIds(List<Long> userIds) throws Exception {
		// TODO Auto-generated method stub
		List<User> findAllById = usersRepository.findAllById(userIds);
		List<UsersRequest> responceLst = new ArrayList<UsersRequest>();
		for (User user : findAllById) {

			UsersRequest userRequest = new UsersRequest();
			BeanUtils.copyProperties(user, userRequest);
			userRequest.setFirstName(user.getFirstName() != null ? user.getFirstName() : "");
			userRequest.setLastName(user.getLastName() != null ? user.getLastName() : "");
			userRequest.setOtpVerified(user.getOtpVerified());
			userRequest.setUserRoleId(user.getUserRoleId() != null ? user.getUserRoleId().getRoleId() : null);
			userRequest
					.setUserRoleIdString(user.getUserRoleId() != null ? user.getUserRoleId().getDisplayName() : null);
			userRequest.setIsPasswordSet(!OPLUtils.isObjectNullOrEmpty(user.getPassword()));
			userRequest.setEmailVerified(user.getEmailVerified());
			userRequest.setPassword(null);
			if (!OPLUtils.isObjectNullOrEmpty(user.getUserOrgId())) {
				userRequest.setUserOrgName(user.getUserOrgId().getDisplayOrgName());
			}
			if (user.getCampaignMaster() != null) {
				userRequest.setCampaignMasterId(user.getCampaignMaster().getId());
			}
			responceLst.add(userRequest);

		}
		return responceLst;
	}

//	@Override
//	public void updateLangAudit(LangAuditRequest languageAudit) {
//		logger.info("Enter updateLangAudit() ===> ");
//		LanguageAudit langAudit = new LanguageAudit();
//		langAudit.setApplicationId(!OPLUtils.isObjectNullOrEmpty(languageAudit.getApplicationId()) ? languageAudit.getApplicationId() : null);
//		langAudit.setLanguage( languageAudit.getLanguage());
//		langAudit.setCreatedDate(new Date());
//		langAudit.setUserId(languageAudit.getUserId());
//		langAudit.setApplicationCode(!OPLUtils.isObjectNullOrEmpty(languageAudit.getApplicationCode()) ? languageAudit.getApplicationCode() : null);
//		langAudit.setSchemeId(!OPLUtils.isObjectNullOrEmpty(languageAudit.getSchemeId()) ? languageAudit.getSchemeId() : null);
//		langAudit.setIsActive(Boolean.TRUE);
//		langAuditRepo.save(langAudit);
//	}

	@Override
	public List<Map<String, Object>> getAccessPaths(AuthClientResponse authClientResponse) {
		try {
			List<PathAccessRoleMapping> accessRoleMappings = pathAccessRoleMappingRepository
					.findByRoleIdAndTypeIdAndIsActiveTrue(authClientResponse.getUserRoleId(),
							authClientResponse.getUserType());
			if (!OPLUtils.isListNullOrEmpty(accessRoleMappings)) {
				List<Map<String, Object>> mapList = new ArrayList<>(accessRoleMappings.size());
				accessRoleMappings.forEach(x -> {
					Map<String, Object> map = new HashMap<>();
					map.put("schemeId", x.getSchemeId());
					map.put("path", x.getPathAccessId().getPath());
					mapList.add(map);
				});
				return mapList;
			}
		} catch (Exception e) {
			logger.error("error while get user access path", e);
		}
		return Collections.emptyList();
	}

	@Override
	public Long getFirstUserIdByOrgIdAndHoRoleID(Long orgId, Long roleId) {
		User user = usersRepository.findFirstByUserOrgIdUserOrgIdAndUserRoleIdRoleIdAndIsActiveTrue(orgId, roleId);
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			return user.getUserId();
		}
		return null;
	}
	
	 public UserResponse updatePasswordWithEmail(UsersRequest usersRequest) {
		 try {
			 User user = usersRepository.findByUserId(usersRequest.getUserId());
			 if(!OPLUtils.isObjectNullOrEmpty(user)) {
				 user.setEmail(usersRequest.getEmail());
				 String encryptedPassword = DigestUtils.md5DigestAsHex(usersRequest.getPassword().getBytes());
				 user.setPassword(encryptedPassword);
				 user.setPassChanged(true);
				 usersRepository.save(user);
				 return new UserResponse(usersRequest, "Password Update Successfully!!", HttpStatus.OK.value());
			 }
		} catch (Exception e) {
			logger.error("Exception while updatePasswordWithEmail", e);
		}
		return null; 
	 }

		@Override
		public UserResponse updateMobileByUserId(UsersRequest usersRequest) {
			try {
				Long checkMobileExist = usersRepository.countByMobileAndUserTypeMasterIdAndIsActiveTrue(usersRequest.getMobile(),usersRequest.getUserType());
				if (checkMobileExist > 0) {
					return new UserResponse(Boolean.FALSE, "Mobile no already exists.",
							HttpStatus.NOT_MODIFIED.value());
				}

				Integer updateMobile = usersRepository.updateMobileByUserId(usersRequest.getUserId(),
						usersRequest.getMobile());
				if (updateMobile > 0) {
					return new UserResponse(Boolean.TRUE, "Successfully Mobile Updated", HttpStatus.OK.value());
				} else {
					return new UserResponse(Boolean.FALSE, "Mobile Not updated", HttpStatus.NOT_MODIFIED.value());
				}
			} catch (Exception e) {
				return new UserResponse(Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}
	
	@Override
	public UserResponse sendMobileForForgotPassword(UsersRequest usersRequest) {
		User user = null;
		if (usersRequest.getUserType() != null) {
			if (usersRequest.getType().equals(1)) {
				user = usersRepository.findByMobileAndUserTypeMasterId(usersRequest.getMobile(),
						usersRequest.getUserType());
				if (user == null) {
					logger.info("MobileNumber NOT Found-----> " + usersRequest.getMobile());
					return new UserResponse("MobileNumber NOT Found", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			} else {
				user = usersRepository.findOneByUsernameAndUserTypeMasterId(usersRequest.getUserName(),
						usersRequest.getUserType());
				if (user == null) {
					logger.info("UserName NOT Found-----> " + usersRequest.getUserName());
					return new UserResponse("UserName NOT Found", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
				if (OPLUtils.isObjectNullOrEmpty(user.getMobile())) {
					logger.info("Mobile Number Not Found-----> " + usersRequest.getMobile());
					return new UserResponse("Mobile Number Not Found", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			}
		}
	
		if (!user.getIsActive()) {
			logger.info("MobileNumber is not active currently -----> " + usersRequest.getMobile());
			return new UserResponse(
					"Password reset instructions have been Mobile to you. Please check in your registered Mobile",
					HttpStatus.OK.value(), Boolean.TRUE);
		}

		// LAST MODIFIED BY HARSHIT FOR 5 TIME FORGOT PASSWORD ONLY ON SINGLE DAY
//		ForgotPassAudit forgotPassAudit = new ForgotPassAudit();
		Boolean status = Boolean.FALSE;
		String msg = "";
		try {
//			forgotPassAudit.setUserId(user.getUserId());
//			forgotPassAudit.setCreatedDate(new Date());

			// CHECK LIMITED TIME TO ATTEMPT FORGOT PASSWORD
//			Integer dayCount = 5;
//			if (oneDayCount != null) {
//				dayCount = Integer.parseInt(oneDayCount);
//			}
//			Long countForOneDay = forgotPassAuditRepo.countForOneDayAudit(user.getUserId());
//			if (countForOneDay > dayCount) {
//				msg = "Reached Maximum Attempt : " + countForOneDay;
//				return new UserResponse("You have reached maximum attempt to forgot password on single day, Please try again tomorrow!!", HttpStatus.OK.value(), Boolean.FALSE);
//			}

//			String stringToEncrypt = user.getEmail() + "$" + user.getSignUpDate() + "$" + UsersUtils.CHANGE_PASSWORD_URL
//					+ "$" + user.getUserTypeMaster().getId();
//			status = sendVerificationEmail(user, null, null, emailParameters(user.getEmail(), user.getEmail(),
//					stringToEncrypt, null, false, false, originDomain), 44L);
//			if (status) {
//			msg = "Successfully Sent Mail!!";
//			return new UserResponse(
//					"Password reset instructions have been e-mailed to you. Please check in your registered e-mail",
//					HttpStatus.OK.value(), Boolean.TRUE);
//		} else {
//			msg = "Error while sent call Notification client";
//			return new UserResponse("The application has encountered some error, please try after some times!!",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
			logger.info("exit form sendEmailForForgotPassword()");
//			user.setEmail(user.getEmail());
//			usersRepository.save(user);
			OTPRequest request = new OTPRequest();
			request.setMobileNo(user.getMobile());
			request.setRequestType(usersRequest.getOtpType());
			request.setMasterId(user.getUserId());
			request.setEmailId(user.getEmail());
			request.setName(user.getUsername());
			request.setNotificationMasterId(usersRequest.getNotificationMasterId());
			OTPResponse otpResponse = otpClient.sendOTP(request);
			logger.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			if (otpResponse != null && otpResponse.getStatus() == 200) {
				return new UserResponse(
						"Password reset instructions have been e-mailed to you. Please check in your registered e-mail",
						HttpStatus.OK.value(), Boolean.TRUE, request);
			} else {
				return new UserResponse("The application has encountered some error, please try after some times!!",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}

		} catch (Exception e) {
			logger.error("Exception while Forgot Password ===============>", e);
			msg = e.getMessage();
			return new UserResponse("The application has encountered some error, please try after some times!!",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		} finally {
			logger.info(msg);
//			forgotPassAudit.setIsSuccess(status);
//			forgotPassAudit.setMessage(msg);
//			forgotPassAudit.setModifiedDate(new Date());
//			forgotPassAudit.setEmail(email);
//			forgotPassAuditRepo.save(forgotPassAudit);
		}
	}
	
	@Override
	public UserResponse forgotUserName(UsersRequest usersRequest) {
		try {
			User user = null;
			if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())
					&& !OPLUtils.isObjectNullOrEmpty(usersRequest.getUserType())) {
				user = usersRepository.findByMobileAndUserTypeMasterId(usersRequest.getMobile(),
						usersRequest.getUserType());
				if (OPLUtils.isObjectNullOrEmpty(user.getUsername())) {
					logger.info("UserName NOT Found-----> " + usersRequest.getMobile());
					return new UserResponse("UserName NOT Found", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			}
			/* SEND UserName TO YourMOBILE */
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("userName", user.getUsername());
			String[] toSms = { "91" + user.getMobile() };
			Notification smsReq = NotificationClient.prepareRequestForSmsOrEmail(toSms, parameters,
					usersRequest.getNotificationMasterId(), null, NotificationType.SMS);
			NotificationRequest notificationRequest = new NotificationRequest();
			notificationRequest.addNotification(smsReq);
			notificationClient.send(notificationRequest);
			logger.info("OTP For UserId==>{}", usersRequest.getNotificationMasterId());
//			if (isSent) {
				logger.info("Success to send notification :: " + notificationRequest.getClientRefId());
				return new UserResponse("UserName Send Successfully", HttpStatus.OK.value(), Boolean.TRUE, user.getUsername());
//			} else {
//				logger.info("Failed to send notification :: " + notificationRequest.getClientRefId());
//				return new UserResponse("UserName Not Send Successfully", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE,
//						user.getUsername());
//			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Exception while Forgot UserName  ===============>", e);
			return new UserResponse("The application has encountered some error, please try after some times!!",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public UserResponse updateEmailByUserId(UsersRequest usersRequest) {
		try {
			Long checkEmail = usersRepository.countByEmailAndUserTypeMasterIdAndIsActiveTrue(usersRequest.getEmail(),usersRequest.getUserType());
			if (checkEmail > 0) {
				return new UserResponse(Boolean.FALSE, "email already exists.", HttpStatus.NOT_MODIFIED.value());
			}

			Integer updateEmail = usersRepository.updateEmailByUserId(usersRequest.getUserId(),
					usersRequest.getEmail());
			if (updateEmail > 0) {
				return new UserResponse(Boolean.TRUE, "Successfully Email Updated", HttpStatus.OK.value());
			} else {
				return new UserResponse(Boolean.FALSE, "Email Not updated", HttpStatus.NOT_MODIFIED.value());
			}
		} catch (Exception e) {
			return new UserResponse(Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
}

