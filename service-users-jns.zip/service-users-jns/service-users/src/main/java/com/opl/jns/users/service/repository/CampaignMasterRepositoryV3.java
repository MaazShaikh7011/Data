package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.users.service.domain.CampaignMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface CampaignMasterRepositoryV3 extends JpaRepository<CampaignMaster, Long>{

	public CampaignMaster findByCampaignUrlAndIsActive(String campaignUrl, Boolean isActive);

	public CampaignMaster findByOrganisationMasterUserOrgIdAndIsActive(Long orgId, Boolean isActive);

	public CampaignMaster findByIdAndIsActive(Long id, boolean isActive);

	@Query(value = "Select id from CampaignMaster where organisationMaster.userOrgId = :orgId and isActive = true")
	public Long getIdByOrgId(@Param("orgId") Long orgId);

}
