package com.opl.jns.users.service.service;

import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.SignUpRequest;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.utils.common.CommonResponse;

public interface SignUpServiceV3 {

	public CommonResponse signup(SignUpRequest signUpReq) throws UserException;
	
	public boolean sendMobileOTP(SignUpRequest usersRequest);
	
	public CommonResponse sendEmailOTP(SignUpRequest usersRequest);
	
	public CommonResponse verifyOTP(SignUpRequest usersRequest);
	
	public CommonResponse skipForEmailVerification(UsersRequest usersRequest);
	
	public CommonResponse setPassword(UsersRequest usersRequest);
	
	public AuthResponse callAuthClient(UsersRequest usersRequest);

//	public CommonResponse getFacilitatorTokens(FacilitatorTokenReq facilitatorTokenReq);

//    CommonResponse preScreenSignUp(UsersRequest usersRequest);

	CommonResponse sendMobileEmailOTP(SignUpRequest usersRequest);

	public CommonResponse diySignup(SignUpRequest signUpReq);

	public CommonResponse checkMobile(SignUpRequest signUpReq);
	
	public CommonResponse grienvanceVerifyOTP(SignUpRequest usersRequest);
}
