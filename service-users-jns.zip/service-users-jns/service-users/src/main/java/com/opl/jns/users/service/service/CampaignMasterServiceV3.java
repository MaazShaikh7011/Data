package com.opl.jns.users.service.service;

import com.opl.jns.users.api.model.BankSpecificJourneyConfigProxy;
import com.opl.jns.users.api.model.CampaignMasterProxy;
import com.opl.jns.users.api.model.CampaignUserMappingProxy;
import com.opl.jns.utils.common.CommonResponse;

import java.util.List;

public interface CampaignMasterServiceV3 {

    // FETCH CAMPAIGN DETAILS BY URL
//    public CommonResponse getByCampaignUrl(String url);
//
//    // SAVE / UPDATE CAMPAIGN DETAILS
//    public CommonResponse saveUpdate(CampaignMasterProxy campaignMasterProxy, Long userId);
//
//    // FETCH CAMPAIGN DETAILS BY ID
//    public CommonResponse getByCampaignId(Long id);
//
//    // FETCH CAMPAIGN DETAILS BY LIST OF ID
//    public CommonResponse getByListOfCampaignId(List<Long> campaignIdList);
//
//    // FETCH ALL CAMPAIGN DETAILS BY USER ID FROM CAMPAIGN USER MAPPING TABLE
//    public CommonResponse getByUserId(Long userId);
//
//    // SAVE / UPDATE CAMPAIGN USER MAPPING DETAILS
//    public CommonResponse saveUpdateUserMapping(CampaignUserMappingProxy campaignUserMappingProxy);
//
//    // FETCH CAMPAIGN DETAILS BY ORG_ID
//    public CommonResponse getByOrgId(Long orgId);
//
//    public CommonResponse getBankSpecificConfigByCampId(Long campOrgId, Long schemeId);
//
//    public CommonResponse setBankSpecificJourneyConfig(BankSpecificJourneyConfigProxy journeyConfigProxy);
//
//    public CommonResponse getBankSpecificJourneyConfig(BankSpecificJourneyConfigProxy journeyConfigProxy);
//
//    public CommonResponse getJourneyConfigHistory(BankSpecificJourneyConfigProxy journeyConfigProxy);
//
//    public CommonResponse getJourneyConfigForProductScoring(Long userOrgId,Long schemeId);
}
