package com.opl.jns.users.service.service.impl;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import jakarta.transaction.Transactional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.users.service.service.CaptchaServiceV3;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class CaptchaServiceImplV3 implements CaptchaServiceV3 {
//	Random random = new Random();
	SecureRandom random =new  SecureRandom();
	public CommonResponse generateCaptcha() {
		log.info("entry in generateCaptcha()");
		Color backgroundColor = Color.white;
		Color borderColor = Color.black;
		Color textColor = Color.black;
		Color circleColor = new Color(190, 160, 150);
		Font textFont = new Font("Verdana", Font.BOLD, 20);
		int charsToPrint = 6;
		int width = 292;
		int height = 50;
		int circlesToDraw = 25;
		float horizMargin = 10.0f;
		double rotationRange = 0.8;
		BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = (Graphics2D) bufferedImage.getGraphics();
		g.setColor(backgroundColor);
		g.fillRect(0, 0, width, height);

		g.setColor(circleColor);
		for (int i = 0; i < circlesToDraw; i++) {
			int L = (int) (random.nextInt() * height / 1.5);
			int X = (random.nextInt() * width - L);
			int Y = (random.nextInt() * height - L);
			g.draw3DRect(X, Y, L * 2, L * 2, true);
		}
		g.setColor(textColor);
		g.setFont(textFont);
		FontMetrics fontMetrics = g.getFontMetrics();
		int maxAdvance = fontMetrics.getMaxAdvance();
		int fontHeight = fontMetrics.getHeight();

		String elegibleChars = "ABCDEFGHJKLMNPQRSTUVWXYabcdefghjkmnpqrstuvwxy1234567890";
		char[] chars = elegibleChars.toCharArray();
		float spaceForLetters = -horizMargin * 2 + width;
		float spacePerChar = spaceForLetters / (charsToPrint - 1.0f);
		StringBuilder finalString = new StringBuilder();
		for (int i = 0; i < charsToPrint; i++) {
			double randomValue = random.nextDouble();
			int randomIndex = (int) Math.round(randomValue * (chars.length - 1));
			char characterToShow = chars[randomIndex];
			finalString.append(characterToShow);

			// this is a separate canvas used for the character so that
			// we can rotate it independently
			int charWidth = fontMetrics.charWidth(characterToShow);
			int charDim = Math.max(maxAdvance, fontHeight);
			int halfCharDim = (int) (charDim / 2);
			BufferedImage charImage = new BufferedImage(charDim, charDim, BufferedImage.TYPE_INT_ARGB);
			Graphics2D charGraphics = charImage.createGraphics();
			charGraphics.translate(halfCharDim, halfCharDim);
//			double angle = (Math.random() - 0.5) * rotationRange;
			double angle = (random.nextDouble()-0.5) * rotationRange;
			charGraphics.transform(AffineTransform.getRotateInstance(angle));
			charGraphics.translate(-halfCharDim, -halfCharDim);
			charGraphics.setColor(textColor);
			charGraphics.setFont(textFont);
			int charX = (int) (0.5 * charDim - 0.5 * charWidth);
			charGraphics.drawString("" + characterToShow, charX,
					(int) ((charDim - fontMetrics.getAscent()) / 2 + fontMetrics.getAscent()));
			float x = horizMargin + spacePerChar * (i) - charDim / 2.0f;
			int y = (int) ((height - charDim) / 2);
			g.drawImage(charImage, (int) x, y, charDim, charDim, null, null);
			charGraphics.dispose();
		}
		g.setColor(borderColor);
		g.drawRect(0, 0, width - 1, height - 1);
		g.dispose();

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			ImageIO.write(bufferedImage, "jpg", byteArrayOutputStream);
		} catch (IOException e) {
			log.error("Exception while Generate Captcha ------------------>", e);
			return new CommonResponse("The application has encountered some error, please try after some time!!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
		Map<String, Object> map = new HashMap<>();
		map.put("captchaString", Base64.getEncoder().encodeToString(finalString.toString().getBytes()));
		map.put("bytes", byteArrayOutputStream.toByteArray());
		log.info("exit form generateCaptcha()");
		return new CommonResponse("Successfully fetched !!", map, HttpStatus.OK.value(), Boolean.TRUE);
	}
}