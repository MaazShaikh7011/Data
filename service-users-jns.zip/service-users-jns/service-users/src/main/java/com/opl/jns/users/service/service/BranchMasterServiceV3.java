package com.opl.jns.users.service.service;

import java.util.List;
import java.util.Set;

import com.opl.jns.users.api.model.BranchBasicDetailsRequest;

/**
 * @author sandip.bhetariya
 *
 */
public interface  BranchMasterServiceV3 {

	List<BranchBasicDetailsRequest> getBranchListBasedOnCityOrStateOrOrgId(BranchBasicDetailsRequest branchBasicDetailsRequest) throws Exception;

	BranchBasicDetailsRequest get(Long appid) throws Exception;

	List<BranchBasicDetailsRequest> searchBranchListBasedOnCodeOrName(BranchBasicDetailsRequest branchBasicDetailsRequest, Long userId, Long userOrgId) throws Exception;

	List<BranchBasicDetailsRequest> getBranchByListId(Set<Long> ids) throws Exception;

	List<BranchBasicDetailsRequest> getBranchByScheme(Long orgId, Long schemeId);

	BranchBasicDetailsRequest getBranchCode(Long schemeId, Long orgId, String branchCode);
	
	List<BranchBasicDetailsRequest> filterBranchList(BranchBasicDetailsRequest request) throws Exception;

    BranchBasicDetailsRequest getBranchByCodeAndIfscAndOrgId(String code, String ifsc,Long orgId);

	BranchBasicDetailsRequest getBranchDetailsRoZOByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId,Long schemeId);
}
