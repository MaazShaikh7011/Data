package com.opl.jns.users.service.domain;

import java.io.Serializable;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "path_access_role_mapping",indexes = {
		@Index(columnList = "role_id,type_id,is_active", name = DBNameConstant.JNS_USERS + "_PATH_ACC_ROLE_MPG_ROLE_ID_TYPE_ID_IS_ACTIVE_IDX"),
})
public class PathAccessRoleMapping   implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "path_access_role_mapping_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "path_access_role_mapping_seq_gen", sequenceName = "path_access_role_mapping_seq", allocationSize = 1)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "path_access_id", referencedColumnName = "id")
	private PathAccessMaster pathAccessId;
	
	@Column(name = "role_id")
	private Long roleId;
	
	@Column(name = "type_id")
	private Long typeId;
	
	@Column(name = "scheme_id")
	private Long schemeId;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	

}
