package com.opl.jns.users.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
//import com.opl.jns.common.logs.client.AnsLogsClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.otp.client.OTPClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableAutoConfiguration
@EnableScheduling
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableDiscoveryClient
public class UsersMain {

	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(UsersMain.class, args);
//		System.err.println(DataSourceProvider.getDatabaseName());
//		System.err.println(DataSourceProvider.getPassword());
	}

	@Bean
	public NotificationClient notificationClient() {
		NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
//		 NotificationClient notificationClient = new NotificationClient("https://sit-opl-atmanirbhar.instantmseloans.in/notification/");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
		return notificationClient;
	}

	@Bean
	public OTPClient otpClient() {
		OTPClient otpClient = new OTPClient(URLConfig.fetchURL(URLMaster.OTP));
//		OTPClient otpClient = new OTPClient("https://sit-opl-atmanirbhar.instantmseloans.in/otpservice/otp");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(otpClient);
		return otpClient;
	}

	@Bean
	public AuthClient authClient() {
		AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
//		AuthClient authClient = new AuthClient("https://sit-opl-atmanirbhar.instantmseloans.in/auth");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
		return authClient;
	}

	@Bean
	public OneFormClient oneFormClient() {
		OneFormClient oneFormClient = new OneFormClient(URLConfig.fetchURL(URLMaster.ONE_FORM));
//		OneFormClient oneFormClient = new OneFormClient("https://sit-opl-atmanirbhar.instantmseloans.in/oneform");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(oneFormClient);
		return oneFormClient;
	}

//	@Bean
//	public AnsLogsClient clientLogs() {
//		AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
////		ClientLogs clientLogs = new ClientLogs("https://sit-opl-atmanirbhar.instantmseloans.in/ans-logs");
//		applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//		return ansLogsClient;
//	}

	@Bean
	public DMSClient dmsMasterClient() {
		DMSClient dmsClient = new DMSClient(URLConfig.fetchURL(URLMaster.DMS));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(dmsClient);
		return dmsClient;
	}

}