package com.opl.jns.users.service.repository;

/**
 * @author ravi.thummar
 * Date : 21-06-2023
 */
public interface CommonRepository {

    String getSchemeByUserIdBusinessId(Long userId, Long businessType, Integer type);

    String getMenuListByUserId(Long userId);

}
