package com.opl.jns.users.service.service;

import com.opl.jns.utils.common.CommonResponse;

public interface CaptchaServiceV3 {

	public CommonResponse generateCaptcha();

}
