package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.users.service.domain.User;
import com.opl.jns.users.service.domain.UserPasswordChangeLog;

import java.util.List;


/**
 * @author sandip.bhetariya
 *
 */
@Repository

public interface UserPasswordChangeLogRepositoryV3 extends JpaRepository<UserPasswordChangeLog, Long> {
	
//	public  List<UserPasswordChangeLog> findOneByUserId(User user);
}
