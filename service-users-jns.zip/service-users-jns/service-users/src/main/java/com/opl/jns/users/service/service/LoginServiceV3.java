package com.opl.jns.users.service.service;

import jakarta.servlet.http.HttpServletRequest;

import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.users.api.model.LoginResponse;
import com.opl.jns.users.api.model.UsersRequest;

/**
 * @author jaimin.darji
 */
public interface LoginServiceV3 {

    LoginResponse login(UsersRequest userRequest, String remoteAddr);

    OTPResponse validateOTP(UsersRequest usersRequest, Integer otpRequestType);
    
//    public CommonResponse getUserByUserNameForNRLM(String userName, String pass);

    AuthResponse callAuthClient(UsersRequest usersRequest, String userIp);

	void updateCustomerInTokenMapping(AuthRequest authReq, HttpServletRequest servletRequest) throws Exception;

//	List<LoginUserTypeMaster> getLoginUserTypes();

	LoginResponse createPartnerTokenMapping(UsersRequest userRequest, String remoteAddr);
}
