package com.opl.jns.users.service.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.auth.api.utils.EncodeDecodeHelper;
import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.otp.api.exception.OTPException;
import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.otp.client.OTPClient;
import com.opl.jns.users.api.model.LoginResponse;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.domain.CampaignMaster;
import com.opl.jns.users.service.domain.User;
import com.opl.jns.users.service.repository.UsersRepositoryV3;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.utils.common.AESEncryptionUtilitySBI;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

/**
 * @author jaimin.darji
 */
@Service
@Transactional
public class LoginServiceImplV3 implements LoginServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(LoginServiceImplV3.class.getName());

	private static final String USER_BLOCK = "You have reached maximum login attempts, please try next day.";

	public static final Long MARKET_PLACE = 1L;

	@Autowired
	private AuthClient authClient;

	@Autowired
	private UsersRepositoryV3 usersRepository;

	@Autowired
	private OTPClient otpClient;

//    @Autowired
//	LoginUserTypeMasterRepositoryV3 loginUserMasterRepository;

//    @Autowired
//    private CampaignDetailService campaignDetailService;

	@Autowired
	private ConfigProperties configProperties;

//    @Autowired
//    CampaignMasterServiceV3 campaignMasterService;

	/**
	 * For Login Service
	 * 
	 * @param userRequest
	 * @param remoteAdd
	 * @return
	 */
	public LoginResponse login(UsersRequest userRequest, String remoteAdd) {
		String email = userRequest.getEmail();
		LoginResponse loginResponse = new LoginResponse();
		AuthResponse response;
		User user = null;
		if (!OPLUtils.isObjectNullOrEmpty(email) && !OPLUtils.isObjectNullOrEmpty(userRequest.getPassword())) {
//            user = usersRepository.getByCaseSensitiveEmailAndUserTypeMasterId(email, userRequest.getUserType());
			user = usersRepository.findByEmailAndUserTypeMasterId(email, userRequest.getUserType());
			if (user == null) {
				loginResponse.setMessage("You have entered invalid Email-Address, Please enter correct email");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				return loginResponse;
			}else if(Boolean.FALSE.equals(user.getIsActive())) {
				loginResponse.setMessage("User is locked. Please contact system administrator");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				return loginResponse;
			}
			if (user.getPassword() == null) {
				loginResponse.setMessage(
						"Its seems you have not set your password yet, Please try to login with your registered mobile and set password");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				return loginResponse;
			}
		} else if (!OPLUtils.isObjectNullOrEmpty(userRequest.getMobile())) {
			user = usersRepository.findByMobileAndUserTypeMasterId(userRequest.getMobile(), userRequest.getUserType());
			if (user == null || !user.getIsActive()) {
				loginResponse.setMessage("You have entered invalid Mobile, Please enter correct mobile number");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				return loginResponse;
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(user) && !OPLUtils.isObjectNullOrEmpty(user.getEmail())) {
					userRequest.setEmail(user.getEmail());
				}
			}
		} else if (!OPLUtils.isObjectNullOrEmpty(userRequest.getUserName())) {
			email = userRequest.getUserName().concat("@diy.com");
			user = usersRepository.findByEmailAndUserTypeMasterId(email, UserTypeMaster.FUNDSEEKER.getId());
			if (OPLUtils.isObjectNullOrEmpty(user)) {
				user = usersRepository.findOneByUsernameAndUserTypeMasterId(userRequest.getUserName(), UserTypeMaster.FUNDSEEKER.getId());
			}
			if (!OPLUtils.isObjectNullOrEmpty(user)) {
				userRequest.setEmail(user.getEmail());
				userRequest.setPassword(userRequest.getPassword());
				userRequest.setUserType(user.getUserTypeMaster().getId());
			} else {
				loginResponse.setMessage("Invalid Username");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				return loginResponse;
			}
		}
		
		if (user == null) {
			loginResponse.setMessage("Invalid Email Address Or Mobile Number Found!!");
			loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
			return loginResponse;
		}

		email = user.getEmail();

		if (user.getIsLocked() != null && user.getIsLocked()) {
			loginResponse.setMessage(USER_BLOCK);
			loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
			return loginResponse;
		}

		// SEND OTP WHILE LOGIN BO USER
		if (user.getUserRoleId().getRoleId().equals(UserRoleMaster.BRANCH_CHECKER.getId())
				&& OPLUtils.isObjectNullOrEmpty(userRequest.getOtp())
				&& user.getPassword().equalsIgnoreCase(DigestUtils.md5DigestAsHex(userRequest.getPassword().getBytes()))) {
			String configValue = configProperties.getValueByCode("IS_BO_TWO_FECTOR_LOGIN");
			if (!OPLUtils.isObjectNullOrEmpty(configValue) && configValue.equals("ON")) {
				loginResponse.setConfigFlag(configValue);
				sendOTP(user, UsersUtils.OTP_REQUEST_LOGIN_TYPE, NotificationType.EMAIL, JnsNotificationMasterUtil.EMAIL_CUST_BO_LOGIN_SUCESS);
				loginResponse.setMessage("Successfully sent user verification code in your registered email address !!");
				loginResponse.setStatus(HttpStatus.OK.value());
				if (user.getUserRoleId() != null) {
					loginResponse.setUserRoleId(user.getUserRoleId().getRoleId());
				}
				loginResponse.setEmail(email);
				loginResponse.setUserType(user.getUserTypeMaster().getId());
				return loginResponse;
			} else {
				logger.info("IS_BO_TWO_FECTOR_LOGIN  Flag is OFF");
			}
		}

		if ((!OPLUtils.isObjectNullOrEmpty(userRequest.getEmail())
				|| !OPLUtils.isObjectNullOrEmpty(userRequest.getMobile()))
				&& !OPLUtils.isObjectNullOrEmpty(userRequest.getPassword())) {
			// EMAIL/MOBILE AND PASSWORD GENERATE TOKEN
			response = callAuthClient(userRequest, remoteAdd);
		} else if (!OPLUtils.isObjectNullOrEmpty(userRequest.getMobile())
				&& !OPLUtils.isObjectNullOrEmpty(userRequest.getOtp())) {
			// OTP VERFICATION AND GENERATE TOKE
			UsersRequest existingReqData = new UsersRequest();
			existingReqData.setId(user.getUserId());
			existingReqData.setMobile(user.getMobile());
			existingReqData.setOtp(userRequest.getOtp());
			existingReqData.setUserType(userRequest.getUserType());
			OTPResponse otpResponse = validateOTP(existingReqData, UsersUtils.OTP_REQUEST_SIGNUP_TYPE);
			if (OPLUtils.isObjectNullOrEmpty(otpResponse) || otpResponse.getStatus() == HttpStatus.CONFLICT.value()
					|| otpResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
				loginResponse.setMessage("Invalid or expired OTP");
				loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
				user.setLoginCounter((user.getLoginCounter() != null ? user.getLoginCounter() : 0) + 1);
				// Integer loginCounter = updateFailedLoginCounter(userRequest, loginResponse);
				if (user.getLoginCounter() >= 5) {
					// go for is locked
					loginResponse.setStatus(HttpStatus.LOCKED.value());
					user.setIsLocked(true);
					loginResponse.setMessage("5 failed login attempts. Now you are blocked!");
				}
				loginResponse.setLoginCounter(user.getLoginCounter());
				usersRepository.save(user);
				return loginResponse;
			}
			response = callAuthClient(existingReqData, remoteAdd);
		} else {
			logger.info("Email: " + userRequest.getEmail() + " OTP: " + userRequest.getOtp()
					+ " -Email or Password or otp is empty");
			return loginResponse;
		}

		BeanUtils.copyProperties(response, loginResponse);

		// if user fails the login attempt then go for block user
		if ((loginResponse.getStatus() == HttpStatus.UNAUTHORIZED.value())) {
			user.setLoginCounter((user.getLoginCounter() != null ? user.getLoginCounter() : 0) + 1);
			loginResponse.setLoginCounter(user.getLoginCounter());
			// Integer loginCounter = updateFailedLoginCounter(userRequest, loginResponse);
			if (user.getLoginCounter() >= 5) {
				// go for is locked
				loginResponse.setStatus(HttpStatus.LOCKED.value());
				user.setIsLocked(true);
				loginResponse.setMessage("5 failed login attempts. Now you are blocked!");
			}
			if (user.getLoginCounter() > 0) {
				loginResponse.setStatus(HttpStatus.LOCKED.value());
			}
			usersRepository.save(user);
			return loginResponse;
		} else if (loginResponse.getStatus() == HttpStatus.OK.value()
				&& (!OPLUtils.isObjectNullOrEmpty(response.getUserId()))) {
			// If user successfully logged in then set login counter to NULL
			user.setIsLocked(Boolean.FALSE);
			user.setLoginCounter(null);

			// SET CAMPAIGN MASTER ID IN USER DOMAIN
			user.setCampaignMaster(new CampaignMaster(
					userRequest.getCampaignMasterId() != null ? userRequest.getCampaignMasterId() : MARKET_PLACE));
			user = usersRepository.save(user);
		}

		loginResponse.setMobile(user.getMobile());

		// SET URL FOR MOVE TO CHANGE PASSWORD PAGE
//		if (UserTypeMaster.FUNDSEEKER.getId().equals(loginResponse.getUserType())) {
//			logger.info("Before Generate ChangePass Url===========> " + loginResponse.getUserType());
//			if (user != null && !user.isPassChanged()) {
//				generateChangePassLink(user.getModifiedDate(), email, loginResponse, user.getUserTypeMaster().getId());
//			}
//		}

		Long roleId = null;
		if (user.getUserRoleId() != null) {
			roleId = user.getUserRoleId().getRoleId();
			loginResponse.setUserRoleId(roleId);
		}
		loginResponse.setIsPasswordChanged(user.isPassChanged());
		loginResponse.setPasswordResetDate(user.getPasswordResetDate());
		if (UserTypeMaster.FUNDPROVIDER.getId().equals(loginResponse.getUserType())
				|| UserTypeMaster.INSURER.getId().equals(loginResponse.getUserType())) {
			loginResponse.setUserRoleId(roleId);
			loginResponse.setUserOrgId(user.getUserOrgId().getUserOrgId());
			loginResponse.setUserOrgName(user.getUserOrgId().getDisplayOrgName());
			loginResponse.setIsPasswordChanged(user.isPassChanged());
			loginResponse.setUserBranchId(user.getBranchId() != null ? user.getBranchId().getId() : null);
		}
		loginResponse.setUserId(user.getUserId());
		loginResponse.setEmail(email);
		loginResponse.setUserOrgId(response.getUserOrgId());
		loginResponse.setUserType(user.getUserTypeMaster().getId());
		if(UserTypeMaster.FUNDSEEKER.getId() == loginResponse.getUserRoleId()) {
//			loginResponse.setEmail(null);
			loginResponse.setUserName(user.getUsername());
		}
		return loginResponse;
	}

	public OTPResponse sendOTP(User usersRequest, int otpRequestType, NotificationType notificationType,
			Long notificationMasterId) {
		logger.info("entry in sendOTP()");
		try {
			OTPRequest request = new OTPRequest();
			request.setMobileNo(usersRequest.getMobile());
			request.setRequestType(otpRequestType);
			request.setMasterId(usersRequest.getUserId());
			request.setEmailId(usersRequest.getEmail());
			request.setNotificationMasterId(notificationMasterId);
			request.setName(usersRequest.getFirstName());
			request.setSource(usersRequest.getUserRoleId().getRoleId().equals(UserRoleMaster.BORROWER.getId()) ? 4 : 2);
			request.setOrgId(usersRequest.getUserOrgId().getUserOrgId());
			OTPResponse otpResponse = new OTPResponse();
			if (notificationType.equals(NotificationType.SMS)) {
				otpResponse = otpClient.sendOTP(request);
			} else if (notificationType.equals(NotificationType.EMAIL)) {
				otpResponse = otpClient.sendEmailOTP(request);
			}
			logger.info("exit form sendOTP() & otpResponse" + otpResponse.toString());
			return otpResponse;

		} catch (OTPException e) {
			logger.error("Error while OTP send ", e);
		}
		logger.info("exit form sendOTP()");
		return null;
	}

	/**
	 * FOR NRLM LOGIN
	 * 
	 * @return
	 */
//    public CommonResponse getUserByUserNameForNRLM(String userName, String pass) {
//    	try {
//			String email = userName.concat("@nsdl.com");
//			Long userId = usersRepository.getUserIdByEmailAndUserTypeMasterId(email, UserTypeMaster.FUNDSEEKER.getId());
//			if(userId != null) {
//				return new CommonResponse("Found User", HttpStatus.OK.value(), Boolean.TRUE);
//			}
//			userId = usersRepository.getUserIdByUsernameAndUserTypeMasterId(userName, UserTypeMaster.FUNDSEEKER.getId());
//			if(userId != null) {
//				return new CommonResponse("Found User", HttpStatus.OK.value(), Boolean.TRUE);
//			}
//           /* NRLMLoginRes login = null;
//            String passwordEncryptType = configProperties.getValue("NRLM_PASS_ENCRYPT_TYPE");
//            if ("SHA-256".equalsIgnoreCase(passwordEncryptType)) {
//                login = nrlmapi.login(userName, org.apache.commons.codec.digest.DigestUtils.sha256Hex(pass.getBytes()));
//            } else {
//                login = nrlmapi.login(userName, DigestUtils.md5DigestAsHex(pass.getBytes()));
//            }*/
////			NRLMLoginRes login = nrlmapi.login(userName, DigestUtils.md5DigestAsHex(pass.getBytes()));
////			NRLMLoginRes login = nrlmapi.login(userName, org.apache.commons.codec.digest.DigestUtils.sha256Hex(pass.getBytes()));
//           /* if (login.getStatus() != 200) {
//                return new CommonResponse("The NRLM portal is currently under scheduled maintenance. You will be able to log in once the NRLM portal is functioning again.", HttpStatus.OK.value(), Boolean.FALSE);
//            } else if (!login.getFlag()) {
//                return new CommonResponse("You have entered invalid username and password", HttpStatus.OK.value(), Boolean.FALSE);
//            }*/
//			User user = new User();
//			user.setEmail(email);
//			user.setPassword(DigestUtils.md5DigestAsHex(configProperties.getValue(null).getBytes())); //ConfigProperties.NRLM_SIGNUP_DEFAULT_PASS
//			user.setCreatedDate(new Date());
//			user.setUsername(userName);
//			user.setIsActive(Boolean.TRUE);
//			user.setOtpVerified(Boolean.TRUE);
//			user.setUserTypeMaster(new com.opl.jns.common.service.users.domain.UserTypeMaster(UserTypeMaster.FUNDSEEKER.getId()));
//			user.setSignUpDate(new Date());
//			user.setTermsAccepted(Boolean.TRUE);
//			usersRepository.saveAndFlush(user);
//			return new CommonResponse("Found User", HttpStatus.OK.value(), Boolean.TRUE); 
//		} catch (Exception e) {
//			logger.error("Exception while get user details for NRLM -->" + userName, e);
//			return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.OK.value(), Boolean.FALSE);
//		}
//    }

	public AuthResponse callAuthClient(UsersRequest usersRequest, String userIp) {
		AuthRequest req = new AuthRequest();

		if (usersRequest.getEmail() == null || usersRequest.getPassword() == null) {
			req.setUsername(AuthCredentialUtils.setUserName(usersRequest.getMobile(), false));
			req.setPassword(AuthCredentialUtils.TEMP_PP);
		} else {
			req.setUsername(AuthCredentialUtils.setUserName(usersRequest.getEmail(), true));
			req.setPassword(usersRequest.getPassword());
		}
//        req.setUsername(AuthCredentialUtils.setUserName(usersRequest.getEmail(), true));
//        req.setPassword(usersRequest.getPassword());
		req.setUserIp(userIp);
		req.setUserTypeId(usersRequest.getUserType());
		req.setUserBrowser(usersRequest.getBrowserName());
		req.setBrowserVersion(usersRequest.getBrowserVersion());
		req.setDevice(usersRequest.getDevice());
		req.setDeviceType(usersRequest.getDeviceType());
		req.setDeviceOs(usersRequest.getDeviceOs());
		req.setDeviceOsVersion(usersRequest.getDeviceOsVersion());
		req.setUserAgent(usersRequest.getUserAgent());
		req.setCampaignMasterId(usersRequest.getCampaignMasterId() != null ? usersRequest.getCampaignMasterId() : MARKET_PLACE);
		req.setIsMobileLogin(usersRequest.getIsMobileLogin());
		req.setFcmToken(usersRequest.getFcmToken());
//        req.setCampaignCode(usersRequest.getCampaignCode());
		AuthResponse response = authClient.getRefreshToken(req);
		if (response != null && response.getStatus() == HttpStatus.OK.value()) {
			response.setStatus(HttpStatus.OK.value());
			response.setMessage("Login Successful");
			return response;
		} else {
			String errMsg = (usersRequest.getUserType() == UserTypeMaster.FUNDSEEKER.getId() ? "Username" : "E-Mail ID") + " or Password is invalid";
			if (response != null) {
				response.setStatus(
						response.getStatus() != null ? response.getStatus() : HttpStatus.UNAUTHORIZED.value());
				response.setMessage(
						!OPLUtils.isObjectNullOrEmpty(response.getMessage()) ? response.getMessage() : errMsg);
			} else {
				response = new AuthResponse();
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.setMessage(errMsg);
			}
			return response;
		}
	}

	private void generateChangePassLink(Date modifiedDate, String email, LoginResponse loginResponse, Long userTypeId) {
		try {
			loginResponse.setIsPasswordChanged(Boolean.FALSE);
			logger.info("In Generate Change Pass Url Method ===============>TRUE");
			String date = null;
			try {
				SimpleDateFormat print = new SimpleDateFormat(UsersUtils.SIMPLE_DATE_FORMAT);
				date = print.format(modifiedDate);
			} catch (Exception e1) {
				logger.error("Exception while generate change pass ==========>" + e1.getMessage());
			}
			String stringToEncrypt = email + "$" + date + "$" + UsersUtils.EMAIL_VERIFICATION_URL + "$" + userTypeId;
			loginResponse.setGenerateChangePass(AESEncryptionUtilitySBI.encrypt(stringToEncrypt, true));
		} catch (Exception e) {
			logger.error("Exception while Generate Change Password Link ===========>" + e.getMessage());
		}
	}

	public OTPResponse validateOTP(UsersRequest usersRequest, Integer otpRequestType) {
		logger.info("entry in validateOTP()");
		OTPRequest request = new OTPRequest();
		request.setMasterId(usersRequest.getId());
		request.setEmailId(usersRequest.getEmail());
		request.setMobileNo(usersRequest.getMobile());
		request.setRequestType(otpRequestType);
		request.setOtp(usersRequest.getOtp());
		request.setNotificationMasterId(2L);

		if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getOtpOn())) {
			request.setOtpOn(usersRequest.getOtpOn());
		}
		try {
//        	OTPResponse otpResponse = null;
			/*
			 * if(configProperties.getValue(LoadTestingEnum.TESTING_MODE_ON_OFF.getKey()).
			 * equals(LoadTestingEnum.TESTING_MODE.getKey())) { otpResponse = new
			 * OTPResponse(); otpResponse.setStatus(200); }else { otpResponse =
			 * otpClient.verifyOTP(request); }
			 */
			OTPResponse otpResponse = otpClient.verifyOTP(request);
			logger.info("otpResponse :- " + otpResponse.toString());
			if (otpResponse.getStatus() == HttpStatus.OK.value()) {
				logger.info("Valid otp : " + usersRequest.getOtp());
			} else if (otpResponse.getStatus() == HttpStatus.BAD_REQUEST.value() || otpResponse.getStatus() == HttpStatus.CONTINUE.value()) {
				logger.info("Invalid OTP :");
			}
			logger.info("exit form validateOtp(): ");
			return otpResponse;
		} catch (Exception e) {
			logger.error("error while calling OTP client for validating OTP... ", e);
		}
		return null;
	}

	@Override
	public void updateCustomerInTokenMapping(AuthRequest authReq, HttpServletRequest servletRequest) throws Exception {
		AuthRequest request = AuthCredentialUtils.httpResToAuthReq(servletRequest);
		request.setAccessToken(EncodeDecodeHelper.decode(request.getAccessToken()));
		request.setRefreshToken(EncodeDecodeHelper.decode(request.getRefreshToken()));
		request.setUsername(EncodeDecodeHelper.decode(request.getUsername()));
		request.setClientUserId(authReq.getClientUserId());
		authClient.updateCustomerInTokenMapping(request);
	}

//	@Override
//	public List<LoginUserTypeMaster> getLoginUserTypes() {
//		return loginUserMasterRepository.findByIsActiveOrderByOrderAsc(true);
//	}

	@Override
	public LoginResponse createPartnerTokenMapping(UsersRequest userRequest, String remoteAddr) {
		LoginResponse loginResponse = null;
		try {

			User user = usersRepository.findById(userRequest.getUserId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(user))
				return null;

			AuthRequest req = new AuthRequest();

			if (user.getEmail() == null || user.getPassword() == null) {
				req.setUsername(AuthCredentialUtils.setUserName(user.getMobile(), false));
				req.setPassword(AuthCredentialUtils.TEMP_PP);
			} else {
				req.setUsername(AuthCredentialUtils.setUserName(user.getEmail(), true));
//					req.setPassword(user.getPassword());
				req.setPassword(AuthCredentialUtils.TEMP_PP);
			}
			req.setUserId(user.getUserId());
			req.setUserIp(remoteAddr);
			req.setUserTypeId(userRequest.getUserType());
			req.setIsMobileLogin(false);
//		        req.setUserBrowser(user.getBrowserName());
//		        req.setBrowserVersion(user.getBrowserVersion());
//		        req.setDevice(usersRequest.getDevice());
//		        req.setDeviceType(usersRequest.getDeviceType());
//		        req.setDeviceOs(usersRequest.getDeviceOs());
//		        req.setDeviceOsVersion(usersRequest.getDeviceOsVersion());
//		        req.setUserAgent(usersRequest.getUserAgent());
//		        req.setCampaignMasterId(user.getCampaignMaster().getId() != null ? user.getCampaignMaster().getId() : MARKET_PLACE);

			AuthResponse response = authClient.getTokenForBankerAsPartner(req);
			if (response != null) {
				loginResponse = new LoginResponse();
				response.setStatus(HttpStatus.OK.value());
				response.setMessage("Login successfully");
			} else {
				response = new AuthResponse();
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.setMessage("E-Mail ID or Password is invalid");
			}
			BeanUtils.copyProperties(response, loginResponse);

		} catch (Exception e) {
			logger.error("Error while get token for partner", e);
		}
		return loginResponse;
	}

}
