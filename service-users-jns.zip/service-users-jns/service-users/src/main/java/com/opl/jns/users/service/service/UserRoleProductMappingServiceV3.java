package com.opl.jns.users.service.service;

import java.util.List;

import com.opl.jns.users.api.model.UserRoleProductMapProxy;

public interface UserRoleProductMappingServiceV3 {

	public List<UserRoleProductMapProxy> listRoleByUserId(Long userId);

	List<UserRoleProductMapProxy> listRoleByUserIdAndBusinessType(Long userId,Long businessTypeId);
	List<UserRoleProductMapProxy> schemeByUserId(Long userId);

	public String getSchemeByUserIdBusinessId(Long userId, Long businessType, Integer type);

}
