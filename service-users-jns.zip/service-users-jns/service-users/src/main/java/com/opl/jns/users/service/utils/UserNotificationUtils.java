package com.opl.jns.users.service.utils;

import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UserNotificationUtils {
	
	

	@Autowired
	private NotificationClient notificationClient;
	
	
	/**
	 * DOCUMENTS FOR NOTIFICATION :- https://capitaworld-my.sharepoint.com/:x:/r/personal/hiren_kavathiya_onlinepsbloans_com/_layouts/15/Doc.aspx?sourcedoc=%7B6a7a422b-6cd0-4c52-ab5e-24cc3cbb8560%7D&action=edit&activeCell=%27Beneficiary%27!F5&wdinitialsession=d88a0bfb-2484-4191-aeef-e202e3d1d507&wdrldsc=9
	 * Sr.No. :- Sign up
	 */

	public void sendNotificationOnSignUp(String toEmail, String toSms, Long userId) {
		try {
			log.info("Enter the notification while SignUp ------->",userId);
			if(toEmail != null && toSms != null && userId != null) {
				String[] toEmailAry = { toEmail };
				String[] toSmsAry = {91 + toSms };

				Map<String, Object> parameter = new HashedMap<>();
				parameter.put("email", toEmail);

				NotificationRequest notificationRequest = new NotificationRequest();
				notificationRequest.setClientRefId(userId.toString());
				notificationRequest.addNotification(new Notification(587L,ContentType.TEMPLATE,null,toEmailAry,NotificationType.EMAIL,parameter));
				
				notificationRequest.addNotification(new Notification(588L,ContentType.TEMPLATE,null,toSmsAry,NotificationType.SMS,parameter));
				notificationClient.send(notificationRequest);
			}else {
				log.info("User data not found----------->");
			}
			
		
		}catch (Exception e) {
			log.info("Exception while send the notification while Sign up process----->", e);
		}
		
	}
}
