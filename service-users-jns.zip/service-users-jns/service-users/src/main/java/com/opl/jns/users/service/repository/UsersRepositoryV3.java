package com.opl.jns.users.service.repository;

import java.util.List;

import com.opl.jns.users.service.domain.User;
import com.opl.jns.utils.constant.DBNameConstant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * @author sandip.bhetariya
 *
 */
@Repository
public interface UsersRepositoryV3 extends JpaRepository<User, Long> {

//	User findOneByEmail(String email);

//	User findOneByUserId(Long userId);

	User findByEmailAndUserTypeMasterId(String email, final long userTypeMasterId);
	
	@Query("SELECT userId FROM User u where u.email =:email and u.userTypeMaster.id =:userTypeId")
	public Long getUserIdByEmailAndUserTypeMasterId(String email, final long userTypeId);
	
	public Long countByEmailAndUserTypeMasterIdAndIsActiveTrue(String email, final long userTypeId);
		
	public Long countByEmailAndUserTypeMasterIdAndIsActiveTrueAndUserIdNot(String email, final long userTypeId, final long userId);

//	User findOneByEmailAndUserTypeMasterId(String email, Long userTypeId);

//	@Query("SELECT userId FROM User u where u.username =:username and u.userTypeMaster.id =:userTypeId")
//	public Long getUserIdByUsernameAndUserTypeMasterId(String username, Long userTypeId);

	User findOneByUsernameAndUserTypeMasterId(String username, Long userTypeId);

//	User findOneByMobile(String mobileNumber);

	User findByMobileAndUserTypeMasterId(String mobileNumber, Long userTypeId);

	List<User> findAllByMobile(String mobileNumber);

//	List<User> findByIsActive(boolean isActive);

//	@Query("SELECT count(u.id) FROM User u where u.email =:email and u.userTypeMaster.id =:userTypeId and isActive = true")
//	Long checkEmailAndUserType(@Param("email") String email, @Param("userTypeId") Long userTypeId);

//	@Query("SELECT count(u.id) FROM User u where u.email =:email and u.userTypeMaster.id =:userTypeId and isActive = true and userId != :userId")
//	Long checkEmailAndUserTypeAndNotInUserId(@Param("email") String email, @Param("userTypeId") Long userTypeId,
//			@Param("userId") Long userId);

	public Long countByMobileAndUserTypeMasterIdAndIsActiveTrue(String mobile, final long userTypeId);
		
//	@Query("SELECT count(u.id) FROM User u where u.mobile =:mobileNumber and u.userTypeMaster.id =:userTypeId and isActive = true")
//	Long checkMobileAndUserType(@Param("mobileNumber") String mobileNumber, @Param("userTypeId") Long userTypeId);

//	@Query("SELECT count(u.id) FROM User u where u.email =:email and isLocked = true")
//	Long checkEmailAddressLock(@Param("email") String email);

//	@Query("SELECT count(u.id) FROM User u where u.mobile =:mobileNumber and isLocked = true")
//	Long checkMobileNumberLock(@Param("mobileNumber") String mobileNumber);

//    @Query(value="SELECT pm.alias FROM  `users`.`user_permission_master` pm INNER JOIN `users`.`user_permission_mpg` pMpng ON `pm`.id = pMpng.permission_id AND pMpng.is_active = TRUE AND pMpng.user_role_id =:userRoleId AND pMpng.scheme_id =:schemeId AND pMpng.org_id =:orgId WHERE pm.is_active = TRUE" , nativeQuery = true)
	@Query(value = "SELECT pm.alias FROM "+ DBNameConstant.JNS_USERS +".user_permission_master pm INNER JOIN "+ DBNameConstant.JNS_USERS +".user_permission_mpg pMpng ON pm.id = pMpng.permission_id AND pMpng.is_active = 1 AND pMpng.user_role_id =:userRoleId AND pMpng.scheme_id =:schemeId AND pMpng.org_id =:orgId WHERE pm.is_active = 1", nativeQuery = true)
	public List<String> getUserPermissions(@Param("userRoleId") Long userRoleId, @Param("schemeId") Long schemeId,
			@Param("orgId") Long orgId);

	@Query(value = "SELECT pm.alias FROM  "+ DBNameConstant.JNS_USERS +".user_permission_master pm INNER JOIN "+ DBNameConstant.JNS_USERS +".user_permission_mpg pMpng ON pm.id = pMpng.permission_id AND pMpng.is_active = 1 AND pMpng.user_role_id =:userRoleId AND pMpng.scheme_id =:schemeId AND pMpng.org_id =:orgId WHERE pm.is_global = 1 AND pm.is_active = 1", nativeQuery = true)
	public List<String> getUserPermissionsForInactiveScheme(@Param("userRoleId") Long userRoleId,
			@Param("schemeId") Long schemeId, @Param("orgId") Long orgId);

	@Modifying
	@Query("update User SET userRoleId.roleId =:userRoleId,lastBusinessTypeId =:lastBusinessTypeId where userId =:userId")
	public Integer updateRoleIdAndBusinessTypeId(@Param("userRoleId") Long userRoleId,
			@Param("lastBusinessTypeId") Integer lastBusinessTypeId, @Param("userId") Long userId);

	@Modifying
//    @Query(value = "UPDATE `user_token_mapping` SET `active` = FALSE,`logout_date` = NOW() WHERE user_id =:userId AND `active` = TRUE", nativeQuery = true)
	@Query(value = "UPDATE UserTokenMapping SET active = FALSE,logoutDate = current_timestamp WHERE userId =:userId AND active = TRUE")
	public Integer inactiveUserSessionByUserId(@Param("userId") Long userId);

	@Query(value = """
			SELECT u FROM User u \
			INNER JOIN UserRoleProductMapping URPM ON u.userId = URPM.user.userId AND URPM.userRoleMaster.roleId IN (:roleIds) AND URPM.schemeId = :schemeId AND URPM.isActive = true \
			WHERE u.userOrgId.userOrgId = :orgId AND u.isActive = TRUE\
			""")
	public List<User> getUserListBySchmeIdAndUserRoleId(@Param("roleIds") List<Long> roleIds,
			@Param("schemeId") Long schemeId, @Param("orgId") Long orgId);

	@Query(value = """
			SELECT U FROM User U \
			INNER JOIN UserRoleProductMapping URPM ON U.userId = URPM.user.userId AND URPM.userRoleMaster.roleId IN (:roleIds) AND URPM.schemeId = :schemeId AND URPM.isActive = true \
			WHERE U.userOrgId.userOrgId = :orgId AND U.isActive = TRUE AND U.branchId.id = :branchId\
			""")
	public List<User> getUserListBySchmeIdAndUserRoleIdAndBranchId(@Param("roleIds") List<Long> roleIds,
			@Param("schemeId") Long schemeId, @Param("orgId") Long orgId, @Param("branchId") Long branchId);

//	@Query("SELECT u FROM User u where u.mobile =:mobile and u.userTypeMaster.id =:userTypeId AND isActive = TRUE")
//	User findByMobileAndUserTypeIdAndIsActive(String mobile, Long userTypeId);

//	@Query("SELECT u FROM User u where u.mobile =:mobile and u.userTypeMaster.id =:userTypeId")
//	User findByMobileAndUserTypeId(String mobile, Long userTypeId);

//	@Query("SELECT u FROM User u where u.email =:email and u.userTypeMaster.id =:userTypeId AND isActive = TRUE")
//	User findByEmailAndUserTypeIdAndIsActive(String email, Long userTypeId);

	User findFirstByUserOrgIdUserOrgIdAndUserRoleIdRoleIdAndIsActiveTrue(Long orgId, Long roleId);
	
//	User findByUserIdAndEmail(Long userId,String email);
	User findByUserId(Long userId);

	@Modifying
	@Query("update User SET mobile=:mobile where userId =:userId")
	public Integer updateMobileByUserId(@Param("userId") Long userId, @Param("mobile") String mobile);
	
	@Modifying
	@Query("update User SET email=:email where userId =:userId")
	public Integer updateEmailByUserId(@Param("userId") Long userId, @Param("email") String email);
	
	@Query(value = """
		    select gm.id from jns_crm.grievance_pi_details gpd \
		    inner join jns_crm.grievance_master gm on gm.id=gpd.id \
		    where gpd.mobile_number=jns_users."encvalue"(:mobileNumber) and gm.status=:status\
		    """, nativeQuery = true)
	public List<Long> findByMobileNoAndStatus(@Param("mobileNumber") String mobileNumber,@Param("status") Integer status);

}
