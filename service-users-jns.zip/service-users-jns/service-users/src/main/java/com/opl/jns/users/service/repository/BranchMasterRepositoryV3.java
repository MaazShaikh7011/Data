package com.opl.jns.users.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.service.domain.BranchMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface BranchMasterRepositoryV3 extends JpaRepository<BranchMaster, Long> {

	// ########### index JNS_USERS_BRANCH_MST_ORG_ID_BRANCH_TYPE_CITY_ID_STATE_ID
//		@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.isActive=true AND bm.branchType=1 ")
//	public List<BranchMaster> getBranchDetailsListByOrgId(@Param("userOrgId") Long userOrgId);

//	@Query(value = "SELECT u.user_id AS UserId,fp.organization_name AS UserName," + "CASE u.is_active WHEN true THEN 'ACTIVE' WHEN FALSE THEN 'INACTIVE' END AS IsActive,"
//			+ "CASE u.user_role_id WHEN 5 THEN 'HO' WHEN 8 THEN 'Maker' WHEN 9 THEN 'Checker' END AS Role " + "FROM users.`users` u " +
////			"LEFT JOIN users.`fund_provider_details` fp ON u.user_id=fp.user_id " +
//			"WHERE user_role_id IN (5,8,9) AND u.branch_id=:branchId", nativeQuery = true)
//	public List<Object[]> getBranchUser(@Param("branchId") Long branchId);

//	@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId AND bm.branchType=1 and bm.isActive=true")
//	public List<BranchMaster> getBranchListBasedOnOrgId(Long userOrgId);
//
//	@Query("select bm from BranchMaster bm where bm.stateId=:stateId AND bm.branchType=1 and bm.isActive=true")
//	public List<BranchMaster> getBranchListBasedOnState(Integer stateId);
//
//	@Query("select bm from BranchMaster bm where bm.cityId=:cityId and bm.branchType=1 and bm.isActive=true")
//	public List<BranchMaster> getBranchListBasedOnCity(Integer cityId);

//	@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.stateId=:stateId and bm.cityId=:cityId and bm.isActive=true  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnCityOrStateOrOrgId(Long userOrgId, Integer stateId, Integer cityId);

	// BranchMaster ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_IS_ACTIVE_SCH_TYPE_ID_BRANCH_ID
//	@Query("select bm from BranchMaster bm where  bm.id in ( select bp.branchId from BranchProductMapping bp where bp.schTypeId=:schTypeId and bp.userOrgId=:userOrgId and bp.isActive=true) and bm.orgId.userOrgId=:userOrgId and bm.cityId=:cityId and bm.isActive=true  AND bm.branchType=1")

	// BranchMaster ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE
	@Query("select bm from BranchMaster bm where  bm.id in ( select bp.branchId from BranchProductMapping bp where bp.userOrgId=:userOrgId and bp.schTypeId=:schTypeId and bp.isActive=true)  and bm.isActive=true ")
	public List<BranchMaster> getBranchListBasedOnCityOrStateOrOrgId(@Param("userOrgId") Long userOrgId, @Param("schTypeId") Long schTypeId);

//	@Query("select bm from BranchMaster bm where bm.stateId=:stateId and bm.cityId=:cityId and bm.isActive=true  AND bm.branchType=1")
//	public List<BranchMaster> getBranchListBasedOnCityOrState(Integer stateId, Integer cityId);


	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query("""
			select bm from BranchMaster bm where  bm.id in ( select bp.branchId from BranchProductMapping bp where bp.userOrgId=:userOrgId and bp.schTypeId=:schTypeId and  bp.isActive=true and (bp.branchId is null or bp.branchId<>:branchId)) \
			 and (bm.name LIKE %:search% or  bm.code LIKE %:search%) and bm.isActive=true  AND bm.branchType=1\
			""")
	public List<BranchMaster> searchBranchListBasedOnCodeOrName(@Param("search") String search ,@Param("userOrgId") Long userOrgId,@Param("schTypeId") Long schTypeId,@Param("branchId") Long branchId);

//	@Query("select bm from BranchMaster bm where bm.name LIKE %?1% or bm.code LIKE %?1% and bm.isActive=true and bm.orgId.userOrgId=?2")
//	public List<BranchMaster> searchBranchListBasedOnCodeOrName_old(String search , Long userOrgId);

	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE
	@Query("select new com.opl.jns.users.api.model.BranchBasicDetailsRequest(bm.id,bm.name,bm.code,bm.cityId,bm.stateId,b.branchRoId,b.branchZoId,b.branchLhoId,bm.ruralUrbanId) FROM BranchMaster bm INNER JOIN BranchProductMapping b ON b.branchId = bm.id AND b.userOrgId =:orgId AND b.schTypeId =:schemeId AND b.isActive = true where bm.code=:branchCode")
	public List<BranchBasicDetailsRequest> getBranchBasedOnCode(@Param("branchCode")String branchCode, @Param("orgId") Long orgId,@Param("schemeId") Long schemeId);

	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE
	@Query("select new com.opl.jns.users.api.model.BranchBasicDetailsRequest(bm.id,bm.name,bm.code) from BranchMaster bm where bm.id IN(SELECT b.branchId FROM BranchProductMapping b WHERE b.userOrgId =:orgId and b.schTypeId =:schemeId and b.isActive = true)")
	public List<BranchBasicDetailsRequest> getBranchByIds(@Param("orgId") Long orgId,@Param("schemeId") Long schemeId);

	// filter branch List for online and offline based on orgId
//	@Query(value = "SELECT * FROM `users`.`branch_master` BM INNER JOIN  users.branch_product_mapping BPM ON BPM.branch_id = BM.id AND BPM.is_active = true AND BPM.sch_type_id = :schTypeId WHERE (BM.name LIKE %:search% OR BM.`ifsc_code` LIKE %:search% OR BM.`pincode` LIKE %:search%) AND BM.org_id = :userOrgId AND BM.is_active = true AND BM.branch_type = 1",nativeQuery = true)

	// ########### JNS_USERS_BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE
	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE
	@Query(value = "SELECT BM FROM BranchMaster BM INNER JOIN  BranchProductMapping BPM ON BPM.branchId = BM.id AND BPM.userOrgId = :userOrgId AND BPM.schTypeId = :schTypeId AND BPM.isActive = true  WHERE BM.orgId.userOrgId = :userOrgId AND BM.isActive = true AND BM.branchType = 1 AND (BM.name LIKE %:search% OR BM.ifscCode LIKE %:search%)")
	public List<BranchMaster> searchBranchListBasedOnCodeOrName(@Param("search") String searchString,@Param("userOrgId") Long userOrgId, @Param("schTypeId") Long schTypeId);

	//filter branch list based on state
//	@Query(value ="SELECT * FROM `users`.`branch_master` BM INNER JOIN  users.branch_product_mapping BPM ON BPM.branch_id = BM.id AND BPM.is_active = true AND BPM.sch_type_id = :schTypeId WHERE (BM.name LIKE %:search% OR BM.`ifsc_code` LIKE %:search% OR BM.`pincode` LIKE %:search%) AND BM.state_id = :stateId AND BM.org_id = :userOrgId AND BM.is_active = true AND BM.branch_type = 1",nativeQuery = true)

	// BranchMaster ########### JNS_USERS_BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE_STATE_ID
	// BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query(value ="SELECT BPM FROM BranchMaster BM INNER JOIN BranchProductMapping BPM ON BPM.branchId = BM.id AND BPM.userOrgId = :userOrgId AND BPM.schTypeId = :schTypeId AND BPM.isActive = true WHERE BM.orgId.userOrgId = :userOrgId AND BM.isActive = true AND BM.branchType = 1 AND BM.stateId = :stateId AND (BM.name LIKE %:search% OR BM.ifscCode LIKE %:search%) ")
	public List<BranchMaster> serachBranchListBasedOnState(@Param("search") String searchString,@Param("stateId") Integer stateId,@Param("userOrgId") Long userOrgId, @Param("schTypeId") Long schTypeId);

	// ########### JNS_USERS_BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE_CITY_ID_STATE_ID
	@Query("select new com.opl.jns.users.api.model.BranchBasicDetailsRequest(bm.id,bm.name) from BranchMaster bm where  bm.orgId.userOrgId=:orgId And isActive = true AND bm.branchType = 1 And bm.code=:code AND UPPER(ifscCode)=UPPER(:ifsc)")
    BranchBasicDetailsRequest getBranchByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId);

	@Query(value ="SELECT new com.opl.jns.users.api.model.BranchBasicDetailsRequest(BM.id,BM.name,BM.code,BM.cityId,BM.stateId,BPM.branchRoId,BPM.branchZoId,BM.ruralUrbanId) FROM BranchMaster BM INNER JOIN BranchProductMapping BPM ON BPM.branchId = BM.id AND BPM.userOrgId = :userOrgId AND BPM.schTypeId = :schTypeId AND BPM.isActive = true WHERE BM.orgId.userOrgId = :userOrgId AND BM.isActive = true AND BM.branchType = 1 And BM.code = :code AND UPPER(BM.ifscCode) = UPPER(:ifsc)")
	public BranchBasicDetailsRequest getBranchDetailsByCodeAndIfscAndOrgId(@Param("code") String code,@Param("ifsc") String ifsc,@Param("userOrgId") Long userOrgId, @Param("schTypeId") Long schTypeId);

}