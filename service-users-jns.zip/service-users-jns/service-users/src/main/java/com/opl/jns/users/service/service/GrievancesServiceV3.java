package com.opl.jns.users.service.service;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.users.api.model.GrievancesProxy;

/**
 * @author sandip.bhetariya
 *
 */
public interface GrievancesServiceV3 {

//	GrievancesProxy save(GrievancesProxy grievancesRequest, HttpServletRequest request, List<MultipartFile> multipartFiles) throws Exception;
//
//	GrievancesProxy findOne(Long id) throws Exception;

//	List<GrievancesProxy> findAll() throws Exception;

//	GrievancesProxy updateRemark(GrievancesProxy grievancesRequest, HttpServletRequest request) throws Exception;
	
}
