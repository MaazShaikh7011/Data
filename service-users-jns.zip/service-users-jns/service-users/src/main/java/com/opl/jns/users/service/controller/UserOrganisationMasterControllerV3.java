package com.opl.jns.users.service.controller;

import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.api.model.UserOrganisationPdfGenarateRequestResponse;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.users.service.service.UserOrganisationMasterServiceV3;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

@RestController
@RequestMapping("/v3/org")
public class UserOrganisationMasterControllerV3 {

	private static final Logger logger = LoggerFactory.getLogger(UserOrganisationMasterControllerV3.class.getName());

	@Autowired
	private UserOrganisationMasterServiceV3 masterService;

	@GetMapping(value = "/getAllByOrgType/{orgType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getUserDetailsById(@PathVariable Integer orgType) {
		try {
			List<UserOrganisationMasterResponse> all = masterService.getAll(orgType);
			if (all.isEmpty()) {
				return new ResponseEntity<>(new UserResponse("UsersDetails not found by Id !!", HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}
			return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, all), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception while get all organization by org type :- " + orgType, e);
			return new ResponseEntity<>(new UserResponse("Error while fetch all organization list by org type ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getOrganizationName/{orgId}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<CommonResponse> getOrganizationName(@PathVariable Long orgId, HttpServletRequest request) {

		if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
			try {
				logger.info("Enter getOrganizationName");
				String organizationName = masterService.getOrganizationName(orgId);
				return new ResponseEntity<CommonResponse>(new CommonResponse(organizationName, organizationName, HttpStatus.OK.value()), HttpStatus.OK);

			} catch (Exception e) {
				logger.error("Error while getting organization!!", e);
				return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} else {
			return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any orgranization for this id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getOrganizationById/{orgId}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<CommonResponse> getOrganizationById(@PathVariable Long orgId, HttpServletRequest request) {

		if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
			try {
				logger.info("Enter getOrganizationById");
				return new ResponseEntity<CommonResponse>(new CommonResponse(masterService.getById(orgId), "Successfully get Organization", HttpStatus.OK.value()), HttpStatus.OK);

			} catch (Exception e) {
				logger.error("Error while getting organization!!", e);
				return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} else {
			return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any orgranization for this id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}
	
	@PostMapping(value = "/getOrganizationDetailsForPDF", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrganizationDetailsForPDF(@RequestBody UserOrganisationPdfGenarateRequestResponse genarateRequest, HttpServletRequest request) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(genarateRequest)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse(masterService.getOrganizationDetailsForPDF(genarateRequest), "Successfully get Organization", HttpStatus.OK.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new CommonResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(new CommonResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}
	
	
	@PostMapping(value = "/getOrganizationDetailsByOrgIds", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrganizationDetailsByOrgIds(@RequestBody UserOrganisationPdfGenarateRequestResponse genarateRequest, HttpServletRequest request) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(genarateRequest)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse(masterService.getOrganizationDetailsByOrgIds(genarateRequest), "Successfully get Organization", HttpStatus.OK.value()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new CommonResponse(UsersCommonUtils.NO_DATA_FOUND, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}

		} catch (Exception e) {
			return new ResponseEntity<>(new CommonResponse(UsersCommonUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

//	@RequestMapping(value = "/getAllOfflineOrgByOrgTypeBySchemeId/{orgType}/{schemeId}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
//	public @ResponseBody ResponseEntity<UserResponse> getAllOfflineOrgByOrgTypeBySchemeId(@PathVariable(value = "orgType") Integer orgType, @PathVariable(value = "schemeId") Long schemeId, HttpServletRequest request) {
//		try {
//			List<UserOrganisationMasterResponse> all = masterService.getAllOfflineOrgByOrgTypeBySchemeId(orgType, schemeId);
//			if (all.isEmpty()) {
//				return new ResponseEntity<>(new UserResponse("getAllOfflineOrgByOrgTypeBySchemeId not found by Id !!", HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
//			}
//			return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, all), HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("Exception while get all organization by org type :- " + orgType, e);
//			return new ResponseEntity<>(new UserResponse("Error while fetch all organization list by org type ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//		}
//	}

	@GetMapping(value = "/getAllInActiveOrgList", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<UserResponse> getAllInActiveOrgList() {
		try {
			return new ResponseEntity<>(new UserResponse("Data get successfully", HttpStatus.OK.value(), Boolean.TRUE, masterService.getAllInActiveOrgList()), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception while getAllInActiveOrgList =========> ", e);
			return new ResponseEntity<>(new UserResponse("Error while fetch all inActive organization list", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
	
//	@RequestMapping(value = "/checkOrgStatusByOrgIdAndSchemeIdAndCampainType/{orgId}/{schemeId}/{campainType}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
//	public @ResponseBody ResponseEntity<UserResponse> checkOrgStatusByOrgIdAndSchemeIdAndCampainType(@PathVariable(value = "orgId") Long orgId, @PathVariable(value = "schemeId") Long schemeId
//			, @PathVariable(value = "campainType") Integer campainType, HttpServletRequest request) {
//		try {
//			return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, masterService.checkOrgStatusByOrgIdAndSchemeIdAndCampainType(orgId, schemeId,campainType)), HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("Exception while get checkOrgStatusByOrgIdAndSchemeIdAndCampainType :- " + orgId, e);
//			return new ResponseEntity<>(new UserResponse("Error while fetch checkOrgStatusByOrgIdAndSchemeIdAndCampainType ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//		}
//	}
	
//	@SkipInterceptor
//	@GetMapping("/getLenderMaster/{locale}")
//	public ResponseEntity<UserResponse> getLenderMaster(@PathVariable("locale") String locale) {
//		logger.info("getLoanWithSchemes() started");
//		try {
//			UserResponse res = masterService.getLenderMaster(locale);
//			return new ResponseEntity<>(res, HttpStatus.OK);
//		} catch (Exception e) {
//			logger.error("Exception while getLenderMaster() --->", e);
//			return new ResponseEntity<>(new UserResponse("Error while fetch getLenderMaster() ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//		}
//	}
	
	@GetMapping(value = "/getOrgMasterListByUserTypeId/{userTypeId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrgMasterListByUserTypeId(@PathVariable Long userTypeId,@PathVariable Long schemeId) {
		try {
			logger.info("Enter in fetch Insurer details ------------------>");
			List<Map<String, Object>> orgMasterList = masterService.getOrgMasterListByUserTypeId(userTypeId,schemeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no insurer list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Success", orgMasterList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception in getInsurerList :", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/getOrganisationMstListByUserTypeId/{userTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrganisationMstListByUserTypeId(@PathVariable Long userTypeId) {
		try {
			logger.info("Enter in fetch Insurer details ------------------>");
			List<Map<Long, String>> orgMasterList = masterService.getOrganisationMstListByUserTypeId(userTypeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no insurer list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Success", orgMasterList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception in getInsurerList :", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
