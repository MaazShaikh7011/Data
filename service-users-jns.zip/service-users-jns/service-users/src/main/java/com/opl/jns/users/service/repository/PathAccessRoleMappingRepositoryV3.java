package com.opl.jns.users.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.users.service.domain.PathAccessRoleMapping;


/**
 * @author sandip.bhetariya
 *
 */
@Repository
public interface PathAccessRoleMappingRepositoryV3 extends JpaRepository<PathAccessRoleMapping, Long> {

    // PathAccessRoleMapping findByRoleIdAndIsActiveIsTrue(Long RoleId);

    //	 @Query(value="SELECT PAM.path FROM  users.path_access_role_mapping PARM inner join users.path_access_master PAM on (PAM.id = PARM.path_access_id AND PAM.is_active IS TRUE) WHERE PARM.is_active IS TRUE AND  PARM.role_id=:roleId ;",nativeQuery = true)
//    @Query(value = "CALL spGetAccessPaths(:userId)", nativeQuery = true)
//    List<Map<String, Object>> getAccessPaths(Long userId);

//    @Query("select parm from PathAccessRoleMapping parm ON parm.roleId.roleId =:roleId AND parm.typeId.id =:typeId")
    List<PathAccessRoleMapping> findByRoleIdAndTypeIdAndIsActiveTrue(Long roleId, Long typeId);


//    SELECT PAM.path AS path, PARM.scheme_id AS schemeId FROM users.path_access_role_mapping PARM
//    INNER JOIN users.path_access_master PAM ON PAM.id = PARM.path_access_id AND PAM.is_active
//    WHERE PARM.role_id = @userRoleId and PARM.type_id = @userTypeId AND PARM.is_active = TRUE;
}
