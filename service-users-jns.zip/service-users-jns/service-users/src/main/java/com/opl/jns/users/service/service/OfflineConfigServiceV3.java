package com.opl.jns.users.service.service;

import java.util.List;

import com.opl.jns.users.api.model.OfflineConfigurationProxy;
import com.opl.jns.users.api.model.UserCommonRes;

public interface OfflineConfigServiceV3 {

//	public List<OfflineConfigurationProxy> get(int schemeId, long orgId);
	
//	public UserCommonRes update(OfflineConfigurationProxy configurationProxy);
	
//	public List<OfflineConfigurationProxy> getAudit(int schemeId, long orgId);
	
//	public Boolean checkOfflineConfigrationOrgId(Long schemeId,Long orgId, Integer typeId);
	
}
