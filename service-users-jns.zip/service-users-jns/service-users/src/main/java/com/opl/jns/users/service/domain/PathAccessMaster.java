package com.opl.jns.users.service.domain;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "path_access_master")
public class PathAccessMaster implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "path_access_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "path_access_master_seq_gen", sequenceName = "path_access_master_seq", allocationSize = 1)
	private Long id;
	
//	@Column(name = "page_name", columnDefinition = "varchar(255) default ''")
//	private String pageName;
	
	@Column(name = "componant_name", columnDefinition = "varchar(255) default ''")
	private String componantName;
	
	@Column(name = "path", columnDefinition = "varchar(255) default ''")
	private String path;
	
	@Column(name = "is_admin")
	private String isAdmin;
	
	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "description")
	private String desc;

}
