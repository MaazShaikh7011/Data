package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.users.service.domain.BusinessMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface BusinessMasterRepositoryV3 extends JpaRepository<BusinessMaster, Long> {

	public BusinessMaster findById(Integer businessTypeMasterId);
}
