package com.opl.jns.users.service.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.users.service.domain.UserOrganisationMaster;

/**
 * @author sandip.bhetariya
 *
 */
public interface UserOrganisationMasterRepositoryV3 extends JpaRepository<UserOrganisationMaster, Long> {

	public List<UserOrganisationMaster> findByIsActiveAndOrgTypeOrderByDisplayOrgNameAsc(Boolean isActive, Integer orgType);

	@Query(value = "SELECT u.userOrgId as id,u.displayOrgName as value,u.organisationCode as code  FROM UserOrganisationMaster u WHERE u.userTypeMaster.id =:userTypeId AND isActive=true order by u.displayOrgName asc")
	public List<Map<Long, String>> findByUserTypeMasterIdAndIsActiveTrueOrderByDisplayOrgNameAsc(Long userTypeId);

	@Query(value = "SELECT u.displayOrgName FROM UserOrganisationMaster u WHERE isActive=TRUE AND u.userOrgId=:userOrgId ")
	String getBankName(@Param("userOrgId") Long userOrgId);
	
	@Query(value = "SELECT u FROM UserOrganisationMaster u WHERE isActive=TRUE AND u.userOrgId in(:orgIds) ")
	public List<UserOrganisationMaster> findByIsActiveOrgsByList(@Param("orgIds")  List<Long> orgIds);

//	@Query(value = "SELECT u FROM UserOrganisationMaster u WHERE u.userOrgId in (:orgIds) AND isActive=:isActive AND orgType=:orgType order by u.displayOrgName asc")
//	public List<UserOrganisationMaster> findbyUserOrgIdInAndIsActiveAndOrgTypeOrderByDisplayOrgNameAsc(@Param("orgIds") List<Long> orgIds, @Param("isActive") Boolean isActive, @Param("orgType") Integer orgType);

	UserOrganisationMaster findByUserOrgId(Long userOrgId);

	@Query(value = "SELECT u.imagePath FROM UserOrganisationMaster u WHERE u.isActive=true AND u.userOrgId = :userOrgId")
	String getShortImageByOrgId(Long userOrgId);

	@Query(value = "SELECT userOrgId FROM UserOrganisationMaster WHERE isActive=false")
	List<Long> getInActiveOrgList();
	
	
//	@Query(value = "SELECT lm.id AS id ,lm.value AS displayName FROM `users`.`member_lending_institute_master` lm WHERE lm.lang_code =:locale AND lm.is_active = TRUE",nativeQuery = true)
//	@Query(value = "SELECT lm.id AS id ,lm.value AS displayName FROM MemberLendingInstituteMaster lm WHERE lm.langCode =:locale AND lm.isActive = TRUE")
//	List<Map<String, Object>> getLenderMaster(@Param("locale") String locale);
	
//	@Query(value = "SELECT lim.id AS id ,lim.name_of_lending_institute AS LendingInstitute, lim.type_id AS LenderMaster, lim.bank_url_link AS BankURL FROM `users`.`member_lending_institute` lim WHERE lim.lang_code =:locale AND lim.is_active = TRUE",nativeQuery = true)
//	@Query(value = "SELECT lim.id AS id ,lim.name_of_lending_institute AS LendingInstitute, lim.type_id AS LenderMaster, lim.bank_url_link AS BankURL FROM MemberLendingInstituteMaster lim WHERE lim.langCode =:locale AND lim.isActive = TRUE")
//	List<Map<String, Object>> getLenderInstitute(@Param("locale") String locale);
	
//    @Query(value = "select userOrgId,organisationName from UserOrganisationMaster WHERE user_type_id=:userTypeId")
//    List<Object[]> getOrgMasterListByUserTypeId(@Param("userTypeId") Long userTypeId);
    
//    @Query(value = "select iom.scheme_id from users.insurer_org_mapping iom WHERE iom.scheme_id=:schemeId AND iom.is_active=TRUE",nativeQuery = true)
//    List<Object[]> getOrgMasterListBySchemeId(@Param("schemeId") Long schemeId);
    
//    @Query(value = "select organisationName from UserOrganisationMaster WHERE user_org_id=:userOrgId")
//    List<Object[]> getOrgNameByUserOrgId(@Param("userOrgId") Long userOrgId);
	
//    List<UserOrganisationMaster> findBySchemeIdIdAndUserTypeMasterId(Long schemeId,Long userTypeId);
	
}
