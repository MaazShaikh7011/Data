package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.users.service.domain.UserRoleMaster;

/**
 * @author ravi.thummar
 * Date : 27-09-2023
 */
public interface UserRoleMasterRepositoryV3 extends JpaRepository<UserRoleMaster, Long> {

    UserRoleMaster findByRoleId(Long userRoleId);

}
