package com.opl.jns.users.service.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.api.model.UserOrganisationPdfGenarateRequestResponse;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.users.service.domain.InsureOrgMapping;
import com.opl.jns.users.service.domain.UserOrganisationMaster;
import com.opl.jns.users.service.repository.InsureOrgMappingRepositoryV3;
import com.opl.jns.users.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.users.service.service.UserOrganisationMasterServiceV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;


@Service
@Transactional
public class UserOrganisationMasterServiceImplV3 implements UserOrganisationMasterServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(UserOrganisationMasterServiceImplV3.class.getName());

	@Autowired
	private UserOrganisationMasterRepositoryV3 repository;
	
	@Autowired
	private InsureOrgMappingRepositoryV3 mappingRepositoryV3;

//	@Autowired
//	private OfflineConfigurationRepositoryV3 offlineConfigurationRepository;

	@Override
	public List<UserOrganisationMasterResponse> getAll(Integer orgType) {
		try {
			List<UserOrganisationMaster> orgMasterList = repository.findByIsActiveAndOrgTypeOrderByDisplayOrgNameAsc(Boolean.TRUE, orgType);
			if (!orgMasterList.isEmpty()) {
				List<UserOrganisationMasterResponse> orgResList = new ArrayList<>(orgMasterList.size());
				UserOrganisationMasterResponse orgRes = null;
				for (UserOrganisationMaster orgMaster : orgMasterList) {
					orgRes = new UserOrganisationMasterResponse();
					BeanUtils.copyProperties(orgMaster, orgRes);
					orgRes.setOrganisationName(orgMaster.getDisplayOrgName());

					// 11,9,15,21,22,23,24,26,29,
					orgResList.add(orgRes);
				}
				return orgResList;
			}
		} catch (Exception e) {
			logger.error("Exception while get bank list by org type ->" + orgType, e);
		}
		return Collections.emptyList();
	}

	@Override
	public UserOrganisationMasterResponse getById(Long orgId) {
		UserOrganisationMaster orgMaster = repository.findById(orgId).orElse(null);
		if (orgMaster != null) {
			UserOrganisationMasterResponse orgRes = new UserOrganisationMasterResponse();
			BeanUtils.copyProperties(orgMaster, orgRes);
			return orgRes;
		}
		return null;
	}

	@Cacheable(value = "USERS_FETCH_BANK_NAME_BY_ORG_ID", key = "{#orgId}")
	@Override
	public String getOrganizationName(Long orgId) {
		String orgName = repository.getBankName(orgId);
		if (OPLUtils.isStringEmpty(orgName).isEmpty()) {
			return orgName;
		}
		return orgName;
	}

//	@Override
//	public List<UserOrganisationMasterResponse> getAllOfflineOrgByOrgTypeBySchemeId(Integer orgType, Long schemeId) throws Exception {
//		try {
//			List<Long> findBySchemeMasterIdAndIsActive = offlineConfigurationRepository.findBySchemeMasterIdAndIsActive(schemeId, Boolean.TRUE);
//			if (!OPLUtils.isListNullOrEmpty(findBySchemeMasterIdAndIsActive)) {
//
//				List<UserOrganisationMaster> orgMasterList = repository.findbyUserOrgIdInAndIsActiveAndOrgTypeOrderByDisplayOrgNameAsc(findBySchemeMasterIdAndIsActive, Boolean.TRUE, orgType);
//				if (!orgMasterList.isEmpty()) {
//					List<UserOrganisationMasterResponse> orgResList = new ArrayList<>(orgMasterList.size());
//					UserOrganisationMasterResponse orgRes = null;
//					for (UserOrganisationMaster orgMaster : orgMasterList) {
//						orgRes = new UserOrganisationMasterResponse();
//						BeanUtils.copyProperties(orgMaster, orgRes);
//						orgRes.setOrganisationName(orgMaster.getDisplayOrgName());
//
//						// 11,9,15,21,22,23,24,26,29,
//						orgResList.add(orgRes);
//					}
//					return orgResList;
//				}
//			}
//
//		} catch (Exception e) {
//			logger.error("Exception while get bank list by org type ->" + orgType, e);
//		}
//		return Collections.emptyList();
//	}

	@Override
	public List<Long> getAllInActiveOrgList() {
		try {
			List<Long> inActiveOrgList = repository.getInActiveOrgList();
			if (!OPLUtils.isListNullOrEmpty(inActiveOrgList)) {
				return inActiveOrgList;
			}
		} catch (Exception e) {
			logger.error("Exception while getting inActive Org's ======>", e);
		}
		return Collections.emptyList();
	}

//	@Override
//	public Boolean checkOrgStatusByOrgIdAndSchemeIdAndCampainType(Long orgId, Long schemeId, Integer campainType) throws Exception {
//		try {
//			Optional<OfflineConfiguration> findById = offlineConfigurationRepository.findBySchemeMasterIdAndOrganisationMasterUserOrgIdAndTypeId(schemeId, orgId, campainType,Boolean.FALSE);
//			if (findById.isPresent()) {
//				return findById.get().getIsActive();
//			}
//			return true;
//		} catch (Exception e) {
//
//			return true;
//		}
//	}

//	@Override
//	public UserResponse getLenderMaster(String locale) throws Exception {
//		Map<String, Object> map = new HashMap<>();
//		map.put("lendingMaster", repository.getLenderMaster(locale));
//		map.put("lenderInstitute", repository.getLenderInstitute(locale));
//		return new UserResponse( "Get Partner Bank List",HttpStatus.OK.value(), Boolean.TRUE,map);
//
//	}
	
	 public List<Map<String, Object>> getOrgMasterListByUserTypeId(Long userTypeId,Long schemeId ) {
		 
		 	
		 List<InsureOrgMapping> schemeMaster = null;
		 
		 if(OPLUtils.isObjectNullOrEmpty(schemeId) || (schemeId == SchemeMaster.ALL_SCHEME.getId()) || (schemeId == 0)){
			 schemeMaster = mappingRepositoryV3.findByIsActiveTrueOrderByUserOrganisationMasterOrganisationName();
		 }else {
			 schemeMaster= mappingRepositoryV3.findBySchemeMasterIdAndIsActiveTrueOrderByUserOrganisationMasterOrganisationName(schemeId);
		 }
				
//		 List<UserOrganisationMaster> userOrg = repository.findBySchemeIdIdAndUserTypeMasterId(schemeId,userTypeId);
		 List<UserOrganisationMaster> userOrg = new ArrayList<>();
		 List<Map<String, Object>> mapLst = new ArrayList<>();
		 schemeMaster.stream().forEach(val -> {
			 Map<String, Object> map = new HashMap<>();
			 map.put(UsersCommonUtils.ORGANISATION_CODE, val.getUserOrganisationMaster().getOrganisationCode()); 
 			map.put(UsersCommonUtils.USER_ORG_ID, val.getUserOrganisationMaster().getUserOrgId());
 			map.put(UsersCommonUtils.ORGANISATION_NAME, val.getUserOrganisationMaster().getOrganisationName());
 			mapLst.add(map);
		 });
	        
	        //List<Object[]> orgMaster = repository.getOrgMasterListByUserTypeId(userTypeId);
	        
//	        List<Object[]> orgName = repository.getOrgNameByUserOrgId(schemeMaster.getOrgId());
	        
	        
//	        if (!OPLUtils.isListNullOrEmpty(orgMaster)) {
//	        	orgMaster.forEach(val -> {
//	        			Map<String, Object> map = new HashMap<>();
//	        			map.put(UsersCommonUtils.USER_ORG_ID,
//	        					!OPLUtils.isObjectNullOrEmpty(val) && !OPLUtils.isObjectNullOrEmpty(val[0]) ? val[0] : null);
//	        			map.put(UsersCommonUtils.ORGANISATION_NAME,
//	        					!OPLUtils.isObjectNullOrEmpty(val) && !OPLUtils.isObjectNullOrEmpty(val[1]) ? val[1] : null);
//	        			mapLst.add(map);
//	            });
//	        	if (!OPLUtils.isListNullOrEmpty(orgName)) {
//	            orgName.forEach(name ->{	        			
//	            	Map<String, Object> organizationName = new HashMap<>();
//	            	organizationName.put(UsersCommonUtils.ORG_NAME,
//	            			!OPLUtils.isObjectNullOrEmpty(name) && !OPLUtils.isObjectNullOrEmpty(name[0]) ? name[0] : null);
//	            	mapLst.add(organizationName);
//	            });

//	        }
	        return mapLst;
	    }
	 
	 public List<Map<Long, String>> getOrganisationMstListByUserTypeId(Long userTypeId) {
	        return repository.findByUserTypeMasterIdAndIsActiveTrueOrderByDisplayOrgNameAsc(userTypeId);
	    }
	 
	 @Override
		public UserOrganisationPdfGenarateRequestResponse getOrganizationDetailsForPDF(UserOrganisationPdfGenarateRequestResponse genarateRequest) throws Exception {

			if(!OPLUtils.isObjectNullOrEmpty(genarateRequest.getInsurerOrgId()) && !OPLUtils.isObjectNullOrEmpty(genarateRequest.getOrgId())) {
				for (UserOrganisationMaster orgData : repository.findAllById(Arrays.asList(genarateRequest.getInsurerOrgId(),genarateRequest.getOrgId()))) {
					if (null != orgData && null != orgData.getUserOrgId()) {
						if(orgData.getUserOrgId().equals(genarateRequest.getInsurerOrgId())) {
							genarateRequest.setInsurerdisplayOrgName(orgData.getDisplayOrgName());
							genarateRequest.setInsurerImagePath(orgData.getImagePath());
						}else if(orgData.getUserOrgId().equals(genarateRequest.getOrgId())) {
							genarateRequest.setImagePath(orgData.getImagePath());
							genarateRequest.setNameOfBank(orgData.getDisplayOrgName());
						}
					}
				}
			}
					return genarateRequest;
		}

	@Override
	public List<UserOrganisationMasterResponse> getOrganizationDetailsByOrgIds(UserOrganisationPdfGenarateRequestResponse genarateRequest) throws Exception {
		try {
			List<UserOrganisationMaster> orgMasterList = repository.findByIsActiveOrgsByList(genarateRequest.getOrgIds());
			if (!orgMasterList.isEmpty()) {
				List<UserOrganisationMasterResponse> orgResList = new ArrayList<>(orgMasterList.size());
				UserOrganisationMasterResponse orgRes = null;
				for (UserOrganisationMaster orgMaster : orgMasterList) {
					orgRes = new UserOrganisationMasterResponse();
					BeanUtils.copyProperties(orgMaster, orgRes);
					orgRes.setOrganisationName(orgMaster.getDisplayOrgName());
					orgResList.add(orgRes);
				}
				return orgResList;
			}
		} catch (Exception e) {
			logger.error("Exception while get bank list by org type ->" + genarateRequest.getOrgIds(), e);
		}
		return Collections.emptyList();
	}
}
