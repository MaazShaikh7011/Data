package com.opl.jns.users.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.users.service.domain.UserRoleProductMapping;

/**
 * @author sandip.bhetariya
 *
 */
@Repository
public interface UserRoleProductMappingRepositoryV3 extends JpaRepository<UserRoleProductMapping,Long>{

    @Query("select m from UserRoleProductMapping m where m.user.id =:userId and m.isActive=true group by m.businessTypeId order by businessTypeId desc")
    List<UserRoleProductMapping> list(@Param("userId") Long userId);

    @Query("select m from UserRoleProductMapping m where m.user.id =:userId  and m.isActive=true and m.businessTypeId =:businessTypeId order by m.schemeId")
    List<UserRoleProductMapping> listScheme(@Param("userId") Long userId,@Param("businessTypeId") Long businessTypeId);

//    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.userRoleMaster.roleId =:roleId")
//    UserRoleProductMapping checkExistingRole(@Param("userId") Long user,@Param("roleId") Long roleId);
//
//    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.businessTypeId=:businessTypeId and m.isActive=true")
//    UserRoleProductMapping checkExistingRoleBybusinessType(@Param("userId") Long user,@Param("businessTypeId") Long businessTypeId);
    
    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.isActive=true and m.businessTypeId=:businessTypeId ")
    UserRoleProductMapping get(@Param("userId") Long user,@Param("businessTypeId") Long businessTypeId);

    @Query("select m from UserRoleProductMapping m where m.user.id =:userId and m.isActive=true order by schemeId")
    List<UserRoleProductMapping> listSchemes(@Param("userId") Long userId);

    @Query(value = "CALL spGetProductByUserIdAndBusinessTypeId(:userId, :businessType, :type)", nativeQuery = true)
	String spGetProductByUserIdAndBusinessTypeId(@Param("userId") Long userId, @Param("businessType") Long businessType, @Param("type") Integer type);
}
