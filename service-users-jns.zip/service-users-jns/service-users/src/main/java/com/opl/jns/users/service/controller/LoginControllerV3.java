package com.opl.jns.users.service.controller;

import java.util.Base64;

import jakarta.servlet.http.HttpServletRequest;

import org.jfree.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.LoginResponse;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.users.service.service.UsersServiceV3;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;


/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class LoginControllerV3 {

    private static final Logger logger = LoggerFactory.getLogger(LoginControllerV3.class.getName());

    @Autowired
    private LoginServiceV3 loginService;
    
    @Autowired
    private UsersServiceV3 usersService;

    @Autowired
    private AuthClient authClient;

    @SkipInterceptor
    @PostMapping(value = "/login", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LoginResponse> loginUser(@RequestBody UsersRequest userRequest, HttpServletRequest request) {
    	logger.info("Enter in Login API ------------------>" + userRequest.getEmail()+ "------Mobile----------->" + userRequest.getMobile());

        if ((OPLUtils.isObjectNullOrEmpty(userRequest.getEmail()) && OPLUtils.isObjectNullOrEmpty(userRequest.getMobile()) && OPLUtils.isObjectNullOrEmpty(userRequest.getUserName()))
                || (OPLUtils.isObjectNullOrEmpty(userRequest.getPassword()) && OPLUtils.isObjectNullOrEmpty(userRequest.getOtp()))) {
            logger.info("Email : " + userRequest.getEmail() + " OTP :" + userRequest.getOtp() + " - Email or Password or otp is empty");
            return new ResponseEntity<>(new LoginResponse("It seems an error has been encountered during redirection, kindly register/login to continue your process.", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
        }
        
        if(OPLUtils.isObjectNullOrEmpty(userRequest.getUserType())) {
        	logger.info("UsertypeId is missing in request !!");
        	return new ResponseEntity<>(new LoginResponse("Kindly select usertype for login!!", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);	
        }

        String remoteAddr = "";
        remoteAddr = request.getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = request.getRemoteAddr();
        }
        userRequest.setRemoteAddr(remoteAddr);

        // CHECK LOGIN DATA
        return new ResponseEntity<>(loginService.login(userRequest, remoteAddr), HttpStatus.OK);
    }


    @SkipInterceptor
    @GetMapping(value = "/logoutUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> logoutUser(HttpServletRequest request) throws UserException {

    	logger.info("Enter in Logout User------------------>");
        AuthRequest req = requestAdapter(request);
        if (req == null) {
            logger.info("Logout, Bad Request, If any one of from the above four is null or empty");
            return new ResponseEntity<>(new UserResponse("Invalid Refresh Token and Login token", HttpStatus.BAD_REQUEST.value()),
                    HttpStatus.BAD_REQUEST);
        }
        AuthClientResponse response = authClient.logoutUser(req);
        if (response.isAuthenticate()) {
            logger.info("Logout Successfully : UserName- " + req.getUsername() + " LoginToken-" + req.getLoginToken());
            return new ResponseEntity<>(new UserResponse("Logout Successful", HttpStatus.OK.value()), HttpStatus.OK);
        } else {
            logger.info("Logout, Unauthorized Request, Access token expire or invalid : UserName- " + req.getUsername() + " LoginToken -" + req.getLoginToken());
            return new ResponseEntity<>(new UserResponse("Invalid Token and Username", HttpStatus.UNAUTHORIZED.value()), HttpStatus.UNAUTHORIZED);
        }
    }

    private AuthRequest requestAdapter(HttpServletRequest request) throws UserException {
        String accessToken = request.getHeader(AuthCredentialUtils.REQUEST_HEADER_ACCESS_TOKEN);
        String username = request.getHeader(AuthCredentialUtils.REQUEST_HEADER_USERNAME);
        String refreshToken = request.getHeader(AuthCredentialUtils.REQUEST_HEADER_REFRESH_TOKEN);
        String loginToken = request.getHeader(AuthCredentialUtils.REQUEST_HEADER_LOGIN_TOKEN);

        if (OPLUtils.isObjectNullOrEmpty(accessToken) || OPLUtils.isObjectNullOrEmpty(username) || OPLUtils.isObjectNullOrEmpty(refreshToken) || OPLUtils.isObjectNullOrEmpty(loginToken)) {
            logger.info("Access Token : " + accessToken + " UserName : " + username + " Refresh Token : " + refreshToken + " Login Token : " + loginToken);
            return null;
        }
        AuthRequest req = new AuthRequest();
        req.setUsername(username);
        req.setRefreshToken(refreshToken);
        req.setAccessToken(accessToken);
        req.setLoginToken(Integer.valueOf(loginToken));
        return req;
    }

    @RequestMapping(value = "/accessToken", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthResponse> accessToken(HttpServletRequest request) throws UserException {

        AuthRequest req = requestAdapter(request);

        if (req == null) {
            logger.info("Get AccessToken, Bad Request, If any one of from the above four is null or empty");
            return new ResponseEntity<>(new AuthResponse("Invalid Refresh Token and Login token", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
        }
        AuthResponse response = authClient.getAccessToken(req);
        if (response != null) {
            response.setStatus(HttpStatus.OK.value());
            response.setMessage("AccessToken Generate Successfully");
            logger.info("AccessToken Generate Successfully : UserName- " + req.getUsername() + " REfreshToken :" + response.getRefresh_token() + " LoginToken -" + response.getLoginToken());
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            logger.info("Get AccessToken, Unauthorized Request, Access token expire or invalid : UserName - " + req.getUsername() + " LoginToken :" + req.getLoginToken());
            return new ResponseEntity<>(new AuthResponse("Invalid Refresh Token", HttpStatus.UNAUTHORIZED.value()), HttpStatus.UNAUTHORIZED);
        }
    }


    @PostMapping(value = "/getTokensForClient", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> getTokensForClient(@RequestBody AuthRequest authRequest) {
        if (authRequest.getGrant_type() == null) {
            logger.info("Login Token null when gettoken by login token for Client login");
            return new ResponseEntity<>(new UserResponse(null, "Login Token Null or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
        }
        String token = new String(Base64.getDecoder().decode(authRequest.getGrant_type()));
        if (OPLUtils.isObjectNullOrEmpty(token)) {
            logger.info("GET TOKENS For Client Login, token is empty");
            return new ResponseEntity<>(new UserResponse(null, "Token Not Found" + authRequest.getGrant_type(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
        AuthResponse response = authClient.getTokenByLoginTokenForSidbi(new AuthRequest(Integer.parseInt(token)));
        if (response != null) {
            logger.info("Successfully Get Token For Client Login, Token is:- " + token);
            return new ResponseEntity<>(new UserResponse(response, "Successfully get Token", HttpStatus.OK.value()), HttpStatus.OK);
        } else {
            logger.info("Token Not Found For This Token " + authRequest.getGrant_type());
            return new ResponseEntity<>(new UserResponse(null, "Token Not Found For This Token " + authRequest.getGrant_type(), HttpStatus.OK.value()), HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/send/login/otp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> sendLoginOTP(@RequestBody UsersRequest usersRequest) {
        if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getUserType())) {
            logger.info("Requested data can not be empty OR Invalid Request.");
            return new ResponseEntity<>(new UserResponse("Requested data can not be empty OR Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
        
        if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getCaptchaEnter()) && !OPLUtils.isObjectNullOrEmpty(usersRequest.getCaptchaOriginal())) {
        	if(!usersRequest.getCaptchaEnter().equals(usersRequest.getCaptchaOriginal())) {
    			return new ResponseEntity<UserResponse>(new UserResponse("Invalid Captcha, Please Enter Valid Captcha Code !!", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);	
    		}	
        }
        

        boolean checkMobile = usersService.checkMobile(usersRequest.getMobile(), usersRequest.getUserType());
        if (!checkMobile) {
            logger.warn("Mobile number not found");
            return new ResponseEntity<>(new UserResponse("Mobile Not found Or not active", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }

        Boolean userIsLocked = usersService.userIsLocked(usersRequest);
        if (userIsLocked != null && userIsLocked) {
            return new ResponseEntity<>(new UserResponse("User is blocked", HttpStatus.LOCKED.value()), HttpStatus.OK);
        }
        
        usersRequest = usersService.getUserDetailByMobileOrEmail(usersRequest.getMobile(),null,null, usersRequest.getUserType());
//        String msg= null; // apiRestrictionConfig.checkAPIRestriction("LOGIN_THROUGH_MOBILE", usersRequest.getUserId());
//        if(!SUCCESS.equalsIgnoreCase(msg)){
//			return new ResponseEntity<>(new UserResponse(msg,
//					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//		}
        OTPResponse sendOTP = usersService.sendOTP(usersRequest, UsersUtils.OTP_REQUEST_SIGNUP_TYPE, NotificationType.SMS, JnsNotificationMasterUtil.LOGIN_OTP_SMS); // NotificationMasterAlias.SMS_OTP.getMasterId()
       
		
        if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.OK.value())) {
            logger.info("OTP send Success");
            return new ResponseEntity<>(new UserResponse("Verification Code send Success", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.BAD_REQUEST.value())) {
            logger.info("OTP Already sent.");
            return new ResponseEntity<>(new UserResponse("Verification Code Already Sent on your registered mobile no. Please wait for sometime", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else {
            logger.info("Unable to send Verification Code or invalid User details");
            return new ResponseEntity<>(new UserResponse("Unable to send Verification Code or invalid User details", HttpStatus.BAD_REQUEST.value()),
                    HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/bo/login/otp",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> sendBoLoginOTP(@RequestBody UsersRequest usersRequest) {
        if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getUserType())) {
            logger.info("Requested data can not be empty OR Invalid Request.");
            return new ResponseEntity<>(new UserResponse("Requested data can not be empty OR Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }

        boolean checkEmail = usersService.checkEmailAddress(usersRequest.getEmail(), usersRequest.getUserType());
        if (!checkEmail) {
            logger.warn("Email not found");
            return new ResponseEntity<>(new UserResponse("Email not found Or not active", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }

        usersRequest = usersService.getUserDetailByMobileOrEmail(usersRequest.getMobile(),usersRequest.getEmail(),null, usersRequest.getUserType());
        if(OPLUtils.isObjectNullOrEmpty(usersRequest)) {
        	 logger.warn("Mobile Email not found for user details");
             return new ResponseEntity<>(new UserResponse("Mobile Email not found for user details", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
        
        OTPResponse sendOTP = usersService.sendOTP(usersRequest, UsersUtils.OTP_REQUEST_LOGIN_TYPE, NotificationType.EMAIL,7L);
       Log.info("send Verification code response: "+sendOTP);
        if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.OK.value())) {
            logger.info("Verification code send Success");
            return new ResponseEntity<>(new UserResponse("Verification code sent Successfully", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.BAD_REQUEST.value())) {
            logger.info("Verification code Already sent.");
            return new ResponseEntity<>(new UserResponse("Verification code Already Sent on your registered emailId. Please wait for sometime", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else {
            logger.info("Unable to send Verification code or invalid User details");
            return new ResponseEntity<>(new UserResponse("Unable to send Verification code or invalid User details", HttpStatus.BAD_REQUEST.value()),
                    HttpStatus.OK);
        }
    }
    
    @SkipInterceptor
    @PostMapping(value = "/send/grienvance/otp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> sendLoginOTPGrienvance(@RequestBody UsersRequest usersRequest) {
        if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getUserType())) {
            logger.info("Requested data can not be empty OR Invalid Request.");
            return new ResponseEntity<>(new UserResponse("Requested data can not be empty OR Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
        
        if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getCaptchaEnter()) && !OPLUtils.isObjectNullOrEmpty(usersRequest.getCaptchaOriginal())) {
        	if(!usersRequest.getCaptchaEnter().equals(usersRequest.getCaptchaOriginal())) {
    			return new ResponseEntity<UserResponse>(new UserResponse("Invalid Captcha, Please Enter Valid Captcha Code !!", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);	
    		}	
        }
        OTPResponse sendOTP = usersService.sendOTP(usersRequest, UsersUtils.OTP_REQUEST_SIGNUP_TYPE, NotificationType.SMS, JnsNotificationMasterUtil.SMS_CUST_FORGOT_USERNAME_OTP); // NotificationMasterAlias.SMS_OTP.getMasterId()
        if(sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.ALREADY_REPORTED.value())) {
        	return new ResponseEntity<>(new UserResponse(sendOTP.getMessage(), sendOTP.getStatus()),
                    HttpStatus.OK);
        }
		
        if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.OK.value())) {
            logger.info("OTP send Success");
            return new ResponseEntity<>(new UserResponse("OTP send Success", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else if (sendOTP != null && sendOTP.getStatus() != null && sendOTP.getStatus().equals(HttpStatus.BAD_REQUEST.value())) {
            logger.info("OTP Already sent.");
            return new ResponseEntity<>(new UserResponse("OTP Already Sent on your registered mobile no. Please wait for sometime", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } else {
            logger.info("Unable to send Verification Code or invalid User details");
            return new ResponseEntity<>(new UserResponse("Unable to send Verification Code or invalid User details", HttpStatus.BAD_REQUEST.value()),
                    HttpStatus.OK);
        }
    }
    
    
    @PostMapping(value = "/login/otp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @SkipInterceptor
    public ResponseEntity<LoginResponse> loginUserViaOtp(@RequestBody UsersRequest userRequest, HttpServletRequest request) {
        LoginResponse loginResponse = new LoginResponse();
        if (OPLUtils.isObjectNullOrEmpty(userRequest.getEmail()) || OPLUtils.isObjectNullOrEmpty(userRequest.getOtp()) || OPLUtils.isObjectNullOrEmpty(userRequest.getUserType()) ) {
            logger.warn("Email :- " + userRequest.getEmail() + " OTP :-" + userRequest.getOtp() + " -Email or otp is empty");
            loginResponse.setMessage("Email OR Verification Code is Empty");
            loginResponse.setStatus(HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(loginResponse, HttpStatus.BAD_REQUEST);
        }
        String remoteAddr = "";
        remoteAddr = request.getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = request.getRemoteAddr();
        }

//        UsersRequest existingReqData =
//        boolean checkEmailAddress = usersService.checkEmailAddress(userRequest.getEmail(), userRequest.getUserType());
//        if (checkEmailAddress) {
//            loginResponse.setMessage("Email id is invalid");
//            loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
//            return new ResponseEntity<>(loginResponse, HttpStatus.OK);
//        }
        UsersRequest existingReqData = usersService.getUserDetailByMobileOrEmail(null, userRequest.getEmail(), null, userRequest.getUserType());
        existingReqData.setOtp(userRequest.getOtp());
        existingReqData.setOtpOn(UsersUtils.OTP_REQUEST_LOGIN_TYPE);
        OTPResponse otpResponse = loginService.validateOTP(existingReqData, UsersUtils.OTP_REQUEST_LOGIN_TYPE);
        if (OPLUtils.isObjectNullOrEmpty(otpResponse) || otpResponse.getStatus() == HttpStatus.CONFLICT.value() || otpResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
            loginResponse.setMessage("Invalid or expired Verification Code");
            loginResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
            return new ResponseEntity<>(loginResponse, HttpStatus.OK);
        }else {
        	return new ResponseEntity<>(new LoginResponse(otpResponse.getMessage(),otpResponse.getStatus()), HttpStatus.OK);	
        }
//        AuthResponse response = loginService.callAuthClient(existingReqData,remoteAddr);

//        if (!OPLUtils.isObjectNullOrEmpty(response.getUserId())) {
//            UsersRequest lastAccessApplication = userProfileService.getLastAccessApplication(new UsersRequest(response.getUserId()));
//            if (!OPLUtils.isObjectNullOrEmpty(lastAccessApplication)) {
//                loginResponse.setApplicationId(lastAccessApplication.getLastAccessApplicantId());
//            }
//        }
        // For Campaign
//        try {
//
//            CampaignUserMappingProxy campaignUserMappingProxy = new CampaignUserMappingProxy();
//            campaignUserMappingProxy.setUserId(response.getUserId());
//            campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(userRequest.getCampaignMasterId()));
//            campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy);
//
//
////            logger.info("User Id for Campaign Code :" + response.getUserId());
////            CampaignRequest campaignRequest = new CampaignRequest();
////            campaignRequest.setCode(userRequest.getCampaignCode());
////            campaignRequest.setUserId(response.getUserId());
////            campaignDetailService.save(campaignRequest);
////            // set last campion
////            userRequest.setUserId(response.getUserId());
////            usersService.setLastCampaignCode(userRequest);
////            List<String> list = campaignDetailService.getCampainCodesByUserId(response.getUserId());
////            if (OPLUtils.isListNullOrEmpty(list)) {
////                logger.warn("user is not from campaign :- userId - " + response.getUserId());
////            } else {
////                logger.info("User Id for Campaign Code :-" + response.getUserId() + " Codes : " + list.toString());
////                loginResponse.(list);
////            }
//        } catch (Exception e) {
//            logger.error("Error while getting Campaign Code by UserId :" + response.getUserId());
//        }
//        loginResponse.setUserOrgId(response.getUserOrgId());

		
	}
	
	@PostMapping("/updateCustomerInTokenMapping")
	public ResponseEntity<CommonResponse> updateCustomerInTokenMapping(@RequestBody AuthRequest authReq, HttpServletRequest servletRequest) {
		logger.info("INSIDE updateCustomerInTokenMapping() ----->");
		try {
			if (OPLUtils.isObjectNullOrEmpty(authReq.getClientUserId())) {
				return new ResponseEntity<>(new CommonResponse("Request Parameter Null Or Empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.BAD_REQUEST);
			}
			loginService.updateCustomerInTokenMapping(authReq, servletRequest);
			return new ResponseEntity<>(new CommonResponse("Customer id updated in token mapping", HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Throw Exception While updateCustomerInTokenMapping() : ", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * For checking token is valid or not 
	 * and that will be checked in Auth intercepter
	 */
	@GetMapping("/isTokenValid")
	public ResponseEntity<CommonResponse> isTokenValid() {
		logger.info("INSIDE isTokenValid() ----->");
		try {
			return new ResponseEntity<>(new CommonResponse("Token is valid", HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Throw Exception While isTokenValid() : ", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

//	@SkipInterceptor
//	@GetMapping(value = "/getLoginUserTypes")
//	public ResponseEntity<List<LoginUserTypeMaster>> getLoginUserTypes(){
//
//		List<LoginUserTypeMaster> userTypeMaster = loginService.getLoginUserTypes();
//
//		if(userTypeMaster == null) {
//			 ResponseEntity.status(HttpStatus.NOT_FOUND);
//		}
//
//		return ResponseEntity.status(HttpStatus.OK).body(userTypeMaster);
//	}
	
	@PostMapping("/createPartnerTokenMapping")
	public ResponseEntity<CommonResponse> createPartnerTokenMapping(@RequestBody UsersRequest userRequest,
			HttpServletRequest request) {
		logger.info("INSIDE createPartnerTokenMapping() ----->");

		try {
			if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())||OPLUtils.isObjectNullOrEmpty(userRequest.getUserType())) {
				return new ResponseEntity<>(
						new CommonResponse("Required fields is missing in request !!", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.BAD_REQUEST);
			}

			String remoteAddr = "";
			remoteAddr = request.getHeader("X-FORWARDED-FOR");
			if (remoteAddr == null || "".equals(remoteAddr)) {
				remoteAddr = request.getRemoteAddr();
			}
			userRequest.setRemoteAddr(remoteAddr);

			return new ResponseEntity<>(new CommonResponse(loginService.createPartnerTokenMapping(userRequest, remoteAddr),
					"getToken", HttpStatus.OK.value()), HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<>(
					new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
			}

	}


	
	
}