package com.opl.jns.users.service.repository.impl;

import com.opl.jns.users.service.repository.CommonRepository;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;
import java.sql.Clob;

/**
 * @author ravi.thummar
 * Date : 21-06-2023
 */
@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {


    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public String getSchemeByUserIdBusinessId(Long userId, Long businessType, Integer type) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS + ".get_product_by_user_id_and_business_type_id");
        storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("typeid", Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businesstypeid", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result", String.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("userid", !OPLUtils.isObjectNullOrEmpty(userId) ? userId : 0);
        storedProcedureQuery.setParameter("typeid", type);
        storedProcedureQuery.setParameter("businesstypeid", businessType);
        storedProcedureQuery.execute();
        return (String) storedProcedureQuery.getOutputParameterValue("result");
    }

    @Override
    public String getMenuListByUserId(Long userId) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS + ".get_menu_for_banker");
        storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("userid", userId);
        storedProcedureQuery.execute();
        return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
    }
}
