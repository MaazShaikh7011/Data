package com.opl.jns.users.service.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.BankUserDetailReq;
import com.opl.jns.users.api.model.BankUserDetailRes;
import com.opl.jns.users.api.model.UserNotificationDetailsReq;
import com.opl.jns.users.api.model.UserNotificationDetailsRes;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.model.UserTypeRequest;
import com.opl.jns.users.api.model.UsersRequest;

/**
 * @author jaimin.darji
 */
public interface UsersServiceV3 {

    boolean checkEmailAddress(String email, Long userTypeId);

    boolean checkMobile(String mobileNumber, Long userTypeId);

    boolean checkEmailMobileNumber(String email, String mobileNumber, Long userTypeId);

    UsersRequest forRegistrationProcess(UsersRequest usersRequest) throws UserException;

    boolean resendOTP(UsersRequest usersRequest);

    UsersRequest getUserDetailByMobileOrEmail(String mobileNumber, String email, Long userId, Long userTypeId);

    String generateEncryptString(Date signUp, String email, Long userTypeId);

    UsersRequest validateOtp(Long id, String otpValue, String fsLoanParam, boolean fi, Integer otpVerificationType);

    Boolean isSamePassword(UsersRequest usersRequest);
    
    Boolean isSamePasswordForBorrower(UsersRequest usersRequest);
    
    boolean inactiveUserSessionByUserId(Long userId);

    UsersRequest saveLastThreePassword(UsersRequest usersRequest);

    UsersRequest savePasswordChangeLog(UsersRequest usersRequest);

//    boolean setLastCampaignCode(UsersRequest usersRequest);

    Boolean userIsLocked(UsersRequest userRequest);

    OTPResponse sendOTP(UsersRequest usersRequest, int otpRequestType, NotificationType notificationType, Long notificationMasterId);
    
    List<UserTypeRequest> getUserTypeMasterList(UserTypeRequest request);

//    String getAllValidations(Long businessType) throws Exception;

//    String getMenuForBanker(Integer schemeId,Long userId);
    
    String getAllMenuForBanker(Long userId);
    
    public UserResponse sendEmailForForgotPassword(String email,String originDomain,Long userTypeId,Long notiMasterId);

    public UserResponse sendMobileForForgotPassword(UsersRequest usersRequest);
    
    public UserResponse forgotUserName(UsersRequest usersRequest);
    
    public List<String> getUserPermissions(UsersRequest usersRequest);
    
    public Boolean updateRoleAndBusinessTypeId(Long userRoleId, Integer lastBusinessTypeId, Long userId);
    
    public UserNotificationDetailsRes getUserNotificationDetails(UserNotificationDetailsReq notiDetailsReq) throws Exception;

    public UsersRequest getEmailMobile(Long userId);
	
	List<BankUserDetailRes> getUserDetailsByOrgIdBranchIdRoleId(BankUserDetailReq bankUserDetailReq);

    public ResponseEntity<UserResponse> sendOtpOnEmailMobileUpdate(UsersRequest usersRequest);
    
    public Boolean updateEmailMobile(UsersRequest usersRequest);

//	void updateFacilitatorUser(FacilitatorReq facilitatorReq);

//	UsersRequest registerUserByFacilitator(UsersRequest usersRequest) throws Exception;

	boolean isCurrentPasswordWrong(UsersRequest usersRequest);

	List<UsersRequest> getUserDetailsByListOfIds(List<Long> userIds) throws Exception;
	
//	public void updateLangAudit(LangAuditRequest langAudit);
	
	List<Map<String, Object>> getAccessPaths(AuthClientResponse authClientResponse);

	 Long getFirstUserIdByOrgIdAndHoRoleID(Long orgId, Long roleId);

	 public UserResponse updatePasswordWithEmail(UsersRequest usersRequest);

    UserResponse updateMobileByUserId(UsersRequest usersRequest);

	UserResponse updateEmailByUserId(UsersRequest usersRequest);
}
