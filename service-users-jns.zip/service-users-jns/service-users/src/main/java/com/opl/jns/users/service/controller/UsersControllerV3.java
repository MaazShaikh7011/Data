package com.opl.jns.users.service.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import jakarta.servlet.ServletRequest;
import jakarta.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.users.api.exception.UserException;
import com.opl.jns.users.api.model.BankUserDetailReq;
import com.opl.jns.users.api.model.BankUserDetailRes;
import com.opl.jns.users.api.model.UserCommonRes;
import com.opl.jns.users.api.model.UserNotificationDetailsReq;
import com.opl.jns.users.api.model.UserNotificationDetailsRes;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.model.UserTypeRequest;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.users.service.service.UsersServiceV3;
import com.opl.jns.utils.common.AESEncryptionUtilitySBI;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;




/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class UsersControllerV3 {

	private static final Logger logger = LoggerFactory.getLogger(UsersControllerV3.class.getName());

    public static final String SOMETHING_WENT_WRONG = "Something went wrong..!";
    public static final String REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST = "Requested data can not be empty OR Invalid Request.";
    public static final String SUCCESS="SUCCESS";

    @Autowired
    private UsersServiceV3 usersService;
    @Autowired
    private LoginServiceV3 loginService;
//    @Autowired
//    private CampaignDetailService campaignDetailService;


	@SkipInterceptor
	@PostMapping(value = "/register",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> userRegistration(
			@RequestBody UsersRequest usersRequest) throws UserException {
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.isTermsAccepted())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getUserType())) {
			logger.info(REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST);
			return new ResponseEntity<>(
					new UserResponse(REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}

		boolean isEmailExists = usersService.checkEmailAddress(usersRequest.getEmail(), usersRequest.getUserType());
		boolean isMobileNumberExists = usersService.checkEmailMobileNumber(usersRequest.getEmail(),
				usersRequest.getMobile(), usersRequest.getUserType());
		if (isEmailExists && isMobileNumberExists) {
			logger.warn("Email Address & Mobile Number already in use.Please try another." + usersRequest.toString());
			return new ResponseEntity<>(
					new UserResponse("Email Address & Mobile Number already in use.Please try another.",
							HttpStatus.CONFLICT.value()),
					HttpStatus.OK);
		} else if (isEmailExists) {
			logger.info("Email Address already in use.Please try another : " + usersRequest.toString());
			return new ResponseEntity<>(
					new UserResponse("Email Address already in use.Please try another.", HttpStatus.CONFLICT.value()),
					HttpStatus.OK);
		} else if (isMobileNumberExists) {
			logger.warn("Mobile Number already in use.Please try another." + usersRequest.toString());
			return new ResponseEntity<>(
					new UserResponse("Mobile Number already in use.Please try another.", HttpStatus.CONFLICT.value()),
					HttpStatus.OK);
		}
		try {
			usersRequest = usersService.forRegistrationProcess(usersRequest);
			if (usersRequest == null) {
				logger.info(SOMETHING_WENT_WRONG);
				return new ResponseEntity<>(
						new UserResponse(SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()),
						HttpStatus.OK);
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(usersRequest.getOtpStatus())
						&& usersRequest.getOtpStatus().equals(HttpStatus.BAD_REQUEST.value())) {
					usersRequest.setOtpMsg("OTP Already Sent on your registered mobile no. Please wait for sometime");
				}
				if (usersRequest.isOtpVerified() && usersRequest.getUserType() == com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()) {
					try {
						String encryptUrl = usersService.generateEncryptString(usersRequest.getSignUpDate(),
								usersRequest.getEmail(), usersRequest.getUserType());
//                        String encryptedEmail = AESEncryptionUtilitySBI.encrypt(usersRequest.getEmail(), true);
						usersRequest.setVerificationUrl(encryptUrl);
					} catch (Exception e) {
						logger.info("Error while encrypting email ==> {} ::: {}", usersRequest.getApplicationId(), e);
					}
				}
				logger.warn("Registration has been done successfully." + usersRequest.toString());
				return new ResponseEntity<>(new UserResponse(usersRequest.getId(), usersRequest,
						"Registration has been done successfully.", HttpStatus.OK.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Email address already exists..! {}", e);
			return new ResponseEntity<>(
					new UserResponse("Email Address already in use.Please try another. ", HttpStatus.CONFLICT.value()),
					HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/otp/resend", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> resendOTP(@RequestBody UsersRequest usersRequest)
			throws UserException {
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getId())) {
			logger.info("Requested data can not be empty.Invalid Request." + usersRequest);
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		boolean isOTPResend = usersService.resendOTP(usersRequest);
		if (isOTPResend == true) {
			logger.info("OTP Successfully sent.");
			return new ResponseEntity<>(new UserResponse("OTP Successfully sent.", HttpStatus.OK.value()),
					HttpStatus.OK);
		} else {
			logger.error("Unable to send Verification Code as invalid user details.");
			return new ResponseEntity<>(
					new UserResponse("Unable to send Verification Code as invalid user details.", HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/otp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> validateOtp(@RequestBody UsersRequest usersRequest) {
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getId())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getOtp())) {
			logger.info("Requested data can not be empty.Invalid Request." + usersRequest);
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		UsersRequest response = usersService.validateOtp(usersRequest.getId(), usersRequest.getOtp(), "", false,
				usersRequest.getOtpVerificationType());
		if (response.isOtpVerified() || response.isEmailVerified()) {
			if (response.getUserType() == com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()) {
				String encryptUrl = usersService.generateEncryptString(response.getSignUpDate(), response.getEmail(),
						response.getUserType());
				response.setUrlEncrypt(encryptUrl);
			}
			logger.info("OTP has been verified successfully." + usersRequest.toString());
			return new ResponseEntity<UserResponse>(new UserResponse(usersRequest.getId(), response,
					"OTP has been verified successfully.", HttpStatus.OK.value()), HttpStatus.OK);
		} else {
			logger.warn("Please enter a valid OTP." + usersRequest.toString());
			return new ResponseEntity<>(new UserResponse("Please enter a valid OTP.", HttpStatus.CONFLICT.value()),
					HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/set/password", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AuthResponse> setPwdToCompleteSignup(
			@RequestBody UsersRequest usersRequest, HttpServletRequest request) {
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getVerificationUrl())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getPassword())) {
			logger.info("Requested data can not be empty.Invalid Request.");
			return new ResponseEntity<>(new AuthResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		String email = null;
		try {
			String emailAndDate = AESEncryptionUtilitySBI.decrypt(usersRequest.getVerificationUrl(), true);
			if (emailAndDate.contains("$")) {
//                String email$ = emailAndDate.substring(0, emailAndDate.lastIndexOf('$'));
//                email = email$.substring(0, email$.lastIndexOf('$'));
//                usersRequest.setEmail(email);

				// Check link expired based on modified date
				String[] decodedUrlArray = emailAndDate.split(Pattern.quote("$"));
				if (decodedUrlArray.length >= 3) {
					email = decodedUrlArray[0];
					usersRequest.setEmail(email);
					String dateTmp = decodedUrlArray[1];
					Long userTypeId = Long.valueOf(decodedUrlArray[3].toString());
					usersRequest.setUserType(userTypeId);
					Date emailModifiedDate = null;
					try {
						DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						emailModifiedDate = format.parse(dateTmp);
					} catch (ParseException e) {
						logger.error("Error while parse date {}", e);
					}
					UsersRequest usersDetails = usersService.getUserDetailByMobileOrEmail(null, email, null,
							userTypeId);
					if (emailModifiedDate != null) {
						long timediff = usersDetails.getSignUpDate().getTime() - emailModifiedDate.getTime();
						logger.info("Email date: " + dateTmp + " Timediff: " + timediff);
						if (OPLUtils.isObjectListNull(usersDetails)
								|| usersDetails.getSignUpDate().getTime() != emailModifiedDate.getTime()) {
							logger.info(":: Modification date and email date are not matched.");
							logger.info("Link Expired");
							return new ResponseEntity<>(
									new AuthResponse("No data found.or invalid email", HttpStatus.BAD_REQUEST.value()),
									HttpStatus.OK);
						}
					}
				}
				// Check link expired based on modified date end
			}
			String password = usersRequest.getPassword();
			usersRequest.setEmail(email);
			UsersRequest usersDetails = usersService.getUserDetailByMobileOrEmail(null, email, null,
					usersRequest.getUserType());

			if ((!OPLUtils.isObjectNullOrEmpty(usersDetails) && !usersDetails.isOtpVerified())) {
				logger.warn("OTP is not verified for email = " + email);
				return new ResponseEntity<>(new AuthResponse("OTP is not verified", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			if (!UsersUtils.isPatternMatch(usersRequest.getPassword(), UsersUtils.PASSWARD_PATTERN)) {
				return new ResponseEntity<>(new AuthResponse("Password Does not match with the pattern.(Ex. Test@123)",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			// Find from last 3 password
			if (usersService.isSamePassword(usersRequest)) {
				return new ResponseEntity<>(new AuthResponse("Password should not be same as last 3 password.",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			// Save in last 3 password and update password
			usersRequest = usersService.saveLastThreePassword(usersRequest);

			if (usersRequest != null) {
				// INACTIVE ALL PREVIOS SESSION BY USERID
				if(usersRequest.getUserId() != null) {
					usersService.inactiveUserSessionByUserId(usersRequest.getUserId());	
				}
				
				// password change log
				usersService.savePasswordChangeLog(usersRequest);
				logger.info("" + usersRequest.toString());
				String remoteAddr = "";
				remoteAddr = request.getHeader("X-FORWARDED-FOR");
				if (remoteAddr == null || "".equals(remoteAddr)) {
					remoteAddr = request.getRemoteAddr();
				}
				usersRequest.setPassword(password);
				AuthResponse response = loginService.callAuthClient(usersRequest, remoteAddr);
				if (usersRequest.getUserType() == com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId()) {
					response.setUserId(usersRequest.getUserId());
					// For Campaign
//					try {
//						List<String> list = campaignDetailService.getCampainCodesByUserId(usersRequest.getUserId());
//						if (OPLUtils.isListNullOrEmpty(list)) {
//							logger.info("user is not from campaign===>userId=====>" + usersRequest.getUserId());
//						} else {
//							logger.info("User Id for Campaign Code : " + usersRequest.getUserId() + " Codes :- "
//									+ list.toString());
//							response.setCampaignCode(list);
//						}
//					} catch (Exception e) {
//						logger.error("Error while getting Campaign Code by UserId");
//					}
				}
				response.setEmail(usersRequest.getEmail());
				return new ResponseEntity<>(response, HttpStatus.OK);

			} else {
				logger.info("No data found.or invalid email");
				return new ResponseEntity<>(
						new AuthResponse("No data found.or invalid email", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Something went wrong while setting password.. {}", e);
			return new ResponseEntity<>(new AuthResponse("Invalid Email", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}

	}

	@PostMapping(value = "/set/passwordAfterLogin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> setPwdAfterLogin(@RequestBody UsersRequest usersRequest, 
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getPassword())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getConfirmPassword())
				|| (!OPLUtils.isObjectNullOrEmpty(usersRequest.getIsPasswordSet()) && usersRequest.getIsPasswordSet() && OPLUtils.isObjectNullOrEmpty(usersRequest.getOldPassword()))) {
			logger.info("Requested data can not be empty.Invalid Request.");
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		// CONFIRM AND MAIN PASS CHECK
		if(!(usersRequest.getPassword().toString().equals(usersRequest.getConfirmPassword().toString()))) {
			logger.info("Password does not match.Please enter valid password.");
			return new ResponseEntity<>(new UserResponse("Password does not match.Please enter valid password.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		
		usersRequest.setUserId(authResponse.getUserId());
		usersRequest.setEmail(authResponse.getEmail());
		usersRequest.setMobile(authResponse.getMobile());
		usersRequest.setUserType(authResponse.getUserType());

		if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getOldPassword())) {			
			//ADDED THE FLAG FOR ALLOW USER TO SET PASSWORD AT 1st TIME
			if((OPLUtils.isObjectNullOrEmpty(usersRequest.getIsPasswordSet()) || usersRequest.getIsPasswordSet())
					&& usersService.isCurrentPasswordWrong(usersRequest)) {
				logger.info("Current Password is Wrong.");
				return new ResponseEntity<>(new UserResponse("Current Password is Wrong.",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
		}
		if (!UsersUtils.isPatternMatch(usersRequest.getPassword(), UsersUtils.PASSWARD_PATTERN)) {
			return new ResponseEntity<>(new UserResponse("Password Does not match with the pattern.(Ex. Test@123)",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		// Find from last 3 password
		if (usersService.isSamePassword(usersRequest)) {
			return new ResponseEntity<>(
					new UserResponse("Password should not be same as last 3 password.", HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		// Save in last 3 password and update password
		usersRequest = usersService.saveLastThreePassword(usersRequest);
		if (usersRequest != null) {
			// password change log
			usersService.savePasswordChangeLog(usersRequest);
			return new ResponseEntity<>(new UserResponse("Password Changes Successfully !!", HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} else {
			logger.info("Old password does not match.");
			return new ResponseEntity<>(
					new UserResponse("Old password does not match.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
	}

	@SuppressWarnings("unchecked")
	@SkipInterceptor
	@PostMapping(value = "/email/linkVerification", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> linkVerificationForrgotPassword(
			@RequestBody UsersRequest usersRequest) {

		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getVerificationUrl())) {
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		String decodedString = "";
		try {
			decodedString = AESEncryptionUtilitySBI.decrypt(usersRequest.getVerificationUrl(), true);
		} catch (Exception e) {
			logger.error("Error while decrypt {}", e);
		}

		String[] decodedUrlArray = decodedString.split(Pattern.quote("$"));
		if (decodedUrlArray.length < 3) {
			logger.info("Requested data can not be empty.Invalid Request." + usersRequest);
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		String email = decodedUrlArray[0];
		String date = decodedUrlArray[1];
		Long userTypeId = Long.valueOf(decodedUrlArray[3].toString());

		Date emailModifiedDate = null;
		try {
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			emailModifiedDate = format.parse(date);
		} catch (ParseException e) {
			logger.error("Error while parse date {}", e);
		}
		JSONObject response = new JSONObject();
		response.put("isLinkExpired", false);
		UsersRequest usersRequest1 = usersService.getUserDetailByMobileOrEmail(null, email, null, userTypeId);
		if (emailModifiedDate != null) {
			long timediff = usersRequest1.getSignUpDate().getTime() - emailModifiedDate.getTime();
			logger.info("Email date: " + date + " Timediff: " + timediff);
			if (OPLUtils.isObjectListNull(usersRequest1)
					|| usersRequest1.getSignUpDate().getTime() != emailModifiedDate.getTime()) {
				logger.info(":: Modification date and email date are not matched.");
				linkExpired(response);
			}
			return new ResponseEntity<>(new UserResponse(response, "success", HttpStatus.OK.value()), HttpStatus.OK);
		} else {
			logger.info(":: Email date is null.");
			return linkExpired(response);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/email/forgotpasswordEncrypt", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> verifyEmailEncrypt(@RequestBody String encryptString,
			ServletRequest servletRequest) {
		UsersRequest usersRequest = null;
		try {
			usersRequest = MultipleJSONObjectHelper.getObjectFromString(encryptString,
					UsersRequest.class);
		} catch (Exception e) {
			logger.info("Error while Decrypt forgot password text -------------------------> ", e);
		}
		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())
				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getDomain())) {
			logger.info(REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST);
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
							HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		if(OPLUtils.isObjectNullOrEmpty(usersRequest.getNotificationMasterId())) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
							HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		// API RESTRICTION FOR MAX 10 ATTEMPT FORGOT PASSWORD LINK
//		 String msg= null; // apiRestrictionConfig.checkAPIRestriction("FORGOT_PASSWORD_LINK", usersRequest.getEmail());
//	 		if(!SUCCESS.equalsIgnoreCase(msg)){
//	 			 return new ResponseEntity<UserResponse>(
//	                      new UserResponse(msg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),
//	                      HttpStatus.OK);
//	 		}
		return new ResponseEntity<UserResponse>(
				usersService.sendEmailForForgotPassword(usersRequest.getEmail(), usersRequest.getDomain(),usersRequest.getUserType(),usersRequest.getNotificationMasterId()),
				HttpStatus.OK);
	}
	
	@SkipInterceptor
	@PostMapping(value = "/cust/forgotpassword", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> sendMobileForForgotPassword(@RequestBody String encryptString,
			ServletRequest servletRequest) {
		UsersRequest usersRequest = null;
		try {
			usersRequest = MultipleJSONObjectHelper.getObjectFromString(encryptString,
					UsersRequest.class);
		} catch (Exception e) {
			logger.info("Error while Decrypt forgot password text -------------------------> ", e);
		}
		if (OPLUtils.isObjectNullOrEmpty(usersRequest.getNotificationMasterId())) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
							HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}

		return new ResponseEntity<UserResponse>(usersService.sendMobileForForgotPassword(usersRequest),
				HttpStatus.OK);
	}
	
	//send userName only to your mobile 
	@SkipInterceptor
	@PostMapping(value = "/cust/forgotUserName", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> forgotUserName(@RequestBody UsersRequest usersRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(usersRequest.getNotificationMasterId())) {
				return new ResponseEntity<UserResponse>(
						new UserResponse(UsersCommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<UserResponse>(usersService.forgotUserName(usersRequest),
					HttpStatus.OK);

		} catch (Exception e) {
			logger.info("Error while sent userName  forgot password text -------------------------> ", e);
			return new ResponseEntity<>(
					new UserResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}
	}
//    @SkipInterceptor
//    @RequestMapping(value = "/email/changePassword/{userId}", method = RequestMethod.POST, consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	  public ResponseEntity<UserResponse> changePassword(@RequestBody String encryptString,@PathVariable("userId") Long userId ,ServletRequest servletRequest) {
//	        UsersRequest usersRequest=null;
//	        try {
//	             usersRequest = MultipleJSONObjectHelper.getObjectFromString(CommonUtils.descryptText(encryptString), UsersRequest.class);
//	        } catch (Exception e) {
//	          logger.info("Error while Decrypt forgot password text -------------------------> ",e);
//	        }
//	        if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())
//	            || OPLUtils.isObjectListNull(usersRequest.getDomain())) {
//	          logger.info(REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST);
//	          return new ResponseEntity<UserResponse>(new UserResponse(CommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
//	              HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//	        }
//	        return new ResponseEntity<UserResponse>(usersService.sendEmailForForgotPassword(usersRequest.getEmail(),usersRequest.getDomain()), HttpStatus.OK);
//	    }

	@SuppressWarnings("unchecked")
	private ResponseEntity<UserResponse> linkExpired(JSONObject response) {
		response.put("isLinkExpired", true);
		logger.info("linkExpired() :: The link has expired.");
		return new ResponseEntity<>(
				new UserResponse(response, "The link has expired. Please try again.", HttpStatus.BAD_REQUEST.value()),
				HttpStatus.OK);
	}


	// Below 2 methods commented because of new campaign service

//	@PostMapping(value = { "/setLastCampaignCode" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserResponse> setLastCampaignCode(
//			@RequestBody UsersRequest usersRequest,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse)
//			throws UserException {
//		if (!OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())) {
//			usersRequest.setUserId(authResponse.getUserId());
//		}
////		if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getCampaignCode())
////				|| OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId())) {
////			return new ResponseEntity<>(new UserResponse("Invalid data", HttpStatus.BAD_REQUEST.value()),
////					HttpStatus.OK);
////		}
//		boolean isUpdated = usersService.setLastCampaignCode(usersRequest);
//		if (isUpdated) {
//			logger.info("Campaign code updated.");
//			return new ResponseEntity<UserResponse>(
//					new UserResponse(isUpdated, "Campaign code updated.", HttpStatus.OK.value()), HttpStatus.OK);
//		} else {
//			logger.info("Campaign code not updated.");
//			return new ResponseEntity<UserResponse>(
//					new UserResponse(isUpdated, "Campaign code not updated.", HttpStatus.OK.value()), HttpStatus.OK);
//		}
//	}


	// NOT USING THHIS METHOD
//	@PostMapping(value = "/save-code", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserResponse> saveCampaignCode(
//			@RequestBody CampaignRequest campaignRequest,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//		try {
//			if (campaignRequest.getUserId() == null) {
//				campaignRequest.setUserId(authResponse.getUserId());
//			}
//			if (OPLUtils.isObjectListNull(campaignRequest, campaignRequest.getUserId(), campaignRequest.getCode())) {
//				return new ResponseEntity<>(new UserResponse(
//						"End saveCampaignDetail() & Request Object Or UserId Or Code must not be Empty",
//						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
////			campaignDetailService.save(campaignRequest);
//			return new ResponseEntity<>(new UserResponse("Successfully Saved", HttpStatus.OK.value()), HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<>(
//					new UserResponse("Error while save camp code", HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.OK);
//		}
//	}

	@GetMapping(value = "/getUserDetailsById/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getUserDetailsById(@PathVariable Long userId) {
		try {
			UsersRequest userDetails = usersService.getUserDetailByMobileOrEmail(null, null, userId, null);
			if (userDetails == null) {
				return new ResponseEntity<>(
						new UserResponse("UsersDetails not found by Id !!", HttpStatus.OK.value(), Boolean.FALSE),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(
					new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, userDetails),
					HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse("Error while fetch user details by user id :- " + userId,
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
	
	@PostMapping(value = "/getUserDetailsByListOfIds", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<UserResponse> getUserDetailsByListOfIds(@RequestBody List<Long> userIds) {
		logger.info("enter in getUserDetailsByListOfIds=========");
		try {
			if (OPLUtils.isListNullOrEmpty(userIds)) {
				logger.info("Bad Request  in getUserDetailsByListOfIds=========");
				return new ResponseEntity<>(new UserResponse("Requested data can not be null", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, usersService.getUserDetailsByListOfIds(userIds)), HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse("Error while fetch user details ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}
	

	@SkipInterceptor
	@PostMapping(value = "/getUserTypeMasterList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getUserTypeMasterList(
			@RequestBody UserTypeRequest userTypeReq) {
		try {
			return new ResponseEntity<>(new UserResponse("Successfully Fetched", HttpStatus.OK.value(), Boolean.TRUE,
					usersService.getUserTypeMasterList(userTypeReq)), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(new UserResponse("Error while get user type master list ",
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

//	@SkipInterceptor
//	@GetMapping(value = "/getAllValidations/{businessType}")
//	public ResponseEntity<UserResponse> getAllValidations(@PathVariable("businessType") Long businessType) {
//		try {
//			return new ResponseEntity<>(new UserResponse(usersService.getAllValidations(businessType),
//					"Successfully Get Data", HttpStatus.OK.value()), HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<>(
//					new UserResponse("Error While get all validations", HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.OK);
//		}
//	}

//	@GetMapping(value = "/getMenuForBanker/{schemeId}")
//	public ResponseEntity<UserResponse> getMenuForBanker(@PathVariable("schemeId") Integer schemeId,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//		try {
//
//			return new ResponseEntity<>(
//					new UserResponse(usersService.getMenuForBanker(schemeId, authClientResponse.getUserId()),
//							"Successfully Get Data", HttpStatus.OK.value()),
//					HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<>(
//					new UserResponse("Error While getting menu list", HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.OK);
//		}
//	}
	
	@GetMapping(value = "/getAllMenuForBanker")
	public ResponseEntity<UserResponse> getAllMenuForBanker(@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			return new ResponseEntity<>(
					new UserResponse(usersService.getAllMenuForBanker(authClientResponse.getUserId()),
							"Successfully Get Data", HttpStatus.OK.value()),
					HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new UserResponse("Error While getting menu list", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}
	}

//	@PostMapping(value = "/getUserPermissions", consumes = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserResponse> getUserPermissions(@RequestBody UsersRequest usersRequest,
//			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//		logger.info("Enter getUserPermissions ");
//		try {
//			Long orgId = authClientResponse.getUserOrgId();
////			orgId = 16l;
//			if (OPLUtils.isObjectNullOrEmpty(usersRequest)
//					|| OPLUtils.isObjectNullOrEmpty(usersRequest.getUserRoleIdString())
//					|| OPLUtils.isObjectNullOrEmpty(usersRequest.getLoanTypeIdString())
//					|| OPLUtils.isObjectNullOrEmpty(orgId)
//					|| OPLUtils.isObjectNullOrEmpty(usersRequest.getSchemeId())) {
//				return new ResponseEntity<UserResponse>(
//						new UserResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
//			usersRequest.setUserOrgId(orgId);
//			return new ResponseEntity<UserResponse>(new UserResponse(usersService.getUserPermissions(usersRequest),
//					"Successfully", HttpStatus.OK.value()), HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<UserResponse>(
//					new UserResponse("Something went wrong.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//		}
//	}
	// For Admin Panel
	@PostMapping(value = "/getAdminPermissions", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getAdminPermissions(@RequestBody UsersRequest usersRequest) {
		logger.info("Enter getAdminPermissions ");
		try {
			if (OPLUtils.isObjectNullOrEmpty(usersRequest)
					|| OPLUtils.isObjectNullOrEmpty(usersRequest.getUserRoleIdString())) {
				return new ResponseEntity<UserResponse>(
						new UserResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			usersRequest.setUserOrgId(0l);
			usersRequest.setLoanTypeIdString("0");
			usersRequest.setSchemeId(0l);
			return new ResponseEntity<UserResponse>(new UserResponse(usersService.getUserPermissions(usersRequest),
					"Successfully", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<UserResponse>(
					new UserResponse("Something went wrong.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getUserDetailsById", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getUserDetailsById(
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			UsersRequest userDetails = usersService.getUserDetailByMobileOrEmail(null, null,
					authClientResponse.getUserId(), null);
			if (userDetails == null) {
				return new ResponseEntity<>(new UserResponse("UsersDetails not found by Id !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),HttpStatus.OK);
			}
			userDetails.setPassword(null);
			return new ResponseEntity<>(
					new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(), Boolean.TRUE, userDetails),
					HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new UserResponse("Error while fetch user details by user id :- " + authClientResponse.getUserId(),
							HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}
	}

	@GetMapping(value = "/updateRoleAndBusinessTypeId/{roleId}/{businessTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> updateRoleAndBusinessTypeId(@PathVariable Long roleId,
			@PathVariable Integer businessTypeId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			Boolean updateRoleAndBusinessTypeId = usersService.updateRoleAndBusinessTypeId(roleId, businessTypeId,
					authClientResponse.getUserId());
			if (!updateRoleAndBusinessTypeId) {
				return new ResponseEntity<>(new UserResponse("Not updated, Invalid user details found !!",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}
			return new ResponseEntity<>(
					new UserResponse("Successfully Updated !!", HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception while update userRole and businesstypeId ", e);
			return new ResponseEntity<>(new UserResponse("Error while update role and businesstype id",
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getUserNotificationDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getUserNotificationDetails(
			@RequestBody UserNotificationDetailsReq userNotificationReq) {
		try {
			UserNotificationDetailsRes userDetailsRes = usersService.getUserNotificationDetails(userNotificationReq);
			if (userDetailsRes == null) {
				return new ResponseEntity<>(
						new UserResponse("UsersDetails not found !!", HttpStatus.OK.value(), Boolean.FALSE),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(),
						Boolean.TRUE, userDetailsRes), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception while get user notificationDetails ", e);
			return new ResponseEntity<>(new UserResponse("Error while get User Notification details.",
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

	@PostMapping(value = "/get/emailmobile", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getEmailMobile(@RequestBody UsersRequest request,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		UsersRequest userRequest = null;
		if (request.getId() != null) {
			userRequest = usersService.getEmailMobile(request.getId());
		} else if(!OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserId())){
			userRequest = usersService.getEmailMobile(authClientResponse.getUserId());
		} else {
			return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY_INVALID_REQUEST,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

		if (userRequest != null) {
			logger.info("User's Detail.-->" + userRequest);
			return new ResponseEntity<UserResponse>(
					new UserResponse(userRequest, "User's Details.", HttpStatus.OK.value()), HttpStatus.OK);
		} else {
			return new ResponseEntity<UserResponse>(
					new UserResponse("No email address & mobile number found.Invalid Request.",
							HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
	}
	
	@PostMapping(value = "/getBankUserDetailsByOrgIdBranchIdRoleId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getBankUserDetails(@RequestBody BankUserDetailReq benBankUserDetailReq) {
		try {
			List<BankUserDetailRes> bankUserDetailRes = usersService.getUserDetailsByOrgIdBranchIdRoleId(benBankUserDetailReq);
			if (bankUserDetailRes == null) {
				return new ResponseEntity<>(
						new UserResponse("UsersDetails not found !!", HttpStatus.OK.value(), Boolean.FALSE),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new UserResponse("Successfully Fetched Details", HttpStatus.OK.value(),
						Boolean.TRUE, bankUserDetailRes), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception while get user notificationDetails ", e);
			return new ResponseEntity<>(new UserResponse("Error while get User Notification details.",
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

	@PostMapping(value = "/otp/emailMobileUpdate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> emailMobileUpdate(@RequestBody UsersRequest usersRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse)
			throws UserException {
		if(OPLUtils.isObjectNullOrEmpty(authClientResponse) || OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserId())){
			logger.info("UserId should not be null or empty.");
			return new ResponseEntity<>(new UserResponse("UserId should not be null or empty.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		usersRequest.setId(authClientResponse.getUserId());
		if (usersRequest == null || (OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()) && OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()))) {
			logger.info("Requested data can not be empty.Invalid Request." + usersRequest);
			return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		String msg= null; // apiRestrictionConfig.checkAPIRestriction("UPDATE_EMAIL_MOBILE_PROFILE", usersRequest.getId());
		if(!SUCCESS.equalsIgnoreCase(msg)){
			return new ResponseEntity<>(new UserResponse(msg,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		return usersService.sendOtpOnEmailMobileUpdate(usersRequest);
	}


    @PostMapping(value = "/verify/updateEmailMobile", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponse> verifyAndUpdateMobile(@RequestBody UsersRequest usersRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse)
            throws UserException {
        usersRequest.setId(authClientResponse.getUserId());
        if (usersRequest == null || OPLUtils.isObjectNullOrEmpty(usersRequest.getOtp())
                || OPLUtils.isObjectNullOrEmpty(usersRequest.getId()) || (OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()) && OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()))) {
            logger.info("Requested data can not be empty.Invalid Request." + usersRequest);
            return new ResponseEntity<>(new UserResponse("Requested data can not be empty.Invalid Request.",
                    HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }

        if(!OPLUtils.isObjectNullOrEmpty(authClientResponse.getEmail())){
			usersRequest.setEmail(authClientResponse.getEmail());
		}
        Integer otpReqType = 0;
        if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())){
        	otpReqType = UsersUtils.OTP_REQUEST_UPDATE_MOBILE_TYPE;
		}else if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())){
			otpReqType = UsersUtils.OTP_REQUEST_EMAIL_TYPE;
			usersRequest.setOtpOn(UsersUtils.OTP_REQUEST_EMAIL_TYPE);
		}
        OTPResponse otpResponse = loginService.validateOTP(usersRequest,otpReqType);
        if (OPLUtils.isObjectNullOrEmpty(otpResponse) || otpResponse.getStatus() == 409 || otpResponse.getStatus() == 400) {
            logger.warn("Invalid or expired Verification Code");
            return new ResponseEntity<>(
                    new UserResponse("Invalid or expired Verification Code !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),
                    HttpStatus.OK);
        }
        Boolean isMobileUpdated = usersService.updateEmailMobile(usersRequest);
        if(isMobileUpdated){
			logger.info("Mobile number/Email address updated successfully.");
			return new ResponseEntity<UserResponse>(
					new UserResponse(isMobileUpdated, "Details successfully updated.", HttpStatus.OK.value()), HttpStatus.OK);
		}
		logger.warn("Mobile number/Email address not updated.");
		return new ResponseEntity<UserResponse>(
				new UserResponse(isMobileUpdated, "Details not updated.", HttpStatus.OK.value()), HttpStatus.OK);
    }
    
//    @PostMapping(value = "/updateFacilitatorUser", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<UserResponse> updateFacilitatorUser(@RequestBody FacilitatorReq facilitatorReq) {
//      try {
//        if (OPLUtils.isObjectNullOrEmpty(facilitatorReq.getFacilitatorId()) || OPLUtils.isObjectNullOrEmpty(facilitatorReq.getUserId())) {
//          logger.info("Invalid Request. --- {}", facilitatorReq);
//          return new ResponseEntity<>(new UserResponse("Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
//        }
//        usersService.updateFacilitatorUser(facilitatorReq);
//        return new ResponseEntity<>(new UserResponse("User mapped by facilitator.", HttpStatus.OK.value()), HttpStatus.OK);
//      } catch (Exception e) {
//        logger.error("Exception while update Facilitator User ", e);
//        return new ResponseEntity<>(new UserResponse("Exception while update Facilitator User ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
//      }
//    }
    
//    @PostMapping(value = "/registerUserByFacilitator", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<UserResponse> registerUserByFacilitator(@RequestBody UsersRequest usersRequest) {
//      try {
//        if (OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())) {
//          logger.info("Email or Mobile missing.Invalid Request. --- {}", usersRequest);
//          return new ResponseEntity<>(new UserResponse("Email or Mobile missing.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
//        }
//		usersRequest = usersService.registerUserByFacilitator(usersRequest);
//        return new ResponseEntity<>(new UserResponse(usersRequest, "User added by facilitator.", HttpStatus.OK.value()), HttpStatus.OK);
//      } catch (Exception e) {
//        logger.error("Exception while regiterUserByFacilitator()", e);
//        return new ResponseEntity<>(new UserResponse("Exception while regiterUserByFacilitator() ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
//      }
//    }
	
//	 @PostMapping(value = "/updateLangAudit", produces = MediaType.APPLICATION_JSON_VALUE)
//	    public ResponseEntity<UserResponse> updateLangAudit(@RequestBody LangAuditRequest langRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//	      try {
//	    	langRequest.setUserId(authClientResponse.getUserId());
//	        if (OPLUtils.isObjectNullOrEmpty(langRequest.getLanguage()) || (OPLUtils.isObjectNullOrEmpty(langRequest.getApplicationId()) && OPLUtils.isObjectNullOrEmpty(langRequest.getUserId()))) {
//	          logger.info("Application or UserId missing.Invalid Request. --- {}", langRequest);
//	          return new ResponseEntity<>(new UserResponse("Application Id or UserId or Language missing.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
//	        }
//	        usersService.updateLangAudit(langRequest);
//	        return new ResponseEntity<>(new UserResponse(langRequest, "update Language Audit.", HttpStatus.OK.value()), HttpStatus.OK);
//	      } catch (Exception e) {
//	        logger.error("Exception while regiterUserByFacilitator()", e);
//	        return new ResponseEntity<>(new UserResponse("Exception while Language Audit ", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
//	      }
//	    }
	 
	 @GetMapping(value = "/getAccessPaths", produces = MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<UserResponse> getAccessPaths(@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		 try {
			 if (OPLUtils.isObjectNullOrEmpty(authClientResponse)
					 || OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserId())) {
				 return new ResponseEntity<UserResponse>(new UserResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			 }
			 return new ResponseEntity<>(new UserResponse("Successfully Found !!", HttpStatus.OK.value(),
					 Boolean.TRUE, usersService.getAccessPaths(authClientResponse)), HttpStatus.OK);

		 } catch (Exception e) {
			 logger.error("Exception while getUserPath List", e);
			 return new ResponseEntity<>(new UserResponse("Error while getUserPath List",
					 HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		 }
	 }
	 
		@GetMapping(value = "/getFirstUserIdByOrgIdAndHoRoleID/{orgId}/{roleId}", produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<UserCommonRes> getBranchCode(@PathVariable Long orgId,@PathVariable Long roleId,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
			try {
			logger.info("inside getFirstUserIdByOrgIdAndHoRoleID --------------->");
			  Long userId = usersService.getFirstUserIdByOrgIdAndHoRoleID(orgId,roleId);
				if (userId == null) {
					return new ResponseEntity<UserCommonRes>(new UserCommonRes("Data not found.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
				} else {
					return new ResponseEntity<UserCommonRes>(new UserCommonRes("Successfully get data!!", HttpStatus.OK.value(), userId), HttpStatus.OK);
				}

			} catch (Exception e) {
				return new ResponseEntity<UserCommonRes>(new UserCommonRes("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}
		
		
	    @PostMapping(value = "/updatePasswordWithEmail", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<UserResponse> updatePasswordWithEmail(@RequestBody UsersRequest usersRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
	        if (OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId()) && OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()) &&  OPLUtils.isObjectNullOrEmpty(usersRequest.getPassword() )) {
	            return new ResponseEntity<UserResponse>(new UserResponse("Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
	        }
	        try {
	        	return new ResponseEntity<UserResponse>(usersService.updatePasswordWithEmail(usersRequest), HttpStatus.OK);
	        } catch (Exception e) {
	            logger.error("Error while updatePasswordWithEmail!!");
	            return new ResponseEntity<UserResponse>(new UserResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
	        }
	
	    }

	@PostMapping(value = "/updateMobileByUserId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> updateMobileByUserId(@RequestBody UsersRequest usersRequest) {
		if (OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile())) {
			return new ResponseEntity<>(new UserResponse("Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			return new ResponseEntity<>(usersService.updateMobileByUserId(usersRequest), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updatePasswordWithEmail!!");
			return new ResponseEntity<>(new UserResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}
	
	@PostMapping(value = "/updateEmailByUserId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> updateEmailByUserId(@RequestBody UsersRequest usersRequest) {
		if (OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail())) {
			return new ResponseEntity<>(new UserResponse("Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			return new ResponseEntity<>(usersService.updateEmailByUserId(usersRequest), HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updateEmailByUserId!!");
			return new ResponseEntity<>(new UserResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}
}
