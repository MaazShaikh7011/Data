package com.opl.jns.users.service.controller;

import java.util.regex.Pattern;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.users.api.model.LoginResponse;
import com.opl.jns.users.api.model.SignUpRequest;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.api.utils.UsersUtils;
import com.opl.jns.users.service.service.CaptchaServiceV3;
import com.opl.jns.users.service.service.LoginServiceV3;
import com.opl.jns.users.service.service.SignUpServiceV3;
import com.opl.jns.users.service.service.UsersServiceV3;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/v3/signup")
public class SignUpControllerV3 {

	public static final String SUCCESS="SUCCESS";
	
	@Autowired
	private CaptchaServiceV3 captchaService;

	@Autowired
	private SignUpServiceV3 signUpService;

	@Autowired
	private LoginServiceV3 loginService;
	
	@Autowired
	private UsersServiceV3 usersService;
	
	@SkipInterceptor
	@PostMapping(value = "/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> singup(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getMobile())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Please Enter Your Mobile Number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			/*if(!configProperties.getValue(LoadTestingEnum.TESTING_MODE_ON_OFF.getKey()).equals(LoadTestingEnum.TESTING_MODE.getKey())) {
				if(OPLUtils.isObjectNullOrEmpty(signUpReq.getCaptchaEnter())) {
					return new ResponseEntity<CommonResponse>(new CommonResponse("Please Enter Captcha For Verification", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
				}
				if(OPLUtils.isObjectNullOrEmpty(signUpReq.getCaptchaOriginal())) {
					return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Request Parameter Null Or Empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
				}
				if(!signUpReq.getCaptchaEnter().equals(signUpReq.getCaptchaOriginal())) {
					return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Captcha, Please Enter Valid Captcha Code !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
				}
			}*/
			
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getNotificationMasterId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, NotificationMasterId Null Or Empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getCaptchaOriginal()) || OPLUtils.isObjectNullOrEmpty(signUpReq.getCaptchaEnter())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Request Parameter Null Or Empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(!signUpReq.getCaptchaEnter().equals(signUpReq.getCaptchaOriginal())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Captcha, Please Enter Valid Captcha Code !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getUserType())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Request Parameter Null Or Empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getIsTermsAccepted())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Please Accept Privacy Policy, Term & Conditions and Disclaimers", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			
			return new ResponseEntity<CommonResponse>(signUpService.signup(signUpReq), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while Register New User -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/CustReg", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> diySignup(@RequestBody SignUpRequest signUpRequest, HttpServletRequest httpServletRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(signUpRequest.getUsername())) {
				return new ResponseEntity<>(new LoginResponse("Please Enter Your UserName", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			} else if (!Pattern.matches("^[a-zA-Z][a-zA-Z0-9]*$", signUpRequest.getUsername())) {
				return new ResponseEntity<>(new LoginResponse("Please Enter Valid UserName", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			
			if (OPLUtils.isObjectNullOrEmpty(signUpRequest.getPassword())) {
				return new ResponseEntity<>(new LoginResponse("Please Enter Your Password", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			String remoteAddr = "";
			remoteAddr = httpServletRequest.getHeader("X-FORWARDED-FOR");
			if (remoteAddr == null || "".equals(remoteAddr)) {
				remoteAddr = httpServletRequest.getRemoteAddr();
			}
			signUpRequest.setRemoteAddr(remoteAddr);
			signUpRequest.setEmail(signUpRequest.getUsername().toLowerCase() + "@diy.com");

			// Creating User
			CommonResponse commonResponse = signUpService.diySignup(signUpRequest);

			if (commonResponse.getFlag() && commonResponse.getStatus() == HttpStatus.OK.value()) {
				UsersRequest UsersRequest = new UsersRequest();
				UsersRequest.setEmail(null);
				UsersRequest.setUserName(signUpRequest.getUsername());
				UsersRequest.setPassword(signUpRequest.getPassword());
				UsersRequest.setUserType(com.opl.jns.utils.enums.UserTypeMaster.FUNDSEEKER.getId());
				return new ResponseEntity<>(loginService.login(UsersRequest, signUpRequest.getRemoteAddr()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(commonResponse, HttpStatus.valueOf(HttpStatus.OK.value()));
			}
		} catch (Exception e) {
			log.error("Exception while Register New User -> ", e);
		}
		return new ResponseEntity<>(
				new LoginResponse("The application has encountered some error, please try after some time !!",
						HttpStatus.INTERNAL_SERVER_ERROR.value()),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PostMapping(value = "/checkMobile", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> checkMobile(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getMobile())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			return new ResponseEntity<CommonResponse>(signUpService.checkMobile(signUpReq), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while checkMobile -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@SkipInterceptor
	@PostMapping(value = "/verifyOTP", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> verifyOTP(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getOtpType())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, OTP type is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getOtp())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, OTP is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			return new ResponseEntity<CommonResponse>(signUpService.verifyOTP(signUpReq), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while OTP Verification -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@SkipInterceptor
	@PostMapping(value = "/sendEmailOTP", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> sendEmailOTP(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getEmail())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Please Enter Your Email Address", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getOtpType())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getNotificationMasterId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, NotificationMasterId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
//			String msg= null; // apiRestrictionConfig.checkAPIRestriction("SEND_SING_UP_EMAIL_OTP",signUpReq.getUserId());
//			if(!SUCCESS.equalsIgnoreCase(msg)){
//				return new ResponseEntity<CommonResponse>(new CommonResponse(msg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
//			}
			return new ResponseEntity<CommonResponse>(signUpService.sendEmailOTP(signUpReq), HttpStatus.OK);
		} catch (DataIntegrityViolationException e) {
			log.error("Duplicate email found", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Email address already in use.Please try another.", HttpStatus.BAD_REQUEST.value(),
					Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while Send Email for OTP Verification -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@SkipInterceptor
	@PostMapping(value = "/resendMobileOTP", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> resendMobileOTP(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getMobile())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Please Enter Your Mobile Number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			boolean isSent = signUpService.sendMobileOTP(signUpReq);
			if(isSent) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("OTP sent successfully !!", HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);	
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while Send Email for OTP Verification -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	@SkipInterceptor
	@PostMapping(value = "/setPass", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> setPass(@RequestBody UsersRequest usersRequest, HttpServletRequest request) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(usersRequest.getPassword()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getConfirmPassword())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Password is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(!UsersUtils.isPatternMatch(usersRequest.getPassword(), UsersUtils.PASSWARD_PATTERN)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Password Does not match with the pattern.(Ex. Test@123)", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(!usersRequest.getPassword().equals(usersRequest.getConfirmPassword())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems you have not enter same password and confirm password !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			String remoteAddr = "";
		    remoteAddr = request.getHeader("X-FORWARDED-FOR");
		    if (remoteAddr == null || "".equals(remoteAddr)) {
		    	remoteAddr = request.getRemoteAddr();
		    }
			// Find from last 3 password
			if (usersService.isSamePasswordForBorrower(usersRequest)) {
				return new ResponseEntity<>(
						new CommonResponse("Password should not be same as last 3 password.", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
		    usersRequest.setRemoteAddr(remoteAddr);
		    CommonResponse res = signUpService.setPassword(usersRequest);
		    if(res.getFlag()) {
		    	res.setData(signUpService.callAuthClient(usersRequest));
		    }
			return new ResponseEntity<CommonResponse>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while set password during registration -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@SkipInterceptor
	@PostMapping(value = "/skipEmailVerification", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> skipEmailVerification(@RequestBody UsersRequest usersRequest, HttpServletRequest request) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(usersRequest.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			String remoteAddr = "";
		    remoteAddr = request.getHeader("X-FORWARDED-FOR");
		    if (remoteAddr == null || "".equals(remoteAddr)) {
		    	remoteAddr = request.getRemoteAddr();
		    }
		    usersRequest.setRemoteAddr(remoteAddr);
		    CommonResponse res = signUpService.skipForEmailVerification(usersRequest);
		    if(res.getFlag()) {
		    	res.setData(signUpService.callAuthClient(usersRequest));
		    }
			return new ResponseEntity<CommonResponse>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while skip email verification during registration -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@SkipInterceptor
	@GetMapping(value = "/captcha/gen", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> generateCaptcha() {
		log.info("Enter in Generate Captcha --> ");
		return new ResponseEntity<CommonResponse>(captchaService.generateCaptcha(), HttpStatus.OK);
	}
	
//	@PostMapping(value = "/getFacilitatorTokens", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> getFacilitatorTokens(@RequestBody FacilitatorTokenReq facilitatorTokenReq) {
//		log.info("Enter in get Facilitator Tokens--> ");
//		return new ResponseEntity<>(signUpService.getFacilitatorTokens(facilitatorTokenReq), HttpStatus.OK);
//	}


//	@SkipInterceptor
//	@PostMapping(value = "/preScreenSignUp", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> preScreenSignUp(@RequestBody UsersRequest usersRequest) { // , HttpServletRequest request
//		try {
//			if(OPLUtils.isObjectNullOrEmpty(usersRequest.getMobile()) || OPLUtils.isObjectNullOrEmpty(usersRequest.getRequiredAutoRegistration())) {
//				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Mobile or RequiredAutoRegistration is must be in request parameter", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			} else if(!OPLUtils.isObjectNullOrEmpty(usersRequest.getEmail()) && OPLUtils.isObjectNullOrEmpty(usersRequest.getPassword())) {
//				log.info("password not found while creating user by email Id");
//				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Password must be in request parameter", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
//			return new ResponseEntity<CommonResponse>(signUpService.preScreenSignUp(usersRequest), HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while skip email verification during registration -> ", e);
//			return new ResponseEntity<CommonResponse>(
//					new CommonResponse("The application has encountered some error, please try after some time !!",
//							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	
	
	@SkipInterceptor
	@PostMapping(value = "/sendMobileEmailOTP", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> sendMobileEmailOTP(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getEmail()) && OPLUtils.isObjectNullOrEmpty(signUpReq.getMobile())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request,Email Address or Mobile Number is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getUserId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, UserId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getSchemeId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, schemeId is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getSmsNotiMasterId()) &&  OPLUtils.isObjectNullOrEmpty(signUpReq.getEmailNotiMasterId())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, Atlist one NotificationMasterId must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			CommonResponse sendOTP = signUpService.sendMobileEmailOTP(signUpReq);

			if(!OPLUtils.isObjectNullOrEmpty(sendOTP.getData()) && sendOTP.getStatus() == 200) {
				return new ResponseEntity<CommonResponse>(new CommonResponse(sendOTP.getData(),"OTP sent successfully !!", HttpStatus.OK.value()), HttpStatus.OK);	
			}
			
			return new ResponseEntity<CommonResponse>(new CommonResponse("OTP not sent successfully.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
		} catch (DataIntegrityViolationException e) {
			log.error("Duplicate email found", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Email address already in use.Please try another.", HttpStatus.BAD_REQUEST.value(),
					Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while Send Email for OTP Verification -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@SkipInterceptor
	@PostMapping(value = "/grienvanceVerifyOTP", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> grienvanceVerifyOTP(@RequestBody SignUpRequest signUpReq) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getOtpType())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, OTP type is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			if(OPLUtils.isObjectNullOrEmpty(signUpReq.getOtp())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Invalid Request, OTP is must be in request parameter", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);	
			}
			return new ResponseEntity<CommonResponse>(signUpService.grienvanceVerifyOTP(signUpReq), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while OTP Verification -> ", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("The application has encountered some error, please try after some time !!",
							HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
