package com.opl.jns.users.service.domain;

import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.UserEncryptAESUtility;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_token_mapping", indexes = {
		@Index(columnList = "user_name,active", name = DBNameConstant.JNS_USERS + "_usrtknmp_usrnm_actv_idx"),
		@Index(columnList = "user_name,refresh_token,login_token,active", name = DBNameConstant.JNS_USERS
				+ "_usrtknmp_usrn_ref_lgn_actv_idx"),
		@Index(columnList = "user_name,access_token,login_token,active", name = DBNameConstant.JNS_USERS
				+ "_usrtknmp_usrn_acc_lgn_actv_idx"),
		@Index(columnList = "user_id", name = DBNameConstant.JNS_USERS + "_usrtknmp_userid_idx"),
		@Index(columnList = "login_token,active", name = DBNameConstant.JNS_USERS + "_usrtknmp_lgn_actv_idx") })
public class UserTokenMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_token_mapping_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_token_mapping_seq_gen", sequenceName = "user_token_mapping_seq", allocationSize = 1)
	private Long id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "user_name", columnDefinition = "varchar(255) default ''")
	@Convert(converter = UserEncryptAESUtility.class)
	private String userName;

	@Column(name = "user_type")
	private Long userType;

	@Column(name = "user_branch_id")
	private Long userBranchId;

	@Column(name = "user_role_id")
	private Long userRoleId;

	@Column(name = "refresh_token", columnDefinition = "varchar(100) default ''")
	private String refreshToken;

	@Column(name = "access_token", columnDefinition = "varchar(100) default ''")
	private String accessToken;

	@Column(name = "login_token")
	private Integer loginToken;

	@Column(name = "expires_in", columnDefinition = "varchar(255) default ''")
	private String expiresIn;

	@Column(name = "active")
	private Boolean active;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "login_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date loginDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "logout_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date logoutDate;

	@Column(name = "user_ip", columnDefinition = "varchar(100) default ''")
	private String userIp;

	@Column(name = "user_browser", columnDefinition = "varchar(100) default ''")
	private String userBrowser;

	@Column(name = "domain_isactive")
	private Boolean domainIsactive;

	@Column(name = "user_org_id")
	private Long userOrgId;

	@Column(name = "imei_no", columnDefinition = "varchar(45) default ''")
	private String imeiNo;

	@Column(name = "mobile_os", columnDefinition = "varchar(45) default ''")
	private String mobileOs;

	@Column(name = "model_no", columnDefinition = "varchar(45) default ''")
	private String modelNo;

	@Column(name = "os_version", columnDefinition = "varchar(45) default ''")
	private String osVersion;

	@Column(name = "app_version", columnDefinition = "varchar(45) default ''")
	private String appVersion;

	@Column(name = "browser_version", columnDefinition = "varchar(50) default ''")
	private String browserVersion;

	@Column(name = "device", columnDefinition = "varchar(50) default ''")
	private String device;

	@Column(name = "device_type", columnDefinition = "varchar(50) default ''")
	private String deviceType;

	@Column(name = "device_os", columnDefinition = "varchar(100) default ''")
	private String deviceOs;

	@Column(name = "device_os_version", columnDefinition = "varchar(50) default ''")
	private String deviceOsVersion;

	@Column(name = "user_agent", columnDefinition = "varchar(255) default ''")
	private String userAgent;

	@Column(name = "campaign_code", columnDefinition = "varchar(255) default ''")
	private String campaignCode;

	@Column(name = "campaign_master_id")
	private Long campaignMasterId;

	@Column(name = "is_mobile_login")
	private Boolean isMobileLogin;

	@Column(name = "mobile_fcm_token", columnDefinition = "varchar(50) default ''")
	private String mobileFcmToken;

	@Column(name = "client_user_id")
	private Long clientUserId;

}
