package com.opl.jns.users.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.users.service.domain.InsureOrgMapping;

public interface InsureOrgMappingRepositoryV3 extends JpaRepository<InsureOrgMapping, Long> {

	List<InsureOrgMapping> findBySchemeMasterIdAndIsActiveTrueOrderByUserOrganisationMasterOrganisationName(Long schemeId);
	
	List<InsureOrgMapping> findByIsActiveTrueOrderByUserOrganisationMasterOrganisationName();
}
