package com.opl.jns.users.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.users.service.domain.BranchProductMapping;

import java.util.Set;

/**
 * @author sandip.bhetariya
 *
 */
public interface  BranchProductMappingRepositoryV3 extends JpaRepository<BranchProductMapping, Long> {

    // BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
//    @Query("SELECT b.branchId FROM BranchProductMapping b WHERE  b.userOrgId =:orgId and b.schTypeId =:schemeId and b.isActive = true")
//    Set<Long> getByOrgIdAndSchemeId(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId);
//
//    // BranchProductMapping ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
//    @Query("SELECT b FROM BranchProductMapping b WHERE b.isActive = true and schTypeId =:schemeId and branchId=:branchId")
//    BranchProductMapping getByOrgIdAndSchemeIdAndBranchCode(@Param("schemeId") Long schemeId ,@Param("branchId") Long branchId);
}