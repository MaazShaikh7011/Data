package com.opl.jns.users.service.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_type_master",indexes = {
		@Index(columnList = "is_active,is_display_on_login",name = DBNameConstant.JNS_USERS+"_IS_ACTIVE_IS_DISPLAY_ON_LOGIN"),
		@Index(columnList = "is_display_on_login",name = DBNameConstant.JNS_USERS+"_IS_DISPLAY_ON_LOGIN")
})
public class UserTypeMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_type_master_user_management_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_type_master_management_seq_gen", sequenceName = "user_type_master_management_seq", allocationSize = 1)
	private Long id;

	@Column(columnDefinition = "varchar(250) default ''")
	private String code;

	@Column(name = "created_by")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(columnDefinition = "varchar(500) default ''")
	private String description;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "is_display_on_login")
	private Boolean isDisplayOnLogin;

	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(columnDefinition = "varchar(200) default ''")
	private String name;

	public UserTypeMaster(Long id) {
		this.id = id;
	}
// bi-directional many-to-one association to User
//	@OneToMany(mappedBy = "userTypeMaster")
//	private List<User> users;

}