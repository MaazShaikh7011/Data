package com.opl.jns.users.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.users.api.model.UserResponse;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.users.service.repository.CommonRepository;
import com.opl.jns.users.service.service.UserRoleProductMappingServiceV3;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/v3/roleProductMap")
public class UserRoleProductMappingControllerV3 {

	@Autowired
	private UserRoleProductMappingServiceV3 userRoleProductMappingService;

	@Autowired
	private CommonRepository commonRepository;

	
	@GetMapping(value = "/getProductByUserId/{type}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getProductByUserId(@PathVariable Integer type, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		if (authClientResponse == null || authClientResponse.getUserId() == null) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			UserResponse userResponse = new UserResponse();
			userResponse.setData(userRoleProductMappingService.getSchemeByUserIdBusinessId(authClientResponse.getUserId(), null, type));
			userResponse.setStatus(HttpStatus.OK.value());
			userResponse.setMessage("Successfully fetched role product mapping list !!");
			log.info("out /getRoleMapping/{} {}", authClientResponse.getUserId());
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get RoleProduct Mapping ---------->", e);
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}
	}
	
//	@SkipInterceptor
	@GetMapping(value = "/getSchemeByUserIdBusinessId/{businessType}/{typeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getSchemeByUserIdBusinessId(@PathVariable Long businessType,@PathVariable Integer typeId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {

//		if (authClientResponse == null || authClientResponse.getUserId() == null|| businessType == null || typeId == null) {
//			return new ResponseEntity<UserResponse>(
//					new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//		}
		try {
			String productList = commonRepository.getSchemeByUserIdBusinessId(authClientResponse.getUserId(), businessType, typeId);
			UserResponse userResponse = new UserResponse();
			userResponse.setData(productList);
			userResponse.setStatus(HttpStatus.OK.value());
			userResponse.setMessage("Successfully fetched role product mapping list !!");
			log.info("out /getRoleMapping/{} {}", authClientResponse.getUserId());
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get RoleProduct Mapping ---------->", e);
			return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	
	@GetMapping(value = "/getByUserId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getRoleMappind(
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {

		if (authClientResponse == null || authClientResponse.getUserId() == null) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			UserResponse userResponse = new UserResponse();
			userResponse.setListData(userRoleProductMappingService.listRoleByUserId(authClientResponse.getUserId()));
			userResponse.setStatus(HttpStatus.OK.value());
			userResponse.setMessage("Successfully fetched role product mapping list !!");
			log.info("out /getRoleMapping/{} {}", authClientResponse.getUserId());
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get RoleProduct Mapping ---------->", e);
			return new ResponseEntity<UserResponse>(new UserResponse(UsersCommonUtils.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}

	}

	@GetMapping(value = "/getByBusinessType/{businessType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getRoleMapBusinessTypeWise(@PathVariable Long businessType,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {

		if (authClientResponse == null || authClientResponse.getUserId() == null|| businessType == null) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			UserResponse userResponse = new UserResponse();
			userResponse.setListData(userRoleProductMappingService.listRoleByUserIdAndBusinessType(authClientResponse.getUserId(), businessType));
			userResponse.setStatus(HttpStatus.OK.value());
			userResponse.setMessage("Successfully fetched role product mapping list !!");
			log.info("out /getRoleMapping/{} {}", authClientResponse.getUserId());
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get RoleProduct Mapping ---------->", e);
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}

	}

	@GetMapping(value = "/getSchemeListByUserId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponse> getSchemeListByUserId(@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {

		if (authClientResponse == null || authClientResponse.getUserId() == null) {
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			UserResponse userResponse = new UserResponse();
			userResponse.setListData(userRoleProductMappingService.schemeByUserId(authClientResponse.getUserId()));
			userResponse.setStatus(HttpStatus.OK.value());
			userResponse.setMessage("Successfully fetched role product mapping list !!");
			log.info("out /getRoleMapping/{} {}", authClientResponse.getUserId());
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get RoleProduct Mapping ---------->", e);
			return new ResponseEntity<UserResponse>(
					new UserResponse(UsersCommonUtils.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.OK);
		}

	}
}
