package com.opl.jns.users.service.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



/**
 * @author sandip.bhetariya
 *
 */
@RestController
@Slf4j
@RequestMapping("/v3/campaign")
public class CampaignMasterControllerV3 {

//    @Autowired
//    CampaignMasterServiceV3 campaignMasterService;
//    @SkipInterceptor
//    @RequestMapping(value = "/getByCampaignUrl", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getByCampaignUrl(@RequestBody CampaignMasterProxy campaignMasterProxy) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(campaignMasterProxy.getCampaignUrl())) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("CampaignUrl should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getByCampaignUrl(campaignMasterProxy.getCampaignUrl()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign url -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/saveOrUpdateCampaign", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> saveUpdate(@RequestBody CampaignMasterProxy campaignMasterProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            if (OPLUtils.isObjectNullOrEmpty(campaignMasterProxy.getCampaignUrl())) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("CampaignUrl should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.saveUpdate(campaignMasterProxy, authResponse.getUserId()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while saving campaign details by campaign url -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getByCampaignId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getByCampaignId(@RequestBody CampaignMasterProxy campaignMasterProxy) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(campaignMasterProxy.getId())) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("Campaign Master Id should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getByCampaignId(campaignMasterProxy.getId()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @PostMapping("/getByListOfCampaignId")
//    public ResponseEntity<CommonResponse> getByListOfCampaignId(@RequestBody List<Long> campaignIdList) {
//        try {
//            if (OPLUtils.isListNullOrEmpty(campaignIdList) || campaignIdList.size() == 0) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("Campaign Master Id List should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getByListOfCampaignId(campaignIdList), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getByUserId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getByUserId(@RequestBody CampaignUserMappingProxy campaignUserMappingProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if ((OPLUtils.isObjectNullOrEmpty(campaignUserMappingProxy) || OPLUtils.isObjectNullOrEmpty(campaignUserMappingProxy.getUserId())) && (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId()))) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            if (OPLUtils.isObjectNullOrEmpty(campaignUserMappingProxy.getUserId())) {
//                campaignUserMappingProxy.setUserId(authResponse.getUserId());
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getByUserId(campaignUserMappingProxy.getUserId()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/saveUpdateUserMapping", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> saveUpdateUserMapping(@RequestBody CampaignUserMappingProxy campaignUserMappingProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            campaignUserMappingProxy.setUserId(authResponse.getUserId());
//            return new ResponseEntity<CommonResponse>(campaignMasterService.saveUpdateUserMapping(campaignUserMappingProxy), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getByOrgId/{orgId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getByOrgId(@PathVariable("orgId") Long orgId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if(OPLUtils.isObjectNullOrEmpty(orgId)) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("OrgId can not be null or empty.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getByOrgId(orgId), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getBankSpecificConfigByCampId/{orgId}/{schemeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getBankSpecificConfigByCampId(@PathVariable("orgId") Long orgId, @PathVariable("schemeId") Long schemeId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if(OPLUtils.isObjectNullOrEmpty(orgId) || OPLUtils.isObjectNullOrEmpty(schemeId)) {
//                return new ResponseEntity<CommonResponse>(new CommonResponse("OrgId or SchemeId can not be null or empty.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getBankSpecificConfigByCampId(orgId, schemeId), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/setBankSpecificJourneyConfig", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> setBankSpecificJourneyConfig(@RequestBody BankSpecificJourneyConfigProxy journeyConfigProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            journeyConfigProxy.setUserId(authResponse.getUserId());
//            journeyConfigProxy.setUserOrgId(authResponse.getUserOrgId());
//            return new ResponseEntity<CommonResponse>(campaignMasterService.setBankSpecificJourneyConfig(journeyConfigProxy), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getBankSpecificJourneyConfig", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getBankSpecificJourneyConfig(@RequestBody BankSpecificJourneyConfigProxy journeyConfigProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            journeyConfigProxy.setUserId(authResponse.getUserId());
//            journeyConfigProxy.setUserOrgId(authResponse.getUserOrgId());
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getBankSpecificJourneyConfig(journeyConfigProxy), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    @RequestMapping(value = "/getJourneyConfigHistory", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getJourneyConfigHistory(@RequestBody BankSpecificJourneyConfigProxy journeyConfigProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(authResponse) || OPLUtils.isObjectNullOrEmpty(authResponse.getUserId())||OPLUtils.isObjectNullOrEmpty(journeyConfigProxy.getId())) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("UserId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            journeyConfigProxy.setUserId(authResponse.getUserId());
//            journeyConfigProxy.setUserOrgId(authResponse.getUserOrgId());
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getJourneyConfigHistory(journeyConfigProxy), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//    @RequestMapping(value = "/getJourneyConfigForProductScoring/{orgId}/{schemeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> getJourneyConfigForProductScoring(@PathVariable("orgId") Long orgId,@PathVariable("schemeId") Long schemeId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(orgId) || OPLUtils.isObjectNullOrEmpty(schemeId)) {
//                log.info("Auth or userId is null or empty");
//                return new ResponseEntity<CommonResponse>(new CommonResponse("OrgId or schemeId should not be null or empty", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
//            }
//            return new ResponseEntity<CommonResponse>(campaignMasterService.getJourneyConfigForProductScoring(orgId,schemeId), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while getting campaign details by campaign master id -->", e);
//            return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
}