package com.opl.jns.users.service.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.users.service.service.CampaignMasterServiceV3;

@Service
@Transactional
@Slf4j
public class CampaignMasterServiceImplV3 implements CampaignMasterServiceV3 {

//	@Autowired
//	private CampaignMasterRepositoryV3 campaignMasterRepository;
//
//	@Autowired
//	private CampaignUserMappingRepoV3 campaignUserMappingRepo;
//
//	@Autowired
//	private BankSpecificJourneyConfigRepoV3 bankSpecificJourneyConfigRepo;
//
//	@Autowired
//	private JourneyQuestionsRepoV3 journeyQuestionsRepo;
//
//	@Autowired
//	private JourneyQuestionsMappingRepoV3 journeyQuestionsMappingRepo;
//
//	@Autowired
//	private BankSpecificJourneyConfigRepoAuditV3 bankSpecificJourneyConfigRepoAudit;
//
//	public static final Long MARKET_PLACE = 1L;
//
//
//    // FETCH CAMPAIGN DETAILS BY URL
//    public CommonResponse getByCampaignUrl(String url) {
//        try {
//            CampaignMaster campaignMaster = campaignMasterRepository.findByCampaignUrlAndIsActive(url, Boolean.TRUE);
//            if (!OPLUtils.isObjectNullOrEmpty(campaignMaster)) {
//                CampaignMasterProxy campaignMasterProxy = new CampaignMasterProxy();
//                BeanUtils.copyProperties(campaignMaster, campaignMasterProxy);
//                if (!OPLUtils.isObjectNullOrEmpty(campaignMaster.getOrganisationMaster())) {
//                    campaignMasterProxy.setOrgId(campaignMaster.getOrganisationMaster().getUserOrgId());
//                    campaignMasterProxy.setOrgName(campaignMaster.getOrganisationMaster().getOrganisationName());
//                }
//                return new CommonResponse("Successfully saved details !!", campaignMasterProxy, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//            log.info("No data found by url " + url);
//            return new CommonResponse("Something went wrong, Please try after sometimes !!", HttpStatus.OK.value(), Boolean.FALSE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign Master Details ", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // SAVE / UPDATE CAMPAIGN DETAILS
//    public CommonResponse saveUpdate(CampaignMasterProxy campaignMasterProxy, Long userId) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(campaignMasterProxy.getCampaignUrl())) {
//                return new CommonResponse("Invalid Request, Required data is missing or empty !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//            }
//            CampaignMaster campaignMaster = campaignMasterRepository.findByCampaignUrlAndIsActive(campaignMasterProxy.getCampaignUrl(), Boolean.TRUE);
//            if (campaignMaster != null) {
//
//                BeanUtils.copyProperties(campaignMasterProxy, campaignMaster, "campaignUrl", "createdBy", "isActive", "createdDate", "organisationMaster");
//                campaignMaster.setIsActive(campaignMasterProxy.getIsActive() != null ? campaignMasterProxy.getIsActive() : campaignMaster.getIsActive());
//                if (campaignMasterProxy.getOrgId() != null) {
//                    campaignMaster.setOrganisationMaster(new UserOrganisationMaster(campaignMasterProxy.getOrgId()));
//                }
//                campaignMaster.setModifiedBy(userId);
//                campaignMaster.setModifiedDate(new Date());
//
//            } else {
//                campaignMaster = new CampaignMaster();
//                BeanUtils.copyProperties(campaignMasterProxy, campaignMaster);
//                campaignMaster.setOrganisationMaster(new UserOrganisationMaster(campaignMasterProxy.getOrgId()));
//                campaignMaster.setCreatedDate(new Date());
//                campaignMaster.setCreatedBy(userId);
//                campaignMaster.setIsActive(Boolean.TRUE);
//            }
//            campaignMaster = campaignMasterRepository.save(campaignMaster);
//            // RESPONSE NEW GENERATE ID
//            return new CommonResponse("Successfully saved details !!", campaignMaster.getId(), HttpStatus.OK.value(), Boolean.TRUE);
//        } catch (Exception e) {
//            log.error("Exception while Save Or Update Campaign Master Details ", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // FETCH CAMPAIGN DETAILS BY ID
//    public CommonResponse getByCampaignId(Long id) {
//        try {
//            CampaignMaster campaignMaster = campaignMasterRepository.findByIdAndIsActive(id, Boolean.TRUE);
//            if (campaignMaster != null) {
//                CampaignMasterProxy campaignMasterProxy = new CampaignMasterProxy();
//                BeanUtils.copyProperties(campaignMaster, campaignMasterProxy);
//                if (campaignMaster.getOrganisationMaster() != null) {
//                    campaignMasterProxy.setOrgId(campaignMaster.getOrganisationMaster().getUserOrgId());
//                    campaignMasterProxy.setOrgName(campaignMaster.getOrganisationMaster().getOrganisationName());
//                }
//                return new CommonResponse("Successfully saved details !!", campaignMasterProxy, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//            return new CommonResponse("No data found By CampaignId " + id, HttpStatus.OK.value(), Boolean.FALSE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign Master Details by campaignId", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // FETCH CAMPAIGN DETAILS BY LIST OF ID
//    public CommonResponse getByListOfCampaignId(List<Long> campaignIdList) {
//        try {
//            CampaignMaster campaignMaster = null;
//            List<CampaignMasterProxy> campaignMasterProxyList = new ArrayList<>(campaignIdList.size());
//            CampaignMasterProxy campaignMasterProxy = null;
//            for (Long id : campaignIdList) {
//                campaignMaster = campaignMasterRepository.findByIdAndIsActive(id, Boolean.TRUE);
//                if (campaignMaster != null) {
//                    campaignMasterProxy = new CampaignMasterProxy();
//                    BeanUtils.copyProperties(campaignMaster, campaignMasterProxy);
//                    if (campaignMaster.getOrganisationMaster() != null) {
//                        campaignMasterProxy.setOrgId(campaignMaster.getOrganisationMaster().getUserOrgId());
//                        campaignMasterProxy.setOrgName(campaignMaster.getOrganisationMaster().getOrganisationName());
//                    }
//                    campaignMasterProxyList.add(campaignMasterProxy);
//                }
//            }
//            return new CommonResponse("Successfully saved details !!", campaignMasterProxyList, HttpStatus.OK.value(), Boolean.TRUE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign Master Details by campaignId", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // FETCH ALL CAMPAIGN DETAILS BY USER ID FROM CAMPAIGN USER MAPPING TABLE
//    public CommonResponse getByUserId(Long userId) {
//        try {
//            List<CampaignUserMapping> campaignUserMappingList = campaignUserMappingRepo.findByUserUserIdAndIsActive(userId, Boolean.TRUE);
//            if (!OPLUtils.isListNullOrEmpty(campaignUserMappingList)) {
//                List<CampaignUserMappingProxy> campaignUserMappingProxyList = new ArrayList<>(campaignUserMappingList.size());
//                CampaignUserMappingProxy campaignUserMappingProxy = null;
//                for (CampaignUserMapping campaignUserMapping : campaignUserMappingList) {
//                    campaignUserMappingProxy = new CampaignUserMappingProxy();
//                    BeanUtils.copyProperties(campaignUserMapping, campaignUserMappingProxy);
//                    // SET CAMPAIGN MASTER OBJECT AND SET IN CAMPAIGN USE MAPP PROXY
//                    if (campaignUserMapping.getCampaignMaster() != null) {
//                        CampaignMasterProxy campaignMasterProxy = new CampaignMasterProxy();
//                        BeanUtils.copyProperties(campaignUserMapping.getCampaignMaster(), campaignMasterProxy);
//                        campaignUserMappingProxy.setCampaignMaster(campaignMasterProxy);
//                        if (campaignUserMapping.getCampaignMaster().getOrganisationMaster() != null) {
//                            campaignMasterProxy.setOrgId(campaignUserMapping.getCampaignMaster().getOrganisationMaster().getUserOrgId());
//                            campaignMasterProxy.setOrgName(campaignUserMapping.getCampaignMaster().getOrganisationMaster().getOrganisationName());
//                        }
//                    }
//                    if (campaignUserMapping.getUser() != null) {
//                        campaignUserMappingProxy.setUserLastCampaignId(campaignUserMapping.getUser().getCampaignMaster().getId());
//                    }
//                    campaignUserMappingProxyList.add(campaignUserMappingProxy);
//                }
//                return new CommonResponse("Successfully get user details by userId !!", campaignUserMappingProxyList, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//            return new CommonResponse("No data found By userId " + userId, HttpStatus.OK.value(), Boolean.FALSE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign User Mapping Details by userId", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // SAVE / UPDATE CAMPAIGN USER MAPPING DETAILS
//    public CommonResponse saveUpdateUserMapping(CampaignUserMappingProxy campaignUserMappingProxy) {
//        try {
//            if (OPLUtils.isObjectNullOrEmpty(campaignUserMappingProxy.getCampaignMaster()) || OPLUtils.isObjectNullOrEmpty(campaignUserMappingProxy.getCampaignMaster().getId())) {
//                campaignUserMappingProxy.setCampaignMaster(new CampaignMasterProxy(MARKET_PLACE));
//            }
//            CampaignUserMapping campaignUserMapping = campaignUserMappingRepo.
//                    findByUserUserIdAndCampaignMasterIdAndIsActive(campaignUserMappingProxy.getUserId(), campaignUserMappingProxy.getCampaignMaster().getId(), Boolean.TRUE);
//            if (!OPLUtils.isObjectNullOrEmpty(campaignUserMapping)) {
//                campaignUserMapping.setUpdateDate(new Date());
//            } else {
//                campaignUserMapping = new CampaignUserMapping();
//                campaignUserMapping.setUser(new User(campaignUserMappingProxy.getUserId()));
//                campaignUserMapping.setCampaignMaster(new CampaignMaster(campaignUserMappingProxy.getCampaignMaster().getId()));
//                campaignUserMapping.setCreatedDate(new Date());
//                campaignUserMapping.setIsActive(Boolean.TRUE);
//            }
//            campaignUserMappingRepo.save(campaignUserMapping);
//            return new CommonResponse("Details saved successgfully !!", HttpStatus.OK.value(), Boolean.FALSE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign User Mapping Details by userId", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // FETCH CAMPAIGN DETAILS BY ORG_ID
//    public CommonResponse getByOrgId(Long orgId) {
//        try {
//            CampaignMaster campaignMaster = campaignMasterRepository.findByOrganisationMasterUserOrgIdAndIsActive(orgId, Boolean.TRUE);
//            if (campaignMaster != null) {
//                CampaignMasterProxy campaignMasterProxy = new CampaignMasterProxy();
//                BeanUtils.copyProperties(campaignMaster, campaignMasterProxy);
//                if (campaignMaster.getOrganisationMaster() != null) {
//                    campaignMasterProxy.setOrgId(campaignMaster.getOrganisationMaster().getUserOrgId());
//                    campaignMasterProxy.setOrgName(campaignMaster.getOrganisationMaster().getOrganisationName());
//                }
//                return new CommonResponse("Successfully saved details !!", campaignMasterProxy, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//            log.info("No data found by orgId " + orgId);
//            return new CommonResponse("Something went wrong, Please try after sometimes !!", HttpStatus.OK.value(), Boolean.TRUE);
//        } catch (Exception e) {
//            log.error("Exception while get Campaign Master Details ", e);
//            return new CommonResponse("The application has encountered some error, please try after some time !!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//        }
//    }
//
//    // GET BANK SPECIFIC JOURNEY CONFIG DATA BY CAMP_ID
//    public CommonResponse getBankSpecificConfigByCampId(Long campOrgId, Long schemeId) {
//        try {
//            Long id = campaignMasterRepository.getIdByOrgId(campOrgId);
//            if(OPLUtils.isObjectNullOrEmpty(id)) {
//                log.info("No data found on orgId ---------> {}", campOrgId);
//                return new CommonResponse("Campaign data not found.", HttpStatus.BAD_REQUEST.value());
//            }
//            log.info("Enter in getBankSpecificConfigByCampId ------------->");
//            BankSpecificJourneyConfig bankSpecificJourneyConfig = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActiveIsTrue(id, schemeId);
//            if (!OPLUtils.isObjectNullOrEmpty(bankSpecificJourneyConfig)) {
//                log.info("Set Bank specific joourney config");
//                BankSpecificJourneyConfigProxy bankSpecificJourneyConfigProxy = new BankSpecificJourneyConfigProxy();
//                BeanUtils.copyProperties(bankSpecificJourneyConfig, bankSpecificJourneyConfigProxy);
//                log.info("Exit from getBankSpecificConfigByCampId with data ------------->");
//                return new CommonResponse("Data found.", bankSpecificJourneyConfigProxy, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//            log.info("Exit from getBankSpecificConfigByCampId without data ------------->");
//            return new CommonResponse("Data not found.", HttpStatus.OK.value(), Boolean.TRUE);
//        } catch (Exception e) {
//            log.error("Exception while getting bank specic journey config data ---------->", e);
//            return new CommonResponse("This application has encountered some error, please try after sometimes.", HttpStatus.INTERNAL_SERVER_ERROR.value());
//        }
//    }
//	@Override
//	public CommonResponse setBankSpecificJourneyConfig(BankSpecificJourneyConfigProxy journeyConfigProxy) {
//		BankSpecificJourneyConfig confingMaster = null;
//		String response=null;
//		try {
//			CampaignMaster campaignMaster = campaignMasterRepository
//					.findByOrganisationMasterUserOrgIdAndIsActive(journeyConfigProxy.getUserOrgId(), Boolean.TRUE);
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster))
//				return new CommonResponse("Currently this feature is available in bank specific journey. Kindly connect with our support team to enable this feature for your bank.", Boolean.FALSE, HttpStatus.OK.value(), Boolean.FALSE);
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster.getConfiguration())||campaignMaster.getIsComingSoon()||!campaignMaster.getIsActive()) {
//				return new CommonResponse("Currently this feature is available in bank specific journey. Kindly connect with our support team to enable this feature for your bank.", Boolean.FALSE, HttpStatus.OK.value(), Boolean.FALSE);
//			} else {
//				confingMaster = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActive(
//						campaignMaster.getId(), journeyConfigProxy.getSchemeId(), Boolean.TRUE);
//			}
//			if (!OPLUtils.isObjectNullOrEmpty(confingMaster)) {
//				response=confingMaster.getConfiguration();
//				confingMaster.setConfiguration(journeyConfigProxy.getConfiguration());
//				confingMaster.setModifiedBy(new User(journeyConfigProxy.getUserId()));
//				confingMaster.setModifiedDate(new Date());
//			} else {
//				confingMaster = new BankSpecificJourneyConfig();
//				BeanUtils.copyProperties(journeyConfigProxy, confingMaster);
//				confingMaster.setCampaignId(campaignMaster.getId());
//				confingMaster.setCreatedBy(journeyConfigProxy.getUserId());
//				confingMaster.setCreatedDate(new Date());
//				confingMaster.setIsActive(Boolean.TRUE);
//			}
//			bankSpecificJourneyConfigRepo.save(confingMaster);
//
//			if (!OPLUtils.isObjectNullOrEmpty(confingMaster)) {
//				try {
//					BankSpecificJourneyConfigAudit audit = new BankSpecificJourneyConfigAudit();
////					JSONObject oldJson=new JSONObject(response);
//					JSONObject newJson=new JSONObject(confingMaster.getConfiguration());
//					BeanUtils.copyProperties(confingMaster, audit, "id");
//					audit.setConfigurationType(Long.valueOf(String.valueOf(newJson.get("configurationType"))));
//					audit.setConfigurationValue(Long.valueOf(String.valueOf(newJson.get("configurationValue"))));
//					if (String.valueOf(newJson.get("subQuestionsconfigurationType")) != "null" && String.valueOf(newJson.get("subQuestionsconfigurationValue")) != "null") {
//						audit.setSubQueConfigType(Long.valueOf(String.valueOf(newJson.get("subQuestionsconfigurationType"))));
//						audit.setSubQueConfigValue(Long.valueOf(String.valueOf(newJson.get("subQuestionsconfigurationValue"))));
//					} else {
//						audit.setSubQueConfigType(null);
//						audit.setSubQueConfigValue(null);
//					}
//					if (response != null) {
//						audit.setModifiedBy(confingMaster.getModifiedBy().getUserId());
//					} else {
//						audit.setModifiedBy(journeyConfigProxy.getUserId());
//					}
//					audit.setModifiedDate(new Date());
//					audit.setJourneyConfigId(confingMaster.getId());
//					bankSpecificJourneyConfigRepoAudit.save(audit);
//				} catch (Exception e) {
//					log.error("Exception while save bank specific journey config Audit Details ", e);
//				}
//
//			}
//
//			return new CommonResponse("Saved successfully !!", HttpStatus.OK.value(), Boolean.TRUE);
//		} catch (Exception e) {
//			log.error("Exception while set bank specific journey config Details ", e);
//			return new CommonResponse("The application has encountered some error, please try after some time !!",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//
//		} finally {
//			log.info("save bank specific journey config Audit Details " + confingMaster);
//
//		}
//	}
//
//
//
//	@SuppressWarnings("unchecked")
//	@Override
//	public CommonResponse getBankSpecificJourneyConfig(BankSpecificJourneyConfigProxy journeyConfigProxy) {
//		BankSpecificJourneyConfig confingMaster = null;
//		List<JourneyQuestionsMapping> journeyQuestionsMapping = null;
//		try {
//			CampaignMaster campaignMaster = campaignMasterRepository
//					.findByOrganisationMasterUserOrgIdAndIsActive(journeyConfigProxy.getUserOrgId(), Boolean.TRUE);
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster)) {
//				BankSpecificJourneyConfigProxy journeyConfigurationProxy=null;
//				List<JourneyQuestionsProxy> journeyQuestionsProxyList=new ArrayList<JourneyQuestionsProxy>();
//				JourneyQuestionsProxy journeyQuestionsProxy= null;
//				journeyConfigurationProxy = new BankSpecificJourneyConfigProxy();
//				if (OPLUtils.isObjectNullOrEmpty(journeyConfigProxy.getSchemeId())) {
//					journeyQuestionsMapping =  journeyQuestionsMappingRepo.findBySchemeIdAndIsActive(0l,true);
//				} else {
//					journeyQuestionsMapping =  journeyQuestionsMappingRepo.findBySchemeIdAndIsActive(journeyConfigProxy.getSchemeId(),true);
//				}
//				for (JourneyQuestionsMapping journeyMapping : journeyQuestionsMapping) {
//					journeyQuestionsProxy = new JourneyQuestionsProxy();
//					journeyQuestionsProxy.setConfiguration(journeyMapping.getJourneyQuestionsId().getConfiguration());
//					journeyQuestionsProxy.setId(journeyMapping.getJourneyQuestionsId().getId());
//					journeyQuestionsProxyList.add(journeyQuestionsProxy);
//				}
//				journeyConfigurationProxy.setJourneyQuestionsList(journeyQuestionsProxyList);
//				return new CommonResponse("get successfully", journeyConfigurationProxy, HttpStatus.OK.value(),Boolean.TRUE);
//
//			}
//
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster.getConfiguration())||campaignMaster.getIsComingSoon()||!campaignMaster.getIsActive()) {
//				return new CommonResponse("Currently this feature is available in bank specific journey. Kindly connect with our support team to enable this feature for your bank.", Boolean.FALSE, HttpStatus.OK.value(), Boolean.FALSE);
//			} else {
//
//				if (OPLUtils.isObjectNullOrEmpty(journeyConfigProxy.getSchemeId())) {
//					confingMaster = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActive(
//							campaignMaster.getId(), 0l, Boolean.TRUE);
//					journeyQuestionsMapping =  journeyQuestionsMappingRepo.findBySchemeIdAndIsActive(0l,true);
//				} else {
//					confingMaster = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActive(
//							campaignMaster.getId(), journeyConfigProxy.getSchemeId(), Boolean.TRUE);
//					journeyQuestionsMapping =  journeyQuestionsMappingRepo.findBySchemeIdAndIsActive(journeyConfigProxy.getSchemeId(),true);
//					if (OPLUtils.isObjectNullOrEmpty(confingMaster)) {
//						JSONObject defaultConfig = new JSONObject();
//						for (JourneyQuestionsMapping journeyMapping : journeyQuestionsMapping) {
//							JSONObject jsonObj = new JSONObject(journeyMapping.getJourneyQuestionsId().getConfiguration());
//							List<Map<String,Object>> subQuestionsConfig = MultipleJSONObjectHelper.getListOfObjects(String.valueOf(jsonObj.get("subQuestions")), null, Map.class);
//							if(subQuestionsConfig.size() > 0) {
//								for (Map<String,Object> subQuestion:subQuestionsConfig) {
//									if (subQuestion.get("enabled") != null && String.valueOf(subQuestion.get("enabled")).contains(String.valueOf(jsonObj.get("value")))) {
//										defaultConfig.put(String.valueOf(subQuestion.get("key")),String.valueOf(subQuestion.get("value")));
//									} else {
//										defaultConfig.put(String.valueOf(subQuestion.get("key")),JSONObject.NULL);
//									}
//								}
//							}
//							if (!String.valueOf(jsonObj.get("value")).equalsIgnoreCase("true") && !String.valueOf(jsonObj.get("value")).equalsIgnoreCase("false")) {
//								defaultConfig.put(String.valueOf(jsonObj.get("key")),String.valueOf(jsonObj.get("value")));
//							} else {
//								defaultConfig.put(String.valueOf(jsonObj.get("key")),Boolean.valueOf(String.valueOf(jsonObj.get("value"))));
//							}
//						}
//						BankSpecificJourneyConfig confingMasterDefault = new BankSpecificJourneyConfig();
//						BeanUtils.copyProperties(journeyConfigProxy, confingMasterDefault);
//						confingMasterDefault.setCampaignId(campaignMaster.getId());
//						confingMasterDefault.setConfiguration(defaultConfig.toString());
//						confingMasterDefault.setCreatedBy(journeyConfigProxy.getUserId());
//						confingMasterDefault.setCreatedDate(new Date());
//						confingMasterDefault.setIsActive(Boolean.TRUE);
//						bankSpecificJourneyConfigRepo.save(confingMasterDefault);
//
//					} else {
//						JSONObject newJson = new JSONObject(confingMaster.getConfiguration());
//						for (JourneyQuestionsMapping journeyMapping : journeyQuestionsMapping) {
//							JSONObject jsonObj = new JSONObject(journeyMapping.getJourneyQuestionsId().getConfiguration());
//							if (Boolean.FALSE.equals((newJson.has((String.valueOf(jsonObj.get("key"))))))) {
//
//								List<Map<String,Object>> subQuestionsConfig = MultipleJSONObjectHelper.getListOfObjects(String.valueOf(jsonObj.get("subQuestions")), null, Map.class);
//								if(subQuestionsConfig.size() > 0) {
//									for (Map<String,Object> subQuestion:subQuestionsConfig) {
//										if (subQuestion.get("enabled") != null && String.valueOf(subQuestion.get("enabled")).contains(String.valueOf(jsonObj.get("value")))) {
//											newJson.put(String.valueOf(subQuestion.get("key")),String.valueOf(subQuestion.get("value")));
//										}
//
//									}
//								}
//								if (!String.valueOf(jsonObj.get("value")).equalsIgnoreCase("true") && !String.valueOf(jsonObj.get("value")).equalsIgnoreCase("false")) {
//									newJson.put(String.valueOf(jsonObj.get("key")),String.valueOf(jsonObj.get("value")));
//								} else {
//									newJson.put(String.valueOf(jsonObj.get("key")),Boolean.valueOf(String.valueOf(jsonObj.get("value"))));
//								}
//							}
//						}
//						confingMaster.setConfiguration(newJson.toString());
//						confingMaster.setModifiedDate(new Date());
//						confingMaster.setModifiedBy(new User(journeyConfigProxy.getUserId()));
//						bankSpecificJourneyConfigRepo.save(confingMaster);
//					}
//					confingMaster = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActive(
//							campaignMaster.getId(), journeyConfigProxy.getSchemeId(), Boolean.TRUE);
////					journeyQuestionsMapping =  journeyQuestionsMappingRepo.findBySchemeIdAndIsActive(journeyConfigProxy.getSchemeId(),true);
//				}
//				BankSpecificJourneyConfigProxy journeyConfigurationProxy=null;
//				List<JourneyQuestionsProxy> journeyQuestionsProxyList=new ArrayList<JourneyQuestionsProxy>();
//				JourneyQuestionsProxy journeyQuestionsProxy= null;
//				journeyConfigurationProxy = new BankSpecificJourneyConfigProxy();
//				if(!OPLUtils.isObjectNullOrEmpty(confingMaster)) {
//					BeanUtils.copyProperties(confingMaster, journeyConfigurationProxy);
////					for (JourneyQuestionsMapping journeyMapping : journeyQuestionsMapping) {
////						journeyQuestionsProxy = new JourneyQuestionsProxy();
////						journeyQuestionsProxy.setConfiguration(journeyMapping.getJourneyQuestionsId().getConfiguration());
////						journeyQuestionsProxyList.add(journeyQuestionsProxy);
////					}
////
////					journeyConfigurationProxy.setJourneyQuestionsList(journeyQuestionsProxyList);
////					return new CommonResponse("get successfully !!", journeyConfigurationProxy, HttpStatus.OK.value(),
////							Boolean.TRUE);
//				}
//				for (JourneyQuestionsMapping journeyMapping : journeyQuestionsMapping) {
//					journeyQuestionsProxy = new JourneyQuestionsProxy();
//					journeyQuestionsProxy.setConfiguration(journeyMapping.getJourneyQuestionsId().getConfiguration());
//					journeyQuestionsProxy.setId(journeyMapping.getJourneyQuestionsId().getId());
//					journeyQuestionsProxyList.add(journeyQuestionsProxy);
//				}
//				journeyConfigurationProxy.setJourneyQuestionsList(journeyQuestionsProxyList);
//				return new CommonResponse("get successfully", journeyConfigurationProxy, HttpStatus.OK.value(),
//						Boolean.TRUE);
//			}
//		} catch (Exception e) {
//			log.error("Exception while get Bank Specific Journey Config Details ", e);
//			return new CommonResponse("The application has encountered some error, please try after some time !!",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
//	}
//
//	@Override
//	public CommonResponse getJourneyConfigHistory(BankSpecificJourneyConfigProxy journeyConfigProxy) {
//		try {
//			List<BankSpecificJourneyConfigAudit> auditList= bankSpecificJourneyConfigRepoAudit.findByJourneyConfigId(journeyConfigProxy.getId());
//
//			if(OPLUtils.isObjectListNull(auditList)) {
//				return new CommonResponse("No history found", Collections.EMPTY_LIST, HttpStatus.OK.value(), Boolean.FALSE);
//			}
//			List <Map<Object,Object>> reposnse=new ArrayList<Map<Object,Object>>();
//			if (auditList.size() > 0) {
//				auditList.forEach(list->{
//					Map<Object,Object>employeeCode=new HashMap<Object,Object>();
//					employeeCode.put("configurationType", list.getConfigurationType());
//					employeeCode.put("configurationValue", list.getConfigurationValue());
//					employeeCode.put("modifiedName", list.getModifiedBy());
//					employeeCode.put("modifiedDate", list.getModifiedDate());
//					reposnse.add(employeeCode);
//				});
//			}
//
//
//			return new CommonResponse("get successfully !!", reposnse, HttpStatus.OK.value(),Boolean.TRUE);
//		} catch (Exception e) {
//			log.error("Exception while get Bank Specific Journey Config history Details ", e);
//			return new CommonResponse("The application has encountered some error, please try after some time !!",
//					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
//	}
//	@Override
//	public CommonResponse getJourneyConfigForProductScoring(Long userOrgId,Long schemeId) {
//		BankSpecificJourneyConfig confingMaster = null;
//
//		try {
//			CampaignMaster campaignMaster = campaignMasterRepository.findByOrganisationMasterUserOrgIdAndIsActive(userOrgId, Boolean.TRUE);
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster))
//				return new CommonResponse("Currently this feature is available in bank specific journey. Kindly connect with our support team to enable this feature for your bank.", null, HttpStatus.OK.value(), Boolean.FALSE);
//
//			if (OPLUtils.isObjectNullOrEmpty(campaignMaster.getConfiguration())||campaignMaster.getIsComingSoon()||!campaignMaster.getIsActive()) {
//				return new CommonResponse("Currently this feature is available in bank specific journey. Kindly connect with our support team to enable this feature for your bank.", null, HttpStatus.OK.value(), Boolean.FALSE);
//			} else {
//				confingMaster = bankSpecificJourneyConfigRepo.findByCampaignIdAndSchemeIdAndIsActive(campaignMaster.getId(), schemeId, Boolean.TRUE);
//				BankSpecificJourneyConfigProxy journeyConfigurationProxy=null;
//				if(!OPLUtils.isObjectNullOrEmpty(confingMaster)) {
//					Map<String,Object> newJson=MultipleJSONObjectHelper.getMapFromString(confingMaster.getConfiguration());
//					Map<String,Object> jsonObject= new HashMap<String, Object>();
//
//					if(!OPLUtils.isObjectNullOrEmpty(newJson.get("digitalJourney"))) {
//						jsonObject.put("digitalJourney", Boolean.valueOf(String.valueOf(newJson.get("digitalJourney"))));
//					} else {
//						jsonObject.put("digitalJourney",null);
//					}
// 					if (String.valueOf(newJson.get("digitalApproval")).equals("null")) {
//						jsonObject.put("digitalApproval", null);
//					} else {
//						jsonObject.put("digitalApproval", Boolean.valueOf(String.valueOf(newJson.get("digitalApproval"))));
//					}
//					return new CommonResponse("get successfully !!", jsonObject, HttpStatus.OK.value(),Boolean.TRUE);
//				}
//				return new CommonResponse(null, journeyConfigurationProxy, HttpStatus.OK.value(),Boolean.FALSE);
//			}
//		} catch (Exception e) {
//			log.error("Exception while get Bank Specific Journey Config Details ", e);
//			return new CommonResponse("The application has encountered some error, please try after some time !!",HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
//	}
}
