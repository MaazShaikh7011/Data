package com.opl.jns.users.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "branch_product_mapping", indexes = {
		@Index(columnList = "user_org_id,sch_type_id,is_active",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE"),
		@Index(columnList = "user_org_id,sch_type_id,is_active,branch_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID"),
		@Index(columnList = "user_org_id,sch_type_id,is_active,branch_id,branch_lho_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID_BRANCH_LHO_ID"),
		@Index(columnList = "user_org_id,sch_type_id,is_active,branch_lho_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_LHO_ID"),
		@Index(columnList = "user_org_id,sch_type_id,is_active,branch_ro_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_RO_ID"),
		@Index(columnList = "user_org_id,sch_type_id,branch_zo_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_BRANCH_ZO_ID"),
		@Index(columnList = "user_org_id,sch_type_id,is_active,branch_zo_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ZO_ID"),
		@Index(columnList = "user_org_id,branch_lho_id,is_active",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_BRANCH_LHO_ID_IS_ACTIVE"),
		@Index(columnList = "user_org_id,is_active,branch_id,branch_zo_id",name = DBNameConstant.JNS_USERS + "BR_PROD_MP_USER_ORG_ID_IS_ACTIVE_BRANCH_ID_BRANCH_ZO_ID")
})
public class BranchProductMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "branch_product_mapping_config_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "branch_product_mapping_seq_gen", sequenceName = "branch_product_mapping_config_seq", allocationSize = 1)
	private Long id;

	@Column(name = "branch_id")
	private Long branchId;

	@Column(name = "business_id")
	private Long businessTypeId;
	
	@Column(name = "sch_type_id")
	private Long schTypeId;

	@Column(name = "user_org_id")
	private Long userOrgId;

	@Column(name = "branch_ro_id")
	private Long branchRoId;
	
	@Column(name = "branch_zo_id")
	private Long branchZoId;
	
	@Column(name = "branch_ho_id")
	private Long branchHoId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "modified_by")
	private User modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "branch_lho_id")
	private String branchLhoId;
}
