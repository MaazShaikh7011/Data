package com.opl.jns.users.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.users.api.model.BankSpecificJourneyConfigProxy;
import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.UserEncryptAESUtility;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "users", indexes = {
		@Index(columnList = "email, user_type_id,is_active", name = DBNameConstant.JNS_USERS+ "_users_eml_usrtp_actv_idx"),
		@Index(columnList = "mobile, user_type_id,is_active", name = DBNameConstant.JNS_USERS+ "_users_mb_usrtp_actv_idx"),
		@Index(columnList = "email,mobile, user_type_id", name = DBNameConstant.JNS_USERS+ "_users_email_mb_type_idx"),
		@Index(columnList = "is_active,user_type_id,created_by", name = DBNameConstant.JNS_USERS+ "_users_actv_type_mst_created_by_idx"),
		@Index(columnList = "user_org_id,is_active,branch_id", name = DBNameConstant.JNS_USERS+ "_user_org_id_actv_branch_id_idx"),
		@Index(columnList = "user_org_id,user_role_id,is_active", name = DBNameConstant.JNS_USERS+ "_user_org_id_role_id_actv_idx"),
		@Index(columnList = "branch_id", name = DBNameConstant.JNS_USERS+ "_branch_id_idx")
})
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "user_id")

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "users_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "users_seq_gen", sequenceName = "users_seq", allocationSize = 1)
	@Column(name = "user_id")
	private Long userId;

	@Convert(converter = UserEncryptAESUtility.class)
	@Column(name = "email", columnDefinition = "varchar(255) default ''")
	private String email;

	@Convert(converter = AESOracle.class)
	@Column(columnDefinition = "varchar(255) default ''")
	private String mobile;

	@Column(columnDefinition = "varchar(255) default ''")
	private String password;

	@Convert(converter = UserEncryptAESUtility.class)
	@Column(columnDefinition = "varchar(50) default ''")
	private String username;

	@Convert(converter = AESOracle.class)
	@Column(name = "first_name", columnDefinition = "varchar(200) default ''")
	private String firstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "last_name", columnDefinition = "varchar(200) default ''")
	private String lastName;

	@Convert(converter = AESOracle.class)
	@Column(name = "middle_name", columnDefinition = "varchar(200) default ''")
	private String middleName;

	@Column(name = "last_business_type_id")
	private Integer lastBusinessTypeId;

	@Column(name = "terms_accepted")
	private Boolean termsAccepted;

	@Column(name = "otp_verified")
	private Boolean otpVerified;

	@Column(name = "email_verified")
	private Boolean emailVerified;

	@Column(name = "is_deleted")
	private Boolean isDeleted;

	@Column(name = "is_locked")
	private Boolean isLocked;

	@Column(name = "login_counter")
	private Integer loginCounter;

	@Column(name = "campaign_code")
	private String campaignCode;

	@Column(name = "password1", columnDefinition = "varchar(255) default ''")
	private String password1;

	@Column(name = "password2", columnDefinition = "varchar(255) default ''")
	private String password2;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "sign_up_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date signUpDate;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_type_id", referencedColumnName = "id")
	private UserTypeMaster userTypeMaster;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_status", referencedColumnName = "id")
	private UserStatusMaster userStatusMaster;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_org_id", referencedColumnName = "user_org_id")
	private UserOrganisationMaster userOrgId;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_role_id")
	private UserRoleMaster userRoleId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "branch_id")
	private BranchMaster branchId;

	@Column(name = "is_pass_changed")
	private boolean isPassChanged;

	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

//	@Column(name = "is_active" , nullable = false)
	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "created_by")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "password_reset_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date passwordResetDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "user_locked_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date userLockedDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "user_unlocked_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date userUnlockedDate;

	@Column(name = "partner_id")
	private Long partnerId;

	@Column(name = "state_id")
	private Long stateId;

	@Column(name = "city_id")
	private Long citryId;

	@ManyToOne
	@JoinColumn(name = "campaign_master_id")
	private CampaignMaster campaignMaster;

	public User(Long userId) {
		super();
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "User{" + "userId=" + userId + '}';
	}

	public BankSpecificJourneyConfigProxy getCampaignMaster() {
		// TODO Auto-generated method stub
		return null;
	}
}
