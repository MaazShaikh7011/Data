package com.opl.jns.users.service.service.impl;

import java.io.IOException;
import java.util.LinkedHashMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.users.service.service.GrievancesServiceV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;

/**
 * @author sandip.bhetariya
 *
 */
@Service
@Transactional
public class GrievancesServiceImplV3 implements GrievancesServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(GrievancesServiceImplV3.class.getName());

//	@Autowired
//	private GrievancesRepositoryV3 repository;

	@Autowired
	private ConfigProperties configProperties;

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private DMSClient dMSClient;

	private static final String PRODUCTDOCUMENTMAPPINGID = "productDocumentMappingId";

//	@Override
//	public GrievancesProxy save(GrievancesProxy grievancesRequest, HttpServletRequest request, List<MultipartFile> multipartFiles) throws Exception {
//
//		Grievances grievances = new Grievances();
//		BeanUtils.copyProperties(grievancesRequest, grievances);
//		grievances.setCreatedDate(new Date());
//		grievances.setIsActive(Boolean.TRUE);
//		grievances = repository.save(grievances);
//
//		if(!OPLUtils.isObjectListNull(multipartFiles)) {
//			JSONObject jsonObj = new JSONObject();
//			jsonObj.put("otherTrackingId", grievances.getId());
//			jsonObj.put("userType", "otherTracking");
//			jsonObj.put(PRODUCTDOCUMENTMAPPINGID, "760");
//			jsonObj.put("userId", grievances.getId());
//			jsonObj.put("originalFileName", multipartFiles.get(0).getOriginalFilename());
//
//			//MultipartFile result = new MockMultipartFile("statement", multipartFiles.get(0).getBytes());
//			Long dmsUpload = dmsUpload(jsonObj, multipartFiles.get(0));
//			grievances.setDmsId(dmsUpload);
//			grievances = repository.save(grievances);
//
////			grievancesRequest.setId(grievances.getId());
////			if (!OPLUtils.isObjectNullOrEmpty(grievances.getId())) {
////				sendMailToAdminTeam(grievances,multipartFiles.get(0));
////			}
//		}
//
//		grievancesRequest.setId(grievances.getId());
//		if (!OPLUtils.isObjectListNull(multipartFiles)) {
//			sendMailToAdminTeam(grievances,multipartFiles.get(0));
//		}else {
//			sendMailToAdminTeam(grievances,null);
//		}
//
//		return grievancesRequest;
//	}

	public Long dmsUpload(JSONObject jsonObj, MultipartFile multipartFile) throws DocumentException, IOException {
		DocumentResponse documentResponse = dMSClient.uploadFile(jsonObj.toString(), multipartFile);

		@SuppressWarnings("unchecked")
		StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromMap((LinkedHashMap<String, Object>) documentResponse.getData(), StorageDetailsResponse.class);

		return storageDetailsResponse == null ? null : storageDetailsResponse.getId();

		// dMSClient.deleteProductDocument(jsonString)

		// StorageDetailsResponse
		// storageDetailsResponse=(StorageDetailsResponse)
		// documentResponse.getData();

		/*
		 * DocumentImportRequest documentImportRequest = new DocumentImportRequest();
		 * documentImportRequest.setStorageId(storageDetailsResponse.getId());
		 */
	}

//	@Async
//	private void sendMailToAdminTeam(Grievances grievances,  MultipartFile multipartFile) throws Exception {
//		try {
//
//			String value = null; // configProperties.getValue(ConfigProperties.GRIEVANCES_SEND_MAIL);
//			if (!OPLUtils.isObjectNullOrEmpty(value)) {
////				String[] split = value.split(",");
////				List<String> mailList = new ArrayList<String>(Arrays.asList(value.split(",")));
////				System.err.println(mailList.toString());
//
//				NotificationRequest notificationRequest = new NotificationRequest();
//
//				if(!OPLUtils.isObjectNullOrEmpty(grievances.getCreatedBy())) {
//					notificationRequest.setClientRefId(grievances.getCreatedBy().toString());
//				}else {
//					notificationRequest.setClientRefId("1818");
//				}
//				String[] to = value.split(",");
//
//				Map<String, Object> parameter = new HashedMap<>();
//				parameter.put("username", grievances.getName());
//				parameter.put("userBase", grievances.getUserBase());
////				parameter.put("contactDetails", grievances.getMobileNumber() + " - " + grievances.getEmail());
//				parameter.put("subjeect", grievances.getSubject());
//				parameter.put("description", grievances.getDescription());
//				parameter.put("title", "Grievances : " + grievances.getName() + " (" + grievances.getUserBase() + ") - " + grievances.getId());
//
//				parameter.put("email", grievances.getEmail());
//				parameter.put("mobile", grievances.getMobileNumber());
//
//				parameter.put("nameOfScheme", grievances.getNameOfScheme());
//				parameter.put("typeOfQuery", grievances.getTypeOfQuery());
//				parameter.put("stageOfApplication", grievances.getStageOfApplication());
//
//
//				DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");
//				parameter.put("createdOn", dateFormat.format(grievances.getCreatedDate()));
////				parameter.put("trackind", grievances.getId());
//				List<ContentAttachment> contentAttachmentsList = new ArrayList<ContentAttachment>();
//				if (!OPLUtils.isObjectNullOrEmpty(multipartFile)) {
//					ContentAttachment contentAttachment = new ContentAttachment();
//					contentAttachment.setFileName(multipartFile.getOriginalFilename());
//					contentAttachment.setContentInByte(multipartFile.getBytes());
//					contentAttachmentsList.add(contentAttachment);
//				}
//
//				notificationRequest.addNotification(new Notification(750l, ContentType.TEMPLATE, 4173l, to, NotificationType.EMAIL, parameter,null,null,contentAttachmentsList));
//
////				notification.setMasterId(masterId);
////				notification.setContentType(ContentType.CONTENT);
////				notification.setTemplateId(templateId);
////				notification.setSubject("someone try to connect with us, trackind id is ::-" + grievances.getId());
////				ObjectMapper mapper = new ObjectMapper();
////				notification.setContent(mapper.writeValueAsString(grievances));
////				notification.setTo(to);
////				notification.setType(NotificationType.EMAIL);
////				notificationRequest.addNotification(notification);
//
//				notificationClient.send(notificationRequest);
//			}
//
//		} catch (Exception e) {
//			logger.error("error when sending grievances mail", e);
//		}
//	}

//	@Override
//	public GrievancesProxy findOne(Long id) throws Exception {
//		Optional<Grievances> findById = repository.findById(id);
//		if (findById.isPresent()) {
//			GrievancesProxy responce = new GrievancesProxy();
//			Grievances grievances = findById.get();
//			BeanUtils.copyProperties(grievances, responce);
//			return responce;
//		}
//		return null;
//	}

//	@Override
//	public List<GrievancesProxy> findAll() throws Exception {
//		List<Grievances> findAll = repository.findAll();
//		List<GrievancesProxy> responseList = new ArrayList<GrievancesProxy>();
//		for (Grievances grievances : findAll) {
//			GrievancesProxy responce = new GrievancesProxy();
//			BeanUtils.copyProperties(grievances, responce);
//			responseList.add(responce);
//		}
//		return responseList;
//	}

//	@Override
//	public GrievancesProxy updateRemark(GrievancesProxy grievancesRequest, HttpServletRequest request) throws Exception {
//		Optional<Grievances> findById = repository.findById(grievancesRequest.getId());
//		if (findById.isPresent()) {
//			Grievances grievances = findById.get();
//			grievances.setRemarks(grievancesRequest.getRemarks());
//			grievances.setCloseDate(new Date());
//			grievances.setIsActive(Boolean.FALSE);
//			grievances = repository.save(grievances);
//			grievancesRequest.setId(grievances.getId());
//
//			return grievancesRequest;
//		}
//		return null;
//	}

}
