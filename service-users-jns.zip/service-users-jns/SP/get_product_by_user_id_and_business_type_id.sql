CREATE OR REPLACE NONEDITIONABLE PROCEDURE get_product_by_user_id_and_business_type_id (
    userid          IN  NUMBER,
    typeid          IN  NUMBER,
    businesstypeid  IN  NUMBER,
    result          out  clob
) AS
    userroleid  NUMBER;
    userorgid   NUMBER;
    branchid    NUMBER;
    mainquery clob;
BEGIN

    SELECT user_role_id, user_org_id, branch_id INTO userroleid, userorgid, branchid FROM jns_users.users WHERE user_id = userid;
dbms_output.put_line(userroleid || userorgid || branchid );
	mainquery :=  ' SELECT
		JSON_ARRAYAGG(JSON_OBJECT(''userId'' value temp.userId, ''businessTypeId'' value temp.businessTypeId, ''businessTypeName'' value temp.businessTypeName,
        ''roleId'' value temp.roleId, ''imgPath'' value temp.imgPath, ''schemeId'' value temp.schemeId, ''schemeName'' value temp.schemeName, ''shortName'' value temp.shortName,
        ''routingPath'' value temp.routingPath, ''orderId'' value temp.orderId)) FROM (SELECT
		pm.user_id AS userId, pm.business_id AS businessTypeId, btm.display_name AS businessTypeName, pm.user_role_id AS roleId, (case when ' || businesstypeid || ' IS NULL then btm.img_path else schm.img_path end) AS imgPath,
		schm.id AS schemeId, schm.name AS schemeName,schm.short_name AS shortName, (case when ' || businesstypeid || ' IS NULL then btm.path else schm.path end) AS routingPath, (case when ' || businesstypeid || ' IS NULL then btm.order_id else schm.order_id end) AS orderId
		FROM jns_users.user_role_product_mapping pm
		INNER JOIN jns_users.business_master btm ON btm.id = pm.business_id
		INNER JOIN jns_users.users u ON u.user_id = pm.user_id
		INNER JOIN jns_users.scheme_master schm ON schm.id = pm.scheme_id AND pm.is_active = 1
		AND pm.user_id = ' || userid;

--    dbms_output.put_line(mainquery);

-- 	AND schm.is_active = 1
	IF (businessTypeId IS NULL) THEN
		mainquery := CONCAT(mainquery, ' AND btm.is_active = TRUE GROUP BY pm.business_id ORDER BY btm.order_id ASC) temp ');
	ELSE
		mainquery := CONCAT(mainquery, ' and pm.business_id IN(' || businessTypeId || ',-1) ORDER BY (case when ' || businesstypeid || ' IS NULL then btm.order_id else schm.order_id end) ASC) temp ');
	END IF;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);


end get_product_by_user_id_and_business_type_id;