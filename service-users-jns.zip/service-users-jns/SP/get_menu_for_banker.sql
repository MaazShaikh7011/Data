create or replace NONEDITIONABLE PROCEDURE get_menu_for_banker (
    userid  IN   NUMBER,
    result  OUT  CLOB
) AS
    userroleid  NUMBER;
    usertypeid  NUMBER;
    query       CLOB;
BEGIN
    SELECT
        user_role_id,
        user_type_id
    INTO
        userroleid,
        usertypeid
    FROM
        jns_users.users
    WHERE
            user_id = 1
        AND is_active = 1;

    dbms_output.put_line(userroleid || usertypeid);
    query := 'SELECT
        JSON_ARRAYAGG(JSON_OBJECT(
                          ''keyName'' VALUE temp.keyname,
                          ''displayName'' VALUE temp.displayname,
                          ''iconPath'' VALUE temp.iconpath,
                                    ''navigatePath'' VALUE temp.navigatepath,
                                    ''childList'' VALUE temp.childlist,
                                    ''seq'' VALUE temp.seq,
                                    ''schemeId'' VALUE temp.schemeid
                      ))

    FROM
        (
            SELECT
                mm.key_name           AS keyname,
                mm.display_name       AS displayname,
                mm.icon_path          AS iconpath,
                mm.navigation_path    AS navigatepath,
                mm.sequence           AS seq,
                mml.scheme_id         AS schemeid,
                (
                    SELECT
                        JSON_ARRAYAGG(JSON_OBJECT(
                                          ''keyName'' VALUE m.key_name,
                                          ''displayName'' VALUE m.display_name,
                                          ''iconPath'' VALUE m.icon_path,
                                                    ''navigatePath'' VALUE m.navigation_path,
                                                    ''seq'' VALUE m.sequence
                                      ))
                    FROM
                        jns_users.menu_master          m
                        LEFT JOIN jns_users.menu_role_mapping    ml ON ml.menu_id = m.id
                    WHERE
                            ml.role_id = mml.role_id
                        AND ml.type_id = mml.type_id
                        AND ml.scheme_id = mml.scheme_id
                        AND m.parent_id = mm.id
                        AND m.is_active = 1
                        AND ml.is_active = 1
                )                     AS childlist
            FROM
                jns_users.menu_master          mm
                LEFT JOIN jns_users.menu_role_mapping    mml ON mml.menu_id = mm.id
            WHERE
                    mml.role_id = '
             || userroleid
             || '
                AND mml.type_id = '
             || usertypeid
             || '
                AND mm.parent_id IS NULL
                AND mm.is_active = 1
                AND mml.is_active = 1
            ORDER BY
                mm.sequence ASC
        ) temp';
    dbms_output.put_line(query);
    EXECUTE IMMEDIATE query
    INTO result;
    dbms_output.put_line(result);
END get_menu_for_banker;