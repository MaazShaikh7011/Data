DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spGetAllMenuForBanker`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetAllMenuForBanker`(IN roleId BIGINT)
BEGIN

	SELECT JSON_ARRAYAGG(JSON_OBJECT('keyName',temp.keyName,'displayName',temp.displayName,'iconPath',temp.iconPath, 'navigatePath',temp.navigatePath,'childList',temp.childList, 'seq', temp.seq, 
	'schemeId', temp.schemeId -- , 'isMenuView', IF(temp.isMenuView,TRUE,FALSE)
	)) AS menuList FROM (SELECT mm.key_name AS keyName,mm.display_name AS displayName,mm.icon_path AS iconPath, mpm.navigation_path AS navigatePath,
	mm.sequence AS seq,mml.scheme_id AS schemeId, -- mm.is_menu_view AS isMenuView,
	(SELECT JSON_ARRAYAGG(JSON_OBJECT('keyName',m.key_name,'displayName',m.display_name,'iconPath',m.icon_path,'navigatePath',mp.navigation_path)) 
	FROM users.`menu_master` m LEFT JOIN users.`menu_role_mapping` ml ON ml.menu_id = m.id LEFT JOIN users.menu_path_master mp ON mp.menu_id = m.id AND mp.`scheme_id` = ml.`scheme_id`
	 WHERE ml.role_id = mml.role_id AND ml.scheme_id = mml.scheme_id AND m.parent_id = mm.id AND m.is_active = TRUE AND ml.is_active = TRUE ORDER BY m.sequence ASC) AS childList 
	 FROM users.menu_master mm LEFT JOIN users.`menu_role_mapping` mml ON mml.menu_id = mm.id LEFT JOIN users.menu_path_master mpm ON mpm.menu_id = mm.id AND mpm.`scheme_id` = mml.`scheme_id` 
	 WHERE mml.role_id = roleId AND mm.parent_id IS NULL AND mm.is_active = TRUE AND mml.is_active = TRUE ORDER BY mm.sequence ASC) AS temp;
 
	END$$
	
-- 	call spGetAllMenuForBanker(5);

DELIMITER ;