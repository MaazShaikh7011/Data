DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spGetAccessPaths`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetAccessPaths`(IN userId BIGINT)
BEGIN

	SELECT user_type_id, user_role_id INTO @userTypeId, @userRoleId FROM users.users WHERE user_id = userId AND is_active = TRUE;

	SELECT PAM.path AS path FROM users.path_access_role_mapping PARM
	INNER JOIN users.path_access_master PAM ON PAM.id = PARM.path_access_id AND PAM.is_active
	WHERE PARM.role_id = @userRoleId AND PARM.type_id = @userTypeId AND PARM.is_active = TRUE;


	END$$

DELIMITER ;