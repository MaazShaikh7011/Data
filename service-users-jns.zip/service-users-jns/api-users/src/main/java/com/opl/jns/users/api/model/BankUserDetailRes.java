package com.opl.jns.users.api.model;

public class BankUserDetailRes {

	private Long userRoleId;
	private Long orgId;
	private Long branchId;
	private Long schemeId;
	private String email;
	private String mobile;
	private Long userId;
	private String name;

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "BankUserDetailRes [userRoleId=" + userRoleId + ", orgId=" + orgId + ", branchId=" + branchId
				+ ", schemeId=" + schemeId + ", email=" + email + ", mobile=" + mobile + ", userId=" + userId
				+ ", name=" + name + "]";
	}
	
	
}
