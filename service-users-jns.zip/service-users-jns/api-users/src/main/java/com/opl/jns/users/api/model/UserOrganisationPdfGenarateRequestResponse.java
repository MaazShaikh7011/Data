package com.opl.jns.users.api.model;

import java.util.List;

public class UserOrganisationPdfGenarateRequestResponse {

	/**
	 * Request
	 */
	private Long insurerOrgId;
	private Long orgId;
	
	/**
	 * Get Multiple OrgDetails
	 */
	private List<Long> orgIds;

	/***
	 * Response
	 */
	/**
	 * insurer org
	 */
	//private static final String GET_ORGANIZATION_BY_ID = "/v3/org/getOrganizationById";
	private String insurerImagePath;
	private String insurerdisplayOrgName;

	/**
	 * app master org
	 */
	//private static final String GET_ORGANIZATION_BY_ID = "/v3/org/getOrganizationById";
	private String imagePath;

	//private static final String GET_ORGANIZATION_NAME = "/v3/org/getOrganizationName";
	private String nameOfBank;

	public String getInsurerImagePath() {
		return insurerImagePath;
	}

	public void setInsurerImagePath(String insurerImagePath) {
		this.insurerImagePath = insurerImagePath;
	}

	public String getInsurerdisplayOrgName() {
		return insurerdisplayOrgName;
	}

	public void setInsurerdisplayOrgName(String insurerdisplayOrgName) {
		this.insurerdisplayOrgName = insurerdisplayOrgName;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getNameOfBank() {
		return nameOfBank;
	}

	public void setNameOfBank(String nameOfBank) {
		this.nameOfBank = nameOfBank;
	}

	public Long getInsurerOrgId() {
		return insurerOrgId;
	}

	public void setInsurerOrgId(Long insurerOrgId) {
		this.insurerOrgId = insurerOrgId;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	
	

	public List<Long> getOrgIds() {
		return orgIds;
	}

	public void setOrgIds(List<Long> orgIds) {
		this.orgIds = orgIds;
	}

	@Override
	public String toString() {
		return "UserOrganisationPdfGenarateRequestResponse [insurerOrgId=" + insurerOrgId + ", orgId=" + orgId + ", insurerImagePath=" + insurerImagePath + ", insurerdisplayOrgName=" + insurerdisplayOrgName + ", imagePath=" + imagePath
				+ ", nameOfBank=" + nameOfBank + "]";
	}

}
