package com.opl.jns.users.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserTypeRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String code;

	private String description;

	private String name;

	private Boolean isActive;

	private Boolean isDisplayOnLogin;

	public UserTypeRequest() {
	}

	public UserTypeRequest(Long id, String code) {
		this.id = id;
		this.code = code;
	}

	public UserTypeRequest(Long id) {
		this.id = id;
	}

	public UserTypeRequest(String userTypeCode) {

		this.code = userTypeCode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsDisplayOnLogin() {
		return isDisplayOnLogin;
	}

	public void setIsDisplayOnLogin(Boolean isDisplayOnLogin) {
		this.isDisplayOnLogin = isDisplayOnLogin;
	}

	@Override
	public String toString() {
		return "UserTypeRequest [id=" + id + ", code=" + code + ", description=" + description + ", name=" + name
				+ ", isActive=" + isActive + ", isDisplayOnLogin=" + isDisplayOnLogin + "]";
	}
	
}
