package com.opl.jns.users.api.model;

import java.io.Serializable;

public class UserNotificationDetailsRes implements Serializable {

	private static final long serialVersionUID = 1L;

	private BranchBasicDetailsRequest branchDetailsRes;

	private UsersRequest usersDetailsRes;

	private UserOrganisationMasterResponse orgDetailsRes;

	public BranchBasicDetailsRequest getBranchDetailsRes() {
		return branchDetailsRes;
	}

	public void setBranchDetailsRes(BranchBasicDetailsRequest branchDetailsRes) {
		this.branchDetailsRes = branchDetailsRes;
	}

	public UsersRequest getUsersDetailsRes() {
		return usersDetailsRes;
	}

	public void setUsersDetailsRes(UsersRequest usersDetailsRes) {
		this.usersDetailsRes = usersDetailsRes;
	}

	public UserOrganisationMasterResponse getOrgDetailsRes() {
		return orgDetailsRes;
	}

	public void setOrgDetailsRes(UserOrganisationMasterResponse orgDetailsRes) {
		this.orgDetailsRes = orgDetailsRes;
	}

	@Override
	public String toString() {
		return "UserNotificationDetailsRes [branchDetailsRes=" + branchDetailsRes + ", usersDetailsRes="
				+ usersDetailsRes + ", orgDetailsRes=" + orgDetailsRes + "]";
	}
	
	
}
