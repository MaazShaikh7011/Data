package com.opl.jns.users.api.model;

public class SignUpRequest {

	public String mobile;

	public String name;

	public String email;

	public String captchaEnter;

	public String captchaOriginal;

	public String otp;

	public Integer otpType;

	public Long userId;

	public Boolean isTermsAccepted;

	private Long userType;

	public Long campaignMasterId;

	public Long notificationMasterId;
	
	public Long schemeId;
	
	public Long emailNotiMasterId;
	public Long smsNotiMasterId;
	public String username;
	public String password;
	private String remoteAddr;


	public Long getEmailNotiMasterId() {
		return emailNotiMasterId;
	}

	public void setEmailNotiMasterId(Long emailNotiMasterId) {
		this.emailNotiMasterId = emailNotiMasterId;
	}

	public Long getSmsNotiMasterId() {
		return smsNotiMasterId;
	}

	public void setSmsNotiMasterId(Long smsNotiMasterId) {
		this.smsNotiMasterId = smsNotiMasterId;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public Long getNotificationMasterId() {
		return notificationMasterId;
	}

	public void setNotificationMasterId(Long notificationMasterId) {
		this.notificationMasterId = notificationMasterId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCampaignMasterId() {
		return campaignMasterId;
	}

	public void setCampaignMasterId(Long campaignMasterId) {
		this.campaignMasterId = campaignMasterId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCaptchaEnter() {
		return captchaEnter;
	}

	public void setCaptchaEnter(String captchaEnter) {
		this.captchaEnter = captchaEnter;
	}

	public String getCaptchaOriginal() {
		return captchaOriginal;
	}

	public void setCaptchaOriginal(String captchaOriginal) {
		this.captchaOriginal = captchaOriginal;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Boolean getIsTermsAccepted() {
		return isTermsAccepted;
	}

	public void setIsTermsAccepted(Boolean isTermsAccepted) {
		this.isTermsAccepted = isTermsAccepted;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public Integer getOtpType() {
		return otpType;
	}

	public void setOtpType(Integer otpType) {
		this.otpType = otpType;
	}


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRemoteAddr() {
		return remoteAddr;
	}

	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}
}
