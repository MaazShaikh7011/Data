package com.opl.jns.users.api.model;

public class UserRoleProductMapProxy {

	private Long id;

	private Long userId;

	private Long roleId;

	private String roleName;

	private Long businessTypeId;

	private String businessTypeName;

	private String imgPath;

	private String routingPath;

	private Long schemeId;

	private String schemeName;

	private String schemeImgPath;

	private String schemeRoutingPath;

	private Integer sequence;
	
	private Long totalCount;
	
	private Long totalNewCount;
	
	public Long getTotalCount() {
		return totalCount;
	}
	
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Long getTotalNewCount() {
		return totalNewCount;
	}
	
	public void setTotalNewCount(Long totalNewCount) {
		this.totalNewCount = totalNewCount;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Long getBusinessTypeId() {
		return businessTypeId;
	}

	public void setBusinessTypeId(Long businessTypeId) {
		this.businessTypeId = businessTypeId;
	}

	public String getBusinessTypeName() {
		return businessTypeName;
	}

	public void setBusinessTypeName(String businessTypeName) {
		this.businessTypeName = businessTypeName;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public String getRoutingPath() {
		return routingPath;
	}

	public void setRoutingPath(String routingPath) {
		this.routingPath = routingPath;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getSchemeImgPath() {
		return schemeImgPath;
	}

	public void setSchemeImgPath(String schemeImgPath) {
		this.schemeImgPath = schemeImgPath;
	}

	public String getSchemeRoutingPath() {
		return schemeRoutingPath;
	}

	public void setSchemeRoutingPath(String schemeRoutingPath) {
		this.schemeRoutingPath = schemeRoutingPath;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	@Override
	public String toString() {
		return "UserRoleProductMapProxy [id=" + id + ", userId=" + userId + ", roleId=" + roleId + ", roleName="
				+ roleName + ", businessTypeId=" + businessTypeId + ", businessTypeName=" + businessTypeName
				+ ", imgPath=" + imgPath + ", routingPath=" + routingPath + ", schemeId=" + schemeId + ", schemeName="
				+ schemeName + ", schemeImgPath=" + schemeImgPath + ", schemeRoutingPath=" + schemeRoutingPath + "]";
	}
	
	
}
