package com.opl.jns.users.api.model;

import java.util.List;

public class ValidationModuleMstr {
	private String module;
	private List<ValidationFieldMstr> fieldList;

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public List<ValidationFieldMstr> getFieldList() {
		return fieldList;
	}

	public void setFieldList(List<ValidationFieldMstr> fieldList) {
		this.fieldList = fieldList;
	}

	@Override
	public String toString() {
		return "ValidationModuleMstr [module=" + module + ", fieldList=" + fieldList + "]";
	}

}
