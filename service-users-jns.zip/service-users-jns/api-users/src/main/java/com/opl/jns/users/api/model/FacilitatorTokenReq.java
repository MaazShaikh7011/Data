package com.opl.jns.users.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FacilitatorTokenReq implements Serializable {

	private static final long serialVersionUID = 6232712419796541868L;

	private Long facilitatorId;

	private Long applicationId;

	private Long userId;

	public Long getFacilitatorId() {
		return facilitatorId;
	}

	public void setFacilitatorId(Long facilitatorId) {
		this.facilitatorId = facilitatorId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
