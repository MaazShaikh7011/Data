package com.opl.jns.users.api.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FacilitatorReq implements Serializable {

	private static final long serialVersionUID = 638527623017066885L;

	private Long id;
	private Long facilitatorId;
	private Long userId;
	private Long applicationId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getFacilitatorId() {
		return facilitatorId;
	}

	public void setFacilitatorId(Long facilitatorId) {
		this.facilitatorId = facilitatorId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

}
