package com.opl.jns.users.api.model;

import java.util.List;

public class ValidationFieldMstr {
	private String label;
	private Long moduleid;
	private List<ValidationsMstr> validations;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Long getModuleid() {
		return moduleid;
	}

	public void setModuleid(Long moduleid) {
		this.moduleid = moduleid;
	}

	public List<ValidationsMstr> getValidations() {
		return validations;
	}

	public void setValidations(List<ValidationsMstr> validations) {
		this.validations = validations;
	}

	@Override
	public String toString() {
		return "ValidationFieldMstr [label=" + label + ", moduleid=" + moduleid + ", validations=" + validations + "]";
	}

}
