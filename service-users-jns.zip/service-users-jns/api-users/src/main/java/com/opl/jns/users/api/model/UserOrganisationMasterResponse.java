package com.opl.jns.users.api.model;

import java.sql.Timestamp;

public class UserOrganisationMasterResponse {

	private Long userOrgId;

	private String organisationName;

	private String displayOrgName;

	private String organisationCode;

	private Integer orgType;

	private UserTypeRequest userTypeMaster;

	private Long modifiedBy;

	private Timestamp modifiedDate;

	private Boolean isActive;

	private Long campaignType;
	
	private String imagePath;

	private String bankType;

	private String orgCategory;

	public String getOrgCategory() {
		return orgCategory;
	}

	public void setOrgCategory(String orgCategory) {
		this.orgCategory = orgCategory;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getDisplayOrgName() {
		return displayOrgName;
	}

	public void setDisplayOrgName(String displayOrgName) {
		this.displayOrgName = displayOrgName;
	}

	public String getOrganisationCode() {
		return organisationCode;
	}

	public void setOrganisationCode(String organisationCode) {
		this.organisationCode = organisationCode;
	}

	public Integer getOrgType() {
		return orgType;
	}

	public void setOrgType(Integer orgType) {
		this.orgType = orgType;
	}

	public UserTypeRequest getUserTypeMaster() {
		return userTypeMaster;
	}

	public void setUserTypeMaster(UserTypeRequest userTypeMaster) {
		this.userTypeMaster = userTypeMaster;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Long getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(Long campaignType) {
		this.campaignType = campaignType;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Override
	public String toString() {
		return "UserOrganisationMasterResponse [userOrgId=" + userOrgId + ", organisationName=" + organisationName
				+ ", displayOrgName=" + displayOrgName + ", organisationCode=" + organisationCode + ", orgType="
				+ orgType + ", userTypeMaster=" + userTypeMaster + ", modifiedBy=" + modifiedBy + ", modifiedDate="
				+ modifiedDate + ", isActive=" + isActive + ", campaignType=" + campaignType + ", imagePath="
				+ imagePath + "]";
	}
	
	

}
