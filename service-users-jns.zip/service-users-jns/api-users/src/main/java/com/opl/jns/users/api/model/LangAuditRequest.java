package com.opl.jns.users.api.model;


public class LangAuditRequest {

	public Long applicationId;
	
	public Long userId;
	
	public String language;
		
	private String applicationCode;
		
	private Long schemeId;

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	@Override
	public String toString() {
		return "LangAuditRequest [applicationId=" + applicationId + ", userId=" + userId + ", language=" + language
				+ ", applicationCode=" + applicationCode + ", schemeId=" + schemeId + "]";
	}

}
