package com.opl.jns.users.api.model;

import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import java.io.Serializable;
import java.util.Date;

//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

/**
 * @author sandip.bhetariya
 *
 */

public class GrievancesProxy implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String userBase;
	private String name;
	private String mobileNumber;
	private String email;
	private String applicationId;
	private String subject;
	private String description;
	private String remarks;
	private Boolean isActive;
	private Long modifiedBy;
	private Long createdBy;

	private String typeOfQuery;
	private String nameOfScheme;
	private String stageOfApplication;
	private Long campaignCode;

	@Temporal(TemporalType.TIMESTAMP)
	private Date closeDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserBase() {
		return userBase;
	}

	public void setUserBase(String userBase) {
		this.userBase = userBase;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getTypeOfQuery() {
		return typeOfQuery;
	}

	public void setTypeOfQuery(String typeOfQuery) {
		this.typeOfQuery = typeOfQuery;
	}

	public String getNameOfScheme() {
		return nameOfScheme;
	}

	public void setNameOfScheme(String nameOfScheme) {
		this.nameOfScheme = nameOfScheme;
	}

	public String getStageOfApplication() {
		return stageOfApplication;
	}

	public void setStageOfApplication(String stageOfApplication) {
		this.stageOfApplication = stageOfApplication;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(Long campaignCode) {
		this.campaignCode = campaignCode;
	}

}
