package com.opl.jns.users.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author jaimin.darji
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UsersRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	private Long userType;
	private Boolean termsAccepted;
	private Boolean isActive;
	private Boolean otpVerified;
	private Boolean emailVerified;

	private String remoteAddr;
	private String email;
	private String password;
	private String confirmPassword;
	private String oldPassword;
	private Boolean isPasswordSet;
	private String mobile;
	private String userName;
	private String name;
	private String otp;
	private String otpMsg;
	private String verificationUrl;
	private String firstName;
	private String middleName;
	private String lastName;
	private String domain;
	private String pan;
	private String urlEncrypt;

	private Integer otpStatus;
	private Integer otpOn;
	private Integer otpVerificationType;

	private Date modifiedDate;
	private Date signUpDate;

	private Long userOrgId;
	private Long applicationId;
	private Long userId;
	private Long userRoleId;
	private Long businessTypeId;
	private Long domainId;

	private Boolean isMsmeUser;
	private Boolean isLocked;
	private Boolean isLockedByAdmin;
	private Boolean isExistingUser;

	private String browserName;
	private String browserVersion;
	private String device;
	private String deviceType;
	private String deviceOs;
	private String deviceOsVersion;
	private String userAgent;
	private String userRoleIdString;
	private String loanTypeIdString;
	private String userOrgName;
	private Date lastLoginDate;
	private Integer lastBusinessTypeId;
	private Long schemeId;
	
	public String captchaEnter;
	public String captchaOriginal;
	public Long campaignMasterId;

	public Boolean isMobileLogin;
	public String fcmToken;

	public Boolean isRequiredAutoRegistration;

	public CampaignMasterProxy campaignMasterProxy;
	public Boolean isPreScreenLogin;
	public String urlCode;

	public Long notificationMasterId;
	public Integer otpType;
	public Integer Type;
	
	public Long branchId;
	
	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public Integer getOtpType() {
		return otpType;
	}

	public void setOtpType(Integer otpType) {
		this.otpType = otpType;
	}

	public Integer getType() {
		return Type;
	}

	public void setType(Integer type) {
		Type = type;
	}

	public Long getNotificationMasterId() {
		return notificationMasterId;
	}

	public void setNotificationMasterId(Long notificationMasterId) {
		this.notificationMasterId = notificationMasterId;
	}

	public Long getCampaignMasterId() {
		return campaignMasterId;
	}

	public void setCampaignMasterId(Long campaignMasterId) {
		this.campaignMasterId = campaignMasterId;
	}

	public Long getBusinessTypeId() {
		return businessTypeId;
	}

	public void setBusinessTypeId(Long businessTypeId) {
		this.businessTypeId = businessTypeId;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public UsersRequest(Long id) {
		this.id = id;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Date getSignUpDate() {
		return signUpDate;
	}

	public void setSignUpDate(Date signUpDate) {
		this.signUpDate = signUpDate;
	}

	public Boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(Boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public Boolean isOtpVerified() {
		return otpVerified;
	}

	public void setOtpVerified(Boolean otpVerified) {
		this.otpVerified = otpVerified;
	}

	public String getVerificationUrl() {
		return verificationUrl;
	}

	public void setVerificationUrl(String verificationUrl) {
		this.verificationUrl = verificationUrl;
	}

	public UsersRequest() {
	}

	public UsersRequest(String email) {
		this.email = email;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Boolean isTermsAccepted() {
		return termsAccepted;
	}

	public void setTermsAccepted(Boolean termsAccepted) {
		this.termsAccepted = termsAccepted;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Boolean getIsMsmeUser() {
		return isMsmeUser;
	}

	public void setIsMsmeUser(Boolean isMsmeUser) {
		this.isMsmeUser = isMsmeUser;
	}

	private List<Long> roleId;

	public List<Long> getRoleId() {
		return roleId;
	}

	public void setRoleId(List<Long> roleId) {
		this.roleId = roleId;
	}

	public Integer getOtpStatus() {
		return otpStatus;
	}

	public void setOtpStatus(Integer otpStatus) {
		this.otpStatus = otpStatus;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public Boolean getIsLockedByAdmin() {
		return isLockedByAdmin;
	}

	public void setIsLockedByAdmin(Boolean isLockedByAdmin) {
		this.isLockedByAdmin = isLockedByAdmin;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getLastBusinessTypeId() {
		return lastBusinessTypeId;
	}

	public void setLastBusinessTypeId(Integer lastBusinessTypeId) {
		this.lastBusinessTypeId = lastBusinessTypeId;
	}

	public Long getDomainId() {
		return domainId;
	}

	public void setDomainId(Long domainId) {
		this.domainId = domainId;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Boolean getIsExistingUser() {
		return isExistingUser;
	}

	public void setIsExistingUser(Boolean isExistingUser) {
		this.isExistingUser = isExistingUser;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getRemoteAddr() {
		return remoteAddr;
	}

	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}

	public String getBrowserName() {
		return browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}

	public Integer getOtpOn() {
		return otpOn;
	}

	public void setOtpOn(Integer otpOn) {
		this.otpOn = otpOn;
	}

	public String getOtpMsg() {
		return otpMsg;
	}

	public void setOtpMsg(String otpMsg) {
		this.otpMsg = otpMsg;
	}

	public String getUrlEncrypt() {
		return urlEncrypt;
	}

	public void setUrlEncrypt(String urlEncrypt) {
		this.urlEncrypt = urlEncrypt;
	}

	public Integer getOtpVerificationType() {
		return otpVerificationType;
	}

	public void setOtpVerificationType(Integer otpVerificationType) {
		this.otpVerificationType = otpVerificationType;
	}

	public String getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceOs() {
		return deviceOs;
	}

	public void setDeviceOs(String deviceOs) {
		this.deviceOs = deviceOs;
	}

	public String getDeviceOsVersion() {
		return deviceOsVersion;
	}

	public void setDeviceOsVersion(String deviceOsVersion) {
		this.deviceOsVersion = deviceOsVersion;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getUserRoleIdString() {
		return userRoleIdString;
	}

	public void setUserRoleIdString(String userRoleIdString) {
		this.userRoleIdString = userRoleIdString;
	}

	public String getLoanTypeIdString() {
		return loanTypeIdString;
	}

	public void setLoanTypeIdString(String loanTypeIdString) {
		this.loanTypeIdString = loanTypeIdString;
	}

	public String getUserOrgName() {
		return userOrgName;
	}

	public void setUserOrgName(String userOrgName) {
		this.userOrgName = userOrgName;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public String getCaptchaEnter() {
		return captchaEnter;
	}

	public void setCaptchaEnter(String captchaEnter) {
		this.captchaEnter = captchaEnter;
	}

	public String getCaptchaOriginal() {
		return captchaOriginal;
	}

	public void setCaptchaOriginal(String captchaOriginal) {
		this.captchaOriginal = captchaOriginal;
	}

	public Boolean getIsPasswordSet() {
		return isPasswordSet;
	}

	public void setIsPasswordSet(Boolean isPasswordSet) {
		this.isPasswordSet = isPasswordSet;
	}

	public Boolean getIsMobileLogin() {
		return isMobileLogin;
	}

	public void setIsMobileLogin(Boolean isMobileLogin) {
		this.isMobileLogin = isMobileLogin;
	}

	public String getFcmToken() {
		return fcmToken;
	}

	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public Boolean getRequiredAutoRegistration() {
		return isRequiredAutoRegistration;
	}

	public void setRequiredAutoRegistration(Boolean requiredAutoRegistration) {
		isRequiredAutoRegistration = requiredAutoRegistration;
	}

	public CampaignMasterProxy getCampaignMasterProxy() {
		return campaignMasterProxy;
	}

	public void setCampaignMasterProxy(CampaignMasterProxy campaignMasterProxy) {
		this.campaignMasterProxy = campaignMasterProxy;
	}

	public Boolean getIsPreScreenLogin() {
		return isPreScreenLogin;
	}

	public void setIsPreScreenLogin(Boolean isPreScreenLogin) {
		this.isPreScreenLogin = isPreScreenLogin;
	}
	
	

	public String getUrlCode() {
		return urlCode;
	}

	public void setUrlCode(String urlCode) {
		this.urlCode = urlCode;
	}

	@Override
	public String toString() {
		return "UsersRequest [id=" + id + ", userType=" + userType + ", termsAccepted=" + termsAccepted + ", isActive="
				+ isActive + ", otpVerified=" + otpVerified + ", emailVerified=" + emailVerified + ", remoteAddr="
				+ remoteAddr + ", email=" + email + ", password=" + password + ", confirmPassword=" + confirmPassword
				+ ", oldPassword=" + oldPassword + ", isPasswordSet=" + isPasswordSet + ", mobile=" + mobile
				+ ", userName=" + userName + ", name=" + name + ", otp=" + otp + ", otpMsg=" + otpMsg
				+ ", verificationUrl=" + verificationUrl + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", domain=" + domain + ", pan=" + pan + ", urlEncrypt=" + urlEncrypt
				+ ", otpStatus=" + otpStatus + ", otpOn=" + otpOn + ", otpVerificationType=" + otpVerificationType
				+ ", modifiedDate=" + modifiedDate + ", signUpDate=" + signUpDate + ", userOrgId=" + userOrgId
				+ ", applicationId=" + applicationId + ", userId=" + userId + ", userRoleId=" + userRoleId
				+ ", businessTypeId=" + businessTypeId + ", domainId=" + domainId + ", isMsmeUser=" + isMsmeUser
				+ ", isLocked=" + isLocked + ", isLockedByAdmin=" + isLockedByAdmin + ", isExistingUser="
				+ isExistingUser + ", browserName=" + browserName + ", browserVersion=" + browserVersion + ", device="
				+ device + ", deviceType=" + deviceType + ", deviceOs=" + deviceOs + ", deviceOsVersion="
				+ deviceOsVersion + ", userAgent=" + userAgent + ", userRoleIdString=" + userRoleIdString
				+ ", loanTypeIdString=" + loanTypeIdString + ", userOrgName=" + userOrgName + ", lastLoginDate="
				+ lastLoginDate + ", lastBusinessTypeId=" + lastBusinessTypeId + ", schemeId=" + schemeId
				+ ", captchaEnter=" + captchaEnter + ", captchaOriginal=" + captchaOriginal + ", campaignMasterId="
				+ campaignMasterId + ", isMobileLogin=" + isMobileLogin + ", fcmToken=" + fcmToken
				+ ", isRequiredAutoRegistration=" + isRequiredAutoRegistration + ", campaignMasterProxy="
				+ campaignMasterProxy + ", isPreScreenLogin=" + isPreScreenLogin + ", urlCode=" + urlCode + ", roleId="
				+ roleId + "]";
	}
	
	
}
