package com.opl.jns.users.api.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CampaignMasterProxy implements Serializable {

	private static final long serialVersionUID = 6232712419796541868L;

	private Long id;

	private String campaignUrl;

	private String name;

	private Long orgId;

	private String orgName;

	/**
	 * 1. Market Place 2. Bank Specific 3. Both
	 */
	private Integer campaignType;

	private String imageUrl;

	private String subDomainUrl;

	private Boolean isComingSoon;

	private String cssName;

	private Date modifiedDate;

	private Long modifiedBy;

	private Date createdDate;

	private Long createdBy;

	private Boolean isActive;

	private String configuration;

	public String getConfiguration() {
		return configuration;
	}

	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCampaignUrl() {
		return campaignUrl;
	}

	public void setCampaignUrl(String campaignUrl) {
		this.campaignUrl = campaignUrl;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public Integer getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(Integer campaignType) {
		this.campaignType = campaignType;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getSubDomainUrl() {
		return subDomainUrl;
	}

	public void setSubDomainUrl(String subDomainUrl) {
		this.subDomainUrl = subDomainUrl;
	}

	public Boolean getIsComingSoon() {
		return isComingSoon;
	}

	public void setIsComingSoon(Boolean isComingSoon) {
		this.isComingSoon = isComingSoon;
	}

	public String getCssName() {
		return cssName;
	}

	public void setCssName(String cssName) {
		this.cssName = cssName;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public CampaignMasterProxy(){	}

	public CampaignMasterProxy(Long id){
		this.id = id;
	}
}
