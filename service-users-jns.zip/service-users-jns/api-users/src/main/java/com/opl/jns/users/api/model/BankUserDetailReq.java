package com.opl.jns.users.api.model;

import java.util.List;

public class BankUserDetailReq {

	private List<Long> reqRoleIds;
	private Long orgId;
	private Long branchId;
	private Long schemeId;

	public List<Long> getReqRoleIds() {
		return reqRoleIds;
	}

	public void setReqRoleIds(List<Long> reqRoleIds) {
		this.reqRoleIds = reqRoleIds;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	@Override
	public String toString() {
		return "BankUserDetailReq [reqRoleIds=" + reqRoleIds + ", orgId=" + orgId + ", branchId=" + branchId
				+ ", schemeId=" + schemeId + "]";
	}
	
}
