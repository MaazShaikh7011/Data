package com.opl.jns.users.api.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UsersUtils {

	public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final int BUSINESS_TYPE_MSME = 1;
	public static final int BUSINESS_TYPE_PL = 3;
	public static final int BUSINESS_TYPE_HL = 5;

	public static final String ADMIN_MAKER = "Admin_Maker";
	public static final String ADMIN_CHECKER = "Admin_Checker";
	public static final String USER_ORG_ID = "userOrgId";

	public static final int REGISTRATION_SMS = 1;
	public static final int LOGIN_EMAIL = 2;
	public static final int MOBILE_CONSENT_SMS = 3;
	
	public static final int EMAIL_VERIFICATION_URL = 1;
//	public static final int CHANGE_PASSWORD_URL = 2;
	public static final int OTP_REQUEST_SIGNUP_TYPE = 1;
	public static final int OTP_REQUEST_LOGIN_TYPE = 2;
	public static final int OTP_REQUEST_UPDATE_MOBILE_TYPE = 3;
	public static final int OTP_REQUEST_MOBILE_TYPE = 1;
	public static final int OTP_REQUEST_EMAIL_TYPE = 2;
	public static final int CHANGE_PASSWORD_URL = 2;
//	((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20})
	public static final String PASSWARD_PATTERN = "((?=.*\\d)(?=.*[a-zA-Z])(?=.*[@#$%]).{8,20})";

	public static boolean isPatternMatch(String value, String patternToCheck) {
		Pattern pattern = Pattern.compile(patternToCheck);
		Matcher matcher = pattern.matcher(value);
		return matcher.matches();
	}

	public static String convertYesNo(String value) {
		if ("true".equalsIgnoreCase(value) || "1".equalsIgnoreCase(value)) {
			return "Yes";
		} else {
			return "No";
		}
	}

	public final class Status {
		private Status() {
			// Do nothing because of X and Y.
		}

		public static final int OPEN = 1;
		public static final int IN_PROGRESS = 2;
		public static final int REVERTED = 3;
		public static final int APPROVED = 4;
	}

	public final class BranchType {
		private BranchType() {
			// Do nothing because of X and Y.
		}

		public static final int BRANCH_OFFICE = 1;

	}

	public static Long getLoanTypeIdByBusinessTypeId(Long businessTypeId) {

		Long loanTypeId = null;
		if (businessTypeId.equals(1l) || businessTypeId.equals(2l)) {
			loanTypeId = 1l;
		} else if (businessTypeId.equals(3l)) { // PL
			loanTypeId = 7l;
		} else if (businessTypeId.equals(5l)) { // HL
			loanTypeId = 3l;
		} else if (businessTypeId.equals(6l)) { // MFI
			loanTypeId = 17l;
		} else if (businessTypeId.equals(8l)) { // AL
			loanTypeId = 12l;
		} else if (businessTypeId.equals(9l)) { // Co-origination
			loanTypeId = 9l;
		} else if (businessTypeId.equals(10l)) { // Mudra Loan
			loanTypeId = 10l; // This Loan Type is only for Permissions Related . In Loans we are Using WC and
								// TL for Actual Loan Type
		} else if (businessTypeId.equals(21l)) { // E- DFS Loan
			loanTypeId = 21l;
		} else if (businessTypeId.equals(22l)) { // ODOP
			loanTypeId = 22l;
		} else if (businessTypeId.equals(23l)) { // Amazon:(eRetail-Loan)
			loanTypeId = 23l;
		} else if (businessTypeId.equals(24l)) { // SBI:(E-VFS-LoanS)
			loanTypeId = 24l;
		}
		return loanTypeId;
	}

	public static Long getBusinessTypeIdByLoanTypeId(Long loanTypeId) {

		Long buisnessTypeId = null;
		if (loanTypeId.equals(1l) || loanTypeId.equals(2l) || loanTypeId.equals(16l)) {
			buisnessTypeId = 1l;
		} else if (loanTypeId.equals(7l)) { // PL
			buisnessTypeId = 3l;
		} else if (loanTypeId.equals(3l)) { // HL
			buisnessTypeId = 5l;
		} else if (loanTypeId.equals(17l)) { // MFI
			loanTypeId = 6l;
		} else if (loanTypeId.equals(12l)) { // AL
			buisnessTypeId = 8l;
		} else if (loanTypeId.equals(9l)) { // Co-origination
			buisnessTypeId = 9l;
		} else if (loanTypeId.equals(10l)) { // Mudra Loan
			buisnessTypeId = 10l; // This Loan Type is only for Permissions Related . In Loans we are Using WC and
									// TL for Actual Loan Type
		} else if (loanTypeId.equals(21l)) { // E- DFS Loan
			buisnessTypeId = 21l;
		} else if (loanTypeId.equals(22l)) { // ODOP
			buisnessTypeId = 22l;
		} else if (loanTypeId.equals(23l)) { // Amazon:(eRetail-Loan)
			buisnessTypeId = 23l;
		} else if (loanTypeId.equals(24l)) { // SBI:(E-VFS-LoanS)
			buisnessTypeId = 24l;
		}
		return buisnessTypeId;
	}

}
