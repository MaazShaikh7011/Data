package com.opl.jns.users.api.model;

public class ValidationsMstr {
	private String key;
	private String value;
	private String errorMassage;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getErrorMassage() {
		return errorMassage;
	}

	public void setErrorMassage(String errorMassage) {
		this.errorMassage = errorMassage;
	}

	@Override
	public String toString() {
		return "ValidationsMstr [key=" + key + ", value=" + value + ", errorMassage=" + errorMassage + "]";
	}

}
