package com.opl.jns.users.api.model;

import java.util.Date;
import java.util.List;

/**
 * @author jaimin.darji
 */
public class LoginResponse {

	private String access_token;
	private String token_type;
	private String expires_in;
	private String refresh_token;
	private String generateChangePass;
	private String message;
	private String email;
	private String mobile;
	private List<String> campaignCode;

	private Integer loginToken;
	private Integer status;
	private Integer userUrlType;
	private Integer businessType;

	private Long userId;
	private Long userType;
	private Long applicationId;
	private Long userOrgId;
	private String userOrgName;
	private Long userRoleId;
	private Long userBranchId;
	private Long isEmailVerified;
	private Integer loginCounter;
	private String userName;

	private Boolean isPasswordChanged;
	private Date passwordResetDate;
	private String configFlag;

	public String getConfigFlag() {
		return configFlag;
	}

	public void setConfigFlag(String configFlag) {
		this.configFlag = configFlag;
	}

	public LoginResponse() {
		super();
	}

	public LoginResponse(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getToken_type() {
		return token_type;
	}

	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}

	public String getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(String expires_in) {
		this.expires_in = expires_in;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getLoginToken() {
		return loginToken;
	}

	public void setLoginToken(Integer loginToken) {
		this.loginToken = loginToken;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public String getUserOrgName() {
		return userOrgName;
	}

	public void setUserOrgName(String userOrgName) {
		this.userOrgName = userOrgName;
	}

	public List<String> getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(List<String> campaignCode) {
		this.campaignCode = campaignCode;
	}

	public Long getIsEmailVerified() {
		return isEmailVerified;
	}

	public void setIsEmailVerified(Long isEmailVerified) {
		this.isEmailVerified = isEmailVerified;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public Boolean getIsPasswordChanged() {
		return isPasswordChanged;
	}

	public void setIsPasswordChanged(Boolean isPasswordChanged) {
		this.isPasswordChanged = isPasswordChanged;
	}

	public Integer getLoginCounter() {
		return loginCounter;
	}

	public void setLoginCounter(Integer loginCounter) {
		this.loginCounter = loginCounter;
	}

	public Long getUserBranchId() {
		return userBranchId;
	}

	public void setUserBranchId(Long userBranchId) {
		this.userBranchId = userBranchId;
	}

	public Integer getUserUrlType() {
		return userUrlType;
	}

	public void setUserUrlType(Integer userUrlType) {
		this.userUrlType = userUrlType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getGenerateChangePass() {
		return generateChangePass;
	}

	public void setGenerateChangePass(String generateChangePass) {
		this.generateChangePass = generateChangePass;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getPasswordResetDate() {
		return passwordResetDate;
	}

	public void setPasswordResetDate(Date passwordResetDate) {
		this.passwordResetDate = passwordResetDate;
	}

	@Override
	public String toString() {
		return "LoginResponse [access_token=" + access_token + ", token_type=" + token_type + ", expires_in="
				+ expires_in + ", refresh_token=" + refresh_token + ", generateChangePass=" + generateChangePass
				+ ", message=" + message + ", email=" + email + ", mobile=" + mobile + ", campaignCode=" + campaignCode
				+ ", loginToken=" + loginToken + ", status=" + status + ", userUrlType=" + userUrlType
				+ ", businessType=" + businessType + ", userId=" + userId + ", userType=" + userType
				+ ", applicationId=" + applicationId + ", userOrgId=" + userOrgId + ", userRoleId=" + userRoleId
				+ ", userBranchId=" + userBranchId + ", isEmailVerified=" + isEmailVerified + ", loginCounter="
				+ loginCounter + ", userName=" + userName + ", isPasswordChanged=" + isPasswordChanged + "]";
	}

	

}
