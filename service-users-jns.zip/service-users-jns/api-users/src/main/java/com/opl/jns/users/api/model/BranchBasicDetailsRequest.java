package com.opl.jns.users.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;
import java.util.Date;

/**
 * @author sandip.bhetariya
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BranchBasicDetailsRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;

	private String name;

	private Long roleId;

	private Integer cityId;

	private String cityName;
	
	private String cityValue;

	private String code;

	private String contactPersonEmail;

	private String contactPersonName;

	private String contactPersonNumber;

	private Integer countryId;

	private String faxNo;

	private Boolean isHo;

	private String landMark;

	private Long orgId;

	private Integer parentBranchId;

	private Integer pincode;

	private String premisesNo;

	private String remarks;

	private Integer stateId;

	private String stateName;
	
	private String stateValue;

	private String streetName;

	private String telephoneNo;

	private String ifscCode;

	private Long locationId;

	private Integer pageIndex;

	private Integer size;

	private Long userId;

	private Long jobId;

	private Integer status;

	private Date approvedDate;

	private Boolean isCopied;

	private Integer dataReqType;

	private Long branchId;

	private Boolean isActive;

//	private List<BranchCategoryRequest> branchCategoryRequestList;
//
//	private List<DepartmentRequest> departmentRequestList;

	private Boolean isDeleted;

	private Boolean isEdit;

//	private LocationMasterResponse locationMasterResponse;

	private Object workflowData;

	private Long loanSystemId;

	private String locationCode;

	private String smecCode;

	private String smecName;

	private String smecEmail;

	private String smecMobile;

	private String imagePath;

	private Long businessTypeId;
	
	private Long schTypeId;

	private String shortLogoUrl;

	private String largeLogoUrl;

	private String bankName;
	
	private Long zoId;
	
	private Long roId;
	
	private String lhoId;
	
	private Integer ruralUrbanId;

	public Long getRoId() {
		return roId;
	}

	public void setRoId(Long roId) {
		this.roId = roId;
	}

	public Long getZoId() {
		return zoId;
	}

	public void setZoId(Long zoId) {
		this.zoId = zoId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Object getWorkflowData() {
		return workflowData;
	}

	public void setWorkflowData(Object workflowData) {
		this.workflowData = workflowData;
	}

	public String getShortLogoUrl() {
		return shortLogoUrl;
	}

	public void setShortLogoUrl(String shortLogoUrl) {
		this.shortLogoUrl = shortLogoUrl;
	}

	public String getLargeLogoUrl() {
		return largeLogoUrl;
	}

	public void setLargeLogoUrl(String largeLogoUrl) {
		this.largeLogoUrl = largeLogoUrl;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long long1) {
		this.roleId = long1;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getContactPersonEmail() {
		return contactPersonEmail;
	}

	public void setContactPersonEmail(String contactPersonEmail) {
		this.contactPersonEmail = contactPersonEmail;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public Boolean getIsHo() {
		return isHo;
	}

	public void setIsHo(Boolean ho) {
		isHo = ho;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Integer getParentBranchId() {
		return parentBranchId;
	}

	public void setParentBranchId(Integer parentBranchId) {
		this.parentBranchId = parentBranchId;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getPremisesNo() {
		return premisesNo;
	}

	public void setPremisesNo(String premisesNo) {
		this.premisesNo = premisesNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}


	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public Long getLocationId() {
		return locationId;
	}

	public void setLocationId(Long locationId) {
		this.locationId = locationId;
	}

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Boolean getIsCopied() {
		return isCopied;
	}

	public void setIsCopied(Boolean copied) {
		isCopied = copied;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getDataReqType() {
		return dataReqType;
	}

	public void setDataReqType(Integer dataReqType) {
		this.dataReqType = dataReqType;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean active) {
		isActive = active;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean deleted) {
		isDeleted = deleted;
	}

	public Boolean getEdit() {
		return isEdit;
	}

	public void setEdit(Boolean edit) {
		isEdit = edit;
	}

	public String getContactPersonNumber() {
		return contactPersonNumber;
	}

	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}

	public Long getLoanSystemId() {
		return loanSystemId;
	}

	public void setLoanSystemId(Long loanSystemId) {
		this.loanSystemId = loanSystemId;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getSmecCode() {
		return smecCode;
	}

	public void setSmecCode(String smecCode) {
		this.smecCode = smecCode;
	}

	public String getSmecName() {
		return smecName;
	}

	public void setSmecName(String smecName) {
		this.smecName = smecName;
	}

	public String getSmecEmail() {
		return smecEmail;
	}

	public void setSmecEmail(String smecEmail) {
		this.smecEmail = smecEmail;
	}

	public String getSmecMobile() {
		return smecMobile;
	}

	public void setSmecMobile(String smecMobile) {
		this.smecMobile = smecMobile;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Long getBusinessTypeId() {
		return businessTypeId;
	}

	public void setBusinessTypeId(Long businessTypeId) {
		this.businessTypeId = businessTypeId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCityValue() {
		return cityValue;
	}

	public void setCityValue(String cityValue) {
		this.cityValue = cityValue;
	}

	public String getStateValue() {
		return stateValue;
	}

	public void setStateValue(String stateValue) {
		this.stateValue = stateValue;
	}
		
	public Long getSchTypeId() {
		return schTypeId;
	}

	public void setSchTypeId(Long schTypeId) {
		this.schTypeId = schTypeId;
	}
	
	public String getLhoId() {
		return lhoId;
	}

	public void setLhoId(String lhoId) {
		this.lhoId = lhoId;
	}

	public Integer getRuralUrbanId() {
		return ruralUrbanId;
	}

	public void setRuralUrbanId(Integer ruralUrbanId) {
		this.ruralUrbanId = ruralUrbanId;
	}

	public BranchBasicDetailsRequest(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public BranchBasicDetailsRequest(Long id, String name, String code) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
	}

	public BranchBasicDetailsRequest(Long id, Integer stateId) {
		super();
		this.id = id;
		this.stateId = stateId;
	}

	public BranchBasicDetailsRequest() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BranchBasicDetailsRequest other = (BranchBasicDetailsRequest) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public BranchBasicDetailsRequest(Long id) {
		super();
		this.id = id;
	}
	
	public BranchBasicDetailsRequest(Long id, String name, String code,Integer cityId,Integer stateId,Long roId,Long zoId,Integer ruralUrbanId) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.cityId = cityId;
		this.stateId = stateId;
		this.roId = roId;
		this.zoId = zoId;
		this.ruralUrbanId = ruralUrbanId;
	}
	
	public BranchBasicDetailsRequest(Long id, String name, String code,Integer cityId,Integer stateId,Long roId,Long zoId,String lhoId,Integer ruralUrbanId) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.cityId = cityId;
		this.stateId = stateId;
		this.roId = roId;
		this.zoId = zoId;
		this.lhoId = lhoId;
		this.ruralUrbanId = ruralUrbanId;
	}

	@Override
	public String toString() {
		return "BranchBasicDetailsRequest [id=" + id + ", name=" + name + ", roleId=" + roleId + ", cityId=" + cityId
				+ ", cityName=" + cityName + ", cityValue=" + cityValue + ", code=" + code + ", contactPersonEmail="
				+ contactPersonEmail + ", contactPersonName=" + contactPersonName + ", contactPersonNumber="
				+ contactPersonNumber + ", countryId=" + countryId + ", faxNo=" + faxNo + ", isHo=" + isHo
				+ ", landMark=" + landMark + ", orgId=" + orgId + ", parentBranchId=" + parentBranchId + ", pincode="
				+ pincode + ", premisesNo=" + premisesNo + ", remarks=" + remarks + ", stateId=" + stateId
				+ ", stateName=" + stateName + ", stateValue=" + stateValue + ", streetName=" + streetName
				+ ", telephoneNo=" + telephoneNo + ", ifscCode=" + ifscCode + ", locationId=" + locationId
				+ ", pageIndex=" + pageIndex + ", size=" + size + ", userId=" + userId + ", jobId=" + jobId
				+ ", status=" + status + ", approvedDate=" + approvedDate + ", isCopied=" + isCopied + ", dataReqType="
				+ dataReqType + ", branchId=" + branchId + ", isActive=" + isActive + ", isDeleted=" + isDeleted
				+ ", isEdit=" + isEdit + ", workflowData=" + workflowData + ", loanSystemId=" + loanSystemId
				+ ", locationCode=" + locationCode + ", smecCode=" + smecCode + ", smecName=" + smecName
				+ ", smecEmail=" + smecEmail + ", smecMobile=" + smecMobile + ", imagePath=" + imagePath
				+ ", businessTypeId=" + businessTypeId + ", schTypeId=" + schTypeId + ", shortLogoUrl=" + shortLogoUrl
				+ ", largeLogoUrl=" + largeLogoUrl + ", bankName=" + bankName + ", zoId=" + zoId + ", roId=" + roId
				+ "]";
	}

	

	
	
	

}
