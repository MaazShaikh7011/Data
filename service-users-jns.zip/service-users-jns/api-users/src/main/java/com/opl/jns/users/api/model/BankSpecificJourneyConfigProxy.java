package com.opl.jns.users.api.model;

import java.util.Date;
import java.util.List;


public class BankSpecificJourneyConfigProxy {

	private Long id;
	
	private Long journeyConfigId;
	
	private Long campaignId;
	
	private Long schemeId;
	
	private String configuration;
	
	private Integer createdBy;

	private Date createdDate;
	
	private Long modifiedBy;
	
	private String modifiedName;
	
	private Date modifiedDate;
	
	private Boolean isActive;
	
	private Long userId;
	
	private Long userOrgId;
	
	private List<JourneyQuestionsProxy> journeyQuestionsList;

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public BankSpecificJourneyConfigProxy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getJourneyConfigId() {
		return journeyConfigId;
	}

	public void setJourneyConfigId(Long journeyConfigId) {
		this.journeyConfigId = journeyConfigId;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	public Long getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Long schemeId) {
		this.schemeId = schemeId;
	}

	public String getConfiguration() {
		return configuration;
	}

	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public List<JourneyQuestionsProxy> getJourneyQuestionsList() {
		return journeyQuestionsList;
	}

	public void setJourneyQuestionsList(List<JourneyQuestionsProxy> journeyQuestionsList) {
		this.journeyQuestionsList = journeyQuestionsList;
	}
	
	
}
