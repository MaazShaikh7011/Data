package com.opl.jns.users.api.model;

import java.io.Serializable;


public class UserCommonRes implements Serializable {

	private static final long serialVersionUID = 1L;

	private String message;

	private Object data;

	private Integer status;

	private Boolean flag;
	
	private Integer responseType;
	private String sysMessage;
	private Integer msgCode;
	private Boolean isMsgDisp;
	private String success;
	private Long moduleId;

	public UserCommonRes() {
		super();
	}

	public UserCommonRes(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}

	public UserCommonRes(String message, Object data, Integer status) {
		super();
		this.message = message;
		this.data = data;
		this.status = status;
	}

	public UserCommonRes(String message, Object data, Integer status, Boolean flag) {
		super();
		this.message = message;
		this.data = data;
		this.status = status;
		this.flag = flag;
	}
	
	public UserCommonRes(String message, Integer status, Boolean flag) {
		super();
		this.message = message;
		this.status = status;
		this.flag = flag;
	}

	public UserCommonRes(String message, Integer status, Object dataObject) {
		super();
		this.status = status;
		this.message = message;
		this.data= dataObject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public Integer getResponseType() {
		return responseType;
	}

	public void setResponseType(Integer responseType) {
		this.responseType = responseType;
	}

	public String getSysMessage() {
		return sysMessage;
	}

	public void setSysMessage(String sysMessage) {
		this.sysMessage = sysMessage;
	}

	public Integer getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(Integer msgCode) {
		this.msgCode = msgCode;
	}

	public Boolean getIsMsgDisp() {
		return isMsgDisp;
	}

	public void setIsMsgDisp(Boolean isMsgDisp) {
		this.isMsgDisp = isMsgDisp;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public Long getModuleId() {
		return moduleId;
	}

	public void setModuleId(Long moduleId) {
		this.moduleId = moduleId;
	}

	@Override
	public String toString() {
		return "CommonResponse [message=" + message + ", data=" + data + ", status=" + status + ", flag=" + flag
				+ ", responseType=" + responseType + ", sysMessage=" + sysMessage + ", msgCode=" + msgCode
				+ ", isMsgDisp=" + isMsgDisp + ", success=" + success + ", moduleId=" + moduleId + "]";
	}
	
	


}
