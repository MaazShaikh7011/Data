package com.opl.jns.users.api.model;

public class UserNotificationDetailsReq {
	private Long userId;
	private Long userOrgId;
	private Long userBranchId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getUserOrgId() {
		return userOrgId;
	}

	public void setUserOrgId(Long userOrgId) {
		this.userOrgId = userOrgId;
	}

	public Long getUserBranchId() {
		return userBranchId;
	}

	public void setUserBranchId(Long userBranchId) {
		this.userBranchId = userBranchId;
	}

	@Override
	public String toString() {
		return "UserNotificationDetailsReq [userId=" + userId + ", userOrgId=" + userOrgId + ", userBranchId="
				+ userBranchId + "]";
	}
	
}
