package com.opl.jns.users.api.model;

public class ValidationProxy {
	private String moduleName;
	private Long moduleId;
	private Long fieldId;
	private String fieldName;
	private String value;
	private String validationValue;
	private String errorMessage;

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Long getModuleId() {
		return moduleId;
	}

	public void setModuleId(Long moduleId) {
		this.moduleId = moduleId;
	}

	public Long getFieldId() {
		return fieldId;
	}

	public void setFieldId(Long fieldId) {
		this.fieldId = fieldId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValidationValue() {
		return validationValue;
	}

	public void setValidationValue(String validationValue) {
		this.validationValue = validationValue;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "ValidationProxy [moduleName=" + moduleName + ", moduleId=" + moduleId + ", fieldId=" + fieldId + ", fieldName=" + fieldName + ", value=" + value + ", validationValue=" + validationValue + ", errorMessage=" + errorMessage + "]";
	}

}
