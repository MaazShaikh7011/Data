package com.opl.jns.users.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CampaignUserMappingProxy implements Serializable {

	private static final long serialVersionUID = 6232712419796541868L;

	private Long userId;// Required

//	private UsersRequest usersRequest;

	private CampaignMasterProxy campaignMaster;

	private Date createdDate;

	private Date updatedDate;

	private Boolean isActive;

	private Long userLastCampaignId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public CampaignMasterProxy getCampaignMaster() {
		return campaignMaster;
	}

	public void setCampaignMaster(CampaignMasterProxy campaignMaster) {
		this.campaignMaster = campaignMaster;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Boolean getActive() {
		return isActive;
	}

	public void setActive(Boolean active) {
		isActive = active;
	}

	public Long getUserLastCampaignId() {
		return userLastCampaignId;
	}

	public void setUserLastCampaignId(Long userLastCampaignId) {
		this.userLastCampaignId = userLastCampaignId;
	}

	//	public UsersRequest getUsersRequest() {
//		return usersRequest;
//	}
//
//	public void setUsersRequest(UsersRequest usersRequest) {
//		this.usersRequest = usersRequest;
//	}
}
