
Create Table

CREATE TABLE `bank_specific_joureny_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint(20) NOT NULL,
  `scheme_id` bigint(20) DEFAULT NULL,
  `configuration` text,
  `created_by` bigint(20) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `is_active` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_id` (`campaign_id`,`is_active`,`scheme_id`),
  KEY `id` (`id`),
  CONSTRAINT `bank_specific_joureny_config_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaign_master` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1







Create Table

CREATE TABLE `bank_specific_joureny_config_audit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `journey_config_id` bigint(20) DEFAULT NULL,
  `campaign_id` bigint(20) DEFAULT NULL,
  `scheme_id` bigint(20) DEFAULT NULL,
  `configuration_type` bigint(20) DEFAULT NULL,
  `configuration_value` bit(1) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` bigint(20) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journey_config_id` (`journey_config_id`),
  CONSTRAINT `bank_specific_joureny_config_audit_ibfk_1` FOREIGN KEY (`journey_config_id`) REFERENCES `bank_specific_joureny_config` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1




Menu Permission


insert into `menu_master` (`id`, `key_name`, `display_name`, `sequence`, `parent_id`, `icon_path`, `is_active`, `is_admin_menu`, `is_menu_view`) 
values('99','BANK_SPECIFIC_JOURENY_CONFIG','Bank Specific Journey Configuration','4','31','Monitoring-inactive.svg','','','');



insert into `menu_path_master` (`navigation_path`, `menu_id`, `loan_type_id`, `scheme_id`) values('/Config/BankSpecificJourenyConfig','99','9',NULL);
insert into `menu_path_master` (`navigation_path`, `menu_id`, `loan_type_id`, `scheme_id`) values('/Config/BankSpecificJourenyConfig','99','5',NULL);
insert into `menu_path_master` (`navigation_path`, `menu_id`, `loan_type_id`, `scheme_id`) values('/Config/BankSpecificJourenyConfig','99','1',NULL);
insert into `menu_path_master` (`navigation_path`, `menu_id`, `loan_type_id`, `scheme_id`) values('/Config/BankSpecificJourenyConfig','99','11',NULL);
insert into `menu_path_master` (`navigation_path`, `menu_id`, `loan_type_id`, `scheme_id`) values('/Config/BankSpecificJourenyConfig','99','12',NULL);




insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','9',NULL,'','1');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','9',NULL,'','2');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','9',NULL,'','3');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','5',NULL,'','4');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','11',NULL,'','6');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','11',NULL,'','7');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','1',NULL,'','8');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','1',NULL,'','9');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','12',NULL,'','11');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','1',NULL,'','12');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','1',NULL,'','13');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','12',NULL,'','14');
insert into `menu_role_loan_mapping` ( `navigation_path`, `menu_id`, `role_id`, `business_type_id`, `sequence`, `is_active`, `scheme_id`) values(NULL,'99','11','11',NULL,'','15');

