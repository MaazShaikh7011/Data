CREATE OR REPLACE NONEDITIONABLE PROCEDURE spgetallmenuforbanker (
    userid IN NUMBER, result OUT CLOB
) IS
    usertypeid  NUMBER;
    userroleid  NUMBER;
    query        CLOB;
BEGIN

	-- SQLINES LICENSE FOR EVALUATION USE ONLY
    SELECT
        user_role_id,
        user_type_id
    INTO
        userroleid,
        usertypeid
    FROM
        jns_users.users
    WHERE
            user_id = userid
        AND is_active = 1;
    

	-- SQLINES LICENSE FOR EVALUATION USE ONLY
	 query := 'SELECT
        JSON_ARRAYAGG(JSON_OBJECT(
                          ''keyName'' VALUE temp.keyname,
                          ''displayName'' VALUE temp.displayname,
                          ''iconPath'' VALUE temp.iconpath,
                                    ''navigatePath'' VALUE temp.navigatepath,
                                    ''childList'' VALUE temp.childlist,
                                    ''seq'' VALUE temp.seq,
                                    ''schemeId'' VALUE temp.schemeid 
	                      )) AS menulist
    FROM
        (
            SELECT
                mm.key_name           AS keyname,
                mm.display_name       AS displayname,
                mm.icon_path          AS iconpath,
                mm.navigation_path    AS navigatepath,
                mm.sequence           AS seq,
                mml.scheme_id         AS schemeid, -- mm.is_menu_view AS isMenuView,
	                (
                    SELECT
                        JSON_ARRAYAGG(JSON_OBJECT(
                                          ''keyName'' VALUE m.key_name,
                                          ''displayName'' VALUE m.display_name,
                                          ''iconPath'' VALUE m.icon_path,
                                                    ''navigatePath'' VALUE m.navigation_path,
                                                    ''seq'' VALUE m.sequence
                                      ))
                    FROM
                        jns_users.menu_master          m
                        LEFT JOIN jns_users.menu_role_mapping    ml ON ml.menu_id = m.id
                    WHERE
                            ml.role_id = mml.role_id
                        AND ml.type_id = mml.type_id
                        AND ml.scheme_id = mml.scheme_id
                        AND m.parent_id = mm.id
                        AND m.is_active = 1
                        AND ml.is_active = 1
                    ORDER BY
                        m.sequence ASC
                )                     AS childlist
            FROM
                jns_users.menu_master          mm
                LEFT JOIN jns_users.menu_role_mapping    mml ON mml.menu_id = mm.id
            WHERE
                    mml.role_id = ' || userroleid || '
                AND mml.type_id = ' || usertypeid || '
                AND mm.parent_id IS NULL
                AND mm.is_active = 1
                AND mml.is_active = 1
            ORDER BY
                mm.sequence ASC
        )';
        
        
        dbms_output.put_line(query);
        
        EXECUTE IMMEDIATE query INTO result;

END;
