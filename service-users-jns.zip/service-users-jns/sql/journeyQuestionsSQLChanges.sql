UPDATE `users`.`journey_questions` SET `configuration` = '{"label":"Do you want to keep bank statment upload as mandatory for applicant ?","configurationType":"2","controlType":2,"history":[],"key":"bankStatement","value":false,"isCollapsed":false,"subQuestions":[{"label":"Select duration to upload Bank statement","controlType":1,"key":"duration","configurationType":"1","value":null,"isCollapsed":false,"options":[{"label":"Last 6 months","value":"6"},{"label":"Last 12 months","value":"12"},{"label":"Last 18 months","value":"18"}]},{"label":"Mandatory to upload bank statement","controlType":1,"key":"mandatoryToUpload","configurationType":"2","value":null,"isCollapsed":false,"options":[{"label":"ETB customer","value":"1"},{"label":"NTB customer","value":"2"},{"label":"Both","value":"3"}]}],"options":[{"label":"Yes","value":true},{"label":"No","value":false}]}' WHERE `id` = '2'; 

INSERT INTO `users`.`journey_questions` VALUES (4,1,'{"label":"Do you want to enable the feature of end-to-end digital journey i.e. Journey to direct sanction of loan application to customer?","configurationType":"4","controlType":2,"history":[],"key":"digitalJourney","value":false,"isCollapsed":false,"subQuestions":[{"label":"Do you want to display digital approval product with digital sanction product?","controlType":1,"configurationType":"1","key":"digitalApproval","value":false,"isCollapsed":false,"options":[{"label":"Yes","value":true},{"label":"No","value":false}]},{"label":"Select Campaign type for which you want to enable End to end digital process","controlType":1,"key":"CampaignType","configurationType":"2","value":null,"isCollapsed":false,"options":[{"label":"Market Place","value":"1"},{"label":"Bank Specific","value":"2"},{"label":"Both","value":"3"}]}],"options":[{"label":"Yes","value":true},{"label":"No","value":false}]}',NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions` VALUES (5,1,'{"label":"Select purpose of loan for which you want to give loans","configurationType":"5","controlType":1,"history":[],"key":"loanPurpose","value":"3","isCollapsed":false,"subQuestions":[],"options":[{"label":"Working Capital (CC/OD)","value":"1"},{"label":"Term Loan (Asset Acquisition)","value":"2"},{"label":"Both","value":"3"}]}',NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions` VALUES (6,1,'{"label":"Do you want to skip GST part in borrower journey? ","configurationType":"6","controlType":1,"history":[],"key":"skipGstPart","value":false,"isCollapsed":false,"subQuestions":[],"options":[{"label":"Yes","value":true},{"label":"No","value":false}]}',NULL,NULL,NULL,TRUE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,1,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,1,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,1,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,2,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,2,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,2,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,3,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,3,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,3,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,4,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,4,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,4,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,5,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,5,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,5,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,6,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,6,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,6,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,7,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,7,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,7,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,8,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,8,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,8,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,9,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,9,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,9,NULL,NULL,NULL,NULL,TRUE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,10,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,10,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,10,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,11,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,11,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,11,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,12,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,12,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,12,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,13,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,13,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,13,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,14,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,14,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,14,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,15,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,15,NULL,NULL,NULL,NULL,FALSE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,15,NULL,NULL,NULL,NULL,FALSE);

INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,1,NULL,0,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,2,NULL,0,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,3,NULL,0,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,4,NULL,0,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,5,NULL,0,NULL,NULL,NULL,NULL,TRUE);
INSERT INTO `users`.`journey_questions_mapping` VALUES(NULL,6,NULL,0,NULL,NULL,NULL,NULL,TRUE);
