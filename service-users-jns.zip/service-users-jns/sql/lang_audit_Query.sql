CREATE TABLE `users`.`lang_audit` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT(20) DEFAULT NULL,
  `application_id` BIGINT(20) DEFAULT NULL,
  `application_code` VARCHAR(120) DEFAULT NULL,
  `scheme_id` BIGINT(20) DEFAULT NULL,
  `lang` VARCHAR(20) DEFAULT NULL,
  `created_date` DATETIME DEFAULT NULL,
  `is_active` BIT(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) 
