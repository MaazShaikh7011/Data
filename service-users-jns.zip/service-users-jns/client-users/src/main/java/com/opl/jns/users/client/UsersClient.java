package com.opl.jns.users.client;

import java.lang.reflect.Array;
import java.util.*;

import com.opl.jns.users.api.model.*;
import com.opl.jns.utils.common.CommonResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

public class UsersClient {

	private static Logger logger = LoggerFactory.getLogger(UsersClient.class);

	private static final String GET_USERS_DETAIL_BY_USER_ID = "/v3/getUserDetailsById/";
	private static final String GET_BRANCH_DETAILS = "/v3/get";
	private static final String GET_BRANCH_LIST_DETAILS = "/v3/get/getBranchByListId";
	private static final String GET_USER_NOTIFICATION_DETAILS = "/v3/getUserNotificationDetails";
	private static final String GET_EMAIL_MOBILE = "/v3/get/emailmobile";
	private static final String GET_BANK_USER_DETAILS = "/v3/getBankUserDetailsByOrgIdBranchIdRoleId";
	private static final String GET_LIST_OF_USER = "/v3/getByUserId";
	private static final String GET_BRANCH_BY_BRANCH_CODE = "/v3/getBranchByCode";
	private static final String GET_BRANCH_BY_SCHEME = "/v3/getBranchByScheme";
	private static final String GET_ORGANIZATION_NAME = "/v3/org/getOrganizationName";
	private static final String GET_ORGANIZATION_BY_ID = "/v3/org/getOrganizationById";
	private static final String CHECK_ORGSTATUSBY_ORGID_SCHEMEID_CAMPAINTYPE = "/v3/org/checkOrgStatusByOrgIdAndSchemeIdAndCampainType";
	private static final String GET_ALL_INACTIVE_ORG_LIST = "/v3/org/getAllInActiveOrgList";
	private static final String GET_CAMPAIGN_MASTER = "/v3/campaign/getByCampaignId";
	private static final String GET_CAMPAIGN_MASTER_LIST = "/v3/campaign/getByListOfCampaignId";
	private static final String GET_USERS_DETAIL_BY_USER_IDS = "/v3/getUserDetailsByListOfIds";
	private static final String GET_JOURNEY_CONFIG_FOR_PRODUCT_SCORING = "/v3/campaign/getJourneyConfigForProductScoring";
	private static final String GET_BANK_SPECIFIC_CONFIG_BY_CAMPID = "/v3/campaign/getBankSpecificConfigByCampId";
	private static final String PRE_SCREEN_SIGN_UP = "/v3/signup/preScreenSignUp";
	private static final String PRE_SCREEN_LOGIN = "/v3/login";
	private static final String GET_ORG_MASTER_LIST_BY_USER_TYPE_ID = "/v3/org/getOrgMasterListByUserTypeId";
	private static final String GET_ORGANISATION_MASTER_LIST_BY_USER_TYPE_ID = "/v3/org/getOrganisationMstListByUserTypeId";
	private static final String GET_BRANCH_BY_CODE_AND_IFSC_AND_ORGID = "/v3/getBranchByCodeAndIfscAndOrgId";
	private static final String GET_BRANCH_RO_ZO_BY_CODE_AND_IFSC_AND_ORGID = "/v3/getBranchDetailsRoZOByCodeAndIfscAndOrgId";
	private static final String GET_FIRST_USERID_BY_ORGID_AND_HO_ROLEID = "/v3/getFirstUserIdByOrgIdAndHoRoleID";

	private static final String GET_ORGANIZATION_DETAILS_FOR_PDF = "/v3/org/getOrganizationDetailsForPDF";
	private static final String GET_ORGANIZATION_DETAILS_BY_ORG_IDS = "/v3/org/getOrganizationDetailsByOrgIds";
	private static final String UPDATE_MOBILE_BY_USER_ID = "/v3/updateMobileByUserId";
	private static final String CHECK_MOBILE = "/v3/signup/checkMobile";


	private String baseUrl;

	private RestTemplate restTemplate;
	private static final String REQ_AUTH = "req_auth";

	public UsersClient(String baseUrl) {
		this.baseUrl = baseUrl;
		restTemplate = new RestTemplate();
	}

	public static void setClient(HttpHeaders headers) {
		headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		headers.add("Accept", "application/json");
	}

	@SuppressWarnings("unchecked")
	public UsersRequest getUserDetailsByUserId(Long userId) {
		try {
			String url = baseUrl.concat(GET_USERS_DETAIL_BY_USER_ID) + userId;
			logger.info("Enter in getUserDetailsByUserId URL ---------->" + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			UserResponse res = restTemplate.exchange(url, HttpMethod.GET, entity, UserResponse.class).getBody();
			if (res != null && res.getFlag()) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) res.getData(), UsersRequest.class);
			}
		} catch (Exception e) {
			logger.error("Exception while getUserDetailsByUserId -> ", e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<UsersRequest> getUserDetailsByListOfIds(List<Long> userIds) {
		try {
			String url = baseUrl.concat(GET_USERS_DETAIL_BY_USER_IDS);
			//			String url = "http://localhost:8083/user/getUserDetailsByListOfIds";
			logger.info("Enter in getUserDetailsByListOfIds URL ---------->" + url);

			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<List<Long>> entity = new HttpEntity<>(userIds, headers);
			UserResponse comRes = restTemplate.exchange(url, HttpMethod.POST, entity, UserResponse.class).getBody();
			List<UsersRequest> responseList = new ArrayList<>();
			List<Object> objects = ((List<Object>) comRes.getListData());
			for (Object o : objects) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), UsersRequest.class));
			}
			return responseList;

		} catch (Exception e) {
			logger.error("Exception while getUserDetailsByUserId -> ", e);

		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public BranchBasicDetailsRequest getBranch(Long branchId) {
		String url = baseUrl.concat(GET_BRANCH_DETAILS) + "/" + branchId;
		//		url = "http://localhost:8082/user/get/"+ branchId;
		logger.info("getBranch______url---->" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			HttpEntity<BranchBasicDetailsRequest> entity = new HttpEntity<BranchBasicDetailsRequest>(headers);
			//			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.GET, entity, UserCommonRes.class).getBody();
			if (comRes != null && comRes.getStatus() == 200 && comRes.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) comRes.getData(), BranchBasicDetailsRequest.class);
			}
		} catch (Exception e) {
			logger.error("Exception while Get Education Stage  ---> ", e);
		}
		logger.info("Branch Details Not Found ID-" + branchId);
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<BranchBasicDetailsRequest> getBranchByListId(Set<Long> id) {
		String url = baseUrl.concat(GET_BRANCH_LIST_DETAILS);
		logger.info("Get City List By URL ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Set<Long>> entity = new HttpEntity<>(id, headers);
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.POST, entity, UserCommonRes.class).getBody();
			List<BranchBasicDetailsRequest> responseList = new ArrayList<>();
			List<Object> objects = ((List<Object>) comRes.getData());
			for (Object o : objects) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), BranchBasicDetailsRequest.class));
			}
			return responseList;
		} catch (Exception e) {
			logger.error("Exception while getCityByCityListId  ---> ", e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public UserNotificationDetailsRes getUserNotificationDetails(UserNotificationDetailsReq userNotificationReq) {
		String url = baseUrl.concat(GET_USER_NOTIFICATION_DETAILS);

		try {
			logger.info("get Users Notification Details URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			HttpEntity<UserNotificationDetailsReq> entity = new HttpEntity<>(userNotificationReq, headers);
			UserResponse res = restTemplate.exchange(url, HttpMethod.POST, entity, UserResponse.class).getBody();
			if (res != null && res.getFlag()) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) res.getData(), UserNotificationDetailsRes.class);
			}
		} catch (Exception e) {
			logger.error("Exception while getUserNotificationDetails -> ", e);
		}
		return null;
	}

	public UserResponse getEmailMobile(Long userId) {
		try {
			String url = baseUrl.concat(GET_EMAIL_MOBILE);
			UsersRequest usersRequest = new UsersRequest();
			usersRequest.setId(userId);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(usersRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, UserResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Error while getting Email address & Mobile number of user.Something went wrong..!userId:" + userId, e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public List<BankUserDetailRes> getUserDetailsByOrgIdBranchIdRoleId(BankUserDetailReq bankUserDetailReq) {
		String url = baseUrl.concat(GET_BANK_USER_DETAILS);

		try {
			logger.info("get Bank user details URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			HttpEntity<BankUserDetailReq> entity = new HttpEntity<>(bankUserDetailReq, headers);
			UserResponse res = restTemplate.exchange(url, HttpMethod.POST, entity, UserResponse.class).getBody();
			List<BankUserDetailRes> responseList = new ArrayList<>();
			List listData = res.getListData();
			for (Object o : listData) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), BankUserDetailRes.class));
			}
			return responseList;
		} catch (Exception e) {
			logger.error("Exception while getUserDetailsByOrgIdBranchIdRoleId -> ", e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public BranchBasicDetailsRequest getBranchCode(Long schemeId, Long orgId, String branchCode) {
		String url = baseUrl.concat(GET_BRANCH_BY_BRANCH_CODE + "/" + schemeId + "/" + orgId + "/" + branchCode);

		try {
			logger.info("get BranchCode URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<List<Long>> entity = new HttpEntity<>(null, headers);
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.GET, entity, UserCommonRes.class).getBody();
			Object object = comRes.getData();
			BranchBasicDetailsRequest branchBasicDetailsRequest = MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) object), BranchBasicDetailsRequest.class);

			return branchBasicDetailsRequest;
		} catch (Exception e) {
			logger.error("Exception while getBranchCode -> ", e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<BranchBasicDetailsRequest> getBranchByScheme(Long schemeId, Long orgId) {
		String url = baseUrl.concat(GET_BRANCH_BY_SCHEME + "/" + schemeId + "/" + orgId);

		try {
			logger.info("get Branch Scheme URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(schemeId, headers);
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.GET, entity, UserCommonRes.class).getBody();
			Object object = comRes.getData();
			List<BranchBasicDetailsRequest> responseList = new ArrayList<>();
			List<Object> objects = ((List<Object>) comRes.getData());
			for (Object o : objects) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), BranchBasicDetailsRequest.class));
			}
			return responseList;
		} catch (Exception e) {
			logger.error("Exception while getBranch Scheme -> ", e);
		}
		return null;
	}

	public String getOrganizationName(Long orgId) {
		String url;
		url = baseUrl.concat(GET_ORGANIZATION_NAME) + "/" + orgId;

		logger.info("Enter in getOrganizationName()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			CommonResponse body = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(body) && !OPLUtils.isObjectNullOrEmpty(body.getData())) {
				return body.getData().toString();
			}
			return null;
		} catch (Exception e) {
			logger.error("Throw Exception While getOrganizationName ", e);
			return null;
		}
	}

	public CommonResponse getOrganizationById(Long orgId) {
		String url;
		url = baseUrl.concat(GET_ORGANIZATION_BY_ID) + "/" + orgId;
		logger.info("Enter in getOrganizationById()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Throw Exception While getOrganizationById ", e);
			return null;
		}
	}

	public CommonResponse getByCampaignId(CampaignMasterProxy campaignMasterProxy) {

		String url = baseUrl.concat(GET_CAMPAIGN_MASTER);
		logger.info("Get campaign master details ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<CampaignMasterProxy> entity = new HttpEntity<>(campaignMasterProxy, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getCapaignByCampaignId  ---> ", e);
			return null;
		}
	}

	public CommonResponse getByListOfCampaignId(Set<Long> campaignIdList) {

		String url = baseUrl.concat(GET_CAMPAIGN_MASTER_LIST);
		logger.info("Get campaign master details ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			List<Long> list = new ArrayList<>(campaignIdList.size());
			list.addAll(campaignIdList);
			HttpEntity<List<Long>> entity = new HttpEntity<>(list, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getCapaignByCampaignId  ---> ", e);
			return null;
		}
	}

	public List<Long> getAllInActiveOrgList() {
		String url = baseUrl.concat(GET_ALL_INACTIVE_ORG_LIST);
		logger.info("Enter in getAllInActiveOrgList()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			UserResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, UserResponse.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(response) && response.getFlag() == true && response.getStatus() == 200 && !OPLUtils.isListNullOrEmpty(response.getListData())) {
				List<Object> objects = (List<Object>) response.getListData();
				List<Long> inActiveOrgList = MultipleJSONObjectHelper.getListOfObjects(MultipleJSONObjectHelper.getStringfromListOfObject(objects), null, Long.class);
				if (!OPLUtils.isListNullOrEmpty(inActiveOrgList)) {
					return inActiveOrgList;
				}
			}
		} catch (Exception e) {
			logger.error("Throw Exception While getAllInActiveOrgList ", e);
		}
		return Collections.emptyList();
	}

	public CommonResponse checkOrgStatusByOrgIdAndSchemeIdAndCampainType(Long orgId, Long schemeId, Integer campainType) {
		String url;
		url = baseUrl.concat(CHECK_ORGSTATUSBY_ORGID_SCHEMEID_CAMPAINTYPE) + "/" + orgId + "/" + schemeId + "/" + campainType;

		logger.info("Enter in checkOrgStatusByOrgIdAndSchemeIdAndCampainType()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Throw Exception While getOrganizationName ", e);
			return null;
		}
	}

	public CommonResponse getJourneConfigurationForProductScoring(Long orgId, Long schemeId) {
		String url;
		url = baseUrl.concat(GET_JOURNEY_CONFIG_FOR_PRODUCT_SCORING) + "/" + orgId + "/" + schemeId;

		logger.info("Enter in getJourneyConfigForProductScoring()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Throw Exception While getJourneyConfigForProductScoring ", e);
			return null;
		}
	}

	public CommonResponse getBankSpecificConfigByCampId(Long orgId, Long schemeId) {
		String url;
		url = baseUrl.concat(GET_BANK_SPECIFIC_CONFIG_BY_CAMPID) + "/" + orgId + "/" + schemeId;

		logger.info("Enter in getBankSpecificConfigByCampId()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Throw Exception While getBankSpecificConfigByCampId ", e);
			return null;
		}
	}

	public CommonResponse preScreenSignUp(UsersRequest usersRequest) {
		String url = baseUrl.concat(PRE_SCREEN_SIGN_UP);
		logger.info("Enter in preScreenSignUp() ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(usersRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while preScreenSignUp  ---> ", e);
			return null;
		}
	}

	public LoginResponse preScreenLogin(UsersRequest usersRequest) {
		String url = baseUrl.concat(PRE_SCREEN_LOGIN);
		logger.info("Enter in preScreenLogin() ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(usersRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, LoginResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while preScreenLogin  ---> ", e);
			return null;
		}
	}

	public CommonResponse getOrgMasterListByUserTypeId(Long userTypeId, Long schemeId) {
		String url = baseUrl.concat(GET_ORG_MASTER_LIST_BY_USER_TYPE_ID) + "/" + userTypeId + "/" + schemeId;
		logger.info("Enter in getOrgMasterListByUserTypeId() ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getOrgMasterListByUserTypeId  ---> ", e);
			return null;
		}
	}

	public CommonResponse getOrganisationMstListByUserTypeId(Long userTypeId) {
		String url = baseUrl.concat(GET_ORGANISATION_MASTER_LIST_BY_USER_TYPE_ID) + "/" + userTypeId;
		//		String url = "http://localhost:8059/users/v3/org/getOrganisationMstListByUserTypeId"+ "/" + userTypeId;
		logger.info("Enter in getOrganisationMstListByUserTypeId() ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getOrgMasterListByUserTypeId  ---> ", e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public BranchBasicDetailsRequest getBranchByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId) {
		try {
			String url = baseUrl.concat(GET_BRANCH_BY_CODE_AND_IFSC_AND_ORGID + "/" + code + "/" + ifsc + "/" + orgId);
			//			String url = "http://localhost:8059/users/v3/getBranchByCodeAndIfscAndOrgId"+ "/" + code + "/" + ifsc + "/" + orgId;
			logger.info("get BranchCode URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<List<Long>> entity = new HttpEntity<>(null, headers);
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.GET, entity, UserCommonRes.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(comRes) && !OPLUtils.isObjectNullOrEmpty(comRes.getData())) {
				return MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) comRes.getData()), BranchBasicDetailsRequest.class);
			}
		} catch (Exception e) {
			logger.error("Exception while getBranchCode -> ", e);
		}
		return null;
	}

	public BranchBasicDetailsRequest getBranchDetailRoZoByCodeAndIfscAndOrgId(String code, String ifsc, Long orgId, Long schemeId) {
		try {
			String url = baseUrl.concat(GET_BRANCH_RO_ZO_BY_CODE_AND_IFSC_AND_ORGID + "/" + code + "/" + ifsc + "/" + orgId + "/" + schemeId);
			logger.info("get BranchCode URL ----------------> " + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<List<Long>> entity = new HttpEntity<>(null, headers);
			UserCommonRes comRes = restTemplate.exchange(url, HttpMethod.GET, entity, UserCommonRes.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(comRes) && !OPLUtils.isObjectNullOrEmpty(comRes.getData())) {
				return MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) comRes.getData()), BranchBasicDetailsRequest.class);
			}
		} catch (Exception e) {
			logger.error("Exception while getBranchCode -> ", e);
		}
		return null;
	}

	public Long getFirstUserIdByOrgIdAndHoRoleID(Long orgId, Long roleId) {
		//	String url = "http://localhost:8059/users/v3/getFirstUserIdByOrgIdAndHoRoleID"+ "/" + orgId+ "/" + roleId;
		String url = baseUrl.concat(GET_FIRST_USERID_BY_ORGID_AND_HO_ROLEID) + "/" + orgId + "/" + roleId;
		logger.info("Enter in getUserIdByOrgIdAndHoRoleID() ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(headers);
			CommonResponse body = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(body) && !OPLUtils.isObjectNullOrEmpty(body.getData())) {
				return Long.valueOf(body.getData().toString());
			}
			return null;
		} catch (Exception e) {
			logger.error("Exception while getUserIdByOrgIdAndHoRoleID  ---> ", e);
			return null;
		}
	}

	public CommonResponse getOrganizationDetailsForPDF(UserOrganisationPdfGenarateRequestResponse genarateRequest) {

		String url = baseUrl.concat(GET_ORGANIZATION_DETAILS_FOR_PDF);
		logger.info("Get campaign master details ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UserOrganisationPdfGenarateRequestResponse> entity = new HttpEntity<>(genarateRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getCapaignByCampaignId  ---> ", e);
			return null;
		}
	}
	
	public CommonResponse getOrganizationDetailsByOrgIds(UserOrganisationPdfGenarateRequestResponse genarateRequest) {
		
		String url = baseUrl.concat(GET_ORGANIZATION_DETAILS_BY_ORG_IDS);
		logger.info("Get campaign master details ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UserOrganisationPdfGenarateRequestResponse> entity = new HttpEntity<>(genarateRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while getCapaignByCampaignId  ---> ", e);
			return null;
		}
	}

	public UserResponse updateMobileByUserId(UsersRequest usersRequest) {
		String url = baseUrl.concat(UPDATE_MOBILE_BY_USER_ID);
		logger.info("Update Mobile in Users ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<UsersRequest> entity = new HttpEntity<>(usersRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, UserResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while updateMobileByUserId  ---> ", e);
			return null;
		}
	}
	
	public CommonResponse checkMobile(SignUpRequest signUpRequest) {
		String url = baseUrl.concat(CHECK_MOBILE);
//		String url = "http://localhost:8059/users/v3/signup/checkMobile";
		logger.info("check Mobile in Users ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<SignUpRequest> entity = new HttpEntity<>(signUpRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while checkMobile  ---> ", e);
			return null;
		}
	}

}
