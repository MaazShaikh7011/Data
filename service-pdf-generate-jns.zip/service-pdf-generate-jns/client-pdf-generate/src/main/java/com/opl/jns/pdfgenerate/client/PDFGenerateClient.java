package com.opl.jns.pdfgenerate.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.model.COIRequest;

/**
 * @author sandip.bhetariya
 *
 */
public class PDFGenerateClient {

	private static Logger logger = LoggerFactory.getLogger(PDFGenerateClient.class);

	private String baseUrl;
	private RestTemplate restTemplate;

	public PDFGenerateClient(String baseUrlStr) {
		super();
		this.baseUrl = baseUrlStr;
		this.restTemplate = new RestTemplate();
	}

	public static void setClient(HttpHeaders headers) {
		headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		headers.add("Accept", "application/json");
	}

	private static final String GENERATE_COI_URL = "/v1/generateCOI";
	private static final String SET_COI_OTHER_DETAILS = "/v1/setCOIOtherDetails";

	public CommonResponse generateCOI(COIRequest coiRequest) {
		try {
			String url = baseUrl.concat(GENERATE_COI_URL);
			logger.info("Enter in generateCOI URL ---------->" + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<COIRequest> entity = new HttpEntity<>(coiRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while generateCOI -> ", e);

		}
		return null;
	}

	public COIRequest setCOIOtherDetails(COIRequest coiRequest) {
		try {
			String url = baseUrl.concat(SET_COI_OTHER_DETAILS);
			logger.info("Enter in set COI other details  ---------->" + url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<COIRequest> entity = new HttpEntity<>(coiRequest, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, COIRequest.class).getBody();
		} catch (Exception e) {
			logger.error("Exception while set COI other details -> ", e);
		}
		return coiRequest;
	}

}
