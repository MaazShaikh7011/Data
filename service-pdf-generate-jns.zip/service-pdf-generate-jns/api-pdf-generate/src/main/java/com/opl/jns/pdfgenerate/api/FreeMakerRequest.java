package com.opl.jns.pdfgenerate.api;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FreeMakerRequest {
	private String logoUrl;
	private String bankLogoUrl;
	private String nameOfInsurer;
	private String mstPolicyNo;
	private String nameOfMember;
	private String urnNo;
	private String address;
	private String mobileNo;
	private String kycName;
	private String kycValue;
	private String dob;
	private String accountNo;
	private String nameOfBank;
	private String nameOfNominee;
	private String ageOfNominee;
	private String nameOfGuardian;
	private String relationShipOfGuardian;
	private Date dateOfComOfCover;
	private String coverEndDate;
	private String sumAssured;
	private Double premAmtPaid;
	private String lienPeriod;
	private String annuRenDate;

	private String schemeName;
	private String isShowSign;
	private String isHideSign;
	private String isHideGuardian;

	private String aadharNo;

	private Boolean isCustomerUser;
}
