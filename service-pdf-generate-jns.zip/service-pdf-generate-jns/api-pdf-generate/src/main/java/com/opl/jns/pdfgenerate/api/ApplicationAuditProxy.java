package com.opl.jns.pdfgenerate.api;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author sandip.bhetariya
 *
 */
@Setter
@Getter
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ApplicationAuditProxy {

	private Integer id;
	private Long applicationId;
	private Long storageId;
	private Long responseTime;
	private String message;
	private String errorMessage;
	private Boolean isActive;
	private Date createdDate;
	private Date modifiedDate;

}
