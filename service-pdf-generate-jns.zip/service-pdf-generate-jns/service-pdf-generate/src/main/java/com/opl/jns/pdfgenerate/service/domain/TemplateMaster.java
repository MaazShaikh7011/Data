package com.opl.jns.pdfgenerate.service.domain;

import lombok.*;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "template_master")
public class TemplateMaster {

	private static final String SEQ_NAME = DBNameConstant.JNS_PDF_GENERATE + "_template_master_seq_gen";

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQ_NAME)
	@SequenceGenerator(schema = DBNameConstant.JNS_PDF_GENERATE, name = SEQ_NAME, sequenceName = SEQ_NAME, allocationSize = 1)
	private Integer id;

	@Column(name = "name")
	private String name;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "type")
	private Integer type;

	@Lob
	@Column(name = "template")
	private String template;

	@Column(name = "is_active")
	private Boolean isActive;

}
