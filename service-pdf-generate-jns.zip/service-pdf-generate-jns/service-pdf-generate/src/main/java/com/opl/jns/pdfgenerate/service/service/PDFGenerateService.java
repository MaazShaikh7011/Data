package com.opl.jns.pdfgenerate.service.service;

import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.model.COIRequest;

public interface PDFGenerateService {

	CommonResponse generateCOI(COIRequest coiRequest);
	
	public COIRequest setCOIOtherDetails(COIRequest response);

}
