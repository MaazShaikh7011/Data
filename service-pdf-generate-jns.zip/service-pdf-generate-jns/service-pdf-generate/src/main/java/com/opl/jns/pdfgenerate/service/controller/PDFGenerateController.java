package com.opl.jns.pdfgenerate.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opl.jns.pdfgenerate.service.service.PDFGenerateService;
import com.opl.jns.pdfgenerate.service.utils.PDFUtils;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.model.COIRequest;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1")
@Slf4j
public class PDFGenerateController {

	@Autowired
	private PDFGenerateService pdfGenerateService;

	@PostMapping(value = "/generateCOI", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> generateCOI(@RequestBody COIRequest coiRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(coiRequest) || OPLUtils.isObjectNullOrEmpty(coiRequest.getApplicationId())) {
				log.info(PDFUtils.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY);
				return new ResponseEntity<CommonResponse>(new CommonResponse(PDFUtils.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(pdfGenerateService.generateCOI(coiRequest), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while generateCOI ------>", e);
			return new ResponseEntity<>(new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/setCOIOtherDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<COIRequest> setCOIOtherDetails(@RequestBody COIRequest coiRequest) {
		try {
			return new ResponseEntity<>(pdfGenerateService.setCOIOtherDetails(coiRequest), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while generateCOI ------>", e);
			return new ResponseEntity<>(coiRequest, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
