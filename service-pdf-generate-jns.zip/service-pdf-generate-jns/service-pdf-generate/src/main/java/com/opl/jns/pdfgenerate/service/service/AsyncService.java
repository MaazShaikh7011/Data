package com.opl.jns.pdfgenerate.service.service;

import java.util.Date;

import com.opl.jns.pdfgenerate.api.ApplicationAuditProxy;
import com.opl.jns.pdfgenerate.service.domain.TemplateMaster;
import com.opl.jns.utils.model.COIRequest;

public interface AsyncService {

	void saveAduit(ApplicationAuditProxy applicationAuditProxy);

	void uploadFileDMS(byte[] generatePdf, TemplateMaster templateMaster, Long applicationId, ApplicationAuditProxy applicationAuditProxy, String message, Date date, COIRequest coiRequest);

}
