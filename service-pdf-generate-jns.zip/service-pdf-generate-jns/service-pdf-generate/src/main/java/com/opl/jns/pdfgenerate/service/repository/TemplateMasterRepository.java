package com.opl.jns.pdfgenerate.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.pdfgenerate.service.domain.TemplateMaster;

public interface TemplateMasterRepository extends JpaRepository<TemplateMaster, Integer> {

	TemplateMaster findBySchemeIdAndTypeAndIsActiveTrue(Long schemeId, Integer type);

}
