package com.opl.jns.pdfgenerate.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.pdfgenerate.service.domain.ApplicationAudit;

/**
 * @author sandip.bhetariya
 *
 */
public interface ApplicationAuditRepository extends JpaRepository<ApplicationAudit, Integer> {
	
	
}
