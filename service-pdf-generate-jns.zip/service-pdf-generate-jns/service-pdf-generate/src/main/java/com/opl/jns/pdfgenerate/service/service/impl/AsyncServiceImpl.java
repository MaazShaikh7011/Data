package com.opl.jns.pdfgenerate.service.service.impl;

import java.util.Date;

import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.dms.api.model.DDRMultipart;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.pdfgenerate.api.ApplicationAuditProxy;
import com.opl.jns.pdfgenerate.service.domain.ApplicationAudit;
import com.opl.jns.pdfgenerate.service.domain.TemplateMaster;
import com.opl.jns.pdfgenerate.service.repository.ApplicationAuditRepository;
import com.opl.jns.pdfgenerate.service.service.AsyncService;
import com.opl.jns.pdfgenerate.service.utils.PDFUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.model.COIRequest;

import lombok.extern.slf4j.Slf4j;

/**
 * @author sandip.bhetariya
 *
 */

@EnableAsync
@Service
@Transactional
@Slf4j
public class AsyncServiceImpl implements AsyncService {
	
	@Autowired
	private ApplicationAuditRepository auditRepository;
	
	@Autowired
	private DMSClient dmsClient;
	
	@Autowired
	private EreCommonService ereCommonService;

	@Async
	@Override
	public void saveAduit(ApplicationAuditProxy applicationAuditProxy) {
		if (!OPLUtils.isObjectNullOrEmpty(applicationAuditProxy)) {
			log.info(" inside Audit Save AppId --->" + applicationAuditProxy.getApplicationId());

			try {
				ApplicationAudit entity = new ApplicationAudit();
				BeanUtils.copyProperties(applicationAuditProxy, entity, "id");
				entity.setIsActive(Boolean.TRUE);
				auditRepository.save(entity);

				log.info("completed save Audit AppId --->" + applicationAuditProxy.getApplicationId());
			} catch (Exception e) {
				log.error("Audit Data Not Saved Due to Error Occurred", e);
			}
		} else {
			log.error("Audit Data Not Found", applicationAuditProxy);
		}

	}

	@Async
	@Override
	public void uploadFileDMS(byte[] generatePdf, TemplateMaster templateMaster, Long applicationId, ApplicationAuditProxy applicationAuditProxy, String message, Date date, COIRequest coiRequest) {
		try {
			MultipartFile multipartFile = new DDRMultipart(generatePdf);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(PDFUtils.APPLICATION_ID, applicationId);
			jsonObj.put(PDFUtils.PRODUCT_DOCUMENT_MAPPING_ID, PDFUtils.PRODUCT_DOCUMENT_ID);
			jsonObj.put(PDFUtils.USER_TYPE, DocumentAlias.UERT_TYPE_APPLICANT);
			jsonObj.put(PDFUtils.ORIGINAL_FILE_NAME, templateMaster.getFileName() + ".pdf");
			DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
			if (documentResponse.getStatus() == HttpStatus.OK.value()) {
				StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
				applicationAuditProxy.setStorageId(storageDetailsResponse.getId());
				if(!OPLUtils.isObjectNullOrEmpty(storageDetailsResponse) && !OPLUtils.isObjectNullOrEmpty(storageDetailsResponse.getId()))
					ereCommonService.saveStorageIdInLastTransactionDetails(storageDetailsResponse.getId(),coiRequest.getLastTransactionDetailsId());
				else {
					log.info("DocumentResponse is null or empty ---------------->" + applicationId);
					message="Document Storage id not found";
				}
			} else {
				log.info("DocumentResponse is null or empty ---------------->" + applicationId);
				message="Document not upload in dms";
			}
		} catch (Exception e) {
			message = e.getMessage();
			applicationAuditProxy.setErrorMessage(OPLUtils.convertStackTraceToString(e));

		}finally {
			if (!OPLUtils.isObjectNullOrEmpty(applicationAuditProxy)) {
				Date modifiedDate = new Date();
				applicationAuditProxy.setModifiedDate(modifiedDate);
				applicationAuditProxy.setMessage(message);
				applicationAuditProxy.setResponseTime(OPLUtils.getDifferenceInMiliSecondFromDates(modifiedDate, date));

				saveAduit(applicationAuditProxy);
			} else
				log.error("Audit Data Not Saved Due to audit data not found");
		
		}
		
	}

}
