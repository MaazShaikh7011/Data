package com.opl.jns.pdfgenerate.service.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_audit")
public class ApplicationAudit {

	private static final String SEQ_NAME = DBNameConstant.JNS_PDF_GENERATE + "_application_audit_seq_gen";

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQ_NAME)
	@SequenceGenerator(schema = DBNameConstant.JNS_PDF_GENERATE, name = SEQ_NAME, sequenceName = SEQ_NAME, allocationSize = 1)
	private Integer id;

	@Column(name = "application_id")
	private Long applicationId;

	@Column(name = "storage_id")
	private Long storageId;

	@Column(name = "response_time")
	private Long responseTime;

	@Column(name = "message")
	private String message;
	
	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "is_active")
	private Boolean isActive;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

}
