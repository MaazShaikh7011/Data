package com.opl.jns.pdfgenerate.service.service.impl;

import static com.itextpdf.html2pdf.HtmlConverter.convertToPdf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.StringReader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatus.Series;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.layout.font.FontProvider;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.dms.api.model.DDRMultipart;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.TemplateMasterType;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.api.model.LgdStateResponse;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.pdfgenerate.api.ApplicationAuditProxy;
import com.opl.jns.pdfgenerate.service.domain.TemplateMaster;
import com.opl.jns.pdfgenerate.service.repository.TemplateMasterRepository;
import com.opl.jns.pdfgenerate.service.service.AsyncService;
import com.opl.jns.pdfgenerate.service.service.PDFGenerateService;
import com.opl.jns.pdfgenerate.service.utils.PDFUtils;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.api.model.UserOrganisationPdfGenarateRequestResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.model.COIRequest;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.Template;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Transactional
@Service
public class PDFGenerateServiceImpl implements PDFGenerateService {

	@Autowired
	private TemplateMasterRepository templateMasterRepository;

	@Autowired
	private AsyncService asyncService;

	@Autowired
	private ConfigProperties configProperties;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private OneFormClient oneFormClient;

	@Autowired
	private EreCommonService ereCommonService;

	@Override
	public CommonResponse generateCOI(COIRequest coiRequest) {

		CommonResponse response = new CommonResponse();

		ApplicationAuditProxy applicationAuditProxy = null;
		Date date = new Date();
		String message = Series.SUCCESSFUL.name();
		Boolean isAuditSaved = Boolean.TRUE;
		try {
			applicationAuditProxy = new ApplicationAuditProxy();
			Long applicationId = coiRequest.getApplicationId();
			applicationAuditProxy.setApplicationId(applicationId);
			applicationAuditProxy.setCreatedDate(date);
			log.info("Enter in Upload COI in DMS ---------->" + applicationId);
			TemplateMaster templateMaster = templateMasterRepository.findBySchemeIdAndTypeAndIsActiveTrue(coiRequest.getSchemeId(), TemplateMasterType.COI.getId());
			if (!OPLUtils.isObjectNullOrEmpty(templateMaster)) {
				coiRequest = setCOIOtherDetails(coiRequest);
				//				String readyTemplate = createFreemarkerTemplate(templateMaster.getTemplate(), MultipleJSONObjectHelper.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(coiRequest)));
				String readyTemplate = prepareTemplate(templateMaster.getTemplate(), coiRequest);
				if (!OPLUtils.isObjectNullOrEmpty(readyTemplate)) {
					String fileName = templateMaster.getFileName().concat("_").concat(applicationId.toString()).concat("_").concat(String.valueOf(date.getTime()));
					log.info("FILE PATH for applicationId :- " + applicationId + "---------------->" + fileName);
					byte[] generatePdf = generatePdf(readyTemplate, fileName);
					response.setData(Base64.getEncoder().encodeToString(generatePdf));
					Long storageId = uploadFileDMS(generatePdf, templateMaster, applicationId, applicationAuditProxy, message, date, coiRequest);
					//					isAuditSaved = Boolean.FALSE;
					response.setId(storageId);
					response.setMessage(Series.SUCCESSFUL.name());
					response.setStatus(HttpStatus.OK.value());
					return response;

				} else {
					log.info("Mail Template did not found");
					message = "Mail Template did not found";
				}
			} else {
				log.info("template not found from database");
				message = "template not found from database";
			}
		} catch (Exception e) {
			message = e.getMessage();
			applicationAuditProxy.setErrorMessage(e.getMessage());

		} finally {
			if (isAuditSaved) {
				if (!OPLUtils.isObjectNullOrEmpty(applicationAuditProxy)) {
					Date modifiedDate = new Date();
					applicationAuditProxy.setModifiedDate(modifiedDate);
					applicationAuditProxy.setMessage(message);
					applicationAuditProxy.setResponseTime(OPLUtils.getDifferenceInMiliSecondFromDates(modifiedDate, date));

					asyncService.saveAduit(applicationAuditProxy);
				} else
					log.error("Audit Data Not Saved Due to audit data not found", coiRequest);
			}

		}
		response.setMessage(message);
		response.setStatus(HttpStatus.NOT_FOUND.value());
		return response;
	}

	private String getValueById(DropDownMasterKey key, Integer id) throws Exception {
		try {
			return oneFormClient.getNameByKeyAndObjId(key, id).getValue();
		} catch (Exception e) {
			log.error("Exception in fetching the values of [{}] and exception id :", id, e);
		}
		return null;
	}

	public COIRequest setCOIOtherDetails(COIRequest coiReq) {
		try {
			coiReq.setAnnuRenDate(configProperties.getValueByCode(CommonUtils.ANNUAL_RENEWAL_DATE));
			coiReq.setSumAssured(configProperties.getValueByCode(CommonUtils.PMJJBY_SUM_ASSURED));
			coiReq.setLienPeriod(configProperties.getValueByCode(CommonUtils.PMJJBY_LIEN_PERIOD));

			if (!OPLUtils.isObjectNullOrEmpty(coiReq) && !OPLUtils.isObjectNullOrEmpty(coiReq.getInsurerOrgId()) && !OPLUtils.isObjectNullOrEmpty(coiReq.getOrgId())) {
				UserOrganisationPdfGenarateRequestResponse genarateRequest = new UserOrganisationPdfGenarateRequestResponse();
				genarateRequest.setInsurerOrgId(coiReq.getInsurerOrgId());
				genarateRequest.setOrgId(coiReq.getOrgId());

				CommonResponse organizationDetailsForPDF = usersClient.getOrganizationDetailsForPDF(genarateRequest);
				if (!OPLUtils.isObjectNullOrEmpty(organizationDetailsForPDF) && organizationDetailsForPDF.getStatus() == HttpStatus.OK.value()) {
					genarateRequest = MultipleJSONObjectHelper.getObjectFromObject(organizationDetailsForPDF.getData(), UserOrganisationPdfGenarateRequestResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(genarateRequest)) {
						coiReq.setLogoUrl(genarateRequest.getInsurerImagePath());
						coiReq.setNameOfInsurer(genarateRequest.getInsurerdisplayOrgName().toUpperCase());
						coiReq.setBankLogoUrl(genarateRequest.getImagePath());
						coiReq.setNameOfBank(genarateRequest.getNameOfBank().toUpperCase());
					}
				}
				BranchBasicDetailsRequest branchDetails = usersClient.getBranch(coiReq.getBranchId());
				if(!OPLUtils.isObjectNullOrEmpty(branchDetails.getCode()) && !OPLUtils.isObjectListNull(branchDetails)) {
					coiReq.setBranchCode((!OPLUtils.isObjectNullOrEmpty(branchDetails.getCode()) ? branchDetails.getCode() : ""));
					String cityName = null;
					String stateName = null;
					
					if(!OPLUtils.isObjectNullOrEmpty(branchDetails.getCityId())) {
						LgdDistrictStateResponse cityResponse = oneFormClient.getLgdCityByCityId(Long.valueOf(branchDetails.getCityId()));
						if (!OPLUtils.isObjectNullOrEmpty(cityResponse)) {
							 cityName = cityResponse.getDistrictName();
						} 
					}
					if(!OPLUtils.isObjectNullOrEmpty(branchDetails.getStateId())) {
						LgdStateResponse stateResponse = oneFormClient.getLgdStateByStateId(Long.valueOf(branchDetails.getStateId()));
						if (!OPLUtils.isObjectNullOrEmpty(stateResponse)) {
							 stateName  = stateResponse.getStateName();
						} 
					}
						coiReq.setBranchAddress((!OPLUtils.isObjectNullOrEmpty(branchDetails.getStreetName()) ? branchDetails.getStreetName().toUpperCase() : "") + ", "
								+ (!OPLUtils.isObjectNullOrEmpty(cityName) ? cityName.toUpperCase() : "") + ", "
								+ (!OPLUtils.isObjectNullOrEmpty(stateName) ? stateName.toUpperCase() : "") + ", "
								+ (!OPLUtils.isObjectNullOrEmpty(branchDetails.getPincode()) ? branchDetails.getPincode() : "") );	
				}

			}

			if (!OPLUtils.isObjectNullOrEmpty(coiReq.getRelationId()))
				coiReq.setRelationShipOfGuardian(getValueById(DropDownMasterKey.RELEATION_SHIP, coiReq.getRelationId()).toUpperCase());
			return coiReq;

		} catch (Exception e) {
			log.error("error while we getting details", e);
		}
		return coiReq;
	}

	/**
	 * UPLOAD FILE IN DMS SERVICE
	 * 
	 * @param generatePdf
	 * @param applicationId
	 * @param fileName
	 * @return
	 */
	@SuppressWarnings("unused")
	private CommonResponse uploadFile(byte[] generatePdf, Long applicationId, String fileName) {
		try {
			MultipartFile multipartFile = new DDRMultipart(generatePdf);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(PDFUtils.APPLICATION_ID, applicationId);
			jsonObj.put(PDFUtils.PRODUCT_DOCUMENT_MAPPING_ID, PDFUtils.PRODUCT_DOCUMENT_ID);
			jsonObj.put(PDFUtils.USER_TYPE, DocumentAlias.UERT_TYPE_APPLICANT);
			jsonObj.put(PDFUtils.ORIGINAL_FILE_NAME, fileName + ".pdf");
			DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
			if (documentResponse.getStatus() == HttpStatus.OK.value()) {
				StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
				return new CommonResponse("Success", storageDetailsResponse.getId(), HttpStatus.OK.value(), Boolean.TRUE);
			} else {
				return new CommonResponse("No data found", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}
		} catch (Exception e) {
			log.error("Exception while upload file in DMS ---->", e);
			return new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	private byte[] generatePdf(String template, String fileName) throws Exception {
		log.info("INSIDE generatePdf() --->");
		File file = new File(fileName + ".pdf");
		try {
			FontProvider provider = new FontProvider();
			provider.addSystemFonts();
			provider.addStandardPdfFonts();
			ConverterProperties converterProperties = new ConverterProperties();
			converterProperties.setFontProvider(provider);

			log.info("START CONVERTTOPDF() --->");
			convertToPdf(template, new FileOutputStream(file), converterProperties);
			log.info("END CONVERTTOPDF() --->");

			Resource resource = new UrlResource(file.toURI());
			String filePath = resource.getFile().getAbsolutePath();

			log.info("END generatePdf() --->");
			if (OPLUtils.isObjectNullOrEmpty(filePath)) {
				return null;
			} else if (filePath.equals("empty")) {
				return new byte[10];
			} else {
				byte[] fileByte = Files.readAllBytes(Paths.get(filePath));
				file = new File(filePath);
				return fileByte;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("error is getting While generate PDF");
			throw new Exception(e);
		} finally {
			if (file.exists()) {
				boolean flag = file.delete();
				log.info("file.delete() status : {}", flag);
			}
		}
	}

	private String prepareTemplate(String template, COIRequest crtInsData) throws Exception {
		if (!OPLUtils.isObjectNullOrEmpty(template)) {
			template = template.replace("$nameOfMember", OPLUtils.replaceStringIfNull(crtInsData.getNameOfMember().toUpperCase(), ""));
			template = template.replace("$address", OPLUtils.replaceStringIfNull(crtInsData.getAddress().toUpperCase(), ""));

			if (!OPLUtils.isObjectNullOrEmpty(crtInsData.getKycName())) {

				if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.AADHAR.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.AADHAR.getDisplayValue());
					template = template.replace("$kycValue", "-");
				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.PAN.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.PAN.getDisplayValue());
					template = template.replace("$kycValue", OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.PASSPORT.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.PASSPORT.getDisplayValue());
					template = template.replace("$kycValue", OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.DRIVING_LICENCE.getDisplayValue());
					template = template.replace("$kycValue", OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.MGNREGA_CARD.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.MGNREGA_CARD.getDisplayValue());
					template = template.replace("$kycValue", OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getDisplayValue())) {
					template = template.replace("$kycName", KycDocument.VOTERS_ID_CARD.getDisplayValue());
					template = template.replace("$kycValue", OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
				}
			}

			template = template.replace("$nameOfNominee", OPLUtils.replaceStringIfNull(crtInsData.getNameOfNominee().toUpperCase(), ""));
			template = template.replace("$accountNo", OPLUtils.replaceStringIfNull(crtInsData.getAccountNo(), ""));
			template = template.replace("$dateOfComOfCover", !OPLUtils.isObjectNullOrEmpty(crtInsData.getDateOfComOfCover()) ? CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS.format(crtInsData.getDateOfComOfCover()) : "");
			template = template.replace("$sumAssured", OPLUtils.replaceStringIfNull(crtInsData.getSumAssured(), ""));
			template = template.replace("$premAmtPaid", OPLUtils.replaceStringIfNull(crtInsData.getPremAmtPaid(), ""));
			template = template.replace("$mstPolicyNo", OPLUtils.replaceStringIfNull(crtInsData.getMstPolicyNo(), ""));
			template = template.replace("$urnNo", OPLUtils.replaceStringIfNull(crtInsData.getUrnNo(), ""));
			template = template.replace("$mobileNo", OPLUtils.replaceStringIfNull(crtInsData.getMobileNo(), ""));
			template = template.replace("$dob", !OPLUtils.isObjectNullOrEmpty(crtInsData.getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(CommonUtils.sdf.parse(crtInsData.getDob())) : "");
			template = template.replace("$nameOfBank", OPLUtils.replaceStringIfNull(crtInsData.getNameOfBank().toUpperCase(), ""));
			String ageOfNominee = null != crtInsData.getAgeOfNominee() ? crtInsData.getAgeOfNominee().equals("0") || crtInsData.getAgeOfNominee().equals("1") ? crtInsData.getAgeOfNominee() + " YEAR" : crtInsData.getAgeOfNominee() + " YEARS"
					: "0 YEAR";
			template = template.replace("$ageOfNominee", !OPLUtils.isObjectNullOrEmpty(crtInsData.getAgeOfNominee()) ? ageOfNominee : "");
			template = template.replace("$coverAndDate", OPLUtils.replaceStringIfNull(crtInsData.getCoverEndDate(), ""));
			template = template.replace("$signatureDate", !OPLUtils.isObjectNullOrEmpty(crtInsData.getSignatureDate()) ? CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS.format(crtInsData.getSignatureDate()) : "");
			template = template.replace("$lienPeriod", OPLUtils.replaceStringIfNull(crtInsData.getLienPeriod().toUpperCase(), ""));
			template = template.replace("$annuRenDate", OPLUtils.replaceStringIfNull(crtInsData.getAnnuRenDate().toUpperCase(), ""));
			template = template.replace("$logoUrl", OPLUtils.replaceStringIfNull(crtInsData.getLogoUrl(), ""));

			template = template.replace("$bankLogoUrl", OPLUtils.replaceStringIfNull(crtInsData.getBankLogoUrl(), ""));

			template = template.replace("$nameOfInsurer", OPLUtils.replaceStringIfNull(crtInsData.getNameOfInsurer().toUpperCase(), ""));
			template = template.replace("$schemeName", !OPLUtils.isObjectNullOrEmpty(crtInsData.getSchemeId()) ? com.opl.jns.utils.enums.SchemeMaster.getById(crtInsData.getSchemeId()).getName() : "");
			template = template.replace("$nameOfGuardian", OPLUtils.replaceStringIfNull(crtInsData.getNameOfGuardian(), ""));
			template = template.replace("$relationShipOfGuardian", OPLUtils.replaceStringIfNull(crtInsData.getRelationShipOfGuardian(), ""));
			template = template.replace("$isHideGuardian", !OPLUtils.isObjectNullOrEmpty(crtInsData.getAgeOfNominee()) && Integer.valueOf(crtInsData.getAgeOfNominee())<18 ? "display: block;" : "display: none;");

			template = template.replace("$isShowSign", !OPLUtils.isObjectNullOrEmpty(crtInsData.getIsCustomerUser()) && !crtInsData.getIsCustomerUser() ? "display: block;" : "display: none;");
			template = template.replace("$isHideSign", !OPLUtils.isObjectNullOrEmpty(crtInsData.getIsCustomerUser()) && crtInsData.getIsCustomerUser() ? "display: block;" : "display: none;");

			template = template.replace("$branchAddress", OPLUtils.replaceStringIfNull(crtInsData.getBranchAddress().toUpperCase(), ""));
			template = template.replace("$branchCode", OPLUtils.replaceStringIfNull(crtInsData.getBranchCode(), ""));
		}

		return template;
	}

	@SuppressWarnings({ "unused", "deprecation" })
	private String createFreemarkerTemplate(String html, Map<String, Object> inputMap) throws Exception {
		Path tempFilePath = Files.createTempFile("freemarker_template", ".html");
		File file = new File(tempFilePath.toString());
		Writer fileWriter = new FileWriter(file);
		try {
			Configuration cfg = new Configuration();
			cfg.setObjectWrapper(new DefaultObjectWrapper());
			Template template = new Template("", new StringReader(html), cfg);

			template.process(inputMap, fileWriter);

			byte[] fileBytes = Files.readAllBytes(tempFilePath);
			return new String(fileBytes);
		} catch (Exception e) {
			log.error("ERROR IN createFreemarkerTemplate()", e);
			return null;
		} finally {
			fileWriter.close();
			FileUtils.forceDelete(file);
		}
	}

	public Long uploadFileDMS(byte[] generatePdf, TemplateMaster templateMaster, Long applicationId, ApplicationAuditProxy applicationAuditProxy, String message, Date date, COIRequest coiRequest) {
		try {
			MultipartFile multipartFile = new DDRMultipart(generatePdf);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(PDFUtils.APPLICATION_ID, applicationId);
			jsonObj.put(PDFUtils.PRODUCT_DOCUMENT_MAPPING_ID, PDFUtils.PRODUCT_DOCUMENT_ID);
			jsonObj.put(PDFUtils.USER_TYPE, DocumentAlias.UERT_TYPE_APPLICANT);
			jsonObj.put(PDFUtils.ORIGINAL_FILE_NAME, templateMaster.getFileName() + ".pdf");
			DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
			if (documentResponse.getStatus() == HttpStatus.OK.value()) {
				StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
				applicationAuditProxy.setStorageId(storageDetailsResponse.getId());
				if (!OPLUtils.isObjectNullOrEmpty(storageDetailsResponse) && !OPLUtils.isObjectNullOrEmpty(storageDetailsResponse.getId()))
					if (coiRequest.getLastTransactionDetailsId() != null) {
						ereCommonService.saveStorageIdInLastTransactionDetails(storageDetailsResponse.getId(), coiRequest.getLastTransactionDetailsId());
						return storageDetailsResponse.getId();
					} else  if (null != storageDetailsResponse.getId()){
						return storageDetailsResponse.getId();
					}else {
						log.info("DocumentResponse is null or empty ---------------->" + applicationId);
						message = "Document Storage id not found";
					}
			} else {
				log.info("DocumentResponse is null or empty ---------------->" + applicationId);
				message = "Document not upload in dms";
			}
		} catch (Exception e) {
			message = e.getMessage();
			applicationAuditProxy.setErrorMessage(e.getMessage());
		}
		return null;

	}

}
