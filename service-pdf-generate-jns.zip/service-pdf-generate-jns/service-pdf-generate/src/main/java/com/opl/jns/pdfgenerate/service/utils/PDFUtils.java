package com.opl.jns.pdfgenerate.service.utils;

public class PDFUtils {

	public static final String APPLICATION_ID = "applicationId";
	public static final String PRODUCT_DOCUMENT_MAPPING_ID = "productDocumentMappingId";
	public static final String USER_TYPE = "userType";
	public static final String ORIGINAL_FILE_NAME = "originalFileName";
	public static final long PRODUCT_DOCUMENT_ID = 68L;
	public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
	
	

}
