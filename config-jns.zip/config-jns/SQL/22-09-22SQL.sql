COPY TABLES :- 

`ans_config`.`name_match_input_type_master`
`ans_config`.`name_matching_master_audit`

TRIGGER :- 
`ans_config`.`name_match_master_after_update`


ALTER TABLE `ans_config`.`name_matching_master`  
  ADD CONSTRAINT `input_type_id` FOREIGN KEY (`input_type_id`) REFERENCES `ans_config`.`name_match_input_type_master`(`id`);
