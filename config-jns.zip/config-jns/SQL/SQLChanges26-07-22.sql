UPDATE `ans_config`.`ans_config_master` SET `value` = 'https://nrlm.gov.in/nrlmbankloanapp/WebserviceNrlm/services/bankloan/login' WHERE `id` = '7'; 

UPDATE `ans_config`.`ans_config_master` SET `value` = 'https://nrlm.gov.in/nrlmbankloanapp/WebserviceNrlm/services/bank/loanapp/pendingList?username=' WHERE `id` = '8'; 

UPDATE `ans_config`.`ans_config_master` SET `value` = 'https://nrlm.gov.in/nrlmbankloanapp/WebserviceNrlm/services/bank/loanapp/data?loanApplicationId=' WHERE `id` = '9'; 

UPDATE `ans_config`.`ans_config_master` SET `value` = 'https://nrlm.gov.in/nrlmbankloanapp/WebserviceNrlm/services/bank/loanapp/appStatusComplete?loanApplicationId=' WHERE `id` = '10'; 


ALTER TABLE `ans_config`.`nrlm_api_audit`   
	CHANGE `url` `url` VARCHAR(200) CHARSET latin1 COLLATE latin1_swedish_ci NULL;

-- By Hitesh
ALTER TABLE `users`.`user_token_mapping` ADD COLUMN `client_user_id` BIGINT(20) NULL AFTER `mobile_fcm_token`;
