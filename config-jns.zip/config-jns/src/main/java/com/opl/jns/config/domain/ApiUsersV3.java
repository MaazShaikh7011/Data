package com.opl.jns.config.domain;

import java.util.Date;

import jakarta.persistence.*;

import com.opl.jns.config.utils.*;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "api_users", schema = "jns_config")
public class ApiUsersV3 {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_users_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "api_users_seq_gen", sequenceName = "api_users_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "org_id")
	private Long orgId;
	
	@Column(name="api_key")
	private String apiKey;
	
	@Column(name = "user_name")
	private String userName;
	
	@Column(name="ips")
	private String ips;
	
	@Column(name="is_active")
	private Boolean isActive;
	
	@Column(name="is_internal_user")
	private Boolean isInternalUser;
	
	
	@Column(name = "public_key")
	private String publicKey;

	@Column(name = "private_key")
	private String privateKey;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	private Date modifiedDate;
	
	@Column(name="header_config")
	private String headerConfig;
	
	@Column(name="url_config")
	private String urlConfig;

	@Column(name="config_type")
	private Integer configType;

	@Column(name = "org_name")
	private String orgName;
	
	@Column(name = "time_out_config")
	private String timeOutConfig;

	@Transient
	private ConfigType configTypeMst;

	@PostLoad
	void runPostLoad(){
		if(null != configType && 0 != configType){
			configTypeMst = ConfigType.fromId(configType);
		}
	}

}
