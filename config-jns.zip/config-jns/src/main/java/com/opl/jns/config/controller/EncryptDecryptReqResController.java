package com.opl.jns.config.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hazelcast.internal.json.JsonObject;
import com.opl.jns.config.utils.RequestResponseConverter;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EncryptDecryptReqResController {

	@Autowired
	RequestResponseConverter requestResponseConveter;

	@SkipInterceptor
	@PostMapping(value = "/encrypt", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> encrypt(@RequestBody String request) {
		try {

			if (OPLUtils.isObjectNullOrEmpty(request)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Invalid Request", HttpStatus.NO_CONTENT.value(), Boolean.FALSE),
						HttpStatus.OK);
			}
			log.info("IN ENCRYPT ----------------------->" + request);
			byte[] encrypt = requestResponseConveter.encrypt(request);
			String data = new String(encrypt, StandardCharsets.UTF_8);
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully Encrypted !!",
					MultipleJSONObjectHelper.getObjectFromString(data, Object.class), HttpStatus.OK.value(),
					Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.info("Error While Encrypt data :: " + e.getMessage());
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Something went wrong", null, HttpStatus.OK.value(), Boolean.FALSE),
					HttpStatus.OK);
		}
	}

	@SkipInterceptor
	@PostMapping(value = "/decrypt", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> decrypt(@RequestBody String request) throws IOException {
		try {
			if (OPLUtils.isObjectNullOrEmpty(request)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Invalid Request", HttpStatus.NO_CONTENT.value(), Boolean.FALSE),
						HttpStatus.OK);
			}
			log.info("IN DECRYPR ----------------------->" + request);
			InputStream targetStream = new ByteArrayInputStream(request.getBytes("UTF-8"));
			InputStream decrypt = requestResponseConveter.encryptedTxtToDecrypt(targetStream, InputStream.class);
			String generateString = requestResponseConveter.generateString(decrypt);

			return new ResponseEntity<CommonResponse>(new CommonResponse("Data Decrypted properly",
					MultipleJSONObjectHelper.getObjectFromString(generateString, Object.class), HttpStatus.OK.value(),
					Boolean.TRUE), HttpStatus.OK);

		} catch (Exception err) {
			log.error("Something went wrong" + err.getMessage());
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Something went wrong", null, HttpStatus.OK.value(), Boolean.FALSE),
					HttpStatus.OK);
		}
	}

}
