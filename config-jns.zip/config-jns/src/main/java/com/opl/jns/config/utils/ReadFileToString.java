package com.opl.jns.config.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.opl.jns.utils.common.OPLUtils;

@Component
public class ReadFileToString {
	
	private static final Logger logger = LoggerFactory.getLogger(OPLUtils.class);
	
	public  String readUsingApacheCommonsIO(String fileName) {
		logger.info("enter in reading file :-- "+fileName);
		try {
			File file = ResourceUtils.getFile("/apps/services/LoadTesting/"+fileName);
			logger.info("File Path :-- "+file.toString());
			fileName = file.toString();
			return FileUtils.readFileToString(new File(fileName));
		} catch (IOException e) {
			logger.warn("error while reading file :-- "+fileName);
			return null;
		}
	}
	
	public void writeFile(String data, String fileName) {
		Path path = Paths.get(fileName);
		byte[] bytes = data.getBytes();
		try {
		    Files.write(path, bytes);
		} catch (IOException ex) {
			// Handle exception
		}
	}
}
