package com.opl.jns.config.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.config.domain.UserOrganizationMasterV3;

public interface UserOrganizationMasterRepoV3 extends JpaRepository<UserOrganizationMasterV3, Long>{

	public List<UserOrganizationMasterV3> findByOrgType(Long orgType);
	
	@Query(value = "SELECT u.orgId as id,u.displayOrgName as value FROM UserOrganizationMasterV3 u WHERE u.userTypeId =:userTypeId AND isActive=true AND isBorrowerDisplay = true  order by u.displayOrgName asc")
	public List<Map<Long, String>> findByUserTypeIdAndIsActiveTrueAndIsBorrowerDisplayOrderByDisplayOrgNameAsc(@Param("userTypeId") Long userTypeId);
	
	@Query(value = "SELECT u.orgId as id,u.displayOrgName as value FROM UserOrganizationMasterV3 u WHERE u.userTypeId =:userTypeId AND isActive=true AND isBorrowerDisplay = true  order by u.displayOrgName asc")
	public List<Map<String, String>> getOrgIdAndDisplayOrgName(@Param("userTypeId") Long userTypeId);
	
	@Query(value = "SELECT u.orgId as id,u.displayOrgName as value FROM UserOrganizationMasterV3 u WHERE u.userTypeId =:userTypeId AND isActive=true order by u.displayOrgName asc")
	public List<Map<Long, String>> getInsurerList(@Param("userTypeId") Long userTypeId);
	
	@Query(value = "SELECT u.code as id,u.displayOrgName as value FROM UserOrganizationMasterV3 u WHERE u.userTypeId =:userTypeId AND isActive=true order by u.displayOrgName asc")
	public List<Map<String, String>> getCodeAndDisplayOrgName(@Param("userTypeId") Long userTypeId);
	
}
