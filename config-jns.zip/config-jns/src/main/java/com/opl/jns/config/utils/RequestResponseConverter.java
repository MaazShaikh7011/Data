package com.opl.jns.config.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opl.jns.utils.common.AesGcmEncryptionUtils;
//import com.opl.jns.utils.common.EncryptionUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;

@Component
public class RequestResponseConverter extends AbstractHttpMessageConverter<Object> {
	public static final String UTF_8 = "UTF-8";
	public static final Charset DEFAULT_CHARSET = Charset.forName(UTF_8);
	public static final String ENC_DATA = "encData";
	public static final String JAVA_LANG_STRING = "java.lang.String";
	public static final String DATA = "data";
	public static final String REQ_AUTH = "req_auth";
	public static final String IS_DECRYPT = "is_decrypt";
	public static final String TRUE = "true";
	private Charset charset = DEFAULT_CHARSET;

	@Autowired
	private ObjectMapper objectMapper;

	public RequestResponseConverter() {
		List<MediaType> mediaTypes = new ArrayList<>();
		mediaTypes.add(MediaType.APPLICATION_JSON);
//        mediaTypes.add(MediaType.TEXT_HTML); // adding text / html type of support
		setSupportedMediaTypes(mediaTypes);
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return !clazz.getName().contains("java.util.List");
	}

	@Override
	public Object readInternal(Class<? extends Object> clazz, HttpInputMessage inputMessage) throws IOException {
		try {
			ContentDisposition contentDisposition = inputMessage.getHeaders().getContentDisposition();
			if (contentDisposition.isFormData()) {
				return generateMultipart(inputMessage);
			}
			if ((inputMessage.getHeaders().containsKey(REQ_AUTH) && inputMessage.getHeaders().get(REQ_AUTH).contains(TRUE)) || (inputMessage.getHeaders().containsKey(IS_DECRYPT) && inputMessage.getHeaders().get(IS_DECRYPT).contains(TRUE))) {
				if (clazz.getName().contains(JAVA_LANG_STRING)) {
					return generateString(inputMessage.getBody());
				}
				return objectMapper.readValue(inputMessage.getBody(), clazz);
			}
			return objectMapper.readValue(decrypt(inputMessage.getBody(), clazz), clazz);
		} catch (IOException e) {
			logger.error("IOException readInternal " + e);
			return inputMessage.getBody();
		}
	}

	@Override
	public void writeInternal(Object obj, HttpOutputMessage outputMessage) {

		try {
			if ((outputMessage.getHeaders().containsKey(REQ_AUTH) && outputMessage.getHeaders().get(REQ_AUTH).contains(TRUE)) || (outputMessage.getHeaders().containsKey(IS_DECRYPT) && outputMessage.getHeaders().get(IS_DECRYPT).contains(TRUE))) {
				if (obj instanceof byte[] bytes) {
					outputMessage.getBody().write(bytes);
				} else {
					outputMessage.getBody().write(objectMapper.writeValueAsBytes(obj));
				}
			} else {
				if (obj instanceof byte[] bytes) {
					outputMessage.getBody().write(bytes);
				} else {
					outputMessage.getBody().write(encrypt(objectMapper.writeValueAsString(obj)));
				}
			}
		} catch (JsonProcessingException e) {
			logger.error("JsonProcessingException " + e);
		} catch (IOException e) {
			logger.error("IOException " + e);
		}

	}

	public String generateString(InputStream inputStream) throws IOException {
		Writer writer = new StringWriter();
		char[] buffer = new char[1024];
		try {
			Reader reader = new BufferedReader(new InputStreamReader(inputStream, UTF_8));
			int n;
			while ((n = reader.read(buffer)) != -1) {
				writer.write(buffer, 0, n);
			}
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException" + e.getMessage());
		} catch (IOException e) {
			logger.error("IOException decrypt" + e.getMessage());
		} finally {
			inputStream.close();
		}
		return writer.toString().replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "");
	}

	public InputStream decrypt(InputStream inputStream, Class clazz) throws IOException {
		// this is API request params
		String generateString = generateString(inputStream);
		try {
			JSONObject requestJsonObject = new JSONObject(generateString);
			if (requestJsonObject.has(DATA)) {
//				String decryptRequestString = EncryptionUtils.decryptText(requestJsonObject.getString("data"));
				String decryptRequestString = AesGcmEncryptionUtils.decryptNew(requestJsonObject.getString(DATA));
				if (decryptRequestString != null) {
					if (clazz.getName().contains(JAVA_LANG_STRING)) {
						decryptRequestString = MultipleJSONObjectHelper.getStringfromObject(decryptRequestString);
					}
					InputStream byteArrayInputStream = IOUtils.toInputStream(decryptRequestString, StandardCharsets.UTF_8.name());
					return byteArrayInputStream;
				} else {
					return inputStream;
				}
			}
		} catch (JSONException err) {
			logger.error("Error JSONException :::::: " + err.getMessage());
		} catch (NoSuchAlgorithmException | BadPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | NoSuchPaddingException | IllegalBlockSizeException e) {
			logger.info("NoSuchAlgorithmException | BadPaddingException | DigestException | InvalidKeyException | " + "InvalidAlgorithmParameterException | NoSuchPaddingException | IllegalBlockSizeException :: " + e.getMessage());
		}
		return inputStream;
	}

	public byte[] encrypt(String dataToEncrypt) throws JsonProcessingException {
		// do your encryption here
		try {
//			Map<String, String> hashMap = new HashMap<>();
//			hashMap.put("encData", encrypt2);
			JSONObject jsob = new JSONObject();
			jsob.put(ENC_DATA,AesGcmEncryptionUtils.encryptNew(dataToEncrypt));
			return jsob.toString().getBytes();
		} catch (Exception e) {
			logger.info("Error While Encrypt data :: " + e.getMessage());
			return dataToEncrypt.getBytes(StandardCharsets.UTF_8);
		}

	}
	public InputStream encryptedTxtToDecrypt(InputStream inputStream, Class clazz) throws IOException {
		String generateString = generateString(inputStream);
		try {
			JSONObject requestJsonObject = new JSONObject(generateString);
			if (requestJsonObject.has(ENC_DATA)) {
				String decryptRequestString = AesGcmEncryptionUtils.decryptNew(requestJsonObject.getString(ENC_DATA));
				if (decryptRequestString != null) {
					if (clazz.getName().contains(JAVA_LANG_STRING)) {
						decryptRequestString = MultipleJSONObjectHelper.getStringfromObject(decryptRequestString);
					}
					InputStream byteArrayInputStream = IOUtils.toInputStream(decryptRequestString, StandardCharsets.UTF_8.name());
					return byteArrayInputStream;
				} else {
					return inputStream;
				}
			}
		} catch (JSONException err) {
			logger.error("Error JSONException :::::: " + err.getMessage());
		} catch (NoSuchAlgorithmException | BadPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | NoSuchPaddingException | IllegalBlockSizeException e) {
			logger.info("NoSuchAlgorithmException | BadPaddingException | DigestException | InvalidKeyException | " + "InvalidAlgorithmParameterException | NoSuchPaddingException | IllegalBlockSizeException :: " + e.getMessage());
		}
		return inputStream;
	}
	public MultiValueMap<String, String> generateMultipart(HttpInputMessage inputMessage) throws IOException {
		MediaType contentType = inputMessage.getHeaders().getContentType();
		Charset charset = (contentType != null && contentType.getCharset() != null ? contentType.getCharset() : this.charset);
		String body = StreamUtils.copyToString(inputMessage.getBody(), charset);

		String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
		MultiValueMap<String, String> result = new LinkedMultiValueMap<>(pairs.length);
		for (String pair : pairs) {
			int idx = pair.indexOf('=');
			if (idx == -1) {
				result.add(URLDecoder.decode(pair, charset.name()), null);
			} else {
				String name = URLDecoder.decode(pair.substring(0, idx), charset.name());
				String value = URLDecoder.decode(pair.substring(idx + 1), charset.name());
				result.add(name, value);
			}
		}
		return result;
	}
	public static void main(String args[]) throws IOException {
		RequestResponseConverter rs= new RequestResponseConverter();
		String j = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"schemeId\":1,\"customerAccountNumber\":\"string\",\"customerBankName\":\"Rock Patel\",\"customerIFSC\":\"string\",\"accountHolderName\":\"Rock\",\"dob\":\"2022-01-02\",\"gender\":\"M\",\"cif\":\"string\",\"masterPolicyNumber\":\"545454545\",\"dateOfEnrollment\":\"2023-05-16 09:16:54\",\"bankCode\":\"BOB\",\"branchName\":\"string\",\"firstName\":\"Rajesh\",\"middleName\":\"N\",\"lastName\":\"Patel\",\"fatherHusbandName\":\"RameshBhai\",\"mobileNumber\":\"7878544545\",\"emailID\":\"rock@gmail.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"pincode\":385444,\"city\":\"Isanpur\",\"cityLGDCode\":\"string\",\"district\":\"Isanpur\",\"districtLGDCode\":\"string\",\"state\":\"Gujarat\",\"stateLGDCode\":\"string\",\"kycID1\":\"PAN\",\"kycID1number\":\"AAGFV5271N\",\"kycID2\":\"Passport\",\"kycID2number\":\"M65689865\",\"pan\":true,\"panNumber\":\"string\",\"aadhaar\":true,\"aadhaarNumber\":\"string\",\"ckyc\":\"YES\",\"ckycNumber\":\"string\",\"nomineeFirstName\":\"string\",\"nomineeMiddleName\":\"string\",\"nomineeLastName\":\"string\",\"nomineeDateOfBirth\":\"2012-02-22\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"nomineeAddressline1\":\"Isanpur\",\"nomineeAddressline2\":\"Isanpur\",\"nomineePincode\":\"382350\",\"nomineeCity\":\"Ahmedabad\",\"nomineeCityLGDCode\":\"10\",\"nomineeDistrict\":\"Ahmedabad\",\"nomineeDistrictLGDCode\":\"10\",\"nomineeState\":\"Gujarat\",\"nomineeStateLGDCode\":\"10\",\"relationOfNominee\":\"string\",\"nameofGuardian\":\"string\",\"addressOfGuardian\":\"string\",\"relationShipOfGuardian\":\"string\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"claimantFirstName\":\"string\",\"claimantMiddleName\":\"string\",\"claimantLastName\":\"string\",\"claimantDateOfBirth\":\"2012-02-22\",\"relationOfClaimant\":\"string\",\"claimantMobileNumber\":\"string\",\"claimantKYC1\":\"string\",\"claimantKYCNumber1\":\"string\",\"claimantKYC2\":\"string\",\"claimantKycNumber2\":\"string\",\"dateOfAccident\":\"2012-02-22\",\"timeOfAccident\":\"16:12:10\",\"dayOfAccident\":\"Sunday\",\"placeOfAccident\":\"string\",\"natureOfAccident\":\"string\",\"dateOfDeath\":\"2023-05-16 09:16:54\",\"causeOfDeath\":\"string\",\"causeOfDeathDisability\":\"string\",\"typeOfDisability\":\"string\",\"claimantBankAccount\":\"string\",\"claimantBank\":\"string\",\"claimantIFSC\":\"string\",\"premDebitDate\":\"2012-02-22\",\"premRemitDate\":\"2012-02-22\"}";
//     Map<String, Object> stringfromObject = MultipleJSONObjectHelper.getMapFromString(j);
		System.err.println("stribg: "+j);
		byte[] encrypt = null;
		try {
			encrypt = rs.encrypt(j);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sr = new String(encrypt, StandardCharsets.UTF_8);
		System.err.println("data: "+sr);


		InputStream targetStream = new ByteArrayInputStream(sr.getBytes(UTF_8));
		System.err.println("byte: "+targetStream);
		InputStream decrypt = rs.encryptedTxtToDecrypt(targetStream,InputStream.class);




		String generateString = rs.generateString(decrypt);

		System.err.println("decyript: "+generateString);
	}
}

