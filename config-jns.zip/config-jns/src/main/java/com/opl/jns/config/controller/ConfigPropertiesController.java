package com.opl.jns.config.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.config.utils.SkipInterceptor;

import lombok.extern.slf4j.Slf4j;

import jakarta.servlet.http.*;

@Slf4j
@RestController
@RequestMapping("/config_properties")
public class ConfigPropertiesController {

    @Autowired
    private ConfigProperties configProperties;

    @SkipInterceptor
    @GetMapping(value = "/get_by_key/{code}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getByKey(@PathVariable String code) {
        try {
            String value = configProperties.getValue(code);
            if (OPLUtils.isObjectNullOrEmpty(value)) {
                return new ResponseEntity<CommonResponse>(
                        new CommonResponse("No Data Found", HttpStatus.OK.value(), Boolean.FALSE),
                        HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Successfully data found !!", value, HttpStatus.OK.value(), Boolean.TRUE),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while get value by key ==>", e);
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Something went wrong..!", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE),
                    HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @GetMapping(value = "/getProperties", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getProperties(HttpServletRequest httpServletRequest) {
        try {
            CommonResponse res = new CommonResponse();
            res.setData(configProperties.getAllValue());
            res.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getProperties() ", e.getMessage());
            return null;
        }
    }

    @SkipInterceptor
    @GetMapping(value = "/setProperties", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> setProperties(HttpServletRequest httpServletRequest) {
        try {
            CommonResponse res = new CommonResponse();
            configProperties.setAllValue();
            res.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in setProperties() ", e.getMessage());
            return null;
        }
    }


}
