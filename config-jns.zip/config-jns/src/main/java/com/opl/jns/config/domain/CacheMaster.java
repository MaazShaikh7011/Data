package com.opl.jns.config.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

/**
 * @author ravi.thummar
 * Date : 08-08-2023
 */

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cache_master", schema = DBNameConstant.JNS_CONFIG)
public class CacheMaster {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cache_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "cache_master_seq_gen", sequenceName = "cache_master_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "value")
    private String value;

    @Column(name = "hour")
    private Integer hour;

    @Column(name = "is_active")
    private Boolean isActive;

}
