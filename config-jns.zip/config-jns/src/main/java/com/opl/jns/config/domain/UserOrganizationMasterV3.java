package com.opl.jns.config.domain;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_organisation_master", schema = "jns_config")
public class UserOrganizationMasterV3 {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_organisation_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "user_organisation_master_seq_gen", sequenceName = "user_organisation_master_seq_gen", allocationSize = 1)
	@Column(name = "org_id", nullable = true)
	private Long orgId;
	
	@Column(name = "code", nullable = true)
	private String code;
	
	@Column(name = "display_org_name", nullable = true)
	private String displayOrgName;
	
	@Column(name = "is_active", nullable = true)
	private Boolean isActive;
	
	@Column(name = "is_reverse_api_activated", nullable = true)
	private Boolean isReverseApiActivated;
	
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;
	
	@Column(name = "org_type", nullable = true)
	private Long orgType;
	
	@Column(name = "organisation_name", nullable = true)
	private String organisationName;
	
	@Column(name = "user_type_id", nullable = true)
	private Long userTypeId;
	
	@Column(name = "is_borrower_display", nullable = true)
	private Boolean isBorrowerDisplay;
}
