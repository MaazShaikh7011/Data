package com.opl.jns.config.utils;

import java.util.Properties;

import javax.sql.DataSource;

import com.opl.jns.config.utils.*;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.*;
import com.opl.jns.utils.enums.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.sql.init.dependency.DependsOnDatabaseInitialization;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages= {PersistenceContextV3.$_COM_JNS_SERVICE_REPOSITORY_PACKAGE,"com.opl.jns.ere.repo","com.opl.jns.config.repository","com.opl.bucket.storage.repository","com.opl.notification.provider.repository"}, entityManagerFactoryRef = "emFR", transactionManagerRef = "tmr")
public class PersistenceContextV3 {

	public static final String $_COM_JNS_SERVICE_REPOSITORY_PACKAGE = "${com.jns.service.repository-package}";
	@Autowired
	private ApplicationProperties properties;



	public static final String ORACLE_JDBC_ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
	public static final String ORG_HIBERNATE_DIALECT_ORACLE_12_C_DIALECT = "org.hibernate.dialect.OracleDialect";
	public static final String ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY = "org.hibernate.cfg.ImprovedNamingStrategy";
	public static final String HIBERNATE_HQL_BULK_ID_STRATEGY = "hibernate.hql.bulk_id_strategy";
	public static final String ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY = "org.hibernate.hql.spi.id.inline.InlineIdsOrClauseBulkIdStrategy";
	public static final String NONE = "none";
	public static final String CREATE = "create";
	public static final String UPDATE = "update";
	public static final String SELECT_1_FROM_DUAL = "SELECT 1 FROM DUAL";
	private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	private static final String PROPERTY_NAME_HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
	private static final String PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
	private static final String PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY = "hibernate.ejb.naming_strategy";
	private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_NAME_HIBERNATE_LAZY_LOAD = "hibernate.enable_lazy_load_no_trans";

	private static final String ENTITY_MANAGER_REFERENCE = "emFR";
	private static final String DATASTORE = "dsEcr";
	private static final String DATASOURCE = "dataSource";
	private static final String TRANSACTION_MANAGER_REFERENCE = "tmr";
	private static final String TRANSACTION_MANAGER = "transactionManager";


	@Bean(name = {DATASTORE,DATASOURCE})
	@Primary
    public DataSource dataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(ORACLE_JDBC_ORACLE_DRIVER);
//        System.out.println("-------------------------DB-MAIN - ORACLE------------------>" + DataSourceProvider.getDbUrlOracle());
//        System.out.println("-------------------------User/Pwd - ORACLE------------------>" + properties.getOracleDbName()+"/"+properties.getOracleDbPass());
        dataSource.setJdbcUrl(DataSourceProvider.getDbUrlOracle() );
        dataSource.setUsername(properties.getOracleDbName());
        dataSource.setPassword(properties.getOracleDbPass());
        dataSource.setConnectionTestQuery(SELECT_1_FROM_DUAL);
		dataSource.setMaximumPoolSize(Integer.parseInt(properties.getDbMaxConnections()));
		dataSource.setMaxLifetime(Long.parseLong(properties.getDbMaxLifetimeInMillis()));
		dataSource.setConnectionTimeout(Long.parseLong(properties.getDbConnectionTimeoutInMillis()));
		
		if(!OPLUtils.isObjectNullOrEmpty(properties.getDbMinimumIdle())) {
			dataSource.setMinimumIdle(Integer.parseInt(properties.getDbMinimumIdle()));	
		}
		if(!OPLUtils.isObjectNullOrEmpty(properties.getDbMaximumpoolsize())) {
			dataSource.setMaximumPoolSize(Integer.parseInt(properties.getDbMaximumpoolsize()));	
		}
		if(!OPLUtils.isObjectNullOrEmpty(properties.getDbIdelTimeout())) {
			dataSource.setIdleTimeout(Integer.parseInt(properties.getDbIdelTimeout()));	
		}
        return dataSource;
    }


	@Bean(name = {TRANSACTION_MANAGER_REFERENCE,TRANSACTION_MANAGER})
	@DependsOn({DATASTORE,DATASOURCE})
	@DependsOnDatabaseInitialization
	@Primary
	public JpaTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return transactionManager;
	}

	@Bean(name = ENTITY_MANAGER_REFERENCE)
	@DependsOn(DATASTORE)
	@Primary
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

		entityManagerFactoryBean.setDataSource(dataSource());
		entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		entityManagerFactoryBean.setPackagesToScan(properties.getOracleDomainPackageName(),"com.opl.jns.ere.domain","com.opl.jns.config.domain","com.opl.bucket.storage.domain","com.opl.notification.provider.domain");

		Properties jpaProperties = new Properties();
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_DIALECT, ORG_HIBERNATE_DIALECT_ORACLE_12_C_DIALECT);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_FORMAT_SQL,properties.getHibernateFormatSql());
		ENVMode envMode = DataSourceProvider.getEnvMode();
		if(envMode.equals(ENVMode.P)) {
			// To prevent unwanted DDL Operation in database on Production.
			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO, NONE);
		}else {
			if(properties.getHibernateHbm2ddlOracle().equals(CREATE)) {
				properties.setHibernateHbm2ddl(UPDATE);
			}
			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO,properties.getHibernateHbm2ddlOracle());
		}

		jpaProperties.put(PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY, ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL,properties.getHibernateShowSql());
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_LAZY_LOAD,properties.getHibernateEnableLazyLoadNoTrans());
		jpaProperties.put(HIBERNATE_HQL_BULK_ID_STRATEGY, ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY);
		entityManagerFactoryBean.setJpaProperties(jpaProperties);
		return entityManagerFactoryBean;
	}
}
