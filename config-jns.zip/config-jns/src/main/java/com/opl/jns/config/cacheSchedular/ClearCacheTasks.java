package com.opl.jns.config.cacheSchedular;

import com.opl.jns.config.domain.CacheMaster;
import com.opl.jns.config.repository.CacheMasterRepository;
import com.opl.jns.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@EnableCaching
public class ClearCacheTasks {

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private CacheMasterRepository cacheMasterRepository;

    private static final Logger log = LoggerFactory.getLogger(ClearCacheTasks.class);

    /*
     * at 9,12,15,18,21 hour at 5th min
     * */
    //@Scheduled(cron = "0 5 9,12,15,18,21 * * ?")

    /*
     * every 1 hour at 5th min cache will be clear
     * */
//    @Scheduled(cron = "0 5 * * * ?")

    /**
     * every 10 min Call scheduler set
     */
//    @Scheduled(cron = "0/30 * * * * ?")// every 30 sec
    @Scheduled(cron = "0 5 0/1 * * ?") // every 1 hour at 5 min
    public void run() {
        log.info("-- In clear cache scheduler --" + new Date());
        Integer hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
//        List<Integer> everyThreeHours = Arrays.asList(9, 12, 15, 18, 21); // Every 3 Hours clear  // 3, 6,
//        List<Integer> everySixHours = Arrays.asList(9, 15, 21); // Every 6 Hour clear // 3,
//        List<String>  sixHourReportNameList = null; // CacheMaster.getReportCachesList(6);
        List<CacheMaster> cacheMasterList = cacheMasterRepository.findAllByIsActiveTrue();

        forLoop:
        for (String cacheName : cacheManager.getCacheNames()) {
//            String cacheName = cacheManager.getCache(name).getName();
            if (!OPLUtils.isListNullOrEmpty(cacheMasterList)) {
                Optional<CacheMaster> cacheObj = cacheMasterList.stream().filter(x -> x.getValue().equalsIgnoreCase(cacheName)).findFirst();
                if (cacheObj.isPresent()) {
                    if ((hour % cacheObj.get().getHour()) != 0) {
                        break forLoop;
                    } else {
                        cacheManager.getCache(cacheName).clear();
                        log.info(" -- removed cache -- : {}", cacheName);
                    }
                } else {
                    cacheManager.getCache(cacheName).clear();
                    log.info(" -- removed cache -- : {}", cacheName);
                }
            } else {
                cacheManager.getCache(cacheName).clear();
                log.info(" -- removed cache -- : {}", cacheName);
            }

//            if (!everySixHours.contains(hour)
//                    && (sixHourReportNameList.equals(cacheName) || cacheName.contains("onfm"))) {
//                break forLoop;
//            } else if (!everyThreeHours.contains(hour) && cacheName.contains("rpt")) {
//                break forLoop;
//            } else {
//                cacheManager.getCache(name).clear();
//                log.info(" -- removed cache -- : " + cacheName);
//            }
        }
        log.info("-- Exit from clear cache scheduler --" + new Date());
    }
}
