package com.opl.jns.config.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.config.domain.ApiUsersV3;

public interface ApiUsersRepositoryV3 extends JpaRepository<ApiUsersV3, Long> {

	Page<ApiUsersV3> findAll(Pageable pageable);

	List<ApiUsersV3> findAllByIsActiveTrue();
	
	List<ApiUsersV3> findAllByOrderByOrgIdAsc();
	
	ApiUsersV3 findFirstByIsInternalUserTrue();
	
	ApiUsersV3 findFirstByOrgIdAndConfigType(Long orgId, Integer configType);

	ApiUsersV3 findFirstByOrgId(Long orgId);
}