package com.opl.jns.config.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.config.domain.ConfigMasterV3;

public interface ConfigMasterRepositoryV3 extends JpaRepository<ConfigMasterV3, Long> {

    public ConfigMasterV3 findByCodeAndIsActive(String code, Boolean isActive);
    public List<ConfigMasterV3> findAllByIsActiveTrue();

    //@Query(value = "from ConfigMaster where code IN (:codeList) and isActive = true")
    public List<ConfigMasterV3> findByCodeInAndIsActiveTrue(List<String> codeList);

}
