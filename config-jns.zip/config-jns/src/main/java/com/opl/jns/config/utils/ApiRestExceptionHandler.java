package com.opl.jns.config.utils;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;


@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class ApiRestExceptionHandler extends ResponseEntityExceptionHandler  {


    private final static Logger log = LoggerFactory.getLogger(ApiRestExceptionHandler.class);
    /**
     * Handle MissingServletRequestParameterException. Triggered when a 'required' request parameter is missing.
     *
     * @param ex      MissingServletRequestParameterException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        String error = ex.getParameterName() + " parameter is missing";
        return buildResponseEntity(new CommonResponse(error, null, HttpStatus.OK.value()));
    }


    /**
     * Handle HttpMediaTypeNotSupportedException. This one triggers when JSON is invalid as well.
     *
     * @param ex      HttpMediaTypeNotSupportedException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
            HttpMediaTypeNotSupportedException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {
        StringBuilder builder = new StringBuilder();
        builder.append(ex.getContentType());
        builder.append(" Media type is not supported. Supported media types are ");
        ex.getSupportedMediaTypes().forEach(t -> builder.append(t).append(", "));
        return buildResponseEntity(new CommonResponse(builder.substring(0, builder.length() - 2), null, HttpStatus.UNSUPPORTED_MEDIA_TYPE.value()));
    }

    /**
     * Handle MethodArgumentNotValidException. Triggered when an object fails @Valid validation.
     *
     * @param ex      the MethodArgumentNotValidException that is thrown when @Valid validation fails
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {
        CommonResponse commonResponse = new CommonResponse("",BAD_REQUEST.value());
        List<String> errorMessages = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getField().concat(" ").concat(x.getDefaultMessage())).collect(Collectors.toList());
        commonResponse.setMessage(errorMessages.stream().collect(Collectors.joining(", ", "", "")));
        return buildResponseEntity(commonResponse);
    }


    /**
     * Handle HttpMessageNotReadableException. Happens when request JSON is malformed.
     *
     * @param ex      HttpMessageNotReadableException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        log.info("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());
        String error = "It seems that request is not properly formed";
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());

        if(ex.getCause() instanceof InvalidFormatException){
            List<String> fieldsWithInvalidData  = new ArrayList<>();
            List<JsonMappingException.Reference> referenceList = ((InvalidFormatException)ex.getCause()).getPath();
            if(referenceList != null){
                fieldsWithInvalidData  = referenceList.stream().map(JsonMappingException.Reference::getFieldName).collect(Collectors.toList());
            }
            String invalidFieldsLstStr =fieldsWithInvalidData.toString();
            if(invalidFieldsLstStr != null){
                invalidFieldsLstStr =invalidFieldsLstStr.replace("[","").replace("]","");
                invalidFieldsLstStr += " field contains invalid value";
            }
            commonResponse.setMessage(invalidFieldsLstStr);
//            commonResponse.setSuccess(Boolean.FALSE);
            return buildResponseEntityApiSuccess(commonResponse,HttpStatus.OK.value());
        }
        return buildResponseEntity(new CommonResponse(error, null, HttpStatus.OK.value()));
    }

    /**
     * Handle HttpMessageNotWritableException.
     *
     * @param ex      HttpMessageNotWritableException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        String error = "Error writing Response output";
//        return buildResponseEntity(new CommonResponse(error, ex, HttpStatus.INTERNAL_SERVER_ERROR.value()));
		return null;
    }

    /**
     * Handle NoHandlerFoundException.
     *
     * @param ex
     * @param headers
     * @param status
     * @param request
     * @return
     */
    protected ResponseEntity<Object> handleNoHandlerFoundException(
            NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        CommonResponse apiError = new CommonResponse("",BAD_REQUEST.value());
        apiError.setMessage("Could not find the %s method for URL %s".formatted(ex.getHttpMethod(), ex.getRequestURL()));
        apiError.setMessage(ex.getMessage());
        return buildResponseEntity(apiError);
    }



    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
                                                                         HttpHeaders headers, HttpStatus status, WebRequest request) {
        // TODO Auto-generated method stub
        CommonResponse apiError = new CommonResponse("",HttpStatus.METHOD_NOT_ALLOWED.value());
        apiError.setMessage("Requested Method not supported");
        StringBuilder builder = new StringBuilder();
        ex.getSupportedHttpMethods().forEach(t -> builder.append(t).append(", "));
        apiError.setMessage(ex.getMessage());
        return buildResponseEntity(apiError);
    }


    private ResponseEntity<Object> buildResponseEntity(CommonResponse commonResponse) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        //CommonResponse.setStatus(OplMsgCodes.UKN1002);
//        String data = null;
//        try {
//            data = MultipleJSONObjectHelper.getStringfromObject(CommonResponse);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        return new ResponseEntity<>(commonResponse, headers,HttpStatus.valueOf(commonResponse.getStatus()));
    }

    private ResponseEntity<Object> buildResponseEntityApiSuccess(CommonResponse commonResponse,Integer status) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        //CommonResponse.setStatus(OplMsgCodes.UKN1002);
        /*String data = null;
        try {
            data = MultipleJSONObjectHelper.getStringfromObject(CommonResponse);
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        return new ResponseEntity<>(commonResponse, headers,HttpStatus.valueOf(status));
    }

}
