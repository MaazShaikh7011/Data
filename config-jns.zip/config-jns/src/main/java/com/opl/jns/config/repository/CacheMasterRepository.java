package com.opl.jns.config.repository;

import com.opl.jns.config.domain.CacheMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author ravi.thummar
 * Date : 08-08-2023
 */
public interface CacheMasterRepository extends JpaRepository<CacheMaster, Long> {

    public List<CacheMaster> findAllByIsActiveTrue();

}
