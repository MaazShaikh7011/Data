package com.opl.jns.config.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "config_master", schema = "jns_config")
public class ConfigMasterV3 implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "config_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "config_master_seq_gen", sequenceName = "config_master_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "code")
	private String code;

	@Column(name = "value")
	private String value;

	@Column(name = "is_active")
	private Boolean isActive;
	
}
