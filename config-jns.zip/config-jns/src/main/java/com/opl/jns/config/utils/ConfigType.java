package com.opl.jns.config.utils;

public enum ConfigType {
    BANK_CONFIG(1),
    INSURER_CONFIG(2),
	OTHER_CHANNEL_CONFIG(3);

    int configType;

    ConfigType(int configType){
        this.configType = configType;
    }

    public int getConfigType() {
        return configType;
    }


    public static ConfigType fromId(Integer v) {
        for (ConfigType c : ConfigType.values()) {
            if (c.configType == v) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }
}
