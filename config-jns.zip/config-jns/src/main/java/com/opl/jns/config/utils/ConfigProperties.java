package com.opl.jns.config.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.config.repository.ConfigMasterRepositoryV3;

import lombok.extern.slf4j.Slf4j;

/**
 * @author harshit.suhagiya
 * @author Maaz Shaikh
 */
@Component
@Slf4j
public class ConfigProperties {

    @Autowired
    private ConfigMasterRepositoryV3 configMasterRepo;

    private static final List<ConfigMasterProxy> configList=new ArrayList<>();

    public static String TESTING_MODE_ON_OFF = "TESTING_MODE_ON_OFF";
    public static String NAME_MATCH_ALGO = "NAME_MATCH_ALGO";
    public static String NRLM_LOGIN_API = "NRLM_LOGIN_API";
    public static String NRLM_FETCH_APPLICATION_LIST = "NRLM_FETCH_APPLICATION_LIST";
    public static String NRLM_FETCH_APPLICATION_DETAILS = "NRLM_FETCH_APPLICATION_DETAILS";
    public static final String SAVE_DETAILS_TESTING_MODE = "SAVE_DETAILS_TESTING_MODE";
    public static final String SKIP_ALL_TESTING_AND_DE_DUPE_MODE = "SKIP_ALL_TESTING_AND_DE_DUPE_MODE";
    public static final String IS_DIY_SIGN_UP_SKIP_JOURNEY="IS_DIY_SIGN_UP_SKIP_JOURNEY";
    public static final ConfigMasterProxy blankObject = new ConfigMasterProxy();

    public String getValue(String code) {
        if(configList.isEmpty()){
            setAllValue();
        }
        return configList.stream().filter(configMaster -> (configMaster.getCode().equals(code))).findFirst().orElse(blankObject).getValue();
    }

    public void setAllValue() {
    	configList.clear();
        configList.addAll(configMasterRepo.findAllByIsActiveTrue().stream()
                .map(conf -> new ConfigMasterProxy(conf.getId(), conf.getCode(), conf.getValue(), conf.getIsActive()))
                .collect(Collectors.toList()));
    }

    public List<ConfigMasterProxy> getAllValue() {
        if(configList.isEmpty()){
            setAllValue();
        }
        return configList;
    }

    public String getValueByCode(String code) {
        if(configList.isEmpty()){
            setAllValue();
        }
        return configList.stream().filter(configMaster -> (configMaster.getCode().equals(code))).findFirst().orElse(blankObject).getValue();
    }


    public List<ConfigMasterProxy> getValues(String... code) {
        if(configList.isEmpty()){
            setAllValue();
        }
        return configList.stream().filter(configMaster -> Arrays.asList(code).stream()
                .anyMatch(codeStr ->  configMaster.getCode().equals(codeStr))).collect(Collectors.toList());
    }

    public static String getValues(String code) {
        return configList.stream().filter(configMaster -> (configMaster.getCode().equals(code))).findFirst().orElse(blankObject).getValue();
    }
   
    public static String getBankApiTestingModeFlags(){
        return getValues(SAVE_DETAILS_TESTING_MODE);
    }
    public static String getIsDiySignUpSkipJourneyFlags(){
        return getValues(IS_DIY_SIGN_UP_SKIP_JOURNEY);
    }
    public static List<String> getSkipAllTestingAndDeDupeMode(){
       String skipEmailIds =  getValues(SKIP_ALL_TESTING_AND_DE_DUPE_MODE);
       List<String> skipEmailIdsList = new ArrayList<String>(Arrays.asList(skipEmailIds.split(" , ")));
		return skipEmailIdsList;
    }

}
