package com.opl.jns.registry.api.utils.v3;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class Constants {

    public static final  String CLAIM_DE_DUP_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":\"123\",\"hospitalisationDate\":\"2023-11-27 16:05:22\",\"firNo\":\"String\",\"firDate\":\"2023-11-27 16:05:22\",\"panchnamaNo\":\"String\",\"panchnamaDate\":\"2023-11-27 16:05:22\",\"postMortemReportNo\":\"String\",\"postMortemReportDate\":\"2023-11-27 16:05:22\",\"deathordisabilitycertificateReportNo\":\"String\",\"deathordisabilityCertificateReportDate\":\"2023-11-27 16:05:22\",\"documentReceivingDate\":\"2023-11-27\",\"token\":\"String\"}";
    //    public static final  String CLAIM_DE_DUP_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":0,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\",\"data\":{\"isMatched\":\"string\",\"matchWith\":\"string\",\"bankName\":\"string\"}}";
    public static final  String CLAIM_DE_DUP_PLAIN_RESPONSE_SUCCESS="{\"message\":\"Success\",\"success\":true,\"status\":200,\"data\":{\"dedupeCheck\":true,\"isMatchWith\":{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"intimationDate\":\"2000-08-08\",\"type\":1,\"claimStatus\":1,\"dateOfLoss\":\"\",\"beneficiaryBank\":\"\"}},\"token\":\"string\",\"timeStamp\": \"2023-11-27 16:05:22\"}";

    public static final  String ENROLLMENT_PLAIN_REQUEST_EXAMPLE="{\"token\":\"string\",\"customerDetails\":{\"accountNumber\":\"565888744\",\"cif\":\"stringstri\",\"customerIFSC\":\"string\",\"accountHolderName\":\"Rajeshbhai\",\"gender\":\"M\",\"fatherHusbandName\":\"RRameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7567794689\",\"emailId\":\"xyz@gmail.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"city\":\"Ahmedabad\",\"district\":\"string\",\"state\":\"Gujarat\",\"pincode\":382443,\"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringstri\",\"applicantOccupation\":\"worker\"},\"kycDetails\":{\"kycId1\":\"PAN\",\"kycIdValue1\":\"AAGFV5271N\",\"panNumber\":\"AAGFV5271N\",\"aadhaarNumber\":\"548537793745\"},\"nomineeDetails\":{\"nomineeName\":\"Rajesh\",\"dob\":\"2000-08-08\",\"mobile\":\"8787854563\",\"relationShip\":\"Father\",\"emailId\":\"abc@gmail.com\",\"addressOfNominee\":\"nikol,ahemedabad\"},\"guardianDetails\":{\"guradianName\":\"Rock\",\"addressofGuardian\":\"Isanpur\",\"relationShip\":\"Father\",\"mobile\":\"7568898968\",\"emailId\":\"xyz@mail.com\"},\"otherDetails\":{\"schemeName\":\"string\",\"bankCode\":\"string\",\"branchCode\":\"string\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"string\",\"userId2\":\"string\",\"channelId\":\"string\"}}";
    
    public  static final String ENROLLMENT_PLAIN_RESPONSE_SUCCESS="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"message\":\"string\",\"status\":0,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\"}";
    public static final  String UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"debitStatus\": 1,\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"masterPolicyNumber\":\"string\",\"insurerCode\":\"44444\",\"transactionUTR\":\"string\",\"transactionType\":\"string\",\"token\":\"string\"}";
    public static final  String UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-23 07:01:00\",\"token\":\"ae75100d-57d4-436b-9c57-06f25be04f3f\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}}";

    public static final  String UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE="{\"accountNumber\":\"*******8243\",\"dob\":\"2000-08-08\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"accountStatus\":6,\"reason\":\"string\",\"reason\":\"string\",\"token\":\"string\"}";
    public static final  String UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\"}";

    public static final  String PUSH_ENROLLMENT_DEATILS_EXAMPLE="{\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"policyYear\":\"2022\",\"insurerCode\":\"78451\",\"transactionUTR\":\"string\",\"transactionTimeStamp\":\"2023-05-16 09:16:54\",\"transactionAmount\":0,\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"source\":\"Other channel\",\"mode\": \"DIY\",\"transactionType\":\"N\",\"masterPolicyNumber\":\"56556555556\",\"schemeName\":\"string\",\"branchCode\":\"string\",\"bankCode\":\"784521\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"1051\",\"userId2\":\"1051\",\"channelId\":\"string\",\"ruralUrban\":\"Rural\",\"accountNumber\":\"*******8243\",\"cif\":\"5454554\",\"customerIFSC\":\"AAAD0FDFF\",\"accountHolderName\":\"Rock\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"pincode\":385445,\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"kycID1\":\"PAN\",\"kycID1Number\":\"AAGFV5271N\",\"pan\":\"Y\",\"panNumber\":\"string\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"string\", \"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringsssss\", \"applicantOccupation\":\"worker\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"relationshipOfNominee\":\"Wife\",\"nomineeEmailId\":\"rajesh@opl.com\",\"addressofNominee\":\"Isanpur\",\"nameofGuardian\":\"rock\",\"addressOfGuardian\":\"Isanpur\",\"relationShipOfGuardian\":\"Son\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"} }";
	public static final  String PUSH_ENROLLMENT_DEATILS_SUCCESS="{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"string\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":\"123\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":1,\"reason\":1,\"claimId\":\"String\",\"insurerStatus\":\"String\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"},\"token\":\"string\"}";
//    public static final  String UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true}";
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true,\"token\":\"3321156485\",\"timestamp\":\"2023-05-05 16:12:10\"}";
    public static final  String CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":123,\"remarks\":\"\",\"documentList\":[{\"documentType\":\"string\",\"documentId\":\"0\",\"contentType\":\"string\",\"document\":[\"string\"]}],\"token\":\"string\"}";
    public static final  String CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"success\",\"status\":200,\"success\":true,\"token\":\"3321156485\",\"timestamp\":\"2023-05-05 16:12:10\"}";
   
	public static final  String CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":\"452134531\",\"masterPolicyNumber\":\"56556555556\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"schemeName\":\"PMSBY\",\"customerAccountNumber\":\"784512451245\",\"customerBankname\":\"Union\",\"customerIFSC\":\"UBIN0994599\",\"accountHolderName\":\"nimesh\",\"dob\":\"2000-08-08\",\"gender\":\"M\",\"insurerCode\":\"784512\",\"bankCode\":\"784521\",\"branchCode\":\"784512\",\"bankBranchEmailId\":\"xyx@opl.com\", \"mobileNumber\":\"7845124512\",\"emailID\":\"xyx@opl.com\",\"addressline1\":\"A-2 new\",\"addressline2\":\"old city\",\"pincode\":\"382415\",\"city\":\"ahmedabad\",\"district\":\"gujarat\",\"state\":\"gujarat\",\"kycID1\":\"PAN\",\"kycID1number\":\"FMXOO9090A\",\"pan\":\"Y\",\"panNumber\":\"FMXUU7878A\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"784512458956\",\"ckyc\":\"Y\",\"ckycNumber\":\"78451245124512\",\"nomineeName\":\"harsh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeGender\":\"M\",\"nomineeMobileNumber\":\"7845124512\",\"relationshipOfNominee\":\"BROTHER\",\"nomineeEmailId\":\"sss@opl.com\",\"addressofNominee\":\"new delhi\",\"correctNomineeName\":\"rahul\",\"nameofGuardian\":\"harsh\",\"addressOfGuardian\":\"new mumbai\",\"relationShipOfGuardian\":\"SON\",\"guardianMobileNumber\":\"8956234512\",\"guardianEmailId\":\"www@opl.com\",\"claimantName\":\"rajesh\",\"claimantAddress\":\"rajasatstan\",\"claimantDateOfBirth\":\"2000-08-08\",\"relationshipOfClaimant\":\"WIFE\",\"claimantMobileNumber\":\"8945154512\",\"claimantEmailId\":\"ttt@opl.com\",\"claimantKYC1\":\"PAN\",\"claimantKYCNumber1\":\"FDXII8989A\",\"claimantKYC2\":\"AADHAR\",\"claimantKycNumber2\":\"784512458956\",\"claimantGender\":\"M\",\"dateOfAccident\":\"2000-08-08\",\"timeOfAccident\":\"02:20:45\",\"dayOfAccident\":\"Sunday\",\"placeOfOccurence\":\"delhi\",\"natureOfAccident\":\"done\",\"dateOfDeath\":\"2000-08-08 15:24:58\",\"causeOfDeath\":\"Suicide\",\"causeOfDeathDisability\":\"Suicide\",\"typeOfDisability\":\"Total permanent\",\"claimantBankAccountNumber\":\"784512451245\",\"claimantBankName\":\"Union\",\"claimantBranchIFSC\":\"UBIN0995999\",\"premDebitDate\":\"2000-08-08\",\"premRemitDate\":\"2000-08-08\",\"dateOfLodgingClaim\":\"2000-08-08\",\"documents\":[{\"documentType\":\"claimDocuments\",\"contentType\":\"pdf\",\"documentId\":\"7845124512\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}]}";
	public static final  String CLAIM_PUSH_PLAIN_RESPONSE_200="{\"message\":\"success\",\"success\":true,\"status\":\"200\",\"success\":true,\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\":\"2023-11-27 16:05:22\"}";
	
	public static final  String CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"branchCode\":\"string\",\"branchName\":\"string\",\"bankBranchEmailId\":\"xyz@gmail.com\",\"cif\":\"45465454\",\"schemeName\":\"string\",\"bankCode\":\"784521\",\"customerAccountNumber\":\"string\",\"customerIFSC\":\"AAAD0FDFF\",\"accountHolderName\":\"Rock\",\"fatherHusbandName\":\"Rajeshbhai\",\"dob\":\"2000-08-08\",\"gender\":\"M\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressline1\":\"Isanpur\",\"addressline2\":\"Isanpur\",\"pincode\":385445,\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"kycId1\":\"PAN\",\"kycID1number\":\"AAGFV5271N\",\"pan\":\"Y\",\"panNumber\":\"FMXUU7878A\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"784512458956\",\"ckyc\":\"Y\",\"ckycNumber\":\"548537793745\",\"nomineeName\":\"string\",\"nomineeGender\":\"M\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"addressOfNominee\":\"nikol,ahemedabad\",\"relationshipOfNominee\":\"Husband\",\"nomineeNameCorrection\":\"Y\",\"correctNomineeName\":\"string\",\"nameofGuardian*\":\"string\",\"addressofGuardian\":\"Iskon,ahemedabad\",\"relationShipOfGuardian\":\"Wife\",\"guardianMobileNumber\":\"7598898956\",\"guardianEmailId\":\"rajesh@opl.com\",\"claimantName\":\"string\",\"claimantDateOfBirth\":\"2000-08-08\",\"relationshipOfClaimant\":\"string\",\"claimantMobileNumber\":\"string\",\"claimantEmailId\":\"xyz@gmail.com.com\",\"claimantKYC1\":\"string\",\"claimantAddress\":\"Iskon,ahemedabad\",\"claimantKYCNumber1\":\"string\",\"claimantGender\":\"M\",\"dateOfAccident\":\"2000-08-08\",\"timeOfAccident\":\"16:12:10\",\"dayOfAccident\":\"Sunday\",\"placeOfOccurence\":\"string\",\"natureOfAccident\":\"string\",\"dateOfDeath\":\"2023-05-16 09:16:54\",\"causeOfDeath\":\"string\",\"causeOfDeathDisability\":\"string\",\"typeOfDisability\":\"string\",\"claimantBankAccountNumber\":\"string\",\"claimantBankName\":\"string\",\"claimantBranchIFSC\":\"string\",\"premDebitDate\":\"2000-08-08\",\"premRemitDate\":\"2000-08-08\",\"dateOfLodgingClaim\":\"2000-08-08\",\"firstEnrollmentDate\":\"2023-05-14 08:25:17\",\"transactionTimestamp\":\"2023-05-14 00:00:00\",\"transactionAmount\":\"418\",\"transactionUTR\":\"S343423\",\"insurerCode\":\"44444\",\"token\":\"String\"}"; 
    public static final  String CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"success\",\"status\":200,\"data\":{\"claimReferenceId\":123},\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"success\":true}";
    
    public static final  String CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED="{\"message\":\"De-dupe failed reason\",\"status\":\"400\",\"success\":\"true\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"asdasdasdsadsad\"}";
    
    public static final  String UPDATE_NOMINEE_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000003373-236\",\"accountNumber\":\"852852852\",\"nomineeUpdateFlag\":\"YES\",\"accountHolderName\":\"Rock\",\"dob\":\"2023-08-08\",\"customerIFSC\":\"IDIB000D088\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"pincode\":\"385445\",\"kycID1\":\"PAN\",\"kycID1Number\":\"AAGFV5271N\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"policyInceptionDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2023-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"relationshipOfNominee\":\"Wife\",\"addressofNominee\":\"Isanpur\",\"nameofGuardian\":\"helooooooooooooooooooooo\",\"addressOfGuardian\":\"Isanpur\",\"relationShipOfGuardian\":\"Son\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"channelId\":\"BC\",\"userId1\":\"paresh@opl.com\",\"token\":\"JNS5546546645654645654654645\"}";
    public static final  String UPDATE_NOMINEE_SUCCESS ="{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"string\",\"timeStamp\": \"2023-11-27 16:05:22\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}}"; 
    
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
//    public static final  String PLAIN_RESPONSE_401="{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false}";

    public static final  String ENCRYPTED_REQUEST_EXAMPLE ="{\n \"meta-data\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
    public static final String ENCRYPTED_RESPONSE ="{\n\"meta-data\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";

    public static final String PLAIN_REQUEST_LBL_DATE = "<br><u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b><u><br>";
    public static final String PLAIN_REQUEST_MIS_LBL ="<br>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br>‘insufficientAcHolders’ mandatory in case of Renewals only.<br><br>All the 765 districts to be sent by the Banks. In case of No data, Banks to send “0” as value in API.<br><br>District code wise data for both schemes to be sent by the Bank.<br><br>In case of duplicate entries, API will fail.<br>";

    public static final String PLAIN_REQUEST_DOB_DATE = "Date Format should be <b> yyyy-MM-dd HH:mm:ss</b><u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>If Nominee is minor then Guardian details are mandtory.</b><u><br><br><u><b>disabilityStatus and disabitlityDetails are mandatory for PMSBY and not applicable for PMJJBY.</b><u><br><br><b>If disabilitystatus is Yes(Y) then disabilitydetails is mandatory and if disablitystatus is No(N) then disabilitydetails will be null.</b><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
    public static final String PLAIN_REQUEST_DATE = "Date Format should be <b> yyyy-MM-dd HH:mm:ss</b><u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u> <br><br><u><b>If Nominee is minor then Guardian details are mandtory.</b><u><br><br><u><b>disabilityStatus and disabitlityDetails are mandatory for PMSBY and not applicable for PMJJBY.</b><u><br><br><b>If disabilitystatus is Yes(Y) then disabilitydetails is mandatory and if disablitystatus is No(N) then disabilitydetails will be null.</b><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456"; 
    public static final String PLAIN_REQUEST_GUARDIAN_CLAIMAINT = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Guardian details mandatory in case Nominee is minor.</b><u><br><br><u><b>Claimant details mandatory in case Nominee is pre deceased.</b><u><br><br><u><b>Correct Nominee name is mandatory in case Nominee name correction is required</b><u><br><br><u><b>Only Date of death and Cause of Death are mandatory for PMJJBY claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims.</b><u><br>";
    public static final String PLAIN_REQUEST_DOB_GUARDIAN_CLAIMAINT = "<u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Guardian details mandatory in case Nominee is minor.</b><u><br><br><u><b>Claimant details mandatory in case Nominee is pre deceased.</b><u><br><br><u><b>Correct Nominee name is mandatory in case Nominee name correction is required</b><u><br><br><u><b>Only Date of death and Cause of Death are mandatory for PMJJBY claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims.</b><u><br>";
    
    public static final String PLAIN_REQUEST_CLAIM = """
		    <u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Remarks is mandatory for Query revert claims</b></u><br>\
		    <br><br><b> Review Example Description : documentList >>> documentId >>> Enum :</b> <br> \
		     4 - Signed and dully filled Claim cum discharge Form *, <br>\
		     5 - Death Certificate *, <br>\
		     6 - Hospital Discharge Summary *, <br>\
		     7 - Certificate issued by last attending Registered Medical Practitioner *,<br>\
		     8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *,<br>\
		     9 - FIR/Panchnama *, <br>\
		     10 - Hospital Records with deceased complete details *, <br>\
		     11 - KYC of Insured member *, <br>\
		     12 - KYC of Nominee/Claimant *, <br>\
		     13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *, <br>\
		     14 - Nominee Death Certificate *, <br>\
		     15 - Legal Heir Certificate *, <br>\
		     16 - Others *, <br>\
		     17 - Disability Certificate issued by Civil Surgeon *, <br>\
		     18 - Hospital records supporting the disability *, <br>\
		     19 - Checklist  *, <br>\
		     20 - Copy of Passbook of Insured *, <br>\
		     21 - Post mortem Report *, <br>\
		     22 - Aadhar/PAN of Nominee/Claimant *,<br>\
		     23 - Aadhar/PAN of Insured Member *</p><br>\
		    """;
    
    public static final String DOB_DATE_FORMAT_DESCRIPTION_PUSH_CLAIM="""
		    <u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br>\
		    <br> Guardian details mandatory in case Nominee is minor.\
		    <br> Claimant details mandatory in case Nominee is pre deceased.\
		    <br> Correct Nominee name is mandatory in case Nominee name correction is required\
		    <br> Only Date of death and Cause of Death are mandatory for PMJJBY claims.\
		    <br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.\
		    <br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims\
		    <br><br><p><b>documents</b> >>> <b>documentId</b> >>> <b>Enum :</b> <br>\
		    				4 - Signed and dully filled Claim cum discharge Form *, <br>\
		    				5 - Death Certificate *, <br>\
		    				6 - Hospital Discharge Summary *,
		     <br>\
		    				7 - Certificate issued by last attending Registered Medical Practitioner *,
		     <br>\
		    				8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *,
		     <br>\
		    				9 - FIR/Panchnama *,
		     <br>\
		    				10 - Hospital Records with deceased complete details *,
		     <br>\
		    				11 - KYC of Insured member *,
		     <br>\
		    				12 - KYC of Nominee/Claimant *,
		     <br>\
		    				13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *,
		     <br>\
		    				14 - Nominee Death Certificate *,
		     <br>\
		    				15 - Legal Heir Certificate *,
		     <br>\
		    				16 - Others *,
		     <br>\
		    				17 - Disability Certificate issued by Civil Surgeon *,
		     <br>\
		    				18 - Hospital records supporting the disability *,
		     <br>\
		    				19 - Checklist  *,
		     <br>\
		    				20 - Copy of Passbook of Insured *,
		     <br>\
		    				21 - Post mortem Report *,
		     <br>\
		    				22 - Aadhar/PAN of Nominee/Claimant *,
		    <br>\
		    				23 - Aadhar/PAN of Insured Member *</p><br>\
		    """;
    public static final String PUSH_ENROLLMENT_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>Disability status & Disability details mandatory only in PMSBY</u><br><br><u>For Assisted mode enrollment – user id 1 will be banker login id and user id 2 will be ‘bcreferralid’ if sent by Bank</u><br><br><u>For Other channel enrollments – user id 1 and user id 2 will be as per sent by Bank</u><br><br><u>Mode will be optional in case \"Other channel\" is sent in Source data field. Otherwise Mode will ne mandatory.</u><br><br><u>If Nominee is minor then Guardian details would be mandatory.</u>";
    public static final String DATE_FORMAT_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u>";
    public static final String DATE_FORMAT_DESCRIPTION_AND_OTHER="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Repudiated and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved claims</b><u><br>";
    public static final String DATE_FORMAT_DESCRIPTION_INSURER="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u>Reason is mandatory for Rejected and Queried claims<br><br><u>Transaction details are mandatory for Approved claims<u><br>";
    public static final String PUSH_CLIAM_STATUS_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>Remarks is mandatory for Query revert claims from bank</u>";
    public static final String DATE_FORMAT_DESCRIPTION_DATE="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b><u>";
    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
    public static final String UPDATE_TRASACTION_DESC = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><b>debitStatus</b> >>> <b>Enum :</b> <br>For Enum 1 - COI will Generate<br>For Enum 2 - The case will be moved to failed and reattempt for COI to be done<br>For Enum 3 to 8 - The reponse will have success with COI null. The case will be moved to Rejected";
//    public static final String[] IGNORE_AUDOTIR_FIELDS = { "id", "createdDate", "isActive", "modifiedDate" ,"claimMaster"};
//    public static final String[] IGNORE_AUDITOR_FIELDS_INCLUDES_NOMINEE = { "id", "createdDate", "isActive", "modifiedDate","nomineeFirstName","nomineeMiddleName","nomineeLastName","claimMaster" ,"applicationMaster"};
    public static final String INSURER_UPDATE_CLAIM_STATUS="""
    <u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Reason is mandatory for Rejected and Queried claims</u><br><br><u>Transaction details are mandatory for Approved claims</u><br><br><u>Mandatory for Insurers not using JS portal for claims; if using JS portal then the API is optional</u><br><br>\
    <p><b>reason</b> >>>  <b>Enum :</b> <br>\
      <b>Queried Claims:</b> <br>\
    				1. Complete claim documents not submitted by claimants, <br>\
    				2. Claim documents not forwarded by banks to insurer, <br>\
    				3. Deceased’s name mismatch with death certificate, <br>\
    				4. Nominee’s name differs in enrolment & claim form, <br>\
    				5. KYC proof of nominee not submitted, <br>\
    				6. NEFT account details of nominee not submitted, <br>\
    				7. Title to claim money not clear, <br>\
    				8. NEFT Rejected </p>\
     <p> <b>Rejected claims:</b> <br>\
      <b>PMJJBY scheme: </b> <br>\
    				1. Complete claim documents not submitted by claimants, <br>\
    				2. Death during lien period, <br>\
    				3. Death not established by documents submitted, <br>\
    				4. Others <br>\
      <b>PMSBY scheme: </b> <br>\
    				1. Duplicate claim, <br>\
    				2. Death due to suicide, <br>\
    				3. Death is not due to accident, <br>\
    				4. Disability not due to accident ,<br>\
    				5. Disability not permanent ,<br>\
    				6. Death / disability due to accident, not established by documents submitted ,<br>\
    				7. Others\
    """;
    
    public static final String UPDATE_NOMIEE_DESC="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>If Nominee is minor then Guardian details are mandatory.</u><br><br><u>Policy inception date will be of the current PY.</u><br><br><u>Branch code and Address in the revised COI will be of the Enrolment branch. If not available, then will show NULL.</u>";
    
    public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
//    public static final DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    public static final DateFormat sdf_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
//  public static final String ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN = "^(?!\\s)([A-Za-z0-9 /.,:@#&_=\\()'\\x22.-]+)*$";
//  public static final String ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN = "^(?!\\s)[A-Za-z0-9]([A-Za-z0-9 /.,\\x22()&-]+)*$";
//  public static final String ONLY_ALPHABETS_WITH_SPACE_ALLOWED = "^(?!\\s)(?!\\d+$)([a-zA-Z .]*)*$";
    
    public static final String COMMON_DATA_MESSAGE = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 500 - Internal Server Error
            3. 400 - Parameter Missing in Request (Bad Request)
            4. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    
    public static final String COMMON_DATA_MESSAGE_ENROLLMENT = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 208 - Already Reported(Customer is already enrolled with Scheme or Enrollment in process with other bank.)
            3. 500 - Internal Server Error
            4. 400 - Parameter Missing in Request (Bad Request)
            5. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    
    public static final String COMMON_DATA_MESSAGE_DE_DUPE = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 204 - Data(de-dupe) Not Found.
            3. 500 - Internal Server Error
            4. 400 - Parameter Missing in Request (Bad Request)
            5. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted EncryptedRequest is not correctly formed";
    public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

//    public static final String STATUS = "status";
    
    public static final String SUCCESS = "Success";

    public static final String FAILED = "Failed";
//    public static final long LONG_1 = 1L;
//    public static final long LONG_2 = 2L;
//    public static final long LONG_3 = 3L;
//    public static final long LONG_4 = 4L;
//    public static final long LONG_5 = 5L;
//    public static final long LONG_6 = 6L;
//
//    public static final int INT_1 = 1;
//    public static final int INT_2 = 2;
//    public static final int INT_3 = 3;
//    public static final int INT_4 = 4;
    public static final String PLAIN_REQUEST_LBL = "Plain Request";
    public static final String PLAIN_RESPONSE_LBL = "Plain Response";
    public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";
    public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
    public static final String REQUEST_EXAMPLES_DESC = "Request examples";
    public static final String STRING_400 = "400";
    public static final String STRING_200 = "200";
    public static final String STRING_401 = "401";

//    public static class MSG {
//        public static final String SUCCESS = "Success";
//        public static final String FAILED = "Failed";
//        public static final String USER_NOT_FOUND = "User Not Found";
//        public static final String SMTG_WNT_WNG = "Something Went Wrong.";
//        public static final String TOKEN_SAVED_SUCCESS = "Token Saved Successfully";
//        public static final String TOKEN_SAVED_FAILED = "Failed to save token";
//    }

    public static class DocumentAlias {
    	DocumentAlias(){
    	}

//        public static final Map<Long, String> SRMS_DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();

        public static final Map<Long, String> DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
        public static final Long SIGNED_CLAIM_FORM = 4l;
        public static final Long FIR_PUNCHNAMA = 5l;
        public static final Long POST_MORTEM_REPORT = 6l;
        public static final Long OTHER = 7l;

        public static final String SIGNED_CLAIM_FORM_NAME = "Signed Claim Form";
        public static final String FIR_PUNCHNAMA_NAME = "FIR / Panchnama";
        public static final String POST_MORTEM_REPORT_NAME = "Post Mortem Report";
        public static final String OTHER_NAME = "Other";
//        public static final String PDF ="pdf";
//        public static final String WORD ="word";
//        public static final String EXCEL ="excel";
//        public static final String TEXT ="text";
//        public static final String XML ="xml";


        static {

            DOCUMENT_MAP_ID_DESC_MAP.put(SIGNED_CLAIM_FORM, SIGNED_CLAIM_FORM_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(FIR_PUNCHNAMA, FIR_PUNCHNAMA_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(POST_MORTEM_REPORT, POST_MORTEM_REPORT_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(OTHER, OTHER_NAME);
        }
    }

//    public static class CostOfCourse {
//    	CostOfCourse(){
//    	}
//        public static final String TUITION_FEE = "Tuition Fee";
//        public static final String EXAM_FEE = "Exam Fee";
//        public static final String EQUIPMENT = "Equipment";
//        public static final String HOSTEL_EXPENSES = "Hostel Expenses";
//        public static final String OTHER_EXPENSES = "Other Expenses";
//    }

    public static class ErrorMsg {
    	ErrorMsg(){
    	}

        public static final String FAILED = "failed";
        public static final String SMTG_WNT_WRG = "Something went wrong";

    }

    public enum ApplicationMaster{
    	APPROVED(1,"Approved"),
    	REFERRED(2,"Referred");
    	
    	Integer id;
        String value;

        ApplicationMaster(Integer id, String value) {
            this.id = id;
            this.value = value;
        }

        public Integer getId(){
            return this.id;
        }

        public String getValue(){
            return this.value;
        }

        public static ApplicationMaster getById(Integer id) {
            try {
            	for(ApplicationMaster applicationMaster : values()) {
      	   			 if(applicationMaster.getId().equals(id)){
      	   				 return applicationMaster;
      	   			 }
      		 	}
              	return null;
            } catch (Exception e) {
                return null;
            }
        }
    }

//    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_MESSAGE = "Get the details of the list of claims registered by the banks through the portal.";
    public static final String PUSH_ENROLLMENT_DETAILS = "To push successful enrolment details to Bank/Insurer";
    public static final String ENROLLMENT_DETAILS = "To push Enrolment details of the ETB customer to JS portal via other channels of the Bank";
    public static final String UPDATE_TRANSACTION_DETAILS = "To push the successful transaction details for the premium debit from customer's A/C";
    public static final String UPDATE_STATUS = "To update the Enrolled A/C status to JS portal";
    public static final String DE_DUP_API_MESSAGE = "To check Claim De-dupe status prior to Claim approval";
    
    public static final String UPDATE_CLAIM_STATUS = "To update Insurer's claim status to JS portal";
    public static final String CLAIM_DETAILS = "To send claim registration details to JS portal by Banks Other Channel";
    public static final String CLAIM_UPLOAD_DOCUMENTS = "To send claim documents to JS portal via Banks Other Channel";
    
    public static final String PUSH_CLAIM_DETAILS = "To push successful Claim registration details and documents to Banks/Insurers";
    
    public static final  String CLAIM_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":0,\"urn\":\"JNS-XXXXX-0000-00-00000-0000\",\"claimStatus\":6,\"reason\":\"String\",\"claimId\":\"0\",\"insurerStatus\":\"String\",\"transactionUTR\":\"String\",\"dateOfTransaction\":\"2023-05-16 09:16:54\",\"amountOfTransaction\":100}";
    public static final String DATE_FORMAT_DESCRIPTION_FOR_UPDATE_STATUS="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b></u><br><br><b>Reason</b> is mandatory for Queried(7) and Repudiated(8) Claim.<br><br><b>Transaction details(transactionUTR,dateOfTransaction,amountOfTransaction)</b> are mandatory only for Approved(10) Claim.";
    public static final  String CLAIM_RESPONSE_EXAMPLE="{\"message\":\"String\",\"status\":\"200\",\"success\":\"true\"}";
    public static final String STATUS = "status";
    public static final String INVALID_CLAIM_REF_ID = "Invalid claimReferenceId";
    public static final String CLAIM_DEDUPE_API_MESSAGE = "(To check De-dupe for Claims)";
    public static final String WB_UPDATE_CLAIM_STATUS = "(Claim status update Webhook)";
    public static final  String CLAIM_PLAIN_DE_DUPE_REQUEST_EXAMPLE="{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"hospitalisationDate\":\"value\",\"firNo\":\"value\",\"firDate\":\"value\",\"panchnamaNo\":\"value\",\"panchnamaDate\":\"value\",\"postMortemReportNo\":\"value\",\"postMortemReportDate\":\"value\",\"deathCertificateReportNo\":\"value\",\"deathCertificateReportDate\":\"value\",\"documentReceivingDate\":\"value\"}";
	public static final  String CLAIM_PLAIN_DE_DUPE_SUCCESS_RESPONSE_EXAMPLE="{\"message\":\"Success\",\"success\":true,\"status\":200,\"data\":{\"dedupeCheck\":true,\"isMatchWith\":{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"intimationDate\":\"\",\"type\":1,\"claimStatus\":1,\"dateOfLoss\":\"\",\"beneficiaryName\":\"{Nominee/Guardian/Claimant Name}\",\"beneficiaryBank\":\"\"}}}";
	public static final  String DEDUPE_FAILED_PLAIN_RESPONSE_400="{\"message\":\"De-dupe failed reason\",\"status\":\"400\",\"success\":\"true\",\"flag\":false,\"claimReferenceId\":null}";
    public static final String MIS_ENROLLMENT_DETAILS = "To give mis Enrollment details";
    public static final String MIS_ENROLLMENT_API_PLAIN_REQUEST="{\"type\":\"ENROLL|RENEWAL\",\"token\":\"sdfsdfsdfsdfsdfsdf\",\"fromDate\":\"2023-05-07 00:00:00\",\"toDate\":\"2023-05-14 00:00:00\",\"districtList\":[{\"districtCode\":25,\"pmsby\":{\"elgSvngAccHldr\":100,\"elgPMJDYHldr\":200,\"ruralMale\":5646,\"ruralFemale\":5646,\"ruralTransG\":5646,\"urbanFemale\":5646,\"urbanlMale\":5646,\"urbanlTransG\":5646,\"totalEnrolment\":46564,\"prmclctdruralMale\":5646,\"prmclctdruralFemale\":5646,\"prmclctdruralTransG\":5646,\"prmclctdurbanFemale\":5646,\"prmclctdurbanlMale\":5646,\"prmclctdurbanlTransG\":5646,\"totalPrmclctdNwErollment\":46564,\"recordsTransmittedToInsurer\":546,\"premiumPaidToInsurer\":5654,\"aadharSeeded\":46564,\"mobileSeeded\":46564,\"emailSeeded\":46564,\"pmjdyEnrolled\":46564,\"mgnregaEnrolled\":46564,\"mudraEnrolled\":46564,\"kccEnrolled\":46564,\"otherSchemeEnrolled\":46564,\"insufficientAcHolders\":500,\"caste\":{\"sc\":0,\"st\":41654,\"general\":655654,\"obc\":564646},\"nomineeAvlb\":54654},\"pmjjby\":{\"elgSvngAccHldr\":100,\"elgPMJDYHldr\":200,\"ruralMale\":5646,\"ruralFemale\":5646,\"ruralTransG\":5646,\"urbanFemale\":5646,\"urbanlMale\":5646,\"urbanlTransG\":5646,\"totalEnrolment\":46564,\"prmclctdruralMale\":5646,\"prmclctdruralFemale\":5646,\"prmclctdruralTransG\":5646,\"prmclctdurbanFemale\":5646,\"prmclctdurbanlMale\":5646,\"prmclctdurbanlTransG\":5646,\"totalPrmclctdNwErollment\":46564,\"recordsTransmittedToInsurer\":546,\"premiumPaidToInsurer\":5654,\"aadharSeeded\":46564,\"mobileSeeded\":46564,\"emailSeeded\":46564,\"pmjdyEnrolled\":46564,\"mgnregaEnrolled\":46564,\"mudraEnrolled\":46564,\"kccEnrolled\":46564,\"otherSchemeEnrolled\":46564,\"insufficientAcHolders\":500,\"caste\":{\"sc\":0,\"st\":41654,\"general\":655654,\"obc\":564646},\"nomineeAvlb\":54654}}]}";

public static final String QUERY_ALREADY_SUBMIT = "Please wait until the previous query has resolved before submitting a new one.";
public static final String EXIT_FROM_UPDATE_CLAIM_STATUS = "... .Exit from updateClaimStatus(). ...";
public static final String STATUS_UPDATE = "Status updated successfully.";
public static final String NOMINEE_UPDATE_DETAILS= "Published by JS portal. To be added in the Other channel Swagger";

}
