package com.opl.jns.registry.api.utils.v2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class Constants {

    public static final  String DE_DUP_PLAIN_REQUEST_EXAMPLE="{\"kycId1\":\"PAN\",\"kycIdValue1\":\"AAGFV5271N\",\"kycId2\":\"DRIVINGL\",\"kycIdValue2\":\"string\",\"ckycNumber\":\"54853079374\",\"gender\":\"M\",\"firstName\":\"rock\",\"middleName\":\"rajeshbhai\",\"lastName\":\"patel\",\"fatherHusbandName\":\"Rajeshbhai\",\"mob\":\"8777895478\",\"pincode\":382443,\"dob\":\"13/06/2000\",\"bankCode\":\"BOB\",\"accNo\":\"548545657854\",\"scheme\":\"PMJJBY\",\"accountStatus\":\"string\",\"type\":\"string\",\"cif\":\"stringstri\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\"}";
    public static final  String DE_DUP_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":0,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\",\"data\":{\"isMatched\":\"string\",\"matchWith\":\"string\",\"bankName\":\"string\"}}";
  public static final  String ENROLLMENT_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"customerDetails\":{\"dob\":\"13/06/2000\",\"gender\":\"M\",\"accountHolderName\":\"Rajeshbhai\",\"firstName\":\"Rajesh\",\"middleName\":\"Rajubhai\",\"lastName\":\"Patel\",\"fatherHusbandName\":\"RRameshBhai\",\"mobileNumber\":\"7567794689\",\"emailId\":\"xyz@gmail.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"pincode\":382443,\"city\":\"Ahmedabad\",\"cityLGDCode\":0,\"district\":\"string\",\"districtLGDCode\":0,\"state\":\"Gujarat\",\"stateLGDCode\":0,\"accountNumber\":\"565888744\",\"cif\":\"stringstri\",\"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringstri\"},\"kycDetails\":{\"kycId1\":\"PAN\",\"kycIdValue1\":\"AAGFV5271N\",\"kycId2\":\"DRIVINGL\",\"kycIdValue2\":\"string\",\"panNumber\":\"AAGFV5271N\",\"aadhaarNumber\":\"548537793745\",\"ckyc\":\"Y\",\"ckycNumber\":\"548537793745\"},\"guardianDetails\":{\"relationShip\":\"Father\",\"firstName\":\"Rock\",\"middleName\":\"M\",\"lastName\":\"Panchal\",\"address\":\"Isanpur\",\"pincode\":\"385658\",\"mobile\":\"7568898968\",\"email\":\"xyz@mail.com\",\"state\":\"Gujarat\",\"city\":\"Ahemedabad\",\"district\":\"string\"},\"nomineeDetails\":{\"relationShip\":\"Father\",\"firstName\":\"Rajesh\",\"middleName\":\"N\",\"lastName\":\"Panchal\",\"dob\":\"13/06/2000\",\"mobile\":\"8787854563\",\"email\":\"abc@gmail.com\",\"addressLine1\":\"Isanpur,ahemedabad\",\"addressLine2\":\"nikol,ahemedabad\",\"pincode\":\"358446\",\"city\":\"Ahemedabad\",\"cityLGDCode\":0,\"district\":\"string\",\"districtLGDCode\":0,\"state\":\"Gujarat\",\"stateLGDCode\":0},\"insurerDetails\":[{\"year\":\"2020\",\"code\":\"454545\",\"masterPolicyNumber\":\"54545454\"}],\"policyDetails\":{\"transactionUTR\":\"string\",\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"masterPolicyNumber\":\"string\",\"insurerCode\":\"string\",\"dateOfEnrollment\":\"2023-05-05 16:12:10\"},\"otherDetails\":{\"scheme\":\"PMJJBY\",\"bankCode\":\"string\",\"branchCode\":\"string\",\"branchIFSC\":\"string\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"string\",\"userId2\":\"string\",\"channelId\":\"string\",\"ruralUrban\":\"string\"}}";
    public  static final String ENROLLMENT_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":0,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\",\"data\":{\"deDupeStatus\":true,\"deDupeMsg\":\"string\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\"}}";

    public static final  String UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"masterPolicyNumber\":\"string\",\"insurerCode\":\"44444\",\"transactionUTR\":\"string\",\"transactionType\":\"string\",\"insurerIFSC\":\"string\",\"insurerAccountNumber\":\"string\"}";
    public static final  String UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-23 07:01:00\",\"token\":\"ae75100d-57d4-436b-9c57-06f25be04f3f\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}}";

    public static final  String UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"status\":7,\"reason\":\"string\"}";
    public static final  String UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\"}";

    public static final  String UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":\"JNS-XXXXX-0000-00-00000-0000\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":10,\"insurerStatus\":\"String\",\"reason\":\"String\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"}}";
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true}";

    public static final  String CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":123,\"remarks\":\"\",\"documentList\":[{\"documentType\":\"string\",\"documentId\":\"0\",\"contentType\":\"string\",\"document\":[\"string\"]}]}";
    public static final  String CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"success\",\"data\":{},\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"status\":200,\"success\":true}";

    public static final  String CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"nomineeNameCorrection\":\"YES\",\"correctNomineeFirstName\":\"string\",\"correctnomineeMiddleName\":\"string\",\"correctnomineeLastName\":\"string\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"guardianMobileNumber\":\"7598898956\",\"guardianEmailId\":\"rajesh@opl.com\",\"isNomineePredeceased\":\"YES\",\"claimantFirstName\":\"string\",\"claimantMiddleName\":\"string\",\"claimantLastName\":\"string\",\"claimantDateOfBirth\":\"2012-02-22\",\"relationOfClaimant\":\"string\",\"claimantMobileNumber\":\"string\",\"claimantEmailId\":\"xyz@gmail.com.com\",\"claimantKYC1\":\"string\",\"claimantKYCNumber1\":\"string\",\"claimantKYC2\":\"string\",\"claimantKycNumber2\":\"string\",\"claimantAddressLine1\":\"Isanpur\",\"claimantAddressLine2\":\"Isanpur\",\"claimantCity\":\"Isanpur\",\"claimantDistrict\":\"Isanpur\",\"claimantState\":\"Isanpur\",\"claimantPincode\":385444,\"dateOfAccident\":\"2012-02-22\",\"timeOfAccident\":\"16:12:10\",\"dayOfAccident\":\"Sunday\",\"placeOfAccident\":\"string\",\"natureOfAccident\":\"string\",\"dateOfDeath\":\"2023-05-16 09:16:54\",\"causeOfDeath\":\"string\",\"causeOfDeathDisability\":\"string\",\"typeOfDisability\":\"string\",\"claimantBankAccount\":\"string\",\"claimantBank\":\"string\",\"claimantIFSC\":\"string\"}";
    public static final  String CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"success\",\"status\":200,\"data\":{\"claimReferenceId\":123},\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"success\":true}";
    
    public static final  String CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED="{\"message\":\"De-dupe failed reason\",\"status\":\"400\",\"success\":\"true\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"asdasdasdsadsad\"}";
    

//    public static final  String PLAIN_RESPONSE_401="{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false}";

    public static final  String ENCRYPTED_REQUEST_EXAMPLE ="{\n \"meta-data\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
    public static final String ENCRYPTED_RESPONSE ="{\n\"meta-data\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";

    public static final String PLAIN_REQUEST_LBL_DATE = "<br><u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b><u><br>";

    public static final String PLAIN_REQUEST_DOB_DATE = "DOB Date Format Should be <u><b>dd/MM/yyyy</b><u><br><br><u>Date Format should be <b> yyyy-MM-dd HH:mm:ss</b><u><br><br><u><b>If Nominee is minor then Guardian details are mandtory.</b><u><br><br><u><b>disabilityStatus and disabitlityDetails are mandatory for PMSBY and not applicable for PMJJBY.</b><u><br><br><b>If disabilitystatus is Yes(Y) then disabilitydetails is mandatory and if disablitystatus is No(N) then disabilitydetails will be null.</b><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
    
    public static final String PLAIN_REQUEST_GUARDIAN_CLAIMAINT = "<br><u><b>Guardian details mandatory in case Nominee is minor.</b><u><br><br><u><b>Claimant details mandatory in case Nominee is pre deceased.</b><u><br><br><u><b>Correct Nominee First name is mandatory in case Nominee name correction is required</b><u><br><br><u><b>Only Date of death and Cause of Death are mandatory for PMJJBY claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims.</b><u><br>";
    
    public static final String PLAIN_REQUEST_CLAIM = "<br><u><b>Remarks is mandatory for Query revert claims</b><u><br>";

    public static final String DATE_FORMAT_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b>";
    public static final String DATE_FORMAT_DESCRIPTION_AND_OTHER="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Repudiated and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved claims</b><u><br>";
    public static final String DATE_FORMAT_DESCRIPTION_DATE="<u>Date Format should be <b>dd/MM/yyyy<b><u>";
    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
//    public static final String[] IGNORE_AUDOTIR_FIELDS = { "id", "createdDate", "isActive", "modifiedDate" ,"claimMaster"};
//    public static final String[] IGNORE_AUDITOR_FIELDS_INCLUDES_NOMINEE = { "id", "createdDate", "isActive", "modifiedDate","nomineeFirstName","nomineeMiddleName","nomineeLastName","claimMaster" ,"applicationMaster"};

    public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
    public static final DateFormat sdf_yyyy_MM_dd=new SimpleDateFormat("yyyy-MM-dd");
    public static final DateFormat sdf_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
//  public static final String ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN = "^(?!\\s)([A-Za-z0-9 /.,:@#&_=\\()'\\x22.-]+)*$";
//  public static final String ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN = "^(?!\\s)[A-Za-z0-9]([A-Za-z0-9 /.,\\x22()&-]+)*$";
//  public static final String ONLY_ALPHABETS_WITH_SPACE_ALLOWED = "^(?!\\s)(?!\\d+$)([a-zA-Z .]*)*$";
    
    public static final String COMMON_DATA_MESSAGE = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 500 - Internal Server Error
            3. 400 - Parameter Missing in Request (Bad Request)
            4. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    
    public static final String COMMON_DATA_MESSAGE_ENROLLMENT = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 208 - Already Reported(Customer is already enrolled with Scheme or Enrollment in process with other bank.)
            3. 500 - Internal Server Error
            4. 400 - Parameter Missing in Request (Bad Request)
            5. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    
    public static final String COMMON_DATA_MESSAGE_DE_DUPE = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 204 - Data(de-dupe) Not Found.
            3. 500 - Internal Server Error
            4. 400 - Parameter Missing in Request (Bad Request)
            5. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted EncryptedRequest is not correctly formed";
    public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";
    
    public static final String UPDATE_INSURANCE_STATUS_MESSAGE = """
            Update Application\
             Status by the banks through the portal.\
            """;

//    public static final String STATUS = "status";
    
    public static final String SUCCESS = "Success";

    public static final String FAILED = "Failed";
//    public static final long LONG_1 = 1L;
//    public static final long LONG_2 = 2L;
//    public static final long LONG_3 = 3L;
//    public static final long LONG_4 = 4L;
//    public static final long LONG_5 = 5L;
//    public static final long LONG_6 = 6L;
//
//    public static final int INT_1 = 1;
//    public static final int INT_2 = 2;
//    public static final int INT_3 = 3;
//    public static final int INT_4 = 4;
    public static final String PLAIN_REQUEST_LBL = "Plain Request";
    public static final String PLAIN_RESPONSE_LBL = "Plain Response";
    public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";
    public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
    public static final String REQUEST_EXAMPLES_DESC = "Request examples";
    public static final String STRING_400 = "400";
    public static final String STRING_200 = "200";
    public static final String STRING_401 = "401";

//    public static class MSG {
//        public static final String SUCCESS = "Success";
//        public static final String FAILED = "Failed";
//        public static final String USER_NOT_FOUND = "User Not Found";
//        public static final String SMTG_WNT_WNG = "Something Went Wrong.";
//        public static final String TOKEN_SAVED_SUCCESS = "Token Saved Successfully";
//        public static final String TOKEN_SAVED_FAILED = "Failed to save token";
//    }

    public static class DocumentAlias {
    	DocumentAlias(){
    	}

//        public static final Map<Long, String> SRMS_DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();

        public static final Map<Long, String> DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
        public static final Long SIGNED_CLAIM_FORM = 4l;
        public static final Long FIR_PUNCHNAMA = 5l;
        public static final Long POST_MORTEM_REPORT = 6l;
        public static final Long OTHER = 7l;

        public static final String SIGNED_CLAIM_FORM_NAME = "Signed Claim Form";
        public static final String FIR_PUNCHNAMA_NAME = "FIR / Panchnama";
        public static final String POST_MORTEM_REPORT_NAME = "Post Mortem Report";
        public static final String OTHER_NAME = "Other";
//        public static final String PDF ="pdf";
//        public static final String WORD ="word";
//        public static final String EXCEL ="excel";
//        public static final String TEXT ="text";
//        public static final String XML ="xml";


        static {

            DOCUMENT_MAP_ID_DESC_MAP.put(SIGNED_CLAIM_FORM, SIGNED_CLAIM_FORM_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(FIR_PUNCHNAMA, FIR_PUNCHNAMA_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(POST_MORTEM_REPORT, POST_MORTEM_REPORT_NAME);
            DOCUMENT_MAP_ID_DESC_MAP.put(OTHER, OTHER_NAME);
        }
    }

//    public static class CostOfCourse {
//    	CostOfCourse(){
//    	}
//        public static final String TUITION_FEE = "Tuition Fee";
//        public static final String EXAM_FEE = "Exam Fee";
//        public static final String EQUIPMENT = "Equipment";
//        public static final String HOSTEL_EXPENSES = "Hostel Expenses";
//        public static final String OTHER_EXPENSES = "Other Expenses";
//    }

    public static class ErrorMsg {
    	ErrorMsg(){
    	}

        public static final String FAILED = "failed";
        public static final String SMTG_WNT_WRG = "Something went wrong";

    }

    public enum ApplicationMaster{
    	APPROVED(1,"Approved"),
    	REFERRED(2,"Referred");
    	
    	Integer id;
        String value;

        ApplicationMaster(Integer id, String value) {
            this.id = id;
            this.value = value;
        }

        public Integer getId(){
            return this.id;
        }

        public String getValue(){
            return this.value;
        }

        public static ApplicationMaster getById(Integer id) {
            try {
            	for(ApplicationMaster applicationMaster : values()) {
      	   			 if(applicationMaster.getId().equals(id)){
      	   				 return applicationMaster;
      	   			 }
      		 	}
              	return null;
            } catch (Exception e) {
                return null;
            }
        }
    }

//    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_MESSAGE = "Get the details of the list of claims registered by the banks through the portal.";
    public static final String PUSH_ENROLLMENT_DETAILS = "Push Enrollment details.";
    public static final String UPDATE_TRANSACTION_DETAILS = "Update Transaction Details.";
    public static final String UPDATE_STATUS = "Update Status";
    public static final String DE_DUP_API_MESSAGE = "To check de-dupe validation for enrollment, claim and renewal";
    
    public static final String UPDATE_CLAIM_STATUS = "To update claim status";
    public static final String CLAIM_DETAILS = "To check claim Details";
    public static final String CLAIM_UPLOAD_DOCUMENTS = "To check claim upload documents";
    
    public static final  String CLAIM_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":0,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":6,\"reason\":\"String\",\"claimId\":\"0\",\"insurerStatus\":\"String\",\"transactionUTR\":\"String\",\"dateOfTransaction\":\"2023-05-16 09:16:54\",\"amountOfTransaction\":100}";
    public static final String DATE_FORMAT_DESCRIPTION_FOR_UPDATE_STATUS="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b></u><br><br><b>Reason</b> is mandatory for Queried(7) and Repudiated(8) Claim.<br><br><b>Transaction details(transactionUTR,dateOfTransaction,amountOfTransaction)</b> are mandatory only for Approved(10) Claim.";
    public static final  String CLAIM_RESPONSE_EXAMPLE="{\"message\":\"String\",\"status\":\"200\",\"success\":\"true\"}";
    public static final String STATUS = "status";
    public static final String INVALID_CLAIM_REF_ID = "Invalid claimReferenceId";
    public static final String CLAIM_DEDUPE_API_MESSAGE = "(To check De-dupe for Claims)";
    public static final String WB_UPDATE_CLAIM_STATUS = "(Claim status update Webhook)";
    public static final  String CLAIM_PLAIN_DE_DUPE_REQUEST_EXAMPLE="{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"hospitalisationDate\":\"value\",\"firNo\":\"value\",\"firDate\":\"value\",\"panchnamaNo\":\"value\",\"panchnamaDate\":\"value\",\"postMortemReportNo\":\"value\",\"postMortemReportDate\":\"value\",\"deathCertificateReportNo\":\"value\",\"deathCertificateReportDate\":\"value\",\"documentReceivingDate\":\"value\"}";
	public static final  String CLAIM_PLAIN_DE_DUPE_SUCCESS_RESPONSE_EXAMPLE="{\"message\":\"Success\",\"success\":true,\"status\":200,\"data\":{\"dedupeCheck\":true,\"isMatchWith\":{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"intimationDate\":\"\",\"type\":1,\"claimStatus\":1,\"dateOfLoss\":\"\",\"beneficiaryName\":\"{Nominee/Guardian/Claimant Name}\",\"beneficiaryBank\":\"\"}}}";
	public static final  String DEDUPE_FAILED_PLAIN_RESPONSE_400="{\"message\":\"De-dupe failed reason\",\"status\":\"400\",\"success\":\"true\",\"flag\":false,\"claimReferenceId\":null}";
}
