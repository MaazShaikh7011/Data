package com.opl.jns.registry.api.error;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.api.proxy.common.APIResponseV3;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Response400 extends APIResponseV3 implements Serializable {

	private static final long serialVersionUID = 1L;


	@JsonProperty("success")
	@Schema(allowableValues = {"True", "False"})
	private Boolean success;

	@JsonProperty("message")
	@Size(min = 0,max = 255)
	private String message;

	@Schema(example = "200")
	@JsonProperty("status")
	private Integer status;

	@NotNull
	@JsonProperty("token")
	@Size(min = 0, max = 100)
	private String token;

	@NotNull
	@ApiModelProperty(notes = "timeStamp",example = "yyyy-MM-dd HH:mm:ss",required = true)
	private LocalDateTime timeStamp;


	@Hidden
	public static final String PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"status\":400,\"success\":false}";

	// for webhook
	@Hidden
	public static final String WB_PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"status\":400,\"success\":false}";

}
