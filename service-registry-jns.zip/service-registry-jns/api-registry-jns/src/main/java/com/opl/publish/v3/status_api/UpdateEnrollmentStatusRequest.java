package com.opl.publish.v3.status_api;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateEnrollmentStatusRequest implements Serializable {

	@NotNull
	@Size(min = 31, max = 32)
	public String urn;

	@NotNull
	@Schema(allowableValues = { "6", "7", "8","9" }, 
	description = "6:Opt-Out,7:Account Inactive,8:Insufficient Balance,9:Account Holder Deceased")
	public Integer accountStatus;
	
	@Size(min = 0, max = 255)
	public String reason;
	
	@NotNull
	public String token;
	
	private final static long serialVersionUID = 1175522787349167251L;

}
