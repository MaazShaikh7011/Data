package com.opl.jns.registry.api.publish.common.enroll;

import com.opl.jns.api.proxy.jansuraksha.common.RegCommonResponse;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentDataResProxyV2;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EnrollBeforeResProxy extends RegCommonResponse {

	private static final long serialVersionUID = 3934780058843192301L;

	private boolean proceed;

	private Long userId;

	private Long branchId;
	private Long branchRoId;
	private Long branchZoId;
	private Long branchStateId;
	private Long branchCityId;
	private Integer ruralUrbanId;

	private Long insurerOrgId;

	private EnrollmentDataResProxyV2 dataResProxyV2;

	public EnrollBeforeResProxy(String message, Integer status, boolean proceed) {
		super(message, status);
		this.proceed = proceed;
	}

	public EnrollBeforeResProxy(String message, Integer status, boolean proceed,
			EnrollmentDataResProxyV2 dataResProxyV2) {
		super(message, status);
		this.proceed = proceed;
		this.dataResProxyV2 = dataResProxyV2;
	}

}
