package com.opl.jns.registry.client;

import com.opl.jns.published.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;


public class RegistryClient {

    private static Logger logger = LoggerFactory.getLogger(RegistryClient.class);

    private String baseUrlStr;
    private static final String IS_DECRYPT = "isDecrypt";
    private static final String PUSHPULL = "/jns/internal/pushData";

    private RestTemplate restTemplate;

    public RegistryClient(String baseUrl) {
        this.baseUrlStr = baseUrl;
        restTemplate = new RestTemplate();
    }

    public static void setClient(HttpHeaders headers) {
        headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.set(IS_DECRYPT, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.add("Accept", "application/json");
    }

}
