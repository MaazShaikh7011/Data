package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.MisDataDocDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MisDataDocDetailsRepo extends JpaRepository<MisDataDocDetails, Long> {
}
