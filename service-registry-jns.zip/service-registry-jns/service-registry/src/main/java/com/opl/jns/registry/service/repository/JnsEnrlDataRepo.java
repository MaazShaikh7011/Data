package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.JnsEnrlData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface JnsEnrlDataRepo extends JpaRepository<JnsEnrlData, Long> {

    List<JnsEnrlData> findAllByVersionAndType(Long version, Integer type);

    List<JnsEnrlData> findAllByVersionAndTypeAndOrgIdAndSchemeId(Long version, Integer type, Long orgId, Integer schemeId);

    @Query("SELECT new com.opl.jns.registry.service.domain.JnsEnrlData(PM.orgId, PM.branchStateId, PM.branchCityId, COUNT(PM.id), SUM(PM.premiumAmount), " +
            " SUM(CASE WHEN APS.bankPush = true AND APS.insurerPush = true THEN 1 ELSE 0 END), " +
            " SUM(CASE WHEN APS.bankPush = true AND APS.insurerPush = true THEN PM.premiumAmount ELSE 0 END)) " +
            " FROM PMSBY PM " +
            " INNER JOIN ApplicationPushStatus APS ON PM.id = APS.id " +
            " WHERE PM.status = 2 AND PM.orgId = :orgId AND PM.enrollmentDate>=TO_DATE(:fromDate,'DD-MM-YYYY') AND PM.enrollmentDate<=TO_DATE(:toDate,'DD-MM-YYYY') " +
            " GROUP BY PM.branchStateId, PM.branchCityId, PM.orgId ")
    List<JnsEnrlData> getJNSPMSBYCounts(@Param("orgId") Long orgId, @Param("fromDate") String fromDate, @Param("toDate") String toDate);

    @Query("SELECT new com.opl.jns.registry.service.domain.JnsEnrlData(PM.orgId, PM.branchStateId, PM.branchCityId, COUNT(PM.id), SUM(PM.premiumAmount), " +
            " SUM(CASE WHEN APS.bankPush = true AND APS.insurerPush = true THEN 1 ELSE 0 END), " +
            " SUM(CASE WHEN APS.bankPush = true AND APS.insurerPush = true THEN PM.premiumAmount ELSE 0 END)) " +
            " FROM PMJJBY PM " +
            " INNER JOIN ApplicationPushStatus APS ON PM.id = APS.id " +
            " WHERE PM.status = 2 AND PM.orgId = :orgId AND PM.enrollmentDate>=TO_DATE(:fromDate,'DD-MM-YYYY') AND PM.enrollmentDate<=TO_DATE(:toDate,'DD-MM-YYYY') " +
            " GROUP BY PM.branchStateId, PM.branchCityId, PM.orgId ")
    List<JnsEnrlData> getJNSPMJJBYCounts(@Param("orgId") Long orgId, @Param("fromDate") String fromDate, @Param("toDate") String toDate);

    @Query("SELECT UOM.orgId FROM UserOrganizationMaster UOM WHERE UOM.userTypeId = 2 AND UOM.orgId <> 0 ")
    Set<Long> getOrgIdList();
}
