package com.opl.jns.registry.service.service.publish.v2;

import com.opl.jns.ere.domain.ApplicationMasterV3;

/**
 * @author sandip.bhetariya
 *
 */
public interface CommitTransactionalServiceV2 {

	ApplicationMasterV3 applicationMasterSave(ApplicationMasterV3 applicationMaster) throws Exception;
	
}
