package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.WeekMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface WeekMasterRepository extends JpaRepository<WeekMaster, Long> {

    WeekMaster findFirstByStatus(Integer status);
    WeekMaster findFirstByOrderByIdDesc();

    @Transactional
    @Modifying
    @Query("UPDATE WeekMaster SET status = " + WeekMaster.StatusEnum.IN_PROGRESS + " WHERE id=:id")
    void updateStuts(Long id);
}
