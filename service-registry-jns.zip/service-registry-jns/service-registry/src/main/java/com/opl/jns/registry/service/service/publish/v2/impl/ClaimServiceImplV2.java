package com.opl.jns.registry.service.service.publish.v2.impl;
//package com.opl.service.registry.jns.service.publish.v2.impl;
//
//import java.io.IOException;
//import java.text.SimpleDateFormat;
//import java.util.Objects;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//import com.opl.jns.ere.domain.ApplicationMasterV3;
//import com.opl.jns.ere.domain.ClaimMasterV3;
//import com.opl.jns.ere.domain.NomineeDetails;
//import com.opl.jns.ere.enums.NomineeType;
//import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
//import com.opl.jns.ere.repo.ClaimMasterRepoV3;
//import com.opl.jns.published.utils.common.DateUtils;
//import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
//import com.opl.jns.published.utils.common.OPLUtils;
//import com.opl.jns.published.utils.common.RegCommonResponse;
//import com.opl.jns.published.utils.common.RegistryResponse;
//import com.opl.jns.utils.enums.ClaimStageMaster;
//import com.opl.publish.common.RegistryReqProxy;
//import com.opl.publish.v2.claimDetails.ClaimDetailDataProxyV2;
//import com.opl.publish.v2.claimDetails.ClaimDetailsReqProxyV2;
//import com.opl.publish.v2.claimDetails.ClaimDetailsResProxyV2;
//import com.opl.publish.v2.claimUpload.ClaimUploadDocsReqProxyV2;
//import com.opl.publish.v3.claimDedup.ClaimDeDupReqProxyV3;
//import com.opl.publish.v3.claimStatusInsurer.ClaimStatusUpdateReqProxyV3;
//import com.opl.service.registry.jns.service.publish.common.ClaimService;
//import com.opl.service.registry.jns.service.publish.common.impl.ClaimAbstract;
//import com.opl.service.registry.jns.utils.GetterSetter;
//import com.opl.service.registry.jns.utils.v2.ClaimValidation;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Service
//@Slf4j
//@Qualifier("ClaimServiceImplV2")
//public class ClaimServiceImplV2 extends ClaimAbstract implements ClaimService {
//
//	/** Claim */
//	@Autowired
//	private ClaimMasterRepoV3 claimMasterRepo;
//
//	@Autowired
//	private ApplicationMasterRepositoryV3 applicationMasterRepository;
//
//	@Autowired
//	private ClaimValidation claimValidation;
//	
//	@Autowired
//	private GetterSetter getterSetter;
//
//	@SuppressWarnings("unchecked")
//	@Transactional
//	public <T extends RegistryReqProxy, U extends RegCommonResponse> U saveClaimApi(T in, Long orgId) throws Exception {
//		ClaimDetailsReqProxyV2 claimRequest = (ClaimDetailsReqProxyV2) in;
//		ClaimDetailsResProxyV2 commonResponse = claimValidation.checkClaimDetailsValidationsV2(claimRequest);
//		if (Boolean.FALSE.equals(commonResponse.getSuccess())) {
//			log.warn("enrollmentDetails from request-> {} ",
//					MultipleJSONObjectHelper.getStringfromObject(claimRequest));
//			return (U) commonResponse;
//		}
//		ClaimDetailsResProxyV2 resp = new ClaimDetailsResProxyV2();
//
//		ApplicationMasterV3 applicationMaster = applicationMasterRepository
//				.findFirstByUrnAndIsActiveTrue(claimRequest.getUrn().trim());
//		if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
//			log.info("There is no enrollment for URN: " + claimRequest.getUrn().trim());
//			return (U) new ClaimDetailsResProxyV2("There is no enrollment for URN.", null, HttpStatus.BAD_REQUEST.value());
//		} else if (!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !applicationMaster.getOrgId().equals(orgId)) {
//			log.info("In your organization, enrollment doesn't exist.: " + claimRequest.getUrn().trim());
//			return (U) new ClaimDetailsResProxyV2("In your organization, enrollment doesn't exist.", null,
//					HttpStatus.BAD_REQUEST.value());
//		}
//
//		ClaimMasterV3 claimMaster = claimMasterRepo
//				.findFirstByApplicationMasterUrnAndApplicationMasterIsActiveTrueAndIsActiveTrueOrderByIdDesc(claimRequest.getUrn());
//		if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//			if (claimMaster.getClaimStageId() != ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
//				resp.setMessage("Claim has already been initiated for the selected A/C holder ");
//			} else {
//				resp.setMessage("Claim has already been completed for the selected A/C holder ");
//			}
//			resp.setStatus(HttpStatus.OK.value());
//			resp.setData(new ClaimDetailDataProxyV2(claimMaster.getId()));
//			resp.setSuccess(Boolean.TRUE);
//			return (U) resp;
//		}
//
//		StringBuilder s1 = new StringBuilder();
//		// claimant kyc id 1 and 2 validation
//		ClaimValidation.kycIdValidation(claimRequest.getClaimantKYC1(), claimRequest.getClaimantKYCNumber1(), s1,
//				"KYC ID1");
//		ClaimValidation.kycIdValidation(claimRequest.getClaimantKYC2(), claimRequest.getClaimantKycNumber2(), s1,
//				"KYC ID2");
//		// Scheme wise field validations
//		ClaimValidation.checkMandatoryFieldsOfBothSchemeCommon(claimRequest, applicationMaster.getSchemeId(), s1);
//		
//		ClaimValidation.checkMandatoryFieldsOfBothSchemeV2(claimRequest, applicationMaster.getSchemeId(),
//				applicationMaster.getEnrollmentDate(), s1);
//
//		// Guardian Validations
//		NomineeDetails existingNominee = null;
//
//		if (!OPLUtils.isObjectNullOrEmpty(applicationMaster)
//				&& !OPLUtils.isObjectListNull(applicationMaster.getNomineeDetails())) {
//			existingNominee = applicationMaster.getNomineeDetails().stream()
//					.filter(x -> Objects.equals(x.getType(), NomineeType.NOMINEE.getId())).findAny().orElse(null);
//			if (!OPLUtils.isObjectNullOrEmpty(existingNominee)) {
//				String dob = new SimpleDateFormat(DateUtils.DateFormat.YYYY_MM_DD).format(existingNominee.getDob());
//				Integer ageFromBirthDate = DateUtils
//						.getAgeFromBirthDate(new SimpleDateFormat(DateUtils.DateFormat.YYYY_MM_DD).parse(dob));
//				if (ageFromBirthDate < 18) {
//					log.warn("age is less then 18 so guardian details is mandatory   AGE -> ({}),  YEAR -> ({})",
//							existingNominee.getDob(), ageFromBirthDate);
//					if (OPLUtils.isObjectNullOrEmpty(claimRequest.getGuardianMobileNumber())) {
//						log.warn("guardianMobileNumber can not be null or empty.");
//						s1.append("guardianMobileNumber can not be null or empty.");
//					}
//				}
//			}
//		}
//
//		if (!OPLUtils.isObjectNullOrEmpty(s1.toString())) {
//			commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
//			commonResponse.setSuccess(OPLUtils.isObjectNullOrEmpty(s1.toString()));
//			commonResponse.setMessage(s1.toString());
//			return (U) commonResponse;
//		}
//
//		// for second and third time claim
//		if (null != claimMaster) {
//			resp = this.deDupeLogic(claimMaster);
//			if (Boolean.FALSE.equals(resp.getSuccess())) {
//				return (U) resp;
//			}
//		}
//
//		// set nominee details
//		claimMaster = getterSetter.setClaimNomineeDetails(existingNominee, claimRequest,claimMaster,applicationMaster,orgId);
//		claimMaster = getterSetter.setClaimDetails(existingNominee, claimRequest, claimMaster, applicationMaster);
//
//		resp.setSuccess(Boolean.TRUE);
//		resp.setMessage("Success");
//		resp.setData(new ClaimDetailDataProxyV2(claimMaster.getId()));
//		resp.setStatus(HttpStatus.OK.value());
//		return (U) resp;
//	}
//
//	@SuppressWarnings("unchecked")
//	@Override
//	public <T extends RegistryReqProxy, U extends RegCommonResponse> U getClaimdetailsByClaimUploadDocuments(T in)
//			throws IOException {
//		ClaimUploadDocsReqProxyV2 claimUploadDocuments = (ClaimUploadDocsReqProxyV2) in;
//		try {
//			return this.documentUploadAndManageProcess(claimUploadDocuments.getDocumentList(),claimUploadDocuments.getClaimReferenceId());
//		} catch (Exception e) {
//			log.error("Exception is getting while getClaimdetailsByClaimUploadDocuments call ", e);
//			return (U) new RegistryResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
//					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//	}
//	
//	@Override
//	public boolean updateClaimStatusInsurerByJsForScheduler(Long claimId) {
//		try {
//			/** re-push the docs only */
//			this.rePushDocs(claimId);
//			return true;
//		} catch (Exception e) {
//			log.error("Exception is getting while updateClaimStatusInsurerByJsForScheduler call ", e);
//			return false;
//		}
//	}
//
//	@Override
//	public RegistryResponse getClaimDedupeData(ClaimDeDupReqProxyV3 dedupeRequest) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public RegistryResponse updateClaimStatus(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, StringBuilder message,
//			HttpServletRequest httpServletRequest) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
////	private RegistryResponse getClaimDetailsByClaimUploadDocumentsBKP(ClaimUploadDocsReqProxyV2 claimUploadDocuments)
////			throws IOException {
////		DocumentResponse docResponse = null;
////		try {
////			ClaimMasterV3 claimMaster = claimMasterRepo
////					.findByIdAndIsActiveTrue(claimUploadDocuments.getClaimReferenceId());
////			// here claimReferenceId is claimId from claim master - ere
////			if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
////				log.error("ClaimMaster data not found");
////				return new RegistryResponse("ClaimMaster data not found", HttpStatus.NOT_FOUND.value(), Boolean.FALSE);
////			}
////
////			DocumentRequest documentRequest = new DocumentRequest();
////			documentRequest.setApplicationId(claimMaster.getApplicationMaster().getId());
////			documentRequest.setSchemeId(claimMaster.getApplicationMaster().getSchemeId());
////			documentRequest.setClaimId(claimMaster.getId());
////
////			if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMJJBY.getId().intValue())
////				documentRequest.setDisabilityTypeId(
////						OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) ? null
////								: claimMaster.getClaimDetail().getCauseOfDeathDisabilityId());
////			else {
////				documentRequest.setDisabilityTypeId(
////						OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) ? null
////								: claimMaster.getClaimDetail().getNatureOfLossId());
////			}
////
////			DocumentResponse documentResponse = dmsClient.findTypeIdByDisabilityTypeIdAndSchemeId(documentRequest);
////			if (!OPLUtils.isObjectNullOrEmpty(documentResponse.getDataList())) {
////				@SuppressWarnings("unchecked")
////				List<AnsProductDocumentResponse> masterList = MultipleJSONObjectHelper.getListOfObjects(
////						MultipleJSONObjectHelper.getStringfromListOfObject(documentResponse.getDataList()), null,
////						AnsProductDocumentResponse.class);
////				List<MultipartObjectRequest> multiPartObjList = new ArrayList<>();
////				StringBuilder s1 = new StringBuilder();
////				List<Long> reqDocIds = claimUploadDocuments.getDocumentList().stream()
////						.map(ClaimDocumentV2::getDocumentId).collect(Collectors.toList());
////				masterList.stream().forEach(document -> {
////
////					if ((OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame())
////							|| claimMaster.getIsClaimantSame() == Boolean.FALSE)) {
////						/** NOTE :- CLAIM_SEND_BACK_BY_INSURER means Query status from insurer */
////						if (claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
////							prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList, document);
////						} else {
////							if ((!document.getDocId().equals(14L) && !document.getDocId().equals(15L))) {
////								if (Boolean.TRUE.equals(
////										document.getIsMandatory() && !reqDocIds.contains(document.getDocId()))) {
////									s1.append(document.getDocId() + " - " + document.getDocumentName() + ",");
////								} else {
////									prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList,
////											document);
////								}
////							}
////						}
////					} else {
////						if (Boolean.TRUE
////								.equals(document.getIsMandatory() && !reqDocIds.contains(document.getDocId()))) {
////							s1.append(document.getDocId() + " - " + document.getDocumentName() + ",");
////						} else {
////							prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList, document);
////						}
////					}
////				});
////				if (!OPLUtils.isObjectNullOrEmpty(s1.toString())) {
////					log.error("Please upload mandatory documents");
////					return new RegistryResponse(s1.toString(), "Missing Documents: " + s1,
////							HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
////				}
////
////				/** Upload documents */
////				docResponse = dmsClient.uploadMultipleFileWithDocMappingIds(multiPartObjList);
////				if (docResponse.getStatus() == 200 && !OPLUtils.isListNullOrEmpty(docResponse.getDataList())) {
////					if (!claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
////						/** push complete claim details */
////						updateClaimMaster(claimMaster.getId(), RegistryUtils.PUSH_CLAIM_DATA);
////					} else {
////						/** update the re-uploaded docs in table */
////						List<Long> storageList = new ArrayList<>(docResponse.getDataList().size());
////						for (Object obj : docResponse.getDataList()) {
////							@SuppressWarnings("rawtypes")
////							StorageDetailsResponse objectFromMap = MultipleJSONObjectHelper.getObjectFromMap((Map) obj,
////									StorageDetailsResponse.class);
////							storageList.add(objectFromMap.getId());
////						}
////
////						claimMaster.setQueriedStorageId(
////								!storageList.isEmpty() ? storageList.toString().replace('[', ' ').replace(']', ' ')
////										: null);
////						claimMasterRepo.save(claimMaster);
////
////						/** re-push the docs only */
////						rePushDocs(claimMaster.getId());
////					}
////					return new RegistryResponse("Uploaded Successfully", docResponse.getDataList(),
////							HttpStatus.OK.value(), Boolean.TRUE);
////				}
////				log.error("Something went wrong");
////				return new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
////						Boolean.FALSE);
////			} else {
////				log.error("Data not found");
////				return new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
////						Boolean.FALSE);
////			}
////		} catch (Exception e) {
////			log.error("Exception is getting while getClaimdetailsByClaimUploadDocuments call ", e);
////			return new RegistryResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
////					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
////		} finally {
////			/*
////			 * if(!OPLUtils.isObjectNullOrEmpty(docResponse)) { String plainResponse =
////			 * MultipleJSONObjectHelper.getStringfromObject(docResponse); String req =
////			 * MultipleJSONObjectHelper.getStringfromObject(claimUploadDocuments);
////			 * saveRequestResponse(webhookAudit.getId(),req,plainResponse); }
////			 */
////		}
////	}
//
//}
