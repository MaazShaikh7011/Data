package com.opl.jns.registry.service.utils.v2;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.CustomerDetailsV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.KycDetailsV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.PatternUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class EnrollmentValidation {
	
    @Autowired
    private ApiConfigMasterRepo configMasterRepo;

	/**
	 * CHECK ENROLLMENT DETAILS COMMON VALIDATIONS
	 * 
	 * @param customerDetails
	 * @param kycDetails
	 * @param scheme
	 * @return
	 */
	public <T extends CustomerDetailsV1,U extends KycDetailsV1> String checkEnrollmentDetailsCommonValidations(T customerDetails, U kycDetails, String scheme) throws ParseException {
        StringBuilder stringBuilder = new StringBuilder();
        CustomerDetailsV1 customerDetailsV1 = customerDetails;
        KycDetailsV1 kycDetailsV1 = kycDetails;
	       if (!OPLUtils.isObjectNullOrEmpty(customerDetailsV1) && !OPLUtils.isObjectNullOrEmpty(kycDetailsV1)) {
	    	    StringBuilder s1 = checkCustomerDetailsCommonValidations(customerDetails,kycDetails,scheme);
	    	    stringBuilder.append(s1);
	        } else {
	        	stringBuilder.append("Enrollment details not found");
	        }
	       return stringBuilder.toString();
	}
	
	/**
	 * CHECK ENROLLMENT DETAILS VALIDATIONS FOR V2
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public String checkEnrollmentDetailsValidationsV2(EnrollmentReqProxyV2 enrollmentDetails) throws ParseException{
        StringBuilder stringBuilder = new StringBuilder();
	       if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails)) {
	    	   	StringBuilder s1 = checkCustomerDetailsValidationsV2(enrollmentDetails);
	    	    StringBuilder s2 = checkNomineeGuardianValidationsV2(enrollmentDetails);
	    	    stringBuilder.append(s1);
	    	    stringBuilder.append(s2);
	        } else {
	        	stringBuilder.append("Enrollment details not found");
	        }
	       return stringBuilder.toString();
	}
	
	/**
	 * CHECK ENROLLMENT DETAILS VALIDATIONS FOR V3
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public String checkEnrollmentDetailsValidationsV3(EnrollmentReqProxyV3 enrollmentDetails) throws ParseException{
        StringBuilder stringBuilder = new StringBuilder();
	       if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails)) {
	    	   	StringBuilder s1 = checkCustomerDetailsValidationsV3(enrollmentDetails);
	    	    StringBuilder s2 = checkNomineeGuardianValidationsV3(enrollmentDetails);
	    	    stringBuilder.append(s1);
	    	    stringBuilder.append(s2);
	        } else {
	        	stringBuilder.append("Enrollment details not found");
	        }
	       return stringBuilder.toString();
	}
	
	/**
	 * CHECK CUSTOMER DETAILS COMMON VALIDATIONS
	 * 
	 * @param customerDetails
	 * @param kycDetails
	 * @param schemeName
	 * @return
	 */
	public <T extends CustomerDetailsV1, S extends KycDetailsV1> StringBuilder checkCustomerDetailsCommonValidations(
			CustomerDetailsV1 customerDetails,KycDetailsV1 kycDetailsV1, String schemeName) {
		 StringBuilder s1 = new StringBuilder();
		 if (OPLUtils.isObjectNullOrEmpty(customerDetails))
			 s1.append("Customer details not found");
		 else { 
			 if (!OPLUtils.isObjectNullOrEmpty(schemeName)) {
					if(schemeName.equalsIgnoreCase(SchemeMaster.PMSBY.getShortName())) {
						if (OPLUtils
								.isObjectNullOrEmpty(customerDetails.getDisabilityStatus())) {
							s1.append("Disability Status not found.");
						} 
						if (!OPLUtils.isObjectNullOrEmpty(customerDetails.getDisabilityStatus())
								&& !customerDetails.getDisabilityStatus()
										.equalsIgnoreCase(YesNo.YES.getValue())
								&& !customerDetails.getDisabilityStatus()
										.equalsIgnoreCase(YesNo.NO.getValue())) {
							s1.append("Disability status must be : YES or NO");
						}
						if (!OPLUtils.isObjectNullOrEmpty(customerDetails.getDisabilityStatus())
								&& customerDetails.getDisabilityStatus()
										.equalsIgnoreCase(YesNo.YES.getValue())) {
							if (OPLUtils.isObjectNullOrEmpty(
									customerDetails.getDisabilityDetails())) {
								s1.append(" Disability Details not found.");
							}
						}
						
					}
				}
				else {
					s1.append("Please provide scheme in other details.");
				}
				s1 = kycIdValidation(kycDetailsV1.getKycId1(), kycDetailsV1.getKycIdValue1(), s1,"KYC ID1");
		 }  
		return s1;
	}
	
	/**
	 * CHECK CUSTOMER DETAILS VALIDATIONS V2
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public StringBuilder checkCustomerDetailsValidationsV2(EnrollmentReqProxyV2 enrollmentDetails)
			throws ParseException {
		StringBuilder s1 = new StringBuilder();
		if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails()))
			s1.append("Customer details not found");
		else {
			String schemeName = enrollmentDetails.getOtherDetails().getScheme();

			try {
				// DOB VALIDATION
				Date dob = null;
				try {
					dob = new SimpleDateFormat(DateUtils.DateFormat.DD_MM_YYYY)
							.parse(enrollmentDetails.getCustomerDetails().getDob());
				} catch (Exception e) {
					log.warn("Applicant's date of birth format is invalid");
					s1.append("Applicant's date of birth format is invalid");
				}

				// CHECK ENROLLMENT AGE VALIDATION
				String enrollmentAgeLimit = null;
				if (Objects.equals(schemeName, SchemeMaster.PMJJBY.getShortName())) {
					enrollmentAgeLimit = configMasterRepo
							.findByCodeAndIsActiveTrue(RegistryUtils.PMJJBY_ENROLLMENT_AGE_LIMIT).getValue();
				} else {
					enrollmentAgeLimit = configMasterRepo
							.findByCodeAndIsActiveTrue(RegistryUtils.PMSBY_ENROLLMENT_AGE_LIMIT).getValue();
				}
				String[] enrollmentAgeLimitArray = null;
				enrollmentAgeLimitArray = enrollmentAgeLimit.split(",");

				Boolean isAgeValid = com.opl.jns.utils.common.OPLUtils.getAgeCriteriaValidation(
						SchemeMaster.getByCode(schemeName).getId().intValue(), dob, null, enrollmentAgeLimitArray);

				if (Boolean.FALSE.equals(isAgeValid)) {
					s1.append(
							" As per bank records, you have exceeded the age criteria for the selected scheme. You will not be able to proceed here.");
				}
			} catch (Exception e) {
				log.warn("Exception while dob validation", e);
			}
			s1 = kycIdValidation(enrollmentDetails.getKycDetails().getKycId2(),
					enrollmentDetails.getKycDetails().getKycIdValue2(), s1, "KYC ID2");

		}
		return s1;
	}
	
	/**
	 * CHECK CUSTOMER DETAILS VALIDATIONS V3
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public StringBuilder checkCustomerDetailsValidationsV3(EnrollmentReqProxyV3 enrollmentDetails)
			throws ParseException {
		StringBuilder s1 = new StringBuilder();
		if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails()))
			s1.append("Customer details not found");
		else {
			String schemeName = enrollmentDetails.getOtherDetails().getSchemeName();

			try {
				// CHECK ENROLLMENT AGE VALIDATION
				String enrollmentAgeLimit = null;
				if (Objects.equals(schemeName, SchemeMaster.PMJJBY.getShortName())) {
					enrollmentAgeLimit = configMasterRepo
							.findByCodeAndIsActiveTrue(RegistryUtils.PMJJBY_ENROLLMENT_AGE_LIMIT).getValue();
				} else {
					enrollmentAgeLimit = configMasterRepo
							.findByCodeAndIsActiveTrue(RegistryUtils.PMSBY_ENROLLMENT_AGE_LIMIT).getValue();
				}
				String[] enrollmentAgeLimitArray = null;
				enrollmentAgeLimitArray = enrollmentAgeLimit.split(",");

				Boolean isAgeValid = com.opl.jns.utils.common.OPLUtils.getAgeCriteriaValidation(
						SchemeMaster.getByCode(schemeName).getId().intValue(), Date.from(enrollmentDetails.getCustomerDetails().getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()), null, enrollmentAgeLimitArray);

				if (Boolean.FALSE.equals(isAgeValid)) {
					s1.append(
							" As per bank records, you have exceeded the age criteria for the selected scheme. You will not be able to proceed here.");
				}
			} catch (Exception e) {
				log.warn("Exception while dob validation", e);
			}
		}
		return s1;
	}
	
	/**
	 * CHECK NOMINEE/GUARDIAN VALIDATIONS V2
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public static StringBuilder checkNomineeGuardianValidationsV2(EnrollmentReqProxyV2 enrollmentDetails) {
		StringBuilder s1 = new StringBuilder();
		if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
			s1.append("Nominee details can not be empty");
        } else if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getDob())) {
            try {
                Date dob = new SimpleDateFormat(DateUtils.DateFormat.DD_MM_YYYY).parse(enrollmentDetails.getNomineeDetails().getDob());
                Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
                if (ageFromBirthDate < 18) {
                	if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails())) {
                		log.warn("age is less then 18 so guardian details is mandatory   AGE -> ({}),  YEAR -> ({})", enrollmentDetails.getNomineeDetails().getDob(), ageFromBirthDate);
                		s1.append("""
				                Guardian details can not be empty\
				                """);	
                	}
                	else {
                		  
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
                			log.warn("Guardian First Name can not be null or empty.");
                			s1.append("Guardian First Name can not be null or empty.");
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
                			String firstName = enrollmentDetails.getGuardianDetails().getFirstName();
                			if(Boolean.TRUE.equals(findLength(firstName,1L,50L))) {
                				log.warn("Guardian First Name must be between 1 and 50 Characters. -> ({}))", firstName);
                				s1.append("Guardian First Name must be between 1 and 50 Characters.");
                			}
                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
                			log.warn("Guardian Address can not be null or empty.");
                			s1.append("Guardian Address can not be null or empty.");
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
                			String address = enrollmentDetails.getGuardianDetails().getAddress();
                			if(Boolean.TRUE.equals(findLength(address,2L,200L))) {
                				log.warn("Guardian Address must be between 2 and 200 Characters. -> ({}))", address);
                				s1.append("Guardian Address must be between 2 and 200 Characters.");
                				}
                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getPincode())) {
                			log.warn("Guardian Pincode can not be null or empty.");
                			s1.append("Guardian Pincode can not be null or empty.");
                          
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getPincode())) {
                			String pincode = enrollmentDetails.getGuardianDetails().getPincode();
                			if(Boolean.TRUE.equals(findLength(pincode,6L,6L))) {
                				log.warn("Guardian Pincode must be 6 Characters. -> ({}))", pincode);
                				s1.append("Guardian Pincode must be 6 Characters.");       
                			}
                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getState())) {
                			log.warn("Guardian State can not be null or empty.");
                			s1.append("Guardian State can not be null or empty.");
                           
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getState())) {
                			String state = enrollmentDetails.getGuardianDetails().getState();
                			if(Boolean.TRUE.equals(findLength(state,2L,200L))) {
                				log.warn("Guardian State must be between 2 and 200 characters. -> ({}))", state);
                				s1.append("Guardian State must be between 2 and 200 characters.");  
                			}
                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getCity())) {
                			log.warn("Guardian City can not be null or empty.");
                			s1.append("Guardian City can not be null or empty.");                          
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getCity())) {
                			String city = enrollmentDetails.getGuardianDetails().getCity();
                			if(Boolean.TRUE.equals(findLength(city,2L,200L))) {
                				log.warn("Guardian City must be between 2 and 200 characters. -> ({}))", city);
                				s1.append("Guardian City must be between 2 and 200 characters.");       
                			}
                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getDistrict())) {
                			log.warn("Guardian District can not be null or empty.");
                			s1.append("Guardian District can not be null or empty.");                 
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getDistrict())) {
                			String district = enrollmentDetails.getGuardianDetails().getDistrict();
                			if(Boolean.TRUE.equals(findLength(district,2L,200L))) {
                				log.warn("Guardian District must be between 2 and 200 characters . -> ({}))", district);
                				s1.append("Guardian District must be between 2 and 200 characters."); 
                			}
                		}
                		/**CHECK GUARDIAN RELATIONSHIP VALIDATION*/
                		s1 = checkGuardianRelationShipValidOrNot(s1,enrollmentDetails.getGuardianDetails().getRelationShip());
                	}  
                }
            } catch (Exception e) {
                log.error(" Nominee birth date can not be parse", e);
                s1.append(" Nominee birth date can not be parse");
            }
        } else {
        	 s1.append("Nominee birth date can not be empty");
        }
		return s1;
	}
	
	/**
	 * CHECK NOMINEE/GUARDIAN VALIDATIONS V3
	 * 
	 * @param enrollmentDetails
	 * @return
	 */
	public static StringBuilder checkNomineeGuardianValidationsV3(EnrollmentReqProxyV3 enrollmentDetails) {
		StringBuilder s1 = new StringBuilder();
		if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
			s1.append("Nominee details can not be empty");
		} else if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getDob())) {
			try {
				Date dob = Date.from(enrollmentDetails.getNomineeDetails().getDob()
						.atStartOfDay(ZoneId.systemDefault()).toInstant());
				Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
				if (ageFromBirthDate < 18) {
					if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails())) {
						log.warn("age is less then 18 so guardian details is mandatory   AGE -> ({}),  YEAR -> ({})",
								enrollmentDetails.getNomineeDetails().getDob(), ageFromBirthDate);
						s1.append("" + "Guardian details can not be empty");
					} else {

						if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getGuradianName())) {
							log.warn("Guardian Name can not be null or empty.");
							s1.append("Guardian Name can not be null or empty.");
						} else if (!OPLUtils
								.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getGuradianName())) {
							String name = enrollmentDetails.getGuardianDetails().getGuradianName();
							if (Boolean.TRUE.equals(findLength(name, 1L, 300L))) {
								log.warn("Guardian Name must be between 1 and 50 Characters. -> ({}))", name);
								s1.append("Guardian Name must be between 1 and 50 Characters.");
							}
						}
						if (OPLUtils
								.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddressofGuardian())) {
							log.warn("Guardian Address can not be null or empty.");
							s1.append("Guardian Address can not be null or empty.");
						} else if (!OPLUtils
								.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddressofGuardian())) {
							String address = enrollmentDetails.getGuardianDetails().getAddressofGuardian();
							if (Boolean.TRUE.equals(findLength(address, 2L, 500L))) {
								log.warn("Guardian Address must be between 2 and 500 Characters. -> ({}))", address);
								s1.append("Guardian Address must be between 2 and 500 Characters.");
							}
						}
						/**CHECK GUARDIAN RELATIONSHIP VALIDATION*/
						s1 = checkGuardianRelationShipValidOrNot(s1,enrollmentDetails.getGuardianDetails().getRelationShip());
					}
				}
			} catch (Exception e) {
				log.error(" Nominee birth date can not be parse", e);
				s1.append(" Nominee birth date can not be parse");
			}
		} else {
        	 s1.append("Nominee birth date can not be empty");
        }
		return s1;
	}
	
	/**
	 * VALIDATE UPDATE TRANSACTION COMMON REQUEST 
	 * @param transactionRequest
	 * @return 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T extends UpdateTransReqProxyV1, U extends String> U validateTransactionDetailCommonValidation(
			T t) {
		String errorMsg = null;
		UpdateTransReqProxyV1 transactionRequest = (UpdateTransReqProxyV1) t;

		if (OPLUtils.isObjectNullOrEmpty(transactionRequest))
			errorMsg = "Data Can not be null";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionAmount()))
			errorMsg = "transactionAmount not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getUrn()))
			errorMsg = "urn code not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getMasterPolicyNumber()))
			errorMsg = "masterPolicyNumber not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionUTR()))
			errorMsg = "transactionUtr not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionUTR()))
			errorMsg = "Transaction Amount Can not be empty, null or Zero";
		else if (!OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionAmount())
				&& transactionRequest.getTransactionAmount() == 0)
			errorMsg = "Invalid Transaction Amount. Value must be non-zero numeric value.";

//		if (!OPLUtils.isObjectNullOrEmpty(errorMsg)) {
//			return (U) new RegCommonResponse(errorMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
		return (U) errorMsg;
	}
	
	/**
	 * VALIDATE UPDATE TRANSACTION REQUEST V2
	 * @param transactionRequest
	 * @return
	 */
	public UpdateTransResProxyV2 validateTransactionDetailV2(UpdateTransReqProxyV2 transactionRequest) {
		String errorMsg = null;
		if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionTimeStamp()))
			errorMsg = "transactionTimeStamp code not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getInsurerCode()))
			errorMsg = "insurerCode not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()))
			errorMsg = "transactionType not found";

		if (!OPLUtils.isObjectNullOrEmpty(errorMsg)) {
			return new UpdateTransResProxyV2(errorMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		return null;
	}
	
	/**
	 * VALIDATE UPDATE TRANSACTION REQUEST V3
	 * @param transactionRequest
	 * @return
	 */
	public UpdateTransResProxyV3 validateTransactionDetailV3(UpdateTransReqProxyV3 transactionRequest) {
		String errorMsg = null;
		if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionTimeStamp()))
			errorMsg = "transactionTimeStamp code not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getInsurerCode()))
			errorMsg = "insurerCode not found";
		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()))
			errorMsg = "transactionType not found";

		if (!OPLUtils.isObjectNullOrEmpty(errorMsg)) {
			return new UpdateTransResProxyV3(errorMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		return null;
	}
	
	public static StringBuilder checkGuardianRelationShipValidOrNot(StringBuilder s1,String gdRelationShip) {
		if(OPLUtils.isObjectNullOrEmpty(gdRelationShip)) {
			log.warn("Guardian RelationShip can not be null or empty.");
			s1.append("Guardian RelationShip can not be null or empty.");
		}else if(!OPLUtils.isObjectNullOrEmpty(gdRelationShip)) {
			try {	                			
    			RelationShip rel = RelationShip.fromValue(gdRelationShip);
    			if(OPLUtils.isObjectNullOrEmpty(rel)) {
    				log.warn("Guardian Provided Relationship not valid. -> ({}))", gdRelationShip);
    				s1.append("Guardian Provided Relationship(relationShip) not valid.");
    			}
			}
			catch(Exception e) {
				log.warn("Guardian Provided Relationship not valid. -> ({}))", gdRelationShip);
				s1.append("Guardian Provided Relationship not valid.");
			}
		}
		return s1;
	}


	public static Boolean findLength(String key,Long min,Long max) {
	   if(key.length() < min  || key.length() > max) {
		   return Boolean.TRUE;
	   }
	   return Boolean.FALSE;
   }
	
	public static StringBuilder kycIdValidOrNot(String kycId,String kycIdName) {
		if(!kycId.equalsIgnoreCase(KycDocument.PAN.getKey()) && !kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey()) && !kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey()) &&
				!kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey()) && !kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey()) && !kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			return new StringBuilder(kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA");
		}
		return null;
	}
	
	
	public static CommonResponse kycIdNumberValidOrNot(String kycId,String kycIdNumber,String kycIdName) {
		if(kycId.equalsIgnoreCase(KycDocument.PAN.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PAN_PATTERN);
			java.util.regex.Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid pan number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.AADHAR_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid aadhar number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PASSPORT_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid passport number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.VOTERS_ID_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid voter id number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.DRIVING_LICENCE_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid driving licence number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.MGNREGA_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid mgnrega card number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}
		return null;
	}
	
	public StringBuilder kycIdValidation(String kycId,String kycIdValue,StringBuilder builder,String kycIdName) {
		if (!OPLUtils.isObjectNullOrEmpty(kycId)) {
			StringBuilder sb1 = kycIdValidOrNot(kycId, kycIdName);
			if (!OPLUtils.isObjectNullOrEmpty(sb1)) {
				return builder.append(sb1);
			}
			if (!OPLUtils.isObjectNullOrEmpty(kycIdValue) && !kycIdValue.equalsIgnoreCase(RegistryUtils.AADHAR)) {
				CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(kycId,kycIdValue,kycIdName);
				if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
					return builder.append(commonResponsekycNo.getMessage());
				}
			}
		}
		return builder;
	}
	
	/**
	 * CHECK ENROLLMENT DETAILS VALIDATIONS FOR V3
	 * 
	 * @param nomineeUpdateAPI
	 * @return
	 */
	public String checkNomineeUpdateValidationsV3(NomineeUpdateRequest request) throws ParseException {
		StringBuilder stringBuilder = new StringBuilder();
		StringBuilder s1 = checkNomineeGuardianValidV3(request);
		stringBuilder.append(s1);
		return stringBuilder.toString();
	}
	
	/**
	 * CHECK NOMINEE/GUARDIAN VALIDATIONS V3
	 * 
	 * @param nomineeUpdateAPI
	 * @return
	 */
	public static StringBuilder checkNomineeGuardianValidV3(NomineeUpdateRequest request) {
		StringBuilder s1 = new StringBuilder();
		try {
			Date dob = Date.from(request.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant());
			Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
			if (ageFromBirthDate < 18) {
				if (OPLUtils.isObjectNullOrEmpty(request.getNameofGuardian())) {
					log.warn("Guardian Name can not be null or empty.");
					s1.append("Guardian Name can not be null or empty.");
				} else if (!OPLUtils.isObjectNullOrEmpty(request.getNameofGuardian())) {
					String name = request.getNameofGuardian();
					if (Boolean.TRUE.equals(findLength(name, 1L, 300L))) {
						log.warn("Guardian Name must be between 1 and 300 Characters. -> ({}))", name);
						s1.append("Guardian Name must be between 1 and 300 Characters.");
					}
				}
				if (OPLUtils.isObjectNullOrEmpty(request.getAddressOfGuardian())) {
					log.warn("Guardian Address can not be null or empty.");
					s1.append("Guardian Address can not be null or empty.");
				} else if (!OPLUtils.isObjectNullOrEmpty(request.getAddressOfGuardian())) {
					String address = request.getAddressOfGuardian();
					if (Boolean.TRUE.equals(findLength(address, 2L, 500L))) {
						log.warn("Guardian Address must be between 2 and 500 Characters. -> ({}))", address);
						s1.append("Guardian Address must be between 2 and 500 Characters.");
					}
				}
				/** CHECK GUARDIAN RELATIONSHIP VALIDATION */
				s1 = checkGuardianRelationShipValidOrNot(s1, request.getRelationShipOfGuardian());
			}
		} catch (Exception e) {
			log.error(" Nominee birth date can not be parse", e);
			s1.append(" Nominee birth date can not be parse");
		}
		return s1;
	}
}
