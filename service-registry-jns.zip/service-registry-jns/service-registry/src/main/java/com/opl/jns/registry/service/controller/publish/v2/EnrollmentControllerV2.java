package com.opl.jns.registry.service.controller.publish.v2;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe.DeDupReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe.DeDupResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatestatus.UpdateStatusReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransResProxyV2;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.api.proxy.jansuraksha.v2.Response400V2;
import com.opl.jns.api.proxy.jansuraksha.v2.Response401;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.service.publish.common.EnrollService;
import com.opl.jns.registry.service.utils.RegistryUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@RestController
@RequestMapping("/v2")
@Slf4j
@Tag(name = "1. Other Channel Enrollments API", description = "List Of Registry Api")
public class EnrollmentControllerV2 {

	@Autowired
	@Qualifier("EnrollmentServiceImplV2")
	private EnrollService enrollService;

	@PostMapping("/de-dupe")
	@Operation(operationId = "1", summary = Constants.DE_DUP_API_MESSAGE, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.DE_DUP_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION_DATE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_DE_DUPE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = DeDupResProxyV2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.DE_DUP_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)

							) }) })

	public ResponseEntity<DeDupResProxyV2> checkDeDup(@Valid @RequestBody DeDupReqProxyV2 dedupeReq,
													  HttpServletRequest httpServletRequest) {
		DeDupResProxyV2 commonResponse = new DeDupResProxyV2(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
				HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		commonResponse = (DeDupResProxyV2) RegistryUtils.setTokenAndTimeStempV2(commonResponse, httpServletRequest);
		if (OPLUtils.isObjectNullOrEmpty(dedupeReq)) {
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				commonResponse.setMessage(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY);
				commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
				commonResponse.setSuccess(Boolean.FALSE);
				return new ResponseEntity<>(commonResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
			commonResponse = enrollService.deDupe(dedupeReq, userOrgId);
			commonResponse = (DeDupResProxyV2) RegistryUtils.setTokenAndTimeStempV2(commonResponse, httpServletRequest);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			commonResponse.setMessage(Constants.ErrorMsg.SMTG_WNT_WRG);
			commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			commonResponse.setSuccess(Boolean.FALSE);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		}

	}

	@PostMapping("/enrollment")
	@Operation(operationId = "2", summary = Constants.PUSH_ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_DOB_DATE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_ENROLLMENT, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<EnrollmentResProxyV2> pushEnrollment(
			@Valid @RequestBody EnrollmentReqProxyV2 applicationRequest, HttpServletRequest httpServletRequest) {
		EnrollmentResProxyV2 enrollmentResponse = new EnrollmentResProxyV2(
				Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		enrollmentResponse = (EnrollmentResProxyV2) RegistryUtils.setTokenAndTimeStemp(enrollmentResponse,
				httpServletRequest);
		if (OPLUtils.isObjectNullOrEmpty(applicationRequest)) {
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				enrollmentResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
			enrollmentResponse = enrollService.enroll(applicationRequest, userOrgId);
			enrollmentResponse = (EnrollmentResProxyV2) RegistryUtils.setTokenAndTimeStemp(enrollmentResponse,
					httpServletRequest);
			log.info("<--- Exit From enrollment ---> ");
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in PushEnrollment Details() {}", e.getMessage());
			enrollmentResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.FAILED,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		}

	}

	@PostMapping("/updateTransactionDetails")
	@Operation(operationId = "3", summary = Constants.UPDATE_TRANSACTION_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateTransResProxyV2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })

	public ResponseEntity<UpdateTransResProxyV2> saveTransaction(
			@Valid @RequestBody UpdateTransReqProxyV2 transactionRequest, HttpServletRequest httpServletRequest) {
		UpdateTransResProxyV2 coiResponse = new UpdateTransResProxyV2(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
				HttpStatus.BAD_REQUEST.value());
		coiResponse = (UpdateTransResProxyV2) RegistryUtils.setTokenAndTimeStemp(coiResponse, httpServletRequest);
		if (OPLUtils.isObjectNullOrEmpty(transactionRequest)) {
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				coiResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), null);
				return new ResponseEntity<>(coiResponse, HttpStatus.OK);
			}

			coiResponse = enrollService.updateTransactionDetailsAndGetCoiFiles(transactionRequest,coiResponse);
			coiResponse = (UpdateTransResProxyV2) RegistryUtils.setTokenAndTimeStemp(coiResponse, httpServletRequest);
			log.info("<--- Exit From Update Transaction Details  ---> ");
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			coiResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		}
	}

	@PostMapping("/updateStatus")
	@Operation(operationId = "4", summary = Constants.UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = RegistryResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimDetailsResProxyV2> updateStatus(@Valid @RequestBody UpdateStatusReqProxyV2 statusApiReq,
			HttpServletRequest httpServletRequest) {
		ClaimDetailsResProxyV2 commonResponse = new ClaimDetailsResProxyV2(
				Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value());
		commonResponse = (ClaimDetailsResProxyV2) RegistryUtils.setTokenAndTimeStemp(commonResponse,
				httpServletRequest);
		if (OPLUtils.isObjectNullOrEmpty(statusApiReq)) {
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				commonResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), null);
				return new ResponseEntity<>(commonResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);

			/* UPDATE STAGE IN INSURANCE APPLICATION MASTER COLLECTION */
			commonResponse = enrollService.updateStatus(statusApiReq);
			commonResponse = (ClaimDetailsResProxyV2) RegistryUtils.setTokenAndTimeStemp(commonResponse,
					httpServletRequest);
			log.info("<--- Exit From Update Transaction Details  ---> ");
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			commonResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		}

	}

}
