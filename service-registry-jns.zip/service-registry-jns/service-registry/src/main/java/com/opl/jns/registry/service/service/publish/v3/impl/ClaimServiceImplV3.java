package com.opl.jns.registry.service.service.publish.v3.impl;

import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReqV3;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupDataResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDedupMatchWithResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailDataProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimDocumentResProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.ddregistry.api.model.dedupe.ClaimDedupApiResponse;
import com.opl.jns.ere.domain.*;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ClmDeDupeDetailsRepository;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.ere.utils.DedupeDataResponse;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.domain.PUBClaimMaster;
import com.opl.jns.registry.service.repository.PUBClaimMasterRepo;
import com.opl.jns.registry.service.service.publish.common.ClaimService;
import com.opl.jns.registry.service.service.publish.common.impl.ClaimAbstractV3;
import com.opl.jns.registry.service.utils.GetterSetterV3;
import com.opl.jns.registry.service.utils.v2.ClaimValidation;
import com.opl.jns.registry.service.utils.v3.ClaimValidationV3;
import com.opl.jns.registry.service.utils.v3.DeDupeRegistryUtility;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.webhook.client.WebHookClient;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.*;

@Service
@Slf4j
@Qualifier("ClaimServiceImplV3")
public class ClaimServiceImplV3 extends ClaimAbstractV3 implements ClaimService {

	@Autowired
	private ClmMasterRepository clmMasterRepo;
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;
	
	@Autowired
	private GetterSetterV3 getterSetterV3;
	
	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 applicationMasterOtherDetailsRepository;

	@Autowired
	private PUBClaimMasterRepo pubClaimMasterRepo;
	
	@Autowired
	private DeDupeRegistryUtility deDupeRegistryUtility;
	
	@Autowired
	private WebHookClient webHookClient;
	
	@Autowired
	private NotificationClient notificationClient;
	
	@Autowired
	private UsersClient usersClient;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	@Autowired
	private ClmDeDupeDetailsRepository clmDeDupeDetailsRepository;
	
	private static final int INT_200 = 200;
	
	
	@SuppressWarnings("unchecked")
	@Transactional
	public <T extends RegistryReqProxy, U extends APIResponseV3> U saveClaimApi(T in, Long orgId) throws Exception {
		ClaimDetailsReqProxyV3 claimRequest = (ClaimDetailsReqProxyV3) in;
		ClaimDetailsResProxyV3 commonResponse = ClaimValidationV3.checkClaimDetailsValidationsV3(claimRequest);
		if (Boolean.FALSE.equals(commonResponse.getSuccess())) {
			log.warn("enrollmentDetails from request-> {} ",
					MultipleJSONObjectHelper.getStringfromObject(claimRequest));
			return (U) commonResponse;
		}
		
		ClaimDetailsResProxyV3 resp = new ClaimDetailsResProxyV3();

		String[] urn = claimRequest.getUrn().split("-");
		Long applicationId = Long.valueOf(urn[4]);
		
		Long schemeId = SchemeMaster.getByCode(claimRequest.getSchemeName()).getId();
		
		/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
		ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(schemeId, applicationId);
				
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.info("There is no enrollment for URN: " + claimRequest.getUrn().trim());
			return (U) new ClaimDetailsResProxyV3("There is no enrollment for URN.", null, HttpStatus.BAD_REQUEST.value());
		} else if (!OPLUtils.isObjectNullOrEmpty(appMaster) && !appMaster.getOrgId().equals(orgId)) {
			log.info("In your organization, enrollment doesn't exist.: " + claimRequest.getUrn().trim());
			return (U) new ClaimDetailsResProxyV3("In your organization, enrollment doesn't exist.", null,
					HttpStatus.BAD_REQUEST.value());
		}

		// Get existing claim detail
		ClmMaster clmMaster = new ClmMaster();
		clmMaster = clmMasterRepo.findFirstByUrnAndIsActiveTrueOrderByIdDesc(claimRequest.getUrn());
			
		// for second and third time claim
		if (null != clmMaster) {
			resp = this.deDupeLogic(clmMaster,appMaster);
			if (Boolean.FALSE.equals(resp.getSuccess())) {
				if(resp.getStatus() == INT_200) {
					resp.setSuccess(Boolean.TRUE);
				}
				return (U) resp;
			}
		}
		
		/** CHECK PMSBY DEDUPE */
		resp = this.checkPMSBYDedupe(appMaster,schemeId);
		if (Boolean.FALSE.equals(resp.getSuccess())) {
			return (U) resp;
		}

		StringBuilder s1 = new StringBuilder();
		// claimant kyc id 1 and 2 validation
		ClaimValidationV3.kycIdValidation(claimRequest.getClaimantKYC1(), claimRequest.getClaimantKYCNumber1(), s1,"KYC ID1");
		
		// Scheme wise field validations
		ClaimValidationV3.checkMandatoryFieldsOfBothSchemeCommon(claimRequest, schemeId.intValue(), s1);
		
		ClaimValidationV3.checkMandatoryFieldsOfBothScheme(claimRequest, schemeId.intValue(),
				appMaster.getEnrollmentDate(), s1);

		
		
		if (!OPLUtils.isObjectNullOrEmpty(s1.toString())) {
			commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			commonResponse.setSuccess(OPLUtils.isObjectNullOrEmpty(s1.toString()));
			commonResponse.setMessage(s1.toString());
			return (U) commonResponse;
		}


//		// set nominee details  -- pending KP
//		if(!OPLUtils.isObjectNullOrEmpty(clmMaster)) {
//			ClmNomineeDetails  existingNominee = clmNomineeDetailsRepository.getByClaimIdAndIsActiveTrue(clmMaster.getId());
//		
//		
//				existingNominee.setMobileNumber(claimRequest.getNomineeMobileNumber());
//				String existingNomineeEmail = OPLUtils.isObjectNullOrEmpty(existingNominee.getEmail()) ? null
//						: existingNominee.getEmail();
//				existingNominee.setEmail(OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeEmailId()) ? existingNomineeEmail
//						: claimRequest.getNomineeEmailId());
////				if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeNameCorrection())
////						&& claimRequest.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
////					existingNominee.setCorrectNomineeFirstName(claimRequest.getCorrectNomineeName());
////				}	
//				
//			}
	
		BranchBasicDetailsRequest branchDetails = usersClient.getBranchCode(schemeId,appMaster.getOrgId(),claimRequest.getBranchCode());
		
		if (OPLUtils.isObjectNullOrEmpty(branchDetails)) {
			log.error("BRANCH DETAILS NOT FOUND BY BRANCH CODE AND SCHEME ID");
			return (U) new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), "Branch Details Not Found",false);
		}
		
		/**GET HO USER ID*/
		Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(appMaster.getOrgId(), UserRoleMaster.HEAD_OFFICE.getId());
		
		if (OPLUtils.isObjectNullOrEmpty(userId)) {
			log.error("USER ID NOT FOUND BY ORG ID AND HO ROLE ID");
			return (U) new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), "User Id Not Found",false);
		}
		
		// save claim master details save
		/** SET CLAIM MASTER */
		clmMaster=getterSetterV3.setClmMaster(appMaster,claimRequest,orgId,branchDetails,schemeId.intValue(),userId);
		
		/** SET CLAIM APPLICANT DETAILS */
		ClmDetails clmDetails = getterSetterV3.setClmDetails(clmMaster, claimRequest,branchDetails);
		clmMaster.setClmDetails(clmDetails);

		/** SET CLAIM APPLICANT PI DETAILS */
		ClmPIDetails clmPIDetails = getterSetterV3.setClmPIDetails(claimRequest,clmMaster,appMaster);
		clmPIDetails.setClmDetails(clmDetails);
		clmDetails.setClmPIDetails(clmPIDetails);
		
		/** SET CLAIM NOMINEE AND NOMINEE PI DETAILS */
		ClmNomineeDetails clmNomineeDetails = getterSetterV3.setClmNomineeDetails(claimRequest, clmMaster);
//		clmNomineeDetailsRepo.save(clmNomineeDetails);
		clmMaster.setClmNomineeDetails(clmNomineeDetails);		
		clmMaster = clmMasterRepo.save(clmMaster);

		resp.setSuccess(Boolean.TRUE);
		resp.setMessage("Success");
		resp.setData(new ClaimDetailDataProxyV3(clmMaster.getId()));
		resp.setStatus(HttpStatus.OK.value());
		return (U) resp;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends ClaimUploadDocsReqProxyV3, U extends ClaimDocumentResProxy> U getClaimdetailsByClaimUploadDocuments(T claimUploadDocuments) {
		try {
			return this.documentUploadAndManageProcess(claimUploadDocuments.getDocumentList(),claimUploadDocuments.getClaimReferenceId(),claimUploadDocuments.getRemarks());
		} catch (Exception e) {
			log.error("Exception is getting while getClaimdetailsByClaimUploadDocuments call ", e);
			return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(),HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), Boolean.FALSE);
		}
	}

	@Override
	public boolean updateClaimStatusInsurerByJsForScheduler(Long claimId) {
		try {
			/** re-push the docs only */
			rePushDocs(claimId);
			return true;
		} catch (Exception e) {
			log.error("Exception is getting while updateClaimStatusInsurerByJsForScheduler call ", e);
			return false;
		}
	}

//	private RegistryResponse getClaimDetailsByClaimUploadDocumentsBKP(ClaimUploadDocsReqProxyV2 claimUploadDocuments)
//			throws IOException {
//		DocumentResponse docResponse = null;
//		try {
//			ClaimMasterV3 claimMaster = claimMasterRepo
//					.findByIdAndIsActiveTrue(claimUploadDocuments.getClaimReferenceId());
//			// here claimReferenceId is claimId from claim master - ere
//			if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//				log.error("ClaimMaster data not found");
//				return new RegistryResponse("ClaimMaster data not found", HttpStatus.NOT_FOUND.value(), Boolean.FALSE);
//			}
//
//			DocumentRequest documentRequest = new DocumentRequest();
//			documentRequest.setApplicationId(claimMaster.getApplicationMaster().getId());
//			documentRequest.setSchemeId(claimMaster.getApplicationMaster().getSchemeId());
//			documentRequest.setClaimId(claimMaster.getId());
//
//			if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMJJBY.getId().intValue())
//				documentRequest.setDisabilityTypeId(
//						OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) ? null
//								: claimMaster.getClaimDetail().getCauseOfDeathDisabilityId());
//			else {
//				documentRequest.setDisabilityTypeId(
//						OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) ? null
//								: claimMaster.getClaimDetail().getNatureOfLossId());
//			}
//
//			DocumentResponse documentResponse = dmsClient.findTypeIdByDisabilityTypeIdAndSchemeId(documentRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(documentResponse.getDataList())) {
//				@SuppressWarnings("unchecked")
//				List<AnsProductDocumentResponse> masterList = MultipleJSONObjectHelper.getListOfObjects(
//						MultipleJSONObjectHelper.getStringfromListOfObject(documentResponse.getDataList()), null,
//						AnsProductDocumentResponse.class);
//				List<MultipartObjectRequest> multiPartObjList = new ArrayList<>();
//				StringBuilder s1 = new StringBuilder();
//				List<Long> reqDocIds = claimUploadDocuments.getDocumentList().stream()
//						.map(ClaimDocumentV2::getDocumentId).collect(Collectors.toList());
//				masterList.stream().forEach(document -> {
//
//					if ((OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame())
//							|| claimMaster.getIsClaimantSame() == Boolean.FALSE)) {
//						/** NOTE :- CLAIM_SEND_BACK_BY_INSURER means Query status from insurer */
//						if (claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
//							prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList, document);
//						} else {
//							if ((!document.getDocId().equals(14L) && !document.getDocId().equals(15L))) {
//								if (Boolean.TRUE.equals(
//										document.getIsMandatory() && !reqDocIds.contains(document.getDocId()))) {
//									s1.append(document.getDocId() + " - " + document.getDocumentName() + ",");
//								} else {
//									prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList,
//											document);
//								}
//							}
//						}
//					} else {
//						if (Boolean.TRUE
//								.equals(document.getIsMandatory() && !reqDocIds.contains(document.getDocId()))) {
//							s1.append(document.getDocId() + " - " + document.getDocumentName() + ",");
//						} else {
//							prepareForUploadDocs(claimUploadDocuments, documentRequest, multiPartObjList, document);
//						}
//					}
//				});
//				if (!OPLUtils.isObjectNullOrEmpty(s1.toString())) {
//					log.error("Please upload mandatory documents");
//					return new RegistryResponse(s1.toString(), "Missing Documents: " + s1,
//							HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//				}
//
//				/** Upload documents */
//				docResponse = dmsClient.uploadMultipleFileWithDocMappingIds(multiPartObjList);
//				if (docResponse.getStatus() == 200 && !OPLUtils.isListNullOrEmpty(docResponse.getDataList())) {
//					if (!claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
//						/** push complete claim details */
//						updateClaimMaster(claimMaster.getId(), RegistryUtils.PUSH_CLAIM_DATA);
//					} else {
//						/** update the re-uploaded docs in table */
//						List<Long> storageList = new ArrayList<>(docResponse.getDataList().size());
//						for (Object obj : docResponse.getDataList()) {
//							@SuppressWarnings("rawtypes")
//							StorageDetailsResponse objectFromMap = MultipleJSONObjectHelper.getObjectFromMap((Map) obj,
//									StorageDetailsResponse.class);
//							storageList.add(objectFromMap.getId());
//						}
//
//						claimMaster.setQueriedStorageId(
//								!storageList.isEmpty() ? storageList.toString().replace('[', ' ').replace(']', ' ')
//										: null);
//						claimMasterRepo.save(claimMaster);
//
//						/** re-push the docs only */
//						rePushDocs(claimMaster.getId());
//					}
//					return new RegistryResponse("Uploaded Successfully", docResponse.getDataList(),
//							HttpStatus.OK.value(), Boolean.TRUE);
//				}
//				log.error("Something went wrong");
//				return new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
//						Boolean.FALSE);
//			} else {
//				log.error("Data not found");
//				return new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
//						Boolean.FALSE);
//			}
//		} catch (Exception e) {
//			log.error("Exception is getting while getClaimdetailsByClaimUploadDocuments call ", e);
//			return new RegistryResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
//					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		} finally {
//			/*
//			 * if(!OPLUtils.isObjectNullOrEmpty(docResponse)) { String plainResponse =
//			 * MultipleJSONObjectHelper.getStringfromObject(docResponse); String req =
//			 * MultipleJSONObjectHelper.getStringfromObject(claimUploadDocuments);
//			 * saveRequestResponse(webhookAudit.getId(),req,plainResponse); }
//			 */
//		}
//	}

	@Override
	public ClaimStatusUpdateResProxyV3 updateClaimStatus(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, StringBuilder message, HttpServletRequest httpServletRequest) {
		try {
			log.info("....Entry in updateClaimStatus()....");
			
			Integer[] claimStatus = { ClaimStatus.CLAIM_INSURER_IN_PROGRESS.getId(),
					ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId(), ClaimStatus.CLAIM_REJECTED.getId(),
					ClaimStatus.CLAIM_ACCEPTED.getId() };

			if (!Arrays.asList(claimStatus).contains(updateAppClaimRequest.getClaimStatus())) {
				log.error(
						"claimStatus must be :11 - In process,7 - Queried ,8 - Rejected,10 - Approved");
				return new ClaimStatusUpdateResProxyV3("claimStatus must be :11 - In process,7 - Queried ,8 - Rejected,10 - Approved",
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			
			ClmMaster master = clmMasterRepo.findByIdAndIsActiveTrue(updateAppClaimRequest.getClaimReferenceId());
			
			if (ClaimValidation.validateRequestForUpdateStatusApi(updateAppClaimRequest, message, master)) 
				return new ClaimStatusUpdateResProxyV3(!OPLUtils.isObjectNullOrEmpty(message) ? message.toString() : null, Boolean.FALSE, HttpStatus.BAD_REQUEST.value());
			
			/**CHECK REASON IS VALID OR NOT*/
			ClaimStatusUpdateResProxyV3 reasonIsValidOrNot = this.reasonIsValidOrNot(updateAppClaimRequest, master);
			if(!OPLUtils.isObjectNullOrEmpty(reasonIsValidOrNot)) {
				return reasonIsValidOrNot;
			}

			/**CHECK VALIDATION CLAIM ALREADY QUERIED*/
			if (updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
				if (master.getStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
					log.info("QUERY_ALREADY_SUBMIT ==="+Constants.QUERY_ALREADY_SUBMIT);
					return new ClaimStatusUpdateResProxyV3(Constants.QUERY_ALREADY_SUBMIT,Boolean.FALSE, HttpStatus.BAD_REQUEST.value());
				}
			}
			
			/**UPDATE CLAIM STATUS PUBLISH*/
			PUBClaimMaster pubMaster = pubClaimMasterRepo.findByClaimIdAndIsActiveTrue(updateAppClaimRequest.getClaimReferenceId());
			if(!OPLUtils.isObjectNullOrEmpty(pubMaster)) {
				Date curruntDate = new Date();
				pubMaster.setModifiedDate(curruntDate);
				pubMaster.setClaimStatus(updateAppClaimRequest.getClaimStatus());
		        pubClaimMasterRepo.save(pubMaster);
			}
	
	        /** update internal status */
	        ClmMaster claimMasterV3 = updateStatusFromPublish(updateAppClaimRequest, master);
	        
	        message.append(Constants.STATUS_UPDATE);

			/**PUSH CLAIM STATUS TO BANK*/
			PushClaimStatustoBankReqV3 bankReq = getterSetterV3.prepareRequestForPushBankStatus(updateAppClaimRequest, claimMasterV3);
			webHookClient.pushClaimStatusToBank(bankReq);

	        log.info(".. ..Exit from updateClaimStatus().. ..");
	        return new ClaimStatusUpdateResProxyV3(CommonErrorMsg.Common.SUCCESS,  Boolean.TRUE,HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Error while updateClaimStatus()",e);
		}
		return new ClaimStatusUpdateResProxyV3(null, Boolean.FALSE,HttpStatus.BAD_REQUEST.value());
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends APIResponseV3> U getClaimDedupeData(ClaimDeDupReqProxyV3 dedupeRequest) throws Exception {
		ClaimDeDupDataResProxyV3 claimDeDupProxy = new ClaimDeDupDataResProxyV3();
		try {

			/** GET INSURANCE CLAIM DATA */
			ClmMaster master = clmMasterRepo.findByIdAndIsActiveTrue(dedupeRequest.getClaimReferenceId());
			if(OPLUtils.isObjectNullOrEmpty(master)) {
				return (U) new ClaimDeDupResProxyV3("Invalid ClaimReferenceId", claimDeDupProxy, HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}

			RegistryResponse commonResponse = null;
			/** CHECK FIRST SAME APPLICATION HAS CLAIM OR NOT */
			RegistryResponse deDupeResult = deDupeLogicForClaim(master);
			if (deDupeResult.getSuccess().equals(Boolean.FALSE)) {
				commonResponse = setDedupeCommonResponse(claimDeDupProxy, deDupeResult);
			}

			/** CHECK CLAIM DEDUPE IN DD REGISTRY PYTHON CALL */
			try {
				
				Integer updateCount = clmDeDupeDetailsRepository
						.isActiveFalseByClaimId(master.getId(), master.getCreatedBy());
				if (updateCount > 0) {
					log.info("total Update Count ----> {}", updateCount);
				}

				ClmDeDupeDetails deDupeDetails = saveDedupeDetails(master, dedupeRequest);

				if (!OPLUtils.isObjectNullOrEmpty(deDupeDetails) && deDupeResult.getSuccess().equals(Boolean.TRUE)) {
					List<DedupeDataResponse> claimDedupApiResponse = ereCommonService.checkClaimDedupeData(
							master.getId(), master.getSchemeId().longValue(),
							dedupeRequest.getDeathordisabilitycertificateReportNo(), dedupeRequest.getFirNo(),
							dedupeRequest.getPanchnamaNo(), dedupeRequest.getPostMortemReportNo(),
							!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getDeathordisabilityCertificateReportDate()) ? Date.from(dedupeRequest.getDeathordisabilityCertificateReportDate().atZone(ZoneId.systemDefault()).toInstant()) : null,
							!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getFirDate()) ? Date.from(dedupeRequest.getFirDate().atZone(ZoneId.systemDefault()).toInstant()) : null,
							!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getPanchnamaDate()) ? Date.from(dedupeRequest.getPanchnamaDate().atZone(ZoneId.systemDefault()).toInstant()) : null,
							!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getPostMortemReportDate()) ? Date.from(dedupeRequest.getPostMortemReportDate().atZone(ZoneId.systemDefault()).toInstant()) : null);
					if (!OPLUtils.isListNullOrEmpty(claimDedupApiResponse)) {
						DedupeDataResponse dedupeDataResponse = claimDedupApiResponse.get(0);
						ClaimDedupMatchWithResProxyV3 claimDDDetails = new ClaimDedupMatchWithResProxyV3();
						claimDDDetails.setDateOfLoss(dedupeDataResponse.getDateOfLoss());
						claimDDDetails.setIntimationDate(
								CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(dedupeDataResponse.getClaimInimationDate()));
						claimDDDetails.setType(
								Long.valueOf(NatureOfLoss.fromBankValue(dedupeDataResponse.getType()).getId()));
						claimDDDetails.setUrn(dedupeDataResponse.getUrn());
						claimDDDetails.setClaimStatus(Long.valueOf(dedupeDataResponse.getStatus()));
						claimDDDetails.setBeneficiaryBank(dedupeDataResponse.getBeneficiaryBank());
						claimDeDupProxy.setDedupeCheck(Boolean.TRUE);
						claimDeDupProxy.setIsMatchWith(claimDDDetails);
						return (U) new ClaimDeDupResProxyV3(CommonErrorMsg.Common.SUCCESS, claimDeDupProxy,
								HttpStatus.OK.value(), Boolean.TRUE);
					}
				}
			} catch (Exception e) {
				log.error("Error while deDupeLogicInDD() ", e);
			}

			/** GET NOMINEE DETAILS */
			ClaimDedupMatchWithResProxyV3 claimDeDupeDetails = new ClaimDedupMatchWithResProxyV3();
			claimDeDupeDetails.setClaimStatus(master.getStatus().longValue());
			claimDeDupeDetails.setDateOfLoss(getDateOfLoss(master));
			claimDeDupeDetails.setIntimationDate(!OPLUtils.isObjectNullOrEmpty(master.getClaimDate()) ? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(master.getClaimDate()) : null);
			Long disabilityId = !OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getTypeOfDisabilityId())
					? NatureOfLoss.DISABILITY.getId().longValue()
					: null;
			claimDeDupeDetails.setType(!OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getDateOfDeath())
					? Long.valueOf(NatureOfLoss.DEATH.getId())
					: disabilityId);
			claimDeDupeDetails.setUrn(master.getUrn());
			claimDeDupeDetails.setBeneficiaryBank(master.getClmDetails().getClmPIDetails().getClmBankName());
			claimDeDupProxy.setIsMatchWith(claimDeDupeDetails);
			claimDeDupProxy.setDedupeCheck((deDupeResult.getSuccess().equals(Boolean.FALSE)) ? Boolean.TRUE : Boolean.FALSE);
			if(deDupeResult.getSuccess().equals(Boolean.TRUE)) {
				return (U) new ClaimDeDupResProxyV3(CommonErrorMsg.Common.SUCCESS,
										new ClaimDeDupDataResProxyV3().toBuilder().dedupeCheck(Boolean.FALSE).build(), HttpStatus.OK.value(), Boolean.TRUE);
			}else {				
				return (U) setCommonRes(claimDeDupProxy, commonResponse);
			}

		} catch (Exception e) {
			log.error("Error while getClaimDedupeData() ", e);
		}
		return (U) new ClaimDeDupResProxyV3(CommonErrorMsg.Common.FAILED, claimDeDupProxy, HttpStatus.BAD_REQUEST.value(),
				Boolean.FALSE);
	}
	
	public com.opl.jns.ere.domain.ClmDeDupeDetails saveDedupeDetails(ClmMaster master, ClaimDeDupReqProxyV3 dedupeRequest){
		com.opl.jns.ere.domain.ClmDeDupeDetails claimDeDupeDetails = new com.opl.jns.ere.domain.ClmDeDupeDetails();
		claimDeDupeDetails
				.setHospitalisationDate(!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getHospitalisationDate())
						? Date.from(dedupeRequest.getHospitalisationDate().atZone(ZoneId.systemDefault())
								.toInstant())
						: null);
		claimDeDupeDetails.setFIRNo(dedupeRequest.getFirNo());
		claimDeDupeDetails.setFIRDate(!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getFirDate())
				? Date.from(dedupeRequest.getFirDate().atZone(ZoneId.systemDefault()).toInstant())
				: null);
		claimDeDupeDetails.setPanchnamaNo(dedupeRequest.getPanchnamaNo());
		claimDeDupeDetails.setPanchnamaDate(!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getPanchnamaDate())
				? Date.from(dedupeRequest.getPanchnamaDate().atZone(ZoneId.systemDefault()).toInstant())
				: null);
		claimDeDupeDetails.setPostMortemReportNo(dedupeRequest.getPostMortemReportNo());
		claimDeDupeDetails.setPostMortemReportDate(
				!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getPostMortemReportDate()) ? Date.from(
						dedupeRequest.getPostMortemReportDate().atZone(ZoneId.systemDefault()).toInstant())
						: null);
		claimDeDupeDetails
				.setDeathDisabilityCertificateReportNo(dedupeRequest.getDeathordisabilitycertificateReportNo());
		claimDeDupeDetails.setDeathDisabilityCertificateReportDate(
				!OPLUtils.isObjectNullOrEmpty(dedupeRequest.getDeathordisabilityCertificateReportDate())
						? Date.from(dedupeRequest.getDeathordisabilityCertificateReportDate()
								.atZone(ZoneId.systemDefault()).toInstant())
						: null);
		claimDeDupeDetails.setClaimMaster(master);
		claimDeDupeDetails.setIsActive(Boolean.TRUE);
		claimDeDupeDetails.setCreatedBy(master.getCreatedBy());
		claimDeDupeDetails.setCreatedDate(new Date());
		return clmDeDupeDetailsRepository
				.save(claimDeDupeDetails);
	}
	
	/**SET COMMON RESPONSE*/
	public ClaimDeDupResProxyV3 setCommonRes(ClaimDeDupDataResProxyV3 claimDeDupProxy, RegistryResponse commonResponse) {
		return new ClaimDeDupResProxyV3(!OPLUtils.isObjectNullOrEmpty(commonResponse) ? commonResponse.getMessage()
						: CommonErrorMsg.Common.SUCCESS,
						claimDeDupProxy, HttpStatus.OK.value(), Boolean.TRUE);
	}
	
	/**GET NATURE OF LOSS*/
	public String getDateOfLoss(ClmMaster master) {
		try {
			if (master.getSchemeId().intValue() == SchemeMaster.PMSBY.getId()) {
				if (!OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getNatureOfLossId())
						&& master.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
					return CommonUtils.sdf.format(master.getClmDetails().getDateOfDeath());
				} else {
					return CommonUtils.sdf.format(master.getClmDetails().getDateTimeOfAccident());
				}

			} else if (master.getSchemeId().intValue() == SchemeMaster.PMJJBY.getId()) {
				return CommonUtils.sdf.format(master.getClmDetails().getDateOfDeath());
			}
		} catch (Exception e) {
			log.error("Error while getDateOfLoss() ", e);
		}
		return null;
	}
	
	/**CHECK DE DUPE LOGIC*/
	private RegistryResponse deDupeLogicForClaim(ClmMaster claimMaster) {
		if (SchemeMaster.PMJJBY.getId().intValue() == claimMaster.getSchemeId()) {
			long dateDiff = DateUtils.dateDiff(claimMaster.getClmDetails().getDateOfDeath(),
					claimMaster.getFirstEnrollmentDate());
			if (dateDiff > 30) {
				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
					return new RegistryResponse(CommonUtils.CLAIM_DEATH_PAID_MSG, HttpStatus.CREATED.value(), false);
				} else {
					return new RegistryResponse(CommonUtils.CLAIM_DEATH_MSG, HttpStatus.CREATED.value(), false);
				}
			} else {
				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
					return new RegistryResponse(CommonUtils.CLAIM_ACCIDENTIAL_PAID_MSG, HttpStatus.CREATED.value(),
							false);
				} else {
					return new RegistryResponse(CommonUtils.CLAIM_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(), false);
				}
			}
		} else {
			/** PMSBY Multi Claim Validation check(Max 2 claim allowed) */
			List<Integer> statusList = new ArrayList<>();
			statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
			statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
			Long count = clmMasterRepo.countByApplicationIdAndIsActiveTrueAndStatusIn(
					claimMaster.getApplicationId(), statusList);
			if (!OPLUtils.isObjectNullOrEmpty(count) && count >= CommonUtils.LONG_2) {
				return new RegistryResponse(CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),
						false);
			} else {
				statusList.clear();
				statusList.add(ClaimStatus.CLAIM_IN_PROGRESS.getId());
				count = clmMasterRepo.countByApplicationIdAndIsActiveTrueAndStatusIn(
						claimMaster.getApplicationId(), statusList);
				if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
					return new RegistryResponse(CommonUtils.CLAIM_SUBMISSION_IN_PROGRESS_MSG, HttpStatus.CREATED.value(),
							false);
				}
			}
		}
		return new RegistryResponse(CommonUtils.PROCEED, HttpStatus.CREATED.value(), true);
	}
	
	
	public ClaimDedupApiResponse deDupeLogicInDD(ClmMaster claimMaster,ClaimDeDupReqProxyV3 dedupeRequest) {
		return deDupeRegistryUtility.callClaimDedupeRequest(claimMaster,dedupeRequest);
	}
	
	public RegistryResponse setDedupeCommonResponse(ClaimDeDupDataResProxyV3 claimDeDupProxy, RegistryResponse commonResponse) {
		claimDeDupProxy.setDedupeCheck(Boolean.FALSE);
		claimDeDupProxy.setIsMatchWith(new ClaimDedupMatchWithResProxyV3());
		return new RegistryResponse(commonResponse.getSuccess().equals(Boolean.FALSE) ? commonResponse.getMessage()
				: CommonErrorMsg.Common.SUCCESS, claimDeDupProxy, HttpStatus.OK.value(), Boolean.TRUE);
	}
	
	public ClmMaster updateStatusFromPublish(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, ClmMaster claimMaster) {
		try {
			log.info("Enter into updateStatusFromPublish() :::");
			claimMaster.setStatus(updateAppClaimRequest.getClaimStatus());
			if (!OPLUtils
					.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails()) && updateAppClaimRequest.getClaimStatus()==ClaimStatus.CLAIM_ACCEPTED.getId()) {
				claimMaster.setTransactionUTR(updateAppClaimRequest.getTransactionDetails().getTransactionUTR());
				claimMaster.setTransactionAmount(updateAppClaimRequest.getTransactionDetails().getTransactionAmount());
				if (!OPLUtils
						.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails().getTransactionTimeStamp())) {
					Date dateOfTransaction = Date.from(updateAppClaimRequest.getTransactionDetails()
							.getTransactionTimeStamp().atZone(ZoneId.systemDefault()).toInstant());
					claimMaster.setTransactionTimeStamp(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss
							.parse(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(dateOfTransaction)));
				}	
			}
			
			claimMaster.setIsPortalThroughUpdatedStatus(false);
			claimMaster.setModifiedDate(new Date());
			claimMaster.setInsurerClaimId(updateAppClaimRequest.getClaimId());
			claimMaster.setInsurerStatus(updateAppClaimRequest.getInsurerStatus());
			if (updateAppClaimRequest.getClaimStatus() == ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()
					|| updateAppClaimRequest.getClaimStatus() == ClaimStatus.CLAIM_REJECTED.getId()) {
				claimMaster.setStatusReasonId(updateAppClaimRequest.getReason());
			}
			/**FIRST BANK CLAIM STATUS PUSH FLAG SET FALSE*/
			claimMaster.setIsBankClaimStatusPush(false);
			clmMasterRepository.save(claimMaster);

			/**AFTER UPDATE STATUS SEND SMS*/
			sendSms(claimMaster);
			
			return claimMaster;
		} catch (Exception e) {
			log.error("Error while updateStatusFromPublish()", e);
		}
		return null;
	}
	
	public void sendSms(ClmMaster claimMaster) {
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails())
				&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getClmPIDetails())) {
				if (claimMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().longValue()
						|| (claimMaster.getSchemeId() == SchemeMaster.PMSBY.getId().longValue() && claimMaster
								.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId()))) {
					sendNotificationInCaseOfStatusUpdate(
							setEmailParameters(
									OPLUtils.isObjectNullOrEmpty(claimMaster.getUrn()) ? null : claimMaster.getUrn(),
									OPLUtils.isObjectNullOrEmpty(
											claimMaster.getClmDetails().getClmPIDetails().getApFirstName())
													? null
													: claimMaster.getClmDetails().getClmPIDetails().getApFirstName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getSchemeId())
											? null
											: SchemeMaster.getById(Long.valueOf(claimMaster.getSchemeId()))
													.getShortName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getStatus())
											? null
											: ClaimStatus.fromId(claimMaster.getStatus()).getShortValue(),
									applicationMasterOtherDetailsRepository
											.getSouceByApplicationId(claimMaster.getApplicationId()),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId()) ? null
											: claimMaster.getOrgId()),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApEmail()) ? null
									: claimMaster.getClmDetails().getApEmail(),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getClmMobile())
									? claimMaster.getClmNomineeDetails().getMobileNumber()
									: claimMaster.getClmDetails().getClmMobile());
				} else if (claimMaster.getSchemeId() == SchemeMaster.PMSBY.getId().longValue()
						&& claimMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())) {
					sendNotificationInCaseOfStatusUpdate(
							setEmailParameters(
									OPLUtils.isObjectNullOrEmpty(claimMaster.getUrn()) ? null : claimMaster.getUrn(),
									OPLUtils.isObjectNullOrEmpty(
											claimMaster.getClmDetails().getClmPIDetails().getApFirstName())
													? null
													: claimMaster.getClmDetails().getClmPIDetails().getApFirstName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getSchemeId()) ? null
											: SchemeMaster.getById(Long.valueOf(claimMaster.getSchemeId()))
													.getShortName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getStatus())
											? null
											: ClaimStatus.fromId(claimMaster.getStatus()).getShortValue(),
									applicationMasterOtherDetailsRepository
											.getSouceByApplicationId(claimMaster.getApplicationId()),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId()) ? null
											: claimMaster.getOrgId()),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApEmail()) ? null
									: claimMaster.getClmDetails().getApEmail(),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApMobileNumber()) ? null
									: claimMaster.getClmDetails().getApMobileNumber());
				}
			}
	}
		
		 public void sendNotificationInCaseOfStatusUpdate(Map<String, Object> emailParameters, String toEmail, String toSms) {
		        log.info("entry in sendNotification()");

		        String[] toEmailAry = {toEmail};
		        String[] toSmsAry = {91 + toSms};

		        NotificationRequest notificationRequest = new NotificationRequest();
		        if (!OPLUtils.isObjectNullOrEmpty(toEmail)) {
		            Notification emailNoti = NotificationClient.prepareRequestForSmsOrEmail(toEmailAry, emailParameters, JnsNotificationMasterUtil.EMAIL_CUST_CLAIM_SETTLEMENT_SUCESS, null, NotificationType.EMAIL);
		            notificationRequest.addNotification(emailNoti);
		        }
		        if (!OPLUtils.isObjectNullOrEmpty(toSms)) {
		            Long smstempId = null;
		            if (emailParameters.get("nameOfScheme").equals("PMSBY")) {
		                smstempId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMSBY;
		            } else {
		                smstempId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMJJBY;
		            }
		            Notification smsNoti = NotificationClient.prepareRequestForSmsOrEmail(toSmsAry, emailParameters, smstempId, null, NotificationType.SMS);
		            notificationRequest.addNotification(smsNoti);
		        }

		        if (!OPLUtils.isListNullOrEmpty(notificationRequest.getNotifications()) && !notificationRequest.getNotifications().isEmpty()) {
		            notificationClient.send(notificationRequest);
		            log.info("Notification sent successfully");
		        }

		    }
		 
		    public Map<String, Object> setEmailParameters(String urn, String claimaintName, String schemeName, String status,Integer source,Long orgId) {
		        log.info("entry in emailParameters()");
		        Map<String, Object> emailParameters = new HashMap<>();
		        emailParameters.put("claimaintName", claimaintName);
		        emailParameters.put("statusUpdate", status);
		        emailParameters.put("nameOfScheme", schemeName);
		        emailParameters.put("urn", urn.substring(4));
		        emailParameters.put("source", source);
		        emailParameters.put("orgId", orgId);
		        return emailParameters;
		    }

}
