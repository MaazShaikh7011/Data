package com.opl.jns.registry.service.service.publish.common.impl;

import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.*;
import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.service.publish.common.MisServiceV3;
import com.opl.jns.registry.service.utils.v3.MisAsyncComponent;
import com.opl.jns.registry.service.utils.v3.MisEnrollmentValidations;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.opl.jns.registry.service.utils.GetCommonData.STATE_DISTRICT_LIST;

@Service("MisServiceImplV3")
@Slf4j
public class MisServiceImplV3 implements MisServiceV3 {

    public static final long MIS_API_DATA_PROD_MAP_ID = 89L;
    @Autowired
    private MisEnrollmentValidations misEnrollmentValidations;

    @Autowired
    private DMSClient dmsClient;

    @Autowired
    private MisAsyncComponent misAsyncComponent;

    /**
     * Mission office enrollment api
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T extends RegistryReqProxy, U extends APIResponseV3> U misEnrollmentDetails(T t) {
        try {
            MisEnrollmentReqV3 misEnrollmentReq = (MisEnrollmentReqV3) t;
            String validationMsg = misEnrollmentValidations.checkBasicValidation(misEnrollmentReq);
            if (!OPLUtils.isObjectNullOrEmpty(validationMsg)) {
                return (U) new MisEnrollmentResProxyV3(validationMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, uploadRequestInDMS(misEnrollmentReq));
            }

            log.info("Calling uploadRequestInDMS() ----------> ");
            Long storageId = uploadRequestInDMS(misEnrollmentReq);
            if (storageId == null) {
                return (U) new MisEnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(), "Technical error!!", Boolean.FALSE);
            }
            log.info("Calling misAsyncComponent.saveRequestedData() with storageId ----------> {}", storageId);
            misEnrollmentReq.setStorageId(storageId);
            misAsyncComponent.saveRequestedData(misEnrollmentReq);

            return (U) new MisEnrollmentResProxyV3(Constants.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE, storageId);
        } catch (Exception e) {
            log.error("EXCEPTION IS GETTING WHILE misEnrollmentDetails ---> ", e);
            return (U) new MisEnrollmentResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), Constants.FAILED, Boolean.FALSE);
        }
    }

    private Long uploadRequestInDMS(MisEnrollmentReqV3 misEnrollmentReq) throws IOException, DocumentException {
        log.info("In uploadRequestInDMS() ----------> ");

        String fileName = misEnrollmentReq.getOrgId() + "_" + misEnrollmentReq.getToken() + ".txt";
        String data = MultipleJSONObjectHelper.getStringfromObject(misEnrollmentReq);
        MultipartFile multipartFile = new MockMultipartFile("Mis Request Data", fileName, MediaType.TEXT_PLAIN_VALUE, data.getBytes());

        // CREATE REQUEST FOR DMS
        DocumentRequest documentRequest = new DocumentRequest();
        documentRequest.setUserType("user");
        documentRequest.setProductDocumentMappingId(MIS_API_DATA_PROD_MAP_ID);
        documentRequest.setOriginalFileName(fileName);

        log.info("Calling dmsClient.uploadFile() -----------> ");
        DocumentResponse documentResponse = dmsClient.uploadFile(MultipleJSONObjectHelper.getStringfromObject(documentRequest), multipartFile);
        if (!OPLUtils.isObjectNullOrEmpty(documentResponse)
                && Objects.equals(documentResponse.getStatus(), HttpStatus.OK.value())
                && !OPLUtils.isObjectNullOrEmpty(documentResponse.getData())) {
            StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
            return storageDetailsResponse.getId();
        } else {
            log.info("Document Failure Response --------------> {}", documentResponse);
        }
        return null;
    }

    @Override
    public CommonResponse getDistrictWiseData(Long counter, Long startsFrom, String type) {
        List<DistrictWiseData> districtList = new ArrayList<>(STATE_DISTRICT_LIST.size());
        try {
            DistrictWiseData districtWiseData;
            for (int i = 0; i < STATE_DISTRICT_LIST.size(); i++) {
                districtWiseData = new DistrictWiseData();
                if (i != 0) {
                    startsFrom = startsFrom + counter;
                }
                districtWiseData.districtCode = STATE_DISTRICT_LIST.get(i).getLgdDistrictCode();

                districtWiseData.pmsby = new Pmsby();
                getData(startsFrom, type, districtWiseData.pmsby);

                startsFrom = startsFrom + counter;

                districtWiseData.pmjjby = new Pmjjby();
                getData(startsFrom, type, districtWiseData.pmjjby);

                districtList.add(districtWiseData);
            }
            return new CommonResponse("Data found successfully.", districtList, HttpStatus.OK.value(), true);
        } catch (Exception e) {
            return new CommonResponse("This application has encountered some error, please try after sometimes.", HttpStatus.INTERNAL_SERVER_ERROR.value(), true);
        }
    }

    private <T extends MisCommonProxy> void getData(Long count, String type, T misCommonProxy) {
        misCommonProxy.elgSvngAccHldr = count;
        misCommonProxy.elgPMJDYHldr = ++count;
        misCommonProxy.ruralMale = ++count;
        misCommonProxy.ruralFemale = ++count;
        misCommonProxy.ruralTransG = ++count;
        misCommonProxy.urbanFemale = ++count;
        misCommonProxy.urbanMale = ++count;
        misCommonProxy.urbanTransG = ++count;
        misCommonProxy.totalEnrolment = ++count;
        misCommonProxy.prmclctdruralMale = ++count;
        misCommonProxy.prmclctdruralFemale = ++count;
        misCommonProxy.prmclctdruralTransG = ++count;
        misCommonProxy.prmclctdurbanFemale = ++count;
        misCommonProxy.prmclctdurbanMale = ++count;
        misCommonProxy.prmclctdurbanTransG = ++count;
        misCommonProxy.totalPrmclctdNwErollment = ++count;
        misCommonProxy.recordsTransmittedToInsurer = ++count;
        misCommonProxy.premiumPaidToInsurer = ++count;
        misCommonProxy.aadharSeeded = ++count;
        misCommonProxy.mobileSeeded = ++count;
        misCommonProxy.emailSeeded = ++count;
        misCommonProxy.pmjdyEnrolled = ++count;
        misCommonProxy.mgnregaEnrolled = ++count;
        misCommonProxy.mudraEnrolled = ++count;
        misCommonProxy.kccEnrolled = ++count;
        misCommonProxy.otherSchemeEnrolled = ++count;
        if (type.equalsIgnoreCase("renewal")) {
            misCommonProxy.insufficientAcHolders = ++count;
        }

        misCommonProxy.caste = new Caste();
        misCommonProxy.caste.general = ++count;
        misCommonProxy.caste.obc = ++count;
        misCommonProxy.caste.sc = ++count;
        misCommonProxy.caste.st = ++count;

        misCommonProxy.nomineeAvlb = ++count;
        misCommonProxy.frshEnrol1JuneCrrntYear = ++count;
        misCommonProxy.renewals1JuneCrrntYear = ++count;
        misCommonProxy.insufficientAcHolders = ++count;
        misCommonProxy.prmdebitedRs = ++count;
        if (type.equalsIgnoreCase("renewal")) {
            misCommonProxy.prmdebitedRs = ++count;
        }
    }
}
