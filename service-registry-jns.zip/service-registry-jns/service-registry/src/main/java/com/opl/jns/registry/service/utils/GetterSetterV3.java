package com.opl.jns.registry.service.utils;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReqV3;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.UpdateTransactionRequestV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.ere.domain.ClmAddressMaster;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmNomineeDetails;
import com.opl.jns.ere.domain.ClmNomineePIDetails;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.oneform.api.model.PincodeMasterResponse;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
	public class GetterSetterV3 {
	
		@Autowired
		private OneFormClient oneFormClient;
		
		public static final int INT_1900 = 1900;

		/**
		 * PREPARE CLAIM MASTER ENTITY WHILE SAVING CLAIM MASTER API V3
		 *
		 * @param appMaster
		 * @param claimRequest
		 * @param orgId
		 * @param branchDetails
		 * @param schemeId
		 * @param userId
		 * @return
		 */
		public ClmMaster setClmMaster(ApplicationMasterBothSchemeProxy appMaster,
									  ClaimDetailsReqProxyV3 claimRequest, Long orgId, BranchBasicDetailsRequest branchDetails, Integer schemeId, Long userId) {
			log.info("Saving clm Master for req {}--------and-----application master--> {} "+claimRequest,appMaster);
			
			ClmMaster clmMaster = new ClmMaster();
			clmMaster.setUrn(claimRequest.getUrn());
			clmMaster.setApplicationId(appMaster.getId());
			clmMaster.setOrgId(orgId);
			clmMaster.setSchemeId(schemeId);
			
			clmMaster.setFirstEnrollmentDate(appMaster.getEnrollmentDate());
			clmMaster.setBranchId(branchDetails.getId());
			clmMaster.setStatus(ClaimStatus.CLAIM_IN_PROGRESS.getId());
			clmMaster.setStageId(ClaimStageMaster.CLAIM_FORM.getStageId());
			clmMaster.setIsActive(Boolean.TRUE);
			clmMaster.setCreatedBy(userId);
			clmMaster.setCreatedDate(new Date());
			clmMaster.setSource(Source.OTHER_CHANNEL.getId());
//			clmMaster.setModifiedDate(new Date());
			clmMaster.setInsurerOrgId(appMaster.getInsurerOrgId());
	 
			// Set policy details  -- on hold
//			setClmMasterPolicyDetails(clmMaster, appMaster);
	
			// Set branch details
			setClmMasterBranchDetails(clmMaster,branchDetails);
	
	//			clmMaster.setAmountOfTransaction(null);
	//			clmMaster.setClaimAmount(null);
	//			clmMaster.setInsurerClaimId(null);
	//			clmMaster.setInsurerReason(null);
	//			clmMaster.setInsurerStatus(null);
	//			clmMaster.setMessage(null);
	//			clmMaster.setStatusReason(null);
	//			clmMaster.setStatusReasonId(null);
	//			clmMaster.setTransactionUtr(null);
	
	//			clmMaster.setDateOfTransaction(null);
	//			clmMaster.setQueriedStorageId(null);
	//			clmMaster.setIsBankClaimStatusPush(null);
	//			clmMaster.setIsInsurerClaimStatusPush(null);
	
			return clmMaster;
		}
	
		/// on hold for claim upload document 
		/**
		 * PREPARE CLAIM MASTER POLICY DETAILS WHILE SAVING CLAIM MASTER API V3
		 * 
		 * @param clmMaster
		 * @param applicationMaster
		 * @param claimRequest
		 * @return
		 */
//		public void setClmMasterPolicyDetails(ClmMaster clmMaster, ApplicationMasterBothSchemeProxy appMaster) {
//			clmMaster.setPolicyYear(fetchPolicyYear(appMaster.getCompletionDate()));
//			clmMaster.setFinancialYear(fetchFinancialYear(appMaster.getCompletionDate()));
//			clmMaster.setPolicyMonth(fetchMonth(appMaster.getCompletionDate()));
//			clmMaster.setFinancialMonth(fetchMonth(appMaster.getCompletionDate()));
//			clmMaster.setPolicyDay(fetchDay(appMaster.getCompletionDate()));
//			clmMaster.setFinancialDay(fetchDay(appMaster.getCompletionDate()));
//		}
	

		/**
		 * PREPARE CLAIM MASTER BRANCH DETAILS WHILE SAVING CLAIM MASTER API V3
		 *
		 * @param clmMaster
		 * @param branchDetails
		 */
		public void setClmMasterBranchDetails(ClmMaster clmMaster, BranchBasicDetailsRequest branchDetails) {
			log.info("Saving clm master branch details--------------->");
			clmMaster.setBranchRoId(branchDetails.getRoId());
			clmMaster.setBranchZoId(branchDetails.getZoId());
			clmMaster.setBranchLhoId(!OPLUtils.isObjectNullOrEmpty(branchDetails.getLhoId()) ? Long.valueOf(branchDetails.getLhoId()) : null);
			clmMaster.setBranchCityId(
					!OPLUtils.isObjectNullOrEmpty(branchDetails.getCityId()) ? branchDetails.getCityId().longValue()
							: null);
			clmMaster.setBranchStateId(
					!OPLUtils.isObjectNullOrEmpty(branchDetails.getStateId()) ? branchDetails.getStateId().longValue()
							: null);
		}
	
		/**
		 * PREPARE CLAIM DETAILS WHILE SAVING CLAIM DETAILS API V3
		 * 
		 * @param clmMaster
		 * @param claimRequest
		 * @param branchDetails
		 * @return
		 */
		public ClmDetails setClmDetails(ClmMaster clmMaster, ClaimDetailsReqProxyV3 claimRequest,BranchBasicDetailsRequest branchDetails) {
			log.info("Saving clm details--------------->");
			ClmDetails clmDetails = new ClmDetails();
	
			// Address details set
			ClmAddressMaster address = new ClmAddressMaster();
			address.setCityName(claimRequest.getCity());
			address.setDistrict(claimRequest.getDistrict());
			address.setStateName(claimRequest.getState());
	
			if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getPincode())) {
				try {
					address.setPincode(claimRequest.getPincode());
					PincodeMasterResponse pincodeMaster = oneFormClient
							.getFirstPincodeMasterDetailsByPincode(claimRequest.getPincode().toString());
					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
						address.setCityId(pincodeMaster.getCityId());
						address.setStateId(pincodeMaster.getStateId());
					}
				} catch (Exception e) {
					log.info("Exception while getting pincode details ", e);
				}
			}
	
			// Applicant details set
			clmDetails.setId(clmMaster.getId());
			clmDetails.setApAddressMaster(address);
			clmDetails.setApEmail(claimRequest.getEmailId());
			clmDetails.setApMobileNumber(claimRequest.getMobileNumber());
			clmDetails.setApCustomerIfsc(claimRequest.getCustomerIFSC());
			
//			ApplicantInfoV2 applicantInfo = applicantInfoRepoV2.findById(clmMaster.getApplicationId()).orElse(null);
//			if(!OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
//				clmDetails.setApDisabilityDetails(applicantInfo.getDisabilityDetails());
//				clmDetails.setApDisabilityStatus(applicantInfo.getDisabilityStatus());
//				clmDetails.setApFatherHusbandName(applicantInfo.getFatherHusbandName());
//			}

			clmDetails.setApGenderId(OPLUtils.isObjectNullOrEmpty(claimRequest.getGender()) ? null
					: Gender.fromBankValue(claimRequest.getGender()).getId());
			clmDetails.setClmGenderId(OPLUtils.isObjectNullOrEmpty(claimRequest.getClaimantGender()) ? null :
					Gender.fromBankValue(claimRequest.getClaimantGender()).getId());
	
			log.info("Saving Claimant details--------------->");
			// Claimant details set
			clmDetails.setClmRelationId(OPLUtils.isObjectNullOrEmpty(claimRequest.getRelationshipOfClaimant()) ? null
					: RelationShip.fromValue(claimRequest.getRelationshipOfClaimant()).getId());
			clmDetails.setClmEmail(claimRequest.getClaimantEmailId());
			clmDetails.setClmMobile(claimRequest.getClaimantMobileNumber());
			
			clmDetails.setIsClaimantSame(!OPLUtils.isObjectNullOrEmpty(claimRequest.getIsNomineePredeceased())
					&& claimRequest.getIsNomineePredeceased().equalsIgnoreCase(YesNo.YES.getValue()));
			
			clmDetails.setIsNomineeNameCorrection(!OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeNameCorrection())
					&& claimRequest.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue()));
	
			// Common details set
			clmDetails.setBranchCode(branchDetails.getCode());
			clmDetails.setBranchEmailId(claimRequest.getBankBranchEmailId());
			clmDetails.setDateOfDeath(OPLUtils.isObjectNullOrEmpty(claimRequest.getDateOfDeath()) ? null
					: Date.from(claimRequest.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant()));
			clmDetails.setDateTimeOfAccident(OPLUtils.isObjectNullOrEmpty(claimRequest.getDateOfAccident()) || OPLUtils.isObjectNullOrEmpty(claimRequest.getTimeOfAccident())
					? null: Date.from(LocalDateTime.of(claimRequest.getDateOfAccident(),
					LocalTime.parse(claimRequest.getTimeOfAccident())).atZone(ZoneId.systemDefault()).toInstant()));
			clmDetails.setDayOfAccident(claimRequest.getDayOfAccident());
			if (clmMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()) {
				clmDetails.setCauseOfDeathDisabilityId(
						OPLUtils.isObjectNullOrEmpty(claimRequest.getCauseOfDeath()) ? null
								: CauseOfDeathDisabilityV2.fromBankValue(claimRequest.getCauseOfDeath()).getId());
				
			}else {
			clmDetails.setCauseOfDeathDisabilityId(
					OPLUtils.isObjectNullOrEmpty(claimRequest.getCauseOfDeathDisability()) ? null
							: CauseOfDeathDisabilityV2.fromBankValue(claimRequest.getCauseOfDeathDisability()).getId());
			}
			clmDetails.setNatureOfLossId(OPLUtils.isObjectNullOrEmpty(claimRequest.getNatureOfAccident()) ? null
					: NatureOfLoss.fromBankValue(claimRequest.getNatureOfAccident()).getId());
			clmDetails.setTypeOfDisabilityId(OPLUtils.isObjectNullOrEmpty(claimRequest.getTypeOfDisability()) ? null
					: TypeOfDisability.fromBankValue(claimRequest.getTypeOfDisability()).getId());
			clmDetails.setPlaceOfOccurrence(claimRequest.getPlaceOfOccurence());
	
			clmDetails.setPremDebitDate(OPLUtils.isObjectNullOrEmpty(claimRequest.getPremDebitDate()) ? null
					: Date.from(claimRequest.getPremDebitDate().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			clmDetails.setPremRemitDate(OPLUtils.isObjectNullOrEmpty(claimRequest.getPremRemitDate()) ? null
					: Date.from(claimRequest.getPremRemitDate().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			clmDetails.setDateOfLodgingClaim(OPLUtils.isObjectNullOrEmpty(claimRequest.getDateOfLodgingClaim()) ? null
					: Date.from(claimRequest.getDateOfLodgingClaim().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			clmDetails.setBranchCode(claimRequest.getBranchCode());
			clmDetails.setBranchEmailId(claimRequest.getBankBranchEmailId());
			clmDetails.setClmMaster(clmMaster);
			
			return clmDetails;
			
	//			// set scheme wise fields
	//			if (applicationMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()) {
	//				detail.setDateOfDeath(Date.from(claimRequest.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant()));
	//				detail.setCauseOfDeathDisabilityId(
	//						CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeath()).getId());
	//				if (detail.getCauseOfDeathDisability() == CauseOfDeathDisability.ACCIDENTAL_30_DAYS) {
	//					detail.setDateTimeOfAccident(Date.from(LocalDateTime
	//							.of(claimRequest.getDateOfAccident(), LocalTime.parse(claimRequest.getTimeOfAccident()))
	//							.atZone(ZoneId.systemDefault()).toInstant()));
	//				}
	//			} else if (applicationMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue()) {
	//				detail.setDayOfAccident(claimRequest.getDayOfAccident());
	//				detail.setLocationOfLoss(claimRequest.getPlaceOfOccurence());
	//				detail.setNatureOfLossId(NatureOfLoss.fromBankValue(claimRequest.getNatureOfAccident()).getId());
	//				if (claimRequest.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
	//					detail.setTypeOfDisablityId(TypeOfDisability.fromBankValue(claimRequest.getTypeOfDisability()).getId());
	//				}
	//				detail.setDateTimeOfAccident(Date.from(LocalDateTime
	//						.of(claimRequest.getDateOfAccident(), LocalTime.parse(claimRequest.getTimeOfAccident()))
	//						.atZone(ZoneId.systemDefault()).toInstant()));
	//				detail.setCauseOfDeathDisabilityId(
	//						OPLUtils.isObjectNullOrEmpty(claimRequest.getCauseOfDeathDisability()) ? null
	//								: CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeathDisability()).getId());
	//			}
	
			// kyc details
	//			Integer[] kycId = new Integer[1];
	//			KycDocument kycDocument1 = KycDocument.fromBankValue(claimRequest.getClaimantKYC1());
	//			kycId[0] = kycDocument1.getId();
	//			setKycDocument(kycDocument1.getId(), detail, claimRequest.getClaimantKYCNumber1());
	//			detail.setKycDocId(Arrays.toString(kycId).replace("[", "").replace("]", ""));
	//			detail.setClaimantBankAccountNumber(claimRequest.getClaimantBankAccountNumber());
	//			detail.setCustIfscCode(claimRequest.getCustomerIFSC());
	//			
	//			// saving existing nominee changes
	//			List<NomineeDetails> nomineeDetails = new ArrayList<>();
	//			nomineeDetails.add(existingNominee);
	//			// append guardian and claimant
	//			setClaimantAndGuardianDetailsV3(applicationMaster, claimRequest, nomineeDetails);
	//			applicationMaster.setNomineeDetails(nomineeDetails);
	//			applicationMaster = applicationMasterRepository.save(applicationMaster);
	//			claimMaster.setApplicationMaster(applicationMaster);
	//			detail.setClaimMaster(claimMaster);
	//			claimMaster.setClaimDetail(detail);
	
		}


		/**
		 * PREPARE CLAIM PI DETAILS WHILE SAVING CLAIM PI DETAILS API V3
		 *
		 * @param claimRequest
		 * @param clmMaster
		 * @param appMaster
		 * @return
		 */
		public ClmPIDetails setClmPIDetails(ClaimDetailsReqProxyV3 claimRequest, ClmMaster clmMaster,
				ApplicationMasterBothSchemeProxy appMaster) {
			log.info("Saving clm master pi details--------------->");
			ClmPIDetails piDetails = new ClmPIDetails();
	
			// Applicant PI details set
			piDetails.setId(clmMaster.getId());
			piDetails.setApAccountNumber(claimRequest.getCustomerAccountNumber());
			
			piDetails.setApCif(claimRequest.getCif());
			piDetails.setAcHolderName(claimRequest.getAccountHolderName());
			piDetails.setApKycId1(claimRequest.getKycId1());
			piDetails.setApKycIdNumber1(claimRequest.getKycID1number());
			piDetails.setApPan(claimRequest.getPanNumber());
			piDetails.setApAadhaar(claimRequest.getAadhaarNumber());
			piDetails.setApCkycNumber(claimRequest.getCkycNumber());
			piDetails.setApDob(OPLUtils.isObjectNullOrEmpty(claimRequest.getDob()) ? null
					: Date.from(claimRequest.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()));
//			piDetails.setApGenderId(OPLUtils.isObjectNullOrEmpty(claimRequest.getGender()) ? null
//					: Gender.fromBankValue(claimRequest.getGender()).getId());
			piDetails.setApAddressLine1(claimRequest.getAddressline1());
			piDetails.setApAddressLine2(claimRequest.getAddressline2());
	
			// Claimant PI details set
			piDetails.setClmName(claimRequest.getClaimantName());
			piDetails.setClmDob(OPLUtils.isObjectNullOrEmpty(claimRequest.getClaimantDateOfBirth()) ? null
					: Date.from(claimRequest.getClaimantDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			piDetails.setClmAddress(claimRequest.getClaimantAddress());
			piDetails.setClmAccountNumber(claimRequest.getClaimantBankAccountNumber());
			piDetails.setClmBankName(claimRequest.getClaimantBankName());
			piDetails.setClmBranchIfsc(claimRequest.getClaimantBranchIFSC());
//			piDetails.setClmGenderId(OPLUtils.isObjectNullOrEmpty(claimRequest.getClaimantGender()) ? null :
//				 Gender.fromBankValue(claimRequest.getClaimantGender()).getId());
			
			// kyc details
			if(!OPLUtils.isObjectNullOrEmpty(claimRequest.getClaimantKYC1())) {
				Integer[] kycId = new Integer[2];
				KycDocument kycDocument1 = KycDocument.fromBankValue(claimRequest.getClaimantKYC1());
				kycId[0] = kycDocument1.getId();
				piDetails.setClmKycId1(kycId[0]);
				piDetails.setClmKycIdNumber1(claimRequest.getClaimantKYCNumber1());
			}
			piDetails.setApFatherHusbandName(claimRequest.getFatherHusbandName());
			return piDetails;
	
		}
	
		/**
		 * PREPARE CLAIM NOMINEE DETAILS WHILE SAVING CLAIM NOMINEE DETAILS API V3
		 * 
		 * @param clmMaster
		 * @param claimRequest
		 * @return
		 */
		public ClmNomineeDetails setClmNomineeDetails(ClaimDetailsReqProxyV3 claimRequest, ClmMaster clmMaster) {
			log.info("Saving clm master nominee details--------------->");
			ClmNomineeDetails nominee = new ClmNomineeDetails();
			
			// nominee Details set
			nominee.setClmMaster(clmMaster);
			nominee.setClmAddressMaster(null);
			nominee.setRelationId(OPLUtils.isObjectNullOrEmpty(claimRequest.getRelationshipOfNominee())? null : 
				RelationShip.fromValue(claimRequest.getRelationshipOfNominee()).getId());
			nominee.setMobileNumber(claimRequest.getNomineeMobileNumber());
			nominee.setEmail(claimRequest.getNomineeEmailId());
	
			// Guardian details set
			nominee.setGdRelationId(OPLUtils.isObjectNullOrEmpty(claimRequest.getRelationShipOfGuardian()) ? null
					: RelationShip.fromValue(claimRequest.getRelationShipOfGuardian()).getId());
			nominee.setGdMobile(claimRequest.getGuardianMobileNumber());
			nominee.setGdEmail(claimRequest.getGuardianEmailId());
			nominee.setModifiedDate(new Date());
			nominee.setIsActive(Boolean.TRUE);
			
			// Nominee PI details save
			log.info("Saving clm master nominee pi details--------------->");
			ClmNomineePIDetails nomineePI = new ClmNomineePIDetails();
			nomineePI.setName(claimRequest.getNomineeName());
			nomineePI.setAddressLine1(claimRequest.getAddressOfNominee());
			nomineePI.setDob(OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeDateOfBirth()) ? null
					: Date.from(claimRequest.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			nomineePI.setGdAddress(claimRequest.getAddressofGuardian());
			nomineePI.setGdName(claimRequest.getNameofGuardian());
			nominee.setNomineeGenderId(OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeGender()) ? null : Gender.fromBankValue(claimRequest.getNomineeGender()).getId());
			
			if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeNameCorrection())
					&& claimRequest.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
				nomineePI.setCorrectNomineeName(claimRequest.getCorrectNomineeName());	
			}
			nomineePI.setClmNomineeDetails(nominee);
			nominee.setClmNomineePIDetails(nomineePI);
			
			return nominee;
		}
		
		public PushClaimStatustoBankReqV3 prepareRequestForPushBankStatus(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, ClmMaster claimMasterV3) {
			PushClaimStatustoBankReqV3 bankReq=new PushClaimStatustoBankReqV3();				
			bankReq.setClaimId(updateAppClaimRequest.getClaimId());
			bankReq.setClaimReferenceId(updateAppClaimRequest.getClaimReferenceId());
			bankReq.setClaimStatus(updateAppClaimRequest.getClaimStatus());	
			bankReq.setInsurerStatus(updateAppClaimRequest.getInsurerStatus());
			bankReq.setReason(updateAppClaimRequest.getReason());
			bankReq.setUrn(updateAppClaimRequest.getUrn());
			bankReq.setOrgId(claimMasterV3.getOrgId());
			bankReq.setCommonUserId(claimMasterV3.getCreatedBy());
			bankReq.setApplicationId(claimMasterV3.getApplicationId());
			if(!OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails())) {
				UpdateTransactionRequestV3 transactionRequest=new UpdateTransactionRequestV3();
				transactionRequest.setTransactionAmount(updateAppClaimRequest.getTransactionDetails().getTransactionAmount());
				transactionRequest.setTransactionTimeStamp(updateAppClaimRequest.getTransactionDetails().getTransactionTimeStamp());
				transactionRequest.setTransactionUTR(updateAppClaimRequest.getTransactionDetails().getTransactionUTR());
				bankReq.setTransactionDetails(transactionRequest);
			}
			bankReq = WebHookClient.pushClmStausBnkManageRequest(bankReq);
			return bankReq;
		}
	
//		/**
//		 * PREPARE CLAIM NOMINEE PI DETAILS WHILE SAVING CLAIM NOMINEE PI DETAILS API V3
//		 * 
//		 * @param claimRequest
//		 * @param nominee
//		 * @return
//		 */
//		public ClmNomineePIDetails setClmNomineePIDetails(ClaimDetailsReqProxyV3 claimRequest) {
//			log.info("Saving clm master nominee pi details--------------->");
//			ClmNomineePIDetails nomineePI = new ClmNomineePIDetails();
//			nomineePI.setName(claimRequest.getNomineeName());
//			nomineePI.setDob(OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeDateOfBirth()) ? null
//					: Date.from(claimRequest.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
//			nomineePI.setGdAddress(claimRequest.getAddressofGuardian());
//			nomineePI.setGdName(claimRequest.getNameofGuardian());
//			
//			if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeNameCorrection())
//					&& claimRequest.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
//				nomineePI.setCorrectNomineeName(claimRequest.getCorrectNomineeName());	
//			}
//			return nomineePI;
//		
//		}
	
//		static int fetchPolicyYear(Date date) {
//			int currentMonth = date.getMonth();
//			int currentYear = date.getYear() + INT_1900;
//			if (currentMonth > Calendar.MAY) {
//				currentYear = currentYear + 1;
//			}
//	
//			return currentYear;
//		}
//	
//		static int fetchFinancialYear(Date date) {
//			int currentMonth = date.getMonth();
//			int currentYear = date.getYear() + INT_1900;
//			if (currentMonth > Calendar.MARCH) {
//				currentYear = currentYear + 1;
//			}
//	
//			return currentYear;
//		}
//	
//		static int fetchMonth(Date date) {
//			return date.getMonth() + 1;
//		}
//	
//		static int fetchDay(Date date) {
//			return date.getDate();
//		}
			
}
