//package com.opl.jns.registry.service.service.publish.v2;
//
//import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
//import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsReqProxyV2;
//import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV2;
//import com.opl.jns.registry.api.publish.v2.claimDetails.ClaimDetailsResProxyV2;
//
//import java.io.IOException;
//
//public interface ClaimServiceV2 {
//
//	public ClaimDetailsResProxyV2 saveClaimApi(ClaimDetailsReqProxyV2 claimRequest, Long orgId) throws Exception;
//
//	RegistryResponse getClaimdetailsByClaimUploadDocuments(ClaimUploadDocsReqProxyV2 claimUploadDocuments)
//			throws IOException;
//
//	boolean updateClaimStatusInsurerByJsForScheduler(Long claimId);
//
//}
