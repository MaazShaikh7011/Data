package com.opl.jns.registry.service.service.publish.common.impl;

import java.io.IOException;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequestV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.COIDocsProxyV3;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.lib.utils.ConfigProperties;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.service.publish.common.NomineeUpdateService;
import com.opl.jns.registry.service.utils.AsynUtils;
import com.opl.jns.registry.service.utils.GetterSetter;
import com.opl.jns.registry.service.utils.v2.EnrollmentValidation;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.model.COIRequest;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class NomineeUpdateServiceImpl implements NomineeUpdateService {

	@Autowired
	private PmsbyRepository pmsbyRepository;

	@Autowired
	private PmjjbyRepository pmjjbyRepository;

	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepositoryV2;

	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

	@Autowired
	private AddressMasterRepositoryV2 addressMasterRepositoryV2;

	@Autowired
	private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;

	@Autowired
	private NomineePIDetailsRepository nomineePIDetailsRepository;

	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;

	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private PDFGenerateClient pdfGenerateClient;

	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;

	@Autowired
	private ConfigProperties properties;
	
	@Autowired
	private EnrollmentValidation enrollmentValidation;
	
	@Autowired
	private ApplicationPushStatusRepo applicationPushStatusRepo;
	
	@Autowired
	private WebHookClient webHookClient;
	
	@Autowired
	private GetterSetter getterSetter;
	
	@Autowired
	private AsynUtils asynUtils;

	@Override
	public NomieeUpdateResponse updateNominee(NomineeUpdateRequest request) throws Exception {
		try {
			
			/**CHECK NOMINEE UPDATE VALIDATION*/
			String validateMsgV3 = enrollmentValidation.checkNomineeUpdateValidationsV3(request);
			if (!OPLUtils.isObjectNullOrEmpty(validateMsgV3)) {
				log.error("NOMINEE UPDATE FROM REQUEST-> {} ",
						MultipleJSONObjectHelper.getStringfromObject(request));
				return new NomieeUpdateResponse(validateMsgV3,null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			PMSBY pmsby = null;
			PMJJBY pmjjby = null;
			ApplicationMasterBothSchemeProxy mst = null;
			Long schemeId = OPLUtils.getSchemeIdFromUrn(request.getUrn());
			Long applicationId = OPLUtils.getApplicationIdFromUrn(request.getUrn());

			if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
				pmsby = pmsbyRepository.findByIdAndIsActiveTrue(applicationId);
				if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
					mst = MultipleJSONObjectHelper.getObjectFromObject(pmsby, ApplicationMasterBothSchemeProxy.class);
					mst.setSchemeId(SchemeMaster.PMSBY.getId());
				}
			} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId())) {
				pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(applicationId);
				if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
					mst = MultipleJSONObjectHelper.getObjectFromObject(pmjjby, ApplicationMasterBothSchemeProxy.class);
					mst.setSchemeId(SchemeMaster.PMJJBY.getId());
				}
			}

			if (OPLUtils.isObjectNullOrEmpty(mst)) {
				log.info("application Master Details not founds applicationId--> {} schemeId--> {}", applicationId,
						schemeId);
				return new NomieeUpdateResponse("application Master Details not founds applicationId",null,
						HttpStatus.BAD_REQUEST.value(),Boolean.FALSE);
			}

			ApplicantInfoV2 applicantInfoV2 = applicantInfoRepositoryV2.findById(applicationId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(applicantInfoV2)) {
				log.info("Account holder details not founds applicationId--> {}", applicationId);
				return new NomieeUpdateResponse(
						"Its seems we have not found account holder details from given application number!!",null,
						HttpStatus.BAD_REQUEST.value(),Boolean.FALSE);
			}

			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2
					.findById(mst.getLastTransactionId()).orElse(null);

			AddressMasterV2 applicantAddress = addressMasterRepositoryV2.findById(applicantInfoV2.getAddressId())
					.orElse(null);

			NomineeDetailsV2 nomineeMaster = nomineeDetailsRepositoryV2
					.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(applicationId);

			try {
				NomieeUpdateResponse response = saveNominee(nomineeMaster, mst, request, transactionDetailsV2,
						applicantInfoV2, applicantAddress, applicationId, schemeId);
				if (OPLUtils.isObjectNullOrEmpty(response.getCOI())) {
					return new NomieeUpdateResponse(response.getMessage(),null, HttpStatus.BAD_REQUEST.value(),Boolean.FALSE);
				}
				return new NomieeUpdateResponse(
						response.getMessage(), new COIDocsProxyV3(response.getCOI().getDocumentType(),
								response.getCOI().getContentType(), response.getCOI().getDocument()),
						response.getStatus(), response.getSuccess());
			} catch (Exception e) {
				log.error("Exception is getting While save nominee data ", e);
			}

		} catch (Exception e) {
			log.error("Exception is getting While  nominee Update Data  ", e);
		}
		return null;
	}

	private NomieeUpdateResponse saveNominee(NomineeDetailsV2 nomineeMaster, ApplicationMasterBothSchemeProxy mst,
			NomineeUpdateRequest req, TransactionDetailsV2 transactionDetailsV2, ApplicantInfoV2 applicantInfoV2,
			AddressMasterV2 applicantAddress, Long applicationId, Long schemeId) throws OneFormException {

		if (OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
			nomineeMaster = new NomineeDetailsV2();
			nomineeMaster.setId(nomineeDetailsRepositoryV2.getNextValMySequence());
			nomineeMaster.setApplicationId(mst.getId());
			nomineeMaster.setIsActive(Boolean.TRUE);
		} else {
			nomineeMaster.setModifiedDate(new Date());
		}
		
		nomineeMaster.setIsOtherClaimant(false);
		nomineeMaster.setMobileNumber(req.getNomineeMobileNumber());
		nomineeMaster.setRelationId(RelationShip.fromValue(req.getRelationshipOfNominee()).getId());
		nomineeMaster.setEmail(req.getNomineeEmailId());

		NomineePIDetails nomineePIDtl = null;
		if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getId())) {
			nomineePIDtl = nomineePIDetailsRepository.findById(nomineeMaster.getId()).orElse(null);
		} else {
			nomineePIDtl = new NomineePIDetails();
			nomineePIDtl.setId(nomineeMaster.getId());
			nomineePIDtl.setEnrollmentDate(Date.from(req.getFirstEnrollmentDate().atZone(ZoneId.systemDefault()).toInstant()));
		}
		nomineePIDtl.setName(req.getNomineeName());
		nomineePIDtl.setDob(Date.from(req.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
		nomineePIDtl.setAddressLine1(req.getAddressofNominee());

		if (!OPLUtils.isObjectNullOrEmpty(req.getNomineeDateOfBirth())) {
			Integer ageFromBirthDate = DateUtils
					.getAgeFromBirthDate(Date.from(req.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			if(ageFromBirthDate < 18) {				
				nomineePIDtl.setGdName(req.getNameofGuardian());
				nomineeMaster.setGdRelationId(!OPLUtils.isObjectNullOrEmpty(req.getRelationShipOfGuardian()) ? RelationShip.fromValue(req.getRelationShipOfGuardian()).getId() : null);
				nomineeMaster.setGdMobile(req.getGuardianMobileNumber());
				nomineeMaster.setGdEmail(req.getGuardianEmailId());
				nomineePIDtl.setGdAddress(req.getAddressOfGuardian());
			}
		}

		ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(mst.getId()).orElse(null);
		if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getId())) {
			applicantPIDetails = applicantPIDetailsRepository.findById(mst.getId()).orElse(null);
		} else {
			applicantPIDetails = new ApplicantPIDetails();
			applicantPIDetails.setId(mst.getId());
			applicantPIDetails.setAccountNumber(req.getAccountNumber());
			applicantPIDetails.setAcHolderName(req.getAccountHolderName());
			applicantPIDetails.setKycId1(req.getKycID1());
			applicantPIDetails.setKycIdNumber1(req.getKycID1Number());
			applicantPIDetails.setDob(Date.from(req.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			applicantPIDetails.setAddressLine1(req.getAddressLine1());
			applicantPIDetails.setAddressLine2(req.getAddressLine2());
			applicantPIDetails.setEnrollmentDate(new Date());
			applicantPIDetails.setFatherHusbandName(req.getFatherHusbandName());
			// cif,firstName,lastName,middleName,kycId2,kycIdNumber2 --Not in NomineeUpdateRequest
		}
		
		/**AFTER PUSH JNS MASTER NOMINEE UPDATE FLAG SET FALSE*/
		ereCommonService.setNomineePushFlagFalse(mst.getId());

		/** SAVE MISCELLANEOUS AUDIT DATA */
		saveMiscellaneousAuditData(req, applicantPIDetails, mst, nomineeMaster);

		/** GENERATE COI */
		byte[] data = getCOI(mst, transactionDetailsV2, applicantInfoV2, applicantPIDetails, nomineeMaster,
				nomineePIDtl, applicantAddress, true);
		
		/** PUSH APPLICATION */
		pushNomineeUpdateApplication(applicationId, schemeId);

		/** SEND EMAIL HERE */
		asynUtils.sendCoiToApplicantNewDb(mst, transactionDetailsV2, applicantInfoV2,
				applicantPIDetails, nomineeMaster, nomineePIDtl, applicantAddress);

		ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(applicationId).orElse(null);
		
		/** CALL WEBHOOK FOR BANK AND INSURER NOMINEE UPDATE STATUS */
		try {
			callWebhookForPushNomineeUpdateStatusBankAndInsurer(mst, nomineeMaster, nomineePIDtl,applicationPushStatus);
		} catch (Exception e) {
			log.error("Exception is getting While webhook nominee update status ", e);
		}
		
		nomineeDetailsRepositoryV2.save(nomineeMaster);
		nomineePIDetailsRepository.save(nomineePIDtl);

		return new NomieeUpdateResponse(Constants.SUCCESS, new COIDocsProxyV3("coi", "pdf", data),
				HttpStatus.OK.value(), Boolean.TRUE);
	}
	
	public void callWebhookForPushNomineeUpdateStatusBankAndInsurer(ApplicationMasterBothSchemeProxy applicationMaster,
			NomineeDetailsV2 nomineeDetailsV2, NomineePIDetails nomineePIDetails,
			ApplicationPushStatus applicationPushStatus) throws IOException {

		/** PREPARE NOMINEE UPDATE STATUS REQUEST */
		NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq = getterSetter.prepareNomineeUpdateStatusRequest(applicationMaster, nomineeDetailsV2, nomineePIDetails);

		/** BANK WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getBankNmnDtlsPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getBankNmnDtlsPush())) {
			if(OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource())) {				
				nomineeUpdateStatus(nomineeUpdateStatusReq, applicationMaster.getCreatedBy());
			}
		}

		/** INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		nomineeUpdateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
		nomineeUpdateStatusReq.setIsInsurer(true);
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getInsurerNmnDtlsPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getInsurerNmnDtlsPush())) {
			nomineeUpdateStatus(nomineeUpdateStatusReq, applicationMaster.getCreatedBy());
		}
	}

	/** CALL WEBHOOK FOR NOMINEE UPDATE STATUS */
	public void nomineeUpdateStatus(NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq, Long userId) throws IOException {
		nomineeUpdateStatusReq.setCommonUserId(userId);
		webHookClient.nomineeUpdateStatus(nomineeUpdateStatusReq);
	}
	
	public void saveMiscellaneousAuditData(NomineeUpdateRequest req, ApplicantPIDetails applicantPIDetails,
			ApplicationMasterBothSchemeProxy applicationMaster, NomineeDetailsV2 nomineeMaster) {
		miscellaneousAuditRepository.isActiveFalseByApplicationId(applicationMaster.getId(),
				MiscellaneousType.NOMINEE_UPDATE.getId());
		MiscellaneousAudit miscellaneousAudit = new MiscellaneousAudit();
		miscellaneousAudit.setApplicationId(applicationMaster.getId());
		miscellaneousAudit.setUrn(applicationMaster.getUrn());
		miscellaneousAudit.setNomineeId(nomineeMaster.getId());
		miscellaneousAudit.setAccountNumber(applicantPIDetails.getAccountNumber());
		miscellaneousAudit.setType(MiscellaneousType.NOMINEE_UPDATE.getId());
		miscellaneousAudit.setCreatedDate(new Date());
		miscellaneousAudit.setIsActive(true);
		miscellaneousAuditRepository.save(miscellaneousAudit);
	}

	public void pushNomineeUpdateApplication(Long applicationId, Long schemeId) {
		log.info("applicationId => {}", applicationId);

		/* Pushing application */
		String url = properties.getValueByCode("PUSH_PULL_NOMINEE_UPDATE_API_URL").concat(applicationId.toString())
				+ "/" + schemeId.toString();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
			headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
			headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published nominee update Data For -->" + applicationId + "==========API URL ----------->" + url);
			restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			log.error("Exception While calling Public API :: ", e);
		}
	}

	public byte[] getCOI(ApplicationMasterBothSchemeProxy appMaster, TransactionDetailsV2 transactionDetailsV2,
			ApplicantInfoV2 applicantDetails, ApplicantPIDetails applicantPIDetails, NomineeDetailsV2 nomineeDetailsV2,
			NomineePIDetails nomineePIDetails, AddressMasterV2 applicantAddress, Boolean isFreshCreate) {
		try {
			if (!isFreshCreate) {
				Long coiStorageId = transactionDetailsV2.getCoiStorageId();
				if (coiStorageId != null) {
					return dmsClient.productDownloadDocuments(coiStorageId.toString());
				}
			}
			// FETCH COI REQUEST FROM APPLICATION MASTER
			COIRequest coiReq = ereCommonService.generateCOIRequestNewDb(appMaster, transactionDetailsV2,
					applicantDetails, applicantPIDetails, nomineeDetailsV2, nomineePIDetails, applicantAddress);

			// GENERATE PDF FILE FROM PDF CLIENT
			CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
			if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus())
					&& generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
				transactionDetailsV2.setCoiStorageId(generateCOI.getId());
				transactionDetailsRepositoryV2.updateStorageIdInTransaction(generateCOI.getId(),
						appMaster.getLastTransactionId());
				return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
			} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI)
					&& !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
				log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
			} else {
				log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
			}
		} catch (Exception e) {
			log.error("Exception while generate COI ---------------->", e);
		}
		return null;
	}

}
