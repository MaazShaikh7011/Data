package com.opl.jns.registry.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "JNS_CLAIM_DATA", catalog = DBNameConstant.JNS_REPORTS, schema = DBNameConstant.JNS_REPORTS)
public class JnsClaimData implements Serializable {
    private static final long serialVersionUID = -6435335669806051064L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "jns_claim_data_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_REPORTS, name = "jns_claim_data_seq_gen", sequenceName = "jns_claim_data_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "org_id", nullable = false)
    private Long orgId;

    @Column(name = "scheme_id", nullable = false)
    private Integer schemeId;

    @Column(name = "scheme_name", nullable = false, columnDefinition = "varchar(20) default ''")
    private String schemeName;

    @Column(name = "insurer_name", nullable = false, columnDefinition = "varchar(255) default ''")
    private String insurerName;

    @Column(name = "insurer_org_id", nullable = false, columnDefinition = "number(19) default 0")
    private Long insurerOrgId;

    @Column(name = "insurer_code", nullable = false, columnDefinition = "varchar(20) default ''")
    private String insurerCode;

    @Column(name = "bank_name", nullable = false, columnDefinition = "varchar(100) default ''")
    private String bankName;

    @Column(name = "bank_short_name", nullable = false, columnDefinition = "varchar(20) default ''")
    private String bankShortName;

    @Column(name = "bank_code", nullable = false, columnDefinition = "varchar(20) default ''")
    private String bankCode;

    @Column(name = "bank_category", nullable = false, columnDefinition = "varchar(10) default ''")
    private String bankCategory;

    @Column(name = "lgd_state_code", columnDefinition = "varchar(5) default ''")
    private String lgdStateCode;

    @Column(name = "state_name", columnDefinition = "varchar(255) default ''")
    private String stateName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @Column(name = "to_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @Column(name = "version", nullable = false, columnDefinition = "number(19) default 0")
    private Long version;

    @Column(name = "male_clm_rural_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmRuralCount;

    @Column(name = "female_clm_rural_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmRuralCount;

    @Column(name = "transg_clm_rural_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long transgClmRuralCount;

    @Column(name = "male_clm_urban_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmUrbanCount;

    @Column(name = "female_clm_urban_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmUrbanCount;

    @Column(name = "transg_clm_urban_count", nullable = false, columnDefinition = "number(19) default 0")
    private Long transgClmUrbanCount;

    @Column(name = "male_clm_recv", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmRecv;

    @Column(name = "female_clm_recv", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmRecv;

    @Column(name = "trans_g_clm_recv", nullable = false, columnDefinition = "number(19) default 0")
    private Long transGClmRecv;

    @Column(name = "male_clm_paid", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmPaid;

    @Column(name = "female_clm_paid", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmPaid;

    @Column(name = "trans_g_clm_paid", nullable = false, columnDefinition = "number(19) default 0")
    private Long transGClmPaid;

    @Column(name = "male_clm_reject", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmReject;

    @Column(name = "female_clm_reject", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmReject;

    @Column(name = "trans_g_clm_reject", nullable = false, columnDefinition = "number(19) default 0")
    private Long transGClmReject;

    @Column(name = "male_clm_out_stand", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmOutStand;

    @Column(name = "female_clm_out_stand", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmOutStand;

    @Column(name = "trans_g_clm_out_stand", nullable = false, columnDefinition = "number(19) default 0")
    private Long transGClmOutStand;

    @Column(name = "male_clm_amount", nullable = false, columnDefinition = "number(19) default 0")
    private Long maleClmAmount;

    @Column(name = "female_clm_amount", nullable = false, columnDefinition = "number(19) default 0")
    private Long femaleClmAmount;

    @Column(name = "trans_g_clm_amount", nullable = false, columnDefinition = "number(19) default 0")
    private Long transGClmAmount;

    @Column(name = "grater_than_1_year", nullable = false, columnDefinition = "number(19) default 0")
    private Long graterThan1Year;

    @Column(name = "grater_than_6_months", nullable = false, columnDefinition = "number(19) default 0")
    private Long graterThan6Months;

    @Column(name = "grater_than_60_days", nullable = false, columnDefinition = "number(19) default 0")
    private Long graterThan60Days;

    @Column(name = "grater_than_14_days", nullable = false, columnDefinition = "number(19) default 0")
    private Long graterThan14Days;

    @Column(name = "grater_than_7_days", nullable = false, columnDefinition = "number(19) default 0")
    private Long graterThan7Days;

    @Column(name = "less_than_7_days", nullable = false, columnDefinition = "number(19) default 0")
    private Long lessThan7Days;
    
    @Column(name = "kyc_email_cnt", nullable = false, columnDefinition = "number(19) default 0")
    private Long kycEmailCnt;
    
    @Column(name = "kyc_mobile_cnt", nullable = false, columnDefinition = "number(19) default 0")
    private Long kycMobileCnt;
    
    @Column(name = "kyc_aadhaar_cnt", nullable = false, columnDefinition = "number(19) default 0")
    private Long kycAadhaarCnt;

}
