package com.opl.jns.registry.service.utils.v3;

import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.service.domain.JnsClaimData;
import com.opl.jns.registry.service.domain.MisDataDocDetails;
import com.opl.jns.registry.service.domain.WeekMaster;
import com.opl.jns.registry.service.repository.JnsClaimDataRepo;
import com.opl.jns.registry.service.repository.MisDataDocDetailsRepo;
import com.opl.jns.registry.service.repository.WeekMasterRepository;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.sql.Clob;
import java.util.*;
import java.util.stream.Collectors;

@Component("MisClaimAsyncComponent")
@Slf4j
public class MisClaimAsyncComponent {

    @Autowired
    private JnsClaimDataRepo jnsClaimDataRepo;

    @Autowired
    private WeekMasterRepository weekMasterRepository;

    @Autowired
    private Environment environment;

    @Autowired
    private MisDataDocDetailsRepo misDataDocDetailsRepo;

    @Autowired
    private DMSClient dmsClient;

    private static final SchemeMaster PMSBYScheme = SchemeMaster.PMSBY;
    private static final SchemeMaster PMJJBYScheme = SchemeMaster.PMJJBY;
    private static final long MIS_CLAIM_PRO_DOC_MAP_ID = 94L;
    private static final String DATE_FORMAT = "dd-MM-yyyy";
    private static final String DATE_FORMAT_FOR_FILE_NAME = "ddMMyy";


    @SuppressWarnings("unchecked")
    @Async
    @Transactional
    public void prepareDataForMis(WeekMaster weekMaster) {
        try {

            Object dataByToDate = jnsClaimDataRepo.getDataByToDate(DateUtils.setDateFormat(DATE_FORMAT, weekMaster.getToDate()));
            List<JnsClaimData> jnsClaimDataList = (List<JnsClaimData>) MultipleJSONObjectHelper.getListOfObjects(OPLUtils.readClob((Clob) dataByToDate), null, JnsClaimData.class);
            if (OPLUtils.isListNullOrEmpty(jnsClaimDataList)) {
                log.info("Claim data for version {} is null or empty ===================> ", weekMaster.getId());
                return;
            }
            for (JnsClaimData jnsClaimData : jnsClaimDataList) {
                jnsClaimData.setCreatedDate(new Date());
                jnsClaimData.setToDate(weekMaster.getToDate());
                jnsClaimData.setVersion(weekMaster.getId());
            }
            jnsClaimDataRepo.saveAllAndFlush(jnsClaimDataList);
        } catch (Exception e) {
            log.error("Exception in prepareDataForMis() ========> ", e);
        }
    }

    @Async
    public void uploadExcelInDms(Long version) {
        log.info("In uploadExcelInDms() ----version----> {}",version);

        List<JnsClaimData> jnsClaimDataList = jnsClaimDataRepo.findAllByVersion(version);
        if (OPLUtils.isListNullOrEmpty(jnsClaimDataList)) {
            log.info("requestedData is null or empty");
            return;
        }

        String path = environment.getProperty("claim.file.path");

        log.info("In uploadExcelInDms() for file path ----------------> {}", path);
        if (OPLUtils.isObjectNullOrEmpty(path)) {
            log.info("File path is null or empty from application.properties ");
            return;
        }
        try {
            Workbook workbook = new XSSFWorkbook(OPCPackage.open(path));
            if (OPLUtils.isObjectNullOrEmpty(workbook)) {
                return;
            }

            WeekMaster weekMaster = weekMasterRepository.findById(version).orElse(null);

            String fileName;
            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                fileName = "JNS_MIS_CLAIM_Data.xlsx";
            } else {
                fileName = "JNS_CLAIM_MIS_" + DateUtils.setDateFormat(DATE_FORMAT_FOR_FILE_NAME, weekMaster.getFromDate()) + "_" + DateUtils.setDateFormat(DATE_FORMAT_FOR_FILE_NAME, weekMaster.getToDate()) + ".xlsx";
            }
            String name = "Claim Data";

            log.info("Calling  setGenderCount() for scheme {}", PMSBYScheme.getShortName());
            setGenderCount(jnsClaimDataList, workbook, PMSBYScheme.getId().intValue());

            log.info("Calling  setGenderCount() for scheme {}", PMJJBYScheme.getShortName());
            setGenderCount(jnsClaimDataList, workbook, PMJJBYScheme.getId().intValue());

            log.info("Calling  setDataInsurerAndBankAndStateWise() for scheme {}", PMSBYScheme.getShortName());
            setDataInsurerAndBankAndStateWise(jnsClaimDataList, workbook, PMSBYScheme.getId().intValue());

            log.info("Calling  setDataInsurerAndBankAndStateWise() for scheme {}", PMJJBYScheme.getShortName());
            setDataInsurerAndBankAndStateWise(jnsClaimDataList, workbook, PMJJBYScheme.getId().intValue());

            log.info("Calling  setDataInsurerAndBankWise() for scheme {}", PMSBYScheme.getShortName());
            setDataInsurerAndBankWise(jnsClaimDataList, workbook, PMSBYScheme.getId().intValue());

            log.info("Calling  setDataInsurerAndBankWise() for scheme {}", PMJJBYScheme.getShortName());
            setDataInsurerAndBankWise(jnsClaimDataList, workbook, PMJJBYScheme.getId().intValue());


            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.createCellStyle().setLocked(true);
            workbook.write(baos);

            /* PREPARE DMS UPLOAD REQUEST AND UPLOAD EXCEL USING CLIENT */
            MultipartFile multipartFile = new MockMultipartFile(name, fileName, MediaType.ALL_VALUE, baos.toByteArray());

            DocumentRequest documentRequest = new DocumentRequest();
            documentRequest.setUserType("user");
            documentRequest.setProductDocumentMappingId(MIS_CLAIM_PRO_DOC_MAP_ID);
            documentRequest.setOriginalFileName(fileName);

            log.info("Calling dmsClient.uploadFile() -----------> ");
            DocumentResponse documentResponse = dmsClient.uploadFile(MultipleJSONObjectHelper.getStringfromObject(documentRequest), multipartFile);
            if (!OPLUtils.isObjectNullOrEmpty(documentResponse)
                    && Objects.equals(documentResponse.getStatus(), HttpStatus.OK.value())
                    && !OPLUtils.isObjectNullOrEmpty(documentResponse.getData())) {
                StorageDetailsResponse storageDetailsResponse = com.opl.jns.published.utils.common.MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
                saveDMSData(fileName, documentResponse.getStatus(), storageDetailsResponse.getId(), TransactionTypeEnum.CLAIM.getType(), new Date(), version);
            } else {
                log.info("Document Failure Response --------------> {}", documentResponse);
                saveDMSData(fileName, documentResponse != null ? documentResponse.getStatus() : null, null, TransactionTypeEnum.CLAIM.getType(), new Date(), version);
            }
        } catch (Exception e) {
            log.error("Exception in uploadExcelInDms() -----------> ", e);
        }
    }

    private void setGenderCount(List<JnsClaimData> jnsClaimDataList, Workbook workbook, Integer schemeId) {
        log.info("In setGenderCount() ----------> ");
        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " Gender wise");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " Gender wise");
        }
        int index = 3;
        int srNo = 0;
        Map<String, List<JnsClaimData>> insurerWiseData = jnsClaimDataList.stream()
                .filter(obj -> obj.getSchemeId().longValue() == schemeId
                        && !OPLUtils.isObjectNullOrEmpty(obj.getInsurerName()))
                .collect(Collectors.groupingBy(JnsClaimData::getInsurerName));

        for (Map.Entry<String, List<JnsClaimData>> insurerEntry : insurerWiseData.entrySet()) {

            Map<String, List<JnsClaimData>> bankWiseData = insurerEntry.getValue().stream()
                    .filter(obj -> obj.getSchemeId().longValue() == schemeId
                            && !OPLUtils.isObjectNullOrEmpty(obj.getBankName()))
                    .collect(Collectors.groupingBy(JnsClaimData::getBankName));

            String insurerName = insurerEntry.getKey();

            for (Map.Entry<String, List<JnsClaimData>> entry : bankWiseData.entrySet()) {

                String bankName =  entry.getKey();

                log.info("====================================================================");
                log.info("insurerName {}", insurerName);

                log.info("bankName {}", bankName);

                long maleClmRecv = entry.getValue().stream().map(JnsClaimData::getMaleClmRecv).mapToLong(Long::longValue).sum();
                long femaleClmRecv = entry.getValue().stream().map(JnsClaimData::getFemaleClmRecv).mapToLong(Long::longValue).sum();
                long transGClmRecv = entry.getValue().stream().map(JnsClaimData::getTransGClmRecv).mapToLong(Long::longValue).sum();

                long totalClaimReceived = maleClmRecv + femaleClmRecv + transGClmRecv;

                log.info("maleClmRecv {}", maleClmRecv);
                log.info("femaleClmRecv {}", femaleClmRecv);
                log.info("transGClmRecv {}", transGClmRecv);
                log.info("totalClaimReceived {}", totalClaimReceived);

                long maleClmPaid = entry.getValue().stream().map(JnsClaimData::getMaleClmPaid).mapToLong(Long::longValue).sum();
                long femaleClmPaid = entry.getValue().stream().map(JnsClaimData::getFemaleClmPaid).mapToLong(Long::longValue).sum();
                long transGClmPaid = entry.getValue().stream().map(JnsClaimData::getTransGClmPaid).mapToLong(Long::longValue).sum();

                long totalClaimPaid = maleClmPaid + femaleClmPaid + transGClmPaid;

                log.info("maleClmPaid {}", maleClmPaid);
                log.info("femaleClmPaid {}", femaleClmPaid);
                log.info("transGClmPaid {}", transGClmPaid);
                log.info("totalClaimPaid {}", totalClaimPaid);

                long maleClmReject = entry.getValue().stream().map(JnsClaimData::getMaleClmReject).mapToLong(Long::longValue).sum();
                long femaleClmReject = entry.getValue().stream().map(JnsClaimData::getFemaleClmReject).mapToLong(Long::longValue).sum();
                long transGClmReject = entry.getValue().stream().map(JnsClaimData::getTransGClmReject).mapToLong(Long::longValue).sum();

                long totalClaimReject = maleClmReject + femaleClmReject + transGClmReject;

                log.info("maleClmReject {}", maleClmReject);
                log.info("femaleClmReject {}", femaleClmReject);
                log.info("transGClmReject {}", transGClmReject);
                log.info("totalClaimReject {}", totalClaimReject);

                long maleClmOutStand = entry.getValue().stream().map(JnsClaimData::getMaleClmOutStand).mapToLong(Long::longValue).sum();
                long femaleClmOutStand = entry.getValue().stream().map(JnsClaimData::getFemaleClmOutStand).mapToLong(Long::longValue).sum();
                long transGClmOutStand = entry.getValue().stream().map(JnsClaimData::getTransGClmOutStand).mapToLong(Long::longValue).sum();

                long totalClaimOutStand = maleClmOutStand + femaleClmOutStand + transGClmOutStand;

                log.info("maleClmOutStand {}", maleClmOutStand);
                log.info("femaleClmOutStand {}", femaleClmOutStand);
                log.info("transGClmOutStand {}", transGClmOutStand);
                log.info("totalClaimOutStand {}", totalClaimOutStand);

                long maleClmAmount = entry.getValue().stream().map(JnsClaimData::getMaleClmAmount).mapToLong(Long::longValue).sum();
                long femaleClmAmount = entry.getValue().stream().map(JnsClaimData::getFemaleClmAmount).mapToLong(Long::longValue).sum();
                long transGClmAmount = entry.getValue().stream().map(JnsClaimData::getTransGClmAmount).mapToLong(Long::longValue).sum();

                long totalClaimAmount = maleClmAmount + femaleClmAmount + transGClmAmount;

                log.info("maleClmAmount {}", maleClmAmount);
                log.info("femaleClmAmount {}", femaleClmAmount);
                log.info("transGClmAmount {}", transGClmAmount);
                log.info("totalClaimAmount {}", totalClaimAmount);
                log.info("====================================================================");

                int cellId = 0;
                Row row = sheet.createRow(index);

                row.createCell(cellId, CellType.NUMERIC).setCellValue(++srNo);
                row.createCell(++cellId, CellType.STRING).setCellValue(insurerName);
                row.createCell(++cellId, CellType.STRING).setCellValue(bankName);

                row.createCell(++cellId, CellType.NUMERIC).setCellValue(maleClmRecv);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(femaleClmRecv);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(transGClmRecv);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaimReceived);

                row.createCell(++cellId, CellType.NUMERIC).setCellValue(maleClmPaid);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(femaleClmPaid);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(transGClmPaid);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaimPaid);

                row.createCell(++cellId, CellType.NUMERIC).setCellValue(maleClmReject);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(femaleClmReject);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(transGClmReject);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaimReject);

                row.createCell(++cellId, CellType.NUMERIC).setCellValue(maleClmOutStand);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(femaleClmOutStand);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(transGClmOutStand);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaimOutStand);

                row.createCell(++cellId, CellType.NUMERIC).setCellValue(maleClmAmount);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(femaleClmAmount);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(transGClmAmount);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaimAmount);

                index++;
            }
        }
    }

    private void setDataInsurerAndBankAndStateWise(List<JnsClaimData> jnsClaimDataList, Workbook workbook, Integer schemeId) {
        log.info("In setDataInsurerAndStateWise() ---------> ");
        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " State wise");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " State wise");
        }
        int index = 2;
        int srNo = 0;

        Map<String, List<JnsClaimData>> insurerWiseData = jnsClaimDataList.stream()
                .filter(obj -> obj.getSchemeId().longValue() == schemeId
                        && !OPLUtils.isObjectNullOrEmpty(obj.getInsurerName()))
                .collect(Collectors.groupingBy(JnsClaimData::getInsurerName));

        for (Map.Entry<String, List<JnsClaimData>> insurerEntry : insurerWiseData.entrySet()) {
            String insurerName = insurerEntry.getKey();
            Map<String, List<JnsClaimData>> bankWiseData = insurerEntry.getValue().stream()
                    .filter(obj -> !OPLUtils.isObjectNullOrEmpty(obj.getBankName()))
                    .collect(Collectors.groupingBy(JnsClaimData::getBankName));

            for (Map.Entry<String, List<JnsClaimData>> bankEntry : bankWiseData.entrySet()) {
                String bankName = bankEntry.getKey();
                Map<String, List<JnsClaimData>> stateWiseData = bankEntry.getValue().stream()
                        .filter(obj -> !OPLUtils.isObjectNullOrEmpty(obj.getStateName()))
                        .collect(Collectors.groupingBy(JnsClaimData::getStateName));

                stateWiseData = stateWiseData.entrySet().stream()
                        .sorted(Map.Entry.comparingByKey())
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                Map.Entry::getValue,
                                (oldValue, newValue) -> oldValue, LinkedHashMap::new));

                for (Map.Entry<String, List<JnsClaimData>> entry : stateWiseData.entrySet()) {
                    log.info("====================================================================");

                    log.info("insurerName {}", insurerName);
                    log.info("bankName {}", bankName);

                    String stateName = entry.getKey();
                    String stateCode = entry.getValue().get(0).getLgdStateCode();

                    log.info("stateName {}", stateName);
                    log.info("stateCode {}", stateCode);

                    long totalReceivedClaims = entry.getValue().stream().map(JnsClaimData::getMaleClmRecv).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getFemaleClmRecv).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getTransGClmRecv).mapToLong(Long::longValue).sum();

                    log.info("totalReceivedClaims {}", totalReceivedClaims);

                    long totalPaidClaims = entry.getValue().stream().map(JnsClaimData::getMaleClmPaid).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getFemaleClmPaid).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getTransGClmPaid).mapToLong(Long::longValue).sum();

                    log.info("totalPaidClaims {}", totalPaidClaims);

                    long totalRejectedClaims = entry.getValue().stream().map(JnsClaimData::getMaleClmReject).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getFemaleClmReject).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getTransGClmReject).mapToLong(Long::longValue).sum();

                    log.info("totalRejectedClaims {}", totalRejectedClaims);

                    long totalOutStandingClaims = entry.getValue().stream().map(JnsClaimData::getMaleClmOutStand).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getFemaleClmOutStand).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getTransGClmOutStand).mapToLong(Long::longValue).sum();

                    log.info("totalOutStandingClaims {}", totalOutStandingClaims);

                    long totalPaidAmount = entry.getValue().stream().map(JnsClaimData::getMaleClmAmount).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getFemaleClmAmount).mapToLong(Long::longValue).sum() +
                            entry.getValue().stream().map(JnsClaimData::getTransGClmAmount).mapToLong(Long::longValue).sum();

                    log.info("totalPaidAmount {}", totalPaidAmount);
                    log.info("====================================================================");

                    int cellId = 0;
                    Row row = sheet.createRow(index);
                    row.createCell(cellId, CellType.NUMERIC).setCellValue(++srNo);
                    row.createCell(++cellId, CellType.STRING).setCellValue(insurerName);
                    row.createCell(++cellId, CellType.STRING).setCellValue(bankName);

                    row.createCell(++cellId, CellType.STRING).setCellValue(stateCode);
                    row.createCell(++cellId, CellType.STRING).setCellValue(stateName);


                    row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalReceivedClaims);
                    row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalPaidClaims);
                    row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalRejectedClaims);
                    row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalOutStandingClaims);
                    row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalPaidAmount);

                    index++;
                }
            }
        }
    }

    private void setDataInsurerAndBankWise(List<JnsClaimData> jnsClaimDataList, Workbook workbook, Integer schemeId) {
        log.info("In setDataInsurerAndBankWise() ----------> ");

        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " Outstanding Ageing");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " Outstanding Ageing");
        }
        int index = 2;
        int srNo = 0;
        Map<String, List<JnsClaimData>> insurerWiseData = jnsClaimDataList.stream()
                .filter(obj -> obj.getSchemeId().longValue() == schemeId
                        && !OPLUtils.isObjectNullOrEmpty(obj.getInsurerName()))
                .collect(Collectors.groupingBy(JnsClaimData::getInsurerName));

        for (Map.Entry<String, List<JnsClaimData>> stateEntry : insurerWiseData.entrySet()) {

            String insurerName = stateEntry.getKey();
            String insurerCode = stateEntry.getValue().get(0).getInsurerCode();

            Map<String, List<JnsClaimData>> bankWiseData = stateEntry.getValue().stream()
                    .filter(obj -> !OPLUtils.isObjectNullOrEmpty(obj.getBankName()))
                    .collect(Collectors.groupingBy(JnsClaimData::getBankName));

            for (Map.Entry<String, List<JnsClaimData>> entry : bankWiseData.entrySet()) {

                log.info("====================================================================");
                log.info("insurerName {}", insurerName);
                log.info("insurerCode {}", insurerCode);

                String bankName = entry.getKey();
                String bankType = entry.getValue().get(0).getBankCode();
                String bankCategory = entry.getValue().get(0).getBankCategory();

                log.info("bankName {}", bankName);
                log.info("bankType {}", bankType);
                log.info("bankCategory {}", bankCategory);

                long grateThan1Year = entry.getValue().stream().map(JnsClaimData::getGraterThan1Year).mapToLong(Long::longValue).sum();
                long graterThan6Months = entry.getValue().stream().map(JnsClaimData::getGraterThan6Months).mapToLong(Long::longValue).sum();
                long graterThan60Days = entry.getValue().stream().map(JnsClaimData::getGraterThan60Days).mapToLong(Long::longValue).sum();
                long graterThan14Days = entry.getValue().stream().map(JnsClaimData::getGraterThan14Days).mapToLong(Long::longValue).sum();
                long graterThan7Days = entry.getValue().stream().map(JnsClaimData::getGraterThan7Days).mapToLong(Long::longValue).sum();
                long lessThan7Days = entry.getValue().stream().map(JnsClaimData::getLessThan7Days).mapToLong(Long::longValue).sum();

                long totalClaims = grateThan1Year + graterThan6Months + graterThan60Days + graterThan14Days + graterThan7Days + lessThan7Days;

                log.info("lessThan7Days {}", lessThan7Days);
                log.info("graterThan7Days {}", graterThan7Days);
                log.info("graterThan14Days {}", graterThan14Days);
                log.info("graterThan60Days {}", graterThan60Days);
                log.info("graterThan6Months {}", graterThan6Months);
                log.info("grateThan1Year {}", grateThan1Year);
                log.info("totalClaims {}", totalClaims);
                log.info("====================================================================");

                int cellId = 0;
                Row row = sheet.createRow(index);

                row.createCell(cellId, CellType.NUMERIC).setCellValue(++srNo);

                row.createCell(++cellId, CellType.STRING).setCellValue(insurerName);

                row.createCell(++cellId, CellType.STRING).setCellValue(bankName);
                row.createCell(++cellId, CellType.STRING).setCellValue(bankType);
                row.createCell(++cellId, CellType.STRING).setCellValue(bankCategory);


                row.createCell(++cellId, CellType.NUMERIC).setCellValue(totalClaims);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(grateThan1Year);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(graterThan6Months);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(graterThan60Days);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(graterThan14Days);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(graterThan7Days);
                row.createCell(++cellId, CellType.NUMERIC).setCellValue(lessThan7Days);

                index++;
            }
        }
    }

    @Transactional
    private void saveDMSData(String fileName, Integer status, Long dmsStorageId, String type, Date createdDate, Long version) {
        log.info("In saveDMSData() -----------> ");
        MisDataDocDetails misDataDocDetails = new MisDataDocDetails();
        misDataDocDetails.setCreatedDate(createdDate);
        misDataDocDetails.setFileName(fileName);
        misDataDocDetails.setStatus(status);
        misDataDocDetails.setDmsStorageId(dmsStorageId);
        misDataDocDetails.setType(type);
        misDataDocDetails.setVersion(version);
        misDataDocDetails.setIsActive(true);
        misDataDocDetailsRepo.save(misDataDocDetails);
    }
}
