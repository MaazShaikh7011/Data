package com.opl.jns.registry.service.service.publish.v2.impl;
//package com.opl.service.registry.jns.service.publish.v2.impl;
//
//import java.util.Base64;
//import java.util.Date;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//import com.opl.jns.common.client.dms.DMSClient;
//import com.opl.jns.common.client.pdf.generate.PDFGenerateClient;
//import com.opl.jns.common.client.users.UsersClient;
//import com.opl.jns.ere.domain.ApplicationMasterV3;
//import com.opl.jns.ere.domain.InsurerMstDetailsV3;
//import com.opl.jns.ere.domain.TransactionDetailsV3;
//import com.opl.jns.ere.enums.Source;
//import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
//import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
//import com.opl.jns.ere.service.EreCommonService;
//import com.opl.jns.published.utils.common.DateUtils;
//import com.opl.jns.published.utils.common.OPLUtils;
//import com.opl.jns.published.utils.enums.ApplicationStatus;
//import com.opl.jns.published.utils.enums.EnrollStageMaster;
//import com.opl.jns.utils.enums.UserRoleMaster;
//import com.opl.jns.utils.model.COIRequest;
//import com.opl.publish.v2.enrollUpdateTrans.COIDocsProxyV2;
//import com.opl.publish.v2.enrollUpdateTrans.UpdateTransReqProxyV2;
//import com.opl.publish.v2.enrollUpdateTrans.UpdateTransResProxyV2;
//import com.opl.service.registry.jns.service.publish.v2.EnrollTransServiceV2;
//import com.opl.service.registry.jns.utils.AsynUtils;
//import com.opl.service.registry.jns.utils.NotificationPrepareProxy;
//import com.opl.utils.v2.Constants;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author sandip.bhetariya
// *
// */
//
//@Service
//@Slf4j
////@Transactional
//public class EnrollTransServiceImplV2 implements EnrollTransServiceV2 {
//
//	@Autowired
//	private ApplicationMasterRepositoryV3 applicationMasterRepository;
//
//	@Autowired
//	private UsersClient usersClient;
//
//	@Autowired
//	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;
//
//	@Autowired
//	private AsynUtils asynUtils;
//
//	@Autowired
//	private EreCommonService ereCommonService;
//
//	@Autowired
//	private PDFGenerateClient pdfGenerateClient;
//
//	@Autowired
//	private CommitTransactionalServiceImplV2 commitTransactionalServiceImplV2;
//
//	@Autowired
//	private DMSClient dmsClient;
//
//	/**
//	 * UPDATE TRANSACTION DETAILS FROM OTHER CHANNEL API
//	 */
//	@Override
//	public UpdateTransResProxyV2 updateTransactionDetailsAndGetCoiFiles(UpdateTransResProxyV2 coiResponse, UpdateTransReqProxyV2 transactionRequest) throws Exception {
//		Long applicationId = null;
//		try {
//
//			/* VALIDATE TRANSACTION REQUEST */
//			coiResponse = validateTransactionDetail(transactionRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
//				return coiResponse;
//
//			/* FIND APPLICATION MASTER BY URN */
//			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findFirstByUrnAndIsActiveTrue(transactionRequest.getUrn());
//
//			/* VALIDATE APPLICATION MASTER DETAIL AND INTERNAL DE-DUPE CHECK */
//			coiResponse = validateApplicationMasterDetail(applicationMaster, transactionRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
//				return coiResponse;
//			
//			applicationId = applicationMaster.getId();
//			
//			if(Source.OTHER_CHANNEL.getId() != applicationMaster.getApplicationMasterOtherDetails().getSource()) {
//				return new UpdateTransResProxyV2("The application details are not found in the Other Channel mode", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//
//			/* FETCH CURRENT YEAR POLICY INSURER DETAILS */
//			InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(Long.valueOf(applicationMaster.getSchemeId()),
//					applicationMaster.getOrgId(), new Date(), new Date());
//
//			if (!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails) && !OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getMasterPolicyNo())
//					&& !currentInsurerDetails.getMasterPolicyNo().equalsIgnoreCase(transactionRequest.getMasterPolicyNumber())) {
//				log.error("END SAVE TRANSACTION DETAILS (INVALID MASTER POLICY NUMBER) --------->" + applicationId);
//				return new UpdateTransResProxyV2("Invalid Master Policy Number !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//
//			/* PARSE TRANSACTION DATE */
//			Date tranTimeStamp = DateUtils.parse(transactionRequest.getTransactionTimeStamp(), DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
//			if (OPLUtils.isObjectNullOrEmpty(tranTimeStamp)) {
//				log.error("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !! " + transactionRequest.getTransactionTimeStamp());
//				return new UpdateTransResProxyV2("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//			/**if transactionTimeStamp date is after current date*/
//			if(tranTimeStamp.after(new Date())) {
//				return new UpdateTransResProxyV2("Transaction date cannot be future dated. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//			
//			/**if transactionTimeStamp date is before policy start date*/
//			if(!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getPolicyStartDate()) && tranTimeStamp.before(currentInsurerDetails.getPolicyStartDate())) {
//				return new UpdateTransResProxyV2("Transaction date cannot be before the policy year date. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//
//			/* FETCH HO USER ID FROM USER TABLE TO SET AS CREATED BY */
//			Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(applicationMaster.getOrgId(), UserRoleMaster.HEAD_OFFICE.getId());
//			Date curruntDate = new Date();
//
//			/* SET TRANSACTION DETAIL OBJECT */
//			TransactionDetailsV3 transactionDetails = setTransactionDetails(transactionRequest, curruntDate, tranTimeStamp, userId, currentInsurerDetails);
//
//			/* SET APPLICATION MASTER COMPLETED DATA POINTS */
//			applicationMaster = updateApplicationMaster(applicationMaster, curruntDate, tranTimeStamp, userId, currentInsurerDetails, transactionRequest);
//			transactionDetails.setApplicationMaster(applicationMaster);
//			applicationMaster.setLastTransactionDetails(transactionDetails);
//
//			/* GENERATE COI */
//			byte[] coiByte = getCOI(applicationMaster);
//			if (!OPLUtils.isObjectNullOrEmpty(coiByte) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getCoiStorageId())) {
//				/* SAVE APPLICATION MASTER */
//				applicationMaster = commitTransactionalServiceImplV2.applicationMasterSave(applicationMaster);
//				return pushApplicationAndGenerateCoi(applicationMaster, coiByte);
//			}
//			log.error("COI BYTES IS NULL OR EMPTY ------------>" + applicationMaster.getId());
//			return new UpdateTransResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		} catch (Exception e) {
//			log.error("END SAVE TRANSACTION DETAILS (ERROR) --------->" + applicationId, e);
//			return new UpdateTransResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//		}
//	}
//
//	/**
//	 * getCOI Genarated Bytes
//	 * @param applicationMaster
//	 * @return
//	 */
//	private byte[] getCOI(ApplicationMasterV3 applicationMaster) {
//		try {
//			Long storageId = applicationMaster.getLastTransactionDetails().getCoiStorageId();
//			if (storageId != null) {
//				return dmsClient.productDownloadDocuments(storageId.toString());
//			}
//			/* PREPARE COI REQUEST FROM ERE COMMON SERVICE */
//			COIRequest coiReq = ereCommonService.generateCOIRequest(applicationMaster);
//
//			/* GENERATE PDF FILE FROM PDF CLIENT */
//			com.opl.jns.utils.common.CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
//			if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
//				/* SET COI STORAGE ID IN LAST TRANSACTION DETAILS */
//				applicationMaster.getLastTransactionDetails().setCoiStorageId(generateCOI.getId());
//				return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
//			} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
//				log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
//			} else {
//				log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
//			}
//		} catch (Exception e) {
//			log.error("Exception while generate COI ----->", e);
//		}
//		return null;
//	}
//
//	/**
//	 * Validate Application Master Detail
//	 * 
//	 * @param applicationMaster
//	 * @param transactionRequest
//	 * @param applicationId
//	 * @return
//	 * @throws Exception
//	 */
//	private UpdateTransResProxyV2 validateApplicationMasterDetail(ApplicationMasterV3 applicationMaster, UpdateTransReqProxyV2 transactionRequest) throws Exception {
//		Long applicationId = null;
//		/* CHECK THE URN IS VALID OF NOT */
//		if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
//			log.error("END SAVE TRANSACTION DETAILS (NOT FOUND APPLICATION MASTER BY URN) --------->" + transactionRequest.getUrn());
//			return new UpdateTransResProxyV2("Invalid URN Details.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		} else if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails())) {
//			/* IF LAST TRANSACTION IS EXISTS THEN NO NEED TO ADD ANOTHER TRANSACTION */
//			log.error("END SAVE TRANSACTION DETAILS (ALREADY LAST TRANS DETAILS UPDATED) --------->" + transactionRequest.getUrn());
//			byte[] coiByte = getCOI(applicationMaster);
//			return new UpdateTransResProxyV2(Constants.SUCCESS, new COIDocsProxyV2("coi", "pdf", coiByte), HttpStatus.OK.value(), Boolean.TRUE);
//		}
//		applicationId = applicationMaster.getId();
//		log.info("START SAVE TRANSACTION DETAILS ------------->" + applicationId);
//		/* CHECK CURRENT APPLICATION IS EXPIRED OR NOT */
//		if (applicationMaster.getStageId() == EnrollStageMaster.EXPIRED.getStageId()) {
//			log.error("END SAVE TRANSACTION DETAILS (ALREADY EXPIRED) --------->" + applicationId);
//			return new UpdateTransResProxyV2("The application has already expired", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//
//		/* CHECK CURRENT APPLICATION IS REJECTED OR NOT */
//		if (applicationMaster.getStageId() == EnrollStageMaster.REJECTED.getStageId()) {
//			log.error("END SAVE TRANSACTION DETAILS (ALREADY REJECTED) --------->" + applicationId);
//			return new UpdateTransResProxyV2("The application has already been rejected", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//
//		/* CHECK DUBLICATE CIF ALREADY EXIST OR NOT */
//		Long count = applicationMasterRepository.countByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatus(applicationMaster.getOrgId(), applicationMaster.getSchemeId(), applicationMaster.getCif(),
//				ApplicationStatus.ENROLL_COMPLETED.getId());
//		if (count > 0) {
//			log.error("END SAVE TRANSACTION DETAILS (DUBLICATE FOUND BY CIF) --------->" + applicationId);
//			return new UpdateTransResProxyV2("CIF has already completed enrollment", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//		return null;
//	}
//
//	/**
//	 * SET APPLICATION MASTER COMPLETED DETAILS IF TRANSACTION DETAILS ARE VALID
//	 * @param applicationMaster
//	 * @param curruntDate
//	 * @param tranTimeStamp
//	 * @param userId
//	 * @param currentInsurerDetails
//	 * @param transactionRequest
//	 * @return
//	 */
//	private ApplicationMasterV3 updateApplicationMaster(ApplicationMasterV3 applicationMaster, Date curruntDate, Date tranTimeStamp, Long userId, InsurerMstDetailsV3 currentInsurerDetails, UpdateTransReqProxyV2 transactionRequest) {
//		applicationMaster.setStageId(EnrollStageMaster.COMPLETED.getStageId());
//		applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_COMPLETED.getId());
//		applicationMaster.setStatusChangeDate(curruntDate);
//		applicationMaster.setModifiedDate(curruntDate);
//		applicationMaster.setModifiedBy(userId);
//		applicationMaster.setEnrollmentDate(tranTimeStamp);
//		applicationMaster.setCompletionDate(new Date());
//		applicationMaster.setPremiumAmount(transactionRequest.getTransactionAmount());
//		applicationMaster.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
//		return applicationMaster;
//	}
//
//	/**
//	 * PREPARE TRANSACTION DFTAILS OBJECT
//	 * @param transactionRequest
//	 * @param curruntDate
//	 * @param tranTimeStamp
//	 * @param userId
//	 * @param currentInsurerDetails
//	 * @return
//	 */
//	private TransactionDetailsV3 setTransactionDetails(UpdateTransReqProxyV2 transactionRequest, Date curruntDate, Date tranTimeStamp, Long userId, InsurerMstDetailsV3 currentInsurerDetails) {
//		TransactionDetailsV3 transactionDetails = new TransactionDetailsV3();
//		transactionDetails.setCreatedDate(curruntDate);
//		transactionDetails.setIsActive(Boolean.TRUE);
//		transactionDetails.setTransTimeStamp(tranTimeStamp);
//		transactionDetails.setTransAmount(transactionRequest.getTransactionAmount());
//		transactionDetails.setMasterPolicyNo(transactionRequest.getMasterPolicyNumber());
//		transactionDetails.setTransUtr(transactionRequest.getTransactionUTR());
//		transactionDetails.setType(OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()) ? null : Integer.parseInt(transactionRequest.getTransactionType()));
//		transactionDetails.setInsurerCode(transactionRequest.getInsurerCode());
//		transactionDetails.setCreatedBy(userId);
//		transactionDetails.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
//		transactionDetails.setCoverEndDate(currentInsurerDetails.getPolicyEndDate());
//		transactionDetails.setCoverStartDate(tranTimeStamp);
//		String year = currentInsurerDetails.getYear().substring(0, 4);
//		transactionDetails.setYear(OPLUtils.isObjectNullOrEmpty(year) ? null : Integer.valueOf(year));
//		transactionDetails.setInsurerMaster(currentInsurerDetails);
//		return transactionDetails;
//	}
//
//	/**
//	 * BELOW PROCESS HAS BEEN DONE BY BELOW METHOD
//	 * 1. EMAIL/SME SENT
//	 * 2. PUBLISH ENROLLMENT DATA 
//	 * 3. UPDATE STATUS AS COMPLETED IN DE-DUPE REGISTRY  
//	 * @param applicationMaster
//	 * @param coiByte
//	 * @return
//	 * @throws Exception
//	 */
//	private UpdateTransResProxyV2 pushApplicationAndGenerateCoi(ApplicationMasterV3 applicationMaster, byte[] coiByte) throws Exception {
//
//		if (!OPLUtils.isObjectNullOrEmpty(coiByte)) {
//
//			/* SEND EMAIL FOR COI */
//			sendEmailToApplicant(applicationMaster, coiByte);
//
//			/* PUBLISHED THE CLAIM DATA */
////			publishEnrollment(applicationMaster);
//			/* PUBLISHED THE CLAIM DATA */
//			if (OPLUtils.isObjectNullOrEmpty(applicationMaster.getIsPushed()) || (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getIsPushed()) && !applicationMaster.getIsPushed()))
//				publishEnrollment(applicationMaster);
//			else
//				log.info("Already application  is Pushed -->"+applicationMaster.getId());
//
//			
//			/* UPDATE STATUS TO DEDUPE REGISTRY */
////			if (OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()) 
////					|| (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()) && !applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()))
////				asynUtils.updateStatusToDeDupeRegisty(applicationMaster.getId(), applicationMaster.getUrn(), applicationMaster.getEnrollmentDate());
////			else
////				log.info("Already application  Checked status-->"+applicationMaster.getId());
//
//			/* PREPARING RESPONSE */
//			log.info("END SAVE TRANSACTION DETAILS (SUCCESS) --------->" + applicationMaster.getId());
//			return new UpdateTransResProxyV2(Constants.SUCCESS, new COIDocsProxyV2("coi", "pdf", coiByte), HttpStatus.OK.value(), Boolean.TRUE);
//		} else {
//			log.error("END SAVE TRANSACTION DETAILS COI BYTES NULL OR EMPTY [{}]", applicationMaster.getId());
//			throw new Exception("Exception while generate COI");
//		}
//	}
//
//	/**
//	 * CALL PUSH-PULL SERVICE CLIENT
//	 * @param applicationMaster
//	 */
//	private void publishEnrollment(ApplicationMasterV3 applicationMaster) {
//		/* PUBLISHED THE CLAIM DATA */
//		if (OPLUtils.isObjectNullOrEmpty(applicationMaster.getIsPushed()) || (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getIsPushed()) && !applicationMaster.getIsPushed())) {
//			asynUtils.publishEnrollment(applicationMaster.getId(), applicationMaster.getStageId());
//			log.info("TRANSACTION DETAILS PUSHED --------->" + applicationMaster.getId());
//		} else
//			log.info("ALREADY TRANSACTION DETAILS PUSHED --------->" + applicationMaster.getId());
//
//	}
//
//	/**
//	 * PREPARE NOTIFICATION OBJECT AND CALL CLIENT
//	 * @param applicationMaster
//	 * @param coiByte
//	 */
//	private void sendEmailToApplicant(ApplicationMasterV3 applicationMaster, byte[] coiByte) {
//		/* SEND EMAIL FOR COI */
//		NotificationPrepareProxy proxy = new NotificationPrepareProxy();
//		proxy.setId(applicationMaster.getId());
//		proxy.setUrn(applicationMaster.getUrn());
//		proxy.setSchemeId(applicationMaster.getSchemeId());
//		proxy.setEmail(applicationMaster.getApplicantInfo().getEmail());
//		proxy.setMobileNumber(applicationMaster.getApplicantInfo().getMobileNumber());
//		proxy.setFirstName(applicationMaster.getApplicantInfo().getFirstName());
//		proxy.setTransAmount(applicationMaster.getLastTransactionDetails().getTransAmount());
//		proxy.setYear(applicationMaster.getLastTransactionDetails().getYear());
//		proxy.setSource(applicationMaster.getApplicationMasterOtherDetails().getSource());
//		asynUtils.sendCoiToApplicant(proxy, coiByte);
//
//	}
//
//	/**
//	 * VALIDATE UPDATE TRANSACTION REQUEST 
//	 * @param transactionRequest
//	 * @return
//	 */
//	private UpdateTransResProxyV2 validateTransactionDetail(UpdateTransReqProxyV2 transactionRequest) {
//		String errorMsg = null;
//		if (OPLUtils.isObjectNullOrEmpty(transactionRequest))
//			errorMsg = "Data Can not be null";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionAmount()))
//			errorMsg = "transactionAmount not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionTimeStamp()))
//			errorMsg = "transactionTimeStamp code not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getUrn()))
//			errorMsg = "urn code not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getMasterPolicyNumber()))
//			errorMsg = "masterPolicyNumber not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getInsurerCode()))
//			errorMsg = "insurerCode not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionUTR()))
//			errorMsg = "transactionUtr not found";
//		else if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()))
//			errorMsg = "transactionType not found";
//		else if (!OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionAmount()) && transactionRequest.getTransactionAmount() == 0)
//			errorMsg = "Invalid Transaction Amount. Value must be non-zero numeric value.";
//
//		if (!OPLUtils.isObjectNullOrEmpty(errorMsg)) {
//			return new UpdateTransResProxyV2(errorMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//		return null;
//	}
//
////	public static void main(String[] args) {
////		Iterator<String> urn = Arrays.asList("JNS-PMJJBY-23-24-00000001809-867","JNS-PMJJBY-23-24-00000001787-974","JNS-PMJJBY-23-24-00000001762-621","JNS-PMJJBY-23-24-00000001864-073","JNS-PMJJBY-23-24-00000021358-581","JNS-PMJJBY-23-24-00000026506-556","JNS-PMJJBY-23-24-00000052551-831","JNS-PMJJBY-23-24-00000062268-995","JNS-PMJJBY-23-24-00000052428-703","JNS-PMJJBY-23-24-00000052629-989","JNS-PMJJBY-23-24-00000053763-292","JNS-PMJJBY-23-24-00000052557-014","JNS-PMJJBY-23-24-00000052732-467","JNS-PMJJBY-23-24-00000052898-625","JNS-PMJJBY-23-24-00000053127-502","JNS-PMJJBY-23-24-00000065178-157","JNS-PMJJBY-23-24-00000066292-888","JNS-PMJJBY-23-24-00000065753-963","JNS-PMJJBY-23-24-00000066882-355","JNS-PMJJBY-23-24-00000065457-525","JNS-PMJJBY-23-24-00000064739-922","JNS-PMJJBY-23-24-00000065233-578","JNS-PMJJBY-23-24-00000067191-602","JNS-PMJJBY-23-24-00000065225-956","JNS-PMJJBY-23-24-00000065793-668","JNS-PMJJBY-23-24-00000081586-890","JNS-PMJJBY-23-24-00000079289-893","JNS-PMJJBY-23-24-00000080998-064","JNS-PMJJBY-23-24-00000790696-226","JNS-PMJJBY-23-24-00000795104-385","JNS-PMJJBY-23-24-00000791353-751","JNS-PMJJBY-23-24-00000793414-693","JNS-PMJJBY-23-24-00001777958-493").iterator();
////		Iterator<String> timeStmp = Arrays.asList("2023-09-04 00:00:00","2023-09-04 00:00:00","2023-09-04 00:00:00","2023-09-04 00:00:00","2023-09-06 00:00:00","2023-09-07 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-11 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-12 00:00:00","2023-09-13 00:00:00","2023-09-13 00:00:00","2023-09-13 00:00:00","2023-09-25 00:00:00","2023-09-25 00:00:00","2023-09-25 00:00:00","2023-09-25 00:00:00","2023-09-30 00:00:00").iterator();
////		Iterator<String> traUtr = Arrays.asList("S553392","S225465","S99776914","S1265386","S10089004","S39867798","S85406650","S11193366","S84523917","S86130558","S91685047","S85450369","S86689022","S87299062","S88212513","S29146919","S32055794","S30688595","S33244222","S29898033","S27944012","S29307807","S33959554","S29284446","S30808346","S72157089","S69753739","S71560084","S42795322","S44297797","S43019286","S43726688","S47010944").iterator();
////		
////		while (urn.hasNext() && timeStmp.hasNext() && traUtr.hasNext()) {
////			Map<String, Object> map = new HashMap<>();
////			map.put("\"" + "urn" + "\" ", "\"" + urn.next() + "\" ");
////			map.put("\"" + "transactionAmount" + "\" ", "\"" + "342" + "\" ");
////			map.put("\"" + "masterPolicyNumber" + "\" ", "\"" + "G0001580" + "\" ");
////			map.put("\"" + "insurerCode" + "\" ", "\"" + "143" + "\" ");
////			map.put("\"" + "transactionType" + "\" ", "\"" + "1" + "\" ");
////			map.put("\"" + "transactionTimeStamp" + "\" ", "\"" + timeStmp.next() + "\" ");
////			map.put("\"" + "transactionUTR" + "\" ", "\"" + traUtr.next() + "\" ");
////			System.out.println(", " + map);
////		}
////	}
//}
