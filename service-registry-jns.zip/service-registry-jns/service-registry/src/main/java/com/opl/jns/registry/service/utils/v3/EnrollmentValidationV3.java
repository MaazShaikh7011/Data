package com.opl.jns.registry.service.utils.v3;

import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.PatternUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.ZoneId;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class EnrollmentValidationV3 {
	
    @Autowired
    private ApiConfigMasterRepo configMasterRepo;

	public String checkEnrollmentDetailsValidations(EnrollmentReqProxyV3 enrollmentDetails) throws ParseException {
        StringBuilder stringBuilder = new StringBuilder();
	       if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails)) {
	    	    StringBuilder s1 = checkCustomerDetailsValidations(enrollmentDetails);
	    	    StringBuilder s2 = checkNomineeGuardianValidations(enrollmentDetails);
	    	    stringBuilder.append(s1);
	    	    stringBuilder.append(s2);
	        } else {
	        	stringBuilder.append("Enrollment details not found");
	        }
	       return stringBuilder.toString();
	}
	
	public StringBuilder checkCustomerDetailsValidations(EnrollmentReqProxyV3 enrollmentDetails) throws ParseException {		
		 StringBuilder s1 = new StringBuilder();
		 if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails()))
			 s1.append("Customer details not found");
		 else { 
//			if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getCif()))
//				s1.append("cif number is not found");
//			if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getAccountNumber()))
//				s1.append("customer account number is not found");
//			 if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getTransactionDetails().getSchemeName())) {
//					String scheme = enrollmentDetails.getTransactionDetails().getSchemeName();
//					if(scheme.equalsIgnoreCase(SchemeMaster.PMSBY.getShortName())) {
//						if (OPLUtils
//								.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getDisabilityStatus())) {
//							s1.append("Disability Status not found.");
//						} 
//						if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getDisabilityStatus())
//								&& !enrollmentDetails.getCustomerDetails().getDisabilityStatus()
//										.equalsIgnoreCase(YesNo.YES.getShortName())
//								&& !enrollmentDetails.getCustomerDetails().getDisabilityStatus()
//										.equalsIgnoreCase(YesNo.NO.getShortName())) {
//							s1.append("Disability status must be : Y or N");
//						}
//						if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getDisabilityStatus())
//								&& enrollmentDetails.getCustomerDetails().getDisabilityStatus()
//										.equalsIgnoreCase(YesNo.YES.getShortName())) {
//							if (OPLUtils.isObjectNullOrEmpty(
//									enrollmentDetails.getCustomerDetails().getDisabilityDetails())) {
//								s1.append(" Disability Details not found.");
//							}
//						}
//						
//					}
//				}
//				else {
//					s1.append("Please provide scheme in other details.");
//				}

			// DOB VALIDATION
				try {	
					Date dob = null;
					try {						
						dob = Date.from(enrollmentDetails.getCustomerDetails().getDob().atStartOfDay(ZoneId.systemDefault()).toInstant());
					}catch (Exception e) {
						log.warn("Applicant's date of birth format is invalid");
						s1.append("Applicant's date of birth format is invalid");
					}
					
					// CHECK ENROLLMENT AGE VALIDATION
					String enrollmentAgeLimit = null;
//					if (Objects.equals(enrollmentDetails.getTransactionDetails().getSchemeName(), SchemeMaster.PMJJBY.getShortName())) {
//						enrollmentAgeLimit = configMasterRepo.findByCodeAndIsActiveTrue(RegistryUtils.PMJJBY_ENROLLMENT_AGE_LIMIT).getValue();
//					} else {
//						enrollmentAgeLimit = configMasterRepo.findByCodeAndIsActiveTrue(RegistryUtils.PMSBY_ENROLLMENT_AGE_LIMIT).getValue();
//					}
					String[] enrollmentAgeLimitArray = null;
					enrollmentAgeLimitArray = enrollmentAgeLimit.split(",");

//					Boolean isAgeValid = com.opl.jns.utils.common.OPLUtils.getAgeCriteriaValidation(
//							SchemeMaster.getByCode(enrollmentDetails.getTransactionDetails().getSchemeName()).getId().intValue(),
//							dob,null, enrollmentAgeLimitArray);
//					
//					if(Boolean.FALSE.equals(isAgeValid)) {
//						s1.append(" As per bank records, you have exceeded the age criteria for the selected scheme. You will not be able to proceed here.");
//					}
				}catch (Exception e) {
					log.warn("Exception while dob validation",e);
				}
				s1 = kycIdValidation(enrollmentDetails.getKycDetails().getKycId1(), enrollmentDetails.getKycDetails().getKycIdValue1(), s1,"KYC ID1");
				
//				s1 = kycIdValidation(enrollmentDetails.getKycDetails().getKycId2(), enrollmentDetails.getKycDetails().getKycIdValue2(), s1,"KYC ID2");
				
		 }  
		return s1;
	}
	
	public static StringBuilder checkNomineeGuardianValidations(EnrollmentReqProxyV3 enrollmentDetails) {
		StringBuilder s1 = new StringBuilder();
		if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
			s1.append("Nominee details can not be empty");
        } else if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getDob())) {
            try {
                Date dob = Date.from(enrollmentDetails.getNomineeDetails().getDob().atStartOfDay(ZoneId.systemDefault()).toInstant());
                Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
                if (ageFromBirthDate < 18) {
                	if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails())) {
                		log.warn("age is less then 18 so guardian details is mandatory   AGE -> ({}),  YEAR -> ({})", enrollmentDetails.getNomineeDetails().getDob(), ageFromBirthDate);
                		s1.append("""
				                Guardian details can not be empty\
				                """);	
                	}
                	else {
                		  
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
//                			log.warn("Guardian First Name can not be null or empty.");
//                			s1.append("Guardian First Name can not be null or empty.");
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
//                			String firstName = enrollmentDetails.getGuardianDetails().getFirstName();
//                			if(findLength(firstName,1L,50L)) {
//                				log.warn("Guardian First Name must be between 1 and 50 Characters. -> ({}))", firstName);
//                				s1.append("Guardian First Name must be between 1 and 50 Characters.");
//                			}
//                		}
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
//                			log.warn("Guardian Address can not be null or empty.");
//                			s1.append("Guardian Address can not be null or empty.");
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
//                			String address = enrollmentDetails.getGuardianDetails().getAddress();
//                			if(findLength(address,2L,200L)) {
//                				log.warn("Guardian Address must be between 2 and 200 Characters. -> ({}))", address);
//                				s1.append("Guardian Address must be between 2 and 200 Characters.");
//                				}
//                		}
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getPincode())) {
//                			log.warn("Guardian Pincode can not be null or empty.");
//                			s1.append("Guardian Pincode can not be null or empty.");
//                          
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getPincode())) {
//                			String pincode = enrollmentDetails.getGuardianDetails().getPincode();
//                			if(findLength(pincode,6L,6L)) {
//                				log.warn("Guardian Pincode must be 6 Characters. -> ({}))", pincode);
//                				s1.append("Guardian Pincode must be 6 Characters.");       
//                			}
//                		}
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getState())) {
//                			log.warn("Guardian State can not be null or empty.");
//                			s1.append("Guardian State can not be null or empty.");
//                           
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getState())) {
//                			String state = enrollmentDetails.getGuardianDetails().getState();
//                			if(findLength(state,2L,200L)) {
//                				log.warn("Guardian State must be between 2 and 200 characters. -> ({}))", state);
//                				s1.append("Guardian State must be between 2 and 200 characters.");  
//                			}
//                		}
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getCity())) {
//                			log.warn("Guardian City can not be null or empty.");
//                			s1.append("Guardian City can not be null or empty.");                          
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getCity())) {
//                			String city = enrollmentDetails.getGuardianDetails().getCity();
//                			if(findLength(city,2L,200L)) {
//                				log.warn("Guardian City must be between 2 and 200 characters. -> ({}))", city);
//                				s1.append("Guardian City must be between 2 and 200 characters.");       
//                			}
//                		}
//                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getDistrict())) {
//                			log.warn("Guardian District can not be null or empty.");
//                			s1.append("Guardian District can not be null or empty.");                 
//                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getDistrict())) {
//                			String district = enrollmentDetails.getGuardianDetails().getDistrict();
//                			if(findLength(district,2L,200L)) {
//                				log.warn("Guardian District must be between 2 and 200 characters . -> ({}))", district);
//                				s1.append("Guardian District must be between 2 and 200 characters."); 
//                			}
//                		}
                		if(OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getRelationShip())) {
                			log.warn("Guardian RelationShip can not be null or empty.");
                			s1.append("Guardian RelationShip can not be null or empty.");
                		}else if(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getRelationShip())) {
                			String relationShip = enrollmentDetails.getGuardianDetails().getRelationShip();
                			try {	                			
	                			RelationShip rel = RelationShip.fromValue(relationShip);
	                			if(OPLUtils.isObjectNullOrEmpty(rel)) {
	                				log.warn("Guardian Provided Relationship not valid. -> ({}))", relationShip);
	                				s1.append("Guardian Provided Relationship(relationShip) not valid.");
	                			}
                			}
                			catch(Exception e) {
                				log.warn("Guardian Provided Relationship not valid. -> ({}))", relationShip);
                				s1.append("Guardian Provided Relationship not valid.");
                			}
                		}
                	}  
                }
            } catch (Exception e) {
                log.error(" Nominee birth date can not be parse", e);
                s1.append(" Nominee birth date can not be parse");
            }
        } else {
        	 s1.append("Nominee birth date can not be empty");
        }
	//	enrollmentProxy.setDeDupeMsg(s1.toString());
		return s1;
	}
	


	public static Boolean findLength(String key,Long min,Long max) {
	   if(key.length() < min  || key.length() > max) {
		   return Boolean.TRUE;
	   }
	   return Boolean.FALSE;
   }
	
	public static StringBuilder kycIdValidOrNot(String kycId,String kycIdName) {
		if(!kycId.equalsIgnoreCase(KycDocument.PAN.getKey()) && !kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey()) && !kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey()) &&
				!kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey()) && !kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey()) && !kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			return new StringBuilder(kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA");
		}
		return null;
	}
	
	
	public static CommonResponse kycIdNumberValidOrNot(String kycId,String kycIdNumber,String kycIdName) {
		if(kycId.equalsIgnoreCase(KycDocument.PAN.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PAN_PATTERN);
			java.util.regex.Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid pan number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.AADHAR_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid aadhar number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PASSPORT_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid passport number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.VOTERS_ID_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid voter id number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.DRIVING_LICENCE_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid driving licence number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}else if(kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.MGNREGA_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if(!matcher.matches()) {
				return new CommonResponse(kycIdName + " - Invalid mgnrega card number", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}
		return null;
	}
	
	public StringBuilder kycIdValidation(String kycId,String kycIdValue,StringBuilder builder,String kycIdName) {
		if (!OPLUtils.isObjectNullOrEmpty(kycId)) {
			StringBuilder sb1 = kycIdValidOrNot(kycId, kycIdName);
			if (!OPLUtils.isObjectNullOrEmpty(sb1)) {
				return builder.append(sb1);
			}
			if (!OPLUtils.isObjectNullOrEmpty(kycIdValue) && !kycIdValue.equalsIgnoreCase(RegistryUtils.AADHAR)) {
				CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(kycId,kycIdValue,kycIdName);
				if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
					return builder.append(commonResponsekycNo.getMessage());
				}
			}
		}
		return builder;
	}
}
