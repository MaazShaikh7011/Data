package com.opl.jns.registry.service.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequestV3;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.CustomerDetailsV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.KycDetailsV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.utils.YesNo;
import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.model.PincodeMasterResponse;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.enums.ApplicationStatus;
import com.opl.jns.published.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class GetterSetter {

	@Autowired
	private OneFormClient oneFormClient;
	
	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	/**
	 * PREPARE APPLICATION INFO ENTITY WHILE SAVING ENROLLMENT DETAILS API V2
	 * 
	 * @param applicationMaster
	 * @param enrollmentDetails
	 * @return
	 */
	public ApplicantInfo prepareApplicationInfoWhileSaveEnrollmentV2(ApplicationMasterV3 applicationMaster,
			EnrollmentReqProxyV2 enrollmentDetails) {
		// --------------SAVE
		// CUSTOMER_DETAILS--------------------------------------------------------------------
		ApplicantInfo applicantInfo = applicationMaster.getApplicantInfo();
		applicantInfo.setIfsc(enrollmentDetails.getOtherDetails().getBranchIFSC());
		applicantInfo.setDob(
				DateUtils.parse(enrollmentDetails.getCustomerDetails().getDob(), DateUtils.DateFormat.DD_MM_YYYY));
		applicantInfo.setCkyc(enrollmentDetails.getKycDetails().getCkyc());
		applicantInfo.setCkycNumber(enrollmentDetails.getKycDetails().getCkycNumber());
		applicantInfo.setKycId2(enrollmentDetails.getKycDetails().getKycId2());
		applicantInfo.setKycIdNumber2(enrollmentDetails.getKycDetails().getKycIdValue2());
		applicantInfo.setApplicationMaster(applicationMaster);
		return applicantInfo;
	}
	
	/**
	 * PREPARE APPLICATION INFO ENTITY WHILE SAVING ENROLLMENT DETAILS API V3
	 * 
	 * @param applicationMaster
	 * @param enrollmentDetails
	 * @return
	 */
	public ApplicantInfo prepareApplicationInfoWhileSaveEnrollmentV3(ApplicationMasterV3 applicationMaster,
			EnrollmentReqProxyV3 enrollmentDetails) {
		// --------------SAVE
		// CUSTOMER_DETAILS--------------------------------------------------------------------
		ApplicantInfo applicantInfo = applicationMaster.getApplicantInfo();
		applicantInfo.setOccupation(enrollmentDetails.getCustomerDetails().getApplicantOccupation());
		applicantInfo.setIfsc(enrollmentDetails.getCustomerDetails().getCustomerIFSC());
		applicantInfo.setDob(Date.from(enrollmentDetails.getCustomerDetails().getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()));
		applicantInfo.setApplicationMaster(applicationMaster);
		return applicantInfo;
	}
	
	/**
	 * PREPARE APPLICATION INFO ENTITY WHILE SAVING ENROLLMENT DETAILS API COMMON
	 * 
	 * @param applicationMaster
	 * @param customerDetails
	 * @param kycDetails
	 * @return
	 */
	public <T extends CustomerDetailsV1, S extends KycDetailsV1> ApplicantInfo prepareApplicationInfoCommonWhileSaveEnrollment(ApplicationMasterV3 applicationMaster,
																															   T customerDetails, S kycDetails) {
		// --------------SAVE
		// CUSTOMER_DETAILS--------------------------------------------------------------------

		ApplicantInfo applicantInfo = new ApplicantInfo();
		BeanUtils.copyProperties(customerDetails, applicantInfo);
		applicantInfo.setName(customerDetails.getAccountHolderName());
		applicantInfo.setGenderId(OPLUtils.isObjectNullOrEmpty(customerDetails.getGender()) ? null
				: Gender.fromBankValue(customerDetails.getGender()).getId());
		applicantInfo.setDisabilityStatus(customerDetails.getDisabilityStatus());
		applicantInfo.setEmail(customerDetails.getEmailId());
		applicantInfo.setKycId1(kycDetails.getKycId1());
		applicantInfo.setKycIdNumber1(kycDetails.getKycIdValue1());
		applicantInfo.setPan(kycDetails.getPanNumber());
		applicantInfo.setAadhaar(kycDetails.getAadhaarNumber());
		applicantInfo.setIsActive(true);
		applicantInfo.setCreatedDate(new Date());
		applicantInfo.setAppCreatedDate(applicationMaster.getCreatedDate());
		// SET ADDRESS IN Applicant Info
		AddressMasterV3 addressMaster = new AddressMasterV3();
		BeanUtils.copyProperties(customerDetails, addressMaster);
		addressMaster.setCityName(customerDetails.getCity());
		addressMaster.setDistrict(customerDetails.getDistrict());
		addressMaster.setStateName(customerDetails.getState());
		if (!OPLUtils.isObjectNullOrEmpty(customerDetails.getPincode())) {
			try {
				addressMaster.setPincode(Integer.valueOf(customerDetails.getPincode()));
				PincodeMasterResponse pincodeMaster = oneFormClient
						.getFirstPincodeMasterDetailsByPincode(customerDetails.getPincode());
				if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
					addressMaster.setCityId(pincodeMaster.getCityId());
					addressMaster.setStateId(pincodeMaster.getStateId());
				}
			} catch (Exception e) {
				log.info("Exception while getting pincode details ", e);
			}
		}
		applicantInfo.setAddress(addressMaster);
		addressMaster.setAppCreatedDate(applicationMaster.getCreatedDate());
		applicantInfo.setApplicationMaster(applicationMaster);
		return applicantInfo;
	}

	/**
	 * PREPARE NOMINEE DETAILS ENTITY WHILE SAVING ENROLLMENT DETAILS API V2
	 * 
	 * @param applicationMaster
	 * @param enrollmentDetails
	 * @throws ParseException
	 * @throws OneFormException
	 */
	public List<NomineeDetails> prepareNomineeDetailsWhileSaveEnrollmentV2(ApplicationMasterV3 applicationMaster,
			EnrollmentReqProxyV2 enrollmentDetails) throws ParseException, OneFormException {

		List<NomineeDetails> nomineeMasters = new ArrayList<>();
		Date curruntDate = new Date();
		/* Guardian */
		NomineeDetails nomineeGuardian = new NomineeDetails();
		Date dob = new SimpleDateFormat(DateUtils.DateFormat.DD_MM_YYYY)
				.parse(enrollmentDetails.getNomineeDetails().getDob());
		Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
		if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails()) && ageFromBirthDate < 18) {
			nomineeGuardian.setAppCreatedDate(applicationMaster.getCreatedDate());
			nomineeGuardian.setType(NomineeType.GUARDIAN.getId());
			nomineeGuardian.setRelationId(
					OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getRelationShip()) ? null
							: RelationShip.fromValue(enrollmentDetails.getGuardianDetails().getRelationShip()).getId());
			BeanUtils.copyProperties(enrollmentDetails.getGuardianDetails(), nomineeGuardian);
			AddressMasterV3 address = new AddressMasterV3();
			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
				address.setAddressLine1(enrollmentDetails.getGuardianDetails().getAddress());
			}
			address.setCityName(enrollmentDetails.getGuardianDetails().getCity());
			address.setStateName(enrollmentDetails.getGuardianDetails().getState());
			address.setDistrict(enrollmentDetails.getGuardianDetails().getDistrict());
			address.setAppCreatedDate(applicationMaster.getCreatedDate());
			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getPincode())) {
				try {
					address.setPincode(Integer.valueOf(enrollmentDetails.getGuardianDetails().getPincode()));
					PincodeMasterResponse pincodeMaster = oneFormClient
							.getFirstPincodeMasterDetailsByPincode(enrollmentDetails.getGuardianDetails().getPincode());
					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
						address.setCityId(pincodeMaster.getCityId());
						address.setStateId(pincodeMaster.getStateId());
					}
				} catch (Exception e) {
					log.info("Exception while getting pincode details ", e);
				}
			}
			nomineeGuardian.setAddress(address);

			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
				StringBuilder s1 = new StringBuilder();
				s1.append(enrollmentDetails.getGuardianDetails().getFirstName()).append(" ");
				if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getMiddleName()))
					s1.append(enrollmentDetails.getGuardianDetails().getMiddleName()).append(" ");
				if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getLastName()))
					s1.append(enrollmentDetails.getGuardianDetails().getLastName());
				nomineeGuardian.setName(s1.toString());
			}
			nomineeGuardian.setEmail(enrollmentDetails.getGuardianDetails().getEmail());
			nomineeGuardian.setMobileNumber(enrollmentDetails.getGuardianDetails().getMobile());
			nomineeGuardian.setCreatedDate(curruntDate);
			nomineeGuardian.setIsActive(Boolean.TRUE);
//			nomineeGuardian.setCreatedBy(userId);
			nomineeGuardian.setApplicationMaster(applicationMaster);
			nomineeMasters.add(nomineeGuardian);
		}

		/* Nominee */
		NomineeDetails nomineeDetails = new NomineeDetails();
		if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
			nomineeDetails.setAppCreatedDate(applicationMaster.getCreatedDate());
			nomineeDetails.setType(NomineeType.NOMINEE.getId());
			nomineeDetails.setRelationId(
					OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getRelationShip()) ? null
							: RelationShip.fromValue(enrollmentDetails.getNomineeDetails().getRelationShip()).getId());
			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), nomineeDetails);
			AddressMasterV3 address = new AddressMasterV3();
			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), address);
			address.setCityName(enrollmentDetails.getNomineeDetails().getCity());
			address.setStateName(enrollmentDetails.getNomineeDetails().getState());
			address.setDistrict(enrollmentDetails.getNomineeDetails().getDistrict());
			address.setAppCreatedDate(applicationMaster.getCreatedDate());
			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getPincode())) {
				address.setPincode(Integer.valueOf(enrollmentDetails.getNomineeDetails().getPincode().trim()));
				try {
					PincodeMasterResponse pincodeMaster = oneFormClient
							.getFirstPincodeMasterDetailsByPincode(enrollmentDetails.getNomineeDetails().getPincode());
					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
						address.setCityId(pincodeMaster.getCityId());
						address.setStateId(pincodeMaster.getStateId());
					}
				} catch (Exception e) {
					log.error("Exception while fetching pincode  {} for Nominee Exception :{}",
							enrollmentDetails.getNomineeDetails().getPincode(), e);
				}
			}
			nomineeDetails.setAddress(address);

			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getFirstName())) {
				StringBuilder s1 = new StringBuilder();
				s1.append(enrollmentDetails.getNomineeDetails().getFirstName()).append(" ");
				if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getMiddleName()))
					s1.append(enrollmentDetails.getNomineeDetails().getMiddleName()).append(" ");
				if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getLastName()))
					s1.append(enrollmentDetails.getNomineeDetails().getLastName());
				nomineeDetails.setName(s1.toString());
			}
			nomineeDetails.setMobileNumber(enrollmentDetails.getNomineeDetails().getMobile());
			nomineeDetails.setDob(dob);
			nomineeDetails.setApplicationMaster(applicationMaster);
			nomineeDetails.setIsActive(Boolean.TRUE);
			nomineeDetails.setIsOtherClaimant(Boolean.FALSE);
			nomineeDetails.setCreatedDate(curruntDate);
//			nomineeDetails.setCreatedBy(userId);
			nomineeMasters.add(nomineeDetails);
		}

		return nomineeMasters;
	}
	
	/**
	 * PREPARE NOMINEE DETAILS ENTITY WHILE SAVING ENROLLMENT DETAILS API V3
	 * 
	 * @param applicationMaster
	 * @param enrollmentDetails
	 * @return
	 */
	public List<NomineeDetails> prepareNomineeDetailsWhileSaveEnrollmentV3(ApplicationMasterV3 applicationMaster,
			EnrollmentReqProxyV3 enrollmentDetails) {

		List<NomineeDetails> nomineeMasters = new ArrayList<>();
		Date curruntDate = new Date();
		/* Guardian */
		NomineeDetails nomineeGuardian = new NomineeDetails();
		Date dob = Date.from(enrollmentDetails.getNomineeDetails().getDob().atStartOfDay(ZoneId.systemDefault()).toInstant());
		Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
		if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails()) && ageFromBirthDate < 18) {
			nomineeGuardian.setType(NomineeType.GUARDIAN.getId());
			nomineeGuardian.setRelationId(
					OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getRelationShip()) ? null
							: RelationShip.fromValue(enrollmentDetails.getGuardianDetails().getRelationShip()).getId());
			BeanUtils.copyProperties(enrollmentDetails.getGuardianDetails(), nomineeGuardian);
			AddressMasterV3 address = new AddressMasterV3();
			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddressofGuardian())) {
				address.setAddressLine1(enrollmentDetails.getGuardianDetails().getAddressofGuardian());
				address.setAppCreatedDate(applicationMaster.getCreatedDate());
			}
			nomineeGuardian.setAddress(address);

			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getGuradianName())) {
				nomineeGuardian.setName(enrollmentDetails.getGuardianDetails().getGuradianName());
			}
			nomineeGuardian.setEmail(enrollmentDetails.getGuardianDetails().getEmailId());
			nomineeGuardian.setMobileNumber(enrollmentDetails.getGuardianDetails().getMobile());
			nomineeGuardian.setCreatedDate(curruntDate);
			nomineeGuardian.setIsActive(Boolean.TRUE);
			nomineeGuardian.setAppCreatedDate(applicationMaster.getCreatedDate());
//			nomineeGuardian.setCreatedBy(userId);
			nomineeGuardian.setApplicationMaster(applicationMaster);
			nomineeMasters.add(nomineeGuardian);
		}

		/* Nominee */
		NomineeDetails nomineeDetails = new NomineeDetails();
		if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
			nomineeDetails.setType(NomineeType.NOMINEE.getId());
			nomineeDetails.setRelationId(
					OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getRelationShip()) ? null
							: RelationShip.fromValue(enrollmentDetails.getNomineeDetails().getRelationShip()).getId());
			nomineeDetails.setEmail(enrollmentDetails.getNomineeDetails().getEmailId());
			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), nomineeDetails);
			AddressMasterV3 address = new AddressMasterV3();
			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), address);
			address.setAddressLine1(enrollmentDetails.getNomineeDetails().getAddressOfNominee());
			address.setAppCreatedDate(applicationMaster.getCreatedDate());
			nomineeDetails.setAddress(address);

			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getNomineeName())) {
				nomineeDetails.setName(enrollmentDetails.getNomineeDetails().getNomineeName());
			}
			nomineeDetails.setMobileNumber(enrollmentDetails.getNomineeDetails().getMobile());
			nomineeDetails.setDob(dob);
			nomineeDetails.setApplicationMaster(applicationMaster);
			nomineeDetails.setIsActive(Boolean.TRUE);
			nomineeDetails.setIsOtherClaimant(Boolean.FALSE);
			nomineeDetails.setCreatedDate(curruntDate);
			nomineeDetails.setAppCreatedDate(applicationMaster.getCreatedDate());
//			nomineeDetails.setCreatedBy(userId);
			nomineeMasters.add(nomineeDetails);
		}

		return nomineeMasters;
	}
	
	/**
	 * SET APPLICATION MASTER COMPLETED DETAILS IF TRANSACTION DETAILS ARE VALID
	 * @param applicationMaster
	 * @param curruntDate
	 * @param tranTimeStamp
	 * @param userId
	 * @param currentInsurerDetails
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T extends RegistryReqProxy, U extends ApplicationMasterV3> U updateApplicationMaster(
			ApplicationMasterV3 applicationMaster, Date curruntDate, Date tranTimeStamp, Long userId,
			InsurerMstDetailsV3 currentInsurerDetails, T in) {
		UpdateTransReqProxyV1 transactionRequest = (UpdateTransReqProxyV1) in;
		applicationMaster.setStageId(EnrollStageMaster.COMPLETED.getStageId());
		applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_COMPLETED.getId());
		applicationMaster.setStatusChangeDate(curruntDate);
		applicationMaster.setModifiedDate(curruntDate);
		applicationMaster.setModifiedBy(userId);
		applicationMaster.setEnrollmentDate(tranTimeStamp);
		applicationMaster.setCompletionDate(new Date());
		applicationMaster.setPremiumAmount(transactionRequest.getTransactionAmount());
		applicationMaster.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
		return (U) applicationMaster;
	}

	/**
	 * PREPARE TRANSACTION DFTAILS OBJECT
	 * @param transactionRequest
	 * @param curruntDate
	 * @param tranTimeStamp
	 * @param userId
	 * @param currentInsurerDetails
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T extends UpdateTransReqProxyV1,U extends TransactionDetailsV3> U setTransactionDetailsCommon(T transactionRequest, Date curruntDate, Date tranTimeStamp, Long userId, InsurerMstDetailsV3 currentInsurerDetails,ApplicationMasterV3 applicationMasterV3) {
		TransactionDetailsV3 transactionDetails = new TransactionDetailsV3();
		transactionDetails.setCreatedDate(curruntDate);
		transactionDetails.setAppCreatedDate(applicationMasterV3.getCreatedDate());
		transactionDetails.setIsActive(Boolean.TRUE);
		transactionDetails.setTransTimeStamp(tranTimeStamp);
		transactionDetails.setTransAmount(transactionRequest.getTransactionAmount());
		transactionDetails.setMasterPolicyNo(transactionRequest.getMasterPolicyNumber());
		transactionDetails.setTransUtr(transactionRequest.getTransactionUTR());
		transactionDetails.setCreatedBy(userId);
		transactionDetails.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
		transactionDetails.setCoverEndDate(currentInsurerDetails.getPolicyEndDate());
		transactionDetails.setCoverStartDate(tranTimeStamp);
		String year = currentInsurerDetails.getYear().substring(0, 4);
		transactionDetails.setYear(OPLUtils.isObjectNullOrEmpty(year) ? null : Integer.valueOf(year));
		transactionDetails.setInsurerMaster(currentInsurerDetails);
		return (U) transactionDetails;
	}
	
	/**
	 * PREPARE TRANSACTION DFTAILS OBJECT V2
	 * @param transactionRequest
	 * @return
	 */
	public TransactionDetailsV3 setTransactionDetailsV2(UpdateTransReqProxyV2 transactionRequest, TransactionDetailsV3 transactionDetails) {
		transactionDetails.setType(OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()) ? null : Integer.parseInt(transactionRequest.getTransactionType()));
		transactionDetails.setInsurerCode(transactionRequest.getInsurerCode());
		return transactionDetails;
	}
	
	/**
	 * PREPARE TRANSACTION DFTAILS OBJECT V3
	 * @param transactionRequest
	 * @return
	 */
	public TransactionDetailsV3 setTransactionDetailsV3(UpdateTransReqProxyV3 transactionRequest, TransactionDetailsV3 transactionDetails) {
		transactionDetails.setType(OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionType()) ? null : Integer.parseInt(transactionRequest.getTransactionType()));
		transactionDetails.setInsurerCode(transactionRequest.getInsurerCode());
		return transactionDetails;
	}
	
//	public ClaimMasterV3 setClaimNomineeDetails(NomineeDetails existingNominee,
//			ClaimDetailsReqProxyV2 claimRequest, ClaimMasterV3 claimMaster, ApplicationMasterV3 applicationMaster,
//			Long orgId) {
//		existingNominee.setMobileNumber(claimRequest.getNomineeMobileNumber());
//		String existingNomineeEmail = OPLUtils.isObjectNullOrEmpty(existingNominee.getEmail()) ? null
//				: existingNominee.getEmail();
//		existingNominee.setEmail(OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeEmailId()) ? existingNomineeEmail
//				: claimRequest.getNomineeEmailId());
//		if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getNomineeNameCorrection())
//				&& claimRequest.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
//			existingNominee.setCorrectNomineeFirstName(claimRequest.getCorrectNomineeFirstName());
//			existingNominee.setCorrectNomineeMiddleName(claimRequest.getCorrectnomineeMiddleName());
//			existingNominee.setCorrectNomineeLastName(claimRequest.getCorrectnomineeLastName());
//		}
//		claimMaster=setClaimMaster(claimMaster, applicationMaster, orgId);
//		return claimMaster;
//	}
//	
//	public ClaimMasterV3 setClaimMaster(ClaimMasterV3 claimMaster, ApplicationMasterV3 applicationMaster,Long orgId) {
//		claimMaster = new ClaimMasterV3();
//		claimMaster.setClaimStageId(ClaimStageMaster.CLAIM_FORM.getStageId());
//		claimMaster.setSchemeId(applicationMaster.getSchemeId());
//		claimMaster.setOrgId(orgId);
//		claimMaster.setCreatedDate(new Date());
//		claimMaster.setApplicationMaster(applicationMaster);
//		claimMaster.setClaimStatus(ClaimStatus.CLAIM_IN_PROGRESS.getId());
//		claimMaster.setIsPushed(Boolean.FALSE);
//		claimMaster.setIsActive(Boolean.TRUE);
//		return claimMaster;
//	}
//	
//	public ClaimMasterV3 setClaimDetails(NomineeDetails existingNominee,
//			ClaimDetailsReqProxyV2 claimRequest, ClaimMasterV3 claimMaster, ApplicationMasterV3 applicationMaster) {
//		ClaimDetailV3 detail = new ClaimDetailV3();
//		// set scheme wise fields
//		if (applicationMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()) {
//			detail.setDateOfDeath(
//					DateUtils.parse(claimRequest.getDateOfDeath(), DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS));
//			detail.setCauseOfDeathDisabilityId(
//					CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeath()).getId());
//			if (detail.getCauseOfDeathDisability() == CauseOfDeathDisability.ACCIDENTAL_30_DAYS) {
//				detail.setDateTimeOfAccident(
//						DateUtils.parse(claimRequest.getDateOfAccident(), DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS));
//			}
//		} else if (applicationMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue()) {
//			detail.setDayOfAccident(claimRequest.getDayOfAccident());
//			detail.setLocationOfLoss(claimRequest.getPlaceOfAccident());
//			detail.setNatureOfLossId(NatureOfLoss.fromBankValue(claimRequest.getNatureOfAccident()).getId());
//			if (claimRequest.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
//				detail.setTypeOfDisablityId(TypeOfDisability.fromBankValue(claimRequest.getTypeOfDisability()).getId());
//			}
//			detail.setDateTimeOfAccident(
//					DateUtils.parse(claimRequest.getDateOfAccident(), DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS));
//			detail.setCauseOfDeathDisabilityId(
//					OPLUtils.isObjectNullOrEmpty(claimRequest.getCauseOfDeathDisability()) ? null
//							: CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeathDisability()).getId());
//		}
//
//		// kyc details
//		Integer[] kycId = new Integer[2];
//		KycDocument kycDocument1 = KycDocument.fromBankValue(claimRequest.getClaimantKYC1());
//		kycId[0] = kycDocument1.getId();
//		setKycDocument(kycDocument1.getId(), detail, claimRequest.getClaimantKYCNumber1());
//
//		if (!OPLUtils.isObjectNullOrEmpty(claimRequest.getClaimantKYC2())) {
//			KycDocument kycDocument2 = KycDocument.fromBankValue(claimRequest.getClaimantKYC2());
//			kycId[1] = kycDocument2.getId();
//			setKycDocument(kycDocument2.getId(), detail, claimRequest.getClaimantKycNumber2());
//		}
//
//		detail.setKycDocId(Arrays.toString(kycId).replace("[", "").replace("]", ""));
//
//		// saving existing nominee changes
//		List<NomineeDetails> nomineeDetails = new ArrayList<>();
//		nomineeDetails.add(existingNominee);
//		// append guardian and claimant
//		setClaimantAndGuardianDetails(applicationMaster, claimRequest, nomineeDetails);
//		applicationMaster.setNomineeDetails(nomineeDetails);
//		applicationMaster = applicationMasterRepository.save(applicationMaster);
//		claimMaster.setApplicationMaster(applicationMaster);
//		detail.setClaimMaster(claimMaster);
//		claimMaster.setClaimDetail(detail);
//		return claimMasterRepo.save(claimMaster);
//	}
//	
//	public ClaimMasterV3 setClaimDetailsV3(NomineeDetails existingNominee,
//			ClaimDetailsReqProxyV3 claimRequest, ClaimMasterV3 claimMaster, ApplicationMasterV3 applicationMaster) {
//		ClaimDetailV3 detail = new ClaimDetailV3();
//		// set scheme wise fields
//		if (applicationMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()) {
//			detail.setDateOfDeath(Date.from(claimRequest.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant()));
//			detail.setCauseOfDeathDisabilityId(
//					CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeath()).getId());
//			if (detail.getCauseOfDeathDisability() == CauseOfDeathDisability.ACCIDENTAL_30_DAYS) {
//				detail.setDateTimeOfAccident(Date.from(LocalDateTime
//						.of(claimRequest.getDateOfAccident(), LocalTime.parse(claimRequest.getTimeOfAccident()))
//						.atZone(ZoneId.systemDefault()).toInstant()));
//			}
//		} else if (applicationMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue()) {
//			detail.setDayOfAccident(claimRequest.getDayOfAccident());
//			detail.setLocationOfLoss(claimRequest.getPlaceOfOccurence());
//			detail.setNatureOfLossId(NatureOfLoss.fromBankValue(claimRequest.getNatureOfAccident()).getId());
//			if (claimRequest.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
//				detail.setTypeOfDisablityId(TypeOfDisability.fromBankValue(claimRequest.getTypeOfDisability()).getId());
//			}
//			detail.setDateTimeOfAccident(Date.from(LocalDateTime
//					.of(claimRequest.getDateOfAccident(), LocalTime.parse(claimRequest.getTimeOfAccident()))
//					.atZone(ZoneId.systemDefault()).toInstant()));
//			detail.setCauseOfDeathDisabilityId(
//					OPLUtils.isObjectNullOrEmpty(claimRequest.getCauseOfDeathDisability()) ? null
//							: CauseOfDeathDisability.fromBankValue(claimRequest.getCauseOfDeathDisability()).getId());
//		}
//
//		// kyc details
//		Integer[] kycId = new Integer[1];
//		KycDocument kycDocument1 = KycDocument.fromBankValue(claimRequest.getClaimantKYC1());
//		kycId[0] = kycDocument1.getId();
//		setKycDocument(kycDocument1.getId(), detail, claimRequest.getClaimantKYCNumber1());
//		detail.setKycDocId(Arrays.toString(kycId).replace("[", "").replace("]", ""));
//		detail.setClaimantBankAccountNumber(claimRequest.getClaimantBankAccountNumber());
//		detail.setCustIfscCode(claimRequest.getCustomerIFSC());
//		
//		// saving existing nominee changes
//		List<NomineeDetails> nomineeDetails = new ArrayList<>();
//		nomineeDetails.add(existingNominee);
//		// append guardian and claimant
//		setClaimantAndGuardianDetailsV3(applicationMaster, claimRequest, nomineeDetails);
//		applicationMaster.setNomineeDetails(nomineeDetails);
//		applicationMaster = applicationMasterRepository.save(applicationMaster);
//		claimMaster.setApplicationMaster(applicationMaster);
//		detail.setClaimMaster(claimMaster);
//		claimMaster.setClaimDetail(detail);
//		return claimMasterRepo.save(claimMaster);
//	}
	
	private List<NomineeDetails> setClaimantAndGuardianDetails(ApplicationMasterV3 applicationMaster,
															   ClaimDetailsReqProxyV2 claimDetail, List<NomineeDetails> nomineeDetails) {

		/** Guardian */
		if (!OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianMobileNumber())
				&& !OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianEmailId())) {
			applicationMaster.getNomineeDetails().stream()
					.filter(x -> Objects.equals(x.getType(), NomineeType.GUARDIAN.getId())).findAny()
					.ifPresent(guardian -> {
						String guardianEmail = OPLUtils.isObjectNullOrEmpty(guardian.getEmail()) ? null
								: guardian.getEmail();
						guardian.setEmail(OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianEmailId()) ? guardianEmail
								: claimDetail.getGuardianEmailId());
						guardian.setType(NomineeType.GUARDIAN.getId());
						guardian.setMobileNumber(claimDetail.getGuardianMobileNumber());
						nomineeDetails.add(guardian);
					});

		}

		/* Nominee */
		NomineeDetails claimant = new NomineeDetails();
		if (!OPLUtils.isObjectNullOrEmpty(claimDetail.getIsNomineePredeceased())
				&& claimDetail.getIsNomineePredeceased().equalsIgnoreCase(YesNo.YES.getValue())) {
			claimant.setType(NomineeType.CLAIMANT.getId());
			claimant.setRelationId(OPLUtils.isObjectNullOrEmpty(claimDetail.getRelationOfClaimant()) ? null
					: RelationShip.fromValue(claimDetail.getRelationOfClaimant()).getId());
			claimant.setName(claimDetail.getClaimantFirstName());
			claimant.setMobileNumber(claimDetail.getClaimantMobileNumber());
			claimant.setDob(OPLUtils.isObjectNullOrEmpty(claimDetail.getClaimantDateOfBirth()) ? null
					: DateUtils.parse(claimDetail.getClaimantDateOfBirth(), DateUtils.DateFormat.YYYY_MM_DD));
			claimant.setIsActive(Boolean.TRUE);
			claimant.setIsOtherClaimant(Boolean.FALSE);
			claimant.setCreatedDate(new Date());
			AddressMasterV3 address = new AddressMasterV3();
			address.setAddressLine1(claimDetail.getClaimantAddressLine1());
			address.setAddressLine2(claimDetail.getClaimantAddressLine2());
			address.setCityName(claimDetail.getClaimantCity());
			address.setDistrict(claimDetail.getClaimantDistrict());
			address.setStateName(claimDetail.getClaimantState());
			address.setPincode(claimDetail.getClaimantPincode());
			claimant.setAddress(address);
			claimant.setApplicationMaster(applicationMaster);
			nomineeDetails.add(claimant);
		}

		return nomineeDetails;
	}
	
	private List<NomineeDetails> setClaimantAndGuardianDetailsV3(ApplicationMasterV3 applicationMaster,
																 ClaimDetailsReqProxyV3 claimDetail, List<NomineeDetails> nomineeDetails) {

		/** Guardian */
		if (!OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianMobileNumber())
				&& !OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianEmailId())) {
			applicationMaster.getNomineeDetails().stream()
					.filter(x -> Objects.equals(x.getType(), NomineeType.GUARDIAN.getId())).findAny()
					.ifPresent(guardian -> {
						String guardianEmail = OPLUtils.isObjectNullOrEmpty(guardian.getEmail()) ? null
								: guardian.getEmail();
						guardian.setEmail(OPLUtils.isObjectNullOrEmpty(claimDetail.getGuardianEmailId()) ? guardianEmail
								: claimDetail.getGuardianEmailId());
						guardian.setType(NomineeType.GUARDIAN.getId());
						guardian.setMobileNumber(claimDetail.getGuardianMobileNumber());
						nomineeDetails.add(guardian);
					});

		}

		/* Nominee */
		NomineeDetails claimant = new NomineeDetails();
		if (!OPLUtils.isObjectNullOrEmpty(claimDetail.getIsNomineePredeceased())
				&& claimDetail.getIsNomineePredeceased().equalsIgnoreCase(YesNo.YES.getValue())) {
			claimant.setType(NomineeType.CLAIMANT.getId());
			claimant.setRelationId(OPLUtils.isObjectNullOrEmpty(claimDetail.getRelationshipOfClaimant()) ? null
					: RelationShip.fromValue(claimDetail.getRelationshipOfClaimant()).getId());
			claimant.setName(claimDetail.getClaimantName());
			claimant.setMobileNumber(claimDetail.getClaimantMobileNumber());
			claimant.setDob(OPLUtils.isObjectNullOrEmpty(claimDetail.getClaimantDateOfBirth()) ? null
					: Date.from(claimDetail.getClaimantDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			claimant.setIsActive(Boolean.TRUE);
			claimant.setIsOtherClaimant(Boolean.FALSE);
			claimant.setCreatedDate(new Date());
			AddressMasterV3 address = new AddressMasterV3();
			address.setAddressLine1(claimDetail.getClaimantAddress());
			claimant.setAddress(address);
			claimant.setApplicationMaster(applicationMaster);
			nomineeDetails.add(claimant);
		}

		return nomineeDetails;
	}
	
	public NomineeUpdateStatusRequestV3 prepareNomineeUpdateStatusRequest(
			ApplicationMasterBothSchemeProxy applicationMaster, NomineeDetailsV2 nomineeDetailsV2,
			NomineePIDetails nomineePIDetails) {
		NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq = new NomineeUpdateStatusRequestV3();
		nomineeUpdateStatusReq.setApplicationId(applicationMaster.getId());
		nomineeUpdateStatusReq.setOrgId(applicationMaster.getOrgId());
		nomineeUpdateStatusReq.setUrn(applicationMaster.getUrn());
		nomineeUpdateStatusReq.setNomineeUpdateFlag("YES");
		nomineeUpdateStatusReq.setNomineeName(nomineePIDetails.getName());
		nomineeUpdateStatusReq.setNomineeDateOfBirth(!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getDob())
				? nomineePIDetails.getDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		nomineeUpdateStatusReq.setNomineeMobileNumber(nomineeDetailsV2.getMobileNumber());
		nomineeUpdateStatusReq.setNomineeEmailId(nomineeDetailsV2.getEmail());
		nomineeUpdateStatusReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getRelationId())
				? RelationShip.fromId(nomineeDetailsV2.getRelationId()).getValue()
				: null);
		nomineeUpdateStatusReq.setAddressOfNominee(nomineePIDetails.getAddressLine1());
		nomineeUpdateStatusReq.setNameOfGuardian(nomineePIDetails.getGdName());
		nomineeUpdateStatusReq.setAddressOfGuardian(nomineePIDetails.getGdAddress());
		nomineeUpdateStatusReq
				.setRelationshipOfGuardian(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getGdRelationId())
						? RelationShip.fromId(nomineeDetailsV2.getGdRelationId()).getValue()
						: null);
		nomineeUpdateStatusReq.setGuardianMobileNumber(nomineeDetailsV2.getGdMobile());
		nomineeUpdateStatusReq.setGuardianEmailId(nomineeDetailsV2.getGdEmail());
		return nomineeUpdateStatusReq;
	}

//	private void setKycDocument(Integer kycId, ClaimDetailV3 claimDetailV3, String value) {
//		if (Objects.equals(KycDocument.PAN.getId(), kycId)) {
//			claimDetailV3.setPan(value);
//		} else if (Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
//			claimDetailV3.setPassport(value);
//		} else if (Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
//			claimDetailV3.setDrivingLicense(value);
//		} else if (Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
//			claimDetailV3.setMgnerega(value);
//		} else if (Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
//			claimDetailV3.setVottingCardId(value);
//		}
//	}

}
