package com.opl.jns.registry.service.utils;

import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.client.OneFormClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Component("GetCommonData")
@Slf4j
public class GetCommonData {

    public static List<LgdDistrictStateResponse> STATE_DISTRICT_LIST;
    public static List<LgdDistrictStateResponse> STATE_LIST;

    @Async
    public void getStateDistrictData(OneFormClient oneFormClient) {
        try {
            log.info("In getStateDistrictData() ----------> ");
            List<LgdDistrictStateResponse> collectList = oneFormClient.getLgdDistrictStateMaster().stream()
                    .sorted(Comparator.comparing(LgdDistrictStateResponse::getLgdStateCode).thenComparing(LgdDistrictStateResponse::getLgdDistrictCode))
                    .collect(Collectors.toList());
            STATE_DISTRICT_LIST = Collections.unmodifiableList(collectList);
            STATE_LIST = Collections.unmodifiableList(new ArrayList<>(collectList.stream().collect(Collectors.toMap(LgdDistrictStateResponse::getStateId, p -> p, (p, q) -> p)).values()));
            log.info("STATE_LIST Size ----------> {}", STATE_LIST.size());
        } catch (Exception e) {
            log.error("Exception in getStateDistrictData() --------------> ", e);
        }
    }
}
