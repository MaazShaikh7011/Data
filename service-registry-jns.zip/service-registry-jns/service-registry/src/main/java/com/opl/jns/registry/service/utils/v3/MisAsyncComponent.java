package com.opl.jns.registry.service.utils.v3;

import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.DistrictWiseData;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisCommonProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.registry.service.domain.JnsEnrlData;
import com.opl.jns.registry.service.domain.MisDataDocDetails;
import com.opl.jns.registry.service.domain.MisEnrlData;
import com.opl.jns.registry.service.domain.WeekMaster;
import com.opl.jns.registry.service.repository.JnsEnrlDataRepo;
import com.opl.jns.registry.service.repository.MisDataDocDetailsRepo;
import com.opl.jns.registry.service.repository.MisEnrlDataRepo;
import com.opl.jns.registry.service.repository.WeekMasterRepository;
import com.opl.jns.registry.service.utils.GetCommonData;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class MisAsyncComponent {

    public static final long MIS_ENROL_PRO_DOC_MAP_ID = 92L;
    public static final long MIS_RENEWAL_PRO_DOC_MAP_ID = 91L;

    @Autowired
    private UsersClient usersClient;

    @Autowired
    private DMSClient dmsClient;

    @Autowired
    private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

    @Autowired
    private MisEnrlDataRepo misEnrlDataRepo;

    @Autowired
    private MisDataDocDetailsRepo misDataDocDetailsRepo;

    @Autowired
    private Environment environment;

    @Autowired
    private WeekMasterRepository weekMasterRepository;

    @Autowired
    private JnsEnrlDataRepo jnsEnrlDataRepo;

    @PersistenceContext
    private EntityManager entityManager;


    private static final SchemeMaster PMSBYScheme = SchemeMaster.PMSBY;
    private static final SchemeMaster PMJJBYScheme = SchemeMaster.PMJJBY;
    //    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd MMMM yyyy");
    private static final String DATE_FORMAT = "dd MMMM yyyy";
    private static final String DATE_FORMAT_FOR_FILE_NAME = "ddMMyy";

    @Value("${com.jns.common.config.hibernateJdbcBatchSize}")
    private String CHUNK_SIZE;

    private static final int THREAD_POOL_SIZE = 2;

    /*
     * SAVE BANK REQUESTED DATA WITH VERSION OF IN_PROGRESS STATUS
     * IF PREVIOS VERSION OF DATA ARE EXISTS THEN CONSOLIDATE IT WITH REQUESTED DATA AND SAVE
     * */
    @Async
    public void saveRequestedData(MisEnrollmentReqV3 misEnrollmentReq) {
        try {
            Long orgId = misEnrollmentReq.getOrgId();
            Integer type = TransactionTypeEnum.getByType(misEnrollmentReq.getType()).getId();

            log.info("Calling prepareRequest() -----------> ");
            prepareRequest(misEnrollmentReq, orgId);

            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);

            List<MisEnrlData> lastInsertedDataList = new ArrayList<>();
            if ("ENROLL".equalsIgnoreCase(misEnrollmentReq.getType())) {
                log.info("Getting lastInsertedData -----------> ");
                lastInsertedDataList = misEnrlDataRepo.findAllByVersionAndTypeAndOrgId(weekMaster.getId() - 1, type, orgId);
            }

            log.info("Getting existingData -----------> ");
            List<MisEnrlData> existingDataList = misEnrlDataRepo.findAllByVersionAndTypeAndOrgId(weekMaster.getId(), type, orgId);

            log.info("last updated data count {} for orgId {}", lastInsertedDataList.size(), orgId);
            log.info("existing data count {} for orgId {}", existingDataList.size(), orgId);

            log.info("Calling saveMisData() -----------> ");
            saveMisData(misEnrollmentReq, lastInsertedDataList, existingDataList, weekMaster);
        } catch (Exception e) {
            log.error("Exception in saveRequestedData() -------> ", e);
        }
    }

    @Transactional(readOnly = true)
    private void prepareRequest(MisEnrollmentReqV3 misEnrollmentReq, Long orgId) throws IOException {
        log.info("Getting organisationData -----------> ");
        UserOrganisationMasterResponse organisationData = getOrganizationByOrgId(orgId);
        if (OPLUtils.isObjectNullOrEmpty(organisationData)) {
            log.info("organisationData is null or empty.");
            return;
        }
        misEnrollmentReq.setBankName(organisationData.getDisplayOrgName());
        misEnrollmentReq.setBankShortName(organisationData.getOrganisationCode());
        misEnrollmentReq.setBankCode(organisationData.getBankType());
        misEnrollmentReq.setBankCategory(organisationData.getOrgCategory());

        log.info("Getting PMSBYInsurerDetail -----------> ");
        InsurerMstDetailsV3 PMSBYInsurerDetail = getInsurerBySchemeAndOrg(PMSBYScheme.getId(), orgId);
        if (OPLUtils.isObjectNullOrEmpty(PMSBYInsurerDetail)) {
            log.info("PMSBYInsurerDetail is null or empty.");
            return;
        }
        misEnrollmentReq.setPMSBYInsurerOrgId(PMSBYInsurerDetail.getInsurerOrgId());
        misEnrollmentReq.setPMSBYInsurerCode(PMSBYInsurerDetail.getInsurerCode());

        log.info("Getting PMSBYInsurerOrgData -----------> ");
        UserOrganisationMasterResponse PMSBYInsurerOrgData = getOrganizationByOrgId(misEnrollmentReq.getPMSBYInsurerOrgId());
        if (OPLUtils.isObjectNullOrEmpty(PMSBYInsurerOrgData)) {
            log.info("PMSBYInsurerOrgData is null or empty.");
            return;
        }
        misEnrollmentReq.setPMSBYInsurerName(PMSBYInsurerOrgData.getDisplayOrgName());

        log.info("Getting PMJJYInsurerDetail -----------> ");
        InsurerMstDetailsV3 PMJJYInsurerDetail = getInsurerBySchemeAndOrg(PMJJBYScheme.getId(), orgId);
        if (OPLUtils.isObjectNullOrEmpty(PMJJYInsurerDetail)) {
            log.info("PMJJYInsurerDetail is null or empty.");
            return;
        }
        misEnrollmentReq.setPMJJBYInsurerOrgId(PMJJYInsurerDetail.getInsurerOrgId());
        misEnrollmentReq.setPMJJBYInsurerCode(PMJJYInsurerDetail.getInsurerCode());

        log.info("Getting PMJJBYInsurerOrgData -----------> ");
        UserOrganisationMasterResponse PMJJBYInsurerOrgData = getOrganizationByOrgId(misEnrollmentReq.getPMJJBYInsurerOrgId());
        if (OPLUtils.isObjectNullOrEmpty(PMJJBYInsurerOrgData)) {
            log.info("PMJJYInsurerOrgData is null or empty.");
            return;
        }
        misEnrollmentReq.setPMJJBYInsurerName(PMJJBYInsurerOrgData.getDisplayOrgName());
    }

    @Transactional(readOnly = true)
    private InsurerMstDetailsV3 getInsurerBySchemeAndOrg(Long schemeId, Long orgId) {
        return insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId,
                orgId, new Date(), new Date());
    }

    @Transactional(readOnly = true)
    private UserOrganisationMasterResponse getOrganizationByOrgId(Long orgId) throws IOException {
        CommonResponse commonResponse = usersClient.getOrganizationById(orgId);
        if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
            return MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), UserOrganisationMasterResponse.class);
        }
        log.info("Something went worng while getting organization data ---------> {}", commonResponse);
        return null;
    }

    /*
     * IF PREVIOS VERSION OF DATA ARE EXISTS THEN CONSOLIDATE WITH NEW DATA
     * ELSE SET REQUESTED DATA AS IT IS
     * */
    @Transactional
    private void saveMisData(MisEnrollmentReqV3 misEnrollmentReq, List<MisEnrlData> lastInsertedDataList, List<MisEnrlData> existingDataList, WeekMaster weekMaster) {
        List<MisEnrlData> latestMisEnrlDataList = new ArrayList<>();
        List<MisEnrlData> misRenewalDataList = null;
        if (misEnrollmentReq.getType().equalsIgnoreCase(TransactionTypeEnum.ENROLLMENT.getType()) && weekMaster.getIsRenewalUpdated()) {
            misRenewalDataList = getRenewalDataList(misEnrollmentReq.getOrgId());
        }
        for (DistrictWiseData districtWiseData : misEnrollmentReq.getDistrictList()) {
            if (lastInsertedDataList.isEmpty()) {
                // SAVE PMJJBY DATA
                MisEnrlData misEnrlDataPMJJBY = new MisEnrlData();
                BeanUtils.copyProperties(districtWiseData.getPmjjby(), misEnrlDataPMJJBY);
                setMisCommonData(misEnrlDataPMJJBY, PMJJBYScheme, misEnrollmentReq);
                setStateDistrict(misEnrlDataPMJJBY, districtWiseData.districtCode);
                misEnrlDataPMJJBY.setCastSt(districtWiseData.getPmjjby().getCaste().st);
                misEnrlDataPMJJBY.setCastSc(districtWiseData.getPmjjby().getCaste().sc);
                misEnrlDataPMJJBY.setCastObc(districtWiseData.getPmjjby().getCaste().obc);
                misEnrlDataPMJJBY.setCastGeneral(districtWiseData.getPmjjby().getCaste().general);
                misEnrlDataPMJJBY.setVersion(weekMaster.getId());

                if (misEnrollmentReq.getType().equalsIgnoreCase(TransactionTypeEnum.ENROLLMENT.getType())) {
                    log.info("Calling setActiveCountData() -------------> ");
                    setActiveCountData(misEnrlDataPMJJBY, lastInsertedDataList, misRenewalDataList, weekMaster.getIsYearChange());
                }

                if (!OPLUtils.isListNullOrEmpty(existingDataList)) {
                    log.info("Calling checkExistingRecord() -----------> ");
                    checkExistingRecord(misEnrlDataPMJJBY, existingDataList);
                }

                latestMisEnrlDataList.add(misEnrlDataPMJJBY);

                // SAVE PMSBY DATA
                MisEnrlData misEnrlDataPMSBY = new MisEnrlData();
                BeanUtils.copyProperties(districtWiseData.getPmsby(), misEnrlDataPMSBY);
                setMisCommonData(misEnrlDataPMSBY, PMSBYScheme, misEnrollmentReq);
                setStateDistrict(misEnrlDataPMSBY, districtWiseData.districtCode);
                misEnrlDataPMSBY.setCastSt(districtWiseData.getPmsby().getCaste().st);
                misEnrlDataPMSBY.setCastSc(districtWiseData.getPmsby().getCaste().sc);
                misEnrlDataPMSBY.setCastObc(districtWiseData.getPmsby().getCaste().obc);
                misEnrlDataPMSBY.setCastGeneral(districtWiseData.getPmsby().getCaste().general);
                misEnrlDataPMSBY.setVersion(weekMaster.getId());

                if (misEnrollmentReq.getType().equalsIgnoreCase(TransactionTypeEnum.ENROLLMENT.getType())) {
                    log.info("Calling setActiveCountData() -------------> ");
                    setActiveCountData(misEnrlDataPMSBY, lastInsertedDataList, misRenewalDataList, weekMaster.getIsYearChange());
                }

                if (!OPLUtils.isListNullOrEmpty(existingDataList)) {
                    log.info("Calling checkExistingRecord() -----------> ");
                    checkExistingRecord(misEnrlDataPMSBY, existingDataList);
                }
                latestMisEnrlDataList.add(misEnrlDataPMSBY);
            } else {
                // SAVE PMJJBY DATA
                MisEnrlData misEnrlData = getLatestData(districtWiseData.getPmjjby(), PMJJBYScheme, districtWiseData.getDistrictCode(), lastInsertedDataList, misRenewalDataList, misEnrollmentReq, weekMaster.getIsYearChange());
                misEnrlData.setVersion(weekMaster.getId());

                if (!OPLUtils.isListNullOrEmpty(existingDataList)) {
                    log.info("Calling checkExistingRecord() -----------> ");
                    checkExistingRecord(misEnrlData, existingDataList);
                }
                latestMisEnrlDataList.add(misEnrlData);

                // SAVE PMSBY DATA
                misEnrlData = getLatestData(districtWiseData.getPmsby(), PMSBYScheme, districtWiseData.getDistrictCode(), lastInsertedDataList, misRenewalDataList, misEnrollmentReq, weekMaster.getIsYearChange());

                if (!OPLUtils.isListNullOrEmpty(existingDataList)) {
                    log.info("Calling checkExistingRecord() -----------> ");
                    checkExistingRecord(misEnrlData, existingDataList);
                }
                misEnrlData.setVersion(weekMaster.getId());
                latestMisEnrlDataList.add(misEnrlData);
            }
        }
        if (!latestMisEnrlDataList.isEmpty()) {
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            misEnrlDataRepo.saveAllAndFlush(latestMisEnrlDataList);
//            saveAllData(latestMisEnrlDataList);
            stopWatch.stop();
            double totalTimeSeconds = stopWatch.getTotalTimeSeconds();
            log.info("Data saved successfully. ::::>> {} seconds", totalTimeSeconds);
        }
    }

    private List<MisEnrlData> getRenewalDataList(Long orgId) {
        MisEnrlData misEnrlDataTemp = misEnrlDataRepo.findFirstByTypeAndOrgIdOrderByVersionDesc(TransactionTypeEnum.RENEWAL.getId(), orgId);
        if (!OPLUtils.isObjectNullOrEmpty(misEnrlDataTemp))
            return misEnrlDataRepo.findAllByVersionAndTypeAndOrgId(misEnrlDataTemp.getVersion(), TransactionTypeEnum.RENEWAL.getId(), orgId);
        return null;
    }

    /*
     * SAVE MIS-DATA (1530 AT A TIME) USING THREAD POOL EXECUTOE
     * */
//    private void saveAllData(List<MisEnrlData> latestMisEnrlDataList) {
//        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
//        int chunkSize = Integer.parseInt(CHUNK_SIZE) * 2;
//        // Divide the data into chunks
//        for (int i = 0; i < latestMisEnrlDataList.size(); i += chunkSize) {
//            final List<MisEnrlData> chunk = latestMisEnrlDataList.subList(i, Math.min(i + chunkSize, latestMisEnrlDataList.size()));
//            // Submit task to the ExecutorService for saving data in parallel
//            executorService.submit(() -> {
//                misEnrlDataRepo.saveAll(chunk);
//            });
//        }
//        // Shutdown the ExecutorService
//        executorService.shutdown();
//
//        // Wait for all tasks to complete
//        while (!executorService.isTerminated()) {
//            // Do nothing, wait for tasks to complete
//        }
//    }

    /*
     * IF DATA ALREADY EXISTS WITH CURRENT VERSION THEN UPDATE DATA AND SET ID
     * */
    private void checkExistingRecord(MisEnrlData misEnrlData, List<MisEnrlData> existingDataList) {
        log.info("In checkExistingRecord() ---------------> ");
        MisEnrlData existingDate = existingDataList.stream().filter(obj -> Objects.equals(misEnrlData.getLgdStateCode(), obj.getLgdStateCode())
                && Objects.equals(misEnrlData.getLgdDistrictCode(), obj.getLgdDistrictCode())
                && Objects.equals(misEnrlData.getSchemeId(), obj.getSchemeId())).findFirst().orElse(null);
        if (!OPLUtils.isObjectNullOrEmpty(existingDate)) {
            log.info("Existing data get for orgId {}, insurerCode {}, stateCode {} and districtCode {} "
                    , misEnrlData.getOrgId(), misEnrlData.getInsurerCode(), misEnrlData.getLgdStateCode(), misEnrlData.getLgdDistrictCode());
            misEnrlData.setId(existingDate.getId());
        }
    }

    /*
     * PREPARING CONSOLIDATED OBJECT WITH PREVIOUS VERSION OF OBJECT TO SAVE
     * */
    @Transactional(readOnly = true)
    private <T extends MisCommonProxy> MisEnrlData getLatestData(T t, SchemeMaster schemeMaster, String districtCode,
                                                                 List<MisEnrlData> lastInsertedDataList, List<MisEnrlData> misRenewalDataList, MisEnrollmentReqV3 misEnrollmentReq, boolean isYearChange) {
        log.info("In getLatestData() ---------> ");
        MisEnrlData misEnrlData = new MisEnrlData();

        log.info("Calling setMisCommonData() ---------> ");
        setMisCommonData(misEnrlData, schemeMaster, misEnrollmentReq);

        log.info("Calling setStateDistrict() ---------> ");
        setStateDistrict(misEnrlData, districtCode);

        log.info("Calling setCalculatedData() ---------> ");
        setCalculatedData(t, misEnrlData, lastInsertedDataList, misEnrollmentReq.getType(), isYearChange, misRenewalDataList);

        return misEnrlData;
    }

    /*
     * SET COMMON DATA
     * */
    @Transactional(readOnly = true)
    private void setMisCommonData(MisEnrlData misEnrlData, SchemeMaster schemeMaster, MisEnrollmentReqV3 misEnrollmentReq) {
        log.info("In setMisCommonData() ---------> ");

        misEnrlData.setToDate(Date.from(misEnrollmentReq.toDate.atZone(ZoneId.systemDefault()).toInstant()));
        misEnrlData.setFromDate(Date.from(misEnrollmentReq.fromDate.atZone(ZoneId.systemDefault()).toInstant()));
        misEnrlData.setToken(misEnrollmentReq.getToken());
        misEnrlData.setType(TransactionTypeEnum.getByType(misEnrollmentReq.type).getId());
        misEnrlData.setCreatedDate(DateUtils.parse(DateUtils.setDateFormat(DATE_FORMAT, new Date()), DATE_FORMAT));
//        try {
//            misEnrlData.setCreatedDate(DATE_FORMAT.parse(DATE_FORMAT.format(new Date())));
//            misEnrlData.setCreatedDate(DateUtils.parse(DateUtils.setDateFormat(DATE_FORMAT, new Date()), DATE_FORMAT));
//        } catch (ParseException e) {
//            log.error("Error while parsing todays date -----> {}", e.getMessage());
//            misEnrlData.setCreatedDate(new Date());
//        }
        misEnrlData.setUserId(misEnrollmentReq.getUserId());
        misEnrlData.setOrgId(misEnrollmentReq.getOrgId());
        misEnrlData.setStorageId(misEnrollmentReq.getStorageId());

        misEnrlData.setSchemeId(schemeMaster.getId().intValue());
        misEnrlData.setSchemeName(schemeMaster.getShortName());

        if (Objects.equals(schemeMaster.getId(), PMJJBYScheme.getId())) {
            misEnrlData.setInsurerName(misEnrollmentReq.getPMJJBYInsurerName());
            misEnrlData.setInsurerCode(misEnrollmentReq.getPMJJBYInsurerCode());
        } else {
            misEnrlData.setInsurerName(misEnrollmentReq.getPMSBYInsurerName());
            misEnrlData.setInsurerCode(misEnrollmentReq.getPMSBYInsurerCode());
        }

        misEnrlData.setBankName(misEnrollmentReq.getBankName());
        misEnrlData.setBankShortName(misEnrollmentReq.getBankShortName());
        misEnrlData.setBankCode(misEnrollmentReq.getBankCode());
        misEnrlData.setBankCategory(misEnrollmentReq.getBankCategory());
    }

    /*
     * SET STATE(NAME, CODE) AND DISTRICT(NAME, CODE)
     * */
    private void setStateDistrict(MisEnrlData misEnrlData, String districtCode) {
        // PENDING TO SET STATE-DISTRICT DETAILS
        LgdDistrictStateResponse lgdDistrictStateResponse = GetCommonData.STATE_DISTRICT_LIST.stream().filter(obj -> Objects.equals(obj.getLgdDistrictCode(), districtCode)).findFirst().orElse(null);
        if (!OPLUtils.isObjectNullOrEmpty(lgdDistrictStateResponse)) {
            misEnrlData.setStateName(lgdDistrictStateResponse.getStateName());
            misEnrlData.setLgdStateCode(lgdDistrictStateResponse.getLgdStateCode());
            misEnrlData.setDistrictName(lgdDistrictStateResponse.getDistrictName());
            misEnrlData.setLgdDistrictCode(lgdDistrictStateResponse.getLgdDistrictCode());
        } else {
            log.info("LgdDistrictStateResponse is null for districtCode -----------> {}", districtCode);
        }
    }

    /*
     * DOING CONSOLIDATION WITH PREVIOUS VERSION OF DATA
     * */
    @Transactional(readOnly = true)
    private <T extends MisCommonProxy> void setCalculatedData(T t, MisEnrlData misEnrlData, List<MisEnrlData> lastInsertedDataList, String type, boolean isYearChange, List<MisEnrlData> misRenewalDataList) {
        log.info("In setCalculatedData() ---------> ");
        String[] ignoreDataFields = {"createdDate", "userId", "orgId", "storageId", "schemeId", "schemeName", "insurerName", "insurerCode", "bankName", "bankCode", "bankCategory", "type", "stateName", "lgdStateCode", "districtName", "lgdDistrictCode"};

        BeanUtils.copyProperties(t, misEnrlData, ignoreDataFields);
        misEnrlData.setCastSt(t.getCaste().st);
        misEnrlData.setCastSc(t.getCaste().sc);
        misEnrlData.setCastObc(t.getCaste().obc);
        misEnrlData.setCastGeneral(t.getCaste().general);

        if (type.equalsIgnoreCase(TransactionTypeEnum.ENROLLMENT.getType())) {
            log.info("Calling setActiveCountData() ---------> ");
            setActiveCountData(misEnrlData, lastInsertedDataList, misRenewalDataList, isYearChange);
        }

        MisEnrlData lastData = lastInsertedDataList.stream()
                .filter(obj -> Objects.equals(obj.getSchemeId(), misEnrlData.getSchemeId())
                        && Objects.equals(obj.getLgdDistrictCode(), misEnrlData.getLgdDistrictCode()))
                .findFirst()
                .orElse(null);

        if (!OPLUtils.isObjectNullOrEmpty(lastData)) {
            misEnrlData.setElgSvngAccHldr(misEnrlData.getElgSvngAccHldr() + lastData.getElgSvngAccHldr());
            misEnrlData.setElgPMJDYHldr(misEnrlData.getElgPMJDYHldr() + lastData.getElgPMJDYHldr());
            misEnrlData.setRuralMale(misEnrlData.getRuralMale() + lastData.getRuralMale());
            misEnrlData.setRuralFemale(misEnrlData.getRuralFemale() + lastData.getRuralFemale());
            misEnrlData.setRuralTransG(misEnrlData.getRuralTransG() + lastData.getRuralTransG());
            misEnrlData.setUrbanMale(misEnrlData.getUrbanMale() + lastData.getUrbanMale());
            misEnrlData.setUrbanFemale(misEnrlData.getUrbanFemale() + lastData.getUrbanFemale());
            misEnrlData.setUrbanTransG(misEnrlData.getUrbanTransG() + lastData.getUrbanTransG());
            misEnrlData.setTotalEnrolment(misEnrlData.getTotalEnrolment() + lastData.getTotalEnrolment());
            misEnrlData.setPrmclctdruralMale(misEnrlData.getPrmclctdruralMale() + lastData.getPrmclctdruralMale());
            misEnrlData.setPrmclctdruralFemale(misEnrlData.getPrmclctdruralFemale() + lastData.getPrmclctdruralFemale());
            misEnrlData.setPrmclctdruralTransG(misEnrlData.getPrmclctdruralTransG() + lastData.getPrmclctdruralTransG());
            misEnrlData.setPrmclctdurbanMale(misEnrlData.getPrmclctdurbanMale() + lastData.getPrmclctdurbanMale());
            misEnrlData.setPrmclctdurbanFemale(misEnrlData.getPrmclctdurbanFemale() + lastData.getPrmclctdurbanFemale());
            misEnrlData.setPrmclctdurbanTransG(misEnrlData.getPrmclctdurbanTransG() + lastData.getPrmclctdurbanTransG());
            misEnrlData.setTotalPrmclctdNwErollment(misEnrlData.getTotalPrmclctdNwErollment() + lastData.getTotalPrmclctdNwErollment());
            misEnrlData.setRecordsTransmittedToInsurer(misEnrlData.getRecordsTransmittedToInsurer() + lastData.getRecordsTransmittedToInsurer());
            misEnrlData.setPremiumPaidToInsurer(misEnrlData.getPremiumPaidToInsurer() + lastData.getPremiumPaidToInsurer());
            misEnrlData.setAadharSeeded(misEnrlData.getAadharSeeded() + lastData.getAadharSeeded());
            misEnrlData.setMobileSeeded(misEnrlData.getMobileSeeded() + lastData.getMobileSeeded());
            misEnrlData.setEmailSeeded(misEnrlData.getEmailSeeded() + lastData.getEmailSeeded());
            misEnrlData.setPmjdyEnrolled(misEnrlData.getPmjdyEnrolled() + lastData.getPmjdyEnrolled());
            misEnrlData.setMgnregaEnrolled(misEnrlData.getMgnregaEnrolled() + lastData.getMgnregaEnrolled());
            misEnrlData.setMudraEnrolled(misEnrlData.getMudraEnrolled() + lastData.getMudraEnrolled());
            misEnrlData.setKccEnrolled(misEnrlData.getKccEnrolled() + lastData.getKccEnrolled());
            misEnrlData.setOtherSchemeEnrolled(misEnrlData.getOtherSchemeEnrolled() + lastData.getOtherSchemeEnrolled());
            if (!OPLUtils.isObjectNullOrEmpty(misEnrlData.getInsufficientAcHolders()) && !OPLUtils.isObjectNullOrEmpty(lastData.getInsufficientAcHolders())) {
                misEnrlData.setInsufficientAcHolders(misEnrlData.getInsufficientAcHolders() + lastData.getInsufficientAcHolders());
            } else {
                misEnrlData.setInsufficientAcHolders(lastData.getInsufficientAcHolders());
            }
            misEnrlData.setCastSc(misEnrlData.getCastSc() + lastData.getCastSc());
            misEnrlData.setCastSt(misEnrlData.getCastSt() + lastData.getCastSt());
            misEnrlData.setCastObc(misEnrlData.getCastObc() + lastData.getCastObc());
            misEnrlData.setCastGeneral(misEnrlData.getCastGeneral() + lastData.getCastGeneral());
            misEnrlData.setNomineeAvlb(misEnrlData.getNomineeAvlb() + lastData.getNomineeAvlb());
            misEnrlData.setFrshEnrol1JuneCrrntYear(misEnrlData.getFrshEnrol1JuneCrrntYear() + lastData.getFrshEnrol1JuneCrrntYear());
            misEnrlData.setRenewals1JuneCrrntYear(misEnrlData.getRenewals1JuneCrrntYear() + lastData.getRenewals1JuneCrrntYear());
            if (!OPLUtils.isObjectNullOrEmpty(misEnrlData.getPrmdebitedRs()) && !OPLUtils.isObjectNullOrEmpty(lastData.getPrmdebitedRs())) {
                misEnrlData.setPrmdebitedRs(misEnrlData.getPrmdebitedRs() + lastData.getPrmdebitedRs());
            } else {
                misEnrlData.setPrmdebitedRs(lastData.getPrmdebitedRs());
            }
        }
    }

    private void setActiveCountData(MisEnrlData misEnrlData, List<MisEnrlData> lastInsertedDataList, List<MisEnrlData> misRenewalDataList, boolean isYearChange) {
        log.info("In setActiveCountData() -------------> ");

        MisEnrlData misEnrlLastInsertedData = lastInsertedDataList.stream().filter(obj -> Objects.equals(obj.getOrgId(), misEnrlData.getOrgId())
                && Objects.equals(obj.getInsurerCode(), misEnrlData.getInsurerCode())
                && Objects.equals(obj.getLgdDistrictCode(), misEnrlData.getLgdDistrictCode())
                && Objects.equals(obj.getSchemeId(), misEnrlData.getSchemeId())).findFirst().orElse(null);

        MisEnrlData misRenewalData = null;

        if (!OPLUtils.isListNullOrEmpty(misRenewalDataList)) {
            misRenewalData = misRenewalDataList.stream().filter(obj -> Objects.equals(obj.getOrgId(), misEnrlData.getOrgId())
                    && Objects.equals(obj.getInsurerCode(), misEnrlData.getInsurerCode())
                    && Objects.equals(obj.getLgdDistrictCode(), misEnrlData.getLgdDistrictCode())
                    && Objects.equals(obj.getSchemeId(), misEnrlData.getSchemeId())).findFirst().orElse(null);
        }
        misEnrlData.setActiveRuralMale(misEnrlData.getRuralMale() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveRuralMale() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getRuralMale() : 0L));

        misEnrlData.setActiveRuralFemale(misEnrlData.getRuralFemale() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveRuralFemale() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getRuralFemale() : 0L));

        misEnrlData.setActiveRuralTransG(misEnrlData.getRuralTransG() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveRuralTransG() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getRuralTransG() : 0L));

        misEnrlData.setActiveUrbanMale(misEnrlData.getUrbanMale() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveUrbanMale() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getUrbanMale() : 0L));

        misEnrlData.setActiveUrbanFemale(misEnrlData.getUrbanFemale() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveUrbanFemale() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getUrbanFemale() : 0L));

        misEnrlData.setActiveUrbanTransG(misEnrlData.getUrbanTransG() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveUrbanTransG() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getUrbanTransG() : 0L));

        misEnrlData.setActiveTotalEnrolment(misEnrlData.getTotalEnrolment() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveTotalEnrolment() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getTotalEnrolment() : 0L));

        misEnrlData.setActiveAadharSeeded(misEnrlData.getAadharSeeded() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveAadharSeeded() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getAadharSeeded() : 0L));

        misEnrlData.setActiveMobileSeeded(misEnrlData.getMobileSeeded() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveMobileSeeded() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getMobileSeeded() : 0L));

        misEnrlData.setActiveEmailSeeded(misEnrlData.getEmailSeeded() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveEmailSeeded() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getEmailSeeded() : 0L));

        misEnrlData.setActiveCastSc(misEnrlData.getCastSc() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveCastSc() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getCastSc() : 0L));

        misEnrlData.setActiveCastSt(misEnrlData.getCastSt() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveCastSt() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getCastSt() : 0L));

        misEnrlData.setActiveCastGeneral(misEnrlData.getCastGeneral() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveCastGeneral() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getCastGeneral() : 0L));

        misEnrlData.setActiveCastObc(misEnrlData.getCastObc() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveCastObc() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getCastObc() : 0L));

        misEnrlData.setActivePmjdyEnrolled(misEnrlData.getPmjdyEnrolled() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActivePmjdyEnrolled() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getPmjdyEnrolled() : 0L));

        misEnrlData.setActiveMgnregaEnrolled(misEnrlData.getMgnregaEnrolled() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveMgnregaEnrolled() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getMgnregaEnrolled() : 0L));

        misEnrlData.setActiveKccEnrolled(misEnrlData.getKccEnrolled() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveKccEnrolled() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getKccEnrolled() : 0L));

        misEnrlData.setActiveMudraEnrolled(misEnrlData.getMudraEnrolled() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveMudraEnrolled() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getMudraEnrolled() : 0L));

        misEnrlData.setActiveOtherSchemeEnrolled(misEnrlData.getOtherSchemeEnrolled() +
                (!OPLUtils.isObjectNullOrEmpty(misEnrlLastInsertedData) && !isYearChange ? misEnrlLastInsertedData.getActiveOtherSchemeEnrolled() : 0L) +
                (!OPLUtils.isObjectNullOrEmpty(misRenewalData) ? misRenewalData.getOtherSchemeEnrolled() : 0L));

        log.info("Exit from setActiveCountData() -------------> ");
    }

    /*
     * SET DATA IN EXCEL AND UPLOAD IN DMS
     * */
    @Async
    @Transactional
    public void uploadExcelInDms(Integer type, Long version) {

//        if(Objects.equals(type, TransactionTypeEnum.RENEWAL.getId())) {
//            MisEnrlData misEnrlDataTemp = misEnrlDataRepo.findFirstByTypeAndOrgIdOrderByVersionDesc(TransactionTypeEnum.RENEWAL.getId(), orgId);
//            if(!OPLUtils.isObjectNullOrEmpty(misEnrlDataTemp))
//                version = misEnrlDataTemp.getVersion();
//        }

//      GETTING MIS DATA OF ALL BANKS AND BOTH SCHEMES BASED ON VERSION AND TYPE
        List<MisEnrlData> requestedData = misEnrlDataRepo.findAllByVersionAndType(version, type);
        if (OPLUtils.isListNullOrEmpty(requestedData)) {
            log.info("requestedData is null or empty");
            return;
        }

//      GETTING JNS DATA OF ALL BANKS AND BOTH SCHEMES BASED ON VERSION AND TYPE
        List<JnsEnrlData> jnsEnrlDataList = jnsEnrlDataRepo.findAllByVersionAndType(version, type);
        if (OPLUtils.isListNullOrEmpty(jnsEnrlDataList)) {
            log.info("jnsEnrlDataList is null or empty");
            return;
        }
        String path;
        Long productDocMapId = null;
//      GETTING FILE PATH AND SET PRODUCT-DOCUMENT-MAPPING-ID BASED ON REQUESTED PATH
        if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
            path = environment.getProperty("enrollment.file.path");
            productDocMapId = MIS_ENROL_PRO_DOC_MAP_ID;
        } else {
            path = environment.getProperty("renewal.file.path");
            productDocMapId = MIS_RENEWAL_PRO_DOC_MAP_ID;
        }

        log.info("In uploadExcelInDms() for file path ----------------> {}", path);
        if (OPLUtils.isObjectNullOrEmpty(path)) {
            log.info("File path is null or empty from application.properties ");
            return;
        }

        try {
            Workbook workbook = new XSSFWorkbook(OPCPackage.open(path));
            if (OPLUtils.isObjectNullOrEmpty(workbook)) {
                return;
            }
            String name;
            String fileName;
            WeekMaster weekMaster = weekMasterRepository.findById(version).orElse(null);
            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                fileName = "JNS_Mis_Enrollment_Data.xlsx";
            } else {
                fileName = "JNS_ENR_MIS_" + DateUtils.setDateFormat(DATE_FORMAT_FOR_FILE_NAME, weekMaster.getFromDate()) + "_" + DateUtils.setDateFormat(DATE_FORMAT_FOR_FILE_NAME, weekMaster.getToDate()) + ".xlsx";
            }
            if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
                name = "Enrollment Data";
            } else {
                name = "Renewal Data";
            }

            /* SET PMJJBY SCHEME DATA IN EXCEL SHEET */
            List<MisEnrlData> PMJJBYSchemeListData = requestedData.stream()
                    .filter(obj -> obj.getSchemeId() == PMJJBYScheme.getId().intValue())
                    .sorted(Comparator.comparing(MisEnrlData::getLgdStateCode).thenComparing(MisEnrlData::getOrgId))
                    .collect(Collectors.toList());

            List<JnsEnrlData> jnsPMJJBYStateDistrictDataList = jnsEnrlDataList.stream()
                    .filter(obj -> obj.getSchemeId() == PMJJBYScheme.getId().intValue())
                    .collect(Collectors.toList());

            log.info("Calling  writeDataInSheet() for scheme {} and type {}", PMJJBYScheme.getId(), type);
            writeBankWiseData(PMJJBYSchemeListData, jnsPMJJBYStateDistrictDataList, workbook, PMJJBYScheme.getId().intValue(), type);

            if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
                log.info("Calling writeTotalDataInSheet() for scheme {} and type {}", PMJJBYScheme.getId(), type);
                writeConsolidatedData(PMJJBYSchemeListData, jnsPMJJBYStateDistrictDataList, workbook, PMJJBYScheme.getId().intValue());

                log.info("Calling writeActiveData() for scheme {} and type {}", PMJJBYScheme.getId(), type);
                writeActiveData(PMJJBYSchemeListData, jnsPMJJBYStateDistrictDataList, workbook, PMJJBYScheme.getId().intValue());
            }

            /* SET PMSBY SCHEME DATA IN EXCEL SHEET */
            List<MisEnrlData> PMSBYSchemeListData = requestedData.stream()
                    .filter(obj -> obj.getSchemeId() == PMSBYScheme.getId().intValue())
                    .sorted(Comparator.comparing(MisEnrlData::getLgdStateCode).thenComparing(MisEnrlData::getOrgId))
                    .collect(Collectors.toList());

            List<JnsEnrlData> jnsPMSBYStateDistrictDataList = jnsEnrlDataList.stream()
                    .filter(obj -> obj.getSchemeId() == PMSBYScheme.getId().intValue())
                    .collect(Collectors.toList());

            log.info("Calling  writeDataInSheet() for scheme {} and type {}", PMSBYScheme.getId(), type);
            writeBankWiseData(PMSBYSchemeListData, jnsPMSBYStateDistrictDataList, workbook, PMSBYScheme.getId().intValue(), type);

            if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
                log.info("Calling writeTotalDataInSheet() for scheme {} and type {}", PMSBYScheme.getId(), type);
                writeConsolidatedData(PMSBYSchemeListData, jnsPMSBYStateDistrictDataList, workbook, PMSBYScheme.getId().intValue());

                log.info("Calling writeActiveData() for scheme {} and type {}", PMSBYScheme.getId(), type);
                writeActiveData(PMSBYSchemeListData, jnsPMSBYStateDistrictDataList, workbook, PMSBYScheme.getId().intValue());
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.createCellStyle().setLocked(true);
            workbook.write(baos);

            /* PREPARE DMS UPLOAD REQUEST AND UPLOAD EXCEL USING CLIENT */
            MultipartFile multipartFile = new MockMultipartFile(name, fileName, MediaType.ALL_VALUE, baos.toByteArray());

            DocumentRequest documentRequest = new DocumentRequest();
            documentRequest.setUserType("user");
            documentRequest.setProductDocumentMappingId(productDocMapId);
            documentRequest.setOriginalFileName(fileName);

            log.info("Calling dmsClient.uploadFile() -----------> ");
            DocumentResponse documentResponse = dmsClient.uploadFile(MultipleJSONObjectHelper.getStringfromObject(documentRequest), multipartFile);
            if (!OPLUtils.isObjectNullOrEmpty(documentResponse)
                    && Objects.equals(documentResponse.getStatus(), HttpStatus.OK.value())
                    && !OPLUtils.isObjectNullOrEmpty(documentResponse.getData())) {
                StorageDetailsResponse storageDetailsResponse = com.opl.jns.published.utils.common.MultipleJSONObjectHelper.getObjectFromObject(documentResponse.getData(), StorageDetailsResponse.class);
                saveDMSData(fileName, documentResponse.getStatus(), storageDetailsResponse.getId(), TransactionTypeEnum.getById(type.longValue()).getType(), new Date(), version);
            } else {
                log.info("Document Failure Response --------------> {}", documentResponse);
                saveDMSData(fileName, documentResponse != null ? documentResponse.getStatus() : null, null, TransactionTypeEnum.getById(type.longValue()).getType(), new Date(), version);
            }
        } catch (Exception e) {
            log.error("Exception in uploadExcelInDms() -----------------> ", e);
        }
    }

//    ================================================================================================================================================

    /*
     * SET DATA IN EXCEL BANK AND SCHEME WISE
     * */
    @Transactional(readOnly = true)
    private void writeBankWiseData(List<MisEnrlData> dataToWrite, List<JnsEnrlData> jnsEnrlDataList, Workbook workbook, Integer schemeId, Integer type) {
        log.info("In writeDataInSheet() ---------> ");
        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " Bank Wise Data");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " Bank Wise Data");
        }
        int index = 1;
        for (MisEnrlData misEnrlData : dataToWrite) {
            JnsEnrlData jnsEnrlData = jnsEnrlDataList.stream()
                    .filter(obj -> (misEnrlData.getLgdStateCode().equals(obj.getStateCode())
                            && misEnrlData.getLgdDistrictCode().equals(obj.getDistrictCode())
                            && misEnrlData.getOrgId().equals(obj.getOrgId())))
                    .findFirst().orElse(null);

            int cellId = 0;
            Row row = sheet.createRow(index);
            row.createCell(cellId, CellType.STRING).setCellValue(misEnrlData.getStateName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getLgdStateCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getDistrictName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getLgdDistrictCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankShortName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getInsurerCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankCategory());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getElgSvngAccHldr());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getElgPMJDYHldr());
            if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
                setEnrollData(row, cellId, misEnrlData, jnsEnrlData);
            } else {
                setRenewalData(row, cellId, misEnrlData, jnsEnrlData);
            }
            index++;
        }
    }

    /*
     * SET ENROLLMENT DATA IN EXCEL
     * */
    private void setEnrollData(Row row, int cellId, MisEnrlData misEnrlData, JnsEnrlData jnsEnrlData) {
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRuralMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRuralFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRuralTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getUrbanMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getUrbanFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getUrbanTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getTotalEnrolment());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getTotalReceivedEnrollments());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getTotalPrmclctdNwErollment());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getCalculatedPremium());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRecordsTransmittedToInsurer());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getPushedEnrollments());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPremiumPaidToInsurer());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getPushedPremium());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getAadharSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMobileSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getEmailSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPmjdyEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getFrshEnrol1JuneCrrntYear());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRenewals1JuneCrrntYear());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getNomineeAvlb());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastGeneral());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastSc());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastSt());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastObc());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMgnregaEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getKccEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMudraEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getOtherSchemeEnrolled());
    }

    /*
     * SET RENEWAL DATA IN EXCEL
     * */
    private void setRenewalData(Row row, int cellId, MisEnrlData misEnrlData, JnsEnrlData jnsEnrlData) {
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getTotalPrmclctdNwErollment());
//        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsStateDistrictData) ? 0 : jnsStateDistrictData.getCalculatedPremium());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRecordsTransmittedToInsurer());
//        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsStateDistrictData) ? 0 : jnsStateDistrictData.getTotalEnrollments());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanMale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdurbanFemale());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmclctdruralTransG());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPrmdebitedRs());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPremiumPaidToInsurer());
//        row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsStateDistrictData) ? 0 : jnsStateDistrictData.getPushedPremium());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getInsufficientAcHolders());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getPmjdyEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getAadharSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMobileSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getEmailSeeded());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getNomineeAvlb());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastGeneral());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastSc());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastSt());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getCastObc());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMgnregaEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getKccEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getMudraEnrolled());
        row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getOtherSchemeEnrolled());
    }

    /*
     * SET CONSOLIDATED DATA OF ALL ORG'S IN EXCEL SCHEME WISE
     * */
    @Transactional(readOnly = true)
    private void writeConsolidatedData(List<MisEnrlData> dataToWrite, List<JnsEnrlData> jnsEnrlDataList, Workbook workbook, Integer schemeId) {
        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " Consolidated Data");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " Consolidated Data");
        }
        int index = 1;
        for (LgdDistrictStateResponse lgdDistrictStateResponse : GetCommonData.STATE_DISTRICT_LIST) {
            int cellId = 0;
            List<MisEnrlData> finalData = dataToWrite.stream().filter(a -> lgdDistrictStateResponse.getLgdStateCode().equals(a.getLgdStateCode()) && lgdDistrictStateResponse.getLgdDistrictCode().equals(a.getLgdDistrictCode())).collect(Collectors.toList());
            List<JnsEnrlData> finalJNSData = jnsEnrlDataList.stream().filter(a -> lgdDistrictStateResponse.getLgdStateCode().equals(a.getStateCode()) && lgdDistrictStateResponse.getLgdDistrictCode().equals(a.getDistrictCode())).collect(Collectors.toList());
            Row row = sheet.createRow(index);
            row.createCell(cellId, CellType.STRING).setCellValue(lgdDistrictStateResponse.getStateName());
            row.createCell(++cellId, CellType.STRING).setCellValue(lgdDistrictStateResponse.getLgdStateCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(lgdDistrictStateResponse.getDistrictName());
            row.createCell(++cellId, CellType.STRING).setCellValue(lgdDistrictStateResponse.getLgdDistrictCode());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getElgSvngAccHldr).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getElgPMJDYHldr).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getRuralMale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getRuralFemale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getRuralTransG).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getUrbanMale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getUrbanFemale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getUrbanTransG).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getTotalEnrolment).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalJNSData.stream().map(JnsEnrlData::getTotalReceivedEnrollments).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdruralMale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdruralFemale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdurbanTransG).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdurbanMale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdurbanFemale).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPrmclctdruralTransG).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getTotalPrmclctdNwErollment).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalJNSData.stream().map(JnsEnrlData::getCalculatedPremium).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getRecordsTransmittedToInsurer).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalJNSData.stream().map(JnsEnrlData::getPushedEnrollments).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPremiumPaidToInsurer).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalJNSData.stream().map(JnsEnrlData::getPushedPremium).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getAadharSeeded).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getMobileSeeded).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getEmailSeeded).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getFrshEnrol1JuneCrrntYear).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getRenewals1JuneCrrntYear).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getNomineeAvlb).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getCastGeneral).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getCastSc).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getCastSt).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getCastObc).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getPmjdyEnrolled).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getMgnregaEnrolled).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getKccEnrolled).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getMudraEnrolled).mapToLong(Long::longValue).sum());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(finalData.stream().map(MisEnrlData::getOtherSchemeEnrolled).mapToLong(Long::longValue).sum());
            index++;
        }
    }

    /*
     * SET CONSOLIDATED DATA OF ALL ORG'S IN EXCEL SCHEME WISE
     * */
    @Transactional(readOnly = true)
    private void writeActiveData(List<MisEnrlData> dataToWrite, List<JnsEnrlData> jnsEnrlDataList, Workbook workbook, Integer schemeId) {
        Sheet sheet;
        if (schemeId == PMJJBYScheme.getId().intValue()) {
            sheet = workbook.getSheet(PMJJBYScheme.getShortName() + " Active Data");
        } else {
            sheet = workbook.getSheet(PMSBYScheme.getShortName() + " Active Data");
        }
        int index = 1;
        for (MisEnrlData misEnrlData : dataToWrite) {
            JnsEnrlData jnsEnrlData = jnsEnrlDataList.stream()
                    .filter(obj -> (misEnrlData.getLgdStateCode().equals(obj.getStateCode())
                            && misEnrlData.getLgdDistrictCode().equals(obj.getDistrictCode())
                            && misEnrlData.getOrgId().equals(obj.getOrgId())))
                    .findFirst().orElse(null);

            int cellId = 0;
            Row row = sheet.createRow(index);
            row.createCell(cellId, CellType.STRING).setCellValue(misEnrlData.getStateName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getLgdStateCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getDistrictName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getLgdDistrictCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankShortName());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getInsurerCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankCode());
            row.createCell(++cellId, CellType.STRING).setCellValue(misEnrlData.getBankCategory());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getElgSvngAccHldr());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getElgPMJDYHldr());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralMale());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralMale());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralFemale());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralFemale());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralTransG());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveRuralTransG());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanMale());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanMale());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanFemale());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanFemale());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanTransG());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveUrbanTransG());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveTotalEnrolment());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveTotalEnrolment());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getTotalReceivedEnrollments());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(OPLUtils.isObjectNullOrEmpty(jnsEnrlData) ? 0 : jnsEnrlData.getTotalReceivedEnrollments());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveAadharSeeded());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveAadharSeeded());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMobileSeeded());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMobileSeeded());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveEmailSeeded());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveEmailSeeded());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getFrshEnrol1JuneCrrntYear());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getRenewals1JuneCrrntYear());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastGeneral());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastGeneral());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastSc());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastSc());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastSt());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastSt());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastObc());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveCastObc());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActivePmjdyEnrolled());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActivePmjdyEnrolled());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMgnregaEnrolled());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMgnregaEnrolled());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveKccEnrolled());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveKccEnrolled());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMudraEnrolled());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveMudraEnrolled());

            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveOtherSchemeEnrolled());
            row.createCell(++cellId, CellType.NUMERIC).setCellValue(misEnrlData.getActiveOtherSchemeEnrolled());

            index++;
        }
    }

    /*
     * SAVING UPLOADED MIS EXCEL DETAILS (STORAGE-ID, NAME, etc....)
     * */
    @Transactional
    private void saveDMSData(String fileName, Integer status, Long dmsStorageId, String type, Date createdDate, Long version) {
        log.info("In saveDMSData() -----------> ");
        MisDataDocDetails misDataDocDetails = new MisDataDocDetails();
        misDataDocDetails.setCreatedDate(createdDate);
        misDataDocDetails.setFileName(fileName);
        misDataDocDetails.setStatus(status);
        misDataDocDetails.setDmsStorageId(dmsStorageId);
        misDataDocDetails.setType(type);
        misDataDocDetails.setVersion(version);
        misDataDocDetails.setIsActive(true);
        misDataDocDetailsRepo.save(misDataDocDetails);
    }

    /*
     * CREATE NEW VERSION OF WEEK MASTER BASED ON LAST INSERTED VERSION
     * */
    @Async
    @Transactional
    public void addNewRowInWeekMaster() {
        log.info("In addNewRowInWeekMaster() ------> ");
        WeekMaster weekMaster = weekMasterRepository.findFirstByOrderByIdDesc();
        if (!OPLUtils.isObjectNullOrEmpty(weekMaster)) {
            WeekMaster weekMaster1 = new WeekMaster();
            weekMaster1.setId(weekMaster.getId() + 1);
            weekMaster1.setStatus(WeekMaster.StatusEnum.PENDING);
            weekMaster1.setIsRenewalUpdated(false);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(weekMaster.getToDate());

            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + 1);
            weekMaster1.setFromDate(DateUtils.parse(DateUtils.setDateFormat(DATE_FORMAT, calendar.getTime()), DATE_FORMAT));


            calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + 6);
            weekMaster1.setToDate(DateUtils.parse(DateUtils.setDateFormat(DATE_FORMAT, calendar.getTime()), DATE_FORMAT));

            weekMaster1.setFinancialYear(getFinancialYear(calendar));
            weekMaster1.setPolicyYear(getPolicyYear(calendar));

            weekMaster1.setIsYearChange(!Objects.equals(weekMaster.getPolicyYear(), weekMaster1.getPolicyYear()));
            weekMaster1.setDateOfDay(calendar.get(Calendar.DATE));
            weekMaster1.setMonth(calendar.get(Calendar.MONTH) + 1);

            weekMasterRepository.save(weekMaster1);
        }
    }

    private int getFinancialYear(Calendar calendar) {
        int month = calendar.get(Calendar.MONTH) + 1;
        int current = calendar.get(Calendar.YEAR);
        if (month > 3) {
            current = current + 1;
        }
        return current;
    }

    private int getPolicyYear(Calendar calendar) {
        int month = calendar.get(Calendar.MONTH) + 1;
        int current = calendar.get(Calendar.YEAR);
        int nextYear = current;
        if (month > 5) {
            nextYear = current + 1;
        }
        return nextYear;
    }

    /*
     * FOR MIS-DATA
     * CHECK DATA OF EACH ORG'S BASED ON VERSION
     * IF DATA NOT EXISTING THEN CHECK FOR PERVIOUS VERSION DATA
     * IF PERVIOUS VERSION DATA IS EXISTS THEN SET AS IT IS ELSE SET AS 0 DEFAULT
     *
     * ALSO SAVE JNS-DATA BASED ON VERSION
     * */
    @Async
    public void prepareDataForMis(Integer type, WeekMaster weekMaster) {
        log.info("In prepareDataForMis");
        Set<Long> orgIdMasterList = jnsEnrlDataRepo.getOrgIdList();
        if (OPLUtils.isListNullOrEmpty(orgIdMasterList)) {
            log.error("orgIdMasterList is null or empty");
            return;
        }

        for (Long orgId : orgIdMasterList) {

            StopWatch stopWatch = new StopWatch();
            stopWatch.start();

            List<MisEnrlData> misEnrlDataList = misEnrlDataRepo.findAllByVersionAndTypeAndOrgId(weekMaster.getId(), type, orgId);

            if (OPLUtils.isListNullOrEmpty(misEnrlDataList)) {
                log.info("Calling prepareDataForExcel() for SchemeMaster.PMJJBY ----------> ");
                prepareDataForExcel(orgId, weekMaster, type, SchemeMaster.PMJJBY);

                log.info("Calling misAsyncComponent.prepareDataForExcel() for SchemeMaster.PMSBY ----------> ");
                prepareDataForExcel(orgId, weekMaster, type, SchemeMaster.PMSBY);
            }

            log.info("Calling misAsyncComponent.saveJNSEnrlDataList() for SchemeMaster.PMJJBY----------> ");
            saveJNSEnrlDataList(orgId, weekMaster, type, SchemeMaster.PMJJBY);

            log.info("Calling misAsyncComponent.saveJNSEnrlDataList() for SchemeMaster.PMSBY----------> ");
            saveJNSEnrlDataList(orgId, weekMaster, type, SchemeMaster.PMSBY);

            stopWatch.stop();
            double totalTimeSeconds = stopWatch.getTotalTimeSeconds();
            log.info("Data saved successfully. ::::>> {} seconds", totalTimeSeconds);
        }

    }

    /*
     * GETTING PREVIOUS VERSIOIN OF MIS-DATA
     * IF EXISTS THEN SET AS IT IS ELSE SET 0 VALUE AS DEFAULT VALUE FOR EACH FIELD
     * */
    @Transactional
    public void prepareDataForExcel(Long orgId, WeekMaster weekMaster, Integer type, SchemeMaster schemeMaster) {
        try {
            String[] ignoreDataFields = {"id", "createdDate", "fromDate", "toDate", "version"};
            List<MisEnrlData> misEnrlPreviousVersionDataList = misEnrlDataRepo.findAllByVersionAndTypeAndOrgIdAndSchemeId(weekMaster.getId() - 1, type, orgId, schemeMaster.getId().intValue());
            List<MisEnrlData> misEnrlDataListToSave = new ArrayList<>();
            if (misEnrlPreviousVersionDataList.isEmpty()) {
                log.info("Old data not found for orgId {} and version {}", orgId, weekMaster.getId() - 1);

                log.info("Calling setDefaultData for SchemeMaster --> {} ", schemeMaster.getShortName());
                setDefaultData(orgId, weekMaster, schemeMaster, type, misEnrlDataListToSave);
            } else {
                MisEnrlData misEnrlData;
                for (MisEnrlData data : misEnrlPreviousVersionDataList) {
                    misEnrlData = new MisEnrlData();
                    BeanUtils.copyProperties(data, misEnrlData, ignoreDataFields);
                    misEnrlData.setFromDate(weekMaster.getFromDate());
                    misEnrlData.setToDate(weekMaster.getToDate());
                    misEnrlData.setVersion(weekMaster.getId());
                    misEnrlData.setCreatedDate(new Date());
                    misEnrlDataListToSave.add(misEnrlData);
                }
            }
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            misEnrlDataRepo.saveAllAndFlush(misEnrlDataListToSave);
//            saveAllData(misEnrlDataListToSave);
            stopWatch.stop();
            double totalTimeSeconds = stopWatch.getTotalTimeSeconds();
            log.info("Data saved successfully. ::::>> {} seconds", totalTimeSeconds);
        } catch (Exception e) {
            log.error("Exception in prepareDataForExcel() ----------------> ", e);
        }
    }

    /*
     * SAVING DEFAULT VALUE FOR MIS-REPORT SCHEME WISE FOR ALL STATE AND DISTRICT
     * */
    @Transactional(readOnly = true)
    private void setDefaultData(Long orgId, WeekMaster weekMaster, SchemeMaster schemeMaster, Integer type, List<MisEnrlData> misEnrlDataListToSave) {
        log.info("In setDefaultData() ------------> ");
        try {
            UserOrganisationMasterResponse organisationData = getOrganizationByOrgId(orgId);
            if (OPLUtils.isObjectNullOrEmpty(organisationData)) {
                log.info("organisationData is null or empty.");
                return;
            }

            log.info("Calling getInsurerBySchemeAndOrg For Insurer Code -----------> ");
            InsurerMstDetailsV3 insurerMstDetailsV3 = getInsurerBySchemeAndOrg(schemeMaster.getId(), orgId);
            if (OPLUtils.isObjectNullOrEmpty(insurerMstDetailsV3)) {
                log.info("insurerMstDetailsV3 is null or empty.");
                return;
            }

            log.info("Calling getOrganizationByOrgId For Insurer Name -----------> ");
            UserOrganisationMasterResponse organisationMasterResponse = getOrganizationByOrgId(insurerMstDetailsV3.getInsurerOrgId());
            if (OPLUtils.isObjectNullOrEmpty(organisationMasterResponse)) {
                log.info("organisationMasterResponse is null or empty.");
                return;
            }

            MisEnrlData misEnrlData;
            for (LgdDistrictStateResponse lgdDistrictStateResponse : GetCommonData.STATE_DISTRICT_LIST) {
                misEnrlData = new MisEnrlData();
                misEnrlData.setFromDate(weekMaster.getFromDate());
                misEnrlData.setToDate(weekMaster.getToDate());
                misEnrlData.setVersion(weekMaster.getId());
                misEnrlData.setType(type);
                misEnrlData.setOrgId(orgId);
                misEnrlData.setCreatedDate(DateUtils.parse(DateUtils.setDateFormat(DATE_FORMAT, new Date()), DATE_FORMAT));
//                try {
//                    misEnrlData.setCreatedDate(DATE_FORMAT.parse(DATE_FORMAT.format(new Date())));
//                } catch (ParseException e) {
//                    log.error("ParseException in setDefaultData()  -------------> ", e);
//                    misEnrlData.setCreatedDate(new Date());
//                }
                misEnrlData.setSchemeId(schemeMaster.getId().intValue());
                misEnrlData.setStateName(schemeMaster.getShortName());
                misEnrlData.setStateName(lgdDistrictStateResponse.getStateName());
                misEnrlData.setLgdStateCode(lgdDistrictStateResponse.getLgdStateCode());
                misEnrlData.setDistrictName(lgdDistrictStateResponse.getDistrictName());
                misEnrlData.setLgdDistrictCode(lgdDistrictStateResponse.getLgdDistrictCode());
                misEnrlData.setInsurerCode(insurerMstDetailsV3.getInsurerCode());
                misEnrlData.setInsurerName(organisationMasterResponse.getDisplayOrgName());
                misEnrlData.setBankName(organisationData.getDisplayOrgName());
                misEnrlData.setBankCode(organisationData.getBankType());
                misEnrlData.setBankCategory(organisationData.getOrgCategory());
                misEnrlData.setElgSvngAccHldr(0L);
                misEnrlData.setElgPMJDYHldr(0L);
                misEnrlData.setRuralMale(0L);
                misEnrlData.setRuralFemale(0L);
                misEnrlData.setRuralTransG(0L);
                misEnrlData.setUrbanMale(0L);
                misEnrlData.setUrbanFemale(0L);
                misEnrlData.setUrbanTransG(0L);
                misEnrlData.setTotalEnrolment(0L);
                misEnrlData.setPrmclctdruralMale(0L);
                misEnrlData.setPrmclctdruralFemale(0L);
                misEnrlData.setPrmclctdruralTransG(0L);
                misEnrlData.setPrmclctdurbanMale(0L);
                misEnrlData.setPrmclctdurbanFemale(0L);
                misEnrlData.setPrmclctdurbanTransG(0L);
                misEnrlData.setTotalPrmclctdNwErollment(0L);
                misEnrlData.setRecordsTransmittedToInsurer(0L);
                misEnrlData.setPremiumPaidToInsurer(0L);
                misEnrlData.setAadharSeeded(0L);
                misEnrlData.setMobileSeeded(0L);
                misEnrlData.setEmailSeeded(0L);
                misEnrlData.setPmjdyEnrolled(0L);
                misEnrlData.setMgnregaEnrolled(0L);
                misEnrlData.setMudraEnrolled(0L);
                misEnrlData.setKccEnrolled(0L);
                misEnrlData.setOtherSchemeEnrolled(0L);
                misEnrlData.setCastSc(0L);
                misEnrlData.setCastSt(0L);
                misEnrlData.setCastObc(0L);
                misEnrlData.setCastGeneral(0L);
                misEnrlData.setFrshEnrol1JuneCrrntYear(0L);
                misEnrlData.setRenewals1JuneCrrntYear(0L);
                misEnrlData.setActiveAadharSeeded(0L);
                misEnrlData.setActiveEmailSeeded(0L);
                misEnrlData.setActiveMobileSeeded(0L);
                misEnrlData.setActiveCastSc(0L);
                misEnrlData.setActiveCastSt(0L);
                misEnrlData.setActiveCastObc(0L);
                misEnrlData.setActiveCastGeneral(0L);
                misEnrlData.setActiveKccEnrolled(0L);
                misEnrlData.setActiveMgnregaEnrolled(0L);
                misEnrlData.setActiveMudraEnrolled(0L);
                misEnrlData.setActivePmjdyEnrolled(0L);
                misEnrlData.setActiveOtherSchemeEnrolled(0L);
                if (!Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
                    misEnrlData.setInsufficientAcHolders(0L);
                    misEnrlData.setPrmdebitedRs(0L);
                }
                misEnrlDataListToSave.add(misEnrlData);
            }
        } catch (Exception e) {
            log.error("Exception in setDefaultData() ---------> ", e);
        }
    }


    /*
     * GETTING JNS DATA COUNTS BASED ON FROM DATE AND TO DATE OF GIVEN VERSION AND SCHEME WISE
     * AND SET DATA OF EACH STATE AND DISTRICT (IF NOT EXISTS THEN SET DEFAULT VALUE 0)
     * */
    @Transactional
    public void saveJNSEnrlDataList(Long orgId, WeekMaster weekMaster, Integer type, SchemeMaster schemeMaster) {
        log.info("In saveJNSEnrlDataList() ----------> ");

        List<JnsEnrlData> lastInsertedDataList = new ArrayList<>();
        if (Objects.equals(type, TransactionTypeEnum.ENROLLMENT.getId())) {
            log.info("Getting lastInsertedData -----------> ");
            lastInsertedDataList = jnsEnrlDataRepo.findAllByVersionAndTypeAndOrgIdAndSchemeId(weekMaster.getId() - 1, type, orgId, schemeMaster.getId().intValue());
        }

        List<JnsEnrlData> dataToInsert;
        String fromDate = DateUtils.setDateFormat(DATE_FORMAT, weekMaster.getFromDate());
        String toDate = DateUtils.setDateFormat(DATE_FORMAT, weekMaster.getToDate());
        if (schemeMaster == SchemeMaster.PMJJBY) {
            dataToInsert = jnsEnrlDataRepo.getJNSPMJJBYCounts(orgId, fromDate, toDate);
        } else {
            dataToInsert = jnsEnrlDataRepo.getJNSPMSBYCounts(orgId, fromDate, toDate);
        }

        log.info("JnsEnrlData List count {} for scheme {}", dataToInsert.size(), schemeMaster.getShortName());
        for (JnsEnrlData jnsEnrlData : dataToInsert) {
            jnsEnrlData.setVersion(weekMaster.getId());
            jnsEnrlData.setType(type);
            jnsEnrlData.setSchemeId(schemeMaster.getId().intValue());
            LgdDistrictStateResponse lgdDistrictStateResponse = GetCommonData.STATE_DISTRICT_LIST.stream()
                    .filter(obj -> obj.getStateId() == Long.parseLong(jnsEnrlData.getStateCode()) && obj.getDistrictId() == Long.parseLong(jnsEnrlData.getDistrictCode()))
                    .findFirst()
                    .orElse(null);
            if (!OPLUtils.isObjectNullOrEmpty(lgdDistrictStateResponse)) {
                jnsEnrlData.setStateCode(lgdDistrictStateResponse.getLgdStateCode());
                jnsEnrlData.setDistrictCode(lgdDistrictStateResponse.getLgdDistrictCode());
            }
            if (!lastInsertedDataList.isEmpty()) {
                setJNSCalculatedData(jnsEnrlData, lastInsertedDataList);
            }
        }
        if (GetCommonData.STATE_DISTRICT_LIST.size() != (long) dataToInsert.size()) {
            log.info("Calling setDefaultData for SchemeMaster and orgId --> {} {}", schemeMaster.getShortName(), orgId);
            setJNSDefaultData(orgId, schemeMaster, type, weekMaster.getId(), lastInsertedDataList, dataToInsert);
        }
        jnsEnrlDataRepo.saveAllAndFlush(dataToInsert);
//        saveAllJnsData(dataToInsert);
    }

    /*
     * SAVING JNS DATA (21420 AT A TIME) USING THREAD POOL EXECUTOR
     * */
//    private void saveAllJnsData(List<JnsEnrlData> dataToInsert) {
//        ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
//        int chunkSize = Integer.parseInt(CHUNK_SIZE) * 2;
//        // Divide the data into chunks
//        for (int i = 0; i < dataToInsert.size(); i += chunkSize) {
//            final List<JnsEnrlData> chunk = dataToInsert.subList(i, Math.min(i + chunkSize, dataToInsert.size()));
//            // Submit task to the ExecutorService for saving data in parallel
//            executorService.submit(() -> {
//                jnsEnrlDataRepo.saveAll(chunk);
//            });
//        }
//        // Shutdown the ExecutorService
//        executorService.shutdown();
//
//        // Wait for all tasks to complete
//        while (!executorService.isTerminated()) {
//            // Do nothing, wait for tasks to complete
//        }
//    }

    /*
     * DO CONSOLIDATION WITH CURRENT AND LAST VERSION OF DATA AND SET
     * */
    @Transactional(readOnly = true)
    private void setJNSCalculatedData(JnsEnrlData jnsEnrlData, List<JnsEnrlData> lastInsertedDataList) {
        log.info("In setJNSCalculatedData() ---------> ");

        JnsEnrlData lastData = lastInsertedDataList.stream()
                .filter(obj -> Objects.equals(obj.getDistrictCode(), jnsEnrlData.getDistrictCode()))
                .findFirst()
                .orElse(null);

        if (!OPLUtils.isObjectNullOrEmpty(lastData)) {
            jnsEnrlData.setCalculatedPremium(jnsEnrlData.getCalculatedPremium() + lastData.getCalculatedPremium());
            jnsEnrlData.setTotalReceivedEnrollments(jnsEnrlData.getTotalReceivedEnrollments() + lastData.getTotalReceivedEnrollments());
            jnsEnrlData.setPushedEnrollments(jnsEnrlData.getPushedEnrollments() + lastData.getPushedEnrollments());
            jnsEnrlData.setPushedPremium(jnsEnrlData.getPushedPremium() + lastData.getPushedPremium());
        }
    }

    /*
     * IF PREVIOS VERSION DATA ARE EXISTS THEN SET AS IT IS ELSE
     * SET JNS DEFAULT DATA WITH VALUE 0 FOR EACH STATE AND DISTRICT
     * */
    @Transactional(readOnly = true)
    private void setJNSDefaultData(Long orgId, SchemeMaster schemeMaster, Integer type, Long version, List<JnsEnrlData> lastInsertedDataList, List<JnsEnrlData> dataToInsert) {
        log.info("In setJNSDefaultData() ------------> ");
        JnsEnrlData jnsEnrlData;
        for (LgdDistrictStateResponse lgdDistrictStateResponse : GetCommonData.STATE_DISTRICT_LIST) {
            if (dataToInsert.stream().filter(obj -> Objects.equals(obj.getDistrictCode(), lgdDistrictStateResponse.getLgdDistrictCode()))
                    .findFirst()
                    .orElse(null) != null) {
                continue;
            }
            jnsEnrlData = new JnsEnrlData();
            jnsEnrlData.setSchemeId(schemeMaster.getId().intValue());
            jnsEnrlData.setType(type);
            jnsEnrlData.setVersion(version);
            jnsEnrlData.setOrgId(orgId);
            jnsEnrlData.setStateCode(lgdDistrictStateResponse.getLgdStateCode());
            jnsEnrlData.setDistrictCode(lgdDistrictStateResponse.getLgdDistrictCode());

            JnsEnrlData lastData = null;
            if (!lastInsertedDataList.isEmpty()) {
                lastData = lastInsertedDataList.stream()
                        .filter(obj -> Objects.equals(obj.getSchemeId(), schemeMaster.getId().intValue()) &&
                                Objects.equals(obj.getDistrictCode(), lgdDistrictStateResponse.getLgdDistrictCode()))
                        .findFirst()
                        .orElse(null);
            }

            if (!OPLUtils.isObjectNullOrEmpty(lastData)) {
                jnsEnrlData.setCalculatedPremium(lastData.getCalculatedPremium());
                jnsEnrlData.setTotalReceivedEnrollments(lastData.getTotalReceivedEnrollments());
                jnsEnrlData.setPushedEnrollments(lastData.getPushedEnrollments());
                jnsEnrlData.setPushedPremium(lastData.getPushedPremium());
            } else {
                jnsEnrlData.setCalculatedPremium(0L);
                jnsEnrlData.setTotalReceivedEnrollments(0L);
                jnsEnrlData.setPushedEnrollments(0L);
                jnsEnrlData.setPushedPremium(0L);
            }
            dataToInsert.add(jnsEnrlData);
        }

    }

}
