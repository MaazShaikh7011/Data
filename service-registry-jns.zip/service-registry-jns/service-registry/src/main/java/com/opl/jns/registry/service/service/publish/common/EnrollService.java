package com.opl.jns.registry.service.service.publish.common;

import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;

public interface EnrollService {

	public <T extends RegistryReqProxy, U extends MainResponse> U deDupe(T in, Long orgId);

	public <T extends RegistryReqProxy, U extends MainResponse> U enroll(T in, Long orgId);

	public <T extends RegistryReqProxy, U extends MainResponse> U updateStatus(T t);
	
	public <T extends RegistryReqProxy, U extends MainResponse> U updateTransactionDetailsAndGetCoiFiles(T coiResponse,
			U transactionRequest) throws Exception;

}
