package com.opl.jns.registry.service.controller.publish.v3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.insurer.PushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.insurer.PushEnrollment.PushEnrollmentDetailsResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.api.proxy.jansuraksha.v3.Response400V3;
import com.opl.jns.api.proxy.jansuraksha.v3.Response401;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.service.publish.common.EnrollService;
import com.opl.jns.registry.service.utils.RegistryUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "1. Other Channel Enrollments API", description = "List Of Registry Api")
public class EnrollmentControllerV3 {

	@Autowired
	@Qualifier("EnrollmentServiceImplV3")
	private EnrollService enrollService;

	// http://localhost:8065/api/registry/swagger-ui/index.html?configUrl=/api/registry/v3/api-docs/swagger-config

	@PostMapping("/enrollmentDetails")
	@Operation(operationId = "1", summary = Constants.ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_DOB_DATE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_ENROLLMENT, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<EnrollmentResProxyV3> pushEnrollment(
			@Valid @RequestBody EnrollmentReqProxyV3 applicationRequest, HttpServletRequest httpServletRequest) {
		log.info("inside controller");
		EnrollmentResProxyV3 enrollmentResponse = new EnrollmentResProxyV3(
				Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		RegistryUtils.setTokenAndTimeStempV3(enrollmentResponse,
				applicationRequest.getToken());
		if (OPLUtils.isObjectNullOrEmpty(applicationRequest)) {
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				enrollmentResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
			enrollmentResponse = enrollService.enroll(applicationRequest, userOrgId);
			enrollmentResponse = RegistryUtils.setTokenAndTimeStempV3(enrollmentResponse,
					applicationRequest.getToken());
			log.info("<--- Exit From enrollment ---> ");
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in PushEnrollment Details() {}", e.getMessage());
			enrollmentResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.FAILED,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(enrollmentResponse, HttpStatus.OK);
		}

	}

	@PostMapping("/updateTransactionDetails")
	@Operation(operationId = "2", summary = Constants.UPDATE_TRANSACTION_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE, description = Constants.UPDATE_TRASACTION_DESC),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateTransResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })

	public ResponseEntity<UpdateTransResProxyV3> saveTransaction(
			@Valid @RequestBody UpdateTransReqProxyV3 transactionRequest, HttpServletRequest httpServletRequest){
		UpdateTransResProxyV3 coiResponse = new UpdateTransResProxyV3(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value());
		coiResponse = RegistryUtils.setTokenAndTimeStempV3(coiResponse, transactionRequest.getToken());
		if (OPLUtils.isObjectNullOrEmpty(transactionRequest)) {
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				coiResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value(), null);
				return new ResponseEntity<>(coiResponse, HttpStatus.OK);
			}

//            /* VALIDATE REQUEST IF RESULT IS NULL THEN REQUEST IS VALID */
//            coiResponse = commonService.validateTransactionDetail(transactionRequest);
//            if(!OPLUtils.isObjectNullOrEmpty(coiResponse)){
//                return new ResponseEntity<>(coiResponse, HttpStatus.OK);
//            }
//
//            /* SAVE DATA IN INSURANCE TRANSACTION DETAILS COLLECTION */
//            coiResponse = commonService.saveTransactionDetails(transactionRequest);
//            if(coiResponse.getStatus().equals(HttpStatus.OK.value())){
//                /* GENERATE COI AND SEND MAIL AND PUSH THE DATA */
//                coiResponse =  commonService.pushApplicationAndGenerateCoi(transactionRequest.getUrn());
//            }
//
//            coiResponse = (CoiResponse) RegistryUtils.setTokenAndTimeStemp(coiResponse,httpServletRequest);

			/**
			 * combine full controller methods
			 */

           coiResponse = enrollService.updateTransactionDetailsAndGetCoiFiles(transactionRequest,coiResponse);
			coiResponse =RegistryUtils.setTokenAndTimeStempV3(coiResponse, transactionRequest.getToken());
			log.info("<--- Exit From Update Transaction Details  ---> ");
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			coiResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		}
	}

	@PostMapping("/updateEnrolmentAcStatus")
	@Operation(operationId = "3", summary = Constants.UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateStatusResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<UpdateStatusResProxyV3> updateStatus(@Valid @RequestBody UpdateStatusReqProxyV3 statusApiReq,
			HttpServletRequest httpServletRequest) {
		UpdateStatusResProxyV3 commonResponse = new UpdateStatusResProxyV3(Constants.SUCCESS,HttpStatus.OK.value());
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				commonResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), null);
				return new ResponseEntity<>(commonResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);

			/* UPDATE STAGE IN INSURANCE APPLICATION MASTER COLLECTION */
            commonResponse = enrollService.updateStatus(statusApiReq);
			commonResponse = RegistryUtils.setTokenAndTimeStempV3(commonResponse,statusApiReq.getToken());
			log.info("<--- Exit From Update Transaction Details  ---> ");
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			commonResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		}

	}

	@PostMapping(value = "/pushEnrollmentDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = "4", summary = Constants.PUSH_ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_EXAMPLE, description = Constants.PUSH_ENROLLMENT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PushEnrollmentDetailsResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PushEnrollmentDetailsResponse> consumeEnrollmentDetails(
			@Valid @RequestBody PushEnrollmentDetailsRequest detailsRequest, HttpServletRequest httpServletRequest) {
		PushEnrollmentDetailsResponse data = new PushEnrollmentDetailsResponse();
		return new ResponseEntity<>(data, HttpStatus.OK);

	}
}
