package com.opl.jns.registry.service.utils;

import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.v2.*;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.lib.domain.ApiConfigMaster;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.published.utils.enums.EnrollStageMaster;
import com.opl.jns.registry.api.internal.CertificateInsDtlRequest;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.model.COIRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Slf4j
@Component
public class AsynUtils {

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private ApiConfigMasterRepo configRepo;
	
	@Autowired
	private DMSClient dmsClient;
	
	@Autowired
	private PDFGenerateClient pdfGenerateClient;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

	// @Async
	/*public boolean pushDeDupeRegistryData(SingleEnrollmentRequest enrollmentRequest) {
		try {
//    		String url = configRepo.findByCodeAndIsActiveTrue(OPLUtils.SINGLE_ENROLLMENT_REQUEST).getValue();
//        	CommonResponse commonResponse = callSingleEnrollmentRequest(enrollmentRequest, url);
			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
					.callSingleEnrollmentRequest(enrollmentRequest);
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
					SingleEnrollmentResponse singleEnrollmetResponse = MultipleJSONObjectHelper
							.getObjectFromObject(commonResponse.getData(), SingleEnrollmentResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(singleEnrollmetResponse)
							&& !OPLUtils.isObjectNullOrEmpty(singleEnrollmetResponse.getStatus())
							&& singleEnrollmetResponse.getStatus().equals(HttpStatus.OK.value())) {
						applMasterOtherDetailsRepoV3.updateIsDDPushFlag(enrollmentRequest.getApplicationId());
						return true;
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception while PUSH enrollment data in De-dupe Registry ---->", e);
		}
		return false;
	}*/

//    private CommonResponse callSingleEnrollmentRequest(SingleEnrollmentRequest singleEnrollmentRequest, String urlPart) {
//		try {
//			HttpHeaders headers = new HttpHeaders();
//			headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//			headers.setContentType(MediaType.APPLICATION_JSON);
//			RestTemplate restTemplate = new RestTemplate();
//			log.info("callSingleEnrollmentRequest Data For -->" + urlPart);
//			HttpEntity<SingleEnrollmentRequest> entity = new HttpEntity<>(singleEnrollmentRequest, headers);
//			CommonResponse response = restTemplate.exchange(urlPart, HttpMethod.POST, entity, CommonResponse.class)
//					.getBody();
//			if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
//					&& response.getStatus() == 200) {
//				return response;
//			}
//		} catch (Exception e) {
//			log.error("Exception While calling api :: ", e);
//		}
//		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}
//    

//	@Async
//	public void updateStatusToDeDupeRegisty(Long id, String urn, Date enrollmentDate) {
//		/* PUSHING THE DETAILS TO PYTHON */
//		String pythonApiCall = configRepo.findByCodeAndIsActiveTrue(OPLUtils.IS_PYTHON_API_CALL).getValue();
//		if (pythonApiCall.equalsIgnoreCase("true")) {
//			try {
////                String url = configRepo.findByCodeAndIsActiveTrue(OPLUtils.UPDATE_ENROLLMENT_STATUS).getValue();
//				UpdateEnrollRequest updateEnrollRequest = getUpdateEnrollmentStatusReq(id, urn, enrollmentDate);
//				com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
//						.callUpdateEnrollmentStatus(updateEnrollRequest);
////                CommonResponse commonResponse = callUpdateEnrollmentStatus(updateEnrollRequest, url);
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
//						&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//						&& Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
//					if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
//						UpdateEnrollResponse updateEnrollResponse = MultipleJSONObjectHelper
//								.getObjectFromObject(commonResponse.getData(), UpdateEnrollResponse.class);
//						if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse)
//								&& !OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus())
//								&& updateEnrollResponse.getStatus().equals(HttpStatus.OK.value())) {
//							applMasterOtherDetailsRepoV3.updateIsDDStatusPushFlag(id);
//						}
//					}
//				}
//			} catch (Exception e) {
//				log.error("update update enrollment Status Error -->", e);
//			}
//		}
//	}

//	public UpdateEnrollRequest getUpdateEnrollmentStatusReq(Long id, String urn, Date enrollmentDate) {
//		UpdateEnrollRequest enrollRequest = new UpdateEnrollRequest();
//		enrollRequest.setApplicationId(id);
//		enrollRequest.setUrn(urn);
//		enrollRequest.setStatus(APPLICATION_STATUS);
//		enrollRequest.setReason(COMPLETED);
//		enrollRequest
//				.setDateOfEnrollment(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS, enrollmentDate));
//		return enrollRequest;
//
//	}

//    public CommonResponse callUpdateEnrollmentStatus(UpdateEnrollRequest enrollRequest, String urlPart) {
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            RestTemplate restTemplate = new RestTemplate();
//            log.info("callUpdateEnrollmentStatus Data For -->" + urlPart);
//            HttpEntity<UpdateEnrollRequest> entity = new HttpEntity<>(enrollRequest, headers);
//            CommonResponse response = restTemplate.exchange(urlPart, HttpMethod.POST, entity, CommonResponse.class)
//                    .getBody();
//            if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
//                    && response.getStatus() == 200) {
//                return response;
//            }
//        } catch (Exception e) {
//            log.error("Exception While calling api :: ", e);
//        }
//        return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
//    }

//    @Async
    public void publishEnrollment(Long applicationId, Integer stageId) {
        try {
            //Date curruntDate = new Date();
            publishedData(applicationId, stageId);
           /* if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus() == HttpStatus.OK.value()) {
                log.info("Application has been pushed");
				//applicationMasterRepository.updatePublishFlagAndModified(curruntDate, applicationId);
//            } else {//                
//                log.info(" Error in Pushing the application [{}]", commonResponse.getMessage());
//                PushReTryAudit pushReTryAudit = new PushReTryAudit();
//                pushReTryAudit.setApplicationId(applicationId);
//                pushReTryAudit.setReTryCount(RegistryUtils.INT_0);
//                pushReTryAudit.setCreatedDate(curruntDate);
//                pushReTryAudit.setType(RegistryUtils.PUSH_RE_TRY_APPLICATION);
//                pushReTryAudit.setIsPushed(Boolean.FALSE);
//                pushReTryAudit.setMessage(commonResponse.getMessage());
//                pushReTryAuditRepo.save(pushReTryAudit);
            }*/
        } catch (Exception e) {
            log.error("EXCEPTION WHILE PUBLISH ENROLLMENT ----------->", e);
        }
    }

	private CommonResponse publishedData(Long applicationId, Integer stageId) throws Exception {
		CommonResponse commonResponse = new CommonResponse();
		if (OPLUtils.isObjectNullOrEmpty(applicationId) || stageId != EnrollStageMaster.COMPLETED.getStageId()) {
			log.info("Its seems this application has been not completed yet ");
			commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			commonResponse.setMessage("Its seems this application has been not completed yet ");
			return commonResponse;
		}
		ApiConfigMaster pushPullApi = configRepo.findByCodeAndIsActiveTrue("PUSH_PULL_ENROLL_API_URL");
		String url = pushPullApi.getValue().concat(applicationId.toString());
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
			headers.set("isDecrypt", "true");
			headers.add("Accept", "application/json");
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published Data For -->" + applicationId + "==========API URL ----------->" + url);
			commonResponse = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			return commonResponse;
		} catch (Exception e) {
			log.error("Exception While calling Publish API :: ", e);
			commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			commonResponse.setMessage("Exception While calling Publish API ");
			return commonResponse;
		}
	}

     @Async
     public void sendCoiToApplicant(NotificationPrepareProxy master, byte[] coiInByte) {
         CertificateInsDtlRequest request = new CertificateInsDtlRequest();
         request.setApplicationId(master.getId());
         /* send email and sms in case of coi */
         ContentAttachment contentAttachment = new ContentAttachment();
         contentAttachment.setContentInByte(coiInByte);
         contentAttachment.setFileName("Certificate-of-insurance-" + master.getUrn() + ".pdf");
         List<ContentAttachment> contentList = new ArrayList<ContentAttachment>();
 		contentList.add(contentAttachment);	
        /* set email parameter */
		Map<String, Object> emailParam = setEmailParameters(
				OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(), master.getFirstName(),
				OPLUtils.isObjectNullOrEmpty(master.getSchemeId()) ? null
						: com.opl.jns.utils.enums.SchemeMaster.getById(Long.valueOf(master.getSchemeId())).getShortName(),
				OPLUtils.isObjectNullOrEmpty(master.getTransAmount()) ? null : master.getTransAmount(),
				OPLUtils.isObjectNullOrEmpty(master.getYear()) ? null : master.getYear() + 1,
				OPLUtils.isObjectNullOrEmpty(master.getSource()) ? null : master.getSource(),
						OPLUtils.isObjectNullOrEmpty(master.getOrgId()) ? null : master.getOrgId());

        String email = master.getEmail();
        String mobile = master.getMobileNumber();
        /* send email and sms */
        sendCoiEmail(emailParam, email, mobile, contentList);
    }

    private void sendCoiEmail(Map<String, Object> emailParameters, String toEmail, String toSms,
                                 List<ContentAttachment> contentAttachments) {
        log.info("entry in sendNotification for coi");

        String[] toEmailAry = {toEmail};
        String[] toSmsAry = {91 + toSms};

        NotificationRequest notificationRequest = new NotificationRequest();
        
        if (!OPLUtils.isObjectNullOrEmpty(toEmail)) {
           Notification emailNoti = NotificationClient.prepareRequestForSmsOrEmail(toEmailAry, emailParameters, JnsNotificationMasterUtil.EMAIL_CUST_ENROLLMENT_SUCESS, contentAttachments, NotificationType.EMAIL);
            notificationRequest.addNotification(emailNoti);
        }
        if (!OPLUtils.isObjectNullOrEmpty(toSms)) {
        	Long smstempId = null;
			if(emailParameters.get("nameOfScheme").equals("PMSBY")) {
				smstempId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMSBY; 
			}else {
				smstempId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMJJBY;
			}
        	Notification smsNoti = NotificationClient.prepareRequestForSmsOrEmail(toSmsAry, emailParameters, smstempId, null, NotificationType.SMS);
        	notificationRequest.addNotification(smsNoti);
        }
        if (!OPLUtils.isListNullOrEmpty(notificationRequest.getNotifications()) && notificationRequest.getNotifications().size() > 0) {
           notificationClient.send(notificationRequest);
		} 
    }

	public Map<String, Object> setEmailParameters(String urn, String insuredName, String schemeName, Double amount,
			Integer year,Integer source,Long orgId) {
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("insuredName", insuredName);
		emailParameters.put("amountOfPremium", amount);
		emailParameters.put("nameOfScheme", schemeName);
		emailParameters.put("urn", urn.substring(4));
		emailParameters.put("year", !OPLUtils.isObjectNullOrEmpty(year) ? year.toString() : "");
		emailParameters.put("source", source);
		emailParameters.put("orgId", orgId);
		return emailParameters;
	}
	
	@Async
	public void sendCoiToApplicantNewDb(ApplicationMasterBothSchemeProxy master,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantDetails,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomneeAddress) {
		try {
			byte[] coiInByte = getCOINewDb(master, transactionDetailsV2,applicantDetails,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,nomneeAddress,false);

			/** send email and sms in case of coi */
			ContentAttachment contentAttachment = new ContentAttachment();
			contentAttachment.setContentInByte(coiInByte);
			contentAttachment.setFileName("Certificate-of-insurance-" + master.getUrn() + ".pdf");
			List<ContentAttachment> contentList = new ArrayList<ContentAttachment>();
			contentList.add(contentAttachment);

			if(!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2) && !OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
				Long smsTmpId = null;
				String schemeName = null;
				if(!OPLUtils.isObjectNullOrEmpty(master.getSchemeId())) {
					 schemeName = SchemeMaster.getById(master.getSchemeId()).getShortName();
					if(schemeName.equals(SchemeMaster.PMSBY.getShortName())) {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMSBY;
					}else {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMJJBY;
					}
				}

				sendNotification(
					setEmailParameters(OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(), OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getAcHolderName()) ? null : applicantPIDetails.getAcHolderName(),
							schemeName,OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getTransAmount()) ? null : transactionDetailsV2.getTransAmount(),
							OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getYear()) ? null : transactionDetailsV2.getYear() + 1,master.getSource(),OPLUtils.isObjectNullOrEmpty(master.getOrgId()) ? null : master.getOrgId()),
					OPLUtils.isObjectNullOrEmpty(applicantDetails.getEmail()) ? null : applicantDetails.getEmail(),
					OPLUtils.isObjectNullOrEmpty(applicantDetails.getMobileNumber()) ? null : applicantDetails.getMobileNumber(), JnsNotificationMasterUtil.EMAIL_CUST_ENROLLMENT_SUCESS,
							smsTmpId, contentList);
			}
		} catch (Exception e) {
			log.error("Exception while send notification or generate COI----------->", e);
		}
	}
	
	public byte[] getCOINewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantDetails,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 applicantAddress,Boolean isFreshCreate) {
		try {
			if (!isFreshCreate) {
				Long coiStorageId = transactionDetailsV2.getCoiStorageId();
				if (coiStorageId != null) {
					return dmsClient.productDownloadDocuments(coiStorageId.toString());
				}
			}
				// FETCH COI REQUEST FROM APPLICATION MASTER
				COIRequest coiReq = ereCommonService.generateCOIRequestNewDb(appMaster,transactionDetailsV2,applicantDetails,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,applicantAddress);

				// GENERATE PDF FILE FROM PDF CLIENT
				CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
				if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
					transactionDetailsV2.setCoiStorageId(generateCOI.getId());
					transactionDetailsRepositoryV2.updateStorageIdInTransaction(generateCOI.getId(),appMaster.getLastTransactionId());
					return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
				} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
					log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
				} else {
					log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
				}
		} catch (Exception e) {
			log.error("Exception while generate COI ---------------->", e);
		}
		return null;
	}
	
	public void sendNotification(Map<String, Object> emailParameters, String toEmail, String toSms, Long emailTempId, Long smsTempId, List<ContentAttachment> attachments)
	{	
//		log.info("entry in sendNotification()");

		String[] toEmailAry = { toEmail };
		String[] toSmsAry = { 91 + toSms };

		NotificationRequest notificationRequest = new NotificationRequest();
		if(!OPLUtils.isObjectNullOrEmpty(toEmail) && !OPLUtils.isObjectNullOrEmpty(emailTempId)) {
			Notification emailNoti = NotificationClient.prepareRequestForSmsOrEmail(toEmailAry, emailParameters, emailTempId, attachments, NotificationType.EMAIL);
			notificationRequest.addNotification(emailNoti);
		}

		if(!OPLUtils.isObjectNullOrEmpty(toSms) && !OPLUtils.isObjectNullOrEmpty(smsTempId)) {
			Notification smsNoti = NotificationClient.prepareRequestForSmsOrEmail(toSmsAry, emailParameters, smsTempId, null, NotificationType.SMS);
			notificationRequest.addNotification(smsNoti);
		}

		if(!OPLUtils.isListNullOrEmpty(notificationRequest.getNotifications()) && !notificationRequest.getNotifications().isEmpty()) {
			 notificationClient.send(notificationRequest);
			 log.info("Notification sent successfully");
		}
	
	}


}
