package com.opl.jns.registry.service.service.publish.common;

import jakarta.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.util.Map;

public interface ValidationService {

    public Map<String, Object> isValidUser(HttpServletRequest request,  String urn,Long claimRefId) throws IOException ;
}
