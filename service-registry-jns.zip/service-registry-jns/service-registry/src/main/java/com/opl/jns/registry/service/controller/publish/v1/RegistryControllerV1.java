package com.opl.jns.registry.service.controller.publish.v1;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.dedupe.DeDupReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate.UpdateStatusReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.statusupdate.UpdateStatusResProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransResProxyV1;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.api.utils.v1.Constants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@RestController
@RequestMapping("/v1")
@Slf4j
public class RegistryControllerV1 {

//	@Autowired
//	@Qualifier("ClaimServiceImplV2")
//	private ClaimService registryService;

	@PostMapping("/de-dupe")
	@Operation(summary = Constants.DE_DUP_API_MESSAGE, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.DE_DUP_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = DeDupReqProxyV1.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.DE_DUP_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_401),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }) })
	@Tag(name = "1. DE-DUPE API")
	public ResponseEntity<RegistryResponse> checkDeDup(@RequestBody DeDupReqProxyV1 applicationRequest,
			HttpServletRequest httpServletRequest) {
		if (OPLUtils.isObjectNullOrEmpty(applicationRequest)) {
			return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
//			RegistryResponse commonResponse = null;// registryService.deDupe(applicationRequest);
//			commonResponse.setToken(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
//			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			return new ResponseEntity<>(new RegistryResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		return null;

	}

//    @SkipInterceptor
	@PostMapping("/enrollment")
	@Operation(summary = Constants.PUSH_ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV1.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_401),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }) })
	@Tag(name = "2. ENROLLMENT DETAILS")
	public ResponseEntity<RegistryResponse> pushEnrollment(@RequestBody EnrollmentReqProxyV1 applicationRequest,HttpServletRequest httpServletRequest) {
		if (OPLUtils.isObjectNullOrEmpty(applicationRequest)) {
			return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);

			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
//			RegistryResponse commonResponse = null;// registryService.enrollment(applicationRequest, userOrgId);
//			commonResponse.setToken(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
//			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			return new ResponseEntity<>(new RegistryResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		return null;

	}

//    @SkipInterceptor
	@PostMapping("/updateTransactionDetails")
	@Operation(summary = Constants.UPDATE_TRANSACTION_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateTransResProxyV1.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_401),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }) })
	@Tag(name = "3. UPDATE TRANSACTION DETAILS")
	public ResponseEntity<UpdateTransResProxyV1> processRenewal(@RequestBody UpdateTransReqProxyV1 renewalReq,
			HttpServletRequest httpServletRequest) {
		if (OPLUtils.isObjectNullOrEmpty(renewalReq)) {
			return new ResponseEntity<>(new UpdateTransResProxyV1(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				return new ResponseEntity<>(new UpdateTransResProxyV1(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
//			UpdateTransResProxyV1 coiResponse = null;// registryService.updateTransactionDetails(renewalReq);
//			coiResponse.setToken(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
//			return new ResponseEntity<>(coiResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			return new ResponseEntity<>(new UpdateTransResProxyV1(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		return null;

	}

//    @SkipInterceptor
	@PostMapping("/updateStatus")
	@Operation(summary = Constants.UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateStatusResProxyV1.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class), examples = {
									@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PLAIN_RESPONSE_401),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }) })
	@Tag(name = "4. UPDATE STATUS")
	public ResponseEntity<RegistryResponse> updateStatus(@RequestBody UpdateStatusReqProxyV1 statusApiReq,
			HttpServletRequest httpServletRequest) {
		if (OPLUtils.isObjectNullOrEmpty(statusApiReq)) {
			return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				return new ResponseEntity<>(new RegistryResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);

			// TODO testing
//			RegistryResponse commonResponse = null;// registryService.updateStatus(statusApiReq);
//			commonResponse.setToken(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
//			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			return new ResponseEntity<>(new RegistryResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		return null;

	}

}
