package com.opl.jns.registry.service.controller.publish.v3;


import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.lib.utils.SkipInterceptor;
import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.api.proxy.jansuraksha.v3.Response400V3;
import com.opl.jns.api.proxy.jansuraksha.v3.Response401;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.service.publish.common.MisServiceV3;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.registry.service.utils.v3.MisEnrolDataScheduler;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "3. MIS Office", description = "List of Mis api")
public class MisControllerV3 {
    //    , description = Constants.PLAIN_REQUEST_DOB_DATE
//    , description = Constants.PLAIN_REQUEST_LBL_DATE
    @Autowired
    private MisServiceV3 misServiceV3;

    @Autowired
    private MisEnrolDataScheduler misEnrolDataScheduler;

    @PostMapping("/misEnrollmentDetails")
    @Operation(operationId = "10", summary = Constants.MIS_ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
            @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.MIS_ENROLLMENT_API_PLAIN_REQUEST, description = Constants.PLAIN_REQUEST_MIS_LBL),
            @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),})), responses = {
            @ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_ENROLLMENT, content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV3.class), examples = {
                            @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS),
                            @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)})}),
            @ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
                            @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
                            @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)})}),
            @ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
                    @Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class))})})
    public ResponseEntity<MisEnrollmentResProxyV3> misEnrollmentApi(
            @Valid @RequestBody MisEnrollmentReqV3 applicationRequest, HttpServletRequest httpServletRequest) {
        log.info("ENTER INTO MIS ENROLLMENT DETAILS API");
        if (OPLUtils.isObjectNullOrEmpty(applicationRequest)) {
            return new ResponseEntity<>(new MisEnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(),
                    Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, Boolean.FALSE), HttpStatus.OK);
        }
        Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
        Object userId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID);
        if (OPLUtils.isObjectListNull(orgId, userId)) {
            log.info("OrgId or userId is null or empty from httpServletRequest.getAttribute() -> APIAuthUtils.REQ_ATR_ORG_ID, APIAuthUtils.REQ_ATR_APP_USER_ID ----------> ");
            return new ResponseEntity<>(new MisEnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(),
                    Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, Boolean.FALSE), HttpStatus.OK);
        }
        applicationRequest.setOrgId(Long.valueOf(orgId.toString()));
        // HERE USER-ID IS API_USER(ID)
        applicationRequest.setUserId(Long.valueOf(userId.toString()));

        MisEnrollmentResProxyV3 misResponse = new MisEnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(),
                Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, Boolean.FALSE);

        try {
            misResponse = misServiceV3.misEnrollmentDetails(applicationRequest);
            misResponse = RegistryUtils.setTokenAndTimeStempV3(misResponse, applicationRequest.getToken());
            if (!OPLUtils.isObjectNullOrEmpty(misResponse.getDmsStorageId())) {
                httpServletRequest.setAttribute(APIAuthUtils.STORAGE_ID, misResponse.getDmsStorageId());
                misResponse.setDmsStorageId(null);
            }
            log.info("EXIT FROM MIS ENROLLMENT DETAILS API");
            return new ResponseEntity<>(misResponse, HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            misResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
            return new ResponseEntity<>(misResponse, HttpStatus.OK);
        }
    }

    /*
    TESTING PURPOSE ONLY
    API TO CALL SCHEDULAR (12:00 AM) METHOD TO PREPARE ENROLLMENT DATA
    * */
    @GetMapping("/prepareDataForExcelUpload/{type}")
    @Operation(hidden = true)
    public ResponseEntity<?> prepareDataForExcelUpload(@PathVariable Long type) {
        try {
            misEnrolDataScheduler.prepareDataByType(type);
            return new ResponseEntity<>(new CommonResponse("Success.", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            return new ResponseEntity<>(new CommonResponse("Error.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    /*
    TESTING PURPOSE ONLY
    API TO CALL SCHEDULAR (04:00 AM) METHOD FOR ENROLLMENT TO UPLOAD EXCEL IN DMS AND SAVE STORAGE-ID IN TABLE
    * */
    @GetMapping("/uploadExcel/{type}")
    @Operation(hidden = true)
    public ResponseEntity<?> uploadExcel(@PathVariable Long type) {
        try {
            misEnrolDataScheduler.uploadMISEnrolDataByType(type);
            return new ResponseEntity<>(new CommonResponse("Success.", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            return new ResponseEntity<>(new CommonResponse("Error.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    /*
    TESTING PURPOSE ONLY
    API TO GENERATE STATE AND CITY WISE SAMPLE REQUEST FOR BOTH SCHEME
    * */
    @GetMapping("/prepareRequest/{counter}/{startsFrom}/{type}")
    @Operation(hidden = true)
    public ResponseEntity<?> prepareRequest(@PathVariable Long counter, @PathVariable Long startsFrom, @PathVariable Long type) {
        try {
            return new ResponseEntity<>(misServiceV3.getDistrictWiseData(counter, startsFrom, TransactionTypeEnum.getById(type).getType()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
    }

    /*
    TESTING PURPOSE ONLY
    API TO CALL SCHEDULAR (12:00 AM) METHOD TO PREPARE CLAIM DATA
    * */
    @SkipInterceptor
    @GetMapping("/prepareClaimData")
    @Operation(hidden = true)
    public ResponseEntity<?> prepareClaimData() {
        try {
            misEnrolDataScheduler.prepareClaimData();
            return new ResponseEntity<>(new CommonResponse("Success.", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            return new ResponseEntity<>(new CommonResponse("Error.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    /*
    TESTING PURPOSE ONLY
    API TO CALL SCHEDULAR (04:00 AM) METHOD FOR CLAIM TO UPLOAD EXCEL IN DMS AND SAVE STORAGE-ID IN TABLE
    * */
    @SkipInterceptor
    @GetMapping("/uploadMISClaimData")
    @Operation(hidden = true)
    public ResponseEntity<?> uploadMISClaimData() {
        try {
            misEnrolDataScheduler.uploadMISClaimData();
            return new ResponseEntity<>(new CommonResponse("Success.", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR IN MIS ENROLLMENT API DETAILS()", e);
            return new ResponseEntity<>(new CommonResponse("Error.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }
}