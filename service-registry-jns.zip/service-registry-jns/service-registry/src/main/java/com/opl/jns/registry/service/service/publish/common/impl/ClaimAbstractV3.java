package com.opl.jns.registry.service.service.publish.common.impl;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.uploaddocs.ClaimDocumentV1;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailDataProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimDocumentResProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimDocumentV3;
import com.opl.jns.dms.api.model.*;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.PushReTryAudit;
import com.opl.jns.ere.enums.*;
import com.opl.jns.ere.repo.ClmDetailsRepository;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.PushReTryAuditRepo;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.published.lib.domain.ApiConfigMaster;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.SchemeMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Transactional
@Slf4j
public abstract class ClaimAbstractV3 {
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;
	
	@Autowired
	private ClmDetailsRepository clmDetailsRepository;
	
	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private PushReTryAuditRepo pushReTryAuditRepo;

	@Autowired
	private ApiConfigMasterRepo configRepo;
	
	@Autowired
	private BucketStorageUtils bucketStorageUtils;

	private static final String WH_DOC = "WH_DOC_";
	
	protected ClaimDetailsResProxyV3 deDupeLogic(ClmMaster claimMaster, ApplicationMasterBothSchemeProxy appMaster) {
		// DE-DUPE NEED TO CHANGE AS PER SCHEME BASE AND DISCUSSION WITH HRIDAY
		if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getSource()) && !Objects.equals(claimMaster.getSource(), Source.OTHER_CHANNEL.getId())) {
			if(Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_IN_PROGRESS.getId())) {
				return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_INITIATED_OTR_SRC_MSG,
                                        false);
			}
		}
		if (claimMaster.getStageId() == ClaimStageMaster.CLAIM_FORM.getStageId()
				|| claimMaster.getStageId() == ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()) {
			return new ClaimDetailsResProxyV3(RegistryUtils.CLAIM_INITIATED_MSG_1, new ClaimDetailDataProxyV3(claimMaster.getId()),HttpStatus.OK.value(),false);
		} else if (claimMaster.getStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
			if (SchemeMaster.PMJJBY.getId().intValue() == claimMaster.getSchemeId()) {
				return dedupeForPMJJBY(claimMaster,appMaster);
			} else {
				return dedupeForPmsby(claimMaster);
			}
		}
		return new ClaimDetailsResProxyV3(HttpStatus.OK.value(), "", true);
	}
	
	private ClaimDetailsResProxyV3 dedupeForPmsby(ClmMaster claimMaster) {
		
		 ClmDetails clmDetails = clmDetailsRepository.getById(claimMaster.getId());
		// NATURE OF LOASS 1 : DEATH && 2 : DISABILITY
		if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getStatus())
				&& !com.opl.jns.utils.common.OPLUtils
						.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId())
				&& clmDetails.getCauseOfDeathDisabilityId()
						.equals(CauseOfDeathDisabilityV2.ACCIDENTAL.getId())
				&& clmDetails.getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
			return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(),
                    RegistryUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG, false);
		}
		if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId())
				&& clmDetails.getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
			if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
				return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(),
                        RegistryUtils.DEATH + " " + RegistryUtils.CLAIM_ALREADY_PAID_MSG, false);
			}
			if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getStatus())) {
				return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(),
                        RegistryUtils.CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG, false);
			}
			if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getStatus())) {
				return new ClaimDetailsResProxyV3(
                        HttpStatus.BAD_REQUEST.value(), RegistryUtils.DEATH + " " + RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG,
                                        false);
			}
		} else {
			if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId())
					&& clmDetails.getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
					&& !com.opl.jns.utils.common.OPLUtils
							.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId())
					&& clmDetails.getTypeOfDisabilityId()
							.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
					return new ClaimDetailsResProxyV3(
                            HttpStatus.BAD_REQUEST.value(),
                            RegistryUtils.TOTAL_DISABILITY + " " + RegistryUtils.CLAIM_ALREADY_PAID_MSG, false);
				}
				if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getStatus())) {
					return new ClaimDetailsResProxyV3(
                            HttpStatus.BAD_REQUEST.value(),
                            RegistryUtils.TOTAL_DISABILITY + " " + RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, false);
				}
			} else {
				List<Integer> statusList = new ArrayList<>();
				statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
				statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
				Long count = clmMasterRepository.countByApplicationIdAndIsActiveTrueAndStatusIn(
						claimMaster.getApplicationId(), statusList);
				if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(count) && count > RegistryUtils.LONG_2) {
					return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(),
                            RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, false);
				}
				// ------------------------------ NEED TO HANDLE THIS SCENARIO
				return new ClaimDetailsResProxyV3(HttpStatus.OK.value(), SchemeMaster.PMSBY.getShortName(), true);
			}
		}
		List<ClmMaster> claimMastersLst = clmMasterRepository
				.findByApplicationIdAndIsActiveTrue(claimMaster.getApplicationId());
		Boolean isProcced = false;
		if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId())
				&& clmDetails.getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
				&& clmDetails.getTypeOfDisabilityId()
						.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
			for (ClmMaster master : claimMastersLst) {
				if (ClaimStatus.CLAIM_REJECTED.getId().equals(master.getStatus())
						&& (!com.opl.jns.utils.common.OPLUtils
								.isObjectNullOrEmpty(clmDetails.getNatureOfLossId())
								&& clmDetails.getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
								&& !com.opl.jns.utils.common.OPLUtils
										.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId()))) {
					isProcced = true;
				}
			}
		}
		if (isProcced.equals(Boolean.TRUE)) {
			return new ClaimDetailsResProxyV3(HttpStatus.OK.value(), SchemeMaster.PMSBY.getShortName(), true);
		}
		return new ClaimDetailsResProxyV3(HttpStatus.OK.value(), "", true);
	}

	private ClaimDetailsResProxyV3 dedupeForPMJJBY(ClmMaster claimMaster,ApplicationMasterBothSchemeProxy appMaster) {
		ClmDetails clmDetails = clmDetailsRepository.getById(claimMaster.getId());
		
		if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getStatus()) && clmDetails.getCauseOfDeathDisabilityId().equals(CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId())) {
			return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(),
                    RegistryUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG, false);
		} else if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getStatus()) && clmDetails.getCauseOfDeathDisabilityId().equals(CauseOfDeathDisabilityV2.ACCIDENTAL.getId())) {
			return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_ALREADY_REJETED_DEATH_MSG,
                                false);
		}

			long dateDiff = com.opl.jns.utils.common.DateUtils.dateDiff(clmDetails.getDateOfDeath(),
					appMaster.getEnrollmentDate());
			if (dateDiff > 30) {
				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
					return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_DEATH_PAID_MSG, false);
				} else {
					return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_DEATH_MSG, false);
				}
			} else {
				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getStatus())) {
					return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_ACCIDENTIAL_PAID_MSG,
                                                false);
				} else {
					return new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), RegistryUtils.CLAIM_ACCIDENTIAL_MSG, false);
				}
			}
		
	}
	
	@SuppressWarnings("unchecked")
	protected <T extends ClaimDocumentV3, U extends ClaimDocumentResProxy> U documentUploadAndManageProcess(List<T> doc, Long claimRefId, String remarks) {
		
		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimRefId);
		DocumentResponse docResponse = null;
		try {
		// here claimReferenceId is claimId from claim master - ere
		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
			log.error("ClaimMaster data not found");
			return (U) new ClaimDocumentResProxy(HttpStatus.NOT_FOUND.value(),"ClaimMaster data not found",  Boolean.FALSE);
		}

		/** if claim already registered */
		if (claimMaster.getStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()
				&& !Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_IN_PROGRESS.getId())
				&& !Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
			log.error("claim already registered");
			return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(), "Claim already registered with for this claim reference id and URN.", Boolean.FALSE);
		}
		
		/**if claim is queried then remarks is mandatory*/
		if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())
				&& (OPLUtils.isObjectNullOrEmpty(remarks))) {
			log.error("remarks is mandatory for queried claim");
			return (U) new APIResponseV3(HttpStatus.BAD_REQUEST.value(),"Remarks is mandatory for Query revert claims",Boolean.FALSE);
		}
		
		/** if claim source is different */
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getSource()) && !Objects.equals(claimMaster.getSource(), Source.OTHER_CHANNEL.getId())) {
			log.error("source is different");
			return (U) new APIResponseV3(HttpStatus.BAD_REQUEST.value(),"claim source is different",  Boolean.FALSE);
		}
		
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setApplicationId(claimMaster.getApplicationId());
		documentRequest.setSchemeId(claimMaster.getSchemeId());
		documentRequest.setClaimId(claimMaster.getId());

		ClmDetails clmDetails = clmDetailsRepository.getById(claimMaster.getId());
		
		if (claimMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue())
			documentRequest.setDisabilityTypeId(
					OPLUtils.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId()) ? null
							: clmDetails.getCauseOfDeathDisabilityId());
		else {
			documentRequest.setDisabilityTypeId(
					OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId()) ? null
							: clmDetails.getNatureOfLossId());
		}
		List<ClaimDocumentV3> claimUploadDocumentsLst = (List<ClaimDocumentV3>) doc;
		DocumentResponse documentResponse = dmsClient.findTypeIdByDisabilityTypeIdAndSchemeId(documentRequest);
		if (!OPLUtils.isObjectNullOrEmpty(documentResponse.getDataList())) {
			List<AnsProductDocumentResponse> masterList = MultipleJSONObjectHelper.getListOfObjects(
					MultipleJSONObjectHelper.getStringfromListOfObject(documentResponse.getDataList()), null,
					AnsProductDocumentResponse.class);
			List<MultipartObjectRequest> multiPartObjList = new ArrayList<>();
//			StringBuilder s1 = new StringBuilder();

			List<Long> reqDocIds = claimUploadDocumentsLst.stream()
					.map(ClaimDocumentV1::getDocumentId).collect(Collectors.toList());

			if (!OPLUtils.isListNullOrEmpty(masterList)) {
				List<AnsProductDocumentResponse> docList = null;

				if ((OPLUtils.isObjectNullOrEmpty(clmDetails.getIsClaimantSame())
						|| clmDetails.getIsClaimantSame() == Boolean.FALSE)) {
					docList = masterList.stream()
							.filter(x -> !x.getDocId().equals(14L) && !x.getDocId().equals(15L))
							.collect(Collectors.toList());
				} else {
					docList = masterList;
				}
				log.info("doc list: {}",docList.toString());
				if (!OPLUtils.isListNullOrEmpty(docList)) {
					StringBuilder missingDoc = new StringBuilder();
					Map<Integer, List<AnsProductDocumentResponse>> collectMap = docList.stream()
							.collect(Collectors.groupingBy(AnsProductDocumentResponse::getGroupId));

					boolean isAllDoc = true;
					if (!OPLUtils.isObjectNullOrEmpty(collectMap)
							&& !OPLUtils.isListNullOrEmpty(collectMap.values())) {
						for (List<AnsProductDocumentResponse> responseList : collectMap.values()) {
							if (!OPLUtils.isListNullOrEmpty(responseList)) { // isAllDoc &&
								if (responseList.size() == 1) {
									if (!reqDocIds.contains(responseList.get(0).getDocId())
											&& Boolean.TRUE.equals(responseList.get(0).getIsMandatory())) {
										isAllDoc = false;
										missingDoc.append(responseList.get(0).getDocId() + " - "
												+ responseList.get(0).getDocumentName() + ", ");
									}
								} else {
//									List<Long> groupDocIdList = responseList.stream().map(x -> x.getDocId()).collect(Collectors.toList());
									boolean checkGroupDocUpload = false;
									for (AnsProductDocumentResponse response : responseList) {
										if (!checkGroupDocUpload) {
											if (reqDocIds.contains(response.getDocId())
													&& Boolean.TRUE.equals(response.getIsMandatory())) {
												if (9L == response.getDocId() && reqDocIds.contains(9L)) { // 9 ->
																											// FIR/Panchnama
													List<Long> docIdList = responseList.stream()
															.filter(x -> !Objects.equals(x.getDocId(), response.getDocId()))
															.map(x -> x.getDocId()).collect(Collectors.toList());
													if (!OPLUtils.isListNullOrEmpty(docIdList)) {
														Optional<Long> first = docIdList.stream()
																.filter(x -> x == 21L).findFirst();
														if (first.isPresent() && reqDocIds.contains(21L)) { // 21 ->
																											// Post
																											// Mortem
																											// Report
															checkGroupDocUpload = true;
															break;
														}
													}
												} else {
													checkGroupDocUpload = true;
													break;
												}
											}
										}
									}
									if (!checkGroupDocUpload && Boolean.TRUE.equals(responseList.get(0).getIsMandatory())) {
										int index = 0;
										for (AnsProductDocumentResponse response : responseList) {
											if (9L == response.getDocId() && reqDocIds.contains(9L)) { // 9 ->
																										// FIR/Panchnama
												if (index == 0
														&& !OPLUtils.isObjectNullOrEmpty(response.getTitleName())) {
													missingDoc.append(response.getTitleName() + " -> ");
												}
												List<Long> docIdList = responseList.stream()
														.filter(x -> !Objects.equals(x.getDocId(), response.getDocId()))
														.map(x -> x.getDocId()).collect(Collectors.toList());
												if (!OPLUtils.isListNullOrEmpty(docIdList)) {
													Optional<Long> first = docIdList.stream().filter(x -> x == 21L)
															.findFirst();
													if (first.isPresent() && reqDocIds.contains(21L)) { // 21 ->
																										// Post
																										// Mortem
																										// Report
														missingDoc.append(response.getDocId() + " - "
																+ response.getDocumentName() + ", ");
													}
												}
											} else {
												missingDoc.append(response.getDocId() + " - "
														+ response.getDocumentName() + ", ");
											}
											index++;
										}
										isAllDoc = false;
									}
//									 isAllDoc = checkGroupDocUpload;
								}
							}
						}
//						return new RegistryResponse(missingDoc.toString(), "Missing Documents: " + missingDoc, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
					}

					if (!isAllDoc && !OPLUtils.isObjectNullOrEmpty(missingDoc)) { // !isAllDoc &&
						String msg = missingDoc.toString();
						msg = msg.substring(0, msg.length() - 2);
						log.error("Please upload All Mandatory Documents");
						log.info("Missing Documents: " + msg);
						return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(),"Missing Documents:===>    " + msg,Boolean.FALSE);
					}

					docList.stream().forEach(document -> {
						prepareForUploadDocs(claimUploadDocumentsLst, documentRequest, multiPartObjList, document);
					});

					/** Upload documents */
					docResponse = dmsClient.uploadMultipleFileWithDocMappingIds(multiPartObjList);
					if (docResponse.getStatus() == 200 && !OPLUtils.isListNullOrEmpty(docResponse.getDataList())) {
						if (!claimMaster.getStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
							/** push complete claim details */
							CommonResponse response = updateClaimMaster(claimMaster.getId(),
									RegistryUtils.PUSH_CLAIM_DATA);
							if (OPLUtils.isObjectNullOrEmpty(response) && response.getStatus() == 200) {
								claimMaster.setIsPushed(Boolean.TRUE);
								claimMaster.setModifiedDate(new Date());
								claimMaster.setRemarks(remarks);
								clmMasterRepository.save(claimMaster);
							} else {
								/* IN CASE ERROR IN CLAIM PUSHED THE ADD TO PUSH RETRY */
								PushReTryAudit pushReTryAudit = new PushReTryAudit();
								pushReTryAudit.setApplicationId(claimMaster.getApplicationId());
								pushReTryAudit.setClaimId(claimMaster.getId());
								pushReTryAudit.setReTryCount(RegistryUtils.INT_0);
								pushReTryAudit.setCreatedDate(new Date());
								pushReTryAudit.setType(RegistryUtils.PUSH_RE_TRY_CLAIM);
								pushReTryAudit.setIsPushed(Boolean.FALSE);
								pushReTryAudit.setMessage(response.getMessage());
								pushReTryAuditRepo.save(pushReTryAudit);
							}
						} else {
							/** update the re-uploaded docs in table */
							List<Long> storageList = new ArrayList<>(docResponse.getDataList().size());
							for (Object obj : docResponse.getDataList()) {
								@SuppressWarnings("rawtypes")
								StorageDetailsResponse objectFromMap = MultipleJSONObjectHelper
										.getObjectFromMap((Map) obj, StorageDetailsResponse.class);
								storageList.add(objectFromMap.getId());
							}

							claimMaster.setStatus(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
							claimMaster.setRemarks(remarks);
							claimMaster.setQueriedStorageId(!storageList.isEmpty()
									? storageList.toString().replace('[', ' ').replace(']', ' ')
									: null);
							clmMasterRepository.save(claimMaster);

							/** re-push the docs only */
							rePushDocs(claimMaster.getId());

						}
						return (U) new APIResponseV3(HttpStatus.OK.value(),"Uploaded Successfully", Boolean.TRUE);
					}
				}
			}
			log.error("Something went wrong");
			return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(),"Invalid Requested Document details.",Boolean.FALSE);
		} else {
			log.error("Data not found");
			return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(),"Invalid Requested Document details.",Boolean.FALSE);
		}
		}catch (Exception e) {
			log.error("Exception While claim upload document :: ", e);
			return (U) new ClaimDocumentResProxy(HttpStatus.BAD_REQUEST.value(),HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), Boolean.FALSE);
		}
	}
	
	private static void prepareForUploadDocs(List<ClaimDocumentV3> claimUploadDocumentsLst,
			DocumentRequest documentRequest, List<MultipartObjectRequest> multiPartObjList,
			AnsProductDocumentResponse document) {
		claimUploadDocumentsLst.stream().forEach(RequestDoc -> {
			if (document.getDocId().equals(RequestDoc.getDocumentId())) {
				DocumentRequest docRequest = new DocumentRequest();
				BeanUtils.copyProperties(documentRequest, docRequest);
				docRequest.setProductDocumentMappingId(document.getProDocMapId());
				docRequest.setDocumentId(RequestDoc.getDocumentId());
				docRequest.setDocName(document.getDocumentName());
				MultipartObjectRequest objectReq = new MultipartObjectRequest(RequestDoc.getDocument(), docRequest);
				multiPartObjList.add(objectReq);
			}
		});
	}
	
	protected void rePushDocs(Long claimId) {
		/** re-push the docs only */
		updateClaimMaster(claimId, RegistryUtils.PUSH_CLAIM_REVISED_DOCS);
	}

	private CommonResponse updateClaimMaster(Long claimId, String urlPart) {
		ApiConfigMaster pushPullApi = configRepo.findByCodeAndIsActiveTrue(urlPart);
		if (null != pushPullApi) {
			String url = pushPullApi.getValue() + "/" + claimId;
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
				headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
				headers.set("isDecrypt", "true");
				headers.add("Accept", "application/json");
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<?> entity = new HttpEntity<>(headers);
				RestTemplate restTemplate = new RestTemplate();
				log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
				return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			} catch (Exception e) {
				log.error("Exception While calling claim push details api :: ", e);
			}
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	protected ClaimStatusUpdateResProxyV3 reasonIsValidOrNot(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, ClmMaster master) {
		if (updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
			List<QueriedClaimEnum> enumValues = new ArrayList<>(EnumSet.allOf(QueriedClaimEnum.class));
			if (!enumValues.stream().map(x->x.getId()).collect(Collectors.toList()).contains(updateAppClaimRequest.getReason())) {
				log.error(
						"reason must be : 1. Complete claim documents not submitted by claimants 2. Claim documents not forwarded by banks to insurer 3. Deceased’s name mismatch with death certificate 4. Nominee’s name differs in enrolment & claim form 5. KYC proof of nominee not submitted 6. NEFT account details of nominee not submitted 7. Title to claim money not clear 8. NEFT Rejected");
				return new ClaimStatusUpdateResProxyV3(
						"reason must be : 1. Complete claim documents not submitted by claimants 2. Claim documents not forwarded by banks to insurer 3. Deceased’s name mismatch with death certificate 4. Nominee’s name differs in enrolment & claim form 5. KYC proof of nominee not submitted 6. NEFT account details of nominee not submitted 7. Title to claim money not clear 8. NEFT Rejected",
						Boolean.FALSE,HttpStatus.BAD_REQUEST.value());
			}
		}
		
		if (updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_REJECTED.getId())) {
			if(master.getSchemeId().intValue()==SchemeMaster.PMSBY.getId()) {					
				List<PMSBYRejectedClaimEnum> enumValues = new ArrayList<>(EnumSet.allOf(PMSBYRejectedClaimEnum.class));
				if (!enumValues.stream().map(x->x.getId()).collect(Collectors.toList()).contains(updateAppClaimRequest.getReason())) {
					log.error(
							"reason must be : 1. Complete claim documents not submitted by claimants 2. Death during lien period 3. Death not established by documents submitted 4. Others");
					return new ClaimStatusUpdateResProxyV3(
							"reason must be : 1. Complete claim documents not submitted by claimants 2. Death during lien period 3. Death not established by documents submitted 4. Others",
							Boolean.FALSE,HttpStatus.BAD_REQUEST.value());
				}
			}else {
				List<PMJJBYRejectedClaimEnum> enumValues = new ArrayList<>(EnumSet.allOf(PMJJBYRejectedClaimEnum.class));
				if (!enumValues.stream().map(x->x.getId()).collect(Collectors.toList()).contains(updateAppClaimRequest.getReason())) {
					log.error(
							"reason must be : 1. Duplicate claim 2. Death due to suicide 3. Death is not due to accident 4. Disability not due to accident 5. Disability not permanent 6. Death / disability due to accident, not established by documents submitted 7. Others");
					return new ClaimStatusUpdateResProxyV3(
							"reason must be : 1. Duplicate claim 2. Death due to suicide 3. Death is not due to accident 4. Disability not due to accident 5. Disability not permanent 6. Death / disability due to accident, not established by documents submitted 7. Others",
							Boolean.FALSE,HttpStatus.BAD_REQUEST.value());
				}
			}
		}
		return null;
	}
	
	protected ClaimDetailsResProxyV3 checkPMSBYDedupe(ApplicationMasterBothSchemeProxy appMaster,Long schemeId) {
		List<Integer> statusList = new ArrayList<>();
		statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
		statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());

		// PMSBY Multi Claim Validation check(Max 2 claim allowed)
		if (SchemeMaster.PMSBY.getId().intValue() == schemeId) {
			Long count = clmMasterRepository
					.countByApplicationIdAndIsActiveTrueAndStatusIn(appMaster.getId(), statusList);
			if (!OPLUtils.isObjectNullOrEmpty(count) && count >= CommonUtils.LONG_2) {
				return new ClaimDetailsResProxyV3(HttpStatus.CREATED.value(), CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG,
                                        false);
			} else {
				statusList.clear();
				statusList.add(ClaimStatus.CLAIM_IN_PROGRESS.getId());
				count = clmMasterRepository.countByApplicationIdAndIsActiveTrueAndStatusIn(
						appMaster.getId(), statusList);
				if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
					return new ClaimDetailsResProxyV3(HttpStatus.CREATED.value(), CommonUtils.CLAIM_SUBMISSION_IN_PROGRESS_MSG,
                                                false);
				}
			}
		}
		return new ClaimDetailsResProxyV3(HttpStatus.OK.value(), "", true);
	}
}
