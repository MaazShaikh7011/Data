package com.opl.jns.registry.service.service.publish.v2;

import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransResProxyV2;

/**
 * @author sandip.bhetariya
 *
 */
public interface EnrollTransServiceV2 {

	UpdateTransResProxyV2 updateTransactionDetailsAndGetCoiFiles(UpdateTransResProxyV2 coiResponse,
																 UpdateTransReqProxyV2 transactionRequest) throws Exception;

}
