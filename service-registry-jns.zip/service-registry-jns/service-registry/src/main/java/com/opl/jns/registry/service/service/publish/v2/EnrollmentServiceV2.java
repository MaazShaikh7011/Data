package com.opl.jns.registry.service.service.publish.v2;
//package com.opl.service.registry.jns.service.publish.v2;
//
//import com.opl.publish.common.RegistryReqProxy;
//import com.opl.publish.v2.enroll.EnrollmentResProxyV2;
//import com.opl.publish.v2.enrollDedup.DeDupResProxyV2;
//import com.opl.publish.v2.enrollStatusUpdate.UpdateStatusResProxyV2;
//
//public interface EnrollmentServiceV2 {
//
//	public <T extends RegistryReqProxy> DeDupResProxyV2 checkDeDupe(T t, Long orgId);
//
//	public <T extends RegistryReqProxy> EnrollmentResProxyV2 saveEnrollmentDetails(T t, Long userOrgId);
//
//	public <T extends RegistryReqProxy> UpdateStatusResProxyV2 updateStatus(T t);
//
//}
