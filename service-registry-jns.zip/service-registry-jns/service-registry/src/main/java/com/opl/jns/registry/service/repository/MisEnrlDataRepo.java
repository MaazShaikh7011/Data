package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.MisEnrlData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MisEnrlDataRepo extends JpaRepository<MisEnrlData, Long> {

    List<MisEnrlData> findAllByVersionAndType(Long version, Integer type);

    List<MisEnrlData> findAllByVersionAndTypeAndOrgId(Long version, Integer type, Long orgId);

    List<MisEnrlData> findAllByVersionAndTypeAndOrgIdAndSchemeId(Long version, Integer type, Long orgId, Integer schemeId);

    MisEnrlData findFirstByTypeAndOrgIdOrderByVersionDesc(Integer type, Long orgId);

}
