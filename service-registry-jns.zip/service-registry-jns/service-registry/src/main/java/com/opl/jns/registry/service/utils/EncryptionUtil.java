package com.opl.jns.registry.service.utils;

import jakarta.xml.bind.DatatypeConverter;
import org.springframework.stereotype.Component;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;

@Component
public class EncryptionUtil {


    private static final int GCM_TAG_LENGTH = 16;
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final String ALGO_AES = "AES";
    private static final String ALGO_RSA = "RSA";
    private static final String ENCODING = "UTF-8";
    private static final String HEADER_ENC_ALGO = "RSA/ECB/OAEPPADDING";
    private static final String SIGNATURE = "SHA256withRSA";
    private static final String SEPARATOR = ":";
    private static final String OPL_PRIVATE_KEY = "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQCfBwYduLF3cMkjThZqFtEysbOA2z6HaI1Q5+9OY2V71HlthlYKWVhaIoRjrEuEtw+Mw/r9KIo8T5XbASnLz9E0qdRfX9ho9dQ7g1j/jyBFD4RAeR1CeeKwwtTXSkgpa47AfmYjes5+3iu1IdatrRIgyXzBXjXDj5plp/1JdOIFMm+sbYsIFnzojSHWCr+N20DlvzFeNTlT2arCG9aSPc9R5xhPw+jwtGddE4wTxQOEPPM2aFdFRfW/af5iYv2CtUQqanllBhajv5VEahm9y935fysecvESQ+ahqu23HPWg43Q19kMfFTSdLyOoM9IxFT85YteMCEXAeY/ufEJt5Ebs8Bv4rlQIoo9MqXYPbEMgpejAcEQwpYwR5yb1Le6t0rA/s+wm8cA32ksK/IbmozykyFNChiwb5KBa/4m0TYQ8SbeXfH5QGnUQggGlCKKw4tnu56YtRdGNSKsuQC+89wf9XP0+WyMZndb3PYN7FBHAOYypNEPd2uZyPw8vh//TA7TA9ZWBmEaV19WpF6g1cuoMmObRaTX9Wn0B2/gKqPIvbtGdDr5vj2CizSKJUKYPGNrV978HWcb+9cVZ8ncPJlHYlLsvmfPRJyPuOuLkmMNx9GTjm6GcjCAuixnXQIk9N/6xlaJqixwuFiWl5pDdUyRLiyuunFgmeUU3D0tn/0ulvQIDAQABAoICAEGBECjf8eHECGXNfXgXi/Y4sjrKlFgMXeFMmAsO8Ddwjs/pfLlokfcWrrerubOh//q4o0LyFva+xXhfY0r7gC4UIlFi1m5tjA0zjk4+M0mfGZfBC6ddM14h8q/3ff/puPRbXFES/cnOU+yZUqdZWdU9iXDREI5MMYncB33hclQ3sT4yJQmg0bSspZpX9Q1GmdXIyloGzGVYjHjGJL06TpJrAV2h0eqMNONm8NUX2tn2jSwFEKWNKqu8yjbWlZvodHqQPw640kyC1sZGefHu7rEdi7JQIDKo23AOSzqY6ChsaGrt1DoSbwir6SEYr2TeXpuRtj2NDsY4jGvsrSQ82mWKQyZil7IUKx3Mz5sbymVLg8MV42mZdXHpNcWTo6JTTOErFkx3W5Cn/HFpFrQ+6c6uzQNopqPW9oyx/sN7d6t8CfOAjMgJ7vN4VVmRV7Q4kjFJ6Qoz5AbV1qFo0TXlFf2WwVX/ryGPnWB3sbWKtRpQRwiXG/iMMRBuh8YumeG+z2n72Qcb/XwjEtZkjuJDuJc/Ht9Jnq3OiH1IkagVpmKhJ4GaraGQTdyfjwpOCeuPyykzLxaUvQNJ7hZpIo6XdWjHxwKuPbtxmiNx+vHvO3Hwa6BJOSU8TUGwAtxIMT4EXwwjSXnIoTsA1XcjTv1IdqIQqaM22sTVuRP7F0et9LLVAoIBAQDOISNqeXHE60mM/QhvtYSF5RNyUI8NGoa44fGPEEuGEJA6vGReKMMoLNk+cnWwBXUCErUhWoesvefyNTB6EcInNurN5ZK/pCwFr9W2IAYmtLRYx86zujYt2QDFgWA/+uAj85khmDYurLgGWqzyuN2723YYVXWSsDslZqbPeahptDbw11jjyUMdp5oFrNyrAYSEf4QVxnaRDvLTHs+aToUcS4b/fab6sy/LYXT8ztDplMQRbmwqVtPjDLUrmgo4PDgmf/vWtHJuEwK0NgFP1DU4qVUNkBx9yJflWy2GQtDXivjk5YA6LpmgNBQDe7WPJLr9ETlA381aooJzQkVrE5t3AoIBAQDFgJGrxToJIQLRY972qMdNlxsfyHzDiPHeVqBkwN9a+r0yKYPM/k0qFuXfHkz0j8rWq6dtscvGXdRflVjpgPVc27yoEcmg9q3tBSOJT7yR/3yeCefoVsuR1zhrK42ZK66ElPTdZIbByJjl1Fhh5ylbCYJBPhRMBxi6sPU5dSQF63qTzB5lhsbYHmXKay8ugkO/CMdcbRNm+0tY72CZMcdJ3UIlOTauiMc7pKGIO8m5RsMjWxGEz2OhtybMo5KImEjSmpSL1UPajiyW5cAItd8bSjTdKfjb1tgZJB8Sna+lIQhC1LVEEZKBre+JQZaSrUEv4+SelUjQNcPPPiEsWG1rAoIBAAxXh5tUci9sNxct/1dQ8wJhWOy7ThVmxTJEtQXv39XDIB+kMA5DOowpQ0it6cYETaE2JYo9tWnuZPjnnmNwtMNMUnrJiCPZXJlqkc051aRzpWi7bfDs8VmFaLpqqKysBMeiSkTsrDHXPZ2DyF8wGnapCUUjuMpzqtbucoZxrlfF5pQ9EKFy54XbBynX086ZZKnaSLpVC7xbvMZPTfbbRLURAKBDkb/pAq+Wwj5w06losuSoS+mtETrDBAX8TyhW0rXba+TLIR7eHIdVxHZXKmieGu2Y91vAqvecofkr/v0o4QYzh530NFaXR6t9uL09YcTNRzRPMih/Gnh0O1vR7LkCggEBAMTTwdkewBzS8jz9O/oz8BQKcHS3WGeCNhFv4X8nnDDOS/kO2JRWJ0637TTzvJvKJcrU3RH8K+mwHvN3IlnrNBvrvVL+DyREUscw5N52QaZ6qJXTp3Or9EqO42Ii0IYCu3TUAkgVZBsBsCbz/XTsbBGXI2Gj3ZR7ShDcRDeT32eq6skalnx12fsOKEGXmjjOh3d95zjcV4a9D7U9MtbZfhPF1qLEJxO/qlZtVrIva3Ui6Vx16Lqj+FX08kzlAybwJTsF5N6KloncQOHNbBkCL6vBw3dZ2fI1Zb2AexsRXTfC+LmpxFBm9swYLO1sGQRqd9mjU3cbraoaut7xuxu3sKsCggEAAOoBDm/ndoiDm4Vpg8HZmjg3WrOVER554kNpC7zDW+6PoojROnuLGYoLvDEsQhmCa08SdEiJYBc8YAYfWDDAzU6JlGNBQOPpb5AlTa6HBkF3C9jZWpbnSgebhIrWNvd2Oy3v0a/7bRaXXuIRdDQBfgg0bXb6gZr4eHm6jmZf5LSMwR+VTJDsS896pj9nYHAUScy3bQRSBVAW83xAWao9dl08DyxDB5xTEamMdrWDegIpZy6JxM+CPgtV5pLwOuIPxeCBpmDjPcu/AjRO+6tWJsQ9FId3W9LLxKDUbrv3zR08BuhF6GsfrbTEBvZOfV4UFykjBmyhJw3vj2JJb4TzNw==";
    private static final String OPL_PUBLIC_KEY = "MIIFhTCCA22gAwIBAgIUEKQVoGxicPwAXF9r7z4cEy7l7qAwDQYJKoZIhvcNAQELBQAwUjELMAkGA1UEBhMCSU4xDDAKBgNVBAgMA0dVSjEMMAoGA1UEBwwDQUhNMQwwCgYDVQQKDANPUEwxCzAJBgNVBAsMAklUMQwwCgYDVQQDDANPUEwwHhcNMjMwMzAzMTMyNzMyWhcNMzMwMjI4MTMyNzMyWjBSMQswCQYDVQQGEwJJTjEMMAoGA1UECAwDR1VKMQwwCgYDVQQHDANBSE0xDDAKBgNVBAoMA09QTDELMAkGA1UECwwCSVQxDDAKBgNVBAMMA09QTDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAJ8HBh24sXdwySNOFmoW0TKxs4DbPodojVDn705jZXvUeW2GVgpZWFoihGOsS4S3D4zD+v0oijxPldsBKcvP0TSp1F9f2Gj11DuDWP+PIEUPhEB5HUJ54rDC1NdKSClrjsB+ZiN6zn7eK7Uh1q2tEiDJfMFeNcOPmmWn/Ul04gUyb6xtiwgWfOiNIdYKv43bQOW/MV41OVPZqsIb1pI9z1HnGE/D6PC0Z10TjBPFA4Q88zZoV0VF9b9p/mJi/YK1RCpqeWUGFqO/lURqGb3L3fl/Kx5y8RJD5qGq7bcc9aDjdDX2Qx8VNJ0vI6gz0jEVPzli14wIRcB5j+58Qm3kRuzwG/iuVAiij0ypdg9sQyCl6MBwRDCljBHnJvUt7q3SsD+z7CbxwDfaSwr8huajPKTIU0KGLBvkoFr/ibRNhDxJt5d8flAadRCCAaUIorDi2e7npi1F0Y1Iqy5AL7z3B/1c/T5bIxmd1vc9g3sUEcA5jKk0Q93a5nI/Dy+H/9MDtMD1lYGYRpXX1akXqDVy6gyY5tFpNf1afQHb+Aqo8i9u0Z0Ovm+PYKLNIolQpg8Y2tX3vwdZxv71xVnydw8mUdiUuy+Z89EnI+464uSYw3H0ZOOboZyMIC6LGddAiT03/rGVomqLHC4WJaXmkN1TJEuLK66cWCZ5RTcPS2f/S6W9AgMBAAGjUzBRMB0GA1UdDgQWBBQK/fOEblIxsjLJgprXz3ZwD59FpTAfBgNVHSMEGDAWgBQK/fOEblIxsjLJgprXz3ZwD59FpTAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBCwUAA4ICAQBTbQlg7Eyxzbj6I6KsSpDhrxp9p76Hn1nDDxG25WRneSRy6l4vU8evPmwEtHerYKNaqmZZWgHCKCuzci4/YGJBNXhVSsXkt5Ypha4kFMcJBr+IQ6HLU0/NcxUkDhx1lkwK51RtE4AY83cyOd0SCMjLAMmzlPasvdnyrWC0i8SLZl/bTPyq4ZRSXVQDX54H93xFSk1gLhwO5JU1N2chWa0xbWvYjlx0J1rrOOt7hReMnNbfYXo5fyl0iyFOQgLD4/fKwfXnnxiy1jeXBgXB40WO1qAP80TQM5Yb5vssL/aMTbZx0yDXj/RLwHxKaf9Gs024Wat4oVLNZoRatmBhd7SHv3hqrAuZFZQYfHPGnXvgUeGn9it886z17ynbWr+F/kAzzCSBKSeYiEYzCcOnxZbbkzI92UwG4o9/Hn65DMa3hYryBzamK9ezwY8NLjhl20bHnF75biP6TWKRjn2miO4ScAtsJvgDr3CCSF2zi6rhj6EFdx/lTVDca85slDhugctmx5+q4EC5/XB+cxA3bZCVgS1jDER0o6gVjMZVB1Db2NtN5X1zTMMHVOjsXvOp9KRPNz7TYumsC7jmYxcv0DPBog0PHA2stn7Rly0ldYfeV8SqAMGYwQnBkApZkqM3ZUCuC6QEUtAKfas9dtqlYWISpkxEC7tl0PmrD9PxZPC4rw==";

    public static String encrypt(String plainText, String privateKey, String publicKey) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException, NoSuchProviderException  {

        String dynamicKey = UUID.randomUUID().toString().replaceAll("-","");
        byte[] iv = getIVFromAESKey(dynamicKey.getBytes());
        byte[] encrypt = encryptRequestBodyAES256(plainText.getBytes(), dynamicKey.getBytes(),iv);
        String encryptionRequestBody = Base64.getEncoder().encodeToString(encrypt);
        String digitalSignature = signSHA256RSA(encryptionRequestBody, privateKey);
        String headerKey = getEncryptHeader(dynamicKey, publicKey);
        return Base64.getEncoder().encodeToString((headerKey + SEPARATOR + encryptionRequestBody + SEPARATOR + digitalSignature).getBytes());
    }

    private static byte[] getIVFromAESKey(byte[] encoded) {
        return Arrays.copyOfRange(encoded, 0, 16);
    }

    private static byte[] encryptRequestBodyAES256(byte[] plaintext, byte[] key, byte[] IV) throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException {

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        SecretKeySpec keySpec = new SecretKeySpec(key, ALGO_AES);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);
        return cipher.doFinal(plaintext);
    }

    private static String signSHA256RSA(String input, String privateKeyStr) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException {

        byte[] b1 = DatatypeConverter.parseBase64Binary(privateKeyStr);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
        KeyFactory kf = KeyFactory.getInstance(ALGO_RSA);
        Signature privateSignature = Signature.getInstance(SIGNATURE);
        privateSignature.initSign(kf.generatePrivate(spec));
        byte[] bytes = input.getBytes(ENCODING);
        privateSignature.update(bytes);
        byte[] s = privateSignature.sign();
        return Base64.getEncoder().encodeToString(s);
    }

    private static String getEncryptHeader(String keyPlainText, String publicKeyStr) {
        try {
            byte[] keyByteArr = keyPlainText.getBytes();
            PublicKey key = getPublicKey(publicKeyStr);
            Cipher cipher = Cipher.getInstance(HEADER_ENC_ALGO);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedByte = cipher.doFinal(keyByteArr);
            return Base64.getEncoder().encodeToString(encryptedByte);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    static PublicKey  getPublicKey(String publicKeyStr) {

        PublicKey publicKey = null;
        try {
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            BufferedReader br = new BufferedReader(new StringReader(publicKeyStr));
            String line = null;
            StringBuilder keyBuffer = new StringBuilder();

            while ((line = br.readLine()) != null) {
                if (!line.startsWith("-")) {
                    keyBuffer.append(line);
                }
            }
            Certificate certificate = certificateFactory
                    .generateCertificate(new ByteArrayInputStream(Base64.getDecoder().decode(keyBuffer.toString())));
            publicKey = certificate.getPublicKey();
        } catch (Exception var8) {
            var8.printStackTrace();
        }
        return publicKey;
    }
//    public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException, NoSuchProviderException {
//		EncryptionUtil enc=new EncryptionUtil();
//		String request="{\"urn\":\"string\",\"customerDetails\":{\"dob\":\"2022-02-01 00:00:00\",\"gender\":1,\"accountHolderName\":\"Ravi Thummar\",\"firstName\":\"Ravi\",\"middleName\":\"V\",\"lastName\":\"Thummar\",\"mobileNumber\":\"9104661798\",\"addressLine1\":\"b - 501\",\"addressLine2\":\"marutishow room\",\"pincode\":\"205468\",\"city\":\"Ahmedabad\",\"cityLGDCode\":0,\"district\":\"test\",\"districtLGDCode\":0,\"state\":\"test\",\"stateLGDCode\":0,\"accountNumber\":\"123\",\"cif\":\"9809806\"},\"kycDetails\":{\"kycId1\":\"test\",\"kycIdValue1\":\"test\",\"kycId2\":\"test\",\"kycIdValue2\":\"test\",\"panNumber\":\"test\",\"aadhaarNumber\":\"test\"},\"guardianDetails\":{\"relationShip\":\"Brother\",\"firstName\":\"Ravi\",\"middleName\":\"test\",\"lastName\":\"Thummar\",\"dob\":\"string\",\"pan\":\"HTMPT4586T\",\"aadhaar\":\"test\",\"address\":\"test\",\"pincode\":\"500154\",\"mobile\":\"65656546\",\"email\":\"test@gmail.com\",\"state\":\"gujarat\",\"city\":\"Ahmedabad\",\"district\":\"string\"},\"nomineeDetails\":{\"relationShip\":\"Brother\",\"firstName\":\"Jenish\",\"middleName\":\"V\",\"lastName\":\"Patel\",\"dob\":\"string\",\"pan\":\"BHTDT8674T\",\"aadhaar\":\"test\",\"address\":\"test\",\"pincode\":\"767868\",\"mobile\":\"0980980980\",\"email\":\"test@opl.com\",\"state\":\"gujarat\",\"city\":\"Ahmedabad\",\"district\":\"ahmedabad\"},\"insurerDetails\":[{\"year\":\"testyear\",\"code\":\"testcode\",\"accountNumber\":\"12345\",\"ifsc\":\"barb0bapuna\"},{\"year\":\"2022\",\"code\":\"fkngdfl\",\"accountNumber\":\"12345\",\"ifsc\":\"barb0bapuna\"},{\"year\":\"2018\",\"code\":\"hgfdfd\",\"accountNumber\":\"12345\",\"ifsc\":\"barb0bapuna\"}],\"policyDetails\":{\"transactionUTR\":\"6565465465\",\"scheme\":\"PMJJBY\",\"dateOfAutoDebit\":\"test\",\"transactionTimeStamp\":\"test\",\"transactionAmount\":0,\"masterPolicyNumber\":\"987654321\",\"dateOfEnrollment\":\"klmgdl\",\"bankCode\":\"test\",\"branchCode\":\"ravi\",\"branchIFSC\":\"barb0bapuna\",\"consentForAutoDebit\":\"test\"}}";
//		String encrypt=null;
//
//
//        encrypt=enc.encrypt(request, OPL_PRIVATE_KEY, OPL_PUBLIC_KEY);
//
//        System.out.println(" ====> Encrypted Text --> "+encrypt);
//    	System.out.println("Done");
//
//	}

}
