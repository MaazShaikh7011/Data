package com.opl.jns.registry.service.utils.v3;

import com.opl.jns.registry.service.domain.WeekMaster;
import com.opl.jns.registry.service.repository.MisEnrlDataRepo;
import com.opl.jns.registry.service.repository.WeekMasterRepository;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component("MisEnrolDataScheduler")
@Slf4j
public class MisEnrolDataScheduler {

    @Autowired
    private MisEnrlDataRepo misEnrlDataRepo;

    @Autowired
    private MisAsyncComponent misAsyncComponent;

    @Autowired
    private WeekMasterRepository weekMasterRepository;

    @Autowired
    private MisClaimAsyncComponent misClaimAsyncComponent;

    @Value("${com.opl.service.registry.jns.cron.mis.enrol.scheduler.start}")
    private String start;


    @Scheduled(cron = "${com.opl.service.registry.jns.cron.mis.prepare.data}")
    private void prepareMisData() {
        log.info("prepareMisData() scheduler called ------------> ");

        if (!"ON".equalsIgnoreCase(start)) {
            log.info("com.opl.service.registry.jns.cron.mis.enrol.scheduler.start is not set as 'ON'");
            return;
        }
        try {
            misAsyncComponent.addNewRowInWeekMaster();

            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);
            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }

            weekMaster.setStatus(WeekMaster.StatusEnum.COMPLETED);
            weekMasterRepository.save(weekMaster);
            weekMasterRepository.updateStuts(weekMaster.getId() + 1);

            log.info("Calling misAsyncComponent.prepareDataForMis() ");
            misAsyncComponent.prepareDataForMis(TransactionTypeEnum.ENROLLMENT.getId(), weekMaster);

            log.info("Calling misClaimAsyncComponent.prepareDataForMis() ");
            misClaimAsyncComponent.prepareDataForMis(weekMaster);
        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ");
        }
    }

    /*
    * GET ALL DATA BASED ON VERSION
    * GENERATE EXCEL
    * UPLOAD IT ON BUCKET USING DMS SERVICE
    * SAVE STORAGE-ID
    * */
    @Scheduled(cron = "${com.opl.service.registry.jns.cron.mis.enrol}")
    private void uploadMISEnrolData() {

        log.info("uploadMISEnrolData() scheduler called ------------> ");

        if (!"ON".equalsIgnoreCase(start)) {
            log.info("com.opl.service.registry.jns.cron.mis.enrol.scheduler.start is not set as 'ON'");
            return;
        }

//        GETTING WEEK MASTER OBJ WITH IN_PROGRESS STATUS
        try {
            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);

            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }

            log.info("Calling misAsyncComponent.uploadExcelInDms() ");
            misAsyncComponent.uploadExcelInDms(TransactionTypeEnum.ENROLLMENT.getId(), weekMaster.getId() - 1);

            log.info("Calling misClaimAsyncComponent.uploadExcelInDms() ");
            misClaimAsyncComponent.uploadExcelInDms(weekMaster.getId() - 1);
        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ");
        }

    }

    /*
    * CALLING uploadMISEnrolDataByType() SCHEDULAR BY API ONLY
    * */
    public void uploadMISEnrolDataByType(Long typeId) {
        log.info("uploadMISEnrolDataByType() scheduler called ------------> ");
        try {
            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);

            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }
            misAsyncComponent.uploadExcelInDms(typeId.intValue(), weekMaster.getId() - 1);

        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ");
        }
    }

    /*
     * CALLING prepareMisData() SCHEDULAR BY API ONLY
     * */
    public void prepareDataByType(Long type) {
        log.info("In prepareMisDataByType() ------------> ");
        try {
            misAsyncComponent.addNewRowInWeekMaster();

            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);
            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }

            weekMaster.setStatus(WeekMaster.StatusEnum.COMPLETED);
            weekMasterRepository.save(weekMaster);
            weekMasterRepository.updateStuts(weekMaster.getId() + 1);

            log.info("Calling misAsyncComponent.prepareDataForMis() ");
            misAsyncComponent.prepareDataForMis(type.intValue(), weekMaster);

        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ", e);
        }
    }

    /*
     * CALLING prepareClaimData() SCHEDULAR BY API ONLY
     * */
    public void prepareClaimData() {
        log.info("In prepareClaimData() ------------> ");
        try {

            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);
            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }

            misClaimAsyncComponent.prepareDataForMis(weekMaster);

        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ", e);
        }
    }

    /*
     * CALLING uploadMISClaimData() SCHEDULAR BY API ONLY
     * */
    public void uploadMISClaimData() {
        log.info("uploadMISClaimData() scheduler called ------------> ");
        try {
            log.info("Getting current version by status in-progress -----------> ");
            WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);

            if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                log.info("Week Master Object is null for status in-progress.");
                return;
            }
            misClaimAsyncComponent.uploadExcelInDms(weekMaster.getId() - 1);
        } catch (Exception e) {
            log.error("Exception in uploadMISEnrolData() -----> ");
        }
    }
}
