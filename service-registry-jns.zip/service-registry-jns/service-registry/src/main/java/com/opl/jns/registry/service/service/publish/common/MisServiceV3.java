package com.opl.jns.registry.service.service.publish.common;

import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.utils.common.CommonResponse;

public interface MisServiceV3 {
    public <T extends RegistryReqProxy, U extends APIResponseV3> U misEnrollmentDetails(T in);

    CommonResponse getDistrictWiseData(Long counter, Long startsFrom, String type);
}
