package com.opl.jns.registry.service.service.publish.common.impl;

import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.published.lib.domain.UserOrganizationMaster;
import com.opl.jns.published.lib.repository.UserOrganizationMasterRepository;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.lib.utils.ConfigType;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.registry.service.service.publish.common.ValidationService;
import com.opl.jns.utils.enums.SchemeMaster;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class ValidationServiceImpl implements ValidationService {

	@Autowired
	EreCommonService ereCommonService;

	@Autowired
	ClmMasterRepository clmMasterRepository;

	@Autowired
	UserOrganizationMasterRepository organizationMasterRepo;

	@Autowired
	PmsbyRepository pmsbyRepository;

	@Autowired
	PmjjbyRepository pmjjbyRepository;
	
	@Override
	public Map<String, Object> isValidUser(HttpServletRequest request, String urn, Long claimRefId) throws IOException {
		// check skip
		Map<String, Object> map = checkForSkipHeader(request);

		Long applicationId = null;
		if (request.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID) != null
				&& request.getAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID) != null) {
			Long appOrgId = null;
			Long userOrgId = Long.valueOf(request.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID).toString());
			UserOrganizationMaster orgMst = organizationMasterRepo.findByOrgIdAndIsActiveIsTrue(userOrgId);
			if (!OPLUtils.isObjectNullOrEmpty(orgMst)) {
				ApplicationMasterBothSchemeProxy master = null;
				Long orgId = null;
				Long insurerOrgId = null;
				if (OPLUtils.isObjectNullOrEmpty(claimRefId)) {
					String[] urnStr = urn.split("-");
					/**GET APPLICATION ID*/
					applicationId = Long.valueOf(urnStr[4]);
					/**GET SCHEME ID*/
					Long schemeId = SchemeMaster.getByCode(urnStr[1]).getId();
					master = getApplicationMasterForEnrollment(applicationId, schemeId, orgMst, master);
					if(!OPLUtils.isObjectNullOrEmpty(master)) {						
						orgId = master.getOrgId();
						insurerOrgId = master.getInsurerOrgId();
					}
				} else {
					ClmMaster clmMaster = null;
					clmMaster = getClaimMasterForClaim(claimRefId, userOrgId, orgMst, clmMaster);
					if(!OPLUtils.isObjectNullOrEmpty(clmMaster)) {						
						orgId = clmMaster.getOrgId();
						insurerOrgId = clmMaster.getInsurerOrgId();
					}
				}
				if (orgMst.getOrgType().equals(CommonUtils.ORG_TYPE_INSURER)) {
					appOrgId = getInsurerOrgIdEnrollment(insurerOrgId);
				} else if (orgMst.getOrgType().equals(CommonUtils.ORG_TYPE_BANK)) {
					appOrgId = getBankOrgIdEnrollment(orgId);
				}

				if (!OPLUtils.isObjectNullOrEmpty(master)) {
					map.put("applicationId", master.getId());
				}
				map.put("claimRefId", claimRefId);
			}

			if (OPLUtils.isObjectNullOrEmpty(appOrgId)) {
				log.error("Org id not found for " + userOrgId + " in proposal details");
				map.put(Constants.STATUS, Boolean.FALSE);
				return map;
			}
			if (!userOrgId.equals(appOrgId)) {
				log.error("Invalid org id userOrgId=" + userOrgId + " requestApplicationOrgId=" + appOrgId);
				map.put(Constants.STATUS, Boolean.FALSE);
				return map;
			}

			map.put("applicationRefId", applicationId);
			map.put(Constants.STATUS, Boolean.TRUE);
			return map;
		}
		log.error("Org id not found for application reference Id: [{}]", applicationId);
		map.put(Constants.STATUS, Boolean.FALSE);
		return map;
	}

	private static Map<String, Object> checkForSkipHeader(HttpServletRequest request) {
		Map<String, Object> map = new HashMap<>();
		String skipEnc = request.getHeader(APIAuthUtils.REQ_HEADER_ENCRYPTION_SKIP);
		if (skipEnc != null && skipEnc.equals("true")) {
			map.put(Constants.STATUS, Boolean.TRUE);
		}
		return map;
	}

	private ClmMaster getClaimMasterForClaim(Long claimRefId, Long userOrgId, UserOrganizationMaster orgMst,
			ClmMaster clmMaster) {
		if (Objects.equals(orgMst.getOrgType(), CommonUtils.ORG_TYPE_BANK)) { // 1 - bank
			clmMaster = clmMasterRepository.findByIdAndOrgIdAndIsActiveTrue(claimRefId, userOrgId);
		} else if (Objects.equals(orgMst.getOrgType(), CommonUtils.ORG_TYPE_INSURER)) { // 3 - insurer
			clmMaster = clmMasterRepository.findByIdAndInsurerOrgIdAndIsActiveTrue(claimRefId, userOrgId);
		}
		return clmMaster;
	}

	private ApplicationMasterBothSchemeProxy getApplicationMasterForEnrollment(Long applicationRefId, Long schemeId,UserOrganizationMaster orgMst, ApplicationMasterBothSchemeProxy master) throws IOException {
		if (orgMst.getOrgType() == ConfigType.BANK_CONFIG.getConfigType()) { // 1 - bank
			master = ereCommonService.getJnsMasterDataApplicationMaster(applicationRefId, schemeId);
		}
		return master;
	}

	private Long getBankOrgIdEnrollment(Long orgId) {
		if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
			return orgId;
		}
		return null;
	}

	private Long getInsurerOrgIdEnrollment(Long insurerOrgId) {
		if (!OPLUtils.isObjectNullOrEmpty(insurerOrgId)) {
			return insurerOrgId;
		}
		return null;
	}

}
