package com.opl.jns.registry.service.domain;

import com.opl.jns.published.lib.utils.AESEncryption;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * @author ravi.thummar Date : 15-06-2023
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_master",catalog = DBNameConstant.JNS_PUBLISH_API,schema = DBNameConstant.JNS_PUBLISH_API)
public class PUBApplicationMaster extends PUBAuditor {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_application_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_application_master_seq_gen", sequenceName = "pub_application_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "urn", nullable = true)
	private String urn;

	@Column(name = "scheme_id", nullable = true)
	private Integer schemeId;

	@Column(name = "scheme_name", nullable = true)
	private String schemeName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "account_number", nullable = true)
	private String accountNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "cif", nullable = true)
	private String cif;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "org_name", nullable = true)
	private String orgName;
	@Column(name = "org_code", nullable = true)
	private String orgCode;

	@Column(name = "user_id", nullable = true)
	private Long userId;

	@Column(name = "branch_id", nullable = true)
	private Long branchId;

	@Column(name = "branch_name", nullable = true)
	private String branchName;

	@Column(name = "enrollment_date", nullable = true)
	private String enrollmentDate;
	
	@Column(name = "completion_date", nullable = true)
	private Date completionDate;

	@Column(name = "premium_amount", nullable = true)
	private Double premiumAmount;

	@Column(name = "application_status", nullable = true)
	private Integer applicationStatus;

	@Column(name = "message", nullable = true)
	private String message;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Column(name = "insurer_org_name", nullable = true)
	private String insurerOrgName;

	@Column(name = "insurer_org_code", nullable = true)
	private String insurerOrgCode;

	@Column(name = "amount", nullable = true)
	private Double amount;

	@Column(name = "push_ready_date", nullable = true)
	private Date pushReadyDate;

	public PUBApplicationMaster(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
