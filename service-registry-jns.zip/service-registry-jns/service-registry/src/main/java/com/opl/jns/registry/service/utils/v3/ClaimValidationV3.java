package com.opl.jns.registry.service.utils.v3;

import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.ere.enums.*;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.utils.common.PatternUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class ClaimValidationV3 {

	public static final long LONG_30Days = 30L;

	public static boolean isInValidateDate(LocalDateTime dateStr, String dateFormat) {
		try {
			Date parse = Date.from(dateStr.atZone(ZoneId.systemDefault()).toInstant());
			return null != parse ? Boolean.FALSE : Boolean.TRUE;
		} catch (Exception e) {
			return Boolean.TRUE;
		}
	}
	
	public static boolean isFutureDate(Date date) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(date)) {
				if (date.after(new Date())) {
					return Boolean.TRUE;
				}
			}
			return Boolean.FALSE;
		} catch (Exception e) {
			return Boolean.FALSE;
		}
	}

	public static StringBuilder checkMandatoryFieldsOfBothScheme(ClaimDetailsReqProxyV3 claimDetails, int schemeId,
			Date enrollmentDate, StringBuilder s1) {
//		StringBuilder s1 = new StringBuilder();
		if (schemeId == SchemeMaster.PMJJBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfDeath())) {
				log.warn("dateOfDeath can not be null or empty.");
				s1.append("dateOfDeath can not be null or empty.");
			} else {
				boolean isInValidDateOfDeath = isInValidateDate(claimDetails.getDateOfDeath(),
						com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
				if (isInValidDateOfDeath) {
					s1.append("Invalid Date Format for Date Of Death(yyyy-MM-dd HH:mm:ss).");
				}
				
				boolean isFutureDateOfDeath = isFutureDate(Date.from(claimDetails.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant()));
				if (isFutureDateOfDeath) {
					s1.append("dateOfDeath future date not allowed.");
				}
				
			}
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeath())) {
				log.warn("causeOfDeath can not be null or empty.");
				s1.append("causeOfDeath can not be null or empty.");
			} else {
				CauseOfDeathDisabilityV2 disability = CauseOfDeathDisabilityV2
						.fromBankValue(claimDetails.getCauseOfDeath());
				if (!OPLUtils.isObjectNullOrEmpty(disability)) {
//					if (!disability.getValue().equalsIgnoreCase(CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue()) && !disability
//							.getValue().equalsIgnoreCase(CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getValue())) {
//						log.warn("Invalid Cause Of Death (Death|Accidental death within 30 days of lien period).");
//						s1.append("Invalid Cause Of Death (Death|Accidental death within 30 days of lien period).");
//					}

					Date dateOfDeath = Date
							.from(claimDetails.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant());
					long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
					// death case - check days with enroll datediff - 30 day
					if (claimDetails.getCauseOfDeath().equals(CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getValue())) {
						if (dateDiff > LONG_30Days) {
							s1.append("The death not in lian period");
						}
					}else if (claimDetails.getCauseOfDeath().equals(CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue())){
						if (dateDiff < LONG_30Days) {
							s1.append("Cannot register Natural death/Non accidental within 30 days of lien period");
						}	
					}else if (claimDetails.getCauseOfDeath().equals(CauseOfDeathDisabilityV2.SUICIDE.getValue())){
						if (dateDiff < LONG_30Days) {
							s1.append("Cannot register Suicide within 30 days of lien period");
						}	
					}
				}
			}
		} else if (schemeId == SchemeMaster.PMSBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDayOfAccident())) {
				log.warn("dayOfAccident can not be null or empty.");
				s1.append("dayOfAccident can not be null or empty.");
			}
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getPlaceOfOccurence())) {
				log.warn("placeOfOccurence can not be null or empty.");
				s1.append("placeOfOccurence can not be null or empty.");
			}
			// Nature of accident
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNatureOfAccident())) {
				log.warn("natureOfAccident can not be null or empty.");
				s1.append("natureOfAccident can not be null or empty.");
			} else {
				NatureOfLoss natureOfLoss = NatureOfLoss.fromBankValue(claimDetails.getNatureOfAccident());
				if (OPLUtils.isObjectNullOrEmpty(natureOfLoss)) {
					log.warn("Nature Of Loss can be either (Disability|Death).");
					s1.append("Nature Of Loss can be either (Disability|Death).");
				} else {
					if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTypeOfDisability())) {
							log.warn("Type Of Disability can not be null or empty.");
							s1.append("Type Of Disability can not be null or empty.");
						} else {
							TypeOfDisability typeOfDisability = TypeOfDisability
									.fromBankValue(claimDetails.getTypeOfDisability());
							if (OPLUtils.isObjectNullOrEmpty(typeOfDisability)) {
								log.warn("Invalid TypeOfDisability (Partial permanent|Total permanent).");
								s1.append("Invalid TypeOfDisability (Partial permanent|Total permanent).");
							}
						}
					} else if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DEATH.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfDeath())) {
							log.warn("dateOfDeath can not be null or empty.");
							s1.append("dateOfDeath can not be null or empty.");
						} else {
							boolean isInValidDateOfDeath = isInValidateDate(claimDetails.getDateOfDeath(),
									com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
							if (isInValidDateOfDeath) {
								s1.append("Invalid Date Format for Date Of Death(yyyy-MM-dd HH:mm:ss).");
							} else {
								// death case - check days with enroll datediff
								Date dateOfDeath = Date
										.from(claimDetails.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant());
								long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
								if (dateDiff < 0) {
									s1.append("The death date must precede the enrollment date.");
								}
							}
						}
					}
				}
			}

			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
				log.warn("timeOfAccident can not be null or empty.");
				s1.append("timeOfAccident can not be null or empty.");
			}

			// cause of disability
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeathDisability())) {
				log.warn("causeOfDeathDisability can not be null or empty.");
				s1.append("causeOfDeathDisability can not be null or empty.");
			} 
//			else {
//				CauseOfDeathDisabilityV2 disability = CauseOfDeathDisabilityV2
//						.fromBankValue(claimDetails.getCauseOfDeathDisability());
//				if (OPLUtils.isObjectNullOrEmpty(disability)) {
//					log.warn("Invalid Cause Of Death Disability (Accidental).");
//					s1.append("Invalid Cause Of Death Disability (Accidental).");
//				} else if (!disability.getValue().equalsIgnoreCase(CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue())) {
//					log.warn("Invalid Cause Of Death Disability (Accidental).");
//					s1.append("Invalid Cause Of Death Disability (Accidental).");
//				}
//			}

			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfAccident())) {
				log.warn("dateOfAccident can not be null or empty.");
				s1.append("dateOfAccident can not be null or empty.");
			} else {
				
				boolean isFutureDateOfAccident = isFutureDate(Date.from(claimDetails.getDateOfAccident().atStartOfDay(ZoneId.systemDefault()).toInstant()));
				if (isFutureDateOfAccident) {
					s1.append("dateOfAccident future date not allowed.");
				}
				
				// merge here dateOfAccident and timeOfAccident for parsing - yyyy-MM-dd
				// HH:mm:ss
				if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
					claimDetails.setDateOfAccident(claimDetails.getDateOfAccident());
				}
				/* date validations in case dates are not null */
//				boolean isInValidDateOfAccident = isInValidateDate(claimDetails.getDateOfAccident(),
//						com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
//				if (isInValidDateOfAccident) {
//					s1.append("dateOfAccident can not be null or empty.");
//				}
			}
		}
		return s1;
	}
	
	public static StringBuilder checkMandatoryFieldsOfBothSchemeCommon(ClaimDetailsReqProxyV3 claimDetails, int schemeId,
			StringBuilder s1) {
		 if (schemeId == SchemeMaster.PMSBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDayOfAccident())) {
				log.warn("dayOfAccident can not be null or empty.");
				s1.append("dayOfAccident can not be null or empty.");
			}
			// Nature of accident
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNatureOfAccident())) {
				log.warn("natureOfAccident can not be null or empty.");
				s1.append("natureOfAccident can not be null or empty.");
			} else {
				NatureOfLoss natureOfLoss = NatureOfLoss.fromBankValue(claimDetails.getNatureOfAccident());
				if (OPLUtils.isObjectNullOrEmpty(natureOfLoss)) {
					log.warn("Nature Of Accident can be either (Disability|Death).");
					s1.append("Nature Of Accident can be either (Disability|Death).");
				} else {
					if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTypeOfDisability())) {
							log.warn("Type Of Disability can not be null or empty.");
							s1.append("Type Of Disability can not be null or empty.");
						} else {
							TypeOfDisability typeOfDisability = TypeOfDisability
									.fromBankValue(claimDetails.getTypeOfDisability());
							if (OPLUtils.isObjectNullOrEmpty(typeOfDisability)) {
								log.warn("Invalid TypeOfDisability (Partial permanent|Total permanent).");
								s1.append("Invalid TypeOfDisability (Partial permanent|Total permanent).");
							}
						}
				}
			}

//			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
//				log.warn("timeOfAccident can not be null or empty.");
//				s1.append("timeOfAccident can not be null or empty.");
//			}

			}
		}
		return s1;
	}

	public static StringBuilder kycIdValidOrNot(String kycId, String kycIdName) {
		if (!kycId.equalsIgnoreCase(KycDocument.PAN.getKey()) && !kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			return new StringBuilder(kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA");
		}
		return null;
	}

	public static StringBuilder kycIdValidation(String kycId, String kycIdValue, StringBuilder builder,
			String kycIdName) {
		if (!OPLUtils.isObjectNullOrEmpty(kycId)) {
			StringBuilder sb1 = kycIdValidOrNot(kycId, kycIdName);
			if (!OPLUtils.isObjectNullOrEmpty(sb1)) {
				return builder.append(sb1);
			}
			if (!OPLUtils.isObjectNullOrEmpty(kycIdValue) && !kycIdValue.equalsIgnoreCase(RegistryUtils.AADHAR)) {
				com.opl.jns.utils.common.CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(kycId, kycIdValue,
						kycIdName);
				if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
					return builder.append(commonResponsekycNo.getMessage());
				}
			}
		}
		return builder;
	}

	public static com.opl.jns.utils.common.CommonResponse kycIdNumberValidOrNot(String kycId, String kycIdNumber,
			String kycIdName) {
		if (kycId.equalsIgnoreCase(KycDocument.PAN.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PAN_PATTERN);
			java.util.regex.Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid pan number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.AADHAR_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid aadhar number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PASSPORT_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid passport number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.VOTERS_ID_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid voter id number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.DRIVING_LICENCE_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid driving licence number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.MGNREGA_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid mgnrega card number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}
		return null;
	}

	public static Boolean findLength(String key, Long min, Long max) {
		if (key.length() < min || key.length() > max) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public static ClaimDetailsResProxyV3 checkClaimDetailsValidationsV3(ClaimDetailsReqProxyV3 claimDetails) throws ParseException {
		StringBuilder s1 = new StringBuilder();
		ClaimDetailsResProxyV3 commonResponse = new ClaimDetailsResProxyV3();
		commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
		try {
			if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getIsNomineePredeceased())
					&& claimDetails.getIsNomineePredeceased().equalsIgnoreCase(YesNo.YES.getValue())) {
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantDateOfBirth())) {
					s1.append("claimantDateOfBirth can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantMobileNumber())) {
					s1.append("claimantMobileNumber can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantName())) {
					s1.append("claimantName can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getRelationshipOfClaimant())) {
					s1.append("relationshipOfClaimant can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantAddress())) {
					s1.append("claimantAddress can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantGender())) {
					s1.append("claimantGender can not be null or empty.");
				}
			}else if(!OPLUtils.isObjectNullOrEmpty(claimDetails.getIsNomineePredeceased())
					&& claimDetails.getIsNomineePredeceased().equalsIgnoreCase(YesNo.NO.getValue())){
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeMobileNumber())) {
					s1.append("NomineeMobileNumber can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeName())) {
					s1.append("NomineeName can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeDateOfBirth())) {
					s1.append("NomineeDateOfBirth can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getAddressOfNominee())) {
					s1.append("AddressOfNominee can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getRelationshipOfNominee())) {
					s1.append("RelationshipOfNominee can not be null or empty.");
				}
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeGender())) {
					s1.append("nomineeGender can not be null or empty.");
				}
				
				
				// Age validation for nominee
					Integer ageFromBirthDate = DateUtils
							.getAgeFromBirthDate(Date.from(claimDetails.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()));
					if (ageFromBirthDate < 18) {
						log.warn("age is less then 18 so guardian details is mandatory   AGE -> ({}),  YEAR -> ({})",
								claimDetails.getNomineeDateOfBirth(), ageFromBirthDate);
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getGuardianMobileNumber())) {
							log.warn("guardianMobileNumber can not be null or empty.");
							s1.append("guardianMobileNumber can not be null or empty.");
						}
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNameofGuardian())) {
							log.warn("NameofGuardian can not be null or empty.");
							s1.append("NameofGuardian can not be null or empty.");
						}
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getAddressofGuardian())) {
							log.warn("AddressofGuardian can not be null or empty.");
							s1.append("AddressofGuardian can not be null or empty.");
						}
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getRelationShipOfGuardian())) {
							log.warn("RelationShipOfGuardian can not be null or empty.");
							s1.append("RelationShipOfGuardian can not be null or empty.");
						}
					}
				}
			
			if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeNameCorrection())
					&& claimDetails.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCorrectNomineeName())) {
					s1.append("correctNomineeName can not be null or empty.");
				}
			}
			
		} catch (Exception e) {
			log.warn("Exception while validation for claim details", e);
		}

		commonResponse.setSuccess(OPLUtils.isObjectNullOrEmpty(s1.toString()));
		commonResponse.setMessage(!OPLUtils.isObjectNullOrEmpty(s1.toString()) ? s1.toString() : null);
		return commonResponse;
	}
}
