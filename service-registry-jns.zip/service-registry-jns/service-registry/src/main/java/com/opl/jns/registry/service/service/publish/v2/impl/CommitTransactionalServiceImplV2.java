package com.opl.jns.registry.service.service.publish.v2.impl;

import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.registry.service.service.publish.v2.CommitTransactionalServiceV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author sandip.bhetariya
 *
 */
@Service
@Slf4j
@Transactional
public class CommitTransactionalServiceImplV2 implements CommitTransactionalServiceV2 {
	
	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Override
	public ApplicationMasterV3 applicationMasterSave(ApplicationMasterV3 applicationMaster) throws Exception {
		log.info("Saving ApplicationMasterV3");
		return applicationMasterRepository.save(applicationMaster);
	}
	
	
}
