package com.opl.jns.registry.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "mis_enrl_data", catalog = DBNameConstant.JNS_REPORTS, schema = DBNameConstant.JNS_REPORTS, indexes = {
        @Index(columnList = "type", name = DBNameConstant.JNS_REPORTS + "_type_idx"),
        @Index(columnList = "type, org_id", name = DBNameConstant.JNS_REPORTS + "_type_org_id_idx"),
        @Index(columnList = "type, org_id, scheme_id", name = DBNameConstant.JNS_REPORTS + "_type_org_id_scheme_id_idx")
})
@DynamicUpdate
public class MisEnrlData {

    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "mis_enrl_data_seq_gen")
    @GenericGenerator(name = "mis_enrl_data_seq_gen", strategy = "increment", parameters = {@org.hibernate.annotations.Parameter(name = "schema", value = DBNameConstant.JNS_REPORTS)})
//    @SequenceGenerator(schema = DBNameConstant.JNS_REPORTS, name = "mis_enrl_data_seq_gen", sequenceName = "mis_enrl_data_seq_gen", allocationSize = 1)

    private Long id;

    @Column(name = "type", nullable = false, columnDefinition = "varchar(10) default ''")
    private Integer type;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "org_id", nullable = false)
    private Long orgId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @Column(name = "scheme_id", nullable = false)
    private Integer schemeId;

    @Column(name = "scheme_name", nullable = false, columnDefinition = "varchar(20) default ''")
    private String schemeName;

    @Column(name = "state_name", nullable = false, columnDefinition = "varchar(255) default ''")
    private String stateName;

    @Column(name = "lgd_state_code", nullable = false, columnDefinition = "varchar(5) default ''")
    private String lgdStateCode;

    @Column(name = "district_name", nullable = false, columnDefinition = "varchar(255) default ''")
    private String districtName;

    @Column(name = "lgd_district_code", nullable = false, columnDefinition = "varchar(10) default ''")
    private String lgdDistrictCode;

    @Column(name = "insurer_name", nullable = false, columnDefinition = "varchar(255) default ''")
    private String insurerName;

    @Column(name = "insurer_code", nullable = false, columnDefinition = "varchar(20) default ''")
    private String insurerCode;

    @Column(name = "bank_name", nullable = false, columnDefinition = "varchar(100) default ''")
    private String bankName;

    @Column(name = "bank_short_name", nullable = false, columnDefinition = "varchar(20) default ''")
    private String bankShortName;

    @Column(name = "bank_code", nullable = false, columnDefinition = "varchar(20) default ''")
    private String bankCode;

    @Column(name = "bank_category", nullable = false, columnDefinition = "varchar(10) default ''")
    private String bankCategory;

    @Column(name = "elg_savg_acc_hldr", nullable = false, columnDefinition = "number(19) default 0")
    private Long elgSvngAccHldr;

    @Column(name = "elg_pmjdy_hldr", nullable = false, columnDefinition = "number(19) default 0")
    private Long elgPMJDYHldr;

    @Column(name = "rural_male", nullable = false, columnDefinition = "number(19) default 0")
    private Long ruralMale;

    @Column(name = "rural_female", nullable = false, columnDefinition = "number(19) default 0")
    private Long ruralFemale;

    @Column(name = "rural_trans_g", nullable = false, columnDefinition = "number(19) default 0")
    private Long ruralTransG;

    @Column(name = "urban_male", nullable = false, columnDefinition = "number(19) default 0")
    private Long urbanMale;

    @Column(name = "urban_female", nullable = false, columnDefinition = "number(19) default 0")
    private Long urbanFemale;

    @Column(name = "urban_trans_g", nullable = false, columnDefinition = "number(19) default 0")
    private Long urbanTransG;

    @Column(name = "total_enrollment", nullable = false, columnDefinition = "number(19) default 0")
    private Long totalEnrolment;

    @Column(name = "prm_clctd_rural_male", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdruralMale;

    @Column(name = "prm_clctd_rural_female", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdruralFemale;

    @Column(name = "prm_clctd_rural_trans_g", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdruralTransG;

    @Column(name = "prm_clctd_urban_male", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdurbanMale;

    @Column(name = "prm_clctd_urban_female", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdurbanFemale;

    @Column(name = "prm_clctd_urban_trans_g", nullable = false, columnDefinition = "number(19) default 0")
    private Long prmclctdurbanTransG;

    @Column(name = "total_prm_clctd_nw_enrollment", nullable = false, columnDefinition = "number(19) default 0")
    private Long totalPrmclctdNwErollment;

    @Column(name = "records_transmitted_to_insurer", nullable = false, columnDefinition = "number(19) default 0")
    private Long recordsTransmittedToInsurer;

    @Column(name = "premium_paid_to_insurer", nullable = false, columnDefinition = "number(19) default 0")
    private Long premiumPaidToInsurer;

    @Column(name = "aadhar_seeded", nullable = false, columnDefinition = "number(19) default 0")
    private Long aadharSeeded;

    @Column(name = "mobile_seeded", nullable = false, columnDefinition = "number(19) default 0")
    private Long mobileSeeded;

    @Column(name = "email_seeded", nullable = false, columnDefinition = "number(19) default 0")
    private Long emailSeeded;

    @Column(name = "pmjdy_enrolled", nullable = false, columnDefinition = "number(19) default 0")
    private Long pmjdyEnrolled;

    @Column(name = "mgnrega_enrolled", nullable = false, columnDefinition = "number(19) default 0")
    private Long mgnregaEnrolled;

    @Column(name = "mudra_enrolled", nullable = false, columnDefinition = "number(19) default 0")
    private Long mudraEnrolled;

    @Column(name = "kcc_enrolled", nullable = false, columnDefinition = "number(19) default 0")
    private Long kccEnrolled;

    @Column(name = "other_scheme_enrolled", nullable = false, columnDefinition = "number(19) default 0")
    private Long otherSchemeEnrolled;

    @Column(name = "insufficient_ac_holders", columnDefinition = "number(19) default 0")
    private Long insufficientAcHolders;

    @Column(name = "cast_sc", nullable = false, columnDefinition = "number(19) default 0")
    private Long castSc;

    @Column(name = "cast_st", nullable = false, columnDefinition = "number(19) default 0")
    private Long castSt;

    @Column(name = "cast_general", nullable = false, columnDefinition = "number(19) default 0")
    private Long castGeneral;

    @Column(name = "cast_obc", nullable = false, columnDefinition = "number(19) default 0")
    private Long castObc;

    @Column(name = "nominee_avlb", nullable = false, columnDefinition = "number(19) default 0")
    private Long nomineeAvlb;

    @Column(name = "token", nullable = false, columnDefinition = "varchar(100) default ''")
    private String token;

    @Column(name = "to_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @Column(name = "from_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date fromDate;

    @Column(name = "storage_id", nullable = false, columnDefinition = "number(19) default 0")
    private Long storageId;

    @Column(name = "frsh_enrol_1_june_crrnt_year", nullable = false, columnDefinition = "number(19) default 0")
    private Long frshEnrol1JuneCrrntYear;

    @Column(name = "renewals_1_june_crrnt_year", nullable = false, columnDefinition = "number(19) default 0")
    private Long renewals1JuneCrrntYear;

    @Column(name = "prmdebited_rs", columnDefinition = "number(19) default 0")
    private Long prmdebitedRs;

//    =========================================== ACTIVE ===========================================

    @Column(name = "active_rural_male", columnDefinition = "number(19) default 0")
    private Long activeRuralMale;

    @Column(name = "active_rural_female", columnDefinition = "number(19) default 0")
    private Long activeRuralFemale;

    @Column(name = "active_rural_trans_g", columnDefinition = "number(19) default 0")
    private Long activeRuralTransG;

    @Column(name = "active_urban_male", columnDefinition = "number(19) default 0")
    private Long activeUrbanMale;

    @Column(name = "active_urban_female", columnDefinition = "number(19) default 0")
    private Long activeUrbanFemale;

    @Column(name = "active_urban_trans_g", columnDefinition = "number(19) default 0")
    private Long activeUrbanTransG;

    @Column(name = "active_total_enrollment", columnDefinition = "number(19) default 0")
    private Long activeTotalEnrolment;

    @Column(name = "active_aadhar_seeded", columnDefinition = "number(19) default 0")
    private Long activeAadharSeeded;

    @Column(name = "active_mobile_seeded", columnDefinition = "number(19) default 0")
    private Long activeMobileSeeded;

    @Column(name = "active_email_seeded", columnDefinition = "number(19) default 0")
    private Long activeEmailSeeded;

    @Column(name = "active_cast_sc", columnDefinition = "number(19) default 0")
    private Long activeCastSc;

    @Column(name = "active_cast_st", columnDefinition = "number(19) default 0")
    private Long activeCastSt;

    @Column(name = "active_cast_general", columnDefinition = "number(19) default 0")
    private Long activeCastGeneral;

    @Column(name = "active_cast_obc", columnDefinition = "number(19) default 0")
    private Long activeCastObc;

    @Column(name = "active_pmjdy_enrolled", columnDefinition = "number(19) default 0")
    private Long activePmjdyEnrolled;

    @Column(name = "active_mgnrega_enrolled", columnDefinition = "number(19) default 0")
    private Long activeMgnregaEnrolled;

    @Column(name = "active_mudra_enrolled", columnDefinition = "number(19) default 0")
    private Long activeMudraEnrolled;

    @Column(name = "active_kcc_enrolled", columnDefinition = "number(19) default 0")
    private Long activeKccEnrolled;

    @Column(name = "active_other_scheme_enrolled", columnDefinition = "number(19) default 0")
    private Long activeOtherSchemeEnrolled;

    @Column(name = "version", columnDefinition = "number(19) default 0")
    private Long version;

}
