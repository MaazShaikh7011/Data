package com.opl.jns.registry.service.domain;

import com.opl.jns.published.lib.utils.AESEncryption;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "claim_master", catalog = DBNameConstant.JNS_PUBLISH_API,schema = DBNameConstant.JNS_PUBLISH_API)
public class PUBClaimMaster extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_claim_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_claim_master_seq_gen", sequenceName = "pub_claim_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "claim_id", nullable = true)
	private Long claimId;
	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "application_ref_id", referencedColumnName = "id")
	private PUBApplicationMaster applicationMaster;

	@Column(name = "claim_branch_id", nullable = true)
	private Long claimBranchId;

	@Column(name = "claim_date", nullable = true)
	private Date claimDate;

	@Column(name = "claim_amount", nullable = true)
	private Double claimAmount;

	@Column(name = "claim_status", nullable = true)
	private Integer claimStatus;

	@Column(name = "transaction_utr", nullable = true)
	private String transactionUtr;

    @Convert(converter = AESEncryption.class)
	@Column(name = "date_of_transaction", nullable = true)
	private String dateOfTransaction;

	@Column(name = "amount_of_transaction", nullable = true)
	private Double amountOfTransaction;

	@Column(name = "insurer_claim_id", nullable = true)
	private String insurerClaimId;

	@Column(name = "insurer_status", nullable = true)
	private String insurerStatus;

	@Column(name = "insurer_reason", nullable = true)
	private String insurerReason;

	@Column(name = "status_reason_id", nullable = true)
	private Integer statusReasonId;

	@Column(name = "status_reason", nullable = true)
	private String statusReason;

	@Column(name = "is_claimant_same", nullable = true)
	private Boolean isClaimantSame;

	@Column(name = "claim_branch_name", nullable = true)
	private String claimBranchName;

	@Column(name = "claim_date_str", nullable = true)
	private String claimDateStr;

	@Column(name = "status_reason_name", nullable = true)
	private String statusReasonName;

	@Column(name = "push_ready_date", nullable = true)
	private Date pushReadyDate;

	public PUBClaimMaster(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
