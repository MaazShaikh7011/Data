package com.opl.jns.registry.service.service.publish.common;

import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimDocumentResProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import jakarta.servlet.http.HttpServletRequest;

public interface ClaimService {

	public <T extends RegistryReqProxy, U extends APIResponseV3> U saveClaimApi(T claimRequest, Long orgId) throws Exception;

	public <T extends ClaimUploadDocsReqProxyV3, U extends ClaimDocumentResProxy> U getClaimdetailsByClaimUploadDocuments(T claimUploadDocuments);

	boolean updateClaimStatusInsurerByJsForScheduler(Long claimId);
	
	<T extends RegistryReqProxy, U extends APIResponseV3> U getClaimDedupeData(ClaimDeDupReqProxyV3 dedupeRequest) throws  Exception;
	
	public ClaimStatusUpdateResProxyV3 updateClaimStatus(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, StringBuilder message, HttpServletRequest httpServletRequest);

}
