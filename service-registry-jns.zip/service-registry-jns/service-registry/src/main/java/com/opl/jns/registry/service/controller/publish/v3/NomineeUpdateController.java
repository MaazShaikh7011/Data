package com.opl.jns.registry.service.controller.publish.v3;

import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.api.proxy.jansuraksha.v3.Response400V3;
import com.opl.jns.api.proxy.jansuraksha.v3.Response401;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.service.publish.common.NomineeUpdateService;
import com.opl.jns.registry.service.utils.RegistryUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "4.NomineeUpdate API", description = "API to update Bank/Insurer for Nominee updation from JS portal")
public class NomineeUpdateController {

	@Autowired
	NomineeUpdateService nomineeService;

	@PostMapping(value = "/updateNomineeAPI", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = "11", summary = Constants.NOMINEE_UPDATE_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_NOMINEE_EXAMPLE, description = Constants.UPDATE_NOMIEE_DESC),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = NomieeUpdateResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_NOMINEE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<NomieeUpdateResponse> updateNomineeAPI(@Valid @RequestBody NomineeUpdateRequest nomineeRequest,
			HttpServletRequest httpServletRequest) {
		NomieeUpdateResponse nomineeResponse = new NomieeUpdateResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
				HttpStatus.BAD_REQUEST.value());
		nomineeResponse = RegistryUtils.setTokenAndTimeStempV3(nomineeResponse,
				nomineeRequest.getToken());
		if (OPLUtils.isObjectNullOrEmpty(nomineeRequest)) {
			return new ResponseEntity<>(nomineeResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				nomineeResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), null);
				return new ResponseEntity<>(nomineeResponse, HttpStatus.OK);
			}
			nomineeResponse = nomineeService.updateNominee(nomineeRequest);
			nomineeResponse =  RegistryUtils.setTokenAndTimeStempV3(nomineeResponse,
					nomineeRequest.getToken());
			log.info("<--- Exit From Update Nominee Details  ---> ");
			return new ResponseEntity<>(nomineeResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getNomineeUpdateDetails() {}", e.getMessage());
			nomineeResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(nomineeResponse, HttpStatus.OK);
		}
	}

}
