package com.opl.jns.registry.service.utils;

import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ClmDetailsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DeDupeRegistryAPIClient {

	private static final String IS_MATCHED_Y = "Y";
	private static final String IS_MATCHED_N = "N";

	private static final String IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER = "It seems an error occurred in De-dupe response; please try again later.";

	private static final Integer APPLICATION_STATUS = 2;

	private static final String COMPLETED = "Completed";

	@Autowired
	private DedupeRegistryClient dedupeRegistryClient;

	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 appMstOtherDtlsRepoV3;
	
	@Autowired
	private ApplicationMasterRepositoryV3 appMasterRepo;
	
	@Autowired
	private ClmDetailsRepository clmDetailsRepository;

	/**
	 * DEDUPE CALL FOR PYTHON REGISTRY
	 * 
	 * @param deDupeDetails
	 * @param orgId
	 * @param insurerOrgId
	 * @return
	 */
	/*public DeDupResProxyV2 dedupe(DeDupReqProxyV2 deDupeDetails, Long orgId, Long insurerOrgId) {
		try {
			log.info("ENTER IN CHECKING DE-DUPE APPLICATION -------------->");
			DeDupDataProxyV2 deDupProxy = null;
			DedupApiReqProxy dedupRequest = getCheckDedupeReq(deDupeDetails, orgId, insurerOrgId);
			dedupRequest.setOrgId(orgId);
			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
					.callCheckDedupeRequest(dedupRequest);
			if (!OPLUtils.isObjectNullOrEmptyOrDash(commonResponse.getStatus())
					&& (commonResponse.getStatus() == HttpStatus.OK.value()
							|| commonResponse.getStatus() == HttpStatus.NO_CONTENT.value())) {
				@SuppressWarnings("rawtypes")
				ApiData apiData = MultipleJSONObjectHelper.getObjectFromMap((Map) commonResponse.getData(),
						ApiData.class);
				if (!OPLUtils.isObjectNullOrEmpty(apiData) && !OPLUtils.isObjectNullOrEmpty(apiData.getIsMatched())) {
					//in case duplicate found 
					if (apiData.getIsMatched().equalsIgnoreCase(IS_MATCHED_Y)) {
						deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_Y).matchWith(apiData.getMatchesWith())
								.bankName(apiData.getBankName()).build();
						return new DeDupResProxyV2("Data Found Successfully", deDupProxy, HttpStatus.OK.value(),
								Boolean.TRUE);
					} else {
						// in case duplicate not found 
						deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_N).build();
						return new DeDupResProxyV2("data Not Found", deDupProxy, HttpStatus.NO_CONTENT.value(),
								Boolean.FALSE);
					}
				} else if (commonResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
					return new DeDupResProxyV2(commonResponse.getMessage(), null, HttpStatus.BAD_REQUEST.value(),
							Boolean.TRUE);
				} else {
					log.error("RESPONSE IS NOT VALID FROM DE-DUPE SERVICE");
				}
			} else if (commonResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
				return new DeDupResProxyV2(commonResponse.getMessage(), null, HttpStatus.BAD_REQUEST.value(),
						Boolean.TRUE);
			} else {
				log.error("RESPONSE IS NOT SUCCESS FROM DE-DUPE SERVICE");
				return new DeDupResProxyV2(commonResponse.getMessage(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE CALLING DE-DUPE REGISTRY API -->", e);
		}
		return new DeDupResProxyV2(IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}*/

	/**
	 * PUSH ENROLLMENT DETAILS INTO DE-DUPE REGISTRY
	 * 
	 * @param enrollmentDetails
	 * @param master
	 * @param masterPolicyNumber
	 * @param urnCode
	 * @return
	 */
	/*public boolean pushDeDupeRegistryData(EnrollmentReqProxyV2 enrollmentDetails, ApplicationMasterV3 master,
			String masterPolicyNumber, String urnCode) {
		try {
			log.info("PUSH SINGLE ENROLLMENT IN DE-DUPE REGISTRY --------------------->" + urnCode);
			SingleEnrollmentRequest enrollmentRequest = getSingleEnrollmentReq(enrollmentDetails, master,
					masterPolicyNumber, urnCode);
			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
					.callSingleEnrollmentRequest(enrollmentRequest);
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
					SingleEnrollmentResponse singleEnrollmetResponse = MultipleJSONObjectHelper
							.getObjectFromObject(commonResponse.getData(), SingleEnrollmentResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(singleEnrollmetResponse)
							&& !OPLUtils.isObjectNullOrEmpty(singleEnrollmetResponse.getStatus())
							&& singleEnrollmetResponse.getStatus().equals(HttpStatus.OK.value())) {
						appMstOtherDtlsRepoV3.updateIsDDPushFlag(enrollmentRequest.getApplicationId());
						return true;
					}
				}
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PUSH ENROLLMENT DATA IN DE-DUPE REGISTRY ---->", e);
		}
		return false;
	}*/

	/**
	 * UPDATE STATUS API
	 * 
	 * @param applicationMaster
	 */
	/*public boolean updateStatus(ApplicationMasterV3 applicationMaster) {
		log.info("ENTER IN DE-DUPE REGISTRY UPDATE STATUS API ------------>");
		try {
			UpdateEnrollRequest updateEnrollRequest = getUpdateEnrollmentStatusReq(applicationMaster.getId(),
					applicationMaster.getUrn(), applicationMaster.getEnrollmentDate());
			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
					.callUpdateEnrollmentStatus(updateEnrollRequest);
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
					UpdateEnrollResponse updateEnrollResponse = MultipleJSONObjectHelper
							.getObjectFromObject(commonResponse.getData(), UpdateEnrollResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse)
							&& !OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus())
							&& Objects.equals(updateEnrollResponse.getStatus(), HttpStatus.OK.value())) {
						return true;
					}
				}
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE CALL UPDATE STATUS IN DD-REGISTRY API -->", e);
		}
		return false;
	}*/

	/*private UpdateEnrollRequest getUpdateEnrollmentStatusReq(Long id, String urn, Date enrollmentDate) {
		UpdateEnrollRequest enrollRequest = new UpdateEnrollRequest();
		enrollRequest.setApplicationId(id);
		enrollRequest.setUrn(urn);
		enrollRequest.setStatus(APPLICATION_STATUS);
		enrollRequest.setReason(COMPLETED);
		enrollRequest
				.setDateOfEnrollment(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS, enrollmentDate));
		return enrollRequest;

	}*/

	/*private SingleEnrollmentRequest getSingleEnrollmentReq(EnrollmentReqProxyV2 enrollmentDetails,
			ApplicationMasterV3 master, String masterPolicyNumber, String urnCode) {
		SingleEnrollmentRequest enrollmentRequest = new SingleEnrollmentRequest();
		enrollmentRequest.setApplicationId(master.getId());
		enrollmentRequest.setUrn(urnCode);
		enrollmentRequest.setSource(!OPLUtils.isObjectNullOrEmpty(master.getApplicationMasterOtherDetails().getSource())
				? Source.fromId(master.getApplicationMasterOtherDetails().getSource()).getValue()
				: null);
		enrollmentRequest.setScheme(SchemeMaster.getById(master.getSchemeId().longValue()).getShortName());
		enrollmentRequest.setOrgId(master.getOrgId());
		enrollmentRequest.setEnrollStatus(ApplicationStatus.ENROLL_IN_PROGRESS.getId());

		CustomerDetails customerDetails = new CustomerDetails();
		customerDetails.setDob(enrollmentDetails.getCustomerDetails().getDob());
		customerDetails.setGender(enrollmentDetails.getCustomerDetails().getGender());
		customerDetails.setAccountHolderName(enrollmentDetails.getCustomerDetails().getAccountHolderName());
		customerDetails.setFirstName(enrollmentDetails.getCustomerDetails().getFirstName());
		customerDetails.setMiddleName(enrollmentDetails.getCustomerDetails().getMiddleName());
		customerDetails.setLastName(enrollmentDetails.getCustomerDetails().getLastName());
		customerDetails.setFatherHusbandName(enrollmentDetails.getCustomerDetails().getFatherHusbandName());
		customerDetails.setOrgId(master.getOrgId());
		customerDetails.setCustIfsc(master.getApplicantInfo().getIfsc());
		customerDetails.setAccountNumber(enrollmentDetails.getCustomerDetails().getAccountNumber());
		customerDetails.setCif(enrollmentDetails.getCustomerDetails().getCif());
		enrollmentRequest.setCustomerDetails(customerDetails);

		KycDetails kycDetails = new KycDetails();
		kycDetails.setKycId1(enrollmentDetails.getKycDetails().getKycId1());
		kycDetails.setKycIdValue1(enrollmentDetails.getKycDetails().getKycIdValue1());
		kycDetails.setKycId2(enrollmentDetails.getKycDetails().getKycId2());
		kycDetails.setKycIdValue2(enrollmentDetails.getKycDetails().getKycIdValue2());
		kycDetails.setPanNumber(master.getApplicantInfo().getPan());
		kycDetails.setAadhaarNumber(master.getApplicantInfo().getAadhaar());
		kycDetails.setCkyc(enrollmentDetails.getKycDetails().getCkyc());
		kycDetails.setCkycNumber(enrollmentDetails.getKycDetails().getCkycNumber());
		enrollmentRequest.setKycDetails(kycDetails);

		PolicyDetails policyDetails = new PolicyDetails();
		if (!OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails())) {
			if (!OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getInsurerMaster())) {
				policyDetails.setPolicyPeriod(master.getLastTransactionDetails().getInsurerMaster().getYear());
			}
			policyDetails.setTransactionType(!OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getType())
					? TransactionType.fromId(master.getLastTransactionDetails().getType()).getValue()
					: null);
		}
		policyDetails.setInsurerOrgId(master.getInsurerOrgId());
		policyDetails.setMasterPolicyNumber(masterPolicyNumber);

		enrollmentRequest.setPolicyDetails(policyDetails);
		return enrollmentRequest;
	}

	private DedupApiReqProxy getCheckDedupeReq(DeDupReqProxyV2 deDupeDetails, Long orgId, Long insurerOrgId) {
		DedupApiReqProxy dedupRequest = new DedupApiReqProxy();
		dedupRequest.setKycId1(deDupeDetails.getKycId1());
		dedupRequest.setKycIdValue1(deDupeDetails.getKycIdValue1());
		dedupRequest.setKycId2(deDupeDetails.getKycId2());
		dedupRequest.setKycIdValue2(deDupeDetails.getKycIdValue2());
		dedupRequest.setCkycNumber(deDupeDetails.getCkycNumber());
		dedupRequest.setGender(deDupeDetails.getGender());
		dedupRequest.setFirstName(deDupeDetails.getFirstName());
		dedupRequest.setMiddleName(deDupeDetails.getMiddleName());
		dedupRequest.setLastName(deDupeDetails.getLastName());
		dedupRequest.setFatherHusbandName(deDupeDetails.getFatherHusbandName());
		dedupRequest.setMob(deDupeDetails.getMob());
		dedupRequest.setPincode(
				!OPLUtils.isObjectNullOrEmpty(deDupeDetails.getPincode()) ? Integer.parseInt(deDupeDetails.getPincode())
						: null);
		dedupRequest.setDob(deDupeDetails.getDob());
		dedupRequest.setBankCode(deDupeDetails.getBankCode());
		dedupRequest.setAccNo(deDupeDetails.getAccNo());
		dedupRequest.setScheme(deDupeDetails.getScheme());
		dedupRequest.setAccountStatus(deDupeDetails.getAccountStatus());
		dedupRequest.setType(deDupeDetails.getType());
		dedupRequest.setCif(deDupeDetails.getCif());
		dedupRequest.setUrn(deDupeDetails.getUrn());
		dedupRequest.setOrgId(orgId);
		dedupRequest.setInsurerOrgId(insurerOrgId);
		return dedupRequest;
	}*/
	
	/**
	 * PUSH CLAIM DETAILS INTO DE-DUPE REGISTRY
	 * 
	 * @param claimMaster
	 * @return
	 */
//	public CommonResponse callPushClaimRequest(ClaimMasterV3 claimMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
//					.callPushClaimRequest(getcallClaimPushRequestData(claimMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())
//					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);
//			}
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//					false);
//		} catch (Exception e) {
//			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//					false);
//		}
//	}
	
	
	/**
	 * PUSH CLAIM DETAILS INTO DE-DUPE REGISTRY
	 * 
	 * @param claimMaster
	 * @return
	 */
//	public CommonResponse callPushClaimRequestV3(ClmMaster claimMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient
//					.callPushClaimRequest(getcallClaimPushRequestDataV3(claimMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())
//					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);
//			}
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//					false);
//		} catch (Exception e) {
//			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//					false);
//		}
//	}


//	private PushClaimProxy getcallClaimPushRequestData(ClaimMasterV3 claimMaster) {
//		ApplicationMasterV3 applicationMaster = claimMaster.getApplicationMaster();
//		PushClaimProxy pushClaimProxy = new PushClaimProxy();
//		pushClaimProxy.setUrn(applicationMaster.getUrn());
//		pushClaimProxy.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//		pushClaimProxy.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId())
//				? Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue()
//				: null);
//		pushClaimProxy.setApplicantAccNo(applicationMaster.getAccountNumber());
//		pushClaimProxy.setOrgId(applicationMaster.getOrgId());
//		pushClaimProxy
//				.setApplicantDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//		pushClaimProxy.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//		pushClaimProxy.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//		pushClaimProxy.setApplicantfirstName(applicationMaster.getApplicantInfo().getFirstName());
//		pushClaimProxy.setApplicantmiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//		pushClaimProxy.setApplicantlastName(applicationMaster.getApplicantInfo().getLastName());
//		pushClaimProxy.setDateofDeath(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateOfDeath()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDetail().getDateOfDeath()) : null);
//		pushClaimProxy
//				.setDateofAccident(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//		pushClaimProxy.setClaimStatusId(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//		pushClaimProxy.setEnrollmentDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(applicationMaster.getCompletionDate()));
//		if(applicationMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
//			String typeOfDisability = null;
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//				typeOfDisability = TypeOfDisability.fromId(claimMaster.getClaimDetail().getTypeOfDisablityId()).getValue();
//			}
//			String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId()) ? typeOfDisability : "-";
//			pushClaimProxy.setClaimType(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DEATH.getId()) ? NatureOfLoss.DEATH.getValue() : typeOfLoss );
//		}else if(applicationMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue() && (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()))) {		
//				String typeOfLoss=Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId()) ? "Accidental Death" : "-";
//				pushClaimProxy.setClaimType(Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId()) ? CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getValue() :typeOfLoss );
//			
//		}
//		pushClaimProxy.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDate()) : null);
//		return pushClaimProxy;
//	}
	
//	private PushClaimProxy getcallClaimPushRequestDataV3(ClmMaster claimMaster) {
//		ApplicationMasterV3 applicationMaster = appMasterRepo.findByIdAndIsActiveTrue(claimMaster.getApplicationId());
//		ClmDetails clmDetails = clmDetailsRepository.getById(claimMaster.getId());
//		
////		ApplicationMasterV3 applicationMaster = claimMaster.getApplicationMaster();
//		PushClaimProxy pushClaimProxy = new PushClaimProxy();
//		pushClaimProxy.setUrn(applicationMaster.getUrn());
//		pushClaimProxy.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//		pushClaimProxy.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId())
//				? Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue()
//				: null);
//		pushClaimProxy.setApplicantAccNo(applicationMaster.getAccountNumber());
//		pushClaimProxy.setOrgId(applicationMaster.getOrgId());
//		pushClaimProxy
//				.setApplicantDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//		pushClaimProxy.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//		pushClaimProxy.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//		pushClaimProxy.setApplicantfirstName(applicationMaster.getApplicantInfo().getFirstName());
//		pushClaimProxy.setApplicantmiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//		pushClaimProxy.setApplicantlastName(applicationMaster.getApplicantInfo().getLastName());
//		pushClaimProxy.setDateofDeath(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateOfDeath()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(clmDetails.getDateOfDeath()) : null);
//		pushClaimProxy
//				.setDateofAccident(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateTimeOfAccident()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(clmDetails.getDateTimeOfAccident()) : null);
//		pushClaimProxy.setClaimStatusId(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//		pushClaimProxy.setEnrollmentDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(applicationMaster.getCompletionDate()));
//		if(applicationMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
//			String typeOfDisability = null;
//			if(!OPLUtils.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId())) {
//				typeOfDisability = TypeOfDisability.fromId(clmDetails.getTypeOfDisabilityId()).getValue();
//			}
//			String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId()) && Objects.equals(clmDetails.getNatureOfLossId(), NatureOfLoss.DISABILITY.getId()) ? typeOfDisability : "-";
//			pushClaimProxy.setClaimType(!OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId()) && Objects.equals(clmDetails.getNatureOfLossId(), NatureOfLoss.DEATH.getId()) ? NatureOfLoss.DEATH.getValue() : typeOfLoss );
//		}else if(applicationMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue() && (!OPLUtils.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId()))) {		
//				String typeOfLoss=Objects.equals(clmDetails.getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId()) ? "Accidental Death" : "-";
//				pushClaimProxy.setClaimType(Objects.equals(clmDetails.getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getId()) ? CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue() :typeOfLoss );
//			
//		}
//		pushClaimProxy.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDate()) : null);
//		return pushClaimProxy;
//	}
}
