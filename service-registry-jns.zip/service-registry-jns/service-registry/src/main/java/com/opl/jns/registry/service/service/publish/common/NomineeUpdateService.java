package com.opl.jns.registry.service.service.publish.common;

import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;

public interface NomineeUpdateService {

	public NomieeUpdateResponse updateNominee(NomineeUpdateRequest nomineeRequest) throws Exception;
	
}
