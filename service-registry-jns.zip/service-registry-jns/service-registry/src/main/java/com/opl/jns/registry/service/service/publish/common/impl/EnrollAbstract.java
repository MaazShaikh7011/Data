package com.opl.jns.registry.service.service.publish.common.impl;


import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Objects;
import java.util.Random;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequestV3;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.COIDocsProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransResProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe.DeDupDataProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe.DeDupReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.dedupe.DeDupResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentDataResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.COIDocsProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.COIDocsProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ApplicationQueryProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.ApplicationStatus;
import com.opl.jns.published.utils.enums.EnrollStageMaster;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeReqProxy;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeResProxy;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.utils.AsynUtils;
import com.opl.jns.registry.service.utils.NotificationPrepareProxy;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.registry.service.utils.v2.EnrollmentValidation;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.model.COIRequest;
import com.opl.jns.webhook.client.WebHookClient;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;

@Component
@Transactional
@Slf4j
public abstract class EnrollAbstract {

	@Autowired
	private static Validator validator;
	
	@Autowired
	private EnrollmentValidation enrollmentValidation;

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;
	
	@Autowired
	private ApplicationPushStatusRepo applicationPushStatusRepo;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private ApiConfigMasterRepo configRepo;

	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 appMstrOtherDtlsRepoV3;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;
	
	@Autowired
	private PmjjbyRepository pmjjbyRepository;
	
	@Autowired
	private PmsbyRepository pmsbyRepository; 
	
	@Autowired
	private AsynUtils asynUtils;

	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private PDFGenerateClient pdfGenerateClient;

	@Autowired
	private DMSClient dmsClient;
	
	@Autowired
	private WebHookClient webHookClient;
	
	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

	private static final Integer[] inProcessOrCompletedApplication = new Integer[] {
			ApplicationStatus.ENROLL_IN_PROGRESS.getId()};//, ApplicationStatus.ENROLL_COMPLETED.getId() -removed rejected renewal in master and insurance .app in not reject issues

	private static final String IS_MATCHED_Y = "Y";
	private static final String IS_MATCHED_N = "N";
	private static final String IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER = "It seems an error occurred in De-dupe response; please try again later.";

	/**
	 * ENROLLMENT DE-DUPE
	 * 
	 * @param <T>
	 * @param in
	 * @param orgId
	 * @return
	 */
	protected <T extends RegistryReqProxy> DeDupResProxyV2 enDeDupe(T in, Long orgId) {
		try {
			DeDupReqProxyV2 deDupeDetails = (DeDupReqProxyV2) in;
			/* CHECK KYC VALIDATION */
			StringBuilder s1 = new StringBuilder();
			s1 = enrollmentValidation.kycIdValidation(deDupeDetails.getKycId1(), deDupeDetails.getKycIdValue1(), s1,
					"KYC ID1");
			s1 = enrollmentValidation.kycIdValidation(deDupeDetails.getKycId2(), deDupeDetails.getKycIdValue2(), s1,
					"KYC ID2");
			if (s1.length() > 0) {
				log.error("KYC VALIDATION FAILED ---> " + s1.toString());
				return new DeDupResProxyV2(s1.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* CHECK DOB VALIDATION AND FORMAT */
			if (!OPLUtils.isObjectNullOrEmpty(deDupeDetails.getDob())) {
				try {
					Constants.sdf_dd_MM_yyyy.parse(deDupeDetails.getDob());
				} catch (Exception e) {
					log.error("DATE OF BIRTH FORMAT IS INVALID ---> ", e);
					return new DeDupResProxyV2("date of birth format is invalid", HttpStatus.BAD_REQUEST.value(),
							Boolean.FALSE);
				}
			}

			/* CHECK ACCOUNT AND CIF NUMBER VALIDATION */
			if (OPLUtils.isObjectNullOrEmpty(deDupeDetails.getAccNo())
					|| OPLUtils.isObjectNullOrEmpty(deDupeDetails.getCif())) {
				log.error("ACCOUNT OR CIF IS NOT FOUND");
				return new DeDupResProxyV2("Customer Account Or Cif is not Found", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			Integer schemeId = SchemeMaster.getByCode(deDupeDetails.getScheme()).getId().intValue();
			/* GET CURRENT YEAR POLICY INSURER DETAILS */
			InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
							schemeId.longValue(), orgId, new Date(), new Date());
			if (OPLUtils.isObjectNullOrEmpty(currentInsurerDetails)) {
				log.error("INSURER DETAILS NOT FOUND FOR THE CURRENT YEAR");
				return new DeDupResProxyV2("Insurer detail dose not exists", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}

			ApplicationQueryProxy applicationQueryProxy = null;
			// Same Organization Check If CIF Enrollment Exist
			applicationQueryProxy = applicationMasterRepository
					.fetchEnromentValidateByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusIn(orgId, schemeId,
							deDupeDetails.getCif(), inProcessOrCompletedApplication);
			if (!OPLUtils.isObjectNullOrEmpty(applicationQueryProxy)) {
				return callDedupe(applicationQueryProxy, orgId);
			}
			
			/**CHECK JNS MASTER DATA APPLICATION MASTER DEDUPE*/
			String urn=ereCommonService.checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(
					schemeId, deDupeDetails.getCif(), orgId);
			if (!OPLUtils.isObjectNullOrEmpty(urn)) {
				return callMasterDeDupe(urn, orgId);
			}

			/* DEDUPE - CHECK Python api configure here */
			applicationQueryProxy = applicationMasterRepository
					.fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusIn(
							schemeId, deDupeDetails.getAccNo(), deDupeDetails.getCif(),
							inProcessOrCompletedApplication);

			if (!OPLUtils.isObjectNullOrEmpty(applicationQueryProxy)) {
				return callDedupe(applicationQueryProxy, orgId);
			}

			return new DeDupResProxyV2("data Not Found", DeDupDataProxyV2.builder().isMatched(IS_MATCHED_N).build(),
					HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
		} catch (Exception e) {
			log.error("EXCEPTION IS GETTING WHILE CHECK DEDUPE ", e);
			return new DeDupResProxyV2(IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	/**
	 * BEFORE ENROLLMENT VALIDATION
	 * 
	 * @param beforeProxy
	 * @return
	 * @throws IOException 
	 */
	protected EnrollBeforeResProxy enrollBefore(EnrollBeforeReqProxy beforeProxy) throws IOException {

		Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(beforeProxy.getOrgId(),
				UserRoleMaster.HEAD_OFFICE.getId());

		/* GET CURRENT YEAR POLICY INSURER DETAILS */
		InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository
				.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
						beforeProxy.getSchemeId(), beforeProxy.getOrgId(), new Date(), new Date());

		if (OPLUtils.isObjectNullOrEmpty(currentInsurerDetails)) {
			log.error("INSURER DETAILS NOT FOUND FOR THE CURRENT YEAR");
			return new EnrollBeforeResProxy("Insurer details dose not exists. Kindly contact HO",
					HttpStatus.BAD_REQUEST.value(), false);
		}

		BranchBasicDetailsRequest branch = usersClient.getBranchCode(beforeProxy.getSchemeId(),
				beforeProxy.getOrgId(), beforeProxy.getBranchCode());

		if (OPLUtils.isObjectNullOrEmpty(branch) || OPLUtils.isObjectNullOrEmpty(branch.getId())) {
			log.error("BRANCH DETAILS NOT FOUND BY BRANCH CODE AND BRANCH IFSC CODE");
			return new EnrollBeforeResProxy("Branch Details Not Found", HttpStatus.BAD_REQUEST.value(), false);
		}

		ApplicationQueryProxy applicationQueryProxy = null;

		/* CHECK BY CIF WITH SAME BANK AND SAME SCHEME */
		applicationQueryProxy = applicationMasterRepository
				.fetchEnromentValidateByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusIn(
						beforeProxy.getOrgId(), beforeProxy.getSchemeId().intValue(), beforeProxy.getCif(),
						inProcessOrCompletedApplication);
		if (!OPLUtils.isObjectNullOrEmpty(applicationQueryProxy)) {
			return callEnrollmentDedupe(applicationQueryProxy, beforeProxy.getOrgId());
		}

		/* CHECK BY ACCOUNT NUMBER AND CIF WITH ALL THE BANKS */
		applicationQueryProxy = applicationMasterRepository
				.fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusIn(
						beforeProxy.getSchemeId().intValue(), beforeProxy.getAccNo(), beforeProxy.getCif(),
						inProcessOrCompletedApplication);

		if (!OPLUtils.isObjectNullOrEmpty(applicationQueryProxy)) {
			return callEnrollmentDedupe(applicationQueryProxy, beforeProxy.getOrgId());
		}
		
		/**CHECK JNS MASTER DATA APPLICATION MASTER DEDUPE*/
		String urn=ereCommonService.checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(
				beforeProxy.getSchemeId().intValue(), beforeProxy.getCif(), beforeProxy.getOrgId());
		if (!OPLUtils.isObjectNullOrEmpty(urn)) {
			return new EnrollBeforeResProxy(Constants.FAILED, HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE,
					new EnrollmentDataResProxyV2(Boolean.TRUE, HttpStatus.ALREADY_REPORTED.getReasonPhrase(),urn));
		}

		EnrollBeforeResProxy beforeResProxy = new EnrollBeforeResProxy();
		beforeResProxy.setProceed(true);
		beforeResProxy.setUserId(userId);
		beforeResProxy.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
		beforeResProxy.setBranchId(branch.getId());
		beforeResProxy.setBranchRoId(branch.getRoId());
		beforeResProxy.setBranchZoId(branch.getZoId());
		beforeResProxy.setBranchStateId(branch.getStateId() != null ? branch.getStateId().longValue() : null);
		beforeResProxy.setBranchCityId(branch.getCityId() != null ? branch.getCityId().longValue() : null);
		beforeResProxy.setRuralUrbanId(branch.getRuralUrbanId());
		return beforeResProxy;
	}

	public EnrollBeforeResProxy enrollAfter(ApplicationMasterV3 applicationMaster) {

		/* FETCH HO USER ID FROM USER CLIENT */
		Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(applicationMaster.getOrgId(),
				UserRoleMaster.HEAD_OFFICE.getId());

//		applicationMaster.setCreatedDate(new Date());
		applicationMaster.setUserId(userId);
		applicationMaster.setCreatedBy(userId);
		applicationMaster.setIsActive(Boolean.TRUE);
		applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_IN_PROGRESS.getId());
		applicationMaster.setStatusChangeDate(new Date());
		applicationMaster.setStageId(EnrollStageMaster.APPLICATION_FORM.getStageId());

		ApplicationMasterOtherDetailsV3 otherDetails = applicationMaster.getApplicationMasterOtherDetails();
		otherDetails.setSource(Source.OTHER_CHANNEL.getId());
		otherDetails.setTypeOfVerification(2);
		otherDetails.setAppCreatedDate(applicationMaster.getCreatedDate());
		otherDetails.setApplicationMaster(applicationMaster);
		applicationMaster.setApplicationMasterOtherDetails(otherDetails);

		applicationMaster.getApplicantInfo().setCreatedBy(userId);
		applicationMaster.getNomineeDetails().forEach(a -> a.setCreatedBy(userId));

		applicationMaster = applicationMasterRepository.save(applicationMaster);

		/* GENERATE URN CODE METHOD */
		String urnCode = generateUrnCode(applicationMaster.getSchemeId(), applicationMaster.getId());
		applicationMasterRepository.updateUrn(urnCode, applicationMaster.getOrgId(), applicationMaster.getSchemeId(),
				applicationMaster.getId());
		log.info("GENERATE NEW URN ------------------->" + urnCode);
		return new EnrollBeforeResProxy(Constants.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE,
				new EnrollmentDataResProxyV2(Boolean.FALSE, "", urnCode));

	}

	/**
	 * GENERATE URN CODE LOGIC
	 * 
	 * @param schemeId
	 * @param applicationId
	 * @return
	 */
	protected String generateUrnCode(Integer schemeId, Long applicationId) {
		if (null == applicationId || null == schemeId) {
			return null;
		}
		Random rand = new Random();
		String id = "%03d".formatted(rand.nextInt(1000));
		return configRepo.findByCodeAndIsActiveTrue(RegistryUtils.JNS_APP_CODE_INITIAL).getValue().toUpperCase()
				.concat(RegistryUtils.CHAR_DASH)
				.concat(SchemeMaster.getById(schemeId.longValue()).getShortName().toUpperCase())
				.concat(RegistryUtils.CHAR_DASH).concat(RegistryUtils.getPolicyYearToYear())
				.concat(RegistryUtils.CHAR_DASH).concat("%011d".formatted(applicationId))
				.concat(RegistryUtils.CHAR_DASH).concat(id);

	}

	/**
	 * HANDLE DE-DUPE FAILED RESPONSE WHILE ENROLLMENT API
	 * 
	 * @param applicationMaster
	 * @param orgId
	 * @return
	 */
	private EnrollBeforeResProxy callEnrollmentDedupe(ApplicationQueryProxy applicationMaster, Long orgId) {
		if (applicationMaster.getApplicationStatus() == ApplicationStatus.ENROLL_IN_PROGRESS.getId()) {

			Integer source = appMstrOtherDtlsRepoV3.getSouceByApplicationId(applicationMaster.getApplicationId());
			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())
					&& applicationMaster.getOrgId().equals(orgId)) {
				if (Source.OTHER_CHANNEL.getId().equals(source)) {
					log.error("RETURN ALREADY ENROLLMENT IN PROGRESS");
					return new EnrollBeforeResProxy(Constants.SUCCESS, HttpStatus.OK.value(), Boolean.FALSE,
							new EnrollmentDataResProxyV2(Boolean.FALSE, "Already Enrollment Inprocess.",
									applicationMaster.getUrn()));
				} else {
					log.error("ENROLLMENT IS CURRENTLY IN PROCESS THROUGH ASSISTED MODE");
					return new EnrollBeforeResProxy(Constants.FAILED, HttpStatus.ALREADY_REPORTED.value(),
							Boolean.FALSE, new EnrollmentDataResProxyV2(Boolean.TRUE,
									"Enrollment is currently in process through assisted mode.", ""));
				}
			} else {
				String organizationName = usersClient.getOrganizationName(applicationMaster.getOrgId());
				log.error("ALREADY ENROLLMENT INPROCESS WITH THE BANK (" + organizationName + ").");
				return new EnrollBeforeResProxy(Constants.FAILED, HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE,
						new EnrollmentDataResProxyV2(Boolean.TRUE,
								"Already Enrollment Inprocess with the bank (" + organizationName + ").", ""));
			}
		} else {
			log.error("ALREADY ENROLLMENT COMPLETED");
			return new EnrollBeforeResProxy(Constants.FAILED, HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE,
					new EnrollmentDataResProxyV2(Boolean.TRUE, HttpStatus.ALREADY_REPORTED.getReasonPhrase(),
							applicationMaster.getUrn()));
		}
	}

	/**
	 * HANDLE DE-DUPE FAILUR RESPONSE WHILE DE-DUPE API
	 * 
	 * @param applicationQueryProxy
	 * @param orgId
	 * @return
	 */
	private DeDupResProxyV2 callDedupe(ApplicationQueryProxy applicationQueryProxy, Long orgId) {
		String organizationName = usersClient.getOrganizationName(applicationQueryProxy.getOrgId());
		DeDupDataProxyV2 deDupProxy = null;
		if (applicationQueryProxy.getApplicationStatus() == ApplicationStatus.ENROLL_IN_PROGRESS.getId()) {
			if (!OPLUtils.isObjectNullOrEmpty(applicationQueryProxy.getOrgId())
					&& applicationQueryProxy.getOrgId().equals(orgId)) {
				Integer source = appMstrOtherDtlsRepoV3
						.getSouceByApplicationId(applicationQueryProxy.getApplicationId());
				if (Source.OTHER_CHANNEL.getId().equals(source)) {
					deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_N).matchWith("")
							.bankName(organizationName).build();
					log.error("RETURN ALREADY ENROLLMENT IN PROGRESS");
					return new DeDupResProxyV2("Already Enrollment Inprocess.", deDupProxy,
							HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				} else {
					deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_Y).matchWith("")
							.bankName(organizationName).build();
					log.error("ENROLLMENT IS CURRENTLY IN PROCESS THROUGH ASSISTED MODE");
					return new DeDupResProxyV2("Enrollment is currently in process through assisted mode.", deDupProxy,
							HttpStatus.OK.value(), Boolean.TRUE);
				}
			} else {
				deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_Y)
						.matchWith("Already Enrollment Inprocess with the bank (" + organizationName + ").")
						.bankName(organizationName).build();
				log.error(deDupProxy.getMatchWith());
				return new DeDupResProxyV2("Data Found Successfully", deDupProxy, HttpStatus.OK.value(), Boolean.TRUE);
			}
		} else {
			if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
				deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_Y)
						.matchWith(applicationQueryProxy.getUrn()).bankName(organizationName).build();
			}
			log.error("ALREADY ENROLLMENT COMPLETED");
			return new DeDupResProxyV2("Data Found Successfully", deDupProxy, HttpStatus.OK.value(), Boolean.TRUE);
		}
	}
	
	/**
	 * HANDLE DE-DUPE MASTER TABLE WHILE DE-DUPE API
	 * 
	 * @param urn
	 * @param orgId
	 * @return
	 */
	private DeDupResProxyV2 callMasterDeDupe(String urn,Long orgId) {
		String organizationName = usersClient.getOrganizationName(orgId);
		DeDupDataProxyV2 deDupProxy = null;
		if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
			deDupProxy = DeDupDataProxyV2.builder().isMatched(IS_MATCHED_Y)
					.matchWith(urn).bankName(organizationName).build();
		}
		log.error("ALREADY ENROLLMENT COMPLETED");
		return new DeDupResProxyV2("Data Found Successfully", deDupProxy, HttpStatus.OK.value(), Boolean.TRUE);
	}

	/**
	 * ENROLLMENT UPDATE STATUS
	 * 
	 * @param urn
	 * @return
	 * @throws IOException 
	 */
	public MainResponse enUpdateStatus(String accNo, LocalDate dob, String cif, String urn, Integer accStatus, String reason, String token) throws IOException {

		Integer[] intArr = { com.opl.jns.utils.enums.ApplicationStatus.OPT_OUT.getId(),
				com.opl.jns.utils.enums.ApplicationStatus.ACCOUNT_INACTIVE.getId(),
				com.opl.jns.utils.enums.ApplicationStatus.INSUFFICIENT_BALANCE.getId(),
				com.opl.jns.utils.enums.ApplicationStatus.ACCOUNT_HOLDER_DECEASED.getId() };

		if (!Arrays.asList(intArr).contains(accStatus)) {
			log.error(
					"Status must be :6 for Opt-Out, 7 for Account Inactive, 8 for Insufficient Balance and  9 for Account Holder Deceased.");
			return new UpdateStatusResProxyV3("Status must be :6 for Opt-Out, 7 for Account Inactive, 8 for Insufficient Balance and  9 for Account Holder Deceased.",
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}

		/**FETCH JNS_MASTER PMSBY/PMJJBY*/
		Long schemeId = OPLUtils.getSchemeIdFromUrn(urn);
		Long applicationId = OPLUtils.getApplicationIdFromUrn(urn);
		PMSBY pmsby = null;
		PMJJBY pmjjby = null;
		ApplicationMasterBothSchemeProxy appMaster = null;
		if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
			pmsby = pmsbyRepository.findByIdAndIsActiveTrue(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
				appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmsby, ApplicationMasterBothSchemeProxy.class);
				appMaster.setSchemeId(SchemeMaster.PMSBY.getId());
			}
		} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId())) {
			pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
				appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmjjby,
						ApplicationMasterBothSchemeProxy.class);
				appMaster.setSchemeId(SchemeMaster.PMJJBY.getId());
			}
		}
		
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.error("APPLICATION MASTER DETAILS NOT FOUND BY URN -->" + urn);
			return new UpdateStatusResProxyV3(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(),
                                Boolean.FALSE);
		}
		
		if (Arrays.asList(intArr).contains(appMaster.getStatus())) {
			log.error("APPLICATION MASTER ALREADY STATUS UPDATED URN -->" + urn);
			return new UpdateStatusResProxyV3(HttpStatus.BAD_REQUEST.value(), "already status updated",
                                Boolean.FALSE);
		}
		
		/**GET JNS_MASTER PMSBY/PMJJBY MODIFIED DATE*/
		Long modifiedBy = null;
		if(Objects.equals(appMaster.getSchemeId(), SchemeMaster.PMSBY.getId())) {
			modifiedBy=pmsby.getModifiedBy();
		}else if(Objects.equals(appMaster.getSchemeId(), SchemeMaster.PMJJBY.getId())) {
			modifiedBy=pmjjby.getModifiedBy();
		}
		
		/**FETCH TRANSACTION DETAILS BY TRANSACTIO ID*/
		TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findById(appMaster.getLastTransactionId()).orElse(null);
		if(OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
			log.error("TRANSACTION DETAILS NOT FOUND BY TRANSACTION ID -->" + appMaster.getLastTransactionId());
			return new UpdateStatusResProxyV3(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(),
                                Boolean.FALSE);
		}
		
		Date coverEndDate = transactionDetailsV2.getCoverEndDate();
		
		/** SAVING FOR MISCELLANEOUS */
		saveMiscellaneousAudit(accStatus, urn, appMaster, accNo, cif, token, modifiedBy, reason, dob, coverEndDate);
		
		if(!Objects.equals(accStatus, com.opl.jns.utils.enums.ApplicationStatus.OPT_OUT.getId())) {
			/**UPDATE JNS_MASTER PMSBY/PMJJBY*/
			updateJnsMasterAppMst(pmsby, pmjjby, appMaster, accStatus);
			
			/**UPDATE JNS_INSURANCE APPLICATION MASTER*/
			updateApplicationMaster(accStatus,urn);
		}
		
		/** CALL WEBHOOK FOR BANK AND INSURER OPT OUT UPDATE STATUS */
		if (PhaseMode.checkPhase2(appMaster.getOrgId()) && Objects.equals(accStatus, com.opl.jns.utils.enums.ApplicationStatus.OPT_OUT.getId())) {
            /**AFTER PUSH JNS MASTER NOMINEE UPDATE FLAG SET FALSE*/
			ereCommonService.setOptOutPushFlagFalse(appMaster.getId());
        	
			try {
				callWebhookForPushOptOutUpdateStatusBankAndInsurer(accNo,urn,cif, appMaster,coverEndDate);
			} catch (Exception e) {
				log.error("Exception is getting While webhook opt out update status ", e);
			}
		}
		
		return new UpdateStatusResProxyV3(HttpStatus.OK.value(), Constants.SUCCESS, Boolean.TRUE);
	}
	
	public void saveMiscellaneousAudit(Integer accStatus, String urn, ApplicationMasterBothSchemeProxy appMaster,
			String accNo, String cif, String token, Long modifiedBy, String reason, LocalDate dob, Date coverEndDate) {
		if (Objects.equals(accStatus, com.opl.jns.utils.enums.ApplicationStatus.OPT_OUT.getId())) {
			MiscellaneousAudit miscellaneousAudit = new MiscellaneousAudit().toBuilder()
					.applicationId(appMaster.getId()).urn(urn)
					.type(MiscellaneousType.fromApplicationStatus(accStatus).getId()).accountNumber(accNo).cif(cif)
					.accountStatus(accStatus).reason(reason).requestToken(token)
					.dob(!OPLUtils.isObjectNullOrEmpty(dob)
							? Date.from(dob.atStartOfDay(ZoneId.systemDefault()).toInstant())
							: null)
					.createdBy(modifiedBy).dateOfEffective(coverEndDate).dateOfRequest(new Date())
					.createdDate(new Date()).isActive(Boolean.TRUE).build();
			miscellaneousAuditRepository.save(miscellaneousAudit);
		}
	}

	public void updateJnsMasterAppMst(PMSBY pmsby, PMJJBY pmjjby, ApplicationMasterBothSchemeProxy appMaster,
			Integer accStatus) {
		if (Objects.equals(appMaster.getSchemeId(), SchemeMaster.PMSBY.getId())) {
			pmsby.setStatus(accStatus);
			pmsby.setStatusChangeDate(new Date());
			pmsby.setModifiedDate(new Date());
			pmsbyRepository.save(pmsby);
		} else if (Objects.equals(appMaster.getSchemeId(), SchemeMaster.PMJJBY.getId())) {
			pmjjby.setStatus(accStatus);
			pmjjby.setStatusChangeDate(new Date());
			pmjjby.setModifiedDate(new Date());
			pmjjbyRepository.save(pmjjby);
		}
	}

	public void updateApplicationMaster(Integer accStatus, String urn) {
		ApplicationMasterV3 appMst = applicationMasterRepository.findFirstByUrnAndIsActiveTrue(urn);
		if (!OPLUtils.isObjectNullOrEmpty(appMst)) {
			appMst.setApplicationStatus(accStatus);
			appMst.setStatusChangeDate(new Date());
			appMst.setModifiedDate(new Date());
			applicationMasterRepository.save(appMst);
		}
	}

	public void callWebhookForPushOptOutUpdateStatusBankAndInsurer(String accNo, String urn, String cif,
			ApplicationMasterBothSchemeProxy applicationMaster, Date coverEndDate) {

		/** PREPARE OPT OUT UPDATE STATUS REQUEST */
		OptOutUpdateStatusRequestV3 updateStatusReq = prepareOptOutUpdateStatusRequest(accNo, urn, cif, applicationMaster,
				coverEndDate);

		/** BANK WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		if(applicationMaster.getOrgId()!=CommonUtils.SBI_BANK_ID) {			
			optOutUpdateStatus(updateStatusReq, applicationMaster.getCreatedBy());
		}

		/** INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		updateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
		updateStatusReq.setIsInsurer(true);
		optOutUpdateStatus(updateStatusReq, applicationMaster.getCreatedBy());
	}

	public OptOutUpdateStatusRequestV3 prepareOptOutUpdateStatusRequest(String accNo, String urn, String cif,
																	  ApplicationMasterBothSchemeProxy applicationMaster, Date coverEndDate) {
		OptOutUpdateStatusRequestV3 updateStatusReq = new OptOutUpdateStatusRequestV3();
		updateStatusReq.setAccountNumber(accNo);
		updateStatusReq.setCif(cif);
		updateStatusReq.setEffectiveDate(!OPLUtils.isObjectNullOrEmpty(coverEndDate)
				? coverEndDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
				: null);
		updateStatusReq.setUrn(urn);
		updateStatusReq.setApplicationId(applicationMaster.getId());
		updateStatusReq.setOrgId(applicationMaster.getOrgId());
		updateStatusReq.setRequestDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		return updateStatusReq;
	}
	
	
	public APIResponseV3 optOutUpdateStatus(OptOutUpdateStatusRequestV3 outUpdateStatusReq,
											 Long userId) {
		APIResponseV3 optOutUpdateStatus = null;
		try {
			try {
				outUpdateStatusReq.setCommonUserId(userId);
				optOutUpdateStatus = webHookClient.optOutUpdateStatus(outUpdateStatusReq);
			} catch (Exception e) {
				log.error("Exception while OPT OUT UPDATE STATUS -----> ", e);
				return new APIResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),CommonErrorMsg.Enrollment.UNABLE_TO_OPT_OUT_UPDATE_STATUS);
			}

			if (!OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus) && !OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus.getStatus())
					&& optOutUpdateStatus.getStatus() == HttpStatus.OK.value()
					&& optOutUpdateStatus.getSuccess().equals(Boolean.TRUE)) {
				
				StringBuilder validateResponse = validateResponse(optOutUpdateStatus);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new APIResponseV3(HttpStatus.BAD_REQUEST.value(),validateResponse.toString(),  Boolean.FALSE);
				}
				
				return new APIResponseV3(HttpStatus.OK.value(),"opt out status updated successfully", Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While opt out update status ", e);
		}
		return new APIResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), !OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus) ? optOutUpdateStatus.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_OPT_OUT_UPDATE_STATUS, Boolean.FALSE);
	}
	
	/** common method for response JAVAX validation*/
	public static <T> StringBuilder validateResponse(T object) throws ValidationException {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<T>> violations = validator.validate(object);

        if (!violations.isEmpty()) {
        	StringBuilder sb = new StringBuilder();
			for (ConstraintViolation<T> constraintViolation : violations) {
				if (sb.length() > 0) {
					sb.append(", " + constraintViolation.getMessage());
				} else {
					sb.append(constraintViolation.getMessage());
				}
			}
			return sb;
        }
		return null;
    }
	
	
	/**
	 * getCOI Genarated Bytes
	 * @param applicationMaster
	 * @return
	 */
	public byte[] getCOI(ApplicationMasterV3 applicationMaster) {
		try {
			Long storageId = applicationMaster.getLastTransactionDetails().getCoiStorageId();
			if (storageId != null) {
				return dmsClient.productDownloadDocuments(storageId.toString());
			}
			/* PREPARE COI REQUEST FROM ERE COMMON SERVICE */
			COIRequest coiReq = ereCommonService.generateCOIRequest(applicationMaster);

			/* GENERATE PDF FILE FROM PDF CLIENT */
			com.opl.jns.utils.common.CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
			if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
				/* SET COI STORAGE ID IN LAST TRANSACTION DETAILS */
				applicationMaster.getLastTransactionDetails().setCoiStorageId(generateCOI.getId());
				return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
			} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
				log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
			} else {
				log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
			}
		} catch (Exception e) {
			log.error("Exception while generate COI ----->", e);
		}
		return null;
	}
	
	public <T extends RegistryReqProxy> UpdateTransResProxyV2 callValidateApplicationMasterDetailV2(
			ApplicationMasterV3 applicationMaster, T in) throws Exception {
		UpdateTransResProxyV1 transResProxyV1 = validateCommonApplicationMasterDetail(applicationMaster, in);
		if (!OPLUtils.isObjectNullOrEmpty(transResProxyV1)) {
			if (!OPLUtils.isObjectNullOrEmpty(transResProxyV1.getCoi())) {
				return new UpdateTransResProxyV2(transResProxyV1.getMessage(),
						new COIDocsProxyV2(transResProxyV1.getCoi().getDocumentType(),
								transResProxyV1.getCoi().getContentType(), transResProxyV1.getCoi().getDocument()),
						transResProxyV1.getStatus(), transResProxyV1.getSuccess());
			} else {
				return new UpdateTransResProxyV2(transResProxyV1.getMessage(), transResProxyV1.getStatus(),
						transResProxyV1.getSuccess());
			}
		}
		return null;
	}
	
	public <T extends RegistryReqProxy> UpdateTransResProxyV3 callValidateApplicationMasterDetailV3(
			ApplicationMasterV3 applicationMaster, T in) throws Exception {
		UpdateTransResProxyV1 transResProxyV1 = validateCommonApplicationMasterDetail(applicationMaster, in);
		if (!OPLUtils.isObjectNullOrEmpty(transResProxyV1)) {
			if (!OPLUtils.isObjectNullOrEmpty(transResProxyV1.getCoi())) {
				return new UpdateTransResProxyV3(transResProxyV1.getMessage(),
						new COIDocsProxyV3(transResProxyV1.getCoi().getDocumentType(),
								transResProxyV1.getCoi().getContentType(), transResProxyV1.getCoi().getDocument()),
						transResProxyV1.getStatus(), transResProxyV1.getSuccess());
			} else {
				return new UpdateTransResProxyV3(transResProxyV1.getMessage(), transResProxyV1.getStatus(),
						transResProxyV1.getSuccess());
			}
		}
		return null;
	}

	/**
	 * Validate Application Master Detail
	 * 
	 * @param applicationMaster
	 * @return
	 * @throws Exception
	 */
	public <T extends RegistryReqProxy> UpdateTransResProxyV1 validateCommonApplicationMasterDetail(
			ApplicationMasterV3 applicationMaster, T in) throws Exception {
		Long applicationId = null;
		UpdateTransReqProxyV1 transactionRequest = (UpdateTransReqProxyV1) in;
		/* CHECK THE URN IS VALID OF NOT */
		if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
			log.error("END SAVE TRANSACTION DETAILS (NOT FOUND APPLICATION MASTER BY URN) --------->"
					+ transactionRequest.getUrn());
			return new UpdateTransResProxyV1("Invalid URN Details.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		} else if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails())) {
			/* IF LAST TRANSACTION IS EXISTS THEN NO NEED TO ADD ANOTHER TRANSACTION */
			log.error("END SAVE TRANSACTION DETAILS (ALREADY LAST TRANS DETAILS UPDATED) --------->"
					+ transactionRequest.getUrn());
			byte[] coiByte = getCOI(applicationMaster);
			return new UpdateTransResProxyV1(Constants.SUCCESS, new COIDocsProxyV1("coi", "pdf", coiByte),
					HttpStatus.OK.value(), Boolean.TRUE);
		}
		applicationId = applicationMaster.getId();
		log.info("START SAVE TRANSACTION DETAILS ------------->" + applicationId);
		/* CHECK CURRENT APPLICATION IS EXPIRED OR NOT */
		if (applicationMaster.getStageId() == EnrollStageMaster.EXPIRED.getStageId()) {
			log.error("END SAVE TRANSACTION DETAILS (ALREADY EXPIRED) --------->" + applicationId);
			return new UpdateTransResProxyV1("The application has already expired", HttpStatus.BAD_REQUEST.value(),
					Boolean.FALSE);
		}

		/* CHECK CURRENT APPLICATION IS REJECTED OR NOT */
		if (applicationMaster.getStageId() == EnrollStageMaster.REJECTED.getStageId()) {
			log.error("END SAVE TRANSACTION DETAILS (ALREADY REJECTED) --------->" + applicationId);
			return new UpdateTransResProxyV1("The application has already been rejected",
					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}

		/* CHECK DUBLICATE CIF ALREADY EXIST OR NOT */
		Long count = applicationMasterRepository.countByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatus(
				applicationMaster.getOrgId(), applicationMaster.getSchemeId(), applicationMaster.getCif(),
				ApplicationStatus.ENROLL_COMPLETED.getId());
		if (count > 0) {
			log.error("END SAVE TRANSACTION DETAILS (DUBLICATE FOUND BY CIF) --------->" + applicationId);
			return new UpdateTransResProxyV1("CIF has already completed enrollment", HttpStatus.BAD_REQUEST.value(),
					Boolean.FALSE);
		}
		return null;
	}


	/**
	 * BELOW PROCESS HAS BEEN DONE BY BELOW METHOD
	 * 1. EMAIL/SME SENT
	 * 2. PUBLISH ENROLLMENT DATA 
	 * 3. UPDATE STATUS AS COMPLETED IN DE-DUPE REGISTRY  
	 * @param applicationMaster
	 * @param coiByte
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T extends UpdateTransResProxyV1> T pushApplicationAndGenerateCoi(ApplicationMasterV3 applicationMaster, byte[] coiByte) throws Exception {

		if (!OPLUtils.isObjectNullOrEmpty(coiByte)) {

			/* SEND EMAIL FOR COI */
			sendEmailToApplicant(applicationMaster, coiByte);

			/* PUBLISHED THE CLAIM DATA */
//			publishEnrollment(applicationMaster);
			/* PUBLISHED THE CLAIM DATA */
			ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(applicationMaster.getId()).orElse(null);
			if(!OPLUtils.isObjectNullOrEmpty(applicationPushStatus)) {
				if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getMasterPush()) || (!OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getMasterPush()) && !applicationPushStatus.getMasterPush()))
					publishEnrollment(applicationMaster);
				else
					log.info("Already application  is Pushed -->"+applicationMaster.getId());				
			}else {
				ereCommonService.insertApplcationPushStatus(applicationMaster.getId());
				publishEnrollment(applicationMaster);
			}
			
			/* UPDATE STATUS TO DEDUPE REGISTRY */
//			if (OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()) 
//					|| (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()) && !applicationMaster.getApplicationMasterOtherDetails().getIsddStatusPush()))
//				asynUtils.updateStatusToDeDupeRegisty(applicationMaster.getId(), applicationMaster.getUrn(), applicationMaster.getEnrollmentDate());
//			else
//				log.info("Already application  Checked status-->"+applicationMaster.getId());

			/* PREPARING RESPONSE */
			log.info("END SAVE TRANSACTION DETAILS (SUCCESS) --------->" + applicationMaster.getId());
			return (T) new UpdateTransResProxyV1(Constants.SUCCESS, new COIDocsProxyV2("coi", "pdf", coiByte), HttpStatus.OK.value(), Boolean.TRUE);
		} else {
			log.error("END SAVE TRANSACTION DETAILS COI BYTES NULL OR EMPTY [{}]", applicationMaster.getId());
			throw new Exception("Exception while generate COI");
		}
	}

	/**
	 * CALL PUSH-PULL SERVICE CLIENT
	 * @param applicationMaster
	 */
	private void publishEnrollment(ApplicationMasterV3 applicationMaster) {
		/* PUBLISHED THE CLAIM DATA */
		asynUtils.publishEnrollment(applicationMaster.getId(), applicationMaster.getStageId());
		log.info("TRANSACTION DETAILS PUSHED --------->" + applicationMaster.getId());
	}

	/**
	 * PREPARE NOTIFICATION OBJECT AND CALL CLIENT
	 * @param applicationMaster
	 * @param coiByte
	 */
	private void sendEmailToApplicant(ApplicationMasterV3 applicationMaster, byte[] coiByte) {
		/* SEND EMAIL FOR COI */
		NotificationPrepareProxy proxy = new NotificationPrepareProxy();
		proxy.setId(applicationMaster.getId());
		proxy.setUrn(applicationMaster.getUrn());
		proxy.setSchemeId(applicationMaster.getSchemeId());
		proxy.setEmail(applicationMaster.getApplicantInfo().getEmail());
		proxy.setMobileNumber(applicationMaster.getApplicantInfo().getMobileNumber());
		proxy.setFirstName(applicationMaster.getApplicantInfo().getName());
		proxy.setTransAmount(applicationMaster.getLastTransactionDetails().getTransAmount());
		proxy.setYear(applicationMaster.getLastTransactionDetails().getYear());
		proxy.setSource(applicationMaster.getApplicationMasterOtherDetails().getSource());
		proxy.setOrgId(applicationMaster.getOrgId());
		asynUtils.sendCoiToApplicant(proxy, coiByte);

	}
	
	/**
	 * UPDATE ENROLLMENT STAGE
	 * @param applicationMaster
	 * @param userId
	 */
	protected void updateStage(ApplicationMasterV3 applicationMaster,Long userId,Integer stageId,Integer applicationStatus,String msg) {
		applicationMaster.setStageId(stageId);
		applicationMaster.setModifiedDate(new Date());
		applicationMaster.setModifiedBy(userId);
		applicationMaster.setApplicationStatus(applicationStatus);
		applicationMaster.setStatusChangeDate(new Date());
		if(!OPLUtils.isObjectNullOrEmpty(msg)) {			
			applicationMaster.setMessage(msg);
		}
		applicationMasterRepository.save(applicationMaster);
	}

}
