package com.opl.jns.registry.service.service.publish.v2.impl;

import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransResProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentDataResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatestatus.UpdateStatusReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.COIDocsProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollment.updatetransaction.UpdateTransResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.enrollmentstatusupdate.UpdateStatusResProxyV2;
import com.opl.jns.ere.domain.*;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.ChannelIdEnumV2;
import com.opl.jns.ere.enums.EnrollTypeEnum;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeReqProxy;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeResProxy;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.service.publish.common.EnrollService;
import com.opl.jns.registry.service.service.publish.common.impl.EnrollAbstract;
import com.opl.jns.registry.service.utils.GetterSetter;
import com.opl.jns.registry.service.utils.v2.EnrollmentValidation;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.UserRoleMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
@Transactional
@Qualifier("EnrollmentServiceImplV2")
public class EnrollmentServiceImplV2 extends EnrollAbstract implements EnrollService {

	public static final String IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER = "It seems an error occurred in De-dupe response; please try again later.";

	@Autowired
	private EnrollmentValidation enrollmentValidation;

	@Autowired
	private GetterSetter getterSetter;
	
	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private CommitTransactionalServiceImplV2 commitTransactionalServiceImplV2;
	
	@Autowired
	private EreCommonService ereCommonService;

	/**
	 * OTHER CHANNEL DE-DUPE CHECK
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U deDupe(T in, Long orgId) {
		return (U) enDeDupe(in, orgId);
	}

	/**
	 * OTHER CHANNEL ENROLLMENT DETAILS
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U enroll(T in, Long orgId) {
		try {

			EnrollmentReqProxyV2 enrollmentDetails = (EnrollmentReqProxyV2) in;

			/* VALIDATE CUSTOMER DETAILS AND GUARDIAN DETAILS */
			String validateMsg = enrollmentValidation.checkEnrollmentDetailsCommonValidations(
					enrollmentDetails.getCustomerDetails(), enrollmentDetails.getKycDetails(),
					enrollmentDetails.getOtherDetails().getScheme());
			String validateMsgV2 = enrollmentValidation.checkEnrollmentDetailsValidationsV2(enrollmentDetails);

			/* RETURN IF VALIDATION FALSE */
			if (!OPLUtils.isObjectNullOrEmpty(validateMsg) || !OPLUtils.isObjectNullOrEmpty(validateMsgV2)) {
				log.error("ENROLLMENTDETAILS FROM REQUEST-> {} ",
						MultipleJSONObjectHelper.getStringfromObject(enrollmentDetails));
				return (U) new EnrollmentResProxyV2(
						!OPLUtils.isObjectNullOrEmpty(validateMsg) ? validateMsg
								: !OPLUtils.isObjectNullOrEmpty(validateMsgV2) ? validateMsgV2 : Constants.FAILED,
						new EnrollmentDataResProxyV2(false, "", ""), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getOtherDetails())
					|| OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getOtherDetails().getScheme())) {
				log.error("SCHEME DETAILS NOT FOUND");
				return (U) new EnrollmentResProxyV2("Scheme Details not found.",
						new EnrollmentDataResProxyV2(false, "", ""), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			int schemeId = SchemeMaster.getByCode(enrollmentDetails.getOtherDetails().getScheme()).getId().intValue();

			EnrollBeforeReqProxy beforeReqProxy = EnrollBeforeReqProxy.builder().orgId(orgId)
					.schemeId(Long.valueOf(schemeId)).branchCode(enrollmentDetails.getOtherDetails().getBranchCode())
					.branchIFSC(enrollmentDetails.getOtherDetails().getBranchIFSC()).cif(enrollmentDetails.getCustomerDetails().getCif())
					.accNo(enrollmentDetails.getCustomerDetails().getAccountNumber()).build();

			EnrollBeforeResProxy beforeValidate = this.enrollBefore(beforeReqProxy);
			if (!beforeValidate.isProceed()) {
				return (U) new EnrollmentResProxyV2(beforeValidate.getMessage(),
						beforeValidate.getDataResProxyV2() != null ? beforeValidate.getDataResProxyV2()
								: new EnrollmentDataResProxyV2(false, "", ""),
						beforeValidate.getStatus(), Boolean.FALSE);
			}

			/* SET APPLICATION MASTER TABLE VALUES */
			ApplicationMasterV3 applicationMaster = new ApplicationMasterV3();
			applicationMaster.setSchemeId(schemeId);
			applicationMaster.setAccountNumber(enrollmentDetails.getCustomerDetails().getAccountNumber());
			applicationMaster.setCif(enrollmentDetails.getCustomerDetails().getCif());
			applicationMaster.setOrgId(orgId);
			applicationMaster.setBranchId(beforeValidate.getBranchId());
			applicationMaster.setInsurerOrgId(beforeValidate.getInsurerOrgId());
			applicationMaster.setCreatedDate(new Date());
			applicationMaster.setEnrollType(EnrollTypeEnum.NEW_ENROLLMENT.getId());

			/* APPLICATION MASTER OTHERS DETAILS */
			ApplicationMasterOtherDetailsV3 otherDetails = new ApplicationMasterOtherDetailsV3();
			BeanUtils.copyProperties(enrollmentDetails.getOtherDetails(), otherDetails);
			otherDetails.setApplicationMaster(applicationMaster);
			otherDetails.setRuralUrbanSemi(enrollmentDetails.getOtherDetails().getRuralUrban());
			otherDetails.setSchemeId(schemeId);
			otherDetails.setOrgId(orgId);
			otherDetails.setBranchRoId(beforeValidate.getBranchRoId());
			otherDetails.setBranchZoId(beforeValidate.getBranchZoId());
			otherDetails.setBranchCityId(beforeValidate.getBranchCityId());
			otherDetails.setBranchStateId(beforeValidate.getBranchStateId());
			otherDetails.setRuralUrbanId(beforeValidate.getRuralUrbanId());
			if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getOtherDetails().getChannelId())) {
				otherDetails.setChannel(
						ChannelIdEnumV2.fromValue(enrollmentDetails.getOtherDetails().getChannelId()).getId());
			}else {
				otherDetails.setChannel(ChannelIdEnum.OTHER.getId());
			}
			otherDetails.setAppCreatedDate(applicationMaster.getCreatedDate());

			applicationMaster.setApplicationMasterOtherDetails(otherDetails);

			/* APPLICANT INFO DETAILS SAVE */
			ApplicantInfo applicantInfo = getterSetter.prepareApplicationInfoCommonWhileSaveEnrollment(applicationMaster,
					enrollmentDetails.getCustomerDetails(),enrollmentDetails.getKycDetails());
			applicationMaster.setApplicantInfo(applicantInfo);
			applicantInfo = getterSetter.prepareApplicationInfoWhileSaveEnrollmentV2(applicationMaster,enrollmentDetails);
			applicationMaster.setApplicantInfo(applicantInfo);

			/* NOMINEE AND GAURDIAN DETAILS SET */
			List<NomineeDetails> nomineeMasters = getterSetter
					.prepareNomineeDetailsWhileSaveEnrollmentV2(applicationMaster, enrollmentDetails);
			applicationMaster.setNomineeDetails(nomineeMasters);

			EnrollBeforeResProxy enrollAfter = this.enrollAfter(applicationMaster);
			return (U) new EnrollmentResProxyV2(enrollAfter.getMessage(), enrollAfter.getDataResProxyV2(),
					enrollAfter.getStatus(), Boolean.TRUE);

		} catch (Exception e) {
			log.error("EXCEPTION IS GETTING WHILE SAVE APPLICATION_MASTER_DETAILS ----> ", e);
			return (U) new EnrollmentResProxyV2(Constants.FAILED, new EnrollmentDataResProxyV2(Boolean.FALSE, "", ""),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	/**
	 * OTHER CHANNEL UPDATE STATUS
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U updateStatus(T t) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(t)) {
				return (U) new UpdateStatusResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			UpdateStatusReqProxyV2 statusApiDetails = (UpdateStatusReqProxyV2) t;
			return (U) enUpdateStatus(null,null,null,statusApiDetails.getUrn(),statusApiDetails.getStatus(),statusApiDetails.getReason(),null);
		} catch (Exception e) {
			log.error("EXCEPTION IS GETTING WHILE UPDATE STATUS ---> ", e);
			return (U) new UpdateStatusResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
	
	

	/**
	 * UPDATE TRANSACTION DETAILS FROM OTHER CHANNEL API
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U updateTransactionDetailsAndGetCoiFiles(T in, U u) throws Exception {
		Long applicationId = null;
		try {
			
			UpdateTransResProxyV2 coiResponse = (UpdateTransResProxyV2) u;
			UpdateTransReqProxyV2 transactionRequest = (UpdateTransReqProxyV2) in;

			/* VALIDATE TRANSACTION REQUEST */
			String errorMsg = enrollmentValidation.validateTransactionDetailCommonValidation(transactionRequest);
			if (!OPLUtils.isObjectNullOrEmpty(errorMsg))
				return (U) new UpdateTransResProxyV2(errorMsg, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			
			coiResponse = enrollmentValidation.validateTransactionDetailV2(transactionRequest);
			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
				return (U) coiResponse;

			/* FIND APPLICATION MASTER BY URN */
			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findFirstByUrnAndIsActiveTrue(transactionRequest.getUrn());

			/* VALIDATE APPLICATION MASTER DETAIL AND INTERNAL DE-DUPE CHECK */
			coiResponse = this.callValidateApplicationMasterDetailV2(applicationMaster, transactionRequest);
			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
				return (U) coiResponse;
			
			applicationId = applicationMaster.getId();
			
			if(!Objects.equals(Source.OTHER_CHANNEL.getId(), applicationMaster.getApplicationMasterOtherDetails().getSource())) {
				return (U) new UpdateTransResProxyV2("The application details are not found in the Other Channel mode", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* FETCH CURRENT YEAR POLICY INSURER DETAILS */
			InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(Long.valueOf(applicationMaster.getSchemeId()),
					applicationMaster.getOrgId(), new Date(), new Date());

			if (!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails) && !OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getMasterPolicyNo())
					&& !currentInsurerDetails.getMasterPolicyNo().equalsIgnoreCase(transactionRequest.getMasterPolicyNumber())) {
				log.error("END SAVE TRANSACTION DETAILS (INVALID MASTER POLICY NUMBER) --------->" + applicationId);
				return (U) new UpdateTransResProxyV2("Invalid Master Policy Number !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* PARSE TRANSACTION DATE */
			Date tranTimeStamp = DateUtils.parse(transactionRequest.getTransactionTimeStamp(), DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
			if (OPLUtils.isObjectNullOrEmpty(tranTimeStamp)) {
				log.error("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !! " + transactionRequest.getTransactionTimeStamp());
				return (U) new UpdateTransResProxyV2("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			/**if transactionTimeStamp date is after current date*/
			if(tranTimeStamp.after(new Date())) {
				return (U) new UpdateTransResProxyV2("Transaction date cannot be future dated. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			/**if transactionTimeStamp date is before policy start date*/
			if(!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getPolicyStartDate()) && tranTimeStamp.before(currentInsurerDetails.getPolicyStartDate())) {
				return (U) new UpdateTransResProxyV2("Transaction date cannot be before the policy year date. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* FETCH HO USER ID FROM USER TABLE TO SET AS CREATED BY */
			Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(applicationMaster.getOrgId(), UserRoleMaster.HEAD_OFFICE.getId());
			Date curruntDate = new Date();

			/* SET TRANSACTION DETAIL OBJECT */
			TransactionDetailsV3 transactionDetails = getterSetter.setTransactionDetailsCommon(transactionRequest, curruntDate, tranTimeStamp, userId, currentInsurerDetails,applicationMaster);
			transactionDetails = getterSetter.setTransactionDetailsV2(transactionRequest,transactionDetails);

			/* SET APPLICATION MASTER COMPLETED DATA POINTS */
			applicationMaster = getterSetter.updateApplicationMaster(applicationMaster, curruntDate, tranTimeStamp, userId, currentInsurerDetails, transactionRequest);
			transactionDetails.setApplicationMaster(applicationMaster);
			applicationMaster.setLastTransactionDetails(transactionDetails);

			/* GENERATE COI */
			byte[] coiByte = this.getCOI(applicationMaster);
			if (!OPLUtils.isObjectNullOrEmpty(coiByte) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getCoiStorageId())) {
				/* SAVE APPLICATION MASTER */
				applicationMaster = commitTransactionalServiceImplV2.applicationMasterSave(applicationMaster);
				
				ereCommonService.insertApplcationPushStatus(applicationId);
				UpdateTransResProxyV1 transResPxyV1 = this.pushApplicationAndGenerateCoi(applicationMaster, coiByte);
				return (U) new UpdateTransResProxyV2(transResPxyV1.getMessage(),
						new COIDocsProxyV2(transResPxyV1.getCoi().getDocumentType(),
								transResPxyV1.getCoi().getContentType(), transResPxyV1.getCoi().getDocument()),
						transResPxyV1.getStatus(), transResPxyV1.getSuccess());
			}
			log.error("COI BYTES IS NULL OR EMPTY ------------>" + applicationMaster.getId());
			return (U) new UpdateTransResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		} catch (Exception e) {
			log.error("END SAVE TRANSACTION DETAILS (ERROR) --------->" + applicationId, e);
			return (U) new UpdateTransResProxyV2(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}
	
}
