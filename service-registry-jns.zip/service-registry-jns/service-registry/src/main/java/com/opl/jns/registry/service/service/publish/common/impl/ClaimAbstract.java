package com.opl.jns.registry.service.service.publish.common.impl;
//package com.opl.service.registry.jns.service.publish.common.impl;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Map;
//import java.util.Objects;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.BeanUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Component;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.client.RestTemplate;
//
//import com.opl.bucket.storage.utils.BucketStorageUtils;
//import com.opl.jns.common.api.dms.exception.DocumentException;
//import com.opl.jns.common.api.dms.model.AnsProductDocumentResponse;
//import com.opl.jns.common.api.dms.model.DocumentRequest;
//import com.opl.jns.common.api.dms.model.DocumentResponse;
//import com.opl.jns.common.api.dms.model.MultipartObjectRequest;
//import com.opl.jns.common.api.dms.model.StorageDetailsResponse;
//import com.opl.jns.common.client.dms.DMSClient;
//import com.opl.jns.ere.domain.ClaimMasterV3;
//import com.opl.jns.ere.domain.ClaimStatusWebhookAudit;
//import com.opl.jns.ere.domain.PayloadAuditWebHook;
//import com.opl.jns.ere.domain.PushReTryAudit;
//import com.opl.jns.ere.enums.CauseOfDeathDisability;
//import com.opl.jns.ere.enums.NatureOfLoss;
//import com.opl.jns.ere.enums.TypeOfDisability;
//import com.opl.jns.ere.enums.WebhookMasterEnum;
//import com.opl.jns.ere.repo.ClaimMasterRepoV3;
//import com.opl.jns.ere.repo.ClaimStatusWebhookAuditRepository;
//import com.opl.jns.ere.repo.PayloadAuditWbRepo;
//import com.opl.jns.ere.repo.PushReTryAuditRepo;
//import com.opl.jns.ere.utils.WebHookPayloadProxy;
//import com.opl.jns.published.lib.domain.ApiConfigMaster;
//import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
//import com.opl.jns.published.utils.common.CommonResponse;
//import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
//import com.opl.jns.published.utils.common.OPLUtils;
//import com.opl.jns.published.utils.common.RegCommonResponse;
//import com.opl.jns.published.utils.common.RegistryResponse;
//import com.opl.jns.utils.enums.ClaimStageMaster;
//import com.opl.jns.utils.enums.ClaimStatus;
//import com.opl.jns.utils.enums.SchemeMaster;
//import com.opl.publish.common.RegistryReqProxy;
//import com.opl.publish.v1.claimUpload.ClaimDocumentV1;
//import com.opl.publish.v2.claimDetails.ClaimDetailsResProxyV2;
//import com.opl.service.registry.jns.utils.DeDupeRegistryAPIClient;
//import com.opl.service.registry.jns.utils.RegistryUtils;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Component
//@Transactional
//@Slf4j
//public abstract class ClaimAbstract {
//	
//	@Autowired
//	private ClaimMasterRepoV3 claimMasterRepo;
//	
//	@Autowired
//	private DMSClient dmsClient;
//
//	@Autowired
//	private PushReTryAuditRepo pushReTryAuditRepo;
//
//	@Autowired
//	private DeDupeRegistryAPIClient deDupeRegistryAPIClient;
//	
//	@Autowired
//	private ApiConfigMasterRepo configRepo;
//	
//	@Autowired
//	private BucketStorageUtils bucketStorageUtils;
//
//	@Autowired
//	private PayloadAuditWbRepo auditWbRepo;
//
//	@Autowired
//	private ClaimStatusWebhookAuditRepository claimStatusWebhookAuditRepository;
//	
//	private static final String WH_DOC = "WH_DOC_";
//	
//	protected ClaimDetailsResProxyV2 deDupeLogic(ClaimMasterV3 claimMaster) {
//		// DE-DUPE NEED TO CHANGE AS PER SCHEME BASE AND DISCUSSION WITH HRIDAY
//		if (claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_FORM.getStageId()
//				|| claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()) {
//			return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_INITIATED_MSG, HttpStatus.OK.value(), false);
//		} else if (claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
//			if (SchemeMaster.PMJJBY.getId().intValue() == claimMaster.getApplicationMaster().getSchemeId()) {
//				return dedupeForPMJJBY(claimMaster);
//			} else {
//				return dedupeForPmsby(claimMaster);
//			}
//		}
//		return new ClaimDetailsResProxyV2("", HttpStatus.OK.value(), true);
//	}
//	
//	private ClaimDetailsResProxyV2 dedupeForPmsby(ClaimMasterV3 claimMaster) {
//		// NATURE OF LOASS 1 : DEATH && 2 : DISABILITY
//		if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus())
//				&& !com.opl.jns.utils.common.OPLUtils
//						.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId())
//				&& claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()
//						.equals(CauseOfDeathDisability.ACCIDENTAL.getId())
//				&& claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
//			return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG,
//					HttpStatus.OK.value(), false);
//		}
//		if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())
//				&& claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
//			if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//				return new ClaimDetailsResProxyV2(RegistryUtils.DEATH + " " + RegistryUtils.CLAIM_ALREADY_PAID_MSG,
//						HttpStatus.OK.value(), false);
//			}
//			if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus())) {
//				return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG,
//						HttpStatus.OK.value(), false);
//			}
//			if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getClaimStatus())) {
//				return new ClaimDetailsResProxyV2(
//						RegistryUtils.DEATH + " " + RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.OK.value(),
//						false);
//			}
//		} else {
//			if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())
//					&& claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
//					&& !com.opl.jns.utils.common.OPLUtils
//							.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())
//					&& claimMaster.getClaimDetail().getTypeOfDisablityId()
//							.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
//				if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//					return new ClaimDetailsResProxyV2(
//							RegistryUtils.TOTAL_DISABILITY + " " + RegistryUtils.CLAIM_ALREADY_PAID_MSG,
//							HttpStatus.OK.value(), false);
//				}
//				if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getClaimStatus())) {
//					return new ClaimDetailsResProxyV2(
//							RegistryUtils.TOTAL_DISABILITY + " " + RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG,
//							HttpStatus.OK.value(), false);
//				}
//			} else {
//				List<Integer> statusList = new ArrayList<>();
//				statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
//				statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//				Long count = claimMasterRepo.countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(
//						claimMaster.getApplicationMaster().getId(), statusList);
//				if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(count) && count > RegistryUtils.LONG_2) {
//					return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG,
//							HttpStatus.OK.value(), false);
//				}
//				// ------------------------------ NEED TO HANDLE THIS SCENARIO
//				return new ClaimDetailsResProxyV2(SchemeMaster.PMSBY.getShortName(), HttpStatus.OK.value(), true);
//			}
//		}
//		List<ClaimMasterV3> claimMastersLst = claimMasterRepo
//				.findByApplicationMasterIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId());
//		Boolean isProcced = false;
//		if (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())
//				&& claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
//				&& claimMaster.getClaimDetail().getTypeOfDisablityId()
//						.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
//			for (ClaimMasterV3 master : claimMastersLst) {
//				if (ClaimStatus.CLAIM_REJECTED.getId().equals(master.getClaimStatus())
//						&& (!com.opl.jns.utils.common.OPLUtils
//								.isObjectNullOrEmpty(master.getClaimDetail().getNatureOfLossId())
//								&& master.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
//								&& !com.opl.jns.utils.common.OPLUtils
//										.isObjectNullOrEmpty(master.getClaimDetail().getTypeOfDisablityId()))) {
//					isProcced = true;
//				}
//			}
//		}
//		if (isProcced.equals(Boolean.TRUE)) {
//			return new ClaimDetailsResProxyV2(SchemeMaster.PMSBY.getShortName(), HttpStatus.OK.value(), true);
//		}
//		return new ClaimDetailsResProxyV2("", HttpStatus.OK.value(), true);
//	}
//
//	private static ClaimDetailsResProxyV2 dedupeForPMJJBY(ClaimMasterV3 claimMaster) {
//		if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus()) && claimMaster.getClaimDetail()
//				.getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId())) {
//			return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG,
//					HttpStatus.OK.value(), false);
//		} else if (ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus()) && claimMaster
//				.getClaimDetail().getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId())) {
//			return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ALREADY_REJETED_DEATH_MSG, HttpStatus.OK.value(),
//					false);
//		}
//
//		long dateDiff = com.opl.jns.utils.common.DateUtils.dateDiff(claimMaster.getClaimDetail().getDateOfDeath(),
//				claimMaster.getApplicationMaster().getEnrollmentDate());
//		if (dateDiff > 30) {
//			if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//				return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_DEATH_PAID_MSG, HttpStatus.OK.value(), false);
//			} else {
//				return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_DEATH_MSG, HttpStatus.OK.value(), false);
//			}
//		} else {
//			if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//				return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ACCIDENTIAL_PAID_MSG, HttpStatus.OK.value(),
//						false);
//			} else {
//				return new ClaimDetailsResProxyV2(RegistryUtils.CLAIM_ACCIDENTIAL_MSG, HttpStatus.OK.value(), false);
//			}
//		}
//	}
//	
//	@SuppressWarnings("unchecked")
//	protected <T extends RegistryReqProxy, U extends RegCommonResponse> U documentUploadAndManageProcess(List<T> doc,Long claimRefId) throws DocumentException, IOException {
//		ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimRefId);
//		DocumentResponse docResponse = null;
//		String referenceId = WH_DOC + OPLUtils.generateUUID();
//		try {
//		// here claimReferenceId is claimId from claim master - ere
//		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//			log.error("ClaimMaster data not found");
//			return (U) new RegistryResponse("ClaimMaster data not found", HttpStatus.NOT_FOUND.value(), Boolean.FALSE);
//		}
//
//		/** if claim already registered */
//		if (claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()
//				&& !Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_IN_PROGRESS.getId())
//				&& !Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
//			log.error("claim already registered");
//			return (U) new RegistryResponse("claim already registered", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}
//		DocumentRequest documentRequest = new DocumentRequest();
//		documentRequest.setApplicationId(claimMaster.getApplicationMaster().getId());
//		documentRequest.setSchemeId(claimMaster.getApplicationMaster().getSchemeId());
//		documentRequest.setClaimId(claimMaster.getId());
//
//		if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMJJBY.getId().intValue())
//			documentRequest.setDisabilityTypeId(
//					OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) ? null
//							: claimMaster.getClaimDetail().getCauseOfDeathDisabilityId());
//		else {
//			documentRequest.setDisabilityTypeId(
//					OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) ? null
//							: claimMaster.getClaimDetail().getNatureOfLossId());
//		}
//		List<ClaimDocumentV1> claimUploadDocumentsLst = (List<ClaimDocumentV1>) doc;
//		DocumentResponse documentResponse = dmsClient.findTypeIdByDisabilityTypeIdAndSchemeId(documentRequest);
//		if (!OPLUtils.isObjectNullOrEmpty(documentResponse.getDataList())) {
//			List<AnsProductDocumentResponse> masterList = MultipleJSONObjectHelper.getListOfObjects(
//					MultipleJSONObjectHelper.getStringfromListOfObject(documentResponse.getDataList()), null,
//					AnsProductDocumentResponse.class);
//			List<MultipartObjectRequest> multiPartObjList = new ArrayList<>();
////			StringBuilder s1 = new StringBuilder();
//
//			List<Long> reqDocIds = claimUploadDocumentsLst.stream()
//					.map(ClaimDocumentV1::getDocumentId).collect(Collectors.toList());
//
//			if (!OPLUtils.isListNullOrEmpty(masterList)) {
//				List<AnsProductDocumentResponse> docList = null;
//
//				if ((OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame())
//						|| claimMaster.getIsClaimantSame() == Boolean.FALSE)) {
//					docList = masterList.stream()
//							.filter(x -> !x.getDocId().equals(14L) && !x.getDocId().equals(15L))
//							.collect(Collectors.toList());
//				} else {
//					docList = masterList;
//				}
//				if (!OPLUtils.isListNullOrEmpty(docList)) {
//					StringBuilder missingDoc = new StringBuilder();
//					Map<Integer, List<AnsProductDocumentResponse>> collectMap = docList.stream()
//							.collect(Collectors.groupingBy(AnsProductDocumentResponse::getGroupId));
//
//					boolean isAllDoc = true;
//					if (!OPLUtils.isObjectNullOrEmpty(collectMap)
//							&& !OPLUtils.isListNullOrEmpty(collectMap.values())) {
//						for (List<AnsProductDocumentResponse> responseList : collectMap.values()) {
//							if (!OPLUtils.isListNullOrEmpty(responseList)) { // isAllDoc &&
//								if (responseList.size() == 1) {
//									if (!reqDocIds.contains(responseList.get(0).getDocId())
//											&& responseList.get(0).getIsMandatory()) {
//										isAllDoc = false;
//										missingDoc.append(responseList.get(0).getDocId() + " - "
//												+ responseList.get(0).getDocumentName() + ", ");
//									}
//								} else {
////									List<Long> groupDocIdList = responseList.stream().map(x -> x.getDocId()).collect(Collectors.toList());
//									boolean checkGroupDocUpload = false;
//									for (AnsProductDocumentResponse response : responseList) {
//										if (!checkGroupDocUpload) {
//											if (reqDocIds.contains(response.getDocId())
//													&& response.getIsMandatory()) {
//												if (9L == response.getDocId() && reqDocIds.contains(9L)) { // 9 ->
//																											// FIR/Panchnama
//													List<Long> docIdList = responseList.stream()
//															.filter(x -> x.getDocId() != response.getDocId())
//															.map(x -> x.getDocId()).collect(Collectors.toList());
//													if (!OPLUtils.isListNullOrEmpty(docIdList)) {
//														Optional<Long> first = docIdList.stream()
//																.filter(x -> x == 21L).findFirst();
//														if (first.isPresent() && reqDocIds.contains(21L)) { // 21 ->
//																											// Post
//																											// Mortem
//																											// Report
//															checkGroupDocUpload = true;
//															break;
//														}
//													}
//												} else {
//													checkGroupDocUpload = true;
//													break;
//												}
//											}
//										}
//									}
//									if (!checkGroupDocUpload && responseList.get(0).getIsMandatory()) {
//										int index = 0;
//										for (AnsProductDocumentResponse response : responseList) {
//											if (9L == response.getDocId() && reqDocIds.contains(9L)) { // 9 ->
//																										// FIR/Panchnama
//												if (index == 0
//														&& !OPLUtils.isObjectNullOrEmpty(response.getTitleName())) {
//													missingDoc.append(response.getTitleName() + " -> ");
//												}
//												List<Long> docIdList = responseList.stream()
//														.filter(x -> x.getDocId() != response.getDocId())
//														.map(x -> x.getDocId()).collect(Collectors.toList());
//												if (!OPLUtils.isListNullOrEmpty(docIdList)) {
//													Optional<Long> first = docIdList.stream().filter(x -> x == 21L)
//															.findFirst();
//													if (first.isPresent() && reqDocIds.contains(21L)) { // 21 ->
//																										// Post
//																										// Mortem
//																										// Report
//														missingDoc.append(response.getDocId() + " - "
//																+ response.getDocumentName() + ", ");
//													}
//												}
//											} else {
//												missingDoc.append(response.getDocId() + " - "
//														+ response.getDocumentName() + ", ");
//											}
//											index++;
//										}
//										isAllDoc = false;
//									}
////									 isAllDoc = checkGroupDocUpload;
//								}
//							}
//						}
////						return new RegistryResponse(missingDoc.toString(), "Missing Documents: " + missingDoc, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//					}
//
//					if (!isAllDoc && !OPLUtils.isObjectNullOrEmpty(missingDoc)) { // !isAllDoc &&
//						String msg = missingDoc.toString();
//						msg = msg.substring(0, msg.length() - 2);
//						log.error("Please upload All Mandatory Documents");
//						log.info("Missing Documents: " + msg);
//						return (U) new RegistryResponse("Missing Documents:===>    " + msg,
//								HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//					}
//
//					docList.stream().forEach(document -> {
//						prepareForUploadDocs(claimUploadDocumentsLst, documentRequest, multiPartObjList, document);
//					});
//
//					/** Upload documents */
//					docResponse = dmsClient.uploadMultipleFileWithDocMappingIds(multiPartObjList);
//					if (docResponse.getStatus() == 200 && !OPLUtils.isListNullOrEmpty(docResponse.getDataList())) {
//						if (!claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
//							/** push complete claim details */
//							CommonResponse response = updateClaimMaster(claimMaster.getId(),
//									RegistryUtils.PUSH_CLAIM_DATA);
//							if (OPLUtils.isObjectNullOrEmpty(response) && response.getStatus() == 200) {
//								claimMaster.setIsPushed(Boolean.TRUE);
//								claimMaster.setModifiedDate(new Date());
//								claimMasterRepo.save(claimMaster);
//							} else {
//								/* IN CASE ERROR IN CLAIM PUSHED THE ADD TO PUSH RETRY */
//								PushReTryAudit pushReTryAudit = new PushReTryAudit();
//								pushReTryAudit.setApplicationId(claimMaster.getApplicationMaster().getId());
//								pushReTryAudit.setClaimId(claimMaster.getId());
//								pushReTryAudit.setReTryCount(RegistryUtils.INT_0);
//								pushReTryAudit.setCreatedDate(new Date());
//								pushReTryAudit.setType(RegistryUtils.PUSH_RE_TRY_CLAIM);
//								pushReTryAudit.setIsPushed(Boolean.FALSE);
//								pushReTryAudit.setMessage(response.getMessage());
//								pushReTryAuditRepo.save(pushReTryAudit);
//							}
//						} else {
//							/** update the re-uploaded docs in table */
//							List<Long> storageList = new ArrayList<>(docResponse.getDataList().size());
//							for (Object obj : docResponse.getDataList()) {
//								@SuppressWarnings("rawtypes")
//								StorageDetailsResponse objectFromMap = MultipleJSONObjectHelper
//										.getObjectFromMap((Map) obj, StorageDetailsResponse.class);
//								storageList.add(objectFromMap.getId());
//							}
//
//							claimMaster.setQueriedStorageId(!storageList.isEmpty()
//									? storageList.toString().replace('[', ' ').replace(']', ' ')
//									: null);
//							claimMasterRepo.save(claimMaster);
//
//							/** re-push the docs only */
//							rePushDocs(claimMaster.getId());
//
//							/** push data dd registry through python */
//							try {
//								deDupeRegistryAPIClient.callPushClaimRequest(claimMaster);
//							} catch (Exception e) {
//								log.error("Error while push claim python API",
//										claimMaster.getApplicationMaster().getId(), e.getMessage());
//							}
//
//						}
//						return (U) new RegistryResponse("Uploaded Successfully", docResponse.getDataList(),
//								HttpStatus.OK.value(), Boolean.TRUE);
//					}
//				}
//			}
//			log.error("Something went wrong");
//			return (U) new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
//					Boolean.FALSE);
//		} else {
//			log.error("Data not found");
//			return (U) new RegistryResponse("Invalid Requested Document details.", HttpStatus.BAD_REQUEST.value(),
//					Boolean.FALSE);
//		}
//		}catch (Exception e) {
//			log.error("Exception While claim upload document :: ", e);
//			return (U) new RegistryResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
//					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//		}finally {
//			if (!OPLUtils.isObjectNullOrEmpty(docResponse)
//					&& claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
//				// WEBHOOK AUDITING
//				ClaimStatusWebhookAudit webhookAudit = webhookAudit(claimMaster.getId(), claimMaster.getClaimStatus(),
//						!OPLUtils.isObjectNullOrEmpty(docResponse) ? docResponse.getStatus()
//								: HttpStatus.INTERNAL_SERVER_ERROR.value(),
//						WebhookMasterEnum.UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_OTHER_CHANEL_API.getId(),
//						claimMaster.getApplicationMaster().getUrn());
//
//				// BUCKET AUDITING
//				updateBucketLogs(webhookAudit.getId(),
//						MultipleJSONObjectHelper.getStringfromObject(doc),
//						MultipleJSONObjectHelper.getStringfromObject(docResponse), referenceId);
//			}
//		}
//	}
//	
//	private static void prepareForUploadDocs(List<ClaimDocumentV1> claimUploadDocumentsLst,
//			DocumentRequest documentRequest, List<MultipartObjectRequest> multiPartObjList,
//			AnsProductDocumentResponse document) {
//		claimUploadDocumentsLst.stream().forEach(RequestDoc -> {
//			if (document.getDocId().equals(RequestDoc.getDocumentId())) {
//				DocumentRequest docRequest = new DocumentRequest();
//				BeanUtils.copyProperties(documentRequest, docRequest);
//				docRequest.setProductDocumentMappingId(document.getProDocMapId());
//				docRequest.setDocumentId(RequestDoc.getDocumentId());
//				docRequest.setDocName(document.getDocumentName());
//				MultipartObjectRequest objectReq = new MultipartObjectRequest(RequestDoc.getDocument(), docRequest);
//				multiPartObjList.add(objectReq);
//			}
//		});
//	}
//	
//	protected void rePushDocs(Long claimId) {
//		/** re-push the docs only */
//		updateClaimMaster(claimId, RegistryUtils.PUSH_CLAIM_REVISED_DOCS);
//	}
//
//	private CommonResponse updateClaimMaster(Long claimId, String urlPart) {
//		ApiConfigMaster pushPullApi = configRepo.findByCodeAndIsActiveTrue(urlPart);
//		if (null != pushPullApi) {
//			String url = pushPullApi.getValue() + "/" + claimId;
//			try {
//				HttpHeaders headers = new HttpHeaders();
//				headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//				headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
//				headers.set("isDecrypt", "true");
//				headers.add("Accept", "application/json");
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				HttpEntity<?> entity = new HttpEntity<>(headers);
//				RestTemplate restTemplate = new RestTemplate();
//				log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
//				return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
//			} catch (Exception e) {
//				log.error("Exception While calling claim push details api :: ", e);
//			}
//		}
//		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}
//
//	/* COMMON WEBHOOK BUCKET AUDIT FOR REQ RES SAVE */
//	private void updateBucketLogs(Long webHookAuditId, String request, String response, String referenceId) {
//
//		log.info("INSIDE UPDATEBUCKET LOGS FOR REFERENCEID [{}] ", referenceId);
//		PayloadAuditWebHook reqResAudit = new PayloadAuditWebHook();
//		reqResAudit.setLogAudit(webHookAuditId);
//		reqResAudit.setStorageId(referenceId);
//		reqResAudit.setCreatedDate(new Date());
//		reqResAudit.setSuccess(false);
//
//		WebHookPayloadProxy loadProxy = new WebHookPayloadProxy();
//		loadProxy.setRequest(request);
//		loadProxy.setResponse(response);
//		loadProxy.setReferenceId(referenceId);
//		loadProxy.setLogAuditId(webHookAuditId);
//		String upload = bucketStorageUtils.upload(getValue(), loadProxy, referenceId);
//		if (!OPLUtils.isObjectNullOrEmpty(upload)) {
//			reqResAudit.setSuccess(true);
//		}
//		auditWbRepo.save(reqResAudit);
//	}
//
//	// GET BUCKET NAME
//	private String getValue() {
//		return System.getenv("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");
//	}
//
//	/* COMMON WEBHOOK AUDIT FOR BANK AND INSURER */
//	private ClaimStatusWebhookAudit webhookAudit(Long claimId, Integer claimStatus, Integer status,
//			Integer webhookStatusId, String urn) {
//
//		log.info("INSIDE WEBHOOKAUDIT FOR CLAIMID  [{}] ", claimId);
//		/** if audit already record found */
//		ClaimStatusWebhookAudit claimStatusWebhookAudit = claimStatusWebhookAuditRepository
//				.findFirstByClaimIdAndWebhookMasterIdAndIsActiveTrue(claimId, webhookStatusId);
//		if (!OPLUtils.isObjectNullOrEmpty(claimStatusWebhookAudit)) {
//			claimStatusWebhookAuditRepository.isActiveFalseByClaimId(claimId);
//		}
//		ClaimStatusWebhookAudit webhookAuditDmn = new ClaimStatusWebhookAudit();
//		if (OPLUtils.isObjectNullOrEmpty(status)
//				|| (!OPLUtils.isObjectNullOrEmpty(status) && status != com.opl.jns.ere.utils.CommonUtils.INT_200)) {
//			webhookAuditDmn.setIsActive(Boolean.TRUE);
//		} else {
//			webhookAuditDmn.setIsActive(Boolean.FALSE);
//		}
//		webhookAuditDmn.setClaimId(claimId);
//		webhookAuditDmn.setCreatedDate(new Date());
//		webhookAuditDmn.setWebhookStatus(status);
//		webhookAuditDmn.setClaimStatus(claimStatus);
//		webhookAuditDmn.setWebhookMasterId(webhookStatusId);
//		webhookAuditDmn.setUrn(urn);
//		return claimStatusWebhookAuditRepository.save(webhookAuditDmn);
//	}
//}
