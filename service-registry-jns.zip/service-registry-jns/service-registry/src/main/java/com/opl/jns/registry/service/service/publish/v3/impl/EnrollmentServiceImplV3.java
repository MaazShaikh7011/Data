package com.opl.jns.registry.service.service.publish.v3.impl;

import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.jansuraksha.common.RegistryReqProxy;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.enrollment.updatetrans.UpdateTransResProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.COIDocsProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.ere.domain.*;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.DebitStatus;
import com.opl.jns.ere.enums.EnrollTypeEnum;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.enums.EnrollStageMaster;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeReqProxy;
import com.opl.jns.registry.api.publish.common.enroll.EnrollBeforeResProxy;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.service.publish.common.EnrollService;
import com.opl.jns.registry.service.service.publish.common.impl.EnrollAbstract;
import com.opl.jns.registry.service.service.publish.v2.impl.CommitTransactionalServiceImplV2;
import com.opl.jns.registry.service.utils.GetterSetter;
import com.opl.jns.registry.service.utils.v2.EnrollmentValidation;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.UserRoleMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
@Transactional
@Qualifier("EnrollmentServiceImplV3")
public class EnrollmentServiceImplV3 extends EnrollAbstract implements EnrollService {

	public static final String IT_SEEMS_AN_ERROR_OCCURRED_IN_DE_DUPE_RESPONSE_PLEASE_TRY_AGAIN_LATER = "It seems an error occurred in De-dupe response; please try again later.";

	@Autowired
	private EnrollmentValidation enrollmentValidation;

	@Autowired
	private GetterSetter getterSetter;
	
	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private CommitTransactionalServiceImplV2 commitTransactionalServiceImplV2;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	/**
	 * OTHER CHANNEL DE-DUPE CHECK
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U deDupe(T in, Long orgId) {
		return (U) enDeDupe(in, orgId);
	}

	/**
	 * OTHER CHANNEL ENROLLMENT DETAILS
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U enroll(T in, Long orgId) {
		try {

			EnrollmentReqProxyV3 enrollmentDetails = (EnrollmentReqProxyV3) in;

			/* VALIDATE CUSTOMER DETAILS AND GUARDIAN DETAILS */
			String validateMsg = enrollmentValidation.checkEnrollmentDetailsCommonValidations(enrollmentDetails.getCustomerDetails(), enrollmentDetails.getKycDetails(),enrollmentDetails.getOtherDetails().getSchemeName());
			String validateMsgV3 = enrollmentValidation.checkEnrollmentDetailsValidationsV3(enrollmentDetails);

			/* RETURN IF VALIDATION FALSE */
			if (!OPLUtils.isObjectNullOrEmpty(validateMsg) || !OPLUtils.isObjectNullOrEmpty(validateMsgV3)) {
				log.error("ENROLLMENTDETAILS FROM REQUEST-> {} ",
						MultipleJSONObjectHelper.getStringfromObject(enrollmentDetails));
				String validMsg = !OPLUtils.isObjectNullOrEmpty(validateMsg) ? validateMsg : !OPLUtils.isObjectNullOrEmpty(validateMsgV3) ? validateMsgV3 : Constants.FAILED;
				return (U) new EnrollmentResProxyV3(validMsg,HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			if (OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getOtherDetails())
					|| OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getOtherDetails().getSchemeName())) {
				log.error("SCHEME DETAILS NOT FOUND");
				return (U) new EnrollmentResProxyV3("Scheme Details not found.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			int schemeId = SchemeMaster.getByCode(enrollmentDetails.getOtherDetails().getSchemeName()).getId().intValue();

			EnrollBeforeReqProxy beforeReqProxy = EnrollBeforeReqProxy.builder().orgId(orgId)
					.schemeId(Long.valueOf(schemeId)).branchCode(enrollmentDetails.getOtherDetails().getBranchCode())
					.branchIFSC(enrollmentDetails.getCustomerDetails().getCustomerIFSC())
					.cif(enrollmentDetails.getCustomerDetails().getCif())
					.accNo(enrollmentDetails.getCustomerDetails().getAccountNumber()).build();

			EnrollBeforeResProxy beforeValidate = this.enrollBefore(beforeReqProxy);
			if (!beforeValidate.isProceed()) {
				if (!OPLUtils.isObjectNullOrEmpty(beforeValidate.getMessage())
						&& !beforeValidate.getMessage().equals(Constants.SUCCESS) && !beforeValidate.getMessage().equals(Constants.FAILED)) {
					return (U) new EnrollmentResProxyV3(beforeValidate.getMessage(),beforeValidate.getStatus(),Boolean.FALSE);
				} else {
					return (U) new EnrollmentResProxyV3(beforeValidate.getDataResProxyV2().getDeDupeMsg(),
							beforeValidate.getStatus(), Boolean.FALSE, beforeValidate.getDataResProxyV2().getUrn());
				}
			}

			/* SET APPLICATION MASTER TABLE VALUES */
			ApplicationMasterV3 applicationMaster = new ApplicationMasterV3();
			applicationMaster.setSchemeId(schemeId);
			applicationMaster.setAccountNumber(enrollmentDetails.getCustomerDetails().getAccountNumber());
			applicationMaster.setCif(enrollmentDetails.getCustomerDetails().getCif());
			applicationMaster.setOrgId(orgId);
			applicationMaster.setBranchId(beforeValidate.getBranchId());
			applicationMaster.setInsurerOrgId(beforeValidate.getInsurerOrgId());
			applicationMaster.setCreatedDate(new Date());
			applicationMaster.setEnrollType(EnrollTypeEnum.NEW_ENROLLMENT.getId());

			/* APPLICATION MASTER OTHERS DETAILS */
			ApplicationMasterOtherDetailsV3 otherDetails = new ApplicationMasterOtherDetailsV3();
			BeanUtils.copyProperties(enrollmentDetails.getOtherDetails(), otherDetails);
			otherDetails.setApplicationMaster(applicationMaster);
			/** RURAL URBAN SAVE DISCUSSION PENDING*/
//			otherDetails.setRuralUrbanSemi(enrollmentDetails.getOtherDetails().getRuralUrban());
			otherDetails.setBranchIFSC(enrollmentDetails.getCustomerDetails().getCustomerIFSC());
			otherDetails.setSchemeId(schemeId);
			otherDetails.setOrgId(orgId);
			otherDetails.setBranchRoId(beforeValidate.getBranchRoId());
			otherDetails.setBranchZoId(beforeValidate.getBranchZoId());
			otherDetails.setBranchCityId(beforeValidate.getBranchCityId());
			otherDetails.setBranchStateId(beforeValidate.getBranchStateId());
			otherDetails.setRuralUrbanId(beforeValidate.getRuralUrbanId());
			otherDetails.setChannel(ChannelIdEnum.valueOf(enrollmentDetails.getOtherDetails().getChannelId()).getId());

			applicationMaster.setApplicationMasterOtherDetails(otherDetails);

			/* APPLICANT INFO DETAILS SAVE */
			ApplicantInfo applicantInfo = getterSetter.prepareApplicationInfoCommonWhileSaveEnrollment(applicationMaster,
					enrollmentDetails.getCustomerDetails(),enrollmentDetails.getKycDetails());
			applicationMaster.setApplicantInfo(applicantInfo);
			applicantInfo = getterSetter.prepareApplicationInfoWhileSaveEnrollmentV3(applicationMaster,enrollmentDetails);
			applicationMaster.setApplicantInfo(applicantInfo);

			/* NOMINEE AND GAURDIAN DETAILS SET */
			List<NomineeDetails> nomineeMasters = getterSetter
					.prepareNomineeDetailsWhileSaveEnrollmentV3(applicationMaster, enrollmentDetails);
			applicationMaster.setNomineeDetails(nomineeMasters);

			EnrollBeforeResProxy enrollAfter = this.enrollAfter(applicationMaster);
			return (U) new EnrollmentResProxyV3(enrollAfter.getMessage(), enrollAfter.getStatus(), Boolean.TRUE,
					enrollAfter.getDataResProxyV2().getUrn());

		} catch (Exception e) {
			log.error("EXCEPTION IS GETTING WHILE SAVE APPLICATION_MASTER_DETAILS ----> ", e);
			return (U) new EnrollmentResProxyV3(Constants.FAILED,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	/**
	 * OTHER CHANNEL UPDATE STATUS
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U updateStatus(T t) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(t)) {
				return (U) new UpdateStatusResProxyV3(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			UpdateStatusReqProxyV3 statusApiDetails = (UpdateStatusReqProxyV3) t;
			return (U) enUpdateStatus(statusApiDetails.getAccountNumber(),statusApiDetails.getDob(),statusApiDetails.getCif(),statusApiDetails.getUrn(),statusApiDetails.getAccountStatus(),statusApiDetails.getReason(),statusApiDetails.getToken());
		} catch (Exception e) {
			log.error("EXCEPTION IS GETTING WHILE UPDATE STATUS ---> ", e);
			return (U) new UpdateStatusResProxyV3(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
	
	/**
	 * UPDATE TRANSACTION DETAILS FROM OTHER CHANNEL API
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends RegistryReqProxy, U extends MainResponse> U updateTransactionDetailsAndGetCoiFiles(T in, U u) throws Exception {
		Long applicationId = null;
		try {
			
			UpdateTransResProxyV3 coiResponse = (UpdateTransResProxyV3) u;
			UpdateTransReqProxyV3 transactionRequest = (UpdateTransReqProxyV3) in;
			
			/* FIND APPLICATION MASTER BY URN */
			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findFirstByUrnAndIsActiveTrue(transactionRequest.getUrn());
			
			/* FETCH HO USER ID FROM USER TABLE TO SET AS CREATED BY */
			Long userId = usersClient.getFirstUserIdByOrgIdAndHoRoleID(applicationMaster.getOrgId(), UserRoleMaster.HEAD_OFFICE.getId());
			
			/* VALIDATE APPLICATION MASTER DETAIL AND INTERNAL DE-DUPE CHECK */
			coiResponse = this.callValidateApplicationMasterDetailV3(applicationMaster, transactionRequest);
			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
				return (U) coiResponse;			
			
			/** DEBIT STATUS WISE MANAGE APPLICATION PREMIUM DEDUCTION FAILED OR REJECTED */
			applicationMaster.setDebitStatus(Integer.parseInt(transactionRequest.getDebitStatus()));
			if (!DebitStatus.SUCEESSFUL_DEBIT.getId().equals(Integer.parseInt(transactionRequest.getDebitStatus()))
					&& !DebitStatus.DUE_TO_API_FAILURE.getId().equals(Integer.parseInt(transactionRequest.getDebitStatus())) ) {
				this.updateStage(applicationMaster, userId, EnrollStageMaster.REJECTED.getStageId(),
						ApplicationStatus.ENROLL_REJECTED.getId(),DebitStatus.fromId(Integer.parseInt(transactionRequest.getDebitStatus())).getValue());
				ereCommonService.checkPremiumDeductionStatus(applicationMaster, userId,EnrollStageMaster.REJECTED.getStageId(),ApplicationStatus.ENROLL_REJECTED.getId());
				return (U) new UpdateTransResProxyV3("Enrolment Rejected - " + "(" + DebitStatus.fromId(Integer.valueOf(transactionRequest.getDebitStatus())).getValue() +")", HttpStatus.OK.value(), Boolean.TRUE);
			}		
			
			if (DebitStatus.DUE_TO_API_FAILURE.getId().equals(Integer.parseInt(transactionRequest.getDebitStatus()))) {
				this.updateStage(applicationMaster, userId, EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId(),
						ApplicationStatus.ENROLL_IN_PROGRESS.getId(),DebitStatus.fromId(Integer.parseInt(transactionRequest.getDebitStatus())).getValue());
				return (U) new UpdateTransResProxyV3("Error occured - Please resume the journey from Transaction Failed", HttpStatus.OK.value(), Boolean.TRUE);
			}
			
			coiResponse = enrollmentValidation.validateTransactionDetailV3(transactionRequest);
			if (!OPLUtils.isObjectNullOrEmpty(coiResponse))
				return (U) coiResponse;
		
			Date curruntDate = new Date();
			
			applicationId = applicationMaster.getId();
			
			if(!Objects.equals(Source.OTHER_CHANNEL.getId(), applicationMaster.getApplicationMasterOtherDetails().getSource())) {
				return (U) new UpdateTransResProxyV3("The application details are not found in the Other Channel mode", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* FETCH CURRENT YEAR POLICY INSURER DETAILS */
			InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(Long.valueOf(applicationMaster.getSchemeId()),
					applicationMaster.getOrgId(), new Date(), new Date());

			if (!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails) && !OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getMasterPolicyNo())
					&& !currentInsurerDetails.getMasterPolicyNo().equalsIgnoreCase(transactionRequest.getMasterPolicyNumber())) {
				log.error("END SAVE TRANSACTION DETAILS (INVALID MASTER POLICY NUMBER) --------->" + applicationId);
				return (U) new UpdateTransResProxyV3("Invalid Master Policy Number !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* PARSE TRANSACTION DATE */
			Date tranTimeStamp = Date.from(transactionRequest.getTransactionTimeStamp().atZone(ZoneId.systemDefault()).toInstant());
			if (OPLUtils.isObjectNullOrEmpty(tranTimeStamp)) {
				log.error("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !! " + transactionRequest.getTransactionTimeStamp());
				return (U) new UpdateTransResProxyV3("Invalid Transaction Timestamp date format(yyyy-MM-dd HH:mm:ss) !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			/**if transactionTimeStamp date is after current date*/
			if(tranTimeStamp.after(new Date())) {
				return (U) new UpdateTransResProxyV3("Transaction date cannot be future dated. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			/**if transactionTimeStamp date is before policy start date*/
			if(!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getPolicyStartDate()) && tranTimeStamp.before(currentInsurerDetails.getPolicyStartDate())) {
				return (U) new UpdateTransResProxyV3("Transaction date cannot be before the policy year date. Kindly provide valid transaction time stamp.", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			/* SET TRANSACTION DETAIL OBJECT */
			TransactionDetailsV3 transactionDetails = getterSetter.setTransactionDetailsCommon(transactionRequest, curruntDate, tranTimeStamp, userId, currentInsurerDetails,applicationMaster);
			transactionDetails = getterSetter.setTransactionDetailsV3(transactionRequest,transactionDetails);

			/* SET APPLICATION MASTER COMPLETED DATA POINTS */
			applicationMaster = getterSetter.updateApplicationMaster(applicationMaster, curruntDate, tranTimeStamp, userId, currentInsurerDetails, transactionRequest);
			transactionDetails.setApplicationMaster(applicationMaster);
			applicationMaster.setLastTransactionDetails(transactionDetails);

			/* GENERATE COI */
			byte[] coiByte = this.getCOI(applicationMaster);
			if (!OPLUtils.isObjectNullOrEmpty(coiByte) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getCoiStorageId())) {
				/* SAVE APPLICATION MASTER */
				applicationMaster = commitTransactionalServiceImplV2.applicationMasterSave(applicationMaster);
				UpdateTransResProxyV1 transResPxyV1 = this.pushApplicationAndGenerateCoi(applicationMaster, coiByte);
				return (U) new UpdateTransResProxyV3(transResPxyV1.getMessage(),
						new COIDocsProxyV3(transResPxyV1.getCoi().getDocumentType(),
								transResPxyV1.getCoi().getContentType(), transResPxyV1.getCoi().getDocument()),
						transResPxyV1.getStatus(), transResPxyV1.getSuccess());
			}
			log.error("COI BYTES IS NULL OR EMPTY ------------>" + applicationMaster.getId());
			return (U) new UpdateTransResProxyV3(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		} catch (Exception e) {
			log.error("END SAVE TRANSACTION DETAILS (ERROR) --------->" + applicationId, e);
			return (U) new UpdateTransResProxyV3(Constants.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

}
