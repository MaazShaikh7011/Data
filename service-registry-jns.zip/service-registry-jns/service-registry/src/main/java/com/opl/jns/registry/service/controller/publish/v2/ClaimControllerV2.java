package com.opl.jns.registry.service.controller.publish.v2;

import com.opl.jns.api.proxy.jansuraksha.v2.Response400V2;
import com.opl.jns.api.proxy.jansuraksha.v2.Response401;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsResProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.uploaddocs.ClaimUploadDocumentsResProxyV2;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.api.utils.v2.Constants;
import com.opl.jns.registry.service.utils.RegistryUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v2")
@Slf4j
@Tag(name = "2. Other Channel Claims API", description = "List Of Other Channel api")
public class ClaimControllerV2 {

//	@Autowired
//	@Qualifier("ClaimServiceImplV2")
//	private ClaimService claimService;

	@PostMapping("/claimDetails")
	@Operation(operationId = "5", summary = Constants.CLAIM_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),

	})), responses = {
			@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = RegistryResponse.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

			),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimDetailsResProxyV2> claimDocuments(@Valid @RequestBody ClaimDetailsReqProxyV2 claimDetailsProxy,
			HttpServletRequest httpServletRequest) {
		if (OPLUtils.isObjectNullOrEmpty(claimDetailsProxy)) {
			return new ResponseEntity<>(new ClaimDetailsResProxyV2(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
					HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		ClaimDetailsResProxyV2 registryResponse = new ClaimDetailsResProxyV2(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
				HttpStatus.BAD_REQUEST.value());
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				registryResponse = (ClaimDetailsResProxyV2) RegistryUtils.setTokenAndTimeStemp(registryResponse,
						httpServletRequest);
				return new ResponseEntity<>(registryResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
			log.info("<--- Exit From Update Transaction Details  ---> ");

//			RegistryResponse commonResponse = claimService.saveClaimApi(claimDetailsProxy, userOrgId);
//			commonResponse = (RegistryResponse) RegistryUtils.setTokenAndTimeStemp(commonResponse, httpServletRequest);
			ClaimDetailsResProxyV2 commonResponse = new ClaimDetailsResProxyV2("Please use phase 2 (v3) api", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			registryResponse.setMessage(Constants.ErrorMsg.SMTG_WNT_WRG);
			// registryResponse.setData(Boolean.FALSE);
			registryResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			registryResponse.setSuccess(Boolean.FALSE);
			registryResponse = (ClaimDetailsResProxyV2) RegistryUtils.setTokenAndTimeStemp(registryResponse,
					httpServletRequest);
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}
	}

	@PostMapping("/claimUploadDocuments")
	@Operation(operationId = "6", summary = Constants.CLAIM_UPLOAD_DOCUMENTS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = RegistryResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V2.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V2.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimUploadDocumentsResProxyV2> claimUploadDocuments(
			@Valid @RequestBody ClaimUploadDocsReqProxyV2 claimUploadDocuments, HttpServletRequest httpServletRequest) {
		ClaimUploadDocumentsResProxyV2 registryResponse = new ClaimUploadDocumentsResProxyV2(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
				HttpStatus.BAD_REQUEST.value());
		if (OPLUtils.isObjectNullOrEmpty(claimUploadDocuments)) {
			registryResponse = (ClaimUploadDocumentsResProxyV2) RegistryUtils.setTokenAndTimeStemp(registryResponse,
					httpServletRequest);
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}
		try {
			registryResponse = (ClaimUploadDocumentsResProxyV2) RegistryUtils.setTokenAndTimeStemp(registryResponse,
					httpServletRequest);
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				registryResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				return new ResponseEntity<>(registryResponse, HttpStatus.OK);
			}
//			registryResponse = claimService.getClaimdetailsByClaimUploadDocuments(claimUploadDocuments);
//			registryResponse = (RegistryResponse) RegistryUtils.setTokenAndTimeStemp(registryResponse,
//					httpServletRequest);
			ClaimUploadDocumentsResProxyV2 commonResponse = new ClaimUploadDocumentsResProxyV2("Please use phase 2 (v3) api", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			registryResponse = (ClaimUploadDocumentsResProxyV2) RegistryUtils.setTokenAndTimeStemp(registryResponse,
					httpServletRequest);
			registryResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}
	}
	
}
