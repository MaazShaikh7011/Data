package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.JnsClaimData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface JnsClaimDataRepo extends JpaRepository<JnsClaimData, Long> {

    @Query(value = """
SELECT JSON_ARRAYAGG(\
JSON_OBJECT( \
'schemeId' value sm.ID, \
'schemeName' value sm.SHORT_NAME, \
'insurerOrgId' value insName.USER_ORG_ID, \
'insurerName' value insName.display_org_name, \
'insurerCode' value insName.ORGANISATION_CODE, \
'orgId' value orgName.USER_ORG_ID, \
'bankName' value orgName.display_org_name, \
'bankShortName' value orgName.ORGANISATION_CODE, \
'bankCode' value orgName.BANK_TYPE, \
'bankCategory' value orgName.ORG_CATEGORY, \
'lgdStateCode' value ls.code, \
'stateName' value ls.NAME, \
'maleClmRecv' value COALESCE(baseTbl.maleClmRec, 0), \
'femaleClmRecv' value COALESCE(baseTbl.femaleClmRec, 0), \
'transGClmRecv' value COALESCE(baseTbl.otherClmRec, 0), \
'maleClmPaid' value COALESCE(baseTbl.maleClmPaid, 0), \
'femaleClmPaid' value COALESCE(baseTbl.femaleClmPaid, 0),\
'transGClmPaid' value COALESCE(baseTbl.otherClmPaid, 0), \
'maleClmReject' value COALESCE(baseTbl.maleClmReject, 0), \
'femaleClmReject' value COALESCE(baseTbl.femaleClmReject, 0), \
'transGClmReject' value COALESCE(baseTbl.otherClmReject, 0), \
'maleClmOutStand' value COALESCE(baseTbl.maleClmOutStand, 0), \
'femaleClmOutStand' value COALESCE(baseTbl.femaleClmOutStand, 0), \
'transGClmOutStand' value COALESCE(baseTbl.otherClmOutStand, 0), \
'maleClmAmount' value COALESCE(baseTbl.maleClmAmount, 0), \
'femaleClmAmount' value COALESCE(baseTbl.femaleClmAmount, 0), \
'transGClmAmount' value COALESCE(baseTbl.otherClmAmount, 0), \
'maleClmRuralCount' value COALESCE(baseTbl.maleClmRural, 0), \
'femaleClmRuralCount' value COALESCE(baseTbl.femaleClmRural, 0), \
'transgClmRuralCount' value COALESCE(baseTbl.otherClmRural, 0), \
'maleClmUrbanCount' value COALESCE(baseTbl.maleClmUrban, 0), \
'femaleClmUrbanCount' value COALESCE(baseTbl.femaleClmUrban, 0), \
'transgClmUrbanCount' value COALESCE(baseTbl.otherClmUrban, 0), \
'graterThan1Year' value COALESCE(baseTbl.graterThan1Year, 0), \
'graterThan6Months' value COALESCE(baseTbl.graterThan6Months, 0), \
'graterThan60Days' value COALESCE(baseTbl.graterThan60Days, 0), \
'graterThan14Days' value COALESCE(baseTbl.graterThan14Days, 0), \
'graterThan7Days' value COALESCE(baseTbl.graterThan7Days, 0), \
'lessThan7Days' value COALESCE(baseTbl.lessThan7Days, 0), \
'kycEmailCnt' value COALESCE(baseTbl.kycEmailCnt, 0), \
'kycMobileCnt' value COALESCE(baseTbl.kycMobileCnt, 0), \
'kycAadhaarCnt' value COALESCE(baseTbl.kycAadhaarCnt, 0) \
) RETURNING CLOB )\
 FROM JNS_CONFIG.INSURER_ORG_SCHEME_MAPPING iosm \
 INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER orgName ON orgName.user_org_id = iosm.ORG_ID \
 INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER insName ON insName.user_org_id = iosm.INSURER_ORG_ID \
 INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.id = iosm.scheme_id \
 LEFT JOIN ( \
 SELECT \
 cm.BRANCH_STATE_ID AS stateId, cm.ORG_ID, cm.INSURER_ORG_ID, cm.scheme_id, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND m.rural_urban_id = 1 THEN 1 ELSE 0 END) AS maleClmRural,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND m.rural_urban_id = 1 THEN 1 ELSE 0 END) AS femaleClmRural,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND m.rural_urban_id = 1 THEN 1 ELSE 0 END) AS otherClmRural,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND m.rural_urban_id = 2 THEN 1 ELSE 0 END) AS maleClmUrban,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND m.rural_urban_id = 2 THEN 1 ELSE 0 END) AS femaleClmUrban,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND m.rural_urban_id = 2 THEN 1 ELSE 0 END) AS otherClmUrban,\
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND cm.stage_id = 14 THEN 1 ELSE 0 END) AS maleClmRec, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND cm.stage_id = 14 THEN 1 ELSE 0 END) AS femaleClmRec, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND cm.stage_id = 14 THEN 1 ELSE 0 END) AS otherClmRec, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND cm.status = 10 THEN 1 ELSE 0 END) AS maleClmPaid, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND cm.status = 10 THEN 1 ELSE 0 END) AS femaleClmPaid, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND cm.status = 10 THEN 1 ELSE 0 END) AS otherClmPaid, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND cm.status = 8 THEN 1 ELSE 0 END) AS maleClmReject, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND cm.status = 8 THEN 1 ELSE 0 END) AS femaleClmReject, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND cm.status = 8 THEN 1 ELSE 0 END) AS otherClmReject, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND cm.status IN (6,7) THEN 1 ELSE 0 END) AS maleClmOutStand, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND cm.status IN (6,7) THEN 1 ELSE 0 END) AS femaleClmOutStand, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND cm.status IN (6,7) THEN 1 ELSE 0 END) AS otherClmOutStand, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 1 AND cm.status = 10 THEN cm.transaction_amount ELSE 0 END) AS maleClmAmount, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 2 AND cm.status = 10 THEN cm.transaction_amount ELSE 0 END) AS femaleClmAmount, \
 SUM(CASE WHEN cd.AP_GENDER_ID = 3 AND cm.status = 10 THEN cm.transaction_amount ELSE 0 END) AS otherClmAmount, \
 SUM(CASE WHEN cd.AP_EMAIL IS NOT NULL THEN 1 ELSE 0 END) AS kycEmailCnt,\
 SUM(CASE WHEN cd.AP_MOBILE_NUMBER IS NOT NULL THEN 1 ELSE 0 END) AS kycMobileCnt,\
 SUM(CASE WHEN cpd.AP_AADHAAR IS NOT NULL THEN 1 ELSE 0 END) AS kycAadhaarCnt,\
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) BETWEEN 0 and 7) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS lessThan7Days, \
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) BETWEEN 8 and 14) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS graterThan7Days, \
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) BETWEEN 15 and 60) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS graterThan14Days, \
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) BETWEEN 61 and 180) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS graterThan60Days, \
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) BETWEEN 181 and 365) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS graterThan6Months, \
 SUM(CASE WHEN ((CEIL(CAST(TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) AS DATE ) - CAST(cm.CLAIM_DATE AS date)) > 365) AND cm.status IN (6,7)) THEN 1 ELSE 0 END) AS graterThan1Year \
 FROM JNS_INSURANCE.CLM_MASTER cm \
 INNER JOIN JNS_INSURANCE.CLM_PI_DETAILS cpd ON cpd.ID = cm.ID \
 INNER JOIN JNS_INSURANCE.CLM_DETAILS cd ON cd.ID = cm.ID \
 INNER JOIN JNS_USERS.BRANCH_MASTER m on m.id = cm.branch_id\
 WHERE cm.BRANCH_STATE_ID IS NOT NULL AND  cm.ORG_ID IS NOT NULL AND cm.INSURER_ORG_ID IS NOT NULL \
 AND TO_TIMESTAMP(CAST(cm.CLAIM_DATE AS DATE)) <= TO_TIMESTAMP(TO_DATE(:toDate,'DD-MM-YYYY')) \
 GROUP BY cm.BRANCH_STATE_ID, cm.ORG_ID,cm.INSURER_ORG_ID, cm.scheme_id \
) baseTbl ON baseTbl.INSURER_ORG_ID = iosm.INSURER_ORG_ID AND baseTbl.ORG_ID = iosm.ORG_ID \
LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.ID = baseTbl.stateId \
ORDER BY iosm.scheme_id ASC \
""", nativeQuery = true)
    Object getDataByToDate(@Param("toDate") String toDate);

    List<JnsClaimData> findAllByVersion(Long version);

}
