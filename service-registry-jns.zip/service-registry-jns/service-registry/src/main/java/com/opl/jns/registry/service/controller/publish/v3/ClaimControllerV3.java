package com.opl.jns.registry.service.controller.publish.v3;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.insurer.PushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.insurer.PushClaim.PushClaimDetailsResponse;
import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.RegistryResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimDocumentResProxy;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.api.proxy.jansuraksha.v3.Response400V3;
import com.opl.jns.api.proxy.jansuraksha.v3.Response401;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.service.publish.common.ClaimService;
import com.opl.jns.registry.service.service.publish.common.ValidationService;
import com.opl.jns.registry.service.utils.RegistryUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "2. Other Channel Claims API", description = "List Of Other Channel api")
public class ClaimControllerV3 {
	
	@Autowired
	@Qualifier("ClaimServiceImplV3")
	private ClaimService claimService;
	
    @Autowired
	ValidationService validationService;

	@PostMapping("/claimDetails")
	@Operation(operationId = "5", summary = Constants.CLAIM_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),

	})), responses = {
			@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimDetailsResProxyV3.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

			),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimDetailsResProxyV3> claimDocuments(@Valid @RequestBody ClaimDetailsReqProxyV3 claimDetailsProxy,
			HttpServletRequest httpServletRequest) {
		ClaimDetailsResProxyV3 registryResponse = new ClaimDetailsResProxyV3();
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				registryResponse = RegistryUtils.setTokenAndTimeStempV3(registryResponse,claimDetailsProxy.getToken());
                return new ResponseEntity<>(registryResponse, HttpStatus.OK);
			}
			Long userOrgId = Long.valueOf(String.valueOf(orgId));
			log.info("userOrgId ==> {}", userOrgId);
			log.info("<--- Exit From Update Transaction Details  ---> ");

			ClaimDetailsResProxyV3 commonResponse = claimService.saveClaimApi(claimDetailsProxy, userOrgId);
			commonResponse = RegistryUtils.setTokenAndTimeStempV3(commonResponse, claimDetailsProxy.getToken());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			registryResponse.setMessage(Constants.ErrorMsg.SMTG_WNT_WRG);
			// registryResponse.setData(Boolean.FALSE);
			registryResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			registryResponse.setSuccess(Boolean.FALSE);
			registryResponse = RegistryUtils.setTokenAndTimeStempV3(registryResponse,
					claimDetailsProxy.getToken());
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}

	}

	@PostMapping("/claimUploadDocuments")
	@Operation(operationId = "6", summary = Constants.CLAIM_UPLOAD_DOCUMENTS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = RegistryResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimDocumentResProxy> claimUploadDocuments(
			@Valid @RequestBody ClaimUploadDocsReqProxyV3 claimUploadDocuments, HttpServletRequest httpServletRequest) {
		ClaimDocumentResProxy registryResponse = new ClaimDocumentResProxy();
		registryResponse = RegistryUtils.setTokenAndTimeStempV3(registryResponse,claimUploadDocuments.getToken());
		if (OPLUtils.isObjectNullOrEmpty(claimUploadDocuments)) {
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}
		try {
			Object orgId = httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
				registryResponse.setStatusAndMessageAndSuccess(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				return new ResponseEntity<>(registryResponse, HttpStatus.OK);
			}
			registryResponse = claimService.getClaimdetailsByClaimUploadDocuments(claimUploadDocuments);
			registryResponse = RegistryUtils.setTokenAndTimeStempV3(registryResponse,claimUploadDocuments.getToken());
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationList() {}", e.getMessage());
			registryResponse = RegistryUtils.setTokenAndTimeStempV3(registryResponse,claimUploadDocuments.getToken());
			registryResponse.setStatusAndMessageAndSuccess(Constants.ErrorMsg.SMTG_WNT_WRG,
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		}

	}

	@PostMapping("/pushClaimDetails")
	@Operation(operationId = "7", summary = Constants.PUSH_CLAIM_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_PUSH_CLAIM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PushClaimDetailsResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_PUSH_PLAIN_RESPONSE_200, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PushClaimDetailsResponse> pushClaimDetails(
            @Valid @RequestBody PushClaimDetailsRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping("/claimDedupeApi")
	@Operation(operationId = "8", summary = Constants.DE_DUP_API_MESSAGE, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DE_DUP_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION_DATE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_DE_DUPE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimDeDupResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DE_DUP_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)

							) }) })

	public ResponseEntity<ClaimDeDupResProxyV3> claimDeDup(@Valid @RequestBody ClaimDeDupReqProxyV3 dedupeRequest, HttpServletRequest httpServletRequest) {
		try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, dedupeRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				ClaimDeDupResProxyV3 matchResponse = new ClaimDeDupResProxyV3(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				RegistryUtils.setTokenAndTimeStempV3(matchResponse,dedupeRequest.getToken());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}
			ClaimDeDupResProxyV3 commonResponse = claimService.getClaimDedupeData(dedupeRequest);
			commonResponse = RegistryUtils.setTokenAndTimeStempV3(commonResponse,dedupeRequest.getToken());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationDetails() {} ", e.getMessage());
//			return new ResponseEntity<>(new ClaimDeDupResProxyV3(Constants.ErrorMsg.SMTG_WNT_WRG, Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
			return null;
		}

	}


	@PostMapping("/insurerUpdateClaimStatus")
	@Operation(operationId = "9", summary = Constants.UPDATE_CLAIM_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE, description =Constants.INSURER_UPDATE_CLAIM_STATUS),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimStatusUpdateResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400V3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400V3.WB_PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//		                            examples = {
//		                                    @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//		                                    @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//		                            }
							) }) })
	public ResponseEntity<ClaimStatusUpdateResProxyV3> updateApplicationStatus(@Valid @RequestBody ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, HttpServletRequest httpServletRequest) {
        try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, updateAppClaimRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				ClaimStatusUpdateResProxyV3 matchResponse = new ClaimStatusUpdateResProxyV3(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}
//			Long apiUserId=null;
//			if(null != httpServletRequest.getAttribute(AuthCredentialUtils.APP_USER_ID)){
//				apiUserId = Long.valueOf(httpServletRequest.getAttribute(AuthCredentialUtils.APP_USER_ID).toString());
//			}
            StringBuilder message = new StringBuilder();
			ClaimStatusUpdateResProxyV3 commonResponse=claimService.updateClaimStatus(updateAppClaimRequest,  message,httpServletRequest);
			commonResponse = RegistryUtils.setTokenAndTimeStempV3(commonResponse,updateAppClaimRequest.getToken());
            return new ResponseEntity<>(commonResponse,HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getApplicationDetails() {} ", e.getMessage());
            return new ResponseEntity<>(new ClaimStatusUpdateResProxyV3(Constants.ErrorMsg.SMTG_WNT_WRG,  Boolean.FALSE,HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }

    }

}
