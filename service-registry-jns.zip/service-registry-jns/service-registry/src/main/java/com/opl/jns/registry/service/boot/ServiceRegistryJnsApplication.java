package com.opl.jns.registry.service.boot;

import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.lib.utils.ApplicationProperties;
import com.opl.jns.published.utils.config.URLConfig;
import com.opl.jns.published.utils.config.URLMaster;
import com.opl.jns.registry.service.utils.GetCommonData;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.webhook.client.WebHookClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableAsync
@EnableScheduling
@EnableConfigurationProperties(ApplicationProperties.class)
public class ServiceRegistryJnsApplication {

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private GetCommonData getCommonData;

    public static void main(String[] args) {
        SpringApplication.run(ServiceRegistryJnsApplication.class, args);
    }

    @Bean
    public UsersClient usersClient() {
        UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
        return usersClient;
    }

    @Bean
    public OneFormClient oneFormClient() {
        OneFormClient oneFormClient = new OneFormClient(URLConfig.fetchURL(URLMaster.ONE_FORM));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(oneFormClient);
        getCommonData.getStateDistrictData(oneFormClient);
        return oneFormClient;
    }

    @Bean
    public DMSClient dMSClient() {
        DMSClient dmsClient = new DMSClient(URLConfig.fetchURL(URLMaster.DMS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(dmsClient);
        return dmsClient;
    }

    @Bean
    public NotificationClient notificationClient() {
        NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
        return notificationClient;
    }
    
    @Bean
    public PDFGenerateClient pdfGenerateClient() {
    	PDFGenerateClient pdfGenerateClient = new PDFGenerateClient(URLConfig.fetchURL(URLMaster.PDF_GENARATE));
//        PDFGenerateClient pdfGenerateClient = new PDFGenerateClient("http://localhost:8073/pdf/generate");
    	applicationContext.getAutowireCapableBeanFactory().autowireBean(pdfGenerateClient);
    	return pdfGenerateClient;
    }
    
    @Bean
    public DedupeRegistryClient dedupeRegistryClient() {
    	DedupeRegistryClient dedupeRegistryClient = new DedupeRegistryClient(URLConfig.fetchURL(URLMaster.DD_REGISTRY));
//        PDFGenerateClient pdfGenerateClient = new PDFGenerateClient("http://localhost:8073/pdf/generate");
    	applicationContext.getAutowireCapableBeanFactory().autowireBean(dedupeRegistryClient);
    	return dedupeRegistryClient;
    }
    
    @Bean
    public WebHookClient webHookClient() {
    	WebHookClient webHookClient = new WebHookClient(URLConfig.fetchURL(URLMaster.WEBHOOK));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(webHookClient);
        return webHookClient;
    }
    
    @Bean
    public UserManagementClient userManagementClient() {
        UserManagementClient userManagementClient = new UserManagementClient(URLConfig.fetchURL(URLMaster.USER_MANAGEMENT));
//        UserManagementClient userManagementClient = new UserManagementClient("http://localhost:8061/user-management");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(userManagementClient);
        return userManagementClient;
    }
}
