package com.opl.jns.registry.service.utils.v2;

import com.opl.jns.api.proxy.jansuraksha.v1.otherchannel.claim.details.ClaimDetailsReqProxyV1;
import com.opl.jns.api.proxy.jansuraksha.v2.otherchannel.claim.details.ClaimDetailsReqProxyV2;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.insurerUpdateClaimStatus.ClaimStatusUpdateReqProxyV3;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.enums.*;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.registry.api.utils.v3.Constants;
import com.opl.jns.registry.service.utils.RegistryUtils;
import com.opl.jns.utils.common.PatternUtils;
import com.opl.jns.utils.enums.ClaimStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class ClaimValidation {

	public static final long LONG_30Days = 30L;
//
//	public ClaimDetailsResProxyV2 checkClaimDetailsValidationsV2(ClaimDetailsReqProxyV2 claimDetails) throws ParseException {
//		StringBuilder s1 = new StringBuilder();
//		ClaimDetailsResProxyV2 commonResponse = new ClaimDetailsResProxyV2();
//		commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
//		try {
//			if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getIsNomineePredeceased())
//					&& claimDetails.getIsNomineePredeceased().equalsIgnoreCase(YesNo.YES.getValue())) {
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantFirstName())) {
//					s1.append("claimantFirstName can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantDateOfBirth())) {
//					s1.append("claimantDateOfBirth can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getRelationOfClaimant())) {
//					s1.append("relationOfClaimant can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantMobileNumber())) {
//					s1.append("claimantMobileNumber can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantAddressLine1())) {
//					s1.append("claimantAddressLine1 can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantCity())) {
//					s1.append("claimantCity can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantDistrict())) {
//					s1.append("claimantDistrict can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantState())) {
//					s1.append("claimantState can not be null or empty.");
//				}
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantPincode())) {
//					s1.append("claimantPincode can not be null or empty.");
//				}
//			}
//			if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getNomineeNameCorrection())
//					&& claimDetails.getNomineeNameCorrection().equalsIgnoreCase(YesNo.YES.getValue())) {
//				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCorrectNomineeFirstName())) {
//					s1.append("correctNomineeFirstName can not be null or empty.");
//				}
//			}
//
//			if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getClaimantDateOfBirth())) {
//				boolean isInValidClaimantDateOfBirth = isInValidateDate(claimDetails.getClaimantDateOfBirth(),
//						DateUtils.DateFormat.YYYY_MM_DD);
//				if (isInValidClaimantDateOfBirth) {
//					s1.append("claimantDateOfBirth should be in 1993-06-06");
//				}
//			}
//		} catch (Exception e) {
//			log.warn("Exception while validation for claim details", e);
//		}
//
//		commonResponse.setSuccess(OPLUtils.isObjectNullOrEmpty(s1.toString()));
//		commonResponse.setMessage(!OPLUtils.isObjectNullOrEmpty(s1.toString()) ? s1.toString() : null);
//		return commonResponse;
//	}
	
	

	public static boolean isInValidateDate(String dateStr, String dateFormat) {
		try {
			Date parse = DateUtils.parse(dateStr, dateFormat);
			return null != parse ? Boolean.FALSE : Boolean.TRUE;
		} catch (Exception e) {
			return Boolean.TRUE;
		}
	}

	public static StringBuilder checkMandatoryFieldsOfBothSchemeCommon(ClaimDetailsReqProxyV1 claimDetails, int schemeId,
																	   StringBuilder s1) {
		 if (schemeId == SchemeMaster.PMSBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDayOfAccident())) {
				log.warn("dayOfAccident can not be null or empty.");
				s1.append("dayOfAccident can not be null or empty.");
			}
			// Nature of accident
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNatureOfAccident())) {
				log.warn("natureOfAccident can not be null or empty.");
				s1.append("natureOfAccident can not be null or empty.");
			} else {
				NatureOfLoss natureOfLoss = NatureOfLoss.fromBankValue(claimDetails.getNatureOfAccident());
				if (OPLUtils.isObjectNullOrEmpty(natureOfLoss)) {
					log.warn("Nature Of Accident can be either (Disability|Death).");
					s1.append("Nature Of Accident can be either (Disability|Death).");
				} else {
					if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DISABILITY.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTypeOfDisability())) {
							log.warn("Type Of Disability can not be null or empty.");
							s1.append("Type Of Disability can not be null or empty.");
						} else {
							TypeOfDisability typeOfDisability = TypeOfDisability
									.fromBankValue(claimDetails.getTypeOfDisability());
							if (OPLUtils.isObjectNullOrEmpty(typeOfDisability)) {
								log.warn("Invalid TypeOfDisability (Partial Disability|Total Disability).");
								s1.append("Invalid TypeOfDisability (Partial Disability|Total Disability).");
							}
						}
				}
			}

//			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
//				log.warn("timeOfAccident can not be null or empty.");
//				s1.append("timeOfAccident can not be null or empty.");
//			}

		
			}
		}
		return s1;
	}
	
	public static StringBuilder checkMandatoryFieldsOfBothSchemeV2(ClaimDetailsReqProxyV2 claimDetails, int schemeId,
			Date enrollmentDate, StringBuilder s1) {
//		StringBuilder s1 = new StringBuilder();
		if (schemeId == SchemeMaster.PMJJBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeath())) {
				log.warn("causeOfDeath can not be null or empty.");
				s1.append("causeOfDeath can not be null or empty.");
			} else {
				CauseOfDeathDisability disability = CauseOfDeathDisability
						.fromBankValue(claimDetails.getCauseOfDeath());
				if (!OPLUtils.isObjectNullOrEmpty(disability)) {
					if (!disability.getValue().equalsIgnoreCase(CauseOfDeathDisability.DEATH.getValue()) && !disability
							.getValue().equalsIgnoreCase(CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getValue())) {
						log.warn("Invalid Cause Of Death (Death|Accidental death within 30 days of lien period).");
						s1.append("Invalid Cause Of Death (Death|Accidental death within 30 days of lien period).");
					}
				}
			}
		} 
		if (schemeId == SchemeMaster.PMJJBY.getId()) {
			// cause of disability
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeathDisability())) {
				log.warn("causeOfDeathDisability can not be null or empty.");
				s1.append("causeOfDeathDisability can not be null or empty.");
			} else {
				CauseOfDeathDisability disability = CauseOfDeathDisability
						.fromBankValue(claimDetails.getCauseOfDeathDisability());
				if (OPLUtils.isObjectNullOrEmpty(disability)) {
					log.warn("Invalid Cause Of Death Disability (Accidental).");
					s1.append("Invalid Cause Of Death Disability (Accidental).");
				} else if (!disability.getValue().equalsIgnoreCase(CauseOfDeathDisabilityV2.ACCIDENTAL.getValue())) {
					log.warn("Invalid Cause Of Death Disability (Accidental).");
					s1.append("Invalid Cause Of Death Disability (Accidental).");
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfDeath())) {
				log.warn("dateOfDeath can not be null or empty.");
				s1.append("dateOfDeath can not be null or empty.");
			} else {
				boolean isInValidDateOfDeath = isInValidateDate(claimDetails.getDateOfDeath(),
						com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
				if (isInValidDateOfDeath) {
					s1.append("Invalid Date Format for Date Of Death(yyyy-MM-dd HH:mm:ss).");
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeath())) {
				log.warn("causeOfDeath can not be null or empty.");
				s1.append("causeOfDeath can not be null or empty.");
			} else {
				CauseOfDeathDisability disability = CauseOfDeathDisability
						.fromBankValue(claimDetails.getCauseOfDeath());
				if (!OPLUtils.isObjectNullOrEmpty(disability)) {
//					 death case - check days with enroll datediff - 30 day
					if (claimDetails.getCauseOfDeath().equals(CauseOfDeathDisability.DEATH.getValue())) {
						Date dateOfDeath = DateUtils.parse(claimDetails.getDateOfDeath(),
								DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
						long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
						if (dateDiff < LONG_30Days) {
							s1.append("The death is in lian period");
						}
					}
				}
			}
		} else if (schemeId == SchemeMaster.PMSBY.getId()) {
//			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getPlaceOfAccident())) {
//				log.warn("placeOfAccident can not be null or empty.");
//				s1.append("placeOfAccident can not be null or empty.");
//			}
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
				log.warn("timeOfAccident can not be null or empty.");
				s1.append("timeOfAccident can not be null or empty.");
			}
			// Nature of accident
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNatureOfAccident())) {
				log.warn("natureOfAccident can not be null or empty.");
				s1.append("natureOfAccident can not be null or empty.");
			} else {
				NatureOfLoss natureOfLoss = NatureOfLoss.fromBankValue(claimDetails.getNatureOfAccident());
				if (OPLUtils.isObjectNullOrEmpty(natureOfLoss)) {
					log.warn("Nature Of Accident can be either (Disability|Death).");
					s1.append("Nature Of Accident can be either (Disability|Death).");
				} else {
					if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DEATH.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfDeath())) {
							log.warn("dateOfDeath can not be null or empty.");
							s1.append("dateOfDeath can not be null or empty.");
						} else {
							boolean isInValidDateOfDeath = isInValidateDate(claimDetails.getDateOfDeath(),
									com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
							if (isInValidDateOfDeath) {
								s1.append("Invalid Date Format for Date Of Death(yyyy-MM-dd HH:mm:ss).");
							} else {
								// death case - check days with enroll datediff
								Date dateOfDeath = DateUtils.parse(claimDetails.getDateOfDeath(),
										DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
								long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
								if (dateDiff < 0) {
									s1.append("The death date must precede the enrollment date.");
								}
							}
						}
					}
				}

				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfAccident())) {
					log.warn("dateOfAccident can not be null or empty.");
					s1.append("dateOfAccident can not be null or empty.");
				} else {
//				 merge here dateOfAccident and timeOfAccident for parsing - yyyy-MM-dd
//				 HH:mm:ss
					if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
						claimDetails.setDateOfAccident(
								claimDetails.getDateOfAccident().concat(" ").concat(claimDetails.getTimeOfAccident()));
					}
					/* date validations in case dates are not null */
					boolean isInValidDateOfAccident = isInValidateDate(claimDetails.getDateOfAccident(),
							com.opl.jns.utils.common.DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS);
					if (isInValidDateOfAccident) {
						s1.append("dateOfAccident can not be null or empty.");
					}
				}
			}
		}
		return s1;
	}
	
	public static StringBuilder checkMandatoryFieldsOfBothSchemeV3(ClaimDetailsReqProxyV3 claimDetails, int schemeId,
																   Date enrollmentDate, StringBuilder s1) {
		if (schemeId == SchemeMaster.PMJJBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getCauseOfDeath())) {
				log.warn("causeOfDeath can not be null or empty.");
				s1.append("causeOfDeath can not be null or empty.");
			} else {
				CauseOfDeathDisability disability = CauseOfDeathDisability
						.fromBankValue(claimDetails.getCauseOfDeath());
				if (!OPLUtils.isObjectNullOrEmpty(disability)) {
//					 death case - check days with enroll datediff - 30 day
					if (claimDetails.getCauseOfDeath().equals(CauseOfDeathDisability.DEATH.getValue())) {
						Date dateOfDeath = Date
								.from(claimDetails.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant());
						long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
						if (dateDiff < LONG_30Days) {
							s1.append("The death is in lian period");
						}
					}
				}
			}
		} else if (schemeId == SchemeMaster.PMSBY.getId()) {
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
				log.warn("timeOfAccident can not be null or empty.");
				s1.append("timeOfAccident can not be null or empty.");
			}
			// Nature of accident
			if (OPLUtils.isObjectNullOrEmpty(claimDetails.getNatureOfAccident())) {
				log.warn("natureOfAccident can not be null or empty.");
				s1.append("natureOfAccident can not be null or empty.");
			} else {
				NatureOfLoss natureOfLoss = NatureOfLoss.fromBankValue(claimDetails.getNatureOfAccident());
				if (OPLUtils.isObjectNullOrEmpty(natureOfLoss)) {
					log.warn("Nature Of Accident can be either (Disability|Death).");
					s1.append("Nature Of Accident can be either (Disability|Death).");
				} else {
					if (claimDetails.getNatureOfAccident().equals(NatureOfLoss.DEATH.getValue())) {
						if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfDeath())) {
							log.warn("dateOfDeath can not be null or empty.");
							s1.append("dateOfDeath can not be null or empty.");
						} else {
							// death case - check days with enroll datediff
							Date dateOfDeath = Date
									.from(claimDetails.getDateOfDeath().atZone(ZoneId.systemDefault()).toInstant());
							long dateDiff = DateUtils.dateDiff(dateOfDeath, enrollmentDate);
							if (dateDiff < 0) {
								s1.append("The death date must precede the enrollment date.");
							}
						}
					}
				}

				if (OPLUtils.isObjectNullOrEmpty(claimDetails.getDateOfAccident())) {
					log.warn("dateOfAccident can not be null or empty.");
					s1.append("dateOfAccident can not be null or empty.");
				} else {
//				 merge here dateOfAccident and timeOfAccident for parsing - yyyy-MM-dd
//				 HH:mm:ss
//					if (!OPLUtils.isObjectNullOrEmpty(claimDetails.getTimeOfAccident())) {
//						claimDetails.setDateOfAccident(
//								claimDetails.getDateOfAccident().concat(" ").concat(claimDetails.getTimeOfAccident()));
//					}
					/* date validations in case dates are not null */
				}
			}
		}
		return s1;
	}

	public static StringBuilder kycIdValidOrNot(String kycId, String kycIdName) {
		if (!kycId.equalsIgnoreCase(KycDocument.PAN.getKey()) && !kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			return new StringBuilder(kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA");
		}
		return null;
	}

	public static StringBuilder kycIdValidation(String kycId, String kycIdValue, StringBuilder builder,
			String kycIdName) {
		if (!OPLUtils.isObjectNullOrEmpty(kycId)) {
			StringBuilder sb1 = kycIdValidOrNot(kycId, kycIdName);
			if (!OPLUtils.isObjectNullOrEmpty(sb1)) {
				return builder.append(sb1);
			}
			if (!OPLUtils.isObjectNullOrEmpty(kycIdValue) && !kycIdValue.equalsIgnoreCase(RegistryUtils.AADHAR)) {
				com.opl.jns.utils.common.CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(kycId, kycIdValue,
						kycIdName);
				if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
					return builder.append(commonResponsekycNo.getMessage());
				}
			}
		}
		return builder;
	}

	public static com.opl.jns.utils.common.CommonResponse kycIdNumberValidOrNot(String kycId, String kycIdNumber,
			String kycIdName) {
		if (kycId.equalsIgnoreCase(KycDocument.PAN.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PAN_PATTERN);
			java.util.regex.Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid pan number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.AADHAR_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid aadhar number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PASSPORT_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid passport number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.VOTERS_ID_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid voter id number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.DRIVING_LICENCE_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid driving licence number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.MGNREGA_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				return new com.opl.jns.utils.common.CommonResponse(kycIdName + " - Invalid mgnrega card number",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
		}
		return null;
	}

	public static Boolean findLength(String key, Long min, Long max) {
		if (key.length() < min || key.length() > max) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public static boolean validateRequestForUpdateStatusApi(ClaimStatusUpdateReqProxyV3 updateAppClaimRequest, StringBuilder message, ClmMaster master) {
		if (OPLUtils.isObjectNullOrEmpty(master)) {
			message.append("Invalid claim reference id");
			log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		if (!master.getUrn().equalsIgnoreCase(updateAppClaimRequest.getUrn())) {
			message.append("Kindly send valid URN.");
			log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		if (!OPLUtils.isObjectNullOrEmpty(master.getStatus()) && master.getStatus().equals(ClaimStatus.CLAIM_ACCEPTED.getId())) {
			message.append("Already approved claim.");
			log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		if (OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getClaimStatus())) {
			message.append("Status can not be null");
			log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		try {			
			ClaimStatus status = ClaimStatus.fromId(Integer.valueOf(updateAppClaimRequest.getClaimStatus()));
			if (OPLUtils.isObjectNullOrEmpty(status)) {
				message.append("Status is not valid");
				log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
				return true;
			}else if(!OPLUtils.isObjectNullOrEmpty(status) && updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_TO_INSURER.getId())){
				message.append("It is a default status when claim was registerd from bank.");
				log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
				return true;
			}
			if (!OPLUtils.isObjectNullOrEmpty(status) && updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_ACCEPTED.getId())				
					&& (OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails()) 
							|| OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails().getTransactionAmount())
							|| OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails().getTransactionUTR())
							|| OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getTransactionDetails().getTransactionTimeStamp()))) {
					message.append("transactionDetails: Transaction Amount, UTR and date of transation cannot be null or empty.");
					log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
				return true;
			}
		}catch (Exception e) {
			message.append("Status is not valid");
			log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		if ((updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()) || updateAppClaimRequest.getClaimStatus().equals(ClaimStatus.CLAIM_REJECTED.getId())) && OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getReason())) {
			 message.append("Reason can not be null");
			 log.info(Constants.EXIT_FROM_UPDATE_CLAIM_STATUS);
			return true;
		}
		return false;
	}

}
