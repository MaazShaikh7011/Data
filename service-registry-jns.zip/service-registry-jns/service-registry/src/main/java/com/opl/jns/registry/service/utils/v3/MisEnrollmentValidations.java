package com.opl.jns.registry.service.utils.v3;

import com.google.common.collect.ImmutableSet;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.DistrictWiseData;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.registry.service.domain.WeekMaster;
import com.opl.jns.registry.service.repository.WeekMasterRepository;
import com.opl.jns.registry.service.utils.GetCommonData;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MisEnrollmentValidations {

    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd MMMM yyyy");

    @Autowired
    private WeekMasterRepository weekMasterRepository;

    public String checkBasicValidation(MisEnrollmentReqV3 misEnrollmentReqV3) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
                if (misEnrollmentReqV3.getType() != null && misEnrollmentReqV3.getType().equalsIgnoreCase(TransactionTypeEnum.RENEWAL.name())) {
                List<DistrictWiseData> data = misEnrollmentReqV3.getDistrictList().stream()
                        .filter(a -> (a.getPmsby().getInsufficientAcHolders() == null || a.getPmjjby().getInsufficientAcHolders() == null)
                                || (a.getPmsby().getPrmdebitedRs() == null || a.getPmjjby().getPrmdebitedRs() == null))
                        .collect(Collectors.toList());
                if (!data.isEmpty()) {
                    log.info("insufficientAcHolders or prmdebitedRs data is null or empty in renewal case");
                    stringBuilder.append(" Insufficient A/C holder value is mandatory for Renewal.");
                }
                WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);
                if (OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                    log.info("Week Master is null or empty for IN_PROGRESS status ");
                    stringBuilder.append("Technical Error.");
                }
                if (!weekMaster.getIsRenewalUpdated()) {
                    weekMaster.setIsRenewalUpdated(true);
                    weekMasterRepository.save(weekMaster);
                }
            } else {
                Calendar fromDate = Calendar.getInstance();
                fromDate.setTime(DATE_FORMAT.parse(DATE_FORMAT.format(Date.from(misEnrollmentReqV3.fromDate.atZone(ZoneId.systemDefault()).toInstant()))));

                Calendar toDate = Calendar.getInstance();
                toDate.setTime(DATE_FORMAT.parse(DATE_FORMAT.format(Date.from(misEnrollmentReqV3.toDate.atZone(ZoneId.systemDefault()).toInstant()))));

                // CHECK REQUEST DATE RANG HAVING 7 DAYS OR NOT
                if ((((toDate.getTime().getTime() - fromDate.getTime().getTime()) / (1000 * 60 * 60 * 24)) % 365) != 6) {
                    stringBuilder.append("Kindly send data of only 7 days.");
                } else {
                    WeekMaster weekMaster = weekMasterRepository.findFirstByStatus(WeekMaster.StatusEnum.IN_PROGRESS);
                    if (!OPLUtils.isObjectNullOrEmpty(weekMaster)) {
                        if (!fromDate.getTime().equals(weekMaster.getFromDate())) {
                            log.info("Invalid fromDate in request");
                            stringBuilder.append("To and From date is invalid.");
                        }
                        if (!toDate.getTime().equals(weekMaster.getToDate())) {
                            log.info("Invalid toDate in request");
                            stringBuilder.append("To and From date is invalid.");
                        }
                    }
                }
            }
            Set<String> districtWiseDataSet = ImmutableSet.copyOf(misEnrollmentReqV3.getDistrictList().stream().map(DistrictWiseData::getDistrictCode).collect(Collectors.toList()));
            if (misEnrollmentReqV3.getDistrictList().size() != districtWiseDataSet.size()) {
                stringBuilder.append("Duplicate entries found in the data, kindly resend.");
            } else if (districtWiseDataSet.size() != GetCommonData.STATE_DISTRICT_LIST.size()) {
                stringBuilder.append("Values for all districts is not sent as per LGD master.");
            }
        } catch (Exception e) {
            log.error("Exception in checkInSufficientAccHolValidation() --------> ", e);
            stringBuilder.append("Technical error.");
        }
        return stringBuilder.toString();
    }
}
