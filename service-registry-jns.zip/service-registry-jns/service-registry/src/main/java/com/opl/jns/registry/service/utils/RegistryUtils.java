package com.opl.jns.registry.service.utils;

import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.Date;

/**
 * @author - Maaz Shaikh
 * @Date - 7/11/2023
 */
@Slf4j
public class RegistryUtils {

    public static final String APPLICATION_ID = "applicationId";
    public static final String PRODUCT_DOCUMENT_MAPPING_ID = "productDocumentMappingId";
    public static final String USER_TYPE = "userType";
    public static final String ORIGINAL_FILE_NAME = "originalFileName";
    public static final String CLAIM_ID = "claimId";
	public static final String JNS_APP_CODE_INITIAL = "JNS_APP_CODE_INITIAL";
	public static final String JNS = "JNS";
	public static final String CHAR_DASH = "-";
	public static final String PMJJBY_ENROLLMENT_AGE_LIMIT = "PMJJBY_ENROLLMENT_AGE_LIMIT";
	public static final String PMSBY_ENROLLMENT_AGE_LIMIT = "PMSBY_ENROLLMENT_AGE_LIMIT";
	
	public static final String PMSBY_CLAIM_AGE_LIMIT = "PMSBY_CLAIM_AGE_LIMIT";
	public static final String PMJJBY_CLAIM_AGE_LIMIT = "PMJJBY_CLAIM_AGE_LIMIT";
	public static final String AADHAR ="Aadhar";
	
	public static String getPolicyYearToYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue();
		int nextYear=current;
		if(month > 5) {
			nextYear = current + 1;
		}else {
			current =current - 1;
		}
		return (current%100)+CHAR_DASH+(nextYear%100);
	}


	public static final String CLAIM_INITIATED_MSG = "Claim has already been initiated for the selected Account Holder";
	public static final String CLAIM_INITIATED_MSG_1 = "Claim details already received. Kindly send Claim documents.";
//	public static final String CLAIM_ALREADY_COMPLETE_MSG = "Claim has already complete for the selected holder !!";
	public static final String CLAIM_ALREADY_PAID_MSG = "Claim has already been paid for the selected A/C holder !!";
	public static final String CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_ALREADY_REJETED_DEATH_MSG = "Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_INITIATED_OTR_SRC_MSG = "Claim has already been initiated for the selected Account Holder in Other source";
	public static final String CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_SUM_INSURED_EXHUSTED_MSG = "Sum Insured has been exhausted for the selected A/C holder.";
//	public static final String CLAIM_SUBMISSION_IN_PROGRESS_MSG = "Kindly complete the claim application that is pending for submission and then proceed here.";
	public static final String CLAIM_DEATH_MSG = "Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_DEATH_PAID_MSG = "Death Claim has already been paid for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_MSG = "Accidental Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_PAID_MSG = "Accidental Death Claim has already been paid for the selected A/C holder";
	public static final String DEATH = "Death";
	public static final String TOTAL_DISABILITY = "Total Disability";
//	public static final String PMSBY_TOTAL_CLAIM_AMOUNT = "PMSBY_TOTAL_CLAIM_AMOUNT";
//	public static final String PROCEED = "Proceed";
//	public static final int NATURE_OF_LOSS_DISABLITY = 2;
//	public static final int TYPE_OF_DISABLITY_ID = 1;
	public static final long LONG_2 = 2L;
	public static final int INT_0 = 0;

	public static final String PUSH_CLAIM_DATA = "PUSH_CLAIM_DATA";
	public static final String PUSH_CLAIM_REVISED_DOCS = "PUSH_CLAIM_REVISED_DOCS";
	public static final int INT_200 = 200;
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;

	public static final int PUSH_RE_TRY_APPLICATION = 1;
	public static final int PUSH_RE_TRY_CLAIM = 2;

	public static <T extends APIResponseV2> T setTokenAndTimeStemp(T commonResponse, HttpServletRequest request){
		HttpServletRequest servletWebRequest =  request;
		if(null != servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN)) {
			commonResponse.setToken(servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
		}
		commonResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		return commonResponse;
	}
	public static <T extends APIResponseV2> T setTokenAndTimeStempV2(T commonResponse, HttpServletRequest request){
		HttpServletRequest servletWebRequest =  request;
		if(null != servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN)) {
			commonResponse.setToken(servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN).toString());
		}
		commonResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		return commonResponse;
	}
	
	public static <T extends APIResponseV3> T setTokenAndTimeStempV3(T commonResponse, String token) {
		commonResponse.setToken(token);
		commonResponse.setTimeStamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		return commonResponse;
	}

	public static LocalDateTime getTimeStamp(){
		return new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}
	
//	public static Object setTokenAndTimeStempV3ForClaim(ClaimDetailsResProxyV2 commonResponse, String token) {
//		commonResponse.setToken(token);
//		commonResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
//		return commonResponse;
//	}
}
