package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.PUBClaimMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface PUBClaimMasterRepo extends JpaRepository<PUBClaimMaster, Long> {

	PUBClaimMaster findByClaimIdAndIsActiveTrue(final long applicationId);

	
	public List<PUBClaimMaster> findAllByApplicationMasterInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long insOrgId, Date claimFromDate, Date claimToDate);
	
	public List<PUBClaimMaster> findAllByApplicationMasterOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long orgId, Date claimFromDate, Date claimToDate);
	
	PUBClaimMaster findByIdAndIsActiveTrue(final long applicationId);
	
	PUBClaimMaster findByIdAndClaimStatusAndIsActiveTrue(final long applicationId,Integer claimStatus);

	PUBClaimMaster findByIdAndApplicationMasterOrgIdAndIsActiveTrue(Long claimId, Long orgId);

	PUBClaimMaster findByIdAndIsActiveTrueAndApplicationMasterInsurerOrgId(Long claimId, Long insOrgId);

	public Long countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(Long applicationId, List<Integer> status);
	
	public List<PUBClaimMaster> findByApplicationMasterIdAndIsActiveTrue(Long applicationId);

	PUBClaimMaster findByIdAndApplicationMasterUrnAndIsActiveTrue(Long claimReferenceId,String urn);


}
