package com.opl.jns.registry.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "JNS_ENRL_DATA", catalog = DBNameConstant.JNS_REPORTS, schema = DBNameConstant.JNS_REPORTS, indexes = {
        @Index(columnList = "type", name = DBNameConstant.JNS_REPORTS + "_type_idx"),
        @Index(columnList = "type, org_id, scheme_id", name = DBNameConstant.JNS_REPORTS + "_type_org_id_scheme_id_idx")
})
public class JnsEnrlData implements Serializable {

    private static final long serialVersionUID = -3620917953347909128L;

    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "jns_enrl_data_seq_gen")
    @GenericGenerator(name = "jns_enrl_data_seq_gen", strategy = "increment", parameters = {@org.hibernate.annotations.Parameter(name = "schema", value = DBNameConstant.JNS_REPORTS)})
    private Long id;

    @Column(name = "type", nullable = false, columnDefinition = "varchar(10) default ''")
    private Integer type;

    @Column(name = "scheme_id", nullable = false)
    private Integer schemeId;

    @Column(name = "org_id", nullable = false, columnDefinition = "number(19) default ''")
    private Long orgId;

    @Column(name = "state_code", nullable = false, columnDefinition = "varchar(10) default ''")
    private String stateCode;

    @Column(name = "district_code", nullable = false, columnDefinition = "varchar(10) default ''")
    private String districtCode;

    @Column(name = "total_received_enrollments", nullable = false, columnDefinition = "number(19) default 0")
    private Long totalReceivedEnrollments;

    @Column(name = "calculated_premium", nullable = false, columnDefinition = "number(19) default 0")
    private Long calculatedPremium;

    @Column(name = "pushed_enrollments", nullable = false, columnDefinition = "number(19) default 0")
    private Long pushedEnrollments;

    @Column(name = "pushed_premium", nullable = false, columnDefinition = "number(19) default 0")
    private Long pushedPremium;

    @Column(name = "version", columnDefinition = "number(19) default 0")
    private Long version;

    public JnsEnrlData(Long orgId, Long stateCode, Long districtCode, Long totalReceivedEnrollments, Double calculatedPremium, Long pushedEnrollments, Double pushedPremium) {
        this.orgId = orgId;
        this.stateCode = stateCode.toString();
        this.districtCode = districtCode.toString();
        this.totalReceivedEnrollments = totalReceivedEnrollments;
        this.calculatedPremium = calculatedPremium.longValue();
        this.pushedEnrollments = pushedEnrollments;
        this.pushedPremium = pushedPremium.longValue();
    }

}
