package com.opl.jns.registry.service.repository;

import com.opl.jns.registry.service.domain.PUBApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface PUBApplicationMasterRepo extends JpaRepository<PUBApplicationMaster, Long> {

	PUBApplicationMaster findByApplicationIdAndIsActiveTrue(long applicationId);
	PUBApplicationMaster findByApplicationId(long applicationId);
	PUBApplicationMaster findFirstByApplicationIdAndIsActiveTrue(long applicationId);

	List<PUBApplicationMaster> findAllByInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long insOrgId, Date fromCreatedDate, Date toCreatedDate);

	List<PUBApplicationMaster> findAllByOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long orgId, Date fromCreatedDate, Date toCreatedDate);

	PUBApplicationMaster findByIdAndIsActiveTrue(Long id);

	PUBApplicationMaster findByIdAndOrgIdAndIsActiveTrue(Long refId, Long bankOrgId);
	PUBApplicationMaster findByIdAndInsurerOrgIdAndIsActiveTrue(Long refId, Long insOrgId);

}
