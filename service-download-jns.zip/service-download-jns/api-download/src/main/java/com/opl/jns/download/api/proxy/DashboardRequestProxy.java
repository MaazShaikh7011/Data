package com.opl.jns.download.api.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
    
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardRequestProxy {
    private Long schemeId;
    private Date fromDate;
    private Date toDate;
    private Long pageNo;
    private Long pageSize;
    private List<Long> orgIds;
    private List<Long> schemeIds;
    private Long orgId;
    private Date date;

}
