package com.opl.jns.download.api.proxy;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentListRequestProxy {
	 private Long totalcount;
	 private Long rowNo;
	 private Long id;
	 private Long applicationId;
	 private String customerAccountNumber;
	 private String urn;
	 private String mobileNumber;
	 private String schemeName;
	 private String enrollDate;
	 private Date modifiedDate;
	 private String source;
	 private String transactionType;
	 private String channelId;
	 private String cif;
	 private String insuredName;
	 private String fatherHusbandName;
	 private String dob;
	 private String gender;
	 private String masterPolicyNumber;
	 private String kycIdName;
	 private String pan;
	 private String kycIdNumber1;
	 private String bankName;
	 private String branchCode;
	 private String branchName;
	 private String roName;
	 private String roCode;
	 private String zoName;
	 private String zoCode;
	 private String userId1;
	 private String userId2;
	 private Long pinCode;
	private String city;
	private String district;
	private String state;
	private String geographicalClassification;
	private String transactionDate;
	private String transactionUTR;
	private Double transactionAmount;
	private String nomineeName;
	private String nomineeDoB;
	private String relationOfNominee;
	private String guardianName;
	private String relationshipOfGuardian;
	private String coiGenerationDate;
	private String reasonForRejection;
	private String requestDate;
	private String endorsementType;
	private String endorsementDate;
	private Long insuredOrgId;
	
}	
	