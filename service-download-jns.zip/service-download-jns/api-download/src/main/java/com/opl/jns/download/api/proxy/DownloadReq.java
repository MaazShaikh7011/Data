package com.opl.jns.download.api.proxy;

import java.util.Date;

import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DownloadReq {

	private Long id;

    private String tokenId;

	private Boolean isDownload;

	@Temporal(TemporalType.TIMESTAMP)
	private Date downloadDate;

	private Boolean isMailSent;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	private Long createdBy;

	private Long docStorageId;

	private String apiStatus;

	private String errorMessage;
	
	private Long schemeId;
}
