package com.opl.jns.download.api.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardResProxy {
    private Long id;

    private String tokenId;

    private Long schemeId;

    private Long orgId;

    private Long insurerOrgId;

    private String fileName;

    private Long docStorageId;

    private String errorMessage;

    private Boolean isActive;

    private Boolean isSuccess;

    private Date createdDate;

    private Date completionDate;

    private Long totalCount;

    private String orgName;
}
