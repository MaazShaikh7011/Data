package com.opl.jns.download.api.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MisDocDetailsProxy {
    private Long id;
    private Date createdDate;
    private String type;
    private Long dmsStorageId;
    private String fileName;
    private Integer status;
    private Date fromDate;
    private Date toDate;
}
