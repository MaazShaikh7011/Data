package com.opl.jns.download.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ho_enrollment_download_history",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE)
public class HoEnrollmentDownloadHistory {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ho_enrollment_download_history_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "ho_enrollment_download_history_seq_gen", sequenceName = "ho_enrollment_download_history_seq", allocationSize = 1)
    private Long id;

    @Column(name = "token_id", nullable = true)
    private String tokenId;

    @Column(name = "scheme_id", nullable = false)
    private Long schemeId;

    @Column(name = "org_id", nullable = false)
    private Long orgId;

    @Column(name = "insurer_org_id", nullable = true)
    private Long insurerOrgId;

    @Column(name = "file_name", nullable = true)
    private String fileName;

    @Column(name = "doc_storage_id", nullable = true)
    private Long docStorageId;

    @Column(name = "error_message", nullable = true)
    private String errorMessage;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_success")
    private Boolean isSuccess;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "completion_date", nullable = true)
    private Date completionDate;

    @Column(name = "org_name", nullable = true)
    private String orgName;

    @Column(name = "insurer_name", nullable = true)
    private String insurerName;
}
