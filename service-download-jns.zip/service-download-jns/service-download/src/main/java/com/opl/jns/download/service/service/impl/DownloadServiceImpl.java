package com.opl.jns.download.service.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.download.api.proxy.DownloadReq;
import com.opl.jns.download.service.domain.DownloadRequest;
import com.opl.jns.download.service.repository.DownloadRequestRepository;
import com.opl.jns.download.service.service.DownloadService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DownloadServiceImpl implements DownloadService {

	@Autowired
	DownloadRequestRepository  downloadRequestRepository;
	
	@Autowired
	private DMSClient dmsClient;
	
	@Override
	public CommonResponse checkIfDownload(DownloadReq req) {
		try {
			DownloadRequest downloadRequest = downloadRequestRepository.findFirstByCreatedByAndSchemeIdOrderByCreatedDateDesc(req.getCreatedBy(), req.getSchemeId());
			if (!OPLUtils.isObjectNullOrEmpty(downloadRequest) &&  !OPLUtils.isObjectNullOrEmpty(downloadRequest.getApiStatus())) {
				if(downloadRequest.getApiStatus().equalsIgnoreCase("In Progress")) {
					int i = DateUtils.addMinutes(downloadRequest.getCreatedDate(), 45).compareTo(new Date());
					if(i < 0) {
						downloadRequest.setApiStatus("Failed");
						downloadRequest.setIsDownload(Boolean.TRUE);
						downloadRequest.setDownloadDate(new Date());
						downloadRequestRepository.save(downloadRequest);
					}
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(downloadRequest)) {
				return new CommonResponse("Exception is getting while checkIfDownload", HttpStatus.NO_CONTENT.value(),
						Boolean.FALSE);
			}
			DownloadReq request = new DownloadReq();
			BeanUtils.copyProperties(downloadRequest, request);
			return new CommonResponse("successfully get List", request, HttpStatus.OK.value(), Boolean.TRUE);

		} catch (Exception e) {
			log.error("Exception is getting while get checkIfDownload For Enrollment", e);
			return new CommonResponse("Exception is getting while checkIfDownload For Enrollment",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public CommonResponse downloadHistory(DownloadReq reqData) {
		try {
			List<DownloadRequest> downloadRequestList = downloadRequestRepository
					.findByCreatedByAndSchemeIdAndIsDownloadIsTrueOrderByCreatedDateDesc(reqData.getCreatedBy(),
							reqData.getSchemeId());
			if (OPLUtils.isListNullOrEmpty(downloadRequestList)) {
				return new CommonResponse("Exception is getting while downloadHistory For Enrollment",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}
			List<DownloadReq> downloadReqList = new ArrayList<DownloadReq>();
			DownloadReq req = null;
			for (DownloadRequest downloadRequest : downloadRequestList) {
				req = new DownloadReq();
				BeanUtils.copyProperties(downloadRequest, req);
				downloadReqList.add(req);
			}
			return new CommonResponse("successfully get DownloadHistory List", downloadReqList, HttpStatus.OK.value(),
					Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting while get downloadHistoryList", e);
			return new CommonResponse("Exception is getting while downloadHistoryList For Enrollment",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public byte[] downloadEnrollmentData(DownloadReq req) {
		try {
			DownloadRequest documentRequest = new DownloadRequest();
			byte[] zipByte = null;
			if (!OPLUtils.isObjectNullOrEmpty(req.getTokenId())
					&& !OPLUtils.isObjectNullOrEmpty(req.getDocStorageId())) {
				documentRequest = downloadRequestRepository.findByTokenId(req.getTokenId());
				zipByte = dmsClient.productDownloadDocuments(req.getDocStorageId().toString());
				if (!OPLUtils.isObjectNullOrEmpty(zipByte)) {
					documentRequest.setIsDownload(true);
					documentRequest.setDownloadDate(new Date());
					documentRequest.setApiStatus("Success");
					downloadRequestRepository.save(documentRequest).getTokenId();
				}
			}
			return zipByte;
		} catch (Exception e) {
			log.error("Exception is getting while downloadEnrollmentData in ZipFile", e);
		}
		return null;
	}
}
