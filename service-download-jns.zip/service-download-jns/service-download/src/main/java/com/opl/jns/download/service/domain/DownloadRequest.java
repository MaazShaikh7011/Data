package com.opl.jns.download.service.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "download_request",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE)
public class DownloadRequest {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "download_request_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "download_request_seq_gen", sequenceName = "download_request_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "token_id", nullable = true)
	private String tokenId;
	
	@Column(name = "is_download", nullable = true)
	private Boolean isDownload;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "download_date", nullable = true)
	private Date downloadDate;
	
    @OneToOne(cascade = CascadeType.ALL ,fetch = FetchType.LAZY)
    @JoinColumn(name = "audit_id")
    private DownloadRequestDetails logAudit;
	
	@Column(name = "is_mail_sent", nullable = true)
	private Boolean isMailSent;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;
	
	@Column(name = "doc_storage_id", nullable = true)
	private Long docStorageId;
	
	@Column(name = "api_status", nullable = true)
	private String apiStatus;
	
	@Column(name = "error_message", nullable = true)
	private String errorMessage;
	
	@Column(name = "scheme_id", nullable = true)
	private Long schemeId;


}
