package com.opl.jns.download.service.config;
//package com.opl.api.download.config;
//
//import java.io.File;
//import java.io.IOException;
//
//import org.apache.poi.ss.formula.functions.T;
//import org.springframework.batch.item.ItemReader;
//import org.springframework.batch.item.json.JacksonJsonObjectReader;
//import org.springframework.core.io.Resource;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//public class JsonFileItemReader<EnrollmentListRequestProxy> implements ItemReader<EnrollmentListRequestProxy> {
//
////	@Override
////	public EnrollmentListRequestProxy read()
////			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
////		// TODO Auto-generated method stub
////		return null;
////	}
//
////	 private final JsonItemReader<T> jsonItemReader;
////	 
////	public JsonFileItemReader(String[] jsonFilePaths, Class<T> targetType) {
////		System.err.println("paths: "+jsonFilePaths);
////		
////        jsonItemReader = new JsonItemReaderBuilder<T>()
////                .jsonObjectReader(new JacksonJsonObjectReader<>(targetType))
////                .resource(new FileSystemResource(jsonFilePaths[0])) // Initialize with the first file
////                .name("jsonFileItemReader")
////                .build();
////        jsonItemReader.open(new ExecutionContext());
////        // Set up other files as resources
////        for (int i = 1; i < jsonFilePaths.length; i++) {
////        	  jsonItemReader.close();
////              jsonItemReader.setResource(new FileSystemResource(jsonFilePaths[i]));
////              jsonItemReader.open(new ExecutionContext());
////        }
////    }
////
////    @Override
////    public T read() throws Exception {
////        return jsonItemReader.read();
////    }
//    
////    public JsonFileItemReader(String jsonFilesFolderPath, Class<T> targetType) throws UnexpectedInputException, ParseException, Exception {
////        super((List<T>) loadJsonItems(jsonFilesFolderPath, targetType));
////    }
////
////    private static <T> List<EnrollmentListRequestProxy> loadJsonItems(String jsonFilesFolderPath, Class<T> targetType) throws UnexpectedInputException, ParseException, Exception {
////    	System.out.println("reader===========================================");
////        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
////        Resource[] resources = resolver.getResources("file:" + jsonFilesFolderPath + "/*.json");
////        JsonItemReader<T> jsonItemReader = null;
////        List<EnrollmentListRequestProxy> items = new ArrayList<>();
////        for (Resource resource : resources) {
////            jsonItemReader = new JsonItemReaderBuilder<T>()
////                    .jsonObjectReader(new JacksonJsonObjectReader<>(targetType))
////                    .resource(resource)
////                    .name("jsonItemReader")
////                    .build();
////            jsonItemReader.open(new ExecutionContext());
////
////            EnrollmentListRequestProxy item;
////            while ((item = (EnrollmentListRequestProxy) jsonItemReader.read()) != null) {            	
////                items.add(item);
////            }
////         
////        }
////        return items;
////    }
//
//
////	 private final JacksonJsonObjectReader<T> jsonObjectReader;
////	    private final Resource jsonResource;
////
////	    public JsonFileItemReader(Resource jsonResource, Class<? extends EnrollmentListRequestProxy> targetType) {
////	        this.jsonObjectReader = new JacksonJsonObjectReader(targetType);
////	        this.jsonResource = jsonResource;
////	    }
////
////	    @Override
////	    public T read() throws Exception {
////	         jsonObjectReader.open((Resource) jsonResource.getInputStream());
////	     
////
////	        return jsonObjectReader.read();
////
////	    }
//
//}