package com.opl.jns.download.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "week_master", catalog = DBNameConstant.JNS_REPORTS, schema = DBNameConstant.JNS_REPORTS, indexes = {
        @Index(columnList = "status", name = "STATUS_BASE_DATA")
})
public class WeekMaster implements Serializable {

    private static final long serialVersionUID = -3633810627118913143L;

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "from_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date fromDate;

    @Column(name = "to_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @Column(name = "status", nullable = false, columnDefinition = "number(1) default 0")
    private Integer status;

    public interface StatusEnum {
        int PENDING = 1;
        int IN_PROGRESS = 2;
        int COMPLETED = 3;
    }

}
