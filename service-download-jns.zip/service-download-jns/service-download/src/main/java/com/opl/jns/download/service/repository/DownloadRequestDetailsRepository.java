package com.opl.jns.download.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.download.service.domain.DownloadRequestDetails;

public interface DownloadRequestDetailsRepository extends JpaRepository<DownloadRequestDetails,Long>  {

}
