package com.opl.jns.download.service.config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Writer;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opl.jns.download.api.proxy.EnrollmentListRequestProxy;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ONLINE PSB LOANS LTD.
 * @version 1.0
 */

@EnableBatchProcessing
@Configuration
@Slf4j
public class BatchConfiguration {

	public String  testNew = null;

	private final String[] completedProxyKeys = new String[] { "rowNo", "source", "transactionType","endorsementType","channelId","urn","cif","insuredName", "fatherHusbandName","dob", "gender",
			"masterPolicyNumber", "enrollDate","customerAccountNumber","kycIdName","pan","kycIdNumber1",
			"bankName","branchCode","branchName","roName","roCode","zoName","zoCode","userId1","userId2","mobileNumber","pinCode",
			"city","district","state","geographicalClassification","nomineeName","nomineeDoB", "relationOfNominee",
			"guardianName", "relationshipOfGuardian","schemeName", "transactionDate", "transactionUTR", "transactionAmount","coiGenerationDate"};

	private final String[] transFailedProxyKeys = new String[] { "rowNo", "source", "transactionType","channelId","urn","cif","insuredName", "fatherHusbandName","dob", "gender",
			"masterPolicyNumber", "enrollDate","customerAccountNumber","kycIdName","pan","kycIdNumber1",
			"bankName","branchCode","branchName","roName","roCode","zoName","zoCode","userId1","userId2","mobileNumber","pinCode",
			"city","district","state","geographicalClassification","nomineeName","nomineeDoB", "relationOfNominee",
			"guardianName", "relationshipOfGuardian","schemeName", "transactionDate", "transactionUTR", "transactionAmount","requestDate"};

	private final String[] rejectedProxyKeys = new String[] { "rowNo", "source", "transactionType","channelId","urn","cif","insuredName", "fatherHusbandName","dob", "gender",
			"masterPolicyNumber", "enrollDate","customerAccountNumber","kycIdName","pan","kycIdNumber1",
			"bankName","branchCode","branchName","roName","roCode","zoName","zoCode","userId1","userId2","mobileNumber","pinCode",
			"city","district","state","geographicalClassification","nomineeName","nomineeDoB", "relationOfNominee",
			"guardianName", "relationshipOfGuardian","schemeName", "transactionDate", "transactionUTR", "transactionAmount","requestDate","reasonForRejection"};

	private final String[] endorsementProxyKeys = new String[] { "rowNo", "source", "transactionType","endorsementType","channelId","urn","cif","insuredName", "fatherHusbandName","dob", "gender",
			"masterPolicyNumber", "enrollDate","customerAccountNumber","kycIdName","pan","kycIdNumber1",
			"bankName","branchCode","branchName","roName","roCode","zoName","zoCode","userId1","userId2","mobileNumber","pinCode",
			"city","district","state","geographicalClassification","nomineeName","nomineeDoB", "relationOfNominee",
			"guardianName", "relationshipOfGuardian","schemeName", "transactionDate", "transactionUTR", "transactionAmount","endorsementDate"};

	private final String[] completedHeaders = new String[] { "Sr.No.", "Source", "Transaction Type","Endorsement Type", "Channel ID",
			"URN","CIF","Insured Name","Father/Husband's Name","DoB","Gender","Master Policy Number","Date of Enrollment",
			"A/C Number","KYC ID Name","PAN","KYC ID Number","Bank Name","Branch Code","Branch Name","RO Name",
			"RO Code","ZO Name","ZO Code","USER ID 1","USER ID 2","Mobile Number","Pincode","City",
			"District","State","Geographical Classification","Nominee Name","Nominee DoB","Relationship of Nominee",
			"Guardian Name","Relationship of Guardian","Scheme Name","Transaction Date","Transaction UTR","Transaction Amount","COI Generation Date"};

	private final String[] transFailedHeaders = new String[] { "Sr.No.", "Source", "Transaction Type", "Channel ID",
			"URN","CIF","Insured Name","Father/Husband's Name","DoB","Gender","Master Policy Number","Date of Enrollment",
			"A/C Number","KYC ID Name","PAN","KYC ID Number","Bank Name","Branch Code","Branch Name","RO Name",
			"RO Code","ZO Name","ZO Code","USER ID 1","USER ID 2","Mobile Number","Pincode","City",
			"District","State","Geographical Classification","Nominee Name","Nominee DoB","Relationship of Nominee",
			"Guardian Name","Relationship of Guardian","Scheme Name","Transaction Date","Transaction UTR","Transaction Amount","Request date"};

	private final String[] rejectedHeaders = new String[] { "Sr.No.", "Source", "Transaction Type", "Channel ID",
			"URN","CIF","Insured Name","Father/Husband's Name","DoB","Gender","Master Policy Number","Date of Enrollment",
			"A/C Number","KYC ID Name","PAN","KYC ID Number","Bank Name","Branch Code","Branch Name","RO Name",
			"RO Code","ZO Name","ZO Code","USER ID 1","USER ID 2","Mobile Number","Pincode","City",
			"District","State","Geographical Classification","Nominee Name","Nominee DoB","Relationship of Nominee",
			"Guardian Name","Relationship of Guardian","Scheme Name","Transaction Date","Transaction UTR","Transaction Amount","Request date","Reason for Rejection"};

	private final String[] endorsementHeaders = new String[] { "Sr.No.", "Source", "Transaction Type","Endorsement Type","Channel ID",
			"URN","CIF","Insured Name","Father/Husband's Name","DoB","Gender","Master Policy Number","Date of Enrollment",
			"A/C Number","KYC ID Name","PAN","KYC ID Number","Bank Name","Branch Code","Branch Name","RO Name",
			"RO Code","ZO Name","ZO Code","USER ID 1","USER ID 2","Mobile Number","Pincode","City",
			"District","State","Geographical Classification","Nominee Name","Nominee DoB","Relationship of Nominee",
			"Guardian Name","Relationship of Guardian","Scheme Name","Transaction Date","Transaction UTR","Transaction Amount","Endorsement Date"};

	@Autowired
	@Qualifier("dsEcr")
	private DataSource dataSource;


//	@Autowired
//	@Qualifier("tmr")
//	private JpaTransactionManager jpaTransactionManager;
//	@Override
//    @Autowired(required = false)
//    public void setDataSource(@Qualifier("batchDataSource") DataSource dataSource) {
//        super.setDataSource(dataSource);
//    }

	@Bean
	@StepScope
	public ItemReader<EnrollmentListRequestProxy> jsonReader(@Value("#{jobParameters[fullPathFileName]}") String pathToFile) throws FileNotFoundException, Exception {
		log.info("classpath: "+new ClassPathResource(pathToFile));

		JacksonJsonObjectReader<EnrollmentListRequestProxy> jsonObjectReader = new JacksonJsonObjectReader<>(EnrollmentListRequestProxy.class);
		Resource jsonResource = new FileSystemResource(pathToFile);
		jsonObjectReader.open(jsonResource);
		ObjectMapper objectMapper = new ObjectMapper();
		jsonObjectReader.setMapper(objectMapper);

		return new JsonItemReaderBuilder<EnrollmentListRequestProxy>()
				.jsonObjectReader(jsonObjectReader)
				.name("JsonItemReader")
				.strict(false)
				.build();

	}

	@Bean
	@StepScope
	public FlatFileItemWriter<EnrollmentListRequestProxy> writer(@Value("#{jobParameters[csvToken]}") String csvToken, @Value("#{jobParameters[csvFilePath]}") String outputPath, @Value("#{jobParameters[status]}") String status) {

		FlatFileItemWriter<EnrollmentListRequestProxy> writer = new FlatFileItemWriter<>();

		writer.setResource(new FileSystemResource(outputPath + "/EnrollmentList_" + 0 + "__" + csvToken + ".csv"));
		writer.setAppendAllowed(true);


		writer.setLineAggregator(new DelimitedLineAggregator<EnrollmentListRequestProxy>() {
			{
				setDelimiter(",");
				setFieldExtractor(new BeanWrapperFieldExtractor() {
					{
						if(!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 1) {
							setNames(completedProxyKeys);
						}
						else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 2){
							setNames(transFailedProxyKeys);
						}
						else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 3){
							setNames(rejectedProxyKeys);
						} else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 5){
							setNames(rejectedProxyKeys);
						}
						else {
							setNames(endorsementProxyKeys);
						}

					}
				});
			}
		});
		writer.setHeaderCallback(new FlatFileHeaderCallback() {
			@Override
			public void writeHeader(Writer writer) throws IOException {

				if(!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 1) {
					for(int i=0;i<completedHeaders.length;i++){
						if(i!=completedHeaders.length-1)
							writer.append(completedHeaders[i] + ",");
						else
							writer.append(completedHeaders[i]);
					}
				}
				else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 2){
					for(int i=0;i<transFailedHeaders.length;i++){
						if(i!=transFailedHeaders.length-1)
							writer.append(transFailedHeaders[i] + ",");
						else
							writer.append(transFailedHeaders[i]);
					}
				}
				else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 3){
					for(int i=0;i<rejectedHeaders.length;i++){
						if(i!=rejectedHeaders.length-1)
							writer.append(rejectedHeaders[i] + ",");
						else
							writer.append(rejectedHeaders[i]);
					}
				} else if (!OPLUtils.isObjectNullOrEmpty(status) && Integer.parseInt(status) == 5){
					for(int i=0;i<rejectedHeaders.length;i++){
						if(i!=rejectedHeaders.length-1)
							writer.append(rejectedHeaders[i] + ",");
						else
							writer.append(rejectedHeaders[i]);
					}
				}
				else{
					for(int i=0;i<endorsementHeaders.length;i++){
						if(i!=endorsementHeaders.length-1)
							writer.append(endorsementHeaders[i] + ",");
						else
							writer.append(endorsementHeaders[i]);
					}
				}

			}
		});

		log.info("CSV created: "+ outputPath + "/EnrollmentList_" + 0 + "__" + csvToken + ".csv");

		return writer;
	}

	@Bean
	public EnrollmentListRequestProxyProcessor processor() {
		return new EnrollmentListRequestProxyProcessor();
	}

	@Bean
	public Job runJob(JobRepository jobRepository,PlatformTransactionManager transactionManager) throws UnexpectedInputException, ParseException, Exception {
		return new JobBuilder("fetchEnrollmentListJob",jobRepository).incrementer(new RunIdIncrementer())
				.flow(step1(jobRepository,transactionManager)).end().build();

	}
	@Bean
	public Step step1(JobRepository jobRepository,
					  PlatformTransactionManager transactionManager) throws UnexpectedInputException, ParseException, Exception {
		return new StepBuilder("EnrollmentJson",jobRepository).<EnrollmentListRequestProxy, EnrollmentListRequestProxy>chunk(20,transactionManager)
				.reader(jsonReader(null))
				.processor(processor())
				.writer(writer(null,null,null))
//                .writer(multiCsvItemWriter(20))
//                .listener(stepExecutionListener())
//                .taskExecutor(taskExecutor())
				.transactionAttribute(attributesForTransaction())
				.build();
	}



	 // DISABLED SPRING BATCH TRANSACTION
	private DefaultTransactionAttribute attributesForTransaction() {
		DefaultTransactionAttribute attribute = new DefaultTransactionAttribute();
		attribute.setPropagationBehavior(Propagation.NOT_SUPPORTED.value());
		attribute.setIsolationLevel(Isolation.READ_UNCOMMITTED.value());
		return attribute;
	}

	private TaskExecutor taskExecutor() {

		SimpleAsyncTaskExecutor executor= new SimpleAsyncTaskExecutor();
		//CRETAES 5 THREAD TO WRITE DATA
		executor.setConcurrencyLimit(5);
		return executor;
	}
}
