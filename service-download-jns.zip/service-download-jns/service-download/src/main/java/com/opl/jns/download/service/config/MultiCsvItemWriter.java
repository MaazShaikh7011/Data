package com.opl.jns.download.service.config;

//package com.opl.api.download.config;
//
//import java.io.IOException;
//import java.io.Writer;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//import java.util.Locale;
//
//import org.codehaus.plexus.component.annotations.Component;
//import org.springframework.batch.core.JobParameters;
//import org.springframework.batch.core.StepExecution;
//import org.springframework.batch.core.annotation.BeforeStep;
//import org.springframework.batch.item.ExecutionContext;
//import org.springframework.batch.item.ItemWriter;
//import org.springframework.batch.item.file.FlatFileHeaderCallback;
//import org.springframework.batch.item.file.FlatFileItemWriter;
//import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
//import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.core.io.FileSystemResource;
//
//import com.opl.api.download.jns.proxy.EnrollmentListRequestProxy;
//
//import lombok.AllArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//@AllArgsConstructor
//@Slf4j
//public class MultiCsvItemWriter implements ItemWriter<EnrollmentListRequestProxy> {
//
//	private final Integer maxItemsPerFile;
//	private String outputPath;
//
////	@Value("#{jobParameters[csvToken]}")
//	private String csvToken;
//
//	private int itemCount = 0;
//	private int fileIndex = 0;
//	private FlatFileItemWriter<EnrollmentListRequestProxy> writer;
//
//	private StepExecution stepExecution;
//
////	Date now = new Date(); // java.util.Date, NOT java.sql.Date or java.sql.Timestamp!
////	String format1 = new SimpleDateFormat("yyyy-MM-dd'-'HH-mm-ss-SSS", Locale.forLanguageTag("tr-TR")).format(now);
//
//	private final String[] proxyKeys = new String[] { "totalcount", "source", "transactionType", "channelId", "urn",
//			"cif", "insuredName", "fatherHusbandName", "dob", "gender", "masterPolicyNumber", "enrollDate",
//			"customerAccountNumber", "kycIdName", "pan", "aadhaar", "bankName", "bankCode", "branchName", "roName",
//			"roCode", "zoName", "zoCode", "userId1", "userId2", "mobileNumber", "pinCode", "city", "district", "state",
//			"geographicalClassification", "nomineeName", "nomineeDoB", "relationOfNominee", "guardianName",
//			"relationshipOfGuardian", "schemeName", "transactionDate", "transactionUTR", "transactionAmount" };
//
//	private final String[] headers = new String[] { "Sr. NO.", "Source", "Transaction Type", "channel ID", "URN", "CIF",
//			"Insured Name", "Fathe/Husbans's Name", "DOB", "Gender", "Master Policy Number", "Date Of Enrollment",
//			"A/C Number", "Kyc ID Name", "PAN", "Aadhar", "Bank Name", "Bank Code", "Branch Name", "RO Name", "RO Code",
//			"ZO Name", "ZO Code", "USER ID 1", "USER ID 2", "Mobile Number", "Pincode", "City", "District", "State",
//			"Geographical Classification", "Nominee Name", "Nominee DOB", "Relation Of Nominee", "Guardian Name",
//			"Relationship of Guardian", "Scheme Name", "Transaction Date", "Transaction UTR", "Transaction Amount" };
//
//	public MultiCsvItemWriter(Integer maxItemsPerFile) {
//		this.maxItemsPerFile = maxItemsPerFile;
////		this.outputPath = outputPath;
////		this.csvToken = csvToken;
//	}
//
//	@Override
//	public void write(List<? extends EnrollmentListRequestProxy> items) throws Exception {
//		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
//		csvToken = parameters.getString("csvToken");
//		outputPath=parameters.getString("csvFilePath");
//
//		if (writer == null || itemCount + items.size() > maxItemsPerFile) {
//			createNewWriter();
//			itemCount = 0;
//		}
////        writer.open(new ExecutionContext());
//		writer.write(items);
//		itemCount += items.size();
//		if (writer != null) {
//			writer.close();
//		}
//	}
//
//	private void createNewWriter() throws Exception {
//		
//		try {
////        currentWriter = new FlatFileItemWriter<>();
////        currentWriter.setResource(new FileSystemResource(outputPath + "/output" + fileIndex + ".csv"));
////
////        // Configure the line aggregator and field extractor based on your data model
////        DelimitedLineAggregator<T> lineAggregator = new DelimitedLineAggregator<>();
////        lineAggregator.setDelimiter(",");
////        BeanWrapperFieldExtractor<T> fieldExtractor = new BeanWrapperFieldExtractor<>();
////        fieldExtractor.setNames(new String[]{"property1", "property2"}); // Set property names
////        lineAggregator.setFieldExtractor(fieldExtractor);
////        currentWriter.setLineAggregator(lineAggregator);
////
////        currentWriter.afterPropertiesSet();
////        currentWriter.open(new ExecutionContext());
////
////       
////    
//			log.info("Write csv :" + csvToken);
//			writer = new FlatFileItemWriter<>();
//			writer.setResource(
//					new FileSystemResource(outputPath + "/EnrollmentList_" + fileIndex + "__" + csvToken + ".csv"));
//			writer.setAppendAllowed(true);
//
//			writer.setLineAggregator(new DelimitedLineAggregator<EnrollmentListRequestProxy>() {
//				{
//					setDelimiter(",");
//					setFieldExtractor(new BeanWrapperFieldExtractor<EnrollmentListRequestProxy>() {
//						{
//							setNames(proxyKeys);
//						}
//					});
//				}
//			});
//
//			writer.setHeaderCallback(new FlatFileHeaderCallback() {
//				@Override
//				public void writeHeader(Writer writer) throws IOException {
//					for (int i = 0; i < headers.length; i++) {
//						if (i != headers.length - 1)
//							writer.append(headers[i] + ",");
//						else
//							writer.append(headers[i]);
//					}
//				}
//			});
//			writer.open(new ExecutionContext());
//			writer.afterPropertiesSet();
//			log.info("CSV created");
////        writer.close();
//			fileIndex++;
//		} catch (Exception e) {
//			log.error("CSV not created." + e.getMessage());
//		}
//
//	}
//
//	@BeforeStep
//	public void saveStepExecution(StepExecution stepExecution) {
//		this.stepExecution = stepExecution;
//	}
//}

