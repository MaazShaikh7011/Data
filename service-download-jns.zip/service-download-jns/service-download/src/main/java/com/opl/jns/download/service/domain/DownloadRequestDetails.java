package com.opl.jns.download.service.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "download_request_details",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE)
public class DownloadRequestDetails {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "download_request_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "download_request_details_seq_gen", sequenceName = "download_request_details_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "filter_json", nullable = true)
	private String filterJson;
    
    @OneToOne(cascade = CascadeType.ALL,mappedBy = "logAudit")
    private DownloadRequest downloadRequest;
}
