package com.opl.jns.download.service.schedular;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.config.repository.UserOrganizationMasterRepoV3;
import com.opl.jns.config.utils.EnvironmentUtils;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.download.api.proxy.DashboardRequestProxy;
import com.opl.jns.download.api.proxy.EnrollmentListRequestProxy;
import com.opl.jns.download.service.domain.HoEnrollmentDownloadHistory;
import com.opl.jns.download.service.repository.CommonRepository;
import com.opl.jns.download.service.repository.HoEnrollmentDownloadRepository;
import com.opl.jns.download.service.service.CommonService;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.SchemeMaster;
import com.spire.xls.CellRange;
import com.spire.xls.ExcelVersion;
import com.spire.xls.IgnoreErrorType;
import com.spire.xls.Workbook;
import com.spire.xls.Worksheet;

import lombok.extern.slf4j.Slf4j;
@Component
//@Transactional
@Slf4j
public class EnrollmentReportScheduler {

    @Autowired
    private CommonRepository commonRepository;

    @Autowired
    private UserOrganizationMasterRepoV3 userOrganizationMasterRepoV3;

    @Autowired
    private CommonService commonService;

    @Autowired
    private HoEnrollmentDownloadRepository downloadRepository;

    @Autowired
    private DMSClient dmsClient;

    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job job;

    @Autowired
    private Environment environment;

    private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(DateUtils.DateFormat.DD_MMM_YYYY);

    private static final DateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DateFormat.DD_MMM_YYYY);

    private static final String OUTPUT_FILE_PATH = "/EnrollmentList_" + 0 + "__";

//    private static final String OUTPUT_FOLDER_PATH = "C:/Users/HarshPanchal/Music/D/jns-service/service-download-jns";

    @Value("${com.ans.user.upload.FilePath}")
    private String OUTPUT_FOLDER_PATH;

    private static final Integer PAGINATION_FROM = 0;
    private static final Integer PAGINATION_TO = 1000000;
    private static final Integer COMPLETED = 1;
    private static final Integer COI_GENERATED_DATE = 1;

    private static final String ERROR_WHILE_GENERATING_EXCEL_FILE = "Error while generating Excel file";
    private static final String ERROR_WHILE_GENERATING_CSV_FILE = "Error while generating csv file";
    private static final String ERROR_WHILE_JOB_PROCESSING = "Error while JOB processing";
    private static final String ERROR_WHILE_UPLOADING_FILE_TO_DMS = "Error while uploading file to DMS";

    @Scheduled(cron = "${cronForEnrollmentDownload}")
    public void generateCsvForEnrollment() {
		try {
			String value = EnvironmentUtils.DAILY_HO_DOWNLOAD_FILE_SCHEDULER_ENABLE.getValue();
			if (value != null && "ON".equalsIgnoreCase(value)) {
				log.info("START generateCsvForEnrollment SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
				List<Long> orgIds = getOrgIds();
				List<Long> schemeList = new ArrayList<>(
						Arrays.asList(SchemeMaster.PMSBY.getId(), SchemeMaster.PMJJBY.getId()));
				String fromToDate = LocalDate.now().plusDays(-1).format(dateFormat);
//                String toDate = LocalDate.now().format(dateFormat);
				getDataOrgWise(orgIds, schemeList, fromToDate, Boolean.FALSE);
				log.info("END DOWNLOAD SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
			} else {
				log.info("DAILY_HO_DOWNLOAD_FILE_SCHEDULER_ENABLE OFF FROM ENVIRONMENT PROPERTY");
			}			
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPDATE POLICY DATA ------------------", e);
        }
    }

    public void generateCsvForEnrollmentForManual(DashboardRequestProxy req) {
        try {
            log.info("START generateCsvForEnrollmentForManual SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
            
            for (Date date = req.getFromDate(); !date.after(req.getToDate()); date = org.apache.commons.lang.time.DateUtils.addDays(date, 1)) {
                System.out.println(date);
                String fromToDate = simpleDateFormat.format(date);
                getDataOrgWise(req.getOrgIds(),req.getSchemeIds(),fromToDate,Boolean.TRUE);
            }
            log.info("END DOWNLOAD SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPDATE POLICY DATA ------------------", e);
        }
    }

    private List<Long> getOrgIds(){
        log.info("ENTER INTO GET ORG IDS ---------------------");
        List<Map<Long, String>> orgList = userOrganizationMasterRepoV3.findByUserTypeIdAndIsActiveTrueAndIsBorrowerDisplayOrderByDisplayOrgNameAsc(2l);
        List<Long> keys = new ArrayList<>();
        orgList.forEach(item -> keys.add(Long.valueOf(String.valueOf(item.get("id")))));
        log.info("EXIT FRON GET ORG IDS ---------------------");
        return keys;
    }

    private void getDataOrgWise(List<Long> orgIds,List<Long> schemeList,String fromToDate,Boolean isManual) {
        for (Long orgId:orgIds) {
            for (Long schemeId:schemeList) {
                try {
                    Map<String, Object> request = prepareRequestForGetData(orgId,schemeId,fromToDate);
                    generateExcel(request,orgId,schemeId,isManual);
                } catch (Exception e) {
                    log.error("ERROR WHILE CALLING SPRING BATCH FOR ORG ID :::: " + orgId,e);
                }
            }
        }
    }

    private Map<String,Object> prepareRequestForGetData(Long orgId,Long schemeId,String fromToDate){
        Map<String,Object> json = new HashMap<>();
        json.put("schemeId", schemeId);
        json.put("orgId",orgId);
        json.put("status",COMPLETED);
        json.put("fromDate",fromToDate);
        json.put("toDate",fromToDate);
        json.put("paginationFROM",PAGINATION_FROM);
        json.put("paginationTO",PAGINATION_TO);
        json.put("statusDate",COI_GENERATED_DATE);
        return json;
    }

    public void generateExcel(Map<String,Object> request,Long orgId,Long schemeId,Boolean isManual){
        File csvFile = null;
        File excelFile = null;
        String jsonFilepath = null;
        HoEnrollmentDownloadHistory historyAudit = null;
        try {
            /* GET DATA FROM SP */
            String response = dataFromSp(request);
            Long insurerOrgId = null;
            String orgName = null;
            String insurerName = null;
            if(response != null) {
                List<EnrollmentListRequestProxy> res = MultipleJSONObjectHelper.getListOfObjects(response,null, EnrollmentListRequestProxy.class);
                if(res.size()>0) {
                    insurerOrgId = res.get(0).getInsuredOrgId();
                    orgName = res.get(0).getBankName();
                    insurerName = res.get(0).getInsuredName();
                }
            }


            if(response != null) {
                log.info("DATA FOUND FOR ORG ID ::::[{}] AND SCHEME ID :::: [{}]",orgId,schemeId);
                /* GENERATE UNIQUE TOKEN */
                String token = generateTokenId(schemeId, orgId);
                historyAudit = new HoEnrollmentDownloadHistory();
                historyAudit.setOrgId(orgId);
                historyAudit.setSchemeId(schemeId);
                historyAudit.setCreatedDate(new Date());
                historyAudit.setCompletionDate(isManual ? simpleDateFormat.parse(request.get("fromDate").toString()) : Date.from(LocalDate.now().plusDays(-1).atStartOfDay(ZoneId.systemDefault()).toInstant()));
                historyAudit.setTokenId(token);
                historyAudit.setIsActive(Boolean.TRUE);
                historyAudit.setInsurerOrgId(insurerOrgId);
                historyAudit.setOrgName(orgName);
                historyAudit.setInsurerName(insurerName);

                /* CREATE JSON FILE AND WRITE DATA INTO JSON */
                jsonFilepath = OUTPUT_FOLDER_PATH + OUTPUT_FILE_PATH +token + ".json";
                FileWriter write = new FileWriter(jsonFilepath);
                BufferedWriter bufferedWriter = new BufferedWriter(write);
                bufferedWriter.write(response);
                bufferedWriter.close();
                write.close();

                /* START JOB PROCESSING */
                JobExecution job = commonService.jobStart(token,OUTPUT_FOLDER_PATH,OUTPUT_FILE_PATH);
                if(job != null && !job.isRunning() && job.getStatus() == BatchStatus.COMPLETED) {
                    csvFile = new File(OUTPUT_FOLDER_PATH + OUTPUT_FILE_PATH + token + ".csv");
                    if(csvFile.exists()) {
                        log.info("Absolute file path of csv :::: {}",csvFile.getAbsolutePath());
//                        convertCsvToExcel(csvFile);
//                        excelFile = new File(OUTPUT_FOLDER_PATH + OUTPUT_FILE_PATH + token + ".xlsx");
                        if(csvFile.exists()) {
                            Long storageId = uploadToDMS(csvFile);
                            if (storageId != null) {
                                historyAudit.setDocStorageId(storageId);
                                historyAudit.setIsSuccess(Boolean.TRUE);
                            } else {
                                log.info("DMS ERROR OCCURED FOR ORG ::::: [{}] AD SCHEME :::: [{}] AND FILE NAME ::::::: [{}]",orgId,schemeId,csvFile.getName());
                                updateErrorMessageAndStatus(historyAudit,ERROR_WHILE_UPLOADING_FILE_TO_DMS,Boolean.FALSE);
                            }
                            historyAudit.setFileName(csvFile.getName());
                        } else {
                            log.info("ERROR WHILE GENERATING EXCEL FILE FOR ORG ::::: [{}] AD SCHEME :::: [{}] AND FILE NAME ::::::: [{}]",orgId,schemeId,csvFile.getName());
                            updateErrorMessageAndStatus(historyAudit,ERROR_WHILE_GENERATING_EXCEL_FILE,Boolean.FALSE);
                        }
                    } else {
                        log.info("ERROR WHILE GENERATING CSV FILE FOR ORG ::::: [{}] AD SCHEME :::: [{}] AND FILE NAME ::::::: [{}]",orgId,schemeId,csvFile.getName());
                        updateErrorMessageAndStatus(historyAudit,ERROR_WHILE_GENERATING_CSV_FILE,Boolean.FALSE);
                    }
                } else {
                    updateErrorMessageAndStatus(historyAudit,ERROR_WHILE_JOB_PROCESSING,Boolean.FALSE);
                }
            } else {
                log.info("DATA NOT FOUND FOR ORG ID ::::[{}] AND SCHEME ID :::: [{}]",orgId,schemeId);
            }
        } catch (Exception e) {
            log.error("ERROR WHILE GENERATING JSON FILE FROM DATA FOR ORG [{}] AND SCHEME [{}]",orgId,schemeId,e);
        } finally {
            if(!OPLUtils.isObjectNullOrEmpty(csvFile)) {
                csvFile.delete();
            }
            if(!OPLUtils.isObjectNullOrEmpty(excelFile)) {
                excelFile.delete();
            }
            if(jsonFilepath != null) {
                File jsonFile = new File(jsonFilepath);
                if(jsonFile.exists()) {
                    jsonFile.delete();
                }
            }
            if(!OPLUtils.isObjectNullOrEmpty(historyAudit)) {
                downloadRepository.saveAndFlush(historyAudit);
            }
            log.info("EXIT FROM generateCsv FOR ORG ID ::::[{}] AND SCHEME ID :::: [{}]",orgId,schemeId);
        }

    }

    public void updateErrorMessageAndStatus(HoEnrollmentDownloadHistory historyAudit,String msg,Boolean status){
        historyAudit.setErrorMessage(msg);
        historyAudit.setIsSuccess(status);
    }
    private String dataFromSp(Map<String,Object> request){
        try {
            String req = MultipleJSONObjectHelper.getStringfromObject(request);
            String spName = DBNameConstant.JNS_REPORTS + ".dnld_enroll_list_accept_endorse_final_v5";
            return commonRepository.getDataFromProducer(req, 0l, spName);
        } catch (Exception e) {
            log.error("ERROR WHILE GET DATA FROM SP FOR ORG {} AND SCHEME ID {}",request.get("orgId"),request.get("schemeId"),e);
        }
        return null;
    }
    private String generateTokenId(Long schemeId,Long orgId) {
        String scheme = SchemeMaster.getById(schemeId).getShortName().toUpperCase();
        long token = (long) (Math.random() * Math.pow(10, 10));
        log.info("Token Id: " + "JNS" + "_" + scheme+"_"+ orgId+ "_" + token);
        return "JNS" + "_" + scheme + "_"+ orgId+"_" + token;
    }

    private Long uploadToDMS(File file) throws FileNotFoundException {
        log.info("ENTER INTO UPLOAD FILE TO DMS {} ---------------",file.getName());
        MultipartFile multipartFile = null;
        String docRequest = null;
        DocumentRequest docReq = new DocumentRequest();
        docReq.setProductDocumentMappingId(90l);
        docReq.setDocName(file.getName());
        docReq.setOriginalFileName(file.getName());
        docReq.setDocumentId(27L);
        docReq.setUserType("user");
        docReq.setApplicantType(null);
        docReq.setProductId(null);
        try {
            FileInputStream input = new FileInputStream(file);
            docRequest = MultipleJSONObjectHelper.getStringfromObject(docReq);
            multipartFile = new MockMultipartFile("csvFile", file.getName(),
                    MediaType.APPLICATION_OCTET_STREAM_VALUE, IOUtils.toByteArray(input)) {
            };
        } catch (Exception e) {
            log.error("ERROR WHILE CONVERTING FILE TO MULTIPART FILE {} -------- ", file.getName(), e);
        }
        try {
            if (!OPLUtils.isObjectNullOrEmpty(multipartFile)) {
                DocumentResponse uploadFileRes = dmsClient.uploadFile(docRequest, multipartFile);
                if (!OPLUtils.isObjectNullOrEmpty(uploadFileRes) && !OPLUtils.isObjectNullOrEmpty(uploadFileRes.getData()) && uploadFileRes.getStatus() == 200) {
                    StorageDetailsResponse res = MultipleJSONObjectHelper.getObjectFromObject(uploadFileRes.getData(),
                            StorageDetailsResponse.class);
                    log.info("FILE UPLOADED SUCCESSFULLY. :::: {} WITH STORAGE ID ::::: {}-------",file.getName(),res.getId());
                    log.info("EXIT FROM UPLOAD FILE TO DMS {} ---------------",file.getName());
                    return res.getId();
                }
                log.info("FILE NOT UPLOADED SUCCESSFULLY {} ------",file.getName());
                log.info("EXIT FROM UPLOAD FILE TO DMS {} ---------------",file.getName());
                return null;
            }
        } catch (Exception e) {
            log.error("ERROR WHILE UPLOADING FILE TO DMS {}  ---------", file.getName(), e);
        }
        return null;
    }

    public void convertCsvToExcel(File file){
        com.spire.xls.Workbook workbook = new Workbook();
        //Load a CSV file
        log.info("Absolute file path of csv :::: {}",file.getAbsolutePath());
        workbook.loadFromFile(file.getPath(), ",");

        //Loop through the worksheets in the CSV file
        for (int i = 0; i < workbook.getWorksheets().getCount(); i++)
        {
            Worksheet sheet = workbook.getWorksheets().get(i);
            //Access the used range in each worksheet
            CellRange usedRange = sheet.getAllocatedRange();
            //Ignore errors when saving numbers in the used range with text
            usedRange.setIgnoreErrorOptions(EnumSet.of(IgnoreErrorType.NumberAsText));
            //Autofit columns and rows
            usedRange.autoFitColumns();
            usedRange.autoFitRows();
        }

        //Save the CSV file as Excel .xlsx file
        workbook.saveToFile(file.getPath().replace(".csv",".xlsx"), ExcelVersion.Version2013);
    }

//    @Scheduled(cron = "${cronForEnrollmentDownloadForFailedCase}")
    public void generateCsvforFailedCases() {
        try {
            String value = environment.getRequiredProperty("DAILY_HO_DOWNLOAD_FAILED_CASE_SCHEDULER_ENABLE");
            if (value != null && "ON".equalsIgnoreCase(value)) {
                log.info("START generateCsvforFailedCases SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
                LocalDate localDate = LocalDate.now().plusDays(-1);
                String dateString = localDate.format(dateFormat);
                Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
                List<HoEnrollmentDownloadHistory> hoFailedHistory = downloadRepository.findByIsActiveIsTrueAndIsSuccessAndCompletionDateOrderByCreatedDateDesc(Boolean.FALSE, date);
                if(hoFailedHistory.size()>0) {
                    for (HoEnrollmentDownloadHistory history:hoFailedHistory) {
                        Map<String, Object> request = prepareRequestForGetData(history.getOrgId(),history.getSchemeId(),dateString);
                        generateExcel(request,history.getOrgId(),history.getSchemeId(),Boolean.FALSE);
                    }
                } else {
                    log.info("NO FAILED CASE FOUND FOR DATE {}  ------------------",dateString);
                }
                log.info("END generateCsvforFailedCases SCHEME AND ORG WISE GENERATE EXCEL REPORT ------------------");
            } else {
                log.info("DAILY_HO_DOWNLOAD_FAILED_CASE_SCHEDULER_ENABLE OFF FROM APPLICATION PROPERTY");
            }
        } catch (Exception e) {
            log.error("EXCEPTION WHILE generateCsvforFailedCases()  ------------------", e);
        }
    }
    
}
