package com.opl.jns.download.service.listeners;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;

import com.opl.jns.download.service.repository.DownloadRequestRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class DownloadRequestJobExecutionNotificationListener extends JobExecutionListenerSupport {


	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("DownloadRequestJobExecutionNotificationListener | beforeJob | Executing job id : " + jobExecution.getJobId());
		super.beforeJob(jobExecution);
	}

	@Override
	public void afterJob(JobExecution jobExecution) {

		log.info("DownloadRequestJobExecutionNotificationListener | afterJob | Executing job id : "
				+ jobExecution.getJobId());

		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			log.info("Job Completed");
		}

	}
}
