package com.opl.jns.download.service.service;

import java.util.List;

import com.opl.jns.download.api.proxy.MisDocDetailsProxy;
import com.opl.jns.download.api.proxy.MisDocReq;

public interface MisReportService {
    List<MisDocDetailsProxy> getDocDetails(MisDocReq misDocReq);
}
