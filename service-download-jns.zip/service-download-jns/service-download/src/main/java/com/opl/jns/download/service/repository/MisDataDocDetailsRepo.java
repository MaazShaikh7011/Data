package com.opl.jns.download.service.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.download.service.domain.MisDataDocDetails;

import java.util.Date;
import java.util.List;

public interface MisDataDocDetailsRepo extends JpaRepository<MisDataDocDetails, Long> {

    @Query("SELECT MDD FROM MisDataDocDetails MDD WHERE MDD.status = 200 AND MDD.isActive = TRUE AND MDD.type=:type AND " +
            " weekMaster.id in (:version) " +
            " ORDER BY MDD.createdDate DESC ")
    List<MisDataDocDetails> getDocDetails(@Param("type") String type, @Param("version") List<Long> version);
    
    @Query("SELECT MDD FROM MisDataDocDetails MDD WHERE MDD.status = 200 AND MDD.isActive = TRUE AND MDD.type=:type " +
            " ORDER BY MDD.createdDate DESC ")
    List<MisDataDocDetails> getAllDocDetails(@Param("type") String type);

}