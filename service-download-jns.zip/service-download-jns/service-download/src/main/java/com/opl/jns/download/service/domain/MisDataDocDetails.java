package com.opl.jns.download.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "mis_data_doc_details",catalog = DBNameConstant.JNS_REPORTS,schema = DBNameConstant.JNS_REPORTS)
public class MisDataDocDetails {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mis_data_doc_details_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_REPORTS, name = "mis_data_doc_details_seq_gen", sequenceName = "mis_data_doc_details_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "created_date", nullable = false)
    private Date createdDate;

    @Column(name = "type")
    private String type;

    @Column(name = "dms_storage_id")
    private Long dmsStorageId;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "status")
    private Integer status;

    @Column(name = "is_active")
    private Boolean isActive;

    @ManyToOne(cascade = CascadeType.ALL ,fetch = FetchType.LAZY)
    @JoinColumn(name = "version")
    private WeekMaster weekMaster;

}
