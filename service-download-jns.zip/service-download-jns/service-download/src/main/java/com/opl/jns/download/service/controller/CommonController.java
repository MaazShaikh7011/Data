package com.opl.jns.download.service.controller;

import com.opl.jns.utils.enums.UserTypeMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.download.api.proxy.DashboardRequestProxy;
import com.opl.jns.download.api.proxy.DownloadReq;
import com.opl.jns.download.service.schedular.EnrollmentReportScheduler;
import com.opl.jns.download.service.service.CommonService;
import com.opl.jns.download.service.service.DownloadService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CommonController {

	@Autowired
	private CommonService commonService;
	
	@Autowired
	private DownloadService downloadService;

	@Autowired
	private EnrollmentReportScheduler enrollmentReportScheduler;

	@GetMapping(value = "/hello", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<String> getHello() {

		log.error("enter in getHello ------>");
		return new ResponseEntity<>("success", HttpStatus.OK);
	}
	@PostMapping(value = "/generateEnrollmentCSV", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> generateEnrollmentCSV(@RequestBody String request, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		
		if(OPLUtils.isObjectNullOrEmpty(request)) {
			 return new ResponseEntity<>(new CommonResponse("Request parameter missing",null, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		try {
		
			CommonResponse res = commonService.saveDownloadRequest(request,authClientResponse.getUserId());
			if(!OPLUtils.isObjectNullOrEmpty(res)) {
				return new ResponseEntity<>(res, HttpStatus.OK);
			}
		    return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		} catch (Exception e) {
            log.error("Exception while generateEnrollmentCSV ------>", e);
            return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
	}
	
	/**
	 * checkIfDownload Ready or not For Enrollment Data
	 *
	 * @param req
	 * @return
	 */
	@PostMapping(value = "/checkIfDownload", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> checkIfDownload(@RequestBody DownloadReq req) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(req.getCreatedBy()) && OPLUtils.isObjectNullOrEmpty(req.getSchemeId())) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Request parameter missing", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<CommonResponse>(downloadService.checkIfDownload(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get checkIfDownload For EnrollmentData ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * downloadHistory For Enrollment Data
	 *
	 * @param req
	 * @return
	 */
	@PostMapping(value = "/downloadHistory", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> downloadHistory(@RequestBody DownloadReq req) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(req.getCreatedBy()) && OPLUtils.isObjectNullOrEmpty(req.getSchemeId())) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Request parameter missing", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<CommonResponse>(downloadService.downloadHistory(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get downloadHistory For EnrollmentData ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * downloadEnrollmentData in Zip File
	 *
	 * @param req
	 * @return
	 */
	@PostMapping(value = "/downloadEnrollmentData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> downloadEnrollmentData(@RequestBody DownloadReq req) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(req.getTokenId()) && OPLUtils.isObjectNullOrEmpty(req.getDocStorageId())) {
				return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			}
			byte[] zipByte = downloadService.downloadEnrollmentData(req);
			return new ResponseEntity<>(zipByte, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while dowloadEnrollmentData in ZipFile ------>", e);
			return new ResponseEntity<>(null, HttpStatus.OK);
		}
	}


	@PostMapping(value = "/generateEnrollmentCsvFromScheduler", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> generateEnrollmentCsvFromScheduler(@RequestBody DashboardRequestProxy req,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			enrollmentReportScheduler.generateCsvForEnrollmentForManual(req);
			return new ResponseEntity<>(new CommonResponse("Success", false, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while generateEnrollmentCSV ------>", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getUploadedFileLists", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> getUploadedFileLists(@RequestBody DashboardRequestProxy req, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(authClientResponse) || authClientResponse.getUserOrgId() == null) {
				return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			}
			if(UserTypeMaster.INSURER.getId() == authClientResponse.getUserType()){
				if(OPLUtils.isObjectNullOrEmpty(req.getOrgId())){
					return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
				}
			}
			return new ResponseEntity<>(commonService.getUploadedFileListForHo(req,authClientResponse.getUserOrgId(),authClientResponse.getUserType()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getUploadedFileLists ------>", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/downloadExcelForHo/{storageId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> downloadExcelForHo(@PathVariable Long storageId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if(storageId == null) {
				return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>(commonService.downloadExcelForHo(storageId), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while downloadExcelForHo ------>", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
	}
	
	/**
	 * ADMIN PANEL "Regenerate Report" PAGE USE API
	 *
	 * @param req
	 * @return
	 */
	@PostMapping(value = "/getFailedDownloadApplicationList", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<CommonResponse> getFailedDownloadApplicationList(@RequestBody DashboardRequestProxy req) {
		try {
			return new ResponseEntity<>(commonService.getFailedDownloadApplicationList(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getUploadedFileLists ------>", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
	}

}
