package com.opl.jns.download.service.config;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.springframework.batch.item.ItemProcessor;

import com.opl.jns.download.api.proxy.EnrollmentListRequestProxy;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.MiscellaneousType;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class EnrollmentListRequestProxyProcessor  implements ItemProcessor<EnrollmentListRequestProxy, EnrollmentListRequestProxy> {

//	private SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
    public static final DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    public static final DateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static final DateFormat time=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    public static final DateFormat milliSecond=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    @Override
    public EnrollmentListRequestProxy process(EnrollmentListRequestProxy list) throws Exception {
    	list.setRelationOfNominee(OPLUtils.isObjectNullOrEmpty(list.getRelationOfNominee()) ? list.getRelationOfNominee() :  RelationShip.fromId(Integer.valueOf(list.getRelationOfNominee())).getValue());
    		list.setRelationshipOfGuardian(OPLUtils.isObjectNullOrEmpty(list.getRelationshipOfGuardian()) ? list.getRelationshipOfGuardian() : RelationShip.fromId(Integer.valueOf(list.getRelationshipOfGuardian())).getValue());
    		list.setEndorsementType(OPLUtils.isObjectNullOrEmpty(list.getEndorsementType()) ? list.getEndorsementType() : MiscellaneousType.fromId(Integer.valueOf(list.getEndorsementType())).getValue());
            list.setSource(OPLUtils.isObjectNullOrEmpty(list.getSource()) ? list.getSource() : Source.fromId(Integer.valueOf(list.getSource())).getMode());
            list.setChannelId(OPLUtils.isObjectNullOrEmpty(list.getChannelId()) ? list.getChannelId() : ChannelIdEnum.fromId(Long.valueOf(list.getChannelId())).getShortName());
            if(!OPLUtils.isObjectNullOrEmpty(list.getDob())) {
                list.setDob(sdf.format(sdf1.parse(list.getDob())));
            }
            if(!OPLUtils.isObjectNullOrEmpty(list.getNomineeDoB())) {
                list.setNomineeDoB(sdf.format(sdf1.parse(list.getNomineeDoB())));
            }
            try {
                if(!OPLUtils.isObjectNullOrEmpty(list.getTransactionDate())) {
                    list.setTransactionDate(sdf1.format(milliSecond.parse(list.getTransactionDate())));
                }
            } catch (Exception e) {
                log.error("Error while converting transaction date to particular format ::::: ",e);
                list.setTransactionDate(sdf.format(sdf1.parse(list.getTransactionDate())));
            }

            if(!OPLUtils.isObjectNullOrEmpty(list.getCoiGenerationDate())) {
                list.setCoiGenerationDate(sdf.format(milliSecond.parse(list.getCoiGenerationDate())));
            }
            if(!OPLUtils.isObjectNullOrEmpty(list.getEnrollDate())) {
                list.setEnrollDate(sdf.format(milliSecond.parse(list.getEnrollDate())));
            }
//    		list.setCoiGenerationDate(!OPLUtils.isObjectNullOrEmpty(list.getCoiGenerationDate()) ? date.parse(date.format(list.getCoiGenerationDate())).toString(): null);
        return list;
    }
    
    	
}
