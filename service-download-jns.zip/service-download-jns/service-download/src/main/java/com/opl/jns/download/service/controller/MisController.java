package com.opl.jns.download.service.controller;


import com.opl.jns.download.api.proxy.MisDocDetailsProxy;
import com.opl.jns.download.api.proxy.MisDocReq;
import com.opl.jns.download.service.service.MisReportService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Slf4j
@RequestMapping("/mis")
public class MisController {

    @Autowired
    private MisReportService misReportService;

    @PostMapping(value = "/docDetails", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<CommonResponse> getMisDocDetails(@RequestBody MisDocReq misDocReq) {
        log.info("In getMisDocDetails() ---------------> ");
        try {
            if (OPLUtils.isObjectListNull(misDocReq.getType(), misDocReq.getType())) {
                log.info("Year or type is null or empty.");
                return new ResponseEntity<>(new CommonResponse("Invalid request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            List<MisDocDetailsProxy> docDetailsProxyList = misReportService.getDocDetails(misDocReq);
            if (!OPLUtils.isListNullOrEmpty(docDetailsProxyList)) {
                return new ResponseEntity<>(new CommonResponse("Data found.", docDetailsProxyList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new CommonResponse("Data not found.", null, HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(new CommonResponse("This application has encountered some error, please try after sometimes.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

}
