package com.opl.jns.download.service.repository.impl;

import java.sql.Clob;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.opl.jns.download.service.repository.CommonRepository;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author krunal.prajapati
 * Date : 15-06-2023
 */
@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {

    @Autowired
    EntityManager entityManager;

    @Override
    public String getDataFromProducer(String request, Long userId, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}", spName, request, userId);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
//            return (!OPLUtils.isListNullOrEmpty(storedProcedureQuery.getResultList()))?storedProcedureQuery.getResultList().toString():null;
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }
    
}
