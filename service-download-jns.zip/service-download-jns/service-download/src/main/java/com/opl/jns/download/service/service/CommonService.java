package com.opl.jns.download.service.service;

import java.io.IOException;

import com.opl.jns.download.api.proxy.DashboardRequestProxy;
import com.opl.jns.utils.common.CommonResponse;
import org.springframework.batch.core.JobExecution;

public interface CommonService {

//	public DownloadRequest generateEnrollmentCSV(String request,Long userId) throws IOException;

	public CommonResponse saveDownloadRequest(String request,Long userId) throws IOException;

	public JobExecution jobStart(String token, String outputFolderPath,String outputFilePath) throws IOException;

	public CommonResponse getUploadedFileListForHo(DashboardRequestProxy request, Long orgId,Long userType);

	public CommonResponse downloadExcelForHo(Long storageId);
	
	public CommonResponse getFailedDownloadApplicationList(DashboardRequestProxy request) throws IOException;
}
