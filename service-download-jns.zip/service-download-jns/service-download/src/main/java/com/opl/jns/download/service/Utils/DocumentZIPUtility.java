package com.opl.jns.download.service.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.EnumSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.spire.xls.CellRange;
import com.spire.xls.ExcelVersion;
import com.spire.xls.IgnoreErrorType;
import com.spire.xls.Workbook;
import com.spire.xls.Worksheet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentZIPUtility {

    public static void createZIPOfCSV(File fileToZip, String parentFolder, ZipOutputStream zipOut, String extension) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }

        if (fileToZip.isDirectory()) {
//		            String folderName = parentFolder.isEmpty() ? "" : parentFolder + "/";
//		            zipOut.putNextEntry(new ZipEntry(fileToZip.getName() + "/"));
//		            zipOut.closeEntry();
//    
            File[] children = fileToZip.listFiles((dir, name) -> name.endsWith(extension));

            if (children.length > 0) {
                for (File childFile : children) {
                    createZIPOfCSV(childFile, fileToZip.getName(), zipOut, extension);
                }
            }
            return;
        }
        try {
            if (fileToZip.getName().endsWith(extension)) {
                try (FileInputStream fis = new FileInputStream(fileToZip)) {
                    ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
                    zipOut.putNextEntry(zipEntry);
                    byte[] bytes = new byte[1024];
                    int length;

                    while ((length = fis.read(bytes)) >= 0) {
                        zipOut.write(bytes, 0, length);
                    }
                } catch (Exception e) {
                    log.error("Cannot create ZIP successfully. " + e.getMessage());
                }
            }
        } catch (Exception e) {
            log.error("Cannot create ZIP successfully. " + e.getMessage());
        }

    }

	public static void convertCsvToExcel(File file){
		com.spire.xls.Workbook workbook = new Workbook();
		//Load a CSV file
		log.info("Absolute file path of csv :::: {}",file.getAbsolutePath());
		workbook.loadFromFile(file.getPath(), ",");

		//Loop through the worksheets in the CSV file
		for (int i = 0; i < workbook.getWorksheets().getCount(); i++)
		{
			Worksheet sheet = workbook.getWorksheets().get(i);
			//Access the used range in each worksheet
			CellRange usedRange = sheet.getAllocatedRange();
			//Ignore errors when saving numbers in the used range with text
			usedRange.setIgnoreErrorOptions(EnumSet.of(IgnoreErrorType.NumberAsText));
			//Autofit columns and rows
			usedRange.autoFitColumns();
			usedRange.autoFitRows();
		}

		//Save the CSV file as Excel .xlsx file
		workbook.saveToFile(file.getPath().replace(".csv",".xlsx"), ExcelVersion.Version2013);
	}

}

