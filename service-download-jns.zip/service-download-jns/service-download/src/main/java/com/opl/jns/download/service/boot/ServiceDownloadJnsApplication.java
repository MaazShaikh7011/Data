package com.opl.jns.download.service.boot;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;



@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableScheduling
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
public class ServiceDownloadJnsApplication {

	@Autowired
    private ApplicationContext applicationContext;

	
	public static void main(String[] args) throws IOException {
		SpringApplication.run(ServiceDownloadJnsApplication.class, args);

	}
	
    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }
    
    @Bean
    public DMSClient dMSClient() {
        DMSClient dmsClient = new DMSClient(URLConfig.fetchURL(URLMaster.DMS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(dmsClient);
        return dmsClient;
    }

}
