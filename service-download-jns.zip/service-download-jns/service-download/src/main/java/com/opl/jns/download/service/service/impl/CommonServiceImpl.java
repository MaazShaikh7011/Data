package com.opl.jns.download.service.service.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.springframework.batch.core.*;

import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.download.api.proxy.DashboardRequestProxy;
import com.opl.jns.download.api.proxy.DashboardResProxy;
import com.opl.jns.download.api.proxy.DownloadRequestProxy;
import com.opl.jns.download.service.Utils.DocumentZIPUtility;
import com.opl.jns.download.service.domain.DownloadRequest;
import com.opl.jns.download.service.domain.DownloadRequestDetails;
import com.opl.jns.download.service.domain.HoEnrollmentDownloadHistory;
import com.opl.jns.download.service.repository.CommonRepository;
import com.opl.jns.download.service.repository.DownloadRequestRepository;
import com.opl.jns.download.service.repository.HoEnrollmentDownloadRepository;
import com.opl.jns.download.service.service.CommonService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommonServiceImpl implements CommonService {

//	@Autowired
//	private DownloadRequestDetailsRepository downloadRequestDetailsRepository;

	@Autowired
	private DownloadRequestRepository downloadRequestRepository;

	@Autowired
	private CommonRepository commonRepository;

	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private HoEnrollmentDownloadRepository downloadRepository;

//	private static final String uploadFilePath = "C:/Users/HarshPanchal/Music/D/jns-service/service-download-jns";
	@Value("${com.ans.user.upload.FilePath}")
	private String uploadFilePath;
	
	private final static Double TEN_LAKH = 1000000d;

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private Job job;

	@Autowired
    ConfigProperties configRepo;

	private static final DateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DateFormat.YYYY_MM_DD);

	@Override
	public CommonResponse saveDownloadRequest(String req, Long userId) {
		log.info("Download Request : {} for user [{}]",req,userId);
		DownloadRequest downloadReq = new DownloadRequest();
		Date curruntDate = new Date();
		downloadReq.setCreatedBy(userId);
		downloadReq.setCreatedDate(curruntDate);
		downloadReq.setApiStatus("In Progress");
		
		DownloadRequestDetails reqDetails = new DownloadRequestDetails();
		reqDetails.setFilterJson(req);
		downloadReq.setLogAudit(reqDetails);
		
		try {
			DownloadRequest downloadRequest = downloadRequestRepository.findFirstByCreatedByOrderByCreatedDateDesc(userId);
			if (!OPLUtils.isObjectNullOrEmpty(downloadRequest) &&  !OPLUtils.isObjectNullOrEmpty(downloadRequest.getApiStatus())) {
				if(downloadRequest.getApiStatus().equalsIgnoreCase("Failed") || downloadRequest.getApiStatus().equalsIgnoreCase("Success")) {
					downloadRequest.setIsDownload(Boolean.TRUE);
					downloadRequest.setDownloadDate(curruntDate);
					downloadRequestRepository.save(downloadRequest);
				}
			}
			Long configCounts = Long.valueOf(configRepo.getValue("DOWNLOAD_REPORT_TOTAL_COUNT"));
			log.info("Config_Total_counts: "+configCounts);
			
			Map<String, Object> map = MultipleJSONObjectHelper.getMapFromString(req);
			Object schemeId = map.get("schemeId");
			if(OPLUtils.isObjectNullOrEmpty(schemeId)){
				downloadReq.setIsDownload(Boolean.TRUE);
				downloadReq.setApiStatus("Failed");
				downloadReq.setErrorMessage("Scheme id not found");
				return new CommonResponse("Required details are missing", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			downloadReq.setTokenId(generateTokenId(schemeId));
			downloadReq.setSchemeId(Long.valueOf(schemeId.toString()));
			
			
			Integer status = (Integer) map.get("status");
			String count = fetchEnrollmentCounts(req, userId,status);
			Map<String, Object> tokenMap = MultipleJSONObjectHelper.getMapFromString(count);
			Long totalCount;
			
			// checks for counts
//			if(OPLUtils.isObjectNullOrEmpty(count) || (OPLUtils.isObjectNullOrEmpty(tokenMap.get("totalCount")) && OPLUtils.isObjectNullOrEmpty(tokenMap.get("endorsementCount")))){
//				downloadReq.setApiStatus("Failed");
//				downloadReq.setErrorMessage("No Data Found.");
//				return new CommonResponse("No Data Found.", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
//			}
//			else {
				if(!OPLUtils.isObjectNullOrEmpty(status)) {
					if (status == 1) {
						if (OPLUtils.isObjectNullOrEmpty(tokenMap.get("acceptedCount")) || tokenMap.get("acceptedCount").equals(0)) {
							downloadReq.setApiStatus("Failed");
							downloadReq.setErrorMessage("No accepted records available for download");
							return new CommonResponse("No accepted records available for download", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						totalCount = Long.valueOf(tokenMap.get("acceptedCount").toString());
					} else if (status == 2) {
						if (OPLUtils.isObjectNullOrEmpty(tokenMap.get("transactionFailedCount")) || tokenMap.get("transactionFailedCount").equals(0)) {
							downloadReq.setApiStatus("Failed");
							downloadReq.setErrorMessage("No records available for download");
							return new CommonResponse("No records available for download", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						totalCount = Long.valueOf(tokenMap.get("transactionFailedCount").toString());
					} else if (status == 3) {
						if (OPLUtils.isObjectNullOrEmpty(tokenMap.get("rejectedCount")) || tokenMap.get("rejectedCount").equals(0)) {
							downloadReq.setApiStatus("Failed");
							downloadReq.setErrorMessage("No rejected records available for download");
							return new CommonResponse("No rejected records available for download", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						totalCount = Long.valueOf(tokenMap.get("rejectedCount").toString());
					} else if (status == 4) {
						if (OPLUtils.isObjectNullOrEmpty(tokenMap.get("endorsementCount")) || tokenMap.get("endorsementCount").equals(0)) {
							downloadReq.setApiStatus("Failed");
							downloadReq.setErrorMessage("No endorsement records available for download");
							return new CommonResponse("No endorsement records available for download", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						totalCount = Long.valueOf(tokenMap.get("endorsementCount").toString());
					} else {
						if (OPLUtils.isObjectNullOrEmpty(tokenMap.get("expiredCount")) || tokenMap.get("expiredCount").equals(0)) {
							downloadReq.setApiStatus("Failed");
							downloadReq.setErrorMessage("No expired records available for download");
							return new CommonResponse("No expired records available for download", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						totalCount = Long.valueOf(tokenMap.get("expiredCount").toString());
					}
				}
				else {
					totalCount = Long.valueOf(tokenMap.get("acceptedCount").toString());
				}
//			}
			 
			if (OPLUtils.isObjectNullOrEmpty(totalCount)) {
				downloadReq.setApiStatus("Failed");
				downloadReq.setErrorMessage("No Data Found.");
				return new CommonResponse("No Data Found.", null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			else {
				log.info("TOTAL COUNT ::::: {} FOR TOKEN ID ::: {} ",totalCount,downloadReq.getTokenId());
				if (totalCount > configCounts) {
					downloadReq.setApiStatus("Failed");
					downloadReq.setErrorMessage("kindly contact to our support team for more information Up to 10L we are giving option to download data.");
					return new CommonResponse(downloadReq.getErrorMessage(), null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}else{
					// Asynchronous task for spring batch job
					CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
						try {
							generateEnrollmentCSV(req, userId, downloadReq, totalCount,status);
						} catch (InterruptedException e) {
							log.error("INTERRUPTEDEXCEPTION WHILE CALLING generateEnrollmentCSV ::::: ",e);
						} catch (IOException e) {
							log.error("IOEXCEPTION WHILE CALLING generateEnrollmentCSV ::::: ",e);
						}
					});
				}
				DownloadRequestProxy reqProxy = new DownloadRequestProxy();
				BeanUtils.copyProperties(downloadReq, reqProxy);
				return new CommonResponse("Data Saved Successfully", reqProxy, HttpStatus.OK.value(), Boolean.TRUE);
			} 
		} catch (Exception e) {
			downloadReq.setIsDownload(Boolean.TRUE);
			downloadReq.setErrorMessage(e.getMessage());
			downloadReq.setApiStatus("Failed");
			log.info("Something went wrong From save Download Request----> " , e);
			return new CommonResponse("Something went wrong From save Download Request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);	
		}finally {
			downloadRequestRepository.save(downloadReq);
		}
	}

	public Future<String> generateEnrollmentCSV(String request, Long userId, DownloadRequest downloadRequest,
			Long totalCount,Integer status) throws IOException, InterruptedException  {

		log.info("Async task for spring batch EnrollmentList get job started.");
		String path = uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".json";
		FileWriter write = new FileWriter(path);
		log.info("Writer in json started :::::: {}",new Date());
		try(BufferedWriter bufferedWriter = new BufferedWriter(write)) {
			if (!OPLUtils.isObjectNullOrEmpty(request) && !OPLUtils.isObjectNullOrEmpty(downloadRequest)) {

				if (!OPLUtils.isObjectNullOrEmpty(totalCount)) {

					int chunk = (int) Math.ceil(totalCount / TEN_LAKH);
					int pageFrom = 0;
					int pageTo = 1000000;
					File csvFile = null;
					for (int i = 1; i <= chunk; i++) {

						Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(request);
						mapFromString.put("paginationFROM", pageFrom);
						mapFromString.put("paginationTO", pageTo);

						request = MultipleJSONObjectHelper.getStringfromObject(mapFromString);
						log.info("SP CALL STARTED FOR TOKEN ID :::::: {} AT ::::: {}",downloadRequest.getTokenId(),new Date());
						CommonResponse fetchEnrollmentList = fetchEnrollmentList(request, userId,status);
						log.info("SP CALL COMPLETED FOR TOKEN ID :::::: {} AT ::::: {}",downloadRequest.getTokenId(),new Date());
						if (!OPLUtils.isObjectNullOrEmpty(fetchEnrollmentList.getData())) {
							String data = null;

							if (chunk == 1) {
								data = fetchEnrollmentList.getData().toString();
							} else {
								if (i == chunk) {
									data = fetchEnrollmentList.getData().toString();
								} else {
									data = fetchEnrollmentList.getData().toString().replace("]", ",");
								}
								if (i != 1) {
									data = data.replace("[", "");
								}
							}
							bufferedWriter.write(data);

						} else {
							updateDownloadReqError("EnrollmentList not found.", downloadRequest);
							log.error("EnrollmentList not found.");
							return new AsyncResult<String>("EnrollmentList not found.");
						}

						if (i == 1) {
							pageFrom = pageTo + 1;
						} else {
							pageFrom = pageFrom + pageTo + 1;
						}
					}
					log.info("WRITER IN JSON COMPLETED FOR TOKEN ID :::: {}",downloadRequest.getTokenId());
//					Thread.sleep(10000);
					bufferedWriter.close();
					write.close();
					log.info("BATCH STARTED FOR TOKEN ID :::: {}",downloadRequest.getTokenId());

					JobExecution job = runBatch(chunk, downloadRequest,status);
					if (!OPLUtils.isObjectNullOrEmpty(job) && !job.isRunning() && job.getStatus() == BatchStatus.COMPLETED) {
						log.info("BATCH COMPLETED FOR TOKEN ID :::: {}",downloadRequest.getTokenId());
						csvFile = new File(uploadFilePath + "/EnrollmentList_" + 0 + "__" + downloadRequest.getTokenId() + ".csv");
//						if(csvFile.exists()) {
//							DocumentZIPUtility.convertCsvToExcel(csvFile);
//						}
						Boolean zip = createZip(downloadRequest);
						if (zip) {
							Boolean uploadToDMS = uploadToDMS(downloadRequest);
							if (!uploadToDMS) {
								updateDownloadReqError("DMS error occured.", downloadRequest);
								log.info("DMS error occured.");
							} else {
								deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".csv");
								deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".zip");
								deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".json");
//								deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".xlsx");
							}
						} else {
							updateDownloadReqError("Zip not created successfully.", downloadRequest);
							log.info("Zip not created successfully");
						}
					} else {
						updateDownloadReqError("Spring batch job failed.", downloadRequest);
						log.info("Spring batch job failed.");
					}
				} else {
					updateDownloadReqError("Enrollment List count not found.", downloadRequest);
					log.info("Enrollment List count not found.");
				}
			} else {
				updateDownloadReqError("Missing Request Parameters.", downloadRequest);
				log.info("Missing Request Parameters.");
				return new AsyncResult<String>("Missing Request Parameters.");
			}
			return new AsyncResult<String>(downloadRequest.toString());

		} catch (InterruptedException e) {
			updateDownloadReqError(e.getMessage(), downloadRequest);
			throw new RuntimeException("Async operation failed", e);
		}

	}

	public void updateDownloadReqError(String msg, DownloadRequest downloadReq) {
		downloadReq.setErrorMessage(msg);
		downloadReq.setApiStatus("Failed");
		downloadRequestRepository.save(downloadReq);
	}

	public Boolean uploadToDMS(DownloadRequest downloadRequest) throws FileNotFoundException {
 
		File file = new File(uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".zip");
		String path = file.getAbsolutePath();
		try(FileInputStream input = new FileInputStream(file)) {

			DocumentRequest docReq = new DocumentRequest();
			docReq.setProductDocumentMappingId(69L);
			docReq.setDocName(file.getName());
			docReq.setOriginalFileName(file.getName());
			docReq.setDocumentId(25L);
			docReq.setUserType("user");
			docReq.setApplicantType(1);
			docReq.setProductId(2L);
			String docRequest = MultipleJSONObjectHelper.getStringfromObject(docReq);

			MultipartFile multipartFile = new MockMultipartFile("zipFile", file.getName(),
					MediaType.APPLICATION_OCTET_STREAM_VALUE, IOUtils.toByteArray(input));

			// Zip file upload to DMS.
			DocumentResponse uploadFileRes = dmsClient.uploadFile(docRequest, multipartFile);
			if (!OPLUtils.isObjectNullOrEmpty(uploadFileRes.getData()) && uploadFileRes.getStatus() == 200) {
				StorageDetailsResponse res = MultipleJSONObjectHelper.getObjectFromObject(uploadFileRes.getData(),
						StorageDetailsResponse.class);

				// upate download request data.
				downloadRequest.setDocStorageId(res.getId());
				downloadRequest.setApiStatus("Success");
				downloadRequest.setDownloadDate(new Date());
				downloadRequestRepository.save(downloadRequest);
				log.info("File uploaded successfully.");
				return true;
			} else {
				log.info("File not uploaded successfully.");
				return false;
			}
		} catch (IOException e) {
			updateDownloadReqError(e.getMessage(), downloadRequest);
			log.info("Something went wrong: " + e.getMessage());
			e.printStackTrace();
		} catch (DocumentException e) {
			updateDownloadReqError(e.getMessage(), downloadRequest);
			log.info("Something went wrong: " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	public Boolean createZip(DownloadRequest downloadRequest) {
		try {
			File file = new File( uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".zip");
			String path = file.getAbsolutePath();

			log.info("AbsolutePath: " + path);
			String sourceFile = uploadFilePath;
			FileOutputStream fos = new FileOutputStream(path);
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			String ext = "__" + downloadRequest.getTokenId() + ".csv";
			File fileToZip = new File(sourceFile);
			DocumentZIPUtility.createZIPOfCSV(fileToZip, "", zipOut, ext);
			zipOut.close();
			fos.close();
			log.info("Zip archive created successfully.");
			return true;
		} catch (IOException e) {
			log.info("Zip archive not created successfully." + e.getMessage());
		}
		return false;
	}

	public JobExecution runBatch(int chunk, DownloadRequest downloadRequest,Integer status) {

		try {
			log.info("BatchProcessing | JsonToCsvJob is called");

			String path = uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".json";

			JobParameters jobParameters = new JobParametersBuilder().addLong("startAt", System.currentTimeMillis())
					.addString("fullPathFileName", path).addString("csvToken", downloadRequest.getTokenId())
					.addString("csvFilePath", uploadFilePath).addString("status", status.toString())
					.toJobParameters();

			JobExecution run = jobLauncher.run(job, jobParameters);
			log.info("Number of active threads from the given thread::::: {} " ,Thread.activeCount());
			return run;
		} catch (Exception e) {
			log.error("BatchController | importDvToCsvJob | error : ", e);
		}
		return null;
	}

	private String generateTokenId(Object schemeId) {
		String scheme = SchemeMaster.getById(Long.valueOf(schemeId.toString())).getShortName().toUpperCase();
		long token = (long) (Math.random() * Math.pow(10, 10));
		log.info("Token Id: " + "JNS" + "_" + scheme + "_" + token);
		return "JNS" + "_" + scheme + "_" + token;
	}

	public CommonResponse fetchEnrollmentList(String request, Long userId,Integer status) {
		try {
			String spName = null;
			if(status == 1 || status == 4) {
				spName = DBNameConstant.JNS_REPORTS + ".dnld_enroll_list_accept_endorse_final_v5";
			} else if(status == 2) {
				spName = DBNameConstant.JNS_REPORTS + ".DNLD_ENROLL_LIST_TRANS_FAILED_V5";
			} else {
				spName = DBNameConstant.JNS_REPORTS + ".DNLD_ENROLL_LIST_REJECT_TRANS_FAILED_V5";
			}
			
			String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
			return new CommonResponse(dataFromProducer, "SuccessFully get Enrollment List", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Exception is getting while get Enrollment List", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	public String fetchEnrollmentCounts(String request, Long userId,Integer status) {
		try {
			String spName = null;
			if(status == 1 || status == 4 ) {
				spName = DBNameConstant.JNS_REPORTS + ".FETCH_ENROLL_COUNTS_ACCEPT_ENDORSE_V5";
			} else if (status == 2) {
				spName = DBNameConstant.JNS_REPORTS + ".FETCH_ENROLL_COUNTS_TRANS_FAILED_V5";
			} else {
				spName = DBNameConstant.JNS_REPORTS + ".FETCH_ENROLL_COUNTS_REJ_TRANS_FAILED_V5";
			}
			String response = commonRepository.getDataFromProducer(request, userId, spName);
			if (!OPLUtils.isObjectNullOrEmpty(response)) {
				return response;
				
			}
		} catch (Exception e) {
			log.error("Exception is getting while get Enrollment Count", e);
			return null;
		}
		return null;
	}

	public static void deleteExisting(String folderPath, String extension) throws IOException, InterruptedException {
		File folder = new File(folderPath);
		File[] csvFiles = folder.listFiles((dir, name) -> name.endsWith(extension));
		if (csvFiles != null) {
			for (File csvFile : csvFiles) {
//				Thread.sleep(5000);
//				  FileDeleteStrategy.FORCE.delete(csvFile);
				boolean delete = csvFile.delete();
				log.info("deleted Successfully: "+csvFile.getName() + ":" + delete);
			}
		}
	}

	@Override
	public JobExecution jobStart(String token,String outputFolderPath,String outputFilePath) {
		try {
			log.info("BatchProcessing | JsonToCsvJob is called");
			String path = outputFolderPath + outputFilePath + token + ".json";

			JobParameters jobParameters = new JobParametersBuilder().addLong("startAt", System.currentTimeMillis())
					.addString("fullPathFileName", path).addString("csvToken", token)
					.addString("csvFilePath", outputFolderPath)
					.addString("status","1")
					.toJobParameters();

			JobExecution run = jobLauncher.run(job, jobParameters);
			return run;
		} catch (Exception e) {
			log.error("BatchController | importDvToCsvJob | error : " ,e);
		}
		return null;
	}

	@Override
	public CommonResponse getUploadedFileListForHo(DashboardRequestProxy request, Long orgId,Long userType){
		log.info("----------ENTER INTO GET UPLOADED FILE LIST FOR HO--------------");
		try {
			Date fromDate = simpleDateFormat.parse(simpleDateFormat.format(request.getFromDate()));
			Date toDate = simpleDateFormat.parse(simpleDateFormat.format(request.getToDate()));
			Pageable pageable = PageRequest.of(request.getPageNo().intValue(),request.getPageSize().intValue());
			List<HoEnrollmentDownloadHistory> data = null;
			Long totalCount = 0l;
			if(UserTypeMaster.INSURER.getId() == userType) {
				totalCount = downloadRepository.countByIsActiveIsTrueAndIsSuccessIsTrueAndInsurerOrgIdAndOrgIdAndSchemeIdAndCompletionDateBetween(orgId,request.getOrgId(),request.getSchemeId(),fromDate,toDate);
				data = downloadRepository.findByIsActiveIsTrueAndIsSuccessIsTrueAndCompletionDateBetweenAndInsurerOrgIdAndOrgIdAndSchemeIdOrderByCompletionDateDesc(fromDate,toDate,orgId,request.getOrgId(), request.getSchemeId(), pageable);
			} else {
				totalCount = downloadRepository.countByIsActiveIsTrueAndIsSuccessIsTrueAndOrgIdAndSchemeIdAndCompletionDateBetween(orgId,request.getSchemeId(),fromDate,toDate);
				data = downloadRepository.findByIsActiveIsTrueAndIsSuccessIsTrueAndCompletionDateBetweenAndOrgIdAndSchemeIdOrderByCompletionDateDesc(fromDate,toDate,orgId,request.getSchemeId(), pageable);
			}

			List<DashboardResProxy> dashboardResProxies = new ArrayList<>();
			DashboardResProxy resProxy = null;
			for (HoEnrollmentDownloadHistory obj:data) {
				resProxy = new DashboardResProxy();
				BeanUtils.copyProperties(obj,resProxy);
				resProxy.setTotalCount(totalCount);
				dashboardResProxies.add(resProxy);
			}
			log.info("----------EXIT FROM GET UPLOADED FILE LIST FOR HO--------------");
			return new CommonResponse(dashboardResProxies, "SuccessFully get Enrollment List", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("ERROR WHILE GET UPLOADED FILE LIST FOR HO",e);
		}
		return new CommonResponse(null, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public CommonResponse downloadExcelForHo(Long storageId){
		log.info("----------ENTER INTO DOWNLOAD ENROLLMENT EXCEL FROM STORAGE ID :::::: {} --------------",storageId);
		try {
			byte[] bytes = dmsClient.productDownloadDocuments(storageId.toString());
			if(bytes != null && bytes.length > 0) {
				return new CommonResponse(Base64.getEncoder().encodeToString(bytes), "SuccessFully get Enrollment List", HttpStatus.OK.value());
			}
			return new CommonResponse(null, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
		} catch (Exception e) {
			log.error("ERROR WHILE DOWNLOAD ENROLLMENT EXCEL FROM STORAGE ID :::: {} -----------",storageId,e);
		}
		return new CommonResponse(null, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public CommonResponse getFailedDownloadApplicationList(DashboardRequestProxy request) throws IOException {
		log.info("----------ENTER INTO GET FAILED DOWNLOAD APPLICATION LIST--------------" + MultipleJSONObjectHelper.getStringfromObject(request));
		try {
			List<HoEnrollmentDownloadHistory> data = null;
			if(!OPLUtils.isObjectNullOrEmpty(request.getFromDate()) && !OPLUtils.isObjectNullOrEmpty(request.getToDate())) {
				Date fromDate = simpleDateFormat.parse(simpleDateFormat.format(request.getFromDate()));
				Date toDate = simpleDateFormat.parse(simpleDateFormat.format(request.getToDate()));
				
				data = downloadRepository.findByIsActiveIsTrueAndIsSuccessIsFalseAndCompletionDateBetweenAndOrgIdOrderByCreatedDateDesc(fromDate,toDate,request.getOrgId());
			}else {				
				data = downloadRepository.findByIsActiveIsTrueAndIsSuccessIsFalseOrderByCreatedDateDesc();
			}
			/**DOWNLOAD FAILED OLD APPLICATION COMPARE TO ALREADY COMPLETED APPLICATION AND REMOVE TO LIST*/
			Iterator<HoEnrollmentDownloadHistory> iterate = data.iterator();
			if(!OPLUtils.isListNullOrEmpty(data)) {
				while (iterate.hasNext()) {	
					HoEnrollmentDownloadHistory downlodedRec = iterate.next();
					HoEnrollmentDownloadHistory downloadLst = downloadRepository.findFirstByCompletionDateAndSchemeIdAndOrgIdAndIsActiveTrueAndIsSuccessTrue(downlodedRec.getCompletionDate(), downlodedRec.getSchemeId(), downlodedRec.getOrgId());
					if(!OPLUtils.isObjectNullOrEmpty(downloadLst)) {
						iterate.remove();
					}
				}
			}
			
			List<DashboardResProxy> dashboardResProxies = new ArrayList<>();
			DashboardResProxy resProxy = null;
			for (HoEnrollmentDownloadHistory obj:data) {
				resProxy = new DashboardResProxy();
				BeanUtils.copyProperties(obj,resProxy);
				dashboardResProxies.add(resProxy);
			}
			log.info("----------EXIT FROM GET FAILED DOWNLOAD APPLICATION LIST--------------");
			return new CommonResponse(dashboardResProxies, "SuccessFully get Enrollment List", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("ERROR WHILE GET FAILED DOWNLOAD APPLICATION LIST",e);
		}
		return new CommonResponse(null, "Internal server error", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

}
