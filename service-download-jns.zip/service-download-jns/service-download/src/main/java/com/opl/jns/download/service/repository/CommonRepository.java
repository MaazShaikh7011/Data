package com.opl.jns.download.service.repository;

/**
 * @author krunal.prajapati
 * Date : 16-08-2023
 */
public interface CommonRepository {
    String getDataFromProducer(String request, Long userId, String spName);

}
