package com.opl.jns.download.service.boot;
//package com.opl.api.download.boot;
//
//import java.io.BufferedWriter;
//import java.io.FileWriter;
//
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.context.annotation.DependsOn;
//import org.springframework.stereotype.Component;
//
//@Component("commandLineRunner")
//public class CommandLineRunner implements  ApplicationRunner  {
//
//    @Override
//    public void run(ApplicationArguments  args) throws Exception {
//    	String path = "src/main/resources/enrollmentList.json";
//		FileWriter write = new FileWriter(path);
//		BufferedWriter bufferedWriter = new BufferedWriter(write);
//		bufferedWriter.write("[{}]");
//		bufferedWriter.close();
//		write.close();
//		Thread.sleep(1000);
//    }
//}