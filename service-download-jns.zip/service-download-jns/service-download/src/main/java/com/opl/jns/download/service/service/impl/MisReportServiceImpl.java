package com.opl.jns.download.service.service.impl;

import com.opl.jns.download.api.proxy.MisDocDetailsProxy;
import com.opl.jns.download.api.proxy.MisDocReq;
import com.opl.jns.download.service.domain.MisDataDocDetails;
import com.opl.jns.download.service.repository.MisDataDocDetailsRepo;
import com.opl.jns.download.service.service.MisReportService;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service("MisReportServiceImpl")
@Slf4j
@Transactional(readOnly = true)
public class MisReportServiceImpl implements MisReportService {

    @Autowired
    private MisDataDocDetailsRepo misDataDocDetailsRepo;

    @Override
    public List<MisDocDetailsProxy> getDocDetails(MisDocReq misDocReq) {
        log.info("In getDocDetails() -------------> ");
        try {
        	List<MisDataDocDetails> misDataDocDetailsList = Collections.emptyList();
        	if(!OPLUtils.isListNullOrEmpty(misDocReq.getVersion())) {        		
        		misDataDocDetailsList = misDataDocDetailsRepo.getDocDetails(misDocReq.getType(), misDocReq.getVersion());
        	}else {
        		misDataDocDetailsList = misDataDocDetailsRepo.getAllDocDetails(misDocReq.getType());
        	}
            if (!OPLUtils.isListNullOrEmpty(misDataDocDetailsList)) {
                List<MisDocDetailsProxy> misDocDetailsProxyList = new ArrayList<>(misDataDocDetailsList.size());
                MisDocDetailsProxy misDocDetailsProxy;
                for (MisDataDocDetails misDataDocDetails : misDataDocDetailsList) {
                    misDocDetailsProxy = new MisDocDetailsProxy();
                    BeanUtils.copyProperties(misDataDocDetails, misDocDetailsProxy);
                    if( !OPLUtils.isObjectNullOrEmpty(misDataDocDetails.getWeekMaster())
                            &&!OPLUtils.isObjectNullOrEmpty(misDataDocDetails.getWeekMaster().getFromDate())
                            && !OPLUtils.isObjectNullOrEmpty(misDataDocDetails.getWeekMaster().getToDate())) {
                        misDocDetailsProxy.setFromDate(misDataDocDetails.getWeekMaster().getFromDate());
                        misDocDetailsProxy.setToDate(misDataDocDetails.getWeekMaster().getToDate());
                    }
                    misDocDetailsProxyList.add(misDocDetailsProxy);
                }
                log.info("Exit from getDocDetails() -------------> ");
                return misDocDetailsProxyList;
            }
            log.info("Data not found.");
        } catch (Exception e) {
            log.error("Exception in getDocDetails() --------------> ", e);
        }
        return null;
    }
}
