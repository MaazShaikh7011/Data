package com.opl.jns.download.service.schedular;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.download.service.Utils.DocumentZIPUtility;
import com.opl.jns.download.service.domain.DownloadRequest;
import com.opl.jns.download.service.repository.CommonRepository;
import com.opl.jns.download.service.repository.DownloadRequestRepository;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class HoEnrollmentDownloadSchedular {

	@Autowired
	private DownloadRequestRepository downloadRequestRepository;
	
	@Autowired
	private CommonRepository commonRepository;
	
	@Value("${com.ans.user.upload.FilePath}")
	private String uploadFilePath;
	
//	private final static Double TEN_LAKH = 1000000d;
	
	@Autowired
	private DMSClient dmsClient;

	private final JobLauncher jobLauncher;
	private final Job job;
	
	
	 	@Scheduled(fixedDelay = 10000)
	    private void hoDownloadEnrollment() {
	    	
	    	LocalTime midnight = LocalTime.MIDNIGHT;
	    	LocalDate today = LocalDate.now(ZoneId.of("Europe/Berlin"));
	    	LocalDateTime todayMidnight = LocalDateTime.of(today, midnight);
	    	LocalDateTime tomorrowMidnight = todayMidnight.plusDays(1);
	    	System.err.println("todayMidnight "+todayMidnight);
	    	System.err.println("tomorrowMidnight "+tomorrowMidnight);
	    	
	    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    	String fromDate = todayMidnight.format(formatter); // "1986-04-08 12:30"
	    	String toDate = tomorrowMidnight.format(formatter);
	    	
	    	Map<String, Object> str = new HashMap<String,Object>();
	    	str.put("fromDate", fromDate);
	    	str.put("toDate", toDate);
	    	str.put("schemeId", 2);
	    	str.put("orgId",13);
	    	try {
				String request = MultipleJSONObjectHelper.getStringfromObject(MultipleJSONObjectHelper.getObjectFromMap(str, Object.class));
				
				DownloadRequest downloadReq = new DownloadRequest();
				Date curruntDate = new Date();
				downloadReq.setCreatedBy(null);
				downloadReq.setCreatedDate(curruntDate);
				downloadReq.setApiStatus("In Progress");
				
//				CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
					try {
						generateEnrollmentCSV(request, null, downloadReq);
					} catch (InterruptedException e) {
						log.info("something went wrong");
						e.printStackTrace();
					}
//						catch (IOException e) {
//						e.printStackTrace();
//					}
//				});
//				CommonResponse fetchEnrollmentList = fetchEnrollmentList(request, null, 1);
//				System.err.println("List: "+fetchEnrollmentList);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    }
	 
	 public CommonResponse fetchEnrollmentList(String request, Long userId,Integer status) {
			try {
				String spName = null;
				if(status == 1 || status == 4) {
					spName = DBNameConstant.JNS_REPORTS + ".DNLD_ENROLL_LIST_ACCEPT_ENDORSE";
				}else {
					spName = DBNameConstant.JNS_REPORTS + ".DNLD_ENROLL_LIST_REJECT_TRANS_FAILED";	
				}
				
				String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
				return new CommonResponse(dataFromProducer, "SuccessFully get Enrollment List", HttpStatus.OK.value());
			} catch (Exception e) {
				log.error("Exception is getting while get Enrollment List", e);
			}
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	 
	 public Future<String> generateEnrollmentCSV(String request, Long userId, DownloadRequest downloadRequest) throws IOException, InterruptedException  {

			log.info("Async task for HO spring batch EnrollmentList get job started.");
			String path = uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".json";
			FileWriter write = new FileWriter(path);
			
			try(BufferedWriter bufferedWriter = new BufferedWriter(write)) {
				if (!OPLUtils.isObjectNullOrEmpty(request) && !OPLUtils.isObjectNullOrEmpty(downloadRequest)) {
						int chunk = 1;
						int pageFrom = 0;
						int pageTo = 1000000;
						for (int i = 1; i <= chunk; i++) {

							Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(request);
							mapFromString.put("paginationFROM", pageFrom);
							mapFromString.put("paginationTO", pageTo);

							request = MultipleJSONObjectHelper.getStringfromObject(mapFromString);
						
							CommonResponse fetchEnrollmentList1 = fetchEnrollmentList(request, null,1);
							CommonResponse fetchEnrollmentList2 = fetchEnrollmentList(request, null,2);
							CommonResponse fetchEnrollmentList3 = fetchEnrollmentList(request, null,3);
							CommonResponse fetchEnrollmentList4 = fetchEnrollmentList(request, null,4);

							StringBuilder sb = new StringBuilder();
							sb.append(fetchEnrollmentList1.getData());
							sb.append(fetchEnrollmentList2.getData());
							sb.append(fetchEnrollmentList3.getData());
							sb.append(fetchEnrollmentList4.getData());
							
							if (!OPLUtils.isObjectNullOrEmpty(sb)) {
								String data = null;

								if (chunk == 1) {
									data = sb.toString();
								} else {
									if (i == chunk) {
										data = sb.toString();
									} else {
										data = sb.toString().replace("]", ",");
									}
									if (i != 1) {
										data = data.replace("[", "");
									}
								}
								bufferedWriter.write(data);

							} else {
								updateDownloadReqError("EnrollmentList not found.", downloadRequest);
								log.error("EnrollmentList not found.");
							}

							if (i == 1) {
								pageFrom = pageTo + 1;
							} else {
								pageFrom = pageFrom + pageTo + 1;
							}
						}
						Thread.sleep(10000);
						bufferedWriter.close();
						write.close();

						JobExecution job = runBatch(chunk, downloadRequest,1);
						if (!job.isRunning() && job.getStatus() == BatchStatus.COMPLETED) {
							Boolean zip = createZip(downloadRequest);
							if (zip) {
								Boolean uploadToDMS = uploadToDMS(downloadRequest);

								if (!uploadToDMS) {
									updateDownloadReqError("DMS error occured.", downloadRequest);
									log.info("DMS error occured.");
								} else {
									deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".csv");
									deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".zip");
									deleteExisting(uploadFilePath, "__" + downloadRequest.getTokenId() + ".json");
								}
							} else {
								updateDownloadReqError("Zip not created successfully.", downloadRequest);
								log.info("Zip not created successfully");
							}
						} else {
							updateDownloadReqError("Spring batch job failed.", downloadRequest);
							log.info("Spring batch job failed.");
						}
//						} else {
//							updateDownloadReqError("Data map issue.",downloadRequest);
//							log.info("Data formating issue.");
//							return new AsyncResult<String>("Enrollment List count not found.");
//						}
					
				} else {
					updateDownloadReqError("Missing Request Parameters.", downloadRequest);
					log.info("Missing Request Parameters.");
					return new AsyncResult<String>("Missing Request Parameters.");
				}
				return new AsyncResult<String>(downloadRequest.toString());

			} catch (InterruptedException e) {
				updateDownloadReqError(e.getMessage(), downloadRequest);
				throw new RuntimeException("Async operation failed", e);
			}

		}
	 
	 public void updateDownloadReqError(String msg, DownloadRequest downloadReq) {
			downloadReq.setErrorMessage(msg);
			downloadReq.setApiStatus("Failed");
			downloadRequestRepository.save(downloadReq);
		}

		public Boolean uploadToDMS(DownloadRequest downloadRequest) throws FileNotFoundException {
	 
			File file = new File(uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".zip");
			String path = file.getAbsolutePath();
			try(FileInputStream input = new FileInputStream(file)) {

				DocumentRequest docReq = new DocumentRequest();
				docReq.setProductDocumentMappingId(69L);
				docReq.setDocName(file.getName());
				docReq.setOriginalFileName(file.getName());
				docReq.setDocumentId(25L);
				docReq.setUserType("user");
				docReq.setApplicantType(1);
				docReq.setProductId(2L);
				String docRequest = MultipleJSONObjectHelper.getStringfromObject(docReq);

				MultipartFile multipartFile = new MockMultipartFile("zipFile", file.getName(),
						MediaType.APPLICATION_OCTET_STREAM_VALUE, IOUtils.toByteArray(input));

				// Zip file upload to DMS.
				DocumentResponse uploadFileRes = dmsClient.uploadFile(docRequest, multipartFile);
				if (!OPLUtils.isObjectNullOrEmpty(uploadFileRes.getData()) && uploadFileRes.getStatus() == 200) {
					StorageDetailsResponse res = MultipleJSONObjectHelper.getObjectFromObject(uploadFileRes.getData(),
							StorageDetailsResponse.class);

					// upate download request data.
					downloadRequest.setDocStorageId(res.getId());
					downloadRequest.setApiStatus("Success");
					downloadRequest.setDownloadDate(new Date());
					downloadRequestRepository.save(downloadRequest);
					log.info("File uploaded successfully.");
					return true;
				} else {
					log.info("File not uploaded successfully.");
					return false;
				}
			} catch (IOException e) {
				updateDownloadReqError(e.getMessage(), downloadRequest);
				log.info("Something went wrong: " + e.getMessage());
				e.printStackTrace();
			} catch (DocumentException e) {
				updateDownloadReqError(e.getMessage(), downloadRequest);
				log.info("Something went wrong: " + e.getMessage());
				e.printStackTrace();
			}
			return false;
		}

		public Boolean createZip(DownloadRequest downloadRequest) {
			try {
				File file = new File( uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".zip");
				String path = file.getAbsolutePath();

				log.info("AbsolutePath: " + path);
				String sourceFile = uploadFilePath;
				FileOutputStream fos = new FileOutputStream(path);
				ZipOutputStream zipOut = new ZipOutputStream(fos);
				String ext = "__" + downloadRequest.getTokenId() + ".csv";
				File fileToZip = new File(sourceFile);
				DocumentZIPUtility.createZIPOfCSV(fileToZip, "", zipOut, ext);
				zipOut.close();
				fos.close();
				log.info("Zip archive created successfully.");
				return true;
			} catch (IOException e) {
				log.info("Zip archive not created successfully." + e.getMessage());
			}
			return false;
		}

		public JobExecution runBatch(int chunk, DownloadRequest downloadRequest,Integer status) throws IOException {

			try {
				log.info("BatchProcessing | JsonToCsvJob is called");

				String path = uploadFilePath + "/EnrollmentList__" + downloadRequest.getTokenId() + ".json";

				JobParameters jobParameters = new JobParametersBuilder().addLong("startAt", System.currentTimeMillis())
						.addString("fullPathFileName", path).addString("csvToken", downloadRequest.getTokenId())
						.addString("csvFilePath", uploadFilePath).addString("status", status.toString())
						.toJobParameters();

				JobExecution run = jobLauncher.run(job, jobParameters);
				return run;
			} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
					| JobParametersInvalidException e) {
				log.info("BatchController | importDvToCsvJob | error : " + e.getMessage());
				e.printStackTrace();
			}
			return null;
		}
		
		public static void deleteExisting(String folderPath, String extension) throws IOException, InterruptedException {
			File folder = new File(folderPath);
			File[] csvFiles = folder.listFiles((dir, name) -> name.endsWith(extension));
			if (csvFiles != null) {
				for (File csvFile : csvFiles) {
//					Thread.sleep(5000);
//					  FileDeleteStrategy.FORCE.delete(csvFile);
					boolean delete = csvFile.delete();
					log.info("deleted Successfully: "+csvFile.getName() + ":" + delete);
				}
			}
		}

}
