package com.opl.jns.download.service.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.download.service.domain.HoEnrollmentDownloadHistory;

import java.util.Date;
import java.util.List;

public interface HoEnrollmentDownloadRepository extends JpaRepository<HoEnrollmentDownloadHistory,Long> {

    public List<HoEnrollmentDownloadHistory> findByIsActiveIsTrueAndIsSuccessIsTrueAndCompletionDateBetweenAndOrgIdAndSchemeIdOrderByCompletionDateDesc(Date fromDate, Date toDate, Long orgId, Long schemeId, Pageable pageable);

    public Long countByIsActiveIsTrueAndIsSuccessIsTrueAndOrgIdAndSchemeIdAndCompletionDateBetween(Long orgId, Long schemeId,Date fromDate, Date toDate);

    public List<HoEnrollmentDownloadHistory> findByIsActiveIsTrueAndIsSuccessIsTrueAndCompletionDateBetweenAndInsurerOrgIdAndOrgIdAndSchemeIdOrderByCompletionDateDesc(Date fromDate, Date toDate, Long insurerOrgId, Long orgId, Long schemeId, Pageable pageable);

    public Long countByIsActiveIsTrueAndIsSuccessIsTrueAndInsurerOrgIdAndOrgIdAndSchemeIdAndCompletionDateBetween(Long insurerOrgId, Long orgId, Long schemeId,Date fromDate, Date toDate);

    public List<HoEnrollmentDownloadHistory> findByIsActiveIsTrueAndIsSuccessAndCompletionDateOrderByCreatedDateDesc(Boolean isSuccess, Date fromDate);
    
    public List<HoEnrollmentDownloadHistory> findByIsActiveIsTrueAndIsSuccessIsFalseOrderByCreatedDateDesc();
    
    public List<HoEnrollmentDownloadHistory> findByIsActiveIsTrueAndIsSuccessIsFalseAndCompletionDateBetweenAndOrgIdOrderByCreatedDateDesc(Date fromDate, Date toDate, Long orgId);
    
    public HoEnrollmentDownloadHistory findFirstByCompletionDateAndSchemeIdAndOrgIdAndIsActiveTrueAndIsSuccessTrue(Date complDate,Long schemeId,Long orgId);
}
