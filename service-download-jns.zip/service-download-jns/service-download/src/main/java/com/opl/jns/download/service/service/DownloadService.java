package com.opl.jns.download.service.service;

import org.springframework.stereotype.Service;

import com.opl.jns.download.api.proxy.DownloadReq;
import com.opl.jns.utils.common.CommonResponse;

@Service
public interface DownloadService  {
	CommonResponse checkIfDownload(DownloadReq req);
	
	CommonResponse downloadHistory(DownloadReq req);
	
	byte[] downloadEnrollmentData(DownloadReq req);
}
