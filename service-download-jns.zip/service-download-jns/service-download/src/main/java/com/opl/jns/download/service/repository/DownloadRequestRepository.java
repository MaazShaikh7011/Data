package com.opl.jns.download.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.download.service.domain.*;

public interface DownloadRequestRepository  extends JpaRepository<DownloadRequest,Long> {
	
	
//	public void findAllEnrollMentList();
	

	DownloadRequest findByTokenId(String tokenId);

	DownloadRequest findByCreatedBy(Long createdBy);

	DownloadRequest findFirstByCreatedByOrderByCreatedDateDesc(Long createdBy );
	
	DownloadRequest findFirstByCreatedByAndSchemeIdOrderByCreatedDateDesc(Long createdBy ,Long schemeId);
	
//	List<DownloadRequest> findByCreatedByAndIsDownloadTrueOrderByCreatedDateDesc(Long createdBy);
	List<DownloadRequest> findByCreatedByAndSchemeIdAndDocStorageIdIsNotNullOrderByCreatedDateDesc(Long createdBy,Long schemeId);

	List<DownloadRequest> findByCreatedByAndSchemeIdAndIsDownloadIsTrueOrderByCreatedDateDesc(Long createdBy,Long schemeId);
}
