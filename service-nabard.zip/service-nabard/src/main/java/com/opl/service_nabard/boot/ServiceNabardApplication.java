package com.opl.service_nabard.boot;

import com.opl.jns.nabard.config.proxy.ApplicationProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableCaching
@EnableAutoConfiguration
@EnableConfigurationProperties(ApplicationProperties.class)
public class ServiceNabardApplication {

//	@Autowired
//	ServiceImpl service;

	public static void main(String[] args) {
		SpringApplication.run(ServiceNabardApplication.class, args);
	}

//	@EventListener(ApplicationStartedEvent.class)
//	@PostConstruct
//	public void call(){
//		service.clearCache();
//	}

}
