package com.opl.service_nabard.controller;

import com.opl.jns.nabard.config.utils.MultipleJSONObjectHelper;
import com.opl.service_nabard.proxy.TriggerOtpResponse;
import com.opl.service_nabard.service.ServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
public class Controller {

    @Autowired
    ServiceImpl service;


    @PostMapping(value = "/testApi", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TriggerOtpResponse> testAPI(@Valid @RequestBody Object triggerOtpRequest, HttpServletRequest httpServletRequest) {

        try {
            log.info("START TRIGGER OTP ----------------> {}" , MultipleJSONObjectHelper.getStringfromObject(triggerOtpRequest));
            service.callTriggerOtp(triggerOtpRequest,14l);
        }catch (Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<TriggerOtpResponse>(new TriggerOtpResponse("TEST APP"), HttpStatus.OK);
    }



    @PostMapping(value = "/triggerOTP", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TriggerOtpResponse> triggerOTP(@Valid @RequestBody Object triggerOtpRequest, HttpServletRequest httpServletRequest) {

        try {
            log.info("START TRIGGER OTP ----------------> {}" , MultipleJSONObjectHelper.getStringfromObject(triggerOtpRequest));
        }catch (Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<TriggerOtpResponse>(new TriggerOtpResponse("TEST APP"), HttpStatus.OK);
    }
}
