package com.opl.service_nabard.proxy;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;


@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "flag", "mobileNumber" })
public class TriggerOtpResponse {

	@NotNull(message = "Mobile Number of the selected A/C holder is not found in the Bank CBS.")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	public TriggerOtpResponse() {
		super();
	}

	public TriggerOtpResponse(String mobileNumber) {
		this.mobileNumber =  mobileNumber;
	}

}