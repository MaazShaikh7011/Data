package com.opl.service_nabard.service;

import com.opl.jns.nabard.config.proxy.bank.api.ApiMasterRequest;
import com.opl.jns.nabard.config.proxy.bank.api.BankAPICommonRes;
import com.opl.jns.nabard.config.service.commonConfig.ApiConfigService;
import com.opl.jns.nabard.config.service.integratedRest.HttpUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ServiceImpl {

    @Autowired
    HttpUtility utilityImpl;

    @Autowired
    ApiConfigService apiConfigService;


    public Object callTriggerOtp(Object triggerOtpReq,Long orgId){
        try {
            ApiMasterRequest apiMaster = apiConfigService.getApiMasterByOrgId(orgId);
            String referenceId ="BANK_API_1234" + Math.random();
            String reqToken = "BA_1236554565466556" + Math.random();
            BankAPICommonRes obj = new BankAPICommonRes();
            utilityImpl.post(triggerOtpReq,orgId,1l,1,apiMaster.getId(),obj,referenceId,
                    null,null,apiMaster.getHeaderConfig().getV3(),null,reqToken,false);


        }catch (Exception e){
            log.info("api master not found :",e);
        }
        return null;
    }


}
