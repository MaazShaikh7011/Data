package com.opl.jns.common.service.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import de.codecentric.boot.admin.server.config.EnableAdminServer;

/**
 * 
 * @author krunal.prajapati
 *
 */
@SpringBootApplication
@EnableAdminServer
public class ServiceSpringBootAdminAnsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceSpringBootAdminAnsApplication.class, args);
	}

}
