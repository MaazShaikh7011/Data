package com.opl.jns.service.assitedjourney.v2.enums;

public enum SchemeMaster {
	PMSBY, PMJJBY
}
