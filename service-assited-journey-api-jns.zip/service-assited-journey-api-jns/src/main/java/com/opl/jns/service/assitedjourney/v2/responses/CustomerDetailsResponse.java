package com.opl.jns.service.assitedjourney.v2.responses;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import com.opl.jns.service.assitedjourney.v2.model.*;
import com.opl.jns.service.assitedjourney.v2.responses.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "accountHolderDetails" })
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CustomerDetailsResponse extends CommonResponse {

	@JsonProperty("accountHolderDetails")
	private AccountHolderDetailsResponse accountHolderDetails;

}
