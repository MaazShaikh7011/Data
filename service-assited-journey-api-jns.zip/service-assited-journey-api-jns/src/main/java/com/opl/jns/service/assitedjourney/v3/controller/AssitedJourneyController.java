package com.opl.jns.service.assitedjourney.v3.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.service.assitedjourney.v3.model.CustomerDetailsRequest;
import com.opl.jns.service.assitedjourney.v3.model.PushEnrollmentDetailsRequest;
import com.opl.jns.service.assitedjourney.v3.model.PhysicalVerificationRequest;
import com.opl.jns.service.assitedjourney.v3.model.PremiumDeductionRequest;
import com.opl.jns.service.assitedjourney.v3.model.PushEnrollmentDetailsResponse;
import com.opl.jns.service.assitedjourney.v3.model.TriggerVerificationCodeRequest;
import com.opl.jns.service.assitedjourney.v3.model.VerifyVerificationCodeRequest;
import com.opl.jns.service.assitedjourney.v3.responses.CustomerDetailsResponse;
import com.opl.jns.service.assitedjourney.v3.responses.PhysicalVerificationResponse;
import com.opl.jns.service.assitedjourney.v3.responses.PremiumDeductionResponse;
import com.opl.jns.service.assitedjourney.v3.responses.Response400;
import com.opl.jns.service.assitedjourney.v3.responses.Response401;
import com.opl.jns.service.assitedjourney.v3.responses.TriggerVerificationCodeResponse;
import com.opl.jns.service.assitedjourney.v3.responses.VerifyVerificationCodeResponse;
import com.opl.jns.service.assitedjourney.v3.utils.CommonUtils;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "1. Assisted Mode Enrolment API", description = "List of APIs for Banker Assisted journey on JanSuraksha platform ")
public class AssitedJourneyController {

	@PostMapping(value = "/triggerVerificationCode")
	@Operation(operationId = Constants.STR_1, summary = CommonUtils.TRIGGER_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.TRIGGER_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.TRIGGER_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = TriggerVerificationCodeResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.TRIGGER_RESPONSE_SUCCESS,description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) })

	})
	public ResponseEntity<TriggerVerificationCodeResponse> triggerOTP(@RequestBody TriggerVerificationCodeRequest applicationRequest,
			HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/verifyVerificationCode")
	@Operation(operationId = Constants.STR_2, summary = CommonUtils.VERIFY_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.VERIFY_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.VERIFY_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = VerifyVerificationCodeResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.VERIFY_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<VerifyVerificationCodeResponse> verifyOTP(@RequestBody VerifyVerificationCodeRequest applicationRequest,
			HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/physicalSignatureVerification")
	@Operation(operationId = Constants.STR_3, summary = CommonUtils.PHYSICAL_VERIFICATION, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PHYSICAL_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.PHYSICAL_VERIFICATION_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PhysicalVerificationResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PHYSICAL_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PhysicalVerificationResponse> physicalVerification(
			@RequestBody PhysicalVerificationRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/getCustomerDetails")
	@Operation(operationId = Constants.STR_4, summary = CommonUtils.GET_CUSTOMER_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CUSTOMER_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.CUSTOMER_RECORD_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CustomerDetailsResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CUSTOMER_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE_FORMAT),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<CustomerDetailsResponse> getCustomerDetails(
			@RequestBody CustomerDetailsRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/premiumDeduction")
//	@Tag(name = "5. PREMIUM DEDUCTION API")
	@Operation(operationId = Constants.STR_5, summary = CommonUtils.PREMIUM_DEDUCT, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PREMIUM_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PremiumDeductionResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PREMIUM_RESPONSE_SUCCESS, description = Constants.PREMEMIUM_RESPONSE_DESC),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PremiumDeductionResponse> premiumDeduction(
			@RequestBody PremiumDeductionRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/pushEnrollmentDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = Constants.STR_6, summary = CommonUtils.PUSH_ENROLLMENT, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_EXAMPLE, description = Constants.PUSH_ENROLLMENT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PushEnrollmentDetailsResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_SUCCESS,description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) })

	})
	public ResponseEntity<PushEnrollmentDetailsResponse> consumeEnrollmentDetails(
			@Valid @RequestBody PushEnrollmentDetailsRequest detailsRequest, HttpServletRequest httpServletRequest) {
		try {
			PushEnrollmentDetailsResponse data = null;
			return new ResponseEntity<>(data, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(new PushEnrollmentDetailsResponse(), HttpStatus.OK);
		}

	}
//
//	@PostMapping(value = "/updateClaimStatus")
//	@Operation(
//			operationId = Constants.STR_6,
//			summary = Constants.UPDATE_CLAIM_STATUS,
//			requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC,
//					content = @Content(examples = {
//							@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
//							@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
//					})),
//			responses = {
//					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE,
//							content = {
//									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateStatusResponse.class),
//											examples = {
//													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS),
//													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//											})
//							}
//
//					),
//					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
//							content = {
//									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
//											examples = {
//													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
//													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//											}
//									)
//							}),
//					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
//							content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class),
//									examples = {
//											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//									}
//							)}
//					)
//			}
//	)
//	public ResponseEntity<CoiResponse> bankClaimWebHook(@RequestBody UpdateClaimStatus updateClaimStatus, HttpServletRequest httpServletRequest) {
//		if (OPLUtils.isObjectNullOrEmpty(updateClaimStatus)) {
//			return new ResponseEntity<>(new CoiResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//		}
//		try {
//			Object orgId = httpServletRequest.getAttribute(AuthCredentialUtils.ORG_ID);
//			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
//				return new ResponseEntity<>(new CoiResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
//			Long userOrgId = Long.valueOf(String.valueOf(orgId));
//			log.info("userOrgId ==> {}", userOrgId);
//			return new ResponseEntity<>(null, HttpStatus.OK);
//		} catch (Exception e) {
//			e.printStackTrace();
//			log.error("Error in getApplicationList() {}", e.getMessage());
//			return new ResponseEntity<>(new CoiResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//		}
//
//	}

}
