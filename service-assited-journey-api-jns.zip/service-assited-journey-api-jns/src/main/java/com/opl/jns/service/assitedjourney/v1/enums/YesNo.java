package com.opl.jns.service.assitedjourney.v1.enums;

public enum YesNo {

	YES,NO
}
