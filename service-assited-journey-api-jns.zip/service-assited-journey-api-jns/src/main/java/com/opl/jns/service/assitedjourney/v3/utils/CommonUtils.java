package com.opl.jns.service.assitedjourney.v3.utils;

public class CommonUtils {

	public static final String TRIGGER_OTP = "Trigger to Bank to send verification code to the RMN with the requested Bank A/C";
	public static final String VERIFY_OTP = "To verify verification code sent to the RMN with the requested Bank A/C";
	public static final String GET_CUSTOMER_DETAILS = "To fetch  details of the ETB customer from the Bank records";
	public static final String PREMIUM_DEDUCT = "To trigger debit premium from ETB customer's A/C and credit to Insurer's/pool A/C confirmation";
	public static final String PHYSICAL_VERIFICATION = "To verify signature of the applicant with the requested Bank A/C";
	public static final String TRIGGER_OTP_DIY = "To send OTP to the RMN with the requested Bank A/C";
	public static final String VERIFY_OTP_DIY = "To verify OTP sent to the RMN with the requested Bank A/C";
	public static final String  PUSH_ENROLLMENT_DEATILS = "pushEnrollmentDetails";
	public static final String GET_ACC_HOLDERlIST = "To fetch A/C holder list from Bank records";
	public static final String OPT_OUT_STATUS = "To update Bank/Insurer for the Opt Out request by the Applicant";
	public static final String FETCH_ENROLLMENT_MISAPI = "fetchEnrollmentMIS";
	public static final String FETCH_CLAIM_MISAPI = "fetchClaimMIS";
	public static final String POLICY_DETAILS_FETCH = "To fetch Enrolment details of the Applicant from Bank records";
	public static final String FETCH_INSURED_DETAILS = "API to fetch Insured Details.";
	public static final String PUSH_GRIEVANCE = "API to push Grievance.";
	public static final String UPDATE_GRIEVANCE_STATUS = "API to update Grievance Status.";
	public static final String NOMINEE_UPDATE_STATUS = "To push Nominee update details to Bank/Insurer";
	public static final String GET_COI_DETAILS = "To fetch COI details of the Applicant from Insurer records";
    public static final String PUSH_CLAIM_DETAILS = "To push successful Claim registration details and documents to Banks/Insurers";
    public static final String PUSH_CLAIM_STATUS_TO_BANK = "To update claim status to Bank from JS portal";
    public static final String PUSH_ENROLLMENT = "To push successful enrolment details to Bank/Insurer";
    
	public static final String COMMON_DATA_MESSAGE = "In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :\n"
			+ "1. 200 (flag: true) - Success\n" + "2. 500 (flag: false) - Internal Server Error\n"
			+ "3. 400 (flag: false) - Parameter Missing in Request (Bad Request)\n"
			+ "4. 400 (flag: false) - Request Header is Null or Invalid  (Bad Request)";

	public static final String TRIGGER_OTP_DATA_MESSAGE = "\n\n" + "Trigger OTP error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" + "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Mobile number is not linked with requested account number\n"
			+ "4. 500 (flag: false) - Internal server error while sending OTP\n";
	
	public static final String VERIFY_OTP_DATA_MESSAGE = "\n\n" + "Verify OTP error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Invalid OTP \n"
			+ "4. 500 (flag: false) - Internal server error while verifying OTP\n";
	
	public static final String PHYSICAL_VERIFICATION_DATA_MESSAGE = "\n\n" + "Physical Signature Verification error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - No account holder details found \n";
	
	public static final String CUSTOMER_RECORD_DATA_MESSAGE = "\n\n" + "Customer Record error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - CIF null or invalid found \n"
			+ "5. 400 (flag: false) - No data found from account number and CIF \n";
	
	public static final String PAYMENT_DATA_MESSAGE = "\n\n" + "Premium Deduction error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Insurer Account Number Invalid\n" 
			+ "4. 400 (flag: false) - Insurer Account Inactivated\n"
			+ "5. 500 (flag: false) - Insernal server error while payment deduction \n";

	public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
	public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

}
