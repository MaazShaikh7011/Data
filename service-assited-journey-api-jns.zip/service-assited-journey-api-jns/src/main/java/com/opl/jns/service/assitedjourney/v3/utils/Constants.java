package com.opl.jns.service.assitedjourney.v3.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;

public class Constants {

	
	public static final  String CUSTOMER_REQUEST_EXAMPLE="{\"accountNumber\":\"45455545\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String PHYSICAL_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"signVerifiedByBank\": \"YES\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String CUSTOMER_RESPONSE_SUCCESS="{\"status\":200,\"message\":\"string\",\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"accountHolderDetails\":{\"cif\":\"stringstri\",\"customerIFSC\":\"XXXX000000\",\"accountHolderName\":\"string\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"string\",\"emailId\":\"string\",\"addressline1\":\"string\",\"addressline2\":\"string\",\"city\":\"string\",\"district\":\"string\",\"state\":\"string\",\"pincode\":382350,\"kycID1\":\"DRIVINGL\",\"kycID1number\":\"string\",\"pan\":\"YES\",\"panNumber\":\"XXXXX0000X\",\"aadhaar\":\"YES\",\"aadhaarNumber\":\"stringstri\",\"applicantOccupation\":\"string\",\"nomineeName\":\"string\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"9899999999\",\"relationshipOfNominee\":\"string\",\"nomineeEmailId\":\"xyz@abc.com\",\"addressofNominee\":\"string\",\"nameofGuardian\":\"string\",\"addressofGuardian\":\"string\",\"relationshipOfGuardian\":\"string\",\"guardianMobileNumber\":\"7544454578\",\"guardianEmailId\":\"abc@gmail.com\",\"bcReferralId\":\"string\",\"consentForautodebit\":\"YES\"}}";
	public static final  String PHYSICAL_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": \"true\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}]}";
	public static final  String PREMIUM_REQUEST_EXAMPLE="{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"mode\": \"DIY\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String PREMIUM_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"debitStatus\": 1,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String TRIGGER_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String TRIGGER_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"mobileNumber\": \"7565544547\"}";
	public static final  String VERIFY_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"verifyVerificationcode\": \"454315\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String VERIFY_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String GET_ACC_HOLDERlIST_EXAMPLE="{\"accountNumber\": \"2222222222\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String GET_ACC_HOLDERlIST_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderList\": [{\"accountNumber\": \"2222222222\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"policyInceptionDate\": \"2000-08-08 15:24:58\",\"scheme\": \"PMSBY\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	
	public static final  String DIY_TRIGGER_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"purpose\": \"NEW ENROLLMENT\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String DIY_TRIGGER_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"mobileNumber\": \"7565544547\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String DIY_VERIFY_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"verifyVerificationcode\": \"454315\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"accHolderDtlsReq\":\"YES\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String DIY_VERIFY_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String OPT_OUT_STATUS_EXAMPLE="{\"accountNumber\": \"2222222222\",\"cif\":\"5454554\",\"urn\": \"JNS-XXXXX-00-00-00000000000-000\",\"effectiveDate\": \"2000-08-08 00:00:00\",\"requestDate\": \"2000-08-08 00:00:00\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String OPT_OUT_STATUS_SUCCESS="{\"status\": 200,\"message\": \"string\",\"success\": \"true\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String GET_COI_EXAMPLE="{\"accountNumber\":\"11111111111\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"dob\":\"2000-08-08\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String GET_COI_SUCCESS="{\"accountHolderName\":\"nimesh\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7569987896\",\"addressline1\":\"Isanpur\",\"addressline2\":\"Isanpur\",\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"pincode\":385445,\"kycID1\":\"PAN\",\"kycID1number\":\"FMXOO9090A\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nameofGuardian\":\"rock\",\"relationshipOfGuardian\":\"Son\",\"status\": 200,\"message\": \"string\",\"flag\": true,\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"Timestamp\":\"2000-08-08 15:24:58\"}";
//	public static final  String GET_COI_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"},\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"Timestamp\":\"2000-08-08 15:24:58\"}";
	
	public static final  String NOMINEE_UPDATE_SUCCESS="{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String NOMINEE_UPDATE_STATUS_EXAMPLE="{\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"nomineeUpdateFlag\":\"YES\",\"nomineeName\":\"harsh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7845124512\",\"relationshipOfNominee\":\"WIFE\",\"nomineeEmailId\":\"xyz@gmail.com\",\"addressOfNominee\":\"jarkhand\",\"nameOfGuardian\":\"rahul\",\"addressOfGuardian\":\"jamanagar\",\"relationshipOfGuardian\":\"HUSBAND\",\"guardianMobileNumber\":\"7845895623\",\"guardianEmailId\":\"xyz@gmail.com\"}";
	public static final  String CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":\"452134531\",\"masterPolicyNumber\":\"56556555556\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"schemeName\":\"PMSBY\",\"customerAccountNumber\":\"784512451245\",\"customerBankname\":\"Union\",\"customerIFSC\":\"UBIN0994599\",\"accountHolderName\":\"nimesh\",\"dob\":\"2000-08-08\",\"gender\":\"M\",\"insurerCode\":\"784512\",\"bankCode\":\"784521\",\"branchCode\":\"784512\",\"bankBranchEmailId\":\"xyx@opl.com\", \"mobileNumber\":\"7845124512\",\"emailID\":\"xyx@opl.com\",\"addressline1\":\"A-2 new\",\"addressline2\":\"old city\",\"pincode\":\"382415\",\"city\":\"ahmedabad\",\"district\":\"gujarat\",\"state\":\"gujarat\",\"kycID1\":\"PAN\",\"kycID1number\":\"FMXOO9090A\",\"pan\":\"Y\",\"panNumber\":\"FMXUU7878A\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"784512458956\",\"ckyc\":\"Y\",\"ckycNumber\":\"78451245124512\",\"nomineeName\":\"harsh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeGender\":\"M\",\"nomineeMobileNumber\":\"7845124512\",\"relationshipOfNominee\":\"BROTHER\",\"nomineeEmailId\":\"sss@opl.com\",\"addressofNominee\":\"new delhi\",\"correctNomineeName\":\"rahul\",\"nameofGuardian\":\"harsh\",\"addressOfGuardian\":\"new mumbai\",\"relationShipOfGuardian\":\"SON\",\"guardianMobileNumber\":\"8956234512\",\"guardianEmailId\":\"www@opl.com\",\"claimantName\":\"rajesh\",\"claimantAddress\":\"rajasatstan\",\"claimantDateOfBirth\":\"2000-08-08\",\"relationshipOfClaimant\":\"WIFE\",\"claimantMobileNumber\":\"8945154512\",\"claimantEmailId\":\"ttt@opl.com\",\"claimantKYC1\":\"PAN\",\"claimantKYCNumber1\":\"FDXII8989A\",\"claimantKYC2\":\"AADHAR\",\"claimantKycNumber2\":\"784512458956\",\"claimantGender\":\"M\",\"dateOfAccident\":\"2000-08-08\",\"timeOfAccident\":\"02:20:45\",\"dayOfAccident\":\"Sunday\",\"placeOfOccurence\":\"delhi\",\"natureOfAccident\":\"done\",\"dateOfDeath\":\"2000-08-08 15:24:58\",\"causeOfDeath\":\"Suicide\",\"causeOfDeathDisability\":\"Suicide\",\"typeOfDisability\":\"Total permanent\",\"claimantBankAccountNumber\":\"784512451245\",\"claimantBankName\":\"Union\",\"claimantBranchIFSC\":\"UBIN0995999\",\"premDebitDate\":\"2000-08-08\",\"premRemitDate\":\"2000-08-08\",\"dateOfLodgingClaim\":\"2000-08-08\",\"documents\":[{\"documentType\":\"claimDocuments\",\"contentType\":\"pdf\",\"documentId\":\"7845124512\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}]}";
	public static final  String CLAIM_PUSH_PLAIN_RESPONSE_200="{\"message\":\"success\",\"success\":true,\"status\":\"200\",\"success\":true,\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\":\"2023-11-27 16:05:22\"}";
	
	public static final  String UPDATE_CLAIM_STATUS_INSURE_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":1,\"insurerStatus\":\"String\",\"reason\":1,\"claimId\":\"456789\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"},\"token\":\"string\"}";
	public static final  String UPDATE_CLAIM_STATUS_RESPONSE_EXAMPLE="{\"message\":\"String\",\"status\":\"200\",\"token\":\"string\",\"timeStamp\": \"2023-11-27 16:05:22\",\"success\":\"true\"}";
	
	public static final  String PUSH_ENROLLMENT_DEATILS_EXAMPLE="{\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"policyYear\":\"2022\",\"insurerCode\":\"78451\",\"transactionUTR\":\"string\",\"transactionTimeStamp\":\"2023-05-16 09:16:54\",\"transactionAmount\":0,\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"source\":\"Other channel\",\"mode\": \"DIY\",\"transactionType\":\"N\",\"masterPolicyNumber\":\"56556555556\",\"schemeName\":\"string\",\"branchCode\":\"string\",\"bankCode\":\"784521\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"1051\",\"userId2\":\"1051\",\"channelId\":\"string\",\"ruralUrban\":\"Rural\",\"accountNumber\":\"*******8243\",\"cif\":\"5454554\",\"customerIFSC\":\"AAAD0FDFF\",\"accountHolderName\":\"Rock\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"pincode\":385445,\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"kycID1\":\"PAN\",\"kycID1Number\":\"AAGFV5271N\",\"pan\":\"Y\",\"panNumber\":\"string\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"string\", \"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringsssss\", \"applicantOccupation\":\"worker\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"relationshipOfNominee\":\"Wife\",\"nomineeEmailId\":\"rajesh@opl.com\",\"addressofNominee\":\"Isanpur\",\"nameofGuardian\":\"rock\",\"addressOfGuardian\":\"Isanpur\",\"relationShipOfGuardian\":\"Son\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"} }";	    	
	public static final  String PUSH_ENROLLMENT_DEATILS_SUCCESS="{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";

	public static final  String POLICY_DETAILS_REQUEST_EXAMPLE="{\"accountNumber\": \"*******8243\",\"accountHolderName\": \"string\",\"cif\":\"5454554\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"dob\": \"2000-08-08\",\"tranDetailsReqdDate\": \"2000-08-08 00:00:00\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
//	public static final  String POLICY_DETAILS_RESPONSE_EXAMPLE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\"}";
	public static final  String POLICY_DETAILS_RESPONSE_SUCCESS="{\"customerIFSC\":\"XXXX000000\",\"accountHolderName\":\"string\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"string\",\"emailId\":\"string\",\"addressline1\":\"string\",\"addressline2\":\"string\",\"city\":\"string\",\"district\":\"string\",\"state\":\"string\",\"pincode\":382350,\"kycID1\":\"DRIVINGL\",\"kycID1number\":\"string\",\"pan\":\"YES\",\"panNumber\":\"XXXXX0000X\",\"aadhaar\":\"YES\",\"aadhaarNumber\":\"784512457845\",\"ckyc\":\"YES\",\"ckycNumber\":\"78451245124512\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"string\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"9899999999\",\"relationshipOfNominee\":\"string\",\"nomineeEmailId\":\"xyz@abc.com\",\"addressofNominee\":\"string\",\"nameofGuardian\":\"string\",\"addressofGuardian\":\"string\",\"relationshipofGuardian\":\"string\",\"guardianMobileNumber\":\"7544454578\",\"guardianEmailId\":\"abc@gmail.com\",\"status\": 200,\"success\":true,\"message\": \"string\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"transactionAmount\": 418,\"transactionUTR\": \"202368754654\",\"transactionTimestamp\": \"2023-11-27 16:05:22\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String FETCH_INSURED_DETAILS_REQUEST_EXAMPLE="{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
//	public static final  String FETCH_INSURED_DETAILS_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\"}";
	public static final  String FETCH_INSURED_DETAILS_RESPONSE_SUCCESS="{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final  String PUSH_GRIEVANCE_REQUEST_EXAMPLE="{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
//	public static final  String PUSH_GRIEVANCE_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\"}";
	public static final  String PUSH_GRIEVANCE_RESPONSE_SUCCESS="{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final  String UPDATE_GRIEVANCE_STATUS_REQUEST_EXAMPLE="{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
//	public static final  String UPDATE_GRIEVANCE_STATUS_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\"}";
	public static final  String UPDATE_GRIEVANCE_STATUS_RESPONSE_SUCCESS="{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final  String CLAIM_DE_DUP_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":\"123\",\"hospitalisationDate\":\"2023-11-27 16:05:22\",\"firNo\":\"String\",\"firDate\":\"2023-11-27 16:05:22\",\"panchnamaNo\":\"String\",\"panchnamaDate\":\"2023-11-27 16:05:22\",\"postMortemReportNo\":\"String\",\"postMortemReportDate\":\"2023-11-27 16:05:22\",\"deathCertificateReportNo\":\"String\",\"deathCertificateReportDate\":\"2023-11-27 16:05:22\",\"documentReceivingDate\":\"2023-11-27 16:05:22\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final  String CLAIM_DE_DUP_PLAIN_RESPONSE_SUCCESS="{\"message\":\"Success\",\"success\":true,\"status\":200,\"data\":{\"dedupeCheck\":true,\"isMatchWith\":{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"intimationDate\":\"\",\"type\":1,\"claimStatus\":1,\"dateOfLoss\":\"\",\"beneficiaryName\":\"{Nominee/Guardian/Claimant Name}\",\"beneficiaryBank\":\"\"}},\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	
	public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
	
	public static final String UPDATE_STATUS = "Update Status";
	public static final  String UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE="{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"status\":7,\"reason\":\"string\"}";
    public static final  String UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"string\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	
	public static final  String PLAIN_RESPONSE_400="{\"message\": \"It seems that request is not properly formed.\",\"status\": 400,\"success\": false,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final  String PLAIN_RESPONSE_401="{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false,\"flag\":false}";
    public static final String[] EMPTY_STRING_ARRAY = new String[0];
    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
    public static final String COMMON_DOCUMENT_MESSAGE = "Get Upload Documents Response";
    public static final String DE_DUP_API_MESSAGE = "To check de-dupe validation for enrollment, claim and renewal";
    
    public static final String PLAIN_REQUEST_LBL = "Plain Request";
    public static final String PLAIN_RESPONSE_LBL = "Plain Response";
    public static final String PLAIN_REQUEST_LBL_DATE = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u>";
//    public static final String PLAIN_REQUEST_LBL_DATE_FORMAT = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
    public static final String PLAIN_REQUEST_LBL_DATE_FORMAT = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u> <br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u> <br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
    
    public static final String PLAIN_REQUEST_LBL_DATE_TIME = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b><u><br>";
    public static final String PREMEMIUM_RESPONSE_DESC = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><b>debitStatus</b> >>> <b>Enum :</b> <br>For Enum 1 - COI will Generate<br>For Enum 2 - The case will be moved to failed and reattempt for COI to be done<br>For Enum 3 to 8 - The reponse will have success with COI null. The case will be moved to Rejected";
    public static final String PLAIN_REQUEST_LBL_ACC_HOLDER_LIST = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u><br><br><u><b>URN</b> is mandatory</u><br><br><u><b>Policy inception date should be the of the current Policy Year.</b></u>";
    public static final String DATE_FORMAT_DESCRIPTION_AND_OTHER="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Repudiated and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved claims</b><u><br>";
    public static final String REQUEST_EXAMPLES_DESC = "Request examples";
    public static final String DATE_FORMAT_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b>";
    public static final String PUSH_CLAIMSTATUS_TO_BANK="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Rejected and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved Claims</b><u><br>";
    
    public static final String DOB_DATE_FORMAT_DESCRIPTION_ACC_HOLDER_LIST="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Account Number & DOB OR URN is mandatory</b></u>";
    public static final String DOB_DATE_FORMAT_DESCRIPTION_UPDATE_OPTOUT="<u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>URN</b> is mandatory</u><br>";
    public static final String DOB_DATE_FORMAT_DESCRIPTION="<br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u>";
    public static final String INSURER_UPDATE_CLAIM_STATUS_BANK="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Reason is mandatory for Rejected and Queried claims</u><br><br><u>Transaction details are mandatory for Approved claims</u><br><br><u>Mandatory for Insurers not using JS portal for claims; if using JS portal then the API is optional</u><br><br>"
    	    + "<p><b>reason</b> >>>  <b>Enum :</b> <br>"
    	    		+ "  <b>Queried Claims:</b> <br>"
    	    		+ "				1. Complete claim documents not submitted by claimants, <br>"
    	    		+ "				2. Claim documents not forwarded by banks to insurer, <br>"
    	    		+ "				3. Deceased’s name mismatch with death certificate, <br>"
    	    		+ "				4. Nominee’s name differs in enrolment & claim form, <br>"
    	    		+ "				5. KYC proof of nominee not submitted, <br>"
    	    		+ "				6. NEFT account details of nominee not submitted, <br>"
    	    		+ "				7. Title to claim money not clear, <br>"
    	    		+ "				8. NEFT Rejected </p>"
    	    		+ " <p> <b>Rejected claims:</b> <br>"
    	    		+ "  <b>PMJJBY scheme: </b> <br>"
    	       		+ "				1. Complete claim documents not submitted by claimants, <br>"
    	    		+ "				2. Death during lien period, <br>"
    	    		+ "				3. Death not established by documents submitted, <br>"
    	    		+ "				4. Others <br>"
    	    		+ "  <b>PMSBY scheme: </b> <br>"
    	       		+ "				1. Duplicate claim, <br>"
    	    		+ "				2. Death due to suicide, <br>"
    	    		+ "				3. Death is not due to accident, <br>"
    	    		+ "				4. Disability not due to accident ,<br>"
    	    		+ "				5. Disability not permanent ,<br>"
    	    		+ "				6. Death / disability due to accident, not established by documents submitted ,<br>"
    	    		+ "				7. Others";
    public static final String DOB_DATE_FORMAT_DESCRIPTION_POLICY_HOLDER="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><b><u>If tranDetailsReqdDate is sent in request, then transactionAmount, transactionUTR and transactionTimestamp is mandatory.</u></b>";
    public static final String DOB_DATE_FORMAT_DESCRIPTION_PUSH_CLAIM="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br>"
    		+"<br> Guardian details mandatory in case Nominee is minor."
    		+"<br> Claimant details mandatory in case Nominee is pre deceased."
    		+"<br> Correct Nominee name is mandatory in case Nominee name correction is required"
    		+"<br> Only Date of death and Cause of Death are mandatory for PMJJBY claims."
    		+"<br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims."
    		+"<br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims"	
    		+ "<br><br><br><p><b>documentList</b> >>> <b>documentId</b> >>> <b>Enum :</b> <br>"
    		+ "				4 - Signed and dully filled Claim cum discharge Form *, <br>"
    		+ "				5 - Death Certificate *, <br>"
    		+ "				6 - Hospital Discharge Summary *,\r\n <br>"
    		+ "				7 - Certificate issued by last attending Registered Medical Practitioner *,\r\n <br>"
    		+ "				8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *,\r\n <br>"
    		+ "				9 - FIR/Panchnama *,\r\n <br>"
    		+ "				10 - Hospital Records with deceased complete details *,\r\n <br>"
    		+ "				11 - KYC of Insured member *,\r\n <br>"
    		+ "				12 - KYC of Nominee/Claimant *,\r\n <br>"
    		+ "				13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *,\r\n <br>"
    		+ "				14 - Nominee Death Certificate *,\r\n <br>"
    		+ "				15 - Legal Heir Certificate *,\r\n <br>"
    		+ "				16 - Others *,\r\n <br>"
    		+ "				17 - Disability Certificate issued by Civil Surgeon *,\r\n <br>"
    		+ "				18 - Hospital records supporting the disability *,\r\n <br>"
    		+ "				19 - Checklist  *,\r\n <br>"
    		+ "				20 - Copy of Passbook of Insured *,\r\n <br>"
    		+ "				21 - Post mortem Report *,\r\n <br>"
    		+ "				22 - Aadhar/PAN of Nominee/Claimant *,\r\n<br>"
    		+ "				23 - Aadhar/PAN of Insured Member *</p>";
    public static final String PUSH_ENROLLMENT_DESCRIPTION="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>Disability status & Disability details mandatory only in PMSBY</u><br><br><u>For Assisted mode enrollment – user id 1 will be banker login id and user id 2 will be ‘bcreferralid’ if sent by Bank</u><br><br><u>For Other channel enrollments – user id 1 and user id 2 will be as per sent by Bank</u>";
    
    public static final String RASON_ENUM="<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br>"
    		+ "<p><b>reason</b> >>>  <b>Enum :</b> <br>"
    		+ "  <b>Queried Claims:</b> <br>"
    		+ "				1. Complete claim documents not submitted by claimants, <br>"
    		+ "				2. Claim documents not forwarded by banks to insurer, <br>"
    		+ "				3. Deceased’s name mismatch with death certificate, <br>"
    		+ "				4. Nominee’s name differs in enrolment & claim form, <br>"
    		+ "				5. KYC proof of nominee not submitted, <br>"
    		+ "				6. NEFT account details of nominee not submitted, <br>"
    		+ "				7. Title to claim money not clear, <br>"
    		+ "				8. NEFT Rejected </p>"
    		+ " <p> <b>Rejected claims:</b> <br>"
    		+ "  <b>PMJJBY scheme: </b> <br>"
       		+ "				1. Complete claim documents not submitted by claimants, <br>"
    		+ "				2. Death during lien period, <br>"
    		+ "				3. Death not established by documents submitted, <br>"
    		+ "				4. Others <br>"
    		+ "  <b>PMSBY scheme: </b> <br>"
       		+ "				1. Duplicate claim, <br>"
    		+ "				2. Death due to suicide, <br>"
    		+ "				3. Death is not due to accident, <br>"
    		+ "				4. Disability not due to accident ,<br>"
    		+ "				5. Disability not permanent ,<br>"
    		+ "				6. Death / disability due to accident, not established by documents submitted ,<br>"
    		+ "				7. Others";
    public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";
    
    public static final  String ENCRYPTED_REQUEST_EXAMPLE ="{\n \"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
    public static final String ENCRYPTED_RESPONSE ="{\n\"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";

    public static final String STATUS_UPDATE = "Status updated successfully.";

    public static final String STATUS_UPDATE_PROPERLY = "Please request status update for Hold/Reject only.";

    public static final String[] IGNORE_AUDOTIR_FIELDS = { "id", "createdDate", "isActive", "modifiedDate" ,"claimMaster"};
    public static final String[] IGNORE_AUDITOR_FIELDS_INCLUDES_NOMINEE = { "id", "createdDate", "isActive", "modifiedDate","nomineeFirstName","nomineeMiddleName","nomineeLastName","claimMaster" ,"applicationMaster"};
//    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
    public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
    public static final DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    public static final String DATE_FORMAT_DESCRIPTION_DATE="<u>Date Format should be <b>dd/MM/yyyy<b><u>";

    public static final String COMMON_DATA_MESSAGE = "In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :\n" +
            "1. 200 - Success\n" +
            "2. 500 - Internal Server Error\n" +
            "3. 400 - Parameter Missing in Request (Bad Request)\n" +
            "4. 400 - Invalid Application Reference Id  (Bad Request)";
    
    public static final String COMMON_DATA_MESSAGE_DE_DUPE = "In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :\n" +
            "1. 200 - Success\n" +
            "2. 204 - Data(de-dupe) Not Found.\n" +
            "3. 500 - Internal Server Error\n" +
            "4. 400 - Parameter Missing in Request (Bad Request)\n" +            
            "5. 400 - Invalid Application Reference Id  (Bad Request)";
    public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
    public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

    public static final String STATUS = "status";
    
    public static final String SUCCESS = "Success";

    public static final String FAILED = "Failed";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final long LONG_0 = 0L;
    public static final long LONG_1 = 1L;
    public static final long LONG_2 = 2L;
    public static final long LONG_3 = 3L;
    public static final long LONG_4 = 4L;
    public static final long LONG_5 = 5L;
    public static final long LONG_6 = 6L;
    public static final long DROP_DOWN_ID_RELATIONSHIP = LONG_1;
    public static final long KYC_DROP_DOWN_ID = LONG_2;
    public static final long CAUSE_OF_DESABILITY_DROP_DOWN_ID_PMJJBY = LONG_4;
    public static final long CAUSE_OF_DESABILITY_DROP_DOWN_ID_PMSBY = LONG_6;
    public static final long TYPE_OF_DISABILITY_DROP_DOWN_ID = LONG_5;
    public static final int INT_0 = 0;
    public static final int INT_1 = 1;
    public static final int INT_6 = 6;
    public static final int INT_14 = 14;
    public static final int INT_2 = 2;
    public static final int INT_3 = 3;
    public static final int INT_4 = 4;

    public static final int ENROLLMENT_STAGE_ID = INT_6;
    public static final int CLAIM_STAGE_ID = INT_14;
    public static final long NATURE_OF_LOSS = LONG_3;
    public static final String EXIT_FROM_UPDATE_CLAIM_STATUS = "... .Exit from updateClaimStatus(). ...";
//    public static final int INSURANCE_STATUS_ACCEPT = 10;
//    public static final int INSURANCE_STATUS_REJECTED = 8;
    public static final int ENROLLMENT_TYPE_ID_1 = INT_1;
    public static final String APPLICATION_NOT_FOUND = "Application not found";
    public static final String APPLICATION_NOT_PUSHED = "Application not pushed";
    public static final String APPLICANT = "Applicant";

    public static class MSG {
        public static final String SUCCESS = "Success";
        public static final String FAILED = "Failed";
        public static final String USER_NOT_FOUND = "User Not Found";
        public static final String SMTG_WNT_WNG = "Something Went Wrong.";
        public static final String TOKEN_SAVED_SUCCESS = "Token Saved Successfully";
        public static final String TOKEN_SAVED_FAILED = "Failed to save token";
    }

//    public static class DocumentAlias {
//    	DocumentAlias(){
//    	}
//
//        public static final Map<Long, String> SRMS_DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
//
//        public static final Map<Long, String> DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
//        public static final Long SIGNED_CLAIM_FORM = 4l;
//        public static final Long FIR_PUNCHNAMA = 5l;
//        public static final Long POST_MORTEM_REPORT = 6l;
//        public static final Long OTHER = 7l;
//
//        public static final String OTHERS_NAME = "Others";
//        public static final String QUATATION_OF_EQUIPMENT_NAME = "Quotation of Equipment";
//        public static final String PROJECT_REPORT_NAME = "Project Report";
//        public static final String WORK_ASSURANCE_LETTER_NAME = "Work Assurance Letter";
//        public static final String BANK_STATEMENT_NAME = "Bank Statement";
//
//
//        public static final String SIGNED_CLAIM_FORM_NAME = "Signed Claim Form";
//        public static final String FIR_PUNCHNAMA_NAME = "FIR / Panchnama";
//        public static final String POST_MORTEM_REPORT_NAME = "Post Mortem Report";
//        public static final String OTHER_NAME = "Other";
//        public static final String PDF ="pdf";
//        public static final String WORD ="word";
//        public static final String EXCEL ="excel";
//        public static final String TEXT ="text";
//        public static final String XML ="xml";
//
//
//        static {
//
//            DOCUMENT_MAP_ID_DESC_MAP.put(SIGNED_CLAIM_FORM, SIGNED_CLAIM_FORM_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(FIR_PUNCHNAMA, FIR_PUNCHNAMA_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(POST_MORTEM_REPORT, POST_MORTEM_REPORT_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(OTHER, OTHER_NAME);
//        }
//    }

//    public static class CostOfCourse {
//    	CostOfCourse(){
//    	}
//        public static final String TUITION_FEE = "Tuition Fee";
//        public static final String EXAM_FEE = "Exam Fee";
//        public static final String EQUIPMENT = "Equipment";
//        public static final String HOSTEL_EXPENSES = "Hostel Expenses";
//        public static final String OTHER_EXPENSES = "Other Expenses";
//    }

    public static class ErrorMsg {
    	ErrorMsg(){
    	}

        public static final String FAILED = "failed";
        public static final String SMTG_WNT_WRG = "Something went wrong";

    }

//    public static class Type {
//    	Type(){
//    	}
//        public static final String APPLICANT = "Applicant";
//        public static final String CO_APPLICANT = "Co-Applicant";
//        public static final String PARTNER = "Partner";
//        public static final String INDIVIDUAL = "Individual";
//        public static final String BUSINESS_ENTITY = "Business Entity";
//    }

    public enum ClaimStatus {

        RECEIVED_FROM_BANK(6, "Received from bank"),
        CLAIM_REPUDIATED(8, "Claim repudiated"),
        CLAIM_APPROVED(10, "Claim approved"),
        QUERY(7, "Query"),
        IN_PROCESS(11, "In process");
        private Integer id;
        private String description;

        ClaimStatus(Integer status, String description) {
            this.id = status;
            this.description = description;
        }

        public static ClaimStatus getById(Integer id) {
           return Arrays.stream(values()).filter(x -> x.getId().equals(id)).findFirst().orElse(null);
        }


        public Integer getId() {
            return this.id;
        }

        public String getDescription() {
            return this.description;
        }
    }
    public enum APIStatus {

        PENDING(1, "Pending"),
        IN_PROGRESS(2, "In progress"),
        FAILED(3, Constants.FAILED),
        READY(4, "Ready");
        private Integer id;
        private String description;

        APIStatus(Integer status, String description) {
            this.id = status;
            this.description = description;
        }

        public Integer getId() {
            return this.id;
        }

        public String getDescription() {
            return this.description;
        }
    }

//    public enum ScalingTypes {
//
//        RISK(1, "Risk Score"),
//        CIBIL(2, "Cibil Score"),
//        GROSS_MONTH_INCOME(3, "Gross Monthly Income"),
//        NET_MONTH_INCOME(4, "Net Monthly Income"),
//        LOAN_AMOUNT(5, "Loan Amount"),
//        BUREAU(7,"Bureau"),
//        TYPE_OF_BORROWER(8,"Type of borrower");
//
//        Integer id;
//        String value;
//
//        ScalingTypes(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static ScalingTypes getById(Integer id) {
//        	for(ScalingTypes scalingTypes : values()) {
//	   			 if(scalingTypes.getId().equals(id)){
//	   				 return scalingTypes;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }

//    public enum BaseRateTypes {
//
//        REPO_RATE(1, "Repo Rate"),
//        MCLR(2, "MCLR"),
//        BASE_RATE(3, "Base Rate");
//
//        Integer id;
//        String value;
//
//        BaseRateTypes(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static BaseRateTypes getById(Integer id) {
//        	for(BaseRateTypes baseRateTypes : values()) {
//	   			 if(baseRateTypes.getId().equals(id)){
//	   				 return baseRateTypes;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }

//    public enum ProposalStatus{
//
//        COMPLETED(1, "Completed"),
//        SANCTIONED(2, "Sanctioned"),
//        DISBURSED(3, "Disbursed"),
//        REJECT(4, "Reject"),
//        HOLD(5, "Hold"),
//        HOLD_AFTER_SANCTION(6, "Hold After Sanction"),
//        REJECT_AFTER_SANCTION(7, "Reject After Sanction"),
//        PARTIAL_DISBURSE(8, "Partial Disburse");
//
//        Integer id;
//        String value;
//
//        ProposalStatus(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static ProposalStatus getById(Integer id) {
//        	for(ProposalStatus proposalStatus : values()) {
//	   			 if(proposalStatus.getId().equals(id)){
//	   				 return proposalStatus;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }
    
//    public enum SubsidyStatus{
//    	PEDNING(1, "Pending"),
//        SEND_TO_NODEL_AGENCY(2, "Send to Nodel Agency"),
//        APPROVED(3, "Approved"),
//        HOLD(4, "Hold"),
//        REJECT(5, "Reject");
//
//        Integer id;
//        String stage;
//
//        SubsidyStatus(Integer id, String stage) {
//            this.id = id;
//            this.stage = stage;
//        }
//
//        public Integer getId(){
//            return this.id;
//        }
//
//        public String getStage(){
//            return this.stage;
//        }
//
//        public static SubsidyStatus getById(Integer id){
//        	for(SubsidyStatus subsidyStatus : values()) {
//   	   			 if(subsidyStatus.getId().equals(id)){
//   	   				 return subsidyStatus;
//   	   			 }
//   		 	}
//           	return null;
//        }
//    }
    
//    public enum ApplicationMaster{
//    	APPROVED(1,"Approved"),
//    	REFERRED(2,"Referred");
//
//    	Integer id;
//        String value;
//
//        ApplicationMaster(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public Integer getId(){
//            return this.id;
//        }
//
//        public String getValue(){
//            return this.value;
//        }
//
//        public static ApplicationMaster getById(Integer id) {
//            try {
//            	for(ApplicationMaster applicationMaster : values()) {
//      	   			 if(applicationMaster.getId().equals(id)){
//      	   				 return applicationMaster;
//      	   			 }
//      		 	}
//              	return null;
//            } catch (Exception e) {
//                return null;
//            }
//        }
//    }
//
//    public enum NoGSTReason {
//        EXISTING_BUSINESS(1, "GST is not applicable to my Product/Service."),
//        PERSONAL_LOAN(2, "GST is not applicable in my state."),
//        HOME_LOAN(3, "I/we am/are not required to fill GST return as my/our sales are below limit required to get GST registration."),
//        EDUCATION_LOAN(4, "Other reason");
//
//        private Integer id;
//        private String value;
//
//        private NoGSTReason(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public Integer getId() {
//            return id;
//        }
//
//        public String getValue() {
//            return value;
//        }
//
//        public static NoGSTReason fromId(Integer v) {
//            for (NoGSTReason c : NoGSTReason.values()) {
//                if (c.id.equals(v)) {
//                    return c;
//                }
//            }
//            throw new IllegalArgumentException(v != null ? v.toString() : null);
//        }
//    }
//
    //For Insurance
    public static final String COMMON_BASIC_INSURANCE_APPLICANT_MESSAGE = "Get the details of the list of insurance policies issued by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APPLICANT_DETAIL_MESSAGE = "To push successful enrolment, Nominee update details to Bank/Insurer";
    public static final String UPDATE_INSURANCE_STATUS_MESSAGE = "Update Applicantion Status by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_MESSAGE = "Get the details of the list of claims registered by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_DETAIL_MESSAGE = "Get all the detailed data of the claims taken by the banks through the portal.";
    public static final String UPDATE_INSURANCE_CLAIM_STATUS_MESSAGE = "Update Claim Status by the banks through the portal.";

    public static final String STR_1 = "1";
    public static final String STR_2 = "2";
    public static final String STR_3 = "3";
    public static final String STR_4 = "4";
    public static final String STR_5 = "5";
    public static final String STR_6 = "6";
    public static final String STR_7 = "7";
    public static final String STR_8 = "8";
    public static final String STR_9 = "9";
    public static final String STR_10 = "10";
    public static final String STR_11 = "11";
    public static final String STR_12 = "12";
    public static final String STR_13 = "13";
    public static final String STR_14 = "14";
    public static final String STR_15 = "15";
    public static final String STR_16 = "16";
    public static final String STR_17 = "17";
    public static final String STR_18 = "18";
    public static final String STR_19 = "19";
    public static final String STR_20 = "20";
    public static final String STR_21 = "21";
    public static final String STR_22 = "22";
    public static final String STR_23 = "23";
    public static final String STR_24 = "24";
    public static final String STR_25 = "25";
    public static final String STR_26 = "26";

    public static final String STRING_400 = "400";
    public static final String STRING_200 = "200";
    public static final String STRING_401 = "401";

    /** update claim status*/
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":1,\"claimId\":\"456789\",\"insurerStatus\":\"String\",\"reason\":\"String\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"}}";
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true}";
    public static final String UPDATE_CLAIM_STATUS = "To update claim status";
}