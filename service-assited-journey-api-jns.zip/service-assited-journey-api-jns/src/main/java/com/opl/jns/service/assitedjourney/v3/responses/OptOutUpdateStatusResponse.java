package com.opl.jns.service.assitedjourney.v3.responses;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message","success", "token", "timeStamp" })
public class OptOutUpdateStatusResponse extends CommonResponse {

	@NotNull
	private String token;

	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;
}
