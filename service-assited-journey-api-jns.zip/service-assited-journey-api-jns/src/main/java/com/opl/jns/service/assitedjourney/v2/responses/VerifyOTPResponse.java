package com.opl.jns.service.assitedjourney.v2.responses;

import java.util.List;

import com.opl.jns.service.assitedjourney.v2.model.*;
import com.opl.jns.service.assitedjourney.v2.responses.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class VerifyOTPResponse extends CommonResponse {

	private List<AccountHolderDetails> accountHolderDetails;
}
