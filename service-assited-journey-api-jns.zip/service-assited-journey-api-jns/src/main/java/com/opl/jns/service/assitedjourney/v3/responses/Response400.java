package com.opl.jns.service.assitedjourney.v3.responses;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class Response400 {

	public static final  String PLAIN_RESPONSE_400="{\"message\":\"It seems that request is not properly formed.\",\"data\":{},\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"status\":400,\"success\":false}";
	public static final  String WB_PLAIN_RESPONSE_400="{\"message\":\"It seems that request is not properly formed.\",\"data\":{},\"status\":400,\"success\":false}";
	
	@Schema(example = "It seems that request is not properly formed.")
	private String message;

	@Schema(example = "400")
	private Integer status;

	@Schema(example = "false")
	private Boolean success;
	
	@NotNull
	@Schema(example = "token")
	private String token;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;
	

}
