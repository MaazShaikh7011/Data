package com.opl.jns.service.assitedjourney.v3.model;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.service.assitedjourney.v3.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TriggerVerificationCodeRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
    private LocalDate dob;
	
	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
	
	@NotNull
	private String token;
}
