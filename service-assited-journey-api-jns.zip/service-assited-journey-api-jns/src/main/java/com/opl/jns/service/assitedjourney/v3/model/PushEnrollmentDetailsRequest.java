package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.service.assitedjourney.v3.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v3.enums.YesNo;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;
import com.opl.jns.utils.constant.CommonConstant;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


/**
 * @author - Maaz Shaikh
 * @Date - 21/11/2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PushEnrollmentDetailsRequest implements Serializable {

    private static final long serialVersionUID = 1L;
    
	@NotNull
	private String token;
	
	@NotNull
	@Size(min = 31, max = 32)
    private String urn;
	
    @NotNull
    @Schema(example = "2023")
    private String policyYear;
    
    @Size(min = 2, max = 17)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
    @Pattern(regexp = "556|132|115|190|146|142|101|143|111|136|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
    private String insurerCode;
    
    @NotNull
    @Size(min = 1, max = 35)
    private String transactionUTR;
    
    
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "transactionTimeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime transactionTimeStamp;
    
    @NotNull
    private Double transactionAmount;
    
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "firstEnrollmentDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime firstEnrollmentDate;
    
    @NotNull
    @Size(min = 2, max = 50)
    @Schema(allowableValues ={"Other Channel","Assisted"})
    private String source;
    
    @NotNull
	@Size(min = 2, max = 50)
	@Schema(allowableValues ={"DIY","Assisted"})
	private String mode;
    
    @NotNull
    @Size(min = 1, max = 50)
    @Schema(allowableValues ={"N=New Enrollment"})
    private String transactionType;
    
    @NotNull
    @Size(min = 1, max = 100)
    private String masterPolicyNumber;
    
	@NotNull
    @Schema(allowableValues ={"PMJJBY","PMSBY"})
    private String schemeName;
	
    @NotNull
    @Size(min = 2, max = 30)
    private String branchCode;
    
    @NotNull
	@Size(min = 2, max = 30)
	@Schema(allowableValues = CommonConstant.BANK_SHORT_CODE_NAME)
	@Pattern(regexp = CommonConstant.BANK_SHORT_CODE, flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
	public String bankCode;
    
    @NotNull
    @Schema(allowableValues ={"Yes"})
    private String consentForAutoDebit;
    
    @NotNull
    private String userId1;
    
    private String userId2;
	
    @NotNull	
	@Schema(allowableValues = { "BC", "ATM", "MB", "EB", "SMS", "WHATSAPP", "BRANCH","TAB", "CSP", "WEBSITE", "MISSCALL" ,"DBU","Branch Assisted","From Legacy","DIY Web","DIY Mobile"})
	@Size(min = 1, max = 50)	
	@Pattern(regexp = "BC|ATM|MB|EB|SMS|WHATSAPP|BRANCH|TAB|CSP|WEBSITE|MISSCALL|DBU|Branch Assisted|From Legacy|DIY Web|DIY Mobile", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Channel.")
    private String channelId;
    
    @NotNull
    @Size(min = 5, max = 50)
    @Schema(allowableValues ={"Rural","Urban"})
    private String ruralUrban;
    
	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;
	
    @NotNull
	@Size(min = 3, max = 17)
    private String cif;
    
    @NotNull
	@Size(min = 11, max = 11)
    @Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message="Enter valid IFSc")
	private String customerIFSC;
    
    @NotNull
	@Size(min = 1, max = 300)
    private String accountHolderName;
    
    @NotNull
    @Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
    private String gender;
    
    @NotNull
    @Size(min = 1, max = 150)
    private String fatherHusbandName;
    
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
    private LocalDate dob;
    
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String mobileNumber;// 2 time found
	
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@gmail.com")
	//@Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email not format")
    private String emailId;
	
	@NotNull
	@Size(min = 2, max = 500)
    private String addressLine1;

	@Size(min = 2, max = 500)
    private String addressLine2;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String city;
	
	@NotNull
	@Size(min = 2, max = 200)
	private String district;
	
	@NotNull
	@Size(min = 2, max = 200)
	private String state;
	
	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	private Integer pincode;
	
	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
    private String kycID1;
	
	@NotNull
	@Size(min = 1, max = 100)
    private String kycID1Number;
	
	@JsonProperty("pan")
	@Size(min = 2, max = 3)
	private YesNo pan;
	
	@Size(min = 10, max = 10)
	private String panNumber;
	
	@JsonProperty("aadhaar")
	@Size(min = 2, max = 3)
	private YesNo aadhaar;
	
	@Size(min = 12, max = 12)
	private String aadhaarNumber;
	
	@NotNull
	@JsonProperty("disabilityStatus")
	@Size(min = 1, max = 3)
    private YesNo disabilityStatus;
	
	@NotNull
	@Size(min = 2, max = 200)
    private String disabilityDetails;
	
	private String applicantOccupation;
	
	@NotNull
	@Size(min = 1, max = 300)
    private String nomineeName;
    
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
    private LocalDate nomineeDateOfBirth;
    
    @Size(min = 10, max = 10)    
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String nomineeMobileNumber;
    
	@NotNull
	@Size(min = 1, max = 50)
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    private String relationshipOfNominee;
    
    @Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    private String nomineeEmailId;
    
    @NotNull
    @Size(min = 2, max = 500)
    private String addressofNominee;  
	
    @NotNull
    @Size(min = 1, max = 300)
    private String nameofGuardian;

    @NotNull
    @Size(min = 2, max = 500)
    private String addressOfGuardian;
    

    @NotNull
	@Size(min = 1, max = 50)
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    private String relationShipOfGuardian;
    
    @Size(min = 10, max = 10)    
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String guardianMobileNumber;
    
    
    @Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    private String guardianEmailId;
   
    @NotNull
    private CoiDocumentDetailsProxy COI;
    
}
