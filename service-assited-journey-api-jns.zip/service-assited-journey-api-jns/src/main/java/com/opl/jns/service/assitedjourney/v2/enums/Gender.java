package com.opl.jns.service.assitedjourney.v2.enums;

public enum Gender {

	MALE, FEMALE, TRANSGENDER
}
