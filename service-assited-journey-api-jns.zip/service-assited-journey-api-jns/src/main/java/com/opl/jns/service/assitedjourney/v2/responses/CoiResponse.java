package com.opl.jns.service.assitedjourney.v2.responses;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Maaz Shaikh
 * Date : 06-07-2023
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoiResponse {
    private static final long serialVersionUID = 1L;

    @NotNull
    @Size(min = 0, max = 255)
    private String message;
    @NotNull
    @Schema(example = "2023-05-05 16:12:10")
    private String timestamp;
    @NotNull
    @Size(min = 0, max = 100)
    private String token;

    private Object coi;

    @NotNull
    private Integer status;

    @NotNull
    @Schema(allowableValues = {"True", "False"})
    private Boolean success;

    public CoiResponse(String message, Integer status) {
        super();
        this.message = message;
        this.status = status;
    }

    public CoiResponse(String message, Object data, Integer status) {
        super();
        this.message = message;
        this.coi = data;
        this.status = status;
    }

    public CoiResponse(String message, Object data, Integer status, Boolean success) {
        super();
        this.message = message;
        this.coi = data;
        this.status = status;
        this.success = success;
    }

    public CoiResponse(String message, Integer status, Boolean success) {
        super();
        this.message = message;
        this.status = status;
        this.success = success;
    }

}
