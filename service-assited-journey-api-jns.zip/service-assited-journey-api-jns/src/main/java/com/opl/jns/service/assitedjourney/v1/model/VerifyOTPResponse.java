package com.opl.jns.service.assitedjourney.v1.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class VerifyOTPResponse extends CommonResponse {

	private List<AccountHolderDetails> accountHolderDetails;
}
