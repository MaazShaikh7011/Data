package com.opl.jns.service.assitedjourney.v1.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.service.assitedjourney.v1.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v1.enums.KycId;
import com.opl.jns.service.assitedjourney.v1.enums.YesNo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountHolderDetailsResponse {

	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	@JsonProperty("cif")
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@JsonProperty("customerAccountNumber")
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String customerAccountNumber;

	@NotNull
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
	@JsonProperty("customerIFSC")
	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
	private String customerIFSC;

	@NotNull
	@Size(min = 1, max = 50)
	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@NotNull
	@Schema(example = "13/06/1993")
	@JsonProperty("dob")
	private String dob; 

	@NotNull
	@Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
	@JsonProperty("gender")
	private String gender;

	@NotNull
	@Size(min = 1, max = 50)
	@JsonProperty("firstName")
	private String firstName;

	@Size(min = 1, max = 50)
	@JsonProperty("middleName")
	private String middleName;

	@Size(min = 1, max = 50)
	@JsonProperty("lastName")
	private String lastName;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("emailAddress")
	private String emailAddress;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("addressline1")
	private String addressline1;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("addressline2")
	private String addressline2;
	
	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	@JsonProperty("pincode")
	private Long pincode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("city")
	private String city;

	@Size(min = 1, max = 8)
	@JsonProperty("cityLGDCode")
	private Long cityLGDCode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("district")
	private String district;

	@Size(min = 1, max = 8)
	@JsonProperty("districtLGDCode")
	private Long districtLGDCode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("state")
	private String state;

	@Size(min = 1, max = 8)
	@JsonProperty("stateLGDCode")
	private Long stateLGDCode;

	@NotNull
	@Size(min = 1, max = 25)
	@JsonProperty("kycID1")
	private KycId kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	@JsonProperty("kycID1number")
	private String kycID1number;

	@Size(min = 1, max = 25)
	@JsonProperty("kycID2")
	private KycId kycID2;

	@Size(min = 1, max = 100)
	@JsonProperty("kycID2number")
	private String kycID2number;

	@JsonProperty("pan")
	private YesNo pan;

	@Size(min = FieldsMaster.PAN_MIN, max = FieldsMaster.PAN_MAX)
	@Schema(example = FieldsMaster.PAN_SAMPLE)
	@JsonProperty("panNumber")
	private String panNumber;

	@JsonProperty("aadhaar")
	private YesNo aadhaar;

	@Size(min = 12, max = 12)
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;
	
	@NotNull
	@Size(min = 1, max = 50)
	@JsonProperty("nomineeFirstName")
	private String nomineeFirstName;

	@Size(min = 1, max = 50)
	@JsonProperty("nomineeMiddleName")
	private String nomineeMiddleName;

	@Size(min = 1, max = 50)
	@JsonProperty("nomineeLastName")
	private String nomineeLastName;

	@NotNull
	@Schema(example = "13/06/1993")
	@JsonProperty("nomineeDateOfBirth")
	private String nomineeDateOfBirth;

	
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("nomineeEmailAddress")
	private String nomineeEmailAddress;

	@NotNull
	@Size(min = 2,max = 200)
	@JsonProperty("nomineeAddressLine1")
	private String nomineeAddressLine1;

	@NotNull
	@Size(min = 2,max = 200)
	@JsonProperty("nomineeAddressLine2")
	private String nomineeAddressLine2;

	@NotNull
	@Schema(example = "380001")
	@Size(min = 6,max = 6)
	@JsonProperty("nomineePincode")
	private String nomineePincode;

	@NotNull
	@Size(min = 2,max = 200)
	@JsonProperty("nomineeCity")
	private String nomineeCity;

	@Size(min = 1, max = 8)
	@JsonProperty("nomineeCityLGDCode")
	private Integer nomineeCityLGDCode;

	@NotNull
	@Size(min = 2,max = 200)
	@JsonProperty("nomineeDistrict")
	private String nomineeDistrict;

	@Size(min = 1, max = 8)
	@JsonProperty("nomineeDistrictLGDCode")
	private Integer nomineeDistrictLGDCode;

	@NotNull
	@Size(min = 2,max = 200)
	@JsonProperty("nomineeState")
	private String nomineeState;

	@Size(min = 1, max = 8)
	@JsonProperty("nomineeStateLGDCode")
	private Integer nomineeStateLGDCode;

	@NotNull
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationOfNominee")
	private String relationOfNominee;

	@NotNull
	@Size(min = 1, max = 50)
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	@NotNull
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;
	
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;
	
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("guardianEmailId")
	private String guardianEmailId;
	

//	@JsonProperty("nomineepan")
//	private YesNo nomineepan;// : Yes
//
//	@Size(min = FieldsMaster.PAN_MIN, max = FieldsMaster.PAN_MAX)
//	@Schema(example = FieldsMaster.PAN_SAMPLE)
//	@JsonProperty("nomineepanNumber")
//	private String nomineepanNumber;
//
//	@JsonProperty("nomineeaadhaar")
//	private YesNo nomineeaadhaar;// : Yes
//
//	@Size(min = 10, max = 17)
//	@JsonProperty("nomineeaadhaarNumber")
//	private String nomineeaadhaarNumber;

//	@JsonProperty("consentForENACH")
//	private YesNo consentForENACH;// : Yes

	@NotNull
	@JsonProperty("consentForautodebit")
	@Schema(allowableValues ={"Yes"})
	private String consentForautodebit;// : Yes

	@NotNull
	@JsonProperty("ruralUrban")
	@Size(min = 1, max = 10)
	private String ruralUrban;// : Yes

//	@Schema(example = "13/06/2022")
//	@JsonProperty("dateOfAutoDebit")
//	private String dateOfAutoDebit;// : dd/mm/yyyy
}