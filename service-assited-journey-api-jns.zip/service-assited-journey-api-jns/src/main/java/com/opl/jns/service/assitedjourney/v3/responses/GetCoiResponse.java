package com.opl.jns.service.assitedjourney.v3.responses;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.service.assitedjourney.v3.model.CoiDocumentDetailsProxy;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;
import com.opl.jns.utils.common.PatternUtils;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({ "status", "message", "token", "timeStamp" })
public class GetCoiResponse extends CommonResponse {

	private final static long serialVersionUID = 1175522787349167243L;
	
	@NotNull
	@Size(min = 1, max = 300)
	private String accountHolderName;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
	private LocalDateTime dob;
	
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	private String mobileNumber;
	
	@Size(min = 2, max = 500)
	private String addressline1;

	@Size(min = 2, max = 500)
	private String addressline2;

	@NotNull
	@Size(min = 2, max = 200)
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	private String state;
	
	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	private Integer pincode;
	
	@NotNull
	@Size(min = 1, max = 25)
	@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
	private String kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	private String kycID1number;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "firstEnrollmentDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime firstEnrollmentDate;
	
    @NotNull
    @Size(min = 2, max = 300)
    @Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid nomineeName")
    private String nomineeName;
    
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
	public LocalDateTime nomineeDateOfBirth;
	
    @NotNull
    @Size(min = 1, max = 300)
    @Pattern(regexp = PatternUtils.ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1, message = "Enter valid guradianName	")
    public String nameofGuardian;
    
    @NotNull
    @Size(min = 1, max = 50)
    @Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
    public String relationshipOfGuardian;
    
	@NotNull
	private String token;

	@NotNull
	@Schema(example = "2000-08-08 15:24:58")
	private String timeStamp;
	
//	@NotNull
//	private CoiDocumentDetailsProxy coi;
}
