package com.opl.jns.service.assitedjourney.v2.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.opl.jns.service.assitedjourney.v2.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v2.enums.SchemeMaster;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PremiumDeductionRequest {

	@NotNull
	@Size(min = 3, max = 17)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String customerAccountNumber;

	

	@NotNull
	@Size(min = 1, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = "190")
	private String insurerCode;
	
	@NotNull
	@Size(min = 1, max = 50)
	@Schema(example = "25412")
	private String userId;
	
	@NotNull
	@Size(min = 1, max = 50)
	@Schema(example = "2541")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Enter valid Branch Code")
	private String branchCode;

	
//	@NotNull
//	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
//	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
//	private String insurerAccountNumber;
//
//	@NotNull
//	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
//	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
//	private String insurerIFSC;

	@NotNull
	private SchemeMaster scheme;

	@NotNull
	private Double premiumAmount;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
	
	@Size(min = 3, max = 25)
	@Schema(allowableValues = { "DIY", "Assisted" })
	private String mode;
}
