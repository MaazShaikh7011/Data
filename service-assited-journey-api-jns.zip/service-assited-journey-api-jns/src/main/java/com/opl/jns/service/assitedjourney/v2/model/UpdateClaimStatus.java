package com.opl.jns.service.assitedjourney.v2.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UpdateClaimStatus {

	@NotNull
	@Min(1)
	private Long claimReferenceId;

	@NotNull
	@NotEmpty
	@Size(min = 21,max = 32)
	private String urn;

	@NotNull
	@NotEmpty
	@Size(min = 1,max = 100)
	private String claimId;

	@NotNull
	@Min(8)
	@Max(11)
	@Schema(allowableValues ={"11","7","8","10"},description = "11 - In Process,7 - Query,8 - Claim Repudiated ,10 - Claim Approved")
	private int claimStatus;

	private String insurerStatus;
	
	private String reason;
	
	private UpdateTransactionRequest transactionDetails;
}
