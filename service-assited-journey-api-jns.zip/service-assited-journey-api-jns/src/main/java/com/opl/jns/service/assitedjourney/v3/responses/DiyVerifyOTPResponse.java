package com.opl.jns.service.assitedjourney.v3.responses;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.service.assitedjourney.v3.model.AccountHolderDetailsV3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"status", "message","success","accountHolderDetails","token","timeStamp" })
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DiyVerifyOTPResponse extends CommonResponse {
	
	private List<AccountHolderDetailsV3> accountHolderDetailsV3;
	
	@NotNull
	private String token;

	@NotNull
	@Schema(example = "2000-08-08 15:24:58")
	private String timeStamp;

}
