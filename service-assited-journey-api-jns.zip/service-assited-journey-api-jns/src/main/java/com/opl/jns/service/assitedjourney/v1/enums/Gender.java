package com.opl.jns.service.assitedjourney.v1.enums;

public enum Gender {

	MALE, FEMALE, TRANSGENDER
}
