package com.opl.jns.service.assitedjourney.v3.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.service.assitedjourney.v3.model.NomineeUpdateStatusRequest;
import com.opl.jns.service.assitedjourney.v3.responses.NomineeUpdateStatusResponse;
import com.opl.jns.service.assitedjourney.v3.responses.Response400;
import com.opl.jns.service.assitedjourney.v3.responses.Response401;
import com.opl.jns.service.assitedjourney.v3.utils.CommonUtils;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "4. DIY NomineeUpdate", description = "API to update Bank/Insurer for Nominee updation from JS portal ")
public class DiyNomineeUpdateController {

	@PostMapping(value = "/nomineeUpdateStatus")
//	@Tag(name = "9. OPT OUT STATUS API")
	@Operation(operationId = Constants.STR_16, summary = CommonUtils.NOMINEE_UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.NOMINEE_UPDATE_STATUS_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = NomineeUpdateStatusResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.NOMINEE_UPDATE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE_TIME),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
							) }) })
	public ResponseEntity<NomineeUpdateStatusResponse> optOutStatus(
			@RequestBody NomineeUpdateStatusRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

}
