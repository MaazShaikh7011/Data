package com.opl.jns.service.assitedjourney.v2.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;

public class Constants {

	
	public static final  String CUSTOMER_REQUEST_EXAMPLE="{\"accountNumber\":\"45455545\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String PHYSICAL_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"13/06/1993\",\"signVerifiedByBank\": \"YES\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String CUSTOMER_RESPONSE_SUCCESS="{\"status\":200,\"message\":\"string\",\"flag\":true,\"accountHolderDetails\":{\"cif\":\"stringstri\",\"customerIFSC\":\"XXXX000000\",\"accountHolderName\":\"string\",\"gender\":\"M\",\"firstName\":\"string\",\"middleName\":\"string\",\"lastName\":\"string\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"13/06/1993\",\"mobileNumber\":\"string\",\"emailAddress\":\"string\",\"addressline1\":\"string\",\"addressline2\":\"string\",\"city\":\"string\",\"cityLGDCode\":10,\"district\":\"string\",\"districtLGDCode\":10,\"state\":\"string\",\"stateLGDCode\":10,\"pincode\":382350,\"kycID1\":\"DRIVINGL\",\"kycID1number\":\"string\",\"kycID2\":\"PAN\",\"kycID2number\":\"string\",\"pan\":\"YES\",\"panNumber\":\"XXXXX0000X\",\"aadhaar\":\"YES\",\"aadhaarNumber\":\"stringstri\",\"ckyc\":\"YES\",\"ckycNumber\":\"stringstri\",\"nomineeFirstName\":\"string\",\"nomineeMiddleName\":\"string\",\"nomineeLastName\":\"string\",\"nomineeDateOfBirth\":\"13/06/1993\",\"nomineeMobileNumber\":\"9899999999\",\"relationOfNominee\":\"string\",\"nomineeEmailAddress\":\"xyz@abc.com\",\"nomineeAddressLine1\":\"string\",\"nomineeAddressLine2\":\"string\",\"nomineeCity\":\"string\",\"nomineeCityLGDCode\":10,\"nomineeDistrict\":\"string\",\"nomineeDistrictLGDCode\":10,\"nomineeState\":\"9899999999\",\"nomineeStateLGDCode\":10,\"nomineePincode\":\"380001\",\"nameofGuardian\":\"string\",\"addressofGuardian\":\"string\",\"relationshipofGuardian\":\"string\",\"guardianMobileNumber\":\"7544454578\",\"guardianEmailId\":\"abc@gmail.com\",\"consentForautodebit\":\"YES\",\"ruralUrban\":\"string\"}}";
	public static final  String PHYSICAL_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": \"true\",\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"13/06/1993\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}]}";
	public static final  String PREMIUM_REQUEST_EXAMPLE="{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"mode\": \"Assisted\"}";
	public static final  String PREMIUM_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"13/06/2023 05:06:00\",\"transactionAmount\": \"string\",\"comment\": \"string\"}";
	public static final  String TRIGGER_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"13/06/1993\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String TRIGGER_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"mobileNumber\": \"7565544547\"}";
	public static final  String VERIFY_REQUEST_EXAMPLE="{\"accountNumber\": \"11111111111\",\"dob\": \"13/06/1993\",\"verifyVerificationcode\": \"454315\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final  String VERIFY_RESPONSE_SUCCESS="{\"status\": 200,\"message\": \"string\",\"flag\": true,\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"13/06/1993\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}]}";
	
	
	
	public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
	
	
	public static final  String PLAIN_RESPONSE_400="{\"message\": \"It seems that request is not properly formed.\",\"status\": 400,\"success\": false,\"flag\": false}";
	public static final  String PLAIN_RESPONSE_401="{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false,\"flag\":false}";
    public static final String[] EMPTY_STRING_ARRAY = new String[0];
    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
    public static final String COMMON_DOCUMENT_MESSAGE = "Get Upload Documents Response";
    
    public static final String PLAIN_REQUEST_LBL = "Plain Request";
    public static final String PLAIN_RESPONSE_LBL = "Plain Response";
    public static final String PLAIN_REQUEST_LBL_DATE = "<u>Date Format should be <b>dd/MM/yyyy</b><u>";
    public static final String PLAIN_REQUEST_LBL_DATE_FORMAT = "<u>Date Format should be <b>dd/MM/yyyy</b><u><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
    public static final String PLAIN_REQUEST_LBL_DATE_TIME = "<u>Date Format should be <b>dd/MM/yyyy HH:mm:ss<b><u><br>";
    public static final String REQUEST_EXAMPLES_DESC = "Request examples";
    public static final String DATE_FORMAT_DESCRIPTION="<u>Date Format should be <b>dd/MM/yyyy</b>";
    public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";
    
    public static final  String ENCRYPTED_REQUEST_EXAMPLE ="{\n \"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
    public static final String ENCRYPTED_RESPONSE ="{\n\"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";

    public static final String STATUS_UPDATE = "Status updated successfully.";

    public static final String STATUS_UPDATE_PROPERLY = "Please request status update for Hold/Reject only.";

    public static final String[] IGNORE_AUDOTIR_FIELDS = { "id", "createdDate", "isActive", "modifiedDate" ,"claimMaster"};
    public static final String[] IGNORE_AUDITOR_FIELDS_INCLUDES_NOMINEE = { "id", "createdDate", "isActive", "modifiedDate","nomineeFirstName","nomineeMiddleName","nomineeLastName","claimMaster" ,"applicationMaster"};
//    public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
    public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
    public static final DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

    public static final String COMMON_DATA_MESSAGE = "In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :\n" +
            "1. 200 - Success\n" +
            "2. 500 - Internal Server Error\n" +
            "3. 400 - Parameter Missing in Request (Bad Request)\n" +
            "4. 400 - Invalid Application Reference Id  (Bad Request)";
    public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
    public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

    public static final String STATUS = "status";
    
    public static final String SUCCESS = "Success";

    public static final String FAILED = "Failed";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final long LONG_0 = 0L;
    public static final long LONG_1 = 1L;
    public static final long LONG_2 = 2L;
    public static final long LONG_3 = 3L;
    public static final long LONG_4 = 4L;
    public static final long LONG_5 = 5L;
    public static final long LONG_6 = 6L;
    public static final long DROP_DOWN_ID_RELATIONSHIP = LONG_1;
    public static final long KYC_DROP_DOWN_ID = LONG_2;
    public static final long CAUSE_OF_DESABILITY_DROP_DOWN_ID_PMJJBY = LONG_4;
    public static final long CAUSE_OF_DESABILITY_DROP_DOWN_ID_PMSBY = LONG_6;
    public static final long TYPE_OF_DISABILITY_DROP_DOWN_ID = LONG_5;
    public static final int INT_0 = 0;
    public static final int INT_1 = 1;
    public static final int INT_6 = 6;
    public static final int INT_14 = 14;
    public static final int INT_2 = 2;
    public static final int INT_3 = 3;
    public static final int INT_4 = 4;

    public static final int ENROLLMENT_STAGE_ID = INT_6;
    public static final int CLAIM_STAGE_ID = INT_14;
    public static final long NATURE_OF_LOSS = LONG_3;
    public static final String EXIT_FROM_UPDATE_CLAIM_STATUS = "... .Exit from updateClaimStatus(). ...";
//    public static final int INSURANCE_STATUS_ACCEPT = 10;
//    public static final int INSURANCE_STATUS_REJECTED = 8;
    public static final int ENROLLMENT_TYPE_ID_1 = INT_1;
    public static final String APPLICATION_NOT_FOUND = "Application not found";
    public static final String APPLICATION_NOT_PUSHED = "Application not pushed";
    public static final String APPLICANT = "Applicant";

    public static class MSG {
        public static final String SUCCESS = "Success";
        public static final String FAILED = "Failed";
        public static final String USER_NOT_FOUND = "User Not Found";
        public static final String SMTG_WNT_WNG = "Something Went Wrong.";
        public static final String TOKEN_SAVED_SUCCESS = "Token Saved Successfully";
        public static final String TOKEN_SAVED_FAILED = "Failed to save token";
    }

//    public static class DocumentAlias {
//    	DocumentAlias(){
//    	}
//
//        public static final Map<Long, String> SRMS_DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
//
//        public static final Map<Long, String> DOCUMENT_MAP_ID_DESC_MAP = new HashMap<>();
//        public static final Long SIGNED_CLAIM_FORM = 4l;
//        public static final Long FIR_PUNCHNAMA = 5l;
//        public static final Long POST_MORTEM_REPORT = 6l;
//        public static final Long OTHER = 7l;
//
//        public static final String OTHERS_NAME = "Others";
//        public static final String QUATATION_OF_EQUIPMENT_NAME = "Quotation of Equipment";
//        public static final String PROJECT_REPORT_NAME = "Project Report";
//        public static final String WORK_ASSURANCE_LETTER_NAME = "Work Assurance Letter";
//        public static final String BANK_STATEMENT_NAME = "Bank Statement";
//
//
//        public static final String SIGNED_CLAIM_FORM_NAME = "Signed Claim Form";
//        public static final String FIR_PUNCHNAMA_NAME = "FIR / Panchnama";
//        public static final String POST_MORTEM_REPORT_NAME = "Post Mortem Report";
//        public static final String OTHER_NAME = "Other";
//        public static final String PDF ="pdf";
//        public static final String WORD ="word";
//        public static final String EXCEL ="excel";
//        public static final String TEXT ="text";
//        public static final String XML ="xml";
//
//
//        static {
//
//            DOCUMENT_MAP_ID_DESC_MAP.put(SIGNED_CLAIM_FORM, SIGNED_CLAIM_FORM_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(FIR_PUNCHNAMA, FIR_PUNCHNAMA_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(POST_MORTEM_REPORT, POST_MORTEM_REPORT_NAME);
//            DOCUMENT_MAP_ID_DESC_MAP.put(OTHER, OTHER_NAME);
//        }
//    }

//    public static class CostOfCourse {
//    	CostOfCourse(){
//    	}
//        public static final String TUITION_FEE = "Tuition Fee";
//        public static final String EXAM_FEE = "Exam Fee";
//        public static final String EQUIPMENT = "Equipment";
//        public static final String HOSTEL_EXPENSES = "Hostel Expenses";
//        public static final String OTHER_EXPENSES = "Other Expenses";
//    }

    public static class ErrorMsg {
    	ErrorMsg(){
    	}

        public static final String FAILED = "failed";
        public static final String SMTG_WNT_WRG = "Something went wrong";

    }

//    public static class Type {
//    	Type(){
//    	}
//        public static final String APPLICANT = "Applicant";
//        public static final String CO_APPLICANT = "Co-Applicant";
//        public static final String PARTNER = "Partner";
//        public static final String INDIVIDUAL = "Individual";
//        public static final String BUSINESS_ENTITY = "Business Entity";
//    }

    public enum ClaimStatus {

        RECEIVED_FROM_BANK(6, "Received from bank"),
        CLAIM_REPUDIATED(8, "Claim repudiated"),
        CLAIM_APPROVED(10, "Claim approved"),
        QUERY(7, "Query"),
        IN_PROCESS(11, "In process");
        private Integer id;
        private String description;

        ClaimStatus(Integer status, String description) {
            this.id = status;
            this.description = description;
        }

        public static ClaimStatus getById(Integer id) {
           return Arrays.stream(values()).filter(x -> x.getId().equals(id)).findFirst().orElse(null);
        }


        public Integer getId() {
            return this.id;
        }

        public String getDescription() {
            return this.description;
        }
    }
    public enum APIStatus {

        PENDING(1, "Pending"),
        IN_PROGRESS(2, "In progress"),
        FAILED(3, Constants.FAILED),
        READY(4, "Ready");
        private Integer id;
        private String description;

        APIStatus(Integer status, String description) {
            this.id = status;
            this.description = description;
        }

        public Integer getId() {
            return this.id;
        }

        public String getDescription() {
            return this.description;
        }
    }

//    public enum ScalingTypes {
//
//        RISK(1, "Risk Score"),
//        CIBIL(2, "Cibil Score"),
//        GROSS_MONTH_INCOME(3, "Gross Monthly Income"),
//        NET_MONTH_INCOME(4, "Net Monthly Income"),
//        LOAN_AMOUNT(5, "Loan Amount"),
//        BUREAU(7,"Bureau"),
//        TYPE_OF_BORROWER(8,"Type of borrower");
//
//        Integer id;
//        String value;
//
//        ScalingTypes(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static ScalingTypes getById(Integer id) {
//        	for(ScalingTypes scalingTypes : values()) {
//	   			 if(scalingTypes.getId().equals(id)){
//	   				 return scalingTypes;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }

//    public enum BaseRateTypes {
//
//        REPO_RATE(1, "Repo Rate"),
//        MCLR(2, "MCLR"),
//        BASE_RATE(3, "Base Rate");
//
//        Integer id;
//        String value;
//
//        BaseRateTypes(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static BaseRateTypes getById(Integer id) {
//        	for(BaseRateTypes baseRateTypes : values()) {
//	   			 if(baseRateTypes.getId().equals(id)){
//	   				 return baseRateTypes;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }

//    public enum ProposalStatus{
//
//        COMPLETED(1, "Completed"),
//        SANCTIONED(2, "Sanctioned"),
//        DISBURSED(3, "Disbursed"),
//        REJECT(4, "Reject"),
//        HOLD(5, "Hold"),
//        HOLD_AFTER_SANCTION(6, "Hold After Sanction"),
//        REJECT_AFTER_SANCTION(7, "Reject After Sanction"),
//        PARTIAL_DISBURSE(8, "Partial Disburse");
//
//        Integer id;
//        String value;
//
//        ProposalStatus(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public static ProposalStatus getById(Integer id) {
//        	for(ProposalStatus proposalStatus : values()) {
//	   			 if(proposalStatus.getId().equals(id)){
//	   				 return proposalStatus;
//	   			 }
//		 	}
//        	return null;
//        }
//
//        public Integer getId() {
//            return this.id;
//        }
//
//        public String getValue() {
//            return this.value;
//        }
//    }
    
//    public enum SubsidyStatus{
//    	PEDNING(1, "Pending"),
//        SEND_TO_NODEL_AGENCY(2, "Send to Nodel Agency"),
//        APPROVED(3, "Approved"),
//        HOLD(4, "Hold"),
//        REJECT(5, "Reject");
//
//        Integer id;
//        String stage;
//
//        SubsidyStatus(Integer id, String stage) {
//            this.id = id;
//            this.stage = stage;
//        }
//
//        public Integer getId(){
//            return this.id;
//        }
//
//        public String getStage(){
//            return this.stage;
//        }
//
//        public static SubsidyStatus getById(Integer id){
//        	for(SubsidyStatus subsidyStatus : values()) {
//   	   			 if(subsidyStatus.getId().equals(id)){
//   	   				 return subsidyStatus;
//   	   			 }
//   		 	}
//           	return null;
//        }
//    }
    
//    public enum ApplicationMaster{
//    	APPROVED(1,"Approved"),
//    	REFERRED(2,"Referred");
//
//    	Integer id;
//        String value;
//
//        ApplicationMaster(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public Integer getId(){
//            return this.id;
//        }
//
//        public String getValue(){
//            return this.value;
//        }
//
//        public static ApplicationMaster getById(Integer id) {
//            try {
//            	for(ApplicationMaster applicationMaster : values()) {
//      	   			 if(applicationMaster.getId().equals(id)){
//      	   				 return applicationMaster;
//      	   			 }
//      		 	}
//              	return null;
//            } catch (Exception e) {
//                return null;
//            }
//        }
//    }
//
//    public enum NoGSTReason {
//        EXISTING_BUSINESS(1, "GST is not applicable to my Product/Service."),
//        PERSONAL_LOAN(2, "GST is not applicable in my state."),
//        HOME_LOAN(3, "I/we am/are not required to fill GST return as my/our sales are below limit required to get GST registration."),
//        EDUCATION_LOAN(4, "Other reason");
//
//        private Integer id;
//        private String value;
//
//        private NoGSTReason(Integer id, String value) {
//            this.id = id;
//            this.value = value;
//        }
//
//        public Integer getId() {
//            return id;
//        }
//
//        public String getValue() {
//            return value;
//        }
//
//        public static NoGSTReason fromId(Integer v) {
//            for (NoGSTReason c : NoGSTReason.values()) {
//                if (c.id.equals(v)) {
//                    return c;
//                }
//            }
//            throw new IllegalArgumentException(v != null ? v.toString() : null);
//        }
//    }
//
    //For Insurance
    public static final String COMMON_BASIC_INSURANCE_APPLICANT_MESSAGE = "Get the details of the list of insurance policies issued by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APPLICANT_DETAIL_MESSAGE = "Get all the detailed data of the insurance policies issued by the banks through the portal.";
    public static final String UPDATE_INSURANCE_STATUS_MESSAGE = "Update Applicantion Status by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_MESSAGE = "Get the details of the list of claims registered by the banks through the portal.";
    public static final String COMMON_BASIC_INSURANCE_APP_CLAIM_DETAIL_MESSAGE = "Get all the detailed data of the claims taken by the banks through the portal.";
    public static final String UPDATE_INSURANCE_CLAIM_STATUS_MESSAGE = "Update Claim Status by the banks through the portal.";

    public static final String STR_1 = "1";
    public static final String STR_2 = "2";
    public static final String STR_3 = "3";
    public static final String STR_4 = "4";
    public static final String STR_5 = "5";
    public static final String STR_6 = "6";

    public static final String STRING_400 = "400";
    public static final String STRING_200 = "200";
    public static final String STRING_401 = "401";

    /** update claim status*/
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE="{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":1,\"claimId\":\"456789\",\"insurerStatus\":\"String\",\"reason\":\"String\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"}}";
    public static final  String UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS="{\"message\":\"succss\",\"status\":200,\"success\":true}";
    public static final String UPDATE_CLAIM_STATUS = "To update claim status";
}