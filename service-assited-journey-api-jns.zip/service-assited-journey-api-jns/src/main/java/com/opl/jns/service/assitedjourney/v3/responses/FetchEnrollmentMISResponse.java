package com.opl.jns.service.assitedjourney.v3.responses;

import javax.validation.constraints.NotNull;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "token", "timeStamp" })
public class FetchEnrollmentMISResponse extends CommonResponse {

	@NotNull
	private String token;

	@NotNull
	@Schema(example = "2000-08-08 15:24:58")
	private String timeStamp;
}
