package com.opl.jns.service.assitedjourney.v2.controller;

import javax.servlet.http.HttpServletRequest;

import com.opl.jns.service.assitedjourney.v2.responses.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.published.lib.utils.AuthCredentialUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.service.assitedjourney.v2.model.CustomerDetailsRequest;
import com.opl.jns.service.assitedjourney.v2.model.PhysicalVerificationRequest;
import com.opl.jns.service.assitedjourney.v2.model.PremiumDeductionRequest;
import com.opl.jns.service.assitedjourney.v2.model.TriggerOTPRequest;
import com.opl.jns.service.assitedjourney.v2.model.UpdateClaimStatus;
import com.opl.jns.service.assitedjourney.v2.model.VerifyOTPRequest;
import com.opl.jns.service.assitedjourney.v2.utils.CommonUtils;
import com.opl.jns.service.assitedjourney.v2.utils.Constants;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v2")
@Slf4j
@Tag(name = "1. Bank Published API", description = "List of API for Assited Journey in Jansuraksha Platform")
public class APIControllerV2 {

	@PostMapping(value = "/triggerOTP")
//	@Tag(name = "1. TRIGGER OTP API")
	@Operation(
			operationId = Constants.STR_1,
			summary = CommonUtils.TRIGGER_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.TRIGGER_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })),
			responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.TRIGGER_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = TriggerOTPResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.TRIGGER_RESPONSE_SUCCESS),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//					content = { @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class)
//							, examples = {
//									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) })
					  ) })

			})
	public ResponseEntity<TriggerOTPResponse> triggerOTP(@RequestBody TriggerOTPRequest applicationRequest,
			HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/verifyOTP")
//	@Tag(name = "2. VERIFY OTP API")
	@Operation(
			operationId = Constants.STR_2,
			summary = CommonUtils.VERIFY_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.VERIFY_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.VERIFY_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = VerifyOTPResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.VERIFY_RESPONSE_SUCCESS,description = Constants.PLAIN_REQUEST_LBL_DATE),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, 
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//							, examples = {
//									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }
							) }) })
	public ResponseEntity<VerifyOTPResponse> verifyOTP(@RequestBody VerifyOTPRequest applicationRequest,
			HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/physicalVerification")
//	@Tag(name = "3. PHYSICAL SIGNATURE VERIFICATION API")
	@Operation(
			operationId = Constants.STR_3,
			summary = CommonUtils.PHYSICAL_VERIFICATION, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PHYSICAL_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.PHYSICAL_VERIFICATION_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PhysicalVerificationResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PHYSICAL_RESPONSE_SUCCESS,description = Constants.PLAIN_REQUEST_LBL_DATE),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//							, examples = {
//									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }
							) }) })
	public ResponseEntity<PhysicalVerificationResponse> physicalVerification(
			@RequestBody PhysicalVerificationRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/getCustomerDetails")
//	@Tag(name = "4. CUSTOMER RECORD API")
	@Operation(
			operationId = Constants.STR_4,
			summary = CommonUtils.GET_CUSTOMER_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CUSTOMER_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.CUSTOMER_RECORD_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CustomerDetailsResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CUSTOMER_RESPONSE_SUCCESS,description = Constants.PLAIN_REQUEST_LBL_DATE_FORMAT),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
//					content = {
//							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class)
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//							, examples = {
//									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }
							) }) })
	public ResponseEntity<CustomerDetailsResponse> getCustomerDetails(
			@RequestBody CustomerDetailsRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/premiumDeduction")
//	@Tag(name = "5. PREMIUM DEDUCTION API")
	@Operation(
			operationId = Constants.STR_5,
			summary = CommonUtils.PREMIUM_DEDUCT, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PREMIUM_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = CommonUtils.COMMON_DATA_MESSAGE
							+ CommonUtils.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PremiumDeductionResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PREMIUM_RESPONSE_SUCCESS,description = Constants.PLAIN_REQUEST_LBL_DATE_TIME),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//							, examples = {
//									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }
							) }) })
	public ResponseEntity<PremiumDeductionResponse> premiumDeduction(
			@RequestBody PremiumDeductionRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

//
//	@PostMapping(value = "/updateClaimStatus")
//	@Operation(
//			operationId = Constants.STR_6,
//			summary = Constants.UPDATE_CLAIM_STATUS,
//			requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC,
//					content = @Content(examples = {
//							@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
//							@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
//					})),
//			responses = {
//					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE,
//							content = {
//									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateStatusResponse.class),
//											examples = {
//													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_CLAIM_STATUS_PLAIN_RESPONSE_SUCCESS),
//													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//											})
//							}
//
//					),
//					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
//							content = {
//									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
//											examples = {
//													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
//													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//											}
//									)
//							}),
//					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
//							content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class),
//									examples = {
//											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//									}
//							)}
//					)
//			}
//	)
//	public ResponseEntity<CoiResponse> bankClaimWebHook(@RequestBody UpdateClaimStatus updateClaimStatus, HttpServletRequest httpServletRequest) {
//		if (OPLUtils.isObjectNullOrEmpty(updateClaimStatus)) {
//			return new ResponseEntity<>(new CoiResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//		}
//		try {
//			Object orgId = httpServletRequest.getAttribute(AuthCredentialUtils.ORG_ID);
//			if (OPLUtils.isObjectNullOrEmpty(orgId)) {
//				return new ResponseEntity<>(new CoiResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
//			Long userOrgId = Long.valueOf(String.valueOf(orgId));
//			log.info("userOrgId ==> {}", userOrgId);
//			return new ResponseEntity<>(null, HttpStatus.OK);
//		} catch (Exception e) {
//			e.printStackTrace();
//			log.error("Error in getApplicationList() {}", e.getMessage());
//			return new ResponseEntity<>(new CoiResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//		}
//
//	}

}
