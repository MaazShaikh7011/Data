package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.opl.jns.service.assitedjourney.v3.model.UpdateTransactionRequest;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class PushClaimStatustoBankReq implements Serializable {
	

	@NotNull
	@Min(1)
	private Long claimReferenceId;

	@NotNull
	@NotEmpty
	@Size(min = 21,max = 32)
	private String urn;

	@NotNull
	@Size(min = 1,max = 50)
	@Schema(allowableValues ={"11","7","8","10"},description = "11 - In process,7 - Queried ,8 - Rejected,10 - Approved")
	private int claimStatus;
	
	private String insurerStatus;
	
	@NotNull	
	@Schema(allowableValues  ={ "1", "2", "3",	"4", "5", "6", "7", "8"}, description ="Review Example Description reason >>> Enum")
	private Integer reason;
	
	@NotNull
	@NotEmpty
	@Size(min = 1,max = 100)
	private String claimId;

	private UpdateTransactionRequest transactionDetails;
	
	@NotNull
	private String token;
}
