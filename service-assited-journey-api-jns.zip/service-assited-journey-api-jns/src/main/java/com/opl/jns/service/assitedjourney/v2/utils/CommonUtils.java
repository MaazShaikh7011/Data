package com.opl.jns.service.assitedjourney.v2.utils;

public class CommonUtils {

	public static final String TRIGGER_OTP = "Send OTP to the mobile number registered with requested Accoung number";
	public static final String VERIFY_OTP = "Verify OTP";
	public static final String GET_CUSTOMER_DETAILS = "Get Customer Details By Account Number and CIF";
	public static final String PREMIUM_DEDUCT = "API to trigger premium from ETB customer’s account and creditng the same to the insurer’s account";
	public static final String PHYSICAL_VERIFICATION = "API to fetch the data of the ETB customer based on the account number of the customer provided as an input by the banker after receiving the physical filled and signed form";

	public static final String COMMON_DATA_MESSAGE = "In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :\n"
			+ "1. 200 (flag: true) - Success\n" + "2. 500 (flag: false) - Internal Server Error\n"
			+ "3. 400 (flag: false) - Parameter Missing in Request (Bad Request)\n"
			+ "4. 400 (flag: false) - Request Header is Null or Invalid  (Bad Request)";

	public static final String TRIGGER_OTP_DATA_MESSAGE = "\n\n" + "Trigger OTP error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" + "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Mobile number is not linked with requested account number\n"
			+ "4. 500 (flag: false) - Internal server error while sending OTP\n";
	
	public static final String VERIFY_OTP_DATA_MESSAGE = "\n\n" + "Verify OTP error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Invalid OTP \n"
			+ "4. 500 (flag: false) - Internal server error while verifying OTP\n";
	
	public static final String PHYSICAL_VERIFICATION_DATA_MESSAGE = "\n\n" + "Physical Signature Verification error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - No account holder details found \n";
	
	public static final String CUSTOMER_RECORD_DATA_MESSAGE = "\n\n" + "Customer Record error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - CIF null or invalid found \n"
			+ "5. 400 (flag: false) - No data found from account number and CIF \n";
	
	public static final String PAYMENT_DATA_MESSAGE = "\n\n" + "Premium Deduction error code:\n\n"
			+ "1. 400 (flag: false) - Account Number Invalid\n" 
			+ "2. 400 (flag: false) - Account Inactivated\n"
			+ "3. 400 (flag: false) - Insurer Account Number Invalid\n" 
			+ "4. 400 (flag: false) - Insurer Account Inactivated\n"
			+ "5. 500 (flag: false) - Insernal server error while payment deduction \n";

	public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
	public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

}
