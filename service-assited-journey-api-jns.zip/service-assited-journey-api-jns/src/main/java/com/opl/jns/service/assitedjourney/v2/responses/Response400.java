package com.opl.jns.service.assitedjourney.v2.responses;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class Response400 {

	@Schema(example = "It seems that request is not properly formed.")
	private String message;

	@Schema(example = "400")
	private Integer status;

	@Schema(example = "false")
	private Boolean success;
	
	@Schema(example = "false")
	private Boolean flag;

}
