package com.opl.jns.service.assitedjourney.v3.model;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.service.assitedjourney.v2.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v2.enums.KycId;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountHolderDetailsResponse {	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	@JsonProperty("cif")
	private String cif;

//	@NotNull
//	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
//	@JsonProperty("customerAccountNumber")
//	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
//	private String customerAccountNumber;

	@NotNull
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
	@JsonProperty("customerIFSC")
	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
	private String customerIFSC;

	@NotNull
	@Size(min = 1, max = 300)
	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@NotNull
	@JsonProperty("dob")
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
	private LocalDate dob; 

	@NotNull
	@Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
	@JsonProperty("gender")
	private String gender;
	
	@NotNull
	@Size(min = 1, max = 150)
	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;

	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("emailId")
	private String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	@JsonProperty("addressline1")
	private String addressline1;

	
	@Size(min = 2, max = 500)
	@JsonProperty("addressline2")
	private String addressline2;
	
	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	@JsonProperty("pincode")
	private Long pincode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("city")
	private String city;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("district")
	private String district;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("state")
	private String state;

	@NotNull
	@Size(min = 1, max = 25)
	@JsonProperty("kycID1")
	private KycId kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	@JsonProperty("kycID1number")
	private String kycID1number;

	@JsonProperty("pan")
	private YesNo pan;

	@Size(min = FieldsMaster.PAN_MIN, max = FieldsMaster.PAN_MAX)
	@Schema(example = FieldsMaster.PAN_SAMPLE)
	@JsonProperty("panNumber")
	private String panNumber;

	@JsonProperty("aadhaar")
	private YesNo aadhaar;

	@Size(min = 12, max = 12)
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;

	@JsonProperty("applicantOccupation")
	private String applicantOccupation;
	
	@Size(min = 1, max = 300)
	@JsonProperty("nomineeName")
	private String nomineeName;
	
	@JsonProperty("nomineeDateOfBirth")
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
	private LocalDate nomineeDateOfBirth;

	
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;
	
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipOfNominee")
	private String relationshipOfNominee;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("nomineeEmailId")
	private String nomineeEmailId;

	
	@Size(min = 2,max = 500)
	@JsonProperty("addressofNominee")
	private String addressofNominee;
	
	@Size(min = 1, max = 300)
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	
	@Size(min = 2, max = 500)
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	
	@Schema(allowableValues ={"Husband","Wife","Father","Mother","Son","Daughter","Brother","Sister","Grand father","Grand mother","Grand son","Grand daughter","Mother in law","Father in law","Brother in law","Sister in law","Nephew","Niece","Uncle","Aunt","Others"})
	@JsonProperty("relationshipOfGuardian")
	private String relationshipOfGuardian;
	
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	@Size(min = 10,max = 10)
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;
	
	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("guardianEmailId")
	private String guardianEmailId;
	
	@Size(min = 1, max = 50)
	@JsonProperty("bcReferralId")
	private String bcReferralId;
	
//	@JsonProperty("nomineepan")
//	private YesNo nomineepan;// : Yes
//
//	@Size(min = FieldsMaster.PAN_MIN, max = FieldsMaster.PAN_MAX)
//	@Schema(example = FieldsMaster.PAN_SAMPLE)
//	@JsonProperty("nomineepanNumber")
//	private String nomineepanNumber;
//
//	@JsonProperty("nomineeaadhaar")
//	private YesNo nomineeaadhaar;// : Yes
//
//	@Size(min = 10, max = 17)
//	@JsonProperty("nomineeaadhaarNumber")
//	private String nomineeaadhaarNumber;

//	@JsonProperty("consentForENACH")
//	private YesNo consentForENACH;// : Yes

	@NotNull
	@JsonProperty("consentForautodebit")
	@Schema(allowableValues ={"Yes"})
	private String consentForautodebit;// : Yes

//	@Schema(example = "13/06/2022")
//	@JsonProperty("dateOfAutoDebit")
//	private String dateOfAutoDebit;// : dd/mm/yyyy
}