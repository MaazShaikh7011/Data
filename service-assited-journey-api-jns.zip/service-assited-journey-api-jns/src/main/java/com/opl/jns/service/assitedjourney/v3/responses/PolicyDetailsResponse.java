package com.opl.jns.service.assitedjourney.v3.responses;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.service.assitedjourney.v3.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v3.enums.KycId;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PolicyDetailsResponse extends CommonResponse{

//	@NotNull
//	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
//	@JsonProperty("cif")
//	private String cif;

	@NotNull
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
	@JsonProperty("customerIFSC")
	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
	private String customerIFSC;

	@NotNull
	@Size(min = FieldsMaster.ACC_HOLERNAME_MIN, max = FieldsMaster.ACC_HOLERNAME_MAX)
	@JsonProperty("accountHolderName")
	private String accountHolderName;

	@NotNull
	@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
	@JsonProperty("gender")
	private String gender;

	@NotNull
	@Size(min = 1, max = 150)
	@JsonProperty("fatherHusbandName")
	private String fatherHusbandName;

	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
	private LocalDate dob;

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("emailId")
	private String emailId;

	@NotNull
	@Size(min = 2, max = 500)
	@JsonProperty("addressline1")
	private String addressline1;

	@Size(min = 2, max = 500)
	@JsonProperty("addressline2")
	private String addressline2;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("city")
	private String city;

//	@Size(min = 1, max = 8)
//	@JsonProperty("cityLGDCode")
//	private Long cityLGDCode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("district")
	private String district;

//	@Size(min = 1, max = 8)
//	@JsonProperty("districtLGDCode")
//	private Long districtLGDCode;

	@NotNull
	@Size(min = 2, max = 200)
	@JsonProperty("state")
	private String state;

//	@Size(min = 1, max = 8)
//	@JsonProperty("stateLGDCode")
//	private Long stateLGDCode;

	@NotNull
	@Schema(example = "382350")
	@Size(min = 6, max = 6)
	@JsonProperty("pincode")
	private Long pincode;

	@NotNull
	@Size(min = 1, max = 25)
	@JsonProperty("kycID1")
	private KycId kycID1;

	@NotNull
	@Size(min = 1, max = 100)
	@JsonProperty("kycID1number")
	private String kycID1number;
	
	@JsonProperty("pan")
	@Size(min = 2, max = 3)
	private YesNo pan;

	@Size(min = 10, max = 10)
	private String panNumber;

	@JsonProperty("aadhaar")
	@Size(min = 2, max = 3)
	private YesNo aadhaar;

	@Size(min = 12, max = 12)
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;

	@JsonProperty("ckyc")
	@Size(min = 2, max = 3)
	private YesNo ckyc;

	@Size(min = 14, max = 15)
	@JsonProperty("ckycNumber")
	private String ckycNumber;
	
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "firstEnrollmentDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime firstEnrollmentDate;

//	@Size(min = 1, max = 25)
//	@JsonProperty("kycID2")
//	private KycId kycID2;
//
//	@Size(min = 1, max = 100)
//	@JsonProperty("kycID2number")
//	private String kycID2number;

	@Size(min = 1, max = 300)
	@JsonProperty("nomineeName")
	private String nomineeName;

	@JsonProperty("nomineeDateOfBirth")
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
	private LocalDate nomineeDateOfBirth;

	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@Size(min = 10, max = 10)
	@JsonProperty("nomineeMobileNumber")
	private String nomineeMobileNumber;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@Size(min = 1, max = 50)
	@JsonProperty("relationshipOfNominee")
	private String relationshipOfNominee;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("nomineeEmailId")
	private String nomineeEmailId;

	@Size(min = 2, max = 500)
	@JsonProperty("addressofNominee")
	private String addressofNominee;

	@Size(min = 1, max = 300)
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;

	@Size(min = 2, max = 500)
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;

	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;

	@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
	@Size(min = 10, max = 10)
	@JsonProperty("guardianMobileNumber")
	private String guardianMobileNumber;

	@Size(min = 5, max = 255)
	@Schema(example = "xyz@abc.com")
	@JsonProperty("guardianEmailId")
	private String guardianEmailId;

	@NotNull
	private String token;
	
	@NotNull
	@Size(min = 1, max = 35)
	private String transactionUTR;
	
	@NotNull
	public Double transactionAmount;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "transactionTimestamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime transactionTimestamp;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;
}
