package com.opl.jns.service.assitedjourney.v3.model;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import javax.validation.constraints.*;
import java.io.*;

/**
 * @author - Maaz Shaikh
 * @Date - 06-07-2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTransactionRequestWb implements Serializable {

//	@NotNull
//	@Size(min = 21, max = 32)
//	public String urn;

	@Schema(example = "2023-05-05 16:12:10")
	public String transactionTimeStamp;


	public Double transactionAmount;

//	@NotNull
//	@Size(min = 1, max = 100)
//	public String masterPolicyNumber;
//
//	@NotNull
//	public String insurerCode;


	@Size(min = 1, max = 35)
	public String transactionUTR;
//
//	@NotNull
//	@Schema(allowableValues = { "1", "2" }, description = "1:New Enrolment,2:Renewal")
//	public String transactionType;
//
//	public String insurerIFSC;
//
//	public String insurerAccountNumber;

	private final static long serialVersionUID = 1175522787349167241L;

}