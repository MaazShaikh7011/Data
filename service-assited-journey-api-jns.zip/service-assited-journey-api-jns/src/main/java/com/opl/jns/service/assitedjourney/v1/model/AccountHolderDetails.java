package com.opl.jns.service.assitedjourney.v1.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.opl.jns.service.assitedjourney.v1.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v1.enums.Gender;
import com.opl.jns.service.assitedjourney.v1.enums.YesNo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "accountHolderName", "cif", "dob", "gender", "PMJJBYexists", "PMSBYexists", "KYCUpdated" })

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountHolderDetails {

	@NotNull
	@Size(min = 2, max = 50)
	private String accountHolderName;

	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	private String cif;

	@NotNull
	@Schema(example = "13/06/1993")
	private String dob;

	@NotNull
	@Schema(allowableValues ={"M","F","T"},description = "M: Male,F: Female,T: Transgender")
	private String gender;

	@NotNull
	@JsonProperty("PMJJBYexists")
	private YesNo PMJJBYexists;

	@NotNull
	@JsonProperty("PMSBYexists")
	private YesNo PMSBYexists;

	@NotNull
	@JsonProperty("KYCUpdated")
	private YesNo KYCUpdated;
}
