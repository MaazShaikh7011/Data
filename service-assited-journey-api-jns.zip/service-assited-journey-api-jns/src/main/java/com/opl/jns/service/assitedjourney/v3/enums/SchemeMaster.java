package com.opl.jns.service.assitedjourney.v3.enums;

public enum SchemeMaster {
	PMSBY, PMJJBY
}
