package com.opl.jns.service.assitedjourney.v3.responses;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "transactionUTR", "transactionTimeSTamp", "transactionTimeSTamp",
		"premiumAmount", "transactionAmount", "comment" })
public class PremiumDeductionResponse extends CommonResponse {

	@NotNull
	@Schema(allowableValues =  {"1,2,3,4,5,6,7,8" }, description = "1-Successful Debit,"+
			"2-Error (Due to API failure) ,"+
			"3-Balance insufficient, "+
			"4-Account Closed, "+
			"5-Account Dormant,"+
			"6-Account Frozen, "+
			"7-No debit Account, "+
			"8-No debit due to other reason")
	@Pattern(regexp = "1|2|3|4|5|6|7|8", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid debit status.")
	private Integer debitStatus;
	
	@NotNull
	@JsonProperty("transactionUTR")
	@Size(min = 1, max = 35)
	private String transactionUTR; // : Varchar,

	@NotNull
	@JsonProperty("transactionTimeStamp")
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "transactionTimeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime transactionTimeStamp; // : dd/mm/yyyy,hh:mm:ss

	@NotNull
	@JsonProperty("transactionAmount")
	private String transactionAmount; // : Decimal,

	@JsonProperty("comment")
	@Size(min = 0, max = 255)
	private String comment; // : Varchar,
	
	@NotNull
	private String token;

	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime timeStamp;

}
