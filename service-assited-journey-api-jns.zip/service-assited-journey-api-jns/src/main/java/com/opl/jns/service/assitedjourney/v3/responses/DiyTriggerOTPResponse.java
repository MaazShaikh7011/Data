package com.opl.jns.service.assitedjourney.v3.responses;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"status", "message","success", "mobileNumber", "token", "timeStamp" })
public class DiyTriggerOTPResponse extends CommonResponse{

	@NotNull
	@Size(min = 10, max = 10)
	@Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
	private String mobileNumber;
	
	@NotNull
	private String token;

	@NotNull
	@Schema(example = "2000-08-08 15:24:58")
	private String timeStamp;
}
