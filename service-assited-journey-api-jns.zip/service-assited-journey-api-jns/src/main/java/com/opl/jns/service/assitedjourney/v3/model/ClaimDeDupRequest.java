package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClaimDeDupRequest implements Serializable {

	private final static long serialVersionUID = -9020492356609251905L;
	
	@NotNull
	@Size(min = 21, max = 32)
	public String urn;
	
	@NotNull
	public Long claimReferenceId;
	
	public String hospitalisationDate;
	
	@Size(min = 2, max = 100)
	public String firNo;
	
	public String firDate;
	
	@Size(min = 2, max = 100)
	public String panchnamaNo;

	public String panchnamaDate;
	
	@Size(min = 2, max = 100)
	public String postMortemReportNo;

	public String postMortemReportDate;

	@Size(min = 2, max = 100)
	public String deathCertificateReportNo;
	
	public String deathCertificateReportDate;
	
	public String documentReceivingDate;

	private String token;

}
