package com.opl.jns.service.assitedjourney.v3.model;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.service.assitedjourney.v3.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class FetchEnrollmentMISRequest {
	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	@NotNull
	@Size(min = FieldsMaster.CIF_MIN, max = FieldsMaster.CIF_MAX)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;

	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "effectiveDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime effectiveDate;

	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "requestDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime requestDate;

	@NotNull
	private String token;

}
