package com.opl.jns.service.assitedjourney.v1.model;

import com.fasterxml.jackson.annotation.*;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonPropertyOrder;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "status", "message", "transactionUTR", "transactionTimeSTamp", "transactionTimeSTamp",
		"premiumAmount", "transactionAmount", "comment" })
public class PremiumDeductionResponse extends CommonResponse {

	@NotNull
	@JsonProperty("transactionUTR")
	@Size(min = 5, max = 35)
	private String transactionUTR; // : Varchar,

	@NotNull
	@JsonProperty("transactionTimeStamp")
	@Schema(example = "13/06/2023 05:06:00")
	private String transactionTimeStamp; // : dd/mm/yyyy,hh:mm:ss

	@NotNull
	@JsonProperty("transactionAmount")
	private String transactionAmount; // : Decimal,

	@JsonProperty("comment")
	@Size(min = 0, max = 255)
	private String comment; // : Varchar,

}
