package com.opl.jns.service.assitedjourney.v3.model;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.service.assitedjourney.v3.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DiyTriggerOTPRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;
	
	@NotNull
	@JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
	private LocalDateTime dob;

	@NotNull
	@Size(min =  FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;

	@NotNull
	@Size(min =1, max = 50)
	@Schema(allowableValues = { "1", "2","3","4" }, description = "1:  NEW ENROLLMENT, 2: DIY Sign up, 3: OPT-OUT (DIY),4: NOMINEE UPDATE (DIY)")
	@JsonProperty("purpose")
	private String purpose;

	@NotNull
	private String token;

}
