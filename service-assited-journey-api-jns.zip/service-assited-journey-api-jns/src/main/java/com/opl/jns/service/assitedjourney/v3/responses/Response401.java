package com.opl.jns.service.assitedjourney.v3.responses;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class Response401 {

//	@Schema(example = "Unauthorized Request")
//	private String message;
//
//	@Schema(example = "401")
//	private Integer status;
//
//	@Schema(example = "false")
//	private Boolean success;
//
//	@Schema(example = "false")
//	private Boolean flag;

}
