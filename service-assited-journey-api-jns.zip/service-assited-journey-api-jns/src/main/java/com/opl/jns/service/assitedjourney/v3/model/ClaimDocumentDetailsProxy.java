package com.opl.jns.service.assitedjourney.v3.model;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import java.util.List;

import javax.validation.constraints.*;

import com.opl.jns.service.assitedjourney.v3.responses.CommonResponse;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDocumentDetailsProxy  {

	@NotNull
    @Size(min = 0,max = 255)
//	@Schema( description = "coi")
	private String documentType;
	
	@NotNull
	@Schema( description = "pdf")
	private String contentType;
	
	@NotNull
	@Schema(allowableValues = {"4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"}, description = "Review Example Description : documents >>> documentId >>> Enum ")
	private Long documentId;
	
	@NotNull
	private byte[] document;	
}
