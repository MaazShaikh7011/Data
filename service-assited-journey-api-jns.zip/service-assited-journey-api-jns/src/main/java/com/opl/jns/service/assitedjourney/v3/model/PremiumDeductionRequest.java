package com.opl.jns.service.assitedjourney.v3.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.service.assitedjourney.v2.enums.FieldsMaster;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PremiumDeductionRequest {

	@NotNull
	@Size(min = 3, max = 17)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String customerAccountNumber;

	

	@NotNull
	@Size(min = 2, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
			"132-Future Generali India Insurance Company Limited",
			"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
			"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
			"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
			"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
			"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
			"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
			"512-Life Insurance Corporation of India" })
	@Pattern(regexp = "556|132|115|190|146|142|101|143|111|136|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
	private String insurerCode;
	
	@NotNull
	@Size(min = 1, max = 50)
	@Schema(example = "25412")
	private String userId;
	
	@NotNull
	@Size(min = 2, max = 30)
	@Schema(example = "2541")
	@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Enter valid Branch Code")
	private String branchCode;

	
//	@NotNull
//	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
//	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
//	private String insurerAccountNumber;
//
//	@NotNull
//	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
//	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
//	private String insurerIFSC;

	@NotNull
	@Schema(allowableValues ={"PMJJBY","PMSBY"})
	private String scheme;

	@NotNull
	private Double premiumAmount;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
	
	@Size(min = 3, max = 25)
	@Schema(allowableValues ={"DIY","Assisted"})
	private String mode;
	
	@NotNull
	private String token;
}
