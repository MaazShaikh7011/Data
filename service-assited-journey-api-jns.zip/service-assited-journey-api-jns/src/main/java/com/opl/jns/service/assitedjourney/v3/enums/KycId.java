package com.opl.jns.service.assitedjourney.v3.enums;

public enum KycId {
	AADHAR, PAN, VOTERID, DRIVINGL, PASSPORT, MGNREGA
}