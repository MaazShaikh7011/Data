package com.opl.jns.service.assitedjourney.v3.enums;

public class FieldsMaster {

	public static final int URN_MIN = 31;
	public static final int URN_MAX = 32;
	public static final String URN_SAMPLE = "JNS-XXXXX-0000-00-00000-0000";

	public static final int ACC_NUM_MIN = 3;
	public static final int ACC_NUM_MAX = 17;
	public static final String ACC_NUM_SAMPLE = "*******8243";

	public static final int IFSC_NUM_MIN = 11;
	public static final int IFSC_NUM_MAX = 11;
	public static final String IFSC_NUM_SAMPLE = "XXXX000000";

	public static final int CIF_MIN = 3;
	public static final int CIF_MAX = 17;

	public static final int PAN_MIN = 10;
	public static final int PAN_MAX = 10;
	public static final String PAN_SAMPLE = "XXXXX0000X";

	public static final int AADHAR_MIN = 10;
	public static final int AADHAR_MAX = 17;
	public static final String AADHAR_SAMPLE = "000000000000";
	
	public static final int ACC_HOLERNAME_MIN = 1;
	public static final int ACC_HOLERNAME_MAX = 300;

}
