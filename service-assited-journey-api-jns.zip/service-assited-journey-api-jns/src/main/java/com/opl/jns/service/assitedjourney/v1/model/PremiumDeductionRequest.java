package com.opl.jns.service.assitedjourney.v1.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.opl.jns.service.assitedjourney.v1.enums.FieldsMaster;
import com.opl.jns.service.assitedjourney.v1.enums.SchemeMaster;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PremiumDeductionRequest {

	@NotNull
	@Size(min = 3, max = 17)
	private String cif;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String customerAccountNumber;

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String insurerAccountNumber;

	@NotNull
	@Size(min = FieldsMaster.IFSC_NUM_MIN, max = FieldsMaster.IFSC_NUM_MAX)
	@Schema(example = FieldsMaster.IFSC_NUM_SAMPLE)
	private String insurerIFSC;

	@NotNull
	private SchemeMaster scheme;

	@NotNull
	private Double premiumAmount;

	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
}
