package com.opl.jns.service.assitedjourney.v2.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.opl.jns.service.assitedjourney.v2.enums.FieldsMaster;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TriggerOTPRequest {

	@NotNull
	@Size(min = FieldsMaster.ACC_NUM_MIN, max = FieldsMaster.ACC_NUM_MAX)
	@Schema(example = FieldsMaster.ACC_NUM_SAMPLE)
	private String accountNumber;

	
	@NotNull
	@Schema(example = "13/06/2000")
	private String dob;
	
	@NotNull
	@Size(min = FieldsMaster.URN_MIN, max = FieldsMaster.URN_MAX)
	@Schema(example = FieldsMaster.URN_SAMPLE)
	private String urn;
}
