package com.opl.jns.service.assitedjourney.v3.model;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NomineeUpdateStatusRequest {
	

    private static final long serialVersionUID = 1L;
    
	@NotNull
	private String token;
	
	@NotNull
	@Size(min = 31, max = 32)
    private String urn;
	
	@NotNull
	@Schema(example = "YES")
    private String nomineeUpdateFlag;
	
	@NotNull
	@Size(min = 1, max = 300)
    private String nomineeName;
	
    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD)
    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
    private LocalDate nomineeDateOfBirth;
    
    @Size(min = 10, max = 10)    
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String nomineeMobileNumber;
    
    @NotNull
	@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
			"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
			"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
    @Size(min = 1, max = 50)
    private String relationshipOfNominee;
    
    @Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    private String nomineeEmailId;
    
    @NotNull
    @Size(min = 2, max = 500)
    private String addressOfNominee;
    
    @Size(min = 1, max = 300)
    private String nameOfGuardian;
    
    @Size(min = 2, max = 500)
    private String addressOfGuardian;
    
    @Size(min = 1, max = 50)
    private String relationshipOfGuardian;
    
    @Size(min = 10, max = 10)    
    @Pattern(regexp = "^[6789]\\d{9}",message = "Enter valid mobile Number")
    private String guardianMobileNumber;
    
    @Size(min = 5, max = 255)
    @Schema(example = "xyz@gmail.com")
    private String guardianEmailId;

}
