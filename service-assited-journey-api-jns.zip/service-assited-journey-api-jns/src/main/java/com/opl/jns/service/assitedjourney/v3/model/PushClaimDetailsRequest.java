package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.service.assitedjourney.v3.enums.YesNo;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;
import com.opl.jns.utils.constant.CommonConstant;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PushClaimDetailsRequest implements Serializable  {
	
		@NotNull
		private Long claimReferenceId;
		
		@NotNull
		@Size(min = 1, max = 100)
		private String masterPolicyNumber;
		
		@NotNull
		private String token;
		
		@NotNull
		@Size(min = 31, max = 32)
		private String urn;

		@NotNull
		@Schema(allowableValues = { "PMJJBY", "PMSBY" })
		private String schemeName;

		@NotNull
		@Size(min = 3, max = 17)
		private String customerAccountNumber;

		@NotNull
		@Size(min = 2, max = 50)
		private String customerBankname;

		@NotNull
		@Size(min = 11, max = 11)
		private String customerIFSC;

		@NotNull
		@Size(min = 1, max = 300)
		private String accountHolderName;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "dob", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate dob;

		@NotNull
		@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
		private String gender;
		
		@NotNull
		@Size(min = 2, max = 17)
		@Schema(allowableValues = { "556-The Oriental Insurance Company Limited",
				"132-Future Generali India Insurance Company Limited",
				"115-ICICI LOMBARD General Insurance Company Limited", "190-The New India Assurance Company Limited",
				"146-HDFC ERGO General Insurance Company Limited", "142-Star Union Dai-Ichi Life Insurance Company Limited",
				"101-HDFC Life Insurance Company Limited", "143-IndiaFirst Life Insurance Company Limited",
				"58-National Insurance Company Limited", "136-Canara HSBC Life Insurance Company Limited",
				"111-SBI Life Insurance Company Limited", "134-Universal Sompo General Insurance",
				"105-ICICI Prudential Life Insurance Company Limited", "545-United India Insurance Company",
				"512-Life Insurance Corporation of India" })
		@Pattern(regexp = "556|132|115|190|146|142|101|143|111|136|134|105|545|512", flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid insurer Code.")
		private String insurerCode;

//		@NotNull
//		@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
//	    @ApiModelProperty(notes = "fisrtEnrollmentDate", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
//		private LocalDateTime fisrtEnrollmentDate;

		@NotNull	 	
		@Size(min = 2, max = 30)
		@Schema(allowableValues = CommonConstant.BANK_SHORT_CODE_NAME)
		@Pattern(regexp = CommonConstant.BANK_SHORT_CODE, flags = Pattern.Flag.CASE_INSENSITIVE, message = "Enter valid Bank Code.")
		public String bankCode;

		@NotNull
		@Size(min = 2, max = 30)
		private String branchCode;
		
		@NotNull
		@Size(min = 5, max = 255)
		@Schema(example = "xyz@gmail.com")
		private String bankBranchEmailId;
		
		@NotNull
		@Size(min = 10, max = 10)
		@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
		private String mobileNumber;

		@Size(min = 5, max = 255)
		// @Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email
		// not format")
		@Schema(example = "xyz@gmail.com")
		private String emailID;
		
		@NotNull
		@Size(min = 2, max = 500)
		private String addressline1;

		@Size(min = 2, max = 500)
		private String addressline2;

		@NotNull
		@Schema(example = "382350")
		@Size(min = 6, max = 6)
		private Integer pincode;

		@NotNull
		@Size(min = 2, max = 200)
		private String city;

		@NotNull
		@Size(min = 2, max = 200)
		private String district;

		@NotNull
		@Size(min = 2, max = 200)
		private String state;

		@NotNull
		@Size(min = 1, max = 25)
		@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
		private String kycID1;

		@NotNull
		@Size(min = 1, max = 100)
		private String kycID1number;

//		 @NotNull
//		@Schema(allowableValues ={"AADHAR","PAN","VOTERID","DRIVINGL","PASSPORT","MGNREGA"})
//		@Size(min = 1, max = 25)
//	    private String kycID3;
	//	
//		@NotNull
//		@Size(min = 1, max = 100)
//	    private String kycID3number;
		@JsonProperty("pan")
		private YesNo pan;

		@Size(min = 10, max = 10)
		private String panNumber;

		@JsonProperty("aadhaar")
		private YesNo aadhaar;

		@Size(min = 12, max = 12)
		private String aadhaarNumber;
		
		@JsonProperty("ckyc")
		private YesNo ckyc;

		@Size(min = 14, max = 15)
		private String ckycNumber;

		@NotNull
		@Size(min = 1, max = 300)
		private String nomineeName;
		
		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "nomineeDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate nomineeDateOfBirth;

		@NotNull
		@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
		private String nomineeGender;
		
		@NotNull
		@Size(min = 10, max = 10)
		@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
		private String nomineeMobileNumber;
		
		@NotNull
		@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
				"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
				"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
		@Size(min = 1, max = 50)
		private String relationshipOfNominee;

		@Size(min = 5, max = 255)
		@Schema(example = "xyz@gmail.com")
		// @Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email
		// not format")
		private String nomineeEmailId;

		@NotNull
		@Size(min = 2, max = 500)
		private String addressofNominee;

		@NotNull
		@Size(min = 1, max = 300)
		private String correctNomineeName;
		
		@NotNull
		@Size(min = 1, max = 300)
		private String nameofGuardian;

		@NotNull
		@Size(min = 2, max = 500)
		private String addressOfGuardian;

		@NotNull
		@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
				"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
				"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
		@Size(min = 1, max = 50)
		private String relationShipOfGuardian;

		@NotNull
		@Size(min = 10, max = 10)
		@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
		private String guardianMobileNumber;

		@Size(min = 5, max = 255)
		@Schema(example = "xyz@gmail.com")
		// @Pattern(regexp="^([a-zA-Z0-9])[\\\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}$",message="email
		// not format")
		private String guardianEmailId;

		@NotNull
		@Size(min = 1, max = 300)
		private String claimantName;
		
		@NotNull
		@Size(min = 2, max = 500)
		private String claimantAddress;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "claimantDateOfBirth", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate claimantDateOfBirth;

		@NotNull
		@Schema(allowableValues = { "Husband", "Wife", "Father", "Mother", "Son", "Daughter", "Brother", "Sister",
				"Grand father", "Grand mother", "Grand son", "Grand daughter", "Mother in law", "Father in law",
				"Brother in law", "Sister in law", "Nephew", "Niece", "Uncle", "Aunt", "Others" })
		private String relationshipOfClaimant;

		@NotNull
		@Size(min = 10, max = 10)
		@Pattern(regexp = "^[6789]\\d{9}", message = "Enter valid mobile Number")
		private String claimantMobileNumber;
		
		@Size(min = 5, max = 255)
		@Schema(example = "xyz@gmail.com")
		private String claimantEmailId;

		@NotNull
		@Size(min = 1, max = 25)
		@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
		private String claimantKYC1;

		@NotNull
		@Size(min = 1, max = 100)
		private String claimantKYCNumber1;

		@Schema(allowableValues = { "AADHAR", "PAN", "VOTERID", "DRIVINGL", "PASSPORT", "MGNREGA" })
		@Size(min = 1, max = 25)
		private String claimantKYC2;

		@Size(min = 1, max = 100)
		private String claimantKycNumber2;
		
		@NotNull
		@Schema(allowableValues = { "M", "F", "T" }, description = "M: Male,F: Female,T: Transgender")
		private String claimantGender;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "dateOfAccident", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate dateOfAccident;

		@NotNull
		@Schema(example = "HH:mm:ss")
		private String timeOfAccident;

		@NotNull
		@Size(min = 1, max = 25)
		@Schema(allowableValues = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" })
		private String dayOfAccident;

		@NotNull
		private String placeOfOccurence;

		@NotNull
		@Size(min = 1, max = 100)
		@Schema(allowableValues = { "Death", "Disability" })
		private String natureOfAccident;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
	    @ApiModelProperty(notes = "dateOfDeath", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
		private LocalDateTime dateOfDeath;

		@NotNull
		@Size(min = 1, max = 100)
		@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental death within 30 days of lien period", "Suicide" })
		private String causeOfDeath;

		@NotNull
		@Schema(allowableValues = { "Natural Death/Non Accidental", "Accidental", "Suicide" })
		@Size(min = 1, max = 100)
		private String causeOfDeathDisability;

		@NotNull
		@Schema(allowableValues = { "Partial permanent", "Total permanent" })
		@Size(min = 1, max = 100)
		private String typeOfDisability;

		@NotNull
		@Size(min = 3, max = 17)
		private String claimantBankAccountNumber;

		@NotNull
		@Size(min = 2, max = 50)
		private String claimantBankName;

		@NotNull
		@Size(min = 11, max = 11)
		@Pattern(regexp = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", message = "Enter valid IFSc")
		private String claimantBranchIFSC;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "premDebitDate", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate premDebitDate;

		@NotNull
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "premRemitDate", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate premRemitDate;
		
		@JsonFormat(pattern = Constants.YYYY_MM_DD)
	    @ApiModelProperty(notes = "dateOfLodgingClaim", example = Constants.YYYY_MM_DD, required = true)
		private LocalDate dateOfLodgingClaim;
		
//		private ClaimDocumentDetailsProxy documentList;
		private List<ClaimDocumentDetailsProxy> documents;
}
