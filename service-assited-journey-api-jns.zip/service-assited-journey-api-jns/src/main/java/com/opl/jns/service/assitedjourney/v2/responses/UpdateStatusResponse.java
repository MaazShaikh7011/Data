package com.opl.jns.service.assitedjourney.v2.responses;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import javax.validation.constraints.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UpdateStatusResponse {

	@NotNull
	@Schema(example = "200")
	private Integer status;

	@NotNull
	@Size(min = 0, max = 255)
	private String message;

	@NotNull
	@Schema(allowableValues = { "True", "False" })
	private Boolean success;
}
