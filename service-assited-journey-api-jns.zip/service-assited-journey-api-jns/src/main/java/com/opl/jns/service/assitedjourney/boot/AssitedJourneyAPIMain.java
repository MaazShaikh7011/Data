package com.opl.jns.service.assitedjourney.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.published.lib.utils.ApplicationProperties;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableScheduling
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
//@EnableAutoConfiguration(exclude= {DataSourceAutoConfiguration.class, MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
public class AssitedJourneyAPIMain {

	public static void main(String[] args) {
		SpringApplication.run(AssitedJourneyAPIMain.class, args);
	}

}
