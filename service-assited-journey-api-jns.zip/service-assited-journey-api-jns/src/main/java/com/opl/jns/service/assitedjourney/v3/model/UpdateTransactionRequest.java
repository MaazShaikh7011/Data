package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.service.assitedjourney.v3.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 06-07-2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTransactionRequest implements Serializable {

//	@NotNull
//	@Size(min = 21, max = 32)
//	public String urn;

	@JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "transactionTimeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
	private LocalDateTime transactionTimeStamp;


	public Double transactionAmount;

//	@NotNull
//	@Size(min = 1, max = 100)
//	public String masterPolicyNumber;
//
//	@NotNull
//	public String insurerCode;


	@Size(min = 1, max = 35)
	public String transactionUTR;
//
//	@NotNull
//	@Schema(allowableValues = { "1", "2" }, description = "1:New Enrolment,2:Renewal")
//	public String transactionType;
//
//	public String insurerIFSC;
//
//	public String insurerAccountNumber;

	private final static long serialVersionUID = 1175522787349167241L;

}