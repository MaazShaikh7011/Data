package com.opl.jns.service.assitedjourney.v2.responses;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.opl.jns.service.assitedjourney.v2.responses.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TriggerOTPResponse extends CommonResponse {

	@NotNull
	@Size(min = 10, max = 10)
	private String mobileNumber;
}
