package com.opl.jns.service.assitedjourney.v3.model;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CoiDocumentDetailsProxy {

	@NotNull
	@Schema( description = "coi")
	private String documentType;
	@NotNull
	@Schema( description = "pdf")
	private String contentType;
	@NotNull
	private byte[] document;	
}
