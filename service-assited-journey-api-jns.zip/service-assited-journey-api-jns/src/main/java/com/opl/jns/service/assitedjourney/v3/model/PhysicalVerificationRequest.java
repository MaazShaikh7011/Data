package com.opl.jns.service.assitedjourney.v3.model;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@ToString
public class PhysicalVerificationRequest extends TriggerVerificationCodeRequest {

	@NotNull
	@Schema(allowableValues ={"Yes"})
	private String signVerifiedByBank;
	
	@NotNull
	private String token;
}
