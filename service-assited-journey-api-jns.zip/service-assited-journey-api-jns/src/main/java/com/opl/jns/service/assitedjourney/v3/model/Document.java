package com.opl.jns.service.assitedjourney.v3.model;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;

public class Document implements Serializable {

    @NotNull
    @Min(1)
    @Schema(allowableValues = {"4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23"}, description = "Review Example Description : documents >>> documentId >>> Enum ")
    public Long documentId;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String documentType;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    @Schema(allowableValues ={"pdf"},description = "pdf")
    public String contentType;

    @NotNull
    @NotEmpty
    public byte[] document;
    private final static long serialVersionUID = -2484884962226128489L;
}
