package com.opl.service.conciliation.jns.service;

import com.opl.ConciliationRequest;
import org.springframework.stereotype.Service;

@Service
public interface ReConciliationService {

    public Object reconciliation(ConciliationRequest request);

}
