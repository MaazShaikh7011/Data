package com.opl.service.conciliation.jns.service.impl;

import com.opl.ConciliationRequest;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.service.conciliation.jns.service.ReConciliationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.ArrayUtils;
import org.apache.poi.POIXMLProperties;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

@Service
@Slf4j
public class ReConciliationServiceImpl implements ReConciliationService {

    public static final int RECONCILIATION_TYPE_DOWNLOAD = 1;
    public static final int RECONCILIATION_TYPE_BANK = 2;
    public static final int RECONCILIATION_TYPE_INSURER = 3;
    private static final String DATA_COLUMN_A = "A";
    private static final String DATA_COLUMN_B = "B";

    private static final String DATA_COLUMN_C = "C";
    private static final String DATA_COLUMN_D = "D";

    private static final String DATA_COLUMN_E = "E";
    private static final String DATA_COLUMN_F = "F";


    Long[] dataListColumnA = new Long[]{1L, 2L, 2L, 4L, 5L, 6L, 7L, 8L, 9L, 10L, 11L, 12L, 13L, 14L, 15L, 16L, 17L, 18L, 19L, 20L};
    String[] dataListColumnB = new String[]{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"};

    private static final String SHEET_PROTECT_PASS_KEY = "#JNS$123Reco";


// ----------------------- LOGIC --------------------------------------
//      if type id = 1
//            in this case file in request is not mandatory
//            write data in A and B make it locked
//                Make column C and D unlocked and other cell locked
//      if type id = 2
//                check column A and B is locked or not
//                check column C and D has value or not and if exist then locked C And D and Make E and F unlocked
//      if type id = 3
//                check column A,B,C and D is locked or not
//                check column E and F has value or not and if exist then locked E And F.

    @Override
    public Object reconciliation(ConciliationRequest request) {
        try {
            log.info("req.getType {}", request.getTypeId());
            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            /* CREATE WORKBOOK IN CASE OF DOWNLOAD AND READ UPLOADED WORKBOOK IN ALL OTHER CASE */
            XSSFWorkbook workbook = readOrCreateWorkBook(request);
            if (workbook == null) return "Kindly upload file";

            /* UNLOCKED CELL STYLE */
            CellStyle unlockedCellStyle = workbook.createCellStyle();
            unlockedCellStyle.setLocked(false);

            /* LOCKED CELL STYLE */
            CellStyle lockedCellStyle = workbook.createCellStyle();
            lockedCellStyle.setLocked(true);

            XSSFSheet sheet = workbook.getSheetAt(0);

            switch (request.getTypeId()) {
                case RECONCILIATION_TYPE_DOWNLOAD:
                    /* WRITE EXISTING DATA INTO SHEET */
                    writeDataInColumnForBank(sheet, unlockedCellStyle, lockedCellStyle);
                    break;
                case RECONCILIATION_TYPE_BANK:
                    /* VALIDATE UPLOADED FILE */
                    String validateMsg = validateUploadedExcel(sheet, RECONCILIATION_TYPE_BANK);
                    if (!OPLUtils.isObjectNullOrEmpty(validateMsg)) {
                        return validateMsg;
                    }

                    /* CHECK COLUMN C AND D HAS VALUE OR NOT AND IF EXIST THEN LOCKED C AND D AND MAKE E AND F UNLOCKED */
                    checkColumnUpdatedByBank(sheet, unlockedCellStyle, lockedCellStyle);
                    break;
                case RECONCILIATION_TYPE_INSURER:
                    /* VALIDATE UPLOADED FILE */
                    validateMsg = validateUploadedExcel(sheet, RECONCILIATION_TYPE_INSURER);
                    if (!OPLUtils.isObjectNullOrEmpty(validateMsg)) {
                        return validateMsg;
                    }

                    /* CHECK COLUMN C AND D HAS VALUE OR NOT AND IF EXIST THEN LOCKED C AND D AND MAKE E AND F UNLOCKED */
                    checkUpdatedColumnsByInsurer(sheet, lockedCellStyle, unlockedCellStyle);
                    break;
            }

            /* ADD PRODUCER DETAILS */
            addProducerDetails(workbook);

            /* PROTECT SHEET */
            sheet.protectSheet(SHEET_PROTECT_PASS_KEY);

            /* write sheet */
            workbook.write(bos);
            return bos.toByteArray();
        } catch (Exception e) {
            log.error("exception ", e);
            e.printStackTrace();
        }
        return null;
    }

    private static XSSFWorkbook readOrCreateWorkBook(ConciliationRequest request) throws IOException {
        XSSFWorkbook workbook;
        if (request.getTypeId() == RECONCILIATION_TYPE_DOWNLOAD) {
            workbook = new XSSFWorkbook();
            workbook.createSheet("Reconciliation");
        } else if ((request.getTypeId() == RECONCILIATION_TYPE_BANK || request.getTypeId() == RECONCILIATION_TYPE_INSURER) && OPLUtils.isObjectNullOrEmpty(request.getFile())) {
            return null;
        } else {
            InputStream stream = new ByteArrayInputStream(request.getFile().getBytes());
            workbook = new XSSFWorkbook(stream);
        }
        return workbook;
    }

    private void writeDataInColumnForBank(XSSFSheet sheet, CellStyle unlockedCellStyle, CellStyle lockedCellStyle) {
        /* WRITE DATA IN COLUMN in A */
        int colIdx = CellReference.convertColStringToIndex(DATA_COLUMN_A);
        for (String firstColData : dataListColumnB) {
            Row row = sheet.createRow(ArrayUtils.indexOf(dataListColumnB, firstColData)); // fetch row based on index
            Cell cell = CellUtil.getCell(row, colIdx); // fetch column and get cell
            cell.setCellValue(firstColData);
        }
        /* WRITE DATA IN COLUMN  in B*/
        int colIdxB = CellReference.convertColStringToIndex(DATA_COLUMN_B);
        for (String secondColData : dataListColumnB) {
            Row row = sheet.getRow(ArrayUtils.indexOf(dataListColumnB, secondColData)); // fetch row based on index
            Cell cell = CellUtil.getCell(row, colIdxB); // fetch column and get cell
            cell.setCellValue(secondColData);
        }

        /* MAKING COLUMN C AND D OPEN AND OTHER COLUMN LOCK */
        for (Row row : sheet) {
            /* CREATE ADDITIONAL CELL FOR INSURER */
            CellUtil.createCell(row, CellReference.convertColStringToIndex(DATA_COLUMN_C), null, unlockedCellStyle);
            CellUtil.createCell(row, CellReference.convertColStringToIndex(DATA_COLUMN_D), null, unlockedCellStyle);
            /* LOCK / UN-LOCK CELL */
            for (Cell mycell : row) {
                if (mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_C)
                        || mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_D)) {
                    mycell.setCellStyle(unlockedCellStyle);
                } else {
                    mycell.setCellStyle(lockedCellStyle);
                }
            }
        }
    }

    private static void checkUpdatedColumnsByInsurer(XSSFSheet sheet, CellStyle lockedCellStyle, CellStyle unlockedCellStyle) {
        for (Row row : sheet) {
            for (Cell mycell : row) {
                if (!OPLUtils.isObjectNullOrEmpty(mycell) && mycell.getCellType() != mycell.CELL_TYPE_BLANK) {
                    mycell.setCellStyle(lockedCellStyle);
                } else {
                    mycell.setCellStyle(unlockedCellStyle);
                }
            }
        }
    }

    private static void checkColumnUpdatedByBank(XSSFSheet sheet, CellStyle unlockedCellStyle, CellStyle lockedCellStyle) {
        for (Row row : sheet) {
            /* CREATE ADDITIONAL CELL FOR INSURER */
            CellUtil.createCell(row, CellReference.convertColStringToIndex(DATA_COLUMN_E), null, unlockedCellStyle);
            CellUtil.createCell(row, CellReference.convertColStringToIndex(DATA_COLUMN_F), null, unlockedCellStyle);

            for (Cell mycell : row) {
                if (mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_C)
                        || mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_D)) {
                    mycell.setCellStyle(lockedCellStyle);
                } else if (mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_F)
                        || mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_E)) {
                    mycell.setCellStyle(unlockedCellStyle);
                }
            }
        }
    }

    private static void addProducerDetails(XSSFWorkbook workbook) {
        /* LET US SET SOME CORE PROPERTIES NOW */
        POIXMLProperties props = workbook.getProperties();
        POIXMLProperties.CoreProperties coreProp = props.getCoreProperties();
        coreProp.setCreator("OPL");
        coreProp.setDescription("File generated for reconciliation purpose by JNS");
        coreProp.setCategory("Insurance");

        /* SET SOME CUSTOM PROPERTIES */
        POIXMLProperties.CustomProperties custProp = props.getCustomProperties();
        custProp.addProperty("Author", "JNS");
        custProp.addProperty("Year", new Date().getYear());
        custProp.addProperty("Published", Boolean.TRUE);
    }


    private String validateUploadedExcel(XSSFSheet sheet, int typeId) {

        /* VALIDATE HERE THE SHEET IS CREATED BY OPL OR NOT */
        POIXMLProperties props = sheet.getWorkbook().getProperties();
        POIXMLProperties.CoreProperties coreProp = props.getCoreProperties();
        if (!OPLUtils.isObjectNullOrEmpty(coreProp.getCreator()) && !coreProp.getCreator().equals("OPL")) {
            return "Provided sheet is not downloaded from JNS Portal";
        }

        /* CHECK SHEET IS PROTECTED WITH SAME PASSWORD OR NOT */
        if (!sheet.validateSheetPassword(SHEET_PROTECT_PASS_KEY)) {
            return "Provided sheet is not downloaded from JNS Portal";
        }

        /* CHECK COLUMN EXISTING  IS LOCKED OR NOT */
        for (Row row : sheet) {
            for (Cell mycell : row) {
                if ((mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_A) || mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_B))
                        && !mycell.getCellStyle().getLocked()) {
                    return "Provided sheet is not valid";
                }

                if (typeId == RECONCILIATION_TYPE_INSURER && !mycell.getCellStyle().getLocked()
                        && (mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_C)
                        || mycell.getColumnIndex() == CellReference.convertColStringToIndex(DATA_COLUMN_D))) {
                    return "Provided sheet is not valid";
                }


            }

        }
        return null;
    }
}


//            FormulaEvaluator formulaEvaluator=workbook.getCreationHelper().createFormulaEvaluator();
//
//
//            for (Row row : sheet){     //iteration over row using for each loop
//                for (Cell cell : row){    //iteration over cell using for each loop
//                    boolean isLocked = cell.getCellStyle().getLocked();
//                    if(isLocked) { // read cell in case of locked only
//                        switch (formulaEvaluator.evaluateInCell(cell).getCellType()) {
//                            case Cell.CELL_TYPE_NUMERIC:   //field that represents numeric cell type
//                                //getting the value of the cell as a number
//                                System.out.print(cell.getNumericCellValue() + "\t\t");
//                                break;
//                            case Cell.CELL_TYPE_STRING:    //field that represents string cell type
//                                //getting the value of the cell as a string
//                                System.out.print(cell.getStringCellValue() + "\t\t");
//                                break;
//                        }
//                    }else{
//                        System.out.println("cell is not locked");
//                    }
//                }
//                System.out.println();
//            }