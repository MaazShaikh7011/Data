package com.opl.service.conciliation.jns.controller;

import com.opl.ConciliationRequest;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.service.conciliation.jns.service.ReConciliationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/v1")
@Slf4j
public class ControllerV1 {

    @Autowired
    ReConciliationService service;

    @GetMapping(value = "/testService", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getStageDetails() {
        try {
            log.info("service working !!-->" );
            return new ResponseEntity<>(new CommonResponse("Serivice properly working",HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get stage details ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }



    @PostMapping(value = "/reconciliation", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Object reconciliation(ConciliationRequest req, HttpServletRequest request) {
        try {
            log.info("inside reconciliation !!-->" );
            Object reconciliation = service.reconciliation(req);
            if(reconciliation instanceof  byte[]){
                return reconciliation;
            }else if(reconciliation instanceof String){
                return new ResponseEntity<>(new CommonResponse((String) reconciliation,HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }

            return new ResponseEntity<>(new CommonResponse(reconciliation.toString(),HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get stage details ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }

    }
}