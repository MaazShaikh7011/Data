package com.opl;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Setter
@Getter
public class ConciliationRequest {

    private int typeId;
    private MultipartFile file;


}
