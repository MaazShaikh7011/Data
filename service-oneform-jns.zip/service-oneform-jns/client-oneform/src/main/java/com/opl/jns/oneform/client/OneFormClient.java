package com.opl.jns.oneform.client;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.model.*;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.api.utils.OneformUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

/**
 * @author Sanket
 *
 */
public class OneFormClient {

	private static final Logger logger = LoggerFactory.getLogger(OneFormClient.class.getName());


	private static final String REQUEST_STATE_FROM_COUNTRY = "/v3/master/getStateListByCountryIdListId";
	private static final String REQUEST_CITY_FROM_CITY_ID = "/v3/master/city";
	private static final String REQUEST_LGD_CITY_FROM_CITY_ID = "/v3/master/lgdCity";
	private static final String REQUEST_STATE_FROM_STATE_ID = "/v3/master/state";
	private static final String REQUEST_LGD_STATE_FROM_STATE_ID = "/v3/master/lgdState";
	private static final String REQUEST_STATE_FROM_COUNTRY_ID = "/v3/master/getStateListByCountry";
	private static final String  GET_CITY_STATE_MASTER ="/v3/master/getCityStateMaster";
	private static final String  GET_NAME_BY_KEY_AND_OBJID ="/v3/master/getNameByKeyAndObjId";
	private static final String  GET_ID_BY_KEY_AND_NAME ="/v3/master/getIdByKeyAndName";
	private static final String GET_FIRST_PINCODE_MASTER_BY_PINCODE = "/pincode/master/getFirstPincodeMasterByPincode";

	private static final String  GET_LGD_DISTRICT_STATE_MASTER ="/v3/master/getLgdDistrictStateMaster";


	private String oneFormBaseUrl;
	private RestTemplate restTemplate;

	public OneFormClient(String oneFormBaseUrl) {
		this.oneFormBaseUrl = oneFormBaseUrl;
		restTemplate = new RestTemplate();

	}
	
	public static void setClient(HttpHeaders headers) {
		headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		headers.add("Accept", "application/json");
	}


	public OneFormResponse getStateListByCountryIdListId(List<Long> id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_STATE_FROM_COUNTRY);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<List<Long>> entity = new HttpEntity<>(id, headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, OneFormResponse.class).getBody();
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public MasterResponse getCityByCityId(Long id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_CITY_FROM_CITY_ID);
		url = url.concat("/" + id);
		logger.info("Get City Details By URL ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(id, headers);
			OneFormResponse oneFormRes = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if(oneFormRes != null && oneFormRes.getStatus() == 200 && oneFormRes.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) oneFormRes.getData(), MasterResponse.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("City Details Not Found ID-" + id);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public LgdDistrictStateResponse getLgdCityByCityId(Long id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_LGD_CITY_FROM_CITY_ID);
		url = url.concat("/" + id);
		logger.info("Get City Details By URL ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(id, headers);
			OneFormResponse oneFormRes = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if(oneFormRes != null && oneFormRes.getStatus() == 200 && oneFormRes.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) oneFormRes.getData(), LgdDistrictStateResponse.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("City Details Not Found ID-" + id);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public MasterResponse getStateByStateId(Long id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_STATE_FROM_STATE_ID);
		url = url.concat("/" + id);
		logger.info("Get State Details By URL ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(id, headers);
			OneFormResponse oneFormRes = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if(oneFormRes != null && oneFormRes.getStatus() == 200 && oneFormRes.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) oneFormRes.getData(), MasterResponse.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("State Details Not Found ID-" + id);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public LgdStateResponse getLgdStateByStateId(Long id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_LGD_STATE_FROM_STATE_ID);
		url = url.concat("/" + id);
		logger.info("Get State Details By URL ======================> " + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(id, headers);
			OneFormResponse oneFormRes = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if(oneFormRes != null && oneFormRes.getStatus() == 200 && oneFormRes.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) oneFormRes.getData(), LgdStateResponse.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("State Details Not Found ID-" + id);
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<MasterResponse> getStateListByCountryId(Long id) throws OneFormException {
		String url = oneFormBaseUrl.concat(REQUEST_STATE_FROM_COUNTRY_ID);
		url = url.concat("/" + id);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(id, headers);
			OneFormResponse comRes= restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			List<MasterResponse> responseList = new ArrayList<>();
			List<Object> objects = ((List<Object>)  comRes.getListData());
			for (Object o : objects) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), MasterResponse.class));
			}
			return responseList;
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
	}


	public List<CityStateResponse> getCityStateMaster() throws OneFormException {
		String url = oneFormBaseUrl.concat(GET_CITY_STATE_MASTER);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(null,headers);
//			List<CityStateResponse> cityStateResponsesList = restTemplate.exchange(url, HttpMethod.GET, entity, List.class).getBody();
			OneFormResponse comRes= restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			List<CityStateResponse> responseList = new ArrayList<>();
			List<Object> objects = ((List<Object>)  comRes.getListData());
			for (Object o : objects) {
				responseList.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), CityStateResponse.class));
			}
			return responseList;
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
	}
	
	public DropDownProxy getNameByKeyAndObjId(DropDownMasterKey key, Integer objId) throws OneFormException {
		String url = oneFormBaseUrl.concat(GET_NAME_BY_KEY_AND_OBJID);
		try {
			url = url.concat("/" + key + "/" + objId);
			logger.info(url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(null, headers);
			OneFormResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if (response != null && response.getStatus() == 200 && response.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) response.getData(), DropDownProxy.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("dropdown is not found key => {}, objId=> {},", key, objId);
		return null;
	}

	public DropDownProxy getIdByKeyAndName(DropDownMasterKey key, String name) throws OneFormException {
		String url = oneFormBaseUrl.concat(GET_ID_BY_KEY_AND_NAME);
		try {
			url = url.concat("/" + key + "/" + name);
			logger.info(url);
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(null, headers);
			OneFormResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if (response != null && response.getStatus() == 200 && response.getData() != null) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) response.getData(), DropDownProxy.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		logger.info("dropdown is not found key => {}, name=> {},", key, name);
		return null;
	}
	
	public PincodeMasterResponse getFirstPincodeMasterDetailsByPincode(String pincode) throws OneFormException {
		String url = oneFormBaseUrl.concat(GET_FIRST_PINCODE_MASTER_BY_PINCODE);
	//	String url = "http://localhost:8053/oneform/pincode/master/getFirstPincodeMasterByPincode/" + pincode;
		url = url.concat("/" + pincode);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			HttpEntity<Long> entity = new HttpEntity<>(null, headers);
			OneFormResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			if(!OPLUtils.isObjectNullOrEmpty(response.getData())) {
				return MultipleJSONObjectHelper.getObjectFromMap((Map<String, Object>) response.getData(), PincodeMasterResponse.class);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
		return null;
	}

	public List<LgdDistrictStateResponse> getLgdDistrictStateMaster() throws OneFormException {
		String url = oneFormBaseUrl.concat(GET_LGD_DISTRICT_STATE_MASTER);
		try {
			HttpHeaders headers = new HttpHeaders();
			setClient(headers);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Long> entity = new HttpEntity<>(null, headers);
			OneFormResponse comRes = restTemplate.exchange(url, HttpMethod.GET, entity, OneFormResponse.class).getBody();
			List<LgdDistrictStateResponse> responses = new ArrayList<>();
			List<Object> objects = ((List<Object>) comRes.getData());
			for (Object o : objects) {
				responses.add(MultipleJSONObjectHelper.getObjectFromMap(((LinkedHashMap<String, Object>) o), LgdDistrictStateResponse.class));
			}
			return responses;
		} catch (Exception e) {
			logger.error(OneformUtils.EXCEPTION, e);
			throw new OneFormException(e.getMessage());
		}
	}
}
