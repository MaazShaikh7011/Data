package com.opl.jns.oneform.api.enums;

public enum CourseType {

	FULL_TIME(1l, "Full Time", "101"), PART_TIME(2l, "Part Time", "102"),Correspondence(3l,"Correspondence", "104"),DISTANCE_EDUCATION(4L,"Distance Education", "103");
	
	private Long id;
	private String value;
	private String schemeParamId;

	private CourseType(Long id, String value, String schemeParamId) {
		this.id = id;
		this.value = value;
		this.schemeParamId = schemeParamId;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getSchemeParamId() {
		return schemeParamId;
	}

	public static CourseType fromId(Long v) {
		for (CourseType c : CourseType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CourseType[] getAll() {
		return CourseType.values();
	}

}
