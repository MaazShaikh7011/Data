package com.opl.jns.oneform.api.enums.mudra;

public enum MudraPensionPlan {

	PRADHAN_MANTRI_SURAKSHA_BIMA_YOJANA(1,"Pradhan Mantri Suraksha Bima Yojana (PMSBY)"),
	PRADHAN_MANTRI_JEEVAN_JYOTI_BIMA_YOJANA(2,"Pradhan Mantri Jeevan Jyoti Bima Yojana (PMJJBY)"),
	ATAL_PENSION_YOJANA(3,"Atal Pension Yojana (APY)"),
	INSURANCE_POLICY(4,"Insurance Policy"),
	PENSION_SCHEME(5,"Pension Scheme");

	private Integer id;
	private String value;

	private MudraPensionPlan(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraPensionPlan fromId(Integer v) {
		for (MudraPensionPlan c : MudraPensionPlan.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraPensionPlan[] getAll() {
		return MudraPensionPlan.values();
	}
}
