package com.opl.jns.oneform.api.enums;

public enum OrganizationType {
	
	GOVERMENT_SECTOR(1L,"Goverment Sector"),
	PUBLIC_LTD(2L,"Public Ltd."),
	PVT_LTD(3L,"Pvt. Ltd."),
	PARTNERSHIP(4L,"Partnership"),
	PROPRIETORSHIP(5L,"Proprietorship"),
	MNC(6L,"MNC"),
	OTHERS(7L,"Others");
	
	private Long id;
	private String value;

	private OrganizationType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static OrganizationType fromId(Long v) {
		for (OrganizationType c : OrganizationType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static OrganizationType[] getAll() {
		return OrganizationType.values();
	}
}
