package com.opl.jns.oneform.api.enums.agri;

public enum ProjectCostStorage {
	
	STORAGE_INFRASTUCTURE(1,"Storage Infrastucture"),
	ANCILLIARY_INFRASTRUCTURE(2,"Ancilliary Infrastructure"),
	COST_OF_CIVIL_STRUCTURE(3,"Cost of civil structure"),
	COST_OF_PRIMARY_PROCESSING(4,"Cost of Primary processing");
	
	private Integer id;
	private String value;
	
	private ProjectCostStorage(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	public static ProjectCostStorage fromId(Integer v) {
		for (ProjectCostStorage c : ProjectCostStorage.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static ProjectCostStorage[] getAll() {
		return ProjectCostStorage.values();
	}
}
