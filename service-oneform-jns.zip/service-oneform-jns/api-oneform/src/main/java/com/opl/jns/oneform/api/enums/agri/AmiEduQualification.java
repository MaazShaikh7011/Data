package com.opl.jns.oneform.api.enums.agri;

public enum AmiEduQualification {
	
	ILLITERATE(1,"Illiterate"),BELOW_METRIC(2, "Below Metric"), ABOVE_METRIC(3, "Above Metric"),UNDER_GRADUATES(4, "Under Graduate"), 
	GRADUATES(5, "Graduate"), POST_GRADUATES(6, "Post Graduate"),
	PROFESSIONALS(7, "Professionals"), OTHERS(8, "Others");
	
	private Integer id;
	private String value;

	private AmiEduQualification(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AmiEduQualification fromId(Integer v) {
		for (AmiEduQualification c : AmiEduQualification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiEduQualification[] getAll() {
		return AmiEduQualification.values();
	}
}
