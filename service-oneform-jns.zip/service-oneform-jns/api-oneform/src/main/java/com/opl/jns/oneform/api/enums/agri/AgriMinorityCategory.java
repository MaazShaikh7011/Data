package com.opl.jns.oneform.api.enums.agri;

public enum AgriMinorityCategory {
	
	BUDDHISTS(1,"Buddhists"),
	MUSLIMS(2,"Muslims"),
	CHRISTIANS(3,"Christians"),
	SIKHS(4,"Sikhs"),
	JAINS(5,"Jains"),
	ZOROASTRIANS(6,"Zoroastrians");

	private Integer id;
	private String value;

	private AgriMinorityCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AgriMinorityCategory fromId(Integer v) {
		for (AgriMinorityCategory c : AgriMinorityCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AgriMinorityCategory[] getAll() {
		return AgriMinorityCategory.values();
	}

}
