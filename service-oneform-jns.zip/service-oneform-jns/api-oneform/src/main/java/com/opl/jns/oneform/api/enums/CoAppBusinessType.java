package com.opl.jns.oneform.api.enums;

public enum CoAppBusinessType {

	PVT_LTD(1l, "Pvt. Ltd."),
	PARTNERSHIP(2l, "Partnership"),
	PROPRIETORSHIP(3l, "Proprietorship"),
	OTHERS(4l, "Others");

	private Long id;
	private String value;


	private CoAppBusinessType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CoAppBusinessType fromId(Long v) {
		for (CoAppBusinessType c : CoAppBusinessType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CoAppBusinessType[] getAll() {
		return CoAppBusinessType.values();
	}

}
