package com.opl.jns.oneform.api.enums.srms;

public enum ProcurementMechanism {

	GeM(1, "GeM"),
	Other(2, "Other (Specify)");
	
	private Integer id;
	private String value;

	private ProcurementMechanism(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ProcurementMechanism fromId(Integer v) {
		for (ProcurementMechanism c : ProcurementMechanism.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ProcurementMechanism[] getAll() {
		return ProcurementMechanism.values();
	}
}
