package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmApplicationStatus {
    ALL(12, "All"),
    INPROGRESS(1, "In-progress"),
    FETCHED(2, "Fetched"),
    FAILED(3, "Failed"),
    INPRINCIPLE(4, "In-Principle"),
    REFFERED(5, "Reffered"),
    SANCTIONED(6, "Sanctioned"),
    DISBURSED(7, "Disbursed"),
    HOLD(8, "Hold"),
    REJECTED(9, "Rejected"),
    HOLD_AFTER_SANCTIONED(10, "Hold After Sanctioned"),
    REJECT_AFTER_SANCTIONED(11, "Reject After Sanctioned");
//    SHG_Name(13,"SHG Name"),
//    SHG_MEMBER_NAME(14,"SHG Member Name"),
//    SHG_CODE(15,"SHG Code"),
//    LOAN_APPLICATION_ID(16,"Loan Application Id"),
//    APPLICATION_CODE(17,"Application Code"),
//    LOAN_APPLICATION_NUMBER(18,"Loan Application Number");

    private Integer id;
    private String value;

    private NrlmApplicationStatus(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmApplicationStatus fromId(Integer v) {
        for (NrlmApplicationStatus c : NrlmApplicationStatus.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmApplicationStatus fromName(String v) {
        for (NrlmApplicationStatus c : NrlmApplicationStatus.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }

    public static NrlmApplicationStatus[] getAll() {
        return NrlmApplicationStatus.values();
    }
}
