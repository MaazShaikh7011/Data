package com.opl.jns.oneform.api.enums.kcc;

public enum SocialCategory {

    OBC(1, "OBC", "B"),
    ST(2, "ST", "T"),
    SC(3, "SC", "S"),
    OTHERS(4, "Others", "O");


    private Integer id;
    private String value;
    private String fruitValue;

    private SocialCategory(Integer id, String value, String fruitValue) {
        this.id = id;
        this.value = value;
        this.fruitValue = fruitValue;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public String getFruitValue() {
        return fruitValue;
    }

    public static SocialCategory fromId(Integer v) {
        for (SocialCategory c : SocialCategory.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static SocialCategory fromFruitValue(String v) {
        for (SocialCategory c : SocialCategory.values()) {
            if (c.fruitValue.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static SocialCategory[] getAll() {
        return SocialCategory.values();
    }
}
