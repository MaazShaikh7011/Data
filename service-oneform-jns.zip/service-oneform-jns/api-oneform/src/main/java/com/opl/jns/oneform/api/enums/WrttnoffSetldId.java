package com.opl.jns.oneform.api.enums;

public enum WrttnoffSetldId {
    RESTRUCTURED_LOAN("00", "Restructured Loan"),
    RESTRUCTURED_LOAN_GOV("01", "Restructured Loan (Govt. Mandated)"),
	WRITTEN_OFF("02", "Written-off"),
    SETTLED("03", "Settled"),
    POST_SETTLED("04", "Post (WO) Settled"),
    ACCOUNT_SOLD("05", "Account Sold"),
    WRITTEN_OFF_AND_ACCOUNT_SOLD("06", "Written Off and Account Sold"),
    ACCLOUNT_PURCHASED("07", "Account Purchased"),
    ACCLOUNT_PURCHASED_AND_WRITTEN_OFF("08", "Account Purchased and Written Off"),
    ACCLOUNT_PURCHASED_AND_SETTLED("09", "Account Purchased and Settled"),
    ACCLOUNT_PURCHASED_AND_RESTRUCTURED("10", "Account Purchased and Restructured"),
    RESTRUCTURED_DUE_TO_NATURAL_CALAMITY("11", "Restructured due to Natural Calamity"),
    RESTRUCTURED_DUE_TO_COVID19("12", "Restructured due to COVID-19");

    private String id;
    private String value;

    private WrttnoffSetldId(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static WrttnoffSetldId fromId(String v) {
        for (WrttnoffSetldId c : WrttnoffSetldId.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static WrttnoffSetldId fromValue(String v) {
        for (WrttnoffSetldId c : WrttnoffSetldId.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static WrttnoffSetldId[] getAll() {
        return WrttnoffSetldId.values();
    }
}
