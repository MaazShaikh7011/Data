package com.opl.jns.oneform.api.enums;

public enum SecurityType {
	
	OWNED_HOUSE_RESIDENCE(1l, "Owned house/Residence "), VEHICLE(2l, "Vehicle"),Others(3l, "Others ");
	
	private Long id;
	private String value;

	private SecurityType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SecurityType fromId(Long v) {
		for (SecurityType c : SecurityType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SecurityType[] getAll() {
		return SecurityType.values();
	}

}
