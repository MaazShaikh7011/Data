package com.opl.jns.oneform.api.enums.swms;

public enum SwmsPurposeLoan {
        WORKING_CAPITAL(1,"Working Capital"),
        ASSETS_ACQUISITION(2,"Assets Acquisition");

        private Integer id;
        private String value;

        private SwmsPurposeLoan(Integer id, String value) {
            this.id = id;
            this.value = value;
        }

        public Integer getId() {
            return id;
        }

        public String getValue() {
            return value;
        }

        public static SwmsPurposeLoan fromId(Integer v) {
            for (SwmsPurposeLoan c : SwmsPurposeLoan.values()) {
                if (c.id.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v != null ? v.toString() : null);
        }

        public static SwmsPurposeLoan[] getAll() {
            return SwmsPurposeLoan.values();
        }


}
