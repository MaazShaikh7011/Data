package com.opl.jns.oneform.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author rahul.meena
 *
 */
@JsonInclude(Include.NON_NULL)
public class MasterResponse {
	
	private Object id;
	private String value;
	private String name;
	private String code;
	private Long mappingId;
	private Integer subsidyCode;
	private String cropTypeLength;
	private Integer natureOfScope;
	

	public Integer getNatureOfScope() {
		return natureOfScope;
	}

	public void setNatureOfScope(Integer natureOfScope) {
		this.natureOfScope = natureOfScope;
	}

	public String getCropTypeLength() {
		return cropTypeLength;
	}

	public void setCropTypeLength(String cropTypeLength) {
		this.cropTypeLength = cropTypeLength;
	}

	public MasterResponse() {
		super();
	}

	public MasterResponse(Object id, String value) {
		super();
		this.id = id;
		this.value = value;
		this.name = value;
	}
	public MasterResponse(Long id, String value,String code,Integer ex) {
		super();
		this.id = id;
		this.value = value;
		this.name = value;
		this.code = code;
	}
	public MasterResponse(Long id, String value,Integer code) {
		super();
		this.mappingId = id;
		this.value = value;
		this.subsidyCode = code;
	}
	
	public MasterResponse(Long id, String value,String code) {
		super();
		this.id = id;
		this.value = value;
		this.code = code;
	}
	
//	public MasterResponse(Long mappingId,Object id, String value) {
//		super();
//		this.id = id;
//		this.value = value;
//		this.mappingId=mappingId;
//	}
//
//	public MasterResponse(Object id, String value, Long mappingId, String sbiCode) {
//		super();
//		this.id = id;
//		this.value = value;
//		this.mappingId=mappingId;
//		this.sbiCode=sbiCode;
//	}
	
	public MasterResponse(Object id, String code, String name,String cropTypeLength,Integer natureOfScope) {
		super();
		this.id = id;
		this.code = code;
		this.name=name;
		this.cropTypeLength=cropTypeLength;
		this.natureOfScope =natureOfScope;
	}
	
	
	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	
	public Long getMappingId() {
		return mappingId;
	}

	public void setMappingId(Long mappingId) {
		this.mappingId = mappingId;
	}
//
//	public Integer getProductId() {
//		return productId;
//	}
//
//	public void setProductId(Integer productId) {
//		this.productId = productId;
//	}
//
//	public String getSbiCode() {
//		return sbiCode;
//	}
//
//	public void setSbiCode(String sbiCode) {
//		this.sbiCode = sbiCode;
//	}
//	public Integer getPurposeTypeId() {
//		return purposeTypeId;
//	}
//
//	public void setPurposeTypeId(Integer purposeTypeId) {
//		this.purposeTypeId = purposeTypeId;
//	}
//	
//	public Integer getVehicleType() {
//		return vehicleType;
//	}
//
//	public void setVehicleType(Integer vehicleType) {
//		this.vehicleType = vehicleType;
//	}
//
//	public Integer getVehicleCategory() {
//		return vehicleCategory;
//	}
//
//	public void setVehicleCategory(Integer vehicleCategory) {
//		this.vehicleCategory = vehicleCategory;
//	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MasterResponse other = (MasterResponse) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value)) {
			return false;
		}
		return true;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public String getSidbiValue() {
//		return sidbiValue;
//	}
//
//	public void setSidbiValue(String sidbiValue) {
//		this.sidbiValue = sidbiValue;
//	}
//
//	public Integer getRate() {
//		return rate;
//	}
//
//	public void setRate(Integer rate) {
//		this.rate = rate;
//	}
//
//	public Long getAmount() {
//		return amount;
//	}
//
//	public void setAmount(Long amount) {
//		this.amount = amount;
//	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	

	public Integer getSubsidyCode() {
		return subsidyCode;
	}

	public void setSubsidyCode(Integer subsidyCode) {
		this.subsidyCode = subsidyCode;
	}

	@Override
	public String toString() {
		return "MasterResponse [id=" + id + ", value=" + value + ", name=" + name + ", code=" + code + ", mappingId="
				+ mappingId + "]";
	}
	
	
	

}
