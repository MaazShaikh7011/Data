package com.opl.jns.oneform.api.enums.standupIndia;

public enum STDConstitution {
//    AOP(1,"Association of Persons (AOP)"),
//    BOI(2,"Body of Individuals (BOI)"),
//    PRIVATE_LIMITED(3,"Private Limited"),
//    PUBLIC_LTD_LISTED(4,"Public Ltd - Listed"),
//    PUBLIC_LTD_UNLISTED(5,"Public Ltd - Unlisted"),
//    ONE_PERSON_COMPANY(6,"One Person Company"),
//    LIMITED_LIABILITY_PARTNERSHIP(7,"Limited Liability Partnership"),
//    PARTNERSHIP(8,"Partnership"),
//    GOVERNMENT_ENTITY(9,"Government Entity"),
//    HUF(10,"HUF"),
//    SOLE_PROPRIETORSHIP(11,"Sole-Proprietorship"),
//    TRUST(12,"Trust"),
//    OTHERS(13,"Others");
	
	AOP(1,"Association of Persons (AOP)"),   
    PRIVATE_LIMITED(3,"Private Limited"),
    PUBLIC_LTD_LISTED(4,"Public Ltd - Listed"),
    PUBLIC_LTD_UNLISTED(5,"Public Ltd - Unlisted"),
    ONE_PERSON_COMPANY(6,"One Person Company"),
	LIMITED_LIABILITY_PARTNERSHIP(9,"Limited Liability Partnership"),	
    PARTNERSHIP(8,"Partnership"),
    GOVERNMENT_ENTITY(10,"Government Entity"),	
    HUF(11,"HUF"),
    SOLE_PROPRIETORSHIP(12,"Sole-Proprietorship"),
    OTHERS(14,"Others");

    private Integer id;
    private String value;

    private STDConstitution(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static STDConstitution fromId(Integer v) {
        for (STDConstitution c : STDConstitution.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static STDConstitution[] getAll() {
        return STDConstitution.values();
    }
}
