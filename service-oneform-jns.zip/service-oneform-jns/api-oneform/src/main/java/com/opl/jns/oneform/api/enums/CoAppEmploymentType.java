package com.opl.jns.oneform.api.enums;

public enum CoAppEmploymentType {

	SALARIED(1L,"Salaried"), SELF_EMPLOYED(2L,"Self Employed"),PROFESSIONAL(3L,"Professional"),Others(4L,"Others ");
	
	private Long id;
	private String value;
	
	private CoAppEmploymentType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CoAppEmploymentType fromId(Long v) {
		for (CoAppEmploymentType c : CoAppEmploymentType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CoAppEmploymentType[] getAll() {
		return CoAppEmploymentType.values();
	}
}
