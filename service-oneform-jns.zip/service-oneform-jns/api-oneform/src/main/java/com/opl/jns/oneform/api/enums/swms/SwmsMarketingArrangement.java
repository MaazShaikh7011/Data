package com.opl.jns.oneform.api.enums.swms;

public enum SwmsMarketingArrangement {
	FIRM_MARKETING_ARRANGEMENT(1,"Firm Marketing arrangement/ tie-up for output"),
	NO_MARKETING_ARRANGEMENT(2,"No Marketing arrangement/ tie-up, but product easily marketable"),
	NO_ARRANGEMENT(3,"No arrangement/ tie-up");
	
	private Integer id;
	private String value;

	private SwmsMarketingArrangement(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsMarketingArrangement fromId(Integer v) {
		for (SwmsMarketingArrangement c : SwmsMarketingArrangement.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsMarketingArrangement[] getAll() {
		return SwmsMarketingArrangement.values();
	}
}
