package com.opl.jns.oneform.api.enums;

public enum ResidenceType {

	OWNED(1l, "Owned "), RENTAL(2l, "Rental");
	
	private Long id;
	private String value;

	private ResidenceType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ResidenceType fromId(Long v) {
		for (ResidenceType c : ResidenceType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ResidenceType[] getAll() {
		return ResidenceType.values();
	}

}
