package com.opl.jns.oneform.api.enums.clap;

public enum ClapHouseCategory {

    EWC(1,"EWS"),
    LIG(2,"LIG"),
    MIG_1(3,"MIG-I"),
    MIG_2(3,"MIG-II");

    private Integer id;
    private String value;

    private ClapHouseCategory(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static ClapHouseCategory fromId(Integer v) {
        for (ClapHouseCategory c : ClapHouseCategory.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static ClapHouseCategory[] getAll() {
        return ClapHouseCategory.values();
    }
}
