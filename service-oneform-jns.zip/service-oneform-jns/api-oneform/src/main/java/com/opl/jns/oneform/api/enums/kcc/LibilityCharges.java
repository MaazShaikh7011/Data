package com.opl.jns.oneform.api.enums.kcc;

/**
 * @author rahul.meena
 *
 */
public enum LibilityCharges {
	
	PUBLIC_LIABILITY(1l, "Public Liability"),
	GOVERNMENT_LIABILITY(2l, "Government Liability");

	private Long id;
	private String value;

	private LibilityCharges(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static LibilityCharges fromId(Long v) {
		for (LibilityCharges c : LibilityCharges.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static LibilityCharges[] getAll() {
		return LibilityCharges.values();
	}

}
