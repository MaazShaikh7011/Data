package com.opl.jns.oneform.api.enums;

public enum Month {

	JANUARY(0l, "JANUARY", "JANUARY"),
	FEBRUARY(1l, "FEBRUARY", "FEBRUARY"),
	MARCH(2l, "MARCH", "MARCH"),
	APRIL(3l, "APRIL", "APRIL"),
	MAY(4l, "MAY", "MAY"),
	JUNE(5l, "JUNE", "JUNE"),
	JULY(6l, "JULY", "JULY"),
	AUGUST(7l, "AUGUST", "AUGUST"),
	SEPTEMBER(8l, "SEPTEMBER", "SEPTEMBER"),
	OCTOBER(9l, "OCTOBER", "OCTOBER"),
	NOVEMBER(10l, "NOVEMBER", "NOVEMBER"),
	DECEMBER(11l, "DECEMBER", "DECEMBER");
	
	private Long id;
	private String value;
	private String name;

	private Month(Long id, String value, String name) {
		this.id = id;
		this.value = value;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getName() {
		return name;
	}

	public static Month fromId(Long v) {
		for (Month c : Month.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Month[] getAll() {
		return Month.values();
	}
}
