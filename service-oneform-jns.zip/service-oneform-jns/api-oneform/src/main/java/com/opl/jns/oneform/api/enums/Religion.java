package com.opl.jns.oneform.api.enums;

public enum Religion {
	CHRISTIAN(5L,"Christian"),
	HINDU(1L,"Hindu"),
	JAIN(3L,"Jain"),
	MUSLIM(2L,"Muslim"),
	PARSI(4L,"Parsi"),	
	SHIKH(6L,"Shikh"),
	OTHER(7L,"Other");
	
	private Long id;
	private String value;

	private Religion(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Religion fromId(Long v) {
		for (Religion c : Religion.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Religion[] getAll() {
		return Religion.values();
	}
}
