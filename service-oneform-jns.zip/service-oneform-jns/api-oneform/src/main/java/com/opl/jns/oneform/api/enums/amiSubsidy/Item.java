package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum Item {
	
	CIVIL_WORK(1, "Civil Work"), PLANT_AND_MACHINERY(2, "Plant & Machinery"), ALLIED_ANCIALLARY_FACILITIES(3, "Allied / Anciallary Facilities");

	private Integer id;
	private String value;

	private Item(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Item fromId(Integer v) {
		for (Item c : Item.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Item[] getAll() {
		return Item.values();
	}

}
