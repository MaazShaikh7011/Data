package com.opl.jns.oneform.api.enums.dayNulm;

public enum NulmLoanType {
    WORKING_CAPITAL(1, "Working capital"), TERM_LOAN(2, "Term loan"),COMPOSITE_LOAN(3, "Composite loan (WC + TL)");

    private Integer id;
    private String value;

    private NulmLoanType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NulmLoanType fromId(Integer v) {
        for (NulmLoanType c : NulmLoanType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NulmLoanType[] getAll() {
        return NulmLoanType.values();
    }
}
