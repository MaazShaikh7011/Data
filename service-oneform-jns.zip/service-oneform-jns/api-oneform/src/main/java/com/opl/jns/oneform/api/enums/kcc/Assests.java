package com.opl.jns.oneform.api.enums.kcc;

public enum Assests {
	
	LAND_AGRICULTURAL(1l, "Land (Agricultural)"), LAND_NON_AGRICULTURAL(2l, "Land (Non-Agricultural)"),
	HOUSE_BUILDING(3l, "House/Building"), SHED_FARM_TRACTOR(4l, "Shed (Farm/Tractor)"),
	FISH_POND_TANK(5l, "Fish Pond / Tank"), FARM_EQUIPMENTS(6l, "Farm equipments"), LIVESTOCK(7l, "Livestock"),
	CASH_BANK_BALANCE(8l, "Cash / Bank Balance");

	private Long id;
	private String value;

	private Assests(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Assests fromId(Long v) {
		for (Assests c : Assests.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Assests[] getAll() {
		return Assests.values();
	}
}
