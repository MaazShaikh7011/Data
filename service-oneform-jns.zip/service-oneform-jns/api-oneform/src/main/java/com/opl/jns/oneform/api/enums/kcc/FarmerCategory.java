package com.opl.jns.oneform.api.enums.kcc;

public enum FarmerCategory {

	SCIENTIFIC(1l, "Scientific"),
	PROGRESSIVE(2l, "Progressive"), 
	TRADITIONAL(3l, "Traditional");
	

	private Long id;
	private String value;

	private FarmerCategory(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}


	public static FarmerCategory fromId(Long v) {
		for (FarmerCategory c : FarmerCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static FarmerCategory[] getAll() {
		return FarmerCategory.values();
	}

}
