package com.opl.jns.oneform.api.enums.mudra;

public enum MudraNoOfEmployeesOrWorkers {

	ZERO(1,"0"),
	ONE(2,"1"),
	TWO(3,"2"),
	THREE(4,"3"),
	FOUR(5,"4"),
	FIVE_AND_ABOVE(6,"5 & Above");

	private Integer id;
	private String value;

	private MudraNoOfEmployeesOrWorkers(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraNoOfEmployeesOrWorkers fromId(Integer v) {
		for (MudraNoOfEmployeesOrWorkers c : MudraNoOfEmployeesOrWorkers.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraNoOfEmployeesOrWorkers fromName(String v) {
		for (MudraNoOfEmployeesOrWorkers c : MudraNoOfEmployeesOrWorkers.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraNoOfEmployeesOrWorkers[] getAll() {
		return MudraNoOfEmployeesOrWorkers.values();
	}
}
