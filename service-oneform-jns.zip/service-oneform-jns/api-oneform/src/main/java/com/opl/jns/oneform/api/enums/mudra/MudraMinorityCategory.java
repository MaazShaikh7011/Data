package com.opl.jns.oneform.api.enums.mudra;

public enum MudraMinorityCategory {

	BUDDHISTS(1,"Buddhists"),
	MUSLIMS(2,"Muslims"),
	CHRISTIANS(3,"Christians"),
	SIKHS(4,"Sikhs"),
	JAINS(5,"Jains"),
	ZOROASTRIANS(6,"Zoroastrians");

	private Integer id;
	private String value;

	private MudraMinorityCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraMinorityCategory fromId(Integer v) {
		for (MudraMinorityCategory c : MudraMinorityCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraMinorityCategory[] getAll() {
		return MudraMinorityCategory.values();
	}
}
