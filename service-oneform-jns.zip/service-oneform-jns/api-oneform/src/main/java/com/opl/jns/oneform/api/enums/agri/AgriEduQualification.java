package com.opl.jns.oneform.api.enums.agri;

public enum AgriEduQualification {
	
	GRADUATE(1,"Graduate in Agriculture and allied subjects​"),
	MASTERS_IN_AGRICULTURE_ALLIED_DISCIPLINES(2,"Masters in Agriculture & allied disciplines"),
	PHD(3,"Ph.D in Agriculture & allied disciplines"),
	DEGREE(4,"Degree in Agriculture & allied disciplines"),
	PG_DIPLOMA(5,"PG Diploma in Agri with Degree in Biological Sciences"),
	DIPLOMA_IN_AGRICULTURE(6,"Diploma in Agriculture"),
	INTERMEDIATE_IN_AGRICULTURE(7,"Intermediate in Agriculture"),
	OTHERS(8,"Others (Specify)");

	private Integer id;
	private String value;

	private AgriEduQualification(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AgriEduQualification fromId(Integer v) {
		for (AgriEduQualification c : AgriEduQualification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AgriEduQualification[] getAll() {
		return AgriEduQualification.values();
	}
}
