package com.opl.jns.oneform.api.enums.srms;

public enum ProjectType {
	
	SANITATION_PROJECTS(1, "Sanitation Projects"),
	OTHER_PROJECT(2, "Other Project");	
	
	private Integer id;
	private String value;

	private ProjectType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ProjectType fromId(Integer v) {
		for (ProjectType c : ProjectType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ProjectType[] getAll() {
		return ProjectType.values();
	}

}
