package com.opl.jns.oneform.api.enums.kcc;

public enum YearApiSeasonMaster {

    KHARIF(1,"Kharif"),
    RABI(2,"Rabi"),
    SUMMER(3,"Summer"),
    PERENNIAL_CROP(4,"Perennial Crop");

    private Integer id;
    private String value;

    private YearApiSeasonMaster(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static YearApiSeasonMaster fromId(Integer v) {
        for (YearApiSeasonMaster c : YearApiSeasonMaster.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static YearApiSeasonMaster[] getAll() {
        return YearApiSeasonMaster.values();
    }
}
