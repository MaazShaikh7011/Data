package com.opl.jns.oneform.api.enums.kcc;

public enum SateliteApiType {

    GEO_SPEC_PUSH_DATA(1, "Push Data Geo Spec"),
    GEO_SPEC(2, "FHC Geo Spec"),
    MANTLE_LAB(3, "MantleLab"),
    NEW_KCC_REQUEST_SKY_MET(4, "New Kcc reqest skymate");;

    private Integer id;
    private String value;

    private SateliteApiType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static SateliteApiType fromId(Integer v) {
        for (SateliteApiType c : SateliteApiType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static SateliteApiType[] getAll() {
        return SateliteApiType.values();
    }
}
