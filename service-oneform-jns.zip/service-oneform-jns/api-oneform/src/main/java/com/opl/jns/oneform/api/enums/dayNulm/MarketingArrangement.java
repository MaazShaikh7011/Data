package com.opl.jns.oneform.api.enums.dayNulm;

public enum MarketingArrangement {
    TIEUP_ARRANGEMENT(3l,"Tie up Arrangement"),REGULARBUYER(1l, "Regular Buyers"), OTHERS(2l, "Others");

    private Long id;
    private String value;

    private MarketingArrangement(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static MarketingArrangement fromId(Long v) {
        for (MarketingArrangement c : MarketingArrangement.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static MarketingArrangement[] getAll() {
        return MarketingArrangement.values();
    }
}
