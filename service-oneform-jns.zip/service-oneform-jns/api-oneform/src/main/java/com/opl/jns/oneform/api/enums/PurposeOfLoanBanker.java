package com.opl.jns.oneform.api.enums;

public enum PurposeOfLoanBanker {
	PURCHASE_OF_NEW_OLD_HOUSE(1L, "Purchase of New / Old House", "1"),
	PURCHASE_OF_NONAGRICULTURAL_PLOT_OF_LAND_FOR_CONSTRUCTING_RESIDENTIAL_UNIT(2l,
			"Purchase of non-agricultural plot of Land for constructing residential unit", "1"),
	CONSTRUCTION_OF_NEW_RESIDENTIAL_UNIT(3l, "Construction of new residential unit", "2"),
	COMPLETION_OF_UNDER_CONSTRUCTION_RESIDENTIAL_UNIT(4l, "Completion of under construction residential unit", "2"),
	RENOVATION_OF_EXISTING_RESIDENTIAL_UNIT(5L,
			"Renovation of existing residential unit( Fixed furnishing , Immovable enhancement which added to the value)",
			"3"),
	EXPANSION_OF_HOUSE_FLAT_BUNGLOW(6L, "Expansion of House/Flat/Bunglow", "3");

	private Long id;
	private String value;
	private String code;


	private PurposeOfLoanBanker(Long id, String value, String code) {
		this.id = id;
		this.value = value;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getCode() {
		return code;
	}

	public static PurposeOfLoanBanker fromId(Long v) {
		for (PurposeOfLoanBanker c : PurposeOfLoanBanker.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PurposeOfLoanBanker[] getAll() {
		return PurposeOfLoanBanker.values();
	}

}
