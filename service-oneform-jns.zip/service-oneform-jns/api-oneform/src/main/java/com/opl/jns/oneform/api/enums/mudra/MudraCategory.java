package com.opl.jns.oneform.api.enums.mudra;

public enum MudraCategory {

	GENERAL(1,"General"),
	SC(2,"SC"),
	ST(3,"ST"),
	OBC(4,"OBC"),
	OTHERS(5,"Others"),
	MINORITY_COMMUNITY(6,"Minority Community"),
	WOMEN(7,"Women");

	private Integer id;
	private String value;

	private MudraCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraCategory fromId(Integer v) {
		for (MudraCategory c : MudraCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static MudraCategory fromName(String v) {
		for (MudraCategory c : MudraCategory.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static MudraCategory[] getAll() {
		return MudraCategory.values();
	}
}
