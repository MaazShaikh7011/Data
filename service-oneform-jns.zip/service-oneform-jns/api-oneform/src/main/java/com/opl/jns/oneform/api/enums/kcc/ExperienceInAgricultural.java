package com.opl.jns.oneform.api.enums.kcc;

public enum ExperienceInAgricultural {

	MORE_THAN_FIVE_YEARS(1l, "More than 5 years"), THREE_TO_FIVE_YEARS(2l, "3 to 5 years"),
	UPTO_THREE_YEARS(3l, "Upto 3 years");
	

	private Long id;
	private String value;

	private ExperienceInAgricultural(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}


	public static ExperienceInAgricultural fromId(Long v) {
		for (ExperienceInAgricultural c : ExperienceInAgricultural.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ExperienceInAgricultural[] getAll() {
		return ExperienceInAgricultural.values();
	}

}
