package com.opl.jns.oneform.api.enums;

public enum AccountTypeTempEnum {
	
	AUTO_LOAN_PERSONAL("01","Auto Loan (Personal)", "Auto Loan", "1", "Auto Loan (Personal)", 1l),
	HOUSING_LOAN("02","Housing Loan", "Housing Loan", "2", "Housing Loan", 2l),
	PROPERTY_LOAN("03","literal property loan", "Property Loan", "3", "Property Loan", 3l),
	LOAN_AGAINST_SHARES_SECURITIES("04","Loan Against SHARES/Securities", "Loan against Shares/Securities", "4", "Loan Against Shares / Securities", 4l),
	PERSONAL_LOAN("05","Personal Loan", "Personal Loan", "5", "Personal Loan", 5l),
	CONSUMER_LOAN("06","Consumer Loan", "Consumer Loan", "6", "Consumer Loan", 6l),
	GOLD_LOAN("07","literal gold loan", "Gold Loan", "7", "Gold Loan", 7l),
	EDUCATION_LOAN("08","Education Loan", "Education Loan", "8", "Education Loan", 8l),
	LOAN_TO_PROFESSIONAL("09","Loan to Professional", "Loan to Professional", "9", "Loan to Professional", 9l),
	CREDIT_CARD("10","Credit Card", "Credit Card", "10", "Credit Card", 10l),
	LEASING("11","Leasing", "Lease", "11", "Leasing", 11l),
	OVERDRAFT("12","literal overdraft", "Overdraft", "12", "Overdraft", 12l),
	TWO_WHEELER_LOAN("13","Two wheeler Loan", "Two-wheeler Loan", "13", "Two-Wheeler Loan", 13l),
	NON_FUNDED_CREDIT_FACILITY("14","Non Funded Credit Facility", "Non-Funded Credit Facility", "14", "Non-Funded Credit Facility", 14l),
	LOAN_AGAINST_BANK_DEPOSITS("15","Loan Against Bank Deposits", "Loan Against Bank Deposits", "15", "Loan Against Bank Deposits", 15l),
	FLEET_CARD("16","Fleet Card", "Fleet Card", "16", "Fleet Card", 16l),
	COMMERCIAL_VEHICLE_LOAN("17","Commercial Vehicle Loan", "Commercial Vehicle Loan", "17", "Commercial Vehicle Loan", 17l),
	TELCO_WIRELESS("18","Telco – Wireless", "Telco - Wireless", "18", "Telco Wireless", 18l),
	TELCO_BROADBAND("19","Telco – Broadband", "Telco - Broadband", "19", "Telco Broadband", 19l),
	TELCO_LANDLINE("20","Telco – Landline", "Telco - Landline", "20", "Telco Landline", 20l),
	SECURED_CREDIT_CARD("31","Secured Credit Card", "Secured Credit Card", "31", "Secured Credit Card", 31l),
	USED_CAR_LOAN("32","Used Car Loan", "Used Car Loan", "32", "Used Car Loan", 32l),
	CONSTRUCTION_EQUIPMENT_LOAN("33","Construction Equipment Loan", "Construction Equipment Loan", "33", "Construction Equipment Loan", 33l),
	TRACTOR_LOAN("34","Tractor Loan", "Tractor Loan", "34", "Used Tractor Loan", 34l),
	CORPORATE_CREDIT_CARD("35","Corporate Credit Card", "Corporate Credit Card", "35", "Corporate Credit Card", 35l),
	KISAN_CREDIT_CARD("36","Kisan Credit Card", "", "36", "Kisan Credit Card", 36l), 
	LOAN_ON_CREDIT_CARD("37","Loan on Credit Card","", "37", "Loan on Credit Card", 37l), 
	PRIME_MINISTER_JAAN_DHAN_YOJANA_OVERDRAFT("38","Prime Minister Jaan Dhan Yojana - Overdraft", "","38", "Prime Minister Jaan Dhan Yojana - Overdraft", 38l), 
	MUDRA_LOANS_SHISHU_KISHOR_TARUN("39","Mudra Loans – Shishu / Kishor / Tarun", "", "39", "Mudra Loans – Shishu / Kishor / Tarun", 39l), 
	MICROFINANCE_BUSINESS_LOAN("40","Microfinance – Business Loan", "MicroFinance Business Loan", "", "Microfinance Business Loan", 40l),
	MICROFINANCE_PERSONAL_LOAN("41","Microfinance – Personal Loan", "MicroFinance Personal Loan", "", "Microfinance Personal Loan", 41l),
	MICROFINANCE_HOUSING_LOAN("42","Microfinance – Housing Loan", "MicroFinance Housing Loan", "", "Microfinance Housing Loan", 42l),
	MICROFINANCE_OTHER("43","Microfinance – Other", "MicroFinance Others", "43", "Microfinance Others", 43l),
	PRADHAN_MANTRI_AWAS_YOJANA_CREDIT_LINK_SUBSIDY_SCHEME_MAY_CLSS("44","Pradhan Mantri Awas Yojana - Credit Link Subsidy Scheme MAY CLSS", "", "", "Pradhan Mantri Awas Yojana - CLSS", 44l),
	BUSINESS_LOAN_SECURED("50","Business Loan - Secured", "", "", "Business Loan - Secured", 50l), 
	BUSINESS_LOAN_GENERAL("51","Business Loan – General", "Business Loan", "51", "Business Loan General", 51l),
	BUSINESS_LOAN_PRIORITY_SECTOR_SMALL_BUSINESS("52","Business Loan – Priority Sector – Small Business", "Business Loan-Priority Sector-Small Business", "52", "Business Loan Priority Sector Small Business", 52l),
	BUSINESS_LOAN_PRIORITY_SECTOR_AGRICULTURE("53","Business Loan – Priority Sector – Agriculture", "Business Loan - Priority Sector- Agriculture", "53", "Business Loan Priority Sector Agriculture", 53l),
	BUSINESS_LOAN_PRIORITY_SECTOR_OTHERS("54","Business Loan – Priority Sector – Others", "Business Loan - Priority Sector- Others", "54", "Business Loan Priority Sector Others", 54l),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_GENERAL("55","Business NON_Funded Credit Facility – General", "Business Non-Funded Credit Facility", "55", "Business Non-Funded Credit Facility General", 55l),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_SMALL_BUSINESS("56","Business NON_Funded Credit Facility – Priority Sector – Small Business", "Business Non-Funded Credit Facility - Priority Sector - Small Business", "56", "Business Non-Funded Credit Facility-Priority Sector- Small Business", 56l),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_AGRICULTURE("57","Business NON_Funded Credit Facility – Priority Sector – Agriculture", "Business Non-Funded Credit Facility - Priority Sector - Agriculture", "57", "Business Non-Funded Credit Facility-Priority Sector-Agriculture", 57l),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_OTHERS("58","Business NON_Funded Credit Facility – Priority SECTOR_Others", "Business Non-Funded Credit Facility - Priority Sector - Other", "58", "Business Non-Funded Credit Facility-Priority Sector-Others", 58l),
	BUSINESS_LOAN_AGAINST_BANK_DEPOSITS("59","Business Loan Against Bank Deposits", "Business Loan Against Bank Deposits", "59", "Business Loan Against Bank Deposits", 59l),
	BUSINESS_LOAN_UNSECURED("61","Business Loan - Unsecured", "", "61", "Business Loan Unsecured", 61l), 
	MICROFINANCE_DETAILED_REPORT_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("80","Microfinance Detailed Report (Applicable to Enquiry Purpose only)", "", "", "", 80l),
	SUMMARY_REPORT_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("81","Summary Report (Applicable to Enquiry Purpose only)", "", "", "", 81l), 
	LOCATE_PLUS_FOR_INSURANCE_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("88","Locate Plus for Insurance (Applicable to Enquiry Purpose only)", "", "", "", 88l),
	ACCOUNT_REVIEW_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("90","Account Review (Applicable to Enquiry Purpose only)", "", "", "", 90l),
	RETRO_ENQUIRY_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("91","Retro Enquiry (Applicable to Enquiry Purpose only)", "", "", "", 91l),
	LOCATE_PLUS_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("92","Locate Plus (Applicable to Enquiry Purpose only)", "", "", "", 92l),
	ADVISER_LIABILITY_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("97","Adviser Liability (Applicable to Enquiry Purpose only)", "", "", "", 97l),
	OTHER("105","Other", "Other", "105", "Other", 105l),
	SECURED_ACCOUNT_GROUP_FOR_PORTFOLIO_REVIEW_RESPONSE("98","Secured (Account Group for Portfolio Review response)", "", "", "", 98l),
	UNSECURED_ACCOUNT_GROUP_FOR_PORTFOLIO_REVIEW_RESPONSE("99","Unsecured (Account Group for Portfolio Review response)", "", "", "", 99l),
	// Not Matched loan type with cibil
	AUTO_LEASE("100","Auto Lease", "Auto Lease", "", "", 100l),
	STAFF_LOAN("60","Staff Loan", "Staff Loan", "60", "Staff Loan", 60l),
	DISCLOSURE("101","Disclosure", "Disclosure", "", "", 101l);
  


	private String id;
	private String value;
	private String equifaxValue;
	private String experianValue;
	private String highmarkValue;
	private Long mappingId;

	private AccountTypeTempEnum(String id, String value, String equifaxValue, String experianValue, String highmarkValue,Long mappingId) {
		this.id = id;
		this.value = value;
		this.equifaxValue = equifaxValue;
		this.experianValue = experianValue;
		this.highmarkValue = highmarkValue;
		this.mappingId = mappingId;
	}

	public String getValue() {
		return this.value;
	}

	public String getId() {
		return this.id;
	}

	public Long getMappingId() {
		return mappingId;
	}

	public static AccountTypeTempEnum fromValue(String v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

//	public static AccountTypeTempEnum fromId(String v) {
//		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
//			if (c.id.equals(v) || Integer.parseInt(v) == Integer.parseInt(c.id)) {
//				return c;
//			}
//		}
//		throw new IllegalArgumentException(v);
//	}

	public static AccountTypeTempEnum fromEquifaxValue(String v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.equifaxValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static AccountTypeTempEnum fromExperianRetailValue(String v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.experianValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	public static AccountTypeTempEnum fromHighmarkRetailValue(String v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.highmarkValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	public static AccountTypeTempEnum fromCibilId(Long v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.mappingId.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	
	public static AccountTypeTempEnum fromId(Long v) {
		for (AccountTypeTempEnum c : AccountTypeTempEnum.values()) {
			if (c.mappingId.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	
    public static AccountTypeTempEnum[] getAll() {
        return AccountTypeTempEnum.values();
    }

}
