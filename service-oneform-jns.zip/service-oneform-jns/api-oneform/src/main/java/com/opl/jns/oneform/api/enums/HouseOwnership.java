package com.opl.jns.oneform.api.enums;

public enum HouseOwnership {
	RENTED(1L,"Rented"),
	OWNER(2L,"Owned"),
	INHERITED(3L,"Inherited"),
	OTHER(4L,"Other"),
	COMPANY_LEASED(5L,"Company leased");
	
	private Long id;
	private String value;

	private HouseOwnership(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static HouseOwnership fromId(Long v) {
		for (HouseOwnership c : HouseOwnership.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static HouseOwnership[] getAll() {
		return HouseOwnership.values();
	}


}
