package com.opl.jns.oneform.api.enums.srms;

public enum PurposeEquipment {

	SEWER_CLEANING(1, "Sewer Cleaning"),
	SEPTIC_TANK_CLEANING(2, "Septic Tank Cleaning"),
	OTHER_CLEANING_EQUIPMENT(3, "Other Cleaning Equipment (Specify)");
	
	private Integer id;
	private String value;

	private PurposeEquipment(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static PurposeEquipment fromId(Integer v) {
		for (PurposeEquipment c : PurposeEquipment.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PurposeEquipment[] getAll() {
		return PurposeEquipment.values();
	}
}
