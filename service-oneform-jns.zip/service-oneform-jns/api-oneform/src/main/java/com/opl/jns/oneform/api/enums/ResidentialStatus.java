package com.opl.jns.oneform.api.enums;

public enum ResidentialStatus {
	
	RESIDENT_IN_INDIA(1l, "Resident in India"), NON_RESIDENT (2l, "Non-Resident ");
	
	private Long id;
	private String value;

	private ResidentialStatus(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ResidentialStatus fromId(Long v) {
		for (ResidentialStatus c : ResidentialStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ResidentialStatus[] getAll() {
		return ResidentialStatus.values();
	}


}
