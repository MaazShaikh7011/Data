package com.opl.jns.oneform.api.enums;

public enum CourseName {
	
	GRADUATES(1l,"Graduate", "97"),POST_GRADUATES(2L,"Post Graduate", "98"),M_PHIL(3L,"M.Phil", "100"),PH_D(4L,"Ph.D", "99"),
	DIPLOMA(5L,"Diploma", "100"),PROFESSIONALS(6l,"Professionals", "100"),OTHER_SPECIFY(7l,"Other (Specify)", "100");
	
	private Long id;
	private String value;
	private String schemeParamId;

	private CourseName(Long id, String value, String schemeParamId) {
		this.id = id;
		this.value = value;
		this.schemeParamId = schemeParamId;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getSchemeParamId() {
		return schemeParamId;
	}

	public static CourseName fromId(Long v) {
		for (CourseName c : CourseName.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CourseName[] getAll() {
		return CourseName.values();
	}

}
