package com.opl.jns.oneform.api.enums;

public enum CreditTypeRetail {
	AUTO_LOAN_PERSONAL(1L, "Auto Loan (Personal)"), CONSUMER_LOAN(6L, "Consumer Loan"), CREDIT_CARD(8L, "Credit Card"),
	EDUCATION_LOAN(7L, "Education Loan"), HOUSING_LOAN(2L, "Housing Loan"),
	LOAN_AGAINST_SHARES_SECURITIES(4L, "Loan Against SHARES/Securities"), PERSONAL_LOAN(5L, "Personal Loan"),
	PROPERTY_LOAN(3L, "Property Loan"), OTHER(9L, "Other");

	private Long id;
	private String value;
	
	private CreditTypeRetail(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CreditTypeRetail fromId(Long v) {
		for (CreditTypeRetail c : CreditTypeRetail.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CreditTypeRetail[] getAll() {
		return CreditTypeRetail.values();
	}
}
