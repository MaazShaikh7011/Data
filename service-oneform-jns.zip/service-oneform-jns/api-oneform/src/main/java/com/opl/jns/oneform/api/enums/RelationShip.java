package com.opl.jns.oneform.api.enums;

public enum RelationShip {
	
	FATHER(1l, "Father"), MOTHER(2l, "Mother "), SON(3l, "Son"),DAUGHTER(4l, "Daughter");
	
	private Long id;
	private String value;

	private RelationShip(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static RelationShip fromId(Long v) {
		for (RelationShip c : RelationShip.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RelationShip[] getAll() {
		return RelationShip.values();
	}


}
