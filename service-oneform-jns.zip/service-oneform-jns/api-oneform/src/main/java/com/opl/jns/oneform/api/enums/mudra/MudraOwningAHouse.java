package com.opl.jns.oneform.api.enums.mudra;

public enum MudraOwningAHouse {

	RENTED_FOR_MORE_THAN_THREE_YEAR(1,"Rented for more than 3 year"),
	RENTED_FOR_UPTO_THREE_YEARS(2,"Rented for upto 3 years"),
	OWING_A_HOUSE_NOT_MORTGAGED_SAME_PLACE(3,"Owning a house – Not Mortgaged – Same Place"),
	OWNING_A_HOUSE_NOT_MORTGAGED_OTHER_PLACE(4,"Owning a house - Not Mortgaged - Other Place"),
	OWING_A_HOUSE_MORTGAGED_IN_THE_SAME_PLACE(5,"Owning a house – Mortgaged – In the same place"),
	OWING_A_HOUSE_MORTGAGED_AT_OTHER_PLACE(6,"Owning a house – Mortgaged – At other place"),
	HOUSE_OWNED_BY_SPOUSE(7,"House owned by spouse"),
	LIVING_WITH_FAMILY(8,"Living with Family"),
	OTHERS(9,"Others");

	private Integer id;
	private String value;

	private MudraOwningAHouse(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraOwningAHouse fromId(Integer v) {
		for (MudraOwningAHouse c : MudraOwningAHouse.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraOwningAHouse[] getAll() {
		return MudraOwningAHouse.values();
	}
}
