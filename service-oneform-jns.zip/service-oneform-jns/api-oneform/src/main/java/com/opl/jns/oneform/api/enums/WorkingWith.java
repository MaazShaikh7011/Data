package com.opl.jns.oneform.api.enums;

public enum WorkingWith {

	GOVERNMENT_SECTOR(1l, "Government Sector"), 
	PUBLIC_LTD(2l, "Public Ltd."), 
	Pvt_Ltd(3l, "Pvt. Ltd."),
	PARTNERSHIP(4l, "Partnership"), 
	PROPRIETORSHIP(5l, "Proprietorship"), 
	MNC(6l, "MNC"), 
	Others(7l, "Others ");

	private Long id;
	private String value;

	private WorkingWith(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static WorkingWith fromId(Long v) {
		for (WorkingWith c : WorkingWith.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static WorkingWith[] getAll() {
		return WorkingWith.values();
	}

}
