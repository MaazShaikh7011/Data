package com.opl.jns.oneform.api.enums.kcc;

public enum TypeOfLandOwnership {

	FULLY_OWNED(1l, "Fully Owned"), TENANT_LEASED_OTHER(2l, "Tenant / Leased / Other");
	

	private Long id;
	private String value;

	private TypeOfLandOwnership(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}


	public static TypeOfLandOwnership fromId(Long v) {
		for (TypeOfLandOwnership c : TypeOfLandOwnership.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static TypeOfLandOwnership[] getAll() {
		return TypeOfLandOwnership.values();
	}

}
