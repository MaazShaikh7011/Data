package com.opl.jns.oneform.api.enums.swms;

public enum SwmsWeavingType {
	SILK_WEAVING(1,"Silk Weaving"),
	OTHER_WEAVING(2,"Other Weaving");
	
	private Integer id;
	private String value;

	private SwmsWeavingType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsWeavingType fromId(Integer v) {
		for (SwmsWeavingType c : SwmsWeavingType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsWeavingType[] getAll() {
		return SwmsWeavingType.values();
	}
}
