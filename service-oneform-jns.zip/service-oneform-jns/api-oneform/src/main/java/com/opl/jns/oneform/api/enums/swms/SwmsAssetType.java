package com.opl.jns.oneform.api.enums.swms;

public enum SwmsAssetType {
	HAND_LOOM(1,"Hand Loom"),
	SAVING_WITH(2,"Saving with banks"),
	POST_OFFICE_OR_OTHER_SAVINGS(3,"Post office or other Savings"),
	HOUSEHOLD_DURABLES(4,"Household Durables such as TV, Fridge, etc."),
	VEHICLES(5,"Vehicles"),
	OTHER_MOVABLE_PROPERTY(6,"Other movable properties"),
	OTHER_IMMOVABLE_PROPERTY(7,"House or any other Immovable properties");
	
	private Integer id;
	private String value;

	private SwmsAssetType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsAssetType fromId(Integer v) {
		for (SwmsAssetType c : SwmsAssetType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsAssetType[] getAll() {
		return SwmsAssetType.values();
	}
}
