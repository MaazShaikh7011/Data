package com.opl.jns.oneform.api.enums;

public enum LoanPurpose {
	PURCHASE_OF_NEW_OLD_HOUSE(1L,"Purchase of New / Old House"),
	PURCHASE_OF_NONAGRICULTURAL_PLOT_OF_LAND_FOR_CONSTRUCTING_RESIDENTIAL_UNIT(2l,"Purchase of non-agricultural plot of Land for constructing residential unit"),
	CONSTRUCTION_OF_NEW_RESIDENTIAL_UNIT(3l,"Construction of new residential unit"),
	COMPLETION_OF_UNDER_CONSTRUCTION_RESIDENTIAL_UNIT(4l,"Completion of under construction residential unit"),
	RENOVATION_OF_EXISTING_RESIDENTIAL_UNIT(5L,"Renovation of existing residential unit( Fixed furnishing , Immovable enhancement which added to the value)"),
	EXPANSION_OF_HOUSE_FLAT_BUNGLOW(6L,"Expansion of House/Flat/Bunglow");
	
	private Long id;
	private String value;

	private LoanPurpose(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static LoanPurpose fromId(Long v) {
		for (LoanPurpose c : LoanPurpose.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static LoanPurpose[] getAll() {
		return LoanPurpose.values();
	}
}
