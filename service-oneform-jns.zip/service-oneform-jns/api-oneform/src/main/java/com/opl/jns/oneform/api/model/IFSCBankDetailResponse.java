package com.opl.jns.oneform.api.model;

public class IFSCBankDetailResponse {

	private Long id;
	private String bank;
	private String ifsc;
	private String branch;
	private String address;
	private String city1;
	private String city2;
	private String state;
	private String stdCode;
	private String phoneNumber;
	private Long ansOrgId;
	private Long stateId;
	private Long cityId;
	private Long ifscBankId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity1() {
		return city1;
	}

	public void setCity1(String city1) {
		this.city1 = city1;
	}

	public String getCity2() {
		return city2;
	}

	public void setCity2(String city2) {
		this.city2 = city2;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStdCode() {
		return stdCode;
	}

	public void setStdCode(String stdCode) {
		this.stdCode = stdCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Long getAnsOrgId() {
		return ansOrgId;
	}

	public void setAnsOrgId(Long ansOrgId) {
		this.ansOrgId = ansOrgId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public Long getIfscBankId() {
		return ifscBankId;
	}

	public void setIfscBankId(Long ifscBankId) {
		this.ifscBankId = ifscBankId;
	}

	@Override
	public String toString() {
		return "IFSCBankDetailResponse [id=" + id + ", bank=" + bank + ", ifsc=" + ifsc + ", branch=" + branch + ", address=" + address + ", city1=" + city1 + ", city2=" + city2 + ", state=" + state + ", stdCode=" + stdCode + ", phoneNumber="
				+ phoneNumber + ", ansOrgId=" + ansOrgId + ", stateId=" + stateId + ", cityId=" + cityId + ", ifscBankId=" + ifscBankId + "]";
	}

}
