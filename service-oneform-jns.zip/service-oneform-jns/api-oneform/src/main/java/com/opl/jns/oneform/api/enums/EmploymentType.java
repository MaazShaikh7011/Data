package com.opl.jns.oneform.api.enums;

public enum EmploymentType {

	SALARIED(1L,"Salaried"), SELF_EMPLOYED(2L,"Self Employed"),PENSIONERS(3L,"Pensioners"),PROFESSIONAL(4L,"Professional"),Others(5L,"Others ");
	
	private Long id;
	private String value;

	private EmploymentType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EmploymentType fromId(Long v) {
		for (EmploymentType c : EmploymentType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static EmploymentType[] getAll() {
		return EmploymentType.values();
	}

}
