package com.opl.jns.oneform.api.enums.agri;

public enum AmiTypeOfActivity {
	
	CLEANING(1,"Cleaning"),
	SORTING(2,"Sorting"),
	GRADING(3,"Grading"),
	CUTTING(4,"Cutting"),
	BLEACHING(5,"Bleaching"),
	REFRIGERATING(6,"Refrigerating"),
	CHILLING_FREEZING(7,"Chilling & Freezing"),
	OTHERS_SPECIFY(8,"Others (Specify)");
	
	private Integer id;
	private String value;
	
	private AmiTypeOfActivity(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AmiTypeOfActivity fromId(Integer v) {
		for (AmiTypeOfActivity c : AmiTypeOfActivity.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiTypeOfActivity[] getAll() {
		return AmiTypeOfActivity.values();
	}

}
