package com.opl.jns.oneform.api.enums;

public enum HomeLoanEducationalQualification {

	UNDERGRADUATE(1l, "Undergraduate"),
	GRADUATE(2l, "Graduate"),
	POST_GRADUATE(3l, "Post Graduate"),
	PROFESSIONALS(4l, "Professionals"),
	OTHERS(5l, "Others");
	
	private Long id;
	private String value;
	
	private HomeLoanEducationalQualification(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public static HomeLoanEducationalQualification fromId(Long v) {
		for (HomeLoanEducationalQualification c : HomeLoanEducationalQualification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static HomeLoanEducationalQualification[] getAll() {
		return HomeLoanEducationalQualification.values();
	}
}
