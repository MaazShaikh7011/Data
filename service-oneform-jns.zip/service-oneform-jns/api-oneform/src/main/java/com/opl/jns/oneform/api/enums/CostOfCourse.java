package com.opl.jns.oneform.api.enums;

public enum CostOfCourse {
    TUITION_FEES(1l,"Tuition Fee"),EXAM_FEES(2L,"Exam Fee"),EQUIPMENT(3L,"Equipment"),HOSTEL_EXPENSES(4L,"Hostel Expenses"),
    OTHER_EXPENSES(5L,"Other Expenses");

    private Long id;
    private String value;

    private CostOfCourse(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static CostOfCourse fromId(Long v) {
        for (CostOfCourse c : CostOfCourse.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static CostOfCourse[] getAll() {
        return CostOfCourse.values();
    }
}
