package com.opl.jns.oneform.api.enums.kcc;

/**
 * @author rahul.meena
 *
 */
public enum YesorNoType {
	
	YES(1,"Yes"),
	NO(2,"No");
	
	private Integer id;
	private String value;

	private YesorNoType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static YesorNoType fromId(Integer v) {
		for (YesorNoType c : YesorNoType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static YesorNoType[] getAll() {
		return YesorNoType.values();
	}

}
