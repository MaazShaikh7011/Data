package com.opl.jns.oneform.api.enums.dayNulm;

public enum TypeOfMicroenterPrise {
    MANUFACTURING(1l, "Manufacturing"), TRADING(2l, "Trading"),SERVICES(3l, "Services");
    private Long id;
    private String value;

    private TypeOfMicroenterPrise(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static TypeOfMicroenterPrise fromId(Long v) {
        for (TypeOfMicroenterPrise c : TypeOfMicroenterPrise.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static TypeOfMicroenterPrise[] getAll() {
        return TypeOfMicroenterPrise.values();
    }
}
