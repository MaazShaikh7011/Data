package com.opl.jns.oneform.api.enums.mudra;

public enum MudraAssessedForIncomeTax {

	ASSESSED(1,"Assessed"),
	NOT_ASSESSED(2,"Not Assessed");

	private Integer id;
	private String value;

	private MudraAssessedForIncomeTax(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraAssessedForIncomeTax fromId(Integer v) {
		for (MudraAssessedForIncomeTax c : MudraAssessedForIncomeTax.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraAssessedForIncomeTax[] getAll() {
		return MudraAssessedForIncomeTax.values();
	}
}
