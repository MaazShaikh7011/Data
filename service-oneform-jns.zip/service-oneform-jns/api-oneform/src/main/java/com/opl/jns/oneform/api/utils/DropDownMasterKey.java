package com.opl.jns.oneform.api.utils;

public enum DropDownMasterKey {

    RELEATION_SHIP,
    KYC_DOCUMENTS,
    NATURE_OF_LOSS,
    CAUSE_OF_DEATH,
    TYPE_OF_DISABILITY,
    CAUSE_OF_DEATH_DISABILITY,
    STATUS_REASON,
    GENDER;

    public static DropDownMasterKey[] getAll() {
        return DropDownMasterKey.values();
    }

}
