package com.opl.jns.oneform.api.enums;

public enum BorrowerGroupBanker {
	EWS(1L,"EWS"),
	LIG(2L,"LIG"),
	MIG_1(3L,"MIG - 1"),
	MIG_2(4L,"MIG - 2");
	private Long id;
	private String value;

	private BorrowerGroupBanker(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	public static BorrowerGroupBanker fromId(Long v) {
		for (BorrowerGroupBanker c : BorrowerGroupBanker.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static BorrowerGroupBanker[] getAll() {
		return BorrowerGroupBanker.values();
	}

}
