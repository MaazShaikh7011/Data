package com.opl.jns.oneform.api.enums.mudra;

public enum AccountStatus {

	NO_SUIT_FILED(1, "No Suit Filed", 0, 2), SUIT_FILED(2, "Suit filed", 1, 2), WILLFULL_DEFAULTERS(3, "Willfull Defaulters", 2, 2), SUIT_FILED_WILLFUL_DEFAULTER(4, "Suit filed (Willfull default)", 3, 2), WRITE_OFF(5, "Write Off", 2, 1),
	SETTLED(6, "Settled", 3, 1);

	private Integer id;
	private Integer cibilId;

	/**
	 * 1= "Credit Facility Status (writtenOffAndSettledStatus)"
	 * 2= "Suit Filed / Wilful Default (suitFiledOrWilfulDefault)"
	 */
	private Integer cibilKeyType;
	private String value;

	private AccountStatus(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	private AccountStatus(Integer id, String value, Integer cibilId, Integer cibilKeyType) {
		this.id = id;
		this.value = value;
		this.cibilId = cibilId;
		this.cibilKeyType = cibilKeyType;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public Integer getCibilId() {
		return cibilId;
	}

	public Integer getCibilIdType() {
		return cibilKeyType;
	}

	public static AccountStatus fromId(Integer v) {
		for (AccountStatus c : AccountStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AccountStatus fromCibilIdAndCibilKeyType(Integer cibilId, Integer cibilKeyType) {
		for (AccountStatus c : AccountStatus.values()) {
			if (c.cibilId.equals(cibilId) && c.cibilKeyType.equals(cibilKeyType)) {
				return c;
			}
		}
		throw new IllegalArgumentException(cibilId != null || cibilKeyType != null ? (cibilKeyType.toString() + "" + cibilKeyType.toString()) : null);
	}

	public static AccountStatus[] getAll() {
		return AccountStatus.values();
	}
}
