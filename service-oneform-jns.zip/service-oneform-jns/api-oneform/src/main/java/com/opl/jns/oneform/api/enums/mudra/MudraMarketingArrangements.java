package com.opl.jns.oneform.api.enums.mudra;

/**
 * 
 * @author bhaumik.parekh
 *
 */
public enum MudraMarketingArrangements {
	
	FIRM_MARKETING_ARRANGEMENT_TIE_UP_FOR_OUTPUT (1, "Firm Marketing arrangement/ tie-up for output "), 
	NO_MARKETING_ARRANGEMENT_TIEUP_BUT_PRODUCT_EASILY_MARKETABLE(2,"No Marketing arrangement/ tie-up, but product easily marketable"),
	NO_ARRANGEMENT_TIEUP(3, "No arrangement/ tie-up");

	private Integer id;
	private String value;

	private MudraMarketingArrangements(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraMarketingArrangements fromId(Integer v) {
		for (MudraMarketingArrangements c : MudraMarketingArrangements.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraMarketingArrangements[] getAll() {
		return MudraMarketingArrangements.values();
	}
}
