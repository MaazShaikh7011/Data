package com.opl.jns.oneform.api.enums.agri;

public enum AmiTypeOfBusinessStorage {
	
	PACK_HOUSE(1,"Pack House"),
	COLD_ROOM(2,"Cold room"),
	RIPENING_CHAMBER(3,"Ripening chamber"),
	LOW_COST_ONION_STORAGE_STRUCTURE(4,"Low cost onion storage structure"),
	ZERO_ENERGY_COOL_CHAMBER(5,"Zero energy cool chamber"),
	COCONUT_CHSHEW_NUT_WALNUT_DE_SHELLING_MACHINE(6,"Coconut/chshew nut/Walnut De-shelling machine"),
	OTHERS_SPECIFY(7,"Others (Specify)");
	
	private Integer id;
	private String value;
	
	private AmiTypeOfBusinessStorage(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AmiTypeOfBusinessStorage fromId(Integer v) {
		for (AmiTypeOfBusinessStorage c : AmiTypeOfBusinessStorage.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiTypeOfBusinessStorage[] getAll() {
		return AmiTypeOfBusinessStorage.values();
	}


}
