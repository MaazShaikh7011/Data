package com.opl.jns.oneform.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class KccLgdResponse {
    private Long id;
    private Integer villageCodeUnique;
    private Integer kccDistId;
    private Integer kccTalukId;
    private Integer kccHobliId;
    private Integer kccVillageId;
    private String villageName;
    private String villageNameEng;
    private Long lgdDistCode;
    private Long lgdSubDistCode;
    private Long lgdVillageCode;

    private Boolean isCentConversion;

    public KccLgdResponse() {
        super();
    }

    public KccLgdResponse(Integer kccDistId, Integer kccTalukId, Integer kccHobliId, Integer kccVillageId) {
        this.kccDistId = kccDistId;
        this.kccTalukId = kccTalukId;
        this.kccHobliId = kccHobliId;
        this.kccVillageId = kccVillageId;
    }

    public KccLgdResponse(Long id, Integer villageCodeUnique, Integer kccDistId, Integer kccTalukId, Integer kccHobliId, Integer kccVillageId, String villageName, String villageNameEng, Long lgdDistCode, Long lgdSubDistCode, Long lgdVillageCode) {
        this.id = id;
        this.villageCodeUnique = villageCodeUnique;
        this.kccDistId = kccDistId;
        this.kccTalukId = kccTalukId;
        this.kccHobliId = kccHobliId;
        this.kccVillageId = kccVillageId;
        this.villageName = villageName;
        this.villageNameEng = villageNameEng;
        this.lgdDistCode = lgdDistCode;
        this.lgdSubDistCode = lgdSubDistCode;
        this.lgdVillageCode = lgdVillageCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getVillageCodeUnique() {
        return villageCodeUnique;
    }

    public void setVillageCodeUnique(Integer villageCodeUnique) {
        this.villageCodeUnique = villageCodeUnique;
    }

    public Integer getKccDistId() {
        return kccDistId;
    }

    public void setKccDistId(Integer kccDistId) {
        this.kccDistId = kccDistId;
    }

    public Integer getKccTalukId() {
        return kccTalukId;
    }

    public void setKccTalukId(Integer kccTalukId) {
        this.kccTalukId = kccTalukId;
    }

    public Integer getKccHobliId() {
        return kccHobliId;
    }

    public void setKccHobliId(Integer kccHobliId) {
        this.kccHobliId = kccHobliId;
    }

    public Integer getKccVillageId() {
        return kccVillageId;
    }

    public void setKccVillageId(Integer kccVillageId) {
        this.kccVillageId = kccVillageId;
    }

    public String getVillageName() {
        return villageName;
    }

    public void setVillageName(String villageName) {
        this.villageName = villageName;
    }

    public String getVillageNameEng() {
        return villageNameEng;
    }

    public void setVillageNameEng(String villageNameEng) {
        this.villageNameEng = villageNameEng;
    }

    public Long getLgdDistCode() {
        return lgdDistCode;
    }

    public void setLgdDistCode(Long lgdDistCode) {
        this.lgdDistCode = lgdDistCode;
    }

    public Long getLgdSubDistCode() {
        return lgdSubDistCode;
    }

    public void setLgdSubDistCode(Long lgdSubDistCode) {
        this.lgdSubDistCode = lgdSubDistCode;
    }

    public Long getLgdVillageCode() {
        return lgdVillageCode;
    }

    public void setLgdVillageCode(Long lgdVillageCode) {
        this.lgdVillageCode = lgdVillageCode;
    }

    public Boolean getIsCentConversion() {
        return isCentConversion;
    }

    public void setIsCentConversion(Boolean centConversion) {
        isCentConversion = centConversion;
    }
}
