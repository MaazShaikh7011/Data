package com.opl.jns.oneform.api.enums.dayNulm;

public enum AreaOfPremises {

    OWNED(1, "Owned"), RENTED(2, "Rented");

    private Integer id;
    private String value;

    private AreaOfPremises(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static AreaOfPremises fromId(Integer v) {
        for (AreaOfPremises c : AreaOfPremises.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static AreaOfPremises[] getAll() {
        return AreaOfPremises.values();
    }
}
