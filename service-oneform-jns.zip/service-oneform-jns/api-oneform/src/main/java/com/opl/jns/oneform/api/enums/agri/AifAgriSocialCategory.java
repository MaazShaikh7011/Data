package com.opl.jns.oneform.api.enums.agri;

public enum AifAgriSocialCategory {
	
GENERAL(1l, "General"), OBC(2l, "OBC"), ST(3l, "ST"),SC(4l, "SC"),MINORITY(5l, "Minority"),Agricultural_Labour(6l, "Agricultural Labour"),OTHERS(7l, "Others");
	
	private Long id;
	private String value;

	private AifAgriSocialCategory(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AifAgriSocialCategory fromId(Long v) {
		for (AifAgriSocialCategory c : AifAgriSocialCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AifAgriSocialCategory fromName(String v) {
		for (AifAgriSocialCategory c : AifAgriSocialCategory.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static AifAgriSocialCategory[] getAll() {
		return AifAgriSocialCategory.values();
	}

}
