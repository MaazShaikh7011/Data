package com.opl.jns.oneform.api.enums;

public enum Examination {

	SSC(1l, "SSC(10th)"), HSC(2l, "HSC(12th)"),GRADUATES(3l,"Graduate"),POST_GRADUATES(4L,"Post Graduate"),M_PHIL(5L,"M.Phil"),PH_D(6L,"Ph.D"),
	DIPLOMA(7L,"Diploma"),PROFESSIONALS(8l,"Professionals"),OTHER_SPECIFY(9l,"Other (Specify)");
	
	private Long id;
	private String value;

	private Examination(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Examination fromId(Long v) {
		for (Examination c : Examination.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Examination[] getAll() {
		return Examination.values();
	}

}
