package com.opl.jns.oneform.api.enums.clap;

public enum ClapResponse {
	SUCCESS(1, "success"),
	FAILED(2, "failed"),
	PENDING(3, "pending");

	private Integer id;
	private String value;

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	private ClapResponse(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public static ClapResponse fromId(Integer v) {
		for (ClapResponse c : ClapResponse.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ClapResponse[] getAll() {
		return ClapResponse.values();
	}
}
