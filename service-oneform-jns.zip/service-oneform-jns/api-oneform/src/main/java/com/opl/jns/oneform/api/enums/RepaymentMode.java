package com.opl.jns.oneform.api.enums;

public enum RepaymentMode {
	ESC(1L,"Electronic Clearing System(ECS)"),
	SI(2L,"Standing Instruction(SI)"),
	PDC(3L,"Post Dated Cheque(PDC)"),
	NECS(4L,"National Electronic Clearing Service(NECS)"),
	CASH(5L,"CASH");
	
	private Long id;
	private String value;

	private RepaymentMode(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static RepaymentMode fromId(Long v) {
		for (RepaymentMode c : RepaymentMode.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RepaymentMode[] getAll() {
		return RepaymentMode.values();
	}
}
