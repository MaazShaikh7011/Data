package com.opl.jns.oneform.api.enums.mudra;

public enum ITRType {

	ITR_1(1, "ITR-1", 193), ITR_2(2, "ITR-2", 194), ITR_3(3, "ITR-3", 195), ITR_4(4, "ITR-4", 196), ITR_5(5, "ITR-5", 197), ITR_6(6, "ITR-6", 198);

	private Integer id;
	private String value;
	private Integer productSubId;

	private ITRType(Integer id, String value, Integer productSubId) {
		this.id = id;
		this.value = value;
		this.productSubId = productSubId;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public Integer getProductSubId() {
		return productSubId;
	}

	public static ITRType fromId(Integer v) {
		for (ITRType c : ITRType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ITRType fromProductSubId(Integer v) {
		for (ITRType c : ITRType.values()) {
			if (c.productSubId.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ITRType[] getAll() {
		return ITRType.values();
	}
}
