package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmSocialCategory {

    GENERAL(1, "General"),
    OBC(2, "OBC"),
    ST(3, "ST"),
    SC(4, "SC"),
    OTHER(5, "Other");

    private Integer id;
    private String value;

    private NrlmSocialCategory(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmSocialCategory fromId(Integer v) {
        for (NrlmSocialCategory c : NrlmSocialCategory.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmSocialCategory fromName(String v) {
        for (NrlmSocialCategory c : NrlmSocialCategory.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }

    public static NrlmSocialCategory[] getAll() {
        return NrlmSocialCategory.values();
    }

}
