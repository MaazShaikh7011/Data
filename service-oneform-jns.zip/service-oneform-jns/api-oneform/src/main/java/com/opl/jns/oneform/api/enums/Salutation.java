package com.opl.jns.oneform.api.enums;

public enum Salutation {
	
	MR(1l, "Mr."), MRS(2l, "Mrs."), MS(3l, "Ms.");
	

	private Long id;
	private String value;

	private Salutation(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Salutation fromId(Long v) {
		for (Salutation c : Salutation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Salutation[] getAll() {
		return Salutation.values();
	}

}
