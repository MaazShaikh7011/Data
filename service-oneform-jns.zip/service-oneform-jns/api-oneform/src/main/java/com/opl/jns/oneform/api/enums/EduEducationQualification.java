package com.opl.jns.oneform.api.enums;

public enum EduEducationQualification {
	
	SSC(6l, "SSC(10th)"), HSC(1l, "HSC(12th)"), GRADUATES(2l, "Graduate"), POST_GRADUATES(3l, "Post Graduate"),
	PROFESSIONALS(4l, "Professionals"), OTHERS(5l, "Others"),;

	private Long id;
	private String value;

	private EduEducationQualification(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EduEducationQualification fromId(Long v) {
		for (EduEducationQualification c : EduEducationQualification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static EduEducationQualification[] getAll() {
		return EduEducationQualification.values();
	}

}
