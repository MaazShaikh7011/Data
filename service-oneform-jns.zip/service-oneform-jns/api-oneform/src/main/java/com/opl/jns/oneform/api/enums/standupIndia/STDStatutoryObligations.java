package com.opl.jns.oneform.api.enums.standupIndia;

public enum STDStatutoryObligations {

    REGISTRATION_UNDER_SHOPS_ESTABLISMENT_ACT(1,"Registration under The Shops and Establishments Act,1953","[\"compiledWith\",\"registrationDate\",\"registrationNumber\"]"),
    REGISTRATION_UNDER_UDYOG_MSME(2,"Registration under Udyog/MSME (Provisional/Final)","[\"compiledWith\",\"registrationDate\",\"registrationNumber\"]"),
    DRUG_LICENSE(3,"Drug License","[\"compiledWith\",\"registrationDate\",\"drugLicenseNumber\"]"),
    LASTEST_GST_RETURN_FILED(4,"Lastest GST Return Filed","[\"compiledWith\",\"registrationDate\",\"amount\"]"),
    LATEST_INCOME_TAX_RETURN_FILED(5,"Latest Income Tax Return Filed","[\"compiledWith\",\"registrationDate\",\"amount\"]"),
    ANY_OTHER_STATUTORY_DUES_REMAINING_OUTSTANDING(6,"Any other statutory dues remaining outstanding","[\"compiledWith\",\"amount\"]");

    private Integer id;
    private String value;
    private String code;

    private STDStatutoryObligations(Integer id, String value,String code) {
        this.id = id;
        this.value = value;
        this.code = code;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }
    public String getCode() {
        return code;
    }

    public static STDStatutoryObligations fromId(Integer v) {
        for (STDStatutoryObligations c : STDStatutoryObligations.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static STDStatutoryObligations[] getAll() {
        return STDStatutoryObligations.values();
    }
}
