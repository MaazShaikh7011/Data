package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndNoOfEmployees {
    ZERO(1,"0"),
    ONE(2,"1"),
    TWO(3,"2"),
    THREE(4,"3"),
    FOUR(5,"4"),
    FIVE(6,"5"),
    six(7,"6"),
    SEVEN(8,"7"),
    EIGHT(9,"8"),
    NINE(10,"9"),
    TEN_AND_ABOVE(11,"10 & Above");

    private Integer id;
    private String value;

    private StandupIndNoOfEmployees(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static StandupIndNoOfEmployees fromId(Integer v) {
        for (StandupIndNoOfEmployees c : StandupIndNoOfEmployees.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndNoOfEmployees fromName(String v) {
        for (StandupIndNoOfEmployees c : StandupIndNoOfEmployees.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndNoOfEmployees[] getAll() {
        return StandupIndNoOfEmployees.values();
    }
}
