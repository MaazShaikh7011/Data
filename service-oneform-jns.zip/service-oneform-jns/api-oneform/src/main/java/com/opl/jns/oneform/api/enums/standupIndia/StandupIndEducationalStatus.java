package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndEducationalStatus {
    ILLITERATE(1,"Illiterate"),
    UNDER_GRADUATE(2,"Under Graduate"),
    GRADUATE(3,"Graduate"),
    POST_GRADUATE(4,"Post graduate"),
    PROFESSIONALS(5,"Professionals"),
    OTHER(6,"Other");

    private Integer id;
    private String value;

    private StandupIndEducationalStatus(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndEducationalStatus fromId(Integer v) {
        for (StandupIndEducationalStatus c : StandupIndEducationalStatus.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }
    public static StandupIndEducationalStatus[] getAll() {
        return StandupIndEducationalStatus.values();
    }
}
