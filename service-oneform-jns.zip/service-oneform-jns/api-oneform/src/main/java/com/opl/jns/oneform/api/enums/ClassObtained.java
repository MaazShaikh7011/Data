package com.opl.jns.oneform.api.enums;

public enum ClassObtained {
	
	DISTINCTION(1l, "Distinction "), FIRST_CLASS(2l, "First class"),SECOND_CLASS(3l, "Second Class "), THIRD_CLASS(4l, "Third Class");
	
	private Long id;
	private String value;

	private ClassObtained(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ClassObtained fromId(Long v) {
		for (ClassObtained c : ClassObtained.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ClassObtained[] getAll() {
		return ClassObtained.values();
	}

}
