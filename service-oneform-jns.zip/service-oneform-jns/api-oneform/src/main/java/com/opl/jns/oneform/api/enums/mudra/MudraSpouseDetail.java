package com.opl.jns.oneform.api.enums.mudra;

public enum MudraSpouseDetail {

	EMPLOYED(1,"Employed"),
	NOT_EMPLOYED(2,"Not employed");

	private Integer id;
	private String value;

	private MudraSpouseDetail(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraSpouseDetail fromId(Integer v) {
		for (MudraSpouseDetail c : MudraSpouseDetail.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraSpouseDetail[] getAll() {
		return MudraSpouseDetail.values();
	}
}
