package com.opl.jns.oneform.api.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IndustrySectorRequest {
    Long industryId;
    Long sectorId;
    Long subSectorId;
    String industryName;
    String sectorName;
    String subSectorName;
    Integer subSectortype;

    public Long getIndustryId() {
        return industryId;
    }

    public void setIndustryId(Long industryId) {
        this.industryId = industryId;
    }

    public Long getSectorId() {
        return sectorId;
    }

    public void setSectorId(Long sectorId) {
        this.sectorId = sectorId;
    }

    public Long getSubSectorId() {
        return subSectorId;
    }

    public void setSubSectorId(Long subSectorId) {
        this.subSectorId = subSectorId;
    }

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getSubSectorName() {
        return subSectorName;
    }

    public void setSubSectorName(String subSectorName) {
        this.subSectorName = subSectorName;
    }
    
    

	@Override
	public String toString() {
		return "IndustrySectorRequest [industryId=" + industryId + ", sectorId=" + sectorId + ", subSectorId="
				+ subSectorId + ", industryName=" + industryName + ", sectorName=" + sectorName + ", subSectorName="
				+ subSectorName + "]";
	}

	public Integer getSubSectortype() {
		return subSectortype;
	}

	public void setSubSectortype(Integer subSectortype) {
		this.subSectortype = subSectortype;
	}
    
    
}
