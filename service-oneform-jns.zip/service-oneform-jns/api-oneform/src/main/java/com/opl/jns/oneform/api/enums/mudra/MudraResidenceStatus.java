package com.opl.jns.oneform.api.enums.mudra;

public enum MudraResidenceStatus {

	RECIDENT_INDIA(1,"Resident India"),
	NON_RECIDENT_INDIA(2,"Non resident India"),
	RESIDENT_BUT_NOT_ORDINARY_RESIDENT(3,"Resident but not ordinary resident"),
	ORDINARY_RESIDENT(4,"Ordinary resident"),
	FOREIGN_CORRESPONDENT(5,"Foreign correspondent");

	private Integer id;
	private String value;

	private MudraResidenceStatus(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraResidenceStatus fromId(Integer v) {
		for (MudraResidenceStatus c : MudraResidenceStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraResidenceStatus[] getAll() {
		return MudraResidenceStatus.values();
	}
}
