package com.opl.jns.oneform.api.enums;

public enum InstituteLocation {
	IN_INDIA(1l, "In India", "87"), OUTSIDE_INDIA(2l, "Outside India", "88");

	private Long id;
	private String value;
	private String schemeParamId;

	private InstituteLocation(Long id, String value, String schemeParamId) {
		this.id = id;
		this.value = value;
		this.schemeParamId = schemeParamId;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getSchemeParamId() {
		return schemeParamId;
	}

	public static InstituteLocation fromId(Long v) {
		for (InstituteLocation c : InstituteLocation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static InstituteLocation[] getAll() {
		return InstituteLocation.values();
	}
}
