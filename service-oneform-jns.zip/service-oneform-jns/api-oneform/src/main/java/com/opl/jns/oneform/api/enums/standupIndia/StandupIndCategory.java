package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndCategory {
    SC(1,"SC"),ST(2,"ST"),MINORITY_COMMUNITY(3,"Minority Community"),
    WOMEN(4,"Women"),GENERAL(5,"General");

    private Integer id;
    private String value;

    private StandupIndCategory(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndCategory fromId(Integer v) {
        for (StandupIndCategory c : StandupIndCategory.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndCategory fromName(String v) {
        for (StandupIndCategory c : StandupIndCategory.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }
    public static StandupIndCategory[] getAll() {
        return StandupIndCategory.values();
    }
}
