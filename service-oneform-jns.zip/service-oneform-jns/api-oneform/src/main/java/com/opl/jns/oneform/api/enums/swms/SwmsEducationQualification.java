package com.opl.jns.oneform.api.enums.swms;

public enum SwmsEducationQualification {
	CANNOT_READ_WRITE (1,"Cannot read & write "),
	CAN_READ_WRITE (2,"Can read & Write "),
	SSC_PASS(3,"SSC Pass"),
	HSC_ITI_EQUIVALENT_PASS(4,"HSC/ITI or Equivalent Pass"),
	OTHER(5,"Others( Specify)");
	
	private Integer id;
	private String value;

	private SwmsEducationQualification(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsEducationQualification fromId(Integer v) {
		for (SwmsEducationQualification c : SwmsEducationQualification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsEducationQualification[] getAll() {
		return SwmsEducationQualification.values();
	}
}
