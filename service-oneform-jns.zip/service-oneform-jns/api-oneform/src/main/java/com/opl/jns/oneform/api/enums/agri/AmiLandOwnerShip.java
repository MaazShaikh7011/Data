package com.opl.jns.oneform.api.enums.agri;

public enum AmiLandOwnerShip {
	
	OWNED​(1,"Owned​"),
	LEASED(2,"Leased"),
	SHARE_CROPPER(3,"Share cropper");
	
	private Integer id;
	private String value;
	
	private AmiLandOwnerShip(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AmiLandOwnerShip fromId(Integer v) {
		for (AmiLandOwnerShip c : AmiLandOwnerShip.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiLandOwnerShip[] getAll() {
		return AmiLandOwnerShip.values();
	}

}
