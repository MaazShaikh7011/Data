package com.opl.jns.oneform.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * @author ravi.thummar
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LgdStateResponse {

    private Long stateId;
    private String stateName;
    private String lgdStateCode;


    public LgdStateResponse(Long stateId, String stateName, String lgdStateCode) {
        this.stateId = stateId;
        this.stateName = stateName;
        this.lgdStateCode = lgdStateCode;
    }
}
