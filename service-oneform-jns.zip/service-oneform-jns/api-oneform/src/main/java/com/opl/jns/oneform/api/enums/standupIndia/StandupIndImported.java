package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndImported {
    IMPORTED(1,"Imported"),DOMESTIC(2,"Domestic");

    private Integer id;
    private String value;

    private StandupIndImported(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndImported fromId(Integer v) {
        for (StandupIndImported c : StandupIndImported.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndImported[] getAll() {
        return StandupIndImported.values();
    }
}
