package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndTypeOfFacility {
    WORKING_CAPITAL(1,"Working Capital"),
    TERM_LOAN(2,"Term Loan");
//    ,LC_BG_CREDIT(3,"LC/BG Credit");

    private Integer id;
    private String value;

    private StandupIndTypeOfFacility(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndTypeOfFacility fromId(Integer v) {
        for (StandupIndTypeOfFacility c : StandupIndTypeOfFacility.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndTypeOfFacility[] getAll() {
        return StandupIndTypeOfFacility.values();
    }
}
