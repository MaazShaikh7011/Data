package com.opl.jns.oneform.api.enums;

public enum CreditType {
	
	AUTO_LOAN_PERSONAL("01","Auto Loan (Personal)", "Auto Loan", "1", "Auto Loan (Personal)", 1),
	HOUSING_LOAN("02","Housing Loan", "Housing Loan", "2", "Housing Loan", 2),
	PROPERTY_LOAN("03","literal property loan", "Property Loan", "3", "Property Loan", 3),
	LOAN_AGAINST_SHARES_SECURITIES("04","Loan Against SHARES/Securities", "Loan against Shares/Securities", "4", "Loan Against Shares / Securities", 4),
	PERSONAL_LOAN("05","Personal Loan", "Personal Loan", "5", "Personal Loan", 5),
	CONSUMER_LOAN("06","Consumer Loan", "Consumer Loan", "6", "Consumer Loan", 6),
	GOLD_LOAN("07","literal gold loan", "Gold Loan", "7", "Gold Loan", 7),
	EDUCATION_LOAN("08","Education Loan", "Education Loan", "8", "Education Loan", 8),
	LOAN_TO_PROFESSIONAL("09","Loan to Professional", "Loan to Professional", "9", "Loan to Professional", 9),
	CREDIT_CARD("10","Credit Card", "Credit Card", "10", "Credit Card", 10),
	LEASING("11","Leasing", "Lease", "11", "Leasing", 11),
	OVERDRAFT("12","literal overdraft", "Overdraft", "12", "Overdraft", 12),
	TWO_WHEELER_LOAN("13","Two wheeler Loan", "Two-wheeler Loan", "13", "Two-Wheeler Loan", 13),
	NON_FUNDED_CREDIT_FACILITY("14","Non Funded Credit Facility", "Non-Funded Credit Facility", "14", "Non-Funded Credit Facility", 14),
	LOAN_AGAINST_BANK_DEPOSITS("15","Loan Against Bank Deposits", "Loan Against Bank Deposits", "15", "Loan Against Bank Deposits", 15),
	FLEET_CARD("16","Fleet Card", "Fleet Card", "16", "Fleet Card", 16),
	COMMERCIAL_VEHICLE_LOAN("17","Commercial Vehicle Loan", "Commercial Vehicle Loan", "17", "Commercial Vehicle Loan", 17),
	TELCO_WIRELESS("18","Telco – Wireless", "Telco - Wireless", "18", "Telco Wireless", 18),
	TELCO_BROADBAND("19","Telco – Broadband", "Telco - Broadband", "19", "Telco Broadband", 19),
	TELCO_LANDLINE("20","Telco – Landline", "Telco - Landline", "20", "Telco Landline", 20),
	SECURED_CREDIT_CARD("31","Secured Credit Card", "Secured Credit Card", "31", "Secured Credit Card", 31),
	USED_CAR_LOAN("32","Used Car Loan", "Used Car Loan", "32", "Used Car Loan", 32),
	CONSTRUCTION_EQUIPMENT_LOAN("33","Construction Equipment Loan", "Construction Equipment Loan", "33", "Construction Equipment Loan", 33),
	TRACTOR_LOAN("34","Tractor Loan", "Tractor Loan", "34", "Used Tractor Loan", 34),
	CORPORATE_CREDIT_CARD("35","Corporate Credit Card", "Corporate Credit Card", "35", "Corporate Credit Card", 35),
	KISAN_CREDIT_CARD("36","Kisan Credit Card", "", "36", "Kisan Credit Card", 36), 
	LOAN_ON_CREDIT_CARD("37","Loan on Credit Card","", "37", "Loan on Credit Card", 37), 
	PRIME_MINISTER_JAAN_DHAN_YOJANA_OVERDRAFT("38","Prime Minister Jaan Dhan Yojana - Overdraft", "","38", "Prime Minister Jaan Dhan Yojana - Overdraft", 38), 
	MUDRA_LOANS_SHISHU_KISHOR_TARUN("39","Mudra Loans – Shishu / Kishor / Tarun", "", "39", "Mudra Loans – Shishu / Kishor / Tarun", 39), 
	MICROFINANCE_BUSINESS_LOAN("40","Microfinance – Business Loan", "MicroFinance Business Loan", "", "Microfinance Business Loan", 40),
	MICROFINANCE_PERSONAL_LOAN("41","Microfinance – Personal Loan", "MicroFinance Personal Loan", "", "Microfinance Personal Loan", 41),
	MICROFINANCE_HOUSING_LOAN("42","Microfinance – Housing Loan", "MicroFinance Housing Loan", "", "Microfinance Housing Loan", 42),
	MICROFINANCE_OTHER("43","Microfinance – Other", "MicroFinance Others", "43", "Microfinance Others", 43),
	PRADHAN_MANTRI_AWAS_YOJANA_CREDIT_LINK_SUBSIDY_SCHEME_MAY_CLSS("44","Pradhan Mantri Awas Yojana - Credit Link Subsidy Scheme MAY CLSS", "", "", "Pradhan Mantri Awas Yojana - CLSS", 44),
	BUSINESS_LOAN_SECURED("50","Business Loan - Secured", "", "", "Business Loan - Secured", 50), 
	BUSINESS_LOAN_GENERAL("51","Business Loan – General", "Business Loan", "51", "Business Loan General", 51),
	BUSINESS_LOAN_PRIORITY_SECTOR_SMALL_BUSINESS("52","Business Loan – Priority Sector – Small Business", "Business Loan-Priority Sector-Small Business", "52", "Business Loan Priority Sector Small Business", 52),
	BUSINESS_LOAN_PRIORITY_SECTOR_AGRICULTURE("53","Business Loan – Priority Sector – Agriculture", "Business Loan - Priority Sector- Agriculture", "53", "Business Loan Priority Sector Agriculture", 53),
	BUSINESS_LOAN_PRIORITY_SECTOR_OTHERS("54","Business Loan – Priority Sector – Others", "Business Loan - Priority Sector- Others", "54", "Business Loan Priority Sector Others", 54),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_GENERAL("55","Business NON_Funded Credit Facility – General", "Business Non-Funded Credit Facility", "55", "Business Non-Funded Credit Facility General", 55),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_SMALL_BUSINESS("56","Business NON_Funded Credit Facility – Priority Sector – Small Business", "Business Non-Funded Credit Facility - Priority Sector - Small Business", "56", "Business Non-Funded Credit Facility-Priority Sector- Small Business", 56),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_AGRICULTURE("57","Business NON_Funded Credit Facility – Priority Sector – Agriculture", "Business Non-Funded Credit Facility - Priority Sector - Agriculture", "57", "Business Non-Funded Credit Facility-Priority Sector-Agriculture", 57),
	BUSINESS_NON_FUNDED_CREDIT_FACILITY_PRIORITY_SECTOR_OTHERS("58","Business NON_Funded Credit Facility – Priority SECTOR_Others", "Business Non-Funded Credit Facility - Priority Sector - Other", "58", "Business Non-Funded Credit Facility-Priority Sector-Others", 58),
	BUSINESS_LOAN_AGAINST_BANK_DEPOSITS("59","Business Loan Against Bank Deposits", "Business Loan Against Bank Deposits", "59", "Business Loan Against Bank Deposits", 59),
	BUSINESS_LOAN_UNSECURED("61","Business Loan - Unsecured", "", "61", "Business Loan Unsecured", 61), 
	MICROFINANCE_DETAILED_REPORT_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("80","Microfinance Detailed Report (Applicable to Enquiry Purpose only)", "", "", "", 80),
	SUMMARY_REPORT_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("81","Summary Report (Applicable to Enquiry Purpose only)", "", "", "", 81), 
	LOCATE_PLUS_FOR_INSURANCE_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("88","Locate Plus for Insurance (Applicable to Enquiry Purpose only)", "", "", "", 88),
	ACCOUNT_REVIEW_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("90","Account Review (Applicable to Enquiry Purpose only)", "", "", "", 90),
	RETRO_ENQUIRY_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("91","Retro Enquiry (Applicable to Enquiry Purpose only)", "", "", "", 91),
	LOCATE_PLUS_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("92","Locate Plus (Applicable to Enquiry Purpose only)", "", "", "", 92),
	ADVISER_LIABILITY_APPLICABLE_TO_ENQUIRY_PURPOSE_ONLY("97","Adviser Liability (Applicable to Enquiry Purpose only)", "", "", "", 97),
	OTHER("105","Other", "Other", "105", "Other", 105),
	SECURED_ACCOUNT_GROUP_FOR_PORTFOLIO_REVIEW_RESPONSE("98","Secured (Account Group for Portfolio Review response)", "", "", "", 98),
	UNSECURED_ACCOUNT_GROUP_FOR_PORTFOLIO_REVIEW_RESPONSE("99","Unsecured (Account Group for Portfolio Review response)", "", "", "", 99),
	// Not Matched loan type with cibil
	AUTO_LEASE("100","Auto Lease", "Auto Lease", "", "", 100),
	STAFF_LOAN("60","Staff Loan", "Staff Loan", "60", "Staff Loan", 60),
	DISCLOSURE("101","Disclosure", "Disclosure", "", "", 101);



	private String id;
	private String value;
	private String equifaxValue;
	private String experianValue;
	private String highmarkValue;
	private Integer mappingId;

	private CreditType(String id, String value, String equifaxValue, String experianValue, String highmarkValue,Integer mappingId) {
		this.id = id;
		this.value = value;
		this.equifaxValue = equifaxValue;
		this.experianValue = experianValue;
		this.highmarkValue = highmarkValue;
		this.mappingId = mappingId;
	}

	public String getValue() {
		return this.value;
	}

	public String getId() {
		return this.id;
	}

	public Integer getMappingId() {
		return mappingId;
	}

	public static CreditType fromValue(String v) {
		for (CreditType c : CreditType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

//	public static CreditType1 fromId(String v) {
//		for (CreditType1 c : CreditType1.values()) {
//			if (c.id.equals(v) || Integer.parseInt(v) == Integer.parseInt(c.id)) {
//				return c;
//			}
//		}
//		throw new IllegalArgumentException(v);
//	}

	public static CreditType fromEquifaxValue(String v) {
		for (CreditType c : CreditType.values()) {
			if (c.equifaxValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static CreditType fromExperianRetailValue(String v) {
		for (CreditType c : CreditType.values()) {
			if (c.experianValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	public static CreditType fromHighmarkRetailValue(String v) {
		for (CreditType c : CreditType.values()) {
			if (c.highmarkValue.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	public static CreditType fromCibilId(Long v) {
		for (CreditType c : CreditType.values()) {
			if (Long.valueOf(c.mappingId).equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	
	public static CreditType fromId(Integer v) {
		for (CreditType c : CreditType.values()) {
			if (c.mappingId.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	
    public static CreditType[] getAll() {
        return CreditType.values();
    }

}
