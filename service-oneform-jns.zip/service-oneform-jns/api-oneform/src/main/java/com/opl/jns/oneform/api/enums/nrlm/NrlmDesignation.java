package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmDesignation {

    PRESIDENT(1, "President"),
    SECRETARY(2, "Secretary"),
    TREASURER(3, "Treasurer"),
    MEMBER(4, "Member"),
    PRIVATE(5, "Private");

    private Integer id;
    private String value;

    private NrlmDesignation(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmDesignation fromId(Integer v) {
        for (NrlmDesignation c : NrlmDesignation.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmDesignation fromName(String v) {
        for (NrlmDesignation c : NrlmDesignation.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }

    public static NrlmDesignation[] getAll() {
        return NrlmDesignation.values();
    }

}
