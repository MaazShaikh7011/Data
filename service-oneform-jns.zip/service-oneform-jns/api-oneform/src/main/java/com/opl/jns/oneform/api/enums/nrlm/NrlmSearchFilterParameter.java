package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmSearchFilterParameter {
    ALL(12,"All"),
    SHG_MEMBER_NAME(13,"SHG Member Name"),
    SHG_CODE(14,"SHG Code"),
    LOAN_APPLICATION_ID(15,"Loan Application Id"),
    APPLICATION_CODE(16,"Application Code"),
    LOAN_APPLICATION_NUMBER(17,"Loan Application Number");

    private Integer id;
    private String value;

    private NrlmSearchFilterParameter(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmSearchFilterParameter fromId(Integer v) {
        for (NrlmSearchFilterParameter c : NrlmSearchFilterParameter.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmSearchFilterParameter fromName(String v) {
        for (NrlmSearchFilterParameter c : NrlmSearchFilterParameter.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }

    public static NrlmSearchFilterParameter[] getAll() {
        return NrlmSearchFilterParameter.values();
    }
}
