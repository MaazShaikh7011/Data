package com.opl.jns.oneform.api.enums;

public enum TypeOfProductBanker {
	WORKING_CAPITAL(1l, "Working Capital"), TERM_LOAN(2l, "Term loan");

	private Long id;
	private String value;
	private String code;

	private TypeOfProductBanker(Long id, String value) {
		this.id = id;
		this.value = value;

	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static TypeOfProductBanker fromId(Long v) {
		for (TypeOfProductBanker c : TypeOfProductBanker.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static TypeOfProductBanker[] getAll() {
		return TypeOfProductBanker.values();
	}

}
