package com.opl.jns.oneform.api.enums.agri;

public enum AmiTypeOfProject {
	
	STORAGE_INFRASTRUCTURE(1,"Storage Infrastructure"),
	NON_STORAGE_INFRASTRUCTURE(2,"Non - Storage Infrastructure");
	
	private Integer id;
	private String value;
	
	private AmiTypeOfProject(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AmiTypeOfProject fromId(Integer v) {
		for (AmiTypeOfProject c : AmiTypeOfProject.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiTypeOfProject[] getAll() {
		return AmiTypeOfProject.values();
	}

}
