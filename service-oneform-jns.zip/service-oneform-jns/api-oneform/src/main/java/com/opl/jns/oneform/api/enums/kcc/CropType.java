package com.opl.jns.oneform.api.enums.kcc;

/**
 * @author rahul.meena
 *
 */
public enum CropType {
	
	BAJRI(1l, "Bajri"),
	WHEAT(2l, "Wheat");

	private Long id;
	private String value;

	private CropType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CropType fromId(Long v) {
		for (CropType c : CropType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CropType[] getAll() {
		return CropType.values();
	}

}
