package com.opl.jns.oneform.api.enums.agri;

public enum ProjectCostNonStorage {	
	Plant_Machinery(1,"Plant & Machinery"),
	ANCILLIARY_INFRASTRUCTURE(2,"Ancilliary Infrastructure"),
	COST_OF_CIVIL_STRUCTURE(3,"Cost of civil structure"),
	COST_OF_PRIMARY_PROCESSING(4,"Cost of Primary processing");
	
	private Integer id;
	private String value;
	
	private ProjectCostNonStorage(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	public static ProjectCostNonStorage fromId(Integer v) {
		for (ProjectCostNonStorage c : ProjectCostNonStorage.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static ProjectCostNonStorage[] getAll() {
		return ProjectCostNonStorage.values();
	}
}
