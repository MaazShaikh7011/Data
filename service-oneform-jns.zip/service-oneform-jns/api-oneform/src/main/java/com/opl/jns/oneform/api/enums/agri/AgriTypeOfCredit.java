package com.opl.jns.oneform.api.enums.agri;

public enum AgriTypeOfCredit {
	
	WORKING_CAPITAL(1,"Working Capital"),
	TERM_LOAN(2,"Term Loan");
	
	private Integer id;
	private String value;
	
	private AgriTypeOfCredit(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AgriTypeOfCredit fromId(Integer v) {
		for (AgriTypeOfCredit c : AgriTypeOfCredit.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AgriTypeOfCredit[] getAll() {
		return AgriTypeOfCredit.values();
	}

}
