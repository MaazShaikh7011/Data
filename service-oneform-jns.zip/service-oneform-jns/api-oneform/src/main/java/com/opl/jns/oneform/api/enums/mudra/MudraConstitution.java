package com.opl.jns.oneform.api.enums.mudra;

/**
 * 
 * @author krishna.kevadiya
 *
 */
public enum MudraConstitution {
	
//	PRIVATE_LIMITED(1,"Private Limited"),
//	PUBLIC_LISTED(2,"Public Ltd-Listed"),
//	PUBLIC_UNLISTED(3,"Public Limited -Unlisted"),
//	PARTNERSHIP(4,"Partnership"),
//	SOLE_PROPRIETORSHIP(5,"Sole Proprietorship"),
//	LLP(6,"LLP - Limited Liability Partnership"),
//	HUF(7,"HUF - Hindu Undivided Family"),
//	ONE_PERSON(8,"One Person Company"),
//	GENERAL_ASSOCIATION(9,"General Association");
	
	AOP(1,"Association of Persons (AOP)"),   
    PRIVATE_LIMITED(3,"Private Limited"),
    PUBLIC_LTD_LISTED(4,"Public Ltd - Listed"),
    PUBLIC_LTD_UNLISTED(5,"Public Ltd - Unlisted"),
    ONE_PERSON_COMPANY(6,"One Person Company"),
	LIMITED_LIABILITY_PARTNERSHIP(9,"Limited Liability Partnership"),	
    PARTNERSHIP(8,"Partnership"),
    GOVERNMENT_ENTITY(10,"Government Entity"),	
    HUF(11,"HUF"),
    SOLE_PROPRIETORSHIP(12,"Sole-Proprietorship"),
    OTHERS(14,"Others");
	

	private Integer id;
	private String value;

	private MudraConstitution(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraConstitution fromId(Integer v) {
		for (MudraConstitution c : MudraConstitution.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraConstitution[] getAll() {
		return MudraConstitution.values();
	}

}
