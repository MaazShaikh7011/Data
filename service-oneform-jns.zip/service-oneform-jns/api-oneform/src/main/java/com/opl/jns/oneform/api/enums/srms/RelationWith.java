package com.opl.jns.oneform.api.enums.srms;

public enum RelationWith {

	SELF(1, "Self"),
	FATHER(2, "Father"),
	MOTHER(3, "Mother"),
	HUSBAND(4, "Husband"),
	WIFE(5, "Wife"),
	OTHER(6, "Other");
	
	private Integer id;
	private String value;

	private RelationWith(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static RelationWith fromId(Integer v) {
		for (RelationWith c : RelationWith.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RelationWith[] getAll() {
		return RelationWith.values();
	}
}
