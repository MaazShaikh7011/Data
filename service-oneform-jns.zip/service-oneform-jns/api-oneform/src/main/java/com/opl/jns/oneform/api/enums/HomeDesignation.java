package com.opl.jns.oneform.api.enums;

public enum HomeDesignation {
	SENIOR_MANAGRMENT(1L,"Senior Management"),
	MIDDLR_MANAGEMENT(2L,"Middle Management"),
	JUNIOR(3L,"Junior"),
	PENSIONERS(4L,"Pensioners"),
	OTHERS(5L,"others");
	
	private Long id;
	private String value;

	private HomeDesignation(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static HomeDesignation fromId(Long v) {
		for (HomeDesignation c : HomeDesignation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static HomeDesignation[] getAll() {
		return HomeDesignation.values();
	}
}
