package com.opl.jns.oneform.api.enums.swms;

public enum SwmsBusinessProspects {
	
	HIGH_POTENTIAL(1,"High potential"),
	AVERAGE_POTENTIAL(2,"Average potential"),
	MARGINAL_POTENTIAL(3,"Marginal Potential");
	
	private Integer id;
	private String value;

	private SwmsBusinessProspects(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsBusinessProspects fromId(Integer v) {
		for (SwmsBusinessProspects c : SwmsBusinessProspects.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsBusinessProspects[] getAll() {
		return SwmsBusinessProspects.values();
	}
}
