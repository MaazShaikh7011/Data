package com.opl.jns.oneform.api.enums;

public enum QuotaSelection {
	
	MERIT(1l,"Merit"),MANAGEMENT(2L,"Management");
	
	private Long id;
	private String value;

	private QuotaSelection(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static QuotaSelection fromId(Long v) {
		for (QuotaSelection c : QuotaSelection.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static QuotaSelection[] getAll() {
		return QuotaSelection.values();
	}

}
