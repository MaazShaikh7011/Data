package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmReligion {

    HINDU(1, "Hindu"),
    MUSLIM(2, "Muslim"),
    CHRISTIAN(3, "Christian"),
    PARSI(4, "Parsi"),
    BUDHISM(5, "Budhism"),
    SIKH(6, "Sikh");

    private Integer id;
    private String value;

    private NrlmReligion(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmReligion fromId(Integer v) {
        for (NrlmReligion c : NrlmReligion.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmReligion fromName(String v) {
        for (NrlmReligion c : NrlmReligion.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmReligion[] getAll() {
        return NrlmReligion.values();
    }

}
