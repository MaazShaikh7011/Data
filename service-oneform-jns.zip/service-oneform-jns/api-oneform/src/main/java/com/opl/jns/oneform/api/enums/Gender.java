package com.opl.jns.oneform.api.enums;

public enum Gender {

	MALE(1l, "Male","Male"),
	FEMALE(2l, "Female","Female"), 
	THIRD_GENDER(3l, "Other","Other");
	

	private Long id;
	private String value;
	private final String cibilValue;

	private Gender(Long id, String value,String cibilValue) {
		this.id = id;
		this.value = value;
		this.cibilValue = cibilValue;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getCibilValue() {
		return cibilValue;
	}

	public static Gender fromId(Long v) {
		for (Gender c : Gender.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Gender[] getAll() {
		return Gender.values();
	}

}
