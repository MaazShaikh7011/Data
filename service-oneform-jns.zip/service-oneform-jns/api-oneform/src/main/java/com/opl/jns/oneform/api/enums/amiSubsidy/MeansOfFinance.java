package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum MeansOfFinance {
	
	PROMOTER_CONTRIBUTION(1, "Promoters contribution"), TERM_LOAN(2, "Term loan");

	private Integer id;
	private String value;

	private MeansOfFinance(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MeansOfFinance fromId(Integer v) {
		for (MeansOfFinance c : MeansOfFinance.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MeansOfFinance[] getAll() {
		return MeansOfFinance.values();
	}

}
