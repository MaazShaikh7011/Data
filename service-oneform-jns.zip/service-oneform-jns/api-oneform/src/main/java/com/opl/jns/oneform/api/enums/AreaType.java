package com.opl.jns.oneform.api.enums;

public enum AreaType {
	LAND_AREA(1L,"Land Area"),
	BUILT_UP_AREA(2L,"Built up Area"),
	CARPET_AREA(3L,"Carpet Area");
	
	private Long id;
	private String value;

	private AreaType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AreaType fromId(Long v) {
		for (AreaType c : AreaType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AreaType[] getAll() {
		return AreaType.values();
	}
}
