package com.opl.jns.oneform.api.enums;

public enum EduMinorityCategory {
	
	BUDDHISTS(1,"Buddhists"),
	MUSLIMS(2,"Muslims"),
	CHRISTIANS(3,"Christians"),
	SIKHS(4,"Sikhs"),
	JAINS(5,"Jains"),
	ZOROASTRIANS(6,"Zoroastrians");

	private Integer id;
	private String value;

	private EduMinorityCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EduMinorityCategory fromId(Integer v) {
		for (EduMinorityCategory c : EduMinorityCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static EduMinorityCategory[] getAll() {
		return EduMinorityCategory.values();
	}

}
