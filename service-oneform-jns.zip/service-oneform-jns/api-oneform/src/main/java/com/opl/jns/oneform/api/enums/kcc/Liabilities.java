package com.opl.jns.oneform.api.enums.kcc;

public enum Liabilities {
	
	BANKS(1l, "Banks"), LAND_DEVELOPMENT_BANKS(2l, "Land Development Bank"),
	CO_OPERATIVE_SOCIETY(3l, "Co Operative Society"), GUARANTOR_FOR_OTHER_LOANS(4l, "Guarantor for other Loans"),
	LOANS_FROM_PRIVATE_PERSONS(5l, "Loans from Private persons");

	private Long id;
	private String value;

	private Liabilities(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Liabilities fromId(Long v) {
		for (Liabilities c : Liabilities.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Liabilities[] getAll() {
		return Liabilities.values();
	}
}
