package com.opl.jns.oneform.api.enums;

public enum BankList {
	
	AbasahebPatilRendal("Abasaheb Patil Rendal Sahakari Bank Ltd","AbasahebPatilRendal","625","","","-", 1L),
    AbhinandanUrbanCoOpBankLtd("Abhinandan Urban Co-Op Bank Ltd","AbhinandanUrbanCoOpBankLtd","612","","","ABHIURB", 2L),
    AbhudayaCoOpp("Abhudaya Co-Op bank Ltd","Abhudaya Co-Op bank Ltd","151","","","-", 3L),
    AbhyudayaCoOpBank("Abhyudaya CoOp Bank","","","ABHYUDAYA_CO_OP_BANK","","ABHYUDAYA CO", 4L),
    AcmeBankLtd("Acme Bank Ltd","Acme Bank Ltd","998","","","-", 5L),
    AdarshBank("Adarsh Bank, India","Adarsh Bank, India","161","","","-", 6L),
    AdarshCoOperativeBankLtd("Adarsh Co Operative Bank Ltd","AdarshCoOperativeBankLtd","","Adarsh_Co_Operative_Bank_Ltd","","ADARSHBANK", 7L),
    ADCB("ADCB", "ADCB, India","3","","","-", 8L),
    AdinathCoOpBank ("Adinath Co Op Bank","AdinathCoOpBank","","AdinathCoOpBank","","ADINATH COOP", 9L),
    AgrasenCoop ("Agrasen Co-op Urban Bank","AgrasenCoopUrbanBank","541","","","AGRASENCB", 10L),
    AhmedabadDistrictCoOpBank("Ahmedabad District Co Op Bank","AhmedabadDistrictCoOpBank","","AHMEDABAD_DISTRICT_CO_OP_BANK","","AHMEDADCB", 11L),
    AhmedabadDistrictCoOpBankLtd("Ahmedabad District Co-Op. Bank Ltd","Ahmedabad District Co-Op. Bank Ltd","414","","","AHMEDADCB", 12L),
    AhmedabadMercantileCoOpp("Ahmedabad Mercantile Co-op Bank Ltd","Ahmedabad Mercantile Co-op Bank Ltd","79","","","AMCOBANKLIMITED", 13L),
    AhmednagarShaharSahakariBank("Ahmednagar Shahar Sahakari Bank","AhmednagarShaharSahakariBank","709","","","SAHAR MARYADIT", 14L),
    AirtelPaymentsBankIndia ("Airtel Payments Bank India","AirtelPaymentsBankIndia","267","AIRTEL_BANK","","-", 15L),
    AkhandAnandCoOperativeBankLtdIndia  ("Akhand Anand CoOperative Bank Ltd India","AkhandAnandCoOperativeBankLtdIndia","247","AKHAND_ANAND","","AKHANDACBL", 16L),
    AkolaDistrict  ("Akola District Central Co-Op. Bank Ltd","Akola District Central Co-Op. Bank Ltd","472","TJSB","","AKOLADCCB", 17L),
    AkolaJantaCommercial("Akola Janata Commercial Co-Op. Bank Ltd, India","Akola Janata Commercial Co-Op. Bank Ltd, India","342","","","AKOLA", 18L),
    AllahabadBankIndia  ("Allahabad Bank India","AllahabadBankIndia","4","ALLAHABAD","23","ALLAHABAD BANK", 19L),
    AmarnathCoOpp("Amarnath Co-Op. Bank Ltd, India","Amarnath Co-Op. Bank Ltd, India","516","","","AMARCOOP", 20L),
    AmbernathJaiHindCoOpBankLtdIndia ("Ambernath JaiHind CoOpBank Ltd India","AmbernathJaiHindCoOpBankLtdIndia","248","AMBERNATH_JAI_HIND_CO_OP_BANK","","AMBERNATH COOP", 21L),
    AmericanExpressBankIndia ("American Express Bank India","AmericanExpressBankIndia","5","","","AMEX ", 22L),
    AndhraBankIndia ("Andhra Bank India","Andhra Bank India","6","ANDHRA_BANK","26","ANDHRA BANK", 23L),
    AndhraPradeshGrameenaVikasBankIndia ("AndhraPradesh Grameena Vikas Bank India","AndhraPradeshGrameenaVikasBankIndia","193","","","APGM", 24L),
    AndhraPragathiGrameena("Andhra Pragathi Grameena Bank","Andhra Pragathi Grameena Bank","499","","","APGM", 25L),
    AnnasahabMagarSahakariBank ("Annasahab Magar Sahakari Bank","AnnasahabMagarSahakariBank","","ANNASAHAB_MAGAR_SAHAKARI_BANK","","ANNASAHEBMSB", 26L),
    ApnaSahakariBank ("Apna Sahakari Bank","","","APNA_SAHAKARI_BANK","","APNA SAHA", 27L),
    ArihantCoOpp("Arihant Co-operative Bank Ltd","Arihant Co-operative Bank Ltd","468","","","ARIHANTCOOP", 28L),
    ArvindSahakariBank("Arvind Sahakari Bank","ArvindSahakariBank","182","","","ARVIND SAHAKARI", 29L),
    AssamGraminVikashBankLtd("Assam Gramin Vikash Bank Ltd","AssamGraminVikashBankLtd","767","","","ASSAM GRAMEEN", 30L),
    AssociateCoOpBank("Associate CoOpBank","","","ASSOCIATE_CO_OP_BANK","","ASSOCIATECO", 31L),
    AUSmallFinanceBank("AU Small Finance Bank","AU Small Finance Bank, India","196", "AU_SMALL_FINANCE_BANK","","AU SFB", 32L),
    AxisBankIndia("Axis Bank India","AxisBankIndia","2","AXIS","3","AXIS BANK", 33L),
    BandhanBankIndia ("Bandhan Bank India","BandhanBankIndia","156","BANDHAN","","BANDHAN BANK", 34L),
    BankOfAmerica ("Bank Of America","BankOfAmerica","","BANK_OF_AMERICA","","BANK OF AMERICA", 35L),
    BankofBarodaIndia("Bank of Baroda India","BankofBarodaIndia","8","BANK_OF_BARODA","17","BOB", 36L),
    BankofIndiaIndia ("Bank of India India","BankofIndiaIndia","9","BANK_OF_INDIA","14","BOI", 37L),
    BankofMaharashtraIndia  ("Bank of Maharashtra India","BankofMaharashtraIndia","10","BANK_OF_MAHARASHTRA","27","BOM", 38L),
    BankuraDistrictCentralCoOpBank("Bankura District Central Co-Op Bank","BankuraDistrictCentralCoOpBank","645","","","BANKURADCCB", 39L),
    BaramatiCooperativeBank ("Baramati Co-operative Bank","BaramatiCooperativeBank","567","","","BARAMATI", 40L),
    BarclaysBankIndia("Barclays Bank India","BarclaysBankIndia","73","","","BARCLAYS BANK", 41L),
    BarodaRajasthanKshetriyaGraminBank ("BARODA RAJASTHAN KSHETRIYA GRAMIN BANK","BankofBarodaIndia","","BARODA_RAJASTHAN_KSHETRIYA_GRAMIN_BANK","","BARODARAJKGB", 42L),
    BasseinCatholic ("Bassein Catholic","Bassein Catholic Co-Op. Bank Ltd","387","BASSEIN_CATHOLIC","","BASSEIN", 43L),
    BhaginiNiveditaSahakariBankLtd("Bhagini Nivedita Sahakari Bank Ltd","BhaginiNiveditaSahakariBankLtd","694","","","BHAGININIVEDITA", 44L),
    BhagyodayaCoOp("Bhagyodaya Co-Op. Bank Ltd","Bhagyodaya Co-Op. Bank Ltd","531","","","TBHAGCBL", 45L),
    BhagyodayaCoOpBank ("Bhagyodaya Co Op Bank","BhagyodayaCoOpBank","","Bhagyodaya Co Op Bank","","TBHAGCBL", 46L),
    Bharat  ("Bharat","","","BHARAT","","-", 47L),
    BharatiSahakariBank("Bharati Sahakari Bank","BharatiSahakariBank","641","","","BHARTI", 48L),
    BhartiyaMahilaBank  ("Bhartiya Mahila Bank","","","BHARTIYA_MAHILA_BANK","","BMBL", 49L),
    BicholimUrbanCoOpBank("Bicholim Urban Co-Op Bank","BicholimUrbanCoOpBank","646","","","BICHOLIMCOP", 50L),
    BiharGraminBank("Bihar Gramin Bank Ltd, India","Bihar Gramin Bank Ltd, India","536","","","BIHARGB", 51L),
    BNPParibasIndia ("BNP Paribas India","BNPParibasIndia","7","","","BNP PARIBAS", 52L),
    BombayMercantileCoOperativeBankLtdIndia ("Bombay Mercantile CoOperative Bank Ltd.India","BombayMercantileCoOperativeBankLtd.India","183","","","BOMMER", 53L),
    BuldanaUrbanCoOpCreditSociety("Buldana Urban Co-Op Credit Society","BuldanaUrbanCoOpCreditSociety","695","","","BULDANACEN", 54L),
    CanaraBankIndia ("Canara Bank India","CanaraBankIndia","11","CANARA","12","CANARA BANK", 55L),
    CapitalLocalAreaBank("Capital Local Area Bank","Capital Local Area Bank","118","","","-", 56L),
    CapitalSmallFinanceBankIndia ("Capital Small Finance Bank India","CapitalSmallFinanceBankIndia","222","CAPITAL_SMALL_FINANCE_BANK_LTD","","CAPITAL", 57L),
    CatholicSyrianBankIndia ("Catholic Syrian Bank India","CatholicSyrianBankIndia","111","CATHOLIC_SYRIAN","","CATHOLIC SYRIAN", 58L),
    CentralBankofIndiaIndia ("Central Bank of India India","CentralBankofIndiaIndia","12","CENTRAL_BANK","25","CENTRAL BANK", 59L),
    CentralCoOperativeBank  ("Central CoOperative Bank","","","CENTRAL_CO_OPERATIVE_BANK","","CENTRALARA", 60L),
    ChhattisgarhRajyaGraminBank("Chhattisgarh Rajya Gramin Bank","ChhattisgarhRajyaGraminBank","626","","","CHHATTISGARH RGB", 61L),
    CitibankIndia("Citibank India","CitibankIndia","14","CITY","","CITIBANK", 62L),
    CitizenCreditCoOpp("Citizen Credit Co-Op. Bank Ltd","Citizen Credit Co-Op. Bank Ltd","385","","","CITIZENCREDIT", 63L),
    CitizensCoOpBankLtd("Citizens Co-Op. Bank Ltd","Citizens Co-Op. Bank Ltd","413","","","CITIZN RAJKOT", 64L),
    CityUnionBankIndia  ("City Union Bank India","CityUnionBankIndia","57","CITY_UNION","","CITY UNION", 65L),
    CorporationBankIndia ("Corporation Bank India","CorporationBankIndia","15","CORPORATION","24","CORP BANK", 66L),
    CosmosBank  ("Cosmos Bank","","","COSMOS_BANK","","-", 67L),
    CosmosCoOpp("Cosmos Co-op. Bank Ltd.","Cosmos Co-op. Bank Ltd.","83","","","COSMOS", 68L),
    DBSBankIndia ("DBS Bank India","DBSBankIndia","16","DBS","","DBS", 69L),
    DCBIndia ("DCB India","DCBIndia","18","DCB","","DCB", 70L),
    DeccanMerchantsCoOpBank("Deccan Merchants Co Op Bank","Deccan Merchants Co Op Bank","","Deccan_Merchants_Co_Op_Bank","","DECCANMCOOP", 71L),
    DeccanMerchantsCoOpp("Deccan Merchants Co-op Bank Ltd,","Deccan Merchants Co-op Bank Ltd,","120","","","DECCANMCOOP", 72L),
    DeendayalNagariSahakari("Deendayal Nagari Sahakari","DeendayalNagariSahakari","542","","","DEENDAYAL", 73L),
    DeepakSahakariBankLtdIndia  ("Deepak Sahakari Bank Ltd India","DeepakSahakariBankLtdIndia","249","","","DEEPAKSAH", 74L),
    DenaBankIndia("Dena Bank India","DenaBankIndia","17","DENA_BANK","9","DENA BANK", 75L),
    DeogiriNagariSahakariBank("Deogiri Nagari Sahakari Bank Ltd","DeogiriNagariSahakariBank","635","","","DEOGIRI", 76L),
    DeutscheBankIndia("Deutsche Bank India","DeutscheBankIndia","49","DEUTSCHE_BANK","","DEUTSCHE BANK", 77L),
    DhanalakshmiBankLtdIndia ("Dhanalakshmi Bank Ltd.India","DhanalakshmiBankLtd.India","71","DHANLAXMI","","DHANLAXMI BANK", 78L),
    DMKJaoliBank("DMK Jaoli Bank","DMKJaoliBank","596","","","DATTATRAYA", 79L),
    DNB ("DNB","","","DNB","","DNB", 80L),
    DNS ("DNS","","","DNS","","DNS", 81L),
    DombivliNagariSahakariBankIndia ("Dombivli Nagari Sahakari Bank India","DombivliNagariSahakariBankIndia","192","","","DOMBIVLI", 82L),
    DrAnnasahebChougule("Dr. Annasaheb Chougule Urban Co-Op. Bank Ltd","Dr. Annasaheb Chougule Urban Co-Op. Bank Ltd","200","","","ANNASAHEB", 83L),
    DrBabasahebAmbedkarMultistateCoOpBank("Dr Babasaheb Ambedkar Multistate Co Op Bank","DrBabasahebAmbedkarMultistateCoOpBank","","DR_BABASAHEB_AMBEDKAR_MULTISTATE_CO_OP_BANK","","DRSAHEB", 84L),
    EquitasBankIndia ("Equitas Bank India","EquitasBankIndia","224","EQUITAS_SMALL_FINANCE_BANK","","-", 85L),
    ESAFSmallFinanceBank("ESAF Small Finance Bank","ESAFSmallFinanceBank","589","","","ESAFSFB", 86L),
    FederalBankIndia ("Federal Bank India","FederalBankIndia","19","FEDERAL","57","FEDERAL BANK", 87L),
    FincareSmallFinanceBank("Fincare Small Finance Bank","FincareSmallFinanceBank","592","","","FINCARESFB", 88L),
    FinGrowthCoOpbankLtdIndia("FinGrowth CoOpbank Ltd.India","FinGrowthCoOpbankLtd.India","152","","","URBAN JAIPUR", 89L),
    FinoPaymentBank("Fino Payment Bank ","Fino Payment Bank ","388","","","-", 90L),
    GandhibagSahakariBankLtd("Gandhibag Sahakari Bank Ltd","GandhibagSahakariBankLtd","543","","","GANDHINAG", 91L),
    GPParsikBankIndia("GPParsik Bank India","GPParsikBankIndia","173","GP_PARSIK_BANK","","GPPARSIK", 92L),
    GreaterBombayCoopBankLtdIndia("Greater Bombay CoopBank Ltd India","GreaterBombayCoopBankLtdIndia","265","GREATER_BOMBAY","","TGBCBL", 93L),
    GujaratAmbujaCoOpBankLtdIndia("Gujarat Ambuja CoOpBank Ltd.India","GujaratAmbujaCoOpBankLtd.India","186","","","GUJARAT AMBUJA", 94L),
    GujaratStateCoOpBank("Gujarat State Co Op Bank","GujaratStateCoOpBank","","Gujarat_State_Co_Op_Bank","","GUJSTATECOOP", 95L),
    GujaratStateCoOpBankLtd("Gujarat State Co-Op. Bank Ltd","GujaratStateCo-Op.BankLtd","530","","","GUJSTATECOOP", 96L),
    HastiCoOpBank  ("Hasti Co-Op Bank","HastiCoOpBank","637","","","HASTICBL", 97L),
    HDFCBankIndia("HDFC Bank India","HDFCBankIndia","20","HDFC","32","HDFC BANK", 98L),
    HimatnagarNagarikSahakari("Himatnagar Nagarik Sahakari Bank Ltd","Himatnagar Nagarik Sahakari Bank Ltd","508","","","HIMATNAG", 99L),
    HindusthanCoOpBankLtdIndia  ("Hindusthan CoOpBank Ltd India","HindusthanCoOpBankLtdIndia","260","","","HINDUCB", 100L),
    HPStateCoOpBankLtd ("HP State Co-Op Bank Ltd","HPStateCo-OpBankLtd","554","","","HP STATE COOP", 101L),
    HSBCIndia("HSBC India","HSBCIndia","21","HSBC","","HSBC", 102L),
    ICICIBankIndia  ("ICICI Bank India","ICICIBankIndia","22","ICICI","4","ICICI BANK", 103L),
    IDBIIndia("IDBI India","IDBIIndia","23","IDBI","5","IDBI LTD", 104L),
    IDFCBankIndia("IDFC Bank India","IDFCBankIndia","140","IDFC","8","IDFC FIRST BANK", 105L),
    ImphalUrbanCooperative("Imphal Urban Co-operative Bank Ltd","Imphal Urban Co-operative Bank Ltd","469","","","IMPHALUCBL", 106L),
    IndianBankIndia ("Indian Bank India","IndianBankIndia","24","INDIAN_BANK","13","INDIAN BANK", 107L),
    IndianOverseasBankIndia ("Indian Overseas Bank India","IndianOverseasBankIndia","25","INDIAN_OVERSEAS","28","IOB", 108L),
    IndoreParasparSahakariBank ("Indore Paraspar Sahakari Bank","IndoreParasparSahakariBank","642","","","INDORE PARASPAR", 109L),
    IndraprasthaSehkariBank ("Indraprastha Sehkari Bank","","","INDRAPRASTHA_SEHKARI_BANK","","INDRAPRASTHA", 110L),
    IndrayaniCoOpBank  ("Indrayani Co-Op Bank","IndrayaniCoOpBank","638","","","INDRAYANI", 111L),
    IndusIndBankIndia("IndusInd Bank India","IndusIndBankIndia","26","INDUSIND","","INDUSIND BANK", 112L),
    IrinjalakudaTownCoOpBankLtd ("Irinjalakuda Town Co-Op Bank Ltd","IrinjalakudaTownCoOpBankLtd","692","","","IRINJALAKUDA", 113L),
    J_and_K_BankIndia("J&K Bank India","J&KBankIndia","27","JAMMU_KASHMIR","","J&K BANK", 114L),
    JaiTuljabhavaniUrban("Jai Tuljabhavani Urban Co-Op Bank","Jai Tuljabhavani Urban Co-Op Bank","479","","","JAITULJA", 115L),
    JaiTuljabhavaniUrbanCoOpBank("Jai Tuljabhavani Urban Co Op Bank","JaiTuljabhavaniUrbanCoOpBank","252","Jai_Tuljabhavani_Urban_Co_Op_Bank","","JAITULJA", 116L),
    JalgaonJantaBank("Jalgaon Janata Bank","Jalgaon Janata Bank","115","","","-", 117L),
    JalgaonPeoplesCoOpBank("Jalgaon Peoples Co-Op Bank Ltd","Jalgaon Peoples Co-Op Bank Ltd","509","","","JALGAON PCBL", 118L),
    JaloreNagrikSahBankLtdIndia ("Jalore Nagrik Sah Bank Ltd India","JaloreNagrikSahBankLtdIndia","250","","","JALORENAG", 119L),
    JamiaCoOpBankLtd("Jamia Co-Op Bank Ltd","JamiaCoOpBankLtd","705","","","JAMIACOOP", 120L),
    JamshedpurUrbanCoOpBankLtd("Jamshedpur Urban Co-Op Bank Ltd","JamshedpurUrbanCoOpBankLtd","706","","","JAMSHEDPUR COOP", 121L),
    JanakalyanSahakariBank  ("Janakalyan Sahakari Bank","","","JANAKALYAN_SAHAKARI_BANK","","JANAKALYAN SAH", 122L),
    JanasevaSahakariBankLtdIndia ("Janaseva Sahakari Bank Ltd India","JanasevaSahakariBankLtdIndia","251","JANASEVA_SAHAKARI_BANK","","JANASEVA ", 123L),
    JanaSmallFinanceBank("Jana Small Finance Bank","Jana Small Finance Bank","538","","","-", 124L),
    JanataSahakariBankIndia ("Janata Sahakari Bank India","JanataSahakariBankIndia","158","JANATA_SAHAKARI_BANK","","JANATA SATARA", 125L),
    JanathaSevaCoOpp("Janatha Seva Co-Op. Bank Ltd,","Janatha Seva Co-Op. Bank Ltd,","394","","","JANATHASEV", 126L),
    JankalyanSahakariBank("Jankalyan Sahakari Bank","Jankalyan Sahakari Bank","466","","","JANKALYANCBL", 127L),
    JayPrakashNarayanNagariSahakariBankLtdIndia ("Jay Prakash Narayan Nagari Sahakari Bank LtdIndia","JayPrakashNarayanNagariSahakariBankLtdIndia","252","","","-", 128L),
    JharkhandRajyaGraminBank("Jharkhand Rajya Gramin Bank","JharkhandRajyaGraminBank","651","","","JHARKHAND", 129L),
    JijamataMahilaSahakariBank("Jijamata Mahila Sahakari Bank","JijamataMahilaSahakariBank","644","","","JIJAMATA ", 130L),
    JivanCommercialCoOpBankLtd("Jivan Commercial Co-Op Bank Ltd","JivanCommercialCoOpBankLtd","708","","","JIVAN", 131L),
    KallappannaAwadeBank("Kallappanna Awade Bank","KallappannaAwadeBank","","Kallappanna_Awade_Bank","","KALLAPPANNA", 132L),
    KallappannaAwadeIchalkaranjiJanataSahakariBank("Kallappanna Awade Ichalkaranji Janata Sahakari Bank","Kallappanna Awade Ichalkaranji Janata Sahakari Bank","412","","","KALLAPPANNA", 133L),
    KalyanJanataSahakariBankLtdIndia ("Kalyan Janata Sahakari Bank Ltd India","KalyanJanataSahakariBankLtdIndia","343","KALYAN_JANATA_SAHAKARI_BANK","","KALYANJAN", 134L),
    KangraCoopBankLtdIndia  ("Kangra CoopBank Ltd India","KangraCoopBankLtdIndia","225","KANGRA_CO_OP_BANK","","KANGRACBL", 135L),
    KankariaaManinagarNagSahBankLtd("Kankariaa Maninagar NAG.SAH.BANK LTD","KankariaaManinagarNag.Sah.BankLtd","693","KANKARIAA_MANINAGAR_NAG_SAH_BANK_LTD","","KANKARIA", 136L),
    KarnalaNagariSahakariBank("Karnala Nagari Sahakari Bank","KarnalaNagariSahakariBank","647","","","-", 137L),
    KarnatakaBankIndia  ("Karnataka Bank India","KarnatakaBankIndia","51","KARNATAKA","","KARNATAKA BANK", 138L),
    KarnatakaCentralCoOpBankLtd("Karnataka Central Co-Op Bank Ltd","KarnatakaCentralCoOpBankLtd","768","","","KARNCENTCO", 139L),
    KarnatakaVikasGrameenaBank("Karnataka Vikas Grameena Bank Ltd","Karnataka Vikas Grameena Bank Ltd","533","","","KARNATAKA GRAMEEN", 140L),
    KarurVysyaBankIndia ("KarurVysya Bank India","KarurVysyaBankIndia","50","KARUR_VYASA","","-", 141L),
    KashipurUrbanCoOpBankLtdIndia("Kashipur Urban CoOp Bank Ltd.India","KashipurUrbanCoOpBankLtd.India","164","","","KASHIPURUCBL", 142L),
    KaveriGrameenaBank("Kaveri Grameena Bank","Kaveri Grameena Bank","501","","","KAVERIGB", 143L),
    KEBHanaBank("KEB Hana Bank","KEBHanaBank","754","","","KEBHANA", 144L),
    KeralaGraminBankLtd("Kerala Gramin Bank Ltd","KeralaGraminBankLtd","539","","","KERALAGB", 145L),
    KhamgaonUrbankCoopBankLtdIndia  ("Khamgaon Urbank CoopBank Ltd India","KhamgaonUrbankCoopBankLtdIndia","227","","","TKHAMUCBL", 146L),
    KhardahCoOpBankLtd("Khardah Co-Op Bank Ltd","KhardahCoOpBankLtd","756","","","KHARDAHCO", 147L),
    KokanMercantileCoOp("Kokan Mercantile Co-Op","Kokan Mercantile Co-Op","513","","","KOKAN MER", 148L),
    KolhapurDistrictCentralCoOperativeBankLtd("Kolhapur District Central Co-Operative Bank Ltd","KolhapurDistrictCentralCo-OperativeBankLtd","578","","","-", 149L),
    KolhapurMahilaSahakariBankLtd("Kolhapur Mahila Sahakari Bank Ltd","KolhapurMahilaSahakariBankLtd","607","","","Kolhapur Mahila", 150L),
    KolhapurUrbanCoOpBank("Kolhapur Urban Co-Op Bank","KolhapurUrbanCoOpBank","613","","","KOLHABAN", 151L),
    KopargaonPeoplesCoOpBank("Kopargaon Peoples Co-Op Bank","KopargaonPeoplesCoOpBank","639","","","KOPARBANK", 152L),
    KotakMahindra_IngVysyaBankIndia ("Kotak Mahindra/Ing Vysya Bank India","KotakMahindra/IngVysyaBankIndia","28","KOTAK","30","KOTAK BANK", 153L),
    KukarwadaNagrik("Kukarwada Nagrik Sahakari Bank","Kukarwada Nagrik Sahakari Bank","399","","","KUKARWADA", 154L),
    KurmanchalBank("Kurmanchal Bank","KurmanchalBank","","KURMANCHAL_BANK","","KURMAN", 155L),
    KurmanchalBankIndia ("Kurmanchal Bank India","KurmanchalBankIndia","165","","","KURMAN", 156L),
    LakshmiVilasBankIndia("Lakshmi Vilas Bank India","LakshmiVilasBankIndia","77","LAKSHMI_VILAS","","LAKSHMI VILAS", 157L),
    LangpiDehangiRuralBank("Langpi Dehangi Rural Bank","Langpi Dehangi Rural Bank","503","","","LANGPIDRB", 158L),
    LaturUrbanCoOp("Latur Urban Co-Op","Latur Urban Co-Op","476","","","LATUR URBAN", 159L),
    LokmangalCoOpBank("Lokmangal Co-Op Bank","Lokmangal Co-Op Bank","510","","","LOKMANGAL", 160L),
    MahanagarCoOpp("Mahanagar Co-Op. Bank Ltd","Mahanagar Co-Op. Bank Ltd","400","","","-", 161L),
    MaharashtraGraminBank("Maharashtra Gramin Bank","MaharashtraGraminBank","511","Maharashtra_Gramin_Bank","","MGB", 162L),
    MaharastraGraminBankIndia("Maharastra GraminBank India","MaharastraGraminBankIndia","175","","","MGB", 163L),
    MahaveerCoOpUrbanBankLtd("Mahaveer Co-Op Urban Bank Ltd","MahaveerCoOpUrbanBankLtd","710","","","MAHAVEERBANK", 164L),
    MaheshBankIndia ("Mahesh Bank India","MaheshBankIndia","174","MAHESH_BANK","","-", 165L),
    MaheshSahakariBankLTD("Mahesh Sahakari Bank LTD","","","MAHESH_SAHAKARI_BANK_LTD","","MAHESH SAH", 166L),
    MaheshUrbanCoOperativeBankLtd("Mahesh Urban Co-Operative Bank Ltd","MaheshUrbanCo-OperativeBankLtd","577","","","MAHESHURB", 167L),
    MahilaVikashCoOpBankLtdIndia ("Mahila Vikash CoOp Bank Ltd India","MahilaVikashCoOpBankLtdIndia","261","","","MAHILAVIKAS", 168L),
    ManinagarCoOpp("Maninagar Co-Op. Bank Ltd","Maninagar Co-Op. Bank Ltd","384","","","MANINAGARCP", 169L),
    ManoramaCoOpBankLtd("Manorama Co-Op. Bank Ltd","ManoramaCo-Op.BankLtd","529","","","-", 170L),
    ManoramaCoOpBankSolapur("Manorama Co Op Bank Solapur","Manorama Co Op Bank Solapur","","Manorama_Co_op_Bank_Solapur","","-", 171L),
    ManviPattanaSouharadaSahakariBank("Manvi Pattana Souharada Sahakari Bank","","","MANVI_PATTANA_SOUHARADA_SAHAKARI_BANK","","MANVI PATTANA", 172L),
    MehsanaUrbanCoOpBank ("Mehsana Urban CoOp Bank","Mehsana Urban CoOp Bank","91","MEHSANA_URBAN_CO_OP_BANK","","MEHASANA", 173L),
    MercantileCoOpBank("Mercantile Co-Op Bank","Mercantile Co-Op Bank","511","","","-", 174L),
    MjalgaonJalgaonJanataSahakariBank("Mjalgaon Jalgaon Janata Sahakari Bank","","","MJALGAON_JANATA_SAHAKARI_BANK","","-", 175L),
    ModelCoOperativeBank ("Model CoOperative Bank","","","MODEL_CO_OPERATIVE_BANK","","MODEL", 176L),
    MsantSopankakaSahakariBankLtdIndia  ("Msant Sopankaka Sahakari Bank Ltd India","MsantSopankakaSahakariBankLtdIndia","369","","","-", 177L),
    MSCoOpBankLtd("M S Co-Op. Bank Ltd","M S Co-Op. Bank Ltd","460","","","MSCOOPBANK", 178L),
    NagarikSamabayBankLtd("Nagarik Samabay Bank Ltd","NagarikSamabayBankLtd","605","","","NAGARIK", 179L),
    NagarUrbanCoOpp("Nagar Urban Co-Op. Bank Ltd","Nagar Urban Co-Op. Bank Ltd","392","","","NAGAR AHMED", 180L),
    NagpurNagarikSahakariBank("Nagpur Nagarik Sahakari Bank","Nagpur Nagarik Sahakari Bank","147","NAGPUR_NAGARIK_SAHAKARI_BANK","","NAGPURNAG", 181L),
    NainitalBankIndia("Nainital Bank India","NainitalBankIndia","166","NAINITAL","","NAINITAL BANK", 182L),
    NandedMerchantsCoOpBankLtd("Nanded Merchants Co-Op Bank Ltd","NandedMerchantsCo-OpBankLtd","555","","","TNANDMCBL", 183L),
    NationalBank("National Bank","NationalBank","623","","","-", 184L),
    NavapurMercantileCoOpBankLtdIndia("Navapur Mercantile CoOp Bank Ltd India","NavapurMercantileCoOpBankLtdIndia","253","","","NAVAPURCOOP", 185L),
    NavjeevanCoOpBankLtd("Navjeevan Co-Op Bank Ltd","NavjeevanCo-OpBankLtd","572","","","TNAVCBL", 186L),
    NavnirmanCoopBankLtdIndia("Navnirman CoopBank Ltd India","NavnirmanCoopBankLtdIndia","197","","","NAVNIRMAN", 187L),
    NavsarjanIndustrialCoOpBankLtd("Navsarjan Industrial Co-Op. Bank Ltd","Navsarjan Industrial Co-Op. Bank Ltd","458","","","NAVSARJAN", 188L),
    NawanagarCoopBankLtdIndia("Nawanagar CoopBank Ltd India","NawanagarCoopBankLtdIndia","199","","","NAWCBL", 189L),
    NeelkantCoOpBank("Neelkant Co-Op. Bank","NeelkantCo-Op.Bank","","NEELKANT_CO_OP_BANK","","NEELKAPUR", 190L),
    NeelkanthCoOpBank("Neelkanth Co-Op. Bank","Neelkanth Co-Op. Bank","474","","","NEELKAPUR", 191L),
    NewIndiaCoOpBankLtdIndia ("NewIndia CoOpBank Ltd.India","NewIndiaCoOpBankLtd.India","178","NEW_INDIA_CO_OP_BANK","","NEW INDIA", 192L),
    NidhiCoOpBankLtd("Nidhi Co-Op. Bank Ltd","Nidhi Co-Op. Bank Ltd","459","","","NIDHI", 193L),
    NKGSB("NKGSB Bank","NKGSB Bank","139","","","-", 194L),
    NkgsbCoOpBank("NKGSB Co Op Bank","NkgsbCoOpBank","","NKGSB_CO_OP_BANK","","NKGSB", 195L),
    NoidaCommercialCoOp("Noida Commercial Co-Op","Noida Commercial Co-Op","477","Noida_Commercial_Co_Op_Bank","","NOIDA COOP", 196L),
    NutanNagaikSahakariBank ("Nutan Nagaik Sahakari Bank","Nutan Nagaik Sahakari Bank","376","NUTAN_NAGARIK_SAHAKARI_BANK","","NUTANSAHAKARI", 197L),
    OceanFirst  ("Ocean First","","","OCEAN_FIRST","","-", 198L),
    OmkarNagreeyaSahakariBank  ("Omkar Nagreeya Sahakari Bank","OmkarNagreeyaSahakariBank","502","","","ONSBL", 199L),
    OmprakashDeoraPeoplesCoOpBankLtdIndia("Omprakash Deora Peoples CoOpBank Ltd India","OmprakashDeoraPeoplesCoOpBankLtdIndia","254","","","PEOPLECOOP", 200L),
    OrientalBankofCommerceIndia ("Oriental Bank of Commerce India","OrientalBankofCommerceIndia","29","ORIENTAL_BANK","21","OBC", 201L),
    OsmanabadJanataSahakariBankLtdIndia ("Osmanabad Janata Sahakari Bank Ltd India","OsmanabadJanataSahakariBankLtdIndia","266","","","OSMANJAN", 202L),
    PadmavathiCoOpUrbanBank("Padmavathi Co Op Urban Bank","PadmavathiCoOpUrbanBank","","PADMAVATHI_CO_OP_URBAN_BANK","","PADMAVATHI", 203L),
    PalusSahakariBankLtd("Palus Sahakari Bank Ltd","PalusSahakariBankLtd","772","","","PSBL", 204L),
    PandharpurUrbanCoopBankLtdIndia ("Pandharpur Urban CoopBank Ltd India","PandharpurUrbanCoopBankLtdIndia","194","","","PANDHARPUR URB", 205L),
    PanipatUrbanCoOpBankLtd("Panipat Urban Co-Op. Bank Ltd","Panipat Urban Co-Op. Bank Ltd","456","","","PANIPATURBAN", 206L),
    ParshwanathCoOpBankLtdIndia ("Parshwanath CoOp.BankLtd.India","ParshwanathCoOp.BankLtd.India","177","","","PARSHWANATH", 207L),
    PatanNagrikBank("Patan Nagarik Sahakari Bank Ltd","PatanNagrikBank","462","","","PATANNAG", 208L),
    PavanaSahakariBankLtd("Pavana Sahakari Bank Ltd","PavanaSahakariBankLtd","597","","","PAVANA PUNE", 209L),
    PaytmPaymentsBankIndia  ("Paytm Payments Bank India","PaytmPaymentsBankIndia","268","","","-", 210L),
    PeoplesCoOpBankLtdIndia ("Peoples CoOpBank Ltd India","PeoplesCoOpBankLtdIndia","255","","","PEOPLESCOOPKANPUR", 211L),
    PimpriChinchwadSahakariBank("Pimpri Chinchwad Sahakari Bank","Pimpri Chinchwad Sahakari Bank","505","","","PIMPRI ", 212L),
    PochampallyBank("Pochampally Bank","Pochampally Bank","659","","","POCHAMCOB", 213L),
    PostOfficeSavingBank("Post Office Saving Bank","PostOfficeSavingBank","598","","","-", 214L),
    PragathiCoOperativeBankLtd("Pragathi Co Operative Bank Ltd","PragathiCoOperativeBankLtd","576","","","PRAGATHI", 215L),
    PragatiSahakariBank("Pragati Sahakari Bank","Pragati Sahakari Bank","480","","","PRAGATISAH", 216L),
    PrathamaBank("Prathama Bank","Prathama Bank","396","","","PRATHAMA", 217L),
    PreranaCoOpBank("Prerana Co-Op. Bank","Prerana Co-Op. Bank","525","","","PRERANA", 218L),
    PrimeCoOpBank("Prime Co-Op. Bank","Prime Co-Op. Bank","520","PRIME_BANK","","PRIMECO", 219L),
    PriyadarshiniUrbanCoOpBankLtd("Priyadarshini Urban Co-Op Bank Ltd","PriyadarshiniUrbanCoOpBankLtd","704","","","PRIYABANK", 220L),
    ProgressiveMercCoOp("Progressive Merc. Co-Op","Progressive Merc. Co-Op","475","","","PROGMER", 221L),
    PuduppadiServiceCoOperativeBankLtd("Puduppadi Service Co-Operative Bank Ltd","PuduppadiServiceCo-OperativeBankLtd","587","","","-", 222L),
    PuneDistrictCentralCoOperativeBankLtd("Pune District Central Co-Operative Bank Ltd","PuneDistrictCentralCo-OperativeBankLtd","599","","","PUNEDCCB", 223L),
    PunePeoplesCoOpBankIndia ("Pune Peoples CoOpBank India","PunePeoplesCoOpBankIndia","189","PUNE_PEOPLES_CO_OP_BANK","","-", 224L),
    PuneUrbanCoOpBankLtdIndia("Pune Urban CoOpBank Ltd India","PuneUrbanCoOpBankLtdIndia","324","","","PUNE URBAN", 225L),
    PunjabandSindBankIndia  ("Punjaband Sind Bank India","PunjabandSindBankIndia","31","PUNJAB_SIND","20","PUNJAB & SIND ", 226L),
    PunjabMaharashtaraCoOpBank  ("Punjab Maharashtara CoOp Bank","Punjab Maharashtara CoOp Bank","78","PUNJAB_MAHARASHTRA_CO_OP_BANK","","PMCBANK", 227L),
    PunjabNationalBankIndia ("Punjab National Bank India","PunjabNationalBankIndia","30","PNB","18","PNB", 228L),
    PurvanchalBank("Purvanchal Bank","PurvanchalBank","","PURVANCHAL BANK","","PURVANCHALB", 229L),
    PurvanchalBankLtd("Purvanchal Bank Ltd","Purvanchal Bank Ltd","471","","","PURVANCHALB", 230L),
    PusadUrbanCoOpBankLtdIndia  ("Pusad Urban CoOpBank Ltd India","PusadUrbanCoOpBankLtdIndia","257","","","PUSADURBCO", 231L),
    RaboBank ("Rabo Bank","RaboBank","557","","","-", 232L),
    RaigadDistrictCentralCoOpBankLtd ("Raigad District Central Co-Op Bank Ltd","RaigadDistrictCentralCo-OpBankLtd","553","","","RAIGADDCCB", 233L),
    RajarambapuSahakariBankLtd ("Rajarambapu Sahakari Bank Ltd","RajarambapuSahakariBankLtd","585","","","RAJARAM", 234L),
    RajarshiShahuSahakariBankLtd ("Rajarshi Shahu Sahakari Bank Ltd","RajarshiShahuSahakariBankLtd","573","","","RAJSHAU", 235L),
    RajasthanMarudharaGraminBank("Rajasthan Marudhara Gramin Bank","Rajasthan Marudhara Gramin Bank","390","","","RAJMARGB", 236L),
    RajgurunagarSahakariBankLtd ("Rajgurunagar Sahakari Bank Ltd","RajgurunagarSahakariBankLtd","707","","","RAJGURUNAGAR", 237L),
    RajkotCommercialCoOp("Rajkot Commercial Co-Op","Rajkot Commercial Co-Op","517","","","RAJCOOP", 238L),
    RajkotNagarikSahakariBankLtd ("Rajkot Nagarik Sahakari Bank Ltd","RajkotNagarikSahakariBankLtd","608","","","RAJKOT SAHA", 239L),
    RajkotPeoplesCoOpBankLtdIndia("Rajkot Peoples CoOpBank Ltd.India","RajkotPeoplesCoOpBankLtd.India","195","","","RAJKOTPCBL", 240L),
    RamgarhiaCoOpBank("Ramgarhia Co-Op. Bank ","Ramgarhia Co-Op. Bank ","527","","","RAMGARHIA COOP", 241L),
    RBL_Ratnakar_BankIndia  ("RBL(Ratnakar)BankIndia","RBL(Ratnakar)BankIndia","81","RBL","6","RBL", 242L),
    RBS_ABNAMRO_India("RBS(ABNAMRO)India","RBS(ABNAMRO)India","48","RBS","","RBS", 243L),
    Rmgb("Rmgb","RMGB","527","RMGB","","RAJMARGB", 244L),
    RoyalBankOfScotland ("Royal Bank of Scotland","RoyalBankOfScotland","","RBS","","-", 245L),
    SadhanaSahakariBankLtd("Sadhana Sahakari Bank Ltd","SadhanaSahakariBankLtd","537","","","SADHANA", 246L),
    SahebraoDeshmukhCoOperativeBankLtd("Sahebrao Deshmukh Co-Operative Bank Ltd","SahebraoDeshmukhCo-OperativeBankLtd","600","","","SAHEBRAODES", 247L),
    SahydriSahakariBank("Sahydri Sahakari Bank","SahydriSahakariBank","","SAHYDRI_SAHAKARI_BANK","","SAHYADRI", 248L),
    SaibabaNagariSahakariBankLtd("Saibaba Nagari Sahakari Bank Ltd","SaibabaNagariSahakariBankLtd","728","","","SAIBABA", 249L),
    SamarthSahakariBankIndia ("Samarth Sahakari Bank India","SamarthSahakariBankIndia","159","","","SAMARTHA NAG", 250L),
    SamataSahkariBankLtd("Samata Sahkari Bank Ltd","SamataSahkariBankLtd","535","","","SAMATA", 251L),
    SangliDistrictCentralCoOpBankLtd("Sangli District Central Co-Op Bank Ltd","SangliDistrictCentralCoOpBankLtd","769","","","-", 252L),
    SangliUrbanCoOpBankLtd("Sangli Urban Co-Op. Bank Ltd","Sangli Urban Co-Op. Bank Ltd","455","","","SANGLIURBAN", 253L),
    SangolaUrbanCoOp("Sangola Urban Co-Op","Sangola Urban Co-Op","523","","","-", 254L),
    SangolaUrbanCoOperativeBankLtd("Sangola Urban Co Operative Bank Ltd","Sangola Urban Co Operative Bank Ltd","","SANGOLA_URBAN_CO_OPERATIVE_BANK_LTD","","SANGOLACO", 255L),
    SanmathiSahakariBank("Sanmathi Sahakari Bank","Seva Vikas Co Op Bank","","Sanmathi_Sahakari_Bank","","-", 256L),
    SanmatiSahakariBankLtd("Sanmati Sahakari Bank Ltd","SanmatiSahakariBankLtd","528","","","SANMATI", 257L),
    SarangpurCoOpBankLtdIndia("Sarangpur CoOp.Bank Ltd India","SarangpurCoOp.BankLtdIndia","344","","","THSARCBL", 258L),
    SaraspurNagarikCoOpBankLtdIndia ("Saraspur Nagarik CoOpBank Ltd.India","SaraspurNagarikCoOpBankLtd.India","185","SARASPUR_NAGARIK_CO_OP_BANK","","SARASCOOP", 259L),
    SaraswatBankIndia("Saraswat Bank India","SaraswatBankIndia","72","SARASWAT_BANK","2","-", 260L),
    SardarBhiladwalaPardiPeoplesCoOpBank ("Sardar Bhiladwala Pardi Peoples CoOpBank","","","SARDAR_BHILADWALA_PARDI_PEOPLES_CO _OP_BANK","","-", 261L),
    SardarBhiladwalaPardiPeoplesCoOperativeBankLtd("Sardar Bhiladwala Pardi People's Co-Operative Bank Ltd","SardarBhiladwalaPardiPeople'sCo-OperativeBankLtd","591","","","-", 262L),
    SarvaUPGraminBankLtd("Sarva UP Gramin Bank Ltd","SarvaUPGraminBankLtd","540","","","-", 263L),
    SarvodayaCommercialCoOperativeBankLtd("Sarvodaya Commercial Co-Operative Bank Ltd","SarvodayaCommercialCo-OperativeBankLtd","580","","","SARVODAYA", 264L),
    SarvodayaSahakariBank("Sarvodaya Sahakari Bank","Sarvodaya Sahakari Bank","393","SARVODAYA_SAHAKARI_BANK","","SARVMODASA", 265L),
    SaurashtraGraminBank ("Saurashtra Gramin Bank","Saurashtra Gramin Bank","386","SAURASHTRA_GRAMIN_BANK","","SAURAUSTRAGRA", 266L),
    SDC ("SDC","","","SDC","","-", 267L),
    SevaVikasCoOpBank("Seva Vikas Co Op Bank","Seva Vikas Co Op Bank","","Seva_Vikas_Co_Op_Bank","","SEVAVIKAS", 268L),
    ShaliniSahkariBankLtd("Shalini Sahkari Bank Ltd","ShaliniSahkariBankLtd","606","","","SHALINIBANK", 269L),
    ShamraoVittalCoOpp("Shamrao Vittal Co-Operative Bank Ltd","Shamrao Vittal Co-Operative Bank Ltd","76","","","-", 270L),
    SharadaSahkariBank("Sharada Sahkari Bank","Sharada Sahkari Bank","532","","","SHARDA PUNE", 271L),
    ShinhanBank("Shinhan Bank","ShinhanBank","711","","","SHINHAN", 272L),
    ShirpurPeopleCoOp("Shirpur People Co-Op","Shirpur People Co-Op","506","","","SHIRPEO", 273L),
    ShivajiraoBhosaleSahakariBankLtdIndia("Shivajirao Bhosale Sahakari Bank Ltd India","ShivajiraoBhosaleSahakariBankLtdIndia","258","","","SHIVAJIRAOPUNE", 274L),
    ShivalikMercantileBank("Shivalik Mercantile Bank","ShivalikMercantileBank","","SHIVALIK_MERCANTILE_BANK","","SHIVALIK", 275L),
    ShivalikMercantileCoOp("Shivalik Mercantile Co-Op. Bank Ltd","Shivalik Mercantile Co-Op. Bank Ltd","389","","","SHIVALIK", 276L),
    ShreeCoOpBankLtd(" Shree Co Op Bank LTD","ShreeCoOpBankLtd","","SHREE_CO_OP_BANK_LTD","","-", 277L),
    ShreeCoOpBankLtdIndia("ShreeCoOp.Bank Ltd India","ShreeCoOp.BankLtdIndia","375","","","-", 278L),
    ShreeDharatiCoOpBankLtd("Shree Dharati Co-Op Bank Ltd","ShreeDharatiCoOpBankLtd","660","","","-", 279L),
    ShreeKadiNagarikSahakariBankLtdIndia ("Shree Kadi Nagarik Sahakari Bank Ltd India","ShreeKadiNagarikSahakariBankLtdIndia","349","SHREE_KADI_NAGARIK_SAHAKARI_BANK","","SKADINSBL", 280L),
    ShreeMaheshCoOpBankLtd("Shree Mahesh Co-Op. Bank Ltd","Shree Mahesh Co-Op. Bank Ltd","524","","","MAHESHNASHIK", 281L),
    ShreeMaheshCoOpBankNashik("Shree Mahesh Co Op Bank Nashik","Shree Mahesh Co Op Bank Nashik","","Shree_Mahesh_Co_op_Bank_Nashik","","MAHESHNASHIK", 282L),
    ShriAnandCoOpBank("Shri Anand Co-Op. Bank","Shri Anand Co-Op. Bank","522","","","SHRI ANANDCOOP", 283L),
    ShriArihantCooperativeBank("Shri Arihant Cooperative Bank","ShriArihantCooperativeBank","","SHRI_ARIHANT_COOP_BANK","","ARIHANTCOOP", 284L),
    ShriChhatrapatiRajarshiShahuUrbanCoOpBankLtdIndia("Shri Chhatrapati Rajarshi Shahu Urban CoOpBank Ltd India","ShriChhatrapatiRajarshiShahuUrbanCoOpBankLtdIndia","259","","","RAJA SHAHU", 285L),
    ShriMahalaxmiCoOpBank  ("Shri Mahalaxmi Co-OpBank","ShriMahalaxmiCoOpBank","632","","","SHRIMAHALAXMI", 286L),
    ShriPanchgangaNagariSahakariBankLtd("Shri Panchganga Nagari Sahakari BankLtd","ShriPanchgangaNagariSahakariBankLtd","726","","","-", 287L),
    ShriRajkotDistrictCoOpBank("Shri Rajkot District Co Op Bank","ShriRajkotDistrictCoOpBank","","SHRI_RAJKOT_DISTRICT_CO_OP_BANK","","RAJKOTDCCB ", 288L),
    ShriShiveshwarNagariSahakariBankLtd("Shri Shiveshwar Nagari Sahakari Bank Ltd","ShriShiveshwarNagariSahakariBankLtd","611","","","SHIVESHNAGAR", 289L),
    ShriVeershaivCoOpBank("Shri Veershaiv Co-Op. Bank","Shri Veershaiv Co-Op. Bank","518","","","VEERSHAIV", 290L),
    Sidbi("Sidbi","Sidbi","","","10","SIDBI", 291L),
    SmritiNagrikSahakariBank("Smriti Nagrik Sahakari Bank","Smriti Nagrik Sahakari Bank","478","Smriti Nagrik Sahakari Bank","","SMRITI NAGRIK", 292L),
    SolapurJanataSahakariBank("Solapur Janata Sahakari Bank","","391","SOLAPUR_JANATA_SAHAKARI_BANK","","SOLAPUR JANATA", 293L),
    SouthIndianBankIndia ("South Indian Bank India","SouthIndianBankIndia","52","SOUTH_INDIAN","","SOUTH INDIAN BK", 294L),
    SreeMahayogiLakshmammaCoOp("Sree Mahayogi Lakshmamma Co-Op. Bank","Sree Mahayogi Lakshmamma Co-Op. Bank","397","","","-", 295L),
    SreeMahayogiLakshmammaCoOpBank("Sree Mahayogi Lakshmamma Co op bank","ShriArihantCooperativeBank","","SREE_MAHAYOGI_LAKSHMAMMA_CO_OP_BANK_LTD","","SREEMAHAYOGI", 296L),
    SreenidhiSouhardaSahakariBank("Sreenidhi Souharda Sahakari Bank","","","SREENIDHI_SOUHARDA_SAHAKARI_BANK","","SREENIDHISA", 297L),
    SreenidhiSouhardaSahakariBankNiyamitha("Sreenidhi Souharda Sahakari Bank Niyamitha","SreenidhiSouhardaSahakariBankNiyamitha","604","","","SREENIDHISA", 298L),
    SriBasaveshwarSahakariBank("Sri Basaveshwar Sahakari Bank","SriBasaveshwarSahakariBank","653","","","SBPSBANK", 299L),
    StandardCharteredBankIndia  ("Standard Chartered Bank India","StandardCharteredBankIndia","32","STANDARD_CHARTERED","","SCB", 300L),
    StateBankBikanerJaipur  ("State Bank Bikaner Jaipur","","","STATE_BANK_BIKANER_JAIPUR","","STATE BANK OF BIKANER AND JAIPUR", 301L),
    StateBankHyderabad  ("State Bank Hyderabad","","","STATE_BANK_HYDERABAD","","SBH", 302L),
    StateBankMysore ("State Bank Mysore","","","STATE_BANK_MYSORE","","SBM", 303L),
    StateBankofIndiaIndia("State Bank of India","StateBankofIndiaIndia","35","SBI","16","SBI", 304L),
    StateBankPatiala ("State Bank Patiala","","","STATE_BANK_PATIALA","","SBP", 305L),
    StateBankTravancore ("State Bank Travancore","","","STATE_BANK_TRAVANCORE","","SBT", 306L),
    SterlingUrbanCoOpBank("Sterling Urban Co-Op Bank","Sterling Urban Co-Op Bank","481","Sterling_Urban_Co_Op_Bank","","STERLING", 307L),
    SUCOBank("SUCO Bank","SUCO Bank","467","","","SUCOSAHA", 308L),
    SundarlalSawjiUrbanCoOpBankLtd("Sundarlal Sawji Urban Co-Op. Bank Ltd","Sundarlal Sawji Urban Co-Op. Bank Ltd","461","","","SUNDARLAL", 309L),
    SuratDistrictCoOpBank("Surat District Co-Op. Bank","Surat District Co-Op. Bank","473","","","SURATDCCB", 310L),
    SuratNationalCoOpBankLtd("Surat National Co-Op. Bank Ltd","Surat National Co-Op. Bank Ltd","464","","","SURATNAT", 311L),
    SuratPeoplesCoopBankLtdIndia ("Surat Peoples CoopBank Ltd India","SuratPeoplesCoopBankLtdIndia","244","","","SURATPEO", 312L),
    SuryodaySmallFinanceBank("Suryoday Small Finance Bank","Suryoday Small Finance Bank","507","","","SURYOFIN", 313L),
    SuryodaySmallFinanceBankLtd("Suryoday Small Finance Bank Ltd.","SuryodaySmallFinanceBankLtd","","SURYODAY_SMALL_FINANCE_BANK_LTD","","SURYOFIN", 314L),
    SutexCoopBankLtd("Sutex Co-op Bank Ltd","Sutex Co-op Bank Ltd","92","","","SUTEXCBL", 315L),
    SuvarnayugSahakariBank("Suvarnayug Sahakari Bank","SuvarnayugSahakariBank","574","","","SUVARNAYUG", 316L),
    SVCBank ("SVC Bank","","","SVC_BANK","","-", 317L),
    SyndicateBankIndia  ("Syndicate Bank India","SyndicateBankIndia","41","SYNDICATE","22","SYNDICATE BANK", 318L),
    TamilnadMercantileBankLtdIndia  ("Tamilnad Mercantile Bank Ltd.India","TamilnadMercantileBankLtd.India","75","TAMILNAD_MERCANTILE","","TN MERCANTILE", 319L),
    TelanganaGrameenaBank("Telangana Grameena Bank","Telangana Grameena Bank","500","","","DECCAN", 320L),
    TexcoCoOpBankLtd("Texco Co-Op. Bank Ltd","Texco Co-Op. Bank Ltd","415","","","-", 321L),
    TextileCoOperativeBank  ("Textile CoOperative Bank","","","TEXTILE_CO_OPERATIVE_BANK","","TEXTCO", 322L),
    TextileTradersCoOpBankLtd("Textile Traders Co-Op. Bank Ltd","Textile Traders Co-Op. Bank Ltd","401","","","TEXTILE TRADERS", 323L),
    TgmcBankLtd("TGMC Bank Ltd","TgmcBankLtd","","TGMC_BANK ","","-", 324L),
    ThaneBharatSahakariBank("Thane Bharat Sahakari Bank","ThaneBharatSahakariBank","","THANE_BHARAT_SAHAKARI_BANK_LTD","","THANEBSBL", 325L),
    ThaneBharatSahakariBankLtdIndia ("Thane Bharat Sahakari Bank Ltd India","ThaneBharatSahakariBankLtdIndia","226","","","-", 326L),
    TheAbhinavSahakariBankLtd("The Abhinav Sahakari Bank Ltd","TheAbhinavSahakariBankLtd","658","","","ABHINAV", 327L),
    TheAceCooperativeBankLtd("The Ace Co-operative Bank Ltd","TheAceCo-operativeBankLtd","569","","","-", 328L),
    TheAdinathCoOperativeBankLtdIndia("The Adinath CoOperative Bank Ltd.India","TheAdinathCoOperativeBankLtd.India","180","","","ADINATHSURAT", 329L),
    TheAhmedabadMercantileCoOpBank("The Ahmedabad Mercantile Co Op Bank","TheAhmedabadMercantileCoOpBank","","The_Ahmedabad_Mercantile_Co_Op_Bank","","AMCOBANKLIMITED", 330L),
    TheAhmednagarMerchantCoOpBankLtd("The Ahmednagar Merchant Co Op Bank Ltd","TheAhmednagarMerchantCoOpBankLtd","395","The_Ahmednagar_Merchant_Co_Op_Bank_Ltd","","-", 331L),
    TheAkolaDistrictCentralCoOpBank("The Akola District Central Co Op Bank","TheAkolaDistrictCentralCoOpBank","187","The_Akola_District_Central_Co_Op_Bank","","AKOLADCCB", 332L),
    TheBagatUrbanCoOperativeBankLtd("The Bagat Urban Co-Operative Bank Ltd","TheBagatUrbanCoOperativeBankLtd","691","","","BAGHATUCB", 333L),
    TheBanaskanthaMercantileCoOperativeBankLtdIndia ("The Banaskantha MercantileCo.Operative Bank Ltd India","TheBanaskanthaMercantileCo.OperativeBankLtdIndia","167","","","TBMCBL", 334L),
    TheBardoliNagarikSahakariBank("The Bardoli Nagarik Sahakari Bank","TheBardoliNagarikSahakariBank","649","","","BARDOLINAG", 335L),
    TheBhagyalashmiMahilaSahakariBankLtd("The Bhagyalashmi Mahila Sahakari Bank Ltd","TheBhagyalashmiMahilaSahakariBankLtd","595","","","TBHAGYAMSBL", 336L),
    TheBharatCoOperativeBank("The Bharat Co-Operative Bank","The Bharat Co-Operative Bank","122","","","BHARAT CO", 337L),
    TheBhujMercantileCoopBankLtdIndia("The Bhuj Mercantile Coop.BankLtd.India","TheBhujMercantileCoop.BankLtd.India","168","","","BHUJ", 338L),
    TheBurdwanCentralCoOpBank("The Burdwan Central Co-Op Bank","TheBurdwanCentralCoOpBank","633","","","BURDWANCCB", 339L),
    TheChanasmaNagrikSahakari("The Chanasma Nagrik Sahakari Bank","TheChanasmaNagrikSahakari","609","","","CHANASMA", 340L),
    TheCoOperativeBankofRajkotIndia ("The CoOperative Bankof Rajkot India","TheCoOperativeBankofRajkotIndia","162","","","COOP RAJKOT", 341L),
    TheDahodUrbanCoOpBankLtd("The Dahod Urban-Co-Op.Bank Ltd","TheDahodUrban-Co-Op.BankLtd","558","","","DAHODCOOP", 342L),
    TheEenaduCoOpUrbanBank("The Eenadu Co Op Urban Bank","TheEenaduCoOpUrbanBank","","The_Eenadu_Co_Op_Urban_Bank","","EENADUBANK", 343L),
    TheFinancialCoOpBankLtdIndia ("The Financial CoOpBank Ltd.India","TheFinancialCoOpBankLtd.India","188","","","TFCBL", 344L),
    TheGandeviPeoplesCoOpBank("The Gandevi People's Co-Op Bank","TheGandeviPeoplesCoOpBank","627","","","GANDEVI PEO", 345L),
    TheGandhidhamCooperativeBankLtd("The Gandhidham Cooperative Bank Ltd","TheGandhidhamCooperativeBankLtd","","The_Gandhidham_CoOperative_Bank_Ltd","","TGCBLA", 346L),
    TheGandhidhamMercantileCooperativeBankLtdIndia  ("The Gandhidham Mercantile Cooperative BankLtd.India","TheGandhidhamMercantileCooperativeBankLtd.India","169","TGMC_BANK","","GANDHIDHAM MER", 347L),
    TheGayatriCoOperativeUrbanBankLtdIndia  ("The Gayatri CoOperative Urban Bank Ltd.India","TheGayatriCoOperativeUrbanBankLtd.India","170","","","GAYATRICUBL", 348L),
    TheHindustanCoOpBankLtd("The Hindusthan Co Op Bank Ltd","TheHindustanCoOpBankLtd","","The_Hindusthan_Co_Op_Bank_Ltd","","HINDUCB", 349L),
    TheIncomeTaxDepartmentCoOpBank("The Income-Tax Department Co-Op Bank","TheIncomeTaxDepartmentCoOpBank","654","","","INCOMETAX", 350L),
    TheJainSahakariBank("The Jain Sahakari Bank","TheJainSahakariBank","624","","","JAINSAH", 351L),
    TheJalgaonPeoplesCoOpBank("The Jalgaon Peoples Co Op Bank","TheJalgaonPeoplesCoOpBank","","The_Jalgaon_Peoples_CoOp_Bank","","JALGAON PCBL", 352L),
    TheKairaDistrictCentralCoOpBank("The Kaira District Central Co-Op Bank","TheKairaDistrictCentralCoOpBank","621","","","KAIRACENTRAL", 353L),
    TheKalupurCommercialCoopBankLtdIndia ("The Kalupur Commercial Co.op. Bank Ltd.India","TheKalupurCommercialCo.op.BankLtd.India","154","KALUPUR_COMMERCIAL_CO_OP_BANK","","KALUPUR", 354L),
    TheKanakamahalakshmiCoOpBankLtd("The Kanakamahalakshmi Co Op Bank Ltd","TheKanakamahalakshmiCoOpBankLtd","","THE_KANAKAMAHALAKSHMI_CO_OP_BANK_LTD","","KANAKAMAHA", 355L),
    TheKanakamahalakshmiCoOperativeBankLtd("The Kanakamahalakshmi Co-Operative Bank Ltd","TheKanakamahalakshmiCo-OperativeBankLtd","586","","","KANAKAMAHA", 356L),
    TheKaradUrbanCoopBankIndia  ("The Karad Urban CoopBank India","TheKaradUrbanCoopBankIndia","176","","","KARAD", 357L),
    TheKaradUrbanCoOpBankLtd("The Karad Urban Co Op Bank LTD","TheKaradUrbanCoOpBankLtd","","THE_KARAD_URBAN_CO_OP_BANK_LTD","","KARAD", 358L),
    TheKarnatakaStateCoOperativeApexBankLtd("The Karnataka State Co-Operative Apex Bank Ltd","TheKarnatakaStateCo-OperativeApexBankLtd","568","","","KARSCAB", 359L),
    TheKarnavatiCoOpBankLtd("The Karnavati Co-Op Bank Ltd","TheKarnavatiCoOpBankLtd","724","","","KARNAVATI", 360L),
    TheKhattriCoOpUrbanBankLtd("The Khattri Co-Op Urban Bank Ltd","TheKhattriCoOpUrbanBankLtd","622","","","KHATTRI", 361L),
    TheKunbiSahakariBankLtd("The Kunbi Sahakari Bank Ltd","TheKunbiSahakariBankLtd","725","","","KUNBI", 362L),
    TheKurlaNagrikSahakariBankLtd("The Kurla Nagrik Sahakari Bank Ltd","TheKurlaNagrikSahakariBankLtd","703","","","TKNSBL", 363L),
    TheMogaveeraCoOpBankLtd("The Mogaveera Co Op Bank LTD","TheMogaveeraCoOpBankLtd","755","MOGAVEERA_CO_OP_BANK_LTD","","MOGAVEERAOP", 364L),
    TheMunicipalCoOpBankLtd("The Municipal Co-Op Bank Ltd","TheMunicipalCo-OpBankLtd","575","","","MUNIC COOP", 365L),
    TheNarodaNagrikCoOpBank ("The Naroda Nagrik CoOp Bank","","","THE_NARODA_NAGRIK_CO_OP_BANK","","NARODANAG", 366L),
    TheNashikRoadDeolaliVyapariSahakariBank("The Nashik Road Deolali Vyapari Sahakari Bank","TheNashikRoadDeolaliVyapariSahakariBank","650","","","NASIKVYAPAR", 367L),
    TheNasikMerchantsCoOperativeBankLtd("The Nasik Merchants Co-Operative Bank Ltd","TheNasikMerchantsCo-OperativeBankLtd","581","","","NASHIKMCOOP", 368L),
    ThePanchsheelMercantileCoOpBank("The Panchsheel Mercantile Co-Op Bank","ThePanchsheelMercantileCoOpBank","610","","","PANCHMER", 369L),
    ThePanchsheelMercantileCoOpBankLtd("The Panchsheel Mercantile Co Op Bank LTD","ThePanchsheelMercantileCoOpBankLtd","","THE_PANCHSHEEL_MERCANTILE_CO_OP_BANK_LTD","","PANCHMER", 370L),
    ThePanipatUrbanCoOpBank("The Panipat Urban Co Op Bank","ThePanipatUrbanCoOpBank","","The_Panipat_Urban_Co_Op_Bank","","PANIPATURBAN", 371L),
    TheRajkotCommercialCoOpBank("The Rajkot Commercial Co Op Bank","TheRajkotCommercialCoOpBank","","THE RAJKOT COMMERCIAL COOP BANK","","RAJCOOP", 372L),
    TheSabarkanthaDistrictCentralCoOpBankLtdIndia("The Sabarkantha District Central CoOp Bank Ltd.India","TheSabarkanthaDistrictCentralCoOpBankLtd.India","190","","","SABARKANTHA", 373L),
    TheSataraSahakariBankLtdIndia("The Satara Sahakari Bank Ltd.India","TheSataraSahakariBankLtd.India","181","","","SATARA SAHAKARI", 374L),
    TheSevaVikasCoOperativeBankLtdIndia ("The Seva Vikas CoOperative Bank Ltd.India","TheSevaVikasCoOperativeBankLtd.India","179","","","SEVAVIKAS", 375L),
    TheSuratMercantileCoOpBankLtd("The Surat Mercantile Co-Op. Bank Ltd","TheSuratMercantileCo-Op.BankLtd","565","","","SURATMERC", 376L),
    TheSuratPeopleCoOpBankLtd("The Surat People CO OP Bank LTD","TheSuratPeopleCoOpBankLtd","","THE_SURAT_PEOPLE_CO_OP_BANK_LTD","","SURATPEO", 377L),
    TheSutexCoOpBankLtd("The Sutex Co Op Bank LTD","TheSutexCoOpBankLtd","","THE_SUTEX_CO_OP_BANK","","SUTEXCBL", 378L),
    TheTamilnaduStateApexCoOperativeBank("The Tamilnadu State Apex Co-Operative Bank","TheTamilnaduStateApexCo-OperativeBank","594","","","TSACBL", 379L),
    TheUdaipurMahilaSamridhiUrbanCoOperativeBankLtd("The Udaipur Mahila Samridhi Urban Co-Operative Bank Ltd","TheUdaipurMahilaSamridhiUrbanCo-OperativeBankLtd","582","","","UDAIPUR MAHILA", 380L),
    TheUdaipurUrbanCoOpBankLtd("The Udaipur Urban Co-Op Bank Ltd","TheUdaipurUrbanCoOpBankLtd","758","","","UDAIPUR", 381L),
    TheUnionCoOpBankLtd("The Union Co Op Bank Ltd","TheUnionCoOpBankLtd","643","UNION_CO_OP_BANK_LTD","","UNIONCOP", 382L),
    TheUrbanCoOperativeBankLtd("The Urban Co-Operative Bank Ltd","TheUrbanCo-OperativeBankLtd","584","","","URBAN CO", 383L),
    TheVallabhVidyanagarCommercialCoOperativeBankLtd("The Vallabh VidyaNagar Commercial Co-Operative Bank Ltd","TheVallabhVidyanagarCommercialCo-OperativeBankLtd","","The_Vallabh_VidyaNagar_Commercial_Co_Operative_Bank_Ltd","","VALLABH", 384L),
    TheVarachhaCoOpBankLtd("The Varachha Co Op Bank LTD","TheVarachhaCoOpBankLtd","","THE_VARACHHA_CO_OP_BANK_LTD","","VARACHHACOOP", 385L),
    TheVijayCoOpBankLimited("The Vijay Co Op Bank Limited","TheVijayCoOpBankLimited","","THE_VIJAY_CO_OP_BANK","","VIJAY COOP", 386L),
    TheVishweshwarSahakariBankLtd("The Vishweshwar Sahakari Bank Ltd","TheVishweshwarSahakariBankLtd","","The_Vishweshwar_Sahakari_Bank_Ltd","","VISHWESH SAH", 387L),
    TheVyankateshwaraSahakariBankLtd("The Vyankateshwara Sahakari Bank Ltd","TheVyankateshwaraSahakariBankLtd","588","","","VYANKATESHWARA", 388L),
    TheWaiUrbanCoOperativeBankLimited("The Wai Urban Co-Operative Bank Limited","TheWaiUrbanCoOperativeBankLimited","","The_Wai_Urban_Co_Operative_Bank_Limited","","WAI URBAN", 389L),
    TJSB ("TJSB","TJSB","90","TJSB","","-", 390L),
    
    TumkurMerchantsCreditCoOp("Tumkur Merchants Credit Co-Op","Tumkur Merchants Credit Co-Op","416","","","-", 391L),
    UCOBankIndia ("UCO Bank India","UCOBankIndia","42","UCO","19","UCO BANK", 392L),
    UjjivanBankIndia ("Ujjivan Bank India","UjjivanBankIndia","191","","","-", 393L),
    UjjivanSmallFinanceBank("Ujjivan Small Finance Bank","UjjivanSmallFinanceBank","","UJJIVAN_SMALL_FINANCE_BANK","","UJJIVANSFB", 394L),
    UmaCoOpBank("Uma Co-Op. Bank","Uma Co-Op. Bank","514","","","UMACOOP", 395L),
    UmiyaUrbanCoOpBank("Umiya Urban Co-Op Bank","UmiyaUrbanCoOpBank","766","","","UMIYABAN", 396L),
    UnionBankofIndiaIndia("Union Bankof India India","UnionBankofIndiaIndia","43","UNION_BANK","1","UNION BANK", 397L),
    UnitedBankofIndiaIndia  ("United Bankof India India","UnitedBankofIndiaIndia","44","UNITED_BANK","29","UNITED BANK", 398L),
    UnitedCoOpBank("United Co-Op. Bank","United Co-Op. Bank","470","","","THEUCBLA", 399L),
    UtkarshSmallFinanceBank("Utkarsh Small Finance Bank","Utkarsh Small Finance Bank","465","","","UTKARFIN", 400L),
    UttarakhandGraminBank("Uttarakhand Gramin Bank","Uttarakhand Gramin Bank","341","","","UTTAR GRAMIN", 401L),
    VaidyanathUrbanCoopBankLtdIndia ("Vaidyanath Urban CoopBank Ltd India","VaidyanathUrbanCoopBankLtdIndia","262","","","VAIDYACO", 402L),
    VaijapurMarchantsCoOpBank("Vaijapur Marchants Co Op Bank","VaijapurMarchantsCoOpBank","","VAIJAPUR_MARCHANTS_CO_OP_BANK","","TVAIMCBL", 403L),
    VaijapurMerchantsCoOp("Vaijapur Merchants Co-Op","Vaijapur Merchants Co-Op","454","","","-", 404L),
    VaishyaNagariSahakariBank("Vaishya Nagari Sahakari Bank","VaishyaNagariSahakariBank","","Vaishya_Nagari_Sahakari_Bank","","VAISHYANAGARI", 405L),
    VaishyaNagariSahakariBankIndia  ("Vaishya Nagari Sahakari Bank India","VaishyaNagariSahakariBankIndia","163","","","VAISHYANAGARI", 406L),
    VananchalGraminBank("Vananchal Gramin Bank","VananchalGraminBank","","Vananchal_Gramin_Bank","","VANACHALBR", 407L),
    VarachhaCoopBankLtdIndia ("Varachha Coop Bank Ltd.India","VarachhaCoopBankLtd.India","157","","","VARACHHACOOP", 408L),
    VasaiJanataSahakariBankLtd("Vasai Janata Sahakari Bank Ltd","VasaiJanataSahakariBankLtd","590","","","VASAIJSBL", 409L),
    VasaiVikasSahakariBankLtdIndia  ("Vasai Vikas Sahakari Bank Ltd India","VasaiVikasSahakariBankLtdIndia","302","VASAI_VIKAS_SAH_BANK_LTD","","VASAI", 410L),
    VeerashaivaSahakariBankLtd("Veerashaiva Sahakari Bank Ltd","Veerashaiva Sahakari Bank Ltd","418","","","VEERASHAIV", 411L),
    VidarbhaMerchantsUrbanCoOp("Vidarbha Merchants Urban Co-Op Bank","Vidarbha Merchants Urban Co-Op Bank","398","","","-", 412L),
    VidarbhaMerchantsUrbanCoOpBankLtd("Vidarbha Merchants Urban Co Op Bank Ltd","VidarbhaMerchantsUrbanCoOpBankLtd","","VIDARBHA_MERCHANTS_URBAN_CO_OP_BANK_LTD","","VIDARBHAURB", 413L),
    VidyaSahkariBank("Vidya Sahkari Bank","Vidya Sahkari Bank","534","","","VIDYA PUNE", 414L),
    VijayaBankIndia ("Vijaya Bank India","VijayaBankIndia","45","VIJAYA","15","VijayCopBank", 415L),
    VijayCopBank("VijayCopBank","Vijay Co-Op. Bank","519","","","VIJAY COOP", 416L),
    VikasSahakariBankLtd("Vikas Sahakari Bank Ltd","VikasSahakariBankLtd","566","","","VIKASAHA", 417L),
    VikasSouhardaCoOpBank("Vikas Souharda Co-Op Bank","VikasSouhardaCoOpBank","648","","","VIKASSCBL", 418L),
    VikramadityaNagrikSahakariBankIndia ("Vikramaditya Nagrik Sahakari Bank India","VikramadityaNagrikSahakariBankIndia","171","","","VIKRAMNAGARIK", 419L),
    VinayakSahakariBank("Shri Vinayak Sahakari Bank Ltd","Shri Vinayak Sahakari Bank Ltd","579","","","VINAYAK", 420L),
    VishweshwarSahakariBankLtd("Vishweshwar Sahakari Bank Ltd","Vishweshwar Sahakari Bank Ltd","457","","","VISHWESH SAH", 421L),
    VitaMerchantsCoOpBankLtdIndia("Vita Merchants CoOp Bank Ltd India","VitaMerchantsCoOpBankLtdIndia","263","","","TVMCBL", 422L),
    VyaparikAudyogikSahkariBank("Vyaparik Audyogik Sahkari Bank","VyaparikAudyogikSahkariBank","636","","","VYAPAAUD", 423L),
    VyapariSahakariBankMaryadit("Vyapari Sahakari Bank Maryadit","VyapariSahakariBankMaryadit","564","","","VYAPARIBANK", 424L),
    VysyaCoopBankLtdIndia("VysyaCoopBankLtdIndia","VysyaCoopBankLtdIndia","198","","","VYCBLT", 425L),
    WaiUrbanCoOperativeBankIndia ("Wai Urban CoOperative Bank India","WaiUrbanCoOperativeBankIndia","160","","","WAI URBAN", 426L),
    WardhaNagariSahakariAdhikoshBankLtd("Wardha Nagari Sahakari Adhikosh Bank Ltd","WardhaNagariSahakariAdhikoshBankLtd","544","","","WARDHANAG", 427L),
    YesBankIndia ("Yes Bank India","YesBankIndia","46","YES","","YES BANK", 428L),
    YeshwantUrbanCoOpBankLtdIndia("Yeshwant Urban CoOpBank Ltd.India","YeshwantUrbanCoOpBankLtd.India","184","","","YESHCOOP", 429L),
    ZoroastrianBankIndia ("Zoroastrian Bank India","ZoroastrianBankIndia","172","","","-", 430L),
    ZoroastrianCoOpBankLimited("Zoroastrian Co Op Bank Limited","ZoroastrianCoOpBankLimited","","ZOROASTRIAN_CO_OP_BANK","","ZOROASTRIAN", 431L),

    //--> add on 15/11/2019
	BelagaviShreeBasaveshwarCoOpBankLtd("Belagavi Shree Basaveshwar Co-Op Bank Ltd","BelagaviShreeBasaveshwarCoOpBankLtd","774","","","-", 432L),
	CalicutCityServiceCoOpBank("Calicut City Service Co-Op Bank","CalicutCityServiceCoOpBank","777","","","-", 433L),
	CoastalBank("Coastal Bank","CoastalBank","782","","","-", 434L),
	JaiBhavaniSahakariBank("Jai Bhavani Sahakari Bank","JaiBhavaniSahakariBank","781","","","-", 435L),
	MadheshwariUrbanDevelopmentCo("Madheshwari Urban Development Co-Op Bank","MadheshwariUrbanDevelopmentCoOpBank","771","","","-", 436L),
	NorthEastSmallFinanceBankLtd("North East Small Finance Bank Ltd","NorthEastSmallFinanceBankLtd","775","","","-", 437L),
	SBTABankLtd("SBTA Bank Ltd","SBTABankLtd","727","","","-", 438L),
	SarvodayaCoOpBank("Sarvodaya Co-Op Bank","SarvodayaCoOpBank","778","","","-", 439L),
	TheMalkapurUrbanCoOpBankLtd("The Malkapur Urban Co-Op Bank Ltd","TheMalkapurUrbanCoOpBankLtd","783","","","-", 440L),
	UtkalGrameenBank("Utkal Grameen Bank","UtkalGrameenBank","763","","","-", 441L),
	WardhamanUrbanCoOpbankLtd("Wardhaman Urban Co-Op bank Ltd","WardhamanUrbanCoOpbankLtd","770","","","-", 442L),
	BhadradriCoOpUrbanBank("Bhadradri Co-Op Urban Bank","BhadradriCoOpUrbanBank","789","","","-", 443L),
	GulshanMercantileUrbanCoOpBankIndia("Gulshan Mercantile Urban Co-Op Bank, India","GulshanMercantileUrbanCoOpBankIndia","788","","","-", 444L),
	JainCoOpBankLtdIndia("Jain Co-Op Bank Ltd, India","JainCoOpBankLtdIndia","793","","","-", 445L),
	MangalCoOpBankLtdIndia("Mangal Co-Op Bank Ltd, India","MangalCoOpBankLtdIndia","792","","","-", 446L),
	ShreeWaranaSahakariBankLtdIndia("Shree Warana Sahakari Bank Ltd, India","ShreeWaranaSahakariBankLtdIndia","791","","","-", 447L),
	TheChemburNagrikSahkariBankIndia("The Chembur Nagrik Sahkari Bank, India","TheChemburNagrikSahkariBankIndia","794","","","-", 448L),
	TheGoaUrbanCoOpBankLtdIndia("The Goa Urban Co-Op Bank Ltd, India","TheGoaUrbanCoOpBankLtdIndia","790","","","-", 449L),
	
	
	//add 29-11-2019::
	TheDelhiStateCoOpBankLtdIndia("The Delhi State Co-Op Bank Ltd, India","TheDelhiStateCoOpBankLtdIndia","805","","","-", 450L),
    MumbaiDistrictCentralCoOpBankLtdIndia("Mumbai District Central Co-Op Bank Ltd, India","MumbaiDistrictCentralCoOpBankLtdIndia","801","","","-", 451L),
    ShreeGaneshSahakariBankLtdIndia("Shree Ganesh Sahakari Bank Ltd, India","ShreeGaneshSahakariBankLtdIndia"," 795","","","-", 452L),
    MahanagarNagrikSahakariBankIndia("Mahanagar Nagrik Sahakari Bank, India","MahanagarNagrikSahakariBankIndia","797","","","-", 453L),
    KrishnaGrameenaBankIndia("Krishna Grameena Bank, India","KrishnaGrameenaBankIndia","800","","","-", 454L),
    KamalaCoOpBankLtdIndia("Kamala Co-Op Bank Ltd, India","KamalaCoOpBankLtdIndia","803","","","-", 455L),
    TamilNaduGramaBankIndia("Tamil Nadu Grama Bank, India","TamilNaduGramaBankIndia","804","","","-", 456L),
    TheBangaloreCityCoOpBankLtdIndia("The Bangalore City Co-Op Bank Ltd, India","TheBangaloreCityCoOpBankLtdIndia","796","","","-", 457L),
    TheBavlaNagrikSahkariBankLtdIndia("The Bavla Nagrik Sahkari Bank Ltd, India","TheBavlaNagrikSahkariBankLtdIndia","806","","","-", 458L),
    HutatmaSahakariBankLtdIndia("Hutatma Sahakari Bank Ltd, India","HutatmaSahakariBankLtdIndia","798","","","-", 459L),
    IndiaPostPaymentsBankIndia("India Post Payments Bank, India","IndiaPostPaymentsBankIndia","807","","","-", 460L),
    TheThaneDistrictCentralCoOpBankIndia("The Thane District Central Co-Op Bank, India","TheThaneDistrictCentralCoOpBankIndia","752","","","-", 461L),
    VardhamanMahilaCoOpUrbanBankLtdIndia("Vardhaman Mahila Co-Op Urban Bank Ltd, India","VardhamanMahilaCoOpUrbanBankLtdIndia","802","","","-", 462L),
    
    //add on 16/12/2019
    DrJaiprakashMundadaUrbanCoOpBankLtdIndia("Dr Jaiprakash Mundada Urban Co Op Bank Ltd, India","DrJaiprakashMundadaUrbanCoOpBankLtdIndia","816","","","-", 463L),
    GoaStateCoOpBankLtdIndia("Goa State Co-Op Bank Ltd, India","GoaStateCoOpBankLtdIndia","823","","","-", 464L),
    JalnaMerchantsCoOpBankLtdIndia("Jalna Merchants Co-Op Bank Ltd, India","JalnaMerchantsCoOpBankLtdIndia","812","","","-", 465L),
    ManipalCoOpBankIndia("Manipal Co Op Bank, India","ManipalCoOpBankIndia","819","","","-", 466L),
    MerchantsLiberalCoOpBankLtdIndia("Merchants Liberal Co-Op Bank Ltd, India","MerchantsLiberalCoOpBankLtdIndia","818","","","-", 467L),
    OttapalamCoOpUrbanBankLtdIndia("Ottapalam Co-Op Urban Bank Ltd, India","OttapalamCoOpUrbanBankLtdIndia","811","","","-", 468L),
    SarvaHaryanaGraminBankIndia("Sarva Haryana Gramin Bank, India","SarvaHaryanaGraminBankIndia","810","","","-", 469L),
    TheBhavanaRishiCoOpUrbanBankLtdIndia("The Bhavana Rishi Co-Op Urban Bank Ltd, India","TheBhavanaRishiCoOpUrbanBankLtdIndia","809","","","-", 470L),
    TheMaladSahakariBankLtdIndia("The Malad Sahakari Bank Ltd, India","TheMaladSahakariBankLtdIndia","814","","","-", 471L),
    TheYashwantCoOpLtdIndia("The Yashwant Co-Op Ltd, India","TheYashwantCoOpLtdIndia","808","","","-", 472L),
    ThrissurDistrictCitizensCoOpSocietyLtdIndia("Thrissur District Citizens Co-Op Society Ltd, India","ThrissurDistrictCitizensCoOpSocietyLtdIndia","821","","","-", 473L),
    TumkurVeerashaivaCoOpBankLtdIndia("Tumkur Veerashaiva Co-Op Bank Ltd, India","TumkurVeerashaivaCoOpBankLtdIndia","820","","","-", 474L),
    ZilaSahkariBankLtdIndia("Zila Sahkari Bank Ltd, India","ZilaSahkariBankLtdIndia","822","","","-", 475L),
    MysoreMerchantsCoOpBankLtdIndia("Mysore Merchants Co-Op Bank Ltd, India","MysoreMerchantsCoOpBankLtdIndia","813","","","-", 476L),
	
	
	//add on 21/12/2019
    KalolNagarikSahakariBankLtdIndia("Kalol Nagarik Sahakari Bank Ltd, India","KalolNagarikSahakariBankLtdIndia","827","","","-", 477L),
    KeshavSehkariBankLtdIndia("Keshav Sehkari Bank Ltd, India","KeshavSehkariBankLtdIndia","825","","","-", 478L),
    ShikshakSahakariBankLtdIndia("Shikshak Sahakari Bank Ltd, India","ShikshakSahakariBankLtdIndia","828","","","-", 479L),
    TheMuslimCoOpBankLtdIndia("The Muslim Co-Op Bank Ltd, India","TheMuslimCoOpBankLtdIndia","824","","","-", 480L),
    
   //add on 26/12/2019
    BankofBahrainandKuwait("Bank of Bahrain and Kuwait","BankofBahrainandKuwait","840","","","-", 481L),
    BhujCommercialCoOpBankLtdIndia("Bhuj Commercial Co-Op Bank Ltd, India","BhujCommercialCoOpBankLtdIndia","839","","","-", 482L),
    ThePratapCoOpBankLtdIndia("The Pratap Co-Op Bank Ltd, India","ThePratapCoOpBankLtdIndia","838","","","-", 483L),	
	
    //add on 31/12/2019
    DharmavirSambhajiUrbanCoOpBankLtdIndia("Dharmavir Sambhaji Urban Co-Op Bank Ltd, India","DharmavirSambhajiUrbanCoOpBankLtdIndia","837","","","-", 484L),
    MadhyaPradeshGraminBankIndia("Madhya Pradesh Gramin Bank, India","MadhyaPradeshGraminBankIndia","847","","","-", 485L),
    NagpurMahanagarPalikaKarmachariSahakariBankLtdIndia("Nagpur Mahanagar Palika Karmachari Sahakari Bank Ltd, India","NagpurMahanagarPalikaKarmachariSahakariBankLtdIndia","843","","","-", 486L),	
    TheSangamnerMerchantsCooperativeBankLtdIndia("The Sangamner Merchants Co-operative Bank Ltd, India","TheSangamnerMerchantsCooperativeBankLtdIndia","845","","","-", 487L),
    UnjhaNagarikSahakariBankLtdIndia("Unjha Nagarik Sahakari Bank Ltd, India","UnjhaNagarikSahakariBankLtdIndia","826","","","-", 488L),
    
    
  //add on 05/02/2020
    AmbajogaiPeoplesCoOpBank("Ambajogai Peoples Co-Op. Bank","AmbajogaiPeoplesCoOpBank","850","","","-", 489L),	
    GodavariUrbanCoOpBankIndia("Godavari Urban Co-Op Bank, India","GodavariUrbanCoOpBankIndia","865","","","-", 490L),
    IndoreClothMarketCoOpBankLtdIndia("Indore Cloth Market Co-Op Bank Ltd, India","IndoreClothMarketCoOpBankLtdIndia","858","","","-", 491L),
    NagarikSahakariBankLtdIndia("Nagarik Sahakari Bank Ltd, India","NagarikSahakariBankLtdIndia","868","","","-", 492L),
    PadmavathiCoOpUrbanBankIndia("Padmavathi Co-Op Urban Bank, India","PadmavathiCoOpUrbanBankIndia","855","","","-", 493L),
    ShankarNagariSahakariBankIndia("ShankarNagariSahakariBankIndia","ShankarNagariSahakariBankIndia","854","","","-", 494L),
    ShreeLaxmiCoOpBankIndia("Shree Laxmi Co-Op Bank, India","ShreeLaxmiCoOpBankIndia","873","","","-", 495L),
    ShriKanyakaNagariSahakariBankLtdIndia("Shri Kanyaka Nagari Sahakari Bank Ltd, India","ShriKanyakaNagariSahakariBankLtdIndia","866","","","-", 496L),
    ShriLaxmikrupaUrbanCoOpBankLtdIndia("Shri Laxmikrupa Urban Co-Op Bank Ltd, India","ShriLaxmikrupaUrbanCoOpBankLtdIndia","817","","","-", 497L),
    ShriRenukamataMultistateCoOpUrbanCreditSocietyIndia("Shri Renukamata Multistate Co-Op Urban Credit Society, India","ShriRenukamataMultistateCoOpUrbanCreditSocietyIndia","857","","","-", 498L),
    SolapurSiddheshwarSahakariBankLtdIndia("Solapur Siddheshwar Sahakari Bank Ltd, India","SolapurSiddheshwarSahakariBankLtdIndia","861","","","-", 499L),
    SreeSubramanyeswaraCoOpBankIndia("Sree Subramanyeswara Co-Op Bank, India","SreeSubramanyeswaraCoOpBankIndia","856","","","-", 500L),
    TelanganaStateCoOpBankLtdIndia("Telangana State Co-Op Bank Ltd, India","TelanganaStateCoOpBankLtdIndia","853","","","-", 501L),
    TheAndhraPradeshStateCoOpBankIndia("The Andhra Pradesh State Co-Op Bank, India","TheAndhraPradeshStateCoOpBankIndia","864","","","-", 502L),
    TheBarodaCentralCoOpBankLtdIndia("The Baroda Central Co-Op Bank Ltd, India","TheBarodaCentralCoOpBankLtdIndia","851","","","-", 503L),
    TheDeccanCoOpUrbanBankLtdIndia("The Deccan Co-Op Urban Bank Ltd, India","TheDeccanCoOpUrbanBankLtdIndia","863","","","-", 504L),
    TheHyderabadDistrictCoOpCentralBankLtdIndia("The Hyderabad District Co-Op Central Bank Ltd, India","TheHyderabadDistrictCoOpCentralBankLtdIndia","869","","","-", 505L),
    TheJanathaCoOpBankIndia("The Janatha Co-Op Bank, India","TheJanathaCoOpBankIndia","860","","","-", 506L),
    TheNavalDockyardCoOpBankLtdIndia("The Naval Dockyard Co-Op Bank Ltd, India","TheNavalDockyardCoOpBankLtdIndia","867","","","-", 507L),
    TheSSKCoOpBankLtdIndia("The SSK Co-Op Bank Ltd, India","TheSSKCoOpBankLtdIndia","849","","","-", 508L),
    TheVaishCoOpNewBankLtdIndia("The Vaish Co-Op New Bank Ltd, India","TheVaishCoOpNewBankLtdIndia","852","","","-", 509L),
    Other("Other","Other","","","","-", 510L),
	TumkurGrainMerchantsCreditCoOpBank("Tumkur Grain Merchants Credit Co-Op. Bank","Tumkur Grain Merchants Credit Co-Op. Bank","512","","","TUMKURGRAIN", 511L),
	NotDisclosed("Not Disclosed","Not Disclosed","","","","-", 512L),
	
	BarodaUttarPradeshGraminBank("Baroda uttar pradesh gramin bank","BarodaUttarPradeshGraminBank","","","513","-", 513L),
	UttrakhandGraminBank("Uttrakhand gramin bank","UttrakhandGraminBank","","","514","-", 514L),
	ChaitanyaGodavariGrameenaBank("Chaitanya Godavari Grameena Bank","ChaitanyaGodavariGrameenaBank","","","113","-", 515L),
    KARNATAKA_VIKAS_GRAMEEN_BANK("Karnataka Vikas Grameen Bank","KarnatakaVikasGrameenBank","","","157","-",516L),
    AADHAR_HOUSING_FINANCE_LIMITED("Aadhar Housing Finance Limited","AadharHousingFinanceLimited","","","","-",517L),
	
	PunjabGraminBankIndia("PunjabGraminBankIndia","Punjab Gramin Bank, India","12127","","126","PunjabGraminBankIndia", 519L),
	HimachalPradeshGraminBank("Himachal Pradesh Gramin Bank","HimachalPradeshGraminBank","","","515","HimachalPradeshGraminBank", 520L);
	
    
    private BankList(String name, String perfiosName, String perfiosId, String finbitName,String orgId,String bureauName, Long id) {
        this.name = name;
        this.perfiosName = perfiosName;
        this.perfiosId = perfiosId;
        this.finbitName = finbitName;
        this.orgId = orgId;
        this.bureauName = bureauName;
        this.id = id;
    }

    private String name;
    private String perfiosName;
    private String perfiosId;
    private String finbitName;
    private String orgId;
    private String bureauName;
    private Long id;

    public static BankList[] getAll() {
        return BankList.values();

    }

    public static BankList fromName(String v) {
        for (BankList c : BankList.values()) {
            if (c.name.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
    public static BankList fromPerfiousId(String v) {
        for (BankList c : BankList.values()) {
            if (c.perfiosId.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
    
    public static BankList fromOrgId(String v) {
        for (BankList c : BankList.values()) {
            if (c.orgId.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }
    public static BankList fromBureauName(String v) {
        for (BankList c : BankList.values()) {
            if (c.bureauName.equalsIgnoreCase(v)) {
                return c;
            }
        }
        return null;
    }

    public static BankList fromId(Long v) {
        for (BankList c : BankList.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPerfiosName() {
        return perfiosName;
    }

    public void setPerfiosName(String perfiosName) {
        this.perfiosName = perfiosName;
    }

    public String getPerfiosId() {
        return perfiosId;
    }

    public void setPerfiosId(String perfiosId) {
        this.perfiosId = perfiosId;
    }

    public String getFinbitName() {
        return finbitName;
    }

    public void setFinbitName(String finbitName) {
        this.finbitName = finbitName;
    }

    public String getOrgId() {
        return orgId;
    }

    public String getBureauName() {
        return bureauName;
    }

	public Long getId() {
		return id;
	}
	
	
	

}
