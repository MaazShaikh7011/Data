package com.opl.jns.oneform.api.enums;

public enum RealtionshipType {
	
	FATHER(1l, "Father"), MOTHER(2l, "Mother"),BROTHER(3l,"Brother"),SISTER(4L,"Sister"),SPOUSE(5L,"Spouse"),BROTHER_IN_LAW(6L,"Brother-in-law"),
	SON(7L,"Son"),DAUGHTER(8l,"Daughter"),DAUGHTER_IN_LAW(9l,"Daughter-in-law"),FATHER_IN_LAW(10l,"Father-in-Law"),GRAND_DAUGHTER(11L,"Grand daughter"),GRAND_FATHER(12L,"Grand Father"),
	GRAND_MOTHER(13L,"Grand Mother"),GRAND_SON(14l,"Grand Son"),MOTHER_IN_LAW(15l,"Mother-in-law"),SISTER_IN_LAW(16l,"Sister-in law"),SON_IN_LAW(17l,"Son-in-law"),OTHERS(18L,"Others");
	
	private Long id;
	private String value;

	private RealtionshipType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static RealtionshipType fromId(Long v) {
		for (RealtionshipType c : RealtionshipType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RealtionshipType[] getAll() {
		return RealtionshipType.values();
	}

}
