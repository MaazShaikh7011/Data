package com.opl.jns.oneform.api.enums.dayNulm;

public enum DayNULMEmploymentType {
    SALARIED(1, "Salaried"), NON_SALARIED(2, "Non Salaried");

    private Integer id;
    private String value;

    private DayNULMEmploymentType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static DayNULMEmploymentType fromId(Integer v) {
        for (DayNULMEmploymentType c : DayNULMEmploymentType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static DayNULMEmploymentType[] getAll() {
        return DayNULMEmploymentType.values();
    }
}
