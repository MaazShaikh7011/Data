package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum AmiSubsidyCategory {
	
	TO_REGISTRED_FPOS_WOMEN_THEIR_CO_OPERATIVE(1, "Whether belongs to Registered FPOs/ Women/ SC/ST/ their Co-operatives "), INDIVIDUAL(2, "Individual"), COMPANY_CORPORATION(3, "Company / Coporation"),
	STATE_AGENCY(4,"State Agency"),OTHERS(5,"Others");

	private Integer id;
	private String value;

	private AmiSubsidyCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AmiSubsidyCategory fromId(Integer v) {
		for (AmiSubsidyCategory c : AmiSubsidyCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiSubsidyCategory[] getAll() {
		return AmiSubsidyCategory.values();
	}

}
