package com.opl.jns.oneform.api.enums;

public enum RepaymentBy {
	
	STUDENT(1l, "Student "), PARENTS(2l, "Parents"),GAURANTOR(3l, "Gaurantor ");
	
	private Long id;
	private String value;

	private RepaymentBy(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static RepaymentBy fromId(Long v) {
		for (RepaymentBy c : RepaymentBy.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RepaymentBy[] getAll() {
		return RepaymentBy.values();
	}

}
