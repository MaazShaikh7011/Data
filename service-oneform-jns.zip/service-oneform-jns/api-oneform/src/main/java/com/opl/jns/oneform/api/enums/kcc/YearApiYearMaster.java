package com.opl.jns.oneform.api.enums.kcc;

public enum YearApiYearMaster {
    TEWNTY_TWENTYONE(1,"2020-21", "118"),
    TEWNTYONE_TWENTYTWO(2,"2021-22", "119"),
    TEWNTYTWO_TWENTYTHREE(3,"2022-23", "120");

    private Integer id;
    private String value;
    private String yearCode;

    private YearApiYearMaster(Integer id, String value, String yearCode) {
        this.id = id;
        this.value = value;
        this.yearCode = yearCode;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public String getYearCode() {
        return yearCode;
    }
    public static YearApiYearMaster fromId(Integer v) {
        for (YearApiYearMaster c : YearApiYearMaster.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        return null;
    }

    public static YearApiYearMaster[] getAll() {
        return YearApiYearMaster.values();
    }

    public static YearApiYearMaster findByYear(String v) {
        for (YearApiYearMaster c : YearApiYearMaster.values()) {
            if (c.value.contains(v)) {
                return c;
            }
        }
        return null;
    }
}
