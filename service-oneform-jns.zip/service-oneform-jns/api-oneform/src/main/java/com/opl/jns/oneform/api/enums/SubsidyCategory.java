package com.opl.jns.oneform.api.enums;

public enum SubsidyCategory {
	
	GENERAL(1, "General"), OBC(2, "OBC"), ST(3, "ST"),SC(4, "SC");
	
	private Integer id;
	private String value;

	private SubsidyCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SubsidyCategory fromId(Integer v) {
		for (SubsidyCategory c : SubsidyCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SubsidyCategory[] getAll() {
		return SubsidyCategory.values();
	}
}
