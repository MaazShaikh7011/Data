package com.opl.jns.oneform.api.enums;

public enum StudentRelationship {
	
	FATHER(1l, "Father"), MOTHER(2l, "Mother"),GUARDIAN(3l,"Guardian");
	
	private Long id;
	private String value;

	private StudentRelationship(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static StudentRelationship fromId(Long v) {
		for (StudentRelationship c : StudentRelationship.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static StudentRelationship[] getAll() {
		return StudentRelationship.values();
	}


}
