package com.opl.jns.oneform.api.enums;

public enum SocialCategory {
	
	GENERAL(1l, "General", "93,237"), OBC(2l, "OBC", "94,238"), ST(3l, "ST", "95,239"),SC(4l, "SC", "95,239"),MINORITY(5l, "Minority", "96,240"),OTHERS(6l, "Others", "93,237");
	
	private Long id;
	private String value;
	private String schemeParamId;

	private SocialCategory(Long id, String value, String schemeParamId) {
		this.id = id;
		this.value = value;
		this.schemeParamId = schemeParamId;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getSchemeParamId() {
		return schemeParamId;
	}

	public static SocialCategory fromId(Long v) {
		for (SocialCategory c : SocialCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SocialCategory fromName(String v) {
		for (SocialCategory c : SocialCategory.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static SocialCategory[] getAll() {
		return SocialCategory.values();
	}


}
