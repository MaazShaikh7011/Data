package com.opl.jns.oneform.api.enums;

public enum LoanTypeWCCBanker {

	NEW(1l, "New"), RENEWAL(2l, "Renewal");

	private Long id;
	private String value;
	private String code;

	private LoanTypeWCCBanker(Long id, String value) {
		this.id = id;
		this.value = value;

	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static LoanTypeWCCBanker fromId(Long v) {
		for (LoanTypeWCCBanker c : LoanTypeWCCBanker.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static LoanTypeWCCBanker[] getAll() {
		return LoanTypeWCCBanker.values();
	}
}
