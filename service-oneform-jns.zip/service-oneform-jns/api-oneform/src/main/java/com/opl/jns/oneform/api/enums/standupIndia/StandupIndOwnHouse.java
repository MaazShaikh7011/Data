package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndOwnHouse {

    OWNED(1,"Owned"),
    RENTED(2,"Rented"),
    LEASED(3,"Leased"),
    OTHER(4,"Other");

    private Integer id;
    private String value;

    private StandupIndOwnHouse(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndOwnHouse fromId(Integer v) {
        for (StandupIndOwnHouse c : StandupIndOwnHouse.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }
    public static StandupIndOwnHouse[] getAll() {
        return StandupIndOwnHouse.values();
    }
}
