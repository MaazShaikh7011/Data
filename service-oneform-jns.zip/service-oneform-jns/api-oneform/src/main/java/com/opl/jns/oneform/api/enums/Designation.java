package com.opl.jns.oneform.api.enums;

public enum Designation {
	
	Executive(1l, "Executive"), MANAGERIAL(2l, "Managerial"),OTHER(3l,"Other");
	
	private Long id;
	private String value;

	private Designation(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Designation fromId(Long v) {
		for (Designation c : Designation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Designation[] getAll() {
		return Designation.values();
	}


}
