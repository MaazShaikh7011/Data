package com.opl.jns.oneform.api.enums.srms;

public enum BeneficiaryCategory {

	
	MANUAL_SCAVENGER(1, "Manual Scavenger"),
	SAFAI_KARAMCHARI(2, "Safai Karamchari"),
	DEPENDENT_MANUAL_SCAVENGER(3, "Dependent - Manual Scavenger"),
	DEPENDENT_SAFAI_KARAMCHARI(4, "Dependent - Safai Karamchari"),
	RAG_WASTE_PICKER(5, "Rag/Waste Picker"),
	OTHER(6, "Other (specify)");
	
	private Integer id;
	private String value;

	private BeneficiaryCategory(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static BeneficiaryCategory fromId(Integer v) {
		for (BeneficiaryCategory c : BeneficiaryCategory.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static BeneficiaryCategory[] getAll() {
		return BeneficiaryCategory.values();
	}
}
