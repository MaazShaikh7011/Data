package com.opl.jns.oneform.api.enums.kcc;

public enum RelationShip {

    FATHER(1, "Father"),
    MOTHER(2, "Mother"),
    SISTER(3, "Sister"),
    BROTHER(4, "Brother"),
    WIFE(5, "Wife"),
    HUSBAND(6, "Husband"),
    SON(7, "Son"),
    DAUGHTER(8, "Daughter");


    private Integer id;
    private String value;

    private RelationShip(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static RelationShip fromId(Integer v) {
        for (RelationShip c : RelationShip.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static RelationShip[] getAll() {
        return RelationShip.values();
    }
}
