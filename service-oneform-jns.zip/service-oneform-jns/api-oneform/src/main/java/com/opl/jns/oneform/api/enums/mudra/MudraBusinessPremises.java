package com.opl.jns.oneform.api.enums.mudra;

/**
 * 
 * @author bhaumik.parekh
 *
 */
public enum MudraBusinessPremises {
	OWNED(1, "Owned"), LEASED_OVER(2, "Leased over 5 Years"),LEASED_BELOW(3,"Leased Below 5 Years"),RENTED(4,"Rented");
	
	private Integer id;
	private String value;

	private MudraBusinessPremises(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraBusinessPremises fromId(Integer v) {
		for (MudraBusinessPremises c : MudraBusinessPremises.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraBusinessPremises[] getAll() {
		return MudraBusinessPremises.values();
	}
}
