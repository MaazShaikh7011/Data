package com.opl.jns.oneform.api.enums.mudra;

public enum MudraLabourRawMaterials {

	ACCESS_TO_INPUTS_LOCALLY_AVAILABLE(1,"Access to inputs locally available/ tied up"),
	ACCESS_TO_INPUTS_NOT_LOCALLY_AVAILABLE_BUT(2,"Access to inputs not locally available but source identified"),
	ACCESS_TO_INPUTS_NOT_LOCALLY_AVAILABLE_NOR(3," Access to inputs not locally available nor identified");

	private Integer id;
	private String value;

	private MudraLabourRawMaterials(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraLabourRawMaterials fromId(Integer v) {
		for (MudraLabourRawMaterials c : MudraLabourRawMaterials.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraLabourRawMaterials[] getAll() {
		return MudraLabourRawMaterials.values();
	}
}
