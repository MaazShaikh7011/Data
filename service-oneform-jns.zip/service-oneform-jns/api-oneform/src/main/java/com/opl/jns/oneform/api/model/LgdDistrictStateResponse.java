package com.opl.jns.oneform.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * @author ravi.thummar
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LgdDistrictStateResponse {

    private Long stateId;
    private Long districtId;
    private String stateName;
    private String lgdStateCode;
    private String districtName;
    private String lgdDistrictCode;

    public LgdDistrictStateResponse(Long districtId, String districtName, String lgdDistrictCode) {
        this.districtId = districtId;
        this.districtName = districtName;
        this.lgdDistrictCode = lgdDistrictCode;
    }

    public LgdDistrictStateResponse(Long stateId, Long districtId, String stateName, String lgdStateCode, String districtName, String lgdDistrictCode) {
        this.stateId = stateId;
        this.districtId = districtId;
        this.stateName = stateName;
        this.lgdStateCode = lgdStateCode;
        this.districtName = districtName;
        this.lgdDistrictCode = lgdDistrictCode;
    }
}
