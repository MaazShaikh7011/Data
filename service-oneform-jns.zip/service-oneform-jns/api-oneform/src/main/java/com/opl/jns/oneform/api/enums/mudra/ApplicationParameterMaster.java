package com.opl.jns.oneform.api.enums.mudra;

public enum ApplicationParameterMaster {
	INSURANCE_SCHEME(1, "Insurance Scheme");

	private Integer id;
	private String value;

	private ApplicationParameterMaster(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ApplicationParameterMaster fromId(Integer v) {
		for (ApplicationParameterMaster c : ApplicationParameterMaster.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ApplicationParameterMaster[] getAll() {
		return ApplicationParameterMaster.values();
	}
}
