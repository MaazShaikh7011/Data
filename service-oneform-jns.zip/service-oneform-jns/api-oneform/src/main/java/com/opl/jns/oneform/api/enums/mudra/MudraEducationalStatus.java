package com.opl.jns.oneform.api.enums.mudra;

public enum MudraEducationalStatus {

	GRADUATE(1,"Graduate"),
	UNDER_MATRICULATE(2,"Under Matriculate"),
	ILLITERATE(3,"Illiterate"),
	POST_GRADUATE(4,"Post Graduate"),
	MATRICULATE(5,"Matriculate"),
	NOT_DECLARE(6,"Not declare"),
	MEDICAL_GRADUATE_POST_GRADUATE(7,"Medical Graduate/Post Graduate"),
	ENGINEERING_GRADUATE_POST_GRADUATE(8,"Engineering graduate/Post Graduate"),
	LAW_GRADUATE_POST_GRADUATE(9,"Law graduate/Post Graduate"),
	CA_ICWA_MBA_CFA(10,"CA/ICWA/MBA/CFA"),
	COMPUTER_DEGREE(11,"Computer degree/Diploma/MCA"),
	OTHER_PROFESSIONAL_DEGREE_DIPLOMA(12,"Other Professional degree/Diploma");

	private Integer id;
	private String value;

	private MudraEducationalStatus(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraEducationalStatus fromId(Integer v) {
		for (MudraEducationalStatus c : MudraEducationalStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraEducationalStatus[] getAll() {
		return MudraEducationalStatus.values();
	}
}
