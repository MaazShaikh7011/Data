package com.opl.jns.oneform.api.enums;

public enum EduLoanEmploymentType {

	SALARIED(1L,"Salaried"), SELF_EMPLOYED(2L,"Self Employed"),PROFESSIONAL(3L,"Professional"),Others(4L,"Others ");
	
	private Long id;
	private String value;
	
	private EduLoanEmploymentType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EduLoanEmploymentType fromId(Long v) {
		for (EduLoanEmploymentType c : EduLoanEmploymentType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static EduLoanEmploymentType[] getAll() {
		return EduLoanEmploymentType.values();
	}
}
