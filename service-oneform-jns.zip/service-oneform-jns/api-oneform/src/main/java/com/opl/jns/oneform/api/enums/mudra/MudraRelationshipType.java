package com.opl.jns.oneform.api.enums.mudra;

public enum MudraRelationshipType {

	SHAREHOLDER(1,"Shareholder","Private Limited Company,Public limited company"),
	HOLDING_COMPANY(2,"Holding company","Private Limited Company,Public limited company"),
	SUBSIDARY_COMPANY(3,"Subsidary Company","Private Limited Company,Public limited company"),
	PROPERIETOR(4,"Proprietor","Proprietary"),
	PARTNER(5,"Partner","Partnership,Limited Liability partnership"),
	TRUSTEE(6,"Trustee","Trust"),
	PROMOTER_DIRECTOR(7,"Promoter director","Private Limited Company,Public limited company"),
	NOMINEE_DIRECTOR(8,"Nominee Director","Private Limited Company,Public limited company"),
	INDEPENDENT_DIRECTOR(9,"Independent Director","Private Limited Company,Public limited company"),
	INDIVUDUAL_MEMBER_OF_SHG(10,"Indivudual Member of SHG",""),
	DIRECTOR_SIENCE_RESIGNED(11,"Director-Sience resigned","Private Limited Company,Public limited company"),
	KAARTA(12,"Kaarta","Hindu Undivided Family, Hindu Undivided Family (HUF)"),
	MEMBER(13,"Member","Hindu Undivided Family, Hindu Undivided Family (HUF)"),
	OTHERS(14,"Others","Hindu Undivided Family, Co-operative,Hindu Undivided Family (HUF),Self Help Group,Society,Others");

	private Integer id;
	private String value;
	private String udhyamValue;

	private MudraRelationshipType(Integer id, String value, String udhyamValue) {
		this.id = id;
		this.value = value;
		this.udhyamValue = udhyamValue;;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getUdhyamValue() { return udhyamValue; }

	public static MudraRelationshipType fromId(Integer v) {
		for (MudraRelationshipType c : MudraRelationshipType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraRelationshipType fromName(String v) {
		for (MudraRelationshipType c : MudraRelationshipType.values()) {
			String[] values = c.udhyamValue.split(",");
			for (String temp : values){
				if (temp.equalsIgnoreCase(v)) {
					return c;
				}
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraRelationshipType[] getAll() {
		return MudraRelationshipType.values();
	}
}
