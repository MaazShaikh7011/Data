package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum AmiSubsidyTypeOfProject {
	
	STORAGE_INFRASTRUCTURE(1, "Storage Infrastructure"), OTHER_THAN_STORAGE(2, "Other than storage"), FARMERS_CONSUMER_MARKET(3, "Farmars consumer Market"),
	DEVELOPMENT(4,"Development"),UPGRADATION_OF_RURAL_HAATS(5,"Upgradation of Rural Haats"), RPMS_INTO_GRAMS(6," RPMs into GrAMs");

	private Integer id;
	private String value;

	private AmiSubsidyTypeOfProject(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AmiSubsidyTypeOfProject fromId(Integer v) {
		for (AmiSubsidyTypeOfProject c : AmiSubsidyTypeOfProject.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiSubsidyTypeOfProject[] getAll() {
		return AmiSubsidyTypeOfProject.values();
	}

}
