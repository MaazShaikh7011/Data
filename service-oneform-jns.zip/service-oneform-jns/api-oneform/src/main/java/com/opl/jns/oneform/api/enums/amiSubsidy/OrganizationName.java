package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum OrganizationName {

	NABARD(1, "NABARD"), FINANCIAL_INSTITUTION(2, "Financial Institution / Bank"), DMI(3, "DMI");

	private Integer id;
	private String value;

	private OrganizationName(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static OrganizationName fromId(Integer v) {
		for (OrganizationName c : OrganizationName.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static OrganizationName[] getAll() {
		return OrganizationName.values();
	}

}
