package com.opl.jns.oneform.api.enums.agri;

public enum AmiTypeOfBusiness {
	
	FRUITS_VEGETABLES(1,"Fruits & vegetables"),
	GRAINS_SEEDS(2,"Grains & Seeds"),
	OILSEEDS_COCONUT(3,"Oilseeds & Coconut"),
	BEVERAGES(4,"Beverages"),
	MILK(5,"Milk"),
	MEAT_POULTRY(6,"Meat & Poultry"),
	MARINE_PRODUCTS(7,"Marine products"),
	OTHERS_SPECIFY(8,"Others (Specify)");
	
	private Integer id;
	private String value;
	
	private AmiTypeOfBusiness(Integer id, String value) {
		this.id = id;
		this.value = value;
	
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getValue() {
		return value;
	}
	
	public static AmiTypeOfBusiness fromId(Integer v) {
		for (AmiTypeOfBusiness c : AmiTypeOfBusiness.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AmiTypeOfBusiness[] getAll() {
		return AmiTypeOfBusiness.values();
	}

}
