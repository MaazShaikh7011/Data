package com.opl.jns.oneform.api.enums;

public enum OwnershipIndicator {
    INDIVIDUA(1l, "Individual"),
    AUTHORISED_USER_SUPPLEMENTARY_CREDIT_CARD_HOLDER(2l, "Authorised User (refers to supplementary credit card holder)"),
	GUARANTOR(3l, "Guarantor"),
    JOINT(4l, "Joint");

    private Long id;
    private String value;

    private OwnershipIndicator(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static OwnershipIndicator fromId(Long v) {
        for (OwnershipIndicator c : OwnershipIndicator.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static OwnershipIndicator fromValue(String v) {
        for (OwnershipIndicator c : OwnershipIndicator.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static OwnershipIndicator[] getAll() {
        return OwnershipIndicator.values();
    }
}