package com.opl.jns.oneform.api.enums.amiSubsidy;

public enum NumberOfChambers {
	
	NEW_UNIT_CREATED(1, "New Unit to be created"), EXISTING_UNIT(2, "Existing Unit (If Any)");

	private Integer id;
	private String value;

	private NumberOfChambers(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static NumberOfChambers fromId(Integer v) {
		for (NumberOfChambers c : NumberOfChambers.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static NumberOfChambers[] getAll() {
		return NumberOfChambers.values();
	}

}
