package com.opl.jns.oneform.api.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OneformUtils {
	
	public static final Long LONG_TERM_CREDIT_RATING = 1L;
	public static final Long SHORT_TERM_CREDIT_RATING = 2L;
	public static final Long SME_TERM_CREDIT_RATING = 3L;
	public static final Long CCR_TERM_CREDIT_RATING = 4L;

	public static final String EXCEPTION = "Exception :: ";
	public static final String DATA_FOUND = "Data Found.";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong!";
	public static final String REQUESTED_DATA_CAN_NOT_BE_EMPTY = "Requested data can not be empty.";
	public static final String GIVEN_DETAIL_RECORD_IS_NOT_EXISTS_IN_DB = "Given Detail Record is Not Exists in DB";
	public static final String ERROR_WHILE_GETTING_MASTER_DATA = "Error while getting master data : {}";
	public static final String NAME_CAN_NOT_BE_NULL = "Name can not be null : ";
	public static final String START_SAVE = "Start save";
	public static final String END_SAVE = "End save";
	public static final String CENTRAL_GOVERNMENT_SALARY_ACCOUNT_NOT_WITH_BANK = "Central Government - Salary Account not with Bank";
	public static final String STATE_GOVERNMENT_SALARY_ACCOUNT_NOT_WITH_BANK = "State Government - Salary Account not with Bank";
	public static final String PSU_SALARY_ACCOUNT_NOT_WITH_BANK = "PSU - Salary Account not with Bank";
	public static final String CORPORATE_SALARY_ACCOUNT_NOT_WITH_BANK = "Corporate – Salary Account not with Bank (Small Sector - Pvt Ltd Companies)";
	public static final String CORPORATE_SALARY_ACCOUNT_WITH_BANK = "Corporate – Salary Account with Bank (Small Sector - Pvt Ltd Companies)";
	public static final String PUBLIC_LIMITED_COMPANY = "Public Limited Company";
	public static final String QUASI_GOVERNMENT_NOT_WITH_BANK = "Quasi Government - Salary Account not with Bank";
	public static final String QUASI_GOVERNMENT_WITH_BANK = "Quasi Government - Salary Account with Bank";
	public static final String BANK = "Bank";
	public static final String INSURANCE_COMPANY = "Insurance Company";

	private static final String ALGORITHM = "AES";
	private static final String CHAR_ENCODING = "UTF-8";
	private static final String SECRET = "26f1ac75f77c22ebc66e2359c13ea9955ebd5e2bd7fbe50e5b3ac2977a772302";


	private static final List<EnumsClassName> MASTER_DATA =  new ArrayList<EnumsClassName>();

	public static List<EnumsClassName> getMasterData(){
		return MASTER_DATA;
	}
	static{
		MASTER_DATA.addAll(Arrays.asList(OneformUtils.EnumsClassName.values()));
	}
	
	public enum EnumsClassName{
		LOAN_TYPE,
		BUSINESS_TYPE,
		SALUTATION,
		GENDER,
		SOCIAL_CATEGORY,
		MARITAL_STATUS,
		EDUCATIONAL_QUALIFICATION,
		OCCUPATION,
		RESIDENTIAL_STATUS,
		REALTIONSHIP_TYPE,
		EXAMINATION,
		CLASS_OBTAINED,
		COURSE_NAME,
		QUOTA_SELECTION,
		COURSE_TYPE,
		STUDENT_RELATIONSHIP,
		RESIDENCE_TYPE,
		REPAYMENT_BY,
		SECURITY_TYPE,
		HOME_EMPLOYMENT_TYPE,
		DESIGNATION,
		WORKING_WITH,
		CONSTITUTION,
		CREDIT_TYPE,
		BANK_LIST,
		MONTH,
		RELIGION,
		COMPANY_TYPE,
		HOME_DESIGNATION,
		ORGANIZATION_TYPE,
		HOUSE_OWNERSHIP,
		InstitutionMaster,
		LOAN_PURPOSE,
		PROPERTY_TYPE,
		AREA_TYPE,
		REPAYMENT_MODE,
		EDU_EMPLOYMENT_TYPE,
		CO_APP_BUSINESS_TYPE,
		INSTITUTE_LOCATION,
		COST_OF_COURSE,
		HOME_EDUCATIONAL_QUALIFICATION,
		PURPOSE_OF_LOAN_BANKER,
		BORRWER_GROUP_BANKER,
		CREDIT_TYPE_RETAIL,
		TYPE_OF_PRODUCT_BANKER,
		LOAN_TYPE_WCC_BANKER,
		SWMS_ASSET_TYPE,
		SWMS_BUSINESS_PROSPECTS,
		SWMS_EDUCATION_QUALIFICATION,
		SWMS_MARKETING_ARRANGEMENT,
		SWMS_OWNING_HANDLOOM,
		SWMS_WEAVING_TYPE,
		SWMS_OTHER_BUSINESS,
		SWMS_PURPOSE_LOAN,
		MUDRA_CONSTITUTION,
		MUDRA_BUSINESS_PREMISES,
		MUDRA_LOAN_PURPOSE,
		MUDRA_MARKETING_ARRANGEMENT,
		MUDRA_PENSION_PLAN,
		MUDRA_LABOUR_RAW_MATERIALS,
		MUDRA_NO_OF_EMPLOYEES_OR_WORKERS,
		MUDRA_RELATIONSHIP_TYPE,
		MUDRA_RESIDENCE_STATUS,
		MUDRA_EDUCATIONAL_STATUS,
		MUDRA_OWNING_A_HOUSE,		
		MUDRA_ASSESSED_FOR_INCOMETAX,		
		MUDRA_SPOUSE_DETAIL,		
		MUDRA_CATEGORY,
		MUDRA_MINORITY_CATEGORY,
		AGRI_EDU_QUALIFICATION,
		AGRI_SOCIAL_CATEGORY,
		AIF_AGRI_SOCIAL_CATEGORY,
		AGRI_TYPE_OF_CREDIT,
		AMI_EDU_QUALIFICATION,
		AMI_TYPE_OF_PROJECT,
		AMI_LAND_OWNERSHIP,
		AMI_TYPE_OF_ACTIVITY,
		AMI_TYPE_OF_BUSINESS,
		AMI_TYPE_OF_BUSINESS_STORAGE,
		PROJECT_COST_NON_STORAGE,
		PROJECT_COST_STORAGE,
		BENEFICIARY_CATEGORY,
		RELATION_WITH,
		PURPOSE_EQUIPMENT,
		PROCUREMENT_MECHANISM,
		EDU_EDUCATION_QUALIFICATION,
		SUBSIDY_CATEGORY,
		BUSINESS_TYPE_MASTER,
		STANDUPIND_CATEGORY,
		STANDUPIND_EDUCATIONAL_STATUS,
		STANDUPIND_IMPORTED,
		STANDUPIND_OWN_HOUSE,
		STANDUPIND_TYPE_OF_FACILITY,
		STANDUPIND_NO_OF_EMPLOYEES,
		ITEM,
		MEANS_OF_FINANCE,
		NUMBER_OF_CHEMBER,
		ORAGANIZATION_NAME,
		STD_STATUTORY_OBLIGATIONS,
		AMI_SUBSIDY_CATEGORY,
		AMI_SUBSIDY_TYPE_OF_PROJECT,
		STD_CONSTITUTION,
		AFI_PROJECT_ACTIVITY,
		MARKETING_ARRANGEMENT,
		TYPE_OF_MICRO_ENTERPRISE,
		NRLM_DESIGNATION,
		NRLM_DISABILITY,
		NRLM_RELIGION,
		NRLM_SOCIAL_CATEGORY,
		NRLM_APPLICATION_STATUS,
		MACHINE_TYPE,
		AREA_OF_PREMISES,
		NULM_LOAN_TYPE,
		NATURE_OF_ENTERPRISE,
		AGRI_CONSTITUTION,
		AGRI_MINORITY_CATEGORY,
		EDU_MINORITY_CATEGORY,
		CLAP_HOUSE_CATEGORY,
		ACCOUNT_TYPE_TEMP,
		BANK_LIST_TEMP,
		CONSENT_LANGUAGE,
		NRLM_SEARCH_FILTER_PARAMETER,
		BOARD_MASTER,
		ACCOUNT_STATUS,
		TTRTYPE,
		PROJECT_TYPE,
		RELATIONSHIP,FARMER_CATEGORY,LIABILITIES,ASSESTS,EXPERIENCE_IN_AGRICULTURAL,NO_OF_CROPS_GROWN,STATUS_OF_IRRIGATION,
		
		TYPE_OF_LAND_OWNERSHIP,EXPERIENCE_IN_AGRI,LIBILITY_CHARGES,CROP_INSURED_TYPE,SEASON_TYPE,CROP_TYPE,YES_OR_NO_TYPE,
		KCC_RELATION_SHIP,KCC_SOCIAL_CATEGORY, KCC_OCCUPATION, KCC_OWNERSHIP,KCC_ACCOUNT_STATUS;
		
		
		public static EnumsClassName getByName(String name) {
			for (EnumsClassName st : EnumsClassName.values()) {
				if (st.toString().equals(name)) {
					return st;
				}
			}
			return null;
		}
	}
}
