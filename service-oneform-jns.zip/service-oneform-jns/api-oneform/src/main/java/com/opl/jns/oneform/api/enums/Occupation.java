package com.opl.jns.oneform.api.enums;

public enum Occupation {
	
	STUDENT(1l, "Student"), SALARIED (2l, "Salaried "), SELF_EMPLOYED(3l, "Self Employed"),PROFESSIONAL(4l, "Professional"),OTHERS(5l, "Others");
	
	private Long id;
	private String value;

	private Occupation(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static Occupation fromId(Long v) {
		for (Occupation c : Occupation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Occupation[] getAll() {
		return Occupation.values();
	}


}
