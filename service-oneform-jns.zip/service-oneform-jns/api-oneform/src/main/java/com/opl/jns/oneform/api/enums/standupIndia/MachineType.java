package com.opl.jns.oneform.api.enums.standupIndia;

public enum MachineType {

	LAND_BUILDING(1,"Land / Building"),
	MACHINERY_EQUIPMENT(2,"Machinery / Equipment"),
	OTHER_SPWECIFY(3,"Others (specify)");
	
	private Integer id;
    private String value;

    private MachineType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static MachineType fromId(Integer v) {
        for (MachineType c : MachineType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static MachineType[] getAll() {
        return MachineType.values();
    }
	   
}
