package com.opl.jns.oneform.api.enums;

public enum ConsentLanguage {
    ENGLISH("ENG","English"),
    HINDI("HINDI","Hindi"),
    GUJARATI("GUJARATI","Gujarati"),
    MARATHI("MARATHI","Marathi"),
    TAMIL("TAMIL","Tamil"),
    TELUGU("TELUGU","Telugu"),
    BENGALI("BENGALI","Bengali");

    private String name;
    private String value;

    private ConsentLanguage(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public static ConsentLanguage fromName(String v) {
        for (ConsentLanguage c : ConsentLanguage.values()) {
            if (c.name.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static ConsentLanguage[] getAll() {
        return ConsentLanguage.values();
    }
}
