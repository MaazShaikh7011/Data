package com.opl.jns.oneform.api.enums.nrlm;

public enum NrlmDisability {

    NO(1, "No"),
    SELF(2, "Self"),
    DM(3, "DM");

    private Integer id;
    private String value;

    private NrlmDisability(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NrlmDisability fromId(Integer v) {
        for (NrlmDisability c : NrlmDisability.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmDisability fromName(String v) {
        for (NrlmDisability c : NrlmDisability.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NrlmDisability[] getAll() {
        return NrlmDisability.values();
    }

}
