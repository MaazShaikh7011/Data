package com.opl.jns.oneform.api.enums;

public enum PropertyType {
	HOUSE(1L,"House"),
	PLOT(2L,"Plot"),
	FLAT(3L,"Flat"),
	OTHER(4L,"Other");
	
	private Long id;
	private String value;

	private PropertyType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static PropertyType fromId(Long v) {
		for (PropertyType c : PropertyType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PropertyType[] getAll() {
		return PropertyType.values();
	}
}
