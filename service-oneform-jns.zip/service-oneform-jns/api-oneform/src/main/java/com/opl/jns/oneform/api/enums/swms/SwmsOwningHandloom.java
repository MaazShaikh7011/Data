package com.opl.jns.oneform.api.enums.swms;

public enum SwmsOwningHandloom {
	OWNED(1,"Owned"),
	NOT_OWNED(2,"Not Owned");
	
	private Integer id;
	private String value;

	private SwmsOwningHandloom(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SwmsOwningHandloom fromId(Integer v) {
		for (SwmsOwningHandloom c : SwmsOwningHandloom.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsOwningHandloom[] getAll() {
		return SwmsOwningHandloom.values();
	}
}
