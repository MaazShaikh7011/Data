package com.opl.jns.oneform.api.enums.kcc;

/**
 * @author rahul.meena
 *
 */
public enum CropInsuredType {
	
	LESS_THEN(1l, "Less than 60%"),
	GRETER_THEN(2l, "60% or more");

	private Long id;
	private String value;

	private CropInsuredType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CropInsuredType fromId(Long v) {
		for (CropInsuredType c : CropInsuredType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CropInsuredType[] getAll() {
		return CropInsuredType.values();
	}

}
