package com.opl.jns.oneform.api.enums.kcc;

public enum StatusOfIrrigation {

	PERENNIAL(1l, "Fully Perennial"),
	SEASONAL(2l, "Seasonal"),
	RAINFED(3l, "Rainfed");
	

	private Long id;
	private String value;

	private StatusOfIrrigation(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}


	public static StatusOfIrrigation fromId(Long v) {
		for (StatusOfIrrigation c : StatusOfIrrigation.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static StatusOfIrrigation[] getAll() {
		return StatusOfIrrigation.values();
	}

}
