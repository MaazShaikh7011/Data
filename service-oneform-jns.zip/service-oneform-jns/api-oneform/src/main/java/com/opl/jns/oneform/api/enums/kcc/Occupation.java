package com.opl.jns.oneform.api.enums.kcc;

public enum Occupation {
    AGRICULTURIST(1, "Agriculturist"),	
	HORTICULTURIST(2, "Horticulturist"),	
	SERICULTURE_FARMER (3, "Sericulture Farmer"),	
	SILVICULTURE_FARMER (4, "Silviculture Farmer"),	
	SERICULTURE_REELER(5, "Sericulture Reeler"),	
	SERICULTUR_SEED_PREPARER(6, "Sericulture Seed Preparer(RSP)"),	
	DAIRY_FARMER	(7, "Dairy Farmer"),	
	SHEEP_GOAT_FARMER(8, "Sheep/Goat Farmer"),		
	POULTRY_FARMER(9, "Poultry Farmer"),	
	PIG_REARING_FARMER(10, "Pig rearing Farmer"),	
	RABBIT_REARING_FARMER(11, "Rabbit rearing Farmer"),		
	FISH_FARMER         (12, "Fish Farmer"),	
	FISH_HARVESTER_CAPTURE_FISHERIES(13, "Fish Harvester/Capture Fisheries"),	
	FISH_MARKETEER(14, "Fish Marketeer"),	
	APICULTURE(15, "Apiculture (honey bee)"),	
	FOREST_RIGHTS_ACT_BENEFICIARY_FARMER(16, "Forest Rights Act Beneficiary farmer"),
	AGRICULTURE_PROCESSOR(17, "Agriculture Processor"),
	HORTICULTURE_PROCESSOR(18, "Horticulture Processor"),
	FOREST_PRODUCE_COLLECTOR(19, "Forest Produce Collector"),
	COLD_STORAGE_OWNER(20, "Cold Storage owner"),
	WEARHOUSE_OWNER(21, "Wearhouse owner"),
	AGRICULTURE_MARTKETEER(22, "Agriculture Martketeer"),
	HORTICULTURE_MARKETEER(23, "Horticulture Marketeer"),	
	AGRICULTURE_LABOURER (24, "Agriculture Labourer"),	
	MGNREGA_WORKER(25, "Mgnrega Worker"),
	HANDLOOM_WEAVER(26, "Handloom Weaver"),
	LEATHER_ARTISAN(27, "Leather Artisan"),	
	GOVERNMENT_EMPLOYEE(28, "Government Employee"),	
	STREET_VENDOR	(29, "Street Vendor"),
	TELEVISION_ARTIST(30, "Television Artist"),
	ARTIST(31, "Artist"),
	DRIVER(32, "Driver"),
	STUDENT(33, "Student"),
	BARBER(34, "Barber"),
	WASHER_MEN(35, "Washer men"),
	HAMALI(36, "Hamali"),
	DOMESTIC_WORKER(37, "Domestic Worker"),
	RAG_PICKER(38, "Rag Picker"),
	TAILOR(39, "Tailor"),
	MECHANIC(40, "Mechanic"),
	GOLD_SMITH(41, "Gold Smith"),
	IRON_SMITH(42, "Iron Smith"),
	POTTER(43, "Potter"),
	KILN_WORKER(44, "Kiln Worker"),
	CONSTRUCTION_WORKER(45, "Construction Worker"),
	POWERLOOM_WORKER(46, "Powerloom Worker");
	
	
	
    private Integer id;
    private String value;

    private Occupation(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static Occupation fromId(Integer v) {
        for (Occupation c : Occupation.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

	public static Occupation fromValue(String v) {
		for (Occupation c : Occupation.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

    public static Occupation[] getAll() {
        return Occupation.values();
    }
}
