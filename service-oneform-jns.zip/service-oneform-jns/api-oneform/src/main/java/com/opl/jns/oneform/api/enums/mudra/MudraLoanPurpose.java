package com.opl.jns.oneform.api.enums.mudra;

public enum MudraLoanPurpose {
	
	WORKING_CAPITAL(1, "Working Capital"), 
	ASSET_ACQUISITION(2, "Asset Acquisition");

	private Integer id;
	private String value;

	private MudraLoanPurpose(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MudraLoanPurpose fromId(Integer v) {
		for (MudraLoanPurpose c : MudraLoanPurpose.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MudraLoanPurpose[] getAll() {
		return MudraLoanPurpose.values();
	}
}
