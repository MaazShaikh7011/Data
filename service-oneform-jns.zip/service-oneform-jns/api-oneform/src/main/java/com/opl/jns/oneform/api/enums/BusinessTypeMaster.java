package com.opl.jns.oneform.api.enums;

public enum BusinessTypeMaster {
	BUSINESS_LOAN(1l, "Loan For Business Activity"),
	PERSONAL_LOAN(3l, "Personal Loan"),
	HOME_LOAN(5l, "Home Loan"), 
	EDUCATION_LOAN(9l, "Education Loan"), 
	MUDRA_LOAN(10l, "Mudra Loan"),
	AGRI_LOAN(11l, "Loan For Agriculture Infrastructure"),
	LIVELIHOOD_LOAN(12l, "Loan For Livelihood");

	private Long id;
	private String value;

	private BusinessTypeMaster(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static BusinessTypeMaster fromId(Long v) {
		for (BusinessTypeMaster c : BusinessTypeMaster.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static BusinessTypeMaster[] getAll() {
		return BusinessTypeMaster.values();
	}

}
