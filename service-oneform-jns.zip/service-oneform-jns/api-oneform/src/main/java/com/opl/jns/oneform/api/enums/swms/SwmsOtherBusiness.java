package com.opl.jns.oneform.api.enums.swms;

public enum SwmsOtherBusiness {
	YES(1,"Yes", "241"),
	NO(2,"No", "242");
	
	private Integer id;
	private String value;
	private String schemeParamId;

	private SwmsOtherBusiness(Integer id, String value, String schemeParamId) {
		this.id = id;
		this.value = value;
		this.schemeParamId = schemeParamId;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getSchemeParamId() {
		return schemeParamId;
	}

	public static SwmsOtherBusiness fromId(Integer v) {
		for (SwmsOtherBusiness c : SwmsOtherBusiness.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SwmsOtherBusiness[] getAll() {
		return SwmsOtherBusiness.values();
	}
}	
