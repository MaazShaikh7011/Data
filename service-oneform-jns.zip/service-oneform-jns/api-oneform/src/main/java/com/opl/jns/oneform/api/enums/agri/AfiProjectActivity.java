package com.opl.jns.oneform.api.enums.agri;

public enum AfiProjectActivity {
	
	WAREHOUSE(1,"Warehouse"),SILOS(2, "Silos"), PACKAING_UNITS(3, "Packaging units"),ASSAYING_UNITS(4, "Assaying units"), 
	SORTING_AND_GRADING_UNIT(5, "Sorting & Grading Unit"), COLD_STORES_AND_COLD_CHAIN(6, "Cold Stores and Cold Chain"),
	LOGISTICS_FACILITY(7, "Logistics Facility"), PRIMARY_PROCESSING_CENTER(8, "Primary processing Center"),
	RIPENING_CHAMBERS(9, "Ripening Chambers"),
	WAXING_PLANTS(10, "Waxing Plants"),
	ORGANIC_INPUTS_PRODUCTION(11, "Organic inputs production"),
	BIO_STIMULANT_PRODUCTION_UNITS(12, "Bio stimulant production units"),
	INFTRASTRUCTURE_FOR_SMART_AND_PRECISION_AGRICULTURE(13, "Infrastructure for smart and precision agriculture"),
	SUPPLY_CHAIN_INFRASTRUCTURE_FOR_CLUSTERS_OF_CROPS(14, "Supply chain infrastructure for clusters of crops"),
	SUPPLY_CHAIN_INFRASTRUCTURE_FOR_EXPORT_CLUSTERS_OF_CROPS(15, "Supply chain infrastructure for export clusters of crops"),
	PPP_PROJECTS_PROMOTED_BY_CENTRAL_OR_THEIR_AGENCIES(16, "PPP projects promoted by Central or their agencies"),
	PPP_PROJECTS_PROMOTED_BY_STATE_OR_THEIR_AGENCIES(17, "PPP projects promoted by State. or their agencies"),
	PPP_PROJECTS_PROMOTED_BY_LOCAL_GOVTS_OR_THEIR_AGENCIES(18, "PPP projects promoted by Local Govts. or their agencies"),
	PM_KUSUM_COM_B_AND_COM_C(19, "PM-KUSUM Com-B and Com-C"),
	COMPOSITE_PROJECT(20, "Composite Project"),
	PHM_ACTIVITIES(21, "PHM Activities"),
	OTHERS(22, "Others");
	
	private Integer id;
	private String value;

	private AfiProjectActivity(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static AfiProjectActivity fromId(Integer v) {
		for (AfiProjectActivity c : AfiProjectActivity.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static AfiProjectActivity[] getAll() {
		return AfiProjectActivity.values();
	}

}
