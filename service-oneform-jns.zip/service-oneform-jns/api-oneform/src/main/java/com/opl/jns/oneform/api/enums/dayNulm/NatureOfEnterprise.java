package com.opl.jns.oneform.api.enums.dayNulm;

public enum NatureOfEnterprise {
    NEW(1, "New business"), EXISTING(2, "Existing");

    private Integer id;
    private String value;

    private NatureOfEnterprise(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static NatureOfEnterprise fromId(Integer v) {
        for (NatureOfEnterprise c : NatureOfEnterprise.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static NatureOfEnterprise[] getAll() {
        return NatureOfEnterprise.values();
    }
}
