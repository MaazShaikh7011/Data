package com.opl.jns.oneform.api.enums.kcc;

public enum FarmerClassification {
	MARGINAL(1l, "Marginal"),
	SMALL(2l, "Small"),
	OTHERS(3l, "Others");

	private Long id;
	private String value;

	private FarmerClassification(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}


	public static FarmerClassification fromId(Long v) {
		for (FarmerClassification c : FarmerClassification.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static FarmerClassification[] getAll() {
		return FarmerClassification.values();
	}

}