package com.opl.jns.oneform.api.enums;

public enum IndexDetails{

	CAM_REPORT(1,"Cam Report"),
	APPLICATION_FORM(2,"Application Form"),
	ABBREVIATIONS(3,"Abbreviation");
	
	private Integer id;
	private String value;
	
	
	private IndexDetails(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}
	public String getValue() {
		return value;
	}
	
	
	public static IndexDetails fromId(Integer v) {
        for(IndexDetails c : IndexDetails.values()) {
            if(c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static IndexDetails[] getAll() {
        return IndexDetails.values();
    }
}