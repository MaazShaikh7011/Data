package com.opl.jns.oneform.api.enums.standupIndia;

public enum StandupIndBusinessPremises {
    OWNED(1,"Owned"),
    RENTED(2,"Rented"),
    LESED(3,"Lesed"),
    OTHER(4,"Other");

    private Integer id;
    private String value;

    private StandupIndBusinessPremises(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }


    public static StandupIndBusinessPremises fromId(Integer v) {
        for (StandupIndBusinessPremises c : StandupIndBusinessPremises.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static StandupIndBusinessPremises[] getAll() {
        return StandupIndBusinessPremises.values();
    }
}
