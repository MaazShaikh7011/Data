package com.opl.jns.oneform.api.enums;

public enum CompanyType {

	PVT_LTD(1L,"Pvt. Ltd."),
	PARTNERSHIP(2L,"Partnership"),
	PROPRIETORSHIP(3L,"Proprietorship"),
	OTHER(4L,"Others");
	
	private Long id;
	private String value;

	private CompanyType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static CompanyType fromId(Long v) {
		for (CompanyType c : CompanyType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static CompanyType[] getAll() {
		return CompanyType.values();
	}
}
