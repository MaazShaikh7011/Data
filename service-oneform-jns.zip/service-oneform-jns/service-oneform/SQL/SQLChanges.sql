INSERT INTO `one_form`.`institute_master` (`institute_name`, `created_date`) VALUES ('Other', '2022-06-01 18:37:15');  -- 41990 This must be new generated ID
