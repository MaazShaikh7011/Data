package com.opl.jns.oneform.service.utils;


import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.utils.common.OPLUtils;


@Component
@SuppressWarnings("unchecked")
public class LGDClient {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LGDClient.class);
		
	public <T> T post(String url, Object request, Class<?> clazz, Map<String, String> header,MediaType contentType) throws HttpClientErrorException {
		RestTemplate restTemplate = new RestTemplate();
		LOGGER.info("Calling POST API : [{}]",url);
		HttpHeaders headers = new HttpHeaders();
		if(!OPLUtils.isObjectNullOrEmpty(header)){
			for(Entry<String,String> entry : header.entrySet()){
				headers.set(entry.getKey(), entry.getValue());
			}			
		}
		if(!OPLUtils.isObjectNullOrEmpty(contentType)) {
			headers.setContentType(contentType);			
		}
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity<Object> req = new HttpEntity<>(headers);
		try{
			return (T) restTemplate.postForObject(url, req, clazz);
		}catch(HttpClientErrorException e){
			throw e;
		}
	}
}
