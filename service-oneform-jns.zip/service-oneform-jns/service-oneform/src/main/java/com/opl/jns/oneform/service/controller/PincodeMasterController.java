package com.opl.jns.oneform.service.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.oneform.api.model.OneFormResponse;
import com.opl.jns.oneform.api.model.PincodeMasterResponse;
import com.opl.jns.oneform.api.utils.OneformUtils;
import com.opl.jns.oneform.service.service.PincodeMasterService;
import com.opl.jns.utils.common.OPLUtils;

@RestController
@RequestMapping("/pincode/master")
public class PincodeMasterController {

	private static final Logger logger = LoggerFactory.getLogger(PincodeMasterController.class);

	@Autowired
	private PincodeMasterService pincodeDateService;

	@GetMapping(value = "/getFirstPincodeMasterByPincode/{pincode}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getById(HttpServletRequest request, @PathVariable String pincode) {
		try {
			if(!OPLUtils.isObjectNullOrEmpty(pincode)) {
				PincodeMasterResponse data = pincodeDateService.getFirstPincodeMasterByPincode(pincode);
				if(!OPLUtils.isObjectNullOrEmpty(data)) {
					OneFormResponse loansResponse = new OneFormResponse("Data Found.", HttpStatus.OK.value());
					loansResponse.setData(data);
					return new ResponseEntity<OneFormResponse>(loansResponse, HttpStatus.OK);
				}
				return new ResponseEntity<OneFormResponse>(new OneFormResponse("No data found !!", HttpStatus.BAD_REQUEST.value()), 
						HttpStatus.OK);	
			}
			else {
				logger.error("Pincode can not be null or empty !!");
				return new ResponseEntity<OneFormResponse>(
						new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()),
						HttpStatus.INTERNAL_SERVER_ERROR);		
			}
		} catch (Exception e) {
			logger.error("Error while getById==>", e);
			return new ResponseEntity<OneFormResponse>(
					new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
