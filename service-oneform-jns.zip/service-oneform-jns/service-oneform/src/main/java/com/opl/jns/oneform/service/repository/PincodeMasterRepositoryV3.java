package com.opl.jns.oneform.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.opl.jns.oneform.service.domain.PincodeMasterV3;

public interface PincodeMasterRepositoryV3 extends JpaRepository<PincodeMasterV3, Long> {
	
	public List<PincodeMasterV3> findByPincodeAndIsActive(@Param("pincode") String pincode, @Param("isActive") Boolean isActive);
	public PincodeMasterV3 findFirstByPincode(String pincode);
}
