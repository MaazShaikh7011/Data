package com.opl.jns.oneform.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.oneform.api.model.LgdStateResponse;
import com.opl.jns.oneform.service.domain.LgdStateV3;

public interface LgdStateRepositoryV3 extends JpaRepository<LgdStateV3, Long> {

    @Query("select new com.opl.jns.oneform.api.model.LgdStateResponse(s.id,s.name,s.code) from LgdStateV3 s where s.isActive = TRUE")
    List<LgdStateResponse> findAllByIsActive(Boolean isActive);
    
    @Query("select new com.opl.jns.oneform.api.model.LgdStateResponse(s.id,s.name,s.code) from LgdStateV3 s where s.id=:id")
    LgdStateResponse fetchById(@Param("id") Long id);

}
