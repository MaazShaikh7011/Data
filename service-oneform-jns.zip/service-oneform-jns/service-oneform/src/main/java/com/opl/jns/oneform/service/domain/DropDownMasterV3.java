package com.opl.jns.oneform.service.domain;
import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author - Ravi Thummar
 * @Date - 3/8/2023
 */


@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "dropdowns_master")
public class DropDownMasterV3 implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dropdowns_master_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_ONEFORM, name = "dropdowns_master_seq_gen", sequenceName = "dropdowns_master_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "key", columnDefinition = "varchar(255) default ''")
    private String key;

    @Column(name = "value", columnDefinition = "varchar(255) default ''")
    private String value;

    @Column(name = "desc_name", columnDefinition = "varchar(255) default ''")
    private String desc;

    @Column(name = "is_active")
    private Boolean isActive;

}