package com.opl.jns.oneform.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.oneform.api.model.CityStateResponse;
import com.opl.jns.oneform.api.model.MasterResponse;
import com.opl.jns.oneform.service.domain.CityV3;

public interface CityRepositoryV3  extends JpaRepository<CityV3, Long>{
	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(c.id,c.value) from CityV3 c where c.state.id=:id")
	List<MasterResponse> findByStateId(@Param("id") Long id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(c.id,c.value) from CityV3 c where c.id in :id")
	List<MasterResponse> findById(@Param("id")List<Long> id);
	
	 public List<CityV3> findByValueIgnoreCase(String city);
	 
	@Query(value = "select * from CityV3 where state_id =:stateId and lower(city_name) = lower(:cityName) limit 1",nativeQuery = true)
	public CityV3 findByStateIdAndCityName(@Param("stateId")Long stateId,@Param("cityName")String cityName);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(c.id,c.value) from CityV3 c where c.id = :id")
	MasterResponse findCityById(@Param("id")Long id);

	@Query("""
			select new com.opl.jns.oneform.api.model.MasterResponse(c.id,c.value,c.subsidyCode) from CityV3 c\
			 where c.id = :cityId and c.state.id = :stateId  \
			""")
	MasterResponse findCityByStateId(@Param("cityId")Long cityId,@Param("stateId")Long stateId);

	@Query("select new com.opl.jns.oneform.api.model.CityStateResponse(ST.id, ST.value, CT.id, CT.value) FROM CityV3 CT INNER JOIN StateV3 ST ON ST.id = CT.state.id AND ST.country.id = 101 ORDER BY CT.state.id,CT.value ASC")
	List<CityStateResponse> findAllCityState();
	
	@Query("select new com.opl.jns.oneform.api.model.CityStateResponse(id, value) FROM StateV3 WHERE id IN(:stateId)")
	List<CityStateResponse> findAllCityStateByStateId(@Param("stateId")List<Long> stateId);
}
