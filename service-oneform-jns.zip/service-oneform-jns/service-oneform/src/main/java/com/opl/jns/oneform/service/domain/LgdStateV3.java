package com.opl.jns.oneform.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "lgd_state")
public class LgdStateV3 implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "lgd_state_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_ONEFORM, name = "lgd_state_seq_gen", sequenceName = "lgd_state_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;

    @Column(name = "name", columnDefinition = "varchar(255) default ''")
    private String name;

    @Column(name = "code", columnDefinition = "varchar(15) default ''")
    private String code;

}
