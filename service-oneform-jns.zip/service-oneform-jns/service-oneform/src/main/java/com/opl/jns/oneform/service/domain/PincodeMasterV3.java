package com.opl.jns.oneform.service.domain;

import java.io.Serializable;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pincode_master",indexes = {
		@Index(columnList = "pincode,is_active",name = DBNameConstant.JNS_ONEFORM+"_PIN_MST_PINCODE_ACT")
})
public class PincodeMasterV3 implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pincode_master_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_ONEFORM, name = "pincode_master_seq_gen", sequenceName = "pincode_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "office_name", columnDefinition = "varchar(255) default ''")
	private String officeName;

	@Column(name = "pincode", columnDefinition = "varchar(10) default ''")
	private String pincode;

	@Column(name = "office_type", columnDefinition = "varchar(100) default ''")
	private String officeType;

	@Column(name = "delivery", columnDefinition = "varchar(255) default ''")
	private String delivery;

	@Column(name = "division_name", columnDefinition = "varchar(255) default ''")
	private String divisionName;

	@Column(name = "region_name", columnDefinition = "varchar(255) default ''")
	private String regionName;

	@Column(name = "circle_name", columnDefinition = "varchar(255) default ''")
	private String circleName;

	@Column(name = "district", columnDefinition = "varchar(255) default ''")
	private String district;

	@Column(name = "state_name", columnDefinition = "varchar(255) default ''")
	private String stateName;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "state_id", referencedColumnName = "id")
	private StateV3 state;

	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "city_id", referencedColumnName = "id")
	private CityV3 city;


}
