package com.opl.jns.oneform.service.repository;

import java.util.List;

import com.opl.jns.oneform.api.model.MasterResponse;

public interface CommonMasterRepository {
	
//	public List<MasterResponse> getMasterList(String name);

//	public List<MasterResponse> getMasterListWithoutOrder(String name);

	public List<Object[]> findCityStateCountryById(Long cityId, Integer stateId, Integer countryId);
	
	public List<MasterResponse> getSectorList(Long industryId);
	
	public List<MasterResponse> getSubSectorList(Long sectorId);
	
	public List<Object[]> spRoundRobin(String moduleName);

	public String getIndustryName(Long industryId);

	public String getSectorName(Long sectorId);

	public String getSubSectorName(Long subSectorId);
	
	public Integer getSubSectorType(Long subSectorId);
	
	public List<String> getIndustryNameListById(List<Long> industryIds);
}
