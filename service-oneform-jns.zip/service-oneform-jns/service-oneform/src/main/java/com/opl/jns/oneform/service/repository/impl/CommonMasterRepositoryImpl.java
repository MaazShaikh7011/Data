package com.opl.jns.oneform.service.repository.impl;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.opl.jns.oneform.api.model.MasterResponse;
import com.opl.jns.oneform.service.repository.CommonMasterRepository;

	
@Repository
public class CommonMasterRepositoryImpl implements CommonMasterRepository {
	
	private static final Logger logger = LoggerFactory.getLogger(CommonMasterRepositoryImpl.class);

	@PersistenceContext
	private EntityManager em;

//	@Override
//	public List<MasterResponse> getMasterList(String entityName) {
//		String query = "select new com.opl.jns.common.api.oneform.model.MasterResponse(acc.id,acc.value) from " + entityName
//				+ " acc where acc.isActive = true order by acc.orderNumber";
//
//		return em.createQuery(query, MasterResponse.class).getResultList();
//
//	}
//
//	@Override
//	public List<MasterResponse> getMasterListWithoutOrder(String name) {
//		String query = "SELECT new com.opl.jns.common.api.oneform.model.MasterResponse(acc.id,acc.value) FROM " + name
//				+ " acc WHERE acc.isActive = TRUE ORDER BY acc.value";
//		return em.createQuery(query, MasterResponse.class).getResultList();
//	}

	@SuppressWarnings("unchecked")
	public List<Object[]> findCityStateCountryById(Long cityId, Integer stateId, Integer countryId) {
		return (List<Object[]>) em.createNativeQuery(
				" SELECT ct.city_name , st.state_name , cn.country_name FROM one_form.city ct , one_form.state st , one_form.country cn  WHERE ct.id = "
						+ cityId + " AND st.id = " + stateId + " AND cn.id = " + countryId)
				.getResultList();
	}
	
	public List<MasterResponse> getSectorList(Long industryId) {
		String query = "select new com.opl.jns.oneform.api.model.MasterResponse(si.sectorId.id,si.sectorId.value) from SectorIndustry si where si.industryId.id= " + industryId + " and si.isActive = TRUE ORDER BY si.sectorId.value";
		return em.createQuery(query, MasterResponse.class).getResultList();
	}
	
	public List<MasterResponse> getSubSectorList(Long sectorId) {
		String query = "select new com.opl.jns.oneform.api.model.MasterResponse(si.subSector.id,si.subSector.value) from SubSectorMapping si where si.sectorId.id= " + sectorId + " ORDER BY si.subSector.value";
		return em.createQuery(query, MasterResponse.class).getResultList();
	}
	
	public List<Object[]> spRoundRobin(String moduleName) {
		try {
			StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("spRoundRobin");
			storedProcedureQuery.registerStoredProcedureParameter("moduleName",String.class, ParameterMode.IN);
			storedProcedureQuery.setParameter("moduleName",moduleName);
			return (List<Object[]>) storedProcedureQuery.getResultList();	
		} catch (Exception e) {
			logger.error("Exception while get Round Robine Details By " + moduleName, e);
		}
		return null;
	}
	public String getIndustryName(Long industryId) {
		try {
			return (String) em.createNativeQuery("SELECT i.value FROM `one_form`.`industry` i WHERE i.`id`=:industryId")
					.setParameter("industryId", industryId)
					.getSingleResult();
		} catch (Exception e) {
			logger.error("Error while getIndustryName===>",e);
		}
		return null;
	}

	public String getSectorName(Long sectorId) {
		try {
			return (String) em.createNativeQuery("SELECT i.value FROM `one_form`.`sector` i WHERE i.`id`=:sectorId")
					.setParameter("sectorId", sectorId)
					.getSingleResult();
		} catch (Exception e) {
			logger.error("Error while getSectorName ===>",e);
		}
		return null;
	}
	public String getSubSectorName(Long subSectorId) {
		try {
			return (String) em.createNativeQuery("SELECT i.value FROM `one_form`.`sub_sector` i WHERE i.`id`=:subSectorId")
					.setParameter("subSectorId", subSectorId)
					.getSingleResult();
		} catch (Exception e) {
			logger.error("Error while getSubSectorName ===>",e);
		}
		return null;
	}
	
	public Integer getSubSectorType(Long subSectorId) {
		try {
			return (Integer) em.createNativeQuery("SELECT i.type FROM `one_form`.`sub_sector` i WHERE i.`id`=:subSectorId")
					.setParameter("subSectorId", subSectorId)
					.getSingleResult();
		} catch (Exception e) {
			logger.error("Error while getSubSectorName ===>",e);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<String> getIndustryNameListById(List<Long> industryIds) {
		try {
			return (List<String>) em.createNativeQuery("SELECT i.value FROM `one_form`.`industry` i WHERE i.`id` IN (:industryIds)").setParameter("industryIds", industryIds).getResultList();
		} catch (Exception e) {
			logger.error("Error while getIndustryNameListById ===>", e);
		}
		return null;
	}
	
	
}
