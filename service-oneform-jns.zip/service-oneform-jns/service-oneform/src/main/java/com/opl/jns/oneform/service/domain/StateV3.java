package com.opl.jns.oneform.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "state")
public class StateV3 implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "state_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_ONEFORM, name = "state_seq_gen", sequenceName = "state_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "state_name", columnDefinition = "varchar(255) default ''")
	private String value;

	@Column(name = "order_number")
	private Integer orderNumber;

	@Column(name = "code", columnDefinition = "varchar(15) default ''")
	private String code;

	@Column(name = "itr_code", columnDefinition = "varchar(45) default ''")
	private String itrCode;
	
	@Column(name = "subsidy_code")
	private Integer subsidyCode;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id", referencedColumnName = "id")
	private CountryV3 country;



}
