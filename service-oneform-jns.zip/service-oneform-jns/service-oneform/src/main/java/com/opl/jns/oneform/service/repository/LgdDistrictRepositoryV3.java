package com.opl.jns.oneform.service.repository;

import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.service.domain.LgdDistrictV3;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LgdDistrictRepositoryV3 extends JpaRepository<LgdDistrictV3, Long> {

    @Query("select new com.opl.jns.oneform.api.model.LgdDistrictStateResponse(LS.id, LD.id, LS.name, LS.code, LD.name, LD.code) FROM LgdDistrictV3 LD INNER JOIN LgdStateV3 LS ON LS.id = LD.lgdState.id ORDER BY LD.lgdState.id, LD.name ASC")
    List<LgdDistrictStateResponse> findAllLgdDistrictState();

    @Query("select new com.opl.jns.oneform.api.model.LgdDistrictStateResponse(LD.id, LD.name, LD.code) from LgdDistrictV3 LD where LD.lgdState.id=:id AND LD.isActive = TRUE")
    List<LgdDistrictStateResponse> findByLgdStateId(Long id);
    
    @Query("select new com.opl.jns.oneform.api.model.LgdDistrictStateResponse(LD.id, LD.name, LD.code) from LgdDistrictV3 LD where LD.id = :id")
	LgdDistrictStateResponse findLgdCityById(Long id);
}
