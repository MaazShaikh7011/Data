package com.opl.jns.oneform.service.controller;

import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.oneform.api.model.*;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.api.utils.OneformUtils;
import com.opl.jns.oneform.service.service.CommonMasterServiceV3;
import com.opl.jns.utils.common.OPLUtils;

@RestController
@RequestMapping("/v3/master")
public class CommonMasterControllerV3 {

	private static final Logger logger = LoggerFactory.getLogger(CommonMasterControllerV3.class.getName());
	private static final String INVALID_REQUEST = "INVALID_REQUEST";
	private static final String RES_MSG_SOMETHING_WENT_WRONG = "SOMETHING_WENT_WRONG";
	private static final String ERROR_WHILE_GETTING_LOAN_APPLICATION_DETAILS = "Error while getting Loan Application Details : ";
	private static final String SECTORIDLIST_REQUIRE_TO_GET_SECTORS_DETAILS = "sectorIdList  Require to get sectors Details : ";
	private static final String END_GET_STATELIST_BY_COUNTRYID = "End getStateListByCountryId";
	private static final String END_GET_STATELIST_BY_COUNTRYID_LISTID = "End getStateListByCountryIdListId";
	private static final String END_GET_CITYLIST_BY_STATEID = "End getCityListByStateId";
	
	@Autowired
	private CommonMasterServiceV3 commonMasterService; 
	
	
	@GetMapping(value = "/getStateListByCountryId/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getStateListByCountryId(@PathVariable Long id, HttpServletRequest request) {
		// request must not be null
		logger.info("Start getStateListByCountryId");
		try {
			if (id == null) {
				logger.warn(SECTORIDLIST_REQUIRE_TO_GET_SECTORS_DETAILS + id);
				logger.info(END_GET_STATELIST_BY_COUNTRYID);
				return new ResponseEntity<>(new OneFormResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<MasterResponse> response = commonMasterService.getStateListByCountryId(id);
			OneFormResponse oneFormResponse;
			if (response == null || response.isEmpty()) {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
			} else {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
				oneFormResponse.setListData(response);
			}
			logger.info(END_GET_STATELIST_BY_COUNTRYID);
			return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);

		} catch (Exception e) {
			logger.error(ERROR_WHILE_GETTING_LOAN_APPLICATION_DETAILS, e);
			logger.info(END_GET_STATELIST_BY_COUNTRYID);
			return new ResponseEntity<>(new OneFormResponse(RES_MSG_SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getStateListByCountryIdListId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getStateListByCountryIdListId(@RequestBody List<Long> id) {
		// request must not be null
		logger.info("Start getStateListByCountryIdListId");
		if (id == null) {
			logger.warn(OneformUtils.NAME_CAN_NOT_BE_NULL, id);
			logger.info(END_GET_STATELIST_BY_COUNTRYID_LISTID);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.REQUESTED_DATA_CAN_NOT_BE_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

		try {
			List<StateByCountryIdResponse> response = commonMasterService.getStateListByCountryIdListId(id);
			if (response != null && !response.isEmpty()) {
				OneFormResponse oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
				oneFormResponse.setListData(response);
				logger.info(END_GET_STATELIST_BY_COUNTRYID_LISTID);
				return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);
			} else {
				logger.info(END_GET_STATELIST_BY_COUNTRYID_LISTID);
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.ERROR_WHILE_GETTING_MASTER_DATA, e);
			logger.info(END_GET_STATELIST_BY_COUNTRYID_LISTID);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@GetMapping(value = "/city/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> cityById(@PathVariable Long id) {
		if (id == null || id == 0l) {
			logger.warn("City ID can not be null ==>", id);
			return new ResponseEntity<>(new OneFormResponse("Requested data can not be empty.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

		try {
			MasterResponse response = commonMasterService.findByCityId(id);
			if (response != null) {
				OneFormResponse oneFormResponse = new OneFormResponse("Data Found.", HttpStatus.OK.value());
				oneFormResponse.setData(response);
				return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting master data==>", e);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/lgdCity/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> lgdCityById(@PathVariable Long id) {
		if (id == null || id == 0l) {
			logger.warn("City ID can not be null ==>", id);
			return new ResponseEntity<>(new OneFormResponse("Requested data can not be empty.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

		try {
			LgdDistrictStateResponse response = commonMasterService.findByLgdCityId(id);
			if (!OPLUtils.isObjectNullOrEmpty(response)) {
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), "Data Found.", response), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting master data==>", e);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/state/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> stateById(@PathVariable Long id) {
		if (id == null || id == 0l) {
			logger.warn("State Id can not be null ==>", id);
			return new ResponseEntity<>(new OneFormResponse("Requested data can not be empty.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			MasterResponse response = commonMasterService.findByStateId(id);
			if (response != null) {
				OneFormResponse oneFormResponse = new OneFormResponse("Data Found.", HttpStatus.OK.value());
				oneFormResponse.setData(response);
				return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting master data==>", e);
			logger.info(OneformUtils.START_SAVE);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping(value = "/lgdState/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> lgdStateById(@PathVariable Long id) {
		if (id == null || id == 0l) {
			logger.warn("State Id can not be null ==>", id);
			return new ResponseEntity<>(new OneFormResponse("Requested data can not be empty.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}
		try {
			LgdStateResponse response = commonMasterService.findByLgdStateId(id);
			if (!OPLUtils.isObjectNullOrEmpty(response)) {
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), "Data Found.", response), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Error while getting master data==>", e);
			logger.info(OneformUtils.START_SAVE);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



	@GetMapping(value = "/getStateListByCountry/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getStateListByCountry(@PathVariable Long id, HttpServletRequest request) {
		// request must not be null
		logger.info("Start getStateListByCountryId");
		try {
			if (id == null) {
				logger.warn(SECTORIDLIST_REQUIRE_TO_GET_SECTORS_DETAILS + id);
				logger.info(END_GET_STATELIST_BY_COUNTRYID);
				return new ResponseEntity<>(new OneFormResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<MasterResponse> response = commonMasterService.getStateListByCountry(id);
			OneFormResponse oneFormResponse;
			if (response == null || response.isEmpty()) {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
			} else {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
				oneFormResponse.setListData(response);
			}
			logger.info(END_GET_STATELIST_BY_COUNTRYID);
			return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);

		} catch (Exception e) {
			logger.error(ERROR_WHILE_GETTING_LOAN_APPLICATION_DETAILS, e);
			logger.info(END_GET_STATELIST_BY_COUNTRYID);
			return new ResponseEntity<>(new OneFormResponse(RES_MSG_SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getCityStateMaster")
	public OneFormResponse getCityStateMaster() {
		logger.info("Start getCityStateMaster() ------>");
		try {
			OneFormResponse oneFormResponse=new OneFormResponse();
			List<CityStateResponse> ifscBankDetailResponse = commonMasterService.getCityStateMaster();
			 oneFormResponse.setListData(ifscBankDetailResponse);
			 return oneFormResponse;
		} catch (Exception e) {
			logger.error("Error while getCityStateMaster() ==>", e);
			return null;
		}
	}

	@GetMapping(value = "/getNameByKeyAndObjId/{key}/{objId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getNameByKeyAndObjId(@PathVariable DropDownMasterKey key, @PathVariable Integer objId) {
		try {
			DropDownProxy dropDownProxy = commonMasterService.getNameByKeyAndObjId(key.toString(), objId);
			if (!OPLUtils.isObjectNullOrEmpty(dropDownProxy)) {
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, dropDownProxy), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.ERROR_WHILE_GETTING_MASTER_DATA, e);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getIdByKeyAndName/{key}/{objValue}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getIdByKeyAndName(@PathVariable DropDownMasterKey key, @PathVariable String objValue) {
		try {
			DropDownProxy dropDownProxy = commonMasterService.getIdByKeyAndName(key.toString(), objValue);
			if (!OPLUtils.isObjectNullOrEmpty(dropDownProxy)) {
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, dropDownProxy), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.ERROR_WHILE_GETTING_MASTER_DATA, e);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
	
	@SkipInterceptor
	@PostMapping(value = "/getMasterListByKey", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getMasterListByKey(@RequestBody List<String> key) {
		try {
			Map<String, List<DropDownProxy>> response = commonMasterService.getMasterListByKey(key);
			if (!OPLUtils.isObjectNullOrEmpty(response)) {
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, response), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error(OneformUtils.ERROR_WHILE_GETTING_MASTER_DATA, e);
			return new ResponseEntity<>(new OneFormResponse(OneformUtils.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getCityListByStateId/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getCityListByStateId(@PathVariable Long id, HttpServletRequest request) {
		// request must not be null
		logger.info("Start getCityListByStateId");
		try {
			if (id == null) {
				logger.warn(SECTORIDLIST_REQUIRE_TO_GET_SECTORS_DETAILS + id);
				logger.info(END_GET_CITYLIST_BY_STATEID);
				return new ResponseEntity<>(new OneFormResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<MasterResponse> response = commonMasterService.getCityListByStateId(id);
			OneFormResponse oneFormResponse;
			if (response == null || response.isEmpty()) {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
			} else {
				oneFormResponse = new OneFormResponse(OneformUtils.DATA_FOUND, HttpStatus.OK.value());
				oneFormResponse.setListData(response);
			}
			logger.info(END_GET_CITYLIST_BY_STATEID);
			return new ResponseEntity<>(oneFormResponse, HttpStatus.OK);

		} catch (Exception e) {
			logger.error(ERROR_WHILE_GETTING_LOAN_APPLICATION_DETAILS, e);
			logger.info(END_GET_CITYLIST_BY_STATEID);
			return new ResponseEntity<>(new OneFormResponse(RES_MSG_SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/getLgdDistrictStateMaster")
	public OneFormResponse getLgdDistrictStateMaster() {
		logger.info("Start getLgdDistrictStateMaster() ------>");
		try {
			return new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, commonMasterService.getLgdDistrictStateResponse());
		} catch (Exception e) {
			logger.error("Error while getLgdDistrictStateMaster() ==>", e);
			return null;
		}
	}


	@GetMapping(value = "/getLgdStateList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getLgdStateList() {
		logger.info("Start getLgdStateList");
		try {
			List<LgdStateResponse> response = commonMasterService.getLgdStateList();
			if (!OPLUtils.isListNullOrEmpty(response)) {
				logger.info(END_GET_STATELIST_BY_COUNTRYID);
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, response),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(new OneFormResponse(HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.value()),
					HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(new OneFormResponse(RES_MSG_SOMETHING_WENT_WRONG,
					HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/getLgdCityListByLgdStateId/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OneFormResponse> getLgdCityListByLgdStateId(@PathVariable Long id) {
		logger.info("Start getLgdCityListByLgdStateId");
		try {
			if (id == null) {
				logger.warn(SECTORIDLIST_REQUIRE_TO_GET_SECTORS_DETAILS + id);
				logger.info(END_GET_CITYLIST_BY_STATEID);
				return new ResponseEntity<>(new OneFormResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			List<LgdDistrictStateResponse> response = commonMasterService.getLgdCityListByLgdStateId(id);

			if (!OPLUtils.isListNullOrEmpty(response)) {
				logger.info(END_GET_STATELIST_BY_COUNTRYID);
				return new ResponseEntity<>(new OneFormResponse(HttpStatus.OK.value(), OneformUtils.DATA_FOUND, response),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(new OneFormResponse(HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.value()),
					HttpStatus.NO_CONTENT);

		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(new OneFormResponse(RES_MSG_SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
