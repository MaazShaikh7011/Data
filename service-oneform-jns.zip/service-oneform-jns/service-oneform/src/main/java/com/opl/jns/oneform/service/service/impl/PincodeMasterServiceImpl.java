package com.opl.jns.oneform.service.service.impl;

import com.opl.jns.oneform.api.model.*;
import com.opl.jns.oneform.service.domain.*;
import com.opl.jns.oneform.service.repository.*;
import com.opl.jns.oneform.service.service.*;
import com.opl.jns.utils.common.*;
import org.slf4j.*;
import org.springframework.beans.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

@Service
@Transactional
public class PincodeMasterServiceImpl implements PincodeMasterService {
	
	private static final Logger logger = LoggerFactory.getLogger(PincodeMasterServiceImpl.class);
	
	@Autowired
	private PincodeMasterRepositoryV3 masterRepository;


	@Cacheable(value = "PINCODE_MASTER_FETCH_BY_CODE_CACHE", key = "{#pincode}")
	@Override
	public PincodeMasterResponse getFirstPincodeMasterByPincode(String pincode) {
		PincodeMasterV3 pincodeMaster = masterRepository.findFirstByPincode(pincode);
		if(!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
			PincodeMasterResponse res = new PincodeMasterResponse();
			BeanUtils.copyProperties(pincodeMaster, res);
		    res.setStateId(!OPLUtils.isObjectNullOrEmpty(pincodeMaster.getState()) ?pincodeMaster.getState().getId() : null);
		    res.setCityId(!OPLUtils.isObjectNullOrEmpty(pincodeMaster.getCity()) ? pincodeMaster.getCity().getId() : null);
		    return res;
		}
		return null;
	}
 
}
