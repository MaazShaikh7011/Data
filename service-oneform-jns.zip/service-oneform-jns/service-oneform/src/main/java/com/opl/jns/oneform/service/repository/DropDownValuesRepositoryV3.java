package com.opl.jns.oneform.service.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.opl.jns.oneform.service.domain.DropDownValuesV3;

public interface DropDownValuesRepositoryV3 extends JpaRepository<DropDownValuesV3, Long> {
    //    @Query("from DropDownValues dv WHERE dv.dropdownId.id = :objId ANDV dv.dropdownId.key LIKE :key AND dv.isActive = TRUE")
	DropDownValuesV3 findByObjIdAndIsActiveTrueAndDropdownIdKey(Integer objId, String key);

	DropDownValuesV3 findByValueAndIsActiveTrueAndDropdownIdKey(String objValue, String key);

    @Query("from DropDownValuesV3 dv WHERE dv.dropdownId.key IN(:key) AND dv.isActive = TRUE ORDER BY orderId")
    List<DropDownValuesV3> findByDropdownKeyAndIsActiveTrue(List<String> key);
}
