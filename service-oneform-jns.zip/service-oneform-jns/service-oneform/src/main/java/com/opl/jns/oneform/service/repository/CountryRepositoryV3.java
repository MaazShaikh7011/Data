package com.opl.jns.oneform.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.oneform.api.model.MasterResponse;
import com.opl.jns.oneform.service.domain.CountryV3;

public interface CountryRepositoryV3 extends JpaRepository<CountryV3, Long>{

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(si.id,si.value) from CountryV3 si where si.id=:id")
	MasterResponse fetchById(@Param("id")Long id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(si.id,si.value) from CountryV3 si where si.id in :id")
	List<MasterResponse> findByListId(@Param("id")List<Long> id);
	
	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(si.id,si.value,si.countryCode) from CountryV3 si ")
	List<MasterResponse> getAllCountries();

}
