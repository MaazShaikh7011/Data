package com.opl.jns.oneform.service.utils;

import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class NsdlFechMasterDataEduClient {

    public <T> T post(String url, Object request, Class<?> clazz, Map<String, String> header, MediaType contentType) throws HttpClientErrorException {
        RestTemplate restTemplate = new RestTemplate();
        log.info("Calling POST API : [{}]", url);
        HttpHeaders headers = new HttpHeaders();
        if (!OPLUtils.isObjectNullOrEmpty(header)) {
            for (Map.Entry<String, String> entry : header.entrySet()) {
                headers.set(entry.getKey(), entry.getValue());
            }
        }
        if (!OPLUtils.isObjectNullOrEmpty(contentType)) {
            headers.setContentType(contentType);
        }
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String str, SSLSession sslSession) {
                log.info("Value : [{}]", str);
                log.info("Peer Host : [{}]", sslSession.getPeerHost());
                for (String s : sslSession.getValueNames()) {
                    log.info("Peer Value : [{}]", s);
                }
                return true;
            }
        });
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<Object> req = new HttpEntity<>(request, headers);
        try {
            return (T) restTemplate.postForObject(url, req, clazz);
        } catch (HttpClientErrorException e) {
            throw e;
        }
    }

}
