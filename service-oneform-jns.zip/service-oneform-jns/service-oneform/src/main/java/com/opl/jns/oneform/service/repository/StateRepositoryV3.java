package com.opl.jns.oneform.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.oneform.api.model.MasterResponse;
import com.opl.jns.oneform.service.domain.StateV3;

public interface StateRepositoryV3 extends JpaRepository<StateV3, Long> {
	
	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.value,s.code,0) from StateV3 s where s.country.id=:id")
	List<MasterResponse> findByCountryId(@Param("id") Long id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.value) from StateV3 s where s.id=:id")
	MasterResponse fetchById(@Param("id") Long id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.value) from StateV3 s where s.id in :id")
	List<MasterResponse> findById(@Param("id") List<Long> id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.code) from StateV3 s where s.id in :id")
	List<MasterResponse> findCodeById(@Param("id") List<Long> id);

	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.value) from StateV3 s where s.itrCode=:itrCode")
	MasterResponse getByITRCode(@Param("itrCode") String itrCode);
	
	@Query(value = "select * from StateV3 where country_id =:countryId and lower(state_name) = lower(:stateName) limit 1;",nativeQuery = true)
	public StateV3 findByCountryIdAndStateName(@Param("countryId")Long countryId,@Param("stateName")String stateName);
	
	@Query(value = "select * from StateV3 where country_id =:countryId and code =:stateCode limit 1;",nativeQuery = true)
	public StateV3 findByCountryIdAndStateCode(@Param("countryId")Long countryId, @Param("stateCode")Long stateCode);
	
	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(c.id,c.value,c.subsidyCode) from StateV3 c where c.subsidyCode = :subsidyStateCode")
	MasterResponse findStateBySubsidyStateCode(@Param("subsidyStateCode")Integer subsidyStateCode);
	
	@Query("select new com.opl.jns.oneform.api.model.MasterResponse(s.id,s.value,s.subsidyCode) from StateV3 s where s.country.id=:id")
	List<MasterResponse> findSateByCountryId(@Param("id") Long id);
}
