package com.opl.jns.oneform.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.oneform.service.utils.LGDURLProperties;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = { "com.opl" })
@EnableConfigurationProperties({ApplicationProperties.class,LGDURLProperties.class})
@EnableDiscoveryClient
public class OneFormApplication {
	
	@Autowired
	private ApplicationContext applicationContext; 

	public static void main(String[] args) throws Exception {
		SpringApplication.run(OneFormApplication.class, args);
	}
	
	@Bean
	public AuthClient authClient() {
		AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
		return authClient;
	}
	
//	@Bean
//	public AnsLogsClient clientLogs() {
//		AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
////		ClientLogs clientLogs = new ClientLogs("https://sit-opl-atmanirbhar.instantmseloans.in/ans-logs");
//		applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//		return ansLogsClient;
//	}
}	
