package com.opl.jns.oneform.service.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.oneform.api.model.*;
import com.opl.jns.oneform.service.domain.DropDownMasterV3;
import com.opl.jns.oneform.service.domain.DropDownValuesV3;
import com.opl.jns.oneform.service.repository.*;
import com.opl.jns.oneform.service.service.CommonMasterServiceV3;
import com.opl.jns.utils.common.OPLUtils;


@Service
@Transactional
public class CommonMasterServiceImplV3 implements CommonMasterServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(CommonMasterServiceImplV3.class);
	
	@Autowired
	private CityRepositoryV3 cityRepository;

	@Autowired
	private StateRepositoryV3 stateRepository;

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private CountryRepositoryV3 countryRepository;
	
	@Autowired
	private DropDownValuesRepositoryV3 dropDownValuesRepository;

	@Autowired
	private LgdDistrictRepositoryV3 lgdDistrictRepository;

	@Autowired
	private LgdStateRepositoryV3 lgdStateRepository;

	@Override
	@Cacheable(value = "onfm_getStateListByCountryId")
	public List<MasterResponse> getStateListByCountryId(Long id) {
		logger.info("Start getStateListByCountryId");
		return stateRepository.findByCountryId(id);
	}

	@Override
	@Cacheable(value = "onfm_getStateListByCountryIdListId")
	public List<StateByCountryIdResponse> getStateListByCountryIdListId(List<Long> ids) {
		logger.info("Start getStateListByCountryIdListId");
		List<StateByCountryIdResponse> idResponses = new ArrayList<>();
		for (Long id : ids) {
			StateByCountryIdResponse idResponse = new StateByCountryIdResponse();
			idResponse.setCountryId(countryRepository.fetchById(id));
			idResponse.setStateIdList(stateRepository.findByCountryId(id));
			idResponses.add(idResponse);
		}
		logger.info("End getStateListByCountryIdListId");
		return idResponses;
	}

	@Override
	@Cacheable(value = "onfm_findByCityId")
	public MasterResponse findByCityId(Long id) throws Exception {
		return cityRepository.findCityById(id);
	}

	@Override
	@Cacheable(value = "onfm_getState")
	public MasterResponse findByStateId(Long id) throws Exception {
		return stateRepository.fetchById(id);
	}

	@Override
	@Cacheable(value = "onfm_getLgdState")
	public LgdStateResponse findByLgdStateId(Long id) throws Exception {
		return lgdStateRepository.fetchById(id);
	}

	@Override
	@Cacheable(value = "onfm_getStateListByCountry")
	public List<MasterResponse> getStateListByCountry(Long id) {
		logger.info("Start getStateListByCountryId");
		return stateRepository.findSateByCountryId(id);
	}


	@Override
	@Cacheable(value = "onfm_getCityStateMaster")
	public List<CityStateResponse> getCityStateMaster() {
		logger.info("Start getCityStateByCountryId");
		List<CityStateResponse> data = cityRepository.findAllCityState();
		logger.info("Successfully Out from getCityStateByCountryId");
		return data;
	}

	@Override
	public DropDownProxy getNameByKeyAndObjId(String key, Integer objId) {
		try {
			DropDownValuesV3 dropDownValues = dropDownValuesRepository.findByObjIdAndIsActiveTrueAndDropdownIdKey(objId, key);
			if (!OPLUtils.isObjectNullOrEmpty(dropDownValues)) {
				DropDownProxy dropDownProxy = new DropDownProxy();
				dropDownProxy.setId(dropDownValues.getObjId());
				dropDownProxy.setValue(dropDownValues.getValue());
				return dropDownProxy;
			}
		} catch (Exception e) {
			logger.error("Exception is getting while get dropdown Object ===> {} ",e);
		}
		return null;
	}

	@Override
	public DropDownProxy getIdByKeyAndName(String key, String objValue) {
		try {
			DropDownValuesV3 dropDownValues = dropDownValuesRepository.findByValueAndIsActiveTrueAndDropdownIdKey(objValue, key);
			if (!OPLUtils.isObjectNullOrEmpty(dropDownValues)) {
				DropDownProxy dropDownProxy = new DropDownProxy();
				dropDownProxy.setId(dropDownValues.getObjId());
				dropDownProxy.setValue(dropDownValues.getValue());
				return dropDownProxy;
			}
		} catch (Exception e) {
			logger.error("Exception is getting while get dropdown Object ===> {} ",e);
		}
		return null;
	}
	
	@Override
	public Map<String, List<DropDownProxy>> getMasterListByKey(List<String> key) {
		try {
			List<DropDownValuesV3> dropDownList = dropDownValuesRepository.findByDropdownKeyAndIsActiveTrue(key);
			if (!OPLUtils.isListNullOrEmpty(dropDownList)) {
				Map<DropDownMasterV3, List<DropDownValuesV3>> collect = dropDownList.stream().collect(Collectors.groupingBy(DropDownValuesV3::getDropdownId));
				Map<String, List<DropDownProxy>> response = new HashMap<>(collect.size());
				for (Map.Entry<DropDownMasterV3, List<DropDownValuesV3>> entry : collect.entrySet()) {
					List<DropDownProxy> forMap = new ArrayList<>(entry.getValue().size());
					for (DropDownValuesV3 downValues : entry.getValue()) {
						forMap.add(new DropDownProxy().toBuilder().id(downValues.getObjId()).value(downValues.getValue()).build());
					}
					response.put(entry.getKey().getKey(), forMap);
				}
				return response;
			}
		} catch (Exception e) {
			logger.error("Exception is getting While get Master List-- > {}", e);
		}
		return null;
	}

	@Override
//	@Cacheable(value = "onfm_getCityListByState")
	public List<MasterResponse> getCityListByStateId(Long id) {
		logger.info("Start getCityListByStateId {}", id);
		return cityRepository.findByStateId(id);
	}

	@Override
	@Cacheable(value = "onfm_getLgdDistrictStateResponse")
	public List<LgdDistrictStateResponse> getLgdDistrictStateResponse() {
		logger.info("Start getLgdDistrictStateResponse");
		List<LgdDistrictStateResponse> data = lgdDistrictRepository.findAllLgdDistrictState();
		logger.info("Successfully Out from getLgdDistrictStateResponse");
		return data;
	}

	@Override
	@Cacheable(value = "onfm_getLgdStateList")
	public List<LgdStateResponse> getLgdStateList() {
		logger.info("Start getLgdStateList");
		return lgdStateRepository.findAllByIsActive(Boolean.TRUE);
	}

	@Override
	public List<LgdDistrictStateResponse> getLgdCityListByLgdStateId(Long id) {
		logger.info("Start getCityListByStateId {}", id);
		return lgdDistrictRepository.findByLgdStateId(id);
	}

	@Override
	@Cacheable(value = "onfm_getLgdCityId")
	public LgdDistrictStateResponse findByLgdCityId(Long id) {
		return lgdDistrictRepository.findLgdCityById(id);
	}
}
