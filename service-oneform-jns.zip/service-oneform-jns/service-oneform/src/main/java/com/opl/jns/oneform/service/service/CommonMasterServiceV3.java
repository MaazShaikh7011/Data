package com.opl.jns.oneform.service.service;

import java.util.List;
import java.util.Map;

import com.opl.jns.oneform.api.model.*;

public interface CommonMasterServiceV3 {
	
	
	public List<MasterResponse> getStateListByCountryId(Long id);

	public List<StateByCountryIdResponse> getStateListByCountryIdListId(List<Long> id);
	
	public MasterResponse findByCityId(Long id) throws Exception;

	public MasterResponse findByStateId(Long id) throws Exception;
	
	public LgdStateResponse findByLgdStateId(Long id) throws Exception;

	public List<MasterResponse> getStateListByCountry(Long id) throws Exception;

	public List<CityStateResponse> getCityStateMaster();
	
	public DropDownProxy getNameByKeyAndObjId(String key, Integer objId);

    DropDownProxy getIdByKeyAndName(String string, String objValue);
    
    public Map<String, List<DropDownProxy>> getMasterListByKey(List<String> key);

	public List<MasterResponse> getCityListByStateId(Long id);

	public List<LgdDistrictStateResponse> getLgdDistrictStateResponse();

	public List<LgdStateResponse> getLgdStateList();

	public List<LgdDistrictStateResponse> getLgdCityListByLgdStateId(Long id);

	public LgdDistrictStateResponse findByLgdCityId(Long id);
}

