package com.opl.jns.oneform.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "LGD_DISTRICT")
public class LgdDistrictV3 {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "lgd_district_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_ONEFORM, name = "lgd_district_seq_gen", sequenceName = "lgd_district_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "name", columnDefinition = "varchar(255) default ''")
    private String name;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "state_id", referencedColumnName = "id")
    private LgdStateV3 lgdState;

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;

    @Column(name = "code", columnDefinition = "varchar(15) default ''")
    private String code;
}
