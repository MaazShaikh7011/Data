package com.opl.jns.oneform.service.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ConfigurationProperties(prefix="com.jns.oneform.lgd")
public class LGDURLProperties {

	private String stateUrl;
	private String districtUrl;
	private String districtByStateCodeUrl;
	private String subDistrictUrl;
	private String subDistrictByDistrictUrl;
	private String villageUrl;
	private String villageBySubDistrictUrl;
	private String blockUrl;
	private String blockByVillageUrl;
	private String blockByDistrictUrl;
	private String localBodyUrl;
	private String localBodyWardUrl;
}
