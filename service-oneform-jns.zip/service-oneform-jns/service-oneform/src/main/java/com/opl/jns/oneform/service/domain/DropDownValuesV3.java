package com.opl.jns.oneform.service.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author - Ravi Thummar
 * @Date - 3/8/2023
 */

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "dropdowns_values")
public class DropDownValuesV3 {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dropdowns_values_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_ONEFORM, name = "dropdowns_values_seq_gen", sequenceName = "dropdowns_values_seq_gen", allocationSize = 1)
	private Long id;


	@Column(name = "obj_id")
	private Integer objId;

	@Column(name="value", columnDefinition = "varchar(255) default ''")
	private String value;

	@Column(name = "order_id")
	private Integer orderId;

	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "dropdown_id",referencedColumnName = "id")
	private DropDownMasterV3 dropdownId;

	@Column(name = "is_active")
	  private Boolean isActive;

}