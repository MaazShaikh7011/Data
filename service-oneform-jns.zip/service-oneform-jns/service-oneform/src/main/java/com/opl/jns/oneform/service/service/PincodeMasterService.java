package com.opl.jns.oneform.service.service;

import java.util.List;

import com.opl.jns.oneform.api.model.PincodeMasterResponse;

public interface PincodeMasterService {

	
	public PincodeMasterResponse getFirstPincodeMasterByPincode(String pincode);

}
