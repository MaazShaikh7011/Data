CREATE OR REPLACE PROCEDURE JNS_REPORTS.PUSH_DAILY_COUNT
AS
	results  CLOB;
    startdate TIMESTAMP;
    enddate TIMESTAMP;
    currentdate TIMESTAMP;
    morningdate TIMESTAMP;
    failcase NUMBER;
    publishpendingcount NUMBER;
    futuredateissueenrollment NUMBER;
    futuredateissuecoverenddate NUMBER;
    pastdateissuesenrollment NUMBER;
    pastdateissuescoverenddate NUMBER;
    coountmatchjnsinsurance NUMBER;
    countmatchjnsinsurancepmsby NUMBER;
    countmatchjnsinsurancepmjjby NUMBER;
    countmatchjnsmasterpmsby NUMBER;
    countmatchjnsmasterpmjjby NUMBER;
    countmatchpublish NUMBER;
    orgenrollnullissue NUMBER;
    expireQueryassistedmode NUMBER;
    expirequeryotherchannel NUMBER;
    expireyesterdayassistedmode NUMBER;
    expireyesterdayotherchannel NUMBER;
    dublicatecif NUMBER;
    lagacydatadublicate NUMBER;
    completedenrollmentyesterday NUMBER;
BEGIN
	 SELECT TO_TIMESTAMP(concat(current_date, ' 12:00:00.000000 AM')) INTO startdate FROM dual;
	 SELECT TO_TIMESTAMP(concat(current_date, ' 11:59:59.999999 PM')) INTO enddate FROM dual;
	 SELECT TO_TIMESTAMP(concat(current_date, ' 06:00:00.000000 AM')) INTO morningdate FROM dual;
     SELECT current_timestamp into currentdate FROM dual;

-- 1) Failed cases
	SELECT COUNT(ID) INTO failcase from jns_insurance.APPLICATION_MASTER
	WHERE stage_id in(5,15) and last_transaction_id is not null AND is_active=1 and ENROLLMENT_DATE < (enddate-1);

-- 2) Publish pending count
	SELECT COUNT(ID) INTO publishpendingcount FROM JNS_INSURANCE.application_push_status WHERE (master_push is null or master_push = 0) ORDER BY id ASC;

-- 3) Future Date issues -Enrollment
	SELECT COUNT(id) INTO futuredateissueenrollment from jns_insurance.APPLICATION_MASTER where enrollment_date > enddate and is_active=1;

-- 4) Future Date issues -Cover End Date
	SELECT count(ID) INTO futuredateissuecoverenddate from jns_insurance.transaction_details where cover_end_date > TO_TIMESTAMP(concat(TO_DATE('31-05-25', 'dd-mm-yy'), ' 11:59:59.999999 PM')) AND is_active=1;

-- 5) Past Date issues -Enrollment
	SELECT COUNT(id) INTO pastdateissuesenrollment FROM jns_insurance.APPLICATION_MASTER where enrollment_date < TO_TIMESTAMP(concat(TO_DATE('01-06-23', 'dd-mm-yy'), ' 12:00:00.000000 AM')) AND is_active=1;

-- 6) Past Date issues -Cover Start Date
	SELECT COUNT(id) INTO pastdateissuescoverenddate FROM jns_insurance.transaction_details  where cover_start_date < TO_TIMESTAMP(concat(TO_DATE('01-06-23', 'dd-mm-yy'), ' 12:00:00.000000 AM')) AND is_active=1;

-- 7) Count Match JNS INSURANCE
	SELECT COUNT(ID) INTO coountmatchjnsinsurance FROM jns_insurance.APPLICATION_MASTER where  is_active=1 and stage_id=6  AND enrollment_date < morningdate;

-- 8) Count Match JNS INSURANCE PMSBY
	select COUNT(ID) INTO countmatchjnsinsurancepmsby FROM jns_insurance.APPLICATION_MASTER where  is_active=1 and stage_id=6 and scheme_id=1  AND enrollment_date < morningdate;

-- 9) Count Match JNS INSURANCE PMJJBY
	select COUNT(ID) INTO countmatchjnsinsurancepmjjby FROM jns_insurance.APPLICATION_MASTER where  is_active=1 and stage_id=6 and scheme_id=2  AND enrollment_date < morningdate;

-- 10) Count Match JNS MASTER PMSBY
	select COUNT(ID) INTO countmatchjnsmasterpmsby FROM jns_master.PMSBY where is_active=1 and status=2  AND completion_date < morningdate;

-- 11) Count Match JNS MASTER PMJJBY
	select COUNT(ID) INTO countmatchjnsmasterpmjjby FROM jns_master.PMJJBY where  is_active=1 and status=2  AND completion_date < morningdate;

-- 12) Count Match JNS MASTER ALL SCHEME
	--	Count Match JNS MASTER PMSBY + Count Match JNS MASTER PMJJBY
	-- countmatchjnsmasterpmsby + countmatchjnsmasterpmjjby

-- 13) Count Match PUBLISH
	SELECT COUNT(ID) INTO countmatchpublish FROM JNS_PUBLISH_API.APPLICATION_MASTER where  is_active=1 AND push_ready_date < morningdate;

-- 14) ORG/Enrollment null issues
	SELECT COUNT(ID) INTO orgenrollnullissue FROM jns_insurance.APPLICATION_MASTER where stage_id in(6) and insurer_org_id is null  and is_active=1;

-- 15) Exipre Query -- Asssited mode
	select COUNT(ID) INTO expireQueryassistedmode FROM jns_insurance.application_master  m
	inner join jns_insurance.application_master_other_details d on d.application_master_id =m.id
	WHERE m.is_active = 1 AND m.stage_id in (7) and d.source in (2,4) AND modified_date BETWEEN startdate AND enddate;

-- 16) Exipre Query -Other channel
	SELECT COUNT(ID) INTO expirequeryotherchannel FROM jns_insurance.application_master  m
	INNER JOIN jns_insurance.application_master_other_details d on d.application_master_id =m.id
	WHERE m.is_active = 1 AND m.stage_id in (7) AND d.source=1 AND modified_date BETWEEN startdate AND enddate;

-- 17) Expired Yesterday assisted mode
	SELECT COUNT(ID) INTO expireyesterdayassistedmode FROM jns_master.expired_enrollment WHERE is_active = 1 AND stage_id in (7) AND source in (2,4) AND modified_date BETWEEN startdate AND enddate;

-- 18) Expired Yesterday other channel
	SELECT COUNT(ID) INTO expireyesterdayotherchannel FROM jns_master.expired_enrollment WHERE is_active = 1 AND stage_id in (7) AND source=1 AND modified_date BETWEEN startdate AND enddate;

-- 19) duplicate cif
	SELECT COUNT(*) INTO dublicatecif
	FROM (
		select account_number,cif,count(*) from jns_master.pmjjby p
		inner join JNS_MASTER.applicant_pi_details pi on pi.id=p.id
		where status =2
		group by account_number,cif having count(*) > 1
		union all
		select account_number,cif,count(*) from jns_master.pmsby p
		inner join JNS_MASTER.applicant_pi_details pi on pi.id=p.id
		where status =2
		group by account_number,cif having count(*) > 1
	);

-- 20) legacy data duplicate
	SELECT COUNT(*) INTO lagacydatadublicate
	FROM (
		select account_number,cif,count(*) from jns_master.pmjjby p
		inner join JNS_MASTER.applicant_pi_details pi on pi.id=p.id
		where status =2 and source=3
		group by account_number,cif having count(*) > 1
		union all
		select account_number,cif,count(*) from jns_master.pmsby p
		inner join JNS_MASTER.applicant_pi_details pi on pi.id=p.id
		where status =2 and source=3
		group by account_number,cif having count(*) > 1
	);

-- 21) Completed Enrollment Yesterday
	SELECT count(id) INTO completedenrollmentyesterday FROM JNS_INSURANCE.APPLICATION_MASTER am WHERE STAGE_ID = 6 AND APPLICATION_STATUS =2 AND COMPLETION_DATE BETWEEN (startdate - 1) AND (enddate - 1);


SELECT JSON_OBJECT('Failed Cases' VALUE failcase,
	'Publish Pending Count' VALUE publishpendingcount,
	'Future Date Issues -Enrollment' VALUE futuredateissueenrollment,
	'Future Date Issues -Cover End Date' VALUE futuredateissuecoverenddate,
	'Past Date Issues -Enrollment' VALUE pastdateissuesenrollment,
	'Past Date Issues -Cover Start Date ' VALUE pastdateissuescoverenddate,
	'Count Match JNS INSURANCE' VALUE coountmatchjnsinsurance,
	'Count Match JNS INSURANCE PMSBY' VALUE countmatchjnsinsurancepmsby,
	'Count Match JNS INSURANCE PMJJBY' VALUE countmatchjnsinsurancepmjjby,
	'Count Match JNS MASTER PMSBY' VALUE countmatchjnsmasterpmsby,
	'Count Match JNS MASTER PMJJBY' VALUE countmatchjnsmasterpmjjby,
	'Count Match JNS MASTER ALL SCHEME' VALUE (countmatchjnsmasterpmsby+countmatchjnsmasterpmjjby),
	'Count Match PUBLISH' VALUE countmatchpublish,
	'ORG_Enrollment Null Issues' VALUE orgenrollnullissue,
	'Exipre Query -Asssited Mode' VALUE expireQueryassistedmode,
	'Exipre Query -Other Channel' VALUE expirequeryotherchannel,
	'Expired Yesterday Assisted Mode' VALUE expireyesterdayassistedmode,
	'Expired Yesterday Other Channel' VALUE expireyesterdayotherchannel,
	'Duplicate CIF' VALUE dublicatecif,
	'Legacy Data Duplicate' VALUE lagacydatadublicate,
	'Completed Enrollment Yesterday' VALUE completedenrollmentyesterday) INTO results FROM dual;

INSERT INTO JNS_REPORTS.DAILY_COUNT_STATUS(START_DATE,END_DATE,FAILED_CASES,PUBLISH_PENDING_COUNT,FUTURE_DATE_ISSUES_ENROLLMENT,FUTURE_DATE_ISSUES_COVER_END_DATE,PAST_DATE_ISSUES_ENROLLMENT,PAST_DATE_ISSUES_COVER_START_DATE,COUNT_MATCH_JNS_INSURANCE,COUNT_MATCH_JNS_INSURANCE_PMSBY,COUNT_MATCH_JNS_INSURANCE_PMJJBY,COUNT_MATCH_JNS_MASTER_PMSBY,COUNT_MATCH_JNS_MASTER_PMJJBY,COUNT_MATCH_JNS_MASTER_ALL_SCHEME,COUNT_MATCH_PUBLISH,ORG_ENROLLMENT_NULL_ISSUES,EXIPRE_QUERY_ASSSITED_MODE,EXIPRE_QUERY_OTHER_CHANNEL,EXPIRED_YESTERDAY_ASSISTED_MODE,EXPIRED_YESTERDAY_OTHER_CHANNEL,DUPLICATE_CIF,LEGACY_DATA_DUPLICATE, COMPLETED_ENROLLMENT_YESTERDAY,JSON_OBJ)
SELECT currentdate, current_timestamp, failcase, publishpendingcount, futuredateissueenrollment, futuredateissuecoverenddate, pastdateissuesenrollment, pastdateissuescoverenddate, coountmatchjnsinsurance, countmatchjnsinsurancepmsby, countmatchjnsinsurancepmjjby, countmatchjnsmasterpmsby, countmatchjnsmasterpmjjby, (countmatchjnsmasterpmsby+countmatchjnsmasterpmjjby), countmatchpublish, orgenrollnullissue, expireQueryassistedmode, expirequeryotherchannel, expireyesterdayassistedmode, expireyesterdayotherchannel, dublicatecif, lagacydatadublicate, completedenrollmentyesterday, results FROM DUAL;
--dbms_output.put_line(results);

END PUSH_DAILY_COUNT;