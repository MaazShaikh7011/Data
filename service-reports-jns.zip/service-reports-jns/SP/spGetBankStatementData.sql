DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetBankStatementData`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetBankStatementData`(IN fromDate VARCHAR(20), IN toDate VARCHAR(20),IN environment VARCHAR(255), IN idList LONGTEXT)
BEGIN

	SET @selectQuery = CONCAT(' SELECT DISTINCT UNCOMPRESS(repo.request) AS request, repo.bs_master_id AS bsMasterId, "',environment,'" as environment ');
	SET @retailTableQuery = ' , "Retail" AS loanName FROM `statement_analyzer`.`prefious_log_history` repo ';
	SET @agriTableQuery = ' , "Agri" AS loanName FROM `statement_analyzer_agri`.`prefious_log_history` repo ';
	SET @livelihoodTableQuery = ' , "livelihood" AS loanName FROM `statement_analyzer_livelihood`.`prefious_log_history` repo ';
	SET @msmeTableQuery = ' , "msme" AS loanName FROM `statement_analyzer_msme`.`prefious_log_history` repo ';
	SET @whereClause = CONCAT(' WHERE DATE(repo.created_date) BETWEEN "',fromDate,'" AND "',toDate,'"
		AND (repo.api_type="beforeupload" OR repo.api_type="beforeuploadretail")
		AND UNCOMPRESS(repo.request) IN(',idList,') ');

	SET @query = CONCAT(@selectQuery, @retailTableQuery, @whereClause,
			    ' UNION ALL ', @selectQuery, @agriTableQuery, @whereClause,
			    ' UNION ALL ', @selectQuery, @msmeTableQuery, @whereClause,
			    ' UNION ALL ', @selectQuery, @livelihoodTableQuery, @whereClause);

-- 	select @query;
	PREPARE stmt FROM @query;
	EXECUTE stmt;

-- 	call banker_report.spGetBankStatementData('2022-11-01', '2022-11-31','QA' , '');

END$$

DELIMITER ;