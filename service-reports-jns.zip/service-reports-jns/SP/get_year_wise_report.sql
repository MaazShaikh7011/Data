CREATE OR REPLACE PROCEDURE get_year_wise_report (
    filterjson  IN   VARCHAR2 DEFAULT NULL,
    fromdate    IN   VARCHAR2 DEFAULT NULL,
    todate      IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB
) AS
    selectquery clob;
    mainquery CLOB;
BEGIN
    selectquery := ' select JSON_OBJECT( ''totalCount'' value count(am.id),
            ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
            ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end)) ';

    mainquery := selectquery || ' from JNS_INSURANCE.application_master_test am  ';

    mainquery := mainquery
                 || ' where to_char(am.modified_date,''yyyy-mm-dd'') BETWEEN '''
                 || fromdate
                 || ''' and '''
                 || todate
                 || ''' and stage_id in(6,8) ';
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);

END get_year_wise_report;