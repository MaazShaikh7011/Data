CREATE OR REPLACE PROCEDURE get_top_office (
    filterjson  IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB
) AS
    mainquery  CLOB;
    branchid   LONG;
    limitquery VARCHAR(1000);
BEGIN

    IF JSON_VALUE(filterjson, '$.branchType') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.branchType') = 1 THEN branchid := 'am.branch_id';
        ELSIF JSON_VALUE(filterjson, '$.branchType') = 2 THEN branchid := 'am.branch_ro_id ';
        ELSIF JSON_VALUE(filterjson, '$.branchType') = 3 THEN branchid := 'am.branch_ro_id ';
        END IF;
    END IF;

--    IF
--        JSON_VALUE(filterjson, '$.from') IS NOT NULL
--        AND JSON_VALUE(filterjson, '$.to') IS NOT NULL
--    THEN
--        limitquery := ' OFFSET '
--                      || JSON_VALUE(filterjson, '$.from')
--                      || ' ROWS FETCH NEXT '
--                      || JSON_VALUE(filterjson, '$.to')
--                      || ' ROWS ONLY';
--    ELSE
--        limitquery := '';
--    END IF;

    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''branchId'' value '|| branchid ||', ''totalCount'' value COUNT(am.id), ''totalAmount'' value sum(am.amount)))
    FROM jns_insurance.application_master_test am
    WHERE '|| branchid ||' IS NOT NULL
    GROUP BY '|| branchid ||'
    ORDER BY COUNT(am.id) DESC ';
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);
END get_top_office;