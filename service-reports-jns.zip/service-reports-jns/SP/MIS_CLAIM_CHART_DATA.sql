CREATE OR REPLACE PROCEDURE JNS_REPORTS.MIS_CLAIM_CHART_DATA(
  filterjson  IN   varchar2,
    result      OUT  clob
) AS
    selectquery           CLOB;
    tablequery            CLOB;
    groupByQuery          CLOB;
    whereclause           CLOB;
    mainQuery             CLOB;
    keyValue              CLOB;
BEGIN
    tablequery := ' FROM JNS_REPORTS.JNS_CLAIM_DATA cm ';
    whereclause := ' WHERE 1=1 ';

    If(JSON_VALUE(FILTERJSON, '$.version') is not null) THEN
        whereclause := whereclause || ' AND cm.version = ' || JSON_VALUE(FILTERJSON, '$.version');
    END IF;

    If(JSON_VALUE(FILTERJSON, '$.schemeId') is not null) THEN
        whereclause := whereclause || ' AND cm.SCHEME_ID = ' || JSON_VALUE(FILTERJSON, '$.schemeId');
    END IF;

    If(JSON_VALUE(FILTERJSON, '$.tabId') is not null) THEN

    	If(JSON_VALUE(FILTERJSON, '$.tabId') = 1 OR JSON_VALUE(FILTERJSON, '$.tabId') = 2) THEN
    		If(JSON_VALUE(FILTERJSON, '$.insideTabId') = 1) THEN
    			selectquery := ' (SUM(cm.MALE_CLM_RECV) + SUM(cm.FEMALE_CLM_RECV) + SUM(cm.TRANS_G_CLM_RECV)) ';
    		ELSIF(JSON_VALUE(FILTERJSON, '$.insideTabId') = 2) THEN
    			selectquery := ' (SUM(cm.MALE_CLM_PAID) + SUM(cm.FEMALE_CLM_PAID) + SUM(cm.TRANS_G_CLM_PAID)) ';
    		ELSIF(JSON_VALUE(FILTERJSON, '$.insideTabId') = 3) THEN
    			selectquery := ' (SUM(cm.MALE_CLM_REJECT) + SUM(cm.FEMALE_CLM_REJECT) + SUM(cm.TRANS_G_CLM_REJECT)) ';
    		ELSIF(JSON_VALUE(FILTERJSON, '$.insideTabId') = 4) THEN
    			selectquery := ' (SUM(cm.MALE_CLM_OUT_STAND) + SUM(cm.FEMALE_CLM_OUT_STAND) + SUM(cm.TRANS_G_CLM_OUT_STAND)) ';
    		END IF;
    	END IF;

--         TAB ID = 1 MEANS BANK WISE CHART
        If(JSON_VALUE(FILTERJSON, '$.tabId') = 1) THEN
            selectquery := ' ''totalCount'' value '|| selectquery ||',
                             ''orgId'' value  cm.org_id, ''bankName'' value UOM.SHORT_NAME  )
--                             ORDER BY sum(cm.total_enrollment)  desc
                              RETURNING CLOB)';
            tablequery := tablequery || ' INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER UOM on UOM.user_org_id = cm.org_id ';
            groupByQuery := ' group by cm.org_id,UOM.SHORT_NAME ';

            If(JSON_VALUE(FILTERJSON, '$.orgId') is not null) THEN
                whereclause := whereclause || ' AND cm.org_id = ' || JSON_VALUE(FILTERJSON, '$.orgId');
            END IF;
        END If;

--         TAB ID = 2 MEANS INSURER WISE CHART
        If(JSON_VALUE(FILTERJSON, '$.tabId') = 2) THEN
            selectquery := ' ''totalCount'' value '|| selectquery ||',
                             ''insurerCode'' value cm.INSURER_ORG_ID, ''insurerName'' value  UOM.SHORT_NAME )
--                             ORDER BY sum(mis.total_enrollment) desc
                             RETURNING CLOB)';
--            tablequery := tablequery || ' INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER UOM on UOM.ORGANISATION_CODE = cm.insurer_code ';
             tablequery := tablequery || ' INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER UOM on UOM.user_org_id = cm.insurer_org_id   ';

            groupByQuery := ' group by cm.INSURER_ORG_ID,UOM.SHORT_NAME ';

            If(JSON_VALUE(FILTERJSON, '$.insurerCode') is not null) THEN
                whereclause := whereclause || ' AND cm.insurer_code = ' || JSON_VALUE(FILTERJSON, '$.insurerCode');
            END IF;
        end if;

 --         TAB ID = 3 MEANS STATE WISE CHART
         If(JSON_VALUE(FILTERJSON, '$.tabId') = 3) THEN
                selectquery := ' ''totalCount'' value COALESCE(t.totalCnt, 0),''stateCode'' value  st.code,
                                 ''stateName'' value  st.name ) RETURNING CLOB)
                                   from  jns_oneForm.lgd_state st
                                      left join( select  count(*) As totalCnt, cm.LGD_STATE_CODE AS cStateCode
                                                 '||tablequery|| whereclause ||' group by cm.LGD_STATE_CODE )t
                                      on t.cStateCode = st.code  WHERE  st.is_active =1';
         END IF;

 --     TAB ID = 4 MEANS GENDER WISE CHART
        If(JSON_VALUE(FILTERJSON, '$.tabId') = 4) THEN
        	keyValue := '[{"key":"male","label":"Male","color":"#468CC2,#23699E"},{"key":"female","label":"Female","color":"#B13173,#C86E9C"},{"key":"trans","label":"Transgender","color":"#F96767,#F3A2A2"}]';

        	If(JSON_VALUE(FILTERJSON, '$.insideTabId') = 1) THEN
        		selectquery := ' SELECT sum(cm.MALE_CLM_RURAL_COUNT) AS maleCount,
							sum(cm.FEMALE_CLM_RURAL_COUNT) AS femaleCount,
							sum(cm.TRANSG_CLM_RURAL_COUNT) AS transCount ' ||tablequery|| whereclause;

            ELSIF(JSON_VALUE(FILTERJSON, '$.insideTabId') = 2) THEN
				selectquery := ' SELECT sum(cm.MALE_CLM_URBAN_COUNT) AS maleCount,
							sum(cm.FEMALE_CLM_URBAN_COUNT) AS femaleCount,
							sum(cm.TRANSG_CLM_URBAN_COUNT) AS transCount ' ||tablequery|| whereclause;
        	END IF;

        	selectquery := ' ''male'' VALUE t.maleCount ,''female'' VALUE t.femaleCount,
					''trans'' VALUE t.transCount,''keyValue'' value '''|| keyValue|| ''' ) RETURNING CLOB) FROM ('|| selectquery ||') t ';

        END IF;

 --         TAB ID = 9 MEANS CLIAM_AGINNG WISE CHART
         If(JSON_VALUE(FILTERJSON, '$.tabId') = 9) THEN
            keyValue := '[{"key":"total","label":"Total Outstanding Claims"},{"key":"g1Year","label":">1 Year"},
                            {"key":"g6months","label":"6M-1Y"},{"key":"g60days","label":"60D-6M"},
                            {"key":"g14days","label":"14-60 Days"},{"key":"g7days","label":"7-14 Days"},
                            {"key":"l7days","label":"<7 Days"}]';
            selectquery := ' ''total'' VALUE count(*), ''g1Year'' VALUE sum(cm.grater_than_1_year),
                            ''g6months'' VALUE sum(cm.grater_than_6_months),''g60days'' VALUE sum(cm.grater_than_60_days),
                            ''g14days'' VALUE sum(cm.grater_than_14_days),''g7days'' VALUE sum(cm.grater_than_7_days),
                            ''l7days'' VALUE sum(cm.less_than_7_days), ''keyValue'' value '''|| keyValue|| ''')
                            RETURNING CLOB)';
            groupByQuery := ' group by cm.version';
         END IF;
     END IF;


    IF(JSON_VALUE(FILTERJSON, '$.tabId') = 3 OR JSON_VALUE(FILTERJSON, '$.tabId') = 4 ) THEN
         mainQuery := ('select JSON_ARRAYAGG(JSON_OBJECT(' || selectquery ); -- || whereclause || limitquery;
    ELSE
         mainQuery := ('select JSON_ARRAYAGG(JSON_OBJECT(' || selectquery || tablequery || whereclause || groupByQuery); -- || whereclause || limitquery;
    end If;
--     mainQuery := ('select JSON_ARRAYAGG(JSON_OBJECT(' || selectquery || tablequery || whereclause || groupByQuery); -- || whereclause || limitquery;
    dbms_output.put_line(mainQuery);

    EXECUTE IMMEDIATE mainQuery into result;
END MIS_CLAIM_CHART_DATA;