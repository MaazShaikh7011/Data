CREATE OR REPLACE NONEDITIONABLE PROCEDURE fetch_claim_list (
    filterjson  IN   VARCHAR2,
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
    totalcount    LONG;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    limitquery    CLOB;
    preparequery  CLOB;
BEGIN
    selectquery := ' ''id'' value ca.id,
                           ''applicationId'' value ca.application_id,
                           ''accountHolderName'' value ca.account_holder_name,
                           ''amount_of_transaction'' value ca.amount_of_transaction,
                           ''customerAccountNumber'' value ca.customer_account_number,
                           ''urn'' value ca.urn,
                           ''mobileNumber'' value ca.mobile_number,
                           ''schemeName'' value CASE WHEN ca.schme_id=1 THEN  ''PMSBY'' ELSE ''PMJJBY'' END,
                           ''claimDate'' value ca.claim_date,
                           ''branch_lho_id'' value ca.branch_lho_id,
                           ''branchRoId'' value ca.branch_ro_id,
                           ''branchZoId'' value ca.branch_zo_id,
                           ''city_id'' value ca.city_id ';
    tablequery := 'FROM jns_insurance.claim_master ca ';
    whereclause := ' WHERE  1 = 1 ';
    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.schme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.isActive') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.is_active = ' || JSON_VALUE(filterjson, '$.isActive'));
    END IF;

    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.claimBranchId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE(filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.claimStageId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.claim_status = ' || JSON_VALUE(filterjson, '$.claimStageId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.tabId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.tabId') = 1 THEN
            whereclause := whereclause || ' AND ca.claim_status IN (6, 8) ';
        ELSIF JSON_VALUE(filterjson, '$.tabId') = 2 THEN
            whereclause := whereclause || ' AND ca.claim_status = 6 ';
        ELSIF JSON_VALUE(filterjson, '$.tabId') = 3 THEN
            whereclause := whereclause || ' AND ca.claim_status = 8 ';
        END IF;
    END IF;

    IF
        JSON_VALUE(filterjson, '$.from') IS NOT NULL
        AND JSON_VALUE(filterjson, '$.to') IS NOT NULL
    THEN
        limitquery := ' OFFSET '
                      || JSON_VALUE(filterjson, '$.from')
                      || ' ROWS FETCH NEXT '
                      || JSON_VALUE(filterjson, '$.to')
                      || ' ROWS ONLY';
    ELSE
        limitquery := '';
    END IF;

    EXECUTE IMMEDIATE ' SELECT COUNT(ca.id)'
                      || tablequery
                      || whereclause
    INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
                    || totalcount
                    || ', '
                    || selectquery
                    || ')) '
                    || tablequery
                    || limitquery
                    || whereclause;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
END fetch_claim_list;