create or replace NONEDITIONABLE PROCEDURE              get_state_wise_enroll_count (
    filterjson  IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB
) AS
    whereclause  CLOB;
    mainquery    CLOB;

    roleid        NUMBER;
    typeid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;

BEGIN

        whereclause := 'WHERE amod.branch_state_id IS NOT NULL';

     IF (userid) IS NOT NULL
          THEN SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid ;
            IF(typeid) IS NOT NULL THEN
            IF(typeid = 2) THEN
             whereclause:= concat(whereclause, ' AND am.org_Id = ' || orgid);
                IF( roleid IS NOT NULL AND roleid != 5) THEN
                 IF(roleid = 9) THEN
               whereclause:= concat(whereclause, ' AND am.branch_id = ' || orgid);
             ELSIF(roleid = 13) THEN
               whereclause:= concat(whereclause, ' AND amod.branch_ro_id = ' || orgid);
             ELSIF(roleid = 14) THEN
               whereclause:= concat(whereclause, ' AND amod.BRANCH_ZO_ID = ' || orgid);
             ELSIF(roleid = 15) THEN
               whereclause:= concat(whereclause, ' AND amod.BRANCH_LHO_ID = ' || orgid);
             ELSE
               whereclause := concat(whereclause, ' and 0 ');
             END IF;
             ELSE
               whereclause := concat(whereclause, ' and 0 ');
             END IF;
          ELSE
           whereclause := concat(whereclause, ' and 0 ');
          END IF;
         ELSE
           whereclause := concat(whereclause, ' and 0 ');
         END IF;
        ELSE
         whereclause := concat(whereclause, ' and 0 ');
       END IF;


    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''stateId'' value st.id,
    ''stateName'' value state_name,
    ''enrollStateId'' value enst.stateid ,
    ''totalCount'' value enst.totalapplication,
    ''totalAmount'' value enst.totalamount
    ))
    FROM jns_insurance.state st
       LEFT JOIN (SELECT amod.branch_state_id AS stateid, COUNT(am.id) AS totalapplication, SUM(am.amount) AS totalamount
       FROM jns_insurance.application_master am
       INNER JOIN JNS_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
       ' || whereclause || ' GROUP BY amod.branch_state_id
        ORDER BY COUNT(am.id) DESC) enst ON enst.stateid = st.id
       ';

    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);
END get_state_wise_enroll_count;