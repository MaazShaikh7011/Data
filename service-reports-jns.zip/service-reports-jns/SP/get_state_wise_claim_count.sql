CREATE OR REPLACE NONEDITIONABLE PROCEDURE get_state_wise_claim_count (
    filterjson  IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB
) AS
    whereclause  CLOB;
    mainquery    CLOB;
    roleid       NUMBER;
    typeid       NUMBER;
    orgid        NUMBER;
    branchid     NUMBER;
BEGIN
    whereclause := ' WHERE cd.branch_state_id IS NOT NULL ';
    IF ( userid ) IS NOT NULL THEN
        SELECT
            u.user_type_id,
            u.branch_id,
            u.user_org_id,
            u.user_role_id
        INTO
            typeid,
            branchid,
            orgid,
            roleid
        FROM
            jns_users.users u
        WHERE
                u.is_active = 1
            AND u.user_id = userid;
    --   dbms_output.put_line(typeid || branchid || orgid || roleid );
                IF typeid IS NOT NULL THEN
            IF ( typeid = 2 ) THEN
                whereclause := concat(whereclause, ' AND ca.org_id = ' || orgid);
                IF
                    roleid IS NOT NULL
                    AND roleid != 5
                THEN
                    IF roleid = 9 THEN -- BO
                         whereclause := concat(whereclause, ' AND ca.claim_branch_id = ' || branchid);
                    ELSIF roleid = 13 THEN -- RO
                         whereclause := concat(whereclause, ' AND cd.branch_ro_id = ' || branchid);
                    ELSIF roleid = 14 THEN -- ZO
                         whereclause := concat(whereclause, ' AND cd.branch_zo_id = ' || branchid);
                    ELSIF roleid = 15 THEN -- LHO
                         whereclause := concat(whereclause, ' AND cd.branch_lho_id = ' ||
                        branchid);
                    ELSE
                        whereclause := '';
                    END IF;

                END IF;

            ELSIF typeid = 6 THEN
                whereclause := concat(whereclause, ' AND ca.insurer_org_id = ' || typeid);
            ELSE
                whereclause := concat(whereclause, ' and 0 ');
            END IF;

        ELSE
            whereclause := concat(whereclause, ' and 0 ');
        END IF;

    ELSE
        whereclause := concat(whereclause, ' and 0 ');
    END IF;

    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''stateId'' value st.id,
    ''stateName'' value state_name,
    ''enrollStateId'' value enst.stateid ,
    ''totalCount'' value enst.totalapplication,
    ''totalAmount'' value enst.totalamount
    ))
    FROM jns_insurance.state st
       LEFT JOIN (SELECT cd.branch_state_id AS stateid, COUNT(ca.id) AS totalapplication, SUM(ca.claim_amount) AS totalamount
        FROM jns_insurance.claim_master ca
        INNER JOIN JNS_INSURANCE.claim_detail cd ON cd.claim_id = ca.id

       '
                 || whereclause
                 || ' GROUP BY cd.branch_state_id
        ORDER BY COUNT(ca.id) DESC) enst ON enst.stateid = st.id
       ';
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);
END get_state_wise_claim_count;