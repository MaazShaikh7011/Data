CREATE OR REPLACE NONEDITIONABLE PROCEDURE fetch_enrollment_list (
    filterjson  IN   VARCHAR2,
    userid      IN   NUMBER,
    result      OUT  clob

) AS
    totalcount    LONG;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    limitquery    CLOB;
    preparequery  CLOB;
BEGIN
    selectquery := ' ''id'' value am.id,
                ''applicationId'' value am.id,
                ''urn'' value am.urn,
                ''customerAccountNumber'' value am.account_number,
                ''application_status'' value am.application_status,
                ''branch_id'' value am.branch_id,
                ''createdDate'' value am.created_date,
                ''enrollDate'' value am.enrollment_date,
                ''message'' value am.message,
                ''modifiedDate'' value am.modified_date,
                ''orgId'' value am.org_id,
                ''schemeName'' value am.scheme_id,
                ''stageId'' value am.stage_id,
                ''name'' value ai.name ';
    tablequery := ' FROM jns_insurance.application_master am
                            LEFT JOIN jns_insurance.applicant_info ai ON ai.application_id = am.id AND ai.is_active = 1 ';
    whereclause := ' WHERE am.is_active = 1';
--                    AND am.scheme_id IN(6,7)
--                    AND am.branch_id = 1
--                    AND am.branch_ro_id = 1
--                    AND am.branch_zo_id = 1
--                    and am.branch_lho_id = 1
--                    AND am.org_id = 13
--                    AND insurer_org_id = 188 ';
    dbms_output.put_line(filterjson);
    IF JSON_VALUE(filterjson, '$.tabId') IS NOT NULL THEN
        if JSON_VALUE(filterjson, '$.tabId') = 1 THEN
            whereclause := whereclause || ' AND am.stage_id IN (6, 8) ';
        elsIF JSON_VALUE(filterjson, '$.tabId') = 2 THEN
            whereclause := whereclause || ' AND am.stage_id = 6 ';
        elsif JSON_VALUE(filterjson, '$.tabId') = 3 THEN
            whereclause := whereclause || ' AND am.stage_id = 8 ';
        end if;
    end  if;

    IF
        JSON_VALUE(filterjson, '$.paginationFROM') IS NOT NULL
        AND JSON_VALUE(filterjson, '$.paginationTO') IS NOT NULL
    THEN
        limitquery := ' OFFSET '
                      || JSON_VALUE(filterjson, '$.paginationFROM')
                      || ' ROWS FETCH NEXT '
                      || JSON_VALUE(filterjson, '$.paginationTO')
                      || ' ROWS ONLY';
    ELSE
        limitquery := '';
    END IF;

    EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || tablequery || whereclause
                INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalcount'' value '
                    || totalcount
                    || ', '
                    || selectquery
                    || 'FORMAT JSON RETURNING CLOB)FORMAT JSON RETURNING CLOB) '
                    || tablequery
                    || whereclause
                    || limitquery;

                                        dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
    dbms_output.put_line(result);
END fetch_enrollment_list;