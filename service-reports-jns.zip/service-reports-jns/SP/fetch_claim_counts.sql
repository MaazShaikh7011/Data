CREATE OR REPLACE NONEDITIONABLE PROCEDURE fetch_claim_counts (
    filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
    preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
BEGIN
     -- IF JSON_VALUE(filterjson, '$.claim_status') IS NOT NULL
    -- THEN

              selectquery := ' SELECT JSON_OBJECT(

          ''inProgressCount'' value SUM(CASE WHEN claim_status = 5  THEN 1 ELSE 0 END),
          ''sendToInsurerCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''receivedFromBankCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''sendBackByInsurerCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''sendBackToBnakCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''rejectedCount'' value SUM(CASE WHEN claim_status = 8  THEN 1 ELSE 0 END),
          ''onHoldCount'' value SUM(CASE WHEN claim_status = 9 THEN 1 ELSE 0 END),
          ''acceptedCount'' value SUM(CASE WHEN claim_status = 10  THEN 1 ELSE 0 END),
          ''inProgressCount'' value SUM(CASE WHEN claim_status = 11 THEN 1 ELSE 0 END)
          ) ';
    --  END IF;

            tablequery :=
    ' FROM jns_insurance.claim_master ca ';
    whereclause := ' WHERE ca.is_active = 1 ';
    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.schme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.claimBranchId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE(filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.claimStageId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.claim_stage_id = ' || JSON_VALUE(filterjson, '$.claimStageId'));
    END IF;

    preparequery := selectquery
                    || tablequery
                    || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
END fetch_claim_counts;