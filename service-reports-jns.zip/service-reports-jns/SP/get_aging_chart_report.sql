CREATE OR REPLACE PROCEDURE get_aging_chart_report (
    filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
    preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
BEGIN
    selectquery := 'SELECT json_object(''grp1'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(claim_date AS date)) BETWEEN 0 and 14) then 1 else 0 end),
            ''grp2'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(cm.claim_date AS date)) BETWEEN 15 and 30) then 1 else 0 end),
            ''grp3'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(cm.claim_date AS date)) BETWEEN 31 and 60) then 1 else 0 end),
            ''grp4'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(cm.claim_date AS date)) BETWEEN 61 and 90) then 1 else 0 end),
            ''grp5'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(cm.claim_date AS date)) BETWEEN 91 and 180) then 1 else 0 end) ,
            ''grp6'' value sum(case when (CEIL(CAST(cm.created_date AS DATE ) - CAST(cm.claim_date AS date)) > 180) then 1 else 0 end)) ';
    tablequery := ' FROM JNS_INSURANCE.claim_master cm';
    whereclause := ' WHERE cm.is_active = 1 ';
    preparequery := selectquery
                    || tablequery
                    || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
    dbms_output.put_line(result);
END get_aging_chart_report;