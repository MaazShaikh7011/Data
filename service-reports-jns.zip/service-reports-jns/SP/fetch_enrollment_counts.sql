CREATE OR REPLACE NONEDITIONABLE PROCEDURE fetch_enrollment_counts (
    filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
    preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    limitquery clob;
BEGIN
--    selectQuery := ' SELECT SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END) AS approvedCount,
--                        SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END) AS rejectedCount';

            selectquery := ' SELECT JSON_OBJECT(''acceptedCount'' value SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END),
                                        ''rejectedCount'' value SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END),
                                        ''totalCount'' value SUM(CASE WHEN stage_id IS NOT NULL THEN 1 ELSE 0 END)) ';
    tablequery := ' FROM jns_insurance.application_master am
                            LEFT JOIN jns_insurance.applicant_info ai ON ai.application_id = am.id AND ai.is_active = 1 ';
    whereclause := ' WHERE am.is_active = 1 AND am.stage_id IN(6,8) ';

    IF
        JSON_VALUE(filterjson, '$.paginationFROM') IS NOT NULL
        AND JSON_VALUE(filterjson, '$.paginationTO') IS NOT NULL
    THEN
        limitquery := ' OFFSET '
                      || JSON_VALUE(filterjson, '$.paginationFROM')
                      || ' ROWS FETCH NEXT '
                      || JSON_VALUE(filterjson, '$.paginationTO')
                      || ' ROWS ONLY';
    ELSE
        limitquery := '';
    END IF;

    preparequery := selectquery
                    || tablequery
                    || whereclause || limitquery;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
END fetch_enrollment_counts;