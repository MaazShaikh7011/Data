CREATE OR REPLACE PROCEDURE JNS_REPORTS.fetch_claim_download_v5 (filterjson IN  VARCHAR2,
                                              userid     IN  NUMBER,
                                              result     OUT CLOB)
  AS

    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    selectquery := ' ''id'' value cl.id,
                     ''applicationId''  value cl.applicationId,
                    ''source'' value cl.source, 
                     ''accountHolderName'' value cl.accountHolderName,
                     ''customerAccountNumber'' value cl.customerAccountNumber,
                     ''urn'' value cl.urn,
                     ''mobileNumber'' value cl.mobileNumber,
                     ''schemeName'' value cl.schemeName,
                     ''claimDate'' value cl.claimDate,
                     ''branch_lho_id'' value cl.branchLhoId,
                     ''branchRoId'' value cl.branchRoId,
                     ''branchZoId'' value cl.branchZoId,
                     ''cif'' value cl.cif,
                     ''dob'' value cl.dob,
                     ''schemeId'' value cl.schemeId,
                     ''insurerName'' value cl.insurerName,
                     ''gender'' value cl.gender,
                     ''organisationCode'' value cl.organisationCode,
                     ''organisationName'' value cl.organisationName,
                     ''branchName'' value cl.branchName,
                     ''roName'' value cl.roName,
                     ''roCode'' value cl.roCode,
                     ''zoName'' value cl.zoName,
                     ''zoCode'' value cl.zoCode,
                     ''pincode'' value cl.pincode,
                     ''city'' value cl.city,
                     ''district'' value cl.district,
                     ''state'' value cl.state,
                     ''dateOfBirth'' value cl.dateOfBirth,
                     ''nomineeName'' value cl.nomineeName,
                     ''relationNominee'' value cl.relationNominee,
                     ''guardianName'' value cl.guardianName,
                     ''guardianRelation'' value cl.guardianRelation,
                     ''claimantName'' value cl.claimantName,
                     ''relationClaimant'' value cl.relationClaimant,
                     ''dateOfAutoDebit'' value cl.dateOfAutoDebit,
                     ''dateOfAutoCredit'' value cl.dateOfAutoCredit,
                     ''transectionUtr'' value cl.utr,
                     ''transactionUtr'' value cl.transactionUtr,
                     ''transactionAmount'' value cl.transactionAmount,
                     ''masterPolicyNo'' value cl.masterPolicyNo,
                     ''enrollDate'' value cl.enrollDate,
                     ''caValue'' value cl.caValue,
                     ''caaValue'' value cl.caaValue,
                     ''naValue'' value cl.naValue,
                     ''tdValue'' value cl.tdValue,
                     ''stageName'' value cl.stageName,
                     ''reasonStatus'' value cl.reasonStatus,
                     ''amountTransaction'' value cl.amountTransaction,
                     ''dateTransaction'' value cl.dateTransaction,
                     ''modifiedDate'' value cl.modifiedDate,
                     ''geo'' value cl.geo,
                     ''channelId'' value cl.channelId,
                     ''kycIdName'' value cl.kycIdName,
                     ''pan'' value cl.pan,
                     ''aadhar'' value cl.aadhar,
                     ''fatherHusbandName'' value cl.fatherHusbandName,
                     ''userId1'' value cl.userId1,
                     ''userId2'' value cl.userId2,
                        ''claimStatus'' value cl.claimStatus )RETURNING CLOB)FROM (  SELECT
                        ca.id as id, ca.application_id as applicationId, 
                      	case when am.source = 1 then ''Other Channel'' when am.source=2 then ''assitaed''  when am.source=3 then ''Legacy Data''  when am.source=4 then ''diy''end as source,
                        jns_users."decvalue"(cp.ac_holder_name) as accountHolderName, jns_users."decvalue"(cp.ap_account_number) as customerAccountNumber,
                        ca.urn as urn, jns_users."decvalue"(cd.ap_mobile_number) as mobileNumber, sm.short_name as schemeName,ca.claim_date as claimDate,
                        ca.branch_lho_id as branchLhoId, ca.branch_ro_id as branchRoId, ca.branch_zo_id as branchZoId,cp.ap_cif as cif,
                        jns_users."decvalue"(ap_dob) as dob,ca.scheme_id as schemeId,jns_users."decvalue"(cp.ac_holder_name) as insurerName,
                        GEN.value as gender,uomb.ORGANISATION_NAME as organisationName,uomb.ORGANISATION_CODE as organisationCode,
                        bm.name as branchName,bmro.name as roName,bmro.code as roCode,bmzo.name as zoName,bmzo.code as zoCode,
                        cdm.pincode as pincode,cdm.city_name as city, cdm.district as district, cdm.state_name as state,
                        jns_users."decvalue"(CLM_DOB) as dateOfBirth, jns_users."decvalue"(nmpd.name) as nomineeName, REL1.value as relationNominee,  
                        jns_users."decvalue"(nmpd.GD_NAME) as guardianName,REL2.value as guardianRelation,jns_users."decvalue"(cp.clm_name) as claimantName,REL.value as relationClaimant,
                        jns_users."decvalue"(td.trans_time_stamp) as dateOfAutoDebit, 
                        jns_users."decvalue"(ca.transaction_time_stamp) as dateOfAutoCredit,ca.transaction_utr as utr,
                        jns_users."decvalue"(td.TRANS_UTR) as transactionUtr,ca.transaction_amount as transactionAmount, 
                        jns_users."decvalue"(td.master_policy_no) as masterPolicyNo,
                        ca.FIRST_ENROLLMENT_DATE as enrollDate ,NL.value as naValue,
                        CASE WHEN ca.scheme_id = 1  THEN CDD.value ELSE '' '' END as caValue,
                        CASE WHEN ca.scheme_id = 2  THEN CDD2.value ELSE '' '' END as caaValue,
                        TDD.value as tdValue,
                        case when ca.status = 5 then ''In process'' when ca.status = 6 then ''Sent to Insurer'' when ca.status = 10 then ''Approved'' when ca.status = 8 then ''Rejected'' when ca.status = 7 then ''Queried''  else '''' end as stageName,
                        am.MESSAGE as reasonStatus,
                        cd.AP_TRANSACTION_AMOUNT as amountTransaction, jns_users."decvalue"(cd.AP_TRANSACTION_TIME_STAMP) as dateTransaction,
                        ca.modified_date as modifiedDate,
                        am.RURAL_URBAN as geo, am.channel_id as channelId,
                        jns_users."decvalue"(cp.AP_KYC_ID_1) as kycIdName,jns_users."decvalue"(cp.AP_PAN) as pan,jns_users."decvalue"(cp.AP_AADHAAR) as aadhar,
                        jns_users."decvalue"(cd.AP_FATHER_HUSBAND_NAME) as fatherHusbandName,
                        jns_users."decvalue"(ai.user_id_1) as userId1,
                        jns_users."decvalue"(ai.user_id_2) as userId2,
                        ca.status as claimStatus ';
  
     IF ((JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL) AND (JSON_VALUE (FILTERJSON, '$.schemeId') = 1))
    THEN
      tablequery := ' LEFT JOIN JNS_MASTER.PMSBY am  ON am.id=ca.APPLICATION_ID';
      ELSE
      tablequery := ' LEFT JOIN JNS_MASTER.PMJJBY am  ON am.id=ca.APPLICATION_ID';
    END IF;
    
    tablequery := 'FROM JNS_INSURANCE.clm_master ca 
                   INNER JOIN JNS_INSURANCE.clm_details cd ON cd.id = ca.id
                    INNER JOIN JNS_INSURANCE.CLM_PI_DETAILS cp ON cp.id = ca.id 
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=ca.scheme_id AND sm.is_active=1
                    LEFT JOIN JNS_INSURANCE.CLM_ADDRESS_MASTER cdm ON cdm.id=cd.ap_address_id
                    LEFT JOIN JNS_INSURANCE.CLM_NOMINEE_DETAILS nm ON nm.claim_id=ca.id
                     LEFT JOIN JNS_INSURANCE.CLM_NOMINEE_PI_DETAILS nmpd ON nmpd.id=nm.id
                    LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=cp.ap_gender_id AND GEN.dropdown_id=8 AND GEN.is_active=1
                    LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=ca.org_id AND uomb.is_active=1
                    LEFT JOIN jns_users.branch_master bm ON bm.id=ca.branch_id AND bm.is_active=1
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=ca.branch_ro_id AND bmro.is_active=1
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=ca.branch_zo_id AND bmzo.is_active=1
                    INNER JOIN JNS_MASTER.transaction_details td on td.application_id = ca.APPLICATION_ID 
                    INNER JOIN JNS_MASTER.APPLICANT_INFO ai ON ai.id = ca.APPLICATION_ID
                    LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=cd.clm_relation_id AND REL.dropdown_id=1 AND REL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL1 ON REL1.obj_id=nm.relation_id AND REL1.dropdown_id=1 AND REL1.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL2 ON REL2.obj_id=nm.GD_RELATION_ID AND REL2.dropdown_id=1 AND REL2.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values NL ON NL.obj_id=cd.nature_of_loss_id AND NL.dropdown_id=3 AND NL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values CDD ON CDD.obj_id=cd.cause_of_death_disability_id AND CDD.dropdown_id=6 AND CDD.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values CDD2 ON CDD2.obj_id=cd.cause_of_death_disability_id AND CDD2.dropdown_id=4 AND CDD2.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values TDD ON TDD.obj_id=cd.type_of_disability_id AND TDD.dropdown_id=5 AND TDD.is_active=1
                   ' || tablequery ;

    whereclause := ' WHERE  1 = 1 AND ca.is_active = 1 ';
   


    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND ca.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 0 ');
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || orgid);
        --            ELSE
        --            whereclause := concat(whereclause, ' and 0 ');
        END IF;

      --        ELSE
      --        whereclause := concat(whereclause, ' and 0 ');
      END IF;

    --    ELSE
    --        whereclause := concat(whereclause, ' and 0 ');
    END IF;

--    dbms_output.put_line(whereclause);

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND ca.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.STATUS = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
    THEN
--     IF (JSON_VALUE (filterjson, '$.tabId') = 1)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 6)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 6 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 2
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 3
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 10 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 4
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSIF (JSON_VALUE (filterjson, '$.tabId') = 5)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 8)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 7 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 9
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 7
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSE
--        whereclause := whereclause || ' AND ca.claim_status = 0 ';
--      END IF;
--      ELSE
        whereclause := whereclause || ' AND ca.STATUS In (5,6,10,7,8)';
    END IF;

--   IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
--   THEN
--    IF
--          JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
--      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
--    THEN
--      limitquery := ' OFFSET '
--      || JSON_VALUE (filterjson, '$.paginationFROM')
--      || ' ROWS FETCH NEXT '
--      || JSON_VALUE (filterjson, '$.paginationTO')
--      || ' ROWS ONLY';
--    ELSE
--      limitquery := '';
--    END IF;
--   END IF;

    whereclause := whereclause || ' order by ca.modified_date desc ';
    dbms_output.put_line(whereclause);

    EXECUTE IMMEDIATE ' SELECT COUNT(ca.id)'
    || tablequery
    || whereclause
      INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery
    || ')cl';

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
--      dbms_output.put_line(result);
  END fetch_claim_download_v5;