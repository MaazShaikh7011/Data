create or replace PROCEDURE                         sp_get_common_list_v5(listKey     IN  VARCHAR,
                                                whereClause IN  NUMBER,
                                                result      OUT CLOB)
  AS
    preparequery CLOB;
    querylst     CLOB;
  BEGIN
    CASE
      WHEN listKey = 'getCommmonDropdown' THEN querylst := 'SELECT json_arrayagg(json_object(''id'' value sta.id, ''value'' value sta.val)RETURNING CLOB)
                        FROM (SELECT amod.obj_id AS id,amod.value AS val from jns_oneform.dropdowns_values amod where amod.dropdown_id=' || whereClause ||' AND amod.is_active = 1) sta  ';
      WHEN listKey = 'getChannelId' THEN querylst := 'SELECT json_arrayagg(json_object(''channelId'' value sta.channelId)RETURNING CLOB)
                        FROM (SELECT distinct(amod.channel_id) AS channelId from JNS_INSURANCE.application_master_other_details amod where amod.channel_id is not null ) sta  ';
      WHEN listKey = 'stateList' THEN querylst := 'SELECT state_code AS id, state_name_english AS value FROM jns_oneform.lgd_state WHERE is_active = 1 ';
      WHEN listKey = 'oneFormStateList' THEN querylst := ' SELECT json_arrayagg(json_object(''id'' value sta.id,''value'' value sta.value)RETURNING CLOB)
                        FROM (SELECT st.id AS id, st.state_name AS value from jns_oneform.state st where st.is_active = 1 AND st.country_id=101 ) sta ';
      WHEN listKey = 'districtList' THEN querylst := 'SELECT district_code AS id, district_name_english AS value FROM one_form.lgd_district WHERE state_code =
                            (SELECT state_code FROM one_form.lgd_state WHERE state_name_english LIKE ' || whereClause || ' ROWS FETCH NEXT 1 ROWS ONLY) AND is_active = 1 ';
      WHEN listKey = 'lgdOneFormStateList' THEN querylst := ' SELECT json_arrayagg(json_object(''id'' value sta.id,''value'' value sta.value)RETURNING CLOB)
                        FROM (SELECT st.id AS id, st.name AS value from jns_oneform.lgd_state st where st.is_active = 1 ) sta ';
      WHEN listKey = 'cityList' THEN querylst := 'SELECT district_code AS id, district_name_english AS value FROM one_form.lgd_district WHERE state_code = ' || whereClause || ' AND is_active = 1 ';
      --        WHEN 'documentList' THEN
      --            querylst := 'SELECT pdm.id AS docMappingId, tm.type AS docType, pdm.is_multiple AS isMultiple, pdm.is_mandatory AS isMandatory,pdm.title_name AS titleName,
      --                        psd.doc_name AS otherDocName, IF(psd.id, pdm.id, NULL) AS selectedDocMappingId, dm.name AS documentName, pdm.group_id AS groupId, psd.id AS id,
      --                        dm.id as docId, psd.original_file_name AS uplodedFileName
      --                        FROM document_management.type_master tm
      --                        INNER JOIN document_management.product_document_mapping pdm ON pdm.type_id = tm.id AND pdm.is_active = 1
      --                        INNER JOIN document_management.document_master dm ON dm.id = pdm.document_id AND dm.is_active = 1
      --                        LEFT JOIN document_management.product_storage_details psd ON psd.application_id = JSON_VALUE(whereClause, '$.applicationId') AND psd.claim_id = JSON_VALUE(whereClause, '$.claimId') AND psd.product_document_mapping_id = pdm.id AND psd.is_active = 1
      --                        WHERE tm.is_active= 1 AND tm.scheme_id = JSON_VALUE(whereClause, '$.schemeId') AND tm.type_id = JSON_VALUE(whereClause, '$.typeId') ORDER BY group_id ASC; ';
--      WHEN listKey = 'getUplodedDocumentList' THEN
--      querylst := 'SELECT psd.doc_name AS docName, psd.product_document_mapping_id AS productDocumentMappingId, psd.application_id AS applicationId,psd.claim_id AS claimId, CAST(psd.original_file_name AS CHAR) AS originalFileName
--                        FROM document_management.product_storage_details psd WHERE psd.application_id = ' || JSON_VALUE (whereClause, '$.applicationId') || ' AND psd.claim_id = ' || JSON_VALUE (whereClause, '$.claimId') || ' AND is_active = 1 ';
      WHEN listKey = 'getBankName' THEN querylst := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' value st.id,
                    ''value'' value st.value,
                    ''totalCount'' value st.totalCount,
                    ''totalAmount'' value st.totalAmount
                    ))
                    FROM (SELECT distinct(imd.org_id) AS id, uom.display_org_name AS value, COUNT(am.id) totalCount, sum(am.premium_amount) as totalAmount
                        FROM JNS_INSURANCE.application_master am
                        INNER JOIN  JNS_INSURANCE.insurer_mst_details imd ON imd.org_id=am.org_id
                        INNER JOIN jns_users.user_organisation_master uom ON uom.user_org_id=imd.org_id
                        AND imd.insurer_org_id IN(' || whereClause || ') group by (imd.org_id), imd.org_id, uom.display_org_name) st ';
      ELSE querylst := 'SELECT "Key Not Found" as result ';
    END CASE;

    dbms_output.put_line(querylst);
    EXECUTE IMMEDIATE querylst
      INTO result;
  END sp_get_common_list_v5;