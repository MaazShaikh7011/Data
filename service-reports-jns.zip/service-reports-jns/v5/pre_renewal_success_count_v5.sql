CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_success_count_v5( filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB) AS

   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    amodwhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;
   scheme_id number;
   bankLogoUrl clob;
  displayInsName clob;
BEGIN

	whereclause := ' WHERE bufl.status = 3 AND bufl.is_active = 1 ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select id, short_name into scheme_id, scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE =''' || scheme_code ||''' ');
	    END IF;

	    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
	    	select ORGANISATION_CODE INTO org_code FROM jns_users.USER_ORGANISATION_MASTER uom where uom.USER_ORG_ID = JSON_VALUE(filterjson, '$.orgId');
	        whereclause := CONCAT(whereclause, ' AND bufl.org_code =''' || org_code ||''' ');
	    END IF;

	    IF JSON_VALUE(filterjson, '$.insId') IS NOT NULL THEN
--		    dbms_output.put_line(JSON_VALUE(filterjson, '$.insId'));
	    	select ORGANISATION_CODE INTO org_code FROM jns_users.USER_ORGANISATION_MASTER uom where uom.USER_ORG_ID = JSON_VALUE(filterjson, '$.insId');
--	    	dbms_output.put_line(org_code);
	        whereclause := CONCAT(whereclause, ' AND bufl.insurer_org_code = ''' || org_code ||''' ');
-- 	        dbms_output.put_line(org_code);
	    END IF;

	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer
	    		select ORGANISATION_CODE, IMAGE_PATH, DISPLAY_ORG_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;

	    		IF (typeid = 2) THEN -- Banker
		    		SELECT uom.IMAGE_PATH, uom.DISPLAY_ORG_NAME INTO bankLogoUrl, displayInsName FROM JNS_INSURANCE.INSURER_MST_DETAILS imd
						INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON UOM.USER_ORG_ID = imd.INSURER_ORG_ID
						WHERE imd.is_active= 1 AND imd.ORG_ID = orgid AND imd.SCHEME_ID = JSON_VALUE(filterjson, '$.schemeId') FETCH FIRST ROW ONLY;

	--	    		select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
		            whereclause := CONCAT(whereclause, ' AND bufl.org_code = ''' || org_code ||''' ');
		        ELSIF (typeid = 6) THEN -- Insurer
		            whereclause := CONCAT(whereclause, ' AND bufl.insurer_org_code = ''' || org_code ||''' ');
				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
--				select urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ROLE_MASTER urm WHERE urm.role_id = roleid;
				SELECT sm.SHORT_NAME, sm.IMG_PATH, sm.NAME into org_code, bankLogoUrl, displayInsName FROM JNS_USERS.SCHEME_MASTER sm WHERE sm.id = scheme_id;

				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					whereclause := CONCAT(whereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE = ''PMSBY''');
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE = ''PMJJBY''');
				END IF;
	        END IF;
	    ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1=2 ');
--		whereclause := CONCAT(whereclause, ' AND bufl.org_code = ' || JSON_VALUE (FILTERJSON, '$.orgId'));
	END IF;

	selectquery := ' SELECT JSON_OBJECT(''successCount'' VALUE SUM(CASE WHEN IS_REJECTED = 0 THEN SUCCESS_COUNT ELSE 0 END),
	                ''failedCount'' VALUE SUM(CASE WHEN IS_REJECTED = 0 THEN FAILED_COUNT ELSE 0 END),
					''deficientCount'' VALUE SUM(CASE WHEN IS_REJECTED = 0 THEN FAILED_COUNT ELSE 0 END),
	                ''totalCount'' VALUE SUM(CASE WHEN IS_REJECTED = 0 THEN SUCCESS_COUNT ELSE 0 END) + SUM(CASE WHEN IS_REJECTED = 0 THEN FAILED_COUNT ELSE 0 END)
	               )';

    tablequery := ' FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl';

    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);

END pre_renewal_success_count_v5;