CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_dashboard_list_view_v5(filterjson  IN  VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER,
    result      OUT  CLOB) AS

   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
   	bulkWhereclause   CLOB;
    insidewhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;
    con1 clob;

BEGIN

        tablequery := ' FROM JNS_INSURANCE.INSURER_MST_DETAILS imd ';
        whereclause := ' WHERE IMD.POLICY_START_DATE < CURRENT_DATE AND IMD.POLICY_END_DATE > CURRENT_DATE AND IMD.IS_ACTIVE = 1 ';
		insidewhereclause := ' 1=1 ';
		bulkWhereclause := ' WHERE bufl.IS_ACTIVE = 1 AND bufl.STATUS = 3 ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	    con1 := ' (CASE WHEN ('|| typeid ||' = 2 OR ('|| typeid ||' = 7 AND '|| roleid ||' = 22)) THEN imd.org_id
					WHEN ('|| typeid ||' = 6 OR ('|| typeid ||' = 7 AND ('|| roleid ||' = 23 OR '|| roleid ||' = 24))) THEN imd.insurer_org_id
					ELSE NULL END) ';

	     selectquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(  ''bankName'' value uom.display_org_name,
						''orgid'' value '|| con1 ||',
						''successCount'' VALUE successCount,
						''failedCount'' VALUE failedCount,
						''totalCount'' VALUE totalCount,
						''insId'' VALUE insUom.USER_ORG_ID,
						''insCode'' VALUE insUom.ORGANISATION_CODE,
						''insName'' VALUE insUom.display_org_name,
						''pendingUrnGenCount'' VALUE pendingUrnGenCount,
						''defficientUrnGenCount'' VALUE DECODE(defficientUrnGenCount, NULL, 0, defficientUrnGenCount),
						''successUrnGenCount'' VALUE DECODE(successUrnGenCount, NULL, 0, successUrnGenCount),
						''totalUrnGenCount'' VALUE DECODE(totalUrnGenCount, NULL, 0, totalUrnGenCount)
					)RETURNING CLOB) ';

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND imd.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
	        insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = ' || JSON_VALUE (filterjson, '$.schemeId'));
  		    bulkWhereclause := CONCAT(bulkWhereclause, ' AND BUFL.SCHEME_CODE = ''' || scheme_code || '''');
	    END IF;

	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer

	    		whereclause := CONCAT(whereclause, ' AND DECODE('|| typeid ||', 2, IMD.ORG_ID, IMD.INSURER_ORG_ID) = ' || orgid);
		    	SELECT ORGANISATION_CODE INTO org_code FROM jns_users.USER_ORGANISATION_MASTER WHERE user_org_id = orgid;
		    	bulkWhereclause := CONCAT(bulkWhereclause, ' AND DECODE('|| typeid ||', 2, bufl.ORG_CODE, bufl.INSURER_ORG_CODE) = ''' || org_code ||'''');
				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = DECODE('|| typeid ||', 2, imd.org_id, imd.insurer_org_id)
		                LEFT JOIN (
		                    SELECT TO_CHAR(DECODE('|| typeid ||', 2, prfc.BANK_CODE, prfc.INSURER_CODE)) as ORG_CODE,
							TO_CHAR(DECODE('|| typeid ||', 2, prfc.INSURER_CODE, prfc.BANK_CODE)) as INSURER_ORG_CODE,
							SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as successCount ,
							SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as failedCount,
							SUM(CASE WHEN (prfc.IS_REJECT = 0 AND prfc.URN_GENERATED IS NULL) THEN COUNTS_IN_FILE ELSE 0 END) as pendingUrnGenCount,
							(SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) + SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END)) as totalCount
							FROM JNS_MASTER_DATA.PRE_RENEWAL_FILE_COUNTS prfc WHERE '|| insidewhereclause ||' AND TO_CHAR(DECODE('|| typeid ||', 2, prfc.BANK_CODE, prfc.INSURER_CODE)) = ' || orgid ||'
							GROUP BY DECODE('|| typeid ||', 2, prfc.BANK_CODE, prfc.INSURER_CODE) , DECODE('|| typeid ||', 2, prfc.INSURER_CODE, prfc.BANK_CODE)
		                ) tmp ON tmp.ORG_CODE = DECODE('|| typeid ||', 2, imd.org_id, imd.insurer_org_id) AND tmp.INSURER_ORG_CODE = DECODE('|| typeid ||', 2, imd.insurer_org_id, imd.org_id)
						LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.USER_ORG_ID = tmp.INSURER_ORG_CODE
						LEFT JOIN (
							SELECT TO_CHAR(DECODE('|| typeid ||', 2, MAX(bankUom.USER_ORG_ID), MAX(insUom.USER_ORG_ID))) as ORG_CODE,
							TO_CHAR(DECODE('|| typeid ||', 2, MAX(insUom.USER_ORG_ID), MAX(bankUom.USER_ORG_ID))) as INSURER_ORG_CODE,
						    SUM(CASE WHEN bufl.FAILED_COUNT IS NOT NULL THEN bufl.FAILED_COUNT ELSE 0 END) AS defficientUrnGenCount,
						    SUM(CASE WHEN bufl.SUCCESS_COUNT IS NOT NULL THEN bufl.SUCCESS_COUNT ELSE 0 END) AS successUrnGenCount,
						    SUM(CASE WHEN bufl.TOTAL_COUNT IS NOT NULL THEN bufl.TOTAL_COUNT ELSE 0 END) AS totalUrnGenCount
							FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
							INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.short_name = BUFL.SCHEME_CODE
							LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER bankUom ON bankUom.ORGANISATION_CODE = TO_CHAR(DECODE('|| typeid ||', 2, bufl.ORG_CODE, bufl.INSURER_ORG_CODE))
							LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.ORGANISATION_CODE = TO_CHAR(DECODE('|| typeid ||', 2, bufl.INSURER_ORG_CODE, bufl.ORG_CODE))
							'|| bulkWhereclause ||'
							GROUP BY TO_CHAR(DECODE('|| typeid ||', 2, bufl.ORG_CODE , bufl.INSURER_ORG_CODE)),TO_CHAR(DECODE('|| typeid ||', 2, bufl.INSURER_ORG_CODE, bufl.ORG_CODE))
						) urnGen ON urnGen.ORG_CODE = tmp.ORG_CODE AND urnGen.INSURER_ORG_CODE = tmp.INSURER_ORG_CODE ');
			ELSIF (typeid = 7) THEN -- Council/Association
				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					insidewhereclause := CONCAT(insidewhereclause, ' AND 1=1 ');
					whereclause := CONCAT(whereclause, ' AND 1=1 ');
					bulkWhereclause := CONCAT(bulkWhereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = 1 ');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 1);
					bulkWhereclause := CONCAT(bulkWhereclause, ' AND BUFL.SCHEME_CODE = ''PMSBY''');
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = 2 ');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 2);
					bulkWhereclause := CONCAT(bulkWhereclause, ' AND BUFL.SCHEME_CODE = ''PMJJBY''');
				END IF;
				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id)
		                LEFT JOIN (
		                    SELECT TO_CHAR(DECODE('|| roleid ||', 22, prfc.BANK_CODE, prfc.INSURER_CODE)) as ORG_CODE,
							TO_CHAR(DECODE('|| roleid ||', 22, prfc.INSURER_CODE, prfc.BANK_CODE)) as INSURER_ORG_CODE,
							SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as successCount ,
							SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as failedCount,
							SUM(CASE WHEN (prfc.IS_REJECT = 0 AND prfc.URN_GENERATED IS NULL) THEN COUNTS_IN_FILE ELSE 0 END) as pendingUrnGenCount,
							(SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) + SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END)) as totalCount
							FROM JNS_MASTER_DATA.PRE_RENEWAL_FILE_COUNTS prfc WHERE '|| insidewhereclause ||'
							GROUP BY DECODE('|| roleid ||', 22, prfc.BANK_CODE, prfc.INSURER_CODE) , DECODE('|| roleid ||', 22, prfc.INSURER_CODE, prfc.BANK_CODE)
		                ) tmp ON tmp.ORG_CODE = DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id) AND tmp.INSURER_ORG_CODE = DECODE('|| roleid ||', 22, imd.insurer_org_id, imd.org_id)
						LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.USER_ORG_ID = tmp.INSURER_ORG_CODE
						LEFT JOIN (
							SELECT TO_CHAR(DECODE('|| roleid ||', 22, MAX(bankUom.USER_ORG_ID), MAX(insUom.USER_ORG_ID))) as ORG_CODE,
							TO_CHAR(DECODE('|| roleid ||', 22, MAX(insUom.USER_ORG_ID), MAX(bankUom.USER_ORG_ID))) as INSURER_ORG_CODE,
						    SUM(CASE WHEN bufl.FAILED_COUNT IS NOT NULL THEN bufl.FAILED_COUNT ELSE 0 END) AS defficientUrnGenCount,
						    SUM(CASE WHEN bufl.SUCCESS_COUNT IS NOT NULL THEN bufl.SUCCESS_COUNT ELSE 0 END) AS successUrnGenCount,
						    SUM(CASE WHEN bufl.TOTAL_COUNT IS NOT NULL THEN bufl.TOTAL_COUNT ELSE 0 END) AS totalUrnGenCount
							FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
							INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.short_name = BUFL.SCHEME_CODE
							LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER bankUom ON bankUom.ORGANISATION_CODE = TO_CHAR(DECODE('|| roleid ||', 22, bufl.ORG_CODE, bufl.INSURER_ORG_CODE))
							LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.ORGANISATION_CODE = TO_CHAR(DECODE('|| roleid ||', 22, bufl.INSURER_ORG_CODE, bufl.ORG_CODE))
							'|| bulkWhereclause ||'
							GROUP BY TO_CHAR(DECODE('|| roleid ||', 22, bufl.ORG_CODE , bufl.INSURER_ORG_CODE)),TO_CHAR(DECODE('|| roleid ||', 22, bufl.INSURER_ORG_CODE, bufl.ORG_CODE))
						) urnGen ON urnGen.ORG_CODE = tmp.ORG_CODE AND urnGen.INSURER_ORG_CODE = tmp.INSURER_ORG_CODE ');
	        END IF;
	   	ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
	     whereclause := CONCAT(whereclause, ' AND 1=2 ');
	END IF;


    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;

END pre_renewal_dashboard_list_view_v5;