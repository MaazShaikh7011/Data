CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_list_council_view_v5(filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB) AS

   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    insidewhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;

BEGIN

        tablequery := ' FROM JNS_INSURANCE.INSURER_MST_DETAILS imd ';
        whereclause := ' WHERE IMD.POLICY_START_DATE < CURRENT_DATE AND IMD.POLICY_END_DATE > CURRENT_DATE AND IMD.IS_ACTIVE = 1 ';
		insidewhereclause := ' WHERE bufl.status = 3 AND bufl.is_active=1 ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	    selectquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(  ''bankName'' value uom.display_org_name,
                        ''orgid'' value DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id),
						''successCount'' VALUE successCount,
						''failedCount'' VALUE failedCount,
						''totalCount'' VALUE totalCount,
						''insId'' VALUE insUom.USER_ORG_ID,
						''insCode'' VALUE tmp.INSURER_ORG_CODE,
						''insName'' VALUE insUom.display_org_name
					)RETURNING CLOB) ';

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND imd.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
	        insidewhereclause := CONCAT(insidewhereclause, ' AND BUFL.SCHEME_CODE = ''' || scheme_code ||'''');
	    END IF;

	    IF (typeid) IS NOT NULL THEN
			IF (typeid = 7) THEN -- Council/Association
				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					insidewhereclause := CONCAT(insidewhereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND BUFL.SCHEME_CODE = ''PMSBY''');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 1);
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND BUFL.SCHEME_CODE = ''PMJJBY''');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 2);
				END IF;
				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID  = DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id)
		                LEFT JOIN (
		                    SELECT DECODE('|| roleid ||', 22, BUFL.ORG_CODE, BUFL.INSURER_ORG_CODE) as ORG_CODE,
							DECODE('|| roleid ||', 22, BUFL.INSURER_ORG_CODE, BUFL.ORG_CODE) as INSURER_ORG_CODE,
							SUM(CASE WHEN bufl.IS_REJECTED = 0 THEN bufl.TOTAL_COUNT ELSE 0 END) as successCount ,
		                    SUM(CASE WHEN bufl.IS_REJECTED = 1 THEN bufl.FAILED_COUNT ELSE 0 END) as failedCount,
		                    (SUM(CASE WHEN bufl.IS_REJECTED = 0 THEN bufl.TOTAL_COUNT ELSE 0 END) + SUM(CASE WHEN bufl.IS_REJECTED = 1 THEN bufl.FAILED_COUNT ELSE 0 END)) as totalCount
				            FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl '|| insidewhereclause ||'
				            GROUP BY DECODE('|| roleid ||', 22, BUFL.ORG_CODE, BUFL.INSURER_ORG_CODE) , DECODE('|| roleid ||', 22, BUFL.INSURER_ORG_CODE, BUFL.ORG_CODE)
		                ) tmp ON tmp.ORG_CODE = uom.ORGANISATION_CODE
						LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.ORGANISATION_CODE = tmp.INSURER_ORG_CODE ');
	        END IF;
	   	ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
	     whereclause := CONCAT(whereclause, ' AND 1=2 ');
	END IF;


    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);
END pre_renewal_list_council_view_v5;