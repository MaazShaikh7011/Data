CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLL_COUNTS_REJ_TRANS_FAILED_V5" (
    filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    amodwhereclause CLOB;
    commonQuery clob;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
BEGIN
       --    selectQuery := ' SELECT SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END) AS approvedCount,
    --                        SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END) AS rejectedCount';

    selectquery := ' SELECT JSON_OBJECT(''rejectedCount'' value SUM(CASE WHEN stage_id = 8  and status = 12 THEN 1 ELSE 0 END),
                                        ''expiredCount'' value SUM(CASE WHEN stage_id = 7  and status = 3 THEN 1 ELSE 0 END),
                                        ''totalCount'' value SUM(CASE WHEN stage_id IN(8,7) THEN 1 ELSE 0 END)) ';

    whereclause := ' WHERE 1=1 ';

    commonQuery := ' AND am.is_active = 1 ';
    -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO THAT
    IF userid IS NOT NULL THEN
      SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
      IF (typeid) IS NOT NULL THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
--          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
--          amodwhereclause := ' am.org_Id = amod.org_Id AND ';
          IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
          THEN
            whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId') || commonQuery);
          END IF;
          IF (roleid IS NOT NULL AND roleid != 5) THEN
            IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13) THEN
                if JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
                    whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
                else
                    whereclause := CONCAT(whereclause, ' AND am.branch_ro_id = ' || branchid );
                end if;
            ELSIF (roleid = 14) THEN
                if JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
                    whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
                elsif JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
                    whereclause := CONCAT(whereclause, ' AND am.branch_ro_id IN (' || JSON_VALUE (filterjson, '$.roId')||') ');
                else
                    whereclause := CONCAT(whereclause, ' AND am.BRANCH_ZO_ID = ' || branchid );
                end if;

            ELSIF (roleid = 15) THEN
                whereclause := CONCAT(whereclause, ' AND am.BRANCH_LHO_ID = ' || branchid );
            ELSE
                whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
--          ELSE
--            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        ELSIF typeid = 6 THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
--          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
           IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
           THEN
              whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId') || commonQuery);
           END IF;
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

--    whereclause := CONCAT(whereclause, ' AND am.stage_id IN(8,15) ');



    IF roleid is not null and roleid != 13 and roleid != 14  and JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND am.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
  END IF;

  IF roleid is not null and roleid != 14  and JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND am.branch_ro_id IN (' || JSON_VALUE (filterjson, '$.roId')||') ');
  END IF;

  IF JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NULL and JSON_VALUE (filterjson, '$.zoId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND am.branch_zo_id IN (' || JSON_VALUE (filterjson, '$.zoId')||')  ');
  END IF;

  IF ((roleid = 5 and JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NULL and JSON_VALUE (filterjson, '$.zoId') IS NULL) or typeid = 6) and JSON_VALUE (filterjson, '$.stateId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_state_id IN (' || JSON_VALUE (filterjson, '$.stateId')||')  ');
   END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL THEN
      whereclause := whereclause|| ' AND am.source IN (' || JSON_VALUE (filterjson, '$.channelId')||') ' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

        -- DATE FILTER
    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL THEN
        IF (JSON_VALUE (FILTERJSON, '$.status') IS NOT NULL and JSON_VALUE (FILTERJSON, '$.status') !=1 and JSON_VALUE (FILTERJSON, '$.status') !=4)
        THEN
            whereclause := CONCAT(whereclause, ' AND TRUNC(am.STATUS_CHANGE_DATE) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
        ELSE
         whereclause := CONCAT(whereclause, ' AND TRUNC(am.completion_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')');
      END IF;
    END IF;

--    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

    tablequery := ' FROM JNS_MASTER.EXPIRED_ENROLLMENT am';



--    IF (roleid = 9 OR roleid = 13 OR roleid = 14 OR roleid = 15 OR JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
--      OR JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL) THEN
--      tablequery := CONCAT(tablequery, ' INNER JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id AND ((amod.source = 4 AND am.stage_id <> 8 OR amod.source <> 4 AND am.stage_id IN (8,15)))');
--    END IF;

--    IF JSON_VALUE (FILTERJSON, '$.searchData') IS NOT NULL THEN
--      tablequery := CONCAT(tablequery, ' LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id');
--    END IF;

    preparequery := selectquery || tablequery || whereclause;
   dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
END FETCH_ENROLL_COUNTS_REJ_TRANS_FAILED_V5;