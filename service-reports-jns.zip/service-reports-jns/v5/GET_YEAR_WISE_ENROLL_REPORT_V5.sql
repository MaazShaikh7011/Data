CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_YEAR_WISE_ENROLL_REPORT_V5" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                         fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                         todate     IN  VARCHAR2 DEFAULT NULL,
                                                         userid     IN  NUMBER   DEFAULT NULL,
                                                         result     OUT CLOB)
  AS
    selectquery CLOB;
    whereclause CLOB;
    mainquery   CLOB;
    tablequery  CLOB;
--    amodwhereclause CLOB;
    typeid      NUMBER;
    roleid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
    acceptedCount    clob;
    rejectedCount    clob;
    totalCount clob;
    rocolumn clob;
    zocolumn clob;
  BEGIN
--    selectquery := ' select JSON_OBJECT( ''totalCount'' value count(am.id),
--            ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
--            ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end)) ';

--    DBMS_OUTPUT.PUT_LINE(JSON_VALUE(filterjson, '$.schemeId'));
    
    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.schemeId') = 1 THEN
            acceptedCount :=  'p.PMSBY_A_TOTAL';
            rejectedCount :=  'p.PMSBY_R_TOTAL';
            totalCount :=  'p.PMSBY_A_R_TOTAL';
            rocolumn := 'p.pmsby_ro_id';
            zocolumn := 'p.pmsby_zo_id';
        ELSIF JSON_VALUE(filterjson, '$.schemeId') = 2 THEN
            acceptedCount :=  'p.PMJJBY_A_TOTAL';
            rejectedCount :=  'p.PMJJBY_R_TOTAL';
            totalCount :=  'p.PMJJBY_A_R_TOTAL';
            rocolumn := 'p.pmjjby_ro_id';
            zocolumn := 'p.pmjjby_zo_id';
        end if;
    ELSE
        acceptedCount :=  'p.a_total';
        rejectedCount :=  'p.r_total';
        totalCount :=  'p.total_count';
--        rocolumn := ' AND (p.pmsby_ro_id = ' || branchid || ' OR p.pmjjby_ro_id = ' || branchid || ') ';
--        zocolumn := ' AND (p.pmsby_zo_id = ' || branchid || ' OR p.pmjjby_zo_id = ' || branchid || ') ';
    END IF;
    
    selectquery := ' select JSON_OBJECT(''totalCount'' value sum('|| totalCount ||'),
                    ''acceptedCount'' value sum('|| acceptedCount ||'),
                    ''rejectedCount'' value sum('|| rejectedCount ||')) ';
--    DBMS_OUTPUT.PUT_LINE(selectquery);

    tablequery := ' FROM JNS_REPORTS.policy p ';
    
    whereclause := ' WHERE 1=1 ';

--    amodwhereclause := ' am.org_Id = amod.org_Id AND ';
--
    
--
   dbms_output.put_line(userid);
    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        dbms_output.put_line(typeid);
--        IF (roleid = 13 OR roleid = 14 OR roleid = 15) THEN
--            tablequery := CONCAT(tablequery, ' INNER JOIN JNS_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id ');
--        END IF;
        IF (typeid IS NOT NULL) THEN
--            IF (typeid != 4) THEN -- FOR MINISTRY DON'T NEED THIS CONDITION
                IF (typeid = 2) THEN
                    whereclause := CONCAT(whereclause, ' AND p.org_Id = ' || orgid);
--                    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
--                       whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
--                    END IF;
                    IF (roleid IS NOT NULL AND roleid != 5) THEN
                        IF (roleid = 9) THEN
                            whereclause := CONCAT(whereclause, ' AND p.branch_id = ' || branchid);
                        ELSIF (roleid = 13) THEN
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| rocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_ro_id = ' || branchid || ' OR p.pmjjby_ro_id = ' || branchid || ') ');
                            end if;
                        ELSIF (roleid = 14) THEN
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| zocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_zo_id = ' || branchid || ' OR p.pmjjby_zo_id = ' || branchid || ') ');
                            end if;
                        ELSE
                            whereclause := CONCAT(whereclause, ' AND 1=2 ');
                        END IF;
        --              ELSE
        --                whereclause := CONCAT(whereclause, ' ');
                      END IF;
                ELSIF typeid = 6 THEN
                    whereclause := CONCAT(whereclause, ' AND (p.PMSBY_INSURER_ORG = ' || orgId || ' OR p.PMJJBY_INSURER_ORG = '|| orgId ||') ');
--                    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
--                       whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
--                    END IF;
                ELSIF (typeid = 4 or typeid = 7) THEN
                    if JSON_VALUE(filterjson, '$.ministryReportType') is not null then
                        IF JSON_VALUE(filterjson, '$.ministryReportType') = 1 or JSON_VALUE(filterjson, '$.ministryReportType') = 2 then
                            IF JSON_VALUE(filterjson, '$.ministryOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND p.org_Id = ' || JSON_VALUE(filterjson, '$.ministryOrgId'));
                            END IF;
                        ELSIF JSON_VALUE(filterjson, '$.ministryReportType') = 3 then
                            IF JSON_VALUE(filterjson, '$.ministryInsurerOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND (p.PMSBY_INSURER_ORG = ' || JSON_VALUE(filterjson, '$.ministryInsurerOrgId') || ' OR p.PMJJBY_INSURER_ORG = '|| JSON_VALUE(filterjson, '$.ministryInsurerOrgId') ||') ');
                            END IF;
                        END IF;
--                    else 
--                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    end if;
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
--            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;
--
--    whereclause := CONCAT(whereclause, ' AND am.stage_id in(6,8) ');
--
    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND p.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

	IF (fromdate IS NOT NULL and todate IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' and p.enroll_date BETWEEN  TO_DATE('''|| fromdate ||''', ''YYYY-MM-DD'') and TO_DATE('''|| todate ||''', ''YYYY-MM-DD'')');
--        dbms_output.put_line(whereclause);
    END IF;
   
    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND p.enroll_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;
--    
--    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

--    dbms_output.put_line(whereclause);

    mainquery := selectquery || tablequery || whereclause;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery INTO result;
    dbms_output.put_line(result);

  END GET_YEAR_WISE_ENROLL_REPORT_V5;