CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_dashboard_counts_v5( filterjson  IN  VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER,
    result      OUT  CLOB) AS

    preparequery			CLOB;
    bulkPreparequery		CLOB;
    selectquery   			CLOB;
    bulkSelectquery   		CLOB;
    tablequery    			CLOB;
    bulkTablequery    		CLOB;
    whereclause   			CLOB;
    bulkWhereclause   		CLOB;
    typeid        			NUMBER;
    roleid        			NUMBER;
    orgid         			NUMBER;
    branchid     			NUMBER;
    org_code    			CLOB;
    scheme_code 			CLOB;
    scheme_id 				NUMBER;
    bankLogoUrl 			CLOB;
	displayInsName  		CLOB;
	successUrnGenCount	 	NUMBER;
	defficientUrnGenCount 	NUMBER;
	totalUrnGenCount		NUMBER;
BEGIN

	whereclause := ' WHERE 1=1 '; -- prfc.status = 3
	bulkWhereclause := ' WHERE bufl.IS_ACTIVE = 1 AND bufl.STATUS = 3 ';
	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select id, short_name into scheme_id, scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND prfc.SCHEME_CODE = ' || JSON_VALUE(filterjson, '$.schemeId'));
			bulkWhereclause := CONCAT(bulkWhereclause, ' AND bufl.SCHEME_CODE = ''' || scheme_code || '''');
	    END IF;

	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer
	    		select ORGANISATION_CODE, IMAGE_PATH, DISPLAY_ORG_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;

	    		IF (typeid = 2) THEN -- Banker
		    		SELECT uom.IMAGE_PATH, uom.DISPLAY_ORG_NAME INTO bankLogoUrl, displayInsName FROM JNS_INSURANCE.INSURER_MST_DETAILS imd
						INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON UOM.USER_ORG_ID = imd.INSURER_ORG_ID
						WHERE imd.is_active= 1 AND imd.ORG_ID = orgid AND imd.SCHEME_ID = JSON_VALUE(filterjson, '$.schemeId') FETCH FIRST ROW ONLY;

		    		select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
		            whereclause := CONCAT(whereclause, ' AND prfc.bank_code = ' || orgid);
		            bulkWhereclause := CONCAT(bulkWhereclause, ' AND bufl.ORG_CODE = ''' || org_code || '''');
		        ELSIF (typeid = 6) THEN -- Insurer
		            whereclause := CONCAT(whereclause, ' AND prfc.insurer_code = ' || orgid);
		           	bulkWhereclause := CONCAT(bulkWhereclause, ' AND bufl.INSURER_ORG_CODE = ''' || org_code || '''');
				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
--				select urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ROLE_MASTER urm WHERE urm.role_id = roleid;
				SELECT sm.SHORT_NAME, sm.IMG_PATH, sm.NAME into org_code, bankLogoUrl, displayInsName FROM JNS_USERS.SCHEME_MASTER sm WHERE sm.id = scheme_id;

				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					whereclause := CONCAT(whereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					whereclause := CONCAT(whereclause, ' AND prfc.SCHEME_CODE = 1 ');
					bulkWhereclause := CONCAT(bulkWhereclause, ' AND bufl.SCHEME_CODE = ''PMSBY''');
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					whereclause := CONCAT(whereclause, ' AND prfc.SCHEME_CODE = 2 ');
					bulkWhereclause := CONCAT(bulkWhereclause, ' AND bufl.SCHEME_CODE = ''PMJJBY''');
				END IF;
	        END IF;
	    ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	        bulkWhereclause := CONCAT(bulkWhereclause, ' AND 1=2');
	    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1=2 ');
		bulkWhereclause := CONCAT(bulkWhereclause, ' AND 1=2');
--		whereclause := CONCAT(whereclause, ' AND prfc.org_code = ' || JSON_VALUE (FILTERJSON, '$.orgId'));
	END IF;


	bulkSelectquery := ' SELECT SUM(CASE WHEN bufl.SUCCESS_COUNT IS NOT NULL THEN bufl.SUCCESS_COUNT ELSE 0 END) AS successUrnGenCount,
    							SUM(CASE WHEN bufl.FAILED_COUNT IS NOT NULL THEN bufl.FAILED_COUNT ELSE 0 END) AS defficientUrnGenCount,
								SUM(CASE WHEN bufl.TOTAL_COUNT IS NOT NULL THEN bufl.TOTAL_COUNT ELSE 0 END) AS totalUrnGenCount ';

	bulkTablequery := ' FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
								INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.SHORT_NAME = bufl.SCHEME_CODE AND sm.id = ' || JSON_VALUE(filterjson, '$.schemeId');

	bulkPreparequery := bulkSelectquery || bulkTablequery || bulkWhereclause;
    dbms_output.put_line(bulkPreparequery);
    EXECUTE IMMEDIATE bulkPreparequery INTO successUrnGenCount, defficientUrnGenCount, totalUrnGenCount;

	selectquery := ' SELECT JSON_OBJECT(''successCount'' VALUE SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END),
	                ''failedCount'' VALUE SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END),
					''pendingUrnGenCount'' VALUE SUM(CASE WHEN (IS_REJECT = 0 AND URN_GENERATED IS NULL) THEN COUNTS_IN_FILE ELSE 0 END),
	                ''totalCount'' VALUE (SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) + SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END)),
					''successUrnGenCount'' VALUE '|| successUrnGenCount ||',
					''defficientUrnGenCount'' VALUE '|| defficientUrnGenCount ||',
					''totalUrnGenCount'' VALUE '|| totalUrnGenCount ||',
					''bankLogoUrl'' VALUE '''|| bankLogoUrl ||''',
					''displayInsName'' VALUE '''|| displayInsName ||'''
	               )';

    tablequery := ' FROM JNS_MASTER_DATA.PRE_RENEWAL_FILE_COUNTS prfc';

    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);

END pre_renewal_dashboard_counts_v5;