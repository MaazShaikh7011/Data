CREATE OR REPLACE PROCEDURE JNS_REPORTS.push_data_to_policy_channel_v5
  AS
    name  CLOB;
    mainquery   CLOB;
    selectquery   CLOB;
    deletequery clob;
    yesterdate TIMESTAMP;
    currentdate TIMESTAMP;
  BEGIN

        SELECT TO_TIMESTAMP(concat(TO_DATE(current_date - 2), ' 11:59:59.000000 PM')) into yesterdate FROM dual;
        SELECT current_timestamp into currentdate FROM dual;

       deletequery := ' DELETE FROM JNS_REPORTS.POLICY_CHANNEL  where enroll_date > '''|| yesterdate || '''';
--       dbms_output.put_line('delete' || deletequery);
       EXECUTE IMMEDIATE deletequery;
       commit;


   mainquery := ' INSERT INTO JNS_REPORTS.POLICY_CHANNEL
					(ORG_ID, CHANNEL, SCHEME_ID, ENROLL_DATE, TOTAL_COUNT, BRANCH_RO_ID, BRANCH_ZO_ID, INSURER_ORG_ID) ' ;
--dbms_output.put_line(mainquery);

	selectquery := ' SELECT  tmp.orgId,
						(CASE WHEN (tmp.SOURCE_ID = 2) THEN ''Portal Journey''
							WHEN (tmp.SOURCE_ID = 4) THEN ''DIY Journey''
							WHEN (tmp.SOURCE_ID = 1) THEN dv.VALUE
							ELSE NULL END) AS channelName,
						 tmp.SCHEME_ID, tmp.enroll_date, tmp.totalCount, tmp.BRANCH_RO_ID, tmp.BRANCH_ZO_ID, tmp.INSURER_ORG_ID
						 FROM
							(
								SELECT am.ORG_ID AS orgId, AM."SOURCE" AS SOURCE_ID, am.CHANNEL_ID,
								1 AS SCHEME_ID,
								to_timestamp(CAST(am.status_change_date AS DATE)) AS enroll_date,
								COUNT(am.id)  AS totalCount,
								am.BRANCH_RO_ID,
								am.BRANCH_ZO_ID,
								am.INSURER_ORG_ID
								FROM JNS_MASTER.PMSBY am
								WHERE AM."SOURCE" != 3
								AND am.status_change_date > '''|| yesterdate ||'''
								GROUP BY am.ORG_ID, am.INSURER_ORG_ID, am.BRANCH_ZO_ID, am.BRANCH_RO_ID, AM."SOURCE" ,am.CHANNEL_ID, to_timestamp(CAST(am.status_change_date AS DATE))

								UNION ALL

								SELECT am.ORG_ID AS orgId, AM."SOURCE" AS SOURCE_ID, am.CHANNEL_ID,
								2 AS SCHEME_ID,
								to_timestamp(CAST(am.status_change_date AS DATE)) AS enroll_date,
								COUNT(am.id)  AS totalCount,
								am.BRANCH_RO_ID,
								am.BRANCH_ZO_ID,
								am.INSURER_ORG_ID
								FROM JNS_MASTER.PMJJBY am
								WHERE AM."SOURCE" != 3
								AND am.status_change_date > '''|| yesterdate ||'''
								GROUP BY am.ORG_ID, am.INSURER_ORG_ID, am.BRANCH_ZO_ID, am.BRANCH_RO_ID, AM."SOURCE" ,am.CHANNEL_ID, to_timestamp(CAST(am.status_change_date AS DATE))
							) tmp LEFT JOIN JNS_ONEFORM.DROPDOWNS_VALUES dv ON to_char(dv.OBJ_ID) = tmp.CHANNEL_ID AND  dv.DROPDOWN_ID = 18

';


--	dbms_output.put_line('insert Query' || mainquery);

    mainquery := mainquery || selectquery ;

--    dbms_output.put_line('mainquery' || selectquery);
   EXECUTE IMMEDIATE mainquery;
--  COMMIT;

    update JNS_REPORTS.schedular_date set is_active = 0, modified_date = current_timestamp where type = 1 and report_type = 3;
    insert into JNS_REPORTS.schedular_date(start_date, end_date, type, report_type, is_active)
    values(yesterdate, currentdate, 1,3,1);
    commit;

  END push_data_to_policy_channel_v5;