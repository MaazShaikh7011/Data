CREATE OR REPLACE PROCEDURE JNS_REPORTS.fetch_issued_and_saved_claim_list_v5 (filterjson IN  VARCHAR2,
                                                               userid     IN  NUMBER,
                                                               result     OUT CLOB)
  AS
    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
    countQuery      CLOB;
  BEGIN
 
                               selectquery := ' ''id'' value lst.id,
                           ''applicationId'' value lst.applicationId,
                           ''accountHolderName'' value lst.accountHolderName,
                           ''amount_of_transaction'' value lst.amount_of_transaction,
                           ''customerAccountNumber'' value lst.customerAccountNumber,
                           ''urn'' value lst.urn,
                           ''mobileNumber'' value lst.mobileNumber,
                           ''schemeName'' value lst.schemeName,
                           ''claimDate'' value lst.claimDate,
                           ''modifiedDate'' value lst.modifiedDate,
                           ''createdDate'' value lst.createdDate,
                           ''branch_lho_id'' value lst.branch_lho_id,
                           ''branchRoId'' value lst.branchRoId,
                           ''branchZoId'' value lst.branchZoId,
                           ''city_id'' value lst.city_id ,  
                           ''claimStageId'' value lst.claimStageId)RETURNING CLOB) FROM( SELECT ca.id as id, ca.application_id as applicationId, jns_users."decvalue"(cp.ac_holder_name) as accountHolderName, ca.TRANSACTION_AMOUNT as amount_of_transaction,
                           jns_users."decvalue"(cp.ap_account_number) as customerAccountNumber, ca.urn as urn, jns_users."decvalue"(cd.ap_mobile_number) as mobileNumber, sm.short_name as schemeName, ca.claim_date as claimDate, ca.modified_date as modifiedDate,
                            ca.created_date as createdDate, ca.branch_lho_id as branch_lho_id, ca.branch_ro_id as  branchRoId, ca.branch_zo_id as branchZoId, ca.branch_city_id as city_id,ca.stage_id as claimStageId ';
                            
    tablequery := 'FROM JNS_INSURANCE.clm_master ca 
                   INNER JOIN JNS_INSURANCE.clm_details cd ON cd.id = ca.id 
                    INNER JOIN JNS_INSURANCE.CLM_PI_DETAILS cp ON cp.id = ca.id 
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=ca.scheme_id AND sm.is_active=1';

    whereclause := ' WHERE ca.is_active = 1 ';

    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND ((jns_users."decvalue"(cp.ac_holder_name) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'') or (ca.urn LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'') or (jns_users."decvalue"(cp.ap_account_number) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%''))';
    END IF;

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid IS NOT NULL AND typeid != 5) THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF roleid IS NOT NULL AND roleid != 5 THEN
            IF roleid = 9 THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13 THEN -- RO
              whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id = ' || branchid);
            ELSIF roleid = 14 THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id = ' || branchid);
            ELSIF roleid = 15 THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND ca.branch_lho_id = ' || branchid);
            ELSE
              whereclause := ' AND 1=2 ';
            END IF;
          END IF;

        ELSIF typeid = 6 THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || typeid);
        ELSE 
          whereclause := ' AND 1=2 ';
        END IF;
      ELSE
        whereclause := ' AND 1=2 ';
      END IF;
    ELSE
      whereclause := ' AND 1=2 ';
    END IF;

    IF typeid IS NOT NULL
      AND typeid != 5
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.created_by =' || userId);
      whereclause := CONCAT(whereclause, ' AND ca.stage_id IN (10,11,12) ');
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;


    --    IF JSON_VALUE(filterjson, '$.claimStageId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.claim_status = ' || JSON_VALUE(filterjson, '$.claimStageId'));
    --    END IF;


    --    IF JSON_VALUE(filterjson, '$.tabId') IS NOT NULL THEN
    --        IF JSON_VALUE(filterjson, '$.tabId') = 1 THEN
    --            whereclause := whereclause || ' AND ca.claim_status IN (6, 8) ';
    --        ELSIF JSON_VALUE(filterjson, '$.tabId') = 2 THEN
    --            whereclause := whereclause || ' AND ca.claim_status = 6 ';
    --        ELSIF JSON_VALUE(filterjson, '$.tabId') = 3 THEN
    --            whereclause := whereclause || ' AND ca.claim_status = 8 ';
    --        END IF;
    --    END IF;

    IF
      JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
    THEN
      limitquery := ' OFFSET '
      || JSON_VALUE (filterjson, '$.paginationFROM')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.paginationTO')
      || ' ROWS ONLY';
    ELSE
      limitquery := '';
    END IF;

    countQuery := 'SELECT COUNT(ca.id) ' || tablequery || whereclause;
        dbms_output.put_line(countQuery);
    EXECUTE IMMEDIATE countquery
      INTO totalcount;

    whereclause := whereclause || ' order by ca.created_date desc ';

    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery
    || ')lst';
dbms_output.put_line(preparequery);

    EXECUTE IMMEDIATE preparequery
      INTO result;
       dbms_output.put_line(result);
  END fetch_issued_and_saved_claim_list_v5;