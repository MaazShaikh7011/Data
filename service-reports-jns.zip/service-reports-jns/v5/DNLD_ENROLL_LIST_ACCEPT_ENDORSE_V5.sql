create or replace PROCEDURE             dnld_enroll_list_accept_endorse_v5(
    filterjson  IN   varchar2,
    userid      IN   NUMBER,
    result      OUT  clob
)
AS
 totalcount            LONG;
    selectquery           CLOB;
    fromtodatequery       CLOB;
    tablequery            CLOB;
    inserttablequery      CLOB;
    mainwhereclause       CLOB;
    whereclause           CLOB;
    amodwhereclause       CLOB;
    limitquery            CLOB;
    preparequery          CLOB;
    orderby               CLOB;
    totalcounttablequery  CLOB;
    roleid                NUMBER;
    typeid                NUMBER;
    orgid                 NUMBER;
    branchid              NUMBER;
    insertquery           CLOB;
    appIds                  clob;
    statusQuery clob;
    endorseQuery clob;
    schemeQuery clob;
    commonQuery clob;
--    appmasterjoin         VARCHAR2;

BEGIN

if(JSON_VALUE(FILTERJSON, '$.statusDate') is not null)
THEN
statusQuery :=' ''coiGenerationDate'' VALUE (case when '||JSON_VALUE(FILTERJSON, '$.statusDate')||' = 1 then scm.completion_date else scm.enrollment_date end),';
END IF;

if(JSON_VALUE(FILTERJSON, '$.schemeId') = 1)
THEN

schemeQuery :=' ''schemeName'' VALUE ''PMSBY'', ';
ELSE
schemeQuery :=' ''schemeName'' VALUE ''PMJJBY'', ';
END IF;

--IF(JSON_VALUE(FILTERJSON, '$.status') is not null AND JSON_VALUE(FILTERJSON, '$.status') = 4)
--THEN
--endorseQuery :='''endorsementDate'' VALUE misc.CREATED_DATE,';
--END IF;

     EXECUTE IMMEDIATE ' TRUNCATE TABLE JNS_REPORTS.APP_MASTER_TEMP ';

            selectquery := ' ,''rowNo'' VALUE ROWNUM,
                ''id'' VALUE scm.id,
                ''applicationId'' VALUE scm.id,
                ''customerAccountNumber'' VALUE jns_users."decvalue"(api.ACCOUNT_NUMBER),
                ''urn'' VALUE scm.urn,
                ''mobileNumber'' VALUE jns_users."decvalue"(ai.mobile_number),
                '||schemeQuery||'
                ''enrollDate'' VALUE scm.enrollment_date,
                ''modifiedDate'' VALUE TRUNC(scm.status_change_date),
                ''source'' VALUE scm.source,
                ''transactionType'' VALUE (case when td.type=1 then ''N'' when td.type=2 then ''E'' when td.type=3 then ''R'' else null end),
                ''channelId'' VALUE (REPLACE(scm.channel_id, '','', '''')) ,
                ''cif'' VALUE jns_users."decvalue"(api.cif),
                ''insuredName'' VALUE (REPLACE(jns_users."decvalue"(api.AC_HOLDER_NAME), '','', '''')),
                ''fatherHusbandName'' VALUE (REPLACE(jns_users."decvalue"(ai.FATHER_HUSBAND_NAME), '','', '''')),
                ''dob'' VALUE jns_users."decvalue"(api.DOB),
                ''gender'' VALUE (case when scm.gender_id = 1 then ''MALE'' when scm.gender_id = 2 then ''FEMALE'' when scm.gender_id=3 then ''Other'' else null end),
                ''masterPolicyNumber'' VALUE jns_users."decvalue"(td.master_policy_no),
                ''kycIdName'' VALUE jns_users."decvalue"(api.kyc_id_1),
                ''pan'' VALUE jns_users."decvalue"(api.pan),
                ''kycIdNumber1'' VALUE jns_users."decvalue"(api.kyc_id_number_1),
                ''bankName'' VALUE (REPLACE(uom.display_org_name, '','', '''')),
                ''branchCode'' VALUE bm.code,
                ''branchName'' VALUE (REPLACE(bm.name, '','', '''')),
                ''roName'' VALUE (REPLACE(bmro.name, '','', '''')),
                ''roCode'' VALUE bmro.code,
                ''zoName'' VALUE (REPLACE(bmzo.name, '','', '''')),
                ''zoCode'' VALUE bmzo.code,
                ''userId1'' VALUE ai.user_id_1,
                ''userId2'' VALUE ai.user_id_2,
                ''pinCode'' VALUE aam.pincode,
                ''city'' VALUE (REPLACE(aam.city_name, '','', '''')),
                ''district'' VALUE (REPLACE(aam.district, '','', '''')),
                ''state'' VALUE (REPLACE(aam.state_name, '','', '''')),
                ''transactionDate'' VALUE jns_users."decvalue"(td.trans_time_stamp),
                ''transactionUTR'' VALUE jns_users."decvalue"(td.trans_utr),
                ''transactionAmount'' VALUE td.TRANS_AMOUNT,
                ''nomineeName'' VALUE (REPLACE(jns_users."decvalue"(npd.first_name)|| '' '' || jns_users."decvalue"(npd.middle_name) || '' '' || jns_users."decvalue"(npd.last_name), '','', '''')),
                ''nomineeDoB'' VALUE jns_users."decvalue"(npd.dob),
                ''relationOfNominee'' VALUE nd.relation_id,
                ''guardianName'' VALUE (REPLACE(jns_users."decvalue"(npd.GD_NAME), '','', '''')),
                ''relationshipOfGuardian'' VALUE nd.GD_RELATION_ID,
                ''geographicalClassification'' VALUE scm.RURAL_URBAN,
                ''endorsementType'' VALUE (select misc.type from USR_INSURANCE.MISCELLANEOUS_AUDIT misc where misc.application_id = scm.id order by misc.id DESC fetch first row only),
                '||statusQuery||'
                ''endorsementDate'' VALUE (select misc.created_date from USR_INSURANCE.MISCELLANEOUS_AUDIT misc where misc.application_id = scm.id order by misc.id DESC fetch first row only),
                ''requestDate'' VALUE scm.modified_date,
                ''insuredOrgId'' VALUE scm.INSURER_ORG_ID,
                ''reasonForRejection'' VALUE (REPLACE(scm.message,'','',''''))
               )RETURNING CLOB) ';


  whereclause := ' WHERE 1=1 ';
  commonQuery := ' AND scm.status = 2 AND scm.is_active = 1 ';
--  amodwhereclause := ' am.org_Id = amod.org_Id AND ';

  -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO TAHT
  IF USERID IS NOT NULL AND USERID != 0
  THEN
    SELECT U.USER_TYPE_ID,
           U.BRANCH_ID,
           U.USER_ORG_ID,
           U.USER_ROLE_ID
      INTO typeid,
           branchid,
           orgid,
           roleid
      FROM JNS_USERS.USERS U
      WHERE U.IS_ACTIVE = 1
        AND U.USER_ID = USERID;


    IF (typeid) IS NOT NULL
    THEN
      IF (typeid = 2)
      THEN
        whereclause := CONCAT(whereclause, ' AND scm.org_Id = ' || orgid || commonQuery);
--        amodwhereclause := ' scm.org_Id = amod.org_Id AND ';
--        IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
--        THEN
--          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
--        END IF;
        IF (roleid IS NOT NULL
          AND roleid != 5 AND roleid != 21)
        THEN
          IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND scm.branch_id = ' || branchid);
          ELSIF (roleid = 13) THEN
            if JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
            else
                whereclause := CONCAT(whereclause, ' AND scm.branch_ro_id = ' || branchid );
            end if;
          ELSIF (roleid = 14) THEN
            if JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
            elsif JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND scm.branch_ro_id IN (' || JSON_VALUE (filterjson, '$.roId')||') ');
            else
                whereclause := CONCAT(whereclause, ' AND scm.BRANCH_ZO_ID = ' || branchid );
            end if;

          ELSIF (roleid = 15) THEN
            whereclause := CONCAT(whereclause, ' AND scm.BRANCH_LHO_ID = ' || branchid );
          ELSE
            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        --          ELSE
        --            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSIF typeid = 6
      THEN
        whereclause := CONCAT(whereclause, ' AND scm.insurer_org_id = ' || orgid || commonQuery);
--       IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
--        THEN
--          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
--        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;
  ELSE
     whereclause := CONCAT(whereclause, ' AND scm.org_Id = ' || JSON_VALUE (FILTERJSON, '$.orgId'));
  END IF;


-- IF JSON_VALUE (FILTERJSON, '$.status') IS NOT NULL
-- THEN
--   IF (JSON_VALUE(FILTERJSON, '$.status') = 1 or JSON_VALUE(FILTERJSON, '$.status') = 4)
--   THEN
--        whereclause := CONCAT(whereclause, ' AND am.is_active = 1 AND am.stage_id = 6 ');
--   ELSIF JSON_VALUE(FILTERJSON, '$.status') = 2
--   THEN
--        whereclause := CONCAT(whereclause, ' AND am.is_active = 1 AND am.stage_id = 15 ');
--   ELSE
--        whereclause := CONCAT(whereclause, ' AND am.is_active = 1 AND am.stage_id = 8 ');
--   END IF;
--END IF;


--      dbms_output.put_line(whereclause);

  IF roleid is not null and roleid != 13 and roleid != 14  and JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||')');
  END IF;

  IF roleid is not null and roleid != 14  and JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND scm.branch_ro_id IN (' || JSON_VALUE (filterjson, '$.roId')||') ');
  END IF;

  IF JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NULL and JSON_VALUE (filterjson, '$.zoId') IS NOT NULL THEN
    whereclause := CONCAT(whereclause, ' AND scm.branch_zo_id IN (' || JSON_VALUE (filterjson, '$.zoId')||')  ');
  END IF;

  IF ((roleid = 5 and JSON_VALUE (filterjson, '$.boId') IS NULL and JSON_VALUE (filterjson, '$.roId') IS NULL and JSON_VALUE (filterjson, '$.zoId') IS NULL) or typeid = 6) and JSON_VALUE (filterjson, '$.stateId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND scm.branch_state_id IN (' || JSON_VALUE (filterjson, '$.stateId')||')  ');
   END IF;

  IF JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND scm.source in (' || JSON_VALUE (FILTERJSON, '$.channelId') || ')  ');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.bankId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND scm.org_id = ' || JSON_VALUE (FILTERJSON, '$.bankId'));
  END IF;


  IF JSON_VALUE (FILTERJSON, '$.fromDate') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.toDate') IS NOT NULL

  THEN
    IF JSON_VALUE (FILTERJSON, '$.status') IS NOT NULL
    THEN
    dbms_output.put_line(JSON_VALUE(FILTERJSON, '$.status'));
--        IF JSON_VALUE(FILTERJSON, '$.status') = 1 and JSON_VALUE(FILTERJSON, '$.statusDate') = 1
--        THEN
--            whereclause := CONCAT(whereclause, ' AND TRUNC(scm.completion_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
--            orderby := ' order by scm.completion_date desc ';
--        ELSIF JSON_VALUE(FILTERJSON, '$.status') = 1 and JSON_VALUE(FILTERJSON, '$.statusDate') = 2
--        THEN
--            whereclause := CONCAT(whereclause, ' AND TRUNC(scm.enrollment_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
        IF JSON_VALUE(FILTERJSON, '$.status') = 1
        THEN
            whereclause := CONCAT(whereclause, ' AND TRUNC(scm.STATUS_CHANGE_DATE) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
            orderby := ' order by scm.STATUS_CHANGE_DATE desc ';
        ELSIF JSON_VALUE(FILTERJSON, '$.status') = 4
        THEN
            whereclause := CONCAT(whereclause, ' AND TRUNC(misc.created_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
        ELSE
            whereclause := CONCAT(whereclause, ' AND TRUNC(scm.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
        END IF;
    ELSE
     whereclause := CONCAT(whereclause, ' AND TRUNC(scm.status_change_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
    END IF;
  END IF;

  insertquery := ' INSERT INTO JNS_REPORTS.APP_MASTER_TEMP
                    select scm.id  '; -- JNS_REPORTS.APP_MASTER_TEMP


	IF(JSON_VALUE (FILTERJSON, '$.schemeId') = 1)
	THEN
        if(JSON_VALUE (FILTERJSON, '$.status') = 4)
        THEN
--            endorseQuery :='';
            inserttablequery := ' FROM JNS_MASTER.pmsby scm
            INNER JOIN usr_insurance.miscellaneous_audit misc ON misc.application_id = scm.id  ';

             tablequery := ' FROM JNS_REPORTS.APP_MASTER_TEMP tmpam
--             INNER JOIN usr_insurance.miscellaneous_audit misc ON misc.application_id = tmpam.app_id
             INNER JOIN JNS_MASTER.pmsby scm ON scm.id = tmpam.app_id ';
        ELSE
            inserttablequery := ' FROM JNS_MASTER.pmsby scm ';
        END IF;

        tablequery := ' FROM JNS_REPORTS.APP_MASTER_TEMP tmpam
                    INNER JOIN JNS_MASTER.pmsby scm ON scm.id = tmpam.app_id ';

	ELSE

        IF(JSON_VALUE (FILTERJSON, '$.status') = 4)
        THEN
--        endorseQuery :='''endorsementDate'' VALUE (select misc.created_date from USR_INSURANCE.MISCELLANEOUS_AUDIT misc where misc.application_id = scm.id fetch first row only),';
            inserttablequery := ' FROM JNS_MASTER.PMJJBY scm
            INNER JOIN usr_insurance.miscellaneous_audit misc ON misc.application_id = scm.id  ';

            tablequery := ' FROM JNS_REPORTS.APP_MASTER_TEMP tmpam
--             INNER JOIN usr_insurance.miscellaneous_audit misc ON misc.application_id = tmpam.app_id
             INNER JOIN JNS_MASTER.PMJJBY scm ON scm.id = tmpam.app_id ';
        ELSE
            inserttablequery := ' FROM JNS_MASTER.pmjjby scm ';

            tablequery := ' FROM JNS_REPORTS.APP_MASTER_TEMP tmpam
                    INNER JOIN JNS_MASTER.pmjjby scm ON scm.id = tmpam.app_id ';
        END IF;


	END IF;

 tablequery := CONCAT(tablequery,' LEFT JOIN JNS_MASTER.APPLICANT_PI_DETAILS api ON api.id = scm.id
                    LEFT JOIN JNS_MASTER.applicant_info ai ON ai.id = scm.id
                    LEFT JOIN JNS_MASTER.transaction_details td ON td.id = scm.last_transaction_id
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=scm.branch_ro_id
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=scm.branch_zo_id
                    LEFT JOIN jns_users.branch_master bm ON bm.id=scm.branch_id
                    LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id = scm.org_id AND bm.is_active=1
                    LEFT JOIN JNS_MASTER.address_master aam ON aam.id = ai.address_id
                    LEFT JOIN JNS_MASTER.nominee_details nd ON nd.APPLICATION_ID = scm.id and nd.is_active = 1
                    LEFT JOIN JNS_MASTER.nominee_pi_details npd ON npd.id = nd.id


--                    left JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id
--                    left JOIN USR_INSURANCE.nominee_details guardian ON guardian.application_id = am.id and guardian.type = 3 and guardian.is_active = 1
--                    LEFT JOIN jns_oneform.dropdowns_values SRC ON SRC.obj_id=amod.source AND SRC.dropdown_id=16 AND SRC.is_active=1
');

-- dbms_output.put_line(inserttablequery);
-- dbms_output.put_line('fjhejhf');

--  IF JSON_VALUE (FILTERJSON, '$.status') = 4
--  THEN
--    endorseQuery :='''endorsementDate'' VALUE misc.CREATED_DATE,';
----    tablequery := CONCAT(tablequery, ' INNER JOIN USR_INSURANCE.MISCELLANEOUS_AUDIT misc ON misc.application_id = scm.id ');
----	inserttablequery := CONCAT(inserttablequery, ' INNER JOIN USR_INSURANCE.MISCELLANEOUS_AUDIT misc ON misc.application_id = scm.id ');
--  ELSE
----   tablequery := CONCAT(tablequery, ' LEFT JOIN USR_INSURANCE.MISCELLANEOUS_AUDIT misc ON misc.application_id = scm.id ');
----   inserttablequery := CONCAT(inserttablequery, ' LEFT JOIN USR_INSURANCE.MISCELLANEOUS_AUDIT misc ON misc.application_id = scm.id ');
--  END IF;




--dbms_output.put_line(inserttablequery);
-- IF (roleid = 13 OR roleid = 14 OR roleid = 15 OR JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
--    OR JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL) THEN
--    inserttablequery := CONCAT(inserttablequery, ' INNER JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id ');
--  END IF;

--  IF JSON_VALUE (FILTERJSON, '$.searchData') IS NOT NULL THEN
--    inserttablequery := CONCAT(inserttablequery, ' LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = scm.id');
--  END IF;


  IF (JSON_VALUE (FILTERJSON, '$.isSkipCount') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.isSkipCount') = 0) THEN
    --      dbms_output.put_line(' inside ');
--        dbms_output.put_line(' SELECT am.id ' || inserttablequery || whereclause);
        EXECUTE IMMEDIATE ' SELECT COUNT(scm.id)' || inserttablequery || whereclause INTO totalcount; -- tablequery
  ELSE
    --      dbms_output.put_line(' out side ');
    SELECT 0
      INTO totalcount
      FROM DUAL;
  END IF;



--      dbms_output.put_line(' SELECT COUNT(am.id)' || tablequery || whereclause);
--dbms_output.put_line(JSON_VALUE (filterjson, '$.paginationFROM'));
  IF JSON_VALUE (FILTERJSON, '$.paginationFROM') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.paginationTO') IS NOT NULL THEN
    limitquery := ' OFFSET ' || JSON_VALUE (FILTERJSON, '$.paginationFROM') || ' ROWS FETCH NEXT ' || JSON_VALUE (FILTERJSON, '$.paginationTO') || ' ROWS ONLY';
  -- dbms_output.put_line(limitquery);
  END IF;
-- dbms_output.put_line(limitquery);
--    orderby := ' order by am.completion_date desc ';

  EXECUTE IMMEDIATE insertquery || inserttablequery || whereclause || orderby || limitquery;
  dbms_output.put_line(insertquery || inserttablequery || whereclause || orderby || limitquery);
--
--  COMMIT;

-- dbms_output.put_line(preparequery);
--  preparequery := ' SELECT ' || totalcount || ' AS "totalcount", ' || selectquery || tablequery || orderby ; -- || whereclause || limitquery;
  preparequery := (' SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalcount'' VALUE ' || totalcount || selectquery || tablequery); -- || whereclause || limitquery;

    dbms_output.put_line(preparequery);
  EXECUTE IMMEDIATE preparequery into result;
--    dbms_output.put_line(result);


END dnld_enroll_list_accept_endorse_v5;