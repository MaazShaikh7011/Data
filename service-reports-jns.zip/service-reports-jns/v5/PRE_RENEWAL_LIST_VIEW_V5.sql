CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_list_view_v5(filterjson  IN  VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER,
    result      OUT  CLOB) AS

   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    insidewhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;

BEGIN

        tablequery := ' FROM JNS_INSURANCE.INSURER_MST_DETAILS imd ';
        whereclause := ' WHERE IMD.POLICY_START_DATE < CURRENT_DATE AND IMD.POLICY_END_DATE > CURRENT_DATE AND IMD.IS_ACTIVE = 1 ';
		insidewhereclause := ' 1=1 ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	     selectquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(  ''bankName'' value uom.display_org_name,
                        ''orgid'' value DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id),
						''successCount'' VALUE successCount,
						''failedCount'' VALUE failedCount,
						''totalCount'' VALUE totalCount,
						''insId'' VALUE insUom.USER_ORG_ID,
						''insCode'' VALUE tmp.INSURER_ORG_CODE,
						''insName'' VALUE insUom.display_org_name
					)RETURNING CLOB) ';

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND imd.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
	        insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = ' || JSON_VALUE (filterjson, '$.schemeId'));
	    END IF;

	    IF (typeid) IS NOT NULL THEN
			IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer
				select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;

				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID  = DECODE('|| typeid ||', 2, imd.insurer_org_id,imd.org_id)
		                LEFT JOIN (
		                    SELECT TO_CHAR(DECODE('|| typeid ||', 2, prfc.INSURER_CODE, prfc.BANK_CODE)) as ORG_CODE,
							TO_CHAR(DECODE('|| typeid ||', 2,  prfc.BANK_CODE, prfc.INSURER_CODE)) as INSURER_ORG_CODE,
							SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as successCount,
		                    SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as failedCount,
		                    (SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) + SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END)) as totalCount
				            FROM JNS_MASTER_DATA.PRE_RENEWAL_FILE_COUNTS prfc
				            WHERE '|| insidewhereclause ||' AND TO_CHAR(DECODE('|| typeid ||', 2, prfc.BANK_CODE, prfc.INSURER_CODE)) = ' || orgid ||'
				            GROUP BY TO_CHAR(DECODE('|| typeid ||', 2, prfc.INSURER_CODE, prfc.BANK_CODE)), TO_CHAR(DECODE('|| typeid ||', 2, prfc.BANK_CODE, prfc.INSURER_CODE))
		                ) tmp ON tmp.ORG_CODE = uom.USER_ORG_ID
						LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.USER_ORG_ID = tmp.INSURER_ORG_CODE ');
				whereclause := CONCAT(whereclause, ' AND DECODE('|| typeid ||', 2, IMD.ORG_ID, IMD.INSURER_ORG_ID) = ' || orgid);

--	    		select ORGANISATION_CODE, IMAGE_PATH, DISPLAY_ORG_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
--
--	    		IF (typeid = 2) THEN -- Banker
--		    		SELECT uom.IMAGE_PATH, uom.DISPLAY_ORG_NAME INTO bankLogoUrl, displayInsName FROM JNS_INSURANCE.INSURER_MST_DETAILS imd
--						INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON UOM.USER_ORG_ID = imd.INSURER_ORG_ID
--						WHERE imd.is_active= 1 AND imd.ORG_ID = orgid AND imd.SCHEME_ID = JSON_VALUE(filterjson, '$.schemeId') FETCH FIRST ROW ONLY;
--
--	--	    		select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
--		            whereclause := CONCAT(whereclause, ' AND prfc.BANK_CODE = ''' || org_code||''' ');
--		        ELSIF (typeid = 6) THEN -- Insurer
--		            whereclause := CONCAT(whereclause, ' AND prfc.INSURER_CODE = ''' || org_code||''' ');
--				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					insidewhereclause := CONCAT(insidewhereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = 1 ');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 1);
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND prfc.SCHEME_CODE = 2 ');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 2);
				END IF;
				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id)
		                LEFT JOIN (
		                    SELECT TO_CHAR(DECODE('|| roleid ||', 22, prfc.BANK_CODE, prfc.INSURER_CODE)) as ORG_CODE,
							TO_CHAR(DECODE('|| roleid ||', 22, prfc.INSURER_CODE, prfc.BANK_CODE)) as INSURER_ORG_CODE,
							SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as successCount ,
							SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END) as failedCount,
							(SUM(CASE WHEN prfc.IS_REJECT = 0 THEN prfc.COUNTS_IN_FILE ELSE 0 END) + SUM(CASE WHEN prfc.IS_REJECT = 1 THEN prfc.COUNTS_IN_FILE ELSE 0 END)) as totalCount
							FROM JNS_MASTER_DATA.PRE_RENEWAL_FILE_COUNTS prfc WHERE '|| insidewhereclause ||'
							GROUP BY DECODE('|| roleid ||', 22, prfc.BANK_CODE, prfc.INSURER_CODE) , DECODE('|| roleid ||', 22, prfc.INSURER_CODE, prfc.BANK_CODE)
		                ) tmp ON tmp.ORG_CODE = uom.USER_ORG_ID
						LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER insUom ON insUom.USER_ORG_ID = tmp.INSURER_ORG_CODE ');
	        END IF;
	   	ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
	     whereclause := CONCAT(whereclause, ' AND 1=2 ');
	END IF;


    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);


END pre_renewal_list_view_v5;