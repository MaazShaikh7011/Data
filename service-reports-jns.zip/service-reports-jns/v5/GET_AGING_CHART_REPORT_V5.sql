CREATE OR REPLACE PROCEDURE JNS_REPORTS.get_aging_chart_report_v5 (
filterjson  IN   VARCHAR2,
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS
    preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    roleid        NUMBER;
    typeid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    startdate CLOB;
    enddate CLOB;
BEGIN

    whereclause := ' WHERE ca.is_active = 1 ';

    IF(userid) IS NOT NULL THEN
            SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF(typeid) IS NOT NULL THEN
        IF(typeid = 2) THEN
        whereclause:= concat(whereclause, ' AND ca.org_id = ' || orgid);
                IF
                    roleid IS NOT NULL AND roleid != 5
                THEN 
                    IF roleid = 9 THEN -- BO
                                                    whereclause := concat(whereclause, ' AND ca.branch_id = ' || branchid);
                    ELSIF roleid = 13 THEN -- RO
                                                    whereclause := concat(whereclause, ' AND ca.branch_ro_id = ' || branchid);
                    ELSIF roleid = 14 THEN -- ZO
                                                    whereclause := concat(whereclause, ' AND ca.branch_zo_id = ' || branchid);
                    ELSIF roleid = 15 THEN -- LHO
                                                    whereclause := concat(whereclause, ' AND ca.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := conCAT(whereclause, ' and 0 ');
                    END IF;
                END IF;

            ELSIF typeid = 6 THEN
                whereclause := concat(whereclause, ' AND ca.insurer_org_id = ' || orgId);
            ELSIF (typeid = 4 or typeid = 7) THEN
                whereclause := concat(whereclause, ' and 1=1 ');
            ELSE
                whereclause := concat(whereclause, ' and 0 ');
            END IF;

        ELSE
            whereclause := concat(whereclause, ' and 0 ');
        END IF;

    ELSE
        whereclause := concat(whereclause, ' and 0 ');
    END IF;


    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
    END IF;

     IF JSON_VALUE(filterjson, '$.filterType') IS NOT NULL THEN
        if JSON_VALUE(filterjson, '$.filterType') = 1 then
   --         whereclause := concat(whereclause, ' AND am.scheme_id = ' || JSON_VALUE(filterjson, '$.filterType'));
            startdate := 'ca.created_date';
            enddate := 'ca.claim_date';
            whereclause := concat(whereclause, ' AND ca.status = 10 ');
        elsif JSON_VALUE(filterjson, '$.filterType') = 2 then
    --        whereclause := concat(whereclause, ' AND am.scheme_id = ' || JSON_VALUE(filterjson, '$.filterType'));
            startdate := 'ca.created_date';
            enddate := 'SYSTIMESTAMP';
           whereclause := concat(whereclause, ' AND ca.status = 6 ');
        end if;
     END IF;

    selectquery := 'SELECT json_object(''reportedCount'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 0 and 14) then 1 else 0 end),
            ''grp1'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 0 and 14) then 1 else 0 end),
            ''grp2'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 15 and 30) then 1 else 0 end),
            ''grp3'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 31 and 60) then 1 else 0 end),
            ''grp4'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 61 and 90) then 1 else 0 end),
            ''grp5'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) BETWEEN 91 and 180) then 1 else 0 end) ,
            ''grp6'' value sum(case when (CEIL(CAST('|| enddate ||' AS DATE ) - CAST('|| startdate ||' AS date)) > 180) then 1 else 0 end)) ';

    tablequery := ' FROM JNS_INSURANCE.clm_master ca
                    INNER JOIN JNS_INSURANCE.clm_details cd ON cd.id = ca.id ';

    preparequery := selectquery
                    || tablequery
                    || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
    INTO result;
    dbms_output.put_line(result);
END get_aging_chart_report_v5;