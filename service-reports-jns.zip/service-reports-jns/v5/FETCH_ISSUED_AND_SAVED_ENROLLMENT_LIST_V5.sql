CREATE OR REPLACE PROCEDURE JNS_REPORTS.fetch_issued_and_saved_enrollment_list_v5(filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;
    countQuery     clob;
    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
   

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
--          dbms_output.put_line(typeid);
      IF (typeid IS NOT NULL AND typeid != 5) THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (roleid IS NOT NULL
            AND roleid != 5) THEN
            IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13) THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14) THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
            ELSIF (roleid = 15) THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
          END IF;
        ELSIF (typeid = 6) THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
    END IF;


    fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';

    appcodequery := '(am.urn LIKE ''%' || JSON_VALUE (filterjson, '$.applicationCode') || '%'')';

    accnoquery := '(am.account_number LIKE ''%' || JSON_VALUE (filterjson, '$.accountNumber') || '%'')';

    selectquery := ' ''id'' value lst.id,
        ''schemeName'' value lst.shortName,
        ''applicationId'' value lst.applicationId,
        ''urn'' value lst.urn,
        ''customerAccountNumber'' value lst.accountNumber,
        ''application_status'' value lst.applicationStatus,
        ''branch_id'' value lst.branchId,
        ''createdDate'' value lst.createdDate,
        ''enrollDate'' value lst.enrollDate,
        ''message'' value lst.message,
        ''modifiedDate'' value lst.modifiedDate,
        ''orgId'' value lst.orgId,
        ''schemeName'' value lst.schemeName,
        ''stageId'' value lst.stageId,
        ''cif'' value lst.cif,
        ''mobileNumber'' value lst.mobileNumber,
        ''name'' value lst.name )RETURNING CLOB)  FROM (SELECT am.id as id, sm.short_name as shortName, am.id as applicationId, am.urn as urn, jns_users."decvalue"(am.account_number) as accountNumber,
        am.application_status as applicationStatus, am.branch_id as branchId, am.created_date as createdDate, am.enrollment_date as enrollDate, am.message as message,jns_users."decvalue"(am.cif) as cif, am.modified_date as modifiedDate,
         am.org_id as orgId, sm.short_name as schemeName, am.stage_id as stageId, jns_users."decvalue"(ai.mobile_number) as mobileNumber, jns_users."decvalue"(ai.name) as name ';
    tablequery := ' FROM JNS_INSURANCE.application_master am
                    INNER JOIN JNS_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id 
                    LEFT JOIN JNS_INSURANCE.applicant_info ai ON ai.application_id = am.id
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1 ';
   
   
    whereclause := ' WHERE am.is_active = 1 ';
    IF JSON_VALUE (filterjson, '$.pageType') IS NOT NULL AND JSON_VALUE (filterjson, '$.pageType') <> 3 THEN 
    IF typeid IS NOT NULL AND typeid != 5  THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id =' || branchid);
    END IF;
    END IF;
    
    IF JSON_VALUE (filterjson, '$.pageType') IS NOT NULL AND JSON_VALUE (filterjson, '$.pageType') = 3 THEN 
    IF typeid IS NOT NULL AND typeid != 5  THEN
      whereclause := CONCAT(whereclause, ' AND am.user_id =' || userid);
    END IF;
    END IF;

    --    dbms_output.put_line(filterjson);
    IF JSON_VALUE (filterjson, '$.pageType') IS NOT NULL
    THEN
      IF JSON_VALUE (filterjson, '$.pageType') = 1
      THEN
        whereclause := whereclause || ' AND am.stage_id IN (6, 7) ';
      ELSIF JSON_VALUE (filterjson, '$.pageType') = 2
      THEN
        whereclause := whereclause || ' AND am.stage_id IN (4,5) ';
      ELSIF JSON_VALUE (filterjson, '$.pageType') = 3
      THEN
        whereclause := whereclause || ' AND am.stage_id IN (15) ' ;
      END IF;
    END IF;
    
    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;
    

    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND ((jns_users."decvalue"(ai.name) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'') or (am.urn LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'') or (jns_users."decvalue"(am.account_number) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%''))';
    END IF;

    IF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NULL
    THEN
      whereclause := CONCAT(whereclause, fromtodatequery);
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || appcodequery
      || ' AND '
      || accnoquery
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || appcodequery
      || ' AND '
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || accnoquery
      || ' AND '
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || accnoquery
      || ' AND '
      || appcodequery;
    ELSIF JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause || ' AND ' || accnoquery;
    ELSIF JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
    THEN
      whereclause := whereclause || ' AND ' || appcodequery;
    END IF;

    IF
      JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
    THEN

      limitquery := ' OFFSET '
      || JSON_VALUE (filterjson, '$.paginationFROM')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.paginationTO')
      || ' ROWS ONLY';
    ELSE
      limitquery := '';
    END IF;

    whereclause := whereclause || ' order by am.modified_date desc ';

    --        dbms_output.put_line(limitquery);
    countQuery:=' SELECT COUNT(am.id)' || tablequery || whereclause;
               dbms_output.put_line(countQuery);
    EXECUTE IMMEDIATE  countQuery  INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalcount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery
    || ')lst';

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  --    dbms_output.put_line(result);
  END fetch_issued_and_saved_enrollment_list_v5;