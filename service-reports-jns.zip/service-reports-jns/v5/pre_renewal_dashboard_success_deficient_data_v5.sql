CREATE OR REPLACE PROCEDURE JNS_REPORTS.pre_renewal_dashboard_success_deficient_data_v5(
	filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB)
AS
	preparequery  CLOB;
	finalQuery    CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;
    scheme_id number;
    bankLogoUrl clob;
    displayInsName clob;
	limitQuery 	  CLOB;
	groupByQuery  CLOB;
	orderByQuery  CLOB;
BEGIN

	whereclause := ' WHERE bufl.status = 3 AND bufl.is_active = 1 AND FMES.error_code LIKE ''E-%'' ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;

	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select id, short_name into scheme_id, scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE =''' || scheme_code ||''' ');
	    END IF;

	    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
	    	select ORGANISATION_CODE INTO org_code FROM jns_users.USER_ORGANISATION_MASTER uom where uom.USER_ORG_ID = JSON_VALUE(filterjson, '$.orgId');
	        whereclause := CONCAT(whereclause, ' AND bufl.org_code =''' || org_code ||''' ');
	    END IF;

	    IF JSON_VALUE(filterjson, '$.insId') IS NOT NULL THEN
--		    dbms_output.put_line(JSON_VALUE(filterjson, '$.insId'));
	    	select ORGANISATION_CODE INTO org_code FROM jns_users.USER_ORGANISATION_MASTER uom where uom.USER_ORG_ID = JSON_VALUE(filterjson, '$.insId');
--	    	dbms_output.put_line(org_code);
	        whereclause := CONCAT(whereclause, ' AND bufl.insurer_org_code = ''' || org_code ||''' ');
-- 	        dbms_output.put_line(org_code);
	    END IF;

	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer
	    		select ORGANISATION_CODE, DISPLAY_ORG_NAME into org_code, displayInsName from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;

	    		IF (typeid = 2) THEN -- Banker
		    		SELECT uom.DISPLAY_ORG_NAME INTO displayInsName FROM JNS_INSURANCE.INSURER_MST_DETAILS imd
						INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON UOM.USER_ORG_ID = imd.INSURER_ORG_ID
						WHERE imd.is_active= 1 AND imd.ORG_ID = orgid AND imd.SCHEME_ID = JSON_VALUE(filterjson, '$.schemeId') FETCH FIRST ROW ONLY;

	--	    		select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
		            whereclause := CONCAT(whereclause, ' AND bufl.org_code = ''' || org_code ||''' ');
		        ELSIF (typeid = 6) THEN -- Insurer
		            whereclause := CONCAT(whereclause, ' AND bufl.insurer_org_code = ''' || org_code ||''' ');
				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
--				select urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME, urm.DISPLAY_OFFICE_NAME into org_code, displayInsName from jns_users.USER_ROLE_MASTER urm WHERE urm.role_id = roleid;
				SELECT sm.SHORT_NAME, sm.NAME into org_code, displayInsName FROM JNS_USERS.SCHEME_MASTER sm WHERE sm.id = scheme_id;

				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					whereclause := CONCAT(whereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE = ''PMSBY''');
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					whereclause := CONCAT(whereclause, ' AND bufl.SCHEME_CODE = ''PMJJBY''');
				END IF;
	        END IF;
	    ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1=2 ');
--		whereclause := CONCAT(whereclause, ' AND bufl.org_code = ' || JSON_VALUE (FILTERJSON, '$.orgId'));
	END IF;

--	selectquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''errorCode'' VALUE fmes.error_code,
--	                ''failCount'' VALUE SUM(CASE WHEN fmes.error_count IS NOT NULL then error_count ELSE 0 end) DESC,
--					''errorDesc'' VALUE ercm.ERROR_DESC))';

	selectquery := ' SELECT fmes.error_code AS errorCode,
					ercm.ERROR_DESC AS errorDesc,
					SUM(CASE WHEN fmes.error_count IS NOT NULL then error_count ELSE 0 end) AS failCount ';

    tablequery := ' FROM  JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
					LEFT JOIN JNS_MASTER_DATA.FILE_MIGRATION_ERROR_STAT fmes ON CAST(bufl.file_id AS NUMBER)  = fmes.file_id
					INNER JOIN JNS_MASTER_DATA.ERROR_REASON_CODE_MASTER ercm ON ercm.ERROR_CODE  = fmes.ERROR_CODE ';

    groupByQuery := ' GROUP BY fmes.error_code , ercm.ERROR_DESC ';
	orderByQuery := ' ORDER BY SUM(CASE WHEN fmes.error_count IS NOT NULL then error_count ELSE 0 end) DESC ';
	limitQuery := ' FETCH FIRST 5 ROWS ONLY ';
    preparequery := selectquery || tablequery || whereclause || groupByQuery || orderByQuery || limitQuery;
    dbms_output.put_line(preparequery);
 	finalQuery := '  SELECT JSON_ARRAYAGG(JSON_OBJECT(''errorCode'' VALUE tmp.errorCode,
						''failCount'' VALUE tmp.failCount,
						''errorDesc'' VALUE tmp.errorDesc)) from ( '|| preparequery ||') tmp ';
--	dbms_output.put_line(finalQuery);
    EXECUTE IMMEDIATE finalQuery INTO result;
--    dbms_output.put_line(result);

END pre_renewal_dashboard_success_deficient_data_v5;