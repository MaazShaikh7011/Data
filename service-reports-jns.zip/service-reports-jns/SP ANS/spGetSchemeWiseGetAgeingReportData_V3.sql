DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetSchemeWiseGetAgeingReportData_V3`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetSchemeWiseGetAgeingReportData_V3`(IN requestJSON TEXT, IN userId BIGINT)
BEGIN
	DECLARE filterJSON TEXT;
	DECLARE schemeIdList TEXT;

-- 	SELECT user_id, user_org_id, user_role_id, branch_id INTO @userId, @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;
	SET filterJSON = IF(requestJSON -> "$.filterJSON" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.filterJSON") != 'null', JSON_UNQUOTE(requestJSON -> "$.filterJSON"), NULL);
	
	SET @whereClause = " WHERE EPD.is_active = TRUE AND EPD.proposal_status_id IN(1,5,6) ";
	
	SELECT GROUP_CONCAT(scheme_id) INTO schemeIdList FROM users.user_role_product_mapping WHERE user_id = userId AND is_active = TRUE;
	SET @whereClause  = CONCAT(@whereClause, ' AND EPD.sch_type_id IN (', schemeIdList, ') ');
	
	CALL users.spFetchBranchListByUserId(userId, NULL, @branchId, @orgId);
	IF (@branchId IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.branch_id IN', @branchId);
	ELSEIF (@orgId IS NOT NULL) THEN		
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.org_id = ', @orgId);
	ELSE
		SET @whereClause = CONCAT(@whereClause, ' AND 1 = 2 ');
	END IF;
	
	IF (IFNULL(filterJSON, NULL) IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN
		-- Date Filter
		IF ((filterJSON -> "$.fromDate" IS NOT NULL) AND (filterJSON -> "$.toDate" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(journey_completion_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
		END IF;
		-- Source Filter
		IF (filterJSON->"$.appSourceId" IS NOT NULL ) THEN
			IF (filterJSON->"$.appSourceId" = 'MP') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND campaign_master_id = 1 ');
			ELSEIF (filterJSON->"$.appSourceId" = 'BS') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND campaign_master_id != 1 AND campaign_master_id IS NOT NULL');
			END IF;
		END IF;
		-- app TypeId
		IF (filterJSON->"$.appTypeId" IS NOT NULL ) THEN
			IF (filterJSON->"$.appTypeId" = 'approved') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND is_offline = FALSE ');
			ELSEIF (filterJSON->"$.appTypeId" = 'referred')THEN
				SET @whereClause = CONCAT(@whereClause, ' AND is_offline = TRUE ');
			END IF;
		END IF;
	END IF;
	
	SET @selectQuery = " SELECT
			SUM(CASE WHEN (DATEDIFF(CURDATE(), EPD.journey_completion_date) BETWEEN 0 AND 15) THEN 1 ELSE 0 END) AS 'interval1',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), EPD.journey_completion_date) BETWEEN 16 AND 30) THEN 1 ELSE 0 END) AS 'interval2',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), EPD.journey_completion_date) BETWEEN 31 AND 45) THEN 1 ELSE 0 END) AS 'interval3',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), EPD.journey_completion_date) BETWEEN 46 AND 60) THEN 1 ELSE 0 END) AS 'interval4',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), EPD.journey_completion_date) > 60) THEN 1 ELSE 0 END) AS 'interval5',
			COUNT(EPD.journey_completion_date) AS grandTotal,
			sch_type_id AS schemeId,
			SM.name AS schemeName ";
	
	SET @tableQuery = " FROM `banker_report`.`proposal_data` EPD INNER JOIN users.scheme_master SM ON SM.id = EPD.sch_type_id ";
	
	SET @groupByQuery = " GROUP BY EPD.sch_type_id ";
	
	SET @query = CONCAT(@selectQuery, @tableQuery, @whereClause, @groupByQuery);
-- 	select @query;
	PREPARE stmt FROM @query;
	EXECUTE stmt;
-- 	select @query;
-- 	CALL spGetSchemeWiseGetAgeingReportData_V3('{"filterJSON":{"fromDate":"2022-01-01", "toDate":"2022-10-31"}}', 74312);
END$$

DELIMITER ;