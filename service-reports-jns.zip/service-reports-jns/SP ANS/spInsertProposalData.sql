DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spInsertProposalData`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spInsertProposalData`()
BEGIN
	TRUNCATE banker_report.`proposal_data`;
	  -- INSERT PROPOSAL TABLE NAMES IN TEMP TABLE FOR REQUIRED SCHEMES
	  DROP TEMPORARY TABLE IF EXISTS temp_prop_table;
	  CREATE TEMPORARY TABLE temp_prop_table (
	    schema_table_name VARCHAR(500),
	    schema_audit_table_name VARCHAR(500),
	    journey_stage_id INT(11),
	    business_type_id INT(11)
	  );
  
  SET @propTableQuery = CONCAT('INSERT INTO temp_prop_table (schema_table_name,schema_audit_table_name, journey_stage_id,business_type_id)
                                SELECT DISTINCT schema_table_name, schema_audit_table_name, journey_stage_id,business_type_id FROM banker_report.proposal_table_names WHERE 1=1 ');
  
PREPARE propTableQuery FROM @propTableQuery;
EXECUTE propTableQuery;




SELECT
  COUNT(*) INTO @propTableCount
FROM temp_prop_table;

 SET  @newQueryWiseUnion = NULL;
 
 SET  @newQuery = NULL;
 SET @proposalAuditTable = NULL;
 
SET @propTableLoopCnt = 0;

    WHILE @propTableLoopCnt < @propTableCount DO
    
    SET @tempQuery2 = CONCAT('SELECT schema_table_name, schema_audit_table_name, journey_stage_id,business_type_id INTO @proposalTable , @proposalAuditTable, @journeyStageId, @businessTypeId FROM temp_prop_table LIMIT ', @propTableLoopCnt, ', 1');
-- select @tempQuery2;      
      PREPARE stmtQuery2 FROM @tempQuery2;
      EXECUTE stmtQuery2;
	 SET @whereClause = ' WHERE epd.is_active = TRUE AND epd.proposal_status_id IS NOT NULL AND epd.journey_completion_date IS NOT NULL ';

	 IF (@businessTypeId = 9 ||  @businessTypeId = 5 ) THEN
		SET @whereClause = CONCAT(@whereClause, 'AND epd.scheme_ineligible = 0');
	 END IF;
	 
	 IF (@businessTypeId = 11 ||  @businessTypeId = 12) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND epd.is_redirected = 0 ');		
	 END IF;
	
	SET @whereClause = CONCAT(@whereClause, ' AND epd.`journey_stage_id` = ', @journeyStageId);
	
		
	SET @newInsertQuery =	CONCAT('  
					INSERT INTO `banker_report`.`proposal_data`( `proposal_id`,`proposal_status_id`,`sch_type_id`,`journey_stage_id`,`journey_start_date`, `journey_completion_date`,
						`is_active`,`branch_id`,`org_id`,`is_offline`,`el_amount`,`loan_amount_required`,`application_id`,`campaign_master_id`,
						`sanction_amount`,`total_disbursed_amount`,`is_last_disbursed`,`schema_table_name`,`schema_audit_table_name`,`branch_type`,branch_name,
						`user_id`,`user_role_id`,`user_type_id`,`branch_ro_id`,`branch_zo_id`,`branch_lho_id`,`state_id`,`state_name`,`country_id`,`ro_name`,`zo_name`,`changed_date`,`bm_is_active`, organisation_name,display_org_name,
						image_path,`application_code`,`profile_id`,`city_id`,
						`email`,`mobile`,`is_from_reverse_api`,`rejection_reason`,`el_tenure`,`branch_code`,`branch_street_name`,`branch_ro_code`,`branch_zo_code`,`el_roi`,`el_emi`,`el_processing_fee`,`sanction_date`,
						`disbursement_date`,`disbursed_amount`,`employee_code`,`lam_created_by`,`fp_product_id`,`loan_type_id`,`business_type_id`, `is_partner_journey`,`remarks`,`sanction_created_date`,`first_disbursement_entry_date`,
						`first_disbursement_date`,`disbursement_created_date`,`stp_stage`)

						SELECT DISTINCT epd.`proposal_id` , epd.`proposal_status_id` , epd.`sch_type_id` ,epd.`journey_stage_id`,
							epd.`created_date`,epd.`journey_completion_date` ,
							epd.`is_active` ,epd.`branch_id` ,
							epd.`org_id`,epd.`is_offline` ,epd.`el_amount` ,epd.`loan_amount_required` ,
							epd.`application_id`,
							lap.`campaign_master_id` ,
							sd.`sanction_amount` ,
							dd.`total_disbursed_amount` ,dd.`is_last_disbursed`,
							ptn.`schema_table_name` ,ptn.`schema_audit_table_name`,
							bm.`branch_type`, bm.name,
							us.`user_id` ,us.`user_role_id` ,us.`user_type_id` ,
							bpm.`branch_ro_id` ,
							bpm.`branch_zo_id` ,bpm.`branch_lho_id` ,
							st.`id` ,st.`state_name` ,st.`country_id` ,
							RO.name, ZO.name, epd.`modified_date`,
							bm.is_active AS bmis_active,
							uom.`organisation_name`,
							uom.display_org_name,uom.image_path,epd.`application_code`,lap.`profile_id`,bm.`city_id`,
							
							banker_report.decValue(us.email) AS email, banker_report.decValue(us.mobile) AS mobile,
							IF(epd.proposal_status_id = 2, sd.is_from_reverse_api, IF(epd.proposal_status_id IN(3,8), dd.is_from_reverse_api, NULL)),
							epd.`rejection_reason`,epd.`el_tenure`,bm.`code`,bm.`street_name`,RO.code, ZO.code, epd.`el_roi`, epd.`el_emi`,
							epd.`el_processing_fee`, sd.`sanction_date`, dd.`disbursement_date`, dd.`disbursed_amount`,
							lap.`employee_code`, lap.`created_by`, epd.`fp_product_id`, lap.`loan_type_id`, lap.`business_type_id`, lap.`is_partner_journey`,
							IF(epd.proposal_status_id = 2, sd.`remarks`, IF(epd.proposal_status_id IN(3,8), dd.`remarks`, NULL)), sd.`created_date`,
							dd.`first_disbursement_entry_date`, dd.`first_disbursement_date`, dd.`created_date`');
							
							IF( @proposalTable = 'loan_application_details.agri_proposal_details') THEN 
								SET @newInsertQuery = CONCAT(@newInsertQuery,',epd.stp_stage ');
							ELSE
								SET @newInsertQuery = CONCAT(@newInsertQuery,',NULL ');
							END IF;
	SET @newInsertQuery = CONCAT(@newInsertQuery,'FROM ' , @proposalTable , ' epd
		INNER JOIN `loan_application_details`.`loan_application_master` lap ON lap.`application_id` = epd.`application_id` AND lap.is_active = TRUE
		INNER JOIN `banker_report`.`proposal_table_names` ptn ON epd.sch_type_id = ptn.`scheme_id` 
		INNER JOIN `users`.`user_organisation_master` uom ON epd.`org_id` = uom.`user_org_id` -- AND uom.is_active = TRUE
		LEFT JOIN `users`.`users` us ON us.user_id = lap.user_id -- AND us.is_active = TRUE
		LEFT JOIN `users`.`branch_master` bm ON bm.`id` = epd.`branch_id` -- AND bm.is_active = TRUE
		LEFT JOIN `users`.`branch_product_mapping` bpm ON bm.`id` = bpm.`branch_id` AND epd.sch_type_id = bpm.`sch_type_id` -- AND bpm.is_active = TRUE
		LEFT JOIN `users`.`branch_master` RO ON RO.id = bpm.branch_ro_id
		LEFT JOIN `users`.`branch_master` ZO ON ZO.id = bpm.branch_zo_id
		LEFT JOIN `one_form`.`state` st ON bm.`id` = st.`id` AND st.is_active = TRUE
		LEFT JOIN `loan_application_details`.`sanction_details` sd ON sd.`application_id` = epd.`application_id` AND sd.is_active = TRUE
		LEFT JOIN `loan_application_details`.`disbursement_details` dd ON dd.`application_id` = epd.`application_id` AND dd.is_last_disbursed = TRUE AND dd.is_active = TRUE 
		' , @whereClause , '
		-- AND epd.created_date < "2022-04-30"
		');
-- 	TIMESTAMPDIFF(MINUTE,epd.created_date, epd.journey_completion_date)	
-- select @newInsertQuery;
	   SET @propTableLoopCnt = @propTableLoopCnt + 1;
	   PREPARE finalQuery FROM @newInsertQuery;
	   EXECUTE finalQuery;
    
    END WHILE;
	SELECT 'SuccessFully Saved' AS message, (SELECT COUNT(id) FROM `banker_report`.`proposal_data`) AS totalProposal;
	SET @insert_audit = CONCAT(' INSERT INTO  `banker_report`.`proposal_data_audit`(`update_date_time`) SELECT NOW()');
	PREPARE insertQuery FROM @insert_audit;
	EXECUTE insertQuery;
END$$

DELIMITER ;