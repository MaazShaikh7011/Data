DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetSchemeWiseGetStatusReport_LIVE_DATA_NOT_USE`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetSchemeWiseGetStatusReport_LIVE_DATA_NOT_USE`(IN requestJSON TEXT, IN userId BIGINT)
BEGIN

	SET @whereClause = " WHERE EPD.proposal_status_id IS NOT NULL AND EPD.journey_completion_date IS NOT NULL AND EPD.is_active = TRUE ";
	
	SELECT user_org_id, user_role_id, branch_id INTO @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;
	
	SET @selectQuery = " SELECT 
			sch_type_id AS schemeId,
			SM.name AS schemeName,
			SUM(CASE WHEN (EPD.proposal_status_id = 1) THEN 1 ELSE 0 END) AS completed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 3) THEN 1 ELSE 0 END) AS disbursed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 5) THEN 1 ELSE 0 END) AS hold, 
			SUM(CASE WHEN (EPD.proposal_status_id = 6) THEN 1 ELSE 0 END) AS holeAftrSanction, 
			SUM(CASE WHEN (EPD.proposal_status_id = 8) THEN 1 ELSE 0 END) AS partialDisbursed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 4) THEN 1 ELSE 0 END) AS rejected,
			SUM(CASE WHEN (EPD.proposal_status_id = 7) THEN 1 ELSE 0 END) AS rejectAfterSanction,
			SUM(CASE WHEN (EPD.proposal_status_id = 10) THEN 1 ELSE 0 END) AS rejectOffileConfiguration,
			SUM(CASE WHEN (EPD.proposal_status_id = 2) THEN 1 ELSE 0 END) AS sanctioned,
			SUM(CASE WHEN (EPD.proposal_status_id != 9) THEN 1 ELSE 0 END) AS grandTotal ";
	
	SET @commonTableQuery = " INNER JOIN users.scheme_master SM ON SM.id = EPD.sch_type_id ";
	
	SET @groupByQuery = " GROUP BY sch_type_id ";
	
	SET @query = CONCAT(@selectQuery, " FROM `loan_application_details`.`edu_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.scheme_ineligible = FALSE  ", @groupByQuery," UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`agri_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.is_redirected = FALSE  ", @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`hl_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.scheme_ineligible = FALSE  ", @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`msme_proposal_details` EPD  ", @commonTableQuery, @whereClause, @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`livelihood_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.is_redirected = FALSE  ", @groupByQuery);
	PREPARE stmt FROM @query;
	EXECUTE stmt;
-- 	select @query;
-- 	CALL spGetSchemeWiseGetStatusReport_LIVE_DATA_NOT_USE();

END$$

DELIMITER ;