DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetInEligibleReasonList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetInEligibleReasonList`(IN filterJSON TEXT, IN userOrgId BIGINT, IN paginationFROM BIGINT, IN paginationTO BIGINT)
BEGIN
	SET @whereClause = ' WHERE APA.is_active = FALSE ';

	-- FOR BANK FILTER
	IF (userOrgId IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause ,' AND PM.`user_org_id` = ', userOrgId);
	END IF;
		
	-- WHILE APPLY ANY FILTER
	IF (filterJSON IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN
		
		-- FOR SCHEME FILTER
		IF (filterJSON->"$.schemeId" IS NOT NULL AND filterJSON->"$.schemeId" != '') THEN
			SET @getproductDataQuery = CONCAT('SELECT `table_name` INTO @productAuditTableName FROM `banker_report`.`common_table_names` WHERE `scheme_id` = ',JSON_UNQUOTE(filterJSON->"$.schemeId"),' AND `type` = 1');
			PREPARE productStmt FROM @getproductDataQuery;
			EXECUTE productStmt;
			
			SET @proposalTableQuery = CONCAT('SELECT `schema_table_name` INTO @proposalTableName FROM `banker_report`.`proposal_table_names` WHERE `scheme_id` = ', JSON_UNQUOTE(filterJSON->"$.schemeId"));
			PREPARE sproStmt FROM @proposalTableQuery;
			EXECUTE sproStmt;
			SET @whereClause = CONCAT(@whereClause, ' AND PM.`scheme_id` = ', JSON_UNQUOTE(filterJSON->"$.schemeId")); 
		END IF;
		
		-- -- FOR IS MATCH FILTER
-- 		IF (filterJSON->"$.isMatchedId" IS NOT NULL AND filterJSON->"$.isMatchedId" != '') THEN
-- 			IF (filterJSON->"$.isMatchedId" = 1) THEN
-- 				SET @whereClause = CONCAT(@whereClause ,' AND APA.is_active = TRUE ');
-- 			ELSEIF (filterJSON->"$.isMatchedId" = 2) THEN
-- 				SET @whereClause = CONCAT(@whereClause ,' AND APA.is_active = FALSE ');
-- 			END IF;
-- 		END IF;
		
		-- FOR SEARCH FILTER
		IF (filterJSON->"$.searchValue" IS NOT NULL AND filterJSON->"$.searchValue" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (APA.proposal_id LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchValue"),'%''
							OR APA.application_id LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchValue"),'%'' )'); 
		END IF;
		
		-- FOR PRODUCT NAME SEARCH FILTER
		IF (filterJSON->"$.searchProductName" IS NOT NULL AND filterJSON->"$.searchProductName" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (PM.product_name LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchProductName"),'%'')'); 
		END IF;
		
		-- FOR CAMPAIGN TYPE SEARCH FILTER
		IF ((IFNULL(filterJSON -> "$.searchCampaignTypeId", NULL) IS NOT NULL)
		    AND (filterJSON -> "$.searchCampaignTypeId" IS NOT NULL)) THEN
			IF (filterJSON -> "$.searchCampaignTypeId" = 1) THEN
			    SET @whereClause = CONCAT(@whereClause, ' AND (LAM.campaign_master_id = 1 OR LAM.campaign_master_id IS NULL) ');
			ELSEIF (filterJSON -> "$.searchCampaignTypeId" = 2) THEN
			    SET @whereClause = CONCAT(@whereClause, ' AND (LAM.campaign_master_id != 1 AND LAM.campaign_master_id IS NOT NULL) ');
			END IF;
		END IF;
		
		-- COLUMN FILTERS	
		
		IF (filterJSON->"$.appCodeFilter" IS NOT NULL AND filterJSON->"$.appCodeFilter" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND PDT.application_code LIKE ''%', JSON_UNQUOTE(filterJSON -> "$.appCodeFilter"), '%'''); 
		END IF;
		IF (filterJSON->"$.mobileFilter" IS NOT NULL AND filterJSON->"$.mobileFilter" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (banker_report.decValue(U.mobile) LIKE ''%', JSON_UNQUOTE(filterJSON -> "$.mobileFilter"), '%''', ' OR banker_report.decValue(U.email) LIKE ''%', JSON_UNQUOTE(filterJSON -> "$.mobileFilter"), '%'')'); 
		END IF;
		IF (filterJSON->"$.panFilter" IS NOT NULL AND filterJSON->"$.panFilter" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND banker_report.decValue(PRM.pan) LIKE ''%', JSON_UNQUOTE(filterJSON -> "$.panFilter"), '%''');
		END IF;
		IF (filterJSON->"$.orgIdFilter" IS NOT NULL AND filterJSON->"$.orgIdFilter" != '') THEN
			 SET @whereClause = CONCAT(@whereClause, ' AND PDT.org_id = ', filterJSON -> "$.orgIdFilter");
		END IF;
		IF (filterJSON->"$.dateFilter" IS NOT NULL AND filterJSON->"$.dateFilter" != '') THEN
			 SET @whereClause = CONCAT(@whereClause, ' AND DATE(PDT.journey_completion_date) = ', filterJSON -> "$.dateFilter");
		END IF;
		IF (filterJSON->"$.nameFilter" IS NOT NULL AND filterJSON->"$.nameFilter" != '') THEN
			 SET @whereClause = CONCAT(@whereClause, ' AND banker_report.decValue(PRM.name) LIKE ''%', JSON_UNQUOTE(filterJSON -> "$.nameFilter"), '%''');
		END IF;
		
		-- -- FOR BRANCH NAME SEARCH FILTER
-- 		IF (filterJSON->"$.searchBranchName" IS NOT NULL AND filterJSON->"$.searchBranchName" != '') THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND (BM.`name` LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchBranchName"),'%'')'); 
-- 		END IF;
-- 		
-- 		-- FOR STATE NAME SEARCH FILTER
-- 		IF (filterJSON->"$.searchStateName" IS NOT NULL AND filterJSON->"$.searchStateName" != '') THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND (ST.`state_name` LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchStateName"),'%'')'); 
-- 		END IF;
-- 		
-- 		-- FOR CITY NAME SEARCH FILTER
-- 		IF (filterJSON->"$.searchCityName" IS NOT NULL AND filterJSON->"$.searchCityName" != '') THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND (CT.`city_name` LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchCityName"),'%'')'); 
-- 		END IF;
		
		-- DATE FILTER
		IF (filterJSON->"$.fromDate" IS NOT NULL) AND (filterJSON->"$.toDate" IS NOT NULL) AND (filterJSON->"$.fromDate" != '') AND (filterJSON->"$.toDate" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(PDT.modified_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
		ELSEIF (filterJSON->"$.fromDate" IS NOT NULL AND filterJSON->"$.fromDate" != '') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(PDT.modified_date) = ', filterJSON->"$.fromDate");
		END IF;
-- 		APA.created_date
	END IF;
	
	SET @selectQuery = CONCAT('  DISTINCT PDT.`proposal_id` AS proposalId, APA.application_id AS applicationId,
				banker_report.decValue(U.email) AS email,
				banker_report.decValue(U.mobile) AS mobile,
				banker_report.decValue(PRM.name) AS name,
				UOM.`organisation_name` AS bankName,
 				UOM.`user_org_id` AS userOrgId, 				
  				PDT.created_date AS createdDate,
 				PDT.modified_date AS modifiedDate,
				SM.short_name AS shortSchemeName,
				SM.name AS schemeName,
				banker_report.decValue(PRM.`pan`) AS pan,
				IF(LAM.`campaign_master_id` = 1,"Market Place","Bank Specific") AS campaignType,
				IF(PDT.org_id = ',userOrgId ,',"Own Bank", "Other Bank") AS referredType,
				(SELECT JSON_ARRAYAGG(JSON_OBJECT("message",a.message,"product_name",pd.`product_name`,"productIsActive",IF(pd.is_active,TRUE,FALSE) )) 
				FROM ', @productAuditTableName,' a LEFT JOIN `product_ans`.`product_master` pd ON pd.id = a.`fp_product_id`
				WHERE a.application_id = APA.application_id AND a.is_active = FALSE AND pd.user_org_id = PM.`user_org_id` AND pd.scheme_id = PM.`scheme_id`) AS jsonData,
				(IF(PDT.is_offline,"offline","inprinciple")) AS isOffline,
				PDT.application_code AS applicationCode, 
 	            IF(PM.`scheme_id` = 8 ,(CASE WHEN SLD.loan_purpose = 1 THEN "Working Capital" WHEN SLD.loan_purpose = 2 THEN "Term Loan" ELSE "" END),
				IF(PM.`scheme_id` = 9,(CASE WHEN MLD.purpose_of_loan = 1 THEN "Working Capital" WHEN MLD.purpose_of_loan = 2 THEN "Term Loan" ELSE "" END),""))  AS loanPurpose,			
				PM.`scheme_id` AS schemeId,	
				');

	-- UNION ALL QUERY
	SET @tableQuery = CONCAT(@productAuditTableName,' APA 
			INNER JOIN ',@proposalTableName,' PDT ON PDT.application_id = APA.application_id AND PDT.proposal_id  = APA.proposal_id
			INNER JOIN loan_application_details.loan_application_master LAM ON LAM.application_id = APA.application_id
			INNER JOIN loan_application_details.`profile_master` PRM ON PRM.profile_id = LAM.profile_id
			INNER JOIN `users`.`users` U ON U.user_id = LAM.user_id
			LEFT JOIN `product_ans`.`product_master` PM ON PM.id = APA.`fp_product_id`
			LEFT JOIN `users`.`user_organisation_master` UOM ON UOM.`user_org_id` = PM.`user_org_id`
			INNER JOIN `users`.`scheme_master` SM ON SM.id = PM.`scheme_id`
			LEFT JOIN `msme_loan_application`.swms_loan_details  SLD ON SLD.application_id = APA.application_id AND PM.`scheme_id` = 8
            LEFT JOIN `msme_loan_application`.mudra_loan_details  MLD ON MLD.application_id = APA.application_id AND PM.`scheme_id` = 9
			
			 ');

	-- GET TOTAL COUNT FOR PAGINATION
	SET @totalCountQuery =  CONCAT(" SELECT COUNT(DISTINCT PDT.`proposal_id`) INTO @totalCount FROM ", @tableQuery, @whereClause);
	
	PREPARE cntstmt FROM @totalCountQuery;
	EXECUTE cntstmt;

	-- GROUP BY QUERY
	SET @groupByQuery = ' GROUP BY APA.application_id ';

	-- ORDER BT QUERY
	SET @orderByQuery = ' ORDER BY createdDate DESC ';
	
	-- LIMIT QUERY
	SET @limitQuery = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
	
	SET @mainQuery = CONCAT('SELECT ',@selectQuery,' @totalCount AS totalCount FROM ', @tableQuery, @whereClause, @orderByQuery, @limitQuery); -- groupByQuery
-- 	SELECT @mainQuery;
	PREPARE mainStmt FROM @mainQuery;
	EXECUTE mainStmt;

-- 	=============================  CALL `banker_report`.spGetInEligibleReasonList('{"schemeId":6}',32,0,10); ===================
	
END$$

DELIMITER ;