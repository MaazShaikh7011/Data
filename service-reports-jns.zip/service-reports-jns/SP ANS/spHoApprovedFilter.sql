DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spHoApprovedFilter`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spHoApprovedFilter`(IN filterName VARCHAR(255), IN whereClause VARCHAR(255), IN orgId VARCHAR(255), IN userId VARCHAR(255))
BEGIN

IF(filterName = 'branch') THEN
SET @query = CONCAT('SELECT id as id, name as label FROM users.branch_master WHERE org_id = ',orgId);

  IF (IFNULL(whereClause, NULL) IS NOT NULL) THEN
  SET @query = CONCAT(@query, whereClause );
  END IF;

ELSEIF(filterName = 'productList') THEN
SET @query = CONCAT('SELECT id as id, product_name as label FROM product_ans.product_master WHERE user_org_id = ',orgId);

ELSEIF(filterName = 'proposalStatusMaster') THEN
SET @query = CONCAT('SELECT id as id, display_name as label FROM loan_application_details.proposal_status_master ');

ELSEIF(filterName = 'orgList') THEN
SET @query = CONCAT('SELECT user_org_id as id, IF(display_org_name IS NOT NULL, display_org_name, organisation_name) as label, IF(display_org_name IS NOT NULL, display_org_name, organisation_name) as value FROM users.user_organisation_master ');

ELSEIF(filterName = 'bankList') THEN -- For Subsidy
SET @query = CONCAT('SELECT code as id, name as label FROM subsidy_details.`subsidy_master_data`',whereClause);

ELSEIF(filterName = 'applicationStatusList') THEN -- For Subsidy
SET @query = CONCAT('SELECT id as id, stage as label FROM subsidy_details.`subsidy_status_master`');

-- For CLAP
ELSEIF(filterName = 'clap_state') THEN
SET @query = CONCAT('select state_code AS id, state_name AS value, state_name AS label FROM retail_loan_application.clap_state ORDER BY state_name');

ELSEIF(filterName = 'clap_city') THEN
SET @query = CONCAT('select district_code AS id, district_name AS value, district_name AS label FROM retail_loan_application.clap_district WHERE state_code = ',whereClause ,' ORDER BY district_name ');

ELSEIF(filterName = 'clap_town') THEN
SET @query = CONCAT('select town_code AS id, town_name AS value, town_name AS label FROM retail_loan_application.clap_town WHERE district_code = ',whereClause ,' ORDER BY town_name ');

ELSEIF(filterName = 'clap_pli') THEN
SET @query = CONCAT('select pli_code AS id, pli_name AS value, pli_name AS label FROM retail_loan_application.clap_pli ORDER BY pli_name');

ELSEIF(filterName = 'clap_marital_status') THEN
SET @query = CONCAT('select marital_code AS id, description AS value, description AS label FROM retail_loan_application.clap_marital_status');

ELSEIF(filterName = 'clap_gender') THEN
SET @query = CONCAT('select gender_code AS id, description AS value, description AS label FROM retail_loan_application.clap_gender');

-- For admin panel
ELSEIF(filterName = 'scheme_list') THEN
SET @query = CONCAT('SELECT id as id, name as label FROM scheme_details.scheme_master ', whereClause);

ELSEIF(filterName = 'proposal_status') THEN
SET @query = CONCAT('SELECT id as id, display_name as label FROM loan_application_details.proposal_status_master');

ELSEIF(filterName = 'loan_list') THEN
SET @query = CONCAT('SELECT id as id, display_name as label FROM scheme_details.loan_master WHERE `display_name` IS NOT NULL ', whereClause); -- is_active = 1
-- insert into tmp.temp(val, val2) values('whereClause',whereClause);

ELSEIF(filterName = 'thirdparty_module') THEN
SET @query = CONCAT('SELECT id as id, name as label FROM ans_config.tp_module WHERE is_active = 1 ORDER BY sequence ASC');

ELSEIF(filterName = 'thirdparty_service') THEN
SET @query = CONCAT('SELECT TS.provider_id as id, TS.name as label FROM ans_config.tp_services TS INNER JOIN ans_config.tp_module_service_map MAP
                      ON TS.id = MAP.service_id WHERE TS.is_active = 1 ', whereClause);

-- Added Ravi Thummar
ELSEIF(filterName = 'admin_menu_permission') THEN
SET @query = CONCAT(' SELECT role_id AS id, display_name AS label FROM users.user_role_master WHERE is_active = 1 AND role_id IN(SELECT role_id FROM (SELECT * FROM users.user_role_master ORDER BY parent_role_id, role_id) products_sorted, (SELECT @pv := ', whereClause ,') initialisation WHERE FIND_IN_SET(parent_role_id, @pv) AND LENGTH(@pv := CONCAT(@pv, ",", role_id)))');

ELSEIF(filterName = 'other_user_list') THEN
SET @query = CONCAT(' SELECT id AS id, name AS label FROM users.user_type_master WHERE id IN(3,4,6,7,8)');

ELSEIF(filterName = 'campaign_list') THEN
SET @query = CONCAT(' SELECT cm.id AS id, cm.name AS label FROM `users`.`campaign_master` cm ');

-- For IFSC code
ELSEIF(filterName = 'oneform_state') THEN
SET @query = CONCAT(' SELECT id AS id, state_name AS value FROM one_form.state WHERE ', whereClause , ' ORDER BY state_name ');

ELSEIF(filterName = 'oneform_city') THEN
SET @query = CONCAT(' SELECT id AS id, city_name AS value FROM one_form.city WHERE ', whereClause , ' ORDER BY city_name ');

ELSEIF(filterName = 'ifsc_bank') THEN
SET @query = CONCAT(' SELECT id AS id, bank AS value FROM one_form.ifsc_bank_master WHERE ', whereClause , ' ORDER BY bank ');

ELSEIF(filterName = 'ifsc_branch') THEN
SET @query = CONCAT(' SELECT ifsc AS id, branch AS value FROM one_form.ifsc_master WHERE ', whereClause , ' ORDER BY branch ');

ELSEIF(filterName = 'stateList') THEN
	SET @query = CONCAT(' SELECT `state_code` AS `id`,`state_name_english` AS label FROM `one_form`.`lgd_state` ORDER BY state_name_english ASC');

ELSEIF(filterName = 'districtList') THEN
	SET @query = CONCAT(' SELECT ifsc AS id, branch AS value FROM one_form.ifsc_master WHERE ', whereClause , ' ORDER BY branch ');
	SET @query = CONCAT(' SELECT `district_code` AS `id`,`district_name_english` AS label FROM `one_form`.`lgd_district` WHERE state_code = ',whereClause,' ORDER BY district_name_english ASC');

ELSEIF(filterName = 'subDistrictList') THEN
	SET @query = CONCAT(' SELECT `subdistrict_code` AS `id`,`subdistrict_name_english` AS label FROM `one_form`.`lgd_subdistrict` WHERE  `district_code`= ',whereClause,' ORDER BY subdistrict_name_english ASC');

ELSEIF(filterName = 'villageList') THEN
	SET @query = CONCAT(' SELECT `village_code` AS `id`,`village_name_english` AS label FROM `one_form`.`lgd_village` WHERE `subdistrict_code` = ',whereClause,' ORDER BY village_name_english ASC');

ELSEIF(filterName = 'blockList') THEN
	SET @query = CONCAT(' SELECT LB.block_code AS `id`,LB.block_name_english AS label FROM `one_form`.`lgd_block_coverage_mapping` LBCM INNER JOIN `one_form`.`lgd_block` LB ON LB.block_code = LBCM.block_code AND LBCM.village_code = ',whereClause,' ORDER BY LB.block_name_english ASC');

ELSEIF(filterName = 'industryList') THEN
	SET @query = CONCAT(' SELECT `id` AS `id`,`value` AS label FROM `one_form`.`industry`');

ELSEIF(filterName = 'sectorList') THEN
	SET @query = CONCAT(' SELECT S.id AS `id`, S.value AS label FROM `one_form`.`sector_industry` SI INNER JOIN `one_form`.`sector` S ON S.id = SI.`sector_id` WHERE `industry_id` = ',whereClause);

ELSEIF(filterName = 'subSectorList') THEN
	SET @query = CONCAT(' SELECT SS.id AS id, SS.value AS label FROM `one_form`.`sub_sector_mapping` SSM INNER JOIN `one_form`.`sub_sector` SS ON SS.id = SSM.sub_sector_id WHERE sector_id = ',whereClause);

ELSEIF(filterName = 'industryListSbi') THEN
	SET @query = CONCAT(' SELECT `id` AS `id`,`value` AS label FROM `one_form`.`Industry_SBI`');

ELSEIF(filterName = 'sectorListSbi') THEN
	SET @query = CONCAT(' SELECT S.id AS `id`, S.value AS label FROM `one_form`.`sector_industry_SBI` SI INNER JOIN `one_form`.`sector_SBI` S ON S.id = SI.`sector_id` WHERE `industry_id` = ',whereClause);

ELSEIF(filterName = 'subSectorListSbi') THEN
	SET @query = CONCAT(' SELECT SS.id AS id, SS.value AS label FROM `one_form`.`sub_sector_mapping_SBI` SSM INNER JOIN `one_form`.`sub_sector_SBI` SS ON SS.id = SSM.sub_sector_id WHERE sector_id = ',whereClause);


ELSEIF(filterName = 'cropList') THEN
	SET @query = CONCAT (' SELECT `id` AS `id`,`name` AS label FROM `agri_loan_application`.`kcc_crop_master`');

ELSEIF(filterName = 'irrigationMasterList') THEN
	SET @query = CONCAT (' SELECT KCC.id AS id ,KCC.crop_code AS cropCode,KCC.`rainfed_irrigated` AS label , KCC.acz1 AS acz1 ,KCC.acz2 AS acz2 ,KCC.acz3 AS acz3, KCC.acz4 AS acz4,KCC.acz5 AS acz5, KCC.acz6 AS acz6 ,KCC.acz7 AS acz7 ,KCC.acz8 AS acz8 ,KCC.acz9 AS acz9 , KCC.acz10 AS acz10  FROM `agri_loan_application`.`kcc_scale_of_finance` KCC WHERE org_id = -1 AND crop_code = ',whereClause);


ELSEIF(filterName = 'irrigationList') THEN
	SET @query = CONCAT(' SELECT KCIM.`irrigation_id` AS id,KIM.`name` AS label FROM `agri_loan_application`.`kcc_crop_irrigation_mapping` KCIM INNER JOIN `agri_loan_application`.`kcc_irrigation_master` KIM ON KIM.`id` = KCIM.`irrigation_id` WHERE KCIM.`crop_code` = ',whereClause);

ELSEIF(filterName = 'cropScaleFinancialList') THEN
	SET @query = CONCAT('SELECT `crop_code` AS id,`crop` AS label FROM `agri_loan_application`.`kcc_scale_of_finance` GROUP BY crop_code');

ELSEIF(filterName = 'kccStateList') THEN
	SET @query = CONCAT('SELECT `state_code` AS `id`,`state_name_english` AS label FROM `one_form`.`lgd_state` WHERE `state_code` = ',whereClause);

ELSEIF(filterName = 'sofLgdList') THEN
	SET @query = CONCAT (' SELECT id AS id , acz_code AS AczCode , acz_dist_name AS label , lgd_codes AS lgdCode  FROM `agri_loan_application`.`kcc_sof_lgd_code`');

ELSEIF(filterName = 'getKccDocument') THEN
	SET @query = CONCAT (' SELECT CAST(UNCOMPRESS(np.document) AS CHAR) as `document` FROM `stp_details`.`nesl_pfx_sign_audit` np WHERE np.`application_id` = ', whereClause,' ORDER BY np.id DESC LIMIT 1 ');

ELSEIF(filterName = 'kccNameMatching') THEN
	SET @query = CONCAT ('SELECT
				inN.display_name AS inputType,
				kccnm.input_name AS inputName,
				baseN.display_name AS baseType,
				(SELECT a.input_name FROM agri_loan_application.agri_kcc_name_match_new a WHERE a.application_id = kccnm.application_id AND a.input_type_id = kccnm.base_id LIMIT 1) AS baseName,
				IF(kccnm.is_match,"Yes","No") AS isMatch,
				kccnm.bank_set_percentage AS bankSetPercentage,
				ROUND(kccnm.percentage, 2) AS percentage
				FROM agri_loan_application.agri_kcc_name_match_new kccnm
				INNER JOIN name_match_api.name_match_input_type_master inN ON inN.input_type_id = kccnm.input_type_id AND inN.is_for_kcc = TRUE
				INNER JOIN name_match_api.name_match_input_type_master baseN ON baseN.input_type_id = kccnm.base_id AND baseN.is_for_kcc = TRUE
				WHERE kccnm.application_id = ', whereClause);


ELSEIF(filterName = 'sateliteApiResponse') THEN
	SET @query = CONCAT (' SELECT * FROM `agri_loan_application`.`land_details_vendor_response_audit` WHERE application_id = ', whereClause ,' AND is_active = TRUE AND success IS NOT FALSE AND api_type = "FHC Geo Spec"');

ELSEIF(filterName = 'fruitsResponse') THEN
	SET @query = CONCAT (' SELECT LAM.application_id AS appId, PM.`fruits_ref_id` AS fruitsRefId, PM.`data_fetched_from_fruits` AS dataFetched
				FROM `loan_application_details`.`profile_master` PM
				INNER JOIN `loan_application_details`.`loan_application_master` LAM ON LAM.profile_id = PM.profile_id AND LAM.application_id = ', whereClause);

ELSEIF(filterName = 'fruitsCropsYearWise') THEN
	SET @query = CONCAT ('SELECT application_id AS applicationId, land_id AS landId , `is_from_year_api` AS yearApi, `year_ref_id` AS cropRefId FROM `agri_loan_application`.`agri_kcc_proposed_crop_details` WHERE `year_ref_id` IS NOT NULL AND application_id = ', whereClause);

ELSEIF(filterName = 'fruitsCrops') THEN
	SET @query = CONCAT (' SELECT application_id AS applicationId, `pm_kishan_id` AS pmKisanId,`farmer_id` AS farmerId,`survery_number` AS surveyNo,`hissa_no` AS hissaNo,`crop_ref_id` AS cropRefId FROM `agri_loan_application`.`agri_kcc_land_details` WHERE `crop_ref_id` IS NOT NULL AND application_id = ', whereClause);

ELSEIF(filterName = 'fruitsTransactionCharge') THEN
	SET @query = CONCAT (' SELECT response AS res FROM`agri_loan_application`.`kcc_fruit_farmer_transaction` WHERE application_id = ',whereClause,' AND status_code = 1 ORDER BY application_id DESC LIMIT 1 ');

ELSEIF(filterName = 'getTransactionList') THEN
	SET @query = CONCAT (' select id, environment as label from `banker_report`.`bank_transaction_report_urls` where is_active = true ');

 END IF;

-- select @query;
PREPARE stmt1 FROM @query;
	EXECUTE stmt1;

END$$

DELIMITER ;