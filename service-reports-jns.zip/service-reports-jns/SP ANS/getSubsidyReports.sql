DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `getSubsidyReports`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `getSubsidyReports`(IN userId BIGINT, IN filterJSON TEXT, IN paginationFROM BIGINT, IN paginationTO BIGINT)
BEGIN

	SET @whereClause  = CONCAT(" WHERE 1=1 AND SNP.status = 4 ");
	
	IF (IFNULL(filterJSON, NULL) IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN 
		-- SCHEME FILTER
		IF filterJSON -> "$.schemeId" IS NOT NULL THEN
			SET @whereClause = CONCAT(@whereClause, " AND FUH.`scheme_id` IN(", JSON_UNQUOTE(filterJSON -> "$.schemeId"),")");
		END IF;
		
		-- ORGANIZATION FILTER
		IF filterJSON -> "$.userOrgId" IS NOT NULL THEN
			SET @whereClause = CONCAT(@whereClause, " AND FUH.`org_id` IN(", JSON_UNQUOTE(filterJSON -> "$.userOrgId"), ")");
		END IF;
		
		-- DATE RANGE FILTER
		IF (filterJSON->"$.fromDate" IS NOT NULL) AND (filterJSON->"$.toDate" IS NOT NULL) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(SNP.`approved_date`) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
		ELSEIF filterJSON->"$.fromDate" IS NOT NULL THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(SNP.`approved_date`) = ', filterJSON->"$.fromDate");
		END IF;
		
		-- APPLICANT NAME FILTER
		IF filterJSON -> "$.applicantNameFilter" IS NOT NULL THEN
			SET @csisApplicantNameFilter = CONCAT(" AND LMD.`borrower_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @padhoApplicantNameFilter = CONCAT(" AND LMD.`borrower_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @drAmbedkarApplicantNameFilter = CONCAT(" AND LMD.`borrower_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @swmsApplicantNameFilter = CONCAT(" AND LCD.`borrower_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @srmsApplicantNameFilter = CONCAT(" AND LMD.`name_of_loanee` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @nulmApplicantNameFilter = CONCAT(" AND LMD.`borrower_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
			SET @nrlmApplicantNameFilter = CONCAT(" AND LMD.`shg_name` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantNameFilter"),"%' ");
		ELSE 
			SET @csisApplicantNameFilter ="";
			SET @padhoApplicantNameFilter ="";
			SET @drAmbedkarApplicantNameFilter ="";
			SET @swmsApplicantNameFilter ="";
			SET @srmsApplicantNameFilter ="";
			SET @nulmApplicantNameFilter ="";
			SET @nrlmApplicantNameFilter ="";
			
		END IF;

		-- APPLICATION CODE FILTER		
		IF filterJSON -> "$.applicantCodeFilter" IS NOT NULL THEN
			SET @csisApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @padhoApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @drAmbedkarApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @swmsApplicantCodeFilter = CONCAT(" AND LCD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @srmsApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @nulmApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
			SET @nrlmApplicantCodeFilter = CONCAT(" AND LMD.`application_code` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.applicantCodeFilter"),"%' ");
		ELSE
			SET @csisApplicantCodeFilter = "";
			SET @padhoApplicantCodeFilter = "";
			SET @drAmbedkarApplicantCodeFilter = "";
			SET @swmsApplicantCodeFilter = "";
			SET @srmsApplicantCodeFilter = "";
			SET @nulmApplicantCodeFilter = "";
			SET @nrlmApplicantCodeFilter = "";
		END IF;
		
		-- MOBILE FILTER
		IF filterJSON -> "$.mobileFilter" IS NOT NULL THEN
			SET @csisMobileFilter = CONCAT(" AND LMD.`mobile_number` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @padhoMobileFilter = CONCAT(" AND LMD.`student_mobile_no` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @drAmbedkarMobileFilter = CONCAT(" AND LMD.`student_mobile_no` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @swmsMobileFilter = CONCAT(" AND LCD.`borrower_mobile_no` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @srmsMobileFilter = ""; -- CONCAT(" AND LMD.`mobile_number` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @nulmMobileFilter = ""; -- CONCAT(" AND LMD.`mobile_number` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
			SET @nrlmMobileFilter = ""; -- CONCAT(" AND LMD.`mobile_number` LIKE '%", JSON_UNQUOTE(filterJSON -> "$.mobileFilter"),"%' ");
		ELSE
			SET @csisMobileFilter = "";
			SET @padhoMobileFilter = "";
			SET @drAmbedkarMobileFilter = "";
			SET @swmsMobileFilter = "";
			SET @srmsMobileFilter = "";
			SET @nulmMobileFilter = "";
			SET @nrlmMobileFilter = "";
		END IF;
	END IF;
	
	SET @commonSelect = " SELECT SNP.`master_id` AS masterId,
			FUH.`scheme_id` AS schemeId,
			FUH.`org_id` AS orgId,
			SM.`name` AS schemeName,
			STM.name AS statusName,
			SNP.`approved_date` AS subsidyApprovedDate,
			SNP.`approved_amount` AS subsidyApprovedAmount, ";
	
	SET @commonTable = " FROM `subsidy_details`.`file_upload_history` FUH
			INNER JOIN `users`.`scheme_master` SM ON SM.`id` = FUH.`scheme_id`
			LEFT JOIN `subsidy_details`.`subsidy_nodel_mapping` SNP ON SNP.`file_upload_id` = FUH.`id`
			INNER JOIN `subsidy_details`.`status_master` STM ON STM.`id` = SNP.`status` ";
	
	SET @query = CONCAT(@commonSelect," 
			LMD.`application_code` AS applicantCode,
			LMD.`borrower_name` AS applicantName,
			LMD.`mobile_number` AS mobile,
			'onHold' AS loanDisbursedDate,
			LCD.`disbursed_amount` AS loanDisbursedAmount
			",@commonTable," LEFT JOIN `subsidy_details`.`csis_master_data` LMD ON LMD.`id` = SNP.`master_id`
			LEFT JOIN `subsidy_details`.`csis_claim_data` LCD ON LCD.`id` = SNP.`claim_id` ", @whereClause, @csisApplicantNameFilter, @csisApplicantCodeFilter, @csisMobileFilter);
	
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," 
			LMD.`application_code` AS applicantCode,
			LMD.`borrower_name` AS applicantName,
			LMD.`student_mobile_no` AS mobile,
			'onHold' AS loanDisbursedDate,
			LCD.`cumulative_amount_disbursed` AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`padho_master_data` LMD ON LMD.`id` = SNP.`master_id`
				LEFT JOIN `subsidy_details`.`padho_claim_data` LCD ON LCD.`id` = SNP.`claim_id` ", @whereClause, @padhoApplicantNameFilter, @padhoApplicantCodeFilter, @padhoMobileFilter);
					
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," 
			LMD.`application_code` AS applicantCode,
			LMD.`borrower_name` AS applicantName,
			LMD.`student_mobile_no` AS mobile,
			'onHold' AS loanDisbursedDate,
			LCD.`cumulative_amount_disbursed` AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`dr_ambedkar_master_data` LMD ON LMD.`id` = SNP.`master_id`
				LEFT JOIN `subsidy_details`.`dr_ambedkar_claim_data` LCD ON LCD.`id` = SNP.`claim_id` ", @whereClause, @drAmbedkarApplicantNameFilter, @drAmbedkarApplicantCodeFilter, @drAmbedkarMobileFilter);
					
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," 
			LCD.`application_code` AS applicantCode,
			LCD.`borrower_name` AS applicantName,
			LCD.`borrower_mobile_no` AS mobile,
			'onHold' AS loanDisbursedDate,
			'onHold' AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`swms_claim_data` LCD ON LCD.`id` = SNP.`claim_id` ", @whereClause, @swmsApplicantNameFilter, @swmsApplicantCodeFilter, @swmsMobileFilter);
					
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," LMD.`application_code` AS applicantCode,
			LMD.`name_of_loanee` AS applicantName,
			'onHold' AS mobile,
			'onHold' AS loanDisbursedDate,
			'onHold' AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`srms_master_data` LMD ON LMD.`id` = SNP.`master_id` ", @whereClause, @srmsApplicantNameFilter, @srmsApplicantCodeFilter, @srmsMobileFilter);
					
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," 
			LMD.`application_code` AS applicantCode,
			LMD.`borrower_name` AS applicantName,
			'onHold' AS mobile,
			LCD.`disbursed_date` AS loanDisbursedDate,
			LCD.`disbursed_amount` AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`nulm_ind_master_data` LMD ON LMD.`id` = SNP.`master_id`
				LEFT JOIN `subsidy_details`.`nulm_ind_claim_data` LCD ON LCD.`id` = SNP.`claim_id` ", @whereClause, @nulmApplicantNameFilter, @nulmApplicantCodeFilter, @nulmMobileFilter);
				
	SET @query = CONCAT(@query, " UNION ALL ",@commonSelect," 
			LMD.`application_code` AS applicantCode,
			LMD.`shg_name` AS applicantName,
			'onHold' AS mobile,
			'onHold' AS loanDisbursedDate,
			LCD.`disbursed_amount` AS loanDisbursedAmount
				",@commonTable," LEFT JOIN `subsidy_details`.`nrlm_master_data` LMD ON LMD.`id` = SNP.`master_id`
				LEFT JOIN `subsidy_details`.`nrlm_claim_data` LCD ON LCD.`id` = SNP.`claim_id`  ", @whereClause, @nrlmApplicantNameFilter, @nrlmApplicantCodeFilter, @nrlmMobileFilter);
				
-- 	SET @orderBy = ' ORDER BY EPD.modified_date DESC ';

	SET @totalCountQuery = CONCAT('SELECT COUNT(DATA.masterId) INTO @totalCount FROM ( ', @query, ' ) AS DATA');
	PREPARE cntstmt FROM @totalCountQuery;
	EXECUTE cntstmt;

	SET @limit = CONCAT( " LIMIT ", paginationFROM, " , " , paginationTO);		
	SET @orderBy = " ORDER BY subsidyApprovedDate DESC ";
	
	SET @query = CONCAT(@query, @orderBy, @limit);
	
-- 	select @query;
	SET @mainQry = CONCAT(" SELECT @totalCount AS totalCount,
				temp.masterId AS masterId,
				temp.orgId AS orgId,
				temp.applicantCode AS applicantCode,
				temp.applicantName AS applicantName,
				temp.mobile AS mobile,
				temp.schemeId AS schemeId,
				temp.schemeName AS schemeName,
				temp.statusName AS statusName,
				temp.loanDisbursedDate AS loanDisbursedDate,
				temp.loanDisbursedAmount AS loanDisbursedAmount,
				temp.subsidyApprovedDate AS subsidyApprovedDate,
				temp.subsidyApprovedAmount AS subsidyApprovedAmount FROM( ",@query,") temp");
	
	PREPARE stmt FROM @mainQry ;
	EXECUTE stmt;
END$$

DELIMITER ;