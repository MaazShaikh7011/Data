DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetSchemeWiseGetStatusReportData_V3`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetSchemeWiseGetStatusReportData_V3`(IN requestJSON TEXT, IN userId BIGINT)
BEGIN
	DECLARE filterJSON TEXT;
	DECLARE schemeIdList TEXT;
	
	SET filterJSON = IF(requestJSON -> "$.filterJSON" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.filterJSON") != 'null', JSON_UNQUOTE(requestJSON -> "$.filterJSON"), NULL);
	
	SET @whereClause = " WHERE EPD.is_active = TRUE ";
	
	SELECT GROUP_CONCAT(scheme_id) INTO schemeIdList FROM users.user_role_product_mapping WHERE user_id = userId AND is_active = TRUE;
	SET @whereClause  = CONCAT(@whereClause, ' AND EPD.sch_type_id IN (', schemeIdList, ') ');
	
-- 	SELECT user_org_id, user_role_id, branch_id INTO @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;
	CALL users.spFetchBranchListByUserId(userId, NULL, @branchId, @orgId);
	IF (@branchId IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.branch_id IN', @branchId);
	ELSEIF (@orgId  IS NOT NULL) THEN		
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.org_id = ', @orgId);
	ELSE
		SET @whereClause = CONCAT(@whereClause, ' AND 1 = 2 ');
	END IF;
	
	IF (IFNULL(filterJSON, NULL) IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN
		-- Date Filter
		IF ((filterJSON -> "$.fromDate" IS NOT NULL) AND (filterJSON -> "$.toDate" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(journey_completion_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
		END IF;
		-- Source Filter
		IF (filterJSON->"$.appSourceId" IS NOT NULL ) THEN
			IF (filterJSON->"$.appSourceId" = 'MP') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND campaign_master_id = 1 ');
			ELSEIF (filterJSON->"$.appSourceId" = 'BS') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND campaign_master_id != 1 AND campaign_master_id IS NOT NULL');
			END IF;
		END IF;
		-- app TypeId
		IF (filterJSON->"$.appTypeId" IS NOT NULL ) THEN
			IF (filterJSON->"$.appTypeId" = 'approved') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND is_offline = FALSE ');
			ELSEIF (filterJSON->"$.appTypeId" = 'referred')THEN
				SET @whereClause = CONCAT(@whereClause, ' AND is_offline = TRUE ');
			END IF;
		END IF;
	END IF;
	
	SET @selectQuery = " SELECT 
			sch_type_id AS schemeId,
			SM.name AS schemeName,
			SUM(CASE WHEN (EPD.proposal_status_id = 1) THEN 1 ELSE 0 END) AS completed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 3) THEN 1 ELSE 0 END) AS disbursed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 5) THEN 1 ELSE 0 END) AS hold, 
			SUM(CASE WHEN (EPD.proposal_status_id = 6) THEN 1 ELSE 0 END) AS holeAftrSanction, 
			SUM(CASE WHEN (EPD.proposal_status_id = 8) THEN 1 ELSE 0 END) AS partialDisbursed, 
			SUM(CASE WHEN (EPD.proposal_status_id = 4) THEN 1 ELSE 0 END) AS rejected,
			SUM(CASE WHEN (EPD.proposal_status_id = 7) THEN 1 ELSE 0 END) AS rejectAfterSanction,
			SUM(CASE WHEN (EPD.proposal_status_id = 10) THEN 1 ELSE 0 END) AS rejectOffileConfiguration,
			SUM(CASE WHEN (EPD.proposal_status_id = 2) THEN 1 ELSE 0 END) AS sanctioned,
			SUM(CASE WHEN (EPD.proposal_status_id != 9) THEN 1 ELSE 0 END) AS grandTotal ";
	
	SET @commonTableQuery = " FROM `banker_report`.`proposal_data` EPD  INNER JOIN users.scheme_master SM ON SM.id = EPD.sch_type_id ";
	
	SET @groupByQuery = " GROUP BY EPD.sch_type_id ";
	
	SET @query = CONCAT(@selectQuery, @commonTableQuery, @whereClause, @groupByQuery);
-- 	SELECT @query;
	PREPARE stmt FROM @query;
	EXECUTE stmt;
-- 	CALL spGetSchemeWiseGetStatusReportData_V3('{"filterJSON":{"fromDate":"2022-01-01", "toDate":"2022-10-31"}}', 74312);

END$$

DELIMITER ;