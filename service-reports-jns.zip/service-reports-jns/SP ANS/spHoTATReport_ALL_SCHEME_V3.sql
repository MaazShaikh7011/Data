DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spHoTATReport_ALL_SCHEME_V3`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spHoTATReport_ALL_SCHEME_V3`(IN requestJSON TEXT, IN orgId BIGINT,IN userId BIGINT)
BEGIN

  DECLARE X INT DEFAULT 0;
  DECLARE Y INT DEFAULT 0;

  DECLARE selectedSchemeId TEXT;
  DECLARE filterJSON TEXT;
  DECLARE dataType TEXT;
  
  SET selectedSchemeId = IF(requestJSON -> "$.schemeId" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.schemeId") != 'null', JSON_UNQUOTE(requestJSON -> "$.schemeId"), NULL);
  IF (selectedSchemeId IS NULL AND userId IS NOT NULL)
  THEN
	SELECT GROUP_CONCAT(scheme_id) INTO selectedSchemeId FROM users.user_role_product_mapping WHERE user_id = userId AND is_active = TRUE;
  END IF;
  
  SET filterJSON = IF(requestJSON -> "$.filterJSON" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.filterJSON") != 'null', JSON_UNQUOTE(requestJSON -> "$.filterJSON"), NULL);
  SET dataType = IF(requestJSON -> "$.dataType" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.dataType") != 'null', JSON_UNQUOTE(requestJSON -> "$.dataType"), NULL); -- Sanction or Disburse

  SELECT user_org_id,user_role_id,branch_id INTO @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;

  IF (@userRoleId = 13 OR @userRoleId = 14 OR @userRoleId = 15) THEN
  SET @query = "SELECT JSON_ARRAYAGG(tmp.branchId) INTO @branch_id_list FROM ( SELECT DISTINCT  bp.branch_id AS branchId from `users`.`branch_product_mapping` bp 
		INNER JOIN `users`.`branch_master` bm on bm.`id` = bp.`branch_id` and bm.`branch_type` = 1
		where bp.is_active = true";
		
		-- RO
		IF (@userRoleId = 13) THEN
			SET @query = CONCAT(@query, " AND bp.`branch_ro_id` = @userbranchId ");
		-- ZO
		ELSEIF (@userRoleId = 14) THEN
			SET @query = CONCAT(@query, " AND bp.`branch_zo_id` = @userbranchId ");
		-- LHO
		ELSEIF (@varUserRoleId = 15) THEN
			SET @query = CONCAT(@query, " AND bp.`branch_lho_id` = @userbranchId ");
  END IF;
  
  SET @query = CONCAT(@query, ') tmp');

PREPARE branch_id FROM @query;
EXECUTE branch_id;
END IF;

SET X = 0;

SET @schIdWC = IF(selectedSchemeId IS NULL, ' AND 1=1 ', CONCAT(' AND FIND_IN_SET(sch_type_id, ''', selectedSchemeId, ''') '));
SET @propTableWC = IF(selectedSchemeId IS NULL, ' AND 1=1 ', CONCAT(' AND FIND_IN_SET(scheme_id, ''', selectedSchemeId, ''') '));
  

  DROP TEMPORARY TABLE IF EXISTS temp_data;
  CREATE TEMPORARY TABLE temp_data (
    `monthName` VARCHAR(50),
    monthDate DATE,
    `applicationCount` BIGINT,
    `median` INT,
    `avaerage` INT
  );
  
   DROP TEMPORARY TABLE IF EXISTS proposal_temp_table;
    CREATE TEMPORARY TABLE proposal_temp_table (
      proposal_id BIGINT,
      journey_completion_date DATETIME,
      table_name VARCHAR(500),
      audit_table_name VARCHAR(500)
    );

  IF (dataType = 'Sanctioned') THEN
    SET @propStatusWhereClause = '(2)';
  ELSE
    SET @propStatusWhereClause = '(3,8)';
  END IF;

  SET @whereClause = CONCAT(' journey_completion_date IS NOT NULL AND is_active = 1 ');
  
  IF (orgId IS NOT NULL) THEN
    SET @whereClause = CONCAT(@whereClause, ' AND org_id = ', orgId);
  END IF;
  
  
 IF (@branch_id_list IS NOT NULL) THEN
	SELECT REPLACE(REPLACE(@branch_id_list,'[','('),']',')') INTO @branch_id_list1;
	SET @whereClause  = CONCAT(@whereClause, ' AND branch_id IN ', @branch_id_list1);
 END IF;

 IF(@userRoleId = 9) THEN
 	SET @whereClause  = CONCAT(@whereClause, ' AND branch_id = ', @userbranchId);
 END IF;

  IF (IFNULL(filterJSON, NULL) IS NOT NULL
    AND filterJSON != ''
    AND filterJSON != '{}') THEN
    IF ((filterJSON -> "$.fromDate" IS NOT NULL)
      AND (filterJSON -> "$.toDate" IS NOT NULL)) THEN
      SET @whereClause = CONCAT(@whereClause, ' AND DATE(journey_completion_date) BETWEEN ', filterJSON -> "$.fromDate", ' AND ', filterJSON -> "$.toDate");
    END IF;

    IF (filterJSON -> "$.appSourceId" IS NOT NULL) THEN
      IF (filterJSON -> "$.appSourceId" = 'MP') THEN
        SET @whereClause = CONCAT(@whereClause, ' AND application_id IN (SELECT application_id FROM loan_application_details.loan_application_master WHERE campaign_master_id IS NULL OR campaign_master_id = 1)');
      ELSEIF (filterJSON -> "$.appSourceId" = 'BS') THEN
        SET @whereClause = CONCAT(@whereClause, ' AND application_id IN (SELECT application_id FROM loan_application_details.loan_application_master WHERE campaign_master_id IS NOT NULL AND campaign_master_id != 1)');
      END IF;
    END IF;

    IF (filterJSON -> "$.appTypeId" IS NOT NULL) THEN
      IF (filterJSON -> "$.appTypeId" = 'approved') THEN
        SET @whereClause = CONCAT(@whereClause, ' AND is_offline = FALSE ');
      ELSEIF (filterJSON -> "$.appTypeId" = 'referred') THEN
        SET @whereClause = CONCAT(@whereClause, ' AND is_offline = TRUE ');
      END IF;
    END IF;
    
    IF filterJSON -> "$.selectedBank" IS NOT NULL THEN
	SET @whereClause = CONCAT(@whereClause, ' AND org_id IN(',JSON_UNQUOTE(filterJSON -> "$.selectedBank"),')');
    END IF;
  END IF;
  
  WHILE X < 12 DO
	    DROP TEMPORARY TABLE IF EXISTS temp_table;
	    CREATE TEMPORARY TABLE temp_table (
	      propId INT,
	      daysCount INT
	    );
    
	    DROP TEMPORARY TABLE IF EXISTS proposal_temp_table;
	    CREATE TEMPORARY TABLE proposal_temp_table (
	      proposal_id BIGINT,
	      journey_completion_date DATETIME,
	      table_name VARCHAR(500),
	      audit_table_name VARCHAR(500)
	    );

	    SET @loopCnt = 0;
	    SET @totalAppCntQuery = NULL;
	    SET @totalAppCntSumQuery = NULL;
  
	    SET @applicationCountQuery = CONCAT('SELECT COUNT(*) AS totalAppCount FROM `banker_report`.`proposal_data` 
                                                WHERE ', @whereClause,@schIdWC, '
                                                AND MONTH(journey_completion_date) = MONTH((DATE_SUB(curdate(), INTERVAL ', X, ' MONTH)))
                                                AND YEAR(journey_completion_date) = YEAR((DATE_SUB(curdate(), INTERVAL ', X, ' MONTH)))');

            SET @totalAppCntQuery = CONCAT(IF(@totalAppCntQuery IS NOT NULL, CONCAT(@totalAppCntQuery, ' UNION ALL '), ''), @applicationCountQuery);
            SET @totalAppCntSumQuery = CONCAT('SELECT SUM(totalAppCount) INTO @applicationCount FROM (', @applicationCountQuery, ' ) AS DATA');
      
      
	    SET @insertQuery = CONCAT('INSERT INTO proposal_temp_table(proposal_id, journey_completion_date, table_name, audit_table_name)
				SELECT DISTINCT proposal_id, journey_completion_date,schema_table_name,schema_audit_table_name  FROM `banker_report`.`proposal_data`
				 WHERE ', @whereClause,@schIdWC, '
				AND MONTH(journey_completion_date) = MONTH((DATE_SUB(curdate(), INTERVAL ', X, ' MONTH)))
				AND YEAR(journey_completion_date) = YEAR((DATE_SUB(curdate(), INTERVAL ', X, ' MONTH)))
				  AND (proposal_status_id IN ', @propStatusWhereClause,'AND proposal_status_id IS NOT NULL )');


	PREPARE applicationForLoopCountQuery FROM @insertQuery;
	EXECUTE applicationForLoopCountQuery;

	-- PREPARE applicationCountQuery FROM @totalAppCntSumQuery;
	-- EXECUTE applicationCountQuery;

	    SELECT
	      COUNT(*) INTO @applicationForLoopCount
	    FROM proposal_temp_table;
    

     IF @applicationForLoopCount > 0 THEN
     SET Y = 0;
     WHILE Y < @applicationForLoopCount DO

        SET @proposalQuery = CONCAT('SELECT journey_completion_date, proposal_id, audit_table_name INTO @startDate, @proposalId, @proposalAuditTable FROM  proposal_temp_table  LIMIT ', Y, ', 1');

        PREPARE proposalQuery FROM @proposalQuery;
        EXECUTE proposalQuery;


        IF (dataType = 'Sanctioned') THEN
          SET @proposalAuditQuery = CONCAT('SELECT changed_date INTO @endDate FROM ',@proposalAuditTable,' WHERE proposal_id = @proposalId AND (proposal_status_id IS NOT NULL AND journey_completion_date IS NOT NULL) ORDER BY id DESC LIMIT 1');
        ELSE
          SET @proposalAuditQuery = CONCAT('SELECT changed_date INTO @endDate FROM ',@proposalAuditTable,' WHERE proposal_id = @proposalId AND (proposal_status_id = 2) ORDER BY id DESC LIMIT 1');
        END IF;

        PREPARE proposalAuditQuery FROM @proposalAuditQuery;
        EXECUTE proposalAuditQuery;
	-- select @endDate, @startDate, @proposalId, @proposalAuditTable;
        SELECT
          DATEDIFF(@endDate, @startDate) INTO @days;
        INSERT INTO temp_table
          VALUES (@proposalId, @days);

        SET Y = Y + 1;
        
          END WHILE;
    END IF;

    INSERT INTO temp_data
      SELECT
        CONCAT(MONTHNAME((DATE_SUB(CURDATE(), INTERVAL X MONTH))), ' - ', YEAR((DATE_SUB(CURDATE(), INTERVAL X MONTH)))),
        DATE_SUB(LAST_DAY(DATE_SUB(CURDATE(), INTERVAL X MONTH)), INTERVAL DAY(LAST_DAY(DATE_SUB(CURDATE(), INTERVAL X MONTH))) - 1 DAY),
--         @applicationCount,
        COUNT(propId),  
        ((SUBSTRING_INDEX (SUBSTRING_INDEX (GROUP_CONCAT(daysCount ORDER BY daysCount), ',', FLOOR(1 + ((COUNT(daysCount) - 1) / 2))), ',', -1))
        +
        (SUBSTRING_INDEX (SUBSTRING_INDEX (GROUP_CONCAT(daysCount ORDER BY daysCount), ',', CEILING(1 + ((COUNT(daysCount) - 1) / 2))), ',', -1))) / 2,
        AVG(daysCount)
      FROM temp_table;

    SET X = X + 1;
  END WHILE;

  SELECT
    *
  FROM temp_data WHERE monthDate > '2021-12-31';

END$$

DELIMITER ;