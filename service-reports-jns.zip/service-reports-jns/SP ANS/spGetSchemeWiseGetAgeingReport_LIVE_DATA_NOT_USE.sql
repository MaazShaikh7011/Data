DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spGetSchemeWiseGetAgeingReport_LIVE_DATA_NOT_USE`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetSchemeWiseGetAgeingReport_LIVE_DATA_NOT_USE`(IN requestJSON TEXT, IN userId BIGINT)
BEGIN

	SELECT user_org_id, user_role_id, branch_id INTO @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;
	
	SET @whereClause = " WHERE EPD.proposal_status_id IS NOT NULL AND EPD.journey_completion_date IS NOT NULL AND EPD.is_active = TRUE ";
	
	SET @selectQuery = " SELECT
			SUM(CASE WHEN (DATEDIFF(CURDATE(), journey_completion_date) BETWEEN 0 AND 15) THEN 1 ELSE 0 END) AS 'interval1',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), journey_completion_date) BETWEEN 16 AND 30) THEN 1 ELSE 0 END) AS 'interval2',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), journey_completion_date) BETWEEN 31 AND 45) THEN 1 ELSE 0 END) AS 'interval3',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), journey_completion_date) BETWEEN 46 AND 60) THEN 1 ELSE 0 END) AS 'interval4',
			SUM(CASE WHEN (DATEDIFF(CURDATE(), journey_completion_date) > 60) THEN 1 ELSE 0 END) AS 'interval5',
			COUNT(EPD.journey_completion_date) AS 'Grand Total',
			sch_type_id AS schemeId,
			SM.name AS schemeName ";
	
	SET @commonTableQuery = " INNER JOIN users.scheme_master SM ON SM.id = EPD.sch_type_id ";
	
	SET @groupByQuery = " GROUP BY sch_type_id ";
	
	SET @query = CONCAT(@selectQuery, " FROM `loan_application_details`.`edu_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.scheme_ineligible = FALSE  ", @groupByQuery," UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`agri_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.is_redirected = FALSE  ", @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`hl_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.scheme_ineligible = FALSE  ", @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`msme_proposal_details` EPD  ", @commonTableQuery, @whereClause, @groupByQuery, " UNION ALL ",
		@selectQuery, " FROM `loan_application_details`.`livelihood_proposal_details` EPD  ", @commonTableQuery, @whereClause, " AND EPD.is_redirected = FALSE  ", @groupByQuery);
	PREPARE stmt FROM @query;
	EXECUTE stmt;
-- 	select @query;
-- 	CALL spGetSchemeWiseGetAgeingReport_LIVE_DATA_NOT_USE('{}',74312);
END$$

DELIMITER ;