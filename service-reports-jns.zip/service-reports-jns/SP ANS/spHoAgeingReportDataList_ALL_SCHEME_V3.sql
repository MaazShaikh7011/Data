DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spHoAgeingReportDataList_ALL_SCHEME_V3`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spHoAgeingReportDataList_ALL_SCHEME_V3`(IN requestJSON TEXT, IN orgId BIGINT,IN userId BIGINT)
BEGIN

  DECLARE selectedSchemeId TEXT;
  DECLARE filterJSON TEXT;
  
  SET @query = NULL;
  SET selectedSchemeId = IF(requestJSON -> "$.schemeId" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.schemeId") != 'null', JSON_UNQUOTE(requestJSON -> "$.schemeId"), NULL);
  SET filterJSON = IF(requestJSON -> "$.filterJSON" IS NOT NULL AND JSON_UNQUOTE(requestJSON -> "$.filterJSON") != 'null', JSON_UNQUOTE(requestJSON -> "$.filterJSON"), NULL);
  
  IF (selectedSchemeId IS NULL AND userId IS NOT NULL)
  THEN
	SELECT GROUP_CONCAT(scheme_id) INTO selectedSchemeId FROM users.user_role_product_mapping WHERE user_id = userId AND is_active = TRUE;
  END IF;

  SET @group1Query = NULL;
  SET @group2Query = NULL;
  SET @group3Query = NULL;

SELECT user_org_id,user_role_id,branch_id INTO @userOrgId, @userRoleId, @userbranchId FROM users.users WHERE user_id = userId;

IF (@userRoleId = 13 OR @userRoleId = 14 OR @userRoleId = 15) THEN
	SET @query = "SELECT JSON_ARRAYAGG(tmp.branchId) INTO @branch_id_list FROM ( SELECT DISTINCT  bp.branch_id AS branchId from `users`.`branch_product_mapping` bp 
			INNER JOIN `users`.`branch_master` bm on bm.`id` = bp.`branch_id` and bm.`branch_type` = 1
			where bp.is_active = true";
			-- RO
			IF (@userRoleId = 13) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_ro_id` = @userbranchId ");
			-- ZO
			ELSEIF (@userRoleId = 14) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_zo_id` = @userbranchId ");
			
			-- LHO
			ELSEIF (@varUserRoleId = 15) THEN
				SET @query = CONCAT(@query, " AND bp.`branch_lho_id` = @userbranchId ");
END IF;
SET @query = CONCAT(@query, ') tmp');

PREPARE branch_id FROM @query;
EXECUTE branch_id;
END IF;

  SET @schIdWC = IF(selectedSchemeId IS NULL, ' AND 1=1 ', CONCAT(' AND FIND_IN_SET(sch_type_id, ''', selectedSchemeId, ''') '));
  
  SET @whereClause = CONCAT(' AND proposal_status_id IN(1,5,6) ');

  IF (orgId IS NOT NULL AND filterJSON -> "$.selectedBank" IS NULL) THEN
	SET @whereClause = CONCAT(@whereClause, ' AND pd.org_id = ', orgId);
  ELSEIF (orgId IS  NULL AND filterJSON -> "$.selectedBank" IS NOT NULL) THEN
	SET @whereClause = CONCAT(@whereClause,' AND pd.org_id IN(',JSON_UNQUOTE(filterJSON -> "$.selectedBank"),') ');
  ELSEIF (orgId IS NOT NULL AND filterJSON -> "$.selectedBank" IS NOT NULL) THEN
	SET @whereClause = CONCAT(@whereClause,' AND pd.org_id IN(',JSON_UNQUOTE(filterJSON -> "$.selectedBank"),',',orgId,') ');
  END IF;
  
  IF (@branch_id_list IS NOT NULL) THEN
	        SELECT REPLACE(REPLACE(@branch_id_list,'[','('),']',')') INTO @branch_id_list1;
		SET @whereClause  = CONCAT(@whereClause, ' AND pd.branch_id IN ', @branch_id_list1);
  END IF;
  
  IF (@userRoleId = 9 ) THEN 
 	SET @whereClause = CONCAT(@whereClause, ' AND pd.branch_id = ', @userbranchId);	
  END IF;
   
  IF (IFNULL(filterJSON, NULL) IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN
	
	IF ((filterJSON -> "$.fromDate" IS NOT NULL) AND (filterJSON -> "$.toDate" IS NOT NULL)) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND DATE(pd.journey_completion_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
        END IF;
        
        IF (filterJSON->"$.appSourceId" IS NOT NULL ) THEN
		IF (filterJSON->"$.appSourceId" = 'MP') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND pd.campaign_master_id = 1 ');
		ELSEIF (filterJSON->"$.appSourceId" = 'BS') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND pd.campaign_master_id != 1 AND campaign_master_id IS NOT NULL');
		END IF;
        END IF;
        
        IF (filterJSON->"$.appTypeId" IS NOT NULL ) THEN
		IF (filterJSON->"$.appTypeId" = 'approved') THEN
			SET @whereClause = CONCAT(@whereClause, ' AND pd.is_offline = FALSE ');
		ELSEIF (filterJSON->"$.appTypeId" = 'referred')THEN
			SET @whereClause = CONCAT(@whereClause, ' AND pd.is_offline = TRUE ');
		END IF;
        END IF;
        
  END IF; 
  
	SET @selectQuery = " SELECT pd.`proposal_id` as proposalId,pd.`application_id` as applicationId,sm.`name` as schemeName,pd.`journey_completion_date` as journeyCompletionDate ,
			pd.`branch_name` as branchname,bm.`code` as branchCode,pd.`state_name` as branchState,pd.`ro_name` as roname,pd.`zo_name` as zoname,
			IF(pd.is_offline = 0,'Digital Approval' , 'Referred') as stage,
			psm.`name` as proposalstatus,pd.`loan_amount_required` as appliedamount,pd.`el_amount` as eligibleamount,DATEDIFF(CURDATE(), pd.journey_completion_date) as days,pd.`application_code`
			,IF(pd.`campaign_master_id` = 1 OR pd.`campaign_master_id` = NULL,'Market Place' , pd.`organisation_name`) as source,pd.`organisation_name`,banker_report.decValue(pm.`name`) as applicantname
			,ptd.`partner_name` as partnername,ptd.`partner_code` as partnercode,ct.`city_name` as branchcity  ";
			
	SET @tableQuery = " from `banker_report`.`proposal_data` pd
			INNER JOIN `scheme_details`.`scheme_master` sm ON pd.`sch_type_id` =  sm.`id`
			INNER JOIN `users`.`branch_master` bm ON pd.`branch_id` = bm.`id`
			INNER JOIN `loan_application_details`.`profile_master` pm ON pd.`profile_id` = pm.`profile_id`
			INNER JOIN `loan_application_details`.`proposal_status_master` psm ON pd.`proposal_status_id` = psm.`id`
			LEFT JOIN `partner_config`.`partner_details` ptd ON pd.`user_id` = ptd.`partner_id`
			INNER JOIN `one_form`.`city` ct ON pd.`city_id` = ct.`id` ";
			
	SET @commonWhereClause = CONCAT(" WHERE pd.is_active = 1 ", @whereClause, @schIdWC);
  
	SET @query = CONCAT(@selectQuery , " ,'0 - 15 Days' AS agingGroup ",@tableQuery,@commonWhereClause," AND DATEDIFF(CURDATE(), pd.journey_completion_date)  BETWEEN 0 AND 15
		UNION ALL " , @selectQuery ," ,'16-30 Days Days' as agingGroup ",@tableQuery,@commonWhereClause," AND DATEDIFF(CURDATE(), pd.journey_completion_date)  BETWEEN 16 AND 30
		UNION ALL " , @selectQuery ," ,'31-45 Days Days' as agingGroup ",@tableQuery,@commonWhereClause," AND DATEDIFF(CURDATE(), pd.journey_completion_date)  BETWEEN 31 AND 45
		UNION ALL " , @selectQuery ," ,'46-60 Days Days' as agingGroup ",@tableQuery,@commonWhereClause," AND DATEDIFF(CURDATE(), pd.journey_completion_date)  BETWEEN 46 AND 60
		UNION ALL " , @selectQuery," ,'Above 60 days' as agingGroup ",@tableQuery,@commonWhereClause," AND DATEDIFF(CURDATE(), pd.journey_completion_date) > 60 ");

	PREPARE group1Query FROM @query;
	EXECUTE group1Query;

END$$

DELIMITER ;