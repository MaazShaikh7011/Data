DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spHoApprovedList_ALL_SCHEME`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spHoApprovedList_ALL_SCHEME`(IN selectedSchemeId TEXT, IN pageType VARCHAR(255), IN filterJSON TEXT, IN columnFilter TEXT, IN orgId BIGINT, IN roleId BIGINT, IN userId BIGINT, IN userBranchId BIGINT, IN noPagination VARCHAR(255), IN paginationFROM BIGINT, IN paginationTO BIGINT)
BEGIN
	SET @whereClause = CONCAT(' WHERE TRUE ');
	
	IF (roleId = 5 OR roleId = 9 OR roleId = 10 OR roleId = 11 OR roleId = 13 OR roleId = 14 OR roleId = 15) THEN
		CALL users.spFetchBranchListByUserId(userId, NULL, @branchIdList, @orgId);
		IF (@branchIdList IS NOT NULL) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.branch_id IN', @branchIdList);
		ELSEIF(@orgId IS NOT NULL) THEN		
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.org_id = ', @orgId);
		ELSE
			SET @whereClause = CONCAT(@whereClause, ' AND 1 = 2');
		END IF;
	END IF;

	IF (selectedSchemeId IS NULL AND userId IS NOT NULL) THEN
		SELECT GROUP_CONCAT(scheme_id) INTO selectedSchemeId FROM users.user_role_product_mapping WHERE user_id = userId AND is_active = TRUE AND scheme_id != -1;
	END IF;
	
	SET @whereClause = CONCAT(@whereClause, ' AND FIND_IN_SET(EPD.sch_type_id, "', selectedSchemeId,'")');
	
	-- SET @applicantColumnHeader = IF(schemeId = 8 OR schemeId = 9 OR schemeId = 11, 'Organization Name', 'Applicant Name');
	SET @applicantColumnHeader = 'Applicant Name';
	IF (pageType = 'approved') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Approved Date","columnName":"approveDate","viewType":"date"},{"displayName":"Approved Amount","columnName":"approveAmount","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id IN (1,2,3,4,5,6,7,8,9)  AND EPD.is_offline = 0 ');
	ELSEIF (pageType = 'referred') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Referred Date","columnName":"approveDate","viewType":"date"},{"displayName":"Req. Loan Amount","columnName":"requiredAmount","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id IN (1,2,3,4,5,6,7,8,9)  AND EPD.is_offline = 1 ');
	ELSEIF (pageType = 'hold') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Hold Date","columnName":"holdDate","viewType":"date"},{"displayName":"Req. amount","columnName":"approveAmount","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND (EPD.proposal_status_id IN (5,6))');
	ELSEIF (pageType = 'disbursed') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Disbursed Date","columnName":"disbursedDate","viewType":"date"},{"displayName":"Disbursed Amount","columnName":"disbursedAmt","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id IN (3,8) ');
	ELSEIF (pageType = 'sanctioned') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Sanction Date","columnName":"sanctionedDate","viewType":"date"},{"displayName":"Sanction Amount","columnName":"sanctionedAmt","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id IN (2) ');
	ELSEIF (pageType = 'reject') THEN
		SET @tableColumns = CONCAT('[{"displayName":"', @applicantColumnHeader, '<br/>Application Code","columnName":"name"},{"displayName":"Contact","columnName":"contact"},{"displayName":"PAN","columnName":"pan"},{"displayName":"Scheme","columnName":"schemeName"},{"displayName":"Status","columnName":"status"},{"displayName":"Rejected Date","columnName":"rejectedDate","viewType":"date"},{"displayName":"Req. Loan Amount","columnName":"requiredAmount","viewType":"amount"}]');
		SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id IN (4,7,10) ');
	END IF;
	
	SET @selectDataQuery = CONCAT(' 
		EPD.application_id AS applicationId,
		EPD.application_code AS applicationCode,
		CONCAT_WS("",EPD.email, "<br/>", EPD.mobile) AS contact,
		EPD.email AS email,
		EPD.mobile AS mobile,
		banker_report.decValue(PROF.pan) AS pan,
		CONCAT(banker_report.decValue(PROF.name), "<br/>", EPD.application_code) AS name,
		banker_report.decValue(PROF.name) AS applicantName,
		(CASE WHEN (EPD.proposal_status_id = 1 AND EPD.is_offline = 0) THEN "Approved" WHEN (EPD.proposal_status_id = 1 AND EPD.is_offline = 1) THEN "Referred" ELSE PSM.display_name END) AS `status`,
		IF(EPD.is_from_reverse_api,"Reverse API","Online Interface") AS isFromReverseApi,
		EPD.rejection_reason AS rejectionReason,
		SM.short_name AS schemeName,
		EPD.journey_completion_date AS approveDate,
		IF(EPD.is_offline = 0, EPD.el_amount, EPD.loan_amount_required) AS approveAmount,
		EPD.el_tenure AS tenure,
		EPD.branch_code AS branchCode, 
		EPD.branch_name AS branchName,
		IF(EPD.campaign_master_id = 1, "Market Place", "Bank Specific" ) AS campaignType,
		EPD.loan_amount_required AS requiredAmount,
		EPD.zo_name AS zonalOffice,
		EPD.ro_name AS regionalOffice,
		EPD.branch_street_name AS branchAddress, 
		PM.product_name AS productName, 
		EPD.el_roi AS roi,
		EPD.el_emi AS emi,
		LM.name AS typeofLoan,
		(CASE WHEN PM.is_active = 1 THEN "Active" ELSE "Inactive" END) AS productStatus,
		EPD.el_processing_fee AS processingFee,
		EPD.sanction_date AS sanctionedDate,
		EPD.sanction_amount AS sanctionedAmt,
		EPD.disbursement_date AS disbursedDate,
		EPD.total_disbursed_amount AS disbursedAmt,
		EPD.`changed_date` AS holdDate,
		EPD.`changed_date` AS rejectedDate,
		EPD.org_id AS orgId,
		EPD.display_org_name AS orgName,

        IF(EPD.`sch_type_id` = 8 ,(CASE WHEN SLD.loan_purpose = 1 THEN "Working Capital" WHEN SLD.loan_purpose = 2 THEN "Term Loan" ELSE "" END),
        IF(EPD.`sch_type_id` = 9,(CASE WHEN MLD.purpose_of_loan = 1 THEN "Working Capital" WHEN MLD.purpose_of_loan = 2 THEN "Term Loan" ELSE "" END),""))  AS loanPurpose,			
        EPD.sch_type_id AS schemeId,       	       
       	       
		JSON_ARRAY(
			JSON_OBJECT("key", "Branch Name", "value", EPD.branch_name),
			JSON_OBJECT("key", "Branch Code","value", EPD.branch_code), 
			JSON_OBJECT("key", "Branch Address","value", EPD.branch_street_name),
			JSON_OBJECT("key", "Regional Office","value", EPD.ro_name), 
			JSON_OBJECT("key", "Zonal Office","value", EPD.zo_name),
			JSON_OBJECT("key", "Checker Email Id", "value", (SELECT banker_report.decValue(email) FROM users.users WHERE branch_id = EPD.branch_id AND user_role_id = 9 LIMIT 1)),
			JSON_OBJECT("key", "Checker Mobile", "value", (SELECT banker_report.decValue(mobile) FROM users.users WHERE branch_id = EPD.branch_id AND user_role_id = 9 LIMIT 1)),
			JSON_OBJECT("key", "Rejected Reason", "value", "") -- remain EPD.rejection_reason
		)  AS branchObj,

		JSON_ARRAY(
		    JSON_OBJECT("key", "Current Status", "value", PSM.display_name),
		    JSON_OBJECT("key", "Sanction Date", "value", DATE_FORMAT(EPD.sanction_date, "%d %M, %Y")),
		    JSON_OBJECT("key", "Sanction Amount", "value", CONCAT("Rs. ",FORMAT(EPD.sanction_amount,0,"en_IN"))),
		    JSON_OBJECT("key", "Last Disbursements Date", "value", DATE_FORMAT(EPD.disbursement_date, "%d %M, %Y")),
		    JSON_OBJECT("key", "Last Disbursements Amount", "value", CONCAT("Rs. ",FORMAT(EPD.disbursed_amount,0,"en_IN"))),
		    JSON_OBJECT("key", "Total Disbursements Amount", "value", CONCAT("Rs. ",FORMAT(EPD.total_disbursed_amount,0,"en_IN")))
		) AS proposalStatusObj,

		JSON_ARRAY(
			JSON_OBJECT("key", "Partner Name", "value", CONCAT_WS(" ",users.decValue(PU.first_name), users.decValue(PU.last_name))),
			JSON_OBJECT("key", "Partner Code", "value", PD.partner_code), 
			JSON_OBJECT("key", "Employee Code", "value", EPD.employee_code),
			JSON_OBJECT("key", "Source from Partner", "value", IF(PD.user_form = 1, "Bank User", IF(PD.user_form = 2,"External Partner","")))
		) AS partnerDetails,
		
		JSON_ARRAY(
			JSON_OBJECT("key", "Product Name",   "value", PM.product_name),
			JSON_OBJECT("key", "Product Status", "value", (CASE WHEN PM.is_active = 1 THEN "Active" ELSE "Inactive" END)),
			JSON_OBJECT("key", "Type of Loan", "value", 
			IF("',pageType,'" = "disbursed" AND EPD.`business_type_id` = 1,
				(SELECT CASE WHEN loan_purpose = 1 THEN "Working Capital" WHEN loan_purpose = 2 THEN "Term Loan" ELSE "" END FROM msme_loan_application.swms_loan_details WHERE application_id = EPD.application_id LIMIT 1),
				(SELECT CASE WHEN purpose_of_loan=1 THEN "Working Capital" WHEN purpose_of_loan=2 THEN "Term Loan" ELSE "" END FROM msme_loan_application.mudra_loan_details WHERE application_id = EPD.application_id LIMIT 1))
				),
			JSON_OBJECT("key", "Approved Date", "value", DATE_FORMAT(EPD.journey_completion_date, "%d %M, %Y")),
			JSON_OBJECT("key", "Approved Amount", "value", CONCAT("Rs. ",FORMAT(EPD.el_amount,0,"en_IN"))),
			JSON_OBJECT("key", "EMI (Rs.)", "value", CONCAT("Rs. ",FORMAT(EPD.el_emi,0,"en_IN"))),
			JSON_OBJECT("key", "Tenure","value", EPD.el_tenure),
			JSON_OBJECT("key", "ROI (%)", "value", EPD.el_roi), -- 
			JSON_OBJECT("key", "Processing fee (%)", "value", EPD.el_processing_fee),
			JSON_OBJECT("key", "Sources", "value", IF(EPD.campaign_master_id = 1, "Market Place", "Bank Specific")),			
			JSON_OBJECT("key", "Remark", "value", EPD.remarks),
			JSON_OBJECT("key", "Source from Partner", "value", IF(PD.user_form = 1, "Bank User", IF(PD.user_form = 2,"External Partner",""))),
			JSON_OBJECT("key", "Partner Name", "value", CONCAT_WS(" ",users.decValue(PU.first_name), users.decValue(PU.last_name))),
			JSON_OBJECT("key", "Partner Code", "value", PD.partner_code),
			JSON_OBJECT("key", "Employee Code", "value", EPD.employee_code),
			JSON_OBJECT("key", "Minority Category", "value", IF(EPD.sch_type_id = 2, (`banker_report`.categoryValue(EPD.application_id) ),"")),
			JSON_OBJECT("key", "Project Selection", "value", IF(EPD.sch_type_id = 12, (SELECT IF(project_type = 1 ,"Sanitation project","Other project") FROM `msme_loan_application`.`srms_loan_details` WHERE `application_id`= EPD.application_id LIMIT 1) ,""))			
		) AS proposalObj ');
 
	SET @tableQuery = CONCAT(' FROM `banker_report`.`proposal_data` EPD 
			INNER JOIN loan_application_details.profile_master PROF ON PROF.profile_id = EPD.profile_id
			INNER JOIN loan_application_details.proposal_status_master PSM ON PSM.id = EPD.proposal_status_id
			INNER JOIN scheme_details.scheme_master SM ON SM.id = EPD.sch_type_id
			LEFT JOIN product_ans.product_master PM ON PM.id = EPD.fp_product_id
			LEFT JOIN scheme_details.loan_master LM ON LM.id = EPD.loan_type_id
			LEFT JOIN partner_config.partner_details PD ON PD.partner_id = EPD.lam_created_by
			LEFT JOIN users.users PU ON PU.user_id = EPD.lam_created_by AND EPD.is_partner_journey = TRUE 
					
		    LEFT JOIN `msme_loan_application`.swms_loan_details  SLD ON SLD.application_id = EPD.application_id AND PM.`scheme_id` = 8
            LEFT JOIN `msme_loan_application`.mudra_loan_details  MLD ON MLD.application_id = EPD.application_id AND PM.`scheme_id` = 9		
			');			

	IF (IFNULL(filterJSON, NULL) IS NOT NULL AND filterJSON != '' AND filterJSON != '{}') THEN
		IF (filterJSON->"$.fromDate" IS NOT NULL) AND (filterJSON->"$.toDate" IS NOT NULL) AND (filterJSON->"$.fromDate" != '') AND (filterJSON->"$.toDate" != '') THEN
			IF (pageType = 'sanctioned' AND filterJSON->"$.dateFilterTypeId" IS NOT NULL) THEN
				IF filterJSON->"$.dateFilterTypeId" = 1 THEN -- Sanction Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.sanction_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 2 THEN -- Sanction Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.`sanction_created_date`) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				END IF;
			ELSEIF (pageType = 'disbursed' AND filterJSON->"$.dateFilterTypeId" IS NOT NULL) THEN
				IF filterJSON->"$.dateFilterTypeId" = 1 THEN -- Last Disbursement Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.disbursement_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 2 THEN -- First Disbursement Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.first_disbursement_entry_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 3 THEN -- Last Disbursement Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.`disbursement_created_date`) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 4 THEN -- First Disbursement Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.first_disbursement_date) BETWEEN ', filterJSON->"$.fromDate", ' AND ', filterJSON->"$.toDate");
				END IF;
			ELSEIF (pageType = 'reject' OR pageType = 'hold') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.`changed_date`) BETWEEN ', filterJSON -> "$.fromDate", ' AND ', filterJSON -> "$.toDate");
			ELSEIF (pageType = 'approved' OR pageType = 'referred') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.journey_completion_date) BETWEEN ', filterJSON -> "$.fromDate", ' AND ', filterJSON -> "$.toDate");
			END IF;
		END IF;
		
		IF ((IFNULL(filterJSON -> "$.stateId", NULL) IS NOT NULL) AND (filterJSON -> "$.stateId" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.state_id = ', filterJSON -> "$.stateId");
		END IF;
		IF ((IFNULL(filterJSON -> "$.cityId", NULL) IS NOT NULL) AND (filterJSON -> "$.cityId" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.city_id = ', filterJSON -> "$.cityId");
		END IF;
		IF ((IFNULL(filterJSON -> "$.branchId", NULL) IS NOT NULL) AND (filterJSON -> "$.branchId" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.branch_id = ', filterJSON -> "$.branchId");
		END IF;
		IF ((IFNULL(filterJSON -> "$.productId", NULL) IS NOT NULL) AND (filterJSON -> "$.productId" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.fp_product_id = ', filterJSON -> "$.productId");
		END IF;
		IF ((IFNULL(filterJSON -> "$.campaignTypeId", NULL) IS NOT NULL) AND (filterJSON -> "$.campaignTypeId" IS NOT NULL)) THEN
			IF (filterJSON -> "$.campaignTypeId" = 1) THEN
				SET @whereClause = CONCAT(@whereClause, ' AND EPD.campaign_master_id = 1 ');
			ELSEIF (filterJSON -> "$.campaignTypeId" = 2) THEN
				SET @whereClause = CONCAT(@whereClause, ' AND EPD.campaign_master_id != 1 ');
			END IF;
		END IF;
		IF (IFNULL(filterJSON -> "$.proposalDoneThroughId", NULL) IS NOT NULL) THEN
			IF (filterJSON -> "$.proposalDoneThroughId" = 1) THEN
				SET @whereClause = CONCAT(@whereClause, ' AND EPD.is_partner_journey = FALSE ');
			ELSEIF (filterJSON -> "$.proposalDoneThroughId" = 2) THEN
				SET @whereClause = CONCAT(@whereClause, ' AND EPD.is_partner_journey = TRUE ');
			END IF;
		END IF;
		IF (IFNULL(filterJSON -> "$.projectSelectionId", NULL) IS NOT NULL) THEN
			IF (filterJSON -> "$.projectSelectionId" = 1 OR filterJSON -> "$.projectSelectionId" = '1') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND SLD.project_type = 1 ');
			ELSEIF (filterJSON -> "$.projectSelectionId" = 2) THEN
				SET @whereClause = CONCAT(@whereClause, ' AND SLD.project_type != 1 ');
			END IF;
		END IF;
	END IF;

	IF (IFNULL(columnFilter, NULL) IS NOT NULL AND columnFilter != '' AND columnFilter != '{}') THEN
		IF ((IFNULL(columnFilter -> "$.organizationFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.organizationFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (banker_report.decValue(PROF.name) LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.organizationFilter"), '%''', ' OR EPD.application_code LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.organizationFilter"), '%'')');
		END IF;
		IF ((IFNULL(columnFilter -> "$.appCodeFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.appCodeFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.application_code LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.appCodeFilter"), '%''');
		END IF;
		IF ((IFNULL(columnFilter -> "$.emailFilter", NULL) IS NOT NULL)	AND (columnFilter -> "$.emailFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.email LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.emailFilter"), '%''');
		END IF;
		IF ((IFNULL(columnFilter -> "$.mobileFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.mobileFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.mobile LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.mobileFilter"), '%''', ' OR banker_report.decValue(U.email) LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.mobileFilter"), '%'')');
		END IF;
		IF ((IFNULL(columnFilter -> "$.panFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.panFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND banker_report.decValue(PROF.pan) LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.panFilter"), '%''');
		END IF;
		IF ((IFNULL(columnFilter -> "$.proposalStatusFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.proposalStatusFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.proposal_status_id = ', columnFilter -> "$.proposalStatusFilter");
		END IF;
      
		IF (columnFilter -> "$.dateFilter" IS NOT NULL AND columnFilter -> "$.dateFilter" != '') THEN
			IF (pageType = 'sanctioned' AND filterJSON->"$.dateFilterTypeId" IS NOT NULL) THEN
				IF filterJSON->"$.dateFilterTypeId" = 1 THEN -- Sanction Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.sanction_date) = ', columnFilter -> "$.dateFilter");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 2 THEN -- Sanction Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.created_date) = ', columnFilter -> "$.dateFilter");
				END IF;
			ELSEIF (pageType = 'disbursed' AND filterJSON->"$.dateFilterTypeId" IS NOT NULL) THEN
				IF filterJSON->"$.dateFilterTypeId" = 1 THEN -- Last Disbursement Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.disbursement_date) = ', columnFilter -> "$.dateFilter");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 2 THEN -- First Disbursement Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.first_disbursement_entry_date) = ', columnFilter -> "$.dateFilter");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 3 THEN -- Last Disbursement Entry Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.created_date) = ', columnFilter -> "$.dateFilter");
				ELSEIF filterJSON->"$.dateFilterTypeId" = 4 THEN -- First Disbursement Date
					SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.first_disbursement_date) = ', columnFilter -> "$.dateFilter");
				END IF;
			ELSEIF (pageType = 'reject' OR pageType = 'hold') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.`changed_date`) = ', columnFilter -> "$.dateFilter");
			ELSEIF (pageType = 'approved' OR pageType = 'referred') THEN
				SET @whereClause = CONCAT(@whereClause, ' AND DATE(EPD.journey_completion_date) = ', columnFilter -> "$.dateFilter");
			END IF;
		END IF;
	
		IF ((IFNULL(columnFilter -> "$.sanctionAmountFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.sanctionAmountFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.el_amount LIKE ''%', JSON_UNQUOTE(columnFilter -> "$.sanctionAmountFilter"), '%''');
		END IF;
		
		IF ((IFNULL(columnFilter -> "$.orgIdFilter", NULL) IS NOT NULL) AND (columnFilter -> "$.orgIdFilter" IS NOT NULL)) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND EPD.org_id = ', columnFilter -> "$.orgIdFilter");
		END IF;
	END IF;
	
	SET @totalCountQuery = CONCAT('SELECT COUNT(EPD.proposal_id) INTO @totalCount ', @tableQuery, @whereClause);
-- 	select @totalCountQuery;
	PREPARE cntstmt FROM @totalCountQuery;
	EXECUTE cntstmt;
 
	IF (pageType = 'approved') THEN
		SET @orderBy = ' ORDER BY approveDate DESC ';
	ELSEIF (pageType = 'referred') THEN
		SET @orderBy = ' ORDER BY approveDate DESC ';
	ELSEIF (pageType = 'hold') THEN
		SET @orderBy = ' ORDER BY holdDate DESC ';
	ELSEIF (pageType = 'disbursed') THEN
		SET @orderBy = ' ORDER BY disbursedDate DESC ';
	ELSEIF (pageType = 'sanctioned') THEN
		SET @orderBy = ' ORDER BY sanctionedDate DESC ';
	ELSEIF (pageType = 'reject') THEN
		SET @orderBy = ' ORDER BY rejectedDate DESC ';
        END IF;

	IF (noPagination IS NOT NULL AND noPagination != '') THEN
		SET @limit = ' ';
	ELSE
		SET @limit = CONCAT(' LIMIT ', paginationFROM, ' , ', paginationTO);
	END IF;

	IF (@totalCount > 0) THEN
		SET @executeQuery = CONCAT('SELECT @totalCount AS totalCount, @tableColumns as tableColumns, ', @selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
	ELSE
		SET @executeQuery = CONCAT('SELECT @totalCount AS totalCount, @tableColumns as tableColumns ');
	END IF;
-- 	select @executeQuery;
	PREPARE cntstmt FROM @executeQuery;
	EXECUTE cntstmt;
  
-- 	CALL `banker_report`.`spHoApprovedList_ALL_SCHEME_test`(NULL,'approved',NULL,NULL,NULL,21,68254 ,NULL,TRUE,0,10);
END$$

DELIMITER ;