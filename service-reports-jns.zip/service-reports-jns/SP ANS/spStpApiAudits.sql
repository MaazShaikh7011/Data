DELIMITER $$

USE `banker_report`$$

DROP PROCEDURE IF EXISTS `spStpApiAudits`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spStpApiAudits`(IN filterJSON TEXT, IN paginationFROM BIGINT, IN paginationTO BIGINT)
BEGIN
        SET @whereClause = ' WHERE TRUE ';
       
       SET @selectQuery = ' g.id AS id ,
                           g.`application_id` AS applicationId,
                           g.`request_id` AS requestId,
                           g.endpoint AS endpoint,
                           g.url AS url,
                           g.request_ref_number AS rrn,
			   CAST(UNCOMPRESS(g.`plain_reqeust`) AS CHAR) AS plainReq,
			   CAST(UNCOMPRESS(g.`plain_response`) AS CHAR) AS plainRes,
			   g.status AS status,
			   g.request_time AS requestTime ,
			   g.error_msg AS msg ';
          
       SET @selectQuery2 = ' g.id AS id ,
                            g.`application_id` AS applicationId,
                            g.`request_id` AS requestId,
                            g.type AS `endpoint`,
                            NULL AS url,
                            NULL AS rrn,
                            CAST(UNCOMPRESS(L.data) AS CHAR) AS plainReq,
                            NULL AS plainRes,
                            NULL AS `status`,
                            g.`created_date` AS requestTime,
                            g.`error_msg` AS msg ';                       		
    	    	 
    	    	 
    	 SET @tableQuery = ' FROM stp_gateway.gateway_api_audit g
			      INNER JOIN loan_application_details.loan_application_master LAM ON LAM.application_id = g.application_id '; 
			     
	 SET @tableQuery2 = ' FROM stp_gateway.api_audits g
			      INNER JOIN loan_application_details.loan_application_master LAM ON LAM.application_id = g.application_id 
			      LEFT JOIN stp_gateway.req_res_logs L ON L.id = g.logs_id ';	     
		             

     	IF (filterJSON->"$.orgId" IS NOT NULL) AND (filterJSON->"$.orgId" != '') THEN
		SET @whereClause = CONCAT(@whereClause, ' AND LAM.campaign_org_id IN ( ',filterJSON->"$.orgId" ,')');
	END IF;	
	
	
	IF (filterJSON->"$.applicationId" IS NOT NULL) AND (filterJSON->"$.applicationId" != '') THEN
		SET @whereClause = CONCAT(@whereClause, ' AND g.application_id = ', filterJSON->"$.applicationId");
	END IF;	  
	
-- Search filter
      -- IF ((filterJSON->"$.searchValue" IS NOT NULL)) THEN
      -- SET @whereClause = CONCAT(@whereClause, ' AND CONCAT(
      -- SGA.`application_id` LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchValue"), '%''
      -- OR SGA.`request_id` LIKE ''%', JSON_UNQUOTE(filterJSON->"$.searchValue"),'%''
      -- OR SGA.type LIKE  ''%', JSON_UNQUOTE(filterJSON->"$.searchValue"), '%''       
      -- )');
      -- END IF;
              
              
-- Application Count
      SET @selectCountQuery = ' SELECT COUNT(*) INTO @totalCount FROM ';
      
      SET @totalCountQuery = CONCAT(@selectCountQuery, ' ( SELECT ', @selectQuery, @tableQuery, @whereClause, " UNION ALL ", ' SELECT ', @selectQuery2, @tableQuery2, @whereClause, ' ) counter' );      
      
     -- SET @totalCountQuery = CONCAT(@selectCountQuery, @tableQuery, @whereClause);             
            
-- select @totalCountQuery;
      PREPARE cntstmt FROM @totalCountQuery;
      EXECUTE cntstmt;    

-- order by	
    --  SET @orderBy = ' ORDER BY g.id DESC ';
      
-- Limit set......
     IF (paginationTO != 0) THEN
	SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
       ELSE
         SET @limit ='';
       END IF;                 
         
        SET @mainQuery = CONCAT(' SELECT ', @selectQuery , ' , @totalCount AS totalCount ', @tableQuery, @whereClause, " UNION ALL " , ' SELECT ', @selectQuery2 , ' , @totalCount AS totalCount ', @tableQuery2 , @whereClause, @limit);
 
    -- SELECT @mainQuery;
			
     PREPARE stmt FROM @mainQuery;
     EXECUTE stmt;

     -- CALL `banker_report`.`spStpApiAudits`('{"orgId":16, "applicationId":16832}' ,0, 10);
 
 
		                							
END$$

DELIMITER ;