package com.opl.jns.common.service.report.service.impl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.common.service.report.repository.CommonRepository;
import com.opl.jns.common.service.report.service.MiscellaneousService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */

@Service
@Slf4j
public class MiscellaneousServiceImpl implements MiscellaneousService {

    @Autowired
    CommonRepository commonRepository;
    
   

    @Override
    public CommonResponse fetchOptOutApplication(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
            String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
            Integer schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asInt() : null;
            Integer type = filterJSON.has("type") ? filterJSON.get("type").asInt() : null;

            String searchQuery = "  ";
            if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
            	searchQuery = " AND (am.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + searchData + "') OR am.urn = '" + searchData + "')";
//            	searchQuery = " AND " + DBNameConstant.JNS_USERS + ".\"decvalue\"(am.account_number) like " + "'%" +  searchData  + "%'";
            }

            String whereClause = " WHERE 1=1 ";

            if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDPROVIDER.getId())) {
                whereClause += " AND am.org_id =" + authClientResponse.getUserOrgId();
                if (Objects.equals(authClientResponse.getUserRoleId(), UserRoleMaster.BRANCH_OFFICE.getId())) {
                    whereClause += " AND am.branch_id =" + authClientResponse.getUserBranchId();
                } else if (Objects.equals(authClientResponse.getUserRoleId(), UserRoleMaster.ZO.getId())) {
                    whereClause += " AND am.branch_zo_id =" + authClientResponse.getUserBranchId();
                } else if (Objects.equals(authClientResponse.getUserRoleId(), UserRoleMaster.RO.getId())) {
                    whereClause += " AND am.branch_ro_id =" + authClientResponse.getUserBranchId();
                }
            } else if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.INSURER.getId())) {
                whereClause += " AND am.insurer_org_id =" + authClientResponse.getUserOrgId();
            } else if(Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
            	whereClause += " AND am.user_id =" + authClientResponse.getUserId();
            }

            whereClause += " AND am.is_active = 1 " + searchQuery;
            
            String totalCountSelectQuery = "select json_object('totalCount' value count(am.id)) ";
            String tableQuery = "";
            if(schemeId.longValue()==SchemeMaster.PMSBY.getId()) {
            	tableQuery = " FROM  " + DBNameConstant.JNS_MASTER_DATA + ".PMSBY am";
            }else {
            	tableQuery = " FROM  " + DBNameConstant.JNS_MASTER_DATA + ".PMJJBY am";	
            }
            tableQuery  += " INNER JOIN "+ DBNameConstant.JNS_INSURANCE +".miscellaneous_audit ma ON ma.application_id = am.ID AND type = " + (type==2 ? MiscellaneousType.NOMINEE_UPDATE.getId() : MiscellaneousType.OPT_OUT.getId()) +" AND ma.is_active = 1 "
            + " INNER JOIN  " +DBNameConstant.JNS_MASTER_DATA + ".APPLICANT_PI_DETAILS ai ON ai.ID = am.ID  "
            + "INNER JOIN  " + DBNameConstant.JNS_CONFIG + ".user_organisation_master uom ON uom.org_id = am.org_id " ;

            String orderByQuery = " ORDER BY am.modified_date desc ";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";

            String str = commonRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String selectQuery = "select ai.id AS applicationId, " + DBNameConstant.JNS_USERS + ".\"decvalue\"(ai.ac_holder_name) AS name, " + DBNameConstant.JNS_USERS + ".\"decvalue\"(ai.account_number) AS accountNo, am.urn AS urn,";
    		if(schemeId.longValue()==SchemeMaster.PMSBY.getId()) {
    			selectQuery += " 1 AS schemeId, 'PMSBY' AS schemeName, ";
    		}else {            			
    			selectQuery += " 2 AS schemeId, 'PMJJBY' AS schemeName, ";
    		}
            selectQuery += " am.enrollment_date AS enrollDate, ma.date_of_effective AS dateOfEffective, ma.created_date AS dateOfNomineeUpdation,ma.date_of_request AS dateOfRequest,am.org_id as orgId ,uom.display_org_name as orgName ";
            String selectOuterQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + " ,'applicationId' VALUE applicationId, 'name' VALUE name, 'accountNo' VALUE accountNo, 'urn' VALUE urn, 'schemeId' VALUE schemeId, 'schemeName' VALUE schemeName, 'enrollDate' VALUE enrollDate, 'dateOfEffective' VALUE dateOfEffective, 'dateOfNomineeUpdation' VALUE dateOfNomineeUpdation, 'dateOfRequest' VALUE dateOfRequest , 'orgId' VALUE orgId , 'orgName' VALUE orgName  )returning clob) FROM (";
            String mainQuery = selectOuterQuery + selectQuery + tableQuery + whereClause + orderByQuery + limitQuery;
            System.err.println(mainQuery);
            return new CommonResponse("successfully get Data", commonRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }

    }
}
