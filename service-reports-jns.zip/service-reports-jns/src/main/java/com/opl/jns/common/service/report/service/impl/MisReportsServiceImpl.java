package com.opl.jns.common.service.report.service.impl;

import com.opl.jns.common.service.report.domain.WeekMaster;
import com.opl.jns.common.service.report.model.WeekMasterProxy;
import com.opl.jns.common.service.report.repository.WeekMasterRepository;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.common.service.report.domain.WeekMaster;
import com.opl.jns.common.service.report.model.WeekMasterProxy;
import com.opl.jns.common.service.report.repository.CommonRepository;
import com.opl.jns.common.service.report.repository.WeekMasterRepository;
import com.opl.jns.common.service.report.service.MisReportsService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MisReportsServiceImpl implements MisReportsService {

    @Autowired
    CommonRepository commonRepository;

	@Autowired
	WeekMasterRepository weekMasterRepository;
    
	@Override
	public CommonResponse getCumulativeCount(String request) {
		try {
			log.info("Fetching CumulativeCount ---------------------->{}" + request);
			String spName = "MIS_CUMULATIVE_ENROLLMENT_COUNT";
			return new CommonResponse(commonRepository.getMisDataProducer(request, spName),
					"SuccessFully get cumulativeCount", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Exception is getting while get cumulativeCount", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public CommonResponse getMisChartData(String request) {
		try {
			log.info("ENTER INTO MisChartData FOR REQUEST {}--------------------" ,request);
			Map<String, Object> requestMap = MultipleJSONObjectHelper.getMapFromString(request);

			String spName = null;
			if(requestMap != null && requestMap.get("insurerType") != null && Integer.parseInt(requestMap.get("insurerType").toString()) == 1) {
				spName = "MIS_ENROLLMENT_CHART_DATA";
			} else {
				spName = "MIS_CLAIM_CHART_DATA";
			}
			String misDataProducer = commonRepository.getMisDataProducer(request, spName);
			if(requestMap != null && requestMap.get("tabId") != null && Integer.parseInt(requestMap.get("tabId").toString()) >= 4) {
				return new CommonResponse(getChartCountAndLabelRes(misDataProducer),"SuccessFully get getMisChartData", HttpStatus.OK.value());
			}
			return new CommonResponse(misDataProducer,"SuccessFully get MisChartData", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Exception is getting while get MisChartData", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}


	private String getChartCountAndLabelRes(String misDataProducer){
		List<Map<String, String>> data = new ArrayList<>();
		String res = null;
		try {
			Map<String, String> mapData =null;
			if(misDataProducer != null){
				List<Map<String, Object>> mapFromString = MultipleJSONObjectHelper.getListOfObjects(misDataProducer,null,Map.class);
				if(mapFromString.size() > 0) {
					List<Map<String, String>> keyValueList = MultipleJSONObjectHelper.getListOfObjects(mapFromString.getFirst().get("keyValue").toString(), null, Map.class);
					for (Map<String, String> map : keyValueList) {
						mapData =  new HashMap<>();
						mapData.put("count", !OPLUtils.isObjectNullOrEmpty(mapFromString.get(0).get(map.get("key"))) ? mapFromString.get(0).get(map.get("key")).toString() : null);
						mapData.put("charLabel", map.get("label"));
						mapData.put("color", map.get("color"));
						if(map.get("className") != null) {
							mapData.put("class", map.get("className"));
						}
						data.add(mapData);
					}
				}
			}
			res = MultipleJSONObjectHelper.getStringfromListOfObject(data);
		} catch (Exception e) {
			log.error("ERROR WHILE CONVERTING SP RESPONSE TO PROPER CHART RESPONSE--------------",e);
		}
		return res;
	}

	@Override
	public CommonResponse getWeeksBasedOnYear(String year,Integer policyFinId) {
		try {
			log.info("ENTER INTO getWeeksBasedOnYear FOR year {} --------------------", year);

			List<WeekMaster> weeksFromYear = Collections.emptyList();
			if(policyFinId==1) {
				weeksFromYear = weekMasterRepository.findWeeksFromYearPolicyYear(WeekMaster.StatusEnum.COMPLETED, year);
			}else {
				weeksFromYear = weekMasterRepository.findWeeksFromYearFinancialYear(WeekMaster.StatusEnum.COMPLETED, year);
			}
			List<WeekMasterProxy> weekMasterProxyList = new ArrayList<>();
			WeekMasterProxy weekMasterProxy = null;
			for (WeekMaster week:weeksFromYear) {
				weekMasterProxy = new WeekMasterProxy();
				BeanUtils.copyProperties(week,weekMasterProxy);
				weekMasterProxyList.add(weekMasterProxy);
				weekMasterProxy.setVersion(week.getId());
			}
			return new CommonResponse(weekMasterProxyList,"SuccessFully get getWeeksBasedOnYear", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Exception is getting while get MisChartData", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public CommonResponse getYearBasedOnPolicyAndFinYear(Integer policyFinId) {
		try {
			log.info("ENTER INTO getYearBasedOnPolicyAndFinYear FOR policyFinId {} --------------------", policyFinId);
			List<Long> weeksFromYear = Collections.emptyList();
			if(policyFinId==1) {
				weeksFromYear = weekMasterRepository.findAllGroupByPolicyYear();
			}else {
				weeksFromYear = weekMasterRepository.findAllGroupByFinancialYear();
			}

			return new CommonResponse(weeksFromYear,"SuccessFully get getYearBasedOnPolicyAndFinYear", HttpStatus.OK.value());
		} catch (Exception e) {
			log.error("Exception is getting while get getYearBasedOnPolicyAndFinYear", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
//    @Cacheable(value = "rpt_getAgingChartReport", key = "{#request, #userId}")
	public CommonResponse getMisClaimAgingData(String request) {
		try {
//            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
//            Integer tabId = filterJSON.has("tabId") ? filterJSON.get("tabId").asInt() : null;
//            Integer year = filterJSON.has(YEAR) ? filterJSON.get(YEAR).asInt() : null;
//            Integer month = filterJSON.has(MONTH) ? filterJSON.get(MONTH).asInt() : null;
//            int startMonth = (type == 1) ? 4 : 6;
			String spName = "CLAIM_AGING_CHART";

//            Map<String, Object> monthDateRange = ReportUtils.getDayDateRange(Integer.valueOf(year), month, startMonth);
//            String fromDate = monthDateRange.get("startDate").toString();
//            String toDate = monthDateRange.get("endDate").toString();
			String getMonthWiseCount =  commonRepository.getMisDataProducer(request, spName);
			if (!OPLUtils.isObjectNullOrEmpty(getMonthWiseCount)) {
				return new CommonResponse(getMonthWiseCount, "SuccessFully get Claim Aging Report", HttpStatus.OK.value());
			}
		} catch (Exception e) {
			log.error("Exception is getting while get Claim Aging Report", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

}
