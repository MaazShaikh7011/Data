package com.opl.jns.common.service.report.service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.utils.common.CommonResponse;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */
public interface MiscellaneousService {
    CommonResponse fetchOptOutApplication(String request, AuthClientResponse authClientResponse);
}
