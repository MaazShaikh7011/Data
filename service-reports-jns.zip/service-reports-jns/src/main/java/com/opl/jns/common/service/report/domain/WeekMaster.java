package com.opl.jns.common.service.report.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "week_master", schema = DBNameConstant.JNS_REPORTS, indexes = {
        @Index(columnList = "status", name = "STATUS_BASE_DATA")
})
public class WeekMaster implements Serializable {

    private static final long serialVersionUID = -3633810627118913143L;

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "from_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date fromDate;

    @Column(name = "to_date", nullable = false, columnDefinition = "TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @Column(name = "status", nullable = false, columnDefinition = "number(1) default 0")
    private Integer status;

    @Column(name = "financial_year", nullable = false, columnDefinition = "number(10)")
    @ColumnDefault("0")
    private Integer financialYear;

    @Column(name = "policy_year", nullable = false, columnDefinition = "number(10)")
    @ColumnDefault("0")
    private Integer policyYear;

    @Column(name = "date_of_day", nullable = false, columnDefinition = "number(3)")
    @ColumnDefault("0")
    private Integer dateOfDay;

    @Column(name = "month", nullable = false, columnDefinition = "number(2)")
    @ColumnDefault("0")
    private Integer month;

    @Column(name = "is_renewal_updated", nullable = false, columnDefinition = "number(1,0)")
    @ColumnDefault("0")
    private Boolean isRenewalUpdated;

    @Column(name = "is_year_change", nullable = false, columnDefinition = "number(1,0)")
    @ColumnDefault("0")
    private Boolean isYearChange;

    public interface StatusEnum {
        int PENDING = 1;
        int IN_PROGRESS = 2;
        int COMPLETED = 3;
    }

}
