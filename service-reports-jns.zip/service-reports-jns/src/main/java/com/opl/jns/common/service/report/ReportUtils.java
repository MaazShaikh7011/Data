package com.opl.jns.common.service.report;

import com.opl.jns.utils.common.DateUtils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author ravi.thummar
 * Date : 17-06-2023
 */
public class ReportUtils {

    public static List<Map<String, Object>> getYearDateRange(int yearRange, int startMonth) throws IOException {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        List<Map<String, Object>> list = new ArrayList<>(yearRange);
        for (int i = 0; i < yearRange; i++) {
            if (month < startMonth) {
                year--;
            }
            String startDate = year + "-" + (((startMonth + "").length() == 1) ? ("0" + startMonth) : startMonth) + "-01";
//            String endDate = (year + 1) + "-" + (((startMonth - 1) + "").length() == 1 ? ("0" + startMonth) : startMonth) + "-" + getLastDayOfMonth((startMonth - 1), (year + 1));
            String endDate = (year + 1) + "-" + (((startMonth - 1) + "").length() == 1 ? ("0" + (startMonth - 1) ) : startMonth) +  "-" + getLastDayOfMonth((startMonth - 1), (year + 1));
            Map<String, Object> map = new HashMap<>();
            map.put("startDate", startDate);
            map.put("endDate", endDate);
            map.put("yearRangeLabel", (year + "-" + String.valueOf((year + 1)).substring(2, 4)));
 
            list.add(map);
            year--;
        }
        return list;
    }

    public static Map<String, Object> getMonthDateRange(int year, int startMonth) throws IOException {
        String startDate = year + "-" + (((startMonth + "").length() == 1) ? ("0" + startMonth) : startMonth) + "-01";
        String endDate = (year + 1) + "-" + (((startMonth - 1) + "").length() == 1 ? ("0" + (startMonth - 1)) : (startMonth - 1)) + "-" + getLastDayOfMonth((startMonth - 1), (year + 1));
        Map<String, Object> map = new HashMap<>();
        map.put("startDate", startDate);
        map.put("endDate", endDate);
        return map;
    }

    public static List<Map<String, Object>> getMonthFromDateRange(String fromDate, String toDate) {
        DateFormat dateFormat = new SimpleDateFormat(DateUtils.DateFormat.YYYY_MM_DD);
        Calendar beginCalendar = Calendar.getInstance();
        Calendar finishCalendar = Calendar.getInstance();
        try {
            beginCalendar.setTime(dateFormat.parse(fromDate));
            finishCalendar.setTime(dateFormat.parse(toDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Map<String, Object>> monthList = new ArrayList<>();
        while (beginCalendar.before(finishCalendar)) {
            Date time = beginCalendar.getTime();
            Calendar c = Calendar.getInstance();
            c.setTime(time);
            Map<String, Object> monthMap = new HashMap<>();
            monthMap.put("month", (c.get(Calendar.MONTH) + 1));
            monthMap.put("monthName", getMonthForInt(c.get(Calendar.MONTH) + 1));
            monthMap.put("year", c.get(Calendar.YEAR));
            monthList.add(monthMap);
            beginCalendar.add(Calendar.MONTH, 1);
        }
        return monthList;
    }

    public static Map<String, Object> getDayDateRange(int year, int month, int startMonth) throws IOException {
        if (month < startMonth) {
            year++;
        }
        String startDate = year + "-" + (((month + "").length() == 1) ? ("0" + month) : month) + "-01";
        String endDate = year + "-" + (((month + "").length() == 1) ? ("0" + month) : month) + "-" + getLastDayOfMonth(month, year);
        Map<String, Object> map = new HashMap<>();
        map.put("startDate", startDate);
        map.put("endDate", endDate);
        return map;
    }

    private static int getLastDayOfMonth(int month, int year) {
        month--;
        switch (month) {
            case Calendar.APRIL:
            case Calendar.JUNE:
            case Calendar.SEPTEMBER:
            case Calendar.NOVEMBER:
                return 30;
            case Calendar.FEBRUARY:
                if (year % 4 == 0) {
                    return 29;
                }
                return 28;
            default:
                return 31;
        }
    }

    private static String getMonthForInt(int num) {
        String month = "wrong";
        DateFormatSymbols dfs = new DateFormatSymbols();
        String[] months = dfs.getShortMonths();
        if (num >= 1 && num <= 12) {
            month = months[num - 1];
        }
        return month;
    }

}
