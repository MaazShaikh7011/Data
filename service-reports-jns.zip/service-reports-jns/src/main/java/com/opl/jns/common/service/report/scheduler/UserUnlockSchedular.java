package com.opl.jns.common.service.report.scheduler;

import java.util.Date;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.opl.jns.common.service.report.repository.CommonRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Transactional
public class UserUnlockSchedular {

	
	@Autowired
	CommonRepository commonRepo;
	
//	@Scheduled(cron = "0 5 0 ? * *")
	@Scheduled(cron = "0 25 14 ? * *")
	public void pushTheCountInReport() {
		log.info(" user Unlock Scheduler started on {}", new Date());
		try {
			commonRepo.unlockLockedUser();
		} catch (Exception e) {
			log.info("error while user Unlock Scheduler {}", e);
		}
		log.info("user Unlock Scheduler ended {}", new Date());
	}
}
