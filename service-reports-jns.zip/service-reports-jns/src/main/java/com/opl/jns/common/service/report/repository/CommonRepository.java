package com.opl.jns.common.service.report.repository;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
public interface CommonRepository {
    String getDataFromProducer(String request, Long userId, String spName);

    String getReportByDateFilter(String request, Long userId, String fromDate, String toDate, String spName);
    
    String fetchMasterData(String listKey, String whereClause, String spName);

    String fetchOptOutApplication(String query);
	
	String fetchCount(String query);

	void unlockLockedUser();
	
	void schedulerQueryForPolicy(String spName);
	
	 String getMisDataProducer(String request, String spName);
}
