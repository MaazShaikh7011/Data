package com.opl.jns.common.service.report.domain;

import com.opl.jns.utils.config.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author Maaz Shaikh
 * Date : 16-08-2023
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "policy",schema = DBNameConstant.JNS_REPORTS,catalog =  DBNameConstant.JNS_REPORTS)
public class Policy {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "policy_seq_gen")
    @SequenceGenerator(schema = "jns_reports", name = "policy_seq_gen", sequenceName = "policy_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "org_id")
    private Long orgId;
    @Column(name = "insurer_org")
    private Long insurerOrgId;

    @Column(name = "enroll_date")
    private Date date;
    @Column(name = "state")
    private Long state;

    @Column(name = "branch_id")
    private Long branchId;
    @Column(name = "ro_id")
    private Long roId;
    @Column(name = "zo_id")
    private Long zoId;

    @Column(name = "PMJJBY_A_TOTAL")
    private Long pmjjbyAcceptedTotal;
    @Column(name = "PMSBY_A_TOTAL")
    private Long pmsbyAcceptedTotal;
    @Column(name = "A_TOTAL")
    private Long acceptedTotal;
    @Column(name = "PMJJBY_R_TOTAL")
    private Long pmjjbyRejectedTotal;
    @Column(name = "PMSBY_R_TOTAL")
    private Long pmsbyRejectedTotal;
    @Column(name = "R_TOTAL")
    private Long rejectedTotal;
    @Column(name = "TOTAL_COUNT")
    private Long totalCount;
    @Column(name = "PMJJBY_A_AMOUNT")
    private Long pmjjbyAcceptedAmount;
    @Column(name = "PMSBY_A_AMOUNT")
    private Long pmsbyAcceptedAmount;
    @Column(name = "A_AMOUNT")
    private Long totalAmount;


}
