package com.opl.jns.common.service.report.repository;

import com.opl.jns.common.service.report.domain.*;
import org.springframework.data.jpa.repository.*;

import jakarta.transaction.*;
import java.util.*;

public interface PolicyRepository extends JpaRepository<Policy,Long> {


    @Modifying
    @Query(nativeQuery = true,value = """
            update JNS_REPORTS.POLICY p
            set p.ro_id=(select d.ro_id from JNS_INSURANCE.BRANCH_DETAILS d where p.branch_id=d.branch_id),
            p.zo_id=(select d.zo_id from JNS_INSURANCE.BRANCH_DETAILS d where p.branch_id=d.branch_id),
            p.state=(select d.state_id from JNS_INSURANCE.BRANCH_DETAILS d where p.branch_id=d.branch_id)
            where p.org_id=:orgId and  p.ro_id is null and p.zo_id is null and p.state is null and rownum <=100000\
            """)
    int updateRoZOId(Long orgId);

}
