package com.opl.jns.common.service.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.common.service.report.service.MiscellaneousService;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */

@RestController
@RequestMapping("/miscellaneous")
@Slf4j
public class MiscellaneousController {
    @Autowired
    private MiscellaneousService miscellaneousService;


    @PostMapping(value = "/fetchOptOutApplication", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchEnrollmentCounts(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(miscellaneousService.fetchOptOutApplication(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
