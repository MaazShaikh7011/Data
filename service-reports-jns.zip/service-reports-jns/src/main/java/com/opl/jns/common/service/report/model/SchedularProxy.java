package com.opl.jns.common.service.report.model;

import lombok.Data;
/**
 * @author sagar.gorasiya
 * Date : 15-06-2023
 */
@Data
public class SchedularProxy {

	 private String startDate;
	 private String endDate;
}
