package com.opl.jns.common.service.report.repository.impl;

import java.sql.Clob;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.opl.jns.common.service.report.repository.CommonRepository;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {

    @Autowired
    EntityManager entityManager;

    @Override
    public String getDataFromProducer(String request, Long userId, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}", spName, request, userId);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }

    @Override
    public String getReportByDateFilter(String request, Long userId, String fromDate, String toDate, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}, fromDate-> {}, toDate-> {}", spName, request, userId, fromDate, toDate);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);                    
            storedProcedureQuery.registerStoredProcedureParameter("fromdate", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("todate", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("fromdate", fromDate);
            storedProcedureQuery.setParameter("todate", toDate);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }

    @Override
    public String fetchMasterData(String listKey, String whereClause, String spName) {
        try {
            log.info("spName {}", spName);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("listKey", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("whereClause", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("listKey", listKey);
            storedProcedureQuery.setParameter("whereClause", OPLUtils.isObjectNullOrEmpty(whereClause) ? "1" : whereClause);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }

    @Override
    public String fetchOptOutApplication(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }
    
    @Override
    public String fetchCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }
    
    
    
    
//    public void updateCountForReport(String query) {
//
//    	
//		Session hibernateSession = entityManager.unwrap(Session.class);
//
//		hibernateSession.doWork(new org.hibernate.jdbc.Work() {
//
//		    @Override
//		    public void execute(Connection connection) throws SQLException {
//				try (Statement st = connection.createStatement()){
//					st.executeQuery(query);
//				} catch (SQLException e) {
//					log.info("Error while executing query {} :::::",query, e);
//				}
//		    }
//		});
//
//    	
//    }
    
    @Override
    public void schedulerQueryForPolicy(String spName) {
        log.info("SP Name---->   {}", spName);
    	entityManager.createStoredProcedureQuery(spName).execute();
    }

	@Override
	public void unlockLockedUser() {
		try {
			String query="UPDATE jns_users.users SET is_locked = 0, login_counter = 0 WHERE is_locked = 1";
			entityManager.createNativeQuery(query).executeUpdate();
		} catch (Exception e) {
			 log.error("Exception is getting while unlockLockedUser", e);
		}
	}

	@Override
	public String getMisDataProducer(String request, String spName) {
        try {
            log.info("spName {}, request-> {}", spName, request);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }
    
    
}
