package com.opl.jns.common.service.report.service;

import com.opl.jns.utils.common.CommonResponse;

public interface MisReportsService {

	CommonResponse getCumulativeCount(String request);
	CommonResponse getMisChartData(String request);
	CommonResponse getWeeksBasedOnYear(String year,Integer policyFinId);
	CommonResponse getYearBasedOnPolicyAndFinYear(Integer year);
	CommonResponse getMisClaimAgingData(String request);

}
