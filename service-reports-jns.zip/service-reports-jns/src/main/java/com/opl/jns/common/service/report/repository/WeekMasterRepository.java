package com.opl.jns.common.service.report.repository;

import com.opl.jns.common.service.report.domain.WeekMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

public interface WeekMasterRepository extends JpaRepository<WeekMaster, Long> {

    WeekMaster findFirstByStatus(Integer status);
    WeekMaster findFirstByOrderByIdDesc();

    @Transactional
    @Modifying
    @Query("UPDATE WeekMaster SET status = " + WeekMaster.StatusEnum.IN_PROGRESS + " WHERE id=:id")
    void updateStuts(Long id);

    @Query(value = "SELECT * from jns_reports.week_master wm where status=:status and policy_year = :year order by id desc ",nativeQuery = true)
    List<WeekMaster> findWeeksFromYearPolicyYear(@Param("status") Integer status, @Param("year") String year);
    
    @Query(value = "SELECT * from jns_reports.week_master wm where status=:status and financial_year = :year order by id desc ",nativeQuery = true)
    List<WeekMaster> findWeeksFromYearFinancialYear(@Param("status") Integer status, @Param("year") String year);
    
    @Query("SELECT policyYear FROM WeekMaster p GROUP BY policyYear")
    List<Long> findAllGroupByPolicyYear();
    
    @Query("SELECT financialYear FROM WeekMaster p GROUP BY financialYear")
    List<Long> findAllGroupByFinancialYear();
}
