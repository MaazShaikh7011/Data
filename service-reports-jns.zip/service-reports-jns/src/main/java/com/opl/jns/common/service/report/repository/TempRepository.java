package com.opl.jns.common.service.report.repository;

import com.opl.jns.common.service.report.domain.Temp;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */


public interface TempRepository extends JpaRepository<Temp, Long> {
}
