package com.opl.jns.common.service.report.controller;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opl.jns.common.service.report.service.MisReportsService;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/mischart")
public class MisReportsController {
	
	@Autowired
	private MisReportsService misReportService;

	@PostMapping(value = "/getCumulativeCount", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getCumulativeCount(@RequestBody String request) {
		try {
			return new ResponseEntity<>(misReportService.getCumulativeCount(request),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getCumulative Counts ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getMisChartData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getMisChartData(@RequestBody String request) {
		try {
			return new ResponseEntity<>(misReportService.getMisChartData(request),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getCumulative Counts ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getWeeksBasedOnYear/{year}/{policyFinId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getWeeksBasedOnYear(@PathVariable("year") String year,@PathVariable("policyFinId") Integer policyFinId) {
		try {
			return new ResponseEntity<>(misReportService.getWeeksBasedOnYear(year,policyFinId),HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getWeeksBasedOnYear ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getYearBasedOnPolicyAndFinYear/{policyFinId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getYearBasedOnPolicyAndFinYear(@PathVariable("policyFinId") Integer policyFinId) {
		try {
			return new ResponseEntity<>(misReportService.getYearBasedOnPolicyAndFinYear(policyFinId),HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getYearBasedOnPolicyAndFinYear ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getMisClaimAgingData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getMisClaimAgingData(@RequestBody String request) {
		try {
			return new ResponseEntity<>(misReportService.getMisClaimAgingData(request), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getClmAgingReport ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
}
