package com.opl.jns.common.service.report.service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.utils.common.CommonResponse;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
public interface ReportsService {
//    CommonResponse fetchEnrollmentCounts(String request, Long userId);
    CommonResponse fetchEnrollmentCountsWithCaches(String request, Long userId);

    CommonResponse fetchEnrollmentCountsBo(String request, Long userId);

    CommonResponse fetchEnrollmentList(String request, Long userId) throws  Exception;

    CommonResponse fetchIssuedAndSavedEnrollmentAppList(String request, Long userId);

    CommonResponse fetchClaimCounts(String request, Long userId);

    CommonResponse fetchClaimList(String request, Long userId);

    CommonResponse fetchSavedClaimAppList(String request, Long userId);

    CommonResponse getTopOffice(String request, Long userId);

    CommonResponse getStateWiseReport(String request, Long userId);

    CommonResponse getYearWiseReport(String request, Long userId);

    CommonResponse getMonthWiseReport(String request, Long userId);

    CommonResponse getDayWiseReport(String request, Long userId);

    CommonResponse getAgingChartReport(String request, Long userId);

    CommonResponse fetchMasterData(String listKey, String whereClause);

    public void updateRoZOBRANCH(Long orgId);
    
    CommonResponse fetchLastUpdateOnDate(Integer insurerType,Integer reportType);

    CommonResponse getDemographicReport(String request, Long userId);

    CommonResponse getChannelReport(String request, Long userId);

	CommonResponse fetchPreRenewalCounts(String request, Long userId);

    CommonResponse fetchPreRenewalListView(String request, AuthClientResponse authClientResponse);

    CommonResponse fetchPreRenewalFailedData(String request, Long userId);

//	CommonResponse fetchPreRenewalSuccessCount(String request, Long userId);

	CommonResponse fetchPreRenewalSuccessDeficientData(String request, Long userId);
}
