package com.opl.jns.common.service.report.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.common.service.report.domain.SchedularDate;

@Repository
public interface SchedularDateRepository extends JpaRepository<SchedularDate, Long> {

	SchedularDate findByTypeAndReportTypeAndIsActiveTrueOrderByIdDesc(Integer insurerType, Integer reportType);

}
