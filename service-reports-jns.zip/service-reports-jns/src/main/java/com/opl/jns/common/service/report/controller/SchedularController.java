//package com.opl.jns.common.service.report.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.opl.jns.common.service.report.model.SchedularProxy;
//import com.opl.jns.common.service.report.scheduler.ReportSchedular;
//import com.opl.jns.utils.common.CommonResponse;
//
//import lombok.extern.slf4j.Slf4j;
//
//@RestController
//@Slf4j
//@RequestMapping("/scheduler")
//public class SchedularController {
//
//	@Autowired
//	ReportSchedular reportSchedular;
//	
//	@PostMapping(value = "/reportScheduler", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> fetchEnrollmentCounts(@RequestBody SchedularProxy request) {
//        try {
//            Boolean flag = reportSchedular.pushTheCountInPolicy(2,request.getStartDate(), request.getEndDate());
//            return new ResponseEntity<CommonResponse>(new CommonResponse(flag,HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while fetchEnrollmentCounts ------>", e);
//            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//        }
//    }
//
////	@GetMapping(value = "/reportSchedulerRoZo", produces = MediaType.APPLICATION_JSON_VALUE)
////	public ResponseEntity<CommonResponse> reportSchedulerRoZo() {
////		try {
////			Boolean flag = reportSchedular.rozo();
////			return new ResponseEntity<CommonResponse>(new CommonResponse(flag,HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value()), HttpStatus.OK);
////		} catch (Exception e) {
////			log.error("Exception while reportSchedulerRoZo ------>", e);
////			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
////		}
////	}
//	
//	@PostMapping(value = "/reportSchedulerForDemographic", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> reportSchedulerForDemographic(@RequestBody SchedularProxy request) {
//        try {
//            Boolean flag = reportSchedular.pushTheCountInPolicy(1,request.getStartDate(), request.getEndDate());
//            return new ResponseEntity<CommonResponse>(new CommonResponse(flag,HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while fetchEnrollmentCountsForDemographic ------>", e);
//            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//        }
//    }
//	
//}
