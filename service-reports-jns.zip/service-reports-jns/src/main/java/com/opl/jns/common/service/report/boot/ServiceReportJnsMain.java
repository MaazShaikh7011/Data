package com.opl.jns.common.service.report.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;


@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableAutoConfiguration
@EnableAsync
@EnableScheduling
@EnableConfigurationProperties(ApplicationProperties.class)
//@EnableEurekaClient
public class ServiceReportJnsMain {

    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) {
 //        System.err.println(DataSourceProvider.getDatabaseName());
//        System.err.println(DataSourceProvider.getPassword());
//        System.err.println(DataSourceProvider.getDbUrlOracle());
//        System.err.println(DataSourceProvider.getEnvMode());
        SpringApplication.run(ServiceReportJnsMain.class, args);
    }


    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

}
