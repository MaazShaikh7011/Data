package com.opl.jns.common.service.report.service.impl;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.common.service.report.ReportUtils;
import com.opl.jns.common.service.report.domain.SchedularDate;
import com.opl.jns.common.service.report.repository.CommonRepository;
import com.opl.jns.common.service.report.repository.PolicyRepository;
import com.opl.jns.common.service.report.repository.SchedularDateRepository;
import com.opl.jns.common.service.report.service.ReportsService;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */

@Service
@Slf4j
public class ReportsServiceImpl implements ReportsService {

    private static final String JNS_REPORTS = ""; // DBNameConstant.JNS_REPORTS + ".";
//    private static final String JNS_REPORTS_DOT = DBNameConstant.JNS_REPORTS + ".";

    private static final String TYPE = "type";
    private static final String YEAR = "year";
    private static final String MONTH = "month";
    private static final String INSURANCE_TYPE = "insuranceType";
    private static final String PAGINATION_TO = "paginationTO";
    public static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
    private static final DateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DateFormat.DD_MMM_YYYY);

    private static final DateFormat simpleDateFormatter = new SimpleDateFormat(DateUtils.DateFormat.YYYY_MM_DD);

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    ConfigProperties configProperties;

    @Autowired
    SchedularDateRepository schedularDateRepository;

    @Autowired
    PolicyRepository policyRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
//    @Cacheable(value = "rpt_fetchEnrollmentCounts",key = "{#request, #userId}")
    public CommonResponse fetchEnrollmentCountsWithCaches(String request, Long userId) {
        String spName = JNS_REPORTS + "fetch_enrollment_counts_policy_v5";
        return fetchEnrollmentCounts(request, userId, spName);
    }

    @Override
    public CommonResponse fetchEnrollmentCountsBo(String request, Long userId) {
//        String spName = JNS_REPORTS + "fetch_enrollment_counts_v2";
        try {
            Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(request);
            if(mapFromString.get("fromDate") != null && mapFromString.get("toDate") != null) {
                String fromDate = simpleDateFormat.format(simpleDateFormatter.parse(mapFromString.get("fromDate").toString()));
                mapFromString.put("fromDate",fromDate);
                String toDate = simpleDateFormat.format(simpleDateFormatter.parse(mapFromString.get("toDate").toString()));
                mapFromString.put("toDate",toDate);
            }
            request = MultipleJSONObjectHelper.getStringfromObject(mapFromString);
        }catch (Exception e) {
            log.error("EXCEPTION WHILE CONVERTING MAP TO STRING AND STRING TO MAP FOR GETTING ENROLLMENT COUNT",e);
        }
        return fetchEnrollmentCounts(request, userId, null);
    }

    @Override
//    @Cacheable(value = "rpt_fetchEnrollmentList",key = "{#request, #userId}")
    public CommonResponse fetchEnrollmentList(String request, Long userId) throws Exception {

//        String spName = JNS_REPORTS + "fetch_enrollment_list_v4";
//        List<Map<String, Object>> mapList = spExecuteCall(spName, request, userId);
//        return new CommonResponse("SuccessFully Get Data", mapList, HttpStatus.OK.value(), Boolean.TRUE);

        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer tabId = filterJSON.has("tabId") ? filterJSON.get("tabId").asInt() : null;
            String spName = (tabId == 2 ? JNS_REPORTS + "FETCH_ENROLLMENT_ACCEPTED_LIST" : JNS_REPORTS + "fetch_enrollment_list_v2");
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get Enrollment List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Enrollment List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

//    List<Map<String, Object>> spExecuteCall(String spName, String request, Long userId) throws IOException {
//        JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
//        Integer pageSize = filterJSON.has(PAGINATION_TO) ? filterJSON.get(PAGINATION_TO).asInt() : 0;
//        List<Map<String, Object>> result = new ArrayList<>(pageSize);
//
//        jdbcTemplate.execute((Connection con) -> {
//            log.info("CALL " + spName + "({},{},'output')", request, userId);
//            try (CallableStatement cs = con.prepareCall("{CALL " + spName + "(?,?,?)}")) {
//
//                cs.setString(1, request);
//                cs.setLong(2, userId);
//                cs.registerOutParameter(3, OracleTypes.CURSOR);
//                cs.execute();
//
//                try (ResultSet rs = (ResultSet) cs.getObject(3)) {
//                    while (rs.next()) {
//                        Map<String, Object> row = new HashMap<>(rs.getMetaData().getColumnCount());
//                        // Iterate over the columns and retrieve the values by column name
//                        for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
//                            String columnName = rs.getMetaData().getColumnName(i);
//                            Object value = rs.getObject(i);
//                            row.put(columnName, value);
//                        }
//                        result.add(row);
//                    }
//                    return result;
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//                return null;
//            }
//        });
//        return result;
//    }

    @Override
//    @Cacheable(value = "rpt_fetchIssuedAndSavedEnrollmentAppList",key = "{#request, #userId}")
    public CommonResponse fetchIssuedAndSavedEnrollmentAppList(String request, Long userId) {
        try {
            String spName = JNS_REPORTS + "fetch_issued_and_saved_enrollment_list_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get saved Enrollment List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get saved Enrollment List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
//    @Cacheable(value = "rpt_fetchClaimCounts",key = "{#request, #userId}")
    public CommonResponse fetchClaimCounts(String request, Long userId) {
        try {
            String spName = JNS_REPORTS + "fetch_claim_counts_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get Claim Count", HttpStatus.OK.value());
//        	String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
//    		Object objectFromMap = MultipleJSONObjectHelper.getObjectFromString(dataFromProducer, Object.class);
//    		   return new CommonResponse(objectFromMap, "SuccessFully get Claim Count", HttpStatus.OK.value());

        } catch (Exception e) {
            log.error("Exception is getting while get Enrollment Count", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
//    @Cacheable(value = "rpt_fetchClaimList",key = "{#request, #userId}")
    public CommonResponse fetchClaimList(String request, Long userId) {
        try {
//            String spName = JNS_REPORTS + "fetch_claim_list";
            String spName = JNS_REPORTS + "fetch_claim_download_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get Claim List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Claim List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
//    @Cacheable(value = "rpt_fetchSavedClaimAppList",key = "{#request, #userId}")
    public CommonResponse fetchSavedClaimAppList(String request, Long userId) {
        try {
            String spName = JNS_REPORTS + "fetch_issued_and_saved_claim_list_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get saved Claim List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get saved claim List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }


    @Override
    @Cacheable(value = "rpt_getTopOffice", key = "{#request, #userId}")
    public CommonResponse getTopOffice(String request, Long userId) {
        try {
            log.info("Fetching Top Office Reports ---------------------->");
//            return new CommonResponse(reportRepository.getTopOffice(request, authClientResponse.getUserId()), "SuccessFully get Top Office", HttpStatus.OK.value());
            String spName = JNS_REPORTS + "get_top_enroll_office_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get Top Office", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Top Office List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    @Cacheable(value = "rpt_getStateWiseReport", key = "{#request, #userId}")
    public CommonResponse getStateWiseReport(String request, Long userId) {
        try {
            log.info("Fetching State Wise Reports ---------------------->");
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
            if (OPLUtils.isObjectNullOrEmpty(type) || !Arrays.asList(1, 2).contains(type)) {
                return new CommonResponse("Type can not be null or empty", HttpStatus.BAD_REQUEST.value());
            }
            String spName = type == 1 ? JNS_REPORTS + "get_state_wise_enroll_count_v5" : JNS_REPORTS + "get_state_wise_claim_count_v5";
            return new CommonResponse(commonRepository.getDataFromProducer(request, userId, spName), "SuccessFully get state wise report", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get state wise report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    @Cacheable(value = "rpt_getYearWiseReport", key = "{#request, #userId}")
    public CommonResponse getYearWiseReport(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
            Integer insuranceType = filterJSON.has(INSURANCE_TYPE) ? filterJSON.get(INSURANCE_TYPE).asInt() : null;
            int startMonth = (type == 1) ? 4 : 6;
            String yearRange = configProperties.getValue("BANKER_DASHBOARD_YEAR_RANGE");
            if (OPLUtils.isObjectNullOrEmpty(yearRange)) {
                return new CommonResponse("year Range Not Found From Config JNS", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
            }

            List<Map<String, Object>> yearDateRange = ReportUtils.getYearDateRange(Integer.valueOf(yearRange), startMonth);
            String spName = insuranceType == 1 ? JNS_REPORTS + "get_year_wise_enroll_report_v5" : JNS_REPORTS + "get_year_wise_claim_report_v5";
            List<Map<String, Object>> mapList = new ArrayList<>();
            for (int i = 0; i < yearDateRange.size(); i++) {
                Map<String, Object> map = yearDateRange.get(i);
                String fromDate = map.get("startDate").toString();
                String toDate = map.get("endDate").toString();
                String getYearCount = commonRepository.getReportByDateFilter(request, userId, fromDate, toDate, spName);
                if (!OPLUtils.isObjectNullOrEmpty(getYearCount)) {
                    Map<String, Object> mapResult = MultipleJSONObjectHelper.getMapFromString(getYearCount);
                    mapResult.put("chartLabel", map.get("yearRangeLabel").toString());
                    mapList.add(mapResult);
                }
            }
//            return new CommonResponse(reportRepository.getStateWiseReport(request, authClientResponse.getUserId()), "SuccessFully get state wise report", HttpStatus.OK.value());
            return new CommonResponse(mapList, "SuccessFully get year wise report", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get year wise report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    @Cacheable(value = "rpt_getMonthWiseReport", key = "{#request, #userId}")
    public CommonResponse getMonthWiseReport(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
            Integer year = filterJSON.has(YEAR) ? filterJSON.get(YEAR).asInt() : null;
            Integer insuranceType = filterJSON.has(INSURANCE_TYPE) ? filterJSON.get(INSURANCE_TYPE).asInt() : null;
            int startMonth = (type == 1) ? 4 : 6;
            String spName = insuranceType == 1 ? JNS_REPORTS + "get_month_wise_enroll_report_v5" : JNS_REPORTS + "get_month_wise_claim_report_v5";
            Map<String, Object> monthDateRange = ReportUtils.getMonthDateRange(year, startMonth);
            String fromDate = monthDateRange.get("startDate").toString();
            String toDate = monthDateRange.get("endDate").toString();
            String getMonthWiseCount = commonRepository.getReportByDateFilter(request, userId, fromDate, toDate, spName);
            List<Map<String, Object>> listOfObjects = null;
            if (!OPLUtils.isObjectNullOrEmpty(getMonthWiseCount)) {
                listOfObjects = MultipleJSONObjectHelper.getListOfObjects(getMonthWiseCount, null, Map.class);
            }

            List<Map<String, Object>> monthFromDateRange = ReportUtils.getMonthFromDateRange(fromDate, toDate);

            if (insuranceType == 1) {
                List<Map<String, Object>> finalListOfObjects = listOfObjects;
                monthFromDateRange.forEach(x -> {
                    Object o = !OPLUtils.isObjectNullOrEmpty(x.get("month")) ? (x.get("month").toString().length() == 1 ? ("0" + x.get("month")) : x.get("month")) : null;
                    Optional<Map<String, Object>> objectMap = !OPLUtils.isObjectNullOrEmpty(finalListOfObjects) ? finalListOfObjects.stream().filter(x1 -> x1.get("month").toString().equals(o.toString())).findFirst() : Optional.empty();
                    x.put("chartLabel", x.get("month"));
                    x.put("totalCount", objectMap.isPresent() ? objectMap.get().get("totalCount") : 0);
                    x.put("acceptedCount", objectMap.isPresent() ? objectMap.get().get("acceptedCount") : 0);
                    x.put("rejectedCount", objectMap.isPresent() ? objectMap.get().get("rejectedCount") : 0);
                });
            } else {
                List<Map<String, Object>> finalListOfObjects = listOfObjects;
                monthFromDateRange.forEach(x -> {
                    Object o = !OPLUtils.isObjectNullOrEmpty(x.get("month")) ? (x.get("month").toString().length() == 1 ? ("0" + x.get("month")) : x.get("month")) : null;
                    Optional<Map<String, Object>> objectMap = !OPLUtils.isObjectNullOrEmpty(finalListOfObjects) ? finalListOfObjects.stream().filter(x1 -> x1.get("month").toString().equals(o.toString())).findFirst() : Optional.empty();
                    x.put("chartLabel", x.get("month"));
//                    x.put("totalCount", objectMap.isPresent() ? objectMap.get().get("totalCount") : 0);
                    x.put("totalCount", objectMap.isPresent() ? objectMap.get().get("totalCount") : 0);
                    x.put("sendToInsurerCount", objectMap.isPresent() ? objectMap.get().get("sendToInsurerCount") : 0);
                    x.put("approvedCount", objectMap.isPresent() ? objectMap.get().get("approvedCount") : 0);
                    x.put("repudiatedCount", objectMap.isPresent() ? objectMap.get().get("repudiatedCount") : 0);
                });
            }
            return new CommonResponse(monthFromDateRange, "SuccessFully get Month Wise report", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Month Wise report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    @Cacheable(value = "rpt_getDayWiseReport", key = "{#request, #userId}")
    public CommonResponse getDayWiseReport(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
            Integer year = filterJSON.has(YEAR) ? filterJSON.get(YEAR).asInt() : null;
            Integer month = filterJSON.has(MONTH) ? filterJSON.get(MONTH).asInt() : null;
            Integer insuranceType = filterJSON.has(INSURANCE_TYPE) ? filterJSON.get(INSURANCE_TYPE).asInt() : null;
            int startMonth = (type == 1) ? 4 : 6;
            String spName = insuranceType == 1 ? JNS_REPORTS + "get_day_wise_enroll_report_v5" : JNS_REPORTS + "get_day_wise_claim_report_v5";

            Map<String, Object> monthDateRange = ReportUtils.getDayDateRange(year, month, startMonth);
            String fromDate = monthDateRange.get("startDate").toString();
            String toDate = monthDateRange.get("endDate").toString();
            String getMonthWiseCount = commonRepository.getReportByDateFilter(request, userId, fromDate, toDate, spName);
            if (!OPLUtils.isObjectNullOrEmpty(getMonthWiseCount)) {
//                Map<String, Object> mapResult = MultipleJSONObjectHelper.getMapFromString(getYearCount);
                return new CommonResponse(getMonthWiseCount, "SuccessFully get Day Wise report", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("Exception is getting while get Day Wise report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    @Cacheable(value = "rpt_getAgingChartReport", key = "{#request, #userId}")
    public CommonResponse getAgingChartReport(String request, Long userId) {
        try {
//            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
//            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
//            Integer year = filterJSON.has(YEAR) ? filterJSON.get(YEAR).asInt() : null;
//            Integer month = filterJSON.has(MONTH) ? filterJSON.get(MONTH).asInt() : null;
//            int startMonth = (type == 1) ? 4 : 6;
            String spName = JNS_REPORTS + "get_aging_chart_report_v5";

//            Map<String, Object> monthDateRange = ReportUtils.getDayDateRange(Integer.valueOf(year), month, startMonth);
//            String fromDate = monthDateRange.get("startDate").toString();
//            String toDate = monthDateRange.get("endDate").toString();
            String getMonthWiseCount = commonRepository.getDataFromProducer(request, userId, spName);
            if (!OPLUtils.isObjectNullOrEmpty(getMonthWiseCount)) {
                return new CommonResponse(getMonthWiseCount, "SuccessFully get Aging Report", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("Exception is getting while get Aging Report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchMasterData(String listKey, String whereClause) {
        try {
            String spName = JNS_REPORTS + "sp_get_common_list_v5";
            return new CommonResponse(commonRepository.fetchMasterData(listKey, whereClause, spName), "SuccessFully get List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get fetchMasterData List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Transactional
    @Async
    public void updateRoZOBRANCH(Long orgId) {
        log.info("updating the orgId : {}", orgId);
        policyRepository.updateRoZOId(orgId);
    }

    private CommonResponse fetchEnrollmentCounts(String request, Long userId, String spName) {
        try {
            if (!OPLUtils.isObjectNullOrEmpty(spName)) {
                String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
                Object objectFromMap = MultipleJSONObjectHelper.getObjectFromString(dataFromProducer, Object.class);
                return new CommonResponse(objectFromMap, "SuccessFully get Enrollment Count", HttpStatus.OK.value());
            } else {

                String accepted = commonRepository.getDataFromProducer(request, userId, JNS_REPORTS + "fetch_enroll_counts_accept_endorse_v5");
                String rejected = commonRepository.getDataFromProducer(request, userId, JNS_REPORTS + "fetch_enroll_counts_rej_trans_failed_v5");
                String transactionFailed = commonRepository.getDataFromProducer(request, userId, JNS_REPORTS + "FETCH_ENROLL_COUNTS_TRANS_FAILED_V5");

                // .FETCH_ENROLL_COUNTS_REJ_TRANS_FAILED_V2

                Map<String, Object> counts = new HashMap<String, Object>();
                Map<String, Object> rejectedString = null;
                Map<String, Object> acceptedString = null;
                Map<String, Object> transactionFailedString = null;
                if (!OPLUtils.isObjectNullOrEmpty(accepted)) {
                    acceptedString = MultipleJSONObjectHelper.getMapFromString(accepted);
                    if (!OPLUtils.isObjectNullOrEmpty(acceptedString)) {
                        counts.put("acceptedCount", acceptedString.get("acceptedCount"));
                    }
                }
                if (!OPLUtils.isObjectNullOrEmpty(rejected)) {
                    rejectedString = MultipleJSONObjectHelper.getMapFromString(rejected);
                    if (!OPLUtils.isObjectNullOrEmpty(rejectedString)) {
                        counts.put("rejectedCount", rejectedString.get("rejectedCount"));
                        counts.put("transactionInProgressCount", !OPLUtils.isObjectNullOrEmpty(rejectedString.get("transactionInProgressCount")) ? rejectedString.get("transactionInProgressCount") : 0);
//	        		counts.put("totalCount",rejectedString.get("totalCount"));
                    }
                }
                if (!OPLUtils.isObjectNullOrEmpty(transactionFailed)) {
                    transactionFailedString = MultipleJSONObjectHelper.getMapFromString(transactionFailed);
                    if (!OPLUtils.isObjectNullOrEmpty(transactionFailedString)) {
                        counts.put("transactionFailCount", !OPLUtils.isObjectNullOrEmpty(transactionFailedString.get("transactionFailedCount")) ? transactionFailedString.get("transactionFailedCount") : 0);
                        counts.put("transactionInProgressCount", !OPLUtils.isObjectNullOrEmpty(transactionFailedString.get("transactionInProgressCount")) ? transactionFailedString.get("transactionInProgressCount") : 0);
//	        		counts.put("totalCount",rejectedString.get("totalCount"));
                    }
                }

                counts.put("totalCount", null);
                if (!OPLUtils.isObjectNullOrEmpty(counts)) {
                    Object objectFromMap = MultipleJSONObjectHelper.getObjectFromMap(counts, Object.class);
                    return new CommonResponse(objectFromMap, "SuccessFully get Enrollment Count", HttpStatus.OK.value());
                } else {
                    return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
                }
            }

        } catch (Exception e) {
            log.error("Exception is getting while get Enrollment Count", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchLastUpdateOnDate(Integer insurerType, Integer reportType) {
        SchedularDate schedularDate = schedularDateRepository.findByTypeAndReportTypeAndIsActiveTrueOrderByIdDesc(insurerType, reportType);
        if (!OPLUtils.isObjectNullOrEmpty(schedularDate)) {
            return new CommonResponse(dateFormat.format(schedularDate.getEndDate()), "SuccessFully get schedular Date", HttpStatus.OK.value());
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
//    @Cacheable(value = "rpt_getDemographicReport", key = "{#request, #userId}")
    public CommonResponse getDemographicReport(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer type = filterJSON.has(TYPE) ? filterJSON.get(TYPE).asInt() : null;
            Integer insuranceType = filterJSON.has(INSURANCE_TYPE) ? filterJSON.get(INSURANCE_TYPE).asInt() : null;
            int startMonth = (type == 1) ? 4 : 6;

            String yearRange = configProperties.getValue("BANKER_DASHBOARD_YEAR_RANGE");
            if (OPLUtils.isObjectNullOrEmpty(yearRange)) {
                return new CommonResponse("year Range Not Found From Config JNS", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
            }

            List<Map<String, Object>> yearDateRange = ReportUtils.getYearDateRange(Integer.valueOf(yearRange), startMonth);
            String spName = insuranceType == 1 ? JNS_REPORTS + "GET_DEMOGRAPHIC_POLICY_REPORT_V5" : JNS_REPORTS + "GET_DEMOGRAPHIC_CLAIM_REPORT_V5";
            List<Map<String, Object>> mapList = new ArrayList<>();
            for (int i = 0; i < yearDateRange.size(); i++) {
                Map<String, Object> map = yearDateRange.get(i);
                String fromDate = map.get("startDate").toString();
                String toDate = map.get("endDate").toString();
                String getYearCount = commonRepository.getReportByDateFilter(request, userId, fromDate, toDate, spName);
                if (!OPLUtils.isObjectNullOrEmpty(getYearCount)) {
                    Map<String, Object> mapResult = MultipleJSONObjectHelper.getMapFromString(getYearCount);
                    mapResult.put("chartLabel", map.get("yearRangeLabel").toString());
                    mapList.add(mapResult);
                }
            }
//            return new CommonResponse(reportRepository.getStateWiseReport(request, authClientResponse.getUserId()), "SuccessFully get state wise report", HttpStatus.OK.value());
            return new CommonResponse(mapList, "SuccessFully get year wise report", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get year wise report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse getChannelReport(String request, Long userId) {
        try {
            String data = commonRepository.getDataFromProducer(request, userId, (JNS_REPORTS + "GET_CHANNEL_WISE_REPORT"));
            if (!OPLUtils.isObjectNullOrEmpty(data)) {
                List<Map<String, Object>> mapFromString = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
                return new CommonResponse(mapFromString, "SuccessFully get Channel wise report", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("Exception is getting while get Channel Wise Report", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchPreRenewalCounts(String request, Long userId) {
        String spName = JNS_REPORTS + "pre_renewal_dashboard_counts_v5";
        String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
        if (!OPLUtils.isObjectNullOrEmpty(dataFromProducer)) {
            return new CommonResponse(dataFromProducer, "SuccessFully get preRenewal Count", HttpStatus.OK.value());
        }
        return new CommonResponse(null, "Not found preRenewal Count", HttpStatus.NOT_FOUND.value());

    }

    @Override
    public CommonResponse fetchPreRenewalListView(String request, AuthClientResponse authClientResponse) {
        String spName = JNS_REPORTS + "pre_renewal_dashboard_list_view_v5";
        String dataFromProducer = commonRepository.getDataFromProducer(request, authClientResponse.getUserId(), spName);
        if (!OPLUtils.isObjectNullOrEmpty(dataFromProducer)) {
            return new CommonResponse(dataFromProducer, "SuccessFully get preRenewal List View", HttpStatus.OK.value());
        }
        return new CommonResponse("Not found preRenewal List View", HttpStatus.NOT_FOUND.value());
    }

    @Override
    public CommonResponse fetchPreRenewalFailedData(String request, Long userId) {
        String spName = JNS_REPORTS + "pre_renewal_dashboard_failed_data_v5";
        String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
        if (!OPLUtils.isObjectNullOrEmpty(dataFromProducer)) {
            return new CommonResponse(dataFromProducer, "SuccessFully get preRenewal Failed Data", HttpStatus.OK.value());
        }
        return new CommonResponse("Not found preRenewal Failed Data", HttpStatus.NOT_FOUND.value());
    }

//	@Override
//	public CommonResponse fetchPreRenewalSuccessCount(String request, Long userId) {
//        String spName = JNS_REPORTS + "pre_renewal_success_count_v5";
//        String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
//        if (!OPLUtils.isObjectNullOrEmpty(dataFromProducer)) {
//            return new CommonResponse(dataFromProducer, "SuccessFully get preRenewal Failed Data", HttpStatus.OK.value());
//        }
//        return new CommonResponse("Not found preRenewal Failed Data", HttpStatus.NOT_FOUND.value());
//    }

	@Override
	public CommonResponse fetchPreRenewalSuccessDeficientData(String request, Long userId) {
        String spName = JNS_REPORTS + "pre_renewal_dashboard_success_deficient_data_v5";
        String dataFromProducer = commonRepository.getDataFromProducer(request, userId, spName);
        if (!OPLUtils.isObjectNullOrEmpty(dataFromProducer)) {
            return new CommonResponse(dataFromProducer, "SuccessFully get preRenewal Failed Data", HttpStatus.OK.value());
        }
        return new CommonResponse("Not found preRenewal Failed Data", HttpStatus.NOT_FOUND.value());
    }
}
