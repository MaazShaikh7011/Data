package com.opl.jns.common.service.report.scheduler;

import com.opl.jns.common.service.report.repository.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import jakarta.transaction.Transactional;

@Component
@Transactional
@Slf4j
public class ReportScheduler {

    @Autowired
    private CommonRepository commonRepository;

    private static final String JNS_REPORTS = ""; // JNS_REPORTS ".";

    @Scheduled(cron = "${croneForReport}")
    public void pushTheCountInReport() {
        try {
            log.info("START UPDATE POLICY DATA ------------------");
            commonRepository.schedulerQueryForPolicy(JNS_REPORTS + "push_data_to_policy_v5");
            log.info("END UPDATE POLICY DATA ------------------");
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPDATE POLICY DATA ------------------", e);
        }
    }

    @Scheduled(cron = "${croneForReport}")
    public void pushTheCountInDemographicReport() {
        try {
            log.info("START UPDATE DEMOGRAPHIC POLICY DATA ------------------");
            commonRepository.schedulerQueryForPolicy(JNS_REPORTS + "push_data_to_policy_demographic_v5");
            log.info("END UPDATE DEMOGRAPHIC POLICY DATA ------------------");
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPDATE DEMOGRAPHIC POLICY DATA ------------------", e);
        }

    }

    @Scheduled(cron = "${croneForReport}")
    public void pushTheCountInChannelReport() {
        try {
            log.info("START UPDATE CHANNEL POLICY DATA ------------------");
            commonRepository.schedulerQueryForPolicy(JNS_REPORTS + "push_data_to_policy_channel_v5");
            log.info("END UPDATE CHANNEL POLICY DATA ------------------");
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPDATE CHANNEL POLICY DATA ------------------", e);
        }
    }

    @Scheduled(cron = "${croneForPushDailyCount}")
    public void pushDailyCount() {
        try {
            log.info("PUSH_DAILY_COUNT ------------------");
            commonRepository.schedulerQueryForPolicy(JNS_REPORTS + "PUSH_DAILY_COUNT");
            log.info("END PUSH DAILY COUNT DATA ------------------");
        } catch (Exception e) {
            log.error("EXCEPTION WHILE PUSH DAILY COUNT DATA ------------------", e);
        }
    }

}
