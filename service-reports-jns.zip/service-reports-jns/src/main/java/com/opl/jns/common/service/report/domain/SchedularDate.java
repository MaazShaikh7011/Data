package com.opl.jns.common.service.report.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "schedular_date")
public class SchedularDate {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "schedular_date_seq_gen")
	@SequenceGenerator(schema = "jns_reports", name = "schedular_date_seq_gen", sequenceName = "schedular_date_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "type")
	private Integer type;

	@Column(name = "report_type")
	private Integer reportType;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "modified_date")
	private Date modifiedDate;

	public SchedularDate(Date startDate, Date endDate, Integer type, Integer reportType) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.type = type;
		this.reportType = reportType;
	}

}
