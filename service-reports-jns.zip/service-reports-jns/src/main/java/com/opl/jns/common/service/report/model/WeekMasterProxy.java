package com.opl.jns.common.service.report.model;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import java.util.Date;

@Data
public class WeekMasterProxy {
    private Date fromDate;
    private Date toDate;
    private Long version;
}
