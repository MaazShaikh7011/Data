package com.opl.jns.common.service.report.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.common.service.report.model.ReportProxy;
import com.opl.jns.common.service.report.service.ReportsService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.enums.UserRoleMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@RestController
//@RequestMapping("/")
@Slf4j
public class ReportsController {

    @Autowired
    private ReportsService reportsService;

    @PostMapping(value = "/fetchEnrollmentCounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchEnrollmentCounts(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            CommonResponse commonResponse = null;
            if (Objects.equals(authClientResponse.getUserRoleId(), UserRoleMaster.BRANCH_CHECKER.getId())) {
                commonResponse = reportsService.fetchEnrollmentCountsBo(request, authClientResponse.getUserId());
            } else {
                commonResponse = reportsService.fetchEnrollmentCountsWithCaches(request, authClientResponse.getUserId());
            }
            return new ResponseEntity<>(commonResponse, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchEnrollmentList(@RequestBody String request,
                                                              @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchEnrollmentList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchIssuedAndSavedEnrollmentAppList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchIssuedAndSavedEnrollmentAppList(@RequestBody String request,
                                                                               @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchIssuedAndSavedEnrollmentAppList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchClaimCounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchClaimCounts(@RequestBody String request,
                                                           @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
//        	 CommonResponse commonResponse = null;
//        	 commonResponse = reportsService.fetchClaimCounts(request, authClientResponse.getUserId());
//        	   return new ResponseEntity<>(commonResponse, HttpStatus.OK);
            return new ResponseEntity<>(reportsService.fetchClaimCounts(request, authClientResponse.getUserId()), HttpStatus.OK);
            
        } catch (Exception e) {
            log.error("Exception while fetchClaimCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchClaimList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchClaimList(@RequestBody String request,
                                                         @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchClaimList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchSavedClaimAppList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchSavedClaimAppList(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchSavedClaimAppList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


    @PostMapping(value = "/getTopOffice", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getTopOffice(@RequestBody String request,
                                                       @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getTopOffice(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getStateWiseReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getStateWiseReport(@RequestBody String request,
                                                             @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getStateWiseReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getYearWiseReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getYearWiseReport(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getYearWiseReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getMonthWiseReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getMonthWiseReport(@RequestBody String request,
                                                             @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getMonthWiseReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getDayWiseReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getDayWiseReport(@RequestBody String request,
                                                           @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getDayWiseReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getDayWiseReport ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getAgingChartReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getAgingChartReport(@RequestBody String request,
                                                              @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getAgingChartReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getDayWiseReport ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ENUM MASTER LIST BY REQUESTED NAME
     *
     * @param request
     * @param authClientResponse
     * @return OLD : getCommonList
     */
    @PostMapping(value = "/fetchMasterData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchMasterData(@RequestBody ReportProxy request,
                                                          @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchMasterData(request.getListKey(),
                    request.getWhereClause()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch common master list  ==>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/fetchLastUpdateOnDate/{insurerType}/{reportType}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchSchedularDate(@PathVariable Integer insurerType,@PathVariable Integer reportType) {
    	try {
    		return new ResponseEntity<>(reportsService.fetchLastUpdateOnDate(insurerType,reportType),HttpStatus.OK);
    	} catch (Exception e) {
    		log.error("Exception while fetch common master list  ==>", e);
    		return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
    	}
    }

    @PostMapping(value = "/getDemographicReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getDemographicReport(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getDemographicReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getChannelReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getChannelReport(@RequestBody String request,
                                                               @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.getChannelReport(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getChannelReport ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/fetchPreRenewalCounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPreRenewalCounts(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchPreRenewalCounts(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchPreRenewalListView", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPreRenewalListView(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchPreRenewalListView(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPreRenewalListView ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchPreRenewalFailedData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPreRenewalFailedData(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchPreRenewalFailedData(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPreRenewalFailedData ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
    
//    @PostMapping(value = "/fetchPreRenewalSuccessCount", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<CommonResponse> fetchPreRenewalSuccessCount(@RequestBody String request,
//                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
//        try {
//            return new ResponseEntity<>(reportsService.fetchPreRenewalSuccessCount(request, authClientResponse.getUserId()), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error("Exception while fetchPreRenewalListView ------>", e);
//            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//        }
//    }
    
    @PostMapping(value = "/fetchPreRenewalSuccessDeficientData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPreRenewalSuccessDeficientData(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(reportsService.fetchPreRenewalSuccessDeficientData(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPreRenewalSuccessDeficientData ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
}
