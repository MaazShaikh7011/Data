package com.opl.jns.common.service.report.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "temp")
public class Temp {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "temp_seq_gen")
    @SequenceGenerator(schema = "jns_reports", name = "temp_seq_gen", sequenceName = "temp_seq_gen", allocationSize = 1)
    private Long id;
}
