package com.opl.jns.common.service.report.model;

import lombok.Data;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@Data
public class ReportProxy {

    private String filterJSON;
    private Integer branchType;
    private Integer type;
    private String listKey;
    private String whereClause;

}
