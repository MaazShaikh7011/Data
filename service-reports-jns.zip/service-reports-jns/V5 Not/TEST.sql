CREATE OR REPLACE PROCEDURE JNS_REPORTS."TEST" (result OUT CLOB) AS
BEGIN

    INSERT INTO JNS_REPORTS.app_master
        select am.id FROM USR_INSURANCE.application_master am  WHERE 1=1  AND am.scheme_id = 2 AND am.stage_id IN (6, 8)  AND am.org_Id = 13
                    AND am.is_active = 1  OFFSET 100 ROWS FETCH NEXT 10 ROWS ONLY;
  SELECT json_arrayagg(json_object('totalcount' value 604568, 'id' value am.id,
                'applicationId' value am.id,
                'source' value (case when amod.source = 1 then 'Other Channel' when amod.source=2 then 'JanSuraksha' end),
                'urn' value am.urn,
                'cif' value am.cif,
                'customerAccountNumber' value am.account_number,
                'application_status' value am.application_status,
                'branch_id' value am.branch_id,
                'createdDate' value am.created_date,
                'enrollDate' value am.enrollment_date,
                'message' value am.message,
                'modifiedDate' value am.modified_date,
                'orgId' value am.org_id,
                'mobileNumber' value ai.mobile_number,
                'dob' value ai.dob,
                'schemeName' value sm.short_name,
                'schemeId' value am.scheme_id,
                'stageId' value am.stage_id,
                'insurerName' value uom.DISPLAY_ORG_NAME,
                'gender' value GEN.value,
                'organisationCode' value uomb.ORGANISATION_CODE,
                'organisationName' value uomb.ORGANISATION_NAME,
                'branchName' value bm.name,
                'roName' value bmro.name,
                'roCode' value bmro.code,
                'zoName' value bmzo.name,
                'zoCode' value bmzo.code,
                'pincode' value adm.pincode,
                'city' value adm.city_name,
                'district' value adm.district,
                'state' value adm.state_name,
                'nomineeName' value concat(concat(nd.first_name,' '),nd.last_name),
                'dateOfBirth' value nd.dob,
                'ralationNomineeApplicant' value REL.value,
                'panNumber' value nd.pan_number,
                'ralationNomineeApplicant' value REL.value,
                'nameGuardian' value (concat(concat(gd.first_name,' '),gd.last_name)),
                'ralationNomineeguardian' value RELD.value,
                'dateOfAutoDebit' value td.trans_time_stamp,
                'dateOfAutoCredit' value td.trans_time_stamp,
                'transectionUtr' value td.trans_utr,
                'transactionAmount' value td.trans_amount,
                'associatedAccNo' value imd.MASTER_POLICY_NO,
                'masterPolicyNo' value td.master_policy_no,
                'geo' value amod.rural_urban_semi,
                'channelId' value amod.channel_id,
                'userId1' value usr.email,
                'userId2' value usr.email,
                'transactionType' value (case when td.type=1 then 'New Enrollment' when td.type=2 then 'Endorsement' end),
                'fatherHusbandName' value ai.father_husband_name,
                'kycIdName' value ai.kyc_id_1,
                'pan' value ai.pan,
                'aadhar' value ai.aadhaar,
                'name' value ai.name) RETURNING CLOB)  INTO result
                FROM USR_INSURANCE.application_master am
                INNER JOIN JNS_REPORTS.app_master amm on amm.app_id = am.id
--                    INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                     INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                    LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                    LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id=am.id
                    LEFT JOIN USR_INSURANCE.insurer_mst_details imd ON imd.id=td.insurer_master_id
                    LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id=am.insurer_org_id
                    LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=am.org_id
                    LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id
                    LEFT JOIN USR_INSURANCE.address_master adm ON adm.id=ai.address_id
                    LEFT JOIN USR_INSURANCE.nominee_details nd ON nd.application_id=am.id and nd.type=1
                    LEFT JOIN USR_INSURANCE.nominee_details gd ON gd.application_id=am.id and gd.type=3
                    LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=ai.gender_id AND GEN.dropdown_id=8
                    LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=nd.relation_id AND REL.dropdown_id=1
                    LEFT JOIN jns_oneform.dropdowns_values RELD ON RELD.obj_id=gd.relation_id AND RELD.dropdown_id=1
                    LEFT JOIN jns_users.users usr ON usr.user_id=am.created_by
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id WHERE am.id IN(select app_id from JNS_REPORTS.app_master);

                    DBMS_OUTPUT.PUT_LINE(result);
END TEST;

