CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_YEAR_WISE_ENROLL_REPORT_V1" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                         fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                         todate     IN  VARCHAR2 DEFAULT NULL,
                                                         userid     IN  NUMBER   DEFAULT NULL,
                                                         result     OUT CLOB)
  AS
    selectquery CLOB;
    whereclause CLOB;
    mainquery   CLOB;
    tablequery  CLOB;
    amodwhereclause CLOB;
    typeid      NUMBER;
    roleid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
  BEGIN
--    selectquery := ' select JSON_OBJECT( ''totalCount'' value count(am.id),
--            ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
--            ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end)) ';

    selectquery := ' select JSON_OBJECT( ''totalCount'' value count(am.id),
            ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
            ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end)) ';

    tablequery := ' from USR_INSURANCE.application_master am ';

    amodwhereclause := ' am.org_Id = amod.org_Id AND ';

    whereclause := ' WHERE 1=1 ';

    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        
        IF (roleid = 13 OR roleid = 14 OR roleid = 15) THEN
            tablequery := CONCAT(tablequery, ' INNER JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id ');
        END IF;
        IF (typeid IS NOT NULL) THEN
            IF (typeid != 4) THEN -- FOR MINISTRY DON'T NEED THIS CONDITION
                IF (typeid = 2) THEN
                    whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
                    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
                       whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
                    END IF;
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    END IF;
    --              ELSE
    --                whereclause := CONCAT(whereclause, ' ');
                  END IF;
                ELSIF typeid = 6 THEN
                    whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgId);
                    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
                       whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
                    END IF;
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

    whereclause := CONCAT(whereclause, ' AND am.stage_id in(6,8) ');

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF (fromdate IS NOT NULL and todate IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' and am.modified_date BETWEEN  TO_TIMESTAMP('''|| fromdate ||''', ''YYYY-MM-DD'') and TO_TIMESTAMP('''|| todate ||''', ''YYYY-MM-DD'')');
--        dbms_output.put_line(whereclause);
    END IF;
    
    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

--    dbms_output.put_line(whereclause);

    mainquery := selectquery || tablequery || whereclause;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery INTO result;
--    dbms_output.put_line(result);

  END GET_YEAR_WISE_ENROLL_REPORT_V1;