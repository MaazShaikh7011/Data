CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ISSUED_AND_SAVED_ENROLLMENT_LIST_ENC" (filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    userorgid       LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    --    userorgid := 1;
    --dbms_output.put_line(userid);
    SELECT user_org_id
      INTO userorgid
      FROM jns_users.users
      WHERE user_id = userid;
    --        dbms_output.put_line(filterjson);

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
--          dbms_output.put_line(typeid);
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (roleid IS NOT NULL
            AND roleid != 5)
          THEN
            IF (roleid = 9)
            THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
            ELSIF (roleid = 15)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' AND 0 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' AND 0 ');
          END IF;
        ELSIF (typeid = 6)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' AND 0 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' AND 0 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' AND 0 ');
    END IF;


    fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';

    appcodequery := '(am.urn LIKE ''%' || JSON_VALUE (filterjson, '$.applicationCode') || '%'')';

    accnoquery := '(am.account_number LIKE ''%' || jns_users.encvalue(JSON_VALUE (filterjson, '$.searchData')) || '%'')';

    selectquery := ' ''id'' value am.id,
                ''schemeName'' value sm.short_name,
                ''applicationId'' value am.id,
                ''urn'' value am.urn,
                ''customerAccountNumber'' value jns_users.decvalue(am.account_number),
                ''application_status'' value am.application_status,
                ''branch_id'' value am.branch_id,
                ''createdDate'' value am.created_date,
                ''enrollDate'' value am.enrollment_date,
                ''message'' value am.message,
                ''modifiedDate'' value am.modified_date,
                ''orgId'' value am.org_id,
                ''schemeName'' value sm.short_name,
                ''stageId'' value am.stage_id,
                ''mobileNumber'' value jns_users.decvalue(ai.mobile_number),
                ''name'' value case when ai.name is not null then jns_users.decvalue(ai.name) else null end ';
    tablequery := ' FROM USR_INSURANCE.application_master am
                    INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                    LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1 ';
    whereclause := ' WHERE am.is_active = 1
                    AND am.org_id =' || userorgid || '
                    AND am.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId');

    IF typeid IS NOT NULL
      AND typeid != 5
    THEN
      whereclause := CONCAT(whereclause, ' AND am.created_by =' || userId);
    END IF;


    --    dbms_output.put_line(filterjson);
    IF JSON_VALUE (filterjson, '$.pageType') IS NOT NULL
    THEN
      IF JSON_VALUE (filterjson, '$.pageType') = 1
      THEN
        whereclause := whereclause || ' AND am.stage_id IN (6, 7) ';
      ELSIF JSON_VALUE (filterjson, '$.pageType') = 2
      THEN
        whereclause := whereclause || ' AND am.stage_id IN (4,5) ';
      END IF;
    END IF;

    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND ((ai.name LIKE ''%'
      || jns_users.encvalue(JSON_VALUE (filterjson, '$.searchData'))
      || '%'') or (am.urn LIKE ''%'
      || jns_users.encvalue(JSON_VALUE (filterjson, '$.searchData'))
      || '%'') or (am.account_number LIKE ''%'
      || jns_users.encvalue(JSON_VALUE (filterjson, '$.searchData'))
      || '%''))';
    END IF;

    IF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NULL
    THEN
      whereclause := CONCAT(whereclause, fromtodatequery);
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || appcodequery
      || ' AND '
      || accnoquery
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || appcodequery
      || ' AND '
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || accnoquery
      || ' AND '
      || fromtodatequery;
    ELSIF
      JSON_VALUE (filterjson, '$.fromDate') IS NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NULL
      AND JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND '
      || accnoquery
      || ' AND '
      || appcodequery;
    ELSIF JSON_VALUE (filterjson, '$.accountNumber') IS NOT NULL
    THEN
      whereclause := whereclause || ' AND ' || accnoquery;
    ELSIF JSON_VALUE (filterjson, '$.applicationCode') IS NOT NULL
    THEN
      whereclause := whereclause || ' AND ' || appcodequery;
    END IF;

    IF
      JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
    THEN

      limitquery := ' OFFSET '
      || JSON_VALUE (filterjson, '$.paginationFROM')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.paginationTO')
      || ' ROWS ONLY';
    ELSE
      limitquery := '';
    END IF;

    --        dbms_output.put_line(limitquery);

    EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || tablequery || whereclause  INTO totalcount;

    preparequery := 'SELECT json_arrayagg(json_object(''totalcount'' value '
    || totalcount
    || ', '
    || selectquery
    || ')RETURNING CLOB) '
    || tablequery
    || whereclause
    || limitquery;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  --    dbms_output.put_line(result);
  END ;

