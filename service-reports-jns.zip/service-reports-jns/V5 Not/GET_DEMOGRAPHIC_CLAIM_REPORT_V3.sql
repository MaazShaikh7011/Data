CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_DEMOGRAPHIC_CLAIM_REPORT_V3" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                         fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                         todate     IN  VARCHAR2 DEFAULT NULL,
                                                         userid     IN  NUMBER   DEFAULT NULL,
                                                         result     OUT CLOB)
  AS
    selectquery CLOB;
    whereclause CLOB;
    mainquery   CLOB;
    tablequery  CLOB;
--    amodwhereclause CLOB;
    typeid      NUMBER;
    roleid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
    maleColumn    clob;
    femaleColumn    clob;
    otherColumn    clob;
  BEGIN

    maleColumn := 'case when ai.gender_id = 1 then 1 else 0 end';
    femaleColumn := 'case when ai.gender_id = 2 then 1 else 0 end';
    otherColumn := 'case when ai.gender_id = 3 then 1 else 0 end';
    
    selectquery := ' select JSON_OBJECT(''maleCount'' value sum('|| maleColumn ||'),
                    ''femaleCount'' value sum('|| femaleColumn ||'),
                    ''otherCount'' value sum('|| otherColumn ||')) ';
--    DBMS_OUTPUT.PUT_LINE(selectquery);

    tablequery := ' FROM USR_INSURANCE.claim_master cm
                    INNER JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = cm.APPLICATION_ID ';
    

    whereclause := ' WHERE 1=1 ';

    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid IS NOT NULL) THEN
--            IF (typeid != 4) THEN -- FOR MINISTRY DON'T NEED THIS CONDITION
                IF (typeid = 2) THEN                   
                    whereclause := CONCAT(whereclause, ' AND cm.org_Id = ' || orgid);
                    IF (roleid IS NOT NULL AND roleid != 5) THEN
                        IF (roleid = 13 OR roleid = 14) THEN
                           tablequery := concat(tablequery, 'INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = cm.id ');
                        END IF;
                        IF (roleid = 9) THEN
                            whereclause := CONCAT(whereclause, ' AND cm.claim_branch_id = ' || branchid);
                        ELSIF (roleid = 13) THEN
                            whereclause := CONCAT(whereclause, ' AND cd.BRANCH_RO_ID = ' || branchid);
                        ELSIF (roleid = 14) THEN
                            whereclause := CONCAT(whereclause, ' AND cd.BRANCH_ZO_ID = ' || branchid);
                        ELSE
                            whereclause := CONCAT(whereclause, ' AND 1=2 ');
                        END IF;
        --              ELSE
        --                whereclause := CONCAT(whereclause, ' ');
                      END IF;
                ELSIF typeid = 6 THEN
                    tablequery := concat(tablequery, 'INNER JOIN USR_INSURANCE.application_master am ON am.id = cm.APPLICATION_ID ');
                    whereclause := CONCAT(whereclause, ' AND (am.INSURER_ORG_ID ' || orgId || ') ');
                ELSIF typeid = 4 THEN
                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
--            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND cm.scheme_id  = ' || JSON_VALUE(filterjson, '$.schemeId'));
    END IF;
    
    IF (fromdate IS NOT NULL and todate IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' AND cm.claim_date between TO_DATE('''|| fromdate ||''', ''YYYY-MM-DD'') and TO_DATE('''|| todate ||''', ''YYYY-MM-DD'')');
    END IF;
    
    IF (JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL and JSON_VALUE(filterjson, '$.toDate') IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' AND cm.claim_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;

    whereclause := CONCAT(whereclause, ' AND cm.claim_stage_id in(14) ');

--    dbms_output.put_line(whereclause);

    mainquery := selectquery || tablequery || whereclause;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery INTO result;
    dbms_output.put_line(result);

  END GET_DEMOGRAPHIC_CLAIM_REPORT_V3;