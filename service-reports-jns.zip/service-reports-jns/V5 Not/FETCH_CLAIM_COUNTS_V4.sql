CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_CLAIM_COUNTS_V4" (filterjson IN  "VARCHAR",
                                                userid     IN  NUMBER,
                                                result     OUT CLOB)
  AS
    preparequery    CLOB;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' SELECT JSON_OBJECT(
          ''inProgressCount'' value SUM(CASE WHEN status = 5 OR status = 6  THEN 1 ELSE 0 END),
          ''sendToInsurerCount'' value SUM(CASE WHEN status = 6 THEN 1 ELSE 0 END),
          ''receivedFromBankCount'' value SUM(CASE WHEN status = 6 THEN 1 ELSE 0 END),
          ''sendBackByInsurerCount'' value SUM(CASE WHEN status = 7 THEN 1 ELSE 0 END),
          ''sendBackToBnakCount'' value SUM(CASE WHEN status = 7 THEN 1 ELSE 0 END),
          ''rejectedCount'' value SUM(CASE WHEN status = 8  THEN 1 ELSE 0 END),
          ''onHoldCount'' value SUM(CASE WHEN status = 9 THEN 1 ELSE 0 END),
          ''acceptedCount'' value SUM(CASE WHEN status = 10  THEN 1 ELSE 0 END)
--          ''inProgressCount'' value SUM(CASE WHEN status = 11 THEN 1 ELSE 0 END)
          ) ';

    IF ((JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL) AND (JSON_VALUE (FILTERJSON, '$.schemeId') = 1))
    THEN
      tablequery := 'INNER JOIN JNS_MASTER_DATA.PMSBY scm ON scm.id = ca.application_id';
      ELSE
      tablequery := 'INNER JOIN JNS_MASTER_DATA.PMJJBY scm ON scm.id = ca.application_id';
    END IF;
    
    tablequery := ' FROM USR_INSURANCE.clm_master ca 
                        INNER JOIN USR_INSURANCE.clm_details cd ON cd.id = ca.id ';
    whereclause := ' WHERE ca.is_active = 1 ';

    IF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      --   dbms_output.put_line(typeid || branchid || orgid || roleid );
      IF typeid IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND ca.branch_lho_id = ' || branchid);
            ELSE
              whereclause := ' and 1 = 2 ';
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || orgid);
        ELSE
          whereclause := ' and 1 = 2 ';
        END IF;

      ELSE
        whereclause := ' and 1 = 2 ';
      END IF;

    ELSE
      whereclause := ' and 1 = 2 ';
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.stage_id = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND scm.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
--        dbms_output.put_line(result);
  END ;