CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_LIST_V1" (
    filterjson  IN   CLOB,
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS

    totalcount            LONG;
    selectquery           CLOB;
    fromtodatequery       CLOB;
    maintablequery        CLOB;
    tablequery            CLOB;
    mainwhereclause       CLOB;
    whereclause           CLOB;
    amodwhereclause       CLOB;
    limitquery            CLOB;
    preparequery          CLOB;
    orderby               CLOB;
    totalcounttablequery  CLOB;
    roleid                NUMBER;
    typeid                NUMBER;
    orgid                 NUMBER;
    branchid              NUMBER;
    insertquery           CLOB;
    appIds                  clob;
BEGIN
    selectquery := '''id'' value am.id,
                ''applicationId'' value am.id,
                ''source'' value (case when amod.source = 1 then ''Other Channel'' when amod.source=2 then ''JanSuraksha'' end),
                ''urn'' value am.urn,
                ''cif'' value jns_users."decvalue"(am.cif),
                ''customerAccountNumber'' value jns_users."decvalue"(am.account_number),
                ''application_status'' value am.application_status,
                ''branch_id'' value am.branch_id,
                ''createdDate'' value am.created_date,
                ''enrollDate'' value am.enrollment_date,
                ''message'' value am.message,
                ''modifiedDate'' value am.modified_date,
                ''orgId'' value am.org_id,
                ''mobileNumber'' value jns_users."decvalue"(ai.mobile_number),
                ''dob'' value jns_users."decvalue"(ai.dob),
                ''schemeName'' value sm.short_name,
                ''schemeId'' value am.scheme_id,
                ''stageId'' value am.stage_id,
                ''insurerName'' value uom.DISPLAY_ORG_NAME,
                ''gender'' value GEN.value,
                ''organisationCode'' value uomb.ORGANISATION_CODE,
                ''organisationName'' value uomb.ORGANISATION_NAME,
                ''branchName'' value bm.name,
                ''roName'' value bmro.name,
                ''roCode'' value bmro.code,
                ''zoName'' value bmzo.name,
                ''zoCode'' value bmzo.code,
                ''pincode'' value adm.pincode,
                ''city'' value adm.city_name,
                ''district'' value adm.district,
                ''state'' value adm.state_name,
                ''nomineeName'' value concat(concat(jns_users."decvalue"(nd.first_name),'' ''),jns_users."decvalue"(nd.last_name)),
                ''dateOfBirth'' value jns_users."decvalue"(nd.dob),
                ''ralationNomineeApplicant'' value REL.value,
                ''panNumber'' value jns_users."decvalue"(nd.pan_number),
                ''ralationNomineeApplicant'' value REL.value,
                ''nameGuardian'' value (concat(concat(jns_users."decvalue"(gd.first_name),'' ''),jns_users."decvalue"(gd.last_name))),
                ''ralationNomineeguardian'' value RELD.value,
                ''dateOfAutoDebit'' value jns_users."decvalue"(td.trans_time_stamp),
                ''dateOfAutoCredit'' value jns_users."decvalue"(td.trans_time_stamp),
                ''transectionUtr'' value jns_users."decvalue"(td.trans_utr),
                ''transactionAmount'' value td.trans_amount,
                ''associatedAccNo'' value jns_users."decvalue"(imd.master_policy_no),
                ''masterPolicyNo'' value jns_users."decvalue"(td.master_policy_no),
                ''geo'' value amod.rural_urban_semi,
                ''channelId'' value amod.channel_id,
                ''userId1'' value jns_users."decvalue"(usr.email),
                ''userId2'' value jns_users."decvalue"(usr.email),
                ''transactionType'' value (case when td.type=1 then ''New Enrollment'' when td.type=2 then ''Endorsement'' end),
                ''fatherHusbandName'' value jns_users."decvalue"(ai.father_husband_name),
                ''kycIdName'' value jns_users."decvalue"(ai.kyc_id_1),
                ''pan'' value jns_users."decvalue"(ai.pan),
                ''aadhar'' value ai.aadhaar,
                ''name'' value jns_users."decvalue"(ai.name)) RETURNING CLOB) ';


 whereclause := ' WHERE 1=1 ';
 amodwhereclause := ' ';

    -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO TAHT
    IF userid IS NOT NULL THEN
      SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
      IF (typeid) IS NOT NULL THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
            whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
          END IF;
          IF (roleid IS NOT NULL AND roleid != 5) THEN
            IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13) THEN
              amodwhereclause := CONCAT(amodwhereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14) THEN
              amodwhereclause := CONCAT(amodwhereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
            ELSIF (roleid = 15) THEN
              amodwhereclause := CONCAT(amodwhereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
--          ELSE
--            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        ELSIF typeid = 6 THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
           IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
              whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
           END IF;
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

 -- SET TAB WISE DATA TOTAL, APPROVE, REJECT
     IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL THEN
        IF JSON_VALUE (filterjson, '$.tabId') = 1 THEN
            whereclause := whereclause || ' AND am.stage_id IN (6, 8) ';
        ELSIF JSON_VALUE (filterjson, '$.tabId') = 2 THEN
            whereclause := whereclause || ' AND am.stage_id = 6 ';
        ELSIF JSON_VALUE (filterjson, '$.tabId') = 3 THEN
            whereclause := whereclause || ' AND am.stage_id = 8 ';
        END IF;
    END IF;

    -- DATE FILTER
    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')');
    END IF;

    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL THEN
      whereclause := whereclause || ' AND ((am.account_number = jns_users."encvalue"(''' || JSON_VALUE (filterjson, '$.searchData') || ''') OR am.urn = '''|| JSON_VALUE (filterjson, '$.searchData') ||'''))';
    END IF;

--    dbms_output.put_line(whereclause);

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
      amodwhereclause := CONCAT(amodwhereclause, ' AND amod.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL THEN
      amodwhereclause := CONCAT(amodwhereclause, ' AND amod.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL THEN
      amodwhereclause := amodwhereclause|| ' AND amod.source in (' || JSON_VALUE (filterjson, '$.channelId')||')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL THEN
      amodwhereclause := CONCAT(amodwhereclause, ' AND amod.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');


 maintablequery := ' FROM USR_INSURANCE.application_master am
                        INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id '|| amodwhereclause ||'
                        LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id ';

    tablequery := concat(maintablequery, ' LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id=am.id
                    LEFT JOIN USR_INSURANCE.insurer_mst_details imd ON imd.id=td.insurer_master_id
                    LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id=am.insurer_org_id
                    LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=am.org_id
                    LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id
                    LEFT JOIN USR_INSURANCE.address_master adm ON adm.id=ai.address_id
                    LEFT JOIN USR_INSURANCE.nominee_details nd ON nd.application_id=am.id and nd.type=1
                    LEFT JOIN USR_INSURANCE.nominee_details gd ON gd.application_id=am.id and gd.type=3
                    LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=ai.gender_id AND GEN.dropdown_id=8
                    LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=nd.relation_id AND REL.dropdown_id=1
                    LEFT JOIN jns_oneform.dropdowns_values RELD ON RELD.obj_id=gd.relation_id AND RELD.dropdown_id=1
                    LEFT JOIN jns_users.users usr ON usr.user_id=am.created_by
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id ');


--    dbms_output.put_line(' SELECT COUNT(am.id)' || maintablequery || whereclause);
    EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || maintablequery || whereclause
      INTO totalcount;


    IF JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL THEN
      limitquery := ' OFFSET ' || JSON_VALUE (filterjson, '$.paginationFROM') || ' ROWS FETCH NEXT ' || JSON_VALUE (filterjson, '$.paginationTO') || ' ROWS ONLY';
    -- dbms_output.put_line(limitquery);
    END IF;

    insertquery := ' INSERT INTO JNS_REPORTS.app_master 
                    select am.id '|| maintablequery || whereclause || limitquery;
                    DBMS_OUTPUT.PUT_LINE('select am.id '|| maintablequery || whereclause);
    EXECUTE IMMEDIATE insertquery;

--    select json_arrayagg(app_id) into appIds from JNS_REPORTS.app_master;
--    DBMS_OUTPUT.PUT_LINE(appIds);

--    mainwhereclause := ' WHERE am.id IN(select am.id FROM USR_INSURANCE.application_master am '|| whereclause || limitquery ||') ';    
    mainwhereclause := ' WHERE am.id IN(select app_id from JNS_REPORTS.app_master) ';    
    preparequery := 'SELECT json_arrayagg(json_object(''totalcount'' value ' || totalcount || ', ' || selectquery || tablequery || mainwhereclause;

--    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--      dbms_output.put_line(result);

END fetch_enrollment_list_v1;