CREATE OR REPLACE PROCEDURE JNS_REPORTS."PUSH_DATA_TO_POLICY_V4_NEW"
  AS
    name  CLOB;
    mainquery   CLOB;
    selectquery  CLOB;
    deletequery clob;
    yesterdate TIMESTAMP;
    currentdate TIMESTAMP;
  BEGIN
    
        SELECT TO_TIMESTAMP(concat(TO_DATE(current_date - 2), ' 11:59:59.000000 PM')) into yesterdate FROM dual;
        SELECT current_timestamp into currentdate FROM dual;

       deletequery := ' DELETE FROM JNS_REPORTS.policy  where enroll_date > '''|| yesterdate || '''';
--       dbms_output.put_line('delete' || deletequery);
       EXECUTE IMMEDIATE deletequery;
       commit;

   mainquery :=' INSERT INTO JNS_REPORTS.policy(ENROLL_DATE,ORG_ID,BRANCH_ID,state, PMJJBY_A_TOTAL, PMSBY_A_TOTAL, A_TOTAL,
                 PMJJBY_R_TOTAL,PMSBY_R_TOTAL,R_TOTAL,TOTAL_COUNT,PMJJBY_A_AMOUNT,PMSBY_A_AMOUNT,A_AMOUNT,PMJJBY_INSURER_ORG,
                 PMSBY_INSURER_ORG,PMJJBY_A_R_TOTAL,PMSBY_A_R_TOTAL ,PMSBY_ZO_ID,PMSBY_RO_ID,PMJJBY_ZO_ID,PMJJBY_RO_ID,CITY) '  ;
-- dbms_output.put_line(mainquery);

   selectquery := ' SELECT t.completion_date as completion_date,
                    MAX(t.org_Id) As ORG_ID,
                    t.branch_id as BRANCH_ID,
                    MAX(t.state_id) as state_id,
                    SUM(t.PMJJBY_A_TOTAL) as PMJJBY_A_TOTAL,
                    SUM(t.PMSBY_A_TOTAL) as PMSBY_A_TOTAL,
                    (SUM(t.PMJJBY_A_TOTAL) + SUM(t.PMSBY_A_TOTAL)) as A_TOTAL,
                    SUM(t.PMJJBY_R_TOTAL) as PMJJBY_R_TOTAL,
                    SUM(t.PMSBY_R_TOTAL) as PMSBY_R_TOTAL,
                    SUM(t.R_TOTAL) as R_TOTAL,
                    (SUM(t.PMJJBY_A_TOTAL) + SUM(t.PMSBY_A_TOTAL) + SUM(t.R_TOTAL)) as TOTAL_COUNT,
                    SUM(t.PMJJBY_A_AMOUNT) as PMJJBY_A_AMOUNT,
                    SUM(t.PMSBY_A_AMOUNT) as PMSBY_A_AMOUNT,
                    (SUM(t.PMJJBY_A_AMOUNT) + SUM(t.PMSBY_A_AMOUNT)) as A_AMOUNT,
                    MAX(t.PMJJBY_INSURER_ORG) as PMJJBY_INSURER_ORG,
                    MAX(t.PMSBY_INSURER_ORG) as PMSBY_INSURER_ORG,
                    (SUM(t.PMJJBY_A_TOTAL) + SUM(t.PMJJBY_R_TOTAL)) as PMJJBY_A_R_TOTAL,
                    (SUM(t.PMSBY_R_TOTAL) + SUM(t.PMSBY_A_TOTAL)) as PMSBY_A_R_TOTAL,
                    MAX(t.PMSBY_ZO_ID) AS PMSBY_ZO_ID,
                    MAX(t.PMSBY_RO_ID) AS PMSBY_RO_ID,
                    MAX(t.PMJJBY_ZO_ID) AS PMJJBY_ZO_ID,
                    MAX(t.PMJJBY_RO_ID) AS PMJJBY_RO_ID,
                    MAX(t.CITY) AS CITY
                    FROM (
                            SELECT TO_TIMESTAMP(CAST(p.completion_date AS DATE)) AS completion_date,   
                            MAX(p.org_Id) As ORG_ID,
                            p.branch_id AS BRANCH_ID,
                            MAX(p.branch_state_id) as state_id,
                            sum(case when p.status = 2 then 1 else 0 end) AS PMJJBY_A_TOTAL,
                            0 as PMSBY_A_TOTAL,
                        --	0 AS A_TOTAL,
                            0 as PMJJBY_R_TOTAL,
                            0 as PMSBY_R_TOTAL,
                        	0 as R_TOTAL,
                        --	0 as TOTAL_COUNT,
                            sum(case when p.status = 2 then p.premium_amount else 0 end) as PMJJBY_A_AMOUNT,
                            0 as PMSBY_A_AMOUNT,
                        	0 as A_AMOUNT,
                            max(case when p.status = 2 then p.insurer_org_id else null end) as PMJJBY_INSURER_ORG,
                            0 as PMSBY_INSURER_ORG,
                        --	0 as PMSBY_A_R_TOTAL,
                        --	0 as PMJJBY_A_R_TOTAL,
                            NULL  AS PMSBY_ZO_ID,
                            NULL  AS PMSBY_RO_ID,
                            MAX(p.branch_zo_id) AS PMJJBY_ZO_ID,
                            MAX(p.branch_ro_id) AS PMJJBY_RO_ID,
                            MAX(p.BRANCH_CITY_ID) AS CITY
                            FROM JNS_MASTER_DATA.PMJJBY p
                            WHERE p.completion_date > '''|| yesterdate ||'''
                            GROUP BY TO_TIMESTAMP(CAST(p.completion_date AS DATE)), p.branch_id
	
                     UNION ALL
	
                            SELECT TO_TIMESTAMP(CAST(p.completion_date AS DATE)) AS completion_date,
                            MAX(p.org_Id) As ORG_ID,
                            p.branch_id AS BRANCH_ID,
                            MAX(p.branch_state_id) as state_id,
                            0 AS PMJJBY_A_TOTAL,
                            sum(case when p.status = 2 then 1 else 0 end) as PMSBY_A_TOTAL,
                        --	0 AS A_TOTAL,
                            0 as PMJJBY_R_TOTAL,
                            0 as PMSBY_R_TOTAL,
                            0 as R_TOTAL,
                        --	0 as TOTAL_COUNT,
                            0 as PMJJBY_A_AMOUNT,
                            sum(case when p.status = 2 then p.premium_amount else 0 end) as PMSBY_A_AMOUNT,
                            0 as A_AMOUNT,
                            0 as PMJJBY_INSURER_ORG,
                            max(case when p.status = 2 then p.insurer_org_id else null end) as PMSBY_INSURER_ORG,
                        --	0 as PMSBY_A_R_TOTAL,
                        --	0 as PMJJBY_A_R_TOTAL,
                            MAX(p.branch_zo_id) AS PMSBY_ZO_ID,
                            MAX(p.branch_ro_id) AS PMSBY_RO_ID,
                            NULL AS PMJJBY_ZO_ID,
                            NULL AS PMJJBY_RO_ID,
                            MAX(p.BRANCH_CITY_ID) AS CITY
                            FROM JNS_MASTER_DATA.PMSBY p
                            WHERE p.completion_date > '''|| yesterdate ||'''
                            GROUP BY TO_TIMESTAMP(CAST(p.completion_date AS DATE)), p.branch_id
	
                    UNION ALL
	
                            SELECT TO_TIMESTAMP(CAST(p.status_change_date AS DATE)) AS completion_date,
                            MAX(p.org_Id) As ORG_ID,
                            p.branch_id AS BRANCH_ID,
                            NULL as state_id,
                            0 AS PMJJBY_A_TOTAL,
                            0 as PMSBY_A_TOTAL,
                        --	0 AS A_TOTAL,
                            sum(case when p.scheme_id = 2 and p.stage_id = 8 then 1 else 0 end) as PMJJBY_R_TOTAL,
                        	sum(case when p.scheme_id = 1 and p.stage_id = 8 then 1 else 0 end) as PMSBY_R_TOTAL,
                            sum(case when p.stage_id = 8 then 1 else 0 end) as R_TOTAL,	
                        --	0 as TOTAL_COUNT,
                        	0 as PMJJBY_A_AMOUNT,
                        	0 as PMSBY_A_AMOUNT,
                        	0 as A_AMOUNT,
                        	max(case when p.scheme_id = 2 then p.insurer_org_id else null end) as PMJJBY_INSURER_ORG,
                        	max(case when p.scheme_id = 1 then p.insurer_org_id else null end) as PMSBY_INSURER_ORG,
                        --	0 as PMSBY_A_R_TOTAL,
                        --	0 as PMJJBY_A_R_TOTAL,
                            NULL AS PMSBY_ZO_ID,
                            NULL AS PMSBY_RO_ID,
                            NULL AS PMJJBY_ZO_ID,
                            NULL AS PMJJBY_RO_ID,
                            NULL AS CITY
                            FROM JNS_MASTER_DATA.EXPIRED_ENROLLMENT p 
                            WHERE p.STAGE_ID = 8 AND p.STATUS = 12
                            and p.status_change_date > '''|| yesterdate ||'''
                            GROUP BY TO_TIMESTAMP(CAST(p.status_change_date AS DATE)), p.branch_id
                ) t GROUP BY t.completion_date, t.branch_id';
               
--               USR_INSURANCE.APPLICATION_MASTER 

--    dbms_output.put_line(selectquery);
    mainquery := mainquery || selectquery ;
    dbms_output.put_line('mainquery' || mainquery);
   EXECUTE IMMEDIATE mainquery;
  dbms_output.put_line('mainquery successfully done');

--   MERGE INTO JNS_REPORTS.POLICY PT USING ( 
--					    SELECT P.BRANCH_ID,P.BRANCH_RO_ID, P.BRANCH_ZO_ID,P.USER_ORG_ID,b.state_id
--					    FROM JNS_USERS.branch_product_mapping P
--					    inner join JNS_USERS.BRANCH_MASTER b on b.id=P.BRANCH_ID     where sch_type_id=2
--					) TMP ON (PT.BRANCH_ID = TMP.BRANCH_ID and PT.org_id = TMP.USER_ORG_ID )
--					WHEN MATCHED THEN  UPDATE SET      PT.PMJJBY_RO_ID = TMP.BRANCH_RO_ID, 
--					    PT.PMJJBY_ZO_ID = TMP.BRANCH_ZO_ID,     PT.state = tmp.state_id 
--					where PT.PMJJBY_RO_ID is null and PT.PMJJBY_ZO_ID is null;


--    MERGE INTO JNS_REPORTS.POLICY PT USING ( 
--					    SELECT P.BRANCH_ID,P.BRANCH_RO_ID, P.BRANCH_ZO_ID,P.USER_ORG_ID
--					    FROM JNS_USERS.branch_product_mapping P where sch_type_id=1 ) TMP
--					ON (PT.BRANCH_ID = TMP.BRANCH_ID and PT.org_id = TMP.USER_ORG_ID )
--					WHEN MATCHED THEN  UPDATE SET      PT.PMSBY_RO_ID = TMP.BRANCH_RO_ID,
--					    PT.PMSBY_ZO_ID = TMP.BRANCH_ZO_ID
--					where PT.PMSBY_RO_ID is null and PT.PMSBY_ZO_ID is null;
--                    
                    update JNS_REPORTS.schedular_date set is_active = 0, modified_date = current_timestamp where type = 1 and report_type = 1;
                    insert into JNS_REPORTS.schedular_date(start_date, end_date, type, report_type, is_active)
                    values(yesterdate, currentdate, 1,1,1);
                    commit;
  --  dbms_output.put_line(result);
  END;