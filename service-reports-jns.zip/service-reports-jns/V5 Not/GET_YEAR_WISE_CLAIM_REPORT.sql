CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_YEAR_WISE_CLAIM_REPORT" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                        fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                        todate     IN  VARCHAR2 DEFAULT NULL,
                                                        userid     IN  NUMBER   DEFAULT NULL,
                                                        result     OUT CLOB)
  AS
    selectquery CLOB;
    mainquery   CLOB;
    whereclause CLOB;

    roleid      NUMBER;
    typeid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
  BEGIN
    selectquery := ' select JSON_OBJECT( ''sendToInsurerCount'' value sum(case when ca.status = 6 then 1 else 0 end),
                                         ''approvedCount'' value sum(case when ca.status = 10 then 1 else 0 end),
                                         ''repudiatedCount'' value sum(case when ca.status = 8 then 1 else 0 end)) ';

    mainquery := selectquery || ' FROM USR_INSURANCE.clm_master ca 
                                  INNER JOIN USR_INSURANCE.clm_details cd ON cd.id = ca.id';
--    whereclause := ' WHERE 1=1 ';
    whereclause := ' WHERE is_active=1 ';

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
                whereclause:= concat(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND ca.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 0 ');
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || orgId);
        ELSIF (typeid = 4 OR typeid = 7) THEN
                    if JSON_VALUE(filterjson, '$.ministryReportType') is not null then
                        IF JSON_VALUE(filterjson, '$.ministryReportType') = 1 or JSON_VALUE(filterjson, '$.ministryReportType') = 2 then
                            IF JSON_VALUE(filterjson, '$.ministryOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND ca.org_Id = ' || JSON_VALUE(filterjson, '$.ministryOrgId'));
                            END IF;
                        ELSIF JSON_VALUE(filterjson, '$.ministryReportType') = 3 then
                            IF JSON_VALUE(filterjson, '$.ministryInsurerOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND (ca.insurer_org_id = ' || JSON_VALUE(filterjson, '$.ministryInsurerOrgId') || ' OR ca.insurer_org_id = '|| JSON_VALUE(filterjson, '$.ministryInsurerOrgId') ||') ');
                            END IF;
                        END IF;
--                    else 
--                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    end if;
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;

      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;

    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

   IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;
   IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;
    
    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND ca.claim_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;
   
    IF fromDate IS NOT NULL AND toDate IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND ca.claim_date between TO_DATE('''|| fromDate ||''', ''YYYY-MM-DD'') and TO_DATE('''|| toDate ||''', ''YYYY-MM-DD'')');
    END IF;

  whereclause := CONCAT(whereclause, '
  -- and to_char(ca.claim_date,''yyyy-mm-dd'') BETWEEN ''' || fromdate || 
  ''' and '''
    || todate
    || ''' and ca.claim_status in(6,10,8) ');

     mainquery := CONCAT(mainquery, whereclause);
  --  mainquery := mainquery
 --   || ' where to_char(cm.claim_date,''yyyy-mm-dd'') BETWEEN ''' || fromdate || ''' and ''' || todate || ''' and cm.claim_status in(6,10,8) ';
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
      INTO result;
    dbms_output.put_line(result);

  END get_year_wise_claim_report;