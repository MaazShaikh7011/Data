CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_CLAIM_COUNT" (filterjson IN  "VARCHAR",
                                             userid     IN  NUMBER,
                                             result     OUT CLOB)
  AS
    preparequery    CLOB;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' SELECT JSON_OBJECT(
          ''inProgressCount'' value SUM(CASE WHEN claim_status = 5  THEN 1 ELSE 0 END),
          ''sendToInsurerCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''receivedFromBankCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''sendBackByInsurerCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''sendBackToBnakCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''rejectedCount'' value SUM(CASE WHEN claim_status = 8  THEN 1 ELSE 0 END),
          ''onHoldCount'' value SUM(CASE WHEN claim_status = 9 THEN 1 ELSE 0 END),
          ''acceptedCount'' value SUM(CASE WHEN claim_status = 10  THEN 1 ELSE 0 END),
          ''inProgressCount'' value SUM(CASE WHEN claim_status = 11 THEN 1 ELSE 0 END)
          ) ';

    tablequery := ' FROM USR_INSURANCE.claim_master ca
                        LEFT JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
                        LEFT JOIN USR_INSURANCE.application_master am ON am.id = ca.application_id
                        LEFT JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                      ';
    whereclause := ' WHERE ca.is_active = 1 ';

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      --   dbms_output.put_line(typeid || branchid || orgid || roleid );
      IF typeid IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || branchid);
            ELSE
              whereclause := '';
            END IF;
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || typeid);
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || JSON_VALUE (filterjson, '$.roId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || JSON_VALUE (filterjson, '$.zoId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || JSON_VALUE (filterjson, '$.boId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_state_id = ' || JSON_VALUE (filterjson, '$.stateId'));
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_stage_id = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

    preparequery := selectquery
    || tablequery
    || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  END get_claim_count;

