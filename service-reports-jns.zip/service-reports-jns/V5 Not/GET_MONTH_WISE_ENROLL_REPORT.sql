CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_MONTH_WISE_ENROLL_REPORT" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                          fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                          todate     IN  VARCHAR2 DEFAULT NULL,
                                                          userid     IN  NUMBER   DEFAULT NULL,
                                                          result     OUT CLOB)
  AS
    selectquery CLOB;
    tablequery  CLOB;
    whereclause CLOB;
    groupby     CLOB;
    mainquery   CLOB;

    roleid      NUMBER;
    typeid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
  BEGIN
    selectquery := ' select
        json_arrayagg(json_object(
        ''month'' value to_char(am.modified_date,''mm''),
        ''totalCount'' value count(am.id),
        ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
        ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end))) ';

    tablequery := 'FROM USR_INSURANCE.application_master am
                   INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id';

    whereclause := ' where to_char(am.modified_date,''yyyy-mm-dd'') BETWEEN '''
    || fromdate
    || ''' and '''
    || todate
    || ''' and stage_id in(6,8) ';

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

        IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

--    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
--    THEN
--      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
--    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;

      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (
            roleid IS NOT NULL
            AND roleid != 5
            )
          THEN
            IF (roleid = 9)
            THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
            ELSIF (roleid = 15)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' ');
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgId);
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2  ');
    END IF;

    groupby := ' group by to_char(am.modified_date,''yyyy''), to_char(am.modified_date,''mm'') ';
    mainquery := selectquery
    || tablequery
    || whereclause
    || groupby;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
      INTO result;
    dbms_output.put_line(result);
  END get_month_wise_enroll_report;

