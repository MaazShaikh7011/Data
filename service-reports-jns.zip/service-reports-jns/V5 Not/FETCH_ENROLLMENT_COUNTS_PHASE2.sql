CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_COUNTS_PHASE2" (
    filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB
) AS

    preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    amodwhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
BEGIN

     --    selectQuery := ' SELECT SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END) AS approvedCount,
    --                        SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END) AS rejectedCount';

    IF(JSON_VALUE (FILTERJSON, '$.status') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.status') = 4)
    THEN
        selectquery := ' SELECT JSON_OBJECT(''endorsementCount'' value SUM(CASE WHEN ma.type IS NOT NULL THEN 1 ELSE 0 END) )';
     ELSE
        selectquery := ' SELECT JSON_OBJECT(''acceptedCount'' value SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END))';
     END IF;
                    

    whereclause := ' WHERE 1=1 ';
    

    -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO THAT
    IF userid IS NOT NULL THEN
      SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;

	IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL 
	THEN
		IF JSON_VALUE (FILTERJSON, '$.schemeId') = 1
		THEN
			tablequery := ' FROM jns_master_data.pmsby scm';
	
		ELSIF JSON_VALUE (FILTERJSON, '$.schemeId') = 2
		THEN
			tablequery := ' FROM jns_master_data.pmjjby scm';

		END IF;
	END IF;
    
   


      IF (typeid) IS NOT NULL THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND scm.org_Id = ' || orgid);
--          amodwhereclause := ' scm.org_Id = amod.org_Id AND ';
          
--		  IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
--          THEN
--            whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
--          END IF;
          
		  IF (roleid IS NOT NULL AND roleid != 5) THEN
            IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND scm.branch_id = ' || branchid);
            ELSIF (roleid = 13) THEN
              whereclause := CONCAT(whereclause, ' scm.branch_ro_id = ' || branchid || ' AND ');
            ELSIF (roleid = 14) THEN
              whereclause := CONCAT(whereclause, ' scm.BRANCH_ZO_ID = ' || branchid || ' AND ');
            ELSIF (roleid = 15) THEN
              whereclause := CONCAT(whereclause, ' scm.BRANCH_LHO_ID = ' || branchid || ' AND ');
            ELSE
              whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
--          ELSE
--            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        ELSIF typeid = 6 THEN
          whereclause := CONCAT(whereclause, ' AND scm.insurer_org_id = ' || orgid);
           
--		   IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1
--           THEN
--              whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
--           END IF;
        
		ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

    whereclause := CONCAT(whereclause, ' AND scm.is_active = 1 ');

--    whereclause := CONCAT(whereclause, ' AND scm.stage_id IN(6,8,15) ');

    -- DATE FILTER
    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL THEN
        IF(JSON_VALUE (filterjson, '$.status') is not null and JSON_VALUE (filterjson, '$.status') = 4)
        THEN
            tablequery := CONCAT(tablequery, ' INNER JOIN USR_INSURANCE.miscellaneous_audit ma ON ma.application_id = scm.id');
            whereclause := CONCAT(whereclause, ' AND TRUNC(ma.created_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')');
        ELSE
            whereclause := CONCAT(whereclause, ' AND TRUNC(scm.completion_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')');
        END IF;    
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND scm.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND scm.branch_id IN (' || JSON_VALUE (filterjson, '$.boId')||') AND ');
    END IF;


    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL THEN
      whereclause :=  whereclause || ' scm.source IN (' || JSON_VALUE (filterjson, '$.channelId')||') AND ' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' scm.branch_state_id IN (' || JSON_VALUE (filterjson, '$.stateId')||') AND ');
    END IF;
	
	  IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' scm.branch_zo_id IN (' || JSON_VALUE (filterjson, '$.zoId')||') AND ');
    END IF;
	
	IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' scm.branch_ro_id IN (' || JSON_VALUE (filterjson, '$.roId')||') AND ');
    END IF;



--	IF (roleid = 9 OR roleid = 13 OR roleid = 14 OR roleid = 15 OR JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
--    OR JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL) THEN
--      tablequery := CONCAT(tablequery, ' INNER JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = scm.id AND ((amod.source = 4 AND am.stage_id <> 8 OR amod.source <> 4 AND am.stage_id IN (6,8,15)))');
--    END IF;
   
    preparequery := selectquery || tablequery || whereclause;
	dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
	
--    dbms_output.put_line(result);
END FETCH_ENROLLMENT_COUNTS_PHASE2;