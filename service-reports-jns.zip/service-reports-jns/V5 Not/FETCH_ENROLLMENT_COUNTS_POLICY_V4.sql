CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_COUNTS_POLICY_V4" (filterjson IN  VARCHAR2 DEFAULT NULL,
userid     IN  NUMBER   DEFAULT NULL,
result     OUT CLOB)
  AS
    selectquery CLOB;
    whereclause CLOB;
    mainquery   CLOB;
    tablequery  CLOB;
    typeid      NUMBER;
    roleid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
   	successCount NUMBER;
    failCount NUMBER;
    totalCount NUMBER;
   	transactionInProgressCount NUMBER;
    transactionFailCount NUMBER;
    transactionFailInProgressString clob;
   	transactionFailString clob;
    acceptedCountString    clob;
    rejectedCountString    clob;
    totalCountString clob;
    rocolumn clob;
    zocolumn clob;
    mainQueryObj clob;
    tFailAmWhereclause clob;
    tFailEeWhereclause clob;

  BEGIN

    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.schemeId') = 1 THEN
            acceptedCountString :=  'p.PMSBY_A_TOTAL';
            rejectedCountString :=  'p.PMSBY_R_TOTAL';
            totalCountString :=  'p.PMSBY_A_R_TOTAL';
            rocolumn := 'p.pmsby_ro_id';
            zocolumn := ' AND p.pmsby_zo_id = ';
        ELSIF JSON_VALUE(filterjson, '$.schemeId') = 2 THEN
            acceptedCountString :=  'p.PMJJBY_A_TOTAL';
            rejectedCountString :=  'p.PMJJBY_R_TOTAL';
            totalCountString :=  'p.PMJJBY_A_R_TOTAL';
            rocolumn := 'p.pmjjby_ro_id';
            zocolumn := 'p.pmjjby_zo_id';
        end if;
    ELSE
        acceptedCountString :=  'p.a_total';
        rejectedCountString :=  'p.r_total';
        totalCountString :=  'p.total_count';
    END IF;

--    selectquery := ' select JSON_OBJECT(''totalCount'' value sum('|| totalCountString ||'),
--                    ''acceptedCount'' value sum('|| acceptedCountString ||'),
--                    ''rejectedCount'' value sum('|| rejectedCountString ||')) ';

	selectquery := ' select sum('|| acceptedCountString ||'), sum('|| rejectedCountString ||'), sum('|| totalCountString ||') ';
--    DBMS_OUTPUT.PUT_LINE(selectquery);

    tablequery := ' FROM JNS_REPORTS.policy p ';

    whereclause := ' WHERE 1=1 ';

--    amodwhereclause := ' am.org_Id = amod.org_Id AND ';
--

--
    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;

        IF (typeid IS NOT NULL) THEN
--            IF (typeid != 4) THEN -- FOR MINISTRY DON'T NEED THIS CONDITION
                IF (typeid = 2) THEN
                    whereclause := CONCAT(whereclause, ' AND p.org_Id = ' || orgid);
                    tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND am.org_Id = ' || orgid);
                    tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.org_Id = ' || orgid);
                    IF (roleid IS NOT NULL AND roleid != 5) THEN
                        IF (roleid = 9) THEN
                            whereclause := CONCAT(whereclause, ' AND p.branch_id = ' || branchid);
                            tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND am.branch_id = ' || branchid);
                            tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.branch_id = ' || branchid);
                        ELSIF (roleid = 13) THEN
                        	tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND amod.branch_ro_id = ' || branchid);
                            tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.branch_ro_id = ' || branchid);
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| rocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_ro_id = ' || branchid || ' OR p.pmjjby_ro_id = ' || branchid || ') ');
                            end if;
                        ELSIF (roleid = 14) THEN
                        	tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND amod.branch_zo_id = ' || branchid);
                            tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.branch_zo_id = ' || branchid);
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| zocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_zo_id = ' || branchid || ' OR p.pmjjby_zo_id = ' || branchid || ') ');
                            end if;
                        ELSE
                            whereclause := CONCAT(whereclause, ' AND 1=2 ');
                        END IF;
        --              ELSE
        --                whereclause := CONCAT(whereclause, ' ');
                      END IF;
                ELSIF typeid = 6 THEN
                    whereclause := CONCAT(whereclause, ' AND (p.PMSBY_INSURER_ORG = ' || orgId || ' OR p.PMJJBY_INSURER_ORG = '|| orgId ||') ');
                ELSIF (typeid = 4 OR typeid = 7) THEN
                    if JSON_VALUE(filterjson, '$.ministryReportType') is not null then
                        IF JSON_VALUE(filterjson, '$.ministryReportType') = 1 or JSON_VALUE(filterjson, '$.ministryReportType') = 2 then
                            IF JSON_VALUE(filterjson, '$.ministryOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND p.org_Id = ' || JSON_VALUE(filterjson, '$.ministryOrgId'));
                            END IF;
                        ELSIF JSON_VALUE(filterjson, '$.ministryReportType') = 3 then
                            IF JSON_VALUE(filterjson, '$.ministryInsurerOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND (p.PMSBY_INSURER_ORG = ' || JSON_VALUE(filterjson, '$.ministryInsurerOrgId') || ' OR p.PMJJBY_INSURER_ORG = '|| JSON_VALUE(filterjson, '$.ministryInsurerOrgId') ||') ');
                            END IF;
                        END IF;
--                    else 
--                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    end if;
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
--            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

--    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
--        whereclause := CONCAT(whereclause, ' AND p.scheme_id IN(' || JSON_VALUE(filterjson, '$.schemeId') || ')');
--    END IF;

    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND p.enroll_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
        tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND am.STATUS_CHANGE_DATE between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
        tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.CREATED_DATE between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
		whereclause := CONCAT(whereclause, ' AND p.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
		tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
		tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE(filterjson, '$.stateId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND p.state IN(' || JSON_VALUE(filterjson, '$.stateId') || ')');
        tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND amod.BRANCH_STATE_ID IN(' || JSON_VALUE(filterjson, '$.stateId') || ')');
        tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.BRANCH_STATE_ID IN(' || JSON_VALUE(filterjson, '$.stateId') || ')');
    END IF;




    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.schemeId') = 1 THEN
            IF JSON_VALUE(filterjson, '$.zoId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND p.PMSBY_ZO_ID IN(' || JSON_VALUE(filterjson, '$.zoId') || ')');
            END IF;

            IF JSON_VALUE(filterjson, '$.roId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND p.PMSBY_RO_ID IN(' || JSON_VALUE(filterjson, '$.roId') || ')');
            END IF;
        ELSIF JSON_VALUE(filterjson, '$.schemeId') = 2 THEN
            IF JSON_VALUE(filterjson, '$.zoId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND p.PMJJBY_ZO_ID IN(' || JSON_VALUE(filterjson, '$.zoId') || ')');
            END IF;

            IF JSON_VALUE(filterjson, '$.roId') IS NOT NULL THEN
                whereclause := CONCAT(whereclause, ' AND p.PMJJBY_RO_ID IN(' || JSON_VALUE(filterjson, '$.roId') || ')');
            END IF;
        end if;
    else
        IF JSON_VALUE(filterjson, '$.zoId') IS NOT NULL THEN
            whereclause := CONCAT(whereclause, ' AND (p.PMSBY_ZO_ID IN(' || JSON_VALUE(filterjson, '$.zoId') || ') or p.PMJJBY_ZO_ID IN(' || JSON_VALUE(filterjson, '$.zoId') || '))');
        END IF;

        IF JSON_VALUE(filterjson, '$.roId') IS NOT NULL THEN
            whereclause := CONCAT(whereclause, ' AND (p.PMSBY_RO_ID IN(' || JSON_VALUE(filterjson, '$.roId') || ') or p.PMJJBY_RO_ID IN(' || JSON_VALUE(filterjson, '$.roId') || '))');
        END IF;
    END IF;


    IF JSON_VALUE(filterjson, '$.boId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND p.BRANCH_ID IN(' || JSON_VALUE(filterjson, '$.boId') || ')');
        tFailAmWhereclause := CONCAT(tFailAmWhereclause, ' AND am.branch_id IN(' || JSON_VALUE(filterjson, '$.boId') || ')');
        tFailEeWhereclause := CONCAT(tFailEeWhereclause, ' AND ee.branch_id IN(' || JSON_VALUE(filterjson, '$.boId') || ')');
    END IF;

    mainquery := selectquery || tablequery || whereclause;
--    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery INTO successCount, failCount, totalCount;


	transactionFailInProgressString := ' SELECT count(*) FROM USR_INSURANCE.APPLICATION_MASTER am 
				INNER JOIN USR_INSURANCE.APPLICATION_MASTER_OTHER_DETAILS amod ON amod.APPLICATION_MASTER_ID = am.id 
				WHERE am.STAGE_ID = 15 AND am.APPLICATION_STATUS = 1 ' || tFailAmWhereclause;
	EXECUTE IMMEDIATE transactionFailInProgressString INTO transactionInProgressCount;

	transactionFailString := ' SELECT count(*) FROM JNS_MASTER_DATA.EXPIRED_ENROLLMENT ee WHERE ee.STAGE_ID = 15 AND ee.STATUS = 1 ' || tFailEeWhereclause;
	EXECUTE IMMEDIATE transactionFailString INTO transactionFailCount;

	mainQueryObj := ' select JSON_OBJECT(''totalCount'' value '|| totalCount ||',
                    ''acceptedCount'' value '|| successCount ||',
                    ''rejectedCount'' value '|| failCount ||',
					''transactionInProgressCount'' value '|| transactionInProgressCount ||',
					''transactionFailCount'' value '|| transactionFailCount ||'
						) from dual';

--	dbms_output.put_line(mainQueryObj);
   EXECUTE IMMEDIATE mainQueryObj INTO result;
--    dbms_output.put_line(result);

  END FETCH_ENROLLMENT_COUNTS_POLICY_V4;