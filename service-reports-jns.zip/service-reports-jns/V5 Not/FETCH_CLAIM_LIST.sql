CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_CLAIM_LIST" (filterjson IN  VARCHAR2,
                                              userid     IN  NUMBER,
                                              result     OUT CLOB)
  AS

    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    selectquery := ' ''id'' value cl.id,
                           ''source'' value cl.source,
                           ''applicationId'' value cl.applicationId,
                           ''accountHolderName'' value cl.accountHolderName,
                           ''customerAccountNumber'' value cl.customerAccountNumber,
                           ''urn'' value cl.urn,
                           ''mobileNumber'' value cl.mobileNumber,
                           ''schemeName'' value cl.schemeName,
                           ''claimDate'' value cl.claimDate,
                           ''branch_lho_id'' value cl.branchLhoId,
                           ''branchRoId'' value cl.branchRoId,
                           ''branchZoId'' value cl.branchZoId,
                           ''cif'' value cl.cif,
                           ''dob'' value cl.dob,
                           ''schemeId'' value cl.schemeId,
                           ''insurerName'' value cl.insurerName,
                            ''gender'' value cl.gender,
                            ''organisationCode'' value cl.organisationCode,
                            ''organisationName'' value cl.organisationName,
                            ''branchName'' value cl.branchName,
                            ''roName'' value cl.roName,
                            ''roCode'' value cl.roCode,
                            ''zoName'' value cl.zoName,
                            ''zoCode'' value cl.zoCode,
                            ''pincode'' value cl.pincode,
                            ''city'' value cl.city,
                            ''district'' value cl.district,
                            ''state'' value cl.state,
                            ''dateOfBirth'' value cl.dateOfBirth,
                            ''nomineeName'' value cl.nomineeName,
                            ''relationNominee'' value cl.relationNominee,
                            ''guardianName'' value cl.guardianName,
                            ''guardianRelation'' value cl.guardianRelation,
                            ''claimantName'' value cl.claimantName,
                            ''relationClaimant'' value cl.relationClaimant,
                            ''panNumber'' value cl.panNumber,
                            ''dateOfAutoDebit'' value cl.dateOfAutoDebit,
                            ''dateOfAutoCredit'' value cl.dateOfAutoCredit,
                            ''transactionUtr'' value cl.transactionUtr,
                            ''transectionUtr'' value cl.utr,
                            ''transactionAmount'' value cl.transactionAmount,
                            ''masterPolicyNo'' value cl.masterPolicyNo,
                            ''enrollDate'' value cl.enrollDate,
                            ''caValue'' value cl.caValue,
                            ''caaValue'' value cl.caaValue,
                            ''naValue'' value cl.naValue,
                            ''tdValue'' value cl.tdValue,
                            ''stageName'' value cl.stageName,
                            ''reasonStatus'' value cl.reasonStatus,
                            ''amountTransaction'' value cl.amountTransaction,
                            ''dateTransaction'' value cl.dateTransaction,
                            ''modifiedDate'' value cl.modifiedDate,
                            ''geo'' value cl.geo,
                            ''kycIdName'' value cl.kycIdName,
                            ''pan'' value cl.pan,
                            ''aadhar'' value cl.aadhar,
                            ''channelId'' value cl.channelId,
                            ''fatherHusbandName'' value cl.fatherHusbandName,
                            ''userId1'' value cl.userId1,
                            ''userId2'' value cl.userId2,
                            ''claimStatus'' value cl.claimStatus,
                           ''city_id'' value cl.cityId )RETURNING CLOB)FROM ( 
                SELECT
                        ca.id as id, ca.application_id as applicationId, jns_users."decvalue"(ai.name) as accountHolderName, jns_users."decvalue"(am.account_number) as customerAccountNumber, am.urn as urn, jns_users."decvalue"(ai.mobile_number) as mobileNumber, sm.short_name as schemeName,
                        ca.modified_date as claimDate, amod.branch_lho_id as branchLhoId, amod.branch_ro_id as branchRoId, amod.branch_zo_id as branchZoId, amod.branch_city_id as cityId,am.cif as cif,jns_users."decvalue"(ai.dob) as dob,am.scheme_id as schemeId,
                        jns_users."decvalue"(ai.name) as insurerName,uomb.ORGANISATION_NAME as organisationName,uomb.ORGANISATION_CODE as organisationCode,bm.name as branchName,bmro.name as roName,bmro.code as roCode,bmzo.name as zoName,bmzo.code as zoCode,GEN.value as gender,jns_users."decvalue"(ai.name) as name,
                        adm.pincode as pincode, adm.city_name as city, adm.district as district, adm.state_name as state,concat(concat(jns_users."decvalue"(nd.first_name),'' ''),jns_users."decvalue"(nd.last_name)) as claimantName,jns_users."decvalue"(nd.dob) as dateOfBirth, REL.value as relationClaimant,concat(concat(jns_users."decvalue"(cld.first_name),'' ''),jns_users."decvalue"(cld.last_name)) as nomineeName,REL1.value as relationNominee,concat(concat(jns_users."decvalue"(gdd.first_name),'' ''),jns_users."decvalue"(gdd.last_name)) as guardianName,REL2.value as guardianRelation,
                        jns_users."decvalue"(nd.pan_number) as panNumber,jns_users."decvalue"(td.trans_time_stamp) as dateOfAutoDebit,jns_users."decvalue"(td.trans_time_stamp) as dateOfAutoCredit,jns_users."decvalue"(td.trans_utr) as transactionUtr,ca.transaction_utr as utr,td.trans_amount as transactionAmount,
                        jns_users."decvalue"(td.master_policy_no) as masterPolicyNo,am.enrollment_date as enrollDate ,NL.value as naValue,CASE WHEN am.scheme_id = 1  THEN CDD.value ELSE '' '' END as caValue,CASE WHEN am.scheme_id = 2  THEN CDD2.value ELSE '' '' END as caaValue,TDD.value as tdValue,case when ca.claim_status = 6 then ''Sent to Insurer'' when ca.claim_status = 5 then ''In process'' when ca.claim_status = 10 then ''Approved'' when ca.claim_status = 8 then ''Repudiated'' when ca.claim_status = 7 then ''Sent back by Insurer'' when ca.claim_status = 6 then ''Received from bank'' when ca.claim_status = 8 then ''Repudiated'' when ca.claim_status = 7 then ''Sent back to bank'' when ca.claim_status = 11 then ''In process'' else '''' end as stageName,
                        ca.message as reasonStatus,ca.amount_of_transaction as amountTransaction,jns_users."decvalue"(ca.date_of_transaction) as dateTransaction,ca.modified_date as modifiedDate,amod.rural_urban_semi as geo,amod.channel_id as channelId,case when amod.source = 1 then amod.user_id_1 ELSE jns_users."decvalue"(usr.email) END as userId1, case when amod.source = 1 then amod.user_id_2 ELSE '' '' END as userId2, case when amod.source = 1 then ''Other Channel'' when amod.source=2 then ''JanSuraksha'' end as source,
                        jns_users."decvalue"(ai.father_husband_name) as fatherHusbandName,jns_users."decvalue"(ai.kyc_id_1) as kycIdName,jns_users."decvalue"(ai.pan) as pan,jns_users."decvalue"(ai.aadhaar) as aadhar,ca.claim_status as claimStatus ';
    tablequery := 'FROM USR_INSURANCE.claim_master ca 
                   INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
                   INNER JOIN USR_INSURANCE.application_master am ON am.id = ca.application_id 
                   INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                   LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                   LEFT JOIN JNS_ONEFORM.state st ON st.id = amod.branch_state_id
                   LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1
                   LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id=am.id AND td.id = am.last_transaction_id
                    LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id=am.insurer_org_id AND uom.is_active=1
                    LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=am.org_id AND uomb.is_active=1
                    LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id AND bm.is_active=1
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id AND bmro.is_active=1
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id AND bmzo.is_active=1
                    LEFT JOIN USR_INSURANCE.address_master adm ON adm.id=ai.address_id
                    LEFT JOIN USR_INSURANCE.nominee_details cld ON cld.application_id=am.id and cld.type=1 and cld.is_active=1
                    LEFT JOIN USR_INSURANCE.nominee_details nd ON nd.application_id=am.id and nd.type=2 and nd.is_active=1
                    LEFT JOIN USR_INSURANCE.nominee_details gdd ON gdd.application_id=am.id and gdd.type=3 and gdd.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=ai.gender_id AND GEN.dropdown_id=8 AND GEN.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values NL ON NL.obj_id=cd.nature_of_loss_id AND NL.dropdown_id=3 AND NL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values CDD ON CDD.obj_id=cd.cause_of_death_disability_id AND CDD.dropdown_id=6 AND CDD.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values CDD2 ON CDD2.obj_id=cd.cause_of_death_disability_id AND CDD2.dropdown_id=4 AND CDD2.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values TDD ON TDD.obj_id=cd.type_of_disability_id AND TDD.dropdown_id=5 AND TDD.is_active=1
                    LEFT JOIN USR_INSURANCE.stage_master SMC ON SMC.id=ca.claim_status
                    LEFT JOIN jns_users.users usr ON usr.user_id=am.created_by AND usr.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=nd.relation_id AND REL.dropdown_id=1 AND REL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL1 ON REL1.obj_id=cld.relation_id AND REL1.dropdown_id=1 AND REL1.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL2 ON REL2.obj_id=gdd.relation_id AND REL2.dropdown_id=1 AND REL2.is_active=1
                    ';

    whereclause := ' WHERE  1 = 1 AND ca.is_active = 1 ';
   
    IF JSON_VALUE (filterjson, '$.searchTypeId') IS NOT NULL and JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
        IF JSON_VALUE (filterjson, '$.searchTypeId') = 1 THEN
            whereclause := whereclause
            || ' AND jns_users."decvalue"(am.account_number) = ' || JSON_VALUE (filterjson, '$.searchData');
        ELSIF JSON_VALUE (filterjson, '$.searchTypeId') = 2 THEN
            whereclause := whereclause
            || ' AND am.urn = ''' || JSON_VALUE (filterjson, '$.searchData') || '''';
        ELSIF JSON_VALUE (filterjson, '$.searchTypeId') = 3 THEN
            whereclause := whereclause
            || ' AND ca.application_id = ' || JSON_VALUE (filterjson, '$.searchData');
        END IF;
    ELSIF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND ((jns_users."decvalue"(am.account_number) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR am.urn LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR jns_users."decvalue"(ai.mobile_number) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR jns_users."decvalue"(ai.name) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%''))';
    END IF;

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 0 ');
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        --            ELSE
        --            whereclause := concat(whereclause, ' and 0 ');
        END IF;

      --        ELSE
      --        whereclause := concat(whereclause, ' and 0 ');
      END IF;

    --    ELSE
    --        whereclause := concat(whereclause, ' and 0 ');
    END IF;

--    dbms_output.put_line(whereclause);

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_status = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
    THEN
      IF (JSON_VALUE (filterjson, '$.tabId') = 1)
        OR (JSON_VALUE (filterjson, '$.tabId') = 6)
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 6 ';
      ELSIF JSON_VALUE (filterjson, '$.tabId') = 2
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 11 ';
      ELSIF JSON_VALUE (filterjson, '$.tabId') = 3
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 10 ';
      ELSIF JSON_VALUE (filterjson, '$.tabId') = 4
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 8 ';
      ELSIF (JSON_VALUE (filterjson, '$.tabId') = 5)
        OR (JSON_VALUE (filterjson, '$.tabId') = 8)
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 7 ';
      ELSIF JSON_VALUE (filterjson, '$.tabId') = 9
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 11 ';
      ELSIF JSON_VALUE (filterjson, '$.tabId') = 7
      THEN
        whereclause := whereclause || ' AND ca.claim_status = 8 ';
      ELSE
        whereclause := whereclause || ' AND ca.claim_status = 0 ';
      END IF;
    ElSE
        whereclause := whereclause || ' AND ca.claim_status In (6,11,10,8,7)';
    END IF;

   IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
   THEN
    IF
      JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
    THEN
      limitquery := ' OFFSET '
      || JSON_VALUE (filterjson, '$.paginationFROM')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.paginationTO')
      || ' ROWS ONLY';
    ELSE
      limitquery := '';
    END IF;
   END IF;

    whereclause := whereclause || ' order by ca.modified_date desc ';
    dbms_output.put_line(whereclause);

    EXECUTE IMMEDIATE ' SELECT COUNT(ca.id)'
    || tablequery
    || whereclause
      INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery
    || ')cl';

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  END ;