CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_ACCEPTED_LIST" (
    filterjson  IN   varchar2,
    userid      IN   NUMBER,
    result      OUT  clob
)
AS
 totalcount            LONG;
    selectquery           CLOB;
    fromtodatequery       CLOB;
    tablequery            CLOB;
    inserttablequery      CLOB;
    mainwhereclause       CLOB;
    whereclause           CLOB;
    amodwhereclause       CLOB;
    limitquery            CLOB;
    preparequery          CLOB;
    orderby               CLOB;
    totalcounttablequery  CLOB;
    roleid                NUMBER;
    typeid                NUMBER;
    orgid                 NUMBER;
    branchid              NUMBER;
    insertquery           CLOB;
    appIds                  clob;
    schemeQuery clob;
--    appmasterjoin         VARCHAR2;

BEGIN
                            
    IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
    THEN
            if(JSON_VALUE(FILTERJSON, '$.schemeId') = 1)
            THEN
            schemeQuery :=' ''schemeName'' VALUE ''PMSBY'', ';
            ELSE
            schemeQuery :=' ''schemeName'' VALUE ''PMJJBY'', ';
            END IF;
    END IF;

           selectquery := ' , ''id'' VALUE am.id,
                            ''applicationId'' VALUE am.id,
                            ''name'' VALUE jns_users."decvalue"(aip.ac_holder_name),
                            ''customerAccountNumber'' VALUE jns_users."decvalue"(aip.account_number),
                            ''urn'' VALUE am.urn,
                            ''mobileNumber'' VALUE jns_users."decvalue"(ai.mobile_number),
                            ''stageId'' VALUE 6,
                            ''message'' VALUE am.message,
                            ''premiumAmount'' VALUE am.premium_amount,
                            ''enrollDate'' VALUE TRUNC(am.enrollment_date),
                            '||schemeQuery||'
                            ''modifiedDate'' VALUE TRUNC(am.completion_date)
                            )RETURNING CLOB) ';

  whereclause := ' WHERE 1=1 ';
  amodwhereclause := ' am.org_Id = amod.org_Id AND ';
  
    IF ((JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL) AND (JSON_VALUE (FILTERJSON, '$.schemeId') = 1))
    THEN
      tablequery := ' FROM JNS_MASTER_DATA.PMSBY am ';
      ELSE
      tablequery := ' FROM JNS_MASTER_DATA.PMJJBY am ';
    END IF;
  
  tablequery := tablequery || ' INNER JOIN JNS_MASTER_DATA.APPLICANT_INFO ai ON ai.id = am.id
                    INNER JOIN JNS_MASTER_DATA.APPLICANT_PI_DETAILS aip ON aip.id = am.id ';

  -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO TAHT
  IF USERID IS NOT NULL
  THEN
    SELECT U.USER_TYPE_ID,
           U.BRANCH_ID,
           U.USER_ORG_ID,
           U.USER_ROLE_ID
      INTO typeid,
           branchid,
           orgid,
           roleid
      FROM JNS_USERS.USERS U
      WHERE U.IS_ACTIVE = 1
        AND U.USER_ID = USERID;
    IF (typeid) IS NOT NULL
    THEN
      IF (typeid = 2)
      THEN
        whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
--        IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
--        THEN
--          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
--        END IF;
        IF (roleid IS NOT NULL
          AND roleid != 5 AND roleid != 21)
        THEN
          IF (roleid = 9)
          THEN
            whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
          ELSIF (roleid = 13)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_ro_id = ' || branchid || ' AND ');
          ELSIF (roleid = 14)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.BRANCH_ZO_ID = ' || branchid || ' AND ');
          ELSIF (roleid = 15)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.BRANCH_LHO_ID = ' || branchid || ' AND ');
          ELSE
            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        --          ELSE
        --            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSIF typeid = 6
      THEN
        whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
--        IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
--        THEN
--          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
--        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;
  ELSE
    whereclause := CONCAT(whereclause, ' and 1 = 2 ');

  whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

  -- SET TAB WISE DATA TOTAL, APPROVE, REJECT
  IF JSON_VALUE (FILTERJSON, '$.tabId') IS NOT NULL
  THEN
      whereclause := whereclause || ' AND am.APPLICATION_STATUS = 2 ';
    END IF;
  END IF;

--  IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
--  THEN
--      whereclause := whereclause || ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId');
--    END IF;

  -- DATE FILTER
  IF JSON_VALUE (FILTERJSON, '$.fromDate') IS NOT NULL
    AND JSON_VALUE (FILTERJSON, '$.toDate') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND TRUNC(am.completion_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.searchData') IS NOT NULL
  THEN
    whereclause := whereclause || ' AND ((aip.account_number = jns_users."encvalue"(''' || JSON_VALUE (FILTERJSON, '$.searchData') || ''') OR am.urn = ''' || JSON_VALUE (FILTERJSON, '$.searchData') || '''))';
  END IF;

  --    dbms_output.put_line(whereclause);

  IF JSON_VALUE (FILTERJSON, '$.bankId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (FILTERJSON, '$.bankId'));
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_ro_id in (' || JSON_VALUE (FILTERJSON, '$.roId') || ') AND');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_zo_id in (' || JSON_VALUE (FILTERJSON, '$.zoId') || ') AND');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.boId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (FILTERJSON, '$.boId') || ')');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.source in (' || JSON_VALUE (FILTERJSON, '$.channelId') || ') AND ');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_state_id in (' || JSON_VALUE (FILTERJSON, '$.stateId') || ') AND');
  END IF;

EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || tablequery || whereclause INTO totalcount; -- tablequery

IF JSON_VALUE (FILTERJSON, '$.paginationFROM') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.paginationTO') IS NOT NULL THEN
    limitquery := ' OFFSET ' || JSON_VALUE (FILTERJSON, '$.paginationFROM') || ' ROWS FETCH NEXT ' || JSON_VALUE (FILTERJSON, '$.paginationTO') || ' ROWS ONLY';
  -- dbms_output.put_line(limitquery);
  END IF;
  
--  preparequery := ' SELECT ' || totalcount || ' AS "totalcount", ' || selectquery || tablequery || orderby ; -- || whereclause || limitquery;
  preparequery := (' SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalcount'' VALUE ' || totalcount ||' ' || selectquery || tablequery || whereclause || limitquery); -- || whereclause || limitquery;

    dbms_output.put_line(preparequery);
  EXECUTE IMMEDIATE preparequery into result;
--    dbms_output.put_line(result);


END;