CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_DAY_WISE_CLAIM_REPORT" (
 filterjson  IN   VARCHAR2 DEFAULT NULL,
    fromdate    IN   VARCHAR2 DEFAULT NULL,
    todate      IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB
) AS
    selectquery  CLOB;
    tablequery   CLOB;
    whereclause  CLOB;
    groupby      CLOB;
    mainquery    CLOB;

    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
BEGIN
    selectquery := ' 
        select  json_arrayagg(json_object(
        ''day'' value TO_CHAR(ca.claim_date, ''dd''),
        ''sendToInsurerCount'' value SUM(CASE WHEN ca.status = 6  THEN 1 ELSE 0 END),
        ''approvedCount'' value SUM(CASE WHEN ca.status = 10 THEN 1 ELSE 0 END),
        ''repudiatedCount'' value SUM(CASE WHEN ca.status = 8 THEN 1 ELSE 0 END)
    ))';

--    ''inProgressCount'' value SUM(CASE WHEN claim_status = 5  THEN 1 ELSE 0 END),
--    ''sendToInsurer'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
--    ''sendBackByInsurerCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
--    ''rejectedCount'' value SUM(CASE WHEN claim_status = 8  THEN 1 ELSE 0 END),
--    ''onHoldCount'' value SUM(CASE WHEN claim_status = 9 THEN 1 ELSE 0 END),
--    ''acceptedCount'' value SUM(CASE WHEN claim_status = 10  THEN 1 ELSE 0 END),
--    ''inProgressCount'' value SUM(CASE WHEN claim_status = 11 THEN 1 ELSE 0 END)

    tablequery := ' FROM USR_INSURANCE.clm_master ca 
      INNER JOIN USR_INSURANCE.clm_details cd ON cd.id = ca.id ';

    whereclause := ' where TO_CHAR(ca.claim_date,''yyyy-mm-dd'') 
                      BETWEEN '''
                   || fromdate
                   || ''' and '''
                   || todate
                   || ''' and ca.status in(6,10,8) and is_active=1';
         --          || ''' and ca.is_active = 1';

     IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
          whereclause := concat(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
        END IF;
     IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

     IF(userid) IS NOT NULL THEN
            SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF(typeid) IS NOT NULL THEN
        IF(typeid = 2) THEN
      whereclause:= concat(whereclause, ' AND ca.org_id = ' || orgid);
                IF
                    roleid IS NOT NULL AND roleid != 5
                THEN
                    IF roleid = 9 THEN -- BO
                                                    whereclause := concat(whereclause, ' AND ca.branch_id = ' || branchid);
                    ELSIF roleid = 13 THEN -- RO
                                                    whereclause := concat(whereclause, ' AND ca.branch_ro_id = ' || branchid);
                    ELSIF roleid = 14 THEN -- ZO
                                                    whereclause := concat(whereclause, ' AND ca.branch_zo_id = ' || branchid);
                    ELSIF roleid = 15 THEN -- LHO
                                                    whereclause := concat(whereclause, ' AND ca.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := concat(whereclause, ' and 0 ');
                    END IF;
                END IF;
            ELSIF typeid = 6 THEN
                whereclause := concat(whereclause, ' AND ca.insurer_org_id = ' || orgId);
            ELSIF typeid = 4 THEN
                    if JSON_VALUE(filterjson, '$.ministryReportType') is not null then
                        IF JSON_VALUE(filterjson, '$.ministryReportType') = 1 or JSON_VALUE(filterjson, '$.ministryReportType') = 2 then
                            IF JSON_VALUE(filterjson, '$.ministryOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND ca.org_Id = ' || JSON_VALUE(filterjson, '$.ministryOrgId'));
                            END IF;
                        ELSIF JSON_VALUE(filterjson, '$.ministryReportType') = 3 then
                            IF JSON_VALUE(filterjson, '$.ministryInsurerOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND (ca.insurer_org_id = ' || JSON_VALUE(filterjson, '$.ministryInsurerOrgId') || ' OR ca.insurer_org_id = '|| JSON_VALUE(filterjson, '$.ministryInsurerOrgId') ||') ');
                            END IF;
                        END IF;
--                    else 
--                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    end if;
            ELSE
                whereclause := concat(whereclause, ' and 1 = 2 ');
            END IF;
        ELSE
            whereclause := concat(whereclause, ' and 1 = 2 ');
        END IF;
    ELSE
        whereclause := concat(whereclause, ' and 1 = 2 ');
    END IF;

    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND ca.claim_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;
    
    groupby := ' GROUP BY TO_CHAR(ca.claim_date, ''yyyy''), TO_CHAR(ca.claim_date, ''mm''), TO_CHAR(ca.claim_date, ''dd'') ';
    mainquery := selectquery || tablequery || whereclause || groupby;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
--    dbms_output.put_line(result);
END get_day_wise_claim_report;