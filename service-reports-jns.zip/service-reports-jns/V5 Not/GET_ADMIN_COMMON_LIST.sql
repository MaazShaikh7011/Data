CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_ADMIN_COMMON_LIST" ( listKey IN VARCHAR2, whereClause IN VARCHAR2, userId IN NUMBER,result out clob)
IS
query clob;
pv clob;
BEGIN
-- SQLINES DEMO *** IS NOT NULL) THEN
-- SQLINES DEMO *** e = CONCAT(' WHERE ', whereClause);		
-- 	END IF;

	CASE listKey
		WHEN 'admin_menu_permission' THEN
--			query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' value role_id, ''label'' value display_name)returning clob) FROM jns_users.user_role_master WHERE is_active = 1 AND role_id IN(SELECT role_id FROM (SELECT * FROM jns_users.user_role_master ORDER BY parent_role_id, role_id) products_sorted, ( pv := ' || whereClause  ||') initialisation WHERE FIND_IN_SET(parent_role_id, pv) AND LENGTH(pv := CONCAT(pv, ",", role_id)))';

            query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' value role_id, ''label'' value display_name)returning clob) 
FROM jns_users.user_role_master  urm WHERE urm.is_active = 1 AND urm.role_id IN (
SELECT 
distinct(u2.role_id) 
FROM jns_users.user_role_master u
left join jns_users.user_role_master u1 on u.role_id =u1.parent_role_id '|| --OR u.role_id = u1.role_id
' left join jns_users.user_role_master u2 on u1.role_id =u2.parent_role_id OR u1.role_id = u2.role_id 
where u.role_id='||whereClause||'
)';
		WHEN 'admin_menu_permission_list' THEN
--			query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT( ''displayName'' value m.display_name ,''menuId'' value u.menu_id,''id''  value m.id,''isParent'' value m.parent_id)returning clob) FROM jns_users.menu_master m LEFT JOIN jns_users.menu_role_mapping u ON (u.menu_id=m.id AND u.type_id=5 AND u.role_id= ' || whereClause  ||' AND  u.is_active=1) WHERE m.is_active=1 ';
            query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT( ''displayName'' value m.display_name ,''menuId'' value u.menu_id,''id''  value m.id,''isParent'' value m.parent_id)returning clob) FROM jns_users.menu_master m LEFT JOIN jns_users.menu_role_mapping u ON (u.menu_id=m.id AND u.type_id=5 AND u.role_id= ' || whereClause  ||' AND  u.is_active=1 ) WHERE m.is_active=1 And m.type =''Admin Panel''';
		WHEN 'schemeList' THEN
			query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' VALUE id, ''short_name'' VALUE short_name)returning clob) FROM jns_users.scheme_master WHERE is_active = 1 ';
		WHEN 'getOrgListByTypeId' THEN
			query := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''userOrgId'' VALUE user_org_id, ''organisationName'' VALUE display_org_name )returning clob) FROM jns_users.user_organisation_master u WHERE u.user_type_id = ' || whereClause  ||' AND u.is_active = 1 ';
		ELSE
			query := ' SELECT "Key Not Found" as result from dual';
	END CASE;

-- 	select query;
DBMS_OUTPUT.put_line(query);
	EXECUTE IMMEDIATE  query into result;
-- SQLINES DEMO *** List('schemeDistrictMaster','{"districtId":1,"schemeId":2}',NULL);
-- SQLINES DEMO *** List('documentList','{"typeId":2,"schemeId":1}',NULL);
-- SQLINES DEMO *** List('getUplodedDocumentList','{"applicationId":158}',NULL);
END;