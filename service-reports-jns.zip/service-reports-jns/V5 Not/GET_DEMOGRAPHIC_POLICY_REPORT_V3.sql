CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_DEMOGRAPHIC_POLICY_REPORT_V3" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                         fromdate   IN  VARCHAR2 DEFAULT NULL,
                                                         todate     IN  VARCHAR2 DEFAULT NULL,
                                                         userid     IN  NUMBER   DEFAULT NULL,
                                                         result     OUT CLOB)
  AS
    selectquery CLOB;
    whereclause CLOB;
    mainquery   CLOB;
    tablequery  CLOB;
--    amodwhereclause CLOB;
    typeid      NUMBER;
    roleid      NUMBER;
    orgid       NUMBER;
    branchid    NUMBER;
    maleColumn    clob;
    femaleColumn    clob;
    otherColumn    clob;
--    totalColumn clob;
    rocolumn clob;
    zocolumn clob;
  BEGIN
--    selectquery := ' select JSON_OBJECT( ''totalCount'' value count(am.id),
--            ''acceptedCount'' value sum(case when stage_id = 6 then 1 else 0 end),
--            ''rejectedCount'' value sum(case when stage_id = 8 then 1 else 0 end)) ';

--    DBMS_OUTPUT.PUT_LINE(JSON_VALUE(filterjson, '$.schemeId'));
    
    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.schemeId') = 1 THEN
            maleColumn := 'd.pmsby_male';
            femaleColumn := 'd.pmsby_female';
            otherColumn := 'd.pmsby_Other';
--            totalColumn := '';

        ELSIF JSON_VALUE(filterjson, '$.schemeId') = 2 THEN
            maleColumn := 'd.pmjjby_Male';
            femaleColumn := 'd.pmjjby_Female';
            otherColumn := 'd.pmjjby_Other';
--            totalColumn := '';
        end if;
    ELSE
        maleColumn := 'd.MALE_COUNT';
        femaleColumn := 'd.FEMALE_COUNT';
        otherColumn := 'd.OTHER_COUNT';
--        totalColumn := '';
--        rocolumn := ' AND (p.pmsby_ro_id = ' || branchid || ' OR p.pmjjby_ro_id = ' || branchid || ') ';
--        zocolumn := ' AND (p.pmsby_zo_id = ' || branchid || ' OR p.pmjjby_zo_id = ' || branchid || ') ';
    END IF;
    
    
    selectquery := ' select JSON_OBJECT(''maleCount'' value sum('|| maleColumn ||'),
                    ''femaleCount'' value sum('|| femaleColumn ||'),
                    ''otherCount'' value sum('|| otherColumn ||')) ';
--    DBMS_OUTPUT.PUT_LINE(selectquery);

    tablequery := ' FROM JNS_REPORTS.POLICY_DEMOGRAPHIC d ';
    
    whereclause := ' WHERE 1=1 ';

--    amodwhereclause := ' am.org_Id = amod.org_Id AND ';
--
    
--
    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid IS NOT NULL) THEN
--            IF (typeid != 4) THEN -- FOR MINISTRY DON'T NEED THIS CONDITION
                IF (typeid = 2) THEN
                    whereclause := CONCAT(whereclause, ' AND d.org_Id = ' || orgid);
--                    IF (roleid IS NOT NULL AND roleid != 5) THEN
--                        IF (roleid = 9) THEN
--                            whereclause := CONCAT(whereclause, ' AND p.branch_id = ' || branchid);
--                        ELSIF (roleid = 13) THEN
--                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
--                                whereclause := CONCAT(whereclause, ' AND '|| rocolumn ||' = ' || branchid);
--                            else
--                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_ro_id = ' || branchid || ' OR p.pmjjby_ro_id = ' || branchid || ') ');
--                            end if;
--                        ELSIF (roleid = 14) THEN
--                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
--                                whereclause := CONCAT(whereclause, ' AND '|| zocolumn ||' = ' || branchid);
--                            else
--                                whereclause := CONCAT(whereclause, ' AND (p.pmsby_zo_id = ' || branchid || ' OR p.pmjjby_zo_id = ' || branchid || ') ');
--                            end if;
--                        ELSE
--                            whereclause := CONCAT(whereclause, ' AND 1=2 ');
--                        END IF;
--        --              ELSE
--        --                whereclause := CONCAT(whereclause, ' ');
--                      END IF;
--                ELSIF typeid = 6 THEN
--                    whereclause := CONCAT(whereclause, ' AND (p.PMSBY_INSURER_ORG = ' || orgId || ' OR p.PMJJBY_INSURER_ORG = '|| orgId ||') ');
                ELSIF (typeid = 4 or typeid = 7) THEN
                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
--            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

--    whereclause := CONCAT(whereclause, ' AND am.stage_id in(6,8) ');

--    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
--        whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
--    END IF;
--
    IF (fromdate IS NOT NULL and todate IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' AND d.enroll_date between TO_DATE('''|| fromdate ||''', ''YYYY-MM-DD'') and TO_DATE('''|| todate ||''', ''YYYY-MM-DD'')');
    END IF;
    
    IF (JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL and JSON_VALUE(filterjson, '$.toDate') IS NOT NULL) THEN
        whereclause := CONCAT(whereclause, ' AND d.enroll_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;
    
--    
--    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

--    dbms_output.put_line(whereclause);

    mainquery := selectquery || tablequery || whereclause;
    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery INTO result;
    dbms_output.put_line(result);

  END GET_DEMOGRAPHIC_POLICY_REPORT_V3;