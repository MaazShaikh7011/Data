CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_MONTH_WISE_CLAIM_REPORT" (
filterjson  IN   VARCHAR2 DEFAULT NULL,
    fromdate    IN   VARCHAR2 DEFAULT NULL,
    todate      IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
    result      OUT  CLOB ) 
    AS 
    
    selectQuery  CLOB;
    tableQuery   CLOB;
    whereClause  CLOB;
    groupBy      CLOB;
    mainQuery    CLOB;
    fromtodatequery CLOB;

    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;

BEGIN

    selectQuery:= ' select  json_arrayagg(json_object(
       ''month'' value to_char(ca.claim_date,''mm''),
        ''totalCount'' value count(ca.id),
        ''sendToInsurerCount'' value SUM(CASE WHEN ca.status = 6  THEN 1 ELSE 0 END),
        ''approvedCount'' value SUM(CASE WHEN ca.status = 10 THEN 1 ELSE 0 END),
        ''repudiatedCount'' value SUM(CASE WHEN ca.status = 8 THEN 1 ELSE 0 END)
    ))';

    tableQuery:= ' FROM USR_INSURANCE.clm_master ca 
                   INNER JOIN USR_INSURANCE.clm_details cd ON cd.id = ca.id ';

    whereclause := 'WHERE to_char(ca.claim_date,''yyyy-mm-dd'') BETWEEN '''
                   || fromdate
                   || ''' and '''
                   || todate   
                   || ''' and ca.status in(6,10,8) and is_active=1';



  IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

  IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

       IF(userid) IS NOT NULL THEN
            SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
       IF(typeid) IS NOT NULL THEN
       IF(typeid = 2) THEN
        whereclause:= concat(whereclause, ' AND ca.org_id = ' || orgid);
                IF
                    roleid IS NOT NULL AND roleid != 5
                THEN
                    IF roleid = 9 THEN -- BO
                                                    whereclause := concat(whereclause, ' AND ca.branch_id = ' || branchid);
                    ELSIF roleid = 13 THEN -- RO
                                                    whereclause := concat(whereclause, ' AND ca.branch_ro_id = ' || branchid);
                    ELSIF roleid = 14 THEN -- ZO
                                                    whereclause := concat(whereclause, ' AND ca.branch_zo_id = ' || branchid);
                    ELSIF roleid = 15 THEN -- LHO
                                                    whereclause := concat(whereclause, ' AND ca.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := '';
                    END IF;
                END IF;
            ELSIF typeid = 6 THEN
                whereclause := concat(whereclause, ' AND ca.insurer_org_id = ' || orgId);
            ELSIF typeid = 4 THEN
                    if JSON_VALUE(filterjson, '$.ministryReportType') is not null then
                        IF JSON_VALUE(filterjson, '$.ministryReportType') = 1 or JSON_VALUE(filterjson, '$.ministryReportType') = 2 then
                            IF JSON_VALUE(filterjson, '$.ministryOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND ca.org_Id = ' || JSON_VALUE(filterjson, '$.ministryOrgId'));
                            END IF;
                        ELSIF JSON_VALUE(filterjson, '$.ministryReportType') = 3 then
                            IF JSON_VALUE(filterjson, '$.ministryInsurerOrgId') is not null then
                                whereclause := CONCAT(whereclause, ' AND (ca.insurer_org_id = ' || JSON_VALUE(filterjson, '$.ministryInsurerOrgId') || ' OR ca.insurer_org_id = '|| JSON_VALUE(filterjson, '$.ministryInsurerOrgId') ||') ');
                            END IF;
                        END IF;
--                    else 
--                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    end if;
            ELSE
                whereclause := concat(whereclause, ' and 0 ');
            END IF;
        ELSE
            whereclause := concat(whereclause, ' and 0 ');
        END IF;
    ELSE
        whereclause := concat(whereclause, ' and 0 ');
    END IF;

--    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL
--    AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL
--    THEN
--        fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE(filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE(filterjson, '$.toDate') ||  ''', ''YYYY-MM-DD'')';
--        whereclause := concat(whereclause, fromtodatequery);
--    END IF;
    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND ca.claim_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;

     groupBy:= ' GROUP BY TO_CHAR(ca.claim_date, ''yyyy''), TO_CHAR(ca.claim_date, ''mm'') ';

    mainQuery:= selectQuery || tableQuery || whereClause || groupBy;

    dbms_output.put_line(mainquery);

    EXECUTE IMMEDIATE mainquery
    INTO result;
--    dbms_output.put_line(result);


END GET_MONTH_WISE_CLAIM_REPORT;