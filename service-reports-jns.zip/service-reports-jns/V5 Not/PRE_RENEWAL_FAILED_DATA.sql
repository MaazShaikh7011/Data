CREATE OR REPLACE PROCEDURE JNS_REPORTS.PRE_RENEWAL_FAILED_DATA( filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB) AS 
    
   	preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
   	groupByQuery   CLOB;
  	orderByQuery   CLOB;
 	limitQuery   CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB;
BEGIN

	selectquery := ' select ird.REJECTION_REASON_ID, COUNT(ird.ID) AS totalCount ';
	     
	whereclause := ' WHERE 1 = 1 ';

	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	    	FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;
	    
	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        SELECT short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND ird.SCHEME_CODE =''' || scheme_code||''' ');
	    END IF;
	    
	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer	    	
		    	select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
		    	IF (typeid = 2) THEN -- Banker
		            whereclause := CONCAT(whereclause, ' AND ird.org_code = ''' || org_code ||''' ');
		        ELSIF (typeid = 6) THEN -- Insurer
		            whereclause := CONCAT(whereclause, ' AND ird.insurer_org_code = ''' || org_code ||''' '); -- orgid
				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					whereclause := CONCAT(whereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					whereclause := CONCAT(whereclause, ' AND ird.SCHEME_CODE = ''PMSBY''');
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					whereclause := CONCAT(whereclause, ' AND ird.SCHEME_CODE = ''PMJJBY''');
				END IF;
	        END IF;
	    ELSE
	        whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
	    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
--		whereclause := CONCAT(whereclause, ' AND bufl.org_code = ' || JSON_VALUE (FILTERJSON, '$.orgId')); 
	END IF;
           
    tablequery := ' FROM JNS_MASTER_DATA.INSURER_REJECTED_DETAILS ird ';
   
	groupByQuery := ' GROUP BY ird.REJECTION_REASON_ID ';
	orderByQuery := ' ORDER BY COUNT(ird.ID) DESC ';
	limitQuery := ' FETCH FIRST 3 ROWS ONLY ';

--    preparequery := selectquery || tablequery || whereclause || groupByQuery || orderByQuery || limitQuery;
    
    preparequery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(
			''reason'' VALUE rrm.reason,
			''count'' VALUE tmp.totalCount
		)) FROM ('||
			selectquery || tablequery || whereclause || groupByQuery || orderByQuery || limitQuery
		||') tmp 
		INNER JOIN JNS_MASTER_DATA.REJECTION_REASON_MASTER rrm ON rrm.ID = tmp.REJECTION_REASON_ID ';
   
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);

END PRE_RENEWAL_FAILED_DATA;