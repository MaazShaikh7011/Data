CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_TOP_CLAIM_OFFICE" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                  userid     IN  NUMBER   DEFAULT NULL,
                                                  result     OUT CLOB)
  AS

    mainquery    CLOB;
    branchid     LONG;
    whereclause  CLOB;
    limitquery   VARCHAR(1000);

    roleid       NUMBER;
    typeid       NUMBER;
    orgid        NUMBER;
    userbranchid NUMBER;

  BEGIN
    IF JSON_VALUE (filterjson, '$.branchType') IS NOT NULL
    THEN
      IF JSON_VALUE (filterjson, '$.branchType') = 1
      THEN
        branchid := 'ca.branch_id';
      ELSIF JSON_VALUE (filterjson, '$.branchType') = 2
      THEN
        branchid := 'ca.branch_ro_id ';
      ELSIF JSON_VALUE (filterjson, '$.branchType') = 3
      THEN
        branchid := 'ca.branch_zo_id ';
      END IF;
    END IF;

    whereclause := ' WHERE ' || branchid || ' IS NOT NULL ';

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             userbranchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      --   dbms_output.put_line(typeid || branchid || orgid || roleid );
      IF typeid IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || userbranchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || userbranchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || userbranchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || userbranchid);
            ELSE
              whereclause := '';
            END IF;
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' and 0 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 0 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 0 ');
    END IF;


    --    SELECT JSON_ARRAYAGG(JSON_OBJECT('branchId' value cap.branchId, 'totalCount' value cap.totalCount, 'totalAmount' value cap.totalAmount ))
    --FROM (SELECT ca.claim_branch_id as branchId , COUNT(ca.id) totalCount, SUM(ca.claim_amount) as totalAmount
    --       FROM USR_INSURANCE.claim_master ca
    --       INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
    --       GROUP BY ca.claim_branch_id
    --) cap;

    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT (''branchId'' value cap.branchId, ''totalCount'' value cap.totalCount, ''totalAmount'' value cap.totalAmount ))
    FROM (SELECT ' || branchid || ' as branchId , COUNT(ca.id) totalCount, SUM(ca.claim_amount) as totalAmount
          FROM USR_INSURANCE.claim_master ca
          INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
          GROUP BY ' || branchid || ' ORDER BY totalCount DESC FETCH FIRST 10 ROWS ONLY
          )cap';

    --    mainquery:= ' SELECT JSON_ARRAYAGG(JSON_OBJECT(  ) )
    --     FROM USR_INSURANCE.claim_master ca
    --     INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id ';



    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
      INTO result;
    dbms_output.put_line(result);


  END GET_TOP_CLAIM_OFFICE;

