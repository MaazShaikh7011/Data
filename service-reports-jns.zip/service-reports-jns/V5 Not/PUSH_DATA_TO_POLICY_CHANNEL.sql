CREATE OR REPLACE PROCEDURE JNS_REPORTS."PUSH_DATA_TO_POLICY_CHANNEL"
  AS
    name  CLOB;
    mainquery   CLOB;
    selectquery   CLOB;
    deletequery clob;
    yesterdate TIMESTAMP;
    currentdate TIMESTAMP;
  BEGIN

        SELECT TO_TIMESTAMP(concat(TO_DATE(current_date - 2), ' 11:59:59.000000 PM')) into yesterdate FROM dual;
        SELECT current_timestamp into currentdate FROM dual;

       deletequery := ' DELETE FROM JNS_REPORTS.POLICY_CHANNEL  where enroll_date > '''|| yesterdate || '''';
       dbms_output.put_line('delete' || deletequery);
       EXECUTE IMMEDIATE deletequery;
       commit;


   mainquery := ' INSERT INTO JNS_REPORTS.POLICY_CHANNEL
					(ORG_ID, CHANNEL, SCHEME_ID, ENROLL_DATE, TOTAL_COUNT, BRANCH_RO_ID, BRANCH_ZO_ID, INSURER_ORG_ID) ' ;
--dbms_output.put_line(mainquery);

	selectquery := ' SELECT am.ORG_ID AS orgId,
					(CASE WHEN (AMOD.SOURCE = 1 AND amod.CHANNEL_ID IS NOT null) THEN amod.CHANNEL_ID 
					WHEN (AMOD.SOURCE = 1 AND amod.CHANNEL_ID IS null) THEN ''Other Channel Journey''
					WHEN (AMOD.SOURCE = 2) THEN ''Portal Journey''
					WHEN (AMOD.SOURCE = 4) THEN ''DIY Journey''
					ELSE NULL end) AS channelName,
					am.SCHEME_ID,
					to_timestamp(CAST(am.status_change_date AS DATE)) AS enroll_date,
					COUNT(am.id)  AS totalCount,
					amod.BRANCH_RO_ID,
					amod.BRANCH_ZO_ID,
					am.INSURER_ORG_ID  
					FROM USR_INSURANCE.APPLICATION_MASTER am
					INNER JOIN USR_INSURANCE.APPLICATION_MASTER_OTHER_DETAILS amod ON amod.APPLICATION_MASTER_ID = am.ID
					WHERE am.STAGE_ID = 6 AND am.APPLICATION_STATUS = 2
					AND am.status_change_date > '''|| yesterdate ||'''
					GROUP BY am.ORG_ID, am.INSURER_ORG_ID , am.SCHEME_ID, amod.BRANCH_ZO_ID, amod.BRANCH_RO_ID, AMOD.SOURCE ,amod.CHANNEL_ID, to_timestamp(CAST(am.status_change_date AS DATE)) ';
				
  
--dbms_output.put_line(selectquery);
    mainquery := mainquery || selectquery ;
    dbms_output.put_line('mainquery' || mainquery);
--   EXECUTE IMMEDIATE mainquery;
  COMMIT;

    update JNS_REPORTS.schedular_date set is_active = 0, modified_date = current_timestamp where type = 1 and report_type = 3;
    insert into JNS_REPORTS.schedular_date(start_date, end_date, type, report_type, is_active)
    values(yesterdate, currentdate, 1,3,1);
    commit;
--    dbms_output.put_line(result);
  END;