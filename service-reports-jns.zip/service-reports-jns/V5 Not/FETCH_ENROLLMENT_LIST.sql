CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_LIST" (filterjson IN  VARCHAR2,
                                                   userid     IN  NUMBER,
                                                   result     OUT CLOB)
  AS
    totalcount      LONG;
    selectquery     CLOB;
    fromtodatequery CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    orderby   CLOB;
    totalCountTableQuery  CLOB;
    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;

  BEGIN
    selectquery := ' ''id'' value lst.id,
                ''applicationId'' value lst.applicationId,
                ''source'' value lst.source,
                ''urn'' value lst.urn,
                ''cif'' value lst.cif,
                ''customerAccountNumber'' value lst.customerAccountNumber,
                ''application_status'' value lst.application_status,
                ''branch_id'' value lst.branch_id,
                ''createdDate'' value lst.createdDate,
                ''enrollDate'' value lst.enrollDate,
                ''message'' value lst.message,
                ''modifiedDate'' value lst.modifiedDate,
                ''orgId'' value lst.orgId,
                ''mobileNumber'' value lst.mobileNumber,
                ''dob'' value lst.dob,
                ''schemeName'' value lst.schemeName,
                ''schemeId'' value lst.schemeId,
                ''stageId'' value lst.stageId,
                ''insurerName'' value lst.insurerName,
                ''gender'' value lst.gender,
                ''organisationCode'' value lst.organisationCode,
                ''organisationName'' value lst.organisationName,
                ''branchName'' value lst.branchName,
                ''roName'' value lst.roName,
                ''roCode'' value lst.roCode,
                ''zoName'' value lst.zoName,
                ''zoCode'' value lst.zoCode,
                ''pincode'' value lst.pincode,
                ''city'' value lst.city,
                ''district'' value lst.district,
                ''state'' value lst.state,
                ''nomineeName'' value lst.nomineeName,
                ''dateOfBirth'' value lst.dateOfBirth,
                ''ralationNomineeApplicant'' value lst.ralationNomineeApplicant,
                ''panNumber'' value lst.panNumber,
                ''ralationNomineeApplicant'' value lst.ralationNomineeApplicant,
                ''nameGuardian'' value lst.nameGuardian,
                ''ralationNomineeguardian'' value lst.ralationNomineeguardian,
                ''dateOfAutoDebit'' value lst.dateOfAutoDebit,
                ''dateOfAutoCredit'' value lst.dateOfAutoCredit,
                ''transectionUtr'' value lst.transectionUtr,
                ''transactionAmount'' value lst.transactionAmount,
                ''associatedAccNo'' value lst.associatedAccNo,
                ''masterPolicyNo'' value lst.masterPolicyNo,
                ''geo'' value lst.geo,
                ''channelId'' value lst.channelId,
                ''userId1'' value lst.userId1,
                ''userId2'' value lst.userId2,
                ''transactionType'' value lst.transactionType,
                ''fatherHusbandName'' value lst.fatherHusbandName,
                ''kycIdName'' value lst.kycIdName,
                ''pan'' value lst.pan,
                ''aadhar'' value lst.aadhar,
                ''name'' value lst.name )RETURNING CLOB)FROM ( 
                SELECT
                am.id as id, am.id as applicationId ,am.urn as urn, am.cif as cif, am.account_number as customerAccountNumber, am.application_status as application_status, am.branch_id as branch_id, am.created_date as createdDate,
                    am.enrollment_date as enrollDate, am.message as message, am.modified_date as modifiedDate, am.org_id as orgId, ai.mobile_number as mobileNumber,ai.dob as dob, sm.short_name as schemeName, am.scheme_id as schemeId, am.stage_id as stageId,
                uom.DISPLAY_ORG_NAME as insurerName,uomb.ORGANISATION_NAME as organisationName,uomb.ORGANISATION_CODE as organisationCode,bm.name as branchName,bmro.name as roName,bmro.code as roCode,bmzo.name as zoName,bmzo.code as zoCode,GEN.value as gender,ai.name as name,
                adm.pincode as pincode, adm.city_name as city, adm.district as district, adm.state_name as state,concat(concat(nd.first_name,'' ''),nd.last_name) as nomineeName,nd.dob as dateOfBirth, REL.value as ralationNomineeApplicant,
                nd.pan_number as panNumber,concat(concat(gd.first_name,'' ''),gd.last_name) as nameGuardian,RELD.value as ralationNomineeguardian,td.trans_time_stamp as dateOfAutoDebit,td.trans_time_stamp as dateOfAutoCredit,td.trans_utr as transectionUtr,td.trans_amount as transactionAmount,
                imd.MASTER_POLICY_NO as associatedAccNo,td.master_policy_no as masterPolicyNo,amod.rural_urban_semi as geo,amod.channel_id as channelId,usr.email as userId1, usr.email as userId2, case when amod.source = 1 then ''Other Channel'' when amod.source=2 then ''JanSuraksha'' end as source,
                case when td.type=1 then ''New Enrollment'' when td.type=2 then ''Endorsement'' end as transactionType,ai.father_husband_name as fatherHusbandName,ai.kyc_id_1 as kycIdName,ai.pan as pan,ai.aadhaar as aadhar ';

    tablequery := ' FROM USR_INSURANCE.application_master am
                            LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id 
                            INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id 
                            LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id=am.id
                            LEFT JOIN USR_INSURANCE.insurer_mst_details imd ON imd.id=td.insurer_master_id
                            LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id=am.insurer_org_id AND uom.is_active=1
                            LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=am.org_id AND uomb.is_active=1
                            LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id AND bm.is_active=1
                            LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id AND bmro.is_active=1
                            LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id AND bmzo.is_active=1
                            LEFT JOIN USR_INSURANCE.address_master adm ON adm.id=ai.address_id
                            LEFT JOIN USR_INSURANCE.nominee_details nd ON nd.application_id=am.id and nd.type=1
                            LEFT JOIN USR_INSURANCE.nominee_details gd ON gd.application_id=am.id and gd.type=3
                            LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=ai.gender_id AND GEN.dropdown_id=8 AND GEN.is_active=1
                            LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=nd.relation_id AND REL.dropdown_id=1 AND REL.is_active=1
                            LEFT JOIN jns_oneform.dropdowns_values RELD ON RELD.obj_id=gd.relation_id AND RELD.dropdown_id=1 AND RELD.is_active=1
                            LEFT JOIN jns_users.users usr ON usr.user_id=am.created_by AND usr.is_active=1
                            LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1 ';

    whereclause := ' WHERE 1=1 ';

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

     IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL THEN
        IF JSON_VALUE (filterjson, '$.tabId') = 1 THEN
            whereclause := whereclause || ' AND am.stage_id IN (6, 8) ';
        ELSIF JSON_VALUE (filterjson, '$.tabId') = 2 THEN
            whereclause := whereclause || ' AND am.stage_id = 6 ';
        ELSIF JSON_VALUE (filterjson, '$.tabId') = 3 THEN
            whereclause := whereclause || ' AND am.stage_id = 8 ';
        END IF;
    END IF;

    IF userid IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (roleid IS NOT NULL
            AND roleid != 5)
          THEN
            IF (roleid = 9)
            THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
            ELSIF (roleid = 15)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' ');
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');
    --                    AND am.scheme_id IN(6,7)
    --                    AND am.branch_id = 1
    --                    AND am.branch_ro_id = 1
    --                    AND am.branch_zo_id = 1
    --                    and am.branch_lho_id = 1
    --                    AND am.org_id = 13
    --                    AND insurer_org_id = 188 ';

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND ((am.account_number LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR am.urn LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR ai.mobile_number LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR ai.name LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%''))';
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    IF
      JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL
    THEN
      limitquery := ' OFFSET '
      || JSON_VALUE (filterjson, '$.paginationFROM')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.paginationTO')
      || ' ROWS ONLY';
    --        dbms_output.put_line(limitquery);
    END IF;

    totalCountTableQuery := ' FROM USR_INSURANCE.application_master am
                            INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                            LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id ';

    dbms_output.put_line(' SELECT COUNT(am.id)' || totalCountTableQuery || whereclause);
    EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || totalCountTableQuery || whereclause
      INTO totalcount;

    orderby := ' order by am.modified_date desc ';

    preparequery := 'SELECT json_arrayagg(json_object(
              ''totalcount'' value ' || totalcount || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery
    || ')lst';

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  --    dbms_output.put_line(result);
  END ;