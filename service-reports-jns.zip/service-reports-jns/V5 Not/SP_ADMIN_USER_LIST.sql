CREATE OR REPLACE PROCEDURE JNS_REPORTS."SP_ADMIN_USER_LIST" ( 
filterJSON IN varchar2,
paginationFROM IN number,
paginationTO IN number,
result OUT clob)
IS
	
userTypeId NUMBER(10) DEFAULT '5';
whereClause clob;
selectQuery clob;
tableQuery clob;
adminRoleIds clob;
adminRoles clob;
selectCountQuery clob;
totalCountQuery CLOB;
orderBy clob;
limit clob;
mainQuery clob;
totalCount number;
finalquery clob;
BEGIN
	whereClause := CONCAT('WHERE u.user_type_id = ', userTypeId);

	selectQuery := '  jns_users."decvalue"(u.email) AS email,
				jns_users."decvalue"(u.mobile) AS mobile,
				CONCAT(jns_users."decvalue"(u.first_name)|| '' '', jns_users."decvalue"(u.last_name)) AS fullName ,
				urm.display_name AS role,
				urm.role_id AS roleId,
				u.user_id AS userId,
				u.is_locked AS isLocked,
				u.is_active AS isActive,
				u.modified_date AS lastUpdatedDate,
				u.sign_up_date AS signUpDate';

	tableQuery := ' FROM jns_users.users u 
			INNER JOIN jns_users.user_role_master urm ON urm.role_id = u.user_role_id ';	

	IF (json_value(filterJSON,'$.adminRoleId') IS NOT NULL AND json_value(filterJSON,'$.adminRoleId') != 101) THEN

		adminRoleIds := ' SELECT GROUP_CONCAT(role_id)
			FROM (SELECT * FROM jns_users.user_role_master urm
			ORDER BY parent_role_id, urm.role_id) products_sorted,
			(SELECT @pv := ' || json_value(filterJSON,'$.adminRoleId') ||') initialisation
			WHERE FIND_IN_SET(parent_role_id, @pv)
			AND LENGTH(@pv := CONCAT(@pv, '','', role_id)) ';

        EXECUTE IMMEDIATE  adminRoleIds INTO adminRoles;	

		IF (adminRoles IS NOT NULL) THEN
			whereClause := whereClause || ' AND u.user_role_id IN(' || adminRoles  ||')';
		ELSE
			-- SQLINES LICENSE FOR EVALUATION USE ONLY
			EXECUTE IMMEDIATE ' SELECT '''' FROM dual' into result;
		END IF;

	END IF;

	IF (json_value(filterJSON,'$.childUserId') IS NOT NULL) THEN
		whereClause := whereClause || ' AND u.user_role_id =' || json_value(filterJSON,'$.childUserId');
	END IF;

	selectCountQuery := ' SELECT COUNT(*)  ';	
	totalCountQuery :=  selectCountQuery || tableQuery || whereClause;
	EXECUTE IMMEDIATE  totalCountQuery into totalCount;	

-- SQLINES DEMO *** ame
	IF ((json_value(filterJSON,'$.applicantName') IS NOT NULL)) THEN
		whereClause := whereClause || ' AND (CONCAT(jns_users."decvalue"(u.first_name)|| '' '',jns_users."decvalue"(u.last_name)) LIKE ''%' || (json_value(filterJSON,'$.applicantName')) ||'%''
		OR jns_users."decvalue"(u.mobile) LIKE ''%' || json_value(filterJSON,'$.applicantName') ||'%''
		OR jns_users."decvalue"(u.email) LIKE ''%' || json_value(filterJSON,'$.applicantName') ||'%'')';
	END IF;

--   For date RANGE
	IF ((json_value(filterJSON,'$.fromDate') IS NOT NULL) AND (json_value(filterJSON,'$.toDate') IS NOT NULL)) THEN
		whereClause := whereClause || ' AND u.sign_up_date BETWEEN ' || ' to_timestamp('''||json_value(filterJSON,'$.fromDate')||''')' || ' AND ' ||' to_timestamp(to_date('''||json_value(filterJSON,'$.toDate')|| ''')+1)';
	ELSIF (json_value(filterJSON,'$.fromDate') IS NOT NULL) THEN
		whereClause := whereClause || ' AND DATE(u.sign_up_date) = ' || json_value(filterJSON,'$.fromDate');
	END IF;

-- Default set DESC	
	orderBy := ' ORDER BY u.sign_up_date DESC ';
	IF ( filterJSON != '' AND filterJSON != '{}' AND json_value(filterJSON,'$.sortBy') IS NOT NULL AND json_value(filterJSON,'$.sortBy') = 'Oldest First')
	THEN
	  orderBy := ' ORDER BY u.sign_up_date ASC ';
	END IF;	

-- For Limit
	limit := ' OFFSET '
      ||paginationFROM
      || ' ROWS FETCH NEXT '
      || paginationTO
      || ' ROWS ONLY';

	mainQuery := 'SELECT '||  totalCount||' AS totalCount, ' ||selectQuery || tableQuery || whereClause || orderBy || limit;

-- select mainQuery;
--DBMS_OUTPUT.PUT_LINE(mainQuery);
    finalquery:='select json_arrayagg(json_object(  ''totalCount'' value totalCount,
     ''email'' value email,
				  ''mobile'' value mobile,
				 ''fullName''  value fullName,
				  ''role'' value role,
				  ''roleId'' value roleId,
				  ''userId'' value userId,
				  ''isLocked'' value isLocked,
				  ''isActive'' value isActive,
				  ''lastUpdatedDate'' value lastUpdatedDate,
				  ''signUpDate'' value signUpDate)returning clob) from ('||mainQuery||')';
                  DBMS_OUTPUT.PUT_LINE(mainQuery);
	EXECUTE IMMEDIATE  finalquery into result;   

END;