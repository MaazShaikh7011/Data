CREATE OR REPLACE PROCEDURE JNS_REPORTS.PRE_RENEWAL_LIST_VIEW(filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB) AS 
    
   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    insidewhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB; 
     
BEGIN
     selectquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(  ''bankName'' value uom.display_org_name,
                        ''orgid'' value IMD.ORG_ID, 
						''successCount'' VALUE successCount,
						''failedCount'' VALUE failedCount,
						''totalCount'' VALUE totalCount
					)RETURNING CLOB) ';

        tablequery := ' FROM USR_INSURANCE.INSURER_MST_DETAILS imd ';
        whereclause := ' WHERE IMD.POLICY_START_DATE < CURRENT_DATE AND IMD.POLICY_END_DATE > CURRENT_DATE AND IMD.IS_ACTIVE = 1 ';
		insidewhereclause := ' WHERE 1=1 ';
       
	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;
        
	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND imd.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
	    END IF;
	    
	    IF (typeid) IS NOT NULL THEN
			IF (typeid = 2 OR typeid = 6) THEN -- Banker OR Insurer
				select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;   

				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID  = DECODE('|| typeid ||', 2, imd.insurer_org_id,imd.org_id) 
		                LEFT JOIN (
		                    SELECT DECODE('|| typeid ||', 2, BUFL.INSURER_ORG_CODE, BUFL.ORG_CODE) as ORG_CODE, 
							SUM(bufl.SUCCESS_COUNT) as successCount ,
		                    SUM(bufl.FAILED_COUNT) as failedCount,
		                    SUM(bufl.TOTAL_COUNT) as totalCount
				            FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
				            WHERE DECODE('|| typeid ||', 2, BUFL.ORG_CODE, BUFL.INSURER_ORG_CODE) = ''' || org_code ||'''
				            GROUP BY DECODE('|| typeid ||', 2, BUFL.INSURER_ORG_CODE, BUFL.ORG_CODE)
		                ) tmp ON tmp.ORG_CODE = uom.ORGANISATION_CODE ');
				whereclause := CONCAT(whereclause, ' AND DECODE('|| typeid ||', 2, IMD.ORG_ID, IMD.INSURER_ORG_ID) = ' || orgid);
			
--	    		select ORGANISATION_CODE, IMAGE_PATH, DISPLAY_ORG_NAME into org_code, bankLogoUrl, displayInsName from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
--	    		
--	    		IF (typeid = 2) THEN -- Banker
--		    		SELECT uom.IMAGE_PATH, uom.DISPLAY_ORG_NAME INTO bankLogoUrl, displayInsName FROM USR_INSURANCE.INSURER_MST_DETAILS imd 
--						INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON UOM.USER_ORG_ID = imd.INSURER_ORG_ID 
--						WHERE imd.is_active= 1 AND imd.ORG_ID = orgid AND imd.SCHEME_ID = JSON_VALUE(filterjson, '$.schemeId') FETCH FIRST ROW ONLY;
--					
--	--	    		select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;
--		            whereclause := CONCAT(whereclause, ' AND bufl.org_code = ''' || org_code||''' ');
--		        ELSIF (typeid = 6) THEN -- Insurer
--		            whereclause := CONCAT(whereclause, ' AND bufl.insurer_org_code = ''' || org_code||''' ');
--				END IF;
			ELSIF (typeid = 7) THEN -- Council/Association
				IF (roleid = 22) THEN -- Indian Banks' Association (all bannk)
					insidewhereclause := CONCAT(insidewhereclause, ' AND 1=1 ');
				ELSIF (roleid = 23) THEN -- General Insurance (pmsby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND BUFL.SCHEME_CODE = ''PMSBY''');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 1);
				ELSIF (roleid = 24) THEN -- Life Insurance (pmjjby)
					insidewhereclause := CONCAT(insidewhereclause, ' AND BUFL.SCHEME_CODE = ''PMJJBY''');
					whereclause := CONCAT(whereclause, ' AND imd.scheme_id = ' || 2);
				END IF;
				tablequery := CONCAT(tablequery, ' LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID  = DECODE('|| roleid ||', 22, imd.org_id, imd.insurer_org_id) 
		                LEFT JOIN (
		                    SELECT DECODE('|| roleid ||', 22, BUFL.ORG_CODE, BUFL.INSURER_ORG_CODE) as ORG_CODE, 
							SUM(bufl.SUCCESS_COUNT) as successCount ,
		                    SUM(bufl.FAILED_COUNT) as failedCount,
		                    SUM(bufl.TOTAL_COUNT) as totalCount
				            FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl '|| insidewhereclause ||'
				            GROUP BY DECODE('|| roleid ||', 22, BUFL.ORG_CODE, BUFL.INSURER_ORG_CODE)
		                ) tmp ON tmp.ORG_CODE = uom.ORGANISATION_CODE ');
--		               WHERE DECODE('|| roleid ||', 22, BUFL.INSURER_ORG_CODE, BUFL.ORG_CODE) = ''' || org_code ||'''
--				whereclause := CONCAT(whereclause, ' AND DECODE('|| roleid ||', 22 , IMD.INSURER_ORG_ID, IMD.ORG_ID) = ' || orgid);
	        END IF;
	   	ELSE
	        whereclause := CONCAT(whereclause, ' AND 1=2 ');
	    END IF;
	ELSE
	     whereclause := CONCAT(whereclause, ' AND 1=2 '); 
	END IF;


    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);
  
  
END PRE_RENEWAL_LIST_VIEW;