CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_ENROLLMENT_COUNTS" (filterjson IN  "VARCHAR",
                                                     userid     IN  NUMBER,
                                                     result     OUT CLOB)
  AS
    preparequery    CLOB;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    --    selectQuery := ' SELECT SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END) AS approvedCount,
    --                        SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END) AS rejectedCount';

    selectquery := ' SELECT JSON_OBJECT(''acceptedCount'' value SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END),
                                        ''rejectedCount'' value SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END),
                                        ''totalCount'' value SUM(CASE WHEN stage_id IS NOT NULL THEN 1 ELSE 0 END)) ';

    tablequery := ' FROM USR_INSURANCE.application_master am
                        INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id ';

    whereclause := ' WHERE 1=1 ';

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    whereclause := CONCAT(whereclause, ' AND am.stage_id IN(6,8) ');

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL THEN
      whereclause := CONCAT(whereclause, ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')');
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
      IF (typeid) IS NOT NULL THEN
        IF (typeid = 2) THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (roleid IS NOT NULL AND roleid != 5) THEN
            IF (roleid = 9) THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
            ELSIF (roleid = 13) THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
            ELSIF (roleid = 14) THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || branchid);
            ELSIF (roleid = 15) THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' ');
          END IF;
        ELSIF typeid = 6 THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
    END IF;

    whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || JSON_VALUE (filterjson, '$.roId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || JSON_VALUE (filterjson, '$.zoId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || JSON_VALUE (filterjson, '$.boId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.channel_id = ''' || JSON_VALUE (filterjson, '$.channelId')||'''' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND amod.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    preparequery := selectquery
    || tablequery
    || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
    dbms_output.put_line(result);

  END ;

