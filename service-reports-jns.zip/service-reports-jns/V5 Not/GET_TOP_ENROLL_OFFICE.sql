CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_TOP_ENROLL_OFFICE" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                   userid     IN  NUMBER   DEFAULT NULL,
                                                   result     OUT CLOB)
  AS

    mainquery    CLOB;
    branchid     LONG;
    limitquery   VARCHAR(1000);
    whereclause  CLOB;
    roleid       NUMBER;
    typeid       NUMBER;
    orgid        NUMBER;
    userbranchid NUMBER;
  BEGIN
    IF JSON_VALUE (filterjson, '$.branchType') IS NOT NULL
    THEN
      IF JSON_VALUE (filterjson, '$.branchType') = 1
      THEN
        branchid := 'am.branch_id';
      ELSIF JSON_VALUE (filterjson, '$.branchType') = 2
      THEN
        branchid := 'amod.branch_ro_id ';
      ELSIF JSON_VALUE (filterjson, '$.branchType') = 3
      THEN
        branchid := 'amod.branch_zo_id ';
      END IF;
    END IF;

    whereclause := ' WHERE ' || branchid || ' IS NOT NULL';

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             userbranchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
          IF (
            roleid IS NOT NULL
            AND roleid != 5
            )
          THEN
            IF (roleid = 9)
            THEN
              whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || userbranchid);
            ELSIF (roleid = 13)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || userbranchid);
            ELSIF (roleid = 14)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || userbranchid);
            ELSIF (roleid = 15)
            THEN
              whereclause := CONCAT(whereclause, ' AND amod.branch_lho_id = ' || userbranchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 1 = 2 ');
            END IF;
          ELSE
            whereclause := CONCAT(whereclause, ' ');
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

        IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''branchId'' value tmp.branchId, ''branchName'' value tmp.branchName, ''totalCount'' value tmp.totalCount, ''totalAmount'' value tmp.totalAmount))
    from ( SELECT bm.name as branchName, bd.* from( SELECT ' || branchid || ' as branchId, COUNT(am.id) totalCount, sum(am.premium_amount) as totalAmount FROM USR_INSURANCE.application_master am
    INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
    ' || whereclause || '
    GROUP BY ' || branchid || ' ORDER BY totalCount DESC FETCH FIRST 10 ROWS ONLY ) bd
    LEFT JOIN JNS_USERS.branch_master bm on bm.id = bd.branchId
    ) tmp';

    --    SELECT '|| branchid ||' as branchId, bm.name AS branchName, COUNT(am.id) totalCount, sum(am.premium_amount) as totalAmount FROM USR_INSURANCE.application_master am
    --    INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
    --    LEFT JOIN JNS_USERS.branch_master bm on bm.id = '|| branchid || ' ' || whereclause ||'
    --    GROUP BY '|| branchid ||' ORDER BY totalCount DESC FETCH FIRST 10 ROWS ONLY
    --    ) tmp';

    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
      INTO result;
    dbms_output.put_line(result);
  END get_top_enroll_office;

