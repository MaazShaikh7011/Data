CREATE OR REPLACE PROCEDURE JNS_REPORTS."SP_BANK_USER_LIST" (filterJSON IN varchar2,
paginationFROM IN number,
paginationTO IN number,
result OUT CLOB) AS

userTypeId NUMBER(10) DEFAULT '6';
whereClause clob;
selectQuery clob;
tableQuery clob;
adminRoleIds clob;
adminRoles clob;
selectCountQuery clob;
totalCountQuery CLOB;
orderBy clob;
limit clob;
mainQuery clob;
totalCount number;
finalquery CLOB;
BEGIN
  -- whereClause := CONCAT('WHERE u.user_type_id = ', userTypeId);
  selectCountQuery := ' SELECT Distinct COUNT(*)  ';
  selectQuery := ' u.user_id AS userId,
				u.email AS email,
				u.mobile AS mobile,
				u.user_org_id AS orgId,
				uom.display_org_name AS orgName,
				u.branch_id AS branchId,
				bm.name AS branchName,
				bm.code AS branchCode,
				u.user_type_id AS userTypeId,
                CONCAT(u.first_name|| '' '', u.last_name) AS fullName ,
				u.user_role_id AS userRoleId,
				urm.display_name AS roleName,
        u.created_date AS createdOn,
				u.is_active AS isActive,
				u.is_locked AS isLocked ';

--				 CONCAT(IF(u.first_name IS NOT NULL, u.first_name,""), '' '', IF(u.middle_name, u.middle_name, "") , '' '',IF(u.last_name, u.last_name,"")) AS fullName,


    tableQuery := ' FROM jns_users.users u
				INNER JOIN jns_users.user_organisation_master uom ON uom.user_org_id = u.user_org_id
				INNER JOIN jns_users.user_role_master urm ON urm.role_id = u.user_role_id
				LEFT JOIN jns_users.branch_master bm ON bm.id = u.branch_id ';

    IF (json_value(filterJSON,'$.userTypeId') IS NOT NULL) THEN
		whereClause := whereClause || ' AND u.user_type_id =' || json_value(filterJSON,'$.userTypeId');
	END IF;
    IF (json_value(filterJSON,'$.userOrgId') IS NOT NULL) THEN
		whereClause := whereClause || ' AND u.user_org_id =' || json_value(filterJSON,'$.userOrgId');
	END IF;
    IF (json_value(filterJSON,'$.userRoleId') IS NOT NULL) THEN
		whereClause := whereClause || ' AND u.user_role_id =' || json_value(filterJSON,'$.userRoleId');
	END IF;

    -- selectCountQuery := ' SELECT COUNT(*)  ';
	totalCountQuery :=  selectCountQuery || tableQuery || whereClause;
	EXECUTE IMMEDIATE  totalCountQuery into totalCount;

    IF ((json_value(filterJSON,'$.applicantName') IS NOT NULL)) THEN
		whereClause :=whereClause || ' AND (CONCAT(u.first_name|| '' '',u.last_name) LIKE ''%' || (json_value(filterJSON,'$.applicantName')) ||'%''
		OR u.mobile LIKE ''%' || json_value(filterJSON,'$.applicantName') ||'%''
        OR uom.display_org_name LIKE ''%' || json_value(filterJSON,'$.applicantName') ||'%''
		OR decValue(u.email) LIKE ''%' || json_value(filterJSON,'$.applicantName') ||'%'')';
	END IF;


    orderBy := ' ORDER BY u.user_id DESC ';
	IF ( filterJSON != '' AND filterJSON != '{}' AND json_value(filterJSON,'$.sortBy') IS NOT NULL AND json_value(filterJSON,'$.sortBy') = 'Oldest First')
	THEN
	  orderBy := ' ORDER BY u.user_id ASC ';
	END IF;

    limit := ' OFFSET '
      ||paginationFROM
      || ' ROWS FETCH NEXT '
      || paginationTO
      || ' ROWS ONLY';

      mainQuery := 'SELECT '||  totalCount||' AS totalCount, ' ||selectQuery || tableQuery || whereClause || orderBy || limit;
      DBMS_OUTPUT.PUT(mainquery);
--      OPEN RESULT FOR SELECT mainquery FROM dual;
finalquery :=' SELECT JSON_ARRAYAGG(JSON_OBJECT(''userId'' VALUE userId,
				''email'' VALUE email,
				''mobile'' VALUE mobile,
				''orgId'' VALUE orgId,
				''orgName'' VALUE orgName,
				''branchId'' VALUE branchId,
                ''fullName''  value fullName,
				''branchName'' VALUE branchName,
				''branchCode'' VALUE branchCode,
				''userTypeId'' VALUE userTypeId,
				''userRoleId'' VALUE userRoleId,
				''roleName'' VALUE roleName,
                ''createdOn'' VALUE createdOn,
				''isActive'' VALUE isActive,
				''isLocked'' VALUE isLocked  )RETURNING CLOB)FROM ('||mainquery||')';
EXECUTE IMMEDIATE finalquery INTO result;
--    SELECT RESULT INTO RESULT FROM DUAL;
END ;

