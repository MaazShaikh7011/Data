CREATE OR REPLACE PROCEDURE JNS_REPORTS."PUSH_DATA_TO_POLICY_DEMOGRAPHIC"
  AS
    name  CLOB;
    mainquery   CLOB;
    selectquery   CLOB;
    deletequery clob;
    deleteresult clob;
     yesterdate TIMESTAMP;
    currentdate TIMESTAMP;
  BEGIN

        SELECT TO_TIMESTAMP(concat(TO_DATE(current_date - 2), ' 11:59:59.000000 PM')) into yesterdate FROM dual;
        SELECT current_timestamp into currentdate FROM dual;

       deletequery := ' DELETE FROM JNS_REPORTS.policy_demographic  where enroll_date  > '''|| yesterdate || '''';

           dbms_output.put_line(deletequery);
       EXECUTE IMMEDIATE deletequery;
      commit;


   mainquery := ' INSERT INTO JNS_REPORTS.policy_demographic 
   (org_id, ENROLL_DATE, PMSBY_MALE, PMSBY_FEMALE, PMSBY_OTHER, PMJJBY_MALE, PMJJBY_FEMALE, PMJJBY_OTHER, MALE_COUNT, FEMALE_COUNT, OTHER_COUNT) ' ;
--dbms_output.put_line(mainquery);

   selectquery := ' select org_id, to_timestamp(CAST(am.status_change_date AS DATE)),
							sum(case when am.scheme_id = 1 and ai.gender_id = 1 then 1 else 0 end) as pmsbyMale,
							sum(case when am.scheme_id = 1 and ai.gender_id = 2 then 1 else 0 end) as pmsbyFemale,
							sum(case when am.scheme_id = 1 and ai.gender_id = 3 then 1 else 0 end) as pmsbyOther,
							sum(case when am.scheme_id = 2 and ai.gender_id = 1 then 1 else 0 end) as pmjjbyMale,
							sum(case when am.scheme_id = 2 and ai.gender_id = 2 then 1 else 0 end) as pmjjbyFemale,
							sum(case when am.scheme_id = 2 and ai.gender_id = 3 then 1 else 0 end) as pmjjbyOther,
							sum(case when ai.gender_id = 1 then 1 else 0 end) as maleCount,
							sum(case when ai.gender_id = 2 then 1 else 0 end) as femaleCount,
							sum(case when ai.gender_id = 3 then 1 else 0 end) as otherCount
							from  USR_INSURANCE.applicant_info ai
							inner join USR_INSURANCE.application_master am on 
							am.status_change_date > '''|| yesterdate ||'''
							AND am.stage_id = 6  AND am.is_active = 1 and ai.application_id = am.id 
							WHERE 1=1 and ai.gender_id is not null
							group by org_id, to_timestamp(CAST(am.status_change_date AS DATE))';

    mainquery := mainquery || selectquery ;
    dbms_output.put_line(mainquery);

--    EXECUTE IMMEDIATE mainquery;
    
    update JNS_REPORTS.schedular_date set is_active = 0, modified_date = current_timestamp where type = 1 and report_type = 2;
                    insert into JNS_REPORTS.schedular_date(start_date, end_date, type, report_type, is_active)
                    values(yesterdate, currentdate, 1,2,1);
                    commit;
--    dbms_output.put_line(result);                            

--    dbms_output.put_line(result);
  END;