CREATE OR REPLACE PROCEDURE JNS_REPORTS.GET_CHANNEL_WISE_REPORT(
filterjson  IN   VARCHAR2 DEFAULT NULL,
userid      IN   NUMBER DEFAULT NULL,
result     OUT  CLOB)
AS 
	selectquery  CLOB;
	tablequery  CLOB;
	whereclause  CLOB;
	groupbyquery clob;
    mainquery    CLOB;
	rocolumn clob;
   	zocolumn clob;
    roleid        NUMBER;
    typeid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;

BEGIN
	
	IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        IF JSON_VALUE(filterjson, '$.schemeId') = 1 THEN
            rocolumn := 'pc.pmsby_ro_id';
            zocolumn := 'pc.pmsby_zo_id';
        ELSIF JSON_VALUE(filterjson, '$.schemeId') = 2 THEN
            rocolumn := 'pc.pmjjby_ro_id';
            zocolumn := 'pc.pmjjby_zo_id';
        end if;
    END IF;
	whereclause := ' WHERE 1=1 ';
	IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;

        IF (typeid IS NOT NULL) THEN
                IF (typeid = 2) THEN
                    whereclause := CONCAT(whereclause, ' AND pc.org_Id = ' || orgid);
                    IF (roleid IS NOT NULL AND roleid != 5) THEN
                        IF (roleid = 9) THEN
                            whereclause := CONCAT(whereclause, ' AND pc.branch_id = ' || branchid);
                        ELSIF (roleid = 13) THEN
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| rocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (pc.pmsby_ro_id = ' || branchid || ' OR pc.pmjjby_ro_id = ' || branchid || ') ');
                            end if;
                        ELSIF (roleid = 14) THEN
                            IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
                                whereclause := CONCAT(whereclause, ' AND '|| zocolumn ||' = ' || branchid);
                            else
                                whereclause := CONCAT(whereclause, ' AND (pc.pmsby_zo_id = ' || branchid || ' OR pc.pmjjby_zo_id = ' || branchid || ') ');
                            end if;
                        ELSE
                            whereclause := CONCAT(whereclause, ' AND 1=2 ');
                        END IF;
                      END IF;
                ELSE
                    whereclause := CONCAT(whereclause, ' AND 1=2 ');
                END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;
    
    IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := CONCAT(whereclause, ' AND pc.enroll_date between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''YYYY-MM-DD'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''YYYY-MM-DD'')');
    END IF;
	
    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND pc.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
    END IF;
	
   	selectquery := ' SELECT sum(TOTAL_COUNT) AS totalCount, CHANNEL AS channel ';
  	tablequery := ' FROM JNS_REPORTS.POLICY_CHANNEL pc ';
 	groupbyquery := ' GROUP BY CHANNEL ';
	mainquery :=  ' SELECT json_arrayagg(json_object(''totalCount'' value tmp.totalCount, ''channel'' value tmp.channel)) As results from(
					' || selectquery || tablequery || whereclause || groupbyquery || ') tmp ';
				
	dbms_output.put_line(mainquery);
	dbms_output.put_line(selectquery || tablequery || whereclause || groupbyquery);
    EXECUTE IMMEDIATE mainquery INTO result;
    dbms_output.put_line(result);

END GET_CHANNEL_WISE_REPORT;