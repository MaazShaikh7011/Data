CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_STATE_WISE_CLAIM_COUNT_BKP_22_FEB" (filterjson IN  VARCHAR2 DEFAULT NULL,
                                                        userid     IN  NUMBER   DEFAULT NULL,
                                                        result     OUT CLOB)
  AS

    whereclause     CLOB;
    mainquery       CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    whereclause := ' WHERE cd.branch_state_id IS NOT NULL ';

    IF JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      --   dbms_output.put_line(typeid || branchid || orgid || roleid );
      IF typeid IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || branchid);
            ELSE
              whereclause := '';
            END IF;
          END IF;
        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;

     IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
            whereclause := concat(whereclause, ' AND am.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
        END IF;
       IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
            whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
       END IF;

    mainquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' value st.id,
    ''stateName'' value st.state_name, 
    ''enrollStateId'' value enst.stateid , 
    ''totalCount'' value enst.totalapplication, 
    ''totalamount'' value enst.totalAmount 
    )RETURNING CLOB) 
    FROM jns_oneform.state st 
       LEFT JOIN (SELECT cd.branch_state_id AS stateid, COUNT(ca.id) AS totalapplication, SUM(ca.AMOUNT_OF_TRANSACTION) AS totalAmount
        FROM USR_INSURANCE.claim_master ca 
        INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id        
        LEFT JOIN USR_INSURANCE.application_master am ON am.id =ca.application_id

       ' || whereclause || ' GROUP BY cd.branch_state_id
        ORDER BY COUNT(ca.id) DESC) enst ON enst.stateid = st.id WHERE country_id = 101 ';

    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
      INTO result;
    dbms_output.put_line(result);

  END GET_STATE_WISE_CLAIM_COUNT_BKP_22_FEB;