CREATE OR REPLACE PROCEDURE JNS_REPORTS."GET_STATE_WISE_ENROLL_COUNT_V4" (
 filterjson  IN   VARCHAR2 DEFAULT NULL,
    userid      IN   NUMBER DEFAULT NULL,
     result     OUT  CLOB
) AS
    whereclause  CLOB;
    mainquery    CLOB;
    fromtodatequery CLOB; 
    roleid        NUMBER;
    typeid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    totalCount    clob;
    totalAmount    clob;

BEGIN

  whereclause := ' WHERE p.branch_state_id IS NOT NULL ';

     IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND TRUNC(p.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE(filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE(filterjson, '$.toDate') ||  ''', ''YYYY-MM-DD'')');
     END IF;

   IF (userid) IS NOT NULL THEN 
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid ;
        IF(typeid IS NOT NULL) THEN 
            IF(typeid != 4) THEN 
                IF(typeid = 2) THEN
                    whereclause:= concat(whereclause, ' AND p.org_Id = ' || orgid);
--                    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
--                        whereclause := concat(whereclause, ' AND am.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
--                    END IF;
                    IF( roleid IS NOT NULL AND roleid != 5) THEN
                        IF(roleid = 9) THEN
                         whereclause := CONCAT(whereclause, ' AND p.branch_id = ' || branchid);
                        ELSIF (roleid = 13) THEN
                           whereclause := CONCAT(whereclause, ' AND p.branch_ro_id = ' || branchid);
                        ELSIF (roleid = 14) THEN
                           whereclause := CONCAT(whereclause, ' AND p.branch_zo_id = ' || branchid);
                        ELSIF (roleid = 15) THEN
                            whereclause := CONCAT(whereclause, ' AND p.BRANCH_LHO_ID = ' || branchid);
                        ELSE
                            whereclause := concat(whereclause, ' AND 1 = 2 ');
                        END IF;
                    ELSE
                        whereclause := concat(whereclause, ' ');
                    END IF;
                ELSIF typeid = 6 THEN
                    whereclause := concat(whereclause, ' AND p.insurer_org_id = ' || orgid);
--                    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
--                        whereclause := concat(whereclause, ' AND am.scheme_id = ' || JSON_VALUE(filterjson, '$.schemeId'));
--                    END IF;
                ELSE
                    whereclause := concat(whereclause, ' and 1 = 2 ');
                END IF;
            END IF;
        ELSE
            whereclause := concat(whereclause, ' and 1 = 2 ');
        END IF;
    ELSE
        whereclause := concat(whereclause, ' and 1 = 2 ');
    END IF;


       IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL THEN
            whereclause := CONCAT(whereclause, ' AND p.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
       END IF;
       
        mainquery := 'SELECT JSON_ARRAYAGG(JSON_OBJECT(''id'' value st.id,
                    ''stateName'' value state_name,
                    ''enrollStateId'' value enst.stateid ,
                    ''totalCount'' value (CASE WHEN enst.totalapplication IS NOT NULL THEN enst.totalapplication ELSE 0 end),
                    ''amount'' value (CASE WHEN enst.totalamount IS NOT NULL THEN enst.totalamount ELSE 0 end)
                    RETURNING CLOB) RETURNING CLOB)
                    FROM jns_oneform.state st
                    LEFT JOIN (
                    SELECT int.stateid AS stateid, SUM(int.totalapplication) AS totalapplication, SUM(int.totalamount) AS totalamount  FROM (
	                    SELECT p.branch_state_id AS stateid,
	                                    COUNT(p.id) AS totalapplication,
	                                    SUM(p.premium_amount) AS totalamount
	                                    FROM JNS_MASTER_DATA.pmsby p
	                     WHERE 1=1  AND p.org_Id = 13 GROUP BY p.branch_state_id
	                     
	                     UNION ALL
	                     
	                    SELECT p.branch_state_id AS stateid,
	                                    COUNT(p.id) AS totalapplication,
	                                    SUM(p.premium_amount) AS totalamount
	                                    FROM JNS_MASTER_DATA.pmjjby p
	                     WHERE 1=1  AND p.org_Id = 13 GROUP BY p.branch_state_id
                     
                     ) int GROUP BY int.stateid ORDER BY SUM(int.totalapplication) DESC
                     
                    ) enst ON enst.stateid = st.id WHERE st.country_id = 101';


    dbms_output.put_line(mainquery);
    EXECUTE IMMEDIATE mainquery
    INTO result;
    dbms_output.put_line(result);
END get_state_wise_enroll_count_v4;