CREATE OR REPLACE PROCEDURE JNS_REPORTS.PRE_RENEWAL_BANK_INSU_LIST(filterjson  IN   "VARCHAR",
    userid      IN   NUMBER,
    result      OUT  CLOB) AS 
    
   preparequery  CLOB;
    selectquery   CLOB;
    tablequery    CLOB;
    whereclause   CLOB;
    amodwhereclause CLOB;
    typeid        NUMBER;
    roleid        NUMBER;
    orgid         NUMBER;
    branchid      NUMBER;
    org_code    CLOB;
    scheme_code CLOB; 
     
BEGIN
     selectquery := 'SELECT JSON_ARRAYAGG(JSON_OBJECT(  ''bankName'' value orgName,
                                ''orgid'' value IMD.ORG_ID, 
                 ''successCount'' VALUE successCount,
	                ''failedCount'' VALUE failedCount,
	                ''totalCount'' VALUE totalCount
	               )RETURNING CLOB) ';
	     
    
        tablequery := 'FROM USR_INSURANCE.INSURER_MST_DETAILS imd ';
        whereclause := ' WHERE 1 = 1';      
	IF USERID IS NOT NULL AND USERID != 0 THEN
	    SELECT U.USER_TYPE_ID, U.BRANCH_ID, U.USER_ORG_ID, U.USER_ROLE_ID INTO typeid, branchid, orgid, roleid
	      FROM JNS_USERS.USERS U WHERE U.IS_ACTIVE = 1 AND U.USER_ID = USERID;
	     dbms_output.put_line(typeid);
        select ORGANISATION_CODE into org_code from jns_users.USER_ORGANISATION_MASTER where user_org_id = orgid;   
        
	    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.schemeId') != -1 THEN
	        select short_name into scheme_code from jns_users.SCHEME_MASTER where id = JSON_VALUE (filterjson, '$.schemeId');
	        whereclause := CONCAT(whereclause, ' AND imd.scheme_id =' ||JSON_VALUE (filterjson, '$.schemeId'));
	    END IF;
	    
	    IF (typeid) IS NOT NULL THEN
	    	IF (typeid = 2) THEN
	    		whereclause := CONCAT(whereclause, ' AND imd.ORG_ID = ''' || org_code||''' ');
               tableQuery := CONCAT (tablequery,' SELECT
	                    MAX(bufl.insurer_org_code) as orgName, 
	                    SUM(bufl.SUCCESS_COUNT) as successCount , 
	                    SUM(bufl.FAILED_COUNT) as failedCount, 
	                    SUM(bufl.TOTAL_COUNT) as totalCount
	                    FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
			            WHERE BUFL.ORG_CODE  = ' ||org_code||'
			            GROUP BY bufl.insurer_ORG_CODE
	                ) tmp ON imd.insurer_org_id = tmp.orgName
	                LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = imd.insurer_org_id');
	        ELSIF (typeid = 6) THEN
                tableQuery := CONCAT (tablequery,
                'LEFT JOIN (
		            SELECT MAX(bufl.ORG_CODE) as ORG_CODE, SUM(bufl.SUCCESS_COUNT) as successCount , 
                    SUM(bufl.FAILED_COUNT) as failedCount, 
                    SUM(bufl.TOTAL_COUNT) as totalCount
		            FROM JNS_MASTER_DATA.BULK_UPLOAD_FILE_LOG bufl
		            WHERE BUFL.INSURER_ORG_CODE  = '||orgid||'
		            GROUP BY bufl.ORG_CODE
                ) tmp ON imd.org_id = tmp.USER_ORG_ID 
                LEFT JOIN jns_users.USER_ORGANISATION_MASTER uom ON uom.ORGANISATION_CODE = tmp.ORG_CODE ');
                whereclause := CONCAT(whereclause, ' AND imd.INSURER_ORG_ID = ' || orgid || ' AND IMD.IS_ACTIVE= 1');   
	        END IF;
	    ELSE
	        whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
	    END IF;
	ELSE
	     whereclause := CONCAT(whereclause, ' AND 1 = 2 '); 
	END IF;


    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
--    dbms_output.put_line(result);
  
  
END PRE_RENEWAL_BANK_INSU_LIST;