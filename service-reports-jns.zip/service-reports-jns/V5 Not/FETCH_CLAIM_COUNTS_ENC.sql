CREATE OR REPLACE PROCEDURE JNS_REPORTS."FETCH_CLAIM_COUNTS_ENC" (filterjson IN  "VARCHAR",
                                                userid     IN  NUMBER,
                                                result     OUT CLOB)
  AS
    preparequery    CLOB;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' SELECT JSON_OBJECT(
          ''inProgressCount'' value SUM(CASE WHEN claim_status = 5  THEN 1 ELSE 0 END),
          ''sendToInsurerCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''receivedFromBankCount'' value SUM(CASE WHEN claim_status = 6 THEN 1 ELSE 0 END),
          ''sendBackByInsurerCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''sendBackToBnakCount'' value SUM(CASE WHEN claim_status = 7 THEN 1 ELSE 0 END),
          ''rejectedCount'' value SUM(CASE WHEN claim_status = 8  THEN 1 ELSE 0 END),
          ''onHoldCount'' value SUM(CASE WHEN claim_status = 9 THEN 1 ELSE 0 END),
          ''acceptedCount'' value SUM(CASE WHEN claim_status = 10  THEN 1 ELSE 0 END),
          ''inProgressCount'' value SUM(CASE WHEN claim_status = 11 THEN 1 ELSE 0 END)
          ) ';

    tablequery := ' FROM USR_INSURANCE.claim_master ca
                        INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
                        INNER JOIN USR_INSURANCE.application_master am ON am.id = ca.application_id
                        INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                        LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                   LEFT JOIN JNS_ONEFORM.state st ON st.id = amod.branch_state_id
                   LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1
                   LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id=am.id
                    LEFT JOIN jns_users.user_organisation_master uom ON uom.user_org_id=am.insurer_org_id AND uom.is_active=1
                    LEFT JOIN jns_users.user_organisation_master uomb ON uomb.user_org_id=am.org_id AND uomb.is_active=1
                    LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id AND bm.is_active=1
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id AND bmro.is_active=1
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id AND bmzo.is_active=1
                    LEFT JOIN USR_INSURANCE.address_master adm ON adm.id=ai.address_id
                    LEFT JOIN USR_INSURANCE.nominee_details cld ON cld.application_id=am.id and cld.type=1
                    LEFT JOIN USR_INSURANCE.nominee_details nd ON nd.application_id=am.id and nd.type=2
                    LEFT JOIN USR_INSURANCE.nominee_details gdd ON gdd.application_id=am.id and gdd.type=3
                    LEFT JOIN jns_oneform.dropdowns_values GEN ON GEN.obj_id=ai.gender_id AND GEN.dropdown_id=8 AND GEN.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values NL ON NL.obj_id=cd.nature_of_loss_id AND NL.dropdown_id=3 AND NL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values CDD ON CDD.obj_id=cd.cause_of_death_disability_id AND CDD.dropdown_id=6 AND CDD.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values TDD ON TDD.obj_id=cd.type_of_disability_id AND TDD.dropdown_id=5 AND TDD.is_active=1
                    LEFT JOIN USR_INSURANCE.stage_master SMC ON SMC.id=ca.claim_status
                    LEFT JOIN jns_users.users usr ON usr.user_id=am.created_by AND usr.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL ON REL.obj_id=nd.relation_id AND REL.dropdown_id=1 AND REL.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL1 ON REL1.obj_id=cld.relation_id AND REL1.dropdown_id=1 AND REL1.is_active=1
                    LEFT JOIN jns_oneform.dropdowns_values REL2 ON REL2.obj_id=gdd.relation_id AND REL2.dropdown_id=1 AND REL2.is_active=1
                      ';
    whereclause := ' WHERE ca.is_active = 1 ';

    IF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      fromtodatequery := ' AND TRUNC(ca.claim_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';
      whereclause := CONCAT(whereclause, fromtodatequery);
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      --   dbms_output.put_line(typeid || branchid || orgid || roleid );
      IF typeid IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || branchid);
            ELSE
              whereclause := ' and 1 = 2 ';
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        ELSE
          whereclause := ' and 1 = 2 ';
        END IF;

      ELSE
        whereclause := ' and 1 = 2 ';
      END IF;

    ELSE
      whereclause := ' and 1 = 2 ';
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_stage_id = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || JSON_VALUE (filterjson, '$.roId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || JSON_VALUE (filterjson, '$.zoId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || JSON_VALUE (filterjson, '$.boId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.channel_id = ''' || JSON_VALUE (filterjson, '$.channelId')||'''' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_state_id = ' || JSON_VALUE (filterjson, '$.stateId'));
    END IF;

    preparequery := selectquery || tablequery || whereclause;
    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  END ;

