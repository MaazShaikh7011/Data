package com.opl.jns.otp.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.otp.api.exception.OTPException;
import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.utils.common.OPLUtils;

public class OTPClient {

	private static Logger logger = LoggerFactory.getLogger(OTPClient.class);

	private static final String SEND_OTP = "/v3/otp/send";
//	private static final String SEND_OTP_MOBILE_AND_EMAIL = "/v3/otp/sendLoginOTPonMobileAndEmail";
	private static final String SEND_CONSENT_OTP_ON_MOBILE_EMAIL = "/v3/otp/sendConsentOTPOnMobileEmail";
	private static final String VERIFY_OTP = "/v3/otp/verify";
//	private static final String GENERATE_OTP = "/v3/otp/generate";
	private static final String SEND_EMAIL_OTP = "/v3/otp/sendEmailOTP";
//	private static final String PING_OTP = "/v3/otp/ping";
	
    private static final String OTP_SERVICE_IS_NOT_AVAILABLE="OTP Service is not available";
	private String otpBaseUrl;
	
//	@Autowired
	private RestTemplate restTemplate;
	private static final String MSG_EXCEPTION = "Exception ::" ;
	private static final String OTP_SERVICE_ERROR= "OTP Service Error = {}";
	public OTPClient(String otpBaseUrl) {
		this.otpBaseUrl = otpBaseUrl;
//		this.otpBaseUrl = "http://localhost:8181/otpservice/v3/otp";
		restTemplate = new RestTemplate();
	}

	/**
	 * Testing OTP Service whether it is working or not.
	 * 
	 * @return
	 * @throws OTPException
	 */
	/* NOT IN USE */
//	public String ping() throws OTPException {
//		String url = otpBaseUrl.concat(PING_OTP);
//		logger.info("Ping URL==>{}", url);
//		try {
//			return restTemplate.getForObject(url, String.class);
//		} catch (Exception e) {
//			logger.error(OTP_SERVICE_ERROR , e);
//			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
//		}
//	}

	/**
	 * TO send OTP on mobile or email
	 * 
	 * @param request
	 *            hold the Required information like
	 *            mobileNo,email,requestType,masterId
	 * @return
	 * @throws OTPException
	 */
	/* NOT IN USE */
//	public OTPResponse sendOTPonMobileAndEmail(OTPRequest request) throws OTPException {
//		String url = otpBaseUrl.concat(SEND_OTP_MOBILE_AND_EMAIL);
//		logger.info("Send OTP URL==>{}", url);
//		try {
//			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),OTPResponse.class);
//		} catch (Exception e) {
//			logger.error(MSG_EXCEPTION,e);
//			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
//		}
//	}
	
	/* NOT IN USE */
//	public OTPResponse generateOTP(OTPRequest request) throws OTPException {
//		String url = otpBaseUrl.concat(GENERATE_OTP);
//		logger.info("generate OTP URL==>{}", url);
//		try {
//			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),
//					OTPResponse.class);
//		} catch (Exception e) {
//			logger.error(OTP_SERVICE_ERROR, e);
//			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
//		}
//	}

	/**
	 * TO send OTP on mobile AND email
	 * ̥
	 * @param request
	 *            hold the Required information like
	 *            mobileNo,email,requestType,masterId
	 * @return
	 * @throws OTPException
	 */
	public OTPResponse sendOTP(OTPRequest request) throws OTPException {
		String url = otpBaseUrl.concat(SEND_OTP);
		logger.info("Send OTP URL==>{}", url);
		try {
			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),OTPResponse.class);
		} catch (Exception e) {
			logger.error(MSG_EXCEPTION,e);
			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
		}
	}


	/**
	 * To Verify Entered OTP whether it is correct or not
	 * 
	 * @param request
	 *            hold the Required information like
	 *            mobileNo,email,requestType,masterId,OTP
	 * @return
	 * @throws OTPException
	 */
	public OTPResponse verifyOTP(OTPRequest request) throws OTPException {
		String url = otpBaseUrl.concat(VERIFY_OTP);
		logger.info("Verify OTP URL==>{}", url);
		try {
			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),
					OTPResponse.class);
		} catch (Exception e) {
			logger.error(OTP_SERVICE_ERROR, e);
			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
		}
	}

	public HttpEntity<OTPRequest> getHeader(OTPRequest otpRequest, String connentTye) {
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.add("Content-Type", connentTye);
		headers.add("Accept", "application/json");
		headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		return new HttpEntity<>(otpRequest, headers);
	}
	
	public OTPResponse sendEmailOTP(OTPRequest request) throws OTPException {
		String url = otpBaseUrl.concat(SEND_EMAIL_OTP);
		logger.info("Send Email OTP URL==>{}", url);
		try {
			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),
					OTPResponse.class);
		} catch (Exception e) {
			logger.error(OTP_SERVICE_ERROR, e);
			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
		}
	}
	
	public OTPResponse sendConsentOTPonMobileEmail(OTPRequest request) throws OTPException {
		String url = otpBaseUrl.concat(SEND_CONSENT_OTP_ON_MOBILE_EMAIL);
		logger.info("Send OTP URL==>{}", url);
		try {
			return restTemplate.postForObject(url, getHeader(request, MediaType.APPLICATION_JSON_VALUE),OTPResponse.class);
		} catch (Exception e) {
			logger.error(MSG_EXCEPTION,e);
			throw new OTPException(OTP_SERVICE_IS_NOT_AVAILABLE);
		}
	}
}
