package com.opl.jns.otp.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
//import com.opl.jns.common.logs.client.AnsLogsClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableAsync
@EnableScheduling
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableDiscoveryClient
public class OTPApplication {

	@Autowired
	private ApplicationContext applicationContext; 

	@Value("${notification_baseURL}")
	private String notificationBaseURL;
	
	@Value("${capitaworld.service.users.url}") 
	private String usersUrl;
	
	public static void main(String[] args) {
		SpringApplication.run(OTPApplication.class, args);
	}

	@Bean
	public NotificationClient notificationClient() {
		NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
		return notificationClient;
	}
	
	@Bean
	public UsersClient usersClient() {
		UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
		return usersClient;
	}
	
	@Bean
	public AuthClient authClient() {
		AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
		return authClient;
	}
}
