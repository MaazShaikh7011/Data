package com.opl.jns.otp.service.service;

import java.text.ParseException;

import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;

public interface OTPLoggingService {

	/**
	 * Send OTP to given Mobile No
	 * @param request
	 * @return
	 */
	public OTPResponse sendOTP(OTPRequest request);
	
	/**
	 * Send OTP on mobile and email 
	 * @param request
	 * @return
	 */
	/* NOT IN USE */
//	public boolean sendOTPOnMobileAndEmail(OTPRequest request);
	
	/**
	 * Generating OTP to send on Email
	 * @param request
	 * @return
	 */
	/* NOT IN USE */
//	public String genrateOTPForEmail(OTPRequest request);
	
	/**
	 * Getting Random Generated OTP 
	 * @param request
	 * @return
	 */
	public String getOTP(OTPRequest request);
	
	/**
	 * Checking whether the Given OTP is Active and Exists for the Given mobile
	 * @param request
	 * @return
	 */
	public boolean isOTPExists(OTPRequest request);
	
	/**
	 * Verifying the Given OTP with the Given Mobile
	 * @param request
	 * @return
	 * @throws ParseException
	 */
	public boolean verifyOTP(OTPRequest request) throws ParseException;


	/**
	 * Checking the Duration of Last sent OTP on the same Mobile Number.
	 * @param request
	 * @return
	 */
	/* NOT IN USE */
//	public boolean isOptAlreadySentForDefinedDuration(OTPRequest request,Boolean forEmail);
	
	public boolean sendEmailForOTPVerification(OTPRequest request);

	OTPResponse sendConsentOTPOnMobileEmail(OTPRequest request);
}
