package com.opl.jns.otp.service.utils;

public class OTPConstants {

	private OTPConstants(){
		//Nothing to do for X and Y
	}
	// Connection Constants
	public final class Connection {
		private Connection(){
			//Nothing to do for X and Y
		}
		public static final String OTP_DATA_STORE_TRANSACTION_MANAGER = "otpDataStoreTM";
		public static final String OTP_DATA_STORE_ENTITY_MANAGER = "otpDataStoreEM";
		public static final String OTP_DATA_STORE = "otpDataStore";
	}

	// Custom Property Constants
	public final class OTPProperty {
		private OTPProperty(){
			//Nothing to do for X and Y
		}
		public static final String EXPIRY_TIME = "capitaworld.otp.expiry-time";
		public static final String DIGITS = "capitaworld.otp.digits";
	}
	
	public final class OTPOn {
		private OTPOn(){
			//Nothing to do for X and Y
		}
		public static final int EMAIL = 2;
		public static final int MOBILE = 1;
	}
}
