package com.opl.jns.otp.service.domain;

import com.opl.jns.utils.common.*;
import com.opl.jns.utils.constant.*;
import lombok.*;
import org.hibernate.proxy.*;
import org.springframework.format.annotation.*;

import jakarta.persistence.*;
import java.io.*;
import java.util.*;

/**
 * The persistent class for the otp_logging_details database table.
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "otp_logging_details",indexes = {
        @Index(columnList = "otp,is_active,is_expired,is_verified,type_id,master_id",name = DBNameConstant.JNS_OTP+"OTP_LGG_DTL_OTP_ACT_EXP_VRFD_TYP_MST"),
        @Index(columnList = "is_expired,is_verified,type_id,master_id",name = DBNameConstant.JNS_OTP+"OTP_LGG_DTL_EXP_VRFD_TYP_MST")
})
public class OtpLoggingDetail implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 8173598054898240710L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otp_logging_details_otp_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_OTP, name = "otp_logging_details_otp_seq_gen", sequenceName = "otp_logging_details_otp_seq", allocationSize = 1)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "type_id", referencedColumnName = "id")
    private OtpTypeMaster type;

    @Column(name = "otp", columnDefinition = "varchar(50) default ''")
    @Convert(converter = AESOracle.class)
    private String otp;

    @Column(name = "master_id")
    private Long masterId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedDate;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_verified")
    private Boolean isVerified;

    @Column(name = "is_expired")
    private Boolean isExpired;

    @Column(name = "mobile_no", columnDefinition = "varchar(100) default ''")
    @Convert(converter = AESOracle.class)
    private String mobileNo;

    @Column(name = "email", columnDefinition = "varchar(255) default ''")
    @Convert(converter = AESOracle.class)
    private String email;

    @Column(name = "otp_on")
    private Integer otpOn;
}