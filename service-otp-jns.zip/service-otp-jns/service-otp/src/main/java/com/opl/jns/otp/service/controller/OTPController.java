package com.opl.jns.otp.service.controller;

import com.opl.jns.config.utils.*;
import com.opl.jns.otp.api.model.*;
import com.opl.jns.otp.service.service.*;
import com.opl.jns.otp.service.utils.*;
import com.opl.jns.utils.common.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v3/otp")
@Slf4j
public class OTPController {
	
    private static final String REQUESTED_DATA_CAN_NOT_BE_EMPTY="Requested data can not be empty";
    private static final String INVALID_REQUEST="Invalid Request==>{}";
	@Autowired
	private OTPLoggingService oTPLoggingService;

	@GetMapping(value = "/servicecheck")
	public Boolean checkService() {
		return true;
	}

	@SkipInterceptor
	@PostMapping(value = "/send", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OTPResponse> send(@RequestBody OTPRequest request) {
		// request must not be null
		if (request == null) {
			log.warn("OTPRequest Object can not be empty while sending OTP==>{}" , request);
			return new ResponseEntity<OTPResponse>(
					new OTPResponse("Requested data can not be empty.", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// checking basic requirements
		if (request.getRequestType() == null || request.getMobileNo() == null || request.getMasterId() == null) {
			log.warn(INVALID_REQUEST ,request);
			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST,HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		if(request.getOtpOn() == null) {
			request.setOtpOn(OTPConstants.OTPOn.MOBILE);
		}
//		boolean res = oTPLoggingService.isOptAlreadySentForDefinedDuration(request,Boolean.FALSE);
//		if(res){
//			log.info("Otp Already Send for some duration==>");
//			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Already Sent. Please wait for sometime.", HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
//		}

		OTPResponse	response = oTPLoggingService.sendOTP(request);
		if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus()) &&  response.getStatus() == HttpStatus.OK.value()) {
			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Successfully Sent to your mobile number.", HttpStatus.OK.value(),response,Boolean.TRUE),HttpStatus.OK);
		}

		log.error("Something went wrong!.==>{}" , request);
		return new ResponseEntity<OTPResponse>(
				new OTPResponse("Something went wrong!.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
	}
	
	/* NOT IN USE */	
//	@SkipInterceptor
//	@PostMapping(value = "/sendLoginOTPonMobileAndEmail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<OTPResponse> sendOTPonMobileAndEmail(@RequestBody OTPRequest request) {
//		
//		// request must not be null
//		if (request == null) {
//			log.warn("OTPRequest Object can not be empty while sending OTP==>{}" , request);
//			return new ResponseEntity<OTPResponse>(
//					new OTPResponse("Requested data can not be empty.", HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//
//		// checking basic requirements
//		if (request.getRequestType() == null || request.getOtp() != null
//				|| request.getMasterId() == null) {
//			log.warn(INVALID_REQUEST ,request);
//			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST,HttpStatus.BAD_REQUEST.value()),
//					HttpStatus.OK);
//		}
//		boolean res = oTPLoggingService.isOptAlreadySentForDefinedDuration(request,Boolean.FALSE);
//		if(res){
//			log.info("Otp Already Send for some duration==>");
//			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Already Sent. Please wait for sometime.", HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
//		}
//
//		res = oTPLoggingService.sendOTPOnMobileAndEmail(request);
//		if (res) {
//			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Successfully Sent to your mobile number.", HttpStatus.OK.value()),HttpStatus.OK);
//		}
//
//		log.error("Something went wrong!.==>{}" , request);
//		return new ResponseEntity<OTPResponse>(
//				new OTPResponse("Something went wrong!.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//	}
	
	@SkipInterceptor
	@PostMapping(value = "/verify", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OTPResponse> verify(@RequestBody OTPRequest request) {
		if (request == null) {
			log.warn("OTPRequest Object can not be empty while verifying OTP==>{}" , request);
			return new ResponseEntity<OTPResponse>(
					new OTPResponse(REQUESTED_DATA_CAN_NOT_BE_EMPTY, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		}

		// checking basic requirements
		if (request.getRequestType() == null  || request.getOtp() == null
				|| request.getMasterId() == null) {
			log.warn(INVALID_REQUEST , request.getRequestType());
			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST,HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}

		try {
			boolean result = oTPLoggingService.verifyOTP(request);
			if (result) {
				log.info("Successfully Updated OTP For User==>{}", request.getMasterId());
				return new ResponseEntity<OTPResponse>(new OTPResponse("Success", HttpStatus.OK.value()),
						HttpStatus.OK);
			} else {
				log.warn("Invalid or expired OTP==>{}");
				return new ResponseEntity<OTPResponse>(
						new OTPResponse("Invalid or expired OTP", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Error while verifying OTP==>", e);
			return new ResponseEntity<OTPResponse>(
					new OTPResponse("Something went wrong!", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/* NOT IN USE */
//	@PostMapping(value = "/generate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<OTPResponse> generateOTP(@RequestBody OTPRequest request) {
//		// request must not be null
//		if (request == null) {
//			log.warn("OTPRequest Object can not be empty while Generating OTP==>{}", request);
//			return new ResponseEntity<OTPResponse>(
//					new OTPResponse(REQUESTED_DATA_CAN_NOT_BE_EMPTY, HttpStatus.INTERNAL_SERVER_ERROR.value()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//
//		// checking basic requirements
//		if (request.getRequestType() == null || request.getMobileNo() == null || request.getOtp() != null
//				|| request.getMasterId() == null) {
//			log.warn(INVALID_REQUEST, request);
//			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
//					HttpStatus.OK);
//		}
//		
//		if(request.getOtpOn() == null) {
//			request.setOtpOn(OTPConstants.OTPOn.EMAIL);
//		}
//		
////		if(oTPLoggingService.isOptAlreadySentForDefinedDuration(request,Boolean.TRUE)){
////			log.info("Otp Already Send for some duration==>"); // 202 repsent as otp sent once wait some to resend
////			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Already Sent. Please wait for sometime.", HttpStatus.OK.value(),202),HttpStatus.OK);
////		}
//
//		String res = oTPLoggingService.genrateOTPForEmail(request);
//		if (res != null) {
//			return new ResponseEntity<OTPResponse>(
//					new OTPResponse("OTP Successfully Generated.", HttpStatus.OK.value(),res),
//					HttpStatus.OK);
//		}
//
//		log.error("Something went wrong!.==>{}", request);
//		return new ResponseEntity<OTPResponse>(
//				new OTPResponse("Something went wrong!.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//	}
	
	@SkipInterceptor
	@PostMapping(value = "/sendEmailOTP", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OTPResponse> sendEmailOTP(@RequestBody OTPRequest request) {
		
		// checking basic requirements
		if (request.getRequestType() == null || request.getEmailId() == null || request.getMasterId() == null) {
			log.warn(INVALID_REQUEST ,request);
			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST,HttpStatus.BAD_REQUEST.value()),
					HttpStatus.OK);
		}
		if(request.getOtpOn() == null) {
			request.setOtpOn(OTPConstants.OTPOn.EMAIL);
		}
		boolean res = oTPLoggingService.sendEmailForOTPVerification(request);
		if (res) {
			return new ResponseEntity<OTPResponse>(new OTPResponse("User verification Code Successfully Sent to your email address.", HttpStatus.OK.value()),HttpStatus.OK);
		}

		log.error("Something went wrong while sendEmailOTP!.==>{}" , request);
		return new ResponseEntity<OTPResponse>(
				new OTPResponse("Something went wrong!.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
	}
	
	@SkipInterceptor
	@PostMapping(value = "/sendConsentOTPOnMobileEmail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OTPResponse> sendConsentOTPOnMobileEmail(@RequestBody OTPRequest request) {
		
		// request must not be null
		if (request == null) {
			log.warn("OTPRequest Object can not be empty while sending OTP==>{}" , request);
			return new ResponseEntity<OTPResponse>(
					new OTPResponse("Requested data can not be empty.", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// checking basic requirements
		if ((OPLUtils.isObjectNullOrEmpty(request.getSmsNotiMasterId()) && OPLUtils.isObjectNullOrEmpty(request.getEmailNotiMasterId())) || OPLUtils.isObjectNullOrEmpty(request.getRequestType())) {
			log.warn(INVALID_REQUEST ,request);
			return new ResponseEntity<OTPResponse>(new OTPResponse(INVALID_REQUEST,HttpStatus.BAD_REQUEST.value()),
			HttpStatus.OK);
		}
		
//		boolean res = oTPLoggingService.isOptAlreadySentForDefinedDuration(request,Boolean.FALSE);
//		if(res){
//			log.info("Otp Already Send for some duration==>");
//			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Already Sent. Please wait for sometime.", HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
//		}
		 OTPResponse response = oTPLoggingService.sendConsentOTPOnMobileEmail(request);
		if (!OPLUtils.isObjectNullOrEmpty(response.getData()) && response.getStatus() == HttpStatus.OK.value()) {
			return new ResponseEntity<OTPResponse>(new OTPResponse("OTP Sent Successfully.", HttpStatus.OK.value(),response.getData()),HttpStatus.OK);
		}
		log.error("Otp not send successfully.==>{}" , response.getData());
		return new ResponseEntity<OTPResponse>(
				new OTPResponse("Something went wrong!.", HttpStatus.INTERNAL_SERVER_ERROR.value(),null), HttpStatus.OK);
	}
}
