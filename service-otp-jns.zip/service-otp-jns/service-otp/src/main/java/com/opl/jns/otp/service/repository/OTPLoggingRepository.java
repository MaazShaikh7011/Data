package com.opl.jns.otp.service.repository;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.*;

import com.opl.jns.otp.service.domain.*;

public interface OTPLoggingRepository extends JpaRepository<OtpLoggingDetail, Long> {

	@Query("select count(log.id) from OtpLoggingDetail log where log.otp =:otp and log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.mobileNo =:mobileNo")
	public Long getCountOfValidOTP(@Param("otp") String otp, @Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("mobileNo") String mobileNo);

	
	@Query("select count(log.id) from OtpLoggingDetail log where log.otp =:otp and log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.email =:email")
	public Long getCountOfValidOTPEmail(@Param("otp") String otp, @Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("email") String email);

	
	
	@Query("select log from OtpLoggingDetail log where log.otp =:otp and log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.mobileNo =:mobileNo")
	public OtpLoggingDetail getOTPDetails(@Param("otp") String otp, @Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("mobileNo") String mobileNo);
	
	@Query("select log from OtpLoggingDetail log where log.otp =:otp and log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.email =:email")
	public OtpLoggingDetail getOTPDetailsForEmail(@Param("otp") String otp, @Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("email") String email);

	
	
	@Modifying
	@Query("update OtpLoggingDetail log set log.isActive = false where log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.mobileNo =:mobileNo")
	public int inActivePreviousMobileOTP(@Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("mobileNo") String mobileNo);
	
	@Modifying
	@Query("update OtpLoggingDetail log set log.isActive = false where log.isActive = true and log.isExpired = false and log.isVerified = false and log.type.id =:typeId and log.masterId =:masterId and log.email =:email")
	public int inActivePreviousEmailOTP(@Param("typeId") Integer typeId,
			@Param("masterId") Long masterId, @Param("email") String email);


	public OtpLoggingDetail findFirstByEmailAndTypeIdAndIsActiveAndIsExpiredAndIsVerifiedOrderByIdDesc(String email,Integer type,Boolean isActive,Boolean isExpired,Boolean isVerified);
	public OtpLoggingDetail findFirstByMobileNoAndTypeIdAndIsActiveAndIsExpiredAndIsVerifiedOrderByIdDesc(String mobile,Integer type,Boolean isActive,Boolean isExpired,Boolean isVerified);
	

	
}
