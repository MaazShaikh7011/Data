package com.opl.jns.otp.service.service.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.otp.api.model.OTPRequest;
import com.opl.jns.otp.api.model.OTPResponse;
import com.opl.jns.otp.api.utils.DateTimeUtils;
import com.opl.jns.otp.service.domain.OtpLoggingDetail;
import com.opl.jns.otp.service.domain.OtpTypeMaster;
import com.opl.jns.otp.service.repository.OTPLoggingRepository;
import com.opl.jns.otp.service.service.OTPLoggingService;
import com.opl.jns.otp.service.utils.OTPConstants;
import com.opl.jns.otp.service.utils.OTPGenerator;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class OTPLoggingServiceImpl implements OTPLoggingService {

	@Value("${capitaworld.otp.expiry-time}")
	private String otpExpiryTime;

	@Value("${capitaworld.otp.digits}")
	private String otpDigits;

	@Value("${capitaworld.otp.duration-type}")
	private String otpDurationType;

	@Value("${capitaworld.otp.duration}")
	private String otpDuration;

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private OTPLoggingRepository oTPLoggingRepository;

	/**
	 * Send OTP
	 */

	@Override
	public OTPResponse sendOTP(OTPRequest request) {
		/* INACTIVE PREVIOUS OTP IF USER HAS SEND OTP REQUEST TWICE OR MORE THAN TWICE. */
		oTPLoggingRepository.inActivePreviousMobileOTP(request.getRequestType(), request.getMasterId(),request.getMobileNo());

		/* SAVING NEW OTP */
		OtpLoggingDetail loggingDetails = new OtpLoggingDetail();
		String otp = getOTP(request);
		log.info("OTP Generated==>");
		loggingDetails.setOtp(otp);
		loggingDetails.setMasterId(request.getMasterId());
		loggingDetails.setMobileNo(request.getMobileNo());
		loggingDetails.setEmail(request.getEmailId());
		loggingDetails.setType(new OtpTypeMaster(request.getRequestType()));
		loggingDetails.setCreatedDate(new Date());
		loggingDetails.setCreatedBy(request.getMasterId());
		loggingDetails.setIsActive(true);
		loggingDetails.setIsExpired(false);
		loggingDetails.setIsVerified(false);
		loggingDetails.setOtpOn(OTPConstants.OTPOn.MOBILE);
		oTPLoggingRepository.save(loggingDetails);

		/* SEND OTP TO MOBILE */
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("otp", otp);
		String[] toSms = { "91" + loggingDetails.getMobileNo() };
		Notification smsReq = NotificationClient.prepareRequestForSmsOrEmail(toSms, parameters, request.getNotificationMasterId(),null, NotificationType.SMS);
		NotificationRequest notificationRequest = new NotificationRequest();
		notificationRequest.addNotification(smsReq);
		notificationClient.send(notificationRequest);

		log.info("OTP For UserId==>{}", request.getMasterId());
		log.info("Success to send notification :: " + notificationRequest.getClientRefId());
		return new OTPResponse("OTP Send Successfully",HttpStatus.OK.value(),otp,Boolean.TRUE);
	}

	/* NOT IN USE */
//	@Override
//	public String genrateOTPForEmail(OTPRequest request) {
//		// INACTIVE previous OTP if user has send OTP request twice or more than
//		// twice.
//		try {
//			if (request.getOtpOn() == OTPConstants.OTPOn.MOBILE) {
//				oTPLoggingRepository.inActivePreviousMobileOTP(request.getRequestType(), request.getMasterId(),
//						request.getMobileNo());
//			} else {
//				oTPLoggingRepository.inActivePreviousEmailOTP(request.getRequestType(), request.getMasterId(),
//						request.getEmailId());
//			}
//
//			// saving new OTP
//			OtpLoggingDetail loggingDetails = new OtpLoggingDetail();
//			String otp = getOTP(request);
//			log.info("OTP Generated==>");
//			loggingDetails.setOtp(otp);
//			loggingDetails.setMasterId(request.getMasterId());
//			loggingDetails.setMobileNo(request.getMobileNo());
//			loggingDetails.setEmail(request.getEmailId());
//			loggingDetails.setType(new OtpTypeMaster(request.getRequestType()));
//			loggingDetails.setCreatedDate(new Date());
//			loggingDetails.setCreatedBy(request.getMasterId());
//			loggingDetails.setIsActive(true);
//			loggingDetails.setIsExpired(false);
//			loggingDetails.setIsVerified(false);
//			loggingDetails.setOtpOn(request.getOtpOn());
//			oTPLoggingRepository.save(loggingDetails);
//			return otp;
//		} catch (Exception e) {
//			log.error("Exception", e);
//			return null;
//		}
//	}

	/**
	 * generate and check OTP exists or not.
	 */
	@Override
	public String getOTP(OTPRequest request) {
		Integer noOfDigits = Integer.parseInt(otpDigits);
		String otp = OTPGenerator.generateOTP(noOfDigits);
		request.setOtp(otp);
		if (isOTPExists(request)) {
			getOTP(request);
		}
		return otp;
	}

	/**
	 * check whether the OTP is already exists or not.
	 */
	@Override
	public boolean isOTPExists(OTPRequest request) {

		if (request.getOtpOn() == null || OTPConstants.OTPOn.MOBILE == request.getOtpOn()) {
			// Default Mobile
			return oTPLoggingRepository.getCountOfValidOTP(request.getOtp(), request.getRequestType(),
					request.getMasterId(), request.getMobileNo()) > 0;
		} else {
			return oTPLoggingRepository.getCountOfValidOTPEmail(request.getOtp(), request.getRequestType(),
					request.getMasterId(), request.getEmailId()) > 0;
		}
	}

	/**
	 * verify otp and update the status of OTP like expired or verified
	 */
	@Override
	public boolean verifyOTP(OTPRequest request) throws ParseException {

		boolean isExists = isOTPExists(request);
		if (!isExists) {
			return false;
		}
		OtpLoggingDetail otpDetails = null;

		if (request.getOtpOn() == null || request.getOtpOn() == OTPConstants.OTPOn.MOBILE) {
			// Default Mobile
			otpDetails = oTPLoggingRepository.getOTPDetails(request.getOtp(), request.getRequestType(),
					request.getMasterId(), request.getMobileNo());
		} else {
			otpDetails = oTPLoggingRepository.getOTPDetailsForEmail(request.getOtp(), request.getRequestType(),
					request.getMasterId(), request.getEmailId());
		}

		if (otpDetails == null) {
			return false;
		}

		long expiryMinutes = Long.parseLong(otpExpiryTime);
		long originalMinutes = DateTimeUtils.getDateDifference(new Date(), otpDetails.getCreatedDate(),
				DateTimeUtils.DateTime.MINUTES);

		boolean result = true;
		if (originalMinutes > expiryMinutes) {
			otpDetails.setIsExpired(true);
			result = false;
		} else {
			otpDetails.setIsVerified(true);
		}
		otpDetails.setModifiedDate(new Date());
		otpDetails.setModifiedBy(request.getMasterId());
		oTPLoggingRepository.save(otpDetails);
		return result;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getObjectFromMap(Map<?, ?> map, Class<?> clazz) {
		final ObjectMapper mapper = new ObjectMapper(); // jackson's
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return (T) mapper.convertValue(map, clazz);
	}
	
	/* NOT IN USE */
//	@Override
//	public boolean isOptAlreadySentForDefinedDuration(OTPRequest request, Boolean forEmail) {
//
//		if (otpDurationType == null || "".equalsIgnoreCase(otpDurationType)) {
//			log.info("Otp Duration Type is not set!");
//			return false;
//		}
//		if (otpDuration == null || "".equalsIgnoreCase(otpDuration)) {
//			log.info("otpDuration is not set for otpDurationType ==> {}", otpDurationType);
//			return false;
//		}
//
//		OtpLoggingDetail otpSent = null;
//
//		if (forEmail) {
////			otpSent = oTPLoggingRepository.findByEmailAndActiveAndExpired(request.getEmailId(),
////					request.getRequestType(), true, false, false, PageRequest.of(0,1));
//			otpSent = oTPLoggingRepository.findFirstByEmailAndTypeIdAndIsActiveAndIsExpiredAndIsVerifiedOrderByIdDesc(request.getEmailId(),request.getRequestType(), true, false, false);
//		} else {
////			otpSent = oTPLoggingRepository.findByMobileAndActiveAndExpired(request.getMobileNo(),
////					request.getRequestType(), true, false, false, PageRequest.of(0,1));
//			otpSent = oTPLoggingRepository.findFirstByMobileNoAndTypeIdAndIsActiveAndIsExpiredAndIsVerifiedOrderByIdDesc(request.getMobileNo(),request.getRequestType(), true, false, false);
//		}
//		log.info("Successfully checked new query ===============================>");
//		if (otpSent == null) {
//			log.info("Otp is not sent Yet!");
//			return false;
//		}
//		Calendar today = Calendar.getInstance();
//		today.setTime(new Date());
//
//		Calendar createdDate = Calendar.getInstance();
//		createdDate.setTime(otpSent.getCreatedDate());
//		long diffMiliSeconds = today.getTime().getTime() - createdDate.getTime().getTime();
//		long diff = 0l;
//		log.info("Diff======>{} ===========>Otp Duration Property File=======>{}====>For Duration Type=========>{}",
//				diff, otpDuration, otpDurationType);
//		if ("M".equalsIgnoreCase(otpDurationType)) {
//			diff = TimeUnit.MINUTES.convert(diffMiliSeconds, TimeUnit.MILLISECONDS);
//			if (diff < Integer.parseInt(otpDuration)) {
//				return true;
//			}
//		} else if ("S".equalsIgnoreCase(otpDurationType)) {
//			diff = TimeUnit.SECONDS.convert(diffMiliSeconds, TimeUnit.MILLISECONDS);
//			if (diff <= Integer.parseInt(otpDuration)) {
//				return true;
//			}
//		} else {
//			log.info("Invalid Otp Duration Type so default taking 1 min as duration !");
//			diff = TimeUnit.MINUTES.convert(diffMiliSeconds, TimeUnit.MILLISECONDS);
//			if (diff <= 1) {
//				return true;
//			}
//		}
//
//		log.info("Default Return False !");
//		return false;
//	}

	/* NOT IN USE */
//	@Override
//	public boolean sendOTPOnMobileAndEmail(OTPRequest request) {
//		// INACTIVE previous OTP if user has send OTP request twice or more than
//		// twice.
//		log.info("Inside sendOTPOnMobileAndEmail -----");
//
//		oTPLoggingRepository.inActivePreviousMobileOTP(request.getRequestType(), request.getMasterId(),
//				request.getMobileNo());
//
//		// saving new OTP
//		OtpLoggingDetail loggingDetails = new OtpLoggingDetail();
//		String otp = getOTP(request);
//		log.info("OTP Generated==>");
//		loggingDetails.setOtp(otp);
//		loggingDetails.setMasterId(request.getMasterId());
//		loggingDetails.setMobileNo(request.getMobileNo());
//		loggingDetails.setEmail(request.getEmailId());
//		loggingDetails.setType(new OtpTypeMaster(request.getRequestType()));
//		loggingDetails.setCreatedDate(new Date());
//		loggingDetails.setCreatedBy(request.getMasterId());
//		loggingDetails.setIsActive(true);
//		loggingDetails.setIsExpired(false);
//		loggingDetails.setIsVerified(false);
//		loggingDetails.setOtpOn(OTPConstants.OTPOn.MOBILE);
//		oTPLoggingRepository.save(loggingDetails);
//
//
//		Map<String, Object> parameters = new HashMap<>();
//		parameters.put("emailAddress", loggingDetails.getEmail());
//		parameters.put("otp", otp);
//		parameters.put("fp_name", request.getName());
//
//		/* SENDING EMAIL AND SMS FOR VERIFICATION */
//		String[] toSms = { "91" + loggingDetails.getMobileNo() };
//		String[] toEmail = { request.getEmailId() };
//		Notification emailReq = NotificationClient.prepareRequestForSmsOrEmail(toEmail, parameters, 111L,null, NotificationType.EMAIL);
//		Notification smsReq = NotificationClient.prepareRequestForSmsOrEmail(toSms, parameters, request.getNotificationMasterId(),null, NotificationType.SMS);
//		NotificationRequest notificationRequest = new NotificationRequest();
//		notificationRequest.addNotification(emailReq);
//		notificationRequest.addNotification(smsReq);
//		boolean isSent = notificationClient.send(notificationRequest);
//		log.info("OTP sent status [{}] for UserId==>{}",isSent, request.getMasterId());
//		return true;
//
//	}
	
	@Override
	public boolean sendEmailForOTPVerification(OTPRequest request) {
		try {
			oTPLoggingRepository.inActivePreviousEmailOTP(request.getRequestType(), request.getMasterId(), request.getEmailId());

			// saving new OTP
			OtpLoggingDetail loggingDetails = new OtpLoggingDetail();
			String otp = getOTP(request);
			log.info("OTP Generated==>");
			loggingDetails.setOtp(otp);
			loggingDetails.setMasterId(request.getMasterId());
			loggingDetails.setMobileNo(request.getMobileNo());
			loggingDetails.setEmail(request.getEmailId());
			loggingDetails.setType(new OtpTypeMaster(request.getRequestType()));
			loggingDetails.setCreatedDate(new Date());
			loggingDetails.setCreatedBy(request.getMasterId());
			loggingDetails.setIsActive(Boolean.TRUE);
			loggingDetails.setIsExpired(Boolean.FALSE);
			loggingDetails.setIsVerified(Boolean.FALSE);
			loggingDetails.setOtpOn(OTPConstants.OTPOn.EMAIL);
			oTPLoggingRepository.save(loggingDetails);
			
			Map<String, Object> parameters = new HashMap<String, Object>();
			if(request.getNotificationMasterId().equals(JnsNotificationMasterUtil.EMAIL_CUST_BO_LOGIN_SUCESS)) {
				parameters.put("dynamic","false");
			}
			parameters.put("emailAddress", request.getEmailId());
			parameters.put("otp", otp);
			parameters.put("schemeName",request.getScheme());
			parameters.put("bankerName", OPLUtils.isObjectNullOrEmpty(request.getName())? null : request.getName());
			parameters.put("customerName", OPLUtils.isObjectNullOrEmpty(request.getName())? null : request.getName());
			parameters.put("source", request.getSource());

			/* SEND OTP TO EMAIL */
			String[] toEmail = { request.getEmailId() };
			Notification req = NotificationClient.prepareRequestForSmsOrEmail(toEmail, parameters, request.getNotificationMasterId(),null, NotificationType.EMAIL);
			NotificationRequest notificationRequest = new NotificationRequest();
			notificationRequest.addNotification(req);
			notificationClient.send(notificationRequest);
			return true;
		} catch (Exception e) {
			log.error("Exception while send Email Notification for OTP verification ", e);
		}
		return false;
	}
	
	// send email and mobile otp for consent.

	@Override
	public OTPResponse sendConsentOTPOnMobileEmail(OTPRequest request) {
		log.info("Inside sendOTPOnMobileAndEmail -----");
		/* INACTIVE PREVIOUS OTP IF USER HAS SEND OTP REQUEST TWICE OR MORE THAN TWICE */
		oTPLoggingRepository.inActivePreviousMobileOTP(request.getRequestType(), request.getMasterId(), request.getMobileNo());
		oTPLoggingRepository.inActivePreviousEmailOTP(request.getRequestType(), request.getMasterId(), request.getEmailId());

		/* GENERATING NEW OTP */
		OtpLoggingDetail loggingDetails = new OtpLoggingDetail();
		String otp = getOTP(request);
		loggingDetails.setOtp(otp);
		loggingDetails.setMasterId(request.getMasterId());
		loggingDetails.setMobileNo(request.getMobileNo());
		loggingDetails.setEmail(request.getEmailId());
		loggingDetails.setType(new OtpTypeMaster(request.getRequestType()));
		loggingDetails.setCreatedDate(new Date());
		loggingDetails.setCreatedBy(request.getMasterId());
		loggingDetails.setIsActive(true);
		loggingDetails.setIsExpired(false);
		loggingDetails.setIsVerified(false);

		if (!OPLUtils.isObjectNullOrEmpty(request.getMobileNo())) {
			loggingDetails.setOtpOn(OTPConstants.OTPOn.MOBILE);
		} else if (!OPLUtils.isObjectNullOrEmpty(request.getEmailId())) {
			loggingDetails.setOtpOn(OTPConstants.OTPOn.EMAIL);
		}
		loggingDetails = oTPLoggingRepository.save(loggingDetails);

		NotificationRequest notificationRequest = new NotificationRequest();
		Map<String, Boolean> map = new HashMap<>();

		//Sms parameters
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("otp", otp);
		parameters.put("schemeName", request.getScheme());
		parameters.put("bankerName", OPLUtils.isObjectNullOrEmpty(request.getName()) ? "Dear Sir/Madam" : request.getName());
		parameters.put("customerName", OPLUtils.isObjectNullOrEmpty(request.getName()) ? "Dear Sir/Madam" : request.getName());
		parameters.put("source", 4);
		
		/* SENDING OTP on EMAIL */
		if (!OPLUtils.isObjectNullOrEmpty(request.getEmailId()) && !OPLUtils.isObjectNullOrEmpty(request.getEmailNotiMasterId())) {
			String[] toEmail = {request.getEmailId()};
			Notification emailReq = NotificationClient.prepareRequestForSmsOrEmail(toEmail, parameters, request.getEmailNotiMasterId(), null, NotificationType.EMAIL);
			notificationRequest.addNotification(emailReq);
			map.put("isSentEmail", true);
		}
		
		/* SENDING OTP on SMS*/
		if(!OPLUtils.isObjectNullOrEmpty(loggingDetails.getMobileNo()) && !OPLUtils.isObjectNullOrEmpty(request.getSmsNotiMasterId())) {
			String[] to;
			if(loggingDetails.getMobileNo().length()==12 && loggingDetails.getMobileNo().substring(0,2).equals("91")) {				
				to = new String[] {loggingDetails.getMobileNo()};
			}else {
				to = new String[] {"91" + loggingDetails.getMobileNo()};
			}
			Notification smsReq = NotificationClient.prepareRequestForSmsOrEmail(to, parameters, request.getSmsNotiMasterId(), null, NotificationType.SMS);
			notificationRequest.addNotification(smsReq);
			map.put("isSentMobile", true);
		}

		try {
			notificationClient.send(notificationRequest);
			log.info("OTP For UserId==>{}", request.getMasterId());
			return new OTPResponse("OTP Send Successfully", HttpStatus.OK.value(), map);
		}catch (Exception e) {
			return new OTPResponse("OTP Not Send Successfully", HttpStatus.BAD_REQUEST.value(),null);
		}

	}
	

}
