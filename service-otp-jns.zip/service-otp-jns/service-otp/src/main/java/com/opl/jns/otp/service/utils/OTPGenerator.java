package com.opl.jns.otp.service.utils;

import java.security.SecureRandom;

public class OTPGenerator {

	private static final String CHAR_LIST_DEFAULT = "123456789";

//    private static Random random;
    
    private static SecureRandom random;

    private OTPGenerator(){
        // Nothing to do for X and Y
    }

    static {
//        random = new Random();        
       random = new SecureRandom();
    }

	private static int generate(String charList) {
		if (charList == null || charList.isEmpty() || "".equals(charList)) {
            charList = CHAR_LIST_DEFAULT;
		}
		
		int randomInt = 0;
		SecureRandom randomGenerator = OTPGenerator.random;
		randomInt = randomGenerator.nextInt(charList.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}
	
	/**
	 * generate OTP based on passed string by user and digit length.
	 * @param digitLength OTP length
	 * @param charList from String it will generate OTP
	 * @return
	 */
    public static String generateOTP(int digitLength,String charList)
    {
       StringBuilder randStr = new StringBuilder();
        for(int i=0; i < digitLength; i++){
            int number = generate(charList);
            char ch = charList.charAt(number);
            randStr.append(ch);
        }
        return randStr.toString();
    }
    
    /**
     * generate OTP based on passed string by user and digit length.
     * @param digitLength OTP length with default Character List
     * @return
     */
    public static String generateOTP(int digitLength)
    {
    	StringBuilder randStr = new StringBuilder();
        for(int i=0; i < digitLength; i++){
            int number = generate(CHAR_LIST_DEFAULT);
            char ch = CHAR_LIST_DEFAULT.charAt(number);
            randStr.append(ch);
        }
        return randStr.toString();
    }

}
