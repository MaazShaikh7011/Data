package com.opl.jns.otp.api.model;

public class OTPResponse {

	private Integer id;
	private String message;
	private Integer status;
	private Object data;
	private String otp;
	private Boolean flag;

	
	public OTPResponse(){
		super();
	}
	
	public OTPResponse(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}
	
	public OTPResponse(String message, Integer status,Object data) {
		super();
		this.message = message;
		this.status = status;
		this.data = data;
	}
	
	public OTPResponse(String message, Integer status, String otp, Boolean flag) {
		super();
		this.message = message;
		this.status = status;
		this.otp = otp;
		this.flag = flag;
	}
	
	public OTPResponse(String message, Integer status,Object data,Boolean flag) {
		super();
		this.message = message;
		this.status = status;
		this.data = data;
		this.flag = flag;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "OTPResponse [id=" + id + ", message=" + message + ", status=" + status + ", data=" + data + ", otp="
				+ otp + ", flag=" + flag + "]";
	}

	

	
}
