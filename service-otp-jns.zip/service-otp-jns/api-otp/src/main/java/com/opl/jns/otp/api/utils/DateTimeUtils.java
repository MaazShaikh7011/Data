package com.opl.jns.otp.api.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeUtils {

	public static final String DEFAULT_FORMATE = "MM/dd/yyyy HH:mm:ss";

	public final class DateTime {
		private DateTime(){
			//Nothing to do for X and Y
		}
		public static final int DAY = 1;
		public static final int HOUR = 2;
		public static final int MINUTES = 3;
		public static final int SECONDS = 4;
		public static final int MILISECONDS = 5;
	}

	public static long getDateDifference(Date toDate, Date fromDate, int returnType) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(DEFAULT_FORMATE);

		fromDate = format.parse(format.format(fromDate));
		toDate = format.parse(format.format(toDate));
		long diff = toDate.getTime() - fromDate.getTime();
		long result = 0l;

		switch (returnType) {
		case DateTime.DAY:
			result = diff / (24 * 60 * 60 * 1000);
			break;
		case DateTime.HOUR:
			result = diff / (60 * 60 * 1000) % 24;
			break;
		case DateTime.MINUTES:
			result = diff / (60 * 1000) % 60;
			break;
		case DateTime.SECONDS:
			result = diff / 1000 % 60;
			break;
		case DateTime.MILISECONDS:
			result = diff;
			break;
		default:
			break;
		}
		return result;
	}
}
