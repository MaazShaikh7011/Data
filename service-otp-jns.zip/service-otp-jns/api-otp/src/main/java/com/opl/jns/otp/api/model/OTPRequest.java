package com.opl.jns.otp.api.model;

import java.io.Serializable;
import java.util.List;

public class OTPRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8555331390059013196L;
	private String mobileNo;
	private String requestId;
	private Integer requestType;
	private Long masterId;
	private String emailId;
	private String otp;
	private Long notificationAlias;
	private Long notificationMasterId;
	private Integer otpOn;
	private Integer source;
	private String name;
	private String scheme;
	private Long emailNotiMasterId;
	private Long smsNotiMasterId;
	private Long orgId;
	

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Long getEmailNotiMasterId() {
		return emailNotiMasterId;
	}

	public void setEmailNotiMasterId(Long emailNotiMasterId) {
		this.emailNotiMasterId = emailNotiMasterId;
	}

	public Long getSmsNotiMasterId() {
		return smsNotiMasterId;
	}

	public void setSmsNotiMasterId(Long smsNotiMasterId) {
		this.smsNotiMasterId = smsNotiMasterId;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public Long getNotificationAlias() {
		return notificationAlias;
	}

	public void setNotificationAlias(Long notificationAlias) {
		this.notificationAlias = notificationAlias;
	}


	public Long getNotificationMasterId() {
		return notificationMasterId;
	}

	public void setNotificationMasterId(Long notificationMasterId) {
		this.notificationMasterId = notificationMasterId;
	}

	public OTPRequest() {
		// TODO Auto-generated constructor stub
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Integer getRequestType() {
		return requestType;
	}

	public void setRequestType(Integer requestType) {
		this.requestType = requestType;
	}

	public Long getMasterId() {
		return masterId;
	}

	public void setMasterId(Long masterId) {
		this.masterId = masterId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Integer getOtpOn() {
		return otpOn;
	}

	public void setOtpOn(Integer otpOn) {
		this.otpOn = otpOn;
	}
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSource() {
		return source;
	}

	public void setSource(Integer source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "OTPRequest [mobileNo=" + mobileNo + ", requestId=" + requestId + ", requestType=" + requestType
				+ ", masterId=" + masterId + ", emailId=" + emailId + ", otp=" + otp + ", notificationAlias="
				+ notificationAlias + ", notificationMasterId=" + notificationMasterId + ", otpOn=" + otpOn + ", name="
				+ name + "]";
	}


}
