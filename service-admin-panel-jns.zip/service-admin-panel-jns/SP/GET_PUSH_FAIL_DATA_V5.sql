CREATE OR REPLACE PROCEDURE JNS_ADMIN_PANEL.GET_PUSH_FAIL_DATA_V5(
filterjson  IN   "VARCHAR",
userid  IN   NUMBER,
result      OUT  CLOB)
AS
    selectquery 			CLOB;
    whereclause 			CLOB;
    schemeId				NUMBER;
    schemewhereclause		CLOB;
    pmsbyschemeclause		CLOB;
    pmjjbyschemeclause		CLOB;
    dateclause				CLOB;
   	completiondateclause	CLOB;
    createddateclause 		CLOB;
	claimdateclause 		CLOB;
	modifieddateclause		CLOB;
   	groupbyquery  			CLOB;
    mainquery   			CLOB;
   	coverquery   			CLOB;
    userType				CLOB;
BEGIN

	whereclause := ' WHERE am.is_active = 1 ';

	-- ep -> Enrollment Push
	-- op -> Optout Push
	-- nup -> Nominee Update Push
	-- cp -> Claim Push
	-- cst -> Claim status to Bank/Insurer

	IF JSON_VALUE(filterjson, '$.userType') IS NOT NULL THEN
		SELECT DECODE(JSON_VALUE(filterjson, '$.userType'), 2, 'BANK', 'INSURER') INTO userType FROM DUAL;

			IF JSON_VALUE (filterjson, '$.orgId') IS NOT NULL THEN
				IF JSON_VALUE(filterjson, '$.userType') = 2 THEN
					whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.orgId'));
				ELSIF JSON_VALUE(filterjson, '$.userType') = 6 THEN
					whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || JSON_VALUE (filterjson, '$.orgId'));
				END IF;
		    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
    END IF;

    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
    	schemeId := JSON_VALUE (filterjson, '$.schemeId');
		schemewhereclause := ' AND am.scheme_id = ' || schemeId;
		pmsbyschemeclause := ' AND 1 = ' || schemeId;
		pmjjbyschemeclause := ' AND 2 = ' || schemeId;
	ELSE
		pmsbyschemeclause := '';
		pmjjbyschemeclause := '';
	END IF;

   	IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
		dateclause := ' BETWEEN TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''DD-MON-YYYY hh:mi:ss AM'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''DD-MON-YYYY hh:mi:ss AM'')';
		completiondateclause := CONCAT(' AND am.COMPLETION_DATE ', dateclause);
		createddateclause := CONCAT(' AND ma.CREATED_DATE ', dateclause);
		claimdateclause := CONCAT(' AND am.CLAIM_DATE ', dateclause);
		modifieddateclause := CONCAT(' AND am.MODIFIED_DATE ', dateclause);
    ELSE
		completiondateclause := ' ';
		createddateclause := ' ';
		claimdateclause := ' ';
		modifieddateclause := ' ';
    END IF;

--   whereclause := CONCAT(whereclause, ' AND amod.source = 1 ');

		groupbyquery := ' GROUP BY DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) ';

		mainquery := ' SELECT tmp.orgId, SUM(tmp.eps) AS eps, SUM(tmp.epf) AS epf, SUM(tmp.ops) AS ops, SUM(tmp.opf) AS opf, SUM(tmp.nups) AS nups, SUM(tmp.nupf) AS nupf, SUM(tmp.cps) AS cps, SUM(tmp.cpf) AS cpf, SUM(tmp.csts) AS csts, SUM(tmp.cstf) AS cstf  FROM (
					SELECT DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) as orgId,
					SUM(CASE WHEN aps.'|| userType ||'_PUSH = 1 THEN 1 ELSE 0 END) as eps,
					SUM(CASE WHEN (aps.'|| userType ||'_PUSH = 0) THEN 1 ELSE 0 END) as epf,
					0 as ops, 0 as opf, 0 as nups, 0 as nupf, 0 as cps, 0 as cpf, 0 as csts, 0 as cstf
					FROM (
						SELECT am.id, am.ORG_ID, am.INSURER_ORG_ID, am.COMPLETION_DATE FROM JNS_MASTER.PMSBY  am '|| whereclause || pmsbyschemeclause || completiondateclause ||'
							UNION ALL
						SELECT am.id, am.ORG_ID, am.INSURER_ORG_ID, am.COMPLETION_DATE FROM JNS_MASTER.PMJJBY am '|| whereclause || pmjjbyschemeclause || completiondateclause ||'
					) am
					INNER JOIN JNS_INSURANCE.APPLICATION_PUSH_STATUS aps ON APS.ID = am.ID
					'|| groupbyquery ||'

					UNION ALL

					SELECT DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) as orgId,
					0 as eps,0 as epf,
					SUM(CASE WHEN (aps.'|| userType ||'_OPT_OUT_PUSH = 1 AND ma.type = 1) THEN 1 ELSE 0 END) as ops,
					SUM(CASE WHEN (aps.'|| userType ||'_OPT_OUT_PUSH = 0 AND ma.type = 1) THEN 1 ELSE 0 END) as opf,
					SUM(CASE WHEN (aps.'|| userType ||'_NMN_DTLS_PUSH = 1 AND ma.type = 2) THEN 1 ELSE 0 END) as nups,
					SUM(CASE WHEN (aps.'|| userType ||'_NMN_DTLS_PUSH = 0 AND ma.type = 2) THEN 1 ELSE 0 END) as nupf,
					0 AS cps, 0 AS cpf, 0 AS csts,0 AS cstf
					FROM JNS_INSURANCE.MISCELLANEOUS_AUDIT ma
					INNER JOIN  (
						SELECT am.id, am.ORG_ID, am.INSURER_ORG_ID, am.COMPLETION_DATE FROM JNS_MASTER.PMSBY am '|| whereclause || pmsbyschemeclause ||'
							UNION ALL
						SELECT am.id, am.ORG_ID, am.INSURER_ORG_ID, am.COMPLETION_DATE FROM JNS_MASTER.PMJJBY am '|| whereclause || pmjjbyschemeclause ||'
					) am ON am.id = ma.APPLICATION_ID
					INNER JOIN JNS_INSURANCE.APPLICATION_PUSH_STATUS aps ON APS.ID = am.ID
					WHERE 1=1 '|| createddateclause ||'
					'|| groupbyquery ||'

					UNION ALL

					SELECT DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) as orgId,
					0 as eps, 0 as epf, 0 as ops, 0 as opf, 0 AS nups, 0 AS nupf,
					SUM(CASE WHEN (am.IS_'|| userType ||'_CLAIM_PUSH = 1 '|| claimdateclause ||') THEN 1 ELSE 0 END) as cps,
					SUM(CASE WHEN (am.IS_'|| userType ||'_CLAIM_PUSH = 0 '|| claimdateclause ||') THEN 1 ELSE 0 END) as cpf,
					SUM(CASE WHEN (am.IS_'|| userType ||'_CLAIM_STATUS_PUSH = 1 '|| modifieddateclause ||') THEN 1 ELSE 0 END) as csts,
					SUM(CASE WHEN (am.IS_'|| userType ||'_CLAIM_STATUS_PUSH = 0 '|| modifieddateclause ||') THEN 1 ELSE 0 END) as cstf
					FROM JNS_INSURANCE.CLM_MASTER am '|| whereclause || schemewhereclause ||'
					'|| groupbyquery ||'

				) tmp GROUP BY tmp.orgId ORDER BY tmp.orgId ASC ';




--	dbms_output.put_line(mainquery);

	coverquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(
						''orgId'' value t.orgId,
						''bankName'' value uom.DISPLAY_ORG_NAME,
						''eps'' value t.eps,
						''epf'' value t.epf,
						''ops'' value t.ops,
						''opf'' value t.opf,
						''nups'' value t.nups,
						''nupf'' value t.nupf,
						''cps'' value t.cps,
						''cpf'' value t.cpf,
						''csts'' value t.csts,
						''cstf'' value t.cstf
					) RETURNING CLOB) FROM ('|| mainquery ||') t
					INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = t.orgId ';

--	dbms_output.put_line(coverquery);
--CALL JNS_ADMIN_PANEL.GET_PUSH_FAIL_DATA_V5('{"userType":2,"isInside":false,"fromDate":"01-Jun-2024 12:06:00 AM","toDate":"27-Jun-2024 11:06:59 PM","paginationFROM":0,"paginationTO":5}', 0, ?);

    EXECUTE IMMEDIATE coverquery INTO result;

END GET_PUSH_FAIL_DATA_V5;