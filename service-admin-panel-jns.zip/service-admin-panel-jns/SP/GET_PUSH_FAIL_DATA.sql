CREATE OR REPLACE PROCEDURE JNS_ADMIN_PANEL.GET_PUSH_FAIL_DATA(
filterjson  IN   "VARCHAR",
userid  IN   NUMBER,
result      OUT  CLOB)
AS
    selectquery 	CLOB;
    whereclause 	CLOB;
    tablequery		CLOB;
   	groupbyquery  	CLOB;
    orderbyquery  	CLOB;
    limitquery		CLOB;
    mainquery   	CLOB;
   	coverquery   	CLOB;
    userType		CLOB;
    userTypeId		NUMBER;
    totalCount		NUMBER;
    totalCountquery	CLOB;
BEGIN

	whereclause := ' WHERE  am.is_active = 1 ';

	-- ep -> Enrollment Push
	-- op -> Optout Push
	-- nup -> Nominee Update Push
	-- cp -> Claim Push
	-- cst -> Claim status to Bank/Insurer

	IF JSON_VALUE(filterjson, '$.userType') IS NOT NULL THEN
		SELECT DECODE(JSON_VALUE(filterjson, '$.userType'), 2, 'BANK', 'INSURER') INTO userType FROM DUAL;

			IF JSON_VALUE (filterjson, '$.orgId') IS NOT NULL THEN
				IF JSON_VALUE(filterjson, '$.userType') = 2 THEN
					whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.orgId'));
				ELSIF JSON_VALUE(filterjson, '$.userType') = 6 THEN
					whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || JSON_VALUE (filterjson, '$.orgId'));
				END IF;
		    END IF;
	ELSE
		whereclause := CONCAT(whereclause, ' AND 1 = 2 ');
    END IF;

    IF JSON_VALUE(filterjson, '$.schemeId') IS NOT NULL THEN
		whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
	END IF;

   	IF JSON_VALUE(filterjson, '$.fromDate') IS NOT NULL AND JSON_VALUE(filterjson, '$.toDate') IS NOT NULL THEN
         whereclause := CONCAT(whereclause, ' AND am.COMPLETION_DATE between TO_DATE('''|| JSON_VALUE(filterjson, '$.fromDate') ||''', ''DD-MON-YYYY hh:mi:ss AM'') and TO_DATE('''|| JSON_VALUE(filterjson, '$.toDate') ||''', ''DD-MON-YYYY hh:mi:ss AM'')');
    END IF;

--   whereclause := CONCAT(whereclause, ' AND amod.source = 1 ');

	selectquery	:= ' SELECT
						DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) as orgId,
						SUM(CASE WHEN aps.'|| userType ||'_PUSH = 1 THEN 1 ELSE 0 END) as eps,
						SUM(CASE WHEN aps.'|| userType ||'_OPT_OUT_PUSH = 1 THEN 1 ELSE 0 END) as ops,
						SUM(CASE WHEN aps.'|| userType ||'_NMN_DTLS_PUSH = 1 THEN 1 ELSE 0 END) as nups,
						SUM(CASE WHEN cm.IS_'|| userType ||'_CLAIM_PUSH = 1 THEN 1 ELSE 0 END) as cps,
						SUM(CASE WHEN cm.IS_'|| userType ||'_CLAIM_STATUS_PUSH = 1 THEN 1 ELSE 0 END) as csts,
						SUM(CASE WHEN (aps.'|| userType ||'_PUSH = 0 OR aps.'|| userType ||'_PUSH IS NULL) THEN 1 ELSE 0 END) as epf,
						SUM(CASE WHEN (aps.'|| userType ||'_OPT_OUT_PUSH = 0 OR aps.'|| userType ||'_OPT_OUT_PUSH IS NULL) THEN 1 ELSE 0 END) as opf,
						SUM(CASE WHEN (aps.'|| userType ||'_NMN_DTLS_PUSH = 0 OR aps.'|| userType ||'_NMN_DTLS_PUSH IS NULL) THEN 1 ELSE 0 END) as nupf,
						SUM(CASE WHEN (cm.IS_'|| userType ||'_CLAIM_PUSH = 0 OR cm.IS_'|| userType ||'_CLAIM_PUSH IS NULL) THEN 1 ELSE 0 END) as cpf,
						SUM(CASE WHEN (cm.IS_'|| userType ||'_CLAIM_STATUS_PUSH = 0 OR cm.IS_'|| userType ||'_CLAIM_STATUS_PUSH IS NULL) THEN 1 ELSE 0 END) as cstf ';

	tablequery := ' FROM JNS_INSURANCE.APPLICATION_MASTER am
					INNER JOIN JNS_INSURANCE.APPLICATION_PUSH_STATUS aps ON APS.ID = am.ID
					LEFT JOIN JNS_INSURANCE.CLM_MASTER cm ON CM.APPLICATION_ID = am.id ';

	groupbyquery := ' GROUP BY DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) ';

	orderbyquery := ' ORDER BY DECODE('|| JSON_VALUE(filterjson, '$.userType') ||', 2, am.ORG_ID, am.INSURER_ORG_ID) ASC ';

	IF JSON_VALUE(filterjson, '$.isInside') IS NOT NULL AND JSON_VALUE(filterjson, '$.isInside') = 'true' THEN
		selectquery := CONCAT(selectquery, ',  TO_TIMESTAMP(CAST(am.completion_date AS DATE)) as cd');
		groupbyquery := CONCAT(groupbyquery, ', TO_TIMESTAMP(CAST(am.completion_date AS DATE)) ');
		orderbyquery := CONCAT(orderbyquery, ', TO_TIMESTAMP(CAST(am.completion_date AS DATE)) ');
	ELSE
		selectquery := CONCAT(selectquery, ',  NULL AS cd');
	END IF;


	mainquery := selectquery || tablequery || whereclause || groupbyquery || orderbyquery;

	IF JSON_VALUE(filterjson, '$.isInside') IS NOT NULL AND JSON_VALUE(filterjson, '$.isInside') = 'true' THEN
		totalCountquery := 'SELECT count(*) FROM ( '|| mainquery ||' ) t ';
		dbms_output.put_line(totalCountquery);
		EXECUTE IMMEDIATE totalCountquery INTO totalCount;
		dbms_output.put_line('totalCount   ' || totalCount);


		IF JSON_VALUE (filterjson, '$.paginationFROM') IS NOT NULL AND JSON_VALUE (filterjson, '$.paginationTO') IS NOT NULL THEN
			limitquery := ' OFFSET ' || JSON_VALUE (filterjson, '$.paginationFROM') || ' ROWS FETCH NEXT ' || JSON_VALUE (filterjson, '$.paginationTO') || ' ROWS ONLY';
			mainquery := mainquery || limitquery;
		END IF;
	ELSE
		totalCount := 0;
	END IF;

	dbms_output.put_line(mainquery);

	coverquery := ' SELECT JSON_ARRAYAGG(JSON_OBJECT(
						''orgId'' value t.orgId,
						''bankName'' value uom.DISPLAY_ORG_NAME,
						''totalCount'' value COALESCE('|| totalCount ||', 0) ,
						''date'' value t.cd,
						''eps'' value t.eps,
						''epf'' value t.epf,
						''ops'' value t.ops,
						''opf'' value t.opf,
						''nups'' value t.nups,
						''nupf'' value t.nupf,
						''cps'' value t.cps,
						''cpf'' value t.cpf,
						''csts'' value t.csts,
						''cstf'' value t.cstf
					) RETURNING CLOB) FROM ('|| mainquery ||') t
					INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = t.orgId ';

	dbms_output.put_line(coverquery);

    EXECUTE IMMEDIATE coverquery INTO result;

END GET_PUSH_FAIL_DATA;