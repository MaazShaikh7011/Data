//package com.opl.jns.common.service.admin.panel;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ServiceAdminPanelJnsTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
