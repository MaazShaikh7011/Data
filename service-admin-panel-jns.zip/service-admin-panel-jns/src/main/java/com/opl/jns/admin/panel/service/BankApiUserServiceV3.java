package com.opl.jns.admin.panel.service;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.opl.jns.admin.panel.model.BankApiRequest;
import com.opl.jns.admin.panel.model.EncryptDecryptProxy;
import com.opl.jns.admin.panel.model.UserOrganizationMasterProxy;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.utils.common.CommonResponse;

public interface BankApiUserServiceV3 {
	public CommonResponse save(BankApiRequest req);

	public BankApiRequest getApiUserList(Long id);

	public List<UserOrganizationMasterProxy> getOrgMasterListByApimasterId();

	public CommonResponse fetchApiUser(String request, AuthClientResponse authClientResponse);

	public CommonResponse activeIsApiUser(Long id);
	
	public String encryptDecryptData(EncryptDecryptProxy encryptDecryptProxy) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, SignatureException, InvalidAlgorithmParameterException, NoSuchProviderException, InvalidKeySpecException, CertificateException, IOException, Exception;
	
	public List<BankApiRequest> getAllApiUserList();

	public BankApiRequest getApiUserListByOrgId(Long orgId);
}
