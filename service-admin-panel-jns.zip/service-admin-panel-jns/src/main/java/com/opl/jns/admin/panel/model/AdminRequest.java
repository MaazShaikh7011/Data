package com.opl.jns.admin.panel.model;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ravi.thummar
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdminRequest {

    private Long applicationId;
    private Long userId;
    private Long claimId;
    
    
    private String filterJSON;
    private String listKey;
    private String whereClause;
    private Object compilinceDetails;
    
    private String roleId;
    
    private Integer paginationFROM;
    private Integer paginationTO;
    private String filterAnd;
    private String filterOr;
    private Integer schemeId;
    private Integer pageType;
    private Integer tabId;
    private String fromDate;
    private String toDate;
    private String searchData;
    private String accountNumber;
    private String applicationCode;
    
	@NotNull
	private Long orgId;

	private Boolean isDownload;

}
