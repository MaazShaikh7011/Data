package com.opl.jns.admin.panel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.admin.panel.model.BankApiRequest;
import com.opl.jns.admin.panel.model.EncryptDecryptProxy;
import com.opl.jns.admin.panel.model.UserOrganizationMasterProxy;
import com.opl.jns.admin.panel.service.BankApiUserServiceV3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/v3/api")
public class BankApiUsersContollerV3 {

	@Autowired
	private BankApiUserServiceV3 bankApiuserService;

	@PostMapping(value = "/saveApiUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveApiUser(@RequestBody BankApiRequest req) {
		try {
//			}
			return new ResponseEntity<>(bankApiuserService.save(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while save Api Users ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getOrgMasterListByApimasterId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrgMasterListByApimasterId() {
		try {

			List<UserOrganizationMasterProxy> orgList = bankApiuserService.getOrgMasterListByApimasterId();
			if (OPLUtils.isObjectNullOrEmpty(orgList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no orgMaster list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Success", orgList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/getApiUserList/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@SkipInterceptor
	public ResponseEntity<CommonResponse> getApiUserList(@PathVariable Long id) {
		try {
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Api User Details!!",
					bankApiuserService.getApiUserList(id), HttpStatus.OK.value(), true), HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while  get Api User Details ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/fetchApiUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spUserOrganizationList(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(bankApiuserService.fetchApiUser(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchApiUser ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	@GetMapping(value = "/activeIsApiUser/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> activeIsApiUser(@PathVariable Long id) {
			try {
				  if(OPLUtils.isObjectListNull()) {
		                return new ResponseEntity<>( new CommonResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
		            }
				  return new ResponseEntity<>(bankApiuserService.activeIsApiUser(id), HttpStatus.OK); 

			} catch (Exception e) {
				log.error("Error while isActive Api user!!");
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()),
						HttpStatus.OK);
			}
		} 
	
	
		/**
		 * bank and insurer Encrypt and Decrypt data
		 * 
		 * @param EncryptDecryptProxy
		 * @return
		 */
		@PostMapping(value = "/encryptDecryptData", produces = MediaType.APPLICATION_JSON_VALUE)
		@SkipInterceptor
		public ResponseEntity<CommonResponse> encryptDecryptData(@RequestBody EncryptDecryptProxy encryptDecryptProxy) {
			try {
				return new ResponseEntity<>(new CommonResponse("Successfully get Details!!",
						bankApiuserService.encryptDecryptData(encryptDecryptProxy), HttpStatus.OK.value(), true),
						HttpStatus.OK);

			} catch (Exception e) {
				log.error("Exception while  encrypt and decrypt data ==>", e);
				return new ResponseEntity<>(
						new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		}

		/**
		 * get all api user list
		 * 
		 * @param
		 * @return
		 */
		@GetMapping(value = "/getAllApiUserList", produces = MediaType.APPLICATION_JSON_VALUE)
		@SkipInterceptor
		public ResponseEntity<CommonResponse> getAllApiUserList() {
			try {
				return new ResponseEntity<>(new CommonResponse("Successfully get Api User Details!!",
						bankApiuserService.getAllApiUserList(), HttpStatus.OK.value(), true), HttpStatus.OK);

			} catch (Exception e) {
				log.error("Exception while  get Api User Details ==>", e);
				return new ResponseEntity<>(
						new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		}
		
		@GetMapping(value = "/getApiUserListByOrgId/{orgId}", produces = MediaType.APPLICATION_JSON_VALUE)
		@SkipInterceptor
		public ResponseEntity<CommonResponse> getApiUserListByOrgId(@PathVariable Long orgId) {
			try {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Api User Details!!",
						bankApiuserService.getApiUserListByOrgId(orgId), HttpStatus.OK.value(), true), HttpStatus.OK);

			} catch (Exception e) {
				log.error("Exception while  get Api User Details ==>", e);
				return new ResponseEntity<CommonResponse>(
						new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
			}
		}
}
