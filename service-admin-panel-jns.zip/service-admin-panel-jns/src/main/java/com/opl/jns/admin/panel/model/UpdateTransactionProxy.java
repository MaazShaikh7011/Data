package com.opl.jns.admin.panel.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTransactionProxy implements Serializable{
	
	private final static long serialVersionUID = -4357839815853867628L;
	
	public String urn;
	public String transactionTimeStamp;
	public String transactionUTR;
	public Double transactionAmount;
	public String insurerCode;
	public String transactionType;
}
