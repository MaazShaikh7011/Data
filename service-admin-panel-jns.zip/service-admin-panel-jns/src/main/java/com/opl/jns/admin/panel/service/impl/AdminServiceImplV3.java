package com.opl.jns.admin.panel.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.admin.panel.domain.CountDomain;
import com.opl.jns.admin.panel.domain.SupportAudit;
import com.opl.jns.admin.panel.model.APIStorageAuditProxy;
import com.opl.jns.admin.panel.model.AddressMasterProxy;
import com.opl.jns.admin.panel.model.ApplicationMasterProxy;
import com.opl.jns.admin.panel.model.CountProxy;
import com.opl.jns.admin.panel.model.EnrollmentRequest;
import com.opl.jns.admin.panel.model.NomineeDetailsProxy;
import com.opl.jns.admin.panel.model.PostmanCallProxy;
import com.opl.jns.admin.panel.model.SupportAuditProxy;
import com.opl.jns.admin.panel.model.SwaggerReqResponse;
import com.opl.jns.admin.panel.model.UpdateTraTimeStampProxy;
import com.opl.jns.admin.panel.model.UpdateTransactionProxy;
import com.opl.jns.admin.panel.model.UpdateTransactionStatus;
import com.opl.jns.admin.panel.repository.AdminRepositoryV3;
import com.opl.jns.admin.panel.repository.CountRepo;
import com.opl.jns.admin.panel.repository.SupportAuditRepo;
import com.opl.jns.admin.panel.service.AdminServicev3;
import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequestV3;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationRequestV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponseV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequestV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponseV3;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReqV3;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequestV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponseV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequestV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.insurer.GetCoiDetails.GetCoiRequest;
import com.opl.jns.api.proxy.insurer.NomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.insurer.OptOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.insurer.PushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.insurer.PushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.insurer.PushEnrollment.PushEnrollmentDetailsResponse;
import com.opl.jns.api.proxy.insurer.UpdateDocQuery.ClaimStatusWebhook;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.dedupe.ClaimDeDupResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.domain.ConfigMasterV3;
import com.opl.jns.config.repository.ConfigMasterRepositoryV3;
import com.opl.jns.config.utils.ConfigMasterProxy;
import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.SupportAuditAction;
import com.opl.jns.ere.enums.SupportDashboardSearch;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.repo.NomineeDetailsRepositoryV3;
import com.opl.jns.ere.repo.TransactionDetailsRepositoryV3;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ApplicationQueryProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.published.utils.common.RegistryResponse;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserTypeMaster;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AdminServiceImplV3 implements AdminServicev3 {

    @Autowired
    AdminRepositoryV3 adminRepository;

    @Autowired
    private ApplicationMasterRepositoryV3 applicationMasterRepo;

    @Autowired
    private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

    @Autowired
    ConfigMasterRepositoryV3 configMasterRepo;

    @Autowired
    CountRepo countRepo;

    @Autowired
    private TransactionDetailsRepositoryV3 transactionDetailsRepositoryV3;

    @Autowired
    private SupportAuditRepo supportAuditRepo;

    @Autowired
    private EreCommonService ereCommonService;

    @Autowired
    private NomineeDetailsRepositoryV3 nomineeDetailsRepository;

    @Autowired
    private UsersClient usersClient;

    @Autowired
    private ApplicantPIDetailsRepository applicantPIDetailsRepository;

    @Autowired
    private ApplicantInfoRepoV2 applicantInfoRepositoryV2;

    @Autowired
    private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

    @Autowired
    private AddressMasterRepositoryV2 addressMasterRepositoryV2;

    @Autowired
    private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;

    @Autowired
    private NomineePIDetailsRepository nomineePIDetailsRepository;

    @Autowired
    private BankApiClient bankApiClient;

    @Autowired
    private WebHookClient webHookClient;
    
    public static final Integer[] inProcessOrCompletedApplication = new Integer[]{ApplicationStatus.ENROLL_IN_PROGRESS.getId()};
    //public static final Integer[] inProcessOrCompletedApplication = new Integer[]{ApplicationStatus.ENROLL_IN_PROGRESS.getId(), ApplicationStatus.ENROLL_COMPLETED.getId(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()}; - --removed rejected renewal in master and insurance .app in not reject issues
    private static final String USERTYPEID_LITERAL = "userTypeId";
    private static final String TYPEID_LITERAL = "typeId";
    private static final String NOTIFICATION_TYPE = "notificationType";
    private static final String TOTALCOUNT_LITERAL = "totalCount";
    private static final String SUCCESSFULLY_GET_DATA_LITERAL = "successfully get Data";
    private static final String SUCCESSFULLY_SAVED_DATA = "successfully saved Data";
    private static final String SEARCHVALUE_LITERAL = "searchValue";
    private static final String SEARCHDATA_LITERAL = "searchData";
    private static final String SCHEMEID_LITERAL = "schemeId";
    private static final String PAGINATIONTO_LITERAL = "paginationTO";
    private static final String PAGINATIONFROM_LITERAL = "paginationFROM";
    private static final String ORGID_LITERAL = "orgId";
    private static final String FROM_DATE_LITERAL = "fromDate";
    private static final String TO_DATE_LITERAL = "toDate";
    private static final String FILTERJSON_LITERAL = "filterJSON";
    private static final String TOTAL_COUNT_LITERAL = "TotalCount";
    public static final String AUDIT_API = " '/api/jns/publish/fetchPublishApiAuditDetailList'";
    public static final String APP_API = " '/api/jns/publish/fetchPublishedAppList'";
    public static final String CLIAM_API = " '/api/jns/publish/fetchPublishedClaimList'";
    public static final String GET_APP_API = " '/api/jns/get/v3/fetchPublishedAppList'";
    public static final String GET_CLIAM_API = " '/api/jns/get/v3/fetchPublishedClaimList'";

    @Override
    public String fetchMasterData(String listKey, String whereClause, Long userId) {

        log.info("CALL fetchMasterData('{}')", userId);
        String spName = "jns_reports.GET_ADMIN_COMMON_LIST_V5";

        if (listKey.equals("admin_menu_permission")) {
            String Query = null;

            Query = "SELECT JSON_OBJECT('id' value role_id, 'label' value display_name) \r\n"
                    + "FROM jns_users.user_role_master  urm WHERE urm.is_active = 1 AND urm.role_id IN (\r\n"
                    + "SELECT \r\n"
                    + "distinct(u2.role_id) \r\n"
                    + "FROM jns_users.user_role_master u\r\n"
                    + "left join jns_users.user_role_master u1 on u.role_id =u1.parent_role_id "
                    + " left join jns_users.user_role_master u2 on u1.role_id =u2.parent_role_id OR u1.role_id = u2.role_id \r\n"
                    + "where u.role_id='" + whereClause + "' \r\n"
                    + ")";

            if (whereClause.equals("101")) {

                Query = "SELECT JSON_OBJECT('id' value role_id, 'label' value display_name) \r\n"
                        + "FROM jns_users.user_role_master  urm WHERE urm.is_active = 1 AND urm.role_id IN (\r\n"
                        + "SELECT \r\n"
                        + "distinct(u2.role_id) \r\n"
                        + "FROM jns_users.user_role_master u\r\n"
                        + "left join jns_users.user_role_master u1 on u.role_id =u1.parent_role_id OR u.role_id = u1.role_id "
                        + " left join jns_users.user_role_master u2 on u1.role_id =u2.parent_role_id OR u1.role_id = u2.role_id \r\n"
                        + "where u.role_id='" + 101 + "' \r\n"
                        + ")";
            }
            List<Object> list = adminRepository.fetchListOfDataFromDb(Query);
//        	System.out.println(list);
            return OPLUtils.isListNullOrEmpty(list) ? null : list.toString();
        }

        if (listKey.equals("admin_menu_permission_list")) {
            List<Object> list = adminRepository.adminPermissionList(whereClause);
//        	System.out.println(list);
            return list.toString();
        }
        Map<String, Object> reqParam = new LinkedHashMap<>();

        reqParam.put("listKey", listKey);
        reqParam.put("whereClause", whereClause);

        String commonSPcall = adminRepository.commonSPcall(reqParam, userId, spName);
        if (!OPLUtils.isObjectNullOrEmpty(commonSPcall)) {
            return commonSPcall;
        }
        return null;
    }

    @Override
    public CommonResponse fetchBankApiAuditDetailList(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL)
                    ? filterJSON.get(PAGINATIONFROM_LITERAL).asText()
                    : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText()
                    : "10";
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
            String searchAccountNoAndUrn = filterJSON.has("searchAccountNoAndUrn")
                    ? filterJSON.get("searchAccountNoAndUrn").asText()
                    : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long searchTypeId = filterJSON.has("searchTypeId") ? filterJSON.get("searchTypeId").asLong() : null;

            String whereClause = "where 1=1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND al.org_id = " + orgId;
            }
            if ((!OPLUtils.isObjectNullOrEmpty(fromDate)) && (!OPLUtils.isObjectNullOrEmpty(toDate))) {
                whereClause += " AND al.created_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and "
                        + " to_timestamp('" + toDate + "')+1 ";
            }

            if (!OPLUtils.isObjectNullOrEmpty(searchAccountNoAndUrn)) {
                if (searchTypeId == 1) {
                    whereClause += " AND al.application_id =  '" + searchAccountNoAndUrn + "' ";
                } else if (searchTypeId == 2) {
                    whereClause += " AND al.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"( '"
                            + searchAccountNoAndUrn + "') ";
                } else if (searchTypeId == 3) {
                    whereClause += " AND al.urn = '" + searchAccountNoAndUrn + "' ";
                } else if (searchTypeId == 4) {
                    whereClause += " AND al.request_token = '" + searchAccountNoAndUrn + "' ";
                }
            }

            String totalCountSelectQuery = "select (json_object('totalCount' value count(al.id))) ";
            String dbname = DBNameConstant.JNS_BANK_API;

        	String joinTableQuery = "INNER JOIN " + DBNameConstant.JNS_BANK_API
                    + ".PAYLOAD_AUDIT pa ON PA.LOG_AUDIT_ID = AL.ID  ";
            String newTableQuery = " FROM " + dbname + ".audit_log al " + joinTableQuery;
            
            newTableQuery += "INNER JOIN " + DBNameConstant.JNS_BANK_API + ".bank_api_master bam ON bam.id = al.api_id ";

            String orderByQuery = " order by al.created_date desc";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";

            log.info(" TOTAL COUNT QUERY BANKAPIAUDIT DETAIL ======> {}", totalCountSelectQuery + newTableQuery + whereClause);
            String str = adminRepository.fetchCount(totalCountSelectQuery + newTableQuery + whereClause);
            
            boolean isNewTable = true;
            String oldTableQuery = "";
            if (Integer.valueOf(MultipleJSONObjectHelper.getMapFromString(str).get("totalCount").toString()) == 0) {
            	String oldJoinTableQuery = "INNER JOIN " + DBNameConstant.JNS_BANK_API
                        + ".PAYLOAD_AUDIT_OLD_MAY pa ON PA.LOG_AUDIT_ID = AL.ID  ";
            	oldJoinTableQuery += "INNER JOIN " + DBNameConstant.JNS_BANK_API + ".bank_api_master bam ON bam.id = al.api_id ";
                oldTableQuery = " FROM " + dbname + ".audit_log_old_may al " + oldJoinTableQuery;
                System.err.println(totalCountSelectQuery + oldTableQuery + whereClause);
                str = adminRepository.fetchCount(totalCountSelectQuery + oldTableQuery + whereClause);
                isNewTable = false;
            }
            
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT \n" + " al.application_id as applicationId,\n"
                    + " al.id as id,\n"
                    + " bam.name as apiName ,\n"
                    + " al.request_token as requestToken ,\n"
                    + " al.response_code as responseCode,\n"
                    + " al.response_message as responseMessage,\n"
                    + " al.created_date as createdDate ,\n"
                    + " (al.RESPONSE_TIME/1000) as responseTime,\n"
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(al.account_number) as accountNo,\n"
                    + " al.urn as urnCode,\n" + " al.created_date as date1 ";

            selectQuery += " , pa.storage_id AS storageId ";
            String selectsQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT ( \n"
                    + "                           'totalCount'  value " + totalCount + " ,"
                    + "                           'applicationId' value applicationId,\n"
                    + "                           'id' value id,\n"
                    + "                           'apiName' value apiName,\n"
                    + "                           'responseCode' value responseCode,\n"
                    + "                           'requestToken' value requestToken,\n"
                    + "                           'responseMessage' value responseMessage,\n"
                    + "                           'createdDate' value createdDate,\n"
                    + "                           'responseTime' value responseTime,\n"
                    + "                           'accountNo' value accountNo,\n"
                    + "                           'urnCode' value urnCode,\n"
                    + "                           'date1' value date1,\n";

            selectsQuery += " 'storageId' value storageId ";
            selectsQuery += " RETURNING CLOB) RETURNING CLOB ) from ( ";
            String mainQuery = selectsQuery + selectQuery + (isNewTable ? newTableQuery : oldTableQuery) + whereClause + orderByQuery + limitQuery;
            log.info("QUERY BANKAPIAUDIT DETAIL ======> {}", mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get fetchBankApiAuditDetailList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public String spAdminUserList(String request) {
        log.info("CALL spAdminUserList('{}', {})", request);
        String spName = "jns_reports.sp_Admin_User_List";
        return adminRepository.spAdminUserList(request, spName);
    }

    @Override
    public String spBankerUserList(String request) {
        log.info("CALL spBankerUserList('{}', {})", request);
        String spName = "jns_reports.SP_BANK_USER_LIST";
        return adminRepository.spBankerUserList(request, spName);
    }

    @Override
    public CommonResponse fetchBankUserList(String request, AuthClientResponse authClientResponse) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL) ? filterJSON.get(PAGINATIONFROM_LITERAL).asText() : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText() : "10";
            String json1 = filterJSON.has("columnFilter") ? filterJSON.get("columnFilter").asText() : null;
            JsonNode filterJSON1 = MultipleJSONObjectHelper.convertJSONToObject(json1, JsonNode.class);
            Long userOrgId = filterJSON1.has("userOrgId") ? filterJSON1.get("userOrgId").asLong() : null;
            String searchData = filterJSON1.has("userName") ? filterJSON1.get("userName").asText() : null;
            Long userRoleId = filterJSON1.has("userRoleId") ? filterJSON1.get("userRoleId").asLong() : null;
            Long userTypeId = filterJSON1.has(USERTYPEID_LITERAL) ? filterJSON1.get(USERTYPEID_LITERAL).asLong() : null;

            String searchQuery = "";
            if (searchData != null) {
                searchQuery = "AND (" + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.email) like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + " OR " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.mobile) like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + " OR " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.first_name) like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + " OR " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.last_name) like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + " OR bm.name like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + " OR ai.display_org_name like " + "'%" + searchData + "%')";
            }

            String whereClause = "where 1=1 and u.user_role_id < 100 " + searchQuery;

            if (!OPLUtils.isObjectNullOrEmpty(userTypeId)) {
                whereClause += " AND u.user_type_id =" + userTypeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(userOrgId)) {
                whereClause += " AND u.user_org_id =" + userOrgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(userRoleId)) {
                whereClause += " AND u.user_role_id =" + userRoleId;
            }

            String totalCountSelectQuery = "select json_object('totalCount' value count(u.user_id)) ";
            String tableQuery = " FROM  " + DBNameConstant.JNS_USERS + ".users u LEFT JOIN  " + DBNameConstant.JNS_USERS + ".user_organisation_master ai ON ai.user_org_id = u.user_org_id  LEFT JOIN  " + DBNameConstant.JNS_USERS + ".user_role_master sm ON sm.role_id = u.user_role_id LEFT JOIN " + DBNameConstant.JNS_USERS + ".branch_master bm ON bm.id = u.branch_id ";

            String orderByQuery = " ORDER BY u.user_id desc ";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";
            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + " ,"
                    + "'userId' VALUE userId, "
                    + "'email' VALUE email,"
                    + "'isActive' VALUE isActive,"
                    + "'isLocked' VALUE isLocked,"
                    + "'mobile' VALUE mobile, "
                    + "'orgId' VALUE orgId, "
                    + "'orgName' VALUE orgName, "
                    + "'branchId' VALUE branchId, "
                    + "'userTypeId' VALUE userTypeId, "
                    + "'userRoleId' VALUE userRoleId, "
                    + "'userType' VALUE userType,"
                    + "'userName' VALUE userName, "
                    + "'branchName' VALUE branchName, "
                    + "'branchCode' VALUE branchCode )returning clob) FROM (select u.user_id AS userId, "
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.email) AS email,"
                    + "u.is_active AS isActive,"
                    + "u.is_locked AS isLocked, "
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.mobile) AS mobile,"
                    + " u.user_org_id AS orgId, "
                    + " ai.display_org_name AS orgName, "
                    + " u.branch_id AS branchId ,"
                    + " u.user_type_id AS userTypeId,"
                    + " u.user_role_id AS userRoleId,"
                    + " sm.display_name AS userType,"
                    + " bm.name AS branchName,"
                    + " bm.code AS branchCode,"
                    + " CONCAT(" + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.first_name)|| ' ', " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.last_name)) AS userName";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery;
            log.info("QUERY fetchBankUserList  ======> {}", mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }

    }

    @Override
    public CommonResponse spGetBranchList(String request, AuthClientResponse authClientResponse) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL)
                    ? filterJSON.get(PAGINATIONFROM_LITERAL).asText()
                    : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText()
                    : "10";

            String json1 = filterJSON.has(FILTERJSON_LITERAL) ? filterJSON.get(FILTERJSON_LITERAL).asText() : null;
            JsonNode filterJSON1 = MultipleJSONObjectHelper.convertJSONToObject(json1, JsonNode.class);
            Long schTypeId = filterJSON1.has("schTypeId") ? filterJSON1.get("schTypeId").asLong() : 1l;
            Long orgId = filterJSON1.has(ORGID_LITERAL) ? filterJSON1.get(ORGID_LITERAL).asLong() : null;
            Long branchTypeId = filterJSON1.has("branchTypeId") ? filterJSON1.get("branchTypeId").asLong() : null;
            String searchValue = filterJSON1.has(SEARCHVALUE_LITERAL) ? filterJSON1.get(SEARCHVALUE_LITERAL).asText()
                    : null;
            Long searchTypeId = filterJSON1.has("searchTypeId") ? filterJSON1.get("searchTypeId").asLong() : null;

            String whereClause = "where 1 = 1 ";
            String selectQuery = "";
            String tableQuery = "";
            String mainQuery = "";
            String mainCountQuery = "";
            String limit = "";

            if (searchValue != null) {
                if (searchTypeId == 1) {
                    whereClause = whereClause + "  AND bm.name like " + "'%" + searchValue + "%'";
                } else if (searchTypeId == 2) {
                    whereClause = whereClause + "  AND  bm.code = '" + searchValue + "' ";
                } else {
                    whereClause = whereClause + "  AND  bm.id = '" + searchValue + "' ";
                }
            }

            if (orgId != null) {
                whereClause = whereClause.concat(" AND bpm.user_org_id =" + orgId);
            }

            if (branchTypeId != null) {
                whereClause = whereClause.concat(" AND bm.branch_type =" + branchTypeId);
            }

            String selctQuery = "SELECT \n"
                    + "                           bm.id as id,\n"
                    + "                           bm.id as branchId ,\n"
                    + "                           bm.name as branchName,\n"
                    + "                           bm.code as branchCode,\n"
                    + "                           bm.org_id as orgId,\n"
                    + "                           bm.ifsc_code as IFSCCode,\n"
                    + "                           uom.organisation_name as orgName,\n"
                    + "                            bpm.is_active as isActive,\n"
                    + "                            bm.created_on as createdOn,\n"
                    + "                            bm.branch_type as branchTypeId,\n"
                    + "                            BTM.branch_type  as branchTypeName ,\n"
                    + "                            sm.short_name as schemeName ,\n"
                    + "                            bpm.branch_ro_id as branchRoId ,\n"
                    + "                            bpm.branch_zo_id  as branchZoId ,\n"
                    + "                            CONCAT(RO.name|| ' ', RO.code) as roName,\n"
                    + "                            CONCAT(ZO.name|| ' ', ZO.code) as zoName ,\n"
                    + "                            CONCAT(bm.name || ' ,' || bm.code || ' ,' || ofc.city_name || ' ,' ||ofs.state_name ||' ,', bm.pincode) as currentBranch\n ";

            tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".branch_master bm \n"
                    + "                        INNER JOIN jns_users.branch_type_master BTM ON BTM.id = bm.branch_type AND BTM.is_active = 1\n"
                    + "                        INNER JOIN jns_users.branch_product_mapping bpm ON bpm.branch_id = bm.id  AND bpm.sch_type_id =" + schTypeId
                    + "                        LEFT JOIN jns_users.branch_master RO ON RO.id = bpm.branch_ro_id\n"
                    + "                        LEFT JOIN jns_users.branch_master ZO ON ZO.id = bpm.branch_zo_id\n"
                    + "                        INNER JOIN jns_users.user_organisation_master uom ON uom.user_org_id = bm.org_id\n"
                    + "                        INNER JOIN jns_users.scheme_master sm ON sm.id = bpm.sch_type_id\n"
                    + "                        LEFT JOIN jns_oneform.state ofs ON ofs.id = bm.state_id\n"
                    + "                        LEFT JOIN jns_oneform.city ofc ON ofc.id = bm.city_id ";

            mainCountQuery = "select json_object('TotalCount'value count(bm.id)) " + tableQuery + whereClause;

            limit = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";
            String str = adminRepository.fetchCount(mainCountQuery);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTAL_COUNT_LITERAL) ? json.get(TOTAL_COUNT_LITERAL).asInt() : 0;

            selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT ( \n"
                    + "                           'totalCount'  value " + totalCount + " ,"
                    + "                           'id' value id,\n"
                    + "                           'branchId' value branchId,\n"
                    + "                           'branchName' value branchName,\n"
                    + "                           'branchCode' value branchCode,\n"
                    + "                           'orgId' value orgId,\n"
                    + "                           'IFSCCode' value IFSCCode,\n"
                    + "                           'orgName' value orgName,\n"
                    + "                           'isActive' value isActive,\n"
                    + "                            'createdOn' value  createdOn ,\n"
                    + "                            'branchTypeId' value  branchTypeId  ,\n"
                    + "                            'branchTypeName' value branchTypeName  ,\n"
                    + "                            'schemeName' value  schemeName  ,\n"
                    + "                            'branchRoId' value branchRoId  ,\n"
                    + "                            'branchZoId' value branchZoId  ,\n"
                    + "                            'roName' value roName,\n"
                    + "                            'zoName' value zoName,\n"
                    + "                            'currentBranch' value currentBranch     ) RETURNING CLOB ) from (";

            mainQuery = selectQuery + selctQuery + tableQuery + whereClause + limit;
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }


    @Override
    public CommonResponse fetchAdminUserList(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL) ? filterJSON.get(PAGINATIONFROM_LITERAL).asText() : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText() : "10";
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            Long userTypeId = filterJSON.has(USERTYPEID_LITERAL) ? filterJSON.get(USERTYPEID_LITERAL).asLong() : null;

            String searchQuery = "";
            if (searchData != null) {
                searchQuery = "AND u.email like " + "'%" + searchData + "%'";
                searchQuery = "AND u.mobile like " + "'%" + searchData + "%'";
            }

            String whereClause = " WHERE u.is_active = 1  AND " + searchQuery;

            if (!OPLUtils.isObjectNullOrEmpty(userTypeId)) {
                whereClause += "u.user_type_id =" + userTypeId;
            }

            String totalCountSelectQuery = "select json_object('totalCount' value count(u.user_id)) ";
            String tableQuery = " FROM  " + DBNameConstant.JNS_USERS + ".users u INNER JOIN  " + DBNameConstant.JNS_USERS + ".user_role_master sm ON sm.role_id = u.user_role_id  ";

            String orderByQuery = " ORDER BY u.sign_up_date desc ";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";

            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + " ,'userId' VALUE userId, 'email' VALUE email, 'isActive' VALUE isActive, 'isLocked' VALUE isLocked, 'mobileNo' VALUE mobileNo, 'fullName' VALUE fullName, 'signUpDate' VALUE signUpDate, 'role' VALUE role, 'roleId' VALUE roleId )returning clob) FROM (select u.user_id AS userId, u.email AS email,u.is_active AS isActive,u.is_locked AS isLocked, u.mobile AS mobileNo,u.sign_up_date AS signUpDate,sm.display_name AS role,sm.role_id AS roleId,CONCAT(u.first_name|| ' ', u.last_name) AS fullName";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery;
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }

    }

    @Override
    public CommonResponse spUserOrganizationList(String request, AuthClientResponse authClientResponse) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL) ? filterJSON.get(PAGINATIONFROM_LITERAL).asText() : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText() : "10";
            String json1 = filterJSON.has(FILTERJSON_LITERAL) ? filterJSON.get(FILTERJSON_LITERAL).asText() : null;
            JsonNode filterJSON1 = MultipleJSONObjectHelper.convertJSONToObject(json1, JsonNode.class);
            String searchData = filterJSON1.has(SEARCHVALUE_LITERAL) ? filterJSON1.get(SEARCHVALUE_LITERAL).asText() : null;
            Long userTypeId = filterJSON1.has(USERTYPEID_LITERAL) ? filterJSON1.get(USERTYPEID_LITERAL).asLong() : null;

            String searchQuery = "";
            if (searchData != null) {
                searchQuery = "AND (uom.user_org_id like " + "'%" + searchData + "%'";
                searchQuery = searchQuery + "OR uom.organisation_code like " + "'%" + searchData + "%' ";
                searchQuery = searchQuery + " OR uom.display_org_name like " + "'%" + searchData + "%') ";
            }
            String whereClause = " WHERE uom.is_active = 1 " + searchQuery;
            if (!OPLUtils.isObjectNullOrEmpty(userTypeId)) {
                whereClause += "AND uom.user_type_id =" + userTypeId;
            }

            String totalCountSelectQuery = "select json_object('totalCount' value count(uom.user_org_id)) ";
            String tableQuery = " FROM  " + DBNameConstant.JNS_USERS + ".user_organisation_master uom";
            String orderByQuery = " ORDER BY uom.user_org_id desc ";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";

            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + " ,"
                    + "'bankType' VALUE bankType, "
                    + "'isActive' VALUE isActive, "
                    + "'largeLogoUrl' VALUE largeLogoUrl, "
                    + "'imagePath' VALUE imagePath,"
                    + " 'orgCode' VALUE orgCode, "
                    + "'orgFullName' VALUE orgFullName, "
                    + "'orgName' VALUE orgName,"
                    + " 'orgId' VALUE orgId)returning clob) FROM (select uom.user_org_id AS orgId,"
                    + "uom.organisation_name AS orgName,"
                    + "uom.display_org_name AS orgFullName,"
                    + "uom.organisation_code AS orgCode, "
                    + "uom.image_path AS imagePath,"
                    + "uom.large_logo_url AS largeLogoUrl,"
                    + "uom.is_active AS isActive,"
                    + "uom.user_type_id AS bankType";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery;
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }

    }

    @Override
    public List<Object> getUserType() {
        return adminRepository.getUserType();
    }

    @Override
    public CommonResponse spOtherUserList(String request, AuthClientResponse authClientResponse) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL) ? filterJSON.get(PAGINATIONFROM_LITERAL).asText() : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText() : "10";

            String json1 = filterJSON.has(FILTERJSON_LITERAL) ? filterJSON.get(FILTERJSON_LITERAL).asText() : null;
            JsonNode filterJSON1 = MultipleJSONObjectHelper.convertJSONToObject(json1, JsonNode.class);
            Long userTypeId = filterJSON1.has(USERTYPEID_LITERAL) ? filterJSON1.get(USERTYPEID_LITERAL).asLong() : null;
            String searchValue = filterJSON1.has(SEARCHVALUE_LITERAL) ? filterJSON1.get(SEARCHVALUE_LITERAL).asText() : null;

            String whereClause = "where 1 = 1 ";
            String selectQuery = "";
            String tableQuery = "";
            String mainQuery = "";
            String mainCountQuery = "";
            String limit = "";

            if (searchValue != null) {
                whereClause = " AND + " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.email) like " + "'%" + searchValue + "%' OR jns_users.AES_DECRYPT(u.mobile)  like " + "'%" + searchValue + "%' OR  uom.display_org_name like " + "'%" + searchValue + "%'  OR  bm.name " + "'%" + searchValue + "%' ";
            }
            if (userTypeId != null) {
                whereClause = whereClause.concat(" AND u.user_type_id =" + userTypeId);
            }

            String selctQuery = "SELECT \n"
                    + "                           u.user_id AS userId,\n"
                    + "                           " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.email) AS email,\n"
                    + "                            " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.mobile) AS mobile,\n"
                    + "                           u.user_org_id AS userOrgId,\n"
                    + "                           uom.display_org_name AS orgName,\n"
                    + "                           u.branch_id AS branchId,\n"
                    + "                           bm.name AS branchName,\n"
                    + "                           u.user_role_id AS userRoleId,\n"
                    + "                           urm.display_name AS roleName,\n"
                    + "                            u.created_date as createdOn ,\n"
                    + "                            utm.name as typeName ,\n"
                    + "                            u.user_type_id as userTypeId ,\n"
                    + "                            u.is_active as isActive ,\n"
                    + "                            u.is_locked as isLocked ,\n"
                    + "                            CONCAT( " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.first_name) , " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.middle_name)|| ' ,' ||  " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.last_name) ) as fullName\n ";

            tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".users u \n"
                    + "                        LEFT JOIN jns_users.user_organisation_master  uom ON uom.user_org_id = u.user_org_id \n"
                    + "                        LEFT JOIN jns_users.user_role_master urm ON urm.role_id = u.user_role_id \n"
                    + "                        LEFT JOIN jns_users.user_type_master utm ON utm.id = u.user_type_id\n"
                    + "                        LEFT JOIN jns_users.branch_master bm ON bm.id = u.branch_id ";

            mainCountQuery = "select json_object('TotalCount'value count(u.user_id)) " + tableQuery + whereClause;
            limit = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";
            System.err.println(mainCountQuery);
            String str = adminRepository.fetchspOtherUserListCount(mainCountQuery);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTAL_COUNT_LITERAL) ? json.get(TOTAL_COUNT_LITERAL).asInt() : 0;

            selectQuery = "SELECT_JSON_ARRAYAGG_JSON_OBJECT_LITERAL( \n"
                    + "                           'totalCount'  value " + totalCount + " ,"
                    + "                           'userId' value userId,\n"
                    + "                           'email' value email,\n"
                    + "                           'mobile' value mobile,\n"
                    + "                           'userOrgId' value userOrgId,\n"
                    + "                           'orgName' value orgName,\n"
                    + "                           'branchId' value branchId,\n"
                    + "                            'branchName' value  branchName ,\n"
                    + "                            'userRoleId' value  userRoleId  ,\n"
                    + "                            'roleName' value roleName  ,\n"
                    + "                            'createdOn' value createdOn,\n"
                    + "                            'typeName' value typeName,\n"
                    + "                            'userTypeId' value userTypeId  ,\n"
                    + "                            'isLocked' value isLocked,\n"
                    + "                            'isActive' value isActive,\n"
                    + "                            'fullName' value fullName     ) RETURNING CLOB ) from (";
            mainQuery = selectQuery + selctQuery + tableQuery + whereClause + limit;
//            System.err.println(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.spOtherUserList(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {

            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Override
    public String getAllScheme() {
        return adminRepository.getAllScheme();
    }


    // OLD
//    @Override
//    public CommonResponse fetchApplicationList(String request, AuthClientResponse authClientResponse) {
//		try {
//			JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//			Long typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asLong() : null;
//			String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
//			Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
//			Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
//
//			String searchQuery = "";
//			String whereClause = " WHERE am.is_active = 1 ";
//
//			if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
//				whereClause += " AND am.org_id =" + orgId;
//			}
//			if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
//				whereClause += " AND am.scheme_id =" + schemeId;
//			}
//			if (searchData != null) {
//				if (typeId == 1) {
//					searchQuery = " AND  am.urn =  '" + searchData + "'  ";
//				} else if (typeId == 2) {
//					searchQuery = " AND am.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('"
//							+ searchData + "') ";
//				} else {
//					searchQuery = " AND  am.id =  '" + searchData + "'  ";
//				}
//			}
//
//			whereClause = whereClause + searchQuery;
//
//			String totalCountSelectQuery = "select (json_object('totalCount' value count(am.id))) ";
//			String tablesQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am ";
//
//			String orderByQuery = "order by am.created_date desc";
//			String str = adminRepository.fetchCount(totalCountSelectQuery + tablesQuery + whereClause);
//			JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
//			Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;
//
//			String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am INNER JOIN "
//					+ DBNameConstant.JNS_INSURANCE + ".applicant_info ai ON ai.application_id = am.id LEFT JOIN "
//					+ DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1";
//
//			String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
//					+ " ,'schemeName' value schemeName,'id' value id,"
//					+ "'applicationId' value applicationId,'urn' value urn,"
//					+ " 'customerAccountNumber' value customerAccountNumber,"
//					+ "'statusId' value statusId,"
//					+ "'createdDate' value createdDate,"
//					+ "'enrollDate' value enrollDate,"
//					+ " 'modifiedDate' value modifiedDate,"
//					+ " 'orgId' value orgId, "
//					+ " 'stageId' value stageId,"
//					+ "'mobileNumber' value mobileNumber,"
//					+ " 'name' value name )returning clob) FROM ( SELECT  am.id as applicationId,am.id as id,"
//					+ "sm.short_name as schemeName,"
//					+ "am.urn as urn,"
//					+ ""+DBNameConstant.JNS_USERS+".\"decvalue\"(am.account_number) as customerAccountNumber,"
//							+ "am.application_status as statusId,"
//							+ "am.created_date as createdDate,"
//							+ "am.enrollment_date as enrollDate, "
//							+ "am.stage_id as stageId ,"
//							+ "am.modified_date as modifiedDate,"
//					        + "am.org_id as orgId,"+DBNameConstant.JNS_USERS+".\"decvalue\"(ai.mobile_number) as mobileNumber,"
//							+ ""+DBNameConstant.JNS_USERS+".\"decvalue\"(ai.name) as name ";
//			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery  + " )";
////			System.err.println(mainQuery);
//			return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
//					HttpStatus.OK.value(), Boolean.TRUE);
//		} catch (Exception e) {
//			log.error("Exception is getting while fetchApplicationList", e);
//		}
//		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
//				HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}

    @Override
    public CommonResponse fetchApplicationListNew(String request, AuthClientResponse authClientResponse) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Long typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asLong() : null;
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String whereClause = " WHERE am.is_active = 1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND am.org_id =" + orgId;
            }
            String schemeClause = "";
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                schemeClause += " AND am.scheme_id = " + schemeId;
            }

            if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                if (typeId == 1) {
                    searchData = OPLUtils.getApplicationIdFromUrn(searchData).toString();
                }
                whereClause += " AND  am.id =  '" + searchData + "'  ";
            }

            String selectQuery = "SELECT  am.id as applicationId,am.id as id,sm.short_name as schemeName,am.urn as urn," +
                    "JNS_USERS.\"decvalue\"(am.account_number) as customerAccountNumber, am.application_status as statusId,am.created_date as createdDate," +
                    "am.enrollment_date as enrollDate, to_char(am.stage_id) as stageId ,am.modified_date as modifiedDate, am.org_id as orgId," +
                    "JNS_USERS.\"decvalue\"(ai.mobile_number) as mobileNumber,JNS_USERS.\"decvalue\"(ai.name) as name " +
                    "FROM JNS_INSURANCE.application_master am " +
                    "INNER JOIN JNS_INSURANCE.applicant_info ai ON ai.application_id = am.id " +
                    "INNER JOIN JNS_USERS.scheme_master sm ON sm.id = am.scheme_id AND sm.is_active = 1 " +
                    whereClause + schemeClause +

                    "UNION ALL  " +
                    "SELECT  am.id as applicationId,am.id as id,sm.short_name as schemeName,am.urn as urn, '' as customerAccountNumber, " +
                    "am.STATUS  as statusId,am.created_date as createdDate,am.enrollment_date as enrollDate, '' as stageId ,am.modified_date as modifiedDate, " +
                    "am.org_id as orgId,JNS_USERS.\"decvalue\"(AD.mobile_number) as mobileNumber," +
                    "(JNS_USERS.\"decvalue\"(ai.FIRST_NAME) || ' ' || JNS_USERS.\"decvalue\"(ai.MIDDLE_NAME)|| ' ' || JNS_USERS.\"decvalue\"(ai.LAST_NAME)) as name " +
                    "FROM JNS_MASTER.PMJJBY am " +
                    "INNER JOIN JNS_MASTER.APPLICANT_PI_DETAILS ai ON ai.ID = am.id " +
                    "INNER JOIN JNS_MASTER.APPLICANT_INFO AD ON aD.ID = am.id " +
                    "INNER JOIN JNS_USERS.scheme_master sm ON sm.id = 2 AND " + schemeId + " = 2 AND sm.is_active = 1 "
                    + whereClause +

                    "UNION ALL  " +
                    "SELECT  am.id as applicationId,am.id as id,sm.short_name as schemeName,am.urn as urn, '' as customerAccountNumber, " +
                    "am.STATUS  as statusId,am.created_date as createdDate,am.enrollment_date as enrollDate, '' as stageId ,am.modified_date as modifiedDate, " +
                    "am.org_id as orgId,JNS_USERS.\"decvalue\"(AD.mobile_number) as mobileNumber," +
                    "(JNS_USERS.\"decvalue\"(ai.FIRST_NAME) || ' ' || JNS_USERS.\"decvalue\"(ai.MIDDLE_NAME)|| ' ' || JNS_USERS.\"decvalue\"(ai.LAST_NAME)) as name " +
                    "FROM JNS_MASTER.PMSBY am " +
                    "INNER JOIN JNS_MASTER.APPLICANT_PI_DETAILS ai ON ai.ID = am.id " +
                    "INNER JOIN JNS_MASTER.APPLICANT_INFO AD ON aD.ID = am.id " +
                    "INNER JOIN JNS_USERS.scheme_master sm ON sm.id = 1 AND " + schemeId + " = 1 AND sm.is_active = 1 "
                    + whereClause +

                    "UNION ALL " +
                    "SELECT  am.id as applicationId,am.id as id,sm.short_name as schemeName,am.urn as urn,'' as customerAccountNumber, am.status as statusId,am.created_date as createdDate,am.STATUS_CHANGE_DATE as enrollDate, TO_CHAR(am.stage_id)  as stageId ,am.modified_date as modifiedDate, " +
                    "am.org_id as orgId,JNS_USERS.\"decvalue\"(AD.mobile_number) as mobileNumber,(JNS_USERS.\"decvalue\"(ai.FIRST_NAME) || ' ' || JNS_USERS.\"decvalue\"(ai.MIDDLE_NAME)|| ' ' || JNS_USERS.\"decvalue\"(ai.LAST_NAME)) as name " +
                    "FROM JNS_MASTER.EXPIRED_ENROLLMENT am " +
                    "INNER JOIN JNS_MASTER.APPLICANT_PI_DETAILS ai ON ai.ID = am.id " +
                    "INNER JOIN JNS_MASTER.APPLICANT_INFO AD ON aD.ID = am.id " +
                    "INNER JOIN JNS_USERS.scheme_master sm ON sm.id = am.scheme_id AND sm.is_active = 1 " +
                    whereClause + schemeClause ;

            String totalCountQuery = " SELECT to_char(count(tmp.applicationId)) FROM  (" + selectQuery + ") tmp ";
//			log.info("totalCountQuery ->  {}",totalCountQuery);
            String totalCount = adminRepository.fetchCount(totalCountQuery);
//			log.info("string ->  {}",string);

            String mainQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
                    + " ,'schemeName' value schemeName,'id' value id,"
                    + "'applicationId' value applicationId,'urn' value urn,"
                    + " 'customerAccountNumber' value customerAccountNumber,"
                    + "'statusId' value statusId,"
                    + "'createdDate' value createdDate,"
                    + "'enrollDate' value enrollDate,"
                    + " 'modifiedDate' value modifiedDate,"
                    + " 'orgId' value orgId, "
                    + " 'stageId' value stageId,"
                    + "'mobileNumber' value mobileNumber,"
                    + " 'name' value name )returning clob) FROM ( " + selectQuery + " ) ";

//            log.info(" selectQuery -->   [{}] ", selectQuery);

            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while fetchApplicationList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchClaimAppList(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//				Long typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asLong() : null;
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String searchQuery = "";
            String whereClause = " WHERE ca.is_active = 1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND ca.org_id =" + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereClause += " AND ca.scheme_id =" + schemeId;
            }
            if (searchData != null) {
//					if (typeId == 1) {
//						searchQuery = " AND  am.urn =  '" + searchData + "'  ";
//					} else if (typeId == 2) {
//						searchQuery = " AND am.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('"
//								+ searchData + "') ";
//					} else {
                searchQuery = " AND  ca.application_id =  '" + searchData + "'  ";
//					}
            }

            whereClause = whereClause + searchQuery;

            String totalCountSelectQuery = "select (json_object('totalCount' value count(ca.id))) ";
            String tablesQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".clm_master ca ";
//						+ DBNameConstant.JNS_INSURANCE + ".application_master am ON am.id = ca.application_id ";
            String orderByQuery = "order by ca.created_date desc";

            String str = adminRepository.fetchCount(totalCountSelectQuery + tablesQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".clm_master ca INNER JOIN "
                    + DBNameConstant.JNS_INSURANCE + ".clm_details cd ON cd.id = ca.id INNER JOIN "
                    + DBNameConstant.JNS_INSURANCE + ".CLM_PI_DETAILS cp ON cp.id = ca.id INNER JOIN "
                    + DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=ca.scheme_id AND sm.is_active=1";

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
                    + " ,'id' value lst.id,"
                    + " 'applicationId' value lst.applicationId,"
                    + " 'accountHolderName' value lst.accountHolderName, "
                    + "'amount_of_transaction' value lst.amount_of_transaction, "
                    + " 'customerAccountNumber' value lst.customerAccountNumber,"
                    + " 'urn' value lst.urn,"
                    + "  'mobileNumber' value lst.mobileNumber,"
                    + "'schemeName' value lst.schemeName,"
                    + "'claimDate' value lst.claimDate, "
                    + " 'modifiedDate' value lst.modifiedDate,"
                    + "'createdDate' value lst.createdDate,"
                    + "'claimStatusId' value lst.claimStatusId,"
                    + " 'claimStageId' value lst.claimStageId )returning clob) FROM ( SELECT ca.id as id,"
                    + " ca.application_id as applicationId, "
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(cp.ac_holder_name) as accountHolderName, "
                    + "ca.transaction_amount as amount_of_transaction," + ""
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(cp.ap_account_number) as customerAccountNumber,"
                    + " ca.urn as urn,"
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(cd.ap_mobile_number) as mobileNumber, "
                    + " sm.short_name as schemeName,"
                    + " ca.claim_date as claimDate,"
                    + " ca.modified_date as modifiedDate,"
                    + " ca.created_date as createdDate, "
                    + " ca.status as claimStatusId, "
                    + " ca.stage_id as claimStageId ";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + ") lst";
//			System.err.println(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get fetchClaim List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public String getYearsList() {
        return adminRepository.getYearsList();
    }

    @Override
    public String fetchInsurerMstDetailList(String request, Long userId) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String from = filterJSON.has("from") ? filterJSON.get("from").asText() : "0";
            String to = filterJSON.has("to") ? filterJSON.get("to").asText() : "10";
            String years = filterJSON.has("years") ? filterJSON.get("years").asText() : null;
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;


            String tableQuery = " FROM JNS_INSURANCE.insurer_mst_details imd \r\n"
                    + "			    LEFT JOIN jns_users.user_organisation_master UOM ON UOM.user_org_id=imd.insurer_org_id AND UOM.is_active=1\r\n"
                    + "			    LEFT JOIN jns_users.user_organisation_master UOM1 ON UOM1.user_org_id=imd.org_id \r\n"
                    + "			    LEFT JOIN jns_users.scheme_master sm ON sm.id=imd.scheme_id AND sm.is_active=1 ";

            String whereQuery = " WHERE imd.is_active=1 ";
            if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                whereQuery = whereQuery
                        + " AND (jns_users.\"decvalue\"(imd.master_policy_no) LIKE '%" + searchData + "%' OR UOM.organisation_name LIKE '%"
                        + searchData + "%' OR sm.short_name LIKE '%" + searchData + "%' OR imd.year LIKE '%" + searchData + "%' )";
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereQuery = whereQuery + "AND imd.scheme_id = " + schemeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereQuery = whereQuery + "AND (imd.org_id = " + orgId + " or imd.insurer_org_id = " + orgId + " )";
            }

            if (!OPLUtils.isObjectNullOrEmpty(years)) {
                whereQuery = whereQuery + "AND imd.year = '" + years + "'";
            }

            String orderQuery = " ORDER BY imd.year DESC ";
            String limitQuery = "OFFSET " + from + " ROWS FETCH NEXT " + to + " ROWS ONLY";

            String selectCountQuery = " select (json_object('totalCount' value count(*))) " + tableQuery + whereQuery;
            String str = adminRepository.fetchCount(selectCountQuery);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;


            String selectQuery = " SELECT JSON_OBJECT('id' value imd.id  ,\r\n"
                    + "			'insurerName' value UOM.organisation_name,\r\n"
                    + "			'bankName' value UOM1.organisation_name,\r\n"
                    + "			 'orgId' value imd.org_id,\r\n"
                    + "			 'InsurerOrgId' value imd.insurer_org_id,\r\n"
                    + "          'schemeName' value sm.short_name,\r\n"
                    + "           'years' value imd.year,\r\n"
                    + "           'status' value CASE imd.is_active\r\n"
                    + "                             WHEN 1 THEN 'Active'\r\n"
                    + "                             ELSE 'Inactive'\r\n"
                    + "                        END,\r\n"
                    + "            'masterPolicyNo' value jns_users.\"decvalue\"(imd.master_policy_no),\r\n"
                    + "            'insurerCode' value imd.insurer_code,\r\n"
                    + "            'policyStartDate' value TRUNC(imd.policy_start_date),\r\n"
                    + "            'policyEndDate' value TRUNC(imd.policy_end_date),\r\n"
                    + "            'totalcount' value " + totalCount + " ) ";

            String mainQuery = selectQuery + tableQuery + whereQuery + orderQuery + limitQuery;
            List<Object> data = adminRepository.fetchListOfDataFromDb(mainQuery);
            return OPLUtils.isListNullOrEmpty(data) ? null : data.toString();
        } catch (Exception e) {
            log.error("Exception is getting while get saved Enrollment List", e);
            return null;
        }
    }


    @Override
    public String fetchApplicationHistory(String request, Long userId) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String from = filterJSON.has("from") ? filterJSON.get("from").asText() : "0";
            String to = filterJSON.has("to") ? filterJSON.get("to").asText() : "10";
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            String typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asText() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String tableQuery = " from JNS_INSURANCE.application_master_audit am \r\n"
                    + "left join JNS_INSURANCE.error_stage_audit es on es.application_id =am.application_id\r\n"
                    + "left join JNS_USERS.scheme_master sm on sm.id = am.scheme_id\r\n"
                    + "left join JNS_INSURANCE.stage_master stg on stg.id =am.stage_id\r\n"
                    + "left join  JNS_USERS.user_organisation_master om on om.user_org_id=am.org_id ";

            String whereQuery = " WHERE 1=1 ";


            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereQuery = whereQuery + " AND am.org_id = " + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereQuery = whereQuery + " AND am.scheme_id = " + schemeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(typeId)) {
                if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                    if (typeId.equals("1")) {
                        whereQuery = whereQuery
                                + " AND jns_users.\"decvalue\"(am.account_number) LIKE '%" + searchData + "%'";
                    }
                    if (typeId.equals("2")) {
                        whereQuery = whereQuery
                                + " AND am.application_id LIKE '%" + searchData + "%'";
                    }
                    if (typeId.equals("3")) {
                        whereQuery = whereQuery
                                + " AND am.urn LIKE '%" + searchData + "%'";
                    }
                }

            }
            String limitQuery = " OFFSET " + from + " ROWS FETCH NEXT " + to + " ROWS ONLY ";

            String selectCountQuery = " select (json_object('totalCount' value count(*))) " + tableQuery + whereQuery;
            String str = adminRepository.fetchCount(selectCountQuery);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = " select  json_arrayagg(json_object('id' value id,'acctno' value acctno,'urn' value urn ,\r\n"
                    + " 'dob' value dob,'stageId' value stageId,'stageName' value stageName, 'scheme' value scheme ,\r\n"
                    + " 'bankName' value bankName,'message' value message,'stageName2' value stageName2,'totalCount' value " + totalCount + " ,'isListCollapsed' value 'false','date1' value to_char(date1,'DD/MM/YYYY HH:MM:ss')  )returning clob) from ( ";
            String Select = " select  am.application_id as id,jns_users.\"decvalue\"(am.account_number) as acctno,am.urn as urn ,\r\n"
                    + "jns_users.\"decvalue\"(am.dob) as dob,am.stage_id as stageId,stg.stage_name as stageName,sm.short_name as scheme , am.CREATED_DATE as date1 ,\r\n"
                    + "om.organisation_name as bankName ,es.message as message,es.stage_name as stageName2 ," + totalCount + " as totalCount  ";
            String OrderQuery = " order by  am.application_id desc";

            String mainQuery = selectQuery + Select + tableQuery + whereQuery + OrderQuery + limitQuery + "  )";
            System.err.println(mainQuery);
            String data = adminRepository.spOtherUserList(mainQuery);
            return data;
        } catch (Exception e) {
            log.error("Exception is getting while fetchApplicationHistory", e);
            return null;
        }
    }

    public CommonResponse FetchNotificationCount(String request) {
        try {

            log.info("entering FetchNotificationCount api and request ==> {}", request);

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;

            String whereQuery = " where nl.status_code = 200 ";
            if ((!OPLUtils.isObjectNullOrEmpty(fromDate)) && (!OPLUtils.isObjectNullOrEmpty(toDate))) {
                whereQuery += " AND nl.created_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and "
                        + " to_timestamp('" + toDate + "') ";
            }

//	   		String mainQuery=" select json_object('name' value np.provider_name ,\r\n"
//	   				+ "                             'emailCount' value case when(sum(nl.to_email_count+nl.bcc_email_count+nl.cc_email_count)) is null then 0 else  sum(nl.to_email_count+nl.bcc_email_count+nl.cc_email_count) end,\r\n"
//	   				+ "                             'smsCount' value case when(sum(sms_count)) is null then 0 else sum(sms_count) end ) \r\n"
//	   				+ "                             from jns_notification.notification_provider np\r\n"
//	   				+ "                             left join JNS_NOTIFICATION.NOTIFICATION_EMAIL_LOG nl on nl.provider_id=np.id\r\n"
//	   				+ "                             left join JNS_NOTIFICATION.notification_sms_log ns on ns.provider_id=np.id "+whereQuery+" group by np.provider_name";
//
            String mainQuery = "select json_object('name' value np.provider_name ,\r\n"
                    + "'emailCount' value sum(CASE WHEN nl.to_email_count IS NOT NULL THEN nl.to_email_count else 0 end+ \r\n"
                    + "CASE WHEN nl.bcc_email_count IS NOT NULL THEN nl.bcc_email_count else 0 end+ \r\n"
                    + "CASE WHEN nl.cc_email_count IS NOT NULL THEN nl.cc_email_count else 0 end),\r\n"
                    + "'smsCount' value case when(sum(sms_count)) is null then 0 else sum(sms_count) end ) \r\n"
                    + "from jns_notification.notification_logs nl\r\n"
                    + "left join jns_notification.notification_provider np on np.id = nl.provider_id " + whereQuery
                    + "group by np.provider_name";

            List<Object> data = adminRepository.fetchListOfDataFromDb(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    OPLUtils.isListNullOrEmpty(data) ? null : data.toString(), HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get FetchNotificationCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }


    public void updateCountAllBanks() {
        log.info("entering saving insurer Count");

        List<String> countDataList = countRepo.getEnrollmentDetail();
        countDataList.addAll(countRepo.getClaimDetail());
        if (!OPLUtils.isListNullOrEmpty(countDataList)) {
            try {
                List<CountDomain> countDomainList = new ArrayList<>();
                for (String countData : countDataList) {
                    CountDomain countDomain = MultipleJSONObjectHelper.getObjectFromString(countData, CountDomain.class);
                    log.info("countDomain => " + countDomain.toString());
                    countDomainList.add(countDomain);
                }

                countRepo.deleteAll();
                countRepo.saveAll(countDomainList);

            } catch (IOException e) {
                log.error("Exception is getting while saving insurer Count", e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    public CommonResponse fetchAllInsurerCount(String request) {
        try {
            log.info("entering fetchInsurerCount api and request ==> {}", request);
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            String typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asText() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
//	   		Long source = filterJSON.has("source") ? filterJSON.get("source").asLong() : null;

            if (typeId.equals("1")) {
                String completedInsurer = adminRepository.spFetchAdminEnrollmentList(request,
                        DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_INSURER_COMPLATE");
                String rejectedInsuerer = adminRepository.spFetchAdminEnrollmentList(request,
                        DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_INSURER_REJECTED");

                List<CountProxy> complateProxyList = new ArrayList<>();
                List<CountProxy> rejProxyList = new ArrayList<>();

                if (!OPLUtils.isObjectListNull(completedInsurer)) {
                    complateProxyList = MultipleJSONObjectHelper.getListOfObjects(completedInsurer, null,
                            CountProxy.class);
                }

                if (!OPLUtils.isObjectListNull(rejProxyList)) {
                    rejProxyList = MultipleJSONObjectHelper.getListOfObjects(rejectedInsuerer, null,
                            CountProxy.class);
                }

                for (CountProxy proxy : complateProxyList) {
                    for (CountProxy rjProxy : rejProxyList) {
                        if (!OPLUtils.isObjectNullOrEmpty(rjProxy.getInsurerOrgId())) {
                            if (proxy.getInsurerOrgId().equals(rjProxy.getInsurerOrgId())) {
                                proxy.setRejectedCount(rjProxy.getRejectedCount());
                                proxy.setExpiredCount(rjProxy.getExpiredCount());
                            }
                        }
                    }
                    proxy.setTotalCount(
                            (!OPLUtils.isObjectNullOrEmpty(proxy.getCompletedCount()) ? proxy.getCompletedCount() : 0)
                                    + (!OPLUtils.isObjectNullOrEmpty(proxy.getRejectedCount())
                                    ? proxy.getRejectedCount()
                                    : 0)
                                    + (!OPLUtils.isObjectNullOrEmpty(proxy.getExpiredCount()) ? proxy.getExpiredCount()
                                    : 0));

                }
                return new CommonResponse(complateProxyList, "SuccessFully fetch Enrollment  BankWiseCount",
                        HttpStatus.OK.value());
            }
            if (typeId.equals("2")) {
                String selectQuery = null;
                String tableQuery = null;
                String whereQuery = null;
                String groupQuery = null;
                selectQuery = "select json_object( \r\n"
                        + "'insurerOrgId' value uom.org_id,\r\n"
//	   					+ "'scheme' value cm.scheme_id ,\r\n"
                        + "'name' value uom.ORGANISATION_NAME,  \r\n"
//	   					+ "'bankName' value uom1.ORGANISATION_NAME,  \r\n"
//	   					+ "'channelId' value aom.channel_id,\r\n"
//	   					+ "'totalCount' value sum(case when cm.status in(7,8,9,10) then 1 else 0 end) ,  \r\n"
                        + "'totalCount' value count(cm.id),  \r\n"
//	   					+ "'InProgressCount' value sum(case when cm.status = 5 then 1 else 0 end), \r\n"
//	   					+ "'SendToInsurerCount' value sum(case when cm.status = 6 then 1 else 0 end)  , \r\n"
                        + "'accpetedCount' value sum(case when cm.status = 10 then 1 else 0 end), \r\n"
                        + "'onHoldCount' value sum(case when cm.status = 9 then 1 else 0 end)  , \r\n"
                        + "'rejectedCount' value sum(case when cm.status = 8 then 1 else 0 end) , \r\n"
                        + "'sendBackToBankCount' value sum(case when cm.status = 7 then 1 else 0 end)) \r\n";

                tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".clm_master cm \r\n "
                        + " LEFT JOIN " + DBNameConstant.JNS_CONFIG + ".user_organisation_master uom ON uom.org_id = cm.insurer_org_id \r\n";
//	   					+" LEFT JOIN "+ DBNameConstant.JNS_USERS + ".user_organisation_master uom1 ON uom.user_org_id = cm.org_id   \r\n";

                whereQuery = " WHERE 1=1  ";
//				if (OPLUtils.isObjectNullOrEmpty(orgId)) {
//					return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, OPLUtils.isListNullOrEmpty(countRepo.findAll())?null:countRepo.findAll(),
//							HttpStatus.OK.value(), Boolean.TRUE);
//		   		}
                if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                    whereQuery = whereQuery + " AND cm.insurer_org_id = " + orgId;
                }
                if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                    whereQuery = whereQuery + " AND cm.scheme_id = " + schemeId;
                }
//				if (!OPLUtils.isObjectNullOrEmpty(source)) {
//		   			whereQuery = whereQuery+" AND cm.souce = "+source;
//		   		}
//		   		and aom.channel_id is not null
                whereQuery = whereQuery + " and cm.is_active=1 and cm.insurer_org_id is not null ";
                if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
//					whereQuery=whereQuery+" and cm.claim_date between to_timestamp('"+fromDate+"') and to_timestamp('"+toDate+"')+1 ";
                    whereQuery = whereQuery + " AND cm.claim_date BETWEEN TO_DATE('" + fromDate + "', 'DD-MON-YYYY hh:mi:ss AM') AND TO_DATE('" + toDate + "', 'DD-MON-YYYY hh:mi:ss AM') ";
                }
//				groupQuery=" group by cm.org_id,uom.ORGANISATION_NAME,aom.channel_id,cm.scheme_id,uom1.ORGANISATION_NAME ";
                groupQuery = " group by uom.org_id,uom.ORGANISATION_NAME ";
                String mainQuery = selectQuery + tableQuery + whereQuery + groupQuery;
                log.info("QUERY FOR INSURER COUNT ======> {}", mainQuery);
                List<Object> data = adminRepository.fetchListOfDataFromDb(mainQuery);
                return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, OPLUtils.isListNullOrEmpty(data) ? null : data.toString(),
                        HttpStatus.OK.value(), Boolean.TRUE);
            }

        } catch (Exception e) {
            log.error("Exception is getting while get fetchInsurerCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public String getApiConfigMaster() {
        return adminRepository.getApiConfigMaster();
    }

    @Override
    public String getConfigMaster() {
        return adminRepository.getConfigMaster();
    }

    @Override
    public String getTypeMasterForDms() {
        return adminRepository.getTypeMasterForDms();
    }

    @Override
    public String getDocumentMasterForDms() {
        return adminRepository.getDocumentMasterForDms();
    }

    @Override
    public String getPreMimumMaster() {
        return adminRepository.getPreMimumMaster();
    }

    @Override
    public CommonResponse save(ConfigMasterProxy configMasterProxy) {
        try {
            Long id = null;
            ConfigMasterV3 configMaster = null;
            if (!OPLUtils.isObjectNullOrEmpty(configMasterProxy.getId())) {
                configMaster = configMasterRepo.findById(configMasterProxy.getId()).orElse(null);
                if (!OPLUtils.isObjectNullOrEmpty(configMaster)) {
                    BeanUtils.copyProperties(configMasterProxy, configMaster, "id");
                }
            } else {
                configMaster = new ConfigMasterV3();
                BeanUtils.copyProperties(configMasterProxy, configMaster, "id");
            }
            configMaster.setIsActive(true);
            id = configMasterRepo.save(configMaster).getId();
            return new CommonResponse("saved!!!", id, HttpStatus.OK.value(), true);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }


    @Override
    public CommonResponse activeIsConfigMaster(Long id) {
        try {
            ConfigMasterV3 configMaster = configMasterRepo.findById(id).orElse(null);
            if (!OPLUtils.isObjectListNull(configMaster, configMaster.getIsActive())) {
                configMaster.setIsActive(!configMaster.getIsActive());
                configMasterRepo.save(configMaster);
                return new CommonResponse(configMaster.getIsActive() ? "Api User activate successfully." : "User inactivate successfully.", HttpStatus.OK.value(), Boolean.TRUE);
            }
            return new CommonResponse("User not found at given id.", HttpStatus.OK.value());
        } catch (Exception e) {
            return new CommonResponse("This application has encountered some error, please try after sometimes.", HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
    }

    @Override
    public ConfigMasterProxy getConfigListById(Long id) {
        ConfigMasterV3 configMaster = configMasterRepo.findById(id).orElse(null);
        ConfigMasterProxy configMasterProxy = new ConfigMasterProxy();
        if (configMaster != null) {
            BeanUtils.copyProperties(configMaster, configMasterProxy);
        }

        return configMasterProxy;
    }

    @SuppressWarnings("unchecked")
    @Override
    public CommonResponse fetchAppBankWiseCount(String request, AuthClientResponse authClientResponse) {
        try {
            String completed = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_COMPLATED_COUNT");
            String rejected = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_REJECTED_COUNT");
            String application = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_ACCEPTED_COUNT");

            List<CountProxy> countProxyList = MultipleJSONObjectHelper.getListOfObjects(completed, null,
                    CountProxy.class);
            List<CountProxy> countProxyRejectList = MultipleJSONObjectHelper.getListOfObjects(rejected, null,
                    CountProxy.class);
            List<CountProxy> countProxyAppList = MultipleJSONObjectHelper.getListOfObjects(application, null,
                    CountProxy.class);

            if (!OPLUtils.isObjectNullOrEmpty(completed)) {
                for (CountProxy proxy : countProxyList) {

                    for (CountProxy rjCnt : countProxyRejectList) {
                        if (proxy.getOrgId().equals(rjCnt.getOrgId())) {
                            proxy.setRejectedCount(rjCnt.getRejectedCount());
                            proxy.setExpiredCount(rjCnt.getExpiredCount());
                            if (!OPLUtils.isObjectNullOrEmpty(rjCnt.getTransactionFailedCount())) {
                                proxy.setTransactionFailedCount(rjCnt.getTransactionFailedCount());
                            } else {
                                proxy.setTransactionFailedCount(0L);
                            }
                        }
                    }
                    for (CountProxy appProxy : countProxyAppList) {
                        if (proxy.getOrgId().equals(appProxy.getOrgId())) {
                            proxy.setApplicationForm(appProxy.getApplicationForm());
                            proxy.setTranFailedInprogressCnt(null);
                            if (!OPLUtils.isObjectNullOrEmpty(appProxy.getTranFailedInprogressCnt())) {
                                proxy.setTransactionFailedCount(
                                        proxy.getTransactionFailedCount() + appProxy.getTranFailedInprogressCnt());
                            }

                        }

                    }
//					proxy.setTotalCount();
//					if (!OPLUtils.isObjectNullOrEmpty(proxy.getCompletedCount())) {
//						proxy.setTotalCount(proxy.getCompletedCount());
//					} else {
//						proxy.setTotalCount(0L);
//					}
//					if (!OPLUtils.isObjectNullOrEmpty(proxy.getRejectedCount())) {
//						proxy.setTotalCount(proxy.getRejectedCount() + proxy.getTotalCount());
//					}
//					if (!OPLUtils.isObjectNullOrEmpty(proxy.getExpiredCount())) {
//						proxy.setTotalCount(proxy.getExpiredCount() + proxy.getTotalCount());
//					}
//					if (!OPLUtils.isObjectNullOrEmpty(proxy.getApplicationForm())) {
//						proxy.setTotalCount(proxy.getApplicationForm() + proxy.getTotalCount());
//					}
//					if (!OPLUtils.isObjectNullOrEmpty(proxy.getTransactionFailedCount())) {
//						proxy.setTotalCount(proxy.getTransactionFailedCount() + proxy.getTotalCount());
//					}
                    proxy.setTotalCount((!OPLUtils.isObjectNullOrEmpty(proxy.getCompletedCount()) ? proxy.getCompletedCount() : 0)
                            + (!OPLUtils.isObjectNullOrEmpty(proxy.getRejectedCount()) ? proxy.getRejectedCount() : 0)
                            + (!OPLUtils.isObjectNullOrEmpty(proxy.getExpiredCount()) ? proxy.getExpiredCount() : 0)
                            + (!OPLUtils.isObjectNullOrEmpty(proxy.getApplicationForm()) ? proxy.getApplicationForm() : 0)
                            + (!OPLUtils.isObjectNullOrEmpty(proxy.getTransactionFailedCount()) ? proxy.getTransactionFailedCount() : 0));
                }

            }
            return new CommonResponse(countProxyList, "SuccessFully fetch Enrollment  BankWiseCount",
                    HttpStatus.OK.value());

        } catch (Exception e) {
            log.error("Exception is getting while get fetch Enrollment  BankWiseCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());

    }


// old DB
//	JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//	Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
//	Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
//	String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
//	String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : new Date().toString();
//
//	String whereClause = " WHERE am.is_active=1 AND am.stage_id IS NOT NULL ";
//
//	if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
//		whereClause += " AND am.org_id = " + orgId;
//	}
//
//	if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
//		whereClause += " AND am.scheme_id = " + schemeId;
//	}
//
//	if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
//		whereClause += " AND am.status_change_date BETWEEN TO_DATE('" + fromDate + "', 'DD-MON-YYYY hh:mi:ss AM') AND TO_DATE('"+toDate+"', 'DD-MON-YYYY hh:mi:ss AM') ";
//		//whereClause += " AND am.status_change_date between to_timestamp('" + fromDate + "') and to_timestamp('"+ toDate + "') ";
//	} else if (!OPLUtils.isObjectNullOrEmpty(fromDate)) {
//		whereClause += " AND am.status_change_date = TO_DATE('" + fromDate + "', 'DD-MON-YYYY hh:mi:ss AM') ";
//		//whereClause += " AND am.status_change_date = to_timestamp('" + fromDate + "') ";
//	} else if (!OPLUtils.isObjectNullOrEmpty(toDate)) {
//		whereClause += " AND am.status_change_date = TO_DATE('" + toDate + "', 'DD-MON-YYYY hh:mi:ss AM') ";
//		//whereClause += " AND am.status_change_date = to_timestamp('" + fromDate + "') ";
//	}
//
////	String selectQuery = "select JSON_OBJECT('orgId' value am.org_id ,\n"
////			+ "	                         'orgName' value uom.ORGANISATION_NAME, \n "
////			+ "	                         'totalCount' value count(am.id), \n "
////			+ "	                         'CompletedCount' value sum(case when am.stage_id = 6 then 1 else 0 end), \n "
////			+ "	                         'RejectedCount' value sum(case when am.stage_id = 8 then 1 else 0 end) , \n "
////			+ "	                          'ExpiredCount' value sum(case when am.stage_id = 7 then 1 else 0 end ) \n) ";
////
////	String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am LEFT JOIN  "
////			+ DBNameConstant.JNS_USERS + ".user_organisation_master uom ON uom.user_org_id = am.org_id";
////
////	String GroupByQuery = " group by am.org_id,uom.ORGANISATION_NAME";
//
////	String query = selectQuery + tableQuery + whereClause + GroupByQuery;
//
//	String query = "select JSON_OBJECT('orgId' value uom.user_org_id ,\n" +
//			"'orgName' value uom.ORGANISATION_NAME,\n" +
//			"'totalCount' value tmp.totalCount,\n" +
//			"'CompletedCount' value tmp.CompletedCount,\n" +
//			"'RejectedCount' value tmp.RejectedCount,\n" +
//			"'transactionFailed' value tmp.transactionFailed,\n" +
//			"'applicationForm' value tmp.applicationForm,\n" +
//			"'ExpiredCount' value tmp.ExpiredCount) from " + DBNameConstant.JNS_USERS + ".user_organisation_master uom \n" +
//			"left join (select am.org_id as orgId,\n" +
////			"        count(am.id) as totalCount,\n" +
//			"   sum(case when am.stage_id in(4,6,8,7,15) then 1 else 0 end) as totalCount ,\n" +
//			"        sum(case when am.stage_id = 6 then 1 else 0 end) AS CompletedCount, \n" +
//			" \t    sum(case when am.stage_id = 8 then 1 else 0 end) AS RejectedCount  , \n" +
//			" \t    sum(case when am.stage_id = 15 then 1 else 0 end) AS transactionFailed  , \n" +
//			" \t    sum(case when am.stage_id = 4 then 1 else 0 end) AS applicationForm  , \n" +
//			"        sum(case when am.stage_id = 7 then 1 else 0 end ) as ExpiredCount \n" +
//			"        FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am " + whereClause + " group by am.org_id  order by totalCount desc ) tmp on tmp.orgId = uom.user_org_id \n" +
//			"WHERE uom.is_active = 1 and uom.user_type_id = 2";
//
////	System.err.println(query);
////	log.info("Query ======> {}",query);
//	List<Object> list = adminRepository.fetchListOfDataFromDb(query);
//	return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
//			OPLUtils.isListNullOrEmpty(list) ? null : list.toString(), HttpStatus.OK.value(), Boolean.TRUE);


    @SuppressWarnings("unchecked")
    @Override
    public CommonResponse fetchAppOrgIdwiseCount(String request, AuthClientResponse authClientResponse) {
        try {

//			JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//			Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
//			Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
//			String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
//			String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : new Date().toString();
//
//			String whereClause = " WHERE am.stage_id IS NOT NULL";
//
//			if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
//				whereClause += " AND am.org_id = " + orgId;
//			}
//			if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
//				whereClause += " AND am.scheme_id = " + schemeId;
//			}
//			if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
//				whereClause += " AND am.status_change_date between to_timestamp('" + fromDate + "') and to_timestamp('"
//						+ toDate + "') ";
//			} else if (!OPLUtils.isObjectNullOrEmpty(fromDate)) {
//				whereClause += " AND am.status_change_date = to_timestamp('" + fromDate + "') ";
//			}
//
//			String selectQuery = "select JSON_OBJECT("
//					+ " 'channelId' value case \r\n"
//					+ "    when (amod.channel_id is null and amod.source=2) then 'Bank Assisted Mode' \r\n"
//					+ "    when (amod.channel_id is null and amod.source=1) then 'Other Channel' else amod.channel_id end,\n"
//					+ "	                        'schemeId' value  amod.scheme_id, \n "
//					+ "	                        'totalCount' value count(am.id), \n "
//					+ "	                        'CompletedCount' value sum(case when am.stage_id = 6 then 1 else 0 end), \n "
//					+ "	                        'RejectedCount' value sum(case when am.stage_id = 8 then 1 else 0 end) , \n "
//					+ "	                        'transactionFailed' value sum(case when am.stage_id = 15 then 1 else 0 end) , \n "
//					+ "	                        'applicationForm' value sum(case when am.stage_id = 4 then 1 else 0 end) , \n "
//					+ "	                        'ExpiredCount' value sum(case when am.stage_id = 7 then 1 else 0 end ) \n) ";
//
////			String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master_other_details amod INNER JOIN "
////					+ DBNameConstant.JNS_INSURANCE + ".application_master am  on am.org_id = amod.org_id and am.id = amod.application_master_id";
//
//			String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am Left JOIN "
//					+ DBNameConstant.JNS_INSURANCE + ".application_master_other_details amod on am.org_id = amod.org_id and am.id = amod.application_master_id ";
//
////			String groupByQuery = " group by amod.channel_id, amod.scheme_id ";
//			String groupByQuery = " group by amod.channel_id, amod.scheme_id ,amod.source";
//
//			String query = selectQuery + tableQuery + whereClause + groupByQuery;
////			System.err.println(query);
////			log.info("Query ======> {}",query);
//			List<Object> list = adminRepository.fetchListOfDataFromDb(query);
//			return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
//					OPLUtils.isListNullOrEmpty(list) ? null : list.toString(), HttpStatus.OK.value(), Boolean.TRUE);
            String completedchannel = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_COMPLATED_COUNT_ORGIDWISE");
            String rejectedChannel = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_REJECTED_COUNT_ORGIDWISE");
            String applicationChannel = adminRepository.spFetchAdminEnrollmentList(request,
                    DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_ACCEPTED_COUNT_ORGIDWISE");

            List<CountProxy> countProxyList = new ArrayList<>();
            List<CountProxy> countProxyRejectList = new ArrayList<>();
            List<CountProxy> countProxyAppList = new ArrayList<>();

            if (!OPLUtils.isObjectListNull(completedchannel)) {
                countProxyList = MultipleJSONObjectHelper.getListOfObjects(completedchannel, null,
                        CountProxy.class);
            }

            if (!OPLUtils.isObjectListNull(rejectedChannel)) {
                countProxyRejectList = MultipleJSONObjectHelper.getListOfObjects(rejectedChannel, null,
                        CountProxy.class);
            }

            if (!OPLUtils.isObjectListNull(applicationChannel)) {
                countProxyAppList = MultipleJSONObjectHelper.getListOfObjects(applicationChannel, null,
                        CountProxy.class);
            }

            for (CountProxy proxy : countProxyList) {

                for (CountProxy rjProxy : countProxyRejectList) {
                    if (!OPLUtils.isObjectNullOrEmpty(rjProxy.getChannelId())) {
                        if (proxy.getChannelId().equals(rjProxy.getChannelId())) {
                            proxy.setRejectedCount(rjProxy.getRejectedCount());
                            proxy.setExpiredCount(rjProxy.getExpiredCount());
                            if (!OPLUtils.isObjectNullOrEmpty(rjProxy.getTransactionFailedCount())) {
                                proxy.setTransactionFailedCount(rjProxy.getTransactionFailedCount());
                            } else {
                                proxy.setTransactionFailedCount(0L);
                            }
                        }
                    }
                }

                for (CountProxy appProxy : countProxyAppList) {
                    if (!OPLUtils.isObjectNullOrEmpty(appProxy.getChannelId())) {
                        if (proxy.getChannelId().equals(appProxy.getChannelId())) {
                            proxy.setApplicationForm(appProxy.getApplicationForm());
                            proxy.setTranFailedInprogressCnt(null);
                            if (!OPLUtils.isObjectNullOrEmpty(appProxy.getTranFailedInprogressCnt())) {
                                proxy.setTransactionFailedCount((!OPLUtils.isObjectNullOrEmpty(proxy.getTransactionFailedCount()) ? proxy.getTransactionFailedCount() : 0) +
                                        appProxy.getTranFailedInprogressCnt());
//										proxy.setTransactionFailedCount(proxy.getTransactionFailedCount()
//												+ appProxy.getTranFailedInprogressCnt());
                            }
                        }
                    }
                }

                proxy.setTotalCount((!OPLUtils.isObjectNullOrEmpty(proxy.getCompletedCount()) ? proxy.getCompletedCount() : 0)
                        + (!OPLUtils.isObjectNullOrEmpty(proxy.getRejectedCount()) ? proxy.getRejectedCount() : 0)
                        + (!OPLUtils.isObjectNullOrEmpty(proxy.getExpiredCount()) ? proxy.getExpiredCount() : 0)
                        + (!OPLUtils.isObjectNullOrEmpty(proxy.getTransactionFailedCount()) ? proxy.getTransactionFailedCount() : 0));

            }
            return new CommonResponse(countProxyList, "SuccessFully fetch Enrollment  BankWiseCount",
                    HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get fetch Enrollment  OrgIdwiseCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }


    @Override
    public CommonResponse fetchClaimBankWiseCount(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : new Date().toString();

            String whereClause = " WHERE cm.is_active=1 AND  cm.status IS NOT NULL ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND cm.org_id = " + orgId;
            }

            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereClause += " AND cm.scheme_id = " + schemeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND cm.claim_date between to_timestamp('" + fromDate + "') and to_timestamp('" + toDate + "') ";
            } else if (!OPLUtils.isObjectNullOrEmpty(fromDate)) {
                whereClause += " AND cm.claim_date = to_timestamp('" + fromDate + "') ";
            }


//			String totalCountSelectQuery = "select JSON_OBJECT('orgId' value cm.org_id ,\n"
//					+ "	                         'orgName' value uom.ORGANISATION_NAME, \n "
//					+ "	                         'totalCount' value count(cm.id), \n "
//					+ "	                         'AccpetedCount' value sum(case when cm.claim_status = 10 then 1 else 0 end),  \n "
//					+ "	                         'OnHoldCount' value sum(case when cm.claim_status = 9 then 1 else 0 end)  , \n "
//					+ "	                           'RejectedCount' value sum(case when cm.claim_status = 8 then 1 else 0 end) , \n "
//					+ "	                          'SendBackToBnakCount' value sum(case when cm.claim_status = 7 then 1 else 0 end) \n) ";
//
//			String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".claim_master cm LEFT JOIN  "
//					+ DBNameConstant.JNS_USERS + ".user_organisation_master uom ON uom.user_org_id = cm.org_id";
//
//			String GroupByQuery = " group by cm.org_id,uom.ORGANISATION_NAME";

            String query = "select JSON_OBJECT('orgId' value uom.org_id ,\n" +
                    "'orgName' value uom.ORGANISATION_NAME,\n" +
                    "'totalCount' value tmp.totalCount,\n" +
                    "'AccpetedCount' value tmp.AccpetedCount,\n" +
                    "'OnHoldCount' value tmp.OnHoldCount,\n" +
                    "'RejectedCount' value tmp.RejectedCount,\n" +
                    "'SendToInsurerCount' value tmp.SendToInsurerCount,\n" +
                    "'SendBackToBnakCount' value tmp.SendBackToBnakCount) " +
                    " FROM " + DBNameConstant.JNS_CONFIG + ".user_organisation_master uom \n" +
                    "left join (select cm.org_id as orgId,\n" +
                    "       sum(case when cm.status in(5,6,7,8,9,10) then 1 else 0 end) as totalCount ,\n" +
                    "       sum(case when cm.status = 5 then 1 else 0 end) AS InProgressCount, \n" +
                    " \t    sum(case when cm.status = 6 then 1 else 0 end) AS SendToInsurerCount  , \n" +
                    " \t    sum(case when cm.status = 7 then 1 else 0 end) AS SendBackToBnakCount  , \n" +
                    " \t    sum(case when cm.status = 8 then 1 else 0 end) AS RejectedCount,  \n" +
                    " \t    sum(case when cm.status = 9 then 1 else 0 end) AS OnHoldCount,  \n" +
                    " \t    sum(case when cm.status = 10 then 1 else 0 end) AS AccpetedCount  \n" +
                    "        FROM " + DBNameConstant.JNS_INSURANCE + ".clm_master cm " + whereClause +
                    " group by cm.org_id order by totalCount desc ) tmp on tmp.orgId = uom.org_id \n" +
                    " WHERE uom.is_active = 1 and uom.user_type_id = 2";

// 			System.err.println(query);
//			log.info("Query ======> {}",query);
//			String query = totalCountSelectQuery + tableQuery + whereClause + GroupByQuery;
            List<Object> list = adminRepository.fetchListOfDataFromDb(query);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    OPLUtils.isListNullOrEmpty(list) ? null : list.toString(), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get fetch Claim  BankWiseCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());

    }

    @Override
    public CommonResponse fetchclaimOrgIdwiseCount(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : new Date().toString();

//			String whereClause = null;
            String whereClause = " WHERE cm.claim_status IS NOT NULL";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND amod.org_id = " + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND cm.claim_date between to_timestamp('" + fromDate + "') and to_timestamp('" + toDate
                        + "') ";
            } else if (!OPLUtils.isObjectNullOrEmpty(fromDate)) {
                whereClause += " AND cm.status_change_date = to_timestamp('" + fromDate + "') ";
            }
//			whereClause =  whereClause + " AND  amod.channel_id is not null ";

//			String totalCountSelectQuery = "select JSON_OBJECT( 'channelId' value amod.channel_id ,\n"
//					+ "	                        'schemeId' value  amod.scheme_id, \n "
//					+ "	                         'totalCount' value count(cm.id), \n "
//					+ "	                         'AccpetedCount' value sum(case when cm.claim_status = 10 then 1 else 0 end),  \n "
//					+ "	                         'OnHoldCount' value sum(case when cm.claim_status = 9 then 1 else 0 end)  , \n "
//					+ "	                           'RejectedCount' value sum(case when cm.claim_status = 8 then 1 else 0 end) , \n "
//					+ "	                          'SendBackToBnakCount' value sum(case when cm.claim_status = 7 then 1 else 0 end) \n) ";

            String totalCountSelectQuery = "select JSON_OBJECT("
                    + " 'channelId' value case \r\n"
                    + "    when (amod.channel_id is null and amod.source=2) then 'Bank Assisted Mode' \r\n"
                    + "    when (amod.channel_id is null and amod.source=1) then 'Other Channel' else amod.channel_id end,\n"
                    + "	                        'schemeId' value  amod.scheme_id, \n "
                    + "	                        'totalCount' value  sum(case when cm.claim_status in(6,7,8,9,10) then 1 else 0 end), \n "
                    + "	                        'AccpetedCount' value sum(case when cm.claim_status = 10 then 1 else 0 end), \n "
                    + "	                        'OnHoldCount' value sum(case when cm.claim_status = 9 then 1 else 0 end) , \n "
                    + "	                        'RejectedCount' value sum(case when cm.claim_status = 8 then 1 else 0 end) , \n "
                    + "	                        'SendToInsurerCount' value sum(case when cm.claim_status = 6 then 1 else 0 end) , \n "
                    + "	                        'SendBackToBnakCount' value sum(case when cm.claim_status = 7 then 1 else 0 end ) \n) ";

            String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master_other_details amod INNER JOIN "
                    + DBNameConstant.JNS_INSURANCE + ".claim_master cm  on cm.org_id = amod.org_id and cm.application_id " + "= amod.application_master_id";

//			String GroupByQuery = " group by amod.channel_id, amod.scheme_id ";
            String GroupByQuery = " group by amod.channel_id, amod.scheme_id ,amod.source";

//			System.err.println(totalCountSelectQuery + tableQuery + whereClause + GroupByQuery);
            String query = totalCountSelectQuery + tableQuery + whereClause + GroupByQuery;
//			log.info("Query ======> {}",query);
            List<Object> list = adminRepository.fetchListOfDataFromDb(query);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    OPLUtils.isListNullOrEmpty(list) ? null : list.toString(), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get fetch Enrollment  OrgIdwiseCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());

    }

    @Override
    public CommonResponse getDocumentListByAppId(String request) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Long applicationId = filterJSON.has("applicationId") ? filterJSON.get("applicationId").asLong() : null;
            Long claimId = filterJSON.has("claimId") ? filterJSON.get("claimId").asLong() : null;

            String whereClause = " WHERE is_active=1 ";
            ;
            if (!OPLUtils.isObjectNullOrEmpty(applicationId)) {
                whereClause = whereClause + " AND application_id = " + applicationId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(applicationId)) {
                whereClause = whereClause + " AND claim_id = " + claimId;
            }

            String totalCountSelectQuery = "select JSON_OBJECT( 'id' value id ,\n"
                    + "	                        'documentId' value  document_id, \n "
                    + "	                         'docuName' value doc_name, \n "
                    + "	                         'fileName' value original_file_name \n ) ";

            String tableQuery = " FROM " + DBNameConstant.JNS_DMS + ".product_storage_details ";
//			System.err.println(totalCountSelectQuery + tableQuery + whereClause );
            String query = totalCountSelectQuery + tableQuery + whereClause;
            List<Object> list = adminRepository.fetchListOfDataFromDb(query);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    OPLUtils.isListNullOrEmpty(list) ? null : list.toString(), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get Document List ByAppId  ", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse getDocumentListByCliamRefId(String request) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Long claimRefId = filterJSON.has("claimRefId") ? filterJSON.get("claimRefId").asLong() : null;

            String whereClause = " WHERE is_active=1 ";

            if (!OPLUtils.isObjectNullOrEmpty(claimRefId)) {
                whereClause = whereClause + " AND claim_id = " + claimRefId;
            }

            String totalCountSelectQuery = "select JSON_OBJECT( 'id' value id ,\n"
                    + "	                        'masterId' value  master_id, \n "
                    + "	                         'docType' value document_type \n ) ";

            String tableQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".claim_docs ";

            System.err.println(totalCountSelectQuery + tableQuery + whereClause);

            String query = totalCountSelectQuery + tableQuery + whereClause;
            List<Object> list = adminRepository.fetchListOfDataFromDb(query);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, OPLUtils.isListNullOrEmpty(list) ? null : list.toString(),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is while get Document List BY CliamRefId", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());

    }

    @Override
    public String getUsernameAndApiKey() {
        return adminRepository.getUsernameAndApiKey();
    }

    @Override
    public CommonResponse spFetchAdminEnrollmentList(String request) {
        try {
            String spName = DBNameConstant.JNS_ADMIN_PANEL + ".FETCH_ADMIN_ENROLLMENT_LIST";
            return new CommonResponse(adminRepository.spFetchAdminEnrollmentList(request, spName), "SuccessFully get Admin Enrollment List", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Admin Enrollment List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }


    @Override
    public CommonResponse fetchOrgWiseData(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode jsonNode = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(jsonNode.get("filterJSON").asText(), JsonNode.class);
            Long state = filterJSON.has("stateId") ? filterJSON.get("stateId").asLong() : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;

            String whereClause = "where 1=1";

            if (!OPLUtils.isObjectNullOrEmpty(state)) {
                whereClause += " AND  p.state IN(" + state + ")";
            }

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND TRUNC(p.enroll_date) BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            String insideSelectQuery = "select sum(pmsby_a_total) as pmsbyCount,sum(pmjjby_a_total) as pmjjbyCount, max(org_id) as orgId from jns_reports.policy p "
                    + whereClause + " group by p.org_id";

            String selectQuery = "select JSON_ARRAYAGG(JSON_OBJECT('orgName' VALUE uom.DISPLAY_ORG_NAME, 'pmsbyCount' VALUE pt.pmsbyCount, 'pmjjbyCount' VALUE pt.pmjjbyCount RETURNING CLOB) RETURNING CLOB)";

            String tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".USER_ORGANISATION_MASTER uom "
                    + "LEFT JOIN (" + insideSelectQuery + ") pt on pt.orgId = uom.user_org_id "
                    + " where uom.user_type_id = 2";

            String str = adminRepository.spOtherUserList(selectQuery + tableQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }


    @Override
    public CommonResponse fetchInsurerWiseData(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode jsonNode = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(jsonNode.get("filterJSON").asText(), JsonNode.class);


            Long state = filterJSON.has("stateId") ? filterJSON.get("stateId").asLong() : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;

            String whereClause = "";

            if (!OPLUtils.isObjectNullOrEmpty(state)) {
                whereClause += " AND  p.state IN(" + state + ")";
            }

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND TRUNC(p.enroll_date) BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            String insideTableQuery = " from jns_reports.policy p";
//        String insideGroupByQuery = " group by PMJJBY_INSURER_ORG ";
            String insideSelectQuery = "select sum(tmp.pmsbycount) as pmsbyCount, sum(tmp.pmjjbycount) as pmjjbycount, max(tmp.orgid) as orgId from (\n" +
                    " select 0 as pmsbycount, sum(pmjjby_a_total) as pmjjbyCount, PMJJBY_INSURER_ORG as orgid " +
                    insideTableQuery +
                    " where PMJJBY_INSURER_ORG is not null" +
                    whereClause +
                    " group by PMJJBY_INSURER_ORG " +
                    " union all\n" +
                    " select sum(pmsby_a_total) as pmsbyCount, 0 as pmjjbyCount, PMSBY_INSURER_ORG as orgid" +
                    insideTableQuery +
                    " where PMSBY_INSURER_ORG is not null" +
                    whereClause +
                    " group by PMSBY_INSURER_ORG" + ")";

            String selectQuery = "select JSON_ARRAYAGG(JSON_OBJECT('orgName' VALUE uom.DISPLAY_ORG_NAME, 'pmsbyCount' VALUE pt.pmsbyCount, 'pmjjbyCount' VALUE pt.pmjjbyCount RETURNING CLOB) RETURNING CLOB) ";

            String tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".USER_ORGANISATION_MASTER uom "
                    + "LEFT JOIN (" + insideSelectQuery + " tmp group by tmp.orgid) pt on pt.orgId = uom.user_org_id "
                    + " where uom.user_type_id = 6";

//		System.out.println(selectQuery + tableQuery);
            String str = adminRepository.spOtherUserList(selectQuery + tableQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Override
    public CommonResponse spFetchEnrollmentCount(String request, Long userId) {
        try {
            JsonNode jsonNode = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(jsonNode.get("filterJSON").asText(), JsonNode.class);
            Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
//			Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
            String fromDate = filterJSON.has("fromDate") ? filterJSON.get("fromDate").asText() : null;
            String toDate = filterJSON.has("toDate") ? filterJSON.get("toDate").asText() : null;

            String whereClause = " WHERE am.SOURCE != 3 AND am.is_active = 1 ";

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND TRUNC(am.status_change_date) BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            whereClause += " AND" + (!OPLUtils.isObjectNullOrEmpty(orgId) ? " am.org_id = " + orgId : " 1=2");

            String selectQuery = "  as schemeId, am.SOURCE, count(am.ID) as applicationCount, am.channel_id as channel ";

//            String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am " +
//                    "inner join " + DBNameConstant.JNS_INSURANCE + ".application_master_other_details amod on amod.APPLICATION_MASTER_Id= am.id";

            String groupBy = " GROUP BY am.SOURCE, am.CHANNEL_ID ";

            String innQuery = "SELECT inn.schemeId as schemeId, SUM(inn.applicationCount) as applicationCount, " +
                    "(CASE WHEN (inn.SOURCE = 2) THEN 'Portal Journey' " +
                    "WHEN (inn.SOURCE = 4) THEN 'DIY Journey' " +
                    "WHEN (inn.SOURCE = 1) THEN dv.VALUE ELSE NULL END) AS channel FROM (" +
                        "SELECT 1" + selectQuery + " FROM JNS_MASTER.PMSBY am " + whereClause + groupBy +
                        " UNION ALL " +
                        " SELECT 2" + selectQuery + " FROM JNS_MASTER.PMJJBY am " + whereClause + groupBy +
                    " ) inn LEFT JOIN JNS_ONEFORM.DROPDOWNS_VALUES dv ON dv.OBJ_ID = inn.channel AND  dv.DROPDOWN_ID = 18  " +
                    " GROUP BY inn.channel, inn.SOURCE, dv.VALUE, inn.schemeId, inn.applicationCount";

            String query = " SELECT JSON_ARRAYAGG(JSON_OBJECT('pmsbyCount' value SUM(CASE WHEN tmp.schemeId = 1 THEN tmp.applicationCount ELSE 0 END), "
                    + "   'pmjjbyCount' value SUM(CASE WHEN tmp.schemeId = 2 THEN tmp.applicationCount ELSE 0 END),"
                    + "   'channel' value tmp.channel ) RETURNING CLOB) FROM ( " + innQuery + " ) tmp GROUP BY tmp.channel";
//			System.err.println(query);
            return new CommonResponse(adminRepository.spOtherUserList(query), "SuccessFully get Admin Enrollment List",
                    HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while get Admin Enrollment List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

//	@Scheduled(cron = "0 5 0 ? * *")
//	public void getCountReportOrgWise() {
//		try {
//			log.info("START GET REPORT ORG WISE SCHEDULER------------------");
//			CommonResponse commonRes = getReportOrgWise(null);
//			log.info("END GET REPORT ORG WISE SCHEDULER------------------");
//		} catch (Exception e) {
//			log.error("Error while calling getCountReportOrgWise()",e);
//		}
//	}

//	@Override
//	public CommonResponse getReportOrgWise(String request) {
//		try {
//			log.info("START GET REPORT ORG WISE METHOD ---------------->");
//			CommonResponse commonRes = getCountForOrgWiseData(request);
//			if(commonRes.getFlag().equals(Boolean.TRUE) && commonRes.getStatus() == HttpStatus.OK.value() && !OPLUtils.isObjectNullOrEmpty(commonRes.getData())) {
//				String email = properties.getValueByCode("EMAIL_LIST_FOR_ORG_WISE_COUNT");
//				String[] emailList = email.split(",");
//				Boolean emailFlag = sendEmail(emailList,commonRes.getData());
//				if (emailFlag.equals(Boolean.TRUE)) {
//			        return new CommonResponse(EMAIL_SENT_SUCCESSFULLY, HttpStatus.OK.value(), Boolean.TRUE);
//				}
//			}
//			return new CommonResponse(INTERNAL_SERVER_ERROR, HttpStatus.OK.value(), Boolean.FALSE);
//		} catch (Exception e) {
//			log.error("EXCEPTION IN getReportOrgWise()  ---------------->",e);
//		}
//		return new CommonResponse(INTERNAL_SERVER_ERROR, HttpStatus.OK.value(), Boolean.FALSE);
//
//	}
//	private Boolean sendEmail(String[] to,Object orgWiseData) {
//		try {
//			log.info("START SENDEMAIL METHOD() ------------------>");
//			List<Object> orgList = MultipleJSONObjectHelper.getListOfObjects(orgWiseData.toString(), null, Object.class);
//
//			NotificationRequest notificationRequest = new NotificationRequest();
//			Map<String, Object> emailParameters = new HashMap<>();
//			emailParameters.put("orgList",orgList);
//			notificationRequest.setClientRefId("99799");
//			Notification notification = new Notification();
//			notification.setMasterId(11l);
//			notification.setContentType(ContentType.TEMPLATE);
//			notification.setTemplateId(13l);
//			notification.setTo(to);
//			notification.setType(NotificationType.EMAIL);
//			notification.setParameters(emailParameters);
//			notificationRequest.addNotification(notification);
//			try {
//				NotificationResponse res = notificationClient.send(notificationRequest);
//				if(res.getStatus()==HttpStatus.OK.value()) {
//					log.info("REPORT FOR ORG WISE COUNT SENT SUCCESSFULLY ------------>");
//					return true;
//				}
//				log.info("REPORT NOT SENT FOR ORG WISE COUNT---------->");
//			} catch (NotificationException e) {
//				log.error("Error while send notifications ", e);
//			}
//		} catch (Exception e) {
//			log.error("Error while calling sendEmail()",e);
//		}
//		return false;
//	}

    public CommonResponse getCountForOrgWiseData(String request) {
        Long state = null;
        String fromDate = null;
        String toDate = null;
        if (request != null) {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            state = filterJSON.has("stateId") ? filterJSON.get("stateId").asLong() : null;
            fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;

        }
        String whereClause = "where 1=1";

        if (!OPLUtils.isObjectNullOrEmpty(state)) {
            whereClause += " AND  p.state IN(" + state + ")";
        }

        if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
            whereClause += " AND TRUNC(p.enroll_date) BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
        }

        String insideSelectQuery = " select tmpCount.*, pmsbyUom.DISPLAY_ORG_NAME as pmsbyInsurerOrg,pmjjbyUom.DISPLAY_ORG_NAME as pmjjbyInsurerOrg from ( select sum(pmsby_a_total) as pmsbyCount,sum(pmjjby_a_total) as pmjjbyCount,sum(a_total) as totalCount, max(org_id) as orgId,max(p.PMSBY_INSURER_ORG) as pmsbyInsurerOrgId, max(p.PMJJBY_INSURER_ORG) as pmjjbyInsurerOrgId,max(p.enroll_date) as lastUpdatedDate from jns_reports.policy p "
                + whereClause + " group by p.org_id ) tmpCount \n"
                + "LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER pmsbyUom on pmsbyUom.user_org_id = tmpCount.pmsbyInsurerOrgId\n"
                + "LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER pmjjbyUom on pmjjbyUom.user_org_id = tmpCount.pmjjbyInsurerOrgId";

        String selectQuery = "select JSON_ARRAYAGG(JSON_OBJECT('orgName' VALUE uom.DISPLAY_ORG_NAME, 'pmsbyCount' VALUE pt.pmsbyCount, 'pmjjbyCount' VALUE pt.pmjjbyCount,'pmsbyInsurerOrg' VALUE pt.pmsbyInsurerOrg,'pmjjbyInsurerOrg' VALUE pt.pmjjbyInsurerOrg, 'totalCount' VALUE pt.totalCount,'lastUpdatedDate' VALUE TO_char(pt.lastUpdatedDate,'DD-MM-YYYY')) RETURNING CLOB)";

        String tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".USER_ORGANISATION_MASTER uom "
                + "LEFT JOIN (" + insideSelectQuery + ") pt on pt.orgId = uom.user_org_id "
                + " where uom.user_type_id = 2";

        String str = adminRepository.spOtherUserList(selectQuery + tableQuery);
        return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str, HttpStatus.OK.value(), Boolean.TRUE);
    }

    @Override
    public CommonResponse fetchCoiPushAllCounts(String request, Long userId) {

        try {
//	         String spName = DBNameConstant.JNS_ADMIN_PANEL +".FETCH_COI_PUSH_ALL_COUNTS";
//	         String spFetchAdminEnrollmentList = adminRepository.spFetchAdminEnrollmentList(request,spName);
//	         Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(spFetchAdminEnrollmentList);
//	            return new CommonResponse(mapFromString, "SuccessFully get fetchCoiPushAllCounts List", HttpStatus.OK.value());
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String whereClause = " where 1=1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND am.org_id = " + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereClause += " AND am.scheme_id = " + schemeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
//		        	whereClause += " AND am.completion_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and " + " to_timestamp('" + toDate + "')  ";
                whereClause += " AND am.completion_date BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            String tableQuery = " from " + DBNameConstant.JNS_INSURANCE + ".application_push_status ap \r\n"
                    + "Inner join " + DBNameConstant.JNS_INSURANCE + ".application_master am on am.id = ap.id";

            String mainQuery = "select json_object('totalCount'value count(ap.id),\n"
//			 	String mainQuery="select json_object('totalCount'value (sum(ap.master_push) + sum(ap.bank_push) \r\n"
//			 			+ "                                        +sum(ap.insurer_push) + sum(ap.bank_opt_out_push)+sum(ap.insurer_opt_out_push)\r\n"
//			 			+ "                                        +sum(ap.bank_nmn_dtls_push) + sum(ap.insurer_nmn_dtls_push) ),\n"
                    + "'masterPush' value sum(ap.master_push),\n"
                    + "'bankPush' value sum(ap.bank_push),\n"
                    + "'insuerePush' value sum(ap.insurer_push),\n"
                    + "'bankOptOutPush' value sum(ap.bank_opt_out_push),\n"
                    + "'insurerOptOutPush' value sum(ap.insurer_opt_out_push),\n"
                    + "'bankNmnDetailsPush' value sum(ap.bank_nmn_dtls_push),\n"
                    + "'insurerNmnDetailsPush' value sum (ap.insurer_nmn_dtls_push) )" + tableQuery + whereClause;
            System.out.println(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchCount(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while fetchCoiPushAllCounts List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchNotificationList(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            String searchData = filterJSON.has(SEARCHDATA_LITERAL) ? filterJSON.get(SEARCHDATA_LITERAL).asText() : null;
            String typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asText() : null;
            Long notificationType = filterJSON.has(NOTIFICATION_TYPE) ? filterJSON.get(NOTIFICATION_TYPE).asLong() : null;
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL) ? filterJSON.get(PAGINATIONFROM_LITERAL).asText() : null;
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText() : null;

            String whereClause = " where nl.status_code = 200 ";

            if (!OPLUtils.isObjectNullOrEmpty(typeId)) {
                if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                    if (typeId.equals("1")) {
                        whereClause = whereClause
                                + " AND nl.to_id LIKE '%" + searchData + "%'";
                    }
                    if (typeId.equals("2")) {
                        whereClause = whereClause
                                + " AND pa.storage_id LIKE '%" + searchData + "%'";
                    }
                }

            }
            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND nl.created_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and " + " to_timestamp('" + toDate + "')+1 ";
            }
            if (!OPLUtils.isObjectNullOrEmpty(notificationType)) {
                whereClause += " AND nl.notification_type_id =  " + notificationType;
            }

            String orderByQuery = " order by nl.created_date desc";

            String selctQuery = "select nl.to_id as toId,(case when nl.notification_type_id = 1 then 'EMAIL' else 'SMS' end) as type1,nes.subject as subject,pa.storage_id as storageId, np.provider_name as provider\r\n";

            String tableQuery = " from jns_notification.notification_logs nl \r\n"
                    + "LEFT JOIN jns_notification.notification_email_subject nes on nes.subject_id = nl.subject_id \r\n"
                    + "LEFT join jns_notification.payload_audit pa on pa.log_audit_id = nl.id \r\n"
                    + "LEFT join jns_notification.notification_provider np on np.id = nl.provider_id";

            String mainCountQuery = "select json_object('TotalCount'value count(nl.id)) " + tableQuery + whereClause;
            String str = adminRepository.fetchCount(mainCountQuery);

            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTAL_COUNT_LITERAL) ? json.get(TOTAL_COUNT_LITERAL).asInt() : 0;
            String limit = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";

            String selectQuery = "select JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + ",'to' value toId,'type' value type1,'subject' value subject,'storageId' value storageId,'provider' value provider )returning clob) from (";
            String mainQuery = selectQuery + selctQuery + tableQuery + whereClause + orderByQuery + limit;
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while fetchNotificationList List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @SuppressWarnings("unchecked")
    @Override
    public CommonResponse fetchOrgAndInsuranceWiseCount(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            int typeId = filterJSON.has(TYPEID_LITERAL) ? filterJSON.get(TYPEID_LITERAL).asInt() : null;

            String whereClause = " WHERE APPLICATION_STATUS = 2 AND IS_ACTIVE = 1 ";
            String groupByQuery = " GROUP BY ORG_ID, SCHEME_ID, INSURER_ORG_ID ";

            String dbName = "";
            String dateKey = "";
            if (!OPLUtils.isObjectNullOrEmpty(typeId)) {
                if (typeId == 1) {
                    dbName = DBNameConstant.JNS_INSURANCE;
                    whereClause += " AND STAGE_ID = 6 ";
                    dateKey = "STATUS_CHANGE_DATE";
                } else if (typeId == 2) {
                    dbName = DBNameConstant.JNS_PUBLISH_API;
                    dateKey = "PUSH_READY_DATE";
                }
            }
            String selectQuery = " SELECT ORG_ID AS org, SCHEME_ID AS schemeId, INSURER_ORG_ID AS insurerOrgId, COUNT(ORG_ID) AS totalCount, '" + dbName + "' AS dbName ";
            String tableQuery = " FROM " + dbName + ".APPLICATION_MASTER am  ";

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " AND " + dateKey + " BETWEEN to_timestamp('" + fromDate + "') and to_timestamp('" + toDate + "') ";
            }

            String outerQuery = " SELECT obj.dbName, uom.DISPLAY_ORG_NAME AS orgName, sm.SHORT_NAME AS schemeName, uomins.DISPLAY_ORG_NAME AS insName, obj.totalCount FROM (" + selectQuery + tableQuery + whereClause + groupByQuery + ")  obj INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = obj.org INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.id = obj.schemeId LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER uomins ON uomins.USER_ORG_ID = obj.insurerOrgId ORDER BY obj.dbName, obj.org, obj.schemeId ";
            String mainQuery = " SELECT JSON_ARRAYAGG(JSON_OBJECT('dbName' value tmp.dbName, 'orgName' value tmp.orgName, 'schemeName' value tmp.schemeName, 'insName' value tmp.insName, 'totalCount' value tmp.totalCount RETURNING CLOB) RETURNING CLOB) FROM (" + outerQuery + " ) tmp ";

            System.err.println(mainQuery);
            String resData = adminRepository.executeNativeQuery(mainQuery);
            List<Map<String, Object>> mapFromString = null;
            if (!OPLUtils.isObjectNullOrEmpty(resData)) {
                mapFromString = MultipleJSONObjectHelper.getListOfObjects(resData, null, Map.class);
            }
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, mapFromString, HttpStatus.OK.value(),
                    Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while fetchOrgAndInsuranceWiseCount List", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchApiAuditDetailList(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
            String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
            String fromDate = filterJSON.has("fromDate") ? filterJSON.get("fromDate").asText() : null;
            String toDate = filterJSON.has("toDate") ? filterJSON.get("toDate").asText() : new Date().toString();
            Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
            Long type = filterJSON.has("type") ? filterJSON.get("type").asLong() : null;
            Long searchTypeId = filterJSON.has("searchTypeId") ? filterJSON.get("searchTypeId").asLong() : null;
            String requrl = filterJSON.has("requrl") ? filterJSON.get("requrl").asText() : null;

            String whereClause = " WHERE rl.org_id = " + orgId;

            if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                if (searchTypeId == 1) {
                    whereClause += " AND  rl.id =  '" + searchData + "'  ";
                } else if (searchTypeId == 3) {
                    whereClause += " AND rl.request_token =   '" + searchData + "'  ";
                } else if (searchTypeId == 4) {
                    whereClause += " AND rl.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + searchData + "')";
                } else if (searchTypeId == 5) {
                    whereClause += " AND rl.cif = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + searchData + "')";
                } else if (searchTypeId == 6) {
                    whereClause += " AND  rl.urn =  '" + searchData + "'  ";
                } else if (searchTypeId == 7) {
                    whereClause += " AND rl.req_ref_num =   '" + searchData + "'  ";
                }
            }

            if (requrl != null) {
                whereClause += " AND rl.request_url = '" + requrl + "' ";
            }

            String dbname = null;
            if (type == 1) {
                dbname = DBNameConstant.JNS_PUBLISH_API;
//        	  whereClause= whereClause+" and rl.request_url not in ("+ " '/api/jns/publish/fetchPublishApiAuditDetailList' " +")";
                whereClause += " and rl.request_url not in  (" + AUDIT_API + "," + APP_API + "," + CLIAM_API + "," + GET_APP_API + "," + GET_CLIAM_API + " )";
            } else {
                dbname = DBNameConstant.JNS_REGISTRY_API;
            }

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause = whereClause + " and rl.created_date between to_timestamp('" + fromDate + "') and to_timestamp('" + toDate + "') ";
            }

//			String Query1 = " select value from nls_session_parameters where parameter='NLS_TIMESTAMP_FORMAT'";

            String totalCountSelectQuery = "select (json_object('totalCount' value count(rl.id))) ";

            String joinTableQuery = " rl INNER JOIN " + DBNameConstant.JNS_CONFIG + ".api_users api ON api.org_id = rl.org_id AND api.id = rl.api_user_id ";
            String newTableQuery = " FROM " + dbname + ".API_LOGS_DEC " + joinTableQuery;

            String orderByQuery = " order by rl.created_date desc";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";

            System.err.println(totalCountSelectQuery + newTableQuery + whereClause);
            String str = adminRepository.fetchCount(totalCountSelectQuery + newTableQuery + whereClause);
            boolean isNewTable = true;
            String oldTableQuery = "";
            if (Integer.valueOf(MultipleJSONObjectHelper.getMapFromString(str).get("totalCount").toString()) == 0 && (OPLUtils.isObjectNullOrEmpty(searchData) || searchTypeId != 3)) {
                oldTableQuery = " FROM " + dbname + ".API_LOGS_DEC_OLD_MAY " + joinTableQuery;
                str = adminRepository.fetchCount(totalCountSelectQuery + oldTableQuery + whereClause);
                isNewTable = false;
            }
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String selectQuery = "SELECT \n"
                    + "                           rl.id as id,\n"
                    + "                           rl.application_reference_id as applicationReferenceId ,\n"
                    + "                           rl.request_url  as requestUrl,\n"
                    + "                           rl.request_ip as requestIp,\n"
                    + "                           rl.response_status as responseStatus,\n"
                    + "                           rl.created_date as date1,\n"
                    + "                           rl.req_ref_num as reqRefNum,\n"
                    + "                           jns_users.\"decvalue\"(rl.account_number) as accountNumber,\n"
                    + "                           jns_users.\"decvalue\"(rl.cif) as cif,\n"
                    + "                           rl.urn as urn,\n"
                    + "                           (rl.RESPONSE_TIME/1000) as responseTime,\n"
                    + "                           api.org_name as orgName,\n"
                    + "                           api.org_id as orgId,\n";

            if (isNewTable) {
                selectQuery += " rl.request_token as token ";
            } else {
                selectQuery += " rl.token as token ";
            }

            String selectsQuery = "SELECT json_arrayagg(json_object( \n"
                    + "                           'totalCount'  value " + totalCount + " ,"
                    + "                           'id' value id,\n"
                    + "                           'applicationReferenceId' value applicationReferenceId,\n"
                    + "                           'requestUrl' value requestUrl,\n"
                    + "                           'requestIp' value requestIp,\n"
                    + "                           'accountNumber' value accountNumber,\n"
                    + "                           'cif' value cif,\n"
                    + "                           'urn' value urn,\n"
                    + "                           'responseStatus' value responseStatus,\n"
                    + "                           'token' value token,\n"
                    + "                           'date1' value date1,\n"
                    + "                           'reqRefNum' value reqRefNum,\n"
                    + "                           'responseTime' value responseTime , \n"
                    + "                           'orgName' value orgName , \n"
                    + "                           'orgId' value orgId returning clob ) RETURNING CLOB ) from (";

            String mainQuery = selectsQuery + selectQuery + (isNewTable ? newTableQuery : oldTableQuery) + whereClause + orderByQuery + limitQuery;
            System.err.println(mainQuery);
            return new CommonResponse("successfully get Data", adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get fetchApiAuditDetailList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    }


    @Override
    public CommonResponse fetchAuditDetails(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
            String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
            String fromDate = filterJSON.has("fromDate") ? filterJSON.get("fromDate").asText() : null;
            String toDate = filterJSON.has("toDate") ? filterJSON.get("toDate").asText() : new Date().toString();
            Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
//			Long type = filterJSON.has("type") ? filterJSON.get("type").asLong() : null;
            Long searchTypeId = filterJSON.has("searchTypeId") ? filterJSON.get("searchTypeId").asLong() : null;
            String requrl = filterJSON.has("requrl") ? filterJSON.get("requrl").asText() : null;

            String whereClause = "where 1=1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND rl.ORG_ID = " + orgId;
            }

            if (!OPLUtils.isObjectNullOrEmpty(searchTypeId)) {
                if (!OPLUtils.isObjectNullOrEmpty(searchData)) {
                    if (searchTypeId == 1) {
                        whereClause += " AND rl.REQ_LOG_ID = " + searchData;
                    } else if (searchTypeId == 3) {
                        whereClause += " AND rl.APPLICATION_ID = " + searchData;
                    } else if (searchTypeId == 4) {
                        whereClause += " AND rl.ACCOUNT_NUMBER = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + searchData + "') ";
                    } else if (searchTypeId == 5) {
                        whereClause += " AND rl.cif = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + searchData + "') ";
                    }
                } else if (searchTypeId == 2 && !OPLUtils.isObjectNullOrEmpty(requrl)) {
                    whereClause += " AND am.url = '" + requrl + "' ";
                }
            }

            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereClause += " and rl.created_date between to_timestamp('" + fromDate + "') and to_timestamp('" + toDate + "') ";
            }

            String totalCountSelectQuery = " select (json_object('totalCount' value count(rl.id))) ";
            String dbname = DBNameConstant.JNS_DD_REGISTRY;
//			String tableQuery = " FROM " + dbname + ".AUDIT_LOG rl " +
//					"INNER JOIN " + dbname + ".api_master am on am.id =rl.api_id " +
//					"INNER JOIN " + DBNameConstant.JNS_USERS + ".user_organisation_master uom on uom.user_org_id=rl.org_id ";

            String joinTableQuery = " rl INNER JOIN " + dbname + ".api_master am on am.id =rl.api_id " +
                    "    INNER JOIN " + DBNameConstant.JNS_USERS + ".user_organisation_master uom on uom.user_org_id=rl.org_id ";
            String newTableQuery = " FROM " + dbname + ".API_LOGS_DEC " + joinTableQuery;

            String orderByQuery = " order by rl.created_date desc";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";

//			String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            System.err.println(totalCountSelectQuery + newTableQuery + whereClause);
            String str = adminRepository.fetchCount(totalCountSelectQuery + newTableQuery + whereClause);
            boolean isNewTable = true;
            String oldTableQuery = "";
            if (Integer.valueOf(MultipleJSONObjectHelper.getMapFromString(str).get("totalCount").toString()) == 0) {
                oldTableQuery = " FROM " + dbname + ".AUDIT_LOG " + joinTableQuery;
                System.err.println(totalCountSelectQuery + oldTableQuery + whereClause);
                str = adminRepository.fetchCount(totalCountSelectQuery + oldTableQuery + whereClause);
                isNewTable = false;
            }
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String selectQuery = "SELECT am.url apiUrl," +
                    "rl.API_ID apiId," +
                    "rl.APPLICATION_ID applicationId," +
                    "rl.CREATED_DATE createdDate," +
                    "rl.IS_ACTIVE isActive," +
                    "rl.ORG_ID orgId," +
                    "uom.organisation_name orgName," +
                    "rl.id id," +
                    DBNameConstant.JNS_USERS + ".\"decvalue\"(rl.account_number) as accountNumber," +
                    DBNameConstant.JNS_USERS + ".\"decvalue\"(rl.cif) as cif," +
                    "rl.RESPONSE_CODE responseCode," +
                    "(rl.RESPONSE_TIME/1000) as responseTime," +
                    "rl.USER_ID userId ";

            String selectsQuery = "SELECT json_arrayagg(json_object( 'totalCount'  value " + totalCount + ", " +
                    "'apiUrl' value apiUrl," +
                    "'apiId' value apiId," +
                    "'applicationId' value applicationId," +
                    "'createdDate' value createdDate," +
                    "'accountNumber' value accountNumber," +
                    "'cif' value cif," +
                    "'isActive' value isActive," +
                    "'orgName' value orgName," +
                    "'orgId' value orgId," +
                    "'id' value id," +
                    "'responseCode' value responseCode," +
                    "'responseTime' value responseTime," +
                    "'userId' value userId returning clob) RETURNING CLOB ) from (";

            String mainQuery = selectsQuery + selectQuery + (isNewTable ? newTableQuery : oldTableQuery) + whereClause + orderByQuery + limitQuery;
            System.err.println(mainQuery);
            return new CommonResponse("successfully get Data", adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get fetchAuditDetails", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());

    }

    @Override
    public CommonResponse updateEnrollmenrData(EnrollmentRequest enrollmentDetails) {
        try {
            ApplicationMasterV3 applicationMaster = applicationMasterRepo
                    .findByIdAndIsActiveTrue(enrollmentDetails.getApplicationId());
            if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
                log.error("Application master details not found by application id -->"
                        + enrollmentDetails.getApplicationId());
                return null;
            }
            ApplicantInfo applicantInfo = applicationMaster.getApplicantInfo();
            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getFirstName())) {
                applicantInfo.setFirstName(enrollmentDetails.getCustomerDetails().getFirstName());
                applicantInfo
                        .setLastName(!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getLastName())
                                ? enrollmentDetails.getCustomerDetails().getLastName()
                                : null);
                applicantInfo.setMiddleName(
                        !OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getMiddleName())
                                ? enrollmentDetails.getCustomerDetails().getMiddleName()
                                : null);
                applicantInfo.setFatherHusbandName(enrollmentDetails.getCustomerDetails().getFatherHusbandName());
                applicantInfo.setIfsc(enrollmentDetails.getOtherDetails().getBranchIFSC());
                applicantInfo.setName(enrollmentDetails.getCustomerDetails().getAccountHolderName());
//				applicantInfo.setDob(
//						DateUtils.parse(enrollmentDetails.getCustomerDetails().getDob(), DateUtils.DateFormat.DD_MM_YYYY));
                applicantInfo.setGenderId(
                        OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getGender()) ? null
                                : Gender.fromBankValue(enrollmentDetails.getCustomerDetails().getGender()).getId());
                applicantInfo.setDisabilityStatus(enrollmentDetails.getCustomerDetails().getDisabilityStatus());
                applicantInfo.setEmail(enrollmentDetails.getCustomerDetails().getEmailId());
                applicantInfo.setCkyc(enrollmentDetails.getKycDetails().getCkyc());
                applicantInfo.setCkycNumber(enrollmentDetails.getKycDetails().getCkycNumber());
                applicantInfo.setKycId1(enrollmentDetails.getKycDetails().getKycId1());
                applicantInfo.setKycIdNumber1(enrollmentDetails.getKycDetails().getKycIdValue1());
                applicantInfo.setKycId2(enrollmentDetails.getKycDetails().getKycId2());
                applicantInfo.setKycIdNumber2(enrollmentDetails.getKycDetails().getKycIdValue2());
                applicantInfo.setPan(enrollmentDetails.getKycDetails().getPanNumber());
                applicantInfo.setAadhaar(enrollmentDetails.getKycDetails().getAadhaarNumber());
                applicantInfo.setIsActive(true);
                applicantInfo.setCreatedDate(new Date());
                applicationMaster.setApplicantInfo(applicantInfo);
//				applicantInfo.setCreatedBy(userId);
            }

            AddressMasterV3 addressMaster = applicationMaster.getApplicantInfo().getAddress();
            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getFirstName())) {
                addressMaster.setAddressLine1(enrollmentDetails.getCustomerDetails().getAddressLine1());
                addressMaster.setAddressLine2(enrollmentDetails.getCustomerDetails().getAddressLine2());
                addressMaster.setCityName(enrollmentDetails.getCustomerDetails().getCity());
                addressMaster.setDistrict(enrollmentDetails.getCustomerDetails().getDistrict());
                addressMaster.setStateName(enrollmentDetails.getCustomerDetails().getState());
                addressMaster.setPincode(Integer.valueOf(enrollmentDetails.getCustomerDetails().getPincode()));
                applicantInfo.setAddress(addressMaster);
            }

            ApplicationMasterOtherDetailsV3 otherDetails = applicationMaster.getApplicationMasterOtherDetails();
            otherDetails.setRuralUrbanSemi(enrollmentDetails.getOtherDetails().getRuralUrban());
            otherDetails.setConsentForAutoDebit(enrollmentDetails.getOtherDetails().getConsentForAutoDebit());
            applicationMaster.setApplicationMasterOtherDetails(otherDetails);


            List<NomineeDetails> nomineeMasters = setNomineeAndGuardianDetails(applicationMaster,
                    enrollmentDetails);
            applicationMaster.setNomineeDetails(nomineeMasters);

            applicationMaster = applicationMasterRepo.save(applicationMaster);

            CommonResponse response = regenerateAndPushCoi(applicationMaster.getId());
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new CommonResponse("Something went wrong RegenerateAndPushCoiapi",
                        HttpStatus.INTERNAL_SERVER_ERROR.value());
            } else {
                Long applicationId = applicationMaster.getId();
                String mainQuery = "select to_timestamp(push_ready_date) from JNS_PUBLISH_API.APPLICATION_MASTER where application_id ="
                        + applicationId + " ";
                Timestamp pushReadyDate = adminRepository.getpushDate(mainQuery);

//				CommonResponse res = updatePushReadyDate(applicationId, pushReadyDate);
                CommonResponse res = updatePushReadyDate(applicationId);
                if (OPLUtils.isObjectNullOrEmpty(res)) {
                    return new CommonResponse("Something went wrong updatePushReadyDate",
                            HttpStatus.INTERNAL_SERVER_ERROR.value());
                } else {
//					String mainQuerys = "Update JNS_PUBLISH_API.APPLICATION_MASTER set push_ready_date = '"
//							+ pushReadyDate + "' where application_id =" + applicationId + " ";
//					adminRepository.updatePublishData(mainQuerys);
                    countRepo.updatePushReadyDateByAppId(applicationId, pushReadyDate);
                }
            }
            return new CommonResponse("successfully Upadted", HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            // TODO: handle exception
            log.error("Exception is getting while get updateEnrollmenrData", e);
        }
        // TODO Auto-generated method stub
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private List<NomineeDetails> setNomineeAndGuardianDetails(ApplicationMasterV3 applicationMaster,
                                                              EnrollmentRequest enrollmentDetails) throws ParseException {

        List<NomineeDetails> nomineeMasters = new ArrayList<>();
        Date curruntDate = new Date();
        /* Guardian */
//		NomineeDetails nomineeGuardian = new NomineeDetails();
        List<NomineeDetails> nomineeGuardianLst = applicationMaster.getNomineeDetails();

        NomineeDetails nomineeGuardian = null;
        nomineeGuardian = nomineeGuardianLst.stream().filter(x -> x.getType() == NomineeType.GUARDIAN.getId())
                .findFirst().orElse(null);
//		Date dob = new SimpleDateFormat(CommonUtils.sdf_dd_MM_yyyy.format)
//				.parse(enrollmentDetails.getNomineeDetails().getDob());
//		Integer ageFromBirthDate = DateUtils.getAgeFromBirthDate(dob);
//		if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails()) && ageFromBirthDate < 18) {
        if (OPLUtils.isObjectNullOrEmpty(nomineeGuardian)) {
            nomineeGuardian = new NomineeDetails();
            nomineeGuardian.setType(NomineeType.GUARDIAN.getId());
        }
        if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails())) {
            nomineeGuardian.setRelationId(
                    OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getRelationShip()) ? null
                            : RelationShip.fromValue(enrollmentDetails.getGuardianDetails().getRelationShip()).getId());
//			BeanUtils.copyProperties(enrollmentDetails.getGuardianDetails(), nomineeGuardian);

//			AddressMasterV3 address = new AddressMasterV3();
            AddressMasterV3 address = null;
            if (OPLUtils.isObjectNullOrEmpty(nomineeGuardian.getAddress())) {
                address = new AddressMasterV3();
            } else {
                address = nomineeGuardian.getAddress();
            }

            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getAddress())) {
                address.setAddressLine1(enrollmentDetails.getGuardianDetails().getAddress());
            }
            address.setCityName(enrollmentDetails.getGuardianDetails().getCity());
            address.setStateName(enrollmentDetails.getGuardianDetails().getState());
            address.setDistrict(enrollmentDetails.getGuardianDetails().getDistrict());
            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getPincode())) {
                try {
                    address.setPincode(Integer.valueOf(enrollmentDetails.getGuardianDetails().getPincode()));
//					PincodeMasterResponse pincodeMaster = oneFormClient
//							.getFirstPincodeMasterDetailsByPincode(enrollmentDetails.getGuardianDetails().getPincode());
//					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
//						address.setCityId(pincodeMaster.getCityId());
//						address.setStateId(pincodeMaster.getStateId());
//					}
                } catch (Exception e) {
                    log.info("Exception while getting pincode details ", e);
                }
            }
            nomineeGuardian.setAddress(address);

            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getFirstName())) {
                StringBuilder s1 = new StringBuilder();
                s1.append(enrollmentDetails.getGuardianDetails().getFirstName()).append(" ");
                if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getMiddleName()))
                    s1.append(enrollmentDetails.getGuardianDetails().getMiddleName()).append(" ");
                if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getGuardianDetails().getLastName()))
                    s1.append(enrollmentDetails.getGuardianDetails().getLastName());
                nomineeGuardian.setName(s1.toString());
            }
            nomineeGuardian.setEmail(enrollmentDetails.getGuardianDetails().getEmail());
            nomineeGuardian.setMobileNumber(enrollmentDetails.getGuardianDetails().getMobile());
            nomineeGuardian.setCreatedDate(curruntDate);
            nomineeGuardian.setIsActive(Boolean.TRUE);
//			nomineeGuardian.setCreatedBy(userId);
            nomineeGuardian.setApplicationMaster(applicationMaster);
            nomineeMasters.add(nomineeGuardian);
        }

        /* Nominee */

        List<NomineeDetails> nomineeDetailsLst = applicationMaster.getNomineeDetails();
        NomineeDetails nomineeDetails = null;
        nomineeDetails = nomineeDetailsLst.stream().filter(x -> x.getType() == NomineeType.NOMINEE.getId()).findFirst()
                .orElse(null);

        if (OPLUtils.isObjectNullOrEmpty(nomineeDetails)) {
            nomineeDetails = new NomineeDetails();
            nomineeDetails.setType(NomineeType.NOMINEE.getId());
        }

        if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails())) {
            nomineeDetails.setRelationId(
                    OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getRelationShip()) ? null
                            : RelationShip.fromValue(enrollmentDetails.getNomineeDetails().getRelationShip()).getId());
//			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), nomineeDetails);
//			AddressMasterV3 address = new AddressMasterV3();
            AddressMasterV3 address = null;
            if (OPLUtils.isObjectNullOrEmpty(nomineeDetails.getAddress())) {
                address = new AddressMasterV3();
            } else {
                address = nomineeDetails.getAddress();
            }
//			BeanUtils.copyProperties(enrollmentDetails.getNomineeDetails(), address);
            address.setCityName(enrollmentDetails.getNomineeDetails().getCity());
            address.setStateName(enrollmentDetails.getNomineeDetails().getState());
            address.setDistrict(enrollmentDetails.getNomineeDetails().getDistrict());
            address.setAddressLine1(enrollmentDetails.getNomineeDetails().getAddressLine1());
            address.setAddressLine2(enrollmentDetails.getNomineeDetails().getAddressLine2());
            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getCustomerDetails().getPincode())) {
                address.setPincode(Integer.valueOf(enrollmentDetails.getNomineeDetails().getPincode().trim()));
                try {
//					PincodeMasterResponse pincodeMaster = oneFormClient
//							.getFirstPincodeMasterDetailsByPincode(enrollmentDetails.getNomineeDetails().getPincode());
//					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
//						address.setCityId(pincodeMaster.getCityId());
//						address.setStateId(pincodeMaster.getStateId());
//					}
                } catch (Exception e) {
                    log.error("Exception while fetching pincode  {} for Nominee Exception :{}",
                            enrollmentDetails.getNomineeDetails().getPincode(), e);
                }
            }
            nomineeDetails.setAddress(address);

            if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getFirstName())) {
                StringBuilder s1 = new StringBuilder();
                s1.append(enrollmentDetails.getNomineeDetails().getFirstName()).append(" ");
                if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getMiddleName()))
                    s1.append(enrollmentDetails.getNomineeDetails().getMiddleName()).append(" ");
                if (!OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getLastName()))
                    s1.append(enrollmentDetails.getNomineeDetails().getLastName());
                nomineeDetails.setName(s1.toString());
            }
            nomineeDetails.setFirstName(enrollmentDetails.getNomineeDetails().getFirstName());
            nomineeDetails.setMiddleName(
                    !OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getMiddleName())
                            ? enrollmentDetails.getNomineeDetails().getMiddleName()
                            : null);
            nomineeDetails.setLastName(
                    !OPLUtils.isObjectNullOrEmpty(enrollmentDetails.getNomineeDetails().getLastName())
                            ? enrollmentDetails.getNomineeDetails().getLastName()
                            : null);
            nomineeDetails.setMobileNumber(enrollmentDetails.getNomineeDetails().getMobile());
//			nomineeDetails.setDob(dob);
            nomineeDetails.setDob((com.opl.jns.ere.utils.CommonUtils.sdf_dd_MM_yyyy).parse(enrollmentDetails.getNomineeDetails().getDob()));
            nomineeDetails.setApplicationMaster(applicationMaster);
            nomineeDetails.setIsActive(Boolean.TRUE);
            nomineeDetails.setIsOtherClaimant(Boolean.FALSE);
            nomineeDetails.setCreatedDate(curruntDate);
//			nomineeDetails.setCreatedBy(userId);
            nomineeMasters.add(nomineeDetails);
        }
        return nomineeMasters;
    }

    public CommonResponse regenerateAndPushCoi(Long applicationId) {
        String url = "http://localhost:8060/insurance/v3/enrollment/regenerateAndPushCoi";
//		String url = https://jansuraksha.in/insurance/v3/enrollment/regenerateAndPushCoi;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//			headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//			headers.add("Accept", "application/json");
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<List<Long>> entity = new HttpEntity<>(Arrays.asList(applicationId), headers);
            RestTemplate restTemplate = new RestTemplate();
            log.info("regenerateAndPushCoi For -->" + applicationId + "==========API URL ----------->" + url);
            CommonResponse response = restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class)
                    .getBody();

            if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
                    && response.getStatus() == 200) {
                return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("Exception While RegenerateAndPushCoiapi :: ", e);
        }
        return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    public CommonResponse updatePushReadyDate(Long applicationId) {
        String url = "http://localhost:8050/api/jns/push/v3/enrollment" + "/" + applicationId;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
            headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
            headers.set("isDecrypt", "true");
            headers.add("Accept", "application/json");
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<?> entity = new HttpEntity<>(headers);
            RestTemplate restTemplate = new RestTemplate();
            log.info("Published Data For -->" + applicationId + "==========API URL ----------->" + url);
            CommonResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class)
                    .getBody();
            if (!OPLUtils.isObjectNullOrEmpty(response)) {
                return new CommonResponse("Successfully updated pushReadyDate !!", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("Exception While calling claim push details api :: ", e);
        }
        return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse getPublishReqRes(Long auditId, boolean isRegistry) throws IOException {
        String mainQuery = null;
        List<Object> findByLogAudit = null;

        String dbName = "";
        if (isRegistry == true) {
            dbName = DBNameConstant.JNS_REGISTRY_API;
        } else {
            dbName = DBNameConstant.JNS_PUBLISH_API;
        }

        mainQuery = "select json_object( \r\n"
                + "'id' value asd.id ,\r\n"
                + "'logAudit' value asd.log_audit_id ,\r\n"
                + "'storageId' value asd.storage_id,  \r\n"
                + "'createdDate' value asd.created_date,  \r\n"
                + "'typeId' value  asd.type_id )  \r\n"
                + "FROM " + dbName + ".api_storage_dec asd \r\n"
                + "WHERE asd.log_audit_id = " + auditId + " ";
        findByLogAudit = adminRepository.fetchListOfDataFromDb(mainQuery);

        if (OPLUtils.isListNullOrEmpty(findByLogAudit)) {
            mainQuery = "select json_object( \r\n"
                    + "'id' value asd.id ,\r\n"
                    + "'logAudit' value asd.log_audit_id ,\r\n"
                    + "'storageId' value asd.storage_id,  \r\n"
                    + "'createdDate' value asd.created_date,  \r\n"
                    + "'typeId' value  asd.type_id )  \r\n"
                    + "FROM JNS_REGISTRY_API.API_STORAGE_DEC_OLD_MAY asd \r\n"
                    + "WHERE asd.log_audit_id = " + auditId + " ";
            System.err.print(mainQuery);
            findByLogAudit = adminRepository.fetchListOfDataFromDb(mainQuery);
        }

        if (!OPLUtils.isObjectNullOrEmpty(findByLogAudit)) {
            HttpHeaders headers = new HttpHeaders();
            headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
//	            headers.set("isDecrypt", "true");
//	            headers.set("skipEnc", "true");
            headers.add("Accept", "application/json");
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
            Map<String, Object> map = new HashMap<>();
            map.put("reqLogAuditId", auditId);
//			int i = 0;
            String urlDomain = isRegistry ? URLConfig.fetchURL(URLMaster.REGISTRY) : URLConfig.fetchURL(URLMaster.PUBLISH_INSURANCE);
//			String urlDomain = isRegistry ? "/api/registry" : "/api/jns";
            for (Object payloadAudit : findByLogAudit) {
                APIStorageAuditProxy objectFromObject = MultipleJSONObjectHelper.getObjectFromString(payloadAudit.toString(), APIStorageAuditProxy.class);
                String url = urlDomain + "/opl/bucket/deseriablize/" + objectFromObject.getStorageId();
                log.info("----bucket url----> ({})", url);
                @SuppressWarnings("unchecked")
                Map<String, Object> body = new RestTemplate().exchange(url, HttpMethod.GET, entity, Map.class).getBody();
                if (!OPLUtils.isObjectNullOrEmpty(body)) {
                    map.put("plainPayload", !OPLUtils.isObjectNullOrEmpty(body.get("plainPayload")) ? body.get("plainPayload").toString() : null);
                    map.put("encryptPayload", !OPLUtils.isObjectNullOrEmpty(body.get("encryptPayload")) ? body.get("encryptPayload").toString() : null);
                    map.put("plainResponse", !OPLUtils.isObjectNullOrEmpty(body.get("plainResponse")) ? body.get("plainResponse").toString() : null);
                    map.put("encryptResponse", !OPLUtils.isObjectNullOrEmpty(body.get("encryptResponse")) ? body.get("encryptResponse").toString() : null);
                    map.put("referenceId", !OPLUtils.isObjectNullOrEmpty(body.get("referenceId")) ? body.get("referenceId").toString() : null);
                    map.put("header", !OPLUtils.isObjectNullOrEmpty(body.get("header")) ? body.get("header").toString() : null);
//					map.put(objectFromObject.getTypeId() == 1 ? "encryptRequest" : "encryptResponse", !OPLUtils.isObjectNullOrEmpty(body.get("plainPayload")) ? body.get("plainPayload").toString() : null);
//					map.put(objectFromObject.getTypeId() == 1 ? "plainRequest" : "plainResponse", !OPLUtils.isObjectNullOrEmpty(body.get("encryptPayload")) ? body.get("encryptPayload").toString() : null);
//					if (i == 0) {
//						map.put("referenceId", !OPLUtils.isObjectNullOrEmpty(body.get("referenceId")) ? body.get("referenceId").toString() : null);
//						map.put("header", !OPLUtils.isObjectNullOrEmpty(body.get("header")) ? body.get("header").toString() : null);
//					}
//					i++;
                }
            }
            return new CommonResponse(map, "Successfully Get Data", HttpStatus.OK.value());
        }
        return new CommonResponse("Successfully Get Data", HttpStatus.NO_CONTENT.value());
    }

    @Override
    public CommonResponse fetchPublishedAppList(String request) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//			String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
//			String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
//			Long typeId = filterJSON.has("typeId") ? filterJSON.get("typeId").asLong() : null;
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
            Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
            Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;

            String searchQuery = "";

            String whereClause = " WHERE am.is_active = 1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND am.org_id =" + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereClause += " AND am.scheme_id =" + schemeId;
            }
            if (searchData != null) {
//				if (typeId == 1) {
//					searchQuery = " AND  am.urn =  '" +  searchData  +"'  ";
//
//				} else if(typeId == 2) {
////					searchQuery = " AND " + DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) = '"  + searchData + "' ";
//					searchQuery = " AND am.account_number = " + DBNameConstant.JNS_PUBLISH_API + ".\"PUBLISH_ENCVALUE\"('" + searchData + "') ";
//				}else {
                searchQuery = " AND  am.application_id =  '" + searchData + "'  ";
//				}
            }
            whereClause = whereClause + searchQuery;

            String totalCountSelectQuery = "select (json_object('totalCount' value count(am.id))) ";

            String tablesQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".application_master am ";

            String orderByQuery = "order by am.created_date desc";
//			String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY";

            String str = adminRepository.fetchCount(totalCountSelectQuery + tablesQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String tableQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".application_master am INNER JOIN "
                    + DBNameConstant.JNS_PUBLISH_API + ".applicant_info ai ON ai.application_id = am.id LEFT JOIN "
                    + DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1";

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
                    + " ,'schemeName' value schemeName,'applicationReferenceId' value applicationReferenceId,"
                    + "'applicationId' value applicationId,"
                    + "'urn' value urn, 'customerAccountNumber' value customerAccountNumber,"
                    + "'application_status' value application_status, 'createdDate' value createdDate,"
                    + "'enrollDate' value enrollDate,'message' value message, 'modifiedDate' value modifiedDate,"
                    + "'orgId' value orgId,'pushReadyDate' value pushReadyDate,"
                    + "'mobileNumber' value mobileNumber, 'name' value name )returning clob) FROM( SELECT am.id as applicationReferenceId,"
                    + " am.application_id as applicationId,"
                    + "sm.short_name as schemeName,am.urn as urn," + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(am.account_number) as customerAccountNumber,"
                    + "am.application_status as application_status,"
                    + "am.created_date as createdDate,am.enrollment_date as enrollDate,am.push_ready_date as pushReadyDate,am.message as message,am.modified_date as modifiedDate,am.org_id as orgId,"
                    + "" + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(ai.mobile_number) as mobileNumber,"
                    + "" + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(ai.name) as name ";
//			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery + " )";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + " )";
//			System.err.println(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get fetchPublishedAppList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchPublishedClaimList(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//			String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
//			String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
//			Long typeId = filterJSON.has("typeId") ? filterJSON.get("typeId").asLong() : null;
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
            Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
            Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;

            String searchQuery = "";
            String whereClause = " WHERE ca.is_active = 1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND am.org_id =" + orgId;
            }

            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereClause += " AND am.scheme_id =" + schemeId;
            }

            if (searchData != null) {
//				if (typeId == 1) {
//					searchQuery = " AND  am.urn =  '" +  searchData  +"'  ";
//				} else if(typeId == 2) {
////					searchQuery = " AND " + DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) = '"  + searchData + "' ";
//					searchQuery = " AND am.account_number = " + DBNameConstant.JNS_PUBLISH_API + ".\"PUBLISH_ENCVALUE\"('" + searchData + "') ";
//				}else {
                searchQuery = " AND  ca.application_id =  '" + searchData + "'  ";
//				}
            }
            whereClause = whereClause + searchQuery;

            String totalCountSelectQuery = "select (json_object('totalCount' value count(ca.id))) ";

            String tablesQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".claim_master ca INNER JOIN "
                    + DBNameConstant.JNS_PUBLISH_API + ".application_master am ON am.id = ca.application_ref_id ";

            String orderByQuery = "order by ca.created_date desc";
//			String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY";
            String str = adminRepository.fetchCount(totalCountSelectQuery + tablesQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String tableQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".claim_master ca INNER JOIN "
                    + DBNameConstant.JNS_PUBLISH_API + ".claim_detail cd ON cd.claim_id = ca.id INNER JOIN "
                    + DBNameConstant.JNS_PUBLISH_API + ".application_master am ON am.id = ca.application_ref_id LEFT JOIN "
                    + DBNameConstant.JNS_PUBLISH_API + ".applicant_info ai ON ai.application_id = am.id LEFT JOIN "
                    + DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1";

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
                    + " ,'claimReferenceId' value lst.claimReferenceId,"
                    + "'applicationId' value lst.applicationId,"
                    + "'accountHolderName' value lst.accountHolderName,"
                    + " 'amount_of_transaction' value lst.amount_of_transaction, "
                    + " 'customerAccountNumber' value lst.customerAccountNumber, 'urn' value lst.urn,  "
                    + "'mobileNumber' value lst.mobileNumber,'schemeName' value lst.schemeName,'claimDate' value lst.claimDate,  'modifiedDate' value lst.modifiedDate,"
                    + "'createdDate' value lst.createdDate )returning clob) FROM( SELECT ca.id as claimReferenceId, ca.application_id as applicationId,"
                    + " " + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(ai.name) as accountHolderName, ca.amount_of_transaction as amount_of_transaction,"
                    + "" + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(am.account_number) as customerAccountNumber, am.urn as urn,"
                    + "" + DBNameConstant.JNS_PUBLISH_API + ".PUBLISH_DECVALUE(ai.mobile_number) as mobileNumber, sm.short_name as schemeName, "
                    + "ca.claim_date as claimDate, ca.modified_date as modifiedDate,ca.created_date as createdDate";
            String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + ") lst";
//			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery + ") lst";
//			System.err.println(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while get fetchPublishedClaimList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse updateTransactionList(List<UpdateTransactionProxy> transactionproxy) {
        try {
            List<Long> applicationList = new ArrayList<>();
            List<Long> alreadyCompletedList = new ArrayList<>();
            List<Long> dedupeList = new ArrayList<>();
            List<Long> dedupeMasterList = new ArrayList<>();
            Map<String, String> dedupeListMap = new LinkedHashMap<>();
            Map<String, String> dedupeMasterListMap = new LinkedHashMap<>();
            List<Long> errorList = new ArrayList<>();
            List<Long> applicationNotFoundList = new ArrayList<>();
            List<Long> transactionDetailsErrorList = new ArrayList<>();
            for (UpdateTransactionProxy transactionRequest : transactionproxy) {
                try {

                    String scheme = getApplicationIdFromUrn(transactionRequest.getUrn());
                    Long schemeId = 0L;
                    if (scheme.equalsIgnoreCase(SchemeMaster.PMJJBY.getShortName())) {
                        schemeId = SchemeMaster.PMJJBY.getId();
                    } else if (scheme.equalsIgnoreCase(SchemeMaster.PMSBY.getShortName())) {
                        schemeId = SchemeMaster.PMSBY.getId();
                    }
                    ApplicationMasterBothSchemeProxy bothSchemeProxy = ereCommonService
                            .getJnsMasterDataApplicationMaster(schemeId,
                                    OPLUtils.getApplicationIdFromUrn(transactionRequest.getUrn()));
                    if (!OPLUtils.isObjectNullOrEmpty(bothSchemeProxy)
                            && !OPLUtils.isObjectNullOrEmpty(bothSchemeProxy.getStatus())
                            && (bothSchemeProxy.getStatus() == ApplicationStatus.ENROLL_COMPLETED.getId()
                            || bothSchemeProxy.getStatus() == ApplicationStatus.OPT_OUT_IN_PROCESS.getId()
                            || bothSchemeProxy.getStatus() == ApplicationStatus.OPT_OUT.getId())) {
                        alreadyCompletedList.add(bothSchemeProxy.getId());
                        continue;
                    }

                    ApplicationMasterV3 applicationMaster = applicationMasterRepo
                            .findFirstByUrnAndIsActiveTrue(transactionRequest.getUrn());

                    if (!OPLUtils.isObjectNullOrEmpty(applicationMaster)
                            && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationStatus())
                            && (applicationMaster.getApplicationStatus() == ApplicationStatus.ENROLL_COMPLETED.getId()
                            || applicationMaster.getApplicationStatus() == ApplicationStatus.OPT_OUT_IN_PROCESS.getId()
                            || applicationMaster.getApplicationStatus() == ApplicationStatus.OPT_OUT.getId())) {
                        alreadyCompletedList.add(applicationMaster.getId());
                        continue;
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getSchemeId())
                            && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getCif())
                            && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())) {

                        /**CHECK DEDUPE ACCOUNT NUMBER AND CIF USING*/
                        CommonResponse checkDeDupe = checkDeDupe(applicationMaster);
                        if (!OPLUtils.isObjectNullOrEmpty(checkDeDupe)) {
                            dedupeList.add(applicationMaster.getId());
                            dedupeListMap.put(applicationMaster.getUrn(), checkDeDupe.getData().toString());
                            continue;
                        }

                        /**CHECK DEDUPE CIF USING JNS_MASTER*/
                        if (!PhaseMode.checkPhase2(applicationMaster.getOrgId())) {
	                        String urn = ereCommonService.checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(applicationMaster.getSchemeId(), applicationMaster.getCif(), applicationMaster.getOrgId());
	                        if (!OPLUtils.isObjectNullOrEmpty(urn)) {
	                            dedupeMasterList.add(applicationMaster.getId());
	                            dedupeMasterListMap.put(applicationMaster.getUrn(), urn);
	                            continue;
	                        }
                        }

                        TransactionDetailsV3 transactionDetails = new TransactionDetailsV3();
                        if (!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails())) {
                            applicationList.add(applicationMaster.getId());
                            transactionDetails = applicationMaster.getLastTransactionDetails();
                        }

                        Long applicationId = applicationMaster.getId();

                        /* FETCH CURRENT YEAR POLICY INSURER DETAILS */
                        InsurerMstDetailsV3 currentInsurerDetails = insurerMstDetailsRepository
                                .findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
                                        Long.valueOf(applicationMaster.getSchemeId()), applicationMaster.getOrgId(), new Date(),
                                        new Date());
                        if (OPLUtils.isObjectNullOrEmpty(currentInsurerDetails) && OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getMasterPolicyNo())) {
                            //							&& !currentInsurerDetails.getMasterPolicyNo().equalsIgnoreCase(transactionRequest.getMasterPolicyNumber())) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        }

                        /* PARSE TRANSACTION DATE */
                        //					Date tranTimeStamp = Date
                        //							.from(transactionRequest.getTransactionTimeStamp().atZone(ZoneId.systemDefault()).toInstant());
                        if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getTransactionTimeStamp())) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        }
                        Date tranTimeStamp = (com.opl.jns.ere.utils.CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.parse(transactionRequest.getTransactionTimeStamp().toString().replace('T', ' ')));

                        if (OPLUtils.isObjectNullOrEmpty(tranTimeStamp)) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        }
                        /** if transactionTimeStamp date is after current date */
                        if (tranTimeStamp.after(new Date())) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        }

                        /** if transactionTimeStamp date is before policy start date */
                        if (!OPLUtils.isObjectNullOrEmpty(currentInsurerDetails.getPolicyStartDate())
                                && tranTimeStamp.before(currentInsurerDetails.getPolicyStartDate())) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        }

                        Long userId = applicationMaster.getUserId();
                        Date curruntDate = new Date();

                        /* SET TRANSACTION DETAIL OBJECT */
                        transactionDetails = setTransactionDetails(transactionRequest, curruntDate,
                                tranTimeStamp, userId, currentInsurerDetails, transactionDetails);
                        transactionDetails.setAppCreatedDate(applicationMaster.getCreatedDate());
                        ;
                        applicationMaster = updateApplicationMaster(applicationMaster, curruntDate, tranTimeStamp, userId,
                                currentInsurerDetails, transactionRequest);
                        transactionDetails.setApplicationMaster(applicationMaster);

                        applicationMaster.setLastTransactionDetails(transactionDetails);
                        applicationMaster.setPremiumAmount(transactionRequest.getTransactionAmount());
                        applicationMaster.setCompletionDate(curruntDate);
                        applicationMaster.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
                        applicationMasterRepo.save(applicationMaster);
                        ereCommonService.insertApplcationPushStatus(applicationId);
                        CommonResponse response = regenerateAndPushCoi(applicationMaster.getId());
                        if (OPLUtils.isObjectNullOrEmpty(response)) {
                            transactionDetailsErrorList.add(applicationMaster.getId());
                        } else {
                            //						String mainQuery = "select to_timestamp(push_ready_date) from JNS_PUBLISH_API.APPLICATION_MASTER where application_id ="
                            //								+ applicationId + " ";
                            //						Timestamp pushReadyDate = adminRepository.getpushDate(mainQuery);
                            Date pushReadyDate = countRepo.getpushDate(applicationId);
                            CommonResponse res = updatePushReadyDate(applicationId);
                            if (OPLUtils.isObjectNullOrEmpty(res)) {
                                transactionDetailsErrorList.add(applicationMaster.getId());
                            } else {
                                if (!OPLUtils.isObjectNullOrEmpty(pushReadyDate)) {
                                    countRepo.updatePushReadyDateByAppId(applicationId, pushReadyDate);
                                }
                            }
                        }
                    } else {
                        applicationNotFoundList.add(OPLUtils.getApplicationIdFromUrn(transactionRequest.getUrn()));
                        continue;
                    }
                } catch (Exception e) {
                    log.error("Error Application Not Found --------->{} {} ", transactionRequest.getUrn(), e);
                    errorList.add(OPLUtils.getApplicationIdFromUrn(transactionRequest.getUrn()));

                }
            }
            log.info("Dedupe APPLICATION LIST -------------> " + dedupeList.toString());
            log.info("Dedupe JNS MASTER LIST -------------> " + dedupeMasterList.toString());
            log.info("Dedupe APPLICATION LIST -------------> " + MultipleJSONObjectHelper.getStringfromObject(dedupeListMap));
            log.info("Dedupe JNS MASTER LIST -------------> " + MultipleJSONObjectHelper.getStringfromObject(dedupeMasterListMap));
            log.info("Already Completed APPLICATION LIST -------------> " + alreadyCompletedList.toString());
            log.info("Error APPLICATION LIST -------------> " + errorList.toString());
            log.info("Application Not Found APPLICATION LIST -------------> " + applicationNotFoundList.toString());
            log.info("Transaction Failed APPLICATION LIST -------------> " + transactionDetailsErrorList.toString());
            UpdateTransactionStatus transactionStatus = new UpdateTransactionStatus(applicationList, alreadyCompletedList, dedupeList, dedupeMasterList, errorList, applicationNotFoundList, transactionDetailsErrorList, dedupeListMap, dedupeMasterListMap);
            return new CommonResponse("successfully Upadted Trasantion", transactionStatus, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("Exception is getting while Update TransactionDetails", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private TransactionDetailsV3 setTransactionDetails(UpdateTransactionProxy transactionRequest, Date curruntDate, Date tranTimeStamp, Long userId, InsurerMstDetailsV3 currentInsurerDetails, TransactionDetailsV3 transactionDetails) {
        transactionDetails.setCreatedDate(curruntDate);
        transactionDetails.setIsActive(Boolean.TRUE);
        transactionDetails.setTransTimeStamp(tranTimeStamp);
        transactionDetails.setTransAmount(transactionRequest.getTransactionAmount());
        transactionDetails.setMasterPolicyNo(currentInsurerDetails.getMasterPolicyNo());
        transactionDetails.setTransUtr(transactionRequest.getTransactionUTR());
        transactionDetails.setType(1);
        transactionDetails.setInsurerCode(currentInsurerDetails.getInsurerCode());
        transactionDetails.setCreatedBy(userId);
        transactionDetails.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
        transactionDetails.setCoverEndDate(currentInsurerDetails.getPolicyEndDate());
        transactionDetails.setCoverStartDate(tranTimeStamp);
        String year = currentInsurerDetails.getYear().substring(0, 4);
        transactionDetails.setYear(OPLUtils.isObjectNullOrEmpty(year) ? null : Integer.valueOf(year));
        transactionDetails.setInsurerMaster(currentInsurerDetails);
        return transactionDetails;
    }

    private ApplicationMasterV3 updateApplicationMaster(ApplicationMasterV3 applicationMaster, Date curruntDate, Date tranTimeStamp, Long userId, InsurerMstDetailsV3 currentInsurerDetails, UpdateTransactionProxy transactionRequest) {
        applicationMaster.setStageId(EnrollStageMaster.COMPLETED.getStageId());
        applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_COMPLETED.getId());
        applicationMaster.setStatusChangeDate(curruntDate);
        applicationMaster.setModifiedDate(curruntDate);
        applicationMaster.setModifiedBy(userId);
//			applicationMaster.setIsPushed(true);
        //ereCommonService.updateEnrollPushStatus(EnrollPushType.MASTER_PUSH, applicationMaster.getId(), true, curruntDate);
        applicationMaster.setEnrollmentDate(tranTimeStamp);
        applicationMaster.setPremiumAmount(transactionRequest.getTransactionAmount());
        applicationMaster.setInsurerOrgId(currentInsurerDetails.getInsurerOrgId());
        return applicationMaster;
    }

    @Override
    public CommonResponse updateTrasTimeStamp(List<UpdateTraTimeStampProxy> transactionProxy) {
        try {
            /** update insurance transaction time stamp */
            transactionProxy.stream().filter(x -> !OPLUtils.isObjectNullOrEmpty(x.getInsTransactionId())
                    && !OPLUtils.isObjectNullOrEmpty(x.getInsTransTimeStamp())).forEach(x -> {
                try {
                    Date insTimeStamp = CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.parse(x.getInsTransTimeStamp());
                    transactionDetailsRepositoryV3.updateTransTimeStampById(x.getInsTransactionId(),
                            insTimeStamp);
                } catch (ParseException e) {
                    log.error("Error while parsing date insurance time stamp :: ", e);
                }
            });

            /** update publish transaction time stamp by id */
            transactionProxy.stream().filter(x -> !OPLUtils.isObjectNullOrEmpty(x.getPubTransactionId())
                    && !OPLUtils.isObjectNullOrEmpty(x.getPubTransTimeStamp())).forEach(x -> {
                countRepo.updatePubTransTimeStamp(x.getPubTransactionId(), x.getPubTransTimeStamp());
            });

        } catch (Exception e) {
            log.error("Exception is getting while Update transaction time stamp", e);
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
        log.info("End in updateTrasTimeStamp() ---------->");
        return new CommonResponse("successfully Upadted Trasantion time stamp", HttpStatus.OK.value(),
                Boolean.TRUE);
    }


    @Override
    public CommonResponse downloadNotificationList(String request) {
        try {

            log.info("entering FetchNotificationList api and request ==> {}", request);

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;

            String whereQuery = " where nl.status_code = 200 and nl.is_active = 1";
            if ((!OPLUtils.isObjectNullOrEmpty(fromDate)) && (!OPLUtils.isObjectNullOrEmpty(toDate))) {
                whereQuery += " AND nl.created_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and "
                        + " to_timestamp('" + toDate + "') ";
            }

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('id' value id,\r\n"
                    + "                   'toId' value toId,\r\n"
                    + "					'toEmailCount' value toEmailCount,\r\n"
                    + "					'ccEmailCount' value ccEmailCount, \r\n"
                    + "                    'bccEmailCount' value bccEmailCount,\r\n"
                    + "					'smsCount' value smsCount, \r\n"
                    + "                    'contLength' value contLength,\r\n"
                    + "					'masterId' value masterId,\r\n"
                    + "                    'subjectId' value subjectId,\r\n"
                    + "                    'templateId' value templateId,\r\n"
                    + "					'notiTypeId' value notiTypeId,\r\n"
                    + "                    'referenceId' value referenceId,\r\n"
                    + "					'statusCode' value statusCode, \r\n"
                    + "                    'providerId' value providerId,\r\n"
                    + "                   'createdDate' value createdDate )returning clob)"
                    + "					FROM( SELECT nl.id as id,nl.to_id as toId,\r\n"
                    + "					nl.to_email_count as toEmailCount,\r\n"
                    + "                    nl.cc_email_count as ccEmailCount,\r\n"
                    + "                    nl.bcc_email_count as bccEmailCount,\r\n"
                    + "nl.sms_count as smsCount,\r\n" + "nl.content_length as contLength,\r\n"
                    + "nl.master_id as masterId,\r\n" + "nl.subject_id as subjectId,\r\n"
                    + "nl.template_id as templateId,\r\n" + "nl.notification_type_id as notiTypeId,\r\n"
                    + "nl.reference_id as referenceId,\r\n" + "nl.status_code as statusCode,\r\n"
                    + "nl.provider_id as providerId,\r\n" + "nl.created_date as createdDate";

            String tableQuery = " FROM " + DBNameConstant.JNS_NOTIFICATION + ".notification_logs nl";

            String mainQuery = selectQuery + tableQuery + whereQuery + " )";
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get FetchNotificationCount", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse getUserTknMappingLst(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);

            Long userId = filterJSON.has("userId") ? filterJSON.get("userId").asLong() : null;
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL)
                    ? filterJSON.get(PAGINATIONFROM_LITERAL).asText()
                    : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText()
                    : "10";

            String tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".user_token_mapping utm where utm.user_id = " + userId + " order by id desc";
            String totalCountSelectQuery = "select (json_object('totalCount' value count(utm.user_id))) ";
            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;


            String selectQuery = "SELECT\r\n"
                    + "    JSON_ARRAYAGG(JSON_OBJECT(\r\n"
                    + "                      'totalCount' VALUE totalCount,\r\n"
                    + "                      'token' VALUE token,\r\n"
                    + "                      'ips' VALUE ips,\r\n"
                    + "                      'browser' VALUE browser,\r\n"
                    + "                      'device' VALUE device,\r\n"
                    + "                      'deviceType' VALUE deviceType,\r\n"
                    + "                      'browserVersion' VALUE browserVersion,\r\n"
                    + "                      'session' VALUE sessionActive,\r\n"
                    + "                      'loginDate' VALUE loginDate,\r\n"
                    + "                      'logoutDate' VALUE logoutDate\r\n"
                    + "                  RETURNING CLOB) RETURNING CLOB)\r\n"
                    + "from (\r\n"
                    + "select\r\n"
                    + totalCount + " as totalCount,\r\n"
                    + "utm.access_token as token,\r\n"
                    + "utm.user_ip as ips,\r\n"
                    + "utm.user_browser as browser,\r\n"
                    + "utm.device as device,\r\n"
                    + "utm.device_type as deviceType,\r\n"
                    + "utm.browser_version as browserVersion,\r\n"
                    + "utm.active as sessionActive,\r\n"
                    + "utm.login_date as loginDate,\r\n"
                    + "utm.logout_date as logoutDate ";

            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";
            System.out.println(selectQuery + tableQuery + limitQuery);
            String str1 = adminRepository.spOtherUserList(selectQuery + tableQuery + limitQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str1, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Override
    public CommonResponse getUserDetails(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            Integer type = filterJSON.has("type") ? filterJSON.get("type").asInt() : null;
            String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;

            ApplicationMasterV3 applicationMaster = null;
            Long applicationId = null;
            if (Objects.equals(type, SupportDashboardSearch.URN.getId())) {
                applicationMaster = applicationMasterRepo.findFirstByUrnAndIsActiveTrue(searchData);
            } else if (Objects.equals(type, SupportDashboardSearch.APPLICATION_ID.getId())) {
                applicationMaster = applicationMasterRepo.findByIdAndIsActiveTrue(Long.valueOf(searchData));
            } else if (Objects.equals(type, SupportDashboardSearch.ACCOUNT_NO.getId())) {
                applicationMaster = applicationMasterRepo.findFirstByIsActiveTrueAndAccountNumber(searchData);
            }

            ApplicationMasterBothSchemeProxy appMst = null;
            if (OPLUtils.isObjectNullOrEmpty(applicationMaster) && (Objects.equals(type, SupportDashboardSearch.URN.getId()) || Objects.equals(type, SupportDashboardSearch.APPLICATION_ID.getId()))) {
                if (Objects.equals(type, SupportDashboardSearch.URN.getId())) {
                    applicationId = OPLUtils.getApplicationIdFromUrn(searchData);
                } else {
                    applicationId = Long.valueOf(searchData);
                }
                appMst = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMSBY.getId(), applicationId);
                if (OPLUtils.isObjectNullOrEmpty(appMst)) {
                    appMst = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMJJBY.getId(), applicationId);
                }
            }

            String selectQuery = "SELECT\r\n" + "    JSON_OBJECT(\r\n"
                    + "                      'email' VALUE email,\r\n"
                    + "                      'mobile' VALUE mobile,"
                    + "                      'name' VALUE name,"
                    + "                      'signupDate' VALUE signUpDate,"
                    + "                      'type' VALUE type,"
                    + "                      'active' VALUE active,"
                    + "                      'role' VALUE role,"
                    + "                      'bank' VALUE bank,"
                    + "                      'branch' VALUE branch,"
                    + "                      'locked' VALUE locked,"
                    + "                      'resetPassword' VALUE resetPassword,"
                    + "                      'userId' VALUE userId,"
                    + "                      'roleId' VALUE roleId,"
                    + "                      'userTypeId' VALUE userTypeId"
                    + "                  ) from( ";
            String select = " select " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.email) as email,"
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.mobile) as mobile,\r\n"
                    + "u.sign_up_date as signUpDate,\r\n"
                    + "uts.name as type,\r\n"
                    + "(case when u.is_active = 1 then 'Yes' else 'No' end) as active,\r\n"
                    + "urm.role_name as role,\r\n"
                    + "uom.organisation_name as bank,\r\n"
                    + "bm.name as branch,\r\n"
                    + "(case when u.is_locked = 1 then 'Yes' else 'No' end) as locked,\r\n"
                    + "'Yes' as resetPassword,\r\n"
                    + "u.user_id as userId,\r\n"
                    + "u.user_role_id as roleId,\r\n"
                    + "u.user_type_id as userTypeId,\r\n";

            if (OPLUtils.isObjectNullOrEmpty(applicationMaster) || OPLUtils.isObjectNullOrEmpty(appMst)) {
                select += DBNameConstant.JNS_USERS + ".\"decvalue\"(u.first_name) || ' ' || " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.middle_name) || ' ' || " + DBNameConstant.JNS_USERS + ".\"decvalue\"(u.last_name) as name\r\n";
            } else {
                select += "'" + applicationMaster.getApplicantInfo().getName() + "'as name\r\n";
            }

            String tableQuery = null;
            if ((!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !Objects.equals(applicationMaster.getApplicationMasterOtherDetails().getSource(), Source.JANSURAKSHA.getId())) || (!OPLUtils.isObjectNullOrEmpty(appMst) && !Objects.equals(appMst.getSource(), Source.JANSURAKSHA.getId()))) {
                Long orgId = null;
                Long branchId = null;
                if (!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !Objects.equals(applicationMaster.getApplicationMasterOtherDetails().getSource(), Source.JANSURAKSHA.getId())) {
                    orgId = applicationMaster.getOrgId();
                    branchId = applicationMaster.getBranchId();
                } else if (!OPLUtils.isObjectNullOrEmpty(appMst) && !Objects.equals(appMst.getSource(), Source.JANSURAKSHA.getId())) {
                    orgId = appMst.getOrgId();
                    branchId = appMst.getBranchId();
                }
                tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".users u "
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_organisation_master uom on uom.user_org_id = " + orgId
                        + "inner join " + DBNameConstant.JNS_USERS + ".branch_master bm on bm.id =  " + branchId
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_type_master uts on uts.id = u.user_type_id\r\n"
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_role_master urm on urm.role_id = u.user_role_id\r\n"
                        + "where ";
            } else if (Objects.equals(type, SupportDashboardSearch.USERNAME.getId())) {
                tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".users u "
                        + "left join " + DBNameConstant.JNS_USERS + ".user_organisation_master uom on uom.user_org_id = u.user_org_id\r\n"
                        + "left join " + DBNameConstant.JNS_USERS + ".branch_master bm on bm.id = u.branch_id\r\n"
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_type_master uts on uts.id = u.user_type_id\r\n"
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_role_master urm on urm.role_id = u.user_role_id\r\n"
                        + "where ";
            } else {
                tableQuery = " FROM " + DBNameConstant.JNS_USERS + ".users u "
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_organisation_master uom on uom.user_org_id = u.user_org_id\r\n"
                        + "left join " + DBNameConstant.JNS_USERS + ".branch_master bm on bm.id = u.branch_id\r\n"
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_type_master uts on uts.id = u.user_type_id\r\n"
                        + "inner join " + DBNameConstant.JNS_USERS + ".user_role_master urm on urm.role_id = u.user_role_id\r\n"
                        + "where ";
            }

            String whereClause = null;
            if (Objects.equals(type, SupportDashboardSearch.EMAIL.getId())) {
                whereClause = "u.email= " + DBNameConstant.JNS_USERS + ".\"encvalue\"(\'" + searchData + "\')";
            } else if (Objects.equals(type, SupportDashboardSearch.MOBILE_NO.getId())) {
                whereClause = "u.mobile= " + DBNameConstant.JNS_USERS + ".\"encvalue\"(\'" + searchData + "\')";
            } else if (Objects.equals(type, SupportDashboardSearch.USERNAME.getId())) {
                whereClause = "u.username= " + DBNameConstant.JNS_USERS + ".\"encvalue\"(\'" + searchData + "\')";
            } else if (!OPLUtils.isObjectNullOrEmpty(applicationMaster) || !OPLUtils.isObjectNullOrEmpty(appMst)) {
                Long userId = null;
                if (!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
                    userId = applicationMaster.getUserId();
                } else if (!OPLUtils.isObjectNullOrEmpty(appMst)) {
                    userId = appMst.getCreatedBy();
                }
                whereClause = "u.user_id= " + userId;
            }
            System.err.println(selectQuery + select + tableQuery + whereClause + ")");
            String str = adminRepository.fetchCount(selectQuery + select + tableQuery + whereClause + ")");
            if (OPLUtils.isObjectNullOrEmpty(str)) {
                return new CommonResponse("No data found.", HttpStatus.NOT_FOUND.value());
            }
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse("No data found.",
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Override
    public CommonResponse insertSupportAudit(SupportAuditProxy request) {

        supportAuditRepo.isActiveFalseByUserId(request.getSupportUserId());

        SupportAudit audit = new SupportAudit();
        audit.setSupportUserId(request.getSupportUserId());
        audit.setAction(SupportAuditAction.fromId(request.getAction()).getId());
        audit.setIsActive(Boolean.TRUE);
        audit.setCreatedDate(new Date());
        audit.setOldData(request.getOldData());
        audit.setNewData(request.getNewData());
        audit.setUserId(request.getUserId());
        supportAuditRepo.save(audit);
        return new CommonResponse(SUCCESSFULLY_SAVED_DATA, audit, HttpStatus.OK.value(), Boolean.TRUE);
    }

    @Override
    public CommonResponse getNotificationAudit(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String mobile = filterJSON.has("mobile") ? filterJSON.get("mobile").asText() : null;
            String email = filterJSON.has("email") ? filterJSON.get("email").asText() : null;
            Integer notificationTypeId = filterJSON.has("notificationTypeId") ? filterJSON.get("notificationTypeId").asInt() : null;
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL)
                    ? filterJSON.get(PAGINATIONFROM_LITERAL).asText()
                    : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText()
                    : "10";

            if (!OPLUtils.isObjectNullOrEmpty(mobile)) {
                if (mobile.length() == 12 && mobile.substring(0, 2).equals("91")) {
                } else {
                    mobile = "91" + mobile;
                }
            }

            String tableQuery = " FROM\r\n"
                    + DBNameConstant.JNS_NOTIFICATION + ".notification_logs nl\r\n"
                    + "            INNER JOIN " + DBNameConstant.JNS_NOTIFICATION + ".notification_template nt ON nt.id = nl.template_id\r\n"
                    + "        WHERE\r\n"
                    + "            nl.to_id = '" + (notificationTypeId == 1 ? email : mobile) + "'"
                    + "            AND nl.notification_type_id =" + notificationTypeId
                    + "        ORDER BY nl.created_date desc \r\n";
//				String totalCountSelectQuery = "select (json_object('totalCount' value count(nl.to_id))) ";
//				String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery);
//				JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
//				Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT\r\n"
                    + "    JSON_ARRAYAGG(JSON_OBJECT(\r\n"
//		        		+ "                      'totalCount' VALUE totalCount,\r\n"
                    + "                      'emailMobile' VALUE emailmobile,\r\n"
                    + "                      'subject' VALUE subject,\r\n"
                    + "                                'tmType' VALUE tmtype,\r\n"
                    + "                                'status' VALUE status,\r\n"
                    + "                                'createdDate' VALUE createddate\r\n"
                    + "                  RETURNING CLOB) RETURNING CLOB)\r\n"
                    + "FROM\r\n"
                    + "    (\r\n"
                    + "        SELECT\r\n"
//		        		+ +      totalCount      + " AS totalCount,\r\n"
                    + "            nl.to_id            AS emailmobile,\r\n"
                    + "            nt.template_name    AS subject,\r\n"
                    + "            'OTP'               AS tmtype,\r\n"
                    + "            nl.status_code      AS status,\r\n"
                    + "            nl.created_date     AS createddate ";

            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";
            System.out.println(selectQuery + tableQuery + limitQuery);
            String str1 = adminRepository.spOtherUserList(selectQuery + tableQuery + limitQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, str1, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Override
    public String fetchCityWiseData(String request) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String tableSubQuery = " FROM JNS_INSURANCE.APPLICATION_MASTER am \r\n"
                    + "INNER JOIN JNS_USERS.BRANCH_MASTER bm ON bm.id = am.BRANCH_ID";

            String whereQuery = " WHERE am.STAGE_ID=6 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereQuery = whereQuery + " AND am.ORG_ID = " + orgId;
            }

            if ((!OPLUtils.isObjectNullOrEmpty(fromDate)) && (!OPLUtils.isObjectNullOrEmpty(toDate))) {
                if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                    whereQuery = whereQuery + " and am.status_change_date between to_timestamp('" + fromDate + "') and to_timestamp('" + toDate + "')+1 ";
                }
            }
            String groupByQuery = " GROUP BY am.ORG_ID,am.SCHEME_ID,bm.STATE_ID, bm.CITY_ID";
            String orderByQuery = " ORDER BY am.ORG_ID,am.SCHEME_ID,bm.STATE_ID, bm.CITY_ID";

            String selectSubQuery = " select am.ORG_ID ,\r\n "
                    + " am.SCHEME_ID,bm.STATE_ID, bm.CITY_ID,COUNT(am.ID) AS count "
                    + tableSubQuery + whereQuery + groupByQuery + orderByQuery;
//		 System.err.println(selectSubQuery);

            String tableQuery = " INNER JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = t.ORG_ID \r\n"
                    + " INNER JOIN JNS_USERS.SCHEME_MASTER sm ON sm.ID = t.SCHEME_ID \r\n"
                    + " LEFT JOIN JNS_ONEFORM.CITY c ON c.ID = t.CITY_ID \r\n"
                    + " LEFT JOIN JNS_ONEFORM.STATE s ON s.ID = t.STATE_ID \r\n"
                    + " LEFT JOIN JNS_ONEFORM.STATE s2 ON s2.ID = c.STATE_ID ";

            String selectQuery = " select JSON_OBJECT( 'bankName' value  uom.display_org_name ,\r\n"
                    + " 'orgId' value  t.ORG_ID ,\r\n"
                    + "	'schemeName' value sm.SHORT_NAME ,\r\n"
                    + " 'cityId' value  t.CITY_ID ,\r\n"
                    + " 'cityName' value c.CITY_NAME ,\r\n"
                    + " 'branchState' value s.STATE_NAME ,\r\n"
                    + " 'cityState' value  s2.STATE_NAME ,\r\n"
                    + "t.count ) FROM";


            String mainQuery = selectQuery + "(" + selectSubQuery + ") t" + tableQuery;
//		 System.err.println(mainQuery);
            List<Object> data = adminRepository.fetchListOfDataFromDb(mainQuery);
            return OPLUtils.isListNullOrEmpty(data) ? null : data.toString();
        } catch (Exception e) {
            log.error("Exception is getting while get City List", e);
            return null;
        }
    }

    @Override
    public CommonResponse fetchCityWiseForPolicy(String request, Long userId) {
        try {
            String spName = DBNameConstant.JNS_REPORTS + ".GET_CITY_WISE_REPORT_V3";
            return new CommonResponse(adminRepository.getDataFromProducer(request, userId, spName),
                    "SuccessFully get cityWise Reports For Policy ", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("Exception is getting while cityWise Reports For Policy", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    public CommonResponse checkDeDupe(ApplicationMasterV3 applicationMaster) {
        /** CHECK DEDUPE WITH USING CIF */
        ApplicationMasterV3 dupRecCif = applicationMasterRepo
                .findFirstByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusInAndIdNot(applicationMaster.getOrgId(),
                        applicationMaster.getSchemeId(), applicationMaster.getCif(), inProcessOrCompletedApplication, applicationMaster.getId());
        if (!OPLUtils.isObjectNullOrEmpty(dupRecCif)) {
            log.error("CIF DUPLICATE RECORD FOUND APPLICATION ID ---------> " + dupRecCif.getId());
            return new CommonResponse("duplicate record cif for this applicationId", dupRecCif.getUrn(), HttpStatus.BAD_REQUEST.value(),
                    Boolean.FALSE);
        }

        /** CHECK DEDUPE WITH USING CIF AND ACCOUNT NUMBER */
        ApplicationQueryProxy dupRecCifAndAccNo = applicationMasterRepo
                .fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusInAndIdNotIn(
                        applicationMaster.getSchemeId(), applicationMaster.getAccountNumber(), applicationMaster.getCif(),
                        inProcessOrCompletedApplication, applicationMaster.getId());
        if (!OPLUtils.isObjectNullOrEmpty(dupRecCifAndAccNo)) {
            log.error("CIF AND ACCOUNT NUMBER DUPLICATE RECORD FOUND APPLICATION ID ---------> "
                    + dupRecCifAndAccNo.getApplicationId());
            return new CommonResponse("duplicate record account number and cif for this applicationId", dupRecCif.getUrn(),
                    HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
        }
        return null;
    }

    public static String getApplicationIdFromUrn(String urn) {
        try {
            return urn.split("-")[2];
        } catch (Exception e) {
            log.error("Wrong URN Found -->  {}", urn);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public CommonResponse fetchWebhookApiAuditDetailList(String request, Long userId) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has(PAGINATIONFROM_LITERAL)
                    ? filterJSON.get(PAGINATIONFROM_LITERAL).asText()
                    : "0";
            String paginationTO = filterJSON.has(PAGINATIONTO_LITERAL) ? filterJSON.get(PAGINATIONTO_LITERAL).asText()
                    : "10";
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;
            String searchAccountNoAndUrn = filterJSON.has("searchAccountNoAndUrn")
                    ? filterJSON.get("searchAccountNoAndUrn").asText()
                    : null;
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long searchTypeId = filterJSON.has("searchTypeId") ? filterJSON.get("searchTypeId").asLong() : null;
            boolean isFromBucket = filterJSON.has("isFromBucket") ? filterJSON.get("isFromBucket").asBoolean() : false;

            String whereClause = "where 1=1 ";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereClause += " AND al.org_id = " + orgId;
            }
            if ((!OPLUtils.isObjectNullOrEmpty(fromDate)) && (!OPLUtils.isObjectNullOrEmpty(toDate))) {
                whereClause += " AND al.created_date BETWEEN " + " to_timestamp('" + fromDate + "') " + " and "
                        + " to_timestamp('" + toDate + "')+1 ";
            }
            if (isFromBucket) {
                whereClause += " AND pa.success = 1 ";
            }

            if (!OPLUtils.isObjectNullOrEmpty(searchAccountNoAndUrn)) {
                if (searchTypeId == 1) {
                    whereClause += " AND al.application_id =  '" + searchAccountNoAndUrn + "' ";
                } else if (searchTypeId == 2) {
                    whereClause += " AND al.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"( '"
                            + searchAccountNoAndUrn + "') ";
                } else if (searchTypeId == 3) {
                    whereClause += " AND al.urn = '" + searchAccountNoAndUrn + "' ";
                } else if (searchTypeId == 4) {
                    whereClause += " AND al.request_token = '" + searchAccountNoAndUrn + "' ";
                }
            }

            String totalCountSelectQuery = "select (json_object('totalCount' value count(al.id))) ";
            String tableQuery = " FROM " + DBNameConstant.JNS_WEBHOOK_API + ".audit_log al ";

            if (isFromBucket) {
                tableQuery += "INNER JOIN " + DBNameConstant.JNS_WEBHOOK_API
                        + ".PAYLOAD_AUDIT pa ON PA.LOG_AUDIT_ID = AL.ID  ";
            }

            tableQuery += "INNER JOIN " + DBNameConstant.JNS_BANK_API + ".bank_api_master bam ON bam.id = al.api_id ";

            String orderByQuery = " order by al.created_date desc";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )";

            log.info(" TOTAL COUNT QUERY BANKAPIAUDIT DETAIL ======> {}", totalCountSelectQuery + tableQuery + whereClause);
            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has(TOTALCOUNT_LITERAL) ? json.get(TOTALCOUNT_LITERAL).asInt() : 0;

            String selectQuery = "SELECT \n" + " al.application_id as applicationId,\n"
                    + " al.id as id,\n"
                    + " al.request_token as requestToken ,\n"
                    + " bam.name as apiName ,\n"
                    + " al.response_code as responseCode,\n"
                    + " al.created_date as createdDate ,\n"
                    + " (al.RESPONSE_TIME/1000) as responseTime,\n"
                    + DBNameConstant.JNS_USERS + ".\"decvalue\"(al.account_number) as accountNo,\n"
                    + " al.urn as urnCode,\n" + " al.created_date as date1 ";

            if (isFromBucket) {
                selectQuery += " , pa.storage_id AS storageId ";
            }

            String selectsQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT ( \n"
                    + "                           'totalCount'  value " + totalCount + " ,"
                    + "                           'applicationId' value applicationId,\n"
                    + "                           'id' value id,\n"
                    + "                           'apiName' value apiName,\n"
                    + "                           'responseCode' value responseCode,\n"
                    + "                           'requestToken' value requestToken,\n"
                    + "                           'createdDate' value createdDate,\n"
                    + "                           'responseTime' value responseTime,\n"
                    + "                           'accountNo' value accountNo,\n"
                    + "                           'urnCode' value urnCode,\n"
                    + "                           'date1' value date1,\n";

            if (isFromBucket) {
                selectsQuery += " 'storageId' value storageId ";
            }

            selectsQuery += " RETURNING CLOB) RETURNING CLOB ) from ( ";
            String mainQuery = selectsQuery + selectQuery + tableQuery + whereClause + orderByQuery + limitQuery;
            log.info("QUERY WEBHOOKAPIAUDIT DETAIL ======> {}", mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL, adminRepository.fetchOptOutApplication(mainQuery),
                    HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while get fetchWebhookApiAuditDetailList", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public ApplicationMasterProxy getApplicationAllDetails(Long applicationId) {
        try {
            ApplicationMasterV3 mst = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);

            if (OPLUtils.isObjectNullOrEmpty(mst))
                mst = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);

            if (OPLUtils.isObjectNullOrEmpty(mst)) {
                log.error("Application master details not found by application id -->" + applicationId);
                return null;
            }

            Long schemeId = null;
            ApplicationMasterProxy mstReq = new ApplicationMasterProxy();
            BeanUtils.copyProperties(mst, mstReq);
//		Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), mst.getSchemeId().longValue(), mst.getApplicationMasterOtherDetails().getSource());
            mstReq.setApplicationId(mst.getId());
//		mstReq.setPremiumAmount(premiumDtl);
            mstReq.setEnrollDate(mst.getEnrollmentDate());
//		mstReq.setMaxTransactionDate(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(INSURER_START_DATE) + CommonUtils.getCurrentPolicyYear() + "T00:00:00.00"));
            if (!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails())) {
                mstReq.setCoverEndDate(mst.getLastTransactionDetails().getCoverEndDate());
                mstReq.setYear(!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails().getInsurerMaster())
                        ? mst.getLastTransactionDetails().getInsurerMaster().getYear()
                        : null);
            }
            if (!OPLUtils.isObjectNullOrEmpty(mst.getSchemeId())) {
                schemeId = mst.getSchemeId().longValue();
                mstReq.setScheme(com.opl.jns.utils.enums.SchemeMaster.getById(schemeId).getShortName());
            }
            mstReq.setCreatedDate((!OPLUtils.isObjectNullOrEmpty(mst.getStageId())
                    && mst.getStageId() == EnrollStageMaster.COMPLETED.getStageId()) ? mst.getCreatedDate()
                    : mst.getModifiedDate());
            if (!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo())) {
                mstReq.setUrn(mst.getUrn());
                mstReq.setAadhar(mst.getApplicantInfo().getAadhaar());
                mstReq.setPan(mst.getApplicantInfo().getPan());
                mstReq.setKyc(!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getIsKYCUpdate())
                        && mst.getApplicantInfo().getIsKYCUpdate() ? "Yes" : "No");
                mstReq.setFirstName(mst.getApplicantInfo().getFirstName());
                mstReq.setMiddleName(mst.getApplicantInfo().getMiddleName());
                mstReq.setLastName(mst.getApplicantInfo().getLastName());
                mstReq.setFatherHusbandName(mst.getApplicantInfo().getFatherHusbandName());
                mstReq.setDob(
                        !OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getDob()) ? mst.getApplicantInfo().getDob()
                                : null);
                mstReq.setMobileNo(mst.getApplicantInfo().getMobileNumber());
                mstReq.setEmailAddress(mst.getApplicantInfo().getEmail());
                mstReq.setKycId1(mst.getApplicantInfo().getKycId1());
                mstReq.setKycId1number(mst.getApplicantInfo().getKycIdNumber1());
                mstReq.setKycId2(mst.getApplicantInfo().getKycId2());
                mstReq.setKycId2number(mst.getApplicantInfo().getKycIdNumber2());

                mstReq.setIsSameApplicantAddress(mst.getApplicantInfo().getIsSameAppAddress());
                mstReq.setDisabilityDetails(mst.getApplicantInfo().getDisabilityDetails());
                mstReq.setDisabilityStatus(mst.getApplicantInfo().getDisabilityStatus());
                mstReq.setIsNomineeDeatilsSameEnroll(mst.getApplicantInfo().getIsNomineeDetailsSameEnroll());

                mstReq.setCif(mst.getCif());
//			mstReq.setGender(Gender.fromId(mst.getApplicantInfo().getGenderId()).getBankValue());
                mstReq.setGender(!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getGenderId())
                        ? Gender.fromId(mst.getApplicantInfo().getGenderId()).getBankValue()
                        : null);
                mstReq.setCkyc(mst.getApplicantInfo().getCkyc());
                mstReq.setCkycNumber(mst.getApplicantInfo().getCkycNumber());

//			mstReq = getRequiredOrgsDetails(mstReq, mst);

                //if (!OPLUtils.isObjectNullOrEmpty(mst.getDebitStatus())) {
//				//mstReq.setDebitStatus(mst.getDebitStatus());
                //	mstReq.setDebitReason(DebitStatus.fromId(mst.getDebitStatus()).getValue());
                //}
                mstReq.setAccountHolderName(mst.getApplicantInfo().getName());
                mstReq.setAccountNo(mst.getAccountNumber());
                mstReq.setAmount(mst.getPremiumAmount());
                if (OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getAddress())) {
                    mstReq.setAddress(new AddressMasterProxy());
                } else {
                    AddressMasterProxy req = new AddressMasterProxy();
                    BeanUtils.copyProperties(mst.getApplicantInfo().getAddress(), req);
                    req.setCity(mst.getApplicantInfo().getAddress().getCityName());
                    req.setState(mst.getApplicantInfo().getAddress().getStateName());
                    mstReq.setAddress(req);
                }
            }
            NomineeDetails ndMst = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId,
                    NomineeType.NOMINEE.getId());
            NomineeDetails ndMstOfGuardian = nomineeDetailsRepository
                    .findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.GUARDIAN.getId());

            if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
                NomineeDetailsProxy ndReq = new NomineeDetailsProxy();
                BeanUtils.copyProperties(ndMst, ndReq);
                ndReq.setDateOfBirth(ndMst.getDob());
                ndReq.setEmailIdOfNominee(ndMst.getEmail());
                if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian)) {
                    if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getRelationId())) {
//					String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMstOfGuardian.getRelationId());
                        String relationShip = RelationShip.fromId(ndMstOfGuardian.getRelationId()).getValue();
                        ndReq.setRelationShipOfGuardianStr(relationShip);
                        ndReq.setRelationShipOfGuardian(ndMstOfGuardian.getRelationId());
                    }
                    ndReq.setMobileNumberOfGuardian(
                            !OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getMobileNumber()) ? ndMst.getMobileNumber()
                                    : null);
                    ndReq.setEmailIdOfGuardian(
                            !OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getEmail()) ? ndMstOfGuardian.getEmail() : null);
                    ndReq.setAddressOfGuardian(ndMstOfGuardian.getAddress().getAddressLine1());
                    ndReq.setNameOfGuardian(ndMstOfGuardian.getName());
                }
                ndReq.setAge(
                        !OPLUtils.isObjectNullOrEmpty(ndMst.getDob()) ? CommonUtils.getAgeBydob(ndMst.getDob()) : null);
                ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());

                if (!OPLUtils.isObjectNullOrEmpty(ndMst.getRelationId())) {
//				String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getRelationId());
                    String relationShip = RelationShip.fromId(ndMst.getRelationId()).getValue();
                    ndReq.setRelationOfNomineeApplicantStr(relationShip);
                    ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());
                }

                if (!OPLUtils.isObjectNullOrEmpty(ndMst.getAddress())) {
                    if (OPLUtils.isObjectNullOrEmpty(ndReq.getAddress())) {
                        ndReq.setAddress(new AddressMasterProxy());
                    }
                    AddressMasterProxy req = new AddressMasterProxy();
                    BeanUtils.copyProperties(ndMst.getAddress(), req);
                    req.setCity(ndMst.getAddress().getCityName());
                    req.setState(ndMst.getAddress().getStateName());
                    ndReq.setAddress(req);
                }
                List<NomineeDetailsProxy> nomineeMasterList = new ArrayList<NomineeDetailsProxy>();
                nomineeMasterList.add(ndReq);
                mstReq.setNominee(nomineeMasterList);
            }

            TransactionDetailsV3 transactionDetails = mst.getLastTransactionDetails();
            // .findFirstByApplicationMasterIdAndTypeAndIsActiveTrue(mstReq.getId(),
            // CommonUtils.TYPE_ENROLLMENT);
            if (!OPLUtils.isObjectNullOrEmpty(transactionDetails)) {
                mstReq.setTransUtr(transactionDetails.getTransUtr());
                mstReq.setTransTimeStamp(transactionDetails.getTransTimeStamp());
                mstReq.setTransactionType(transactionDetails.getType());
                mstReq.setTransAmount(transactionDetails.getTransAmount());
                mstReq.setTransComment(transactionDetails.getTransComment());

                mstReq.setMasterPolicyNo(transactionDetails.getMasterPolicyNo());
                mstReq.setInsurerCode(transactionDetails.getInsurerCode());
                mstReq.setIsUpdateManually(transactionDetails.getIsUpdateManually());
                ;
            }

            ApplicationMasterOtherDetailsV3 otherDetails = mst.getApplicationMasterOtherDetails();
            if (!OPLUtils.isObjectNullOrEmpty(otherDetails)) {
                mstReq.setUserId1(otherDetails.getUserId1());
                mstReq.setUserId2(otherDetails.getUserId2());
                mstReq.setRuralUrbanSemi(otherDetails.getRuralUrbanSemi());
                mstReq.setRuralUrbanId(otherDetails.getRuralUrbanId());
                mstReq.setChannel(otherDetails.getChannel());
                mstReq.setChannelId(ChannelIdEnum.fromId(Long.valueOf(otherDetails.getChannel())).getShortName());
                mstReq.setSource(otherDetails.getSource());
                mstReq.setSourceValue(Source.fromId(otherDetails.getSource()).getValue());
                mstReq.setConsentForAutoDebit(otherDetails.getConsentForAutoDebit());
            }

            if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
                String orgResponse = usersClient.getOrganizationName(mst.getOrgId());
                if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
                    mstReq.setBankName(orgResponse);
                }
                mstReq.setOrgId(mst.getOrgId());
            }
            mstReq.setIfscCode(mst.getApplicantInfo().getIfsc());
            if (!OPLUtils.isObjectNullOrEmpty(mst.getBranchId())) {
                BranchBasicDetailsRequest branchDetails = usersClient.getBranch(mst.getBranchId());
                if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
                    mstReq.setBranchName(branchDetails.getName());
//				mstReq.setIfscCode(branchDetails.getIfscCode());
                }
            } else {
                log.info("branchId not found from user Auth");
            }
            return mstReq;
        } catch (Exception e) {
            log.error("Exception is getting While Get insurance data ", e);
        }
        return null;
    }

    @Override
    public ApplicationMasterProxy getCustomerMasterDetailsList(Long applicationId, Long schemeId) {
        try {
            /** GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER */
            ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(schemeId,
                    applicationId);

            if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
                log.error("Application master details not found by application id -->" + applicationId);
                return null;
            }

            ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationId).orElse(null);
            if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
                log.error("Applicant info PI details not found by application id -->" + applicationId);
                return null;
            }

            ApplicantInfoV2 applicantDetails = applicantInfoRepositoryV2.findById(applicationId).orElse(null);
            if (OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
                log.error("Applicant info details not found by application id -->" + applicationId);
                return null;
            }

            TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findByApplicationId(applicationId);

            ApplicationMasterProxy mstReq = new ApplicationMasterProxy();
            BeanUtils.copyProperties(appMaster, mstReq);
//		Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), schemeId.longValue(), appMaster.getSource());
//		mstReq.setPremiumAmount(premiumDtl);

//		mstReq.setMaxTransactionDate(
//				CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(INSURER_START_DATE)
//						+ CommonUtils.getCurrentPolicyYear() + "T00:00:00.00"));
            if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
                mstReq.setCoverEndDate(transactionDetailsV2.getCoverEndDate());
            }
            mstReq.setScheme(com.opl.jns.utils.enums.SchemeMaster.getById(schemeId).getShortName());
            mstReq.setCreatedDate(appMaster.getCreatedDate());
            if (!OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
                mstReq.setUrn(appMaster.getUrn());
                mstReq.setCif(applicantPIDetails.getCif());
//			mstReq.setFirstName(applicantPIDetails.getFirstName());
//			mstReq.setMiddleName(applicantPIDetails.getMiddleName());
//			mstReq.setLastName(applicantPIDetails.getLastName());
                mstReq.setAccountHolderName(applicantPIDetails.getAcHolderName());
                mstReq.setFatherHusbandName(applicantPIDetails.getFatherHusbandName());
                mstReq.setDob(
                        !OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getDob()) ? applicantPIDetails.getDob() : null);
                mstReq.setMobileNo(applicantDetails.getMobileNumber());
                mstReq.setEmailAddress(applicantDetails.getEmail());
                mstReq.setKyc(!OPLUtils.isObjectNullOrEmpty(applicantDetails.getIsKYCUpdate())
                        && applicantDetails.getIsKYCUpdate() ? "Yes" : "No");
                mstReq.setKycId1(applicantPIDetails.getKycId1());
                mstReq.setKycId1number(applicantPIDetails.getKycIdNumber1());
                mstReq.setKycId2(applicantPIDetails.getKycId2());
                mstReq.setKycId2number(applicantPIDetails.getKycIdNumber2());
                mstReq.setSchemeId(schemeId);
                mstReq.setEnrollDate(appMaster.getEnrollmentDate());
//			mstReq.setIsSameApplicantAddress(applicantDetails.getIsSameAppAddress());
//			mstReq.setIsNomineeDeatilsSameEnroll(applicantDetails.getIsNomineeDetailsSameEnroll());
//			mstReq = getRequiredOrgsDetailsNewDb(mstReq, appMaster, schemeId);
//			mstReq.setAmount(appMaster.getPremiumAmount());
                mstReq.setRuralUrbanSemi(appMaster.getRuralUrban());

                if (!OPLUtils.isObjectNullOrEmpty(appMaster.getChannelId())) {
                    mstReq.setChannelId(ChannelIdEnum.fromId(Long.valueOf(appMaster.getChannelId())).getShortName());
                }
                if (!OPLUtils.isObjectNullOrEmpty(appMaster.getSource())) {
                    mstReq.setSource(appMaster.getSource());
                    mstReq.setSourceValue(Source.fromId(appMaster.getSource()).getValue());
                }
                mstReq.setConsentForAutoDebit(applicantDetails.getConsentForAutoDebit());

                AddressMasterV2 addressMasterV2 = addressMasterRepositoryV2.findById(applicantDetails.getAddressId())
                        .orElse(null);
                if (OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
                    mstReq.setAddress(new AddressMasterProxy());
                } else {
                    AddressMasterProxy req = new AddressMasterProxy();
                    BeanUtils.copyProperties(addressMasterV2, req);
                    BeanUtils.copyProperties(applicantPIDetails, req);
                    req.setCity(addressMasterV2.getCityName());
                    req.setState(addressMasterV2.getStateName());
                    mstReq.setAddress(req);
                }
            }
            NomineeDetailsV2 ndMst = nomineeDetailsRepositoryV2.findByApplicationIdAndIsActiveTrue(applicationId);
            if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
                NomineePIDetails nomineePIDtl = nomineePIDetailsRepository.findById(ndMst.getId()).orElse(null);
                if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
                    NomineeDetailsProxy ndReq = new NomineeDetailsProxy();
                    BeanUtils.copyProperties(ndMst, ndReq);
                    BeanUtils.copyProperties(nomineePIDtl, ndReq);
                    ndReq.setDateOfBirth(nomineePIDtl.getDob());
                    ndReq.setEmailIdOfNominee(ndMst.getEmail());
                    if (!OPLUtils.isObjectNullOrEmpty(nomineePIDtl.getGdName())) {
                        if (!OPLUtils.isObjectNullOrEmpty(ndMst.getGdRelationId())) {
//						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getGdRelationId());
                            String relationShip = RelationShip.fromId(ndMst.getGdRelationId()).getValue();
                            ndReq.setRelationShipOfGuardianStr(relationShip);
                            ndReq.setRelationShipOfGuardian(ndMst.getGdRelationId());
                        }
                        ndReq.setMobileNumberOfGuardian(
                                !OPLUtils.isObjectNullOrEmpty(ndMst.getGdMobile()) ? ndMst.getGdMobile() : null);
                        ndReq.setEmailIdOfGuardian(
                                !OPLUtils.isObjectNullOrEmpty(ndMst.getGdEmail()) ? ndMst.getGdEmail() : null);
                        ndReq.setAddressOfGuardian(nomineePIDtl.getGdAddress());
                        ndReq.setNameOfGuardian(nomineePIDtl.getGdName());
                    }
                    ndReq.setAge(!OPLUtils.isObjectNullOrEmpty(nomineePIDtl.getDob())
                            ? CommonUtils.getAgeBydob(nomineePIDtl.getDob())
                            : null);
                    ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());

                    if (!OPLUtils.isObjectNullOrEmpty(ndMst.getRelationId())) {
//					String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getRelationId());
                        String relationShip = RelationShip.fromId(ndMst.getRelationId()).getValue();
                        ndReq.setRelationOfNomineeApplicantStr(relationShip);
                        ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());
                    }

                    if (!OPLUtils.isObjectNullOrEmpty(nomineePIDtl)) {
                        if (!OPLUtils.isObjectNullOrEmpty(nomineePIDtl.getAddressLine1())) {
                            ndReq.setAddressLine1(nomineePIDtl.getAddressLine1());
                            ndReq.setAddressLine2(nomineePIDtl.getAddressLine2());
                        }
                    }
                    List<NomineeDetailsProxy> nomineeMasterList = new ArrayList<NomineeDetailsProxy>();
                    nomineeMasterList.add(ndReq);
                    mstReq.setNominee(nomineeMasterList);
                }
            }
            mstReq.setAccountNo(applicantPIDetails.getAccountNumber());
            mstReq.setCustIfscCode(applicantDetails.getIfsc());

            if (!OPLUtils.isObjectNullOrEmpty(appMaster.getOrgId())) {
                String orgResponse = usersClient.getOrganizationName(appMaster.getOrgId());
                if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
                    mstReq.setBankName(orgResponse);
                }
            }
            if (!OPLUtils.isObjectNullOrEmpty(appMaster.getBranchId())) {
                BranchBasicDetailsRequest branchDetails = usersClient.getBranch(appMaster.getBranchId());
                if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
                    mstReq.setBranchName(branchDetails.getName());
                    mstReq.setIfscCode(branchDetails.getIfscCode());
                }
            } else {
                log.info("branchId not found from user Auth");
            }
            mstReq.setDisabilityDetails(applicantDetails.getDisabilityDetails());
            mstReq.setDisabilityStatus(applicantDetails.getDisabilityStatus());
            mstReq.setUserId1(applicantDetails.getUserId1());
            mstReq.setUserId2(applicantDetails.getUserId2());
            if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
                mstReq.setMasterPolicyNo(transactionDetailsV2.getMasterPolicyNo());
                mstReq.setTransUtr(transactionDetailsV2.getTransUtr());
                mstReq.setTransTimeStamp(transactionDetailsV2.getTransTimeStamp());
//			mstReq.setIsUpdateManually(false);
                mstReq.setTransactionType(transactionDetailsV2.getType());
                mstReq.setTransAmount(transactionDetailsV2.getTransAmount());
                mstReq.setTransComment(transactionDetailsV2.getTransComment());
            }

            return mstReq;

        } catch (Exception e) {
            log.error("Exception is getting While Get insurance data ", e);
        }
        return null;

    }

    @Override
    public CommonResponse fetchPostmanResponse(PostmanCallProxy proxy, AuthClientResponse authClientResponse) {
        try {
        	APIResponseV3 webhookResonse = new APIResponseV3();
            if (proxy.getUserTypeId() == SwaggerReqResponse.USERTYPE_BANK) {
                if (proxy.getApiId() == SwaggerReqResponse.TRIGGER_OTP_API_ID) {
                    TriggerOtpRequestV3 triggerOtpReq = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), TriggerOtpRequestV3.class);
                    TriggerOtpResponseV3 triggerResponse = bankApiClient.triggerOTP(triggerOtpReq, authClientResponse);
                    log.info("Enter In TriggerOtpResponse()" + triggerResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, triggerResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.VERIFY_API_ID) {
                    OTPRequestV3 otprequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), OTPRequestV3.class);
                    VerifyOtpApiResponseV3 verifyOtpResponse = bankApiClient.verifyOtp(otprequest, authClientResponse);
                    log.info("Enter In VerifyOtpApiResponse()" + verifyOtpResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, verifyOtpResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PHYSICAL_VERIFICATION_API_ID) {
                    PhysicalVerificationRequestV3 otprequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PhysicalVerificationRequestV3.class);
                    PhysicalVerificationResponseV3 physicalVerificationResponse = bankApiClient.verifyPhysicalSignature(otprequest, authClientResponse);
                    log.info("Enter In PhysicalVerificationResponse()" + physicalVerificationResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, physicalVerificationResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.CUSTOMER_DETAIL_API_ID) {
                    CustomerDetailsRequest custrequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), CustomerDetailsRequest.class);
                    CustomerDetailsDataV3 custResponse = bankApiClient.getCustomerDetails(custrequest, authClientResponse);
                    log.info("Enter In CustomerDetailsResponse()" + custResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, custResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PREMIUM_DEDUCT_API_ID) {
                    PremiumDeductionRequestV3 premimumReq = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PremiumDeductionRequestV3.class);
                    PremiumDeductionResponseV3 premiumResponse = bankApiClient.getPremiumDeduction(premimumReq, authClientResponse);
                    log.info("Enter In PremiumDeductionResponse()" + premiumResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, premiumResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENT_DETAILS_ID) {
                    PushEnrollmentDetailsRequestV3 enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushEnrollmentDetailsRequestV3.class);
                    webhookResonse = webHookClient.pushEnrollment(enrollmentRequest);
                    log.info("Enter In enrollmentRes()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GET_ACCOUNT_HOLDER_LIST_ID) {
                    AccHolderListRequestV3 accHoldrReq = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), AccHolderListRequestV3.class);
                    AccHolderListResponseV3 accHolderResponse = bankApiClient.getAccHolderList(accHoldrReq, authClientResponse);
                    log.info("Enter In AccHolderListResponse()" + accHolderResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, accHolderResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GET_POLICY_DETAILS_ID) {
                    PolicyDetailsRequestV3 policyDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PolicyDetailsRequestV3.class);
                    PolicyDetailsResponseV3 policyDetailsResponse = bankApiClient.getPolicyDetails(policyDetailsRequest, authClientResponse);
                    log.info("Enter In PolicyDetailsResponse()" + policyDetailsResponse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, policyDetailsResponse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.OPT_OUT_UPDATE_STATUS_ID) {
                    OptOutUpdateStatusRequestV3 optOutRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), OptOutUpdateStatusRequestV3.class);
                    webhookResonse = webHookClient.optOutUpdateStatus(optOutRequest);
                    log.info("Enter In optOutResponse()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.NOMINEE_UPDATE_STATUS_ID) {
                    NomineeUpdateStatusRequestV3 nomineeUpdateStatusRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), NomineeUpdateStatusRequestV3.class);
                    webhookResonse = webHookClient.nomineeUpdateStatus(nomineeUpdateStatusRequest);
                    log.info("Enter In nomieeUpdateResponse()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_DEATILS_ID) {
                    PushClaimDetailsRequestV3 pushClaimDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushClaimDetailsRequestV3.class);
                    webhookResonse = webHookClient.claimPush(pushClaimDetailsRequest);
                    log.info("Enter In claimPush()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_STATUS_TO_BANK_ID) {
                    PushClaimStatustoBankReqV3 pushClaimStatustoBankReq = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushClaimStatustoBankReqV3.class);
                    webhookResonse = webHookClient.pushClaimStatusToBank(pushClaimStatustoBankReq);
                    log.info("Enter In pushClaimStatus()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                }
            } else {
                if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS_INSURER_SQS) {
                    PushEnrollmentDetailsRequestV3 enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushEnrollmentDetailsRequestV3.class);
                    TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findFirstByApplicationIdOrderByIdDesc(OPLUtils.getApplicationIdFromUrn(enrollmentRequest.getUrn()));
                    if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
                        enrollmentRequest.setStorageId(transactionDetailsV2.getCoiStorageId());
                    }
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    enrollmentRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(enrollmentRequest.getUrn()));
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        enrollmentRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.pushEnrollment(enrollmentRequest);
                    log.info("Enter In enrollmentRes SQS()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS_INSURER) {
                    PushEnrollmentDetailsRequestV3 enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushEnrollmentDetailsRequestV3.class);
                    TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findFirstByApplicationIdOrderByIdDesc(OPLUtils.getApplicationIdFromUrn(enrollmentRequest.getUrn()));
                    if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
                        enrollmentRequest.setStorageId(transactionDetailsV2.getCoiStorageId());
                    }
                    enrollmentRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(enrollmentRequest.getUrn()));
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        enrollmentRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.pushEnrollmentTesting(enrollmentRequest);
                    log.info("Enter In enrollmentRes()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.OPTOUT_UPDATESTATUS_INSURER) {
                    OptOutUpdateStatusRequestV3 enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), OptOutUpdateStatusRequestV3.class);
                    enrollmentRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(enrollmentRequest.getUrn()));
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        enrollmentRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.optOutUpdateStatus(enrollmentRequest);
                    log.info("Enter In optOutResponse()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.NOMINEEUPDATE_INSURER) {
                    NomineeUpdateStatusRequestV3 nomineeUpdateStatusRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), NomineeUpdateStatusRequestV3.class);
                    nomineeUpdateStatusRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(nomineeUpdateStatusRequest.getUrn()));
                    nomineeUpdateStatusRequest.setOrgId(proxy.getOrgId());
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        nomineeUpdateStatusRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.nomineeUpdateStatus(nomineeUpdateStatusRequest);
                    log.info("Enter In nomieeUpdateResponse()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLIAM_DETAILS_INSURER) {
                    PushClaimDetailsRequestV3 pushClaimDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), PushClaimDetailsRequestV3.class);
                    pushClaimDetailsRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(pushClaimDetailsRequest.getUrn()));
                    pushClaimDetailsRequest.setOrgId(proxy.getOrgId());
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        pushClaimDetailsRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.claimPush(pushClaimDetailsRequest);
                    log.info("Enter In claimPush()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_STATUS_INSURER) {
                    ClaimStatusWebhook claimStatusInsurer = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), ClaimStatusWebhook.class);
                    claimStatusInsurer.setApplicationId(OPLUtils.getApplicationIdFromUrn(claimStatusInsurer.getUrn()));
                    claimStatusInsurer.setOrgId(proxy.getOrgId());
                    webhookResonse = webHookClient.updateDocToInsurerForQuery(claimStatusInsurer);
                    log.info("Enter In pushClaimStatustoInsurer()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GETCOI_INSURER) {
                    GetCoiRequest getCoiRequest = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), GetCoiRequest.class);
                    getCoiRequest.setApplicationId(OPLUtils.getApplicationIdFromUrn(getCoiRequest.getUrn()));
                    getCoiRequest.setOrgId(proxy.getOrgId());
                    if (UserTypeMaster.INSURER.getId() == proxy.getUserTypeId()) {
                        getCoiRequest.setIsInsurer(true);
                    }
                    webhookResonse = webHookClient.getCOIDetails(getCoiRequest);
                    log.info("Enter In getCoiResponse()" + webhookResonse);
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, webhookResonse, HttpStatus.OK.value(),
                            Boolean.TRUE);
                }
            }
            return new CommonResponse(CommonErrorMsg.Common.FAILED, HttpStatus.INTERNAL_SERVER_ERROR.value());
        } catch (Exception e) {
            // TODO: handle exception
            log.error("Exception is getting While postman client Response ", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchBankWebhookRequest(PostmanCallProxy proxy) {
        try {
            if (proxy.getUserTypeId() == SwaggerReqResponse.USERTYPE_BANK) {
                if (proxy.getApiId() == SwaggerReqResponse.TRIGGER_OTP_API_ID) {
                    TriggerOtpRequestV3 triggerOtpReq = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.TRIGGER_REQUEST_EXAMPLE, TriggerOtpRequestV3.class);
                    triggerOtpReq.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, triggerOtpReq, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.VERIFY_API_ID) {
                    OTPRequestV3 otprequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.VERIFY_REQUEST_EXAMPLE, OTPRequestV3.class);
                    otprequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, otprequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PHYSICAL_VERIFICATION_API_ID) {
                    OTPRequestV3 otprequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.PHYSICAL_REQUEST_EXAMPLE, OTPRequestV3.class);
                    otprequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, otprequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.CUSTOMER_DETAIL_API_ID) {
                    CustomerDetailsRequest custrequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.CUSTOMER_REQUEST_EXAMPLE, CustomerDetailsRequest.class);
                    custrequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, custrequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PREMIUM_DEDUCT_API_ID) {
                    PremiumDeductionRequestV3 premimumReq = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.PREMIUM_REQUEST_EXAMPLE, PremiumDeductionRequestV3.class);
                    premimumReq.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, premimumReq, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENT_DETAILS_ID) {
                    PushEnrollmentDetailsRequest enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.PUSH_ENROLLMENT_DEATILS_EXAMPLE, PushEnrollmentDetailsRequest.class);
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, enrollmentRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GET_ACCOUNT_HOLDER_LIST_ID) {
                    AccHolderListRequestV3 accHoldrReq = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.GET_ACC_HOLDERlIST_EXAMPLE, AccHolderListRequestV3.class);
                    accHoldrReq.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, accHoldrReq, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GET_POLICY_DETAILS_ID) {
                    PolicyDetailsRequestV3 policyDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.POLICY_DETAILS_REQUEST_EXAMPLE, PolicyDetailsRequestV3.class);
                    policyDetailsRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, policyDetailsRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.OPT_OUT_UPDATE_STATUS_ID) {
                    OptOutUpdateStatusRequest optOutRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.OPT_OUT_STATUS_EXAMPLE, OptOutUpdateStatusRequest.class);
                    optOutRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, optOutRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.NOMINEE_UPDATE_STATUS_ID) {
                    NomineeUpdateStatusRequest nomineeUpdateStatusRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.NOMINEE_UPDATE_STATUS_EXAMPLE, NomineeUpdateStatusRequest.class);
                    nomineeUpdateStatusRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, nomineeUpdateStatusRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_DEATILS_ID) {
                    PushClaimDetailsRequest pushClaimDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE, PushClaimDetailsRequest.class);
                    pushClaimDetailsRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, pushClaimDetailsRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_STATUS_TO_BANK_ID) {
                    PushClaimStatustoBankReqV3 pushClaimStatustoBankReq = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.BANK_UPDATE_CLAIM_STATUS_EXAMPLE, PushClaimStatustoBankReqV3.class);
                    pushClaimStatustoBankReq.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, pushClaimStatustoBankReq, HttpStatus.OK.value(),
                            Boolean.TRUE);
                }
            } else if (proxy.getUserTypeId() == SwaggerReqResponse.USERTYPE_INSURER) {
                if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS_INSURER_SQS) {
                    PushEnrollmentDetailsRequest enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.PUSH_ENROLLMENT_DEATILS_EXAMPLE_INSURER, PushEnrollmentDetailsRequest.class);
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, enrollmentRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS_INSURER) {
                    PushEnrollmentDetailsRequest enrollmentRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.PUSH_ENROLLMENT_DEATILS_EXAMPLE_INSURER, PushEnrollmentDetailsRequest.class);
                    enrollmentRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, enrollmentRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLIAM_DETAILS_INSURER) {
                    PushClaimDetailsRequest pushClaimDetailsRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE_INSURER, PushClaimDetailsRequest.class);
                    pushClaimDetailsRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, pushClaimDetailsRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_STATUS_INSURER) {
                    ClaimStatusWebhook claimStatusInsurer = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.INSURER_UPDATE_CLAIM_STATUS_EXAMPLE, ClaimStatusWebhook.class);
                    claimStatusInsurer.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, claimStatusInsurer, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.OPTOUT_UPDATESTATUS_INSURER) {
                    OptOutUpdateStatusRequest optOutRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.OPT_OUT_STATUS_EXAMPL_INSURER, OptOutUpdateStatusRequest.class);
                    optOutRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, optOutRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.NOMINEEUPDATE_INSURER) {
                    NomineeUpdateStatusRequest nomineeUpdateStatusRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.NOMINEE_UPDATE_STATUS_EXAMPLE_INSURER, NomineeUpdateStatusRequest.class);
                    nomineeUpdateStatusRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, nomineeUpdateStatusRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.GETCOI_INSURER) {
                    GetCoiRequest getCoiRequest = MultipleJSONObjectHelper.getObjectFromString(SwaggerReqResponse.GET_COI_EXAMPLE, GetCoiRequest.class);
                    getCoiRequest.setOrgId(proxy.getOrgId());
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, getCoiRequest, HttpStatus.OK.value(),
                            Boolean.TRUE);
                }
            } else {
                //Registry
                if (proxy.getApiId() == SwaggerReqResponse.ENROLLMENT_DETAILS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.UPDATE_TRA_DETAILS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.UPDATE_ENROLL_STATUS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.PUSH_ENROLLMENT_DEATILS_EXAMPLE_REGISTRY, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.CLAIM_DETAILS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.CLAIM_UPLOAD_DOC) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_DETAILS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE_REGISTRY, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLIAM_DEDUPE) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.CLAIM_DE_DUP_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                } else if (proxy.getApiId() == SwaggerReqResponse.INSURER_UPDATE_STATUS) {
                    return new CommonResponse(CommonErrorMsg.Common.SUCCESS, SwaggerReqResponse.UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE, HttpStatus.OK.value(),
                            Boolean.TRUE);
                }
            }
        } catch (Exception e) {
            log.error("Exception is getting While fetchBankWebhookRequest ", e);
        }
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public CommonResponse fetchJanApiRequest(PostmanCallProxy proxy, AuthClientResponse authClientResponse) {
        try {
            if (!OPLUtils.isObjectNullOrEmpty(proxy.getApiName())) {
                String url = "http://localhost:8065/api/registry/v3" + proxy.getApiName();
//				String url = "https://qa-jns.instantmseloans.in/api/registry/v3"+proxy.getApiName();
                log.info("fetchJanApiRequest For API URL ----------->" + url);
                HttpHeaders headers = new HttpHeaders();
                if (proxy.getEncDecTypeId() == SwaggerReqResponse.IS_ENC_DEC) {
                    headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
                    headers.set("skipEnc", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
                } else if (proxy.getEncDecTypeId() == SwaggerReqResponse.IS_ENC) {
                    headers.set("skipEnc", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
                } else if (proxy.getEncDecTypeId() == SwaggerReqResponse.IS_DEC) {
                    headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
                }
                headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
                headers.set("user-name", proxy.getUserName());
                headers.set("api-key", proxy.getApiKey());
                headers.add("Content-Type", "application/json");
                headers.setContentType(MediaType.APPLICATION_JSON);
                log.info("URL {}", url);
                log.info("Headers {}", MultipleJSONObjectHelper.getStringfromObject(headers));
                Object req = MultipleJSONObjectHelper.getObjectFromString(proxy.getRequest(), Object.class);
                log.info("req {}", MultipleJSONObjectHelper.getStringfromObject(req));
                HttpEntity<Object> entity = new HttpEntity<>(req, headers);
                RestTemplate restTemplate = new RestTemplate();
//					CommonResponse response = restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class)
//							.getBody();
//					if (!OPLUtils.isObjectNullOrEmpty(response)){
//						return new CommonResponse(CommonErrorMsg.Common.SUCCESS, response, HttpStatus.OK.value(),
//								Boolean.TRUE);
//					}
                if (proxy.getApiId() == SwaggerReqResponse.ENROLLMENT_DETAILS) {
                    EnrollmentResProxyV3 enrollmentResponse = restTemplate
                            .exchange(url, HttpMethod.POST, entity, EnrollmentResProxyV3.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(enrollmentResponse)) {
                        log.info("Enter In enrollmentResponse()" + enrollmentResponse);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, enrollmentResponse,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.UPDATE_TRA_DETAILS) {
                    UpdateTransResProxyV3 updateTraResponse = restTemplate
                            .exchange(url, HttpMethod.POST, entity, UpdateTransResProxyV3.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(updateTraResponse)) {
                        log.info("Enter In updateTraResponse()" + updateTraResponse);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, updateTraResponse,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.UPDATE_ENROLL_STATUS) {
                    UpdateStatusResProxyV3 updateStatusResProxyV3 = restTemplate
                            .exchange(url, HttpMethod.POST, entity, UpdateStatusResProxyV3.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(updateStatusResProxyV3)) {
                        log.info("Enter In updateStatusResProxyV3()" + updateStatusResProxyV3);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, updateStatusResProxyV3,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_ENROLLMENTDETAILS) {
                    PushEnrollmentDetailsResponse pushEnrollmentDetailsResponse = restTemplate
                            .exchange(url, HttpMethod.POST, entity, PushEnrollmentDetailsResponse.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(pushEnrollmentDetailsResponse)) {
                        log.info("Enter In pushEnrollmentDetailsResponse()" + pushEnrollmentDetailsResponse);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, pushEnrollmentDetailsResponse,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.CLAIM_DETAILS) {
                    ClaimDetailsResProxyV3 claimDetailsRes = restTemplate
                            .exchange(url, HttpMethod.POST, entity, ClaimDetailsResProxyV3.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(claimDetailsRes)) {
                        log.info("Enter In claimDetailsRes()" + claimDetailsRes);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, claimDetailsRes,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.CLAIM_UPLOAD_DOC) {
                    RegistryResponse registryResponse = restTemplate
                            .exchange(url, HttpMethod.POST, entity, RegistryResponse.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(registryResponse)) {
                        log.info("Enter In RegistryResponse()" + registryResponse);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, registryResponse,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLAIM_DETAILS) {
                    PushEnrollmentDetailsResponse pushClaimDetailsRes = restTemplate
                            .exchange(url, HttpMethod.POST, entity, PushEnrollmentDetailsResponse.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(pushClaimDetailsRes)) {
                        log.info("Enter In pushClaimDetailsRes()" + pushClaimDetailsRes);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, pushClaimDetailsRes,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.PUSH_CLIAM_DEDUPE) {
                    ClaimDeDupResProxyV3 claimDeDupResPonse = restTemplate
                            .exchange(url, HttpMethod.POST, entity, ClaimDeDupResProxyV3.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(claimDeDupResPonse)) {
                        log.info("Enter In claimDeDupResPonse()" + claimDeDupResPonse);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, claimDeDupResPonse,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                } else if (proxy.getApiId() == SwaggerReqResponse.INSURER_UPDATE_STATUS) {
                    RegistryResponse insurerUpdateRes = restTemplate
                            .exchange(url, HttpMethod.POST, entity, RegistryResponse.class).getBody();
                    if (!OPLUtils.isObjectNullOrEmpty(insurerUpdateRes)) {
                        log.info("Enter In insurerUpdateRes()" + insurerUpdateRes);
                        return new CommonResponse(CommonErrorMsg.Common.SUCCESS, insurerUpdateRes,
                                HttpStatus.OK.value(), Boolean.TRUE);
                    }
                }

                return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
            }
        } catch (Exception e) {
            // TODO: handle exception
            log.error("Exception is getting While fetch jansuraksha Api Request  ", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchClaimReports(String request) {
        try {
            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String fromDate = filterJSON.has(FROM_DATE_LITERAL) ? filterJSON.get(FROM_DATE_LITERAL).asText() : null;
            String toDate = filterJSON.has(TO_DATE_LITERAL) ? filterJSON.get(TO_DATE_LITERAL).asText() : null;
            Long schemeId = filterJSON.has(SCHEMEID_LITERAL) ? filterJSON.get(SCHEMEID_LITERAL).asLong() : null;
            Long orgId = filterJSON.has(ORGID_LITERAL) ? filterJSON.get(ORGID_LITERAL).asLong() : null;

            String whereQuery = " where ca.is_active = 1 AND ca.status NOT IN(5,9,12)";

            if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
                whereQuery += " AND ca.org_id = " + orgId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
                whereQuery += " AND ca.scheme_id = " + schemeId;
            }
            if (!OPLUtils.isObjectNullOrEmpty(fromDate) && !OPLUtils.isObjectNullOrEmpty(toDate)) {
                whereQuery += " AND ca.claim_date BETWEEN TO_DATE('" + fromDate + "', 'YYYY-MM-DD') AND TO_DATE('" + toDate + "', 'YYYY-MM-DD')";
            }

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('orgName' value orgName,\r\n"
                    + "   'schemeName' value schemeName,\r\n"
                    + "    'statusName' value statusName,\r\n"
                    + "    'claimDate' value claimDate,\r\n"
                    + "    'status_change_date' value status_change_date,\r\n"
                    + "         	'aging' value aging )returning clob)"
                    + " 			FROM( SELECT uo.organisation_name as orgName,\r\n"
                    + " 			sc.short_name as schemeName,\r\n"
                    + " 		ca.claim_date as claimDate,\r\n"
                    + "        dvs.VALUE as statusName,\r\n"
                    + "        ca.MODIFIED_DATE  as status_change_date,\r\n"
                    + "        (CEIL(CAST(CURRENT_TIMESTAMP AS date) - CAST(ca.claim_date AS DATE))) As aging ";


            String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".clm_master ca " +
                    "inner join " + DBNameConstant.JNS_INSURANCE + ".clm_details cd ON cd.id = ca.id " +
                    "inner join " + DBNameConstant.JNS_USERS + ".scheme_master sc ON sc.id = ca.scheme_id " +
                    "inner join " + DBNameConstant.JNS_USERS + ".user_organisation_master uo ON uo.user_org_id = ca.org_id " +
                    "inner join " + DBNameConstant.JNS_ONEFORM + ".dropdowns_values dvs ON dvs.OBJ_ID = ca.status and dvs.DROPDOWN_ID=14 ";

            String orderBy = "order by ca.org_id desc";

            String mainQuery = selectQuery + tableQuery + whereQuery + orderBy + " )";
//	System.err.print(mainQuery);
            return new CommonResponse(SUCCESSFULLY_GET_DATA_LITERAL,
                    adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);

        } catch (Exception e) {
            log.error("Exception is getting while fetchClaimReports ", e);
        }
        return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Override
    public CommonResponse fetchPushFailList(String request, Long userId) {
        log.info("CALL spAdminUserList('{}', {})", request);
        String spName = "JNS_ADMIN_PANEL.GET_PUSH_FAIL_DATA_V5";
        String fromProducer = adminRepository.getRecordFromProducer(request, userId, spName);
        return new CommonResponse(fromProducer, "", HttpStatus.OK.value());
    }

}
