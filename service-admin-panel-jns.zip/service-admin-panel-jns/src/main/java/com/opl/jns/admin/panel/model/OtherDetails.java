package com.opl.jns.admin.panel.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.utils.common.PatternUtils;
import java.io.*;

/**
 * @author - Maaz Shaikh
 * @Date - 05/08/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OtherDetails implements Serializable {

	public String scheme;

	@NotNull
	public String bankCode;

	public String branchCode;

    public String branchIFSC;

	public String consentForAutoDebit;

	public String userId1;
	public String userId2;
	public String channelId;

	public String ruralUrban;
	
	private final static long serialVersionUID = 9220963440239073079L;

}