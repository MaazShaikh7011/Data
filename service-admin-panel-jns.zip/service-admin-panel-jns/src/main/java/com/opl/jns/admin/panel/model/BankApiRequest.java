package com.opl.jns.admin.panel.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.opl.jns.config.domain.ApiUsersV3;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankApiRequest {

	private Long id;

	private Long orgId;
	private String apiKey;
	private String userName;
	private String ips;
	private String publicKey;
	private String privateKey;
	private String headerConfig;
	private Boolean isActive;
	private String urlConfig;
	private String orgName;
	private Integer totalCount;
	private Integer paginationFROM;
	private Integer paginationTO;
	private Integer configType;
	private Date createdDate;
	private String timeOutConfig;
	
	public BankApiRequest(final ApiUsersV3 obj) {
	    this(obj.getId(), obj.getOrgName(), obj.getConfigType(),obj.getOrgId());
	}

	public BankApiRequest(Long id, String orgName, Integer configType,Long orgId) {
		 super();
        this.id = id;
        this.orgName = orgName;
        this.configType = configType;
        this.orgId = orgId;
	}

}
