package com.opl.jns.admin.panel.service;

import com.opl.jns.admin.panel.model.*;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.config.utils.ConfigMasterProxy;
import com.opl.jns.utils.common.CommonResponse;

import java.io.IOException;
import java.util.List;

public interface AdminServicev3 {

    public String fetchMasterData(String listKey, String whereClause, Long userId);

    public CommonResponse fetchBankApiAuditDetailList(String request, Long userId);

    public String spAdminUserList(String request);

    public String spBankerUserList(String request);

    CommonResponse fetchBankUserList(String request, AuthClientResponse authClientResponse);

    CommonResponse fetchAdminUserList(String request, AuthClientResponse authClientResponse);

    CommonResponse spUserOrganizationList(String request, AuthClientResponse authClientResponse);

    public CommonResponse spGetBranchList(String request, AuthClientResponse authClientResponse);

    public List<Object> getUserType();

    public CommonResponse spOtherUserList(String request, AuthClientResponse authClientResponse);

    public String getAllScheme();

    CommonResponse fetchClaimAppList(String request, AuthClientResponse authClientResponse);

    public String fetchInsurerMstDetailList(String request, Long userId);

    public String getYearsList();

    public String fetchApplicationHistory(String request, Long userId);

    public String getApiConfigMaster();

    public String getConfigMaster();

    public String getTypeMasterForDms();

    public String getDocumentMasterForDms();

    public String getPreMimumMaster();

    public CommonResponse save(ConfigMasterProxy configMasterProxy);

    public CommonResponse activeIsConfigMaster(Long id);

    public ConfigMasterProxy getConfigListById(Long id);

    public CommonResponse FetchNotificationCount(String request);

    public CommonResponse fetchAllInsurerCount(String request);

    public CommonResponse fetchAppBankWiseCount(String request, AuthClientResponse authClientResponse);

    public CommonResponse fetchAppOrgIdwiseCount(String request, AuthClientResponse authClientResponse);

    public CommonResponse fetchClaimBankWiseCount(String request, AuthClientResponse authClientResponse);

    public CommonResponse fetchclaimOrgIdwiseCount(String request, AuthClientResponse authClientResponse);

    public CommonResponse getDocumentListByAppId(String request);

    public CommonResponse getDocumentListByCliamRefId(String request);

    public void updateCountAllBanks();

    public String getUsernameAndApiKey();

    public CommonResponse spFetchAdminEnrollmentList(String request);

    public CommonResponse fetchOrgWiseData(String request, AuthClientResponse authClientResponse);

    public CommonResponse fetchInsurerWiseData(String request, AuthClientResponse authClientResponse);

    public CommonResponse spFetchEnrollmentCount(String request, Long userId);

//    public CommonResponse getReportOrgWise(String request);

    public CommonResponse fetchCoiPushAllCounts(String request, Long userId);

    public CommonResponse fetchNotificationList(String request, Long userId);

    CommonResponse fetchOrgAndInsuranceWiseCount(String request);

    CommonResponse fetchApiAuditDetailList(String request);

    CommonResponse fetchAuditDetails(String request);

    CommonResponse updateEnrollmenrData(EnrollmentRequest enrollmentDetails);

    CommonResponse getPublishReqRes(Long auditId, boolean isRegistry) throws IOException;

    CommonResponse fetchPublishedAppList(String request);

    CommonResponse fetchPublishedClaimList(String request);

    CommonResponse updateTransactionList(List<UpdateTransactionProxy> transactionproxy);

    CommonResponse updateTrasTimeStamp(List<UpdateTraTimeStampProxy> transactionProxy);

    public CommonResponse downloadNotificationList(String request);

    public CommonResponse getUserTknMappingLst(String request);

    public CommonResponse getUserDetails(String request);

    public CommonResponse insertSupportAudit(SupportAuditProxy request);

    public CommonResponse getNotificationAudit(String request);

    public String fetchCityWiseData(String request);

    CommonResponse fetchCityWiseForPolicy(String request, Long userId);

    // OLD
//	CommonResponse fetchApplicationList(String request, AuthClientResponse authClientResponse);

    CommonResponse fetchApplicationListNew(String request, AuthClientResponse authClientResponse);

    public CommonResponse fetchWebhookApiAuditDetailList(String request, Long userId);

    public ApplicationMasterProxy getApplicationAllDetails(Long applicationId);

    public ApplicationMasterProxy getCustomerMasterDetailsList(Long applicationId, Long schemeId);

    public CommonResponse fetchPostmanResponse(PostmanCallProxy proxy, AuthClientResponse authClientResponse);

    public CommonResponse fetchBankWebhookRequest(PostmanCallProxy proxy);

    public CommonResponse fetchJanApiRequest(PostmanCallProxy proxy, AuthClientResponse authClientResponse);

    public CommonResponse fetchClaimReports(String request);

    public CommonResponse fetchPushFailList(String request, Long userId);



}

