package com.opl.jns.admin.panel.model;

import java.util.Date;



import lombok.Data;

@Data
public class NomineeDetailsProxy {


	private Long applicationId;
	private Long addressId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String correctNomineeFirstName;
	private String correctNomineeMiddleName;
	private String correctNomineeLastName;
	private Date dateOfBirth;
	private Boolean pan;
	private String panNumber;
	private Boolean aadhaar;
	private String aadhaarNumber;
	private String mobileNumber;
	private String emailIdOfNominee;
	private String gender;
	private Integer nomineeGenderId;
	private Integer genderId;
	private Integer relationOfNomineeApplicant;
	private String relationOfNomineeApplicantStr;
	private Integer age;

	private String nameOfGuardian;
	private String addressOfGuardian;
	private Integer relationShipOfGuardian;
	private String relationShipOfGuardianStr;
	private String mobileNumberOfGuardian;
	private String emailIdOfGuardian;
	private Long claimId;
	private AddressMasterProxy address;
	
	//phase 2
	private String name;
	private String addressLine1;
	private String addressLine2;

}
