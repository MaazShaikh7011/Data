package com.opl.jns.admin.panel.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostmanCallProxy {

		private Long userTypeId;
		private Integer apiId;
		private Long orgId;
		private String request;
		private String apiKey;
		private String userName;
		private Integer encDecTypeId;
		private String apiName;
}
