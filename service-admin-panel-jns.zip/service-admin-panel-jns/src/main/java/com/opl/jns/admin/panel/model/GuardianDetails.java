package com.opl.jns.admin.panel.model;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.utils.common.PatternUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class GuardianDetails implements Serializable {

    private final static long serialVersionUID = -4654729453217893182L;

    public String relationShip;

    public String firstName;
    
    public String middleName;
    
    public String lastName;
    
    public String address;
    
    public String pincode;

    public String mobile;
    
    public String email;
    
    public String state;

    public String city;
    
    public String district;

}
