package com.opl.jns.admin.panel.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.registry.client.RegistryClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;
import com.opl.jns.webhook.client.WebHookClient;

@SpringBootApplication
@ComponentScan(basePackages = { "com.opl" })
@EnableAutoConfiguration
@EnableScheduling
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableDiscoveryClient
public class AdminPanelMain {

    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) {
        SpringApplication.run(AdminPanelMain.class, args);
    }


    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }
    
	@Bean
	public NotificationClient notificationClient() {
		NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
//		NotificationClient notificationClient = new NotificationClient("https://qa-ans.instantmseloans.in/notification");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
		return notificationClient;
	}
	
    @Bean
    public UsersClient usersClient() {
        UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
        return usersClient;
    }
    
    @Bean
    public BankApiClient bankClient() {
        BankApiClient bankClient = new BankApiClient(URLConfig.fetchURL(URLMaster.BANK_API));
//        BankApiClient bankClient = new BankApiClient("http://localhost:8053/bankapi");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(bankClient);
        return bankClient;
    }
    @Bean
    public WebHookClient webHookClient() {
    	WebHookClient webHookClient = new WebHookClient(URLConfig.fetchURL(URLMaster.WEBHOOK));
//    	WebHookClient webHookClient = new WebHookClient("http://localhost:8068/wb/jns");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(webHookClient);
        return webHookClient;
    }
    @Bean
    public RegistryClient registryClient() {
    	RegistryClient registryClient = new RegistryClient(URLConfig.fetchURL(URLMaster.REGISTRY));
//    	RegistryClient registryClient = new RegistryClient("http://localhost:8065/api/registry");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(registryClient);
        return registryClient;
    }
}
