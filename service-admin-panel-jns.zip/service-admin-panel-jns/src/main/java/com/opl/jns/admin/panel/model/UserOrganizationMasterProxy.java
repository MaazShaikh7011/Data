package com.opl.jns.admin.panel.model;

import java.util.Date;

import lombok.Data;

@Data
public class UserOrganizationMasterProxy {
	
    private Long orgId;
	private String code;

	private String displayOrgName;

	private Boolean isActive;

	private Boolean isReverseApiActivated;

	private Date modifiedDate;

	private Long orgType;

	private String organisationName;

	private Long userTypeId;

}
