package com.opl.jns.admin.panel.model;

import lombok.Data;

@Data
public class BankApiProxy {

	private Long id;
	private Long serviceapikey;
	private Long orgId;
	private String apiKey;
	private String userName;
	private String ips;
	private String publicKey;
	private String privateKey;
	private String headerConfig;
	private Boolean isActive;
	private String urlConfig;
	private String orgName;
}
