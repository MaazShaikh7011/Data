package com.opl.jns.admin.panel.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "count_domain")
@Getter
@Setter
@ToString
public class CountDomain {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "count_domain_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "count_domain_seq_gen", sequenceName = "count_domain_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "orgId", nullable = true)
	private String orgId;

	@Column(name = "name", nullable = true)
	private String name;
	
	@Column(name = "totalCount", nullable = true)
	private Long totalCount;
	
	@Column(name = "CompletedCount", nullable = true)
	private Long CompletedCount;
	
	@Column(name = "RejectedCount", nullable = true)
	private Long RejectedCount;
	
	@Column(name = "ExpiredCount", nullable = true)
	private Long ExpiredCount;
	
	@Column(name = "SendBackToBankCount", nullable = true)
	private Long SendBackToBankCount;
	
}
