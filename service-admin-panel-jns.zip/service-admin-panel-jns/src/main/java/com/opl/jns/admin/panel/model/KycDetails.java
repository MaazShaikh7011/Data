package com.opl.jns.admin.panel.model;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class KycDetails implements Serializable {

    private final static long serialVersionUID = 2117216721498264230L;
    
    public String kycId1;

    public String kycIdValue1;

    public String kycId2;

    public String kycIdValue2;

    public String panNumber;
  
    public String aadhaarNumber;

    public String ckyc;

    public String ckycNumber;

}