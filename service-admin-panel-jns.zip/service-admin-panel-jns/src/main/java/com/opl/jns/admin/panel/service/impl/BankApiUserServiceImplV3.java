package com.opl.jns.admin.panel.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.admin.panel.model.BankApiRequest;
import com.opl.jns.admin.panel.model.EncryptDecryptProxy;
import com.opl.jns.admin.panel.model.SBIEncryptedRequest;
import com.opl.jns.admin.panel.model.SBIEncryptionUtils;
import com.opl.jns.admin.panel.model.UserOrganizationMasterProxy;
import com.opl.jns.admin.panel.repository.AdminRepositoryV3;
import com.opl.jns.admin.panel.service.BankApiUserServiceV3;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.config.domain.ApiUsersV3;
import com.opl.jns.config.domain.UserOrganizationMasterV3;
import com.opl.jns.config.repository.ApiUsersRepositoryV3;
import com.opl.jns.config.repository.UserOrganizationMasterRepoV3;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.xml.bind.DatatypeConverter;
import lombok.extern.slf4j.Slf4j;



@Service
@Slf4j
public class BankApiUserServiceImplV3 implements BankApiUserServiceV3 {
	
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;
	private static final int GCM_TAG_LENGTH = 16;
	private static final String TRANSFORMATION = "AES/GCM/NoPadding";
	private static final String ALGO_AES = "AES";
	private static final String ALGO_RSA = "RSA";
	private static final String ENCODING = "UTF-8";
	private static final String HEADER_ENC_ALGO = "RSA/ECB/OAEPPADDING";
	private static final String SIGNATURE = "SHA256withRSA";
	private static final String SEPARATOR = ":";
	private static final String OPL_PRIVATE_KEY = "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQCfBwYduLF3cMkjThZqFtEysbOA2z6HaI1Q5+9OY2V71HlthlYKWVhaIoRjrEuEtw+Mw/r9KIo8T5XbASnLz9E0qdRfX9ho9dQ7g1j/jyBFD4RAeR1CeeKwwtTXSkgpa47AfmYjes5+3iu1IdatrRIgyXzBXjXDj5plp/1JdOIFMm+sbYsIFnzojSHWCr+N20DlvzFeNTlT2arCG9aSPc9R5xhPw+jwtGddE4wTxQOEPPM2aFdFRfW/af5iYv2CtUQqanllBhajv5VEahm9y935fysecvESQ+ahqu23HPWg43Q19kMfFTSdLyOoM9IxFT85YteMCEXAeY/ufEJt5Ebs8Bv4rlQIoo9MqXYPbEMgpejAcEQwpYwR5yb1Le6t0rA/s+wm8cA32ksK/IbmozykyFNChiwb5KBa/4m0TYQ8SbeXfH5QGnUQggGlCKKw4tnu56YtRdGNSKsuQC+89wf9XP0+WyMZndb3PYN7FBHAOYypNEPd2uZyPw8vh//TA7TA9ZWBmEaV19WpF6g1cuoMmObRaTX9Wn0B2/gKqPIvbtGdDr5vj2CizSKJUKYPGNrV978HWcb+9cVZ8ncPJlHYlLsvmfPRJyPuOuLkmMNx9GTjm6GcjCAuixnXQIk9N/6xlaJqixwuFiWl5pDdUyRLiyuunFgmeUU3D0tn/0ulvQIDAQABAoICAEGBECjf8eHECGXNfXgXi/Y4sjrKlFgMXeFMmAsO8Ddwjs/pfLlokfcWrrerubOh//q4o0LyFva+xXhfY0r7gC4UIlFi1m5tjA0zjk4+M0mfGZfBC6ddM14h8q/3ff/puPRbXFES/cnOU+yZUqdZWdU9iXDREI5MMYncB33hclQ3sT4yJQmg0bSspZpX9Q1GmdXIyloGzGVYjHjGJL06TpJrAV2h0eqMNONm8NUX2tn2jSwFEKWNKqu8yjbWlZvodHqQPw640kyC1sZGefHu7rEdi7JQIDKo23AOSzqY6ChsaGrt1DoSbwir6SEYr2TeXpuRtj2NDsY4jGvsrSQ82mWKQyZil7IUKx3Mz5sbymVLg8MV42mZdXHpNcWTo6JTTOErFkx3W5Cn/HFpFrQ+6c6uzQNopqPW9oyx/sN7d6t8CfOAjMgJ7vN4VVmRV7Q4kjFJ6Qoz5AbV1qFo0TXlFf2WwVX/ryGPnWB3sbWKtRpQRwiXG/iMMRBuh8YumeG+z2n72Qcb/XwjEtZkjuJDuJc/Ht9Jnq3OiH1IkagVpmKhJ4GaraGQTdyfjwpOCeuPyykzLxaUvQNJ7hZpIo6XdWjHxwKuPbtxmiNx+vHvO3Hwa6BJOSU8TUGwAtxIMT4EXwwjSXnIoTsA1XcjTv1IdqIQqaM22sTVuRP7F0et9LLVAoIBAQDOISNqeXHE60mM/QhvtYSF5RNyUI8NGoa44fGPEEuGEJA6vGReKMMoLNk+cnWwBXUCErUhWoesvefyNTB6EcInNurN5ZK/pCwFr9W2IAYmtLRYx86zujYt2QDFgWA/+uAj85khmDYurLgGWqzyuN2723YYVXWSsDslZqbPeahptDbw11jjyUMdp5oFrNyrAYSEf4QVxnaRDvLTHs+aToUcS4b/fab6sy/LYXT8ztDplMQRbmwqVtPjDLUrmgo4PDgmf/vWtHJuEwK0NgFP1DU4qVUNkBx9yJflWy2GQtDXivjk5YA6LpmgNBQDe7WPJLr9ETlA381aooJzQkVrE5t3AoIBAQDFgJGrxToJIQLRY972qMdNlxsfyHzDiPHeVqBkwN9a+r0yKYPM/k0qFuXfHkz0j8rWq6dtscvGXdRflVjpgPVc27yoEcmg9q3tBSOJT7yR/3yeCefoVsuR1zhrK42ZK66ElPTdZIbByJjl1Fhh5ylbCYJBPhRMBxi6sPU5dSQF63qTzB5lhsbYHmXKay8ugkO/CMdcbRNm+0tY72CZMcdJ3UIlOTauiMc7pKGIO8m5RsMjWxGEz2OhtybMo5KImEjSmpSL1UPajiyW5cAItd8bSjTdKfjb1tgZJB8Sna+lIQhC1LVEEZKBre+JQZaSrUEv4+SelUjQNcPPPiEsWG1rAoIBAAxXh5tUci9sNxct/1dQ8wJhWOy7ThVmxTJEtQXv39XDIB+kMA5DOowpQ0it6cYETaE2JYo9tWnuZPjnnmNwtMNMUnrJiCPZXJlqkc051aRzpWi7bfDs8VmFaLpqqKysBMeiSkTsrDHXPZ2DyF8wGnapCUUjuMpzqtbucoZxrlfF5pQ9EKFy54XbBynX086ZZKnaSLpVC7xbvMZPTfbbRLURAKBDkb/pAq+Wwj5w06losuSoS+mtETrDBAX8TyhW0rXba+TLIR7eHIdVxHZXKmieGu2Y91vAqvecofkr/v0o4QYzh530NFaXR6t9uL09YcTNRzRPMih/Gnh0O1vR7LkCggEBAMTTwdkewBzS8jz9O/oz8BQKcHS3WGeCNhFv4X8nnDDOS/kO2JRWJ0637TTzvJvKJcrU3RH8K+mwHvN3IlnrNBvrvVL+DyREUscw5N52QaZ6qJXTp3Or9EqO42Ii0IYCu3TUAkgVZBsBsCbz/XTsbBGXI2Gj3ZR7ShDcRDeT32eq6skalnx12fsOKEGXmjjOh3d95zjcV4a9D7U9MtbZfhPF1qLEJxO/qlZtVrIva3Ui6Vx16Lqj+FX08kzlAybwJTsF5N6KloncQOHNbBkCL6vBw3dZ2fI1Zb2AexsRXTfC+LmpxFBm9swYLO1sGQRqd9mjU3cbraoaut7xuxu3sKsCggEAAOoBDm/ndoiDm4Vpg8HZmjg3WrOVER554kNpC7zDW+6PoojROnuLGYoLvDEsQhmCa08SdEiJYBc8YAYfWDDAzU6JlGNBQOPpb5AlTa6HBkF3C9jZWpbnSgebhIrWNvd2Oy3v0a/7bRaXXuIRdDQBfgg0bXb6gZr4eHm6jmZf5LSMwR+VTJDsS896pj9nYHAUScy3bQRSBVAW83xAWao9dl08DyxDB5xTEamMdrWDegIpZy6JxM+CPgtV5pLwOuIPxeCBpmDjPcu/AjRO+6tWJsQ9FId3W9LLxKDUbrv3zR08BuhF6GsfrbTEBvZOfV4UFykjBmyhJw3vj2JJb4TzNw==";
	public static final String SBI_BANK_CODE = "SBI";

	@Autowired
	private ApiUsersRepositoryV3 apiUsersRepository;

	@Autowired
	private UserOrganizationMasterRepoV3 userOrgMasterRepo;
	
	@Autowired
	AdminRepositoryV3 adminRepository;

	@Override
	public CommonResponse save(BankApiRequest req) {
		try {
			Long id = null;
			ApiUsersV3 apiuser = null;
			if (!OPLUtils.isObjectNullOrEmpty(req.getId())) {
				apiuser = apiUsersRepository.findById(req.getId()).orElse(null);
				if (!OPLUtils.isObjectNullOrEmpty(apiuser)) {
					BeanUtils.copyProperties(req, apiuser, "id", "createdDate", "modified_date");
					apiuser.setModifiedDate(new Date());
				}
			} else {
				apiuser = new ApiUsersV3();
				BeanUtils.copyProperties(req, apiuser, "id", "createdDate", "modified_date");
				apiuser.setCreatedDate(new Date());

			}

			apiuser.setIsActive(true);
			apiuser.setIsInternalUser(false);
			System.err.println(apiuser);
			System.err.println(req);
			id = apiUsersRepository.save(apiuser).getId();
			return new CommonResponse("saved!!!", id, HttpStatus.OK.value(), true);
		} catch (Exception e) {
			 return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public BankApiRequest getApiUserList(Long id) {

		ApiUsersV3 apiUser = apiUsersRepository.findById(id).orElse(null);
		BankApiRequest bankRequest = new BankApiRequest();
		if (apiUser != null) {
			BeanUtils.copyProperties(apiUser, bankRequest);
		}

		return bankRequest;
	}

	@Override
	public List<UserOrganizationMasterProxy> getOrgMasterListByApimasterId() {
		List<UserOrganizationMasterV3> apiorgList = userOrgMasterRepo.findAll();
		List<UserOrganizationMasterProxy> userOrgProxyList = new ArrayList<UserOrganizationMasterProxy>();

		UserOrganizationMasterProxy userProxy = null;
		if (!OPLUtils.isObjectListNull(apiorgList)) {
			for (UserOrganizationMasterV3 orgList : apiorgList) {
				userProxy = new UserOrganizationMasterProxy();
				BeanUtils.copyProperties(orgList, userProxy);
				userOrgProxyList.add(userProxy);
			}
		}
		return userOrgProxyList;
	}

	@Override
    public CommonResponse fetchApiUser(String request, AuthClientResponse authClientResponse) {
        try {

            JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
            String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
            String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
            
            String json1 = filterJSON.has("filterJSON") ? filterJSON.get("filterJSON").asText() : null;
            JsonNode filterJSON1 = MultipleJSONObjectHelper.convertJSONToObject(json1, JsonNode.class); 
            Long orgId = filterJSON1.has("orgId") ? filterJSON1.get("orgId").asLong() : null;
            

//            if (searchData != null) {
//                searchQuery = "AND (uom.user_org_id like " + "'%" + searchData + "%'";
//                searchQuery = searchQuery+"OR uom.organisation_code like " + "'%" + searchData + "%')";
//            }


            String whereClause = " WHERE 1=1 ";
            
////            	whereClause += "AND a.service_api_key =" + serviceapikey;   
//                whereClause += " AND a.service_api_key =" + serviceapikey;    
//            }
            if(!OPLUtils.isObjectNullOrEmpty(orgId)) {
            	whereClause += " AND  a.org_id =" + orgId;     
            }
            
            String selctQuery="""
		            SELECT\s
		                                       a.id as id,
		                                       a.config_type as configType ,
		                                       a.org_id as orgId,
		                                       a.api_key as apiKey,
		                                       a.user_name as userName,
		                                       a.ips as ips,
		                                       a.is_active as isActive,
		                                       a.public_key as publicKey,
		                                       a.private_key as privateKey,
		                                       a.org_name as orgName,\s
		                                       a.time_out_config as timeOutConfig,\s
		                                       a.created_date as createdDate\s
		            """;


            String tableQuery = " FROM  " + DBNameConstant.JNS_CONFIG + ".api_users a" ;
            
            String totalCountSelectQuery = "select json_object('totalCount' value count(a.id)) ";
            
            String orderByQuery = " ORDER BY a.id desc ";
            String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY)";
          
//            System.err.println(totalCountSelectQuery + tableQuery + whereClause);
            String str = adminRepository.fetchCount(totalCountSelectQuery + tableQuery + whereClause);
            JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
            Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

            String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount + " ,"
            		+ "'id' VALUE id,\n "
            		+ "'configType' VALUE configType,\n "
            		+ "'orgId' VALUE orgId,\n"
            		+ " 'apiKey' VALUE apiKey,\n "
            		+ "'userName' VALUE userName,\n"
            		+ " 'ips' VALUE ips,\n"
            		+ " 'isActive' VALUE isActive,\n"
            		+ " 'privateKey' VALUE privateKey,\n"
            		+ " 'orgName' VALUE orgName,\n "
            		+ " 'createdDate' VALUE createdDate,\n "
            		+ " 'timeOutConfig' VALUE timeOutConfig,\n "
            		+ " 'publicKey' VALUE publicKey RETURNING CLOB \n"+
            		") RETURNING CLOB ) from (";

            String mainQuery = selectQuery + selctQuery +tableQuery + whereClause + orderByQuery + limitQuery;
            System.err.println(mainQuery);
            return new CommonResponse("successfully get Data", adminRepository.fetchOptOutApplication(mainQuery), HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }

    }

	@Override
	public CommonResponse activeIsApiUser(Long id) {
		try {
			ApiUsersV3 apiUser = apiUsersRepository.findById(id).orElse(null);
			  if (!OPLUtils.isObjectListNull(apiUser, apiUser.getIsActive())) {
				  apiUser.setIsActive(!apiUser.getIsActive());
				  apiUsersRepository.save(apiUser);
	                return new CommonResponse(apiUser.getIsActive() ? "Api User activate successfully." : "User inactivate successfully.", HttpStatus.OK.value(), Boolean.TRUE);
	            }
			return new CommonResponse("User not found at given id.", HttpStatus.OK.value()); 
		} catch (Exception e) {
			 return new CommonResponse("This application has encountered some error, please try after sometimes.", HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	@Override
	public String encryptDecryptData(EncryptDecryptProxy encryptDecryptProxy)
			throws Exception {

		ApiUsersV3 apiUser = apiUsersRepository.findById(encryptDecryptProxy.getId()).orElse(null);

		String data = null;
		if (!OPLUtils.isObjectNullOrEmpty(encryptDecryptProxy.getEncryptDecryptType())
				&& !OPLUtils.isObjectNullOrEmpty(apiUser)) {
			if (encryptDecryptProxy.getEncryptDecryptType() == INT_1) {
				if(apiUser.getOrgId()==16) {			
					ApiUsersV3 apiUserDefault = apiUsersRepository.findById(1l).orElse(null);
					SBIEncryptedRequest encryptedRequest = encryptedRequestSBI(apiUserDefault.getPrivateKey(),apiUser.getPublicKey(), encryptDecryptProxy.getEncryptDecryptRequest(), apiUser.getOrgId());
					return MultipleJSONObjectHelper.getStringfromObject(encryptedRequest);
				}
				data = encrypt(encryptDecryptProxy.getEncryptDecryptRequest(), OPL_PRIVATE_KEY, apiUser.getPublicKey());
			} else if (encryptDecryptProxy.getEncryptDecryptType() == INT_2) {
				if(apiUser.getOrgId()==16) {
					SBIEncryptionUtils sbiEncryptionUtils=new SBIEncryptionUtils();
					return sbiEncryptionUtils.decrypt(encryptDecryptProxy.getEncryptDecryptRequest(),encryptDecryptProxy.getSecretKey());					
				}
				data = decrypt(encryptDecryptProxy.getEncryptDecryptRequest(), OPL_PRIVATE_KEY, apiUser.getPublicKey());
			}
		}
		return data;
	}

	/** ---------------------------- ENCRYPTION - DECRYPTION START ---------------------------- */
	public String decrypt(String encText, String privateKey, String publicKey)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException,
			BadPaddingException, SignatureException, InvalidAlgorithmParameterException, NoSuchProviderException,
			InvalidKeySpecException, CertificateException, IOException {

		String split[] = new String(Base64.getDecoder().decode(encText)).split(SEPARATOR);
		String headerKey = split[0];
		String encryptionRequestBody = split[1];
		String digitalSignature = split[2];
		String decryptedHeader = decryptHeader(headerKey, privateKey);
		String decrypt = decSignSHA256RSA(encryptionRequestBody, digitalSignature, publicKey);
		byte[] aesKey = decryptedHeader.getBytes();
		byte[] iv = getIVFromAESKey(aesKey);
		return decryptRequestBody(Base64.getDecoder().decode(decrypt), decryptedHeader.getBytes(), iv);
	}
	
	public String encrypt(String plainText, String privateKey, String publicKey)
			throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			SignatureException, UnsupportedEncodingException, NoSuchProviderException {

		String dynamicKey = UUID.randomUUID().toString().replaceAll("-", "");
		byte[] iv = getIVFromAESKey(dynamicKey.getBytes());
		byte[] encrypt = encryptRequestBodyAES256(plainText.getBytes(), dynamicKey.getBytes(), iv);
		String encryptionRequestBody = Base64.getEncoder().encodeToString(encrypt);
		String digitalSignature = signSHA256RSA(encryptionRequestBody, privateKey);
		String headerKey = getEncryptHeader(dynamicKey, publicKey);
		return Base64.getEncoder().encodeToString(
				(headerKey + SEPARATOR + encryptionRequestBody + SEPARATOR + digitalSignature).getBytes());
	}

	private String decryptRequestBody(byte[] cipherText, byte[] key, byte[] IV) throws NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
			BadPaddingException, NoSuchProviderException {

		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKeySpec keySpec = new SecretKeySpec(key, ALGO_AES);
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
		byte[] decryptedText = cipher.doFinal(cipherText);
		return new String(decryptedText);
	}

	private String decryptHeader(String data, String privatekey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException,
			InvalidKeyException, InvalidKeySpecException {

		byte[] encryptedData = Base64.getDecoder().decode(data);
		PrivateKey privateKey = getPrivateKey(privatekey);
		Cipher cipher = Cipher.getInstance(HEADER_ENC_ALGO);
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] encryptedByte = cipher.doFinal(encryptedData);
		return new String(encryptedByte);
	}

	private static byte[] getIVFromAESKey(byte[] encoded) {
		return Arrays.copyOfRange(encoded, 0, 16);
	}

	private PrivateKey getPrivateKey(String privateKeyStr) throws NoSuchAlgorithmException, InvalidKeySpecException {

		PrivateKey privateKey = null;
		KeyFactory keyFactory = null;
		byte[] encoded = DatatypeConverter.parseBase64Binary(privateKeyStr);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
		keyFactory = KeyFactory.getInstance(ALGO_RSA);
		privateKey = keyFactory.generatePrivate(keySpec);
		return privateKey;
	}

	private String decSignSHA256RSA(String encryptionRequestBody, String digitalSignature, String strPk)
			throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, CertificateException,
			IOException {

		String k = strPk.replaceAll("\n", "").replace("\r", "");
		Signature privateSignature = Signature.getInstance(SIGNATURE);
		privateSignature.initVerify(getPublicKey(k));
		byte[] bytes = encryptionRequestBody.getBytes(ENCODING);
		privateSignature.update(bytes);
		privateSignature.verify(Base64.getDecoder().decode(digitalSignature));
		return encryptionRequestBody;
	}

	private PublicKey getPublicKey(String publicKeyStr) {

		PublicKey publicKey = null;
		try {
			CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
			BufferedReader br = new BufferedReader(new StringReader(publicKeyStr));
			String line = null;
			StringBuilder keyBuffer = new StringBuilder();
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("-")) {
					keyBuffer.append(line);
				}
			}
			Certificate certificate = certificateFactory
					.generateCertificate(new ByteArrayInputStream(Base64.getDecoder().decode(keyBuffer.toString())));
			publicKey = certificate.getPublicKey();
		} catch (Exception var8) {
			var8.printStackTrace();
		}
		return publicKey;
	}

	private byte[] encryptRequestBodyAES256(byte[] plaintext, byte[] key, byte[] IV)
			throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
			BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException {

		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKeySpec keySpec = new SecretKeySpec(key, ALGO_AES);
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);
		return cipher.doFinal(plaintext);
	}

	private String signSHA256RSA(String input, String privateKeyStr) throws NoSuchAlgorithmException,
			InvalidKeyException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException {

		byte[] b1 = DatatypeConverter.parseBase64Binary(privateKeyStr);
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
		KeyFactory kf = KeyFactory.getInstance(ALGO_RSA);
		Signature privateSignature = Signature.getInstance(SIGNATURE);
		privateSignature.initSign(kf.generatePrivate(spec));
		byte[] bytes = input.getBytes(ENCODING);
		privateSignature.update(bytes);
		byte[] s = privateSignature.sign();
		return Base64.getEncoder().encodeToString(s);
	}

	private String getEncryptHeader(String keyPlainText, String publicKeyStr) {
		try {
			byte[] keyByteArr = keyPlainText.getBytes();
			PublicKey key = getPublicKey(publicKeyStr);
			Cipher cipher = Cipher.getInstance(HEADER_ENC_ALGO);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encryptedByte = cipher.doFinal(keyByteArr);
			return Base64.getEncoder().encodeToString(encryptedByte);
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
	/** ---------------------------- ENCRYPTION - DECRYPTION END ---------------------------- */

	/**
     * SBI REQUEST ENCRYPTION
     * @param request
     * @param orgId
     * @param userId
     * @return
	 * @throws Exception 
     * @throws CommonException
     */
    public static SBIEncryptedRequest encryptedRequestSBI(String privateKey,String publicKey, String request, Long orgId) throws Exception {
			SBIEncryptionUtils sbiEncryptionUtils=new SBIEncryptionUtils();
			return sbiEncryptionUtils.prepareRequest(request, privateKey, publicKey, SBI_BANK_CODE);
    }
	
	@Override
	public List<BankApiRequest> getAllApiUserList() {
		List<ApiUsersV3> apiUser = apiUsersRepository.findAllByOrderByOrgIdAsc();
		List<BankApiRequest> bankRequest = new ArrayList<>();
		if (!OPLUtils.isListNullOrEmpty(apiUser)) {
			bankRequest = apiUser.stream().map(obj -> new BankApiRequest(obj.getId(), obj.getOrgName(),obj.getConfigType(),obj.getOrgId()))
					.collect(Collectors.toList());
		}
		return bankRequest;
	}

	@Override
	public BankApiRequest getApiUserListByOrgId(Long orgId) {
		try {
			ApiUsersV3 apiUser = apiUsersRepository.findFirstByOrgId(orgId);
			BankApiRequest bankRequest = new BankApiRequest();
			if (apiUser != null) {
				BeanUtils.copyProperties(apiUser, bankRequest);
			}
			return bankRequest;
		} catch (Exception e) {
			log.error("Exception is getting while getApiUserListByOrgId", e);	
		}
		return null;

	}
}
