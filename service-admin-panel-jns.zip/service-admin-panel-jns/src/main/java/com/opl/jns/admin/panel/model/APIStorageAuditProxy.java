package com.opl.jns.admin.panel.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class APIStorageAuditProxy implements Serializable {

	private final static long serialVersionUID = 2729134690963093267L;
	
	private Long id;
	private Long logAudit;
	private String storageId;
	private Integer typeId;
	private Date createdDate;

}
