package com.opl.jns.admin.panel.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.*;
import java.util.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EnrollmentRequest implements Serializable {

    private final static long serialVersionUID = -4357839815853867628L;
    
    public Long applicationId;
    
    public String urn;

    public CustomerDetails customerDetails;
	
    public KycDetails kycDetails;   

    public NomineeDetails nomineeDetails;
	
    public GuardianDetails guardianDetails;

    public OtherDetails otherDetails;

}