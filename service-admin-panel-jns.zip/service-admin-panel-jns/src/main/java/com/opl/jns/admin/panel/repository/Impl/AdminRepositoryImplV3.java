package com.opl.jns.admin.panel.repository.Impl;

import java.io.IOException;
import java.sql.Clob;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.admin.panel.repository.AdminRepositoryV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class AdminRepositoryImplV3 implements AdminRepositoryV3 {

	@Autowired
	EntityManager entityManager;
	
	private static final String USERID_LITERAL = "userid";
	private static final String RESULT_LITERAL = "result";
	private static final String PAGINATIONTO_LITERAL = "paginationTO";
	private static final String PAGINATIONFROM_LITERAL = "paginationFROM";
	private static final String FILTERJSON_LITERAL = "filterJSON";
	private static final String SELECT_JSON_OBJECT_LITERAL = "SELECT json_object";

	@Override
	public String getRecordFromProducer(String requestJson, Long userId, String spName) {
		try {

			log.info("ENTER IN getRecordFromProducer() :::::::::> ");
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(USERID_LITERAL, Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(RESULT_LITERAL, Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter("filterjson", requestJson);
			storedProcedureQuery.setParameter(USERID_LITERAL, userId);
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue(RESULT_LITERAL));
		} catch (Exception e) {
			log.error("ERROR IN  getRecordFromProducer() ::: {} ", e.getMessage());
		}
		return null;
	}
	
	
	  public String commonSPcall(Map<String, Object> params,  Long userId, String spName) {
	        
	        try {
	            log.info("ENTER IN commonSPcall() :::::::::> ");
	            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
	            if(!OPLUtils.isObjectListNull(params)) {
	            	
	                for(Map.Entry<String, Object> entry : params.entrySet()) {
	                    storedProcedureQuery.registerStoredProcedureParameter(entry.getKey(), entry.getValue().getClass(), ParameterMode.IN);       
	                    storedProcedureQuery.setParameter(entry.getKey(), entry.getValue());
	                }                               
	            }
	            storedProcedureQuery.registerStoredProcedureParameter(USERID_LITERAL, Long.class, ParameterMode.IN);
	            storedProcedureQuery.setParameter(USERID_LITERAL, userId);
	            storedProcedureQuery.registerStoredProcedureParameter(RESULT_LITERAL, Clob.class, ParameterMode.OUT);
	            
	            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue(RESULT_LITERAL));
	            
	        } catch (Exception e) {
	            log.error("ERROR IN  getRecordFromProducer() ::: {} ", e.getMessage());
	        }

	        return null;
	    }
	
	

	@Override
	public String GetAdminCommonList(String listKey, Long whereClause, Long userId, String spName) {
		try {

			log.info("ENTER IN GetAdminCommonList() :::::::::> ");
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter("listKey", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("whereClause", Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(USERID_LITERAL, Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(RESULT_LITERAL, Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter("listKey", listKey);
			storedProcedureQuery.setParameter("whereClause", whereClause);
			storedProcedureQuery.setParameter(USERID_LITERAL, userId);
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue(RESULT_LITERAL));
		} catch (Exception e) {
			log.error("ERROR IN  getRecordFromProducer() ::: {} ", e.getMessage());
		}
		return null;
	}

	@Override
	public String spAdminUserList(String request, String spName) {
		try {

			log.info("ENTER IN spAdminUserList() :::::::::> ");
			JsonNode jsonNode = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
			String filterJSON = jsonNode.has(FILTERJSON_LITERAL) ? jsonNode.get(FILTERJSON_LITERAL).toString() : "";
			String paginationFROM = jsonNode.has(PAGINATIONFROM_LITERAL) ? jsonNode.get(PAGINATIONFROM_LITERAL).asText() : "";
			String paginationTO = jsonNode.has(PAGINATIONTO_LITERAL) ? jsonNode.get(PAGINATIONTO_LITERAL).asText() : "";
			
			
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter(FILTERJSON_LITERAL, String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(PAGINATIONFROM_LITERAL, Integer.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(PAGINATIONTO_LITERAL, Integer.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(RESULT_LITERAL, Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter(FILTERJSON_LITERAL, filterJSON	);
			storedProcedureQuery.setParameter(PAGINATIONFROM_LITERAL, Integer.valueOf(paginationFROM));
			storedProcedureQuery.setParameter(PAGINATIONTO_LITERAL, Integer.valueOf(paginationTO));
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue(RESULT_LITERAL));
		} catch (Exception e) {
			log.error("ERROR IN  getRecordFromProducer() ::: {} ", e.getMessage());
		}
		return null;
	}
	
	@Override
	public String spBankerUserList(String request, String spName) {
		try {

			log.info("ENTER IN spAdminUserList() :::::::::> ");
			JsonNode jsonNode = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
			String filterJSON = jsonNode.has(FILTERJSON_LITERAL) ? jsonNode.get(FILTERJSON_LITERAL).toString() : "";
			String paginationFROM = jsonNode.has(PAGINATIONFROM_LITERAL) ? jsonNode.get(PAGINATIONFROM_LITERAL).asText() : "";
			String paginationTO = jsonNode.has(PAGINATIONTO_LITERAL) ? jsonNode.get(PAGINATIONTO_LITERAL).asText() : "";
			
			
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter(FILTERJSON_LITERAL, String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(PAGINATIONFROM_LITERAL, Integer.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(PAGINATIONTO_LITERAL, Integer.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter(RESULT_LITERAL, Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter(FILTERJSON_LITERAL, filterJSON	);
			storedProcedureQuery.setParameter(PAGINATIONFROM_LITERAL, Integer.valueOf(paginationFROM));
			storedProcedureQuery.setParameter(PAGINATIONTO_LITERAL, Integer.valueOf(paginationTO));
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue(RESULT_LITERAL));
		} catch (Exception e) {
			log.error("ERROR IN  getRecordFromProducer() ::: {} ", e.getMessage());
		}
		return null;
	}
	
	@Override
    public String fetchOptOutApplication(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }
    
    @Override
    public String fetchCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }
    
    
    @Override
    public String spOtherUserList(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }
    
//	@Query(value = "CALL spOtherUserList(:filterJSON, :paginationFROM, :paginationTO)", nativeQuery = true)
    
    @Override
    public String fetchspOtherUserListCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }


	@Override
	public List<Object> getUserType() {

        log.info("ENTER IN getUserType() :::::::::> ");
         String Query="SELECT json_arrayagg(json_Object( u.id,'typeName'value u.name)returning clob)   FROM "+DBNameConstant.JNS_USERS+".user_type_master u WHERE is_active=1";
         System.out.print(Query);   
         String out=OPLUtils.readClob((Clob) entityManager.createNativeQuery(Query).getSingleResult());
             try {
                List<Object> result = MultipleJSONObjectHelper.getListOfObjects(out, null, Object.class);
                return result;
            } catch (IOException e) {
                log.error("ERROR IN  getUserType() ::: {} ", e.getMessage());
            }
        return null;
    }
	
	@Override
	public String getAllScheme() {
        try {
            return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT( 'id' value sm.id, 'schemeName' value sm.name, 'name' value sm.short_name)) from jns_users.scheme_master sm")                    
                    .getSingleResult();
        } catch(Exception e) {
        	log.error("Exception while fetch scheme list", e);
            return null;
        }
    }
	public String getYearsList() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT json_object('year' value year)from (SELECT distinct(imd.year) as year FROM "+DBNameConstant.JNS_INSURANCE+".insurer_mst_details imd where imd.year is not null order by imd.year asc )")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while fetch scheme list", e);
            return null;
        }
	}
	
	public List<Object>adminPermissionList(String whereclause){
		String Query=" SELECT JSON_OBJECT( 'displayName' value m.display_name ,'menuId' value u.menu_id,'id'  value m.id,'isParent' value m.parent_id,'IsActive' value u.is_active) \r\n"
				+ " FROM jns_users.menu_master m LEFT JOIN jns_users.menu_role_mapping u ON (u.menu_id=m.id AND u.type_id=5 AND u.role_id= "+whereclause+" AND  u.is_active=1 ) WHERE m.is_active=1 And  m.type ='Admin Panel' order by m.admin_seq\r\n"
				+ "";
		return entityManager.createNativeQuery(Query).getResultList();
	}
	
	public List<Object> fetchListOfDataFromDb(String Query){
		log.info("Query -> [{}]",Query);
		return entityManager.createNativeQuery(Query).getResultList();
	}

	public String getApiConfigMaster() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT json_object('id' value id ,'code' value code ,'isActive' value is_active,'value' value value) FROM "+DBNameConstant.JNS_CONFIG+".api_config_master")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while getApiConfigMaster", e);
            return null;
        }
	}
	
	public String getConfigMaster() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT json_object('id' value id ,'code' value code ,'isActive' value is_active,'value' value value) FROM "+DBNameConstant.JNS_CONFIG+".config_master ")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while getConfigMaster", e);
            return null;
        }
	}

	public String getTypeMasterForDms() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT JSON_OBJECT("
            		+ "'id' value id ,'typeId' value type_id ,'schemeId' value scheme_id,'type' value type , 'desc' value desc_ ,'isActive' value is_active) "
            		+ "FROM "+DBNameConstant.JNS_DMS+".type_master ")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while getTypeMasterForDms", e);
            return null;
        }
	}

	
	public String getDocumentMasterForDms() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT JSON_OBJECT("
            		+ "'id' value id ,'name' value name,'size' value size_ ,'type' value type ,'isActive' value is_active ) "
            		+ "FROM "+DBNameConstant.JNS_DMS+".document_master ")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while getDocumentMasterForDms", e);
            return null;
        }
	}
	
	public String getPreMimumMaster() {
		try {
            List<Object>list=  entityManager.createNativeQuery("SELECT JSON_OBJECT("
            		+ "'id' value id ,'pujjbyPermium' value pmjjby_premium,'pusbyPermium' value pmsby_premium ,'quarterMonths' value quarter_months ,'isActive' value is_active ) "
            		+ "FROM "+DBNameConstant.JNS_INSURANCE+".premium_master ")                    
                    .getResultList();
            return OPLUtils.isListNullOrEmpty(list)?null:list.toString();
        } catch(Exception e) {
        	log.error("Exception while getPreMimumMaster", e);
            return null;
        }
	}
	
	public String getUsernameAndApiKey() {
		try {
		       return (String) entityManager.createNativeQuery("select (json_object( ap.api_key,ap.user_name )) from JNS_CONFIG.api_users ap WHERE org_id =0 ")                    
	                    .getSingleResult();
        } catch(Exception e) {
        	log.error("Exception while getUsernameAndApiKey", e);
            return null;
        }
	}

	@Override
	public String spFetchAdminEnrollmentList(String request, String spName) {
		  try {
		            log.info("spName {}, request-> {}", spName, request);
		            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
		            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
		            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
		            storedProcedureQuery.setParameter("filterjson", request);
		            storedProcedureQuery.execute();
		            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
		        } catch (Exception e) {
		            log.error("Exception is getting while Call SP FetchAdminEnrollmentList", e.getMessage());
		        }
		        return null;
		    }


	public Map<String, Object> spFetchEnrollmentCount(String query) {
		try {
			String singleResult = (String) entityManager.createNativeQuery(query).getSingleResult();
			if (OPLUtils.isObjectNullOrEmpty(singleResult)) {
				return null;
			}
			return MultipleJSONObjectHelper.getMapFromString(singleResult);
		} catch (Exception e) {
			log.error("Exception while getUsernameAndApiKey", e);
			return null;
		}
	}

	@Override
	public String executeNativeQuery(String query) {
		return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
	}
	
	@Override
	public Timestamp getpushDate(String Query){
		return  (Timestamp) entityManager.createNativeQuery(Query).getSingleResult();
	}

	public int updatePublishData(String Query){
		//entityManager.createNativeQuery(query).
		return entityManager.createNativeQuery(Query)				
				.executeUpdate();
	}


	@Override
	public String getDataFromProducer(String request, Long userId, String spName) {
		try {
			log.info("spName {}, request-> {}, userId-> {}", spName, request, userId);
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter("filterjson", request);
			storedProcedureQuery.setParameter("userid", userId);
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
		} catch (Exception e) {
			log.error("Exception is getting while Call SP", e.getMessage());
		}
		return null;
	}


}


