package com.opl.jns.admin.panel.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UpdateTransactionStatus {
	
	List<Long> applicationList;
	List<Long> alreadyCompletedList;
	List<Long> dedupeList;
	List<Long> dedupeMasterList;
	List<Long> errorList;
	List<Long> applicationNotFoundList;
	List<Long> transactionDetailsErrorList;
	Map<String,String> dedupeListMap;
	Map<String,String> dedupeMasterListMap;

}
