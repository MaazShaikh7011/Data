package com.opl.jns.admin.panel.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTraTimeStampProxy implements Serializable {

	private final static long serialVersionUID = -4357839815853867628L;

	public Long insTransactionId;
	public String insTransTimeStamp;
	public Long pubTransactionId;
	public String pubTransTimeStamp;
}
