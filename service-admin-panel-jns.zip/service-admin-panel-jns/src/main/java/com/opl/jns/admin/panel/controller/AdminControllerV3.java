package com.opl.jns.admin.panel.controller;

import com.opl.jns.admin.panel.model.*;
import com.opl.jns.admin.panel.service.AdminServicev3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.ConfigMasterProxy;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping("/v3")
public class AdminControllerV3 {

    @Autowired
    AdminServicev3 adminService;

    /**
     * FETCH BANK API AUDIT DETAILS
     *
     * @param authClientResponse
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchBankApiAuditDetailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchBankApiAuditDetailList(@RequestBody String request,
                                                                      @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchBankApiAuditDetailList()" + request);
            return new ResponseEntity<>(
                    adminService.fetchBankApiAuditDetailList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Bank Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH NOTIFICATION COUNT
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchNotificationCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchNotificationCount(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchNotificationCount()" + request);
            return new ResponseEntity<>(adminService.FetchNotificationCount(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchNotificationCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ALL BANKWISE INSUERER COUNT LIST FOR ENROLLMENT AND CLAIM
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchAllInsurerCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchAllInsurerCount(@RequestBody String request,
                                                               @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchInsurerCount()" + request);
            return new ResponseEntity<>(adminService.fetchAllInsurerCount(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchInsurerCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH INSURER MST DETAILS LIST
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchInsurerMstDetailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchInsurerMstDetailList(@RequestBody String request,
                                                                    @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchInsurerMstDetailList()" + request);
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.fetchInsurerMstDetailList(request, authClientResponse.getUserId()),
                    HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchInsurerMstDetailList --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchApplicationHistory", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchApplicationHistory(@RequestBody String request,
                                                                  @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchApplicationHistory()" + request);
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.fetchApplicationHistory(request, authClientResponse.getUserId()),
                    HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchApplicationHistory --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getYearsList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getYearsList() {
        try {
            log.info("Enter In getYearsList()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getYearsList(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getYears List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * GET ADMIN COMMON LIST
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchMasterData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> GetAdminCommonList(@RequestBody AdminRequest request,
                                                             @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In GetAdminCommonList()" + request);
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(
                            CommonErrorMsg.Common.SUCCESS, adminService.fetchMasterData(request.getListKey(),
                            request.getWhereClause(), authClientResponse.getUserId()),
                            HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while GetAdminCommon List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/spAdminUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spAdminUserList(@RequestBody String request) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                return new ResponseEntity<>(new CommonResponse("Bad request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
            }
            String response = adminService.spAdminUserList(request);
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new ResponseEntity<>(new CommonResponse("No data Found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE), HttpStatus.NO_CONTENT);
            }
            log.info("Successfully get spAdminUserList");
            return new ResponseEntity<>(new CommonResponse("success", response, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while get spAdminUserList", e);
            return new ResponseEntity<>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/spBankerUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spBankerUserList(@RequestBody String request) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                return new ResponseEntity<>(
                        new CommonResponse("Bad request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),
                        HttpStatus.OK);
            }
            String response = adminService.spBankerUserList(request);
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new ResponseEntity<>(
                        new CommonResponse("No data Found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE),
                        HttpStatus.NO_CONTENT);
            }
            log.info("Successfully get spBankerUserList detail");
            return new ResponseEntity<>(new CommonResponse("success", response, HttpStatus.OK.value(), Boolean.TRUE),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while get spBankerUserList detail", e);
            return new ResponseEntity<>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                    HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * FETCH BankerUserList
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchBankUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchBankUserList(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(adminService.fetchBankUserList(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchBankUserList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * GET BRANCH LIST
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/getBranchList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getBranchList(@RequestBody String request,
                                                        @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                return new ResponseEntity<>(
                        new CommonResponse("Bad request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(adminService.spGetBranchList(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getBranchList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/fetchAdminUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchAdminUserList(@RequestBody String request,
                                                             @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(adminService.fetchAdminUserList(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * GET BankMaster Organization List
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/spUserOrganizationList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spUserOrganizationList(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(adminService.spUserOrganizationList(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getAllUserType", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getAllUserType(@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            List<Object> response = adminService.getUserType();
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new ResponseEntity<CommonResponse>(
                        new CommonResponse("Its seems system has not found details by requested details",
                                HttpStatus.BAD_REQUEST.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(CommonErrorMsg.Common.SUCCESS, response, HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch user type list  ==>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH OtherUser List
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/spOtherUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spOtherUserList(@RequestBody String request,
                                                          @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                return new ResponseEntity<>(
                        new CommonResponse("Bad request", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(adminService.spOtherUserList(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while spOtherUserList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getAllScheme", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getAllScheme(
            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            String response = adminService.getAllScheme();
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new ResponseEntity<CommonResponse>(
                        new CommonResponse("Its seems system has not found details by requested details",
                                HttpStatus.BAD_REQUEST.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(CommonErrorMsg.Common.SUCCESS, response, HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch scheme list  ==>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ApplicationList FOR ApplicationView
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchApplicationList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchApplicationList(@RequestBody String request,
                                                               @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(adminService.fetchApplicationListNew(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchApplicationList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ClaimList FOR ApplicationView
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchClaimAppList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchClaimAppList(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(adminService.fetchClaimAppList(request, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchEnrollmentCounts ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //GET DATA api_config_master.JNS_CONFIG
    @GetMapping(value = "/getApiConfigMaster", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getApiConfigMaster() {
        try {
            log.info("Enter In getApiConfigMaster()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getApiConfigMaster(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getApiConfigMaster List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //GET DATA config_master.JNS_CONFIG
    @GetMapping(value = "/getConfigMaster", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getConfigMaster() {
        try {
            log.info("Enter In getConfigMaster()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getConfigMaster(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getConfigMaster List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //GET DATA type_master.JNS_DMS
    @GetMapping(value = "/getTypeMasterForDms", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getTypeMasterForDms() {
        try {
            log.info("Enter In getTypeMasterForDms()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getTypeMasterForDms(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getTypeMasterForDms List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //GET DATA document_master.JNS_DMS
    @GetMapping(value = "/getDocumentMasterForDms", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getDocumentMasterForDms() {
        try {
            log.info("Enter In getDocumentMasterForDms()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getDocumentMasterForDms(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getDocumentMasterForDms List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //GET DATA premium_master.JNS_INSURANCE
    @GetMapping(value = "/getPreMimumMaster", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getPreMimumMaster() {
        try {
            log.info("Enter In getPreMimumMaster()");
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.getPreMimumMaster(), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getPreMimumMaster List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //SAVE  api_config_master.JNS_CONFIG
    @PostMapping(value = "/saveConfigMaster", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> saveConfigMaster(@RequestBody ConfigMasterProxy configMasterProxy) {
        try {
            return new ResponseEntity<>(adminService.save(configMasterProxy), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while save Api Users ==>", e);
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/activeIsConfigMaster/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> activeIsApiUser(@PathVariable("id") Long id) {
        try {
            if (OPLUtils.isObjectListNull()) {
                return new ResponseEntity<>(new CommonResponse("Invalid Request", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<>(adminService.activeIsConfigMaster(id), HttpStatus.OK);

        } catch (Exception e) {
            log.error("Error while isActive Config!!");
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getConfigListById/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @SkipInterceptor
    public ResponseEntity<CommonResponse> getConfigListById(@PathVariable("id") Long id) {
        try {
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Successfully get config List Details!!",
                            adminService.getConfigListById(id), HttpStatus.OK.value(), true),
                    HttpStatus.OK);

        } catch (Exception e) {
            log.error("Exception while  get config User Details ==>", e);
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.OK);
        }
    }

    /**
     * FETCH BANKWISE ENROLLMENTCOUNT
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchAppBankWiseCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchAppBankWiseCount(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchAppBankWiseCount()" + request);
            return new ResponseEntity<>(adminService.fetchAppBankWiseCount(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Application  BankWiseCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ORGID WISE ENROLLMENTCOUNT
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchAppOrgIdwiseCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchAppOrgIdwiseCount(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchAppBankWiseCount()" + request);
            return new ResponseEntity<>(adminService.fetchAppOrgIdwiseCount(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Enrollment  OrgIdwiseCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH BANKWISE CLAIM COUNT
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchClaimBankWiseCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchClaimBankWiseCount(@RequestBody String request,
                                                                  @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchClaimBankWiseCount()" + request);
            return new ResponseEntity<>(adminService.fetchClaimBankWiseCount(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Claim  BankWiseCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ORGID WISE CLAIM COUNT
     *
     * @param request
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/fetchclaimOrgIdwiseCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchclaimOrgIdwiseCount(@RequestBody String request,
                                                                   @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchclaimOrgIdwiseCount()" + request);
            return new ResponseEntity<>(adminService.fetchclaimOrgIdwiseCount(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Cliam  OrgIdwiseCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * GET DOCUMENTLIST BY APPLICATIONID AND CLAIMID FOR CLIAM LIST IN APPLICATION VIEW
     *
     * @param applicationId
     * @param claimId
     * @return
     */
    @PostMapping(value = "/getDocumentListByAppId", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getDocumentListByAppId(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In getDocumentListByAppId()" + request);
            return new ResponseEntity<>(adminService.getDocumentListByAppId(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Document List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * GET DOCUMENTLIST BY claimRefId FOR PUBLISHED CLIAM LIST IN APPLICATION VIEW
     *
     * @param applicationId
     * @param claimId
     * @return
     */
    @PostMapping(value = "/getDocumentListByCliamRefId", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getDocumentListByCliamRefId(@RequestBody String request,
                                                                      @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In getDocumentListByCliamRefId()" + request);
            return new ResponseEntity<>(adminService.getDocumentListByCliamRefId(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Document List BY CliamRefId--->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getUsernameAndApiKey", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getUsernameAndApiKey() {
        try {
            String response = adminService.getUsernameAndApiKey();
            if (OPLUtils.isObjectNullOrEmpty(response)) {
                return new ResponseEntity<CommonResponse>(
                        new CommonResponse("Its seems system has not found details by requested details",
                                HttpStatus.BAD_REQUEST.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse(CommonErrorMsg.Common.SUCCESS, response, HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getUsernameAndApiKey List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ENROLLMENTLIST FOR API AUDIT DETAILS LOG
     *
     * @param authClientResponse
     * @param request
     * @return
     */
    @PostMapping(value = "/spFetchAdminEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spFetchAdminEnrollmentList(@RequestBody String request,
                                                                     @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                log.error("Reuqest parameters missing.");
                return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
            }
            log.info("Enter In spFetchAdminEnrollmentList()" + request);
            return new ResponseEntity<>(adminService.spFetchAdminEnrollmentList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Document List BY CliamRefId--->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * GET POLICY DATA ORG WISE
     *
     * @param authClientResponse
     * @param request
     * @return
     */
    @PostMapping(value = "/getGetPolicyBarChartOrgWise", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getGetPolicyBarChartOrgWise(@RequestBody String request,
                                                                      @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In getGetPolicyBarChartOrgWise()" + request);
            return new ResponseEntity<>(adminService.fetchOrgWiseData(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getGetPolicyBarChartOrgWise--->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * GET POLICY DATA INSURER WISE
     *
     * @param authClientResponse
     * @param request
     * @return
     */
    @PostMapping(value = "/getGetPolicyBarChartInsurerWise", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getGetPolicyBarChartInsurerWise(@RequestBody String request,
                                                                          @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In getGetPolicyBarChartInsurerWise()" + request);
            return new ResponseEntity<>(adminService.fetchInsurerWiseData(request, authClientResponse),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getGetPolicyBarChartInsurerWise--->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/spFetchEnrollmentCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> spFetchEnrollmentCount(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In spFetchEnrollmentCount()");
            return new ResponseEntity<>(
                    adminService.spFetchEnrollmentCount(request, authClientResponse.getUserId()),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Document List BY CliamRefId--->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

//	@PostMapping(value = "/getReportOrgWise", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> getReportOrgWise(@RequestBody String request) {
//		try {
//			log.info("Enter In getReportOrgWise()");
//			return new ResponseEntity<>(adminService.getReportOrgWise(request), HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while getReportOrgWise--->", e);
//			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//		}
//	}


    @PostMapping(value = "/fetchCoiPushAllCounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchCoiPushAllCounts(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchCoiPushAllCounts()" + request);
            return new ResponseEntity<>(adminService.fetchCoiPushAllCounts(request, authClientResponse.getUserId()),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchCoiPushAllCounts List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/fetchNotificationList", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchNotificationList(@RequestBody String request,
                                                                @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        log.info("inside fetchNotificationList", request);
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                log.info("Request Parameter Missing." + request);
                return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(adminService.fetchNotificationList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchNotificationList --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/fetchOrgAndInsuranceWiseCount", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchOrgAndInsuranceWiseCount(@RequestBody String request) {
        log.info("inside fetchOrgAndInsuranceWiseCount", request);
        try {
            if (OPLUtils.isObjectNullOrEmpty(request)) {
                log.info("Request Parameter Missing." + request);
                return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(adminService.fetchOrgAndInsuranceWiseCount(request),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchOrgAndInsuranceWiseCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/fetchPublishApiAuditDetailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> fetchPublishApiAuditDetailList(@RequestBody String request) {
        try {
            log.info("Enter In fetchPublishApiAuditDetailList()" + request);
            return new ResponseEntity<>(adminService.fetchApiAuditDetailList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Saved publish Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/fetchRegistryApiAuditDetailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> fetchRegistryApiAuditDetailList(@RequestBody String request) {
        try {
            log.info("Enter In fetchRegistryApiAuditDetailList()" + request);
            return new ResponseEntity<>(adminService.fetchApiAuditDetailList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Saved Registry Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //DD Registry
    @SkipInterceptor
    @PostMapping(value = "/fetchAuditDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> fetchAuditDetails(@RequestBody String request) {
        try {
            log.info("Enter In fetchAuditDetails()" + request);
            return new ResponseEntity<>(adminService.fetchAuditDetails(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Saved Registry Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


    @SkipInterceptor
    @PostMapping(value = "/updateEnrollmenrData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateEnrollmenrData(@RequestBody EnrollmentRequest enrollmentDetails) {
        try {
            return new ResponseEntity<CommonResponse>(adminService.updateEnrollmenrData(enrollmentDetails), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while Update EnrollmenrData --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //Other-Channel;
    @SkipInterceptor
    @GetMapping(value = "/getRegistryReqRes/{auditId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getRegistryReqRes(@PathVariable("auditId") Long auditId) {
        try {
            log.info("Enter In getRegistryReqRes() auditId -> ({})", auditId);
            return new ResponseEntity<CommonResponse>(adminService.getPublishReqRes(auditId, true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Registry Req Res --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    //Publish
    @SkipInterceptor
    @GetMapping(value = "/getPublishReqRes/{auditId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getPublishReqRes(@PathVariable("auditId") Long auditId) {
        try {
            log.info("Enter In getPublishReqRes() auditId -> ({})", auditId);
            return new ResponseEntity<CommonResponse>(adminService.getPublishReqRes(auditId, false), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Publish Req Res --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/fetchEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPublishedAppList(@RequestBody String request) {
        try {
            return new ResponseEntity<CommonResponse>(adminService.fetchPublishedAppList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPublishedAppList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @SkipInterceptor
    @PostMapping(value = "/fetchClaimList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPublishedClaimList(@RequestBody String request) {
        try {
            return new ResponseEntity<CommonResponse>(adminService.fetchPublishedClaimList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPublishedClaimList ------>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }

    }

    @SkipInterceptor
    @PostMapping(value = "/updateTransactionList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateTransactionDetails(@RequestBody List<UpdateTransactionProxy> transactionproxy) {
        try {
            return new ResponseEntity<CommonResponse>(adminService.updateTransactionList(transactionproxy), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while Update TransactionDetails --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * UPDATE transaction time stamp publish and insurance
     *
     * @param UpdateTraTimeStampProxy
     * @param
     * @return
     */
    @SkipInterceptor
    @PostMapping(value = "/updateTrasTimeStamp", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateTrasTimeStamp(@RequestBody List<UpdateTraTimeStampProxy> transactionProxy) {
        try {
            log.info("Enter in updateTrasTimeStamp() ---------->");
            return new ResponseEntity<>(adminService.updateTrasTimeStamp(transactionProxy), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while Update transaction time stamp --->", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


    /**
     * DOWNLOAD NOTIFICATION LIST
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/downloadNotificationList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> downloadNotificationList(@RequestBody String request,
                                                                   @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchNotificationList()" + request);
            return new ResponseEntity<>(adminService.downloadNotificationList(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchNotificationList --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUserTknMappingLst", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getUserTknMappingLst(@RequestBody String request) {
        try {
            log.info("Enter In getUserTknMappingLst() request-> ({})", request);
            return new ResponseEntity<>(adminService.getUserTknMappingLst(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getUserTknMappingLst --->", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUserDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getUserDetails(@RequestBody String request) {
        try {
            log.info("Enter In getUserDetails() -> ({})", request);
            return new ResponseEntity<>(adminService.getUserDetails(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getUserTknMappingLst --->", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/insertSupportAudit", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> insertSupportAudit(@RequestBody SupportAuditProxy request) {
        try {
            log.info("Enter In insertSupportAudit() -> ({})", request);
            return new ResponseEntity<>(adminService.insertSupportAudit(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while insertSupportAudit --->", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getNotificationAudit", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getNotificationAudit(@RequestBody String request) {
        try {
            log.info("Enter In getNotificationAudit() -> ({})", request);
            return new ResponseEntity<>(adminService.getNotificationAudit(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getUserTknMappingLst --->", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH CITY/STATE REPORTS
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchCityWiseData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchCityWiseData(@RequestBody String request) {
        try {
            log.info("Enter In fetchCityWiseData()" + request);
            return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS,
                    adminService.fetchCityWiseData(request), HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchInsurerCount --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH CITY/STATE REPORTS
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchCityWiseForPolicy", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchCityWiseForPolicy(@RequestBody String request,
                                                                 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchCityWiseForPolicy()" + request);
            return new ResponseEntity<>(
                    adminService.fetchCityWiseForPolicy(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchCityWiseForPolicy --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


    /**
     * FETCH WEBHOOK AUDIT DETAILS
     *
     * @param authClientResponse
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchWebhookApiAuditDetailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchWebhookApiAuditDetailList(@RequestBody String request,
                                                                         @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchWebhookApiAuditDetailList()" + request);
            return new ResponseEntity<>(
                    adminService.fetchWebhookApiAuditDetailList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Webhooj Api Audit List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    // For Admin pannel
    @GetMapping(value = "/getApplicationAllDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getApplicationAllDetails(
            @PathVariable("applicationId") Long applicationId,
            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter in get application  details ---->" + applicationId);
            ApplicationMasterProxy appMasterReq = adminService.getApplicationAllDetails(applicationId);
            if (appMasterReq == null) {
                return new ResponseEntity<CommonResponse>(new CommonResponse(
                        "Its seems we have not found details by given information, kindly refresh page and try again",
                        HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Successfully get Account Holder Details!!", appMasterReq,
                            HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Application Form Details ==>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    // For Admin pannel
    @GetMapping(value = "/getCustomerMasterDetailsList/{applicationId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getCustomerMasterDetailsList(
            @PathVariable("applicationId") Long applicationId, @PathVariable("schemeId") Long schemeId) {
        try {
            log.info("Enter in get application  details ---->" + applicationId);
            ApplicationMasterProxy appMasterReq = adminService.getCustomerMasterDetailsList(applicationId,
                    schemeId);
            if (appMasterReq == null) {
                return new ResponseEntity<CommonResponse>(new CommonResponse(
                        "Its seems we have not found details by given information, kindly refresh page and try again",
                        HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(
                    new CommonResponse("Successfully get Account Holder Details!!", appMasterReq,
                            HttpStatus.OK.value(), true),
                    HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Application  master Details ==>", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH ALL INSUERER API LIST
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchPostmanResponse", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPostmanResponse(@RequestBody PostmanCallProxy proxy,
                                                               @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchInsurerAPIList()" + proxy);
            if (OPLUtils.isObjectListNull(proxy.getApiId())) {
                return new ResponseEntity<CommonResponse>(new CommonResponse("Missing Requested parameter are missing",
                        HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(adminService.fetchPostmanResponse(proxy, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPostmanResponse --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchBankWebhookRequest", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchBankWebhookRequest(@RequestBody PostmanCallProxy proxy,
                                                                  @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchBankWebhookRequest()" + proxy);
            if (proxy.getApiId() == null) {
                return new ResponseEntity<CommonResponse>(new CommonResponse("Missing Requested parameter are missing",
                        HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(adminService.fetchBankWebhookRequest(proxy), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchPostmanResponse --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/fetchJanApiRequest", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchJanApiRequest(@RequestBody PostmanCallProxy proxy,
                                                             @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchJanApiRequest()" + proxy);
            if (OPLUtils.isObjectListNull(proxy.getApiId())) {
                return new ResponseEntity<CommonResponse>(new CommonResponse("Missing Requested parameter are missing",
                        HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<CommonResponse>(adminService.fetchJanApiRequest(proxy, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchJanApiRequest --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * FETCH CLAIM AGING REPORTS
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/fetchClaimReports", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchClaimReports(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchClaimReports()" + request);
            return new ResponseEntity<>(adminService.fetchClaimReports(request), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetchClaimReports --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }


    @PostMapping(value = "/fetchPushFailList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> fetchPushFailList(@RequestBody String request,
                                                            @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter In fetchPushFailList()" + request);
            return new ResponseEntity<>(
                    adminService.fetchPushFailList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while fetch Push Fail List --->", e);
            return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
}
