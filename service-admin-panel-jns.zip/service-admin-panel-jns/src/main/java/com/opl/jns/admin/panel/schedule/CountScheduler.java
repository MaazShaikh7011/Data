package com.opl.jns.admin.panel.schedule;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.opl.jns.admin.panel.service.AdminServicev3;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CountScheduler {

	@Autowired
	private AdminServicev3 adminService;
    /**
     * Scheduler for expiring application at midnight 9.
    
     * */
    @Scheduled(cron = "0 0 */2 * * *")
//	@Scheduled(cron = "0 0/2 * * * *")
    public void expireApplicationsOnMidNight(){
        log.info("counting in-progress application scheduler =====> Start at :[{}]",new Date());
        adminService.updateCountAllBanks();
    }

    
}