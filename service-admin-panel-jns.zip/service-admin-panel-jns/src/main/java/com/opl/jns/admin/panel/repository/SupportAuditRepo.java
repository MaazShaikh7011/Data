package com.opl.jns.admin.panel.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.admin.panel.domain.SupportAudit;

@Repository
public interface SupportAuditRepo extends JpaRepository<SupportAudit, Long> {

	@Transactional
    @Modifying
    @Query("UPDATE SupportAudit SET isActive=true, modifiedDate = CURRENT_TIMESTAMP WHERE supportUserId =:userId AND isActive=true")
    Integer isActiveFalseByUserId(@Param("userId") Long userId);
	
}
