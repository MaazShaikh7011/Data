package com.opl.jns.admin.panel.model;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class CountProxy {
	
	private Long orgId;
	private String orgName;
	private Long  completedCount;
	private Long  rejectedCount;
	private Long  transactionFailedCount;
	private Long  expiredCount;
	private Long  applicationForm;
	private Long  tranFailedInprogressCnt;
	private Long  totalCount;
	private Long channelId;
	private String  channelIdValue;
	private Long insurerOrgId;
	private String name;
}
