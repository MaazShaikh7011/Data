package com.opl.jns.admin.panel.repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author ravi.dafda
 * Note: Admin-panel related sp specify here.
 */
public interface AdminRepositoryV3 {
	
	public String getRecordFromProducer(String requestJson, Long userId, String spName);

	public String GetAdminCommonList(String listKey, Long whereClause, Long userId, String spName);

	public String spAdminUserList(String request, String spName);
	
	public String spBankerUserList(String request, String spName);
	
	public String commonSPcall(Map<String, Object> params,  Long userId, String spName);
	
String fetchOptOutApplication(String query);
	
	String fetchCount(String query);
	
  String spOtherUserList(String query);
	
	String fetchspOtherUserListCount(String query);

	public List<Object> getUserType();
	
	public String getAllScheme();
	public String getYearsList();
	
	public List<Object>adminPermissionList(String whereclause);

	public List<Object> fetchListOfDataFromDb(String query);
	
	public String getApiConfigMaster();
	public String getConfigMaster();
	public String getTypeMasterForDms();
	public String getDocumentMasterForDms();	
	public String getPreMimumMaster();
	public String getUsernameAndApiKey();
	
	public String spFetchAdminEnrollmentList(String request, String spName);

	Map<String, Object> spFetchEnrollmentCount(String query);
	public String executeNativeQuery(String query);
	
	public Timestamp getpushDate(String Query);
	public int updatePublishData(String Query);
	 String getDataFromProducer(String request, Long userId, String spName);
		
}
