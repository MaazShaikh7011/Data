package com.opl.jns.admin.panel.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "support_audit")
@Getter
@Setter
@ToString
public class SupportAudit {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "support_audit_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_ADMIN_PANEL, name = "support_audit_seq_gen", sequenceName = "support_audit_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "support_userId", nullable = true)
	private Long supportUserId;
	
	@Column(name = "userId", nullable = true)
	private Long userId;

	@Column(name = "action", nullable = true)
	private Integer action;
	
	@Column(name = "old_data", nullable = true)
	private String oldData;
	
	@Column(name = "new_data", nullable = true)
	private String newData;
	
	@Column(name = "is_active", nullable = true)
	private Boolean isActive;
	
	@Column(name = "created_date", nullable = true)
	private Date createdDate;
	
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;
	
}
