package com.opl.jns.admin.panel.repository;

import java.util.Date;
import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.admin.panel.domain.CountDomain;

@Repository
public interface CountRepo extends JpaRepository<CountDomain, Long> {
	
	
	@Query(nativeQuery = true, value = """
			 select json_object( 'orgId' value am.org_id ,
			'name' value uom.ORGANISATION_NAME,
			'totalCount' value count(am.id),  
			'CompletedCount' value sum(case when am.stage_id = 6 then 1 else 0 end),  
			'RejectedCount' value sum(case when am.stage_id = 8 then 1 else 0 end) , 
			'ExpiredCount' value sum(case when am.stage_id = 7 then 1 else 0 end )) 
			FROM JNS_INSURANCE.application_master am 
			left JOIN JNS_USERS.user_organisation_master uom ON uom.user_org_id = am.insurer_org_id 
			 where am.is_active=1 and uom.organisation_name is not null 
			group by am.org_id,uom.ORGANISATION_NAME \
			""")
	List<String> getEnrollmentDetail();
	
	@Query(nativeQuery = true,value = """
			select json_object( 
			'orgId' value cm.org_id ,
			'name' value uom.ORGANISATION_NAME,  
			'totalCount' value count(cm.id),  
			'CompletedCount' value sum(case when cm.claim_status = 10 then 1 else 0 end), 
			'ExpiredCount' value sum(case when cm.claim_status = 9 then 1 else 0 end)  , 
			'RejectedCount' value sum(case when cm.claim_status = 8 then 1 else 0 end) , 
			'SendBackToBankCount' value sum(case when cm.claim_status = 7 then 1 else 0 end)) 
			FROM JNS_INSURANCE.claim_master cm 
			left join JNS_INSURANCE.application_master am on am.id=cm.application_id
			left JOIN JNS_USERS.user_organisation_master uom ON (uom.user_org_id = am.insurer_org_id )
			WHERE cm.is_active=1 and uom.organisation_name is not null 
			group by cm.org_id,uom.ORGANISATION_NAME \
			""")
	List<String> getClaimDetail();
	
	@Transactional
	@Modifying
	@Query(nativeQuery = true,value = "update JNS_PUBLISH_API.APPLICATION_MASTER set push_ready_date = :pushReadyDate  where application_id=:applicationId")
	int updatePushReadyDateByAppId(@Param("applicationId") Long applicationId,@Param("pushReadyDate") Date pushReadyDate);
	
	
	@Query(nativeQuery = true, value = "select to_timestamp(push_ready_date) from JNS_PUBLISH_API.APPLICATION_MASTER where application_id=:applicationId")
	Date getpushDate(@Param("applicationId") Long applicationId);
	
	@Transactional
	@Modifying
	@Query(nativeQuery = true,value = "update JNS_PUBLISH_API.TRANSACTION_DETAILS set TRANS_TIME_STAMP=jns_publish_api.\"PUBLISH_ENCVALUE\"(:tstamp) where id=:id")
	int updatePubTransTimeStamp(@Param("id") Long id,@Param("tstamp") String tstamp);
	
}
