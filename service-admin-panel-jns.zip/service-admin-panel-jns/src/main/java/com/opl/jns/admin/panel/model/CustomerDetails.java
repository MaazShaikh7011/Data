package com.opl.jns.admin.panel.model;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.utils.common.PatternUtils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CustomerDetails implements Serializable {

    private final static long serialVersionUID = 2729134690963093267L;
    
    public String dob;
 
    public String gender;
    
    public String accountHolderName;
   
    public String firstName;

    public String middleName;

    public String lastName;
  	
    public String fatherHusbandName;
  	
    public String mobileNumber;
    
    public String emailId;
     
    public String addressLine1;    
    
    public String addressLine2;
    
    public String pincode;
    
    public String city;
    
    public Long cityLGDCode;
    
    public String district;

    public Long districtLGDCode;

    public String state;
 
    public Long stateLGDCode;

    public String accountNumber;

    public String cif;
    
    public String disabilityStatus;

    public String disabilityDetails;

}
