create or replace PROCEDURE                 "SP_GET_BY_SEARCH_FILTER_LIST" (filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    userorgid       LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' ''applicationId'' value am.id,
                ''id'' value am.id,
                ''fullName'' value jns_users."decvalue"(ai.name),
                ''urnNumber'' value am.urn,
                ''accountNumber'' value jns_users."decvalue"(am.account_number),
                ''contactDetails'' value jns_users."decvalue"(ai.mobile_number),
                ''schemeId'' value am.scheme_id,
                ''lastModifyDate'' value am.modified_date,
                ''stageId'' value am.stage_id,
                ''status'' value am.is_active,
                ''channelId'' value amod.channel_id,
                ''message'' value am.message,
                ''branchCode'' value bm.code,
                ''schemeLable'' value sm.short_name ';

    tablequery := ' FROM USR_INSURANCE.application_master am
                    INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id 
                    LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1 
                    INNER JOIN JNS_USERS.branch_master bm on bm.id = am.branch_id ';

    whereclause := ' WHERE 1=1 AND am.is_active=1 AND am.stage_id = 8 AND ((amod.source = 4 AND am.stage_id = 8 OR amod.source <> 4 AND am.stage_id = 8)) ';

    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid) IS NOT NULL THEN
            IF (typeid = 2) THEN
                whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);   
                    ELSE
                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    END IF;
--                ELSE
--                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                END IF;
            ELSIF (typeid = 6) THEN
                whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
            ELSE
                whereclause := CONCAT(whereclause, ' AND 1=2 ');
            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

    IF (JSON_VALUE (filterjson, '$.schemeId') is not null) then 
        whereclause := CONCAT(whereclause, ' AND am.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));    
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
        if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
            whereclause := CONCAT(whereclause, ' AND am.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
            whereclause := CONCAT(whereclause, ' AND am.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
            whereclause := CONCAT(whereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
            whereclause := CONCAT(whereclause, ' AND ai.name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 5) then -- Pan Number
            whereclause := CONCAT(whereclause, ' AND ai.pan = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 6 OR JSON_VALUE(filterjson, '$.searchType') = 7 OR JSON_VALUE(filterjson, '$.searchType') = 8 OR JSON_VALUE(filterjson, '$.searchType') = 9) then -- Driving Licence OR MGNREGA OR Passport OR Voter's ID Card
            if (JSON_VALUE(filterjson, '$.searchTypeAsStr') is not null and JSON_VALUE(filterjson, '$.searchTypeAsStr') is not null) then
                whereclause := CONCAT(whereclause, ' AND (( ai.kyc_id_1 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchTypeAsStr') || ''') AND ai.kyc_id_number_1 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')) OR 
                (ai.kyc_id_2 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchTypeAsStr') || ''') AND ai.kyc_id_number_2 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')))');
            end if;
        end if;
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;


--    fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';

--    appcodequery := '(am.urn LIKE ''%' || JSON_VALUE (filterjson, '$.applicationCode') || '%'')';
--
--    accnoquery := '(jns_users."decvalue"(am.account_number) LIKE ''%' || JSON_VALUE (filterjson, '$.accountNumber') || '%'')';

    preparequery := 'SELECT json_arrayagg(json_object(' || selectquery || ')returning clob ) ' || tablequery || whereclause;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
      dbms_output.put_line(result);
  END ;