CREATE OR REPLACE PROCEDURE USR_INSURANCE."SP_GET_INSURER_DETAILS_LIST" (filterjson IN  VARCHAR2,
                                                           userid     IN  LONG,
                                                           result     OUT CLOB)
  AS

    selectquery      CLOB;
    tablequery       CLOB;
    whereclause      CLOB;
    selectcountquery CLOB;
    limitby          CLOB;
    totalcount       NUMBER;
    orderby          CLOB;
    mainquery        CLOB;
    jsonQuery        CLOB;
  BEGIN
    limitby := '';

    jsonQuery := 'json_arrayagg(JSON_OBJECT(';

    selectquery := '''id'' value imd.id  ,
			''insurerName'' value UOM.organisation_name,
			 ''orgId'' value imd.org_id,
			''schemeId'' value imd.scheme_id,
            ''schemeName'' value sm.short_name,
            ''years'' value imd.year,
            ''pincode'' value imd.pincode,
            ''status'' value CASE imd.is_active
                             WHEN 1 THEN ''Active''
                             ELSE ''Inactive''
                        END,
            ''masterPolicyNo'' value jns_users."decvalue"(imd.master_policy_no),
            ''insurerCode'' value imd.insurer_code,
            ''insurerAddress'' value imd.insurer_address,
            ''headName'' value imd.head_name,
            ''headEmail'' value imd.head_email,
            ''headContactNo'' value imd.head_contact_no,
            ''headMobileNo'' value imd.head_mobile_no,
            ''associatedAccHolderName'' value imd.associated_acc_holder_name,
            ''associatedAccNo'' value imd.associated_acc_no,
            ''associatedIfscCode'' value imd.associated_ifsc_code,
            ''policyStartDate'' value TRUNC(imd.policy_start_date),
            ''policyEndDate'' value TRUNC(imd.policy_end_date),
            ''policyEndDateFormat'' value imd.policy_end_date';
    tablequery := 'FROM usr_insurance.insurer_mst_details imd
			    LEFT JOIN jns_users.user_organisation_master UOM ON UOM.user_org_id=imd.insurer_org_id AND UOM.is_active=1
			    LEFT JOIN jns_users.scheme_master sm ON sm.id=imd.scheme_id AND sm.is_active=1 ';
    whereclause := ' WHERE imd.is_active=1 ';
    IF JSON_VALUE (filterjson, '$.searchData') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND (jns_users."decvalue"(imd.master_policy_no) LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR UOM.organisation_name LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR sm.short_name LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'' OR imd.year LIKE ''%'
      || JSON_VALUE (filterjson, '$.searchData')
      || '%'')';
    END IF;

    IF
      JSON_VALUE (filterjson, '$.fromDate') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.toDate') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND TRUNC(imd.policy_end_date) BETWEEN TO_DATE('''
      || JSON_VALUE (filterjson, '$.fromDate')
      || ''' ,''YYYY-MM-DD'') AND TO_DATE('''
      || JSON_VALUE (filterjson, '$.toDate')
      || ''' ,''YYYY-MM-DD'')';
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND imd.scheme_id = '
      || JSON_VALUE (filterjson, '$.schemeId');
    END IF;

    IF JSON_VALUE (filterjson, '$.orgId') IS NOT NULL
    THEN
      whereclause := whereclause
      || ' AND imd.org_id = '
      || JSON_VALUE (filterjson, '$.orgId');
    END IF;

    orderby := ' ORDER BY imd.id ASC ';


    -- For Limit


    IF
      JSON_VALUE (filterjson, '$.from') IS NOT NULL
      AND JSON_VALUE (filterjson, '$.to') IS NOT NULL
    THEN
      limitby := ' OFFSET '
      || JSON_VALUE (filterjson, '$.from')
      || ' ROWS FETCH NEXT '
      || JSON_VALUE (filterjson, '$.to')
      || ' ROWS ONLY';
    END IF;

    selectCountQuery := 'SELECT COUNT(*) ';
    selectCountQuery := selectCountQuery || tableQuery || whereClause;
    dbms_output.put_line(whereclause);

    EXECUTE IMMEDIATE selectCountQuery
      INTO totalCount;
    dbms_output.put_line(totalCount);


    mainquery := 'SELECT '
    || jsonQuery
    || selectquery || ', ''totalcount'' value ' || totalcount || ')FORMAT JSON RETURNING CLOB)'
    || tablequery
    || whereclause
    || limitby;

    dbms_output.put_line(mainquery);


    EXECUTE IMMEDIATE mainquery
      INTO result;
  --
  END sp_get_insurer_details_list;

