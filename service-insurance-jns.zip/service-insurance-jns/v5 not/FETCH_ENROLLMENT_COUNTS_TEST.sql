CREATE OR REPLACE PROCEDURE USR_INSURANCE."FETCH_ENROLLMENT_COUNTS_TEST" (filterjson IN  "VARCHAR",
                                                            userid     IN  NUMBER,
                                                            obj        OUT CLOB)
  IS
    prepareQuery     CLOB;
    selectQuery      CLOB;
    tableQuery       CLOB;
    --obj clob;
    selectJSONObject CLOB;
  BEGIN
    --    selectQuery := ' SELECT SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END) AS approvedCount,
    --                        SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END) AS rejectedCount';
    selectQuery := '"approvedCount","SUM(CASE WHEN stage_id = 6 THEN 1 ELSE 0 END)", "rejectedCount","SUM(CASE WHEN stage_id = 8 THEN 1 ELSE 0 END)"';
    selectJSONObject := ' SELECT JSON_OBJECT(' || selectQuery || ') INTO obj ';
    tableQuery := ' FROM jns_insurance.application_master am
                            LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id AND ai.is_active = 1 ';
    prepareQuery := selectJSONObject || tableQuery;
    dbms_output.put_line(prepareQuery);
    EXECUTE IMMEDIATE prepareQuery;
  END fetch_enrollment_counts_test;



