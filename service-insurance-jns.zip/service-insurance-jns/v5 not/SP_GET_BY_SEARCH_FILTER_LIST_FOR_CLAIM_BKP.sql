CREATE OR REPLACE PROCEDURE USR_INSURANCE."SP_GET_BY_SEARCH_FILTER_LIST_FOR_CLAIM_BKP" (filterjson IN  VARCHAR2,
                                              userid     IN  NUMBER,
                                              result     OUT CLOB)
  AS

    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    selectquery := ' ''applicationId'' value am.id,
                ''id'' value ca.id,
                ''fullName'' value jns_users."decvalue"(ai.name),
                ''urnNumber'' value am.urn,
                ''accountNumber'' value jns_users."decvalue"(am.account_number),
                ''contactDetails'' value jns_users."decvalue"(ai.mobile_number),
                ''schemeId'' value am.scheme_id,
                ''lastModifyDate'' value ca.modified_date,
                ''status'' value ca.claim_status,
                ''schemeLable'' value sm.short_name )returning clob) ';
    tablequery := 'FROM USR_INSURANCE.claim_master ca
                   INNER JOIN USR_INSURANCE.claim_detail cd ON cd.claim_id = ca.id
                   INNER JOIN USR_INSURANCE.application_master am ON am.id = ca.application_id
                   INNER JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                   LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                   LEFT JOIN JNS_ONEFORM.state st ON st.id = amod.branch_state_id
                   LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1
--                   LEFT JOIN jns_oneform.dropdowns_values CS ON CS.obj_id=ca.claim_status AND CS.dropdown_id=14 AND CS.is_active=1
                    ';

    whereclause := ' WHERE  1 = 1 AND ca.is_active = 1 AND ca.claim_status IN (6,7,8,10,11)';

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
            if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
                whereclause := CONCAT(whereclause, ' AND am.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            elsif(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
                whereclause := CONCAT(whereclause, ' AND am.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
            elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
                whereclause := CONCAT(whereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
                whereclause := CONCAT(whereclause, ' AND ai.name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            end if;
        else
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        end if;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND am.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND cd.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 0 ');
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        END IF;
      END IF;

    END IF;

    dbms_output.put_line(whereclause);

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND cd.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.claimStageId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.claim_status = ' || JSON_VALUE (filterjson, '$.claimStageId'));
    END IF;

--    IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
--    THEN
--      IF (JSON_VALUE (filterjson, '$.tabId') = 1)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 6)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 6 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 2
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 3
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 10 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 4
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSIF (JSON_VALUE (filterjson, '$.tabId') = 5)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 8)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 7 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 9
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 7
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSE
--        whereclause := whereclause || ' AND ca.claim_status = 0 ';
--      END IF;
--    END IF;

    whereclause := whereclause || ' order by ca.modified_date desc ';

    EXECUTE IMMEDIATE ' SELECT COUNT(ca.id)'
    || tablequery
    || whereclause
      INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
  END ;