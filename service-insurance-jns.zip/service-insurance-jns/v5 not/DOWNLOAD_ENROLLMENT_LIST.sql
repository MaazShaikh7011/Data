CREATE OR REPLACE PROCEDURE USR_INSURANCE."DOWNLOAD_ENROLLMENT_LIST" (
    filterjson  IN   varchar2,
    userid      IN   NUMBER,
    result      OUT  clob
)
AS
 totalcount            LONG;
    selectquery           CLOB;
    fromtodatequery       CLOB;
    tablequery            CLOB;
    inserttablequery      CLOB;
    mainwhereclause       CLOB;
    whereclause           CLOB;
    amodwhereclause       CLOB;
    limitquery            CLOB;
    preparequery          CLOB;
    orderby               CLOB;
    totalcounttablequery  CLOB;
    roleid                NUMBER;
    typeid                NUMBER;
    orgid                 NUMBER;
    branchid              NUMBER;
    insertquery           CLOB;
    appIds                  clob;
--    appmasterjoin         VARCHAR2;

BEGIN

--SYS_REFCURSOR
--    EXECUTE IMMEDIATE('CREATE GLOBAL TEMPORARY TABLE temptable(id NUMBER) on commit delete rows ');
     EXECUTE IMMEDIATE ' TRUNCATE TABLE JNS_REPORTS.APP_MASTER_TEMP ';
--  selectquery := '  am.id AS "id",
--                  am.id AS "applicationId",
--                  jns_users."decvalue"(ai.name) AS "name",
--                  jns_users."decvalue"(am.account_number) AS "customerAccountNumber",
--                  am.urn AS "urn",
--                  jns_users."decvalue"(ai.mobile_number) AS "mobileNumber",
--                  sm.short_name AS "schemeName",
--                  am.stage_id AS "stageId",
--                  am.message AS "message",
--                  TRUNC(am.enrollment_date) AS "enrollDate",
--                  TRUNC(am.modified_date) AS "modifiedDate" ';
--                  SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalcount'' VALUE '|| totalcount ||',
            selectquery := ' ,''id'' VALUE am.id,
                            ''applicationId'' VALUE am.id,
                            ''name'' VALUE jns_users."decvalue"(ai.name),
                            ''customerAccountNumber'' VALUE jns_users."decvalue"(am.account_number),
                            ''urn'' VALUE am.urn,
                            ''mobileNumber'' VALUE jns_users."decvalue"(ai.mobile_number),
                            ''schemeName'' VALUE sm.short_name,
                            ''stageId'' VALUE am.stage_id,
                            ''message'' VALUE am.message,
                            ''enrollDate'' VALUE TRUNC(am.enrollment_date),
                            ''modifiedDate'' VALUE TRUNC(am.modified_date),
                            ''source'' VALUE amod.source,
                            ''transactionType'' VALUE (case when td.type=1 then ''New Enrollment'' when td.type=2 then ''Endorsement'' else null end),
                            ''channelId'' VALUE amod.channel_id,
                            ''cif'' VALUE jns_users."decvalue"(am.cif),
                            ''insuredName'' VALUE jns_users."decvalue"(ai.name),
                            ''fatherHusbandName'' VALUE jns_users."decvalue"(ai.father_husband_name),
                            ''dob'' VALUE jns_users."decvalue"(ai.dob),
                            ''gender'' VALUE (case when ai.gender_id = 1 then ''MALE'' when ai.gender_id = 2 then ''FEMALE'' when ai.gender_id=3 then ''Other'' else null end),
                            ''masterPolicyNumber'' VALUE jns_users."decvalue"(td.master_policy_no),
                            ''kycIdName'' VALUE jns_users."decvalue"(ai.kyc_id_1),
                            ''pan'' VALUE jns_users."decvalue"(ai.pan),
                            ''aadhaar'' VALUE jns_users."decvalue"(ai.aadhaar),
                            ''bankName'' VALUE bm.name,
                            ''bankCode'' VALUE amod.bank_code,
                            ''branchName'' VALUE bm.name,
                            ''roName'' VALUE bmro.name,
                            ''roCode'' VALUE amod.branch_ro_id,
                            ''zoName'' VALUE bmzo.name,
                            ''zoCode'' VALUE amod.branch_zo_id,
                             ''userId1'' VALUE amod.user_id_1,
                            ''userId2'' VALUE amod.user_id_2,
                            ''pinCode'' VALUE aam.pincode,
                            ''city'' VALUE aam.city_name,
                            ''district'' VALUE aam.district,
                            ''state'' VALUE aam.state_name,
                            ''geographicalClassification'' VALUE amod.rural_urban_semi,
                            ''transactionDate'' VALUE jns_users."decvalue"(td.trans_time_stamp),
                            ''transactionUTR'' VALUE jns_users."decvalue"(td.trans_utr),
                            ''transactionAmount'' VALUE td.TRANS_AMOUNT,
                            ''nomineeName'' VALUE jns_users."decvalue"(nominee.first_name),
                            ''nomineeDoB'' VALUE jns_users."decvalue"(nominee.dob),
                            ''relationOfNominee'' VALUE nominee.relation_id,
                            ''guardianName'' VALUE jns_users."decvalue"(guardian.first_name),
                            ''relationshipOfGuardian'' VALUE guardian.relation_id
                           )RETURNING CLOB) ';


  whereclause := ' WHERE 1=1 ';
  amodwhereclause := ' am.org_Id = amod.org_Id AND ';

  -- GET DATA FROM USER_ID AND SET CONDITION ACCORDING TO TAHT
  IF USERID IS NOT NULL
  THEN
    SELECT U.USER_TYPE_ID,
           U.BRANCH_ID,
           U.USER_ORG_ID,
           U.USER_ROLE_ID
      INTO typeid,
           branchid,
           orgid,
           roleid
      FROM JNS_USERS.USERS U
      WHERE U.IS_ACTIVE = 1
        AND U.USER_ID = USERID;
    IF (typeid) IS NOT NULL
    THEN
      IF (typeid = 2)
      THEN
        whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
        IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
        THEN
          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
        END IF;
        IF (roleid IS NOT NULL
          AND roleid != 5 AND roleid != 21)
        THEN
          IF (roleid = 9)
          THEN
            whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
          ELSIF (roleid = 13)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_ro_id = ' || branchid || ' AND ');
          ELSIF (roleid = 14)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.BRANCH_ZO_ID = ' || branchid || ' AND ');
          ELSIF (roleid = 15)
          THEN
            amodwhereclause := CONCAT(amodwhereclause, ' amod.BRANCH_LHO_ID = ' || branchid || ' AND ');
          ELSE
            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
          END IF;
        --          ELSE
        --            whereclause := CONCAT(whereclause, ' and 1 = 2 ');
        END IF;
      ELSIF typeid = 6
      THEN
        whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
        IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
        THEN
          whereclause := CONCAT(whereclause, ' AND am.scheme_id = ' || JSON_VALUE (FILTERJSON, '$.schemeId'));
        END IF;
      ELSE
        whereclause := CONCAT(whereclause, ' and 1 = 2 ');
      END IF;
    ELSE
      whereclause := CONCAT(whereclause, ' and 1 = 2 ');
    END IF;
  ELSE
    whereclause := CONCAT(whereclause, ' and 1 = 2 ');
  END IF;

  whereclause := CONCAT(whereclause, ' AND am.is_active = 1 ');

  -- SET TAB WISE DATA TOTAL, APPROVE, REJECT
  IF JSON_VALUE (FILTERJSON, '$.tabId') IS NOT NULL
  THEN
    IF JSON_VALUE (FILTERJSON, '$.tabId') = 1
    THEN
      whereclause := whereclause || ' AND am.stage_id IN (6, 8) ';
    ELSIF JSON_VALUE (FILTERJSON, '$.tabId') = 2
    THEN
      whereclause := whereclause || ' AND am.stage_id = 6 ';
    ELSIF JSON_VALUE (FILTERJSON, '$.tabId') = 3
    THEN
      whereclause := whereclause || ' AND am.stage_id = 8 ';
    END IF;
  END IF;

  -- DATE FILTER
  IF JSON_VALUE (FILTERJSON, '$.fromDate') IS NOT NULL
    AND JSON_VALUE (FILTERJSON, '$.toDate') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (FILTERJSON, '$.toDate') || ''', ''YYYY-MM-DD'')');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.searchData') IS NOT NULL
  THEN
    whereclause := whereclause || ' AND ((am.account_number = jns_users."encvalue"(''' || JSON_VALUE (FILTERJSON, '$.searchData') || ''') OR am.urn = ''' || JSON_VALUE (FILTERJSON, '$.searchData') || '''))';
  END IF;

  --    dbms_output.put_line(whereclause);

  IF JSON_VALUE (FILTERJSON, '$.bankId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND am.org_id = ' || JSON_VALUE (FILTERJSON, '$.bankId'));
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_ro_id in (' || JSON_VALUE (FILTERJSON, '$.roId') || ') AND');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_zo_id in (' || JSON_VALUE (FILTERJSON, '$.zoId') || ') AND');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.boId') IS NOT NULL
  THEN
    whereclause := CONCAT(whereclause, ' AND am.branch_id in (' || JSON_VALUE (FILTERJSON, '$.boId') || ')');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.source in (' || JSON_VALUE (FILTERJSON, '$.channelId') || ') AND ');
  END IF;

  IF JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL
  THEN
    amodwhereclause := CONCAT(amodwhereclause, ' amod.branch_state_id in (' || JSON_VALUE (FILTERJSON, '$.stateId') || ') AND');
  END IF;

  tablequery := ' FROM JNS_REPORTS.APP_MASTER_TEMP tmpam
                    INNER JOIN USR_INSURANCE.application_master am ON am.id = tmpam.app_id
                    INNER JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id
                    left JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id
                    left JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id
                    left JOIN USR_INSURANCE.address_master aam ON aam.id = am.id
                    left JOIN USR_INSURANCE.nominee_details nominee ON nominee.application_id = am.id and nominee.type = 1
                    left JOIN USR_INSURANCE.nominee_details guardian ON guardian.application_id = am.id and guardian.type = 3
                    left JOIN USR_INSURANCE.transaction_details td ON td.id = am.last_transaction_id
                    LEFT JOIN jns_users.branch_master bmro ON bmro.id=amod.branch_ro_id AND bmro.is_active=1
                    LEFT JOIN jns_users.branch_master bmzo ON bmzo.id=amod.branch_zo_id AND bmzo.is_active=1
                    LEFT JOIN jns_users.branch_master bm ON bm.id=am.branch_id AND bm.is_active=1';


  insertquery := ' INSERT INTO JNS_REPORTS.APP_MASTER_TEMP
                    select am.id  '; -- JNS_REPORTS.APP_MASTER_TEMP

    inserttablequery := ' FROM USR_INSURANCE.application_master am ';
--dbms_output.put_line(inserttablequery);
  IF (roleid = 13 OR roleid = 14 OR roleid = 15 OR JSON_VALUE (FILTERJSON, '$.roId') IS NOT NULL
    OR JSON_VALUE (FILTERJSON, '$.zoId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.channelId') IS NOT NULL OR JSON_VALUE (FILTERJSON, '$.stateId') IS NOT NULL) THEN
    inserttablequery := CONCAT(inserttablequery, ' INNER JOIN USR_INSURANCE.application_master_other_details amod ON ' || amodwhereclause || ' amod.application_master_id = am.id ');
  END IF;
  IF JSON_VALUE (FILTERJSON, '$.searchData') IS NOT NULL THEN
    inserttablequery := CONCAT(inserttablequery, ' LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = am.id');
  END IF;


  IF (JSON_VALUE (FILTERJSON, '$.isSkipCount') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.isSkipCount') = 0) THEN
    --      dbms_output.put_line(' inside ');
--        dbms_output.put_line(' SELECT am.id ' || inserttablequery || whereclause);
        EXECUTE IMMEDIATE ' SELECT COUNT(am.id)' || inserttablequery || whereclause INTO totalcount; -- tablequery
  ELSE
    --      dbms_output.put_line(' out side ');
    SELECT 0
      INTO totalcount
      FROM DUAL;
  END IF;



  --    dbms_output.put_line(' SELECT COUNT(am.id)' || tablequery || whereclause);

  IF JSON_VALUE (FILTERJSON, '$.paginationFROM') IS NOT NULL AND JSON_VALUE (FILTERJSON, '$.paginationTO') IS NOT NULL THEN
    limitquery := ' OFFSET ' || JSON_VALUE (FILTERJSON, '$.paginationFROM') || ' ROWS FETCH NEXT ' || JSON_VALUE (FILTERJSON, '$.paginationTO') || ' ROWS ONLY';
  -- dbms_output.put_line(limitquery);
  END IF;

    orderby := ' order by am.modified_date,am.enrollment_date desc ';

  EXECUTE IMMEDIATE insertquery || inserttablequery || whereclause || orderby || limitquery;
  dbms_output.put_line(insertquery || inserttablequery || whereclause || limitquery);

--  COMMIT;


--  preparequery := ' SELECT ' || totalcount || ' AS "totalcount", ' || selectquery || tablequery || orderby ; -- || whereclause || limitquery;
  preparequery := (' SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalcount'' VALUE ' || totalcount || selectquery || tablequery); -- || whereclause || limitquery;

    dbms_output.put_line(preparequery);
  EXECUTE IMMEDIATE preparequery into result;
--    dbms_output.put_line(result);


END;

