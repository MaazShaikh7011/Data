CREATE OR REPLACE PROCEDURE USR_INSURANCE."SP_GET_BY_SEARCH_FILTER_OPT" (filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    userorgid       LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' ''applicationId'' value ma.application_id,
                ''id'' value ma.id,
                ''fullName'' value jns_users."decvalue"(ma.name),
                ''urnNumber'' value ma.urn,
                ''schemeLable'' value SM.SHORT_NAME,
                ''schemeId'' value am.scheme_id,
                ''enrollDate'' value am.enrollment_date,
--                ''status'' value ''Opt-out'',
                ''status'' value (CASE WHEN ma.type = 1 THEN ''Opt-out'' WHEN  ma.type = 2 THEN ''Sucess'' ELSE NULL END),
                ''nameOfInsurer'' value uom.DISPLAY_ORG_NAME,
                ''premiumAmount'' value am.premium_amount,
                ''source'' value (CASE WHEN amod.source = 1 THEN ''other channel'' WHEN amod.source = 2 THEN ''assitaed'' WHEN amod.source = 3 THEN ''Legacy Data'' WHEN amod.source = 4 THEN ''diy'' ELSE NULL END),
                ''masterPolicyNo'' VALUE jns_users."decvalue"(td.MASTER_POLICY_NO),
                ''branchCode'' value bm.code,
                ''email'' value jns_users."decvalue"(u.email),
                ''channelId'' value amod.channel_id,
                ''dateOfRequest'' value ma.date_of_request,
                ''dateOfEffective'' value ma.date_of_effective,
                ''isActive'' value ma.is_active,
                ''accountNumber'' value jns_users."decvalue"(ma.account_number),
                ''lastModifyDate'' value ma.modified_date,
                ''nomineeUpdateDate'' value nm.created_date ';

    tablequery := ' FROM USR_INSURANCE.miscellaneous_audit ma
                    LEFT JOIN USR_INSURANCE.application_master am ON am.id = ma.application_id
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1
                    LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = am.insurer_org_id
                    LEFT JOIN USR_INSURANCE.application_master_other_details amod ON amod.application_master_id = am.id
                    LEFT JOIN USR_INSURANCE.transaction_details td ON td.application_id = am.id
                    INNER JOIN JNS_USERS.USERS u ON u.user_id = ma.created_by
                    INNER JOIN JNS_USERS.branch_master bm on bm.id = am.branch_id
                    LEFT JOIN USR_INSURANCE.nominee_details nm on nm.id =  ma.nominee_id';

--    whereclause := ' WHERE ma.is_active=1 and ma.type=1';
 whereclause := ' WHERE 1=1 ';

    if(JSON_VALUE(filterjson, '$.type') is not null and JSON_VALUE(filterjson, '$.type') is not null) then
        if(JSON_VALUE(filterjson, '$.type') = 1) then
            whereclause := CONCAT(whereclause, ' AND ma.type =1');
        ELSIF(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
        whereclause := CONCAT(whereclause, ' AND ma.type =2 AND nm.is_active=1 AND nm.type=1');
        end if;
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;

      IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid) IS NOT NULL THEN
            IF (typeid = 2) THEN
                whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_zo_id = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        whereclause := CONCAT(whereclause, ' AND amod.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    END IF;
--                ELSE
--                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                END IF;
            ELSIF (typeid = 6) THEN
                whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
            ELSE
                whereclause := CONCAT(whereclause, ' AND 1=2 ');
            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;
--    IF (JSON_VALUE (filterjson, '$.schemeId') is not null) then
--        whereclause := CONCAT(whereclause, ' AND em.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
--    else
--        whereclause := CONCAT(whereclause, ' AND 1=2 ');
--    end if;

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
--        if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
--            whereclause := CONCAT(whereclause, ' AND am.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        if(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
            whereclause := CONCAT(whereclause, ' AND ma.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
        end if;
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;


    preparequery := 'SELECT json_arrayagg(json_object(' || selectquery || ')returning clob ) ' || tablequery || whereclause;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
      dbms_output.put_line(result);
  END ;