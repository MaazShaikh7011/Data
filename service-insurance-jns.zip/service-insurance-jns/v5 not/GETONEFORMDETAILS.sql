CREATE OR REPLACE PROCEDURE USR_INSURANCE."GETONEFORMDETAILS" (result OUT CLOB)
  AS
    query CLOB;
  BEGIN
    query := 'select json_arrayagg(json_object(''ssdf'' value id)) from  JNS_ONEFORM.dropdowns_master ';
    EXECUTE IMMEDIATE query
      INTO result;
  END GETONEFORMDETAILS;



