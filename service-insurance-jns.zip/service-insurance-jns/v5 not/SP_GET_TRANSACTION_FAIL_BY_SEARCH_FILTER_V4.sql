CREATE OR REPLACE PROCEDURE USR_INSURANCE.SP_GET_TRANSACTION_FAIL_BY_SEARCH_FILTER_V4(filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

--    totalcount      LONG;
--    userorgid       LONG;
    selectquery     CLOB;
    oldSelectquery     CLOB;
    newSelectquery     CLOB;
    oldTablequery      CLOB;
    newTablequery      CLOB;
    commonTablequery      CLOB;
    oldWhereclause     CLOB;
    newWhereclause     CLOB;
    mainInnerQuery CLOB;
--    fromtodatequery CLOB;
--    limitquery      CLOB;
    preparequery    CLOB;
--    appcodequery    CLOB;
--    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;

  BEGIN

	oldSelectquery := ' SELECT am.id as applicationId, am.URN AS urnNumber, 1 as isviewBtn,
				''Transaction Fail(in process)'' AS status,am.CREATED_DATE  AS enrollDate, am.ORG_ID AS orgId,am.SCHEME_ID AS schemeId,
				amod.channel_id AS channelId,am.PREMIUM_AMOUNT AS premiumAmount, am.INSURER_ORG_ID AS insOrgId,am.modified_date  AS modifiedDate,
				(CASE WHEN AMOD.SOURCE = 1 THEN ''other channel'' WHEN AMOD.SOURCE = 2 THEN ''assisted'' WHEN AMOD.SOURCE = 4 THEN ''DIY'' ELSE NULL END) AS source,
				am.branch_id AS branchId, am.user_id AS userId, am.message ';

	newSelectquery := ' SELECT am.id as applicationId, am.URN AS urnNumber, 0 as isviewBtn,
					''Transaction Fail'' AS status,am.CREATED_DATE  AS enrollDate, am.ORG_ID AS orgId,am.SCHEME_ID AS schemeId,
					am.channel_id AS channelId,am.PREMIUM_AMOUNT AS premiumAmount, am.INSURER_ORG_ID AS insOrgId,am.modified_date  AS modifiedDate,
					(CASE WHEN am.SOURCE = 1 THEN ''other channel'' WHEN am.SOURCE = 2 THEN ''assitaed'' WHEN am.SOURCE = 3 THEN ''Legacy Data'' WHEN am.SOURCE = 4 THEN ''diy'' ELSE NULL END) AS source,
					am.branch_id AS branchId, am.CREATED_BY AS userId, am.message ';


    selectquery := '''masterPolicyNo'' VALUE jns_users."decvalue"(imd.MASTER_POLICY_NO),
					''branchCode'' value bm.code,
                    ''fullName'' value jns_users."decvalue"(ai.name),
					''ifscCode'' value bm.IFSC_CODE,
					''applicationId'' value tbl.applicationId,
					''isviewBtn'' value tbl.isviewBtn,
					''nameOfInsurer'' value uom.DISPLAY_ORG_NAME,
					''schemeLable'' value SM.SHORT_NAME,
					''email'' value jns_users."decvalue"(u.email),
					''urnNumber'' value tbl.urnNumber,
					''status'' value tbl.status,
					''enrollDate'' value tbl.enrollDate,
					''orgId'' value tbl.orgId,
					''schemeId'' value tbl.schemeId,
					''channelId'' value tbl.channelId,
					''premiumAmount'' value tbl.premiumAmount,
					''insOrgId'' value tbl.insOrgId,
					''source'' value tbl.source,
					''branchId'' value tbl.branchId,
					''userId'' value tbl.userId,
                    ''lastModifyDate'' value tbl.modifiedDate,
					''message'' value tbl.message ';

	oldTablequery := ' FROM USR_INSURANCE.APPLICATION_MASTER am
						INNER JOIN USR_INSURANCE.APPLICATION_MASTER_OTHER_DETAILS amod ON amod.APPLICATION_MASTER_ID = am.ID ';

	newTablequery := ' FROM JNS_MASTER_DATA.EXPIRED_ENROLLMENT am ';

	commonTablequery := ' INNER JOIN JNS_USERS.SCHEME_MASTER sm ON SM.ID = tbl.schemeId
					INNER JOIN USR_INSURANCE.INSURER_MST_DETAILS imd ON imd.SCHEME_ID = tbl.schemeId AND imd.ORG_ID = tbl.orgId AND imd.POLICY_START_DATE < CURRENT_DATE AND imd.POLICY_END_DATE > CURRENT_DATE AND imd.IS_ACTIVE = 1
					INNER JOIN JNS_USERS.BRANCH_MASTER bm ON bm.id = tbl.branchId
					INNER JOIN JNS_USERS.USERS u ON u.user_id = tbl.userId
                    LEFT JOIN USR_INSURANCE.applicant_info ai ON ai.application_id = tbl.applicationId
					LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = tbl.insOrgId ';

    oldWhereclause := ' WHERE am.is_active=1 AND am.STAGE_ID = 15 AND am.APPLICATION_STATUS = 1';
    newWhereclause := ' WHERE am.is_active=1 AND am.STAGE_ID = 15 AND am.STATUS = 1 ';

--    oldWhereclause := ' AND ((am.source = 4 AND am.stage_id <> 8 OR am.source <> 4)) ';

    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid) IS NOT NULL THEN
            IF (typeid = 2) THEN
                oldWhereclause := CONCAT(oldWhereclause, ' AND am.org_Id = ' || orgid);
                newWhereclause := CONCAT(newWhereclause, ' AND am.org_Id = ' || orgid);
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        oldWhereclause := CONCAT(oldWhereclause, ' AND am.branch_id = ' || branchid);
                        newWhereclause := CONCAT(newWhereclause, ' AND am.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        oldWhereclause := CONCAT(oldWhereclause, ' AND amod.branch_ro_id = ' || branchid);
                        newWhereclause := CONCAT(newWhereclause, ' AND am.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        oldWhereclause := CONCAT(oldWhereclause, ' AND amod.BRANCH_ZO_ID = ' || branchid);
                        newWhereclause := CONCAT(newWhereclause, ' AND am.BRANCH_ZO_ID = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        oldWhereclause := CONCAT(oldWhereclause, ' AND amod.BRANCH_LHO_ID = ' || branchid);
                        newWhereclause := CONCAT(newWhereclause, ' AND am.BRANCH_LHO_ID = ' || branchid);
                    ELSE
                        oldWhereclause := CONCAT(oldWhereclause, ' AND 1=2 ');
                       newWhereclause := CONCAT(newWhereclause, ' AND 1=2 ');
                    END IF;
--                ELSE
--                    oldWhereclause := CONCAT(oldWhereclause, ' AND 1=1 ');
                END IF;
            ELSIF (typeid = 6) THEN
                oldWhereclause := CONCAT(oldWhereclause, ' AND am.insurer_org_id = ' || orgid);
                newWhereclause := CONCAT(newWhereclause, ' AND am.insurer_org_id = ' || orgid);
            ELSE
                oldWhereclause := CONCAT(oldWhereclause, ' AND 1=2 ');
                newWhereclause := CONCAT(newWhereclause, ' AND 1=2 ');
            END IF;
        ELSE
            oldWhereclause := CONCAT(oldWhereclause, ' AND 1=2 ');
            newWhereclause := CONCAT(newWhereclause, ' AND 1=2 ');
        END IF;
    ELSE
        oldWhereclause := CONCAT(oldWhereclause, ' AND 1=2 ');
        newWhereclause := CONCAT(newWhereclause, ' AND 1=2 ');
    END IF;

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
--        if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
--            oldWhereclause := CONCAT(oldWhereclause, ' AND aip.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--        els
        if(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
            oldWhereclause := CONCAT(oldWhereclause, ' AND am.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
           newWhereclause := CONCAT(newWhereclause, ' AND am.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
--            oldWhereclause := CONCAT(oldWhereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
--            oldWhereclause := CONCAT(oldWhereclause, ' AND aip.ac_holder_name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        END IF;
    else
        oldWhereclause := CONCAT(oldWhereclause, ' AND 1=2 ');
    end if;

	mainInnerQuery := oldSelectquery || oldTablequery || oldWhereclause || ' UNION ALL ' || newSelectquery || newTablequery || newWhereclause ;

    preparequery := 'SELECT json_arrayagg(json_object(' || selectquery || ') returning clob ) from ( '|| mainInnerQuery ||' ) tbl' || commonTablequery;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
      dbms_output.put_line(result);
  END ;