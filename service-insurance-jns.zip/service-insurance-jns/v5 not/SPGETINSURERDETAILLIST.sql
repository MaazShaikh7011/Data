CREATE OR REPLACE PROCEDURE USR_INSURANCE."SPGETINSURERDETAILLIST" (filterjson     IN VARCHAR2,
                                                      userId         IN NUMBER,
                                                      paginationFROM IN NUMBER,
                                                      paginationTO   IN NUMBER)
  AS
    selectQuery      VARCHAR2(4000);
    tableQuery       VARCHAR2(4000);
    whereClause      VARCHAR2(4000);
    selectCountQuery VARCHAR2(4000);
    limitBy          VARCHAR2(4000);
    totalCount       NUMBER;
    orderBy          VARCHAR2(4000);
    mainQuery        VARCHAR2(4000);
  BEGIN

    selectQuery := '@totalCount As totalCount,
			imd.id AS id,
			UOM.organisation_name AS insurerName,
			imd.org_id AS orgId,
			imd.scheme_id AS schemeId,
			sm.short_name AS schemeName,
			imd.year AS years,
			imd.pincode AS pincode,
		    IF(imd.is_active=TRUE,''Active'',''Inactive'') AS status,
			users.`decValue`(imd.master_policy_no) AS masterPolicyNo,
			users.`decValue`(imd.insurer_code) AS insurerCode,
			users.`decValue`(imd.insurer_address) AS insurerAddress,
			users.`decValue`(imd.contact_person) AS contactPerson,
			users.`decValue`(imd.mobile_no) AS mobileNumber,
			users.`decValue`(imd.head_name) AS headName,
			users.`decValue`(imd.head_email) AS headEmail,
			users.`decValue`(imd.head_contact_no) AS headContactNo,
			users.`decValue`(imd.head_mobile_no) AS headMobileNo,
			users.`decValue`(imd.associated_acc_holder_name) AS associatedAccHolderName,
			users.`decValue`(imd.associated_acc_no) AS associatedAccNo,
			users.`decValue`(imd.associated_ifsc_code) AS associatedIfscCode,
			users.`decValue`(imd.email) AS email,
			DATE_FORMAT(imd.policy_start_date, ''%d/%m/%Y'') AS policyStartDate,
			DATE_FORMAT(imd.policy_end_date, ''%d/%m/%Y'') AS policyEndDate,
			imd.policy_end_date AS policyEndDateFormat ';

    tableQuery := 'FROM USR_INSURANCE.insurer_mst_details imd
			    LEFT JOIN JNS_USERS.user_organisation_master UOM ON UOM.user_org_id=imd.name_of_insurer AND UOM.is_active=TRUE
			    LEFT JOIN JNS_USERS.scheme_master sm ON sm.id=imd.scheme_id AND sm.is_active=TRUE ';

    whereClause := 'WHERE 1 AND imd.is_active=TRUE';

    orderBy := 'ORDER BY imd.id ASC ';

    -- Total Count
    selectCountQuery := selectCountQuery || tableQuery || whereClause;
    EXECUTE IMMEDIATE selectCountQuery;

    -- For Limit
    limitBy := ' OFFSET ' || paginationFROM || ' ROWS FETCH NEXT ' || paginationTO || ' ROWS ONLY';

    mainQuery := 'SELECT ' || totalCount || ' AS totalCount, ' || selectQuery || tableQuery || whereClause || orderBy || limitBy;

    EXECUTE IMMEDIATE mainQuery;
  END SPGETINSURERDETAILLIST;



