
CREATE TABLE `insurance_application_detail`.stage_master(
id BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
stage_name VARCHAR(100)
);

INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('1', 'created');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('2', 'otp verification');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('3', 'account holder selection');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('4', 'application form');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('5', 'premium deduction');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('6', 'completed');
INSERT INTO `insurance_application_detail`.`stage_master` (`id`, `stage_name`) VALUES ('7', 'expired');


CREATE TABLE `application_master_audit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `application_id` bigint(20) DEFAULT NULL,
  `stage_id` int(11) DEFAULT NULL,
  `application_status` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
);


DELIMITER $$

USE `insurance_application_detail`$$

DROP TRIGGER IF EXISTS `applicationMasterAudit`$$

CREATE

    TRIGGER `applicationMasterAudit` AFTER UPDATE ON `application_master`
    FOR EACH ROW BEGIN

	IF(OLD.stage_id <>  NEW.stage_id OR OLD.application_status <>  NEW.application_status) THEN
		INSERT INTO `insurance_application_detail`.`application_master_audit`(application_id,stage_id,application_status,created_date)
		 VALUES (OLD.id,OLD.stage_id,OLD.application_status,NOW());
	 END IF;


    END;
$$

DELIMITER ;