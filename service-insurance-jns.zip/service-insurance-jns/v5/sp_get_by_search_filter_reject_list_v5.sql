CREATE OR REPLACE PROCEDURE JNS_INSURANCE.sp_get_by_search_filter_reject_list_v5 (filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    userorgid       LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN

    selectquery := ' ''applicationId'' value em.id,
                ''id'' value em.id,
                ''fullName'' value jns_users."decvalue"(ai.name),
                ''urnNumber'' value em.urn,
                ''schemeLable'' value SM.SHORT_NAME,
                ''schemeId'' value em.scheme_id,
                ''enrollDate'' value em.status_change_date,
                ''stageId'' value em.stage_id,
                ''status'' value ''Failed'',
                ''nameOfInsurer'' value uom.DISPLAY_ORG_NAME,
                ''premiumAmount'' value em.premium_amount,
                ''source'' value (CASE WHEN em.SOURCE = 1 THEN ''Enrolment through other channel'' WHEN em.SOURCE = 2 THEN ''JanSuraksha Portal'' WHEN em.SOURCE = 3 THEN ''Legacy Data'' WHEN em.SOURCE = 4 THEN ''JanSuraksha DIY'' ELSE NULL END),
--                ''source'' value em.source,
                ''masterPolicyNo'' VALUE jns_users."decvalue"(imd.MASTER_POLICY_NO),
                ''branchCode'' value bm.code,
                ''email'' value jns_users."decvalue"(u.email),
                ''channelId'' value em.channel_id,
                ''message'' value em.message,
                ''isActive'' value em.is_active,
--                ''accountNumber'' value jns_users."decvalue"(em.account_number),
                ''lastModifyDate'' value em.modified_date';

    tablequery := ' FROM JNS_MASTER.EXPIRED_ENROLLMENT em
                    LEFT JOIN JNS_INSURANCE.applicant_info ai ON ai.application_id = em.id
                    INNER JOIN JNS_INSURANCE.INSURER_MST_DETAILS imd ON imd.SCHEME_ID = em.SCHEME_ID AND imd.ORG_ID = em.org_id AND imd.POLICY_START_DATE < CURRENT_DATE AND imd.POLICY_END_DATE > CURRENT_DATE AND imd.IS_ACTIVE = 1
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=em.scheme_id AND sm.is_active=1
                    LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = imd.insurer_org_id
                    INNER JOIN JNS_USERS.USERS u ON u.user_id = em.created_by
                    INNER JOIN JNS_USERS.branch_master bm on bm.id = em.branch_id ';

--    whereclause := ' WHERE 1=1 AND am.is_active=1 AND em.stage_id = 8 AND ((amod.source = 4 AND am.stage_id = 8 OR amod.source <> 4 AND am.stage_id = 8)) ';
    whereclause := ' WHERE 1=1 AND em.is_active=1 AND em.stage_id = 8';
    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid) IS NOT NULL THEN
            IF (typeid = 2) THEN
                whereclause := CONCAT(whereclause, ' AND em.org_Id = ' || orgid);
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        whereclause := CONCAT(whereclause, ' AND em.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        whereclause := CONCAT(whereclause, ' AND em.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        whereclause := CONCAT(whereclause, ' AND em.branch_zo_id = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        whereclause := CONCAT(whereclause, ' AND em.branch_lho_id = ' || branchid);
                    ELSE
                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    END IF;
--                ELSE
--                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                END IF;
            ELSIF (typeid = 6) THEN
                whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
            ELSE
                whereclause := CONCAT(whereclause, ' AND 1=2 ');
            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

    IF (JSON_VALUE (filterjson, '$.schemeId') is not null) then
        whereclause := CONCAT(whereclause, ' AND em.scheme_id =' || JSON_VALUE (filterjson, '$.schemeId'));
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
--        if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
--            whereclause := CONCAT(whereclause, ' AND am.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        if(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
            whereclause := CONCAT(whereclause, ' AND em.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
--            whereclause := CONCAT(whereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
--            whereclause := CONCAT(whereclause, ' AND ai.name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 5) then -- Pan Number
--            whereclause := CONCAT(whereclause, ' AND ai.pan = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--        elsif(JSON_VALUE(filterjson, '$.searchType') = 6 OR JSON_VALUE(filterjson, '$.searchType') = 7 OR JSON_VALUE(filterjson, '$.searchType') = 8 OR JSON_VALUE(filterjson, '$.searchType') = 9) then -- Driving Licence OR MGNREGA OR Passport OR Voter's ID Card
--            if (JSON_VALUE(filterjson, '$.searchTypeAsStr') is not null and JSON_VALUE(filterjson, '$.searchTypeAsStr') is not null) then
--                whereclause := CONCAT(whereclause, ' AND (( ai.kyc_id_1 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchTypeAsStr') || ''') AND ai.kyc_id_number_1 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')) OR
--                (ai.kyc_id_2 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchTypeAsStr') || ''') AND ai.kyc_id_number_2 = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')))');
--            end if;
        end if;
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;


--    fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';

--    appcodequery := '(am.urn LIKE ''%' || JSON_VALUE (filterjson, '$.applicationCode') || '%'')';
--
--    accnoquery := '(jns_users."decvalue"(am.account_number) LIKE ''%' || JSON_VALUE (filterjson, '$.accountNumber') || '%'')';

    preparequery := 'SELECT json_arrayagg(json_object(' || selectquery || ')returning clob ) ' || tablequery || whereclause;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
      dbms_output.put_line(result);
  END sp_get_by_search_filter_reject_list_v5;