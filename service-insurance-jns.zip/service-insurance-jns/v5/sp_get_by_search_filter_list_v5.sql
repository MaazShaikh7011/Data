CREATE OR REPLACE PROCEDURE sp_get_by_search_filter_list_v5(filterjson IN  VARCHAR2,
                                                                    userid     IN  NUMBER,
                                                                    result     OUT CLOB)
  AS

    totalcount      LONG;
    userorgid       LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    fromtodatequery CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    appcodequery    CLOB;
    accnoquery      CLOB;

    typeid          NUMBER;
    roleid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
    schemeQuery clob;
    schemeIdQuery clob;
  BEGIN

    IF JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL
    THEN
            if(JSON_VALUE(FILTERJSON, '$.schemeId') = 1)
            THEN
            schemeQuery :=' ''schemeLable'' VALUE ''PMSBY'' ';
            schemeIdQuery :=' ''schemeId'' VALUE 1 ';
            ELSE
            schemeQuery :=' ''schemeLable'' VALUE ''PMJJBY'' ';
            schemeIdQuery :=' ''schemeId'' VALUE 2 ';
            END IF;
    END IF;

    selectquery := ' ''applicationId'' value am.id,
                ''id'' value am.id,
                ''fullName'' value jns_users."decvalue"(aip.ac_holder_name),
                ''urnNumber'' value am.urn,
                '||schemeQuery||',
                '||schemeIdQuery||',
                ''enrollDate'' value am.enrollment_date,
                ''stageId'' value 6,
                ''status'' value ''Success'',
                ''nameOfInsurer'' value uom.DISPLAY_ORG_NAME,
                ''premiumAmount'' value am.premium_amount,
--                ''source'' value am.source,
                ''masterPolicyNo'' VALUE jns_users."decvalue"(td.MASTER_POLICY_NO),
                ''branchCode'' value bm.code,
                ''email'' value jns_users."decvalue"(ai.email),
                ''channelId'' value am.channel_id,
                ''message'' value am.message,
                ''source'' value (CASE WHEN am.SOURCE = 1 THEN ''Enrolment through other channel'' WHEN am.SOURCE = 2 THEN ''JanSuraksha Portal'' WHEN am.SOURCE = 3 THEN ''Legacy Data'' WHEN am.SOURCE = 4 THEN ''JanSuraksha DIY'' ELSE NULL END),
                ''userId'' value ai.user_id_1,
                ''isActive'' value am.is_active,
                ''lastModifyDate'' value am.modified_date,
                 ''nomineeUpdateDate'' value nm.modified_date,
                ''contactDetails'' value jns_users."decvalue"(ai.mobile_number),
                ''accountNumber'' value jns_users."decvalue"(aip.account_number)';

        IF ((JSON_VALUE (FILTERJSON, '$.schemeId') IS NOT NULL) AND (JSON_VALUE (FILTERJSON, '$.schemeId') = 1))
    THEN
      tablequery := ' FROM JNS_MASTER_DATA.PMSBY am ';
      ELSE
      tablequery := ' FROM JNS_MASTER_DATA.PMJJBY am ';
    END IF;

    tablequery := tablequery || ' INNER JOIN JNS_MASTER_DATA.APPLICANT_INFO ai ON ai.id = am.id
                    INNER JOIN JNS_MASTER_DATA.APPLICANT_PI_DETAILS aip ON aip.id = am.id
                    INNER JOIN JNS_MASTER_DATA.transaction_details td on td.application_id = am.id
					INNER JOIN JNS_USERS.branch_master bm on bm.id = am.branch_id
                    LEFT JOIN JNS_USERS.USER_ORGANISATION_MASTER uom ON uom.USER_ORG_ID = am.insurer_org_id
                    LEFT JOIN JNS_MASTER_DATA.nominee_details nm ON nm.application_id = am.id';

    whereclause := ' WHERE 1=1 AND am.is_active=1 ';

--    whereclause := ' AND ((am.source = 4 AND am.stage_id <> 8 OR am.source <> 4)) ';

    IF (userid) IS NOT NULL THEN
        SELECT u.user_type_id, u.branch_id, u.user_org_id, u.user_role_id INTO typeid, branchid, orgid, roleid FROM jns_users.users u WHERE u.is_active = 1 AND u.user_id = userid;
        IF (typeid) IS NOT NULL THEN
            IF (typeid = 2) THEN
                whereclause := CONCAT(whereclause, ' AND am.org_Id = ' || orgid);
                IF (roleid IS NOT NULL AND roleid != 5) THEN
                    IF (roleid = 9) THEN
                        whereclause := CONCAT(whereclause, ' AND am.branch_id = ' || branchid);
                    ELSIF (roleid = 13) THEN
                        whereclause := CONCAT(whereclause, ' AND am.branch_ro_id = ' || branchid);
                    ELSIF (roleid = 14) THEN
                        whereclause := CONCAT(whereclause, ' AND am.BRANCH_ZO_ID = ' || branchid);
                    ELSIF (roleid = 15) THEN
                        whereclause := CONCAT(whereclause, ' AND am.BRANCH_LHO_ID = ' || branchid);
                    ELSE
                        whereclause := CONCAT(whereclause, ' AND 1=2 ');
                    END IF;
--                ELSE
--                    whereclause := CONCAT(whereclause, ' AND 1=1 ');
                END IF;
            ELSIF (typeid = 6) THEN
                whereclause := CONCAT(whereclause, ' AND am.insurer_org_id = ' || orgid);
            ELSE
                whereclause := CONCAT(whereclause, ' AND 1=2 ');
            END IF;
        ELSE
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        END IF;
    ELSE
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    END IF;

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
        if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
            whereclause := CONCAT(whereclause, ' AND aip.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
            whereclause := CONCAT(whereclause, ' AND am.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
            whereclause := CONCAT(whereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
        elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
            whereclause := CONCAT(whereclause, ' AND aip.ac_holder_name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            END IF;
    else
        whereclause := CONCAT(whereclause, ' AND 1=2 ');
    end if;


--    fromtodatequery := ' AND TRUNC(am.modified_date) BETWEEN TO_DATE(''' || JSON_VALUE (filterjson, '$.fromDate') || ''', ''YYYY-MM-DD'') AND TO_DATE(''' || JSON_VALUE (filterjson, '$.toDate') || ''', ''YYYY-MM-DD'')';

--    appcodequery := '(am.urn LIKE ''%' || JSON_VALUE (filterjson, '$.applicationCode') || '%'')';
--
--    accnoquery := '(jns_users."decvalue"(am.account_number) LIKE ''%' || JSON_VALUE (filterjson, '$.accountNumber') || '%'')';

    preparequery := 'SELECT json_arrayagg(json_object(' || selectquery || ')returning clob ) ' || tablequery || whereclause;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery INTO result;
      dbms_output.put_line(result);
  END sp_get_by_search_filter_list_v5;