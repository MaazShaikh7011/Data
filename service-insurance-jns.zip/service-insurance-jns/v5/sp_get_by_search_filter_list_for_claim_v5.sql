CREATE OR REPLACE PROCEDURE sp_get_by_search_filter_list_for_claim_v5 (filterjson IN  VARCHAR2,
                                              userid     IN  NUMBER,
                                              result     OUT CLOB)
  AS

    totalcount      LONG;
    selectquery     CLOB;
    tablequery      CLOB;
    whereclause     CLOB;
    limitquery      CLOB;
    preparequery    CLOB;
    fromtodatequery CLOB;

    roleid          NUMBER;
    typeid          NUMBER;
    orgid           NUMBER;
    branchid        NUMBER;
  BEGIN
    selectquery := ' ''applicationId'' value ca.application_id,
                ''id'' value ca.id,
                ''fullName'' value jns_users."decvalue"(cp.ac_holder_name),
                ''urnNumber'' value ca.urn,
                ''accountNumber'' value jns_users."decvalue"(cp.ap_account_number),
                ''contactDetails'' value jns_users."decvalue"(cd.ap_mobile_number),
                ''schemeId'' value ca.scheme_id,
                ''lastModifyDate'' value ca.modified_date,
                ''status'' value ca.status,
                ''schemeLable'' value sm.short_name  )returning clob) ';

    tablequery := 'FROM JNS_INSURANCE.clm_master ca
                   INNER JOIN JNS_INSURANCE.clm_details cd ON cd.id = ca.id
                   INNER JOIN JNS_INSURANCE.CLM_PI_DETAILS cp ON cp.id = ca.id
                    LEFT JOIN jns_users.scheme_master sm ON sm.id=ca.scheme_id AND sm.is_active=1 ';

    whereclause := ' WHERE  1=1 AND ca.is_active = 1 ';

    if(JSON_VALUE(filterjson, '$.searchType') is not null and JSON_VALUE(filterjson, '$.searchValue') is not null) then
--            if(JSON_VALUE(filterjson, '$.searchType') = 1) then -- Account Number
--                whereclause := CONCAT(whereclause, ' AND am.account_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            if(JSON_VALUE(filterjson, '$.searchType') = 2) then -- URN
                whereclause := CONCAT(whereclause, ' AND ca.urn = '''|| JSON_VALUE (filterjson, '$.searchValue')|| '''');
--            elsif(JSON_VALUE(filterjson, '$.searchType') = 3) then -- Mobile Number
--                whereclause := CONCAT(whereclause, ' AND ai.mobile_number = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
--            elsif(JSON_VALUE(filterjson, '$.searchType') = 4) then -- Applicant Name
--                whereclause := CONCAT(whereclause, ' AND ai.name = jns_users."encvalue"('''|| JSON_VALUE (filterjson, '$.searchValue') || ''')');
            end if;
        else
            whereclause := CONCAT(whereclause, ' AND 1=2 ');
        end if;

    IF JSON_VALUE (filterjson, '$.status') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.status IN (' || JSON_VALUE (filterjson, '$.status') ||')');
    END IF;

    IF (userid) IS NOT NULL
    THEN
      SELECT u.user_type_id,
             u.branch_id,
             u.user_org_id,
             u.user_role_id
        INTO typeid,
             branchid,
             orgid,
             roleid
        FROM jns_users.users u
        WHERE u.is_active = 1
          AND u.user_id = userid;
      IF (typeid) IS NOT NULL
      THEN
        IF (typeid = 2)
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || orgid);
          IF
            roleid IS NOT NULL
            AND roleid != 5
          THEN
            IF roleid = 9
            THEN -- BO
              whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || branchid);
            ELSIF roleid = 13
            THEN -- RO
              whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id = ' || branchid);
            ELSIF roleid = 14
            THEN -- ZO
              whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id = ' || branchid);
            ELSIF roleid = 15
            THEN -- LHO
              whereclause := CONCAT(whereclause, ' AND ca.branch_lho_id = ' || branchid);
            ELSE
              whereclause := CONCAT(whereclause, ' and 0 ');
            END IF;
          END IF;

        ELSIF typeid = 6
        THEN
          whereclause := CONCAT(whereclause, ' AND ca.insurer_org_id = ' || orgid);
        END IF;
      END IF;

    END IF;

--    dbms_output.put_line(whereclause);

    IF JSON_VALUE (filterjson, '$.bankId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.org_id = ' || JSON_VALUE (filterjson, '$.bankId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.roId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_ro_id in (' || JSON_VALUE (filterjson, '$.roId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.zoId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_zo_id in (' || JSON_VALUE (filterjson, '$.zoId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.boId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id in (' || JSON_VALUE (filterjson, '$.boId')||')');
    END IF;

    IF JSON_VALUE (filterjson, '$.channelId') IS NOT NULL
    THEN
      whereclause := whereclause|| ' AND amod.source in ( ''' || JSON_VALUE (filterjson, '$.channelId')||''')' ;
    END IF;

    IF JSON_VALUE (filterjson, '$.schemeId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.scheme_id = ' || JSON_VALUE (filterjson, '$.schemeId'));
    END IF;

    IF JSON_VALUE (filterjson, '$.stateId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_state_id in (' || JSON_VALUE (filterjson, '$.stateId')||')');
    END IF;

    --    IF JSON_VALUE(filterjson, '$.orgId') IS NOT NULL THEN
    --        whereclause := concat(whereclause, ' AND ca.org_id = ' || JSON_VALUE(filterjson, '$.orgId'));
    --    END IF;

    IF JSON_VALUE (filterjson, '$.claimBranchId') IS NOT NULL
    THEN
      whereclause := CONCAT(whereclause, ' AND ca.branch_id = ' || JSON_VALUE (filterjson, '$.claimBranchId'));
    END IF;

--    IF JSON_VALUE (filterjson, '$.tabId') IS NOT NULL
--    THEN
--      IF (JSON_VALUE (filterjson, '$.tabId') = 1)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 6)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 6 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 2
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 3
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 10 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 4
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSIF (JSON_VALUE (filterjson, '$.tabId') = 5)
--        OR (JSON_VALUE (filterjson, '$.tabId') = 8)
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 7 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 9
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 11 ';
--      ELSIF JSON_VALUE (filterjson, '$.tabId') = 7
--      THEN
--        whereclause := whereclause || ' AND ca.claim_status = 8 ';
--      ELSE
--        whereclause := whereclause || ' AND ca.claim_status = 0 ';
--      END IF;
--    END IF;

--    whereclause := whereclause || ' order by ca.modified_date desc ';

    EXECUTE IMMEDIATE ' SELECT COUNT(ca.id)'
    || tablequery
    || whereclause
      INTO totalcount;
    preparequery := 'SELECT json_arrayagg(json_object(''totalCount'' value '
    || totalcount
    || ', '
    || selectquery
    || tablequery
    || whereclause
    || limitquery;

    dbms_output.put_line(preparequery);
    EXECUTE IMMEDIATE preparequery
      INTO result;
--         dbms_output.put_line(result);
  END sp_get_by_search_filter_list_for_claim_v5;