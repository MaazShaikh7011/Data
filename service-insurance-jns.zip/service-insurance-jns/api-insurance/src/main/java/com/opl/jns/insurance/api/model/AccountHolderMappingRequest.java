package com.opl.jns.insurance.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class AccountHolderMappingRequest {

	private Long id;
	private Long applicationId;
	private String accountHolderName;
	private String cif;
	private String dob;
	private String gender;
	private Boolean pmjjbyExists;
	private Boolean pmsbyExists;
	private Boolean kycUpdated;
	private String customerAccountNumber;
	private String urnCode;
	private Integer sizeOfACHolder;

	public AccountHolderMappingRequest(Long id, Long applicationId, String accountHolderName, String cif) {
		this.applicationId = applicationId;
		this.accountHolderName = accountHolderName;
		this.cif = cif;
		this.id = id;
	}
}