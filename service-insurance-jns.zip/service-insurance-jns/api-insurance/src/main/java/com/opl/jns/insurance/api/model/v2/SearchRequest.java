package com.opl.jns.insurance.api.model.v2;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchRequest {

	private Integer searchType;
	
	private String searchTypeAsStr;
	
	private String searchValue;

	private Boolean isEnrollment;
	
	private Boolean isClaim;
	
}
