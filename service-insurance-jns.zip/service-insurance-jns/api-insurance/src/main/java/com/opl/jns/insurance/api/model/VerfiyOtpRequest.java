package com.opl.jns.insurance.api.model;

import jakarta.validation.constraints.NotNull;

import lombok.Data;

@Data
public class VerfiyOtpRequest {
	
	@NotNull
	private Long applicationId;
	
	@NotNull
	private String urn;
	
	@NotNull
	private Long orgId;
	
	@NotNull
	private String verifyOTP;
	
	@NotNull
	private String accountNumber;
	
	private Long userId;

}
