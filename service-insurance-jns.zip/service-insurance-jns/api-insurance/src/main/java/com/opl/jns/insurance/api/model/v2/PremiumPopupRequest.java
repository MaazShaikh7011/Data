package com.opl.jns.insurance.api.model.v2;

import lombok.Data;

@Data
public class PremiumPopupRequest {
	
    private Long applicationId;
    private String customerAccountNumber;
    private String customerFullName;
    private Double premiumAmount;
    private Integer policyEndYear;


}
