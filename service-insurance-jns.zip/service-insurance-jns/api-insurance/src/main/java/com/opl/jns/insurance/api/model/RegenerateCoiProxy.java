package com.opl.jns.insurance.api.model;

import lombok.Data;

@Data
public class RegenerateCoiProxy {
	
	private String fromDate;
	private String toDate;
	private Integer paginationFrom;
	private Integer paginationTo;

}
