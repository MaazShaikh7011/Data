package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;

@Data
public class AccountHolderDetailsRequest extends Auditor{
	
    private Long applicationId;
    
    private Long addressId;
    
    private String cif;
    
    private String customerAccountNumber;
    
    private String customerIFSC;
    
    private String customerFullName;
    
    private String insurerAccountNumber;
    
    private String insurerIfsc;
    
    private String accountHolderName;
    
    private String dob;
    
    private String gender;
    
    private String firstName;
    
    private String middleName;
    
    private String lastName;
    
    private Integer nameOfInsId;
    
    private String insurerName;
    
    private String mobileNumber;
    
    private String emailAddress;
    
    private String masterPolicyNo;
    
    private String masterAccountNo;
    
    private String masterIfscCode;
    
    private String kycID1;
    
    private String kycID1number;
    
    private String kycID2;
    
    private String kycID2number;
    
    private Boolean pan;
    
    private String panNumber;
    
    private Boolean aadhaar;
    
    private String aadhaarNumber;
    
    private String relationOfNominee;
    
    private String nameofGuardian;
    
    private String addressofGuardian;
    
    private String relationshipofGuardian;
    
    private Boolean consentForENACH;
    
    private Date dateOfAutoDebit;
    
    private String transectionUtr;
    
    private Date transactionTimestamp;
    
    private Double transactionAmount;
    
    private String comment;
    
    private Long createdBy;
    
    private Long modifiedBy;

    private Double premiumAmount;
}
