package com.opl.jns.insurance.api.model.v2;

import java.util.Date;
import java.util.List;

import com.opl.jns.insurance.api.model.AddressMasterRequest;
import com.opl.jns.insurance.api.model.Auditor;
import com.opl.jns.insurance.api.model.NomineeDetailsRequest;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ApplicationMasterRequestV2 extends Auditor {

	private Long applicationId;
	private String urn;
	private Long userId;
	private Long schemeId;
	private Long orgId;
	private Long insurerOrgId;
	
	private Integer stageId;
	private Date enrollDate;
	
	private Integer applicationStatus;
	
	private Integer claimStageId;
	private Date claimDate;
	
	private Long insurerMasterId;


	private Boolean isPushed;

	private String accountNo;
	private String custIfscCode;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fatherHusbandName;
	private String insuranceName;
	private String scheme;
	private Date dob;
	private String mobileNo;
	private String emailAddress;
	private Long verifyOTP;
	private String kyc;
	private String kycId1; 
	private String kycId1number; 
	private String kycId2; 
	private String kycId2number; 
	private Long kycId3Id;
	private String kycId3; 
	private String kycId3number;
	private Boolean isSameApplicantAddress=false;
	private Boolean isNomineeDeatilsSameEnroll;

	private AddressMasterRequest address;
	private List<NomineeDetailsRequest> nominee;

	private Long holderId;
	private Double amount;
	private Double premiumAmount;
	private Date coverEndDate;
	private Date maxTransactionDate;
	private String branchName;
	private String ifscCode;
	private String accountHolderName;
	private Integer savingType;
	private String bankName;
	private String nameOfBank;
	private String nameOfInsurer;
	private String disabilityDetails;
	private String disabilityStatus;
	
	private String cif;
	private String gender;
	private String ckyc;
	private String ckycNumber;
	private String masterPolicyNo;
	private String insurerCode;
	private String mobileNumber;

	private String transUtr;
	private Date transTimeStamp;
	private Double transAmount;
	private Integer transactionType;
	private String transComment;

	private String userId1;
	private String userId2;
	private String ruralUrbanSemi;
	private String channelId;
	private Integer source;
	private String consentForAutoDebit;
	private String year;
	private String aadhar;
	private String pan;
	
	private String mobile;
	private String email;
	private String resendOTPTime;
	
	private Date dateOfNomineeUpdate;
	private Date nomineeUpdateRequestDate;
	private Date nomineeUpdateEffectiveDate;
	private Boolean isUpdateManually = false;
	private Integer debitStatus;
	private String message;
	
	public ApplicationMasterRequestV2(Long applicationId, Integer stageId) {
		this.applicationId = applicationId;
		this.stageId = stageId;
	}

	public ApplicationMasterRequestV2() {
		super();
	}

	
	
}
