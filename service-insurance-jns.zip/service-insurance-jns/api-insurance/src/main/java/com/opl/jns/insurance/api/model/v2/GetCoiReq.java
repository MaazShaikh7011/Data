package com.opl.jns.insurance.api.model.v2;

import java.time.LocalDate;



import lombok.Data;

@Data
public class GetCoiReq {
	
	private String accountNumber;
    private String cif;
    private String urn;
    private LocalDate dob;
    private Long applicationId;
	private Long orgId;
	private Long userId;
	private Boolean isInsurer;
	private String token;
	private String sourceId;
	private Long schemeId;
}
