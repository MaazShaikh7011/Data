package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;

@Data
public class InsurerMstDetailsRequest extends Auditor {
	
    private Long schemeId;
    private Long orgId;
    private Long insurerOrgId;
    private String nameOfInsurerStr;
    private String insurerCode;
    private String insurerAddress;
    private Long pincode;
    private String contactPerson;
    private String mobileNo;
    private String email;
    private String headName;
    private String headEmail;
    private String headContactNo;
    private String headMobileNo;
    private String associatedAccHolderName;
    private String associatedAccNo;
    private String associatedIfscCode;
    private String customerAccountNumber;
    private String masterPolicyNo;
    private Date policyStartDate;
    private Date policyEndDate;
    private String year;

}
