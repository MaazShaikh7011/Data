package com.opl.jns.insurance.api.model.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ravi.thummar
 * Date : 02-05-2023
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountProxy {
	private Object id;
	private Long days;
	private Long totalCount;
    private Long acceptedCount;
    private Long rejectedCount;
    private Long sendToInsurerCount;
    private Long onHoldCount;
    private Long sendBackByInsurerCount;
    private Long receivedFromBankCount;
    private Long inProgressCount;
    private Long paidOutCount;
    private Long sendBackToBnakCount;
    private Long branchId;
    private String branchName;
    private Long stateId;
    private String stateName;
    private Long amount;
    private Long year;
    private String chartLabel;
    private Long approvedCount;
    private Long repudiatedCount;
    private Long reportedCount;
    private Long grp1;
    private Long grp2;
    private Long grp3;
    private Long grp4;
    private Long grp5;
    private Long grp6;
}
