package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author ravi.thummar 
 * Date : 05-07-2023
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class OptOutProxy {
	private Long applicationId;
	private String urn;
	private String accountNumber;
	private String name;
	private String cif;
	private Date policyEffectiveDate;
	private Date dateOfRequest;
	private Date dateOfEffective;
	private Long schemeId;
}
