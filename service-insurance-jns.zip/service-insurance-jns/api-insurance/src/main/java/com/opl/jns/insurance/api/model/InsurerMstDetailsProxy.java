package com.opl.jns.insurance.api.model;

import lombok.Data;

import java.util.Date;

@Data
public class InsurerMstDetailsProxy {

    private Long schemeId;
    private Long orgId;
    private Long insurerOrgId;
    private Date dateOfDeath;
    private Date dateAndTimeOfAccident;
	private String imagePath;
	private String associatedAccNo;
	private String associatedAccHolderName;
	private String masterPolicyNo;
	private Date policyStartDate;
	private Date policyEndDate;
	private Date coverEndDate;
}
