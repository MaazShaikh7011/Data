package com.opl.jns.insurance.api.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorStageProxy {

	private Long id;

	private Long applicationId;

	private Long claimId;

	private Integer stageId;

	private String stageName;

	private String message;

	private Date modifiedDate;

	private Long modifiedBy;

	public ErrorStageProxy(Long applicationId, Integer stageId, String stageName, String message, Long modifiedBy) {
		super();
		this.applicationId = applicationId;
		this.stageId = stageId;
		this.stageName = stageName;
		this.message = message;
		this.modifiedBy = modifiedBy;
	}

	public ErrorStageProxy(Long applicationId, Long claimId, Integer stageId, String stageName, String message,
			Long modifiedBy) {
		super();
		this.applicationId = applicationId;
		this.claimId = claimId;
		this.stageId = stageId;
		this.stageName = stageName;
		this.message = message;
		this.modifiedBy = modifiedBy;
	}

}
