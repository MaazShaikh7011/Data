package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;

@Data
public class EnrollmentDetailsProxy {

	private String urn;
	private String createdDate;
	private String modifiedDate;
	private String enrollmentDate;
	private String transactionDate;
	private String status;
	private String enrollmentCompletedDate;
	private String bankName;
	private String branchName;
	private String mode;
	private String premiumAmt;
	private String schemeName;
	private String stageName;
	private String enrollStatus;
	private String accountNumber;
	private String cif;
	private String insurer;
	private String published;
	private Date publishedDate;
	private String active;
	private String sendOtpRes;
	private String verifyOtpRes;
	private String physicalVerificationRes;
	private String custInfoRes;
	private String premiumDeductionRes;
	private Long totalCount;

}
