package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ClaimStatusRequest {
	
	private Long claimId;
	private Integer claimStatus;
	private String insurerStatus;
	private String message;	
	private Integer statusReason;
	private String transactionUTR;
	private Date dateOfTransaction;
	private Double amountOfTransaction;

}
