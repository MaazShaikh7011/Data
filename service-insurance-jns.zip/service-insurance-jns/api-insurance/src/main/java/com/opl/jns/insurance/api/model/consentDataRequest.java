package com.opl.jns.insurance.api.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
public class consentDataRequest {
	
	private String privacyPolicyHtml;
	private String termsAndConditionHtml;
	private String desclaimerHtml;
	private List<Integer> consentType;

}
