package com.opl.jns.insurance.api.model;

import lombok.Data;

@Data
public class StoredProcedureRequest {
    private String filterJSON;
    private Long from;
    private Long to;
}
