package com.opl.jns.insurance.api.wrapper.account_holder_det;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cif",
"customerAccountNumber",
"customerIFSC",
"accountHolderName",
"dob",
"gender",
"firstName",
"middleName",
"lastName",
"dateOfBirth",
"mobileNumber",
"emailAddress",
"addressline1",
"addressline2",
"pincode",
"city",
"cityLGDCode",
"district",
"districtLGDCode",
"state",
"stateLGDCode",
"kycID1",
"kycID1number",
"kycID2",
"kycID2number",
"pan",
"panNumber",
"aadhaar",
"aadhaarNumber",
"nomineeFirstName",
"nomineeMiddleName",
"nomineeLastName",
"nomineeDateOfBirth",
"relationOfNominee",
"nameofGuardian",
"addressofGuardian",
"relationshipofGuardian",
"nomineepan",
"nomineepanNumber",
"nomineeaadhaar",
"nomineeaadhaarNumber",
"consentForENACH",
"dateOfAutoDebit"
})
public class AccountHolderDetails {

	@JsonProperty("cif")
	private String cif;
	@JsonProperty("customerAccountNumber")
	private String customerAccountNumber;
	@JsonProperty("customerIFSC")
	private String customerIFSC;
	@JsonProperty("accountHolderName")
	private String accountHolderName;
	@JsonProperty("dob")
	private String dob;
	@JsonProperty("gender")
	private String gender;
	@JsonProperty("firstName")
	private String firstName;
	@JsonProperty("middleName")
	private String middleName;
	@JsonProperty("lastName")
	private String lastName;
	@JsonProperty("dateOfBirth")
	private String dateOfBirth;
	@JsonProperty("mobileNumber")
	private String mobileNumber;
	@JsonProperty("emailAddress")
	private String emailAddress;
	@JsonProperty("addressline1")
	private String addressline1;
	@JsonProperty("addressline2")
	private String addressline2;
	@JsonProperty("pincode")
	private String pincode;
	@JsonProperty("city")
	private String city;
	@JsonProperty("cityLGDCode")
	private String cityLGDCode;
	@JsonProperty("district")
	private String district;
	@JsonProperty("districtLGDCode")
	private String districtLGDCode;
	@JsonProperty("state")
	private String state;
	@JsonProperty("stateLGDCode")
	private String stateLGDCode;
	@JsonProperty("kycID1")
	private String kycID1;
	@JsonProperty("kycID1number")
	private String kycID1number;
	@JsonProperty("kycID2")
	private String kycID2;
	@JsonProperty("kycID2number")
	private String kycID2number;
	@JsonProperty("pan")
	private String pan;
	@JsonProperty("panNumber")
	private String panNumber;
	@JsonProperty("aadhaar")
	private String aadhaar;
	@JsonProperty("aadhaarNumber")
	private String aadhaarNumber;
	@JsonProperty("nomineeFirstName")
	private String nomineeFirstName;
	@JsonProperty("nomineeMiddleName")
	private String nomineeMiddleName;
	@JsonProperty("nomineeLastName")
	private String nomineeLastName;
	@JsonProperty("nomineeDateOfBirth")
	private String nomineeDateOfBirth;
	@JsonProperty("relationOfNominee")
	private String relationOfNominee;
	@JsonProperty("nameofGuardian")
	private String nameofGuardian;
	@JsonProperty("addressofGuardian")
	private String addressofGuardian;
	@JsonProperty("relationshipofGuardian")
	private String relationshipofGuardian;
	@JsonProperty("nomineepan")
	private String nomineepan;
	@JsonProperty("nomineepanNumber")
	private String nomineepanNumber;
	@JsonProperty("nomineeaadhaar")
	private String nomineeaadhaar;
	@JsonProperty("nomineeaadhaarNumber")
	private String nomineeaadhaarNumber;
	@JsonProperty("consentForENACH")
	private String consentForENACH;
	@JsonProperty("dateOfAutoDebit")
	private String dateOfAutoDebit;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();
	
	@JsonProperty("cif")
	public String getCif() {
	return cif;
	}
	
	@JsonProperty("cif")
	public void setCif(String cif) {
	this.cif = cif;
	}
	
	@JsonProperty("customerAccountNumber")
	public String getCustomerAccountNumber() {
	return customerAccountNumber;
	}
	
	@JsonProperty("customerAccountNumber")
	public void setCustomerAccountNumber(String customerAccountNumber) {
	this.customerAccountNumber = customerAccountNumber;
	}
	
	@JsonProperty("customerIFSC")
	public String getCustomerIFSC() {
	return customerIFSC;
	}
	
	@JsonProperty("customerIFSC")
	public void setCustomerIFSC(String customerIFSC) {
	this.customerIFSC = customerIFSC;
	}
	
	@JsonProperty("accountHolderName")
	public String getAccountHolderName() {
	return accountHolderName;
	}
	
	@JsonProperty("accountHolderName")
	public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
	}
	
	@JsonProperty("dob")
	public String getDob() {
	return dob;
	}
	
	@JsonProperty("dob")
	public void setDob(String dob) {
	this.dob = dob;
	}
	
	@JsonProperty("gender")
	public String getGender() {
	return gender;
	}
	
	@JsonProperty("gender")
	public void setGender(String gender) {
	this.gender = gender;
	}
	
	@JsonProperty("firstName")
	public String getFirstName() {
	return firstName;
	}
	
	@JsonProperty("firstName")
	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}
	
	@JsonProperty("middleName")
	public String getMiddleName() {
	return middleName;
	}
	
	@JsonProperty("middleName")
	public void setMiddleName(String middleName) {
	this.middleName = middleName;
	}
	
	@JsonProperty("lastName")
	public String getLastName() {
	return lastName;
	}
	
	@JsonProperty("lastName")
	public void setLastName(String lastName) {
	this.lastName = lastName;
	}
	
	@JsonProperty("dateOfBirth")
	public String getDateOfBirth() {
	return dateOfBirth;
	}
	
	@JsonProperty("dateOfBirth")
	public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
	}
	
	@JsonProperty("mobileNumber")
	public String getMobileNumber() {
	return mobileNumber;
	}
	
	@JsonProperty("mobileNumber")
	public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
	}
	
	@JsonProperty("emailAddress")
	public String getEmailAddress() {
	return emailAddress;
	}
	
	@JsonProperty("emailAddress")
	public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
	}
	
	@JsonProperty("addressline1")
	public String getAddressline1() {
	return addressline1;
	}
	
	@JsonProperty("addressline1")
	public void setAddressline1(String addressline1) {
	this.addressline1 = addressline1;
	}
	
	@JsonProperty("addressline2")
	public String getAddressline2() {
	return addressline2;
	}
	
	@JsonProperty("addressline2")
	public void setAddressline2(String addressline2) {
	this.addressline2 = addressline2;
	}
	
	@JsonProperty("pincode")
	public String getPincode() {
	return pincode;
	}
	
	@JsonProperty("pincode")
	public void setPincode(String pincode) {
	this.pincode = pincode;
	}
	
	@JsonProperty("city")
	public String getCity() {
	return city;
	}
	
	@JsonProperty("city")
	public void setCity(String city) {
	this.city = city;
	}
	
	@JsonProperty("cityLGDCode")
	public String getCityLGDCode() {
	return cityLGDCode;
	}
	
	@JsonProperty("cityLGDCode")
	public void setCityLGDCode(String cityLGDCode) {
	this.cityLGDCode = cityLGDCode;
	}
	
	@JsonProperty("district")
	public String getDistrict() {
	return district;
	}
	
	@JsonProperty("district")
	public void setDistrict(String district) {
	this.district = district;
	}
	
	@JsonProperty("districtLGDCode")
	public String getDistrictLGDCode() {
	return districtLGDCode;
	}
	
	@JsonProperty("districtLGDCode")
	public void setDistrictLGDCode(String districtLGDCode) {
	this.districtLGDCode = districtLGDCode;
	}
	
	@JsonProperty("state")
	public String getState() {
	return state;
	}
	
	@JsonProperty("state")
	public void setState(String state) {
	this.state = state;
	}
	
	@JsonProperty("stateLGDCode")
	public String getStateLGDCode() {
	return stateLGDCode;
	}
	
	@JsonProperty("stateLGDCode")
	public void setStateLGDCode(String stateLGDCode) {
	this.stateLGDCode = stateLGDCode;
	}
	
	@JsonProperty("kycID1")
	public String getKycID1() {
	return kycID1;
	}
	
	@JsonProperty("kycID1")
	public void setKycID1(String kycID1) {
	this.kycID1 = kycID1;
	}
	
	@JsonProperty("kycID1number")
	public String getKycID1number() {
	return kycID1number;
	}
	
	@JsonProperty("kycID1number")
	public void setKycID1number(String kycID1number) {
	this.kycID1number = kycID1number;
	}
	
	@JsonProperty("kycID2")
	public String getKycID2() {
	return kycID2;
	}
	
	@JsonProperty("kycID2")
	public void setKycID2(String kycID2) {
	this.kycID2 = kycID2;
	}
	
	@JsonProperty("kycID2number")
	public String getKycID2number() {
	return kycID2number;
	}
	
	@JsonProperty("kycID2number")
	public void setKycID2number(String kycID2number) {
	this.kycID2number = kycID2number;
	}
	
	@JsonProperty("pan")
	public String getPan() {
	return pan;
	}
	
	@JsonProperty("pan")
	public void setPan(String pan) {
	this.pan = pan;
	}
	
	@JsonProperty("panNumber")
	public String getPanNumber() {
	return panNumber;
	}
	
	@JsonProperty("panNumber")
	public void setPanNumber(String panNumber) {
	this.panNumber = panNumber;
	}
	
	@JsonProperty("aadhaar")
	public String getAadhaar() {
	return aadhaar;
	}
	
	@JsonProperty("aadhaar")
	public void setAadhaar(String aadhaar) {
	this.aadhaar = aadhaar;
	}
	
	@JsonProperty("aadhaarNumber")
	public String getAadhaarNumber() {
	return aadhaarNumber;
	}
	
	@JsonProperty("aadhaarNumber")
	public void setAadhaarNumber(String aadhaarNumber) {
	this.aadhaarNumber = aadhaarNumber;
	}
	
	@JsonProperty("nomineeFirstName")
	public String getNomineeFirstName() {
	return nomineeFirstName;
	}
	
	@JsonProperty("nomineeFirstName")
	public void setNomineeFirstName(String nomineeFirstName) {
	this.nomineeFirstName = nomineeFirstName;
	}
	
	@JsonProperty("nomineeMiddleName")
	public String getNomineeMiddleName() {
	return nomineeMiddleName;
	}
	
	@JsonProperty("nomineeMiddleName")
	public void setNomineeMiddleName(String nomineeMiddleName) {
	this.nomineeMiddleName = nomineeMiddleName;
	}
	
	@JsonProperty("nomineeLastName")
	public String getNomineeLastName() {
	return nomineeLastName;
	}
	
	@JsonProperty("nomineeLastName")
	public void setNomineeLastName(String nomineeLastName) {
	this.nomineeLastName = nomineeLastName;
	}
	
	@JsonProperty("nomineeDateOfBirth")
	public String getNomineeDateOfBirth() {
	return nomineeDateOfBirth;
	}
	
	@JsonProperty("nomineeDateOfBirth")
	public void setNomineeDateOfBirth(String nomineeDateOfBirth) {
	this.nomineeDateOfBirth = nomineeDateOfBirth;
	}
	
	@JsonProperty("relationOfNominee")
	public String getRelationOfNominee() {
	return relationOfNominee;
	}
	
	@JsonProperty("relationOfNominee")
	public void setRelationOfNominee(String relationOfNominee) {
	this.relationOfNominee = relationOfNominee;
	}
	
	@JsonProperty("nameofGuardian")
	public String getNameofGuardian() {
	return nameofGuardian;
	}
	
	@JsonProperty("nameofGuardian")
	public void setNameofGuardian(String nameofGuardian) {
	this.nameofGuardian = nameofGuardian;
	}
	
	@JsonProperty("addressofGuardian")
	public String getAddressofGuardian() {
	return addressofGuardian;
	}
	
	@JsonProperty("addressofGuardian")
	public void setAddressofGuardian(String addressofGuardian) {
	this.addressofGuardian = addressofGuardian;
	}
	
	@JsonProperty("relationshipofGuardian")
	public String getRelationshipofGuardian() {
	return relationshipofGuardian;
	}
	
	@JsonProperty("relationshipofGuardian")
	public void setRelationshipofGuardian(String relationshipofGuardian) {
	this.relationshipofGuardian = relationshipofGuardian;
	}
	
	@JsonProperty("nomineepan")
	public String getNomineepan() {
	return nomineepan;
	}
	
	@JsonProperty("nomineepan")
	public void setNomineepan(String nomineepan) {
	this.nomineepan = nomineepan;
	}
	
	@JsonProperty("nomineepanNumber")
	public String getNomineepanNumber() {
	return nomineepanNumber;
	}
	
	@JsonProperty("nomineepanNumber")
	public void setNomineepanNumber(String nomineepanNumber) {
	this.nomineepanNumber = nomineepanNumber;
	}
	
	@JsonProperty("nomineeaadhaar")
	public String getNomineeaadhaar() {
	return nomineeaadhaar;
	}
	
	@JsonProperty("nomineeaadhaar")
	public void setNomineeaadhaar(String nomineeaadhaar) {
	this.nomineeaadhaar = nomineeaadhaar;
	}
	
	@JsonProperty("nomineeaadhaarNumber")
	public String getNomineeaadhaarNumber() {
	return nomineeaadhaarNumber;
	}
	
	@JsonProperty("nomineeaadhaarNumber")
	public void setNomineeaadhaarNumber(String nomineeaadhaarNumber) {
	this.nomineeaadhaarNumber = nomineeaadhaarNumber;
	}
	
	@JsonProperty("consentForENACH")
	public String getConsentForENACH() {
	return consentForENACH;
	}
	
	@JsonProperty("consentForENACH")
	public void setConsentForENACH(String consentForENACH) {
	this.consentForENACH = consentForENACH;
	}
	
	@JsonProperty("dateOfAutoDebit")
	public String getDateOfAutoDebit() {
	return dateOfAutoDebit;
	}
	
	@JsonProperty("dateOfAutoDebit")
	public void setDateOfAutoDebit(String dateOfAutoDebit) {
	this.dateOfAutoDebit = dateOfAutoDebit;
	}
	
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}
	
	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}

}