package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;

/**
 * @author - Maaz Shaikh
 * @Date - 3/8/2023
 */
@Data
public class Auditor {

    private Long id;
    private Date createdDate;
    private Long createdBy;
    private Date modifiedDate;
    private Long modifiedBy;
    private Boolean isActive;

}
