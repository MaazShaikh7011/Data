package com.opl.jns.insurance.api.model;

import java.util.Date;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ApplicationMasterRequest extends Auditor {

	private Long applicationId;
	private Date urn;
	private Long userId;
	private Long schemeId;
	private Long orgId;
	private String bankName;
	private Integer enrollStageId;
	private Date enrollDate;
	
	private Integer applicationStatus;
	
	private Integer claimStageId;
	private Date claimDate;
	
	private Long insurerMasterId;
	private String urnCode;

	private Boolean isPushed;	

	private String accountNo;
	private String firstName;
	private String middleName;
	private String lastName;
	private String insuranceName;
	private String scheme;
	private Date dob;
	private String mobileNo;
	private Long verifyOTP;
	private String kyc;
	private String kycId1; 
	private String kycId1number; 
	private String kycId2; 
	private String kycId2number; 
	private Boolean isSameApplicantAddress;
	private String emailAddress;
	private AddressMasterRequest address;
	private List<NomineeDetailsRequest> nominee;

	private Long holderId;
	private Double amount;
	private Date coverEndDate;
	private String branchName;
	private String ifscCode;
	private String accountHolderName;
	private Integer savingType;
	private String disabilityStatus;
    private String disabilityDetails;
    private Boolean isNomineeDeatilsSameEnroll;//added
    private String cif;
    private Boolean isNomineeUpdate;
    private Integer type;
    private Boolean isCustWeb;
    private Boolean isRegisterUser;
}
