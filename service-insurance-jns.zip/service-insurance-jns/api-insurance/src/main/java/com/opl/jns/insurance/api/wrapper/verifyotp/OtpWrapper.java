package com.opl.jns.insurance.api.wrapper.verifyotp;

import java.util.LinkedHashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"status",
"message",
"flag"
})
public class OtpWrapper {

	@JsonProperty("status")
	private Long status;
	@JsonProperty("message")
	private String message;
	@JsonProperty("flag")
	private Boolean flag;
	
	@JsonProperty("status")
	public Long getStatus() {
	return status;
	}
	
	@JsonProperty("status")
	public void setStatus(Long status) {
	this.status = status;
	}
	
	@JsonProperty("message")
	public String getMessage() {
	return message;
	}
	
	@JsonProperty("message")
	public void setMessage(String message) {
	this.message = message;
	}
	
	@JsonProperty("flag")
	public Boolean getFlag() {
	return flag;
	}
	
	@JsonProperty("flag")
	public void setFlag(Boolean flag) {
	this.flag = flag;
	}
	
	}