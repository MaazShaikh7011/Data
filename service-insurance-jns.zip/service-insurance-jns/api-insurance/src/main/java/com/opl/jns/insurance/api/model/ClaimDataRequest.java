package com.opl.jns.insurance.api.model;

import jakarta.validation.constraints.NotNull;

import lombok.Data;

@Data
public class ClaimDataRequest {
	
	@NotNull
	private Long applicationId;
	
	@NotNull
	private Long claimId;

}
