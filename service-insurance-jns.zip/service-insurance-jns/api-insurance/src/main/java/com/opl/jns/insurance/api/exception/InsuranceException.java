package com.opl.jns.insurance.api.exception;

/**
 * @author - Maaz Shaikh
 * @Date - 3/9/2023
 */
public class InsuranceException extends Exception{
    public  InsuranceException(String message){
        super(message);
    }
    public  InsuranceException(Exception e){
        super(e);
    }

    public InsuranceException() {
        super();
    }
}
