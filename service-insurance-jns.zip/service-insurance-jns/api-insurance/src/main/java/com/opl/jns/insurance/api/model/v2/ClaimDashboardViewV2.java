package com.opl.jns.insurance.api.model.v2;

import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDashboardViewV2 {

	public String fullName;
	public String urnNo;
	public String typeOfLoss;
	public String receiveddate;
	public String lastActionDate;
	public String schemeName;
	public Integer claimStatus;
	public String claimDate;
	public String isClaimantSame;
	public Integer nomineeAge;
	public Integer rejectCnt;
	public Map<String, Object> insuredDetails;
	public Map<String, Object> insuredAddress;
	public Map<String, Object> nomineeDetails;
	public Map<String, Object> claimantDetails;
	public Map<String, Object> claimDetails;
	public Map<String, Object> guardianDetails;
	public Map<String, Object> claimantBankDetails;
	public Map<String, Object> paymentDetails;
//	public Map<String, Object> approvedDetails;
	public Map<String, Object> pmsbyDetails;
	public Map<String, Object> rejectionDetails;
	public Map<String, Object> sentBackToBank;
	public Map<String, Object> nomineeAddress;
	public Map<String, Object> optOut;
	private Integer schemeId;
	private String premRemitDate;
	private String premDebitDate;
	private String masterPolicyNumber;
	private Boolean isUpdateManually = false;

		
	
}
