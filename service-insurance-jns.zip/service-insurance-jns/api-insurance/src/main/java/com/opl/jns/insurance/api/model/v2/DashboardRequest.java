package com.opl.jns.insurance.api.model.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DashboardRequest {
    private Integer paginationFROM;
    private Integer paginationTO;
    private String filterAnd;
    private String filterOr;
    private Integer schemeId;
    private Integer orgId;
    private Integer scheme;
    private Integer pageType;
    private Integer tabId;
    private String PolicyFromDate;
    private String PolicyToDate;
    private String fromDate;
    private String toDate;
    private String year;
    private String month;
    private Integer stateId;
    private Long boId;
    private Long zoId;
    private Long roId;
    private Integer branchId;
    private String channelId;
    private String searchData;
    private String accountNumber;
    private String applicationCode;
    private Integer branchType;
    private Integer type;
    private Integer filterType;
    private Boolean isSkipCount;
    private Integer insuranceType;
}
