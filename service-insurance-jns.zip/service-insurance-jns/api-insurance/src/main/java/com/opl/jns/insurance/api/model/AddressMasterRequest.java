package com.opl.jns.insurance.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AddressMasterRequest extends Auditor {

    private String addressLine1;
    private String addressLine2;
    private String district;
    private Long districtLgdCode;
    private String city;
    private Long cityLgdCode;
    private Long cityId;
    private String state;
    private Long stateLgdCode;
    private Long stateId;
    private Integer pincode;
    private Boolean isOtherClaimant;

}
