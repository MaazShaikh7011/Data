package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;

@Data
public class AccountHolderDetailsFlagRequest {
	

	private Long id;
    private Long applicationId;
    private Boolean isCifReceived;
    private Boolean isCustomerAccountNumberReceived;
    private Boolean isCustomerIfscReceived;
    private Boolean isAccountHolderNameReceived;
    private Boolean isDobReceived;
    private Boolean isInsurerNameReceived;
    private Boolean isGenderReceived;
    private Boolean isFirstNameReceived;
    private Boolean isMiddleNameReceived;
    private Boolean isLastNameReceived;
    private Boolean isMobileNumberReceived;
    private Boolean isEmailAddressReceived;
    private Boolean isAddressLine1Received;
    private Boolean isAddressLine2Received;
    private Boolean isDistrictReceived;
    private Boolean isDistrictLgdCodeReceived;
    private Boolean isCityReceived;
    private Boolean isCityLgdCodeReceived;
    private Boolean isStateReceived;
    private Boolean isStateLgdCodeReceived;
    private Boolean isPincodeReceived;
    private Boolean isKycId1Received;
    private Boolean isKycId1NumberReceived;
    private Boolean isKycId2Received;
    private Boolean isKycId2NumberReceived;
    private Boolean isPanReceived;
    private Boolean isPanNumberReceived;
    private Boolean isAadhaarReceived;
    private Boolean isAadhaarNumberReceived;
    private Boolean isNameOfGuardianReceived;
    private Boolean isAddressOfGuardianReceived;
    private Boolean isRelationshipOfGuardianReceived;
    private Boolean isConsentForEnachReceived;
    private Boolean isDateOfAutoDebitReceived;
    private Boolean isNomineeFirstNameReceived;
    private Boolean isNomineeMiddleNameReceived;
    private Boolean isNomineeLastNameReceived;
    private Boolean isNomineeDateOfBirthReceived;
    private Boolean isNomineePanReceived;
    private Boolean isNomineePanNumberReceived;
    private Boolean isNomineeAadhaarReceived;
    private Boolean isNomineeAadhaarNumberReceived;
    private Boolean isRelationOfNomineeReceived;
    private Date createdDate;
    private Boolean isActive;

}
