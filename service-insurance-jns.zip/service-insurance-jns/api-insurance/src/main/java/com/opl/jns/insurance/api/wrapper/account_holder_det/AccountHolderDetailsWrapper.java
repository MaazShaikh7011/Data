package com.opl.jns.insurance.api.wrapper.account_holder_det;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"status",
"message",
"accountHolderDetails"
})
public class AccountHolderDetailsWrapper {

@JsonProperty("status")
private Long status;
@JsonProperty("message")
private String message;
@JsonProperty("accountHolderDetails")
private AccountHolderDetails accountHolderDetails;
@JsonIgnore
private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

@JsonProperty("status")
public Long getStatus() {
return status;
}

@JsonProperty("status")
public void setStatus(Long status) {
this.status = status;
}

@JsonProperty("message")
public String getMessage() {
return message;
}

@JsonProperty("message")
public void setMessage(String message) {
this.message = message;
}

@JsonProperty("accountHolderDetails")
public AccountHolderDetails getAccountHolderDetails() {
return accountHolderDetails;
}

@JsonProperty("accountHolderDetails")
public void setAccountHolderDetails(AccountHolderDetails accountHolderDetails) {
this.accountHolderDetails = accountHolderDetails;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}