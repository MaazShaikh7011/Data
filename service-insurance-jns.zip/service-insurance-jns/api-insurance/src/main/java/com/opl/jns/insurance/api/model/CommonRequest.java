package com.opl.jns.insurance.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonRequest {
    private Long paginationFROM;
    private Long paginationTO;
    private String filterJSON;
    private String listKey;
    private String whereClause;
}
