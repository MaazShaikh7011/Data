package com.opl.jns.insurance.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
public class ClaimDeDupeDetailsProxy {
    private Long claimId;
    private Date hospitalisationDate;
    private String fIRNo;
    private Date fIRDate;
    private String panchnamaNo;
    private Date panchnamaDate;
    private String postMortemReportNo;
    private Date postMortemReportDate;
    private String deathDisabilityCertificateReportNo;
    private Date deathDisabilityCertificateReportDate;
}
