package com.opl.jns.insurance.api.model;

import java.util.Date;

import com.opl.jns.utils.common.OPLUtils;

import lombok.Data;

@Data
public class PolicyDetailsProxy {

	private static PolicyDetailsProxy obj;  
	private Long id;
	private String masterPolicyNo;
	private String urn;
	private String branchName;
	private String branchCode;
	private String policyInceptionDate;
	private String insurerName;
	
	public static PolicyDetailsProxy getNewInstance() {
		if(OPLUtils.isObjectNullOrEmpty(obj)) {
			return new PolicyDetailsProxy();
		}
		return obj;
	}

	public PolicyDetailsProxy(String masterPolicyNo, String urn, String branchName, String branchCode,
			String policyInceptionDate, String insurerName) {
		super();
		this.masterPolicyNo = masterPolicyNo;
		this.urn = urn;
		this.branchName = branchName;
		this.branchCode = branchCode;
		this.policyInceptionDate = policyInceptionDate;
		this.insurerName = insurerName;
	}

	public PolicyDetailsProxy() {
		super();
	}
	
}
