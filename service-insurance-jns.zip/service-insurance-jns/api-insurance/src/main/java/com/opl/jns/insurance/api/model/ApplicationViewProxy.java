package com.opl.jns.insurance.api.model;

import lombok.Data;

@Data
public class ApplicationViewProxy {

	private Long id;
	private String urn;
	private String accountHolderName;
	private String schemeName;
	private String applicationStatus;
	private String firstEnrollmentDate;
	private String nameOfInsurer;
	private Double premiumAmount;
	private String source;
	private String masterPolicyNumber;
	private String branchCode;
	private String userId;
	private String channelId;
}
