package com.opl.jns.insurance.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PremiumDeductionFailedProxy {

	private Long applicationId;
	private Integer schemeId;
	private Long userId;
	private String transactionUTR;
	private String transactionTimeStamp;
	private String transactionAmount;
	private String comment;
	

}
