package com.opl.jns.insurance.api.model;

import lombok.Data;

@Data
public class EnrollmentDtlProxy {
	
	private String fromDate;
	private String toDate;
	private Integer paginationFROM;
	private Integer paginationTO;
	private Long userId;
	private String searchData;
	private Integer type;
	private Long orgId;
	private String urn;
	private Integer displayTypeId;

}
