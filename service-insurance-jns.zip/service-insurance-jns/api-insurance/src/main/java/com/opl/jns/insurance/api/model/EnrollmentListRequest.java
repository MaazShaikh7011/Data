package com.opl.jns.insurance.api.model;

import lombok.Getter;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 9/26/2023
 */
@Setter
@Getter
public class EnrollmentListRequest {

    private String paginationFROM;
    private String paginationTO;
    private Long type;
    private Long schemeId;
    private String searchData;
}
