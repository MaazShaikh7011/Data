package com.opl.jns.insurance.api.model;

import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.Data;

@Data
public class UserOrganisationMasterRequest extends Auditor {
	
	private Long userOrgId;
	private String organisationName;
	private String displayOrgName;
	private String organisationCode;
	private Integer orgType;


}
