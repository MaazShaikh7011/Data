package com.opl.jns.insurance.api.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author maaz.shaikh
 * @Date 5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClaimDeDupeDetails implements Serializable {

	private final static long serialVersionUID = 1083988607005075259L;

	public String urn;
	public String intimationDate;
	public Long type;
	public Long claimStatus;
	public String dateOfLoss;
	public String beneficiaryBank;

}