package com.opl.jns.insurance.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class ConsentDataProxy {
	
	private Long applicationId;
	private Integer schemeId;
	private Long orgId;
	private String insurerName;
	private String masterPolicyNumber;
	private String 	quarterMonthsFirst;
	private String 	quarterMonthsSecond;
	private String 	quarterMonthsThird;
	private String 	quarterMonthsFourth;
	private String 	currentMonths;
	private Double 	firstQuarterMonthsAmount;
	private Double 	secondQuarterMonthsAmount;
	private Double 	thirdQuarterMonthsAmount;
	private Double 	fourthQuarterMonthsAmount;
	private Double 	currentMonthsAmount;
}
