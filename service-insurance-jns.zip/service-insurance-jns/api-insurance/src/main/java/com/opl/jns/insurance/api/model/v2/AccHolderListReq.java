package com.opl.jns.insurance.api.model.v2;

import java.time.LocalDate;

import lombok.Data;

@Data
public class AccHolderListReq {

	private String accountValue;

	private LocalDate dob;

	private Long applicationId;
	private Long orgId;
	private Long schemeId;

}
