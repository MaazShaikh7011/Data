package com.opl.jns.insurance.api.wrapper.verifyotp;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"accountHolderName",
"cif",
"dob",
"gender",
"PMJJBYexists",
"PMSBYexists",
"KYCUpdated"
})
public class AccountHolderDetail {

@JsonProperty("accountHolderName")
private String accountHolderName;
@JsonProperty("cif")
private String cif;
@JsonProperty("dob")
private String dob;
@JsonProperty("gender")
private String gender;
@JsonProperty("PMJJBYexists")
private String pMJJBYexists;
@JsonProperty("PMSBYexists")
private String pMSBYexists;
@JsonProperty("KYCUpdated")
private String kYCUpdated;
@JsonIgnore
private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

@JsonProperty("accountHolderName")
public String getAccountHolderName() {
return accountHolderName;
}

@JsonProperty("accountHolderName")
public void setAccountHolderName(String accountHolderName) {
this.accountHolderName = accountHolderName;
}

@JsonProperty("cif")
public String getCif() {
return cif;
}

@JsonProperty("cif")
public void setCif(String cif) {
this.cif = cif;
}

@JsonProperty("dob")
public String getDob() {
return dob;
}

@JsonProperty("dob")
public void setDob(String dob) {
this.dob = dob;
}

@JsonProperty("gender")
public String getGender() {
return gender;
}

@JsonProperty("gender")
public void setGender(String gender) {
this.gender = gender;
}

@JsonProperty("PMJJBYexists")
public String getPMJJBYexists() {
return pMJJBYexists;
}

@JsonProperty("PMJJBYexists")
public void setPMJJBYexists(String pMJJBYexists) {
this.pMJJBYexists = pMJJBYexists;
}

@JsonProperty("PMSBYexists")
public String getPMSBYexists() {
return pMSBYexists;
}

@JsonProperty("PMSBYexists")
public void setPMSBYexists(String pMSBYexists) {
this.pMSBYexists = pMSBYexists;
}

@JsonProperty("KYCUpdated")
public String getKYCUpdated() {
return kYCUpdated;
}

@JsonProperty("KYCUpdated")
public void setKYCUpdated(String kYCUpdated) {
this.kYCUpdated = kYCUpdated;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}