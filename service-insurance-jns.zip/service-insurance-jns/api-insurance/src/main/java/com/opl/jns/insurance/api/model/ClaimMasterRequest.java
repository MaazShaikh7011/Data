package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ClaimMasterRequest extends Auditor {

	private String accountHolderName;
	private Date dob;
	private String mobileNo;
	private String emailAddress;
	private String insuranceName;
	private String accountNo;
	private String mobileOfNominee;
	private String emailOfNominee;
	private String correctNomineeFirstName;
	private String correctNomineeMiddleName;
	private String correctNomineeLastName;
	private String mobileNumberOfGuardian;
	private String emailIdOfGuardian;
	private Integer claimStatus;
	private String urnCode;
	private Long applicationId;
	private Boolean isClaimantSame;
	private Boolean isNomineeSame;
	private Date enrollDate;
	private Date firstEnrollmentDate;
	private Date dateAndTimeOfAccident;
	private Boolean isDateTimeOfAccident;
	private String dayOfAccident;
	private Date dateOfDeath;
	private Boolean isDateOfDeath;
	private String locationOfLoss;
	private Long lossLocationPincode;
	private Integer natureOfLoss;
	private String natureOfLossValue;
	private Integer causeOfDeathDisability;
	private String causeOfDeathDisabilityValue;
	private String relationShipOfGuardianStr;
	private String relationOfNomineeApplicantStr;
	private Long typeOfDisablity;
	private String typeOfDisablityValue;
	private Long firNo;
	private String claimantBankAcNumber;
	private String custIfscCode;
	private String nameOfBank;
	private String claimantKycDetails;
	private String pan;
	private String aadhar;
	private String paasport;
	private String drivingLicence;
	private String mgnregaCard;
	private String voterIdCard;
	private Long otherClaimantId;
	private String kycDocId;

	private Integer claimStageId;

	private Long claimBranchId;

	private Date claimDate;
	
	private NomineeDetailsRequest claimantData;
	private NomineeDetailsRequest nomineeData;

	private AddressMasterRequest apAddress;
	
	private Integer docTypeId;
	private String docTitle;
	
	private String transactionUtr;
	private Date dateOfTransaction;
	private Double amountOfTransaction;
	private Integer clmKycId1;
	private String clmKycIdNumber1;
	private Integer clmKycId2;
	private String clmKycIdNumber2;
	private Date nomineeUpdateRequestDate;
	private Date nomineeUpdateEffectiveDate;
	private Date coverEndDate;
	private String bankName;
	private String custBankName;
	private String custAccountNo;
	private String custIfsc;
	
	
	
}
