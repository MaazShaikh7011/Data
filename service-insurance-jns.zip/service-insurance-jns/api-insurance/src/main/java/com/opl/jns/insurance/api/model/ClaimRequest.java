package com.opl.jns.insurance.api.model;

import lombok.Data;

/**
 * 
 * @author paresh.radadiya
 * @Date - 3/27/2023
 */

@Data
public class ClaimRequest {

	public String accountValue;	
	public Integer type;
	private Long schemeId;

}
