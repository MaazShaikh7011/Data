package com.opl.jns.insurance.api.model;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateClaimAccountHolderRequest {
	
	private Long applicationId;
	private Integer schemeId;
	private String accountNumber;
	private String urn;
	private String accountHolderName;	
	private String cif;
	private Long orgId;
	private Date dateOfDeath;
	private Date dateAndTimeOfAccident;
	private Integer natureOfLoss;
}
