package com.opl.jns.insurance.api.enums;

public enum QuarterEnum {

	FIRST__QUARTER(5L, "FIRST QUARTER","6,7,8",1), SECOND__QUARTER(6L, "SECOND QUARTER","9,10,11",2), THIRD__QUARTER(7L, "THIRD QUARTER","12,1,2",3),
	FOURTH__QUARTER(8L, "FOURTH QUARTER","3,4,5",4);


	private Long id;
	private String value;
	private String month;
	private Integer quarterNo;

	private QuarterEnum(Long id, String value, String month, Integer quarterNo) {
		this.id = id;
		this.value = value;
		this.month = month;
		this.quarterNo = quarterNo;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getMonth() {
		return month;
	}	

	public Integer getQuarterNo() {
		return quarterNo;
	}

	public static QuarterEnum fromId(Integer v) {
		for (QuarterEnum c : QuarterEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static QuarterEnum[] getAll() {
		return QuarterEnum.values();
	}
}
