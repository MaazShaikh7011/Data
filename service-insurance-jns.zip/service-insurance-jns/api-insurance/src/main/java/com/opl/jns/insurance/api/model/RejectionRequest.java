package com.opl.jns.insurance.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RejectionRequest {
    private Long applicationId;
//    private String message;
}
