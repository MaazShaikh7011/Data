package com.opl.jns.insurance.service.repository.impl;

import java.sql.Clob;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.opl.jns.insurance.service.repository.ReportRepositoryV3;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@Repository
@Slf4j
public class ReportRepositoryImplV3 implements ReportRepositoryV3 {

	@Qualifier("emFR")
    @Autowired
    EntityManager entityManager;

    @Override
    public String getDataFromProducer(String request, Long userId, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}", spName, request, userId);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e);
        }
        return null;
    }
    
	@SuppressWarnings("unchecked")
	public List<Object> fetchListOfDataFromDb(String Query){
		return entityManager.createNativeQuery(Query).getResultList();
	}
	@Override
    public String fetchOptOutApplication(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }
	
    @Override
    public String fetchCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }
}
