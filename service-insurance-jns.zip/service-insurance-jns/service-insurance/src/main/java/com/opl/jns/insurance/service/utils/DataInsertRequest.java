package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import lombok.*;
//
///**
// * @author - Maaz Shaikh
// * @Date - 7/4/2023
// */
//@Setter
//@Getter
//@AllArgsConstructor
//@NoArgsConstructor
//public class DataInsertRequest {
//
//    int schemeId;
//    int counter;
//    int count;
//    Long orgId;
//    Long insurerOrgId;
//
//}
