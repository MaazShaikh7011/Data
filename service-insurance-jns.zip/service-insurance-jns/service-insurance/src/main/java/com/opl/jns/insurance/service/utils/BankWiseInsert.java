package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import com.opl.service.insurance.jns.service.*;
//import lombok.extern.slf4j.*;
//import org.springframework.beans.factory.annotation.*;
//import org.springframework.scheduling.annotation.*;
//import org.springframework.stereotype.*;
//
//import java.util.*;
//
///**
// * @author - Maaz Shaikh
// * @Date - 7/31/2023
// */
//@Component
//@Slf4j
//public class BankWiseInsert {
//
//	private static final Random rnd = new Random();
//
//	@Autowired
//	private DataInsertionService dataInsertionService;
//
//	@Async
//	public void insert(int schemeId, Long orgId, Long insurerOrgId, int maxRow) {
//		for (int j = 0; j < maxRow; j++) {
//			log.info("START --------------->" + orgId + "--------" + j);
//			dataInsertionService.dataInsertion(schemeId, rnd.nextInt(j + 1), orgId, insurerOrgId);
//		}
//	}
//
//	public void start(int maxRow) {
//
//		DataInsertBankEnum[] bankList = DataInsertBankEnum.getAll();
//		for (int i = 0; i < bankList.length; i++) {
//			DataInsertBankEnum bank = bankList[i];
//			insert(bank.getSchemeId(), bank.getOrgId(), bank.getInsurerId(), maxRow);
//		}
//	}
//
//}
