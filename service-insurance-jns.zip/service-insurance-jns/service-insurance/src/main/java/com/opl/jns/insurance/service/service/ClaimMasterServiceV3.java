package com.opl.jns.insurance.service.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.ClaimDeDupeDetailsProxy;
import com.opl.jns.insurance.api.model.ClaimMasterRequest;
import com.opl.jns.insurance.api.model.ClaimRequest;
import com.opl.jns.insurance.api.model.ClaimStatusRequest;
import com.opl.jns.insurance.api.model.UpdateClaimAccountHolderRequest;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.utils.common.CommonResponse;

public interface ClaimMasterServiceV3 {

	public CommonResponse getAccountHoldersList(ClaimRequest claimRequest, AuthClientResponse authClientResponse);

	public ClaimMasterRequest getClaimFromDetails(Long claimId) throws OneFormException, IOException;

	public CommonResponse saveClaimFormDetails(ClaimMasterRequest req);

	String fetchViewClaimDetailsByClaimId(String request, Long userId);

	public ClaimMasterRequest getStage(Long claimId);

	public CommonResponse updateStage(Long claimId, Long userId, String remarks);

	public CommonResponse publishedClaimedData(Long claimId) throws InsuranceException;

	public CommonResponse updateClaimAccountHolder(UpdateClaimAccountHolderRequest holderRequest, AuthClientResponse authClientResponse);
	
	public CommonResponse findAllClaimHistoryByApplicationId(Long applicationId);

	public CommonResponse findAllApprovedClaimDetailsByApplicationId(Long claimId);
	
	public CommonResponse fetchViewClaimDetailsByApplicationId(Long applicationId,Long claimId) throws ParseException;
	
	public CommonResponse updateClaimStatus(ClaimStatusRequest claimStatusRequest, Long userId) throws OneFormException, IOException;

	public void pushRemainingClaim();

	public void updateClaimStatusAndStageHistory(Long claimId);
	
	public CommonResponse getAllClaimDetail(Long applicationId,Long claimId) throws ParseException;

	public CommonResponse webHookClaimDocUpload(Long claimId,List<Long> docs);

	public void expireClaimAfter30Days();

	public CommonResponse saveClaimDeDupeDetails(ClaimDeDupeDetailsProxy claimDeDupeDetails, Long userId);

	public CommonResponse getClaimDeDupeDetails(Long claimId);

    CommonResponse UpdateStageWithRemarks(Long claimId, String remarks, Long userId);

//	public CommonResponse claimDataMigrationNewDb();

}
