package com.opl.jns.insurance.service.schedulers;

import com.opl.jns.config.utils.EnvironmentUtils;
import com.opl.jns.insurance.service.service.ApplicationMasterService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author ravi.thummar Date : 19-07-2023
 */

@Component
@Slf4j
public class OptOutScheduler {

	@Autowired
	private ApplicationMasterService applicationMasterService;

	// Every 10 sec call
	// @Scheduled(cron = "*/10 * * * * *")

	/**
	 * Everyday Year 1st June 12:05 AM call
	 */
	@Scheduled(cron = "${ins.optout.schedular}")
	public void optOutApplicationsOnMidNight() {
		String value = EnvironmentUtils.OPT_OUT_SCHEDULER_ENABLE.getValue();
		if (value != null && "ON".equalsIgnoreCase(value)) {
			log.info("OPT-OUT in-progress application scheduler =====> Start at :[{}]", new Date());
			applicationMasterService.optOut(new Date());
		} else {
			log.info("OPT-OUT SCHEDULE OFF FROM ENVIRONMENT PROPERTY");
		}
	}
}
