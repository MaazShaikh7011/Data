package com.opl.jns.insurance.service.utils;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.insurance.api.model.ErrorStageProxy;
import com.opl.jns.insurance.service.domain.ErrorStageAudit;
import com.opl.jns.insurance.service.repository.ErrorStageAuditRepository;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ErrorStageAuditUtils {

	@Autowired
	private ErrorStageAuditRepository auditRepository;

	@Autowired
	private ConfigProperties properties;

	public boolean update(ErrorStageProxy erroStageProxy) {
		try {
			String value = properties.getValue("ERROR_STAGE_AUDIT_ENABLE");
			if (OPLUtils.isObjectNullOrEmpty(value) || "OFF".equalsIgnoreCase(value)) {
				log.info("ERROR STAGE AUDIT ENABLE OFF");
				return true;
			}
			if (OPLUtils.isObjectNullOrEmpty(erroStageProxy.getApplicationId())) {
				log.info("ApplicationId is null or empty while update error stage aduit ");
				return false;
			}
			ErrorStageAudit audit = new ErrorStageAudit();
			BeanUtils.copyProperties(erroStageProxy, audit);
			audit.setModifiedDate(new Date());
			auditRepository.save(audit);
			return true;
		} catch (Exception e) {
			log.error("Exception while update error stage audit -->", e);
		}
		return false;
	}
}
