package com.opl.jns.insurance.service.service;

import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.insurance.api.model.v2.SearchRequest;
import com.opl.jns.utils.common.CommonResponse;

@Service
public interface CommonService {

	public CommonResponse getbySearchFilter(SearchRequest searchRequest, AuthClientResponse authClientResponse);

	public CommonResponse getBySearchFilterNew(String request, Long userId);
	
	public CommonResponse getBySearchFilterNewForClaim(String request, Long userId);

}
