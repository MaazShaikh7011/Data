package com.opl.jns.insurance.service.service.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.Auditor;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ConsentMaster;
import com.opl.jns.ere.domain.ExpSchedulerAudit;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.ExpiredEnrollment;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.ApplicationType;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.ere.enums.EnrollTypeEnum;
import com.opl.jns.ere.enums.ExpSchedulerApiEnum;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.repo.ApplicantInfoRepository;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.repo.ExpSchedulerAuditRepo;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.ExpiredEnrollmentRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.ere.utils.ConsentMasterProxy;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.OptOutProxy;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.service.service.ApplicationMasterService;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.insurance.service.utils.NotificationUtil;
import com.opl.jns.insurance.service.utils.ResponseStatus;
import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg.Common;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 4/27/2023
 */
@Service
@Slf4j
public class ApplicationMasterServiceImpl implements ApplicationMasterService {

	// v1
	@Autowired
	private ConfigProperties properties;

	// v2
	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private UserManagementClient userManagementClient;

	@Autowired
	private ApplicantInfoRepository applicantInfoRepository;

	@Autowired
	private ClmMasterRepository clmMasterRepo;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;

	@Autowired
	private NotificationUtil notificationUtil;

	@Lazy
	@Autowired
	public EnrollmentService enrollmentService;

	@Autowired
	private UsersClient usersClient;
	
	@Autowired
	public ExpSchedulerAuditRepo expSchedulerAuditRepo;

	@Autowired
	private ExpiredEnrollmentRepository expiredEnrollmentRepository;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	@Autowired
	private PmsbyRepository pmsbyRepository;
	
	@Autowired
	private PmjjbyRepository pmjjbyRepository;
	
	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;
	
	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepoV2;
	
	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 appMstrOtherDtlsRepoV3;
	
	@Autowired
	private ConsentMasterRepository consentMasterRepository;

	public static final Date currentDate = new Date();

//	@Autowired
//	private QueueMessagingTemplate queueMessagingTemplate;

	@Value("${pushApplicationSqsUrl}")
	String pushApplicationSqsUrl;

	@Override
	public CommonResponse create(ApplicationMasterRequest req, AuthClientResponse authClientResponse) throws Exception {
		ApplicationMasterV3 applicationMaster = null;

		/**if customer is started journey without registration*/
		if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId()) && !OPLUtils.isObjectNullOrEmpty(req.getIsRegisterUser()) && req.getIsRegisterUser()==Boolean.TRUE) {
			applicationMaster = applicationMasterRepository.findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdNotNullAndOrgIdOrderByIdDesc(req.getSchemeId().intValue(), req.getAccountNo(),
					CommonUtils.stageThatNotIncludeInApplicationCreation, req.getOrgId());
			if(!OPLUtils.isObjectNullOrEmpty(applicationMaster) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicationMasterOtherDetails()) && !Objects.equals(applicationMaster.getApplicationMasterOtherDetails().getSource(), Source.JANSURAKSHA_DIY.getId())
					&& !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getDob()) && applicationMaster.getApplicantInfo().getDob().compareTo(req.getDob())==0) {
				return new CommonResponse("Application already present in other source", ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}
		}
		/**if customer is started journey with registration*/
		else if(Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
			applicationMaster = applicationMasterRepository.findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdAndOrgIdOrderByIdDesc(req.getSchemeId().intValue(), req.getAccountNo(),
					CommonUtils.stageThatNotIncludeInApplicationCreation, req.getUserId(), req.getOrgId());
		}
		/**if user is branch officer*/
		else if(!Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
			applicationMaster = applicationMasterRepository.findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdOrderByIdDesc(req.getSchemeId().intValue(), req.getAccountNo(), CommonUtils.stageThatNotIncludeInApplicationCreation,
					req.getUserId());
		}
		if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
			applicationMaster = new ApplicationMasterV3();
			applicationMaster.setBranchId(authClientResponse.getUserBranchId());
			applicationMaster.setAccountNumber(req.getAccountNo());
			applicationMaster.setUserId(authClientResponse.getUserId());
			applicationMaster.setStageId(EnrollStageMaster.CREATED.getStageId());
			applicationMaster.setSchemeId(!OPLUtils.isObjectNullOrEmpty(req.getSchemeId()) ? req.getSchemeId().intValue() : null);
			applicationMaster.setDob(req.getDob());
			applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_IN_PROGRESS.getId());
			applicationMaster.setStatusChangeDate(new Date());
			applicationMaster.setOrgId(req.getOrgId());
			applicationMaster.setEnrollType(EnrollTypeEnum.NEW_ENROLLMENT.getId());;
			applicationMaster.setApplicantInfo(getApplicationInfoDetails(applicationMaster, authClientResponse));
			// applicationMaster = masterRepository.save(applicationMaster);
		} else {
			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getStageId()) && applicationMaster.getStageId() < EnrollStageMaster.APPLICATION_FORM.getStageId()) {
				applicationMaster.setStageId(EnrollStageMaster.CREATED.getStageId());
				applicationMaster.setBranchId(authClientResponse.getUserBranchId());
				applicationMaster.setDob(req.getDob());
			}
		}
		try {
			ApplicationMasterOtherDetailsV3 otherDetailsFetch = applicationMaster.getApplicationMasterOtherDetails();
			if (OPLUtils.isObjectNullOrEmpty(otherDetailsFetch)) {
				otherDetailsFetch = new ApplicationMasterOtherDetailsV3();
				otherDetailsFetch.setId(applicationMaster.getId());
				otherDetailsFetch.setAppCreatedDate(applicationMaster.getCreatedDate());
			}

			otherDetailsFetch.setOrgId(applicationMaster.getOrgId());
			otherDetailsFetch.setSchemeId(applicationMaster.getSchemeId());
			if (!Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
				// SET Branch Mapping Details
				Map<String, Object> map = userManagementClient.getBranchMappingIds(authClientResponse.getUserBranchId(), req.getSchemeId());
				if (OPLUtils.isObjectNullOrEmpty(map) && !Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
					return new CommonResponse("Bank branch has not been given access for the " + SchemeMaster.getById(req.getSchemeId()).getShortName() + " scheme.", ResponseStatus.NO_CONTENT.getStatusId(), false);
				}
				if (!OPLUtils.isObjectNullOrEmpty(map)) {
					otherDetailsFetch.setBranchRoId(OPLUtils.isObjectNullOrEmpty(map.get("branchRoId")) ? null : Long.valueOf(map.get("branchRoId").toString()));
					otherDetailsFetch.setBranchZoId(OPLUtils.isObjectNullOrEmpty(map.get("branchZoId")) ? null : Long.valueOf(map.get("branchZoId").toString()));
					otherDetailsFetch.setBranchLhoId(OPLUtils.isObjectNullOrEmpty(map.get("branchLhoId")) ? null : Long.valueOf(map.get("branchLhoId").toString()));
					otherDetailsFetch.setBranchCityId(OPLUtils.isObjectNullOrEmpty(map.get("cityId")) ? null : Long.valueOf(map.get("cityId").toString()));
					otherDetailsFetch.setBranchStateId(OPLUtils.isObjectNullOrEmpty(map.get("stateId")) ? null : Long.valueOf(map.get("stateId").toString()));
					otherDetailsFetch.setBranchCode(OPLUtils.isObjectNullOrEmpty(map.get("branchCode")) ? null : map.get("branchCode").toString());
					otherDetailsFetch.setBranchIFSC(OPLUtils.isObjectNullOrEmpty(map.get("branchIfsc")) ? null : map.get("branchIfsc").toString());
					otherDetailsFetch.setRuralUrbanId(OPLUtils.isObjectNullOrEmpty(map.get("ruralUrbanId")) ? null : Integer.valueOf(map.get("ruralUrbanId").toString()));
				}
			}
			
			/**SET BANK CODE*/
			CommonResponse organizationDetailsByOrgIds = usersClient.getOrganizationById(applicationMaster.getOrgId());
			if (!OPLUtils.isObjectNullOrEmpty(organizationDetailsByOrgIds)
					&& organizationDetailsByOrgIds.getStatus() == HttpStatus.OK.value()) {
				UserOrganisationMasterResponse orgDetails = MultipleJSONObjectHelper.getObjectFromObject(organizationDetailsByOrgIds.getData(),UserOrganisationMasterResponse.class);
				otherDetailsFetch.setBankCode(orgDetails.getOrganisationCode());				
			}
			
			if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
				otherDetailsFetch.setSource(Source.JANSURAKSHA_DIY.getId());
				if (!OPLUtils.isObjectNullOrEmpty(req.getIsCustWeb())) {
					if (req.getIsCustWeb().equals(true)) {
						otherDetailsFetch.setChannel(ChannelIdEnum.CUSTOMER_WEB.getId());
					} else if (req.getIsCustWeb().equals(false)) {
						otherDetailsFetch.setChannel(ChannelIdEnum.CUSTOMER_MOBILE.getId());
					}
				} else {
					otherDetailsFetch.setChannel(ChannelIdEnum.CUSTOMER_MOBILE.getId());
				}
			} else {
				otherDetailsFetch.setChannel(ChannelIdEnum.BRANCH_ASSISTED_JNS.getId());
				otherDetailsFetch.setSource(Source.JANSURAKSHA.getId());
			}

			otherDetailsFetch.setApplicationMaster(applicationMaster);
			applicationMaster.setApplicationMasterOtherDetails(otherDetailsFetch);
		} catch (Exception e) {
			log.error("branch Details not found -->", e);
		}
		applicationMaster = applicationMasterRepository.save(applicationMaster);
		
		ApplicationMasterRequestV2 applicationMasterReq = new ApplicationMasterRequestV2();
		BeanUtils.copyProperties(applicationMaster, applicationMasterReq);

		/**INSERT BO CONSENT MAPPING*/
		if(!Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {			
			insertConsentMapping(authClientResponse.getUserId(),applicationMaster.getId());
		}
		
		return new CommonResponse(CommonUtils.APPLICATION_CREATED, applicationMasterReq, ResponseStatus.SUCCESS.getStatusId(), true);
	}
	
	public void insertConsentMapping(Long userId,Long applicationId) {
		try {			
			ereCommonService.insertDataConsentMappingTable(ConsentMappingProxy.builder().appTypeValue(applicationId).appType(ApplicationType.APPLICATION.getId()).userId(userId).consentTypeId(ConsentType.BO_ENROLLMENT.getId()).build());
		}catch (Exception e) {
			log.info("ERROR WHILE SAVE CONSENT--> {}", userId);
		}
	}

	private ApplicantInfo getApplicationInfoDetails(ApplicationMasterV3 applicationMaster, AuthClientResponse authClientResponse) {
		ApplicantInfo info = new ApplicantInfo();
		AddressMasterV3 applicantAddress = new AddressMasterV3();
		applicationMaster.setCreatedDate(new Date());
		applicationMaster.setCreatedBy(authClientResponse.getUserId());
		applicationMaster.setIsActive(Boolean.TRUE);
		applicantAddress.setAppCreatedDate(applicationMaster.getCreatedDate());
		info.setAddress(applicantAddress);
		info.setCreatedDate(new Date());
		info.setIsActive(Boolean.TRUE);
		info.setCreatedBy(authClientResponse.getUserId());
		info.setAppCreatedDate(applicationMaster.getCreatedDate());
		info.setApplicationMaster(applicationMaster);
		return info;
	}

	public CommonResponse updateStage(ApplicationMasterRequestV2 appMasterReq, AuthClientResponse authClientResponse) throws InsuranceException {
		if(OPLUtils.isObjectNullOrEmpty(appMasterReq.getStageId())) {
			return new CommonResponse("stageId not found", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		ApplicationMasterV3 master = applicationMasterRepository.findByIdAndIsActiveTrue(appMasterReq.getApplicationId());
		if (null == master) {
			return new CommonResponse("Its seems we found invalid application, Kindly refresh page and try again!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

		if (EnrollStageMaster.COMPLETED.getStageId() == master.getStageId()) {
			return new CommonResponse("Its seems this application journey already completed. Kindly refresh page and try again!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

		if (EnrollStageMaster.EXPIRED.getStageId() == master.getStageId()) {
			return new CommonResponse("Its seems this application is expired. Kindly refresh page and create new journey!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

//		id(master.getStageId())

		/* updating History */
		//        updateApplicationHistory(master);

		Integer nextStage = master.getStageId();
		if (master.getStageId() == EnrollStageMaster.CREATED.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.OTP_VERIFICATION.getStageId()) {
			nextStage = EnrollStageMaster.OTP_VERIFICATION.getStageId();
		} else if (master.getStageId() == EnrollStageMaster.OTP_VERIFICATION.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId()) {
			nextStage = EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId();
		} else if (master.getStageId() == EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.APPLICATION_FORM.getStageId()) {
			nextStage = EnrollStageMaster.APPLICATION_FORM.getStageId();
		} else if ((master.getStageId() == EnrollStageMaster.APPLICATION_FORM.getStageId() || master.getStageId() == EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId())
				&& appMasterReq.getStageId() == EnrollStageMaster.PREMIUM_DEDUCTION.getStageId()) {
			nextStage = EnrollStageMaster.PREMIUM_DEDUCTION.getStageId();
		} else if (master.getStageId() == EnrollStageMaster.PREMIUM_DEDUCTION.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.COMPLETED.getStageId()) {
			if (!OPLUtils.isObjectNullOrEmpty(appMasterReq.getStageId()) && appMasterReq.getStageId() == EnrollStageMaster.APPLICATION_FORM.getStageId()) {
				nextStage = EnrollStageMaster.APPLICATION_FORM.getStageId();
			} else {
				nextStage = EnrollStageMaster.COMPLETED.getStageId();
				master.setApplicationStatus(ApplicationStatus.ENROLL_COMPLETED.getId());
				master.setCompletionDate(new Date());
				
				/**INSERT DATA FOR FUTURE STATUS PUSH BANK AND INSURER*/
				ereCommonService.insertApplcationPushStatus(master.getId());
			}
		} else if ((master.getStageId() == EnrollStageMaster.COMPLETED.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.REJECTED.getStageId())
				|| (master.getStageId() == EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.REJECTED.getStageId())
				||  (master.getStageId() == EnrollStageMaster.APPLICATION_FORM.getStageId() && appMasterReq.getStageId() == EnrollStageMaster.REJECTED.getStageId())) {
			nextStage = EnrollStageMaster.REJECTED.getStageId();
			master.setApplicationStatus(ApplicationStatus.ENROLL_REJECTED.getId());
			master.setStatusChangeDate(new Date());
		}
		master.setStageId(nextStage);
		master.setModifiedDate(new Date());
		master.setModifiedBy(!OPLUtils.isObjectNullOrEmpty(authClientResponse) ? authClientResponse.getUserId() : master.getModifiedBy());
		master = applicationMasterRepository.save(master);

//		if ((master.getStageId() == EnrollStageMaster.REJECTED.getStageId())
//				&& (master.getApplicationStatus() == ApplicationStatus.ENROLL_REJECTED.getId())) {
//			CommonResponse response = rejectApplication(master, authClientResponse);
//			return new CommonResponse("successfully rejected application", response, HttpStatus.OK.value(), true);
//		}
		if ((master.getStageId() == EnrollStageMaster.REJECTED.getStageId())
				&& (Objects.equals(master.getApplicationStatus(), ApplicationStatus.ENROLL_REJECTED.getId()))) {
			try {
				Long userId = authClientResponse.getUserId();
				CommonResponse response = ereCommonService.checkPremiumDeductionStatus(master, userId,EnrollStageMaster.REJECTED.getStageId(),ApplicationStatus.ENROLL_REJECTED.getId());
				return new CommonResponse("successfully rejected application", response, HttpStatus.OK.value(), true);
			} catch (Exception e) {
				log.error("Exception while rejected application----------->", e);
			}

		} 

		return new CommonResponse("Successfully updated!!", nextStage, HttpStatus.OK.value(), true);
	}

	@Async
	@Override
	public void sendCoiToApplicant(Long applicationId,ApplicationMasterV3 master) {
		if (OPLUtils.isObjectNullOrEmpty(master)){
			master = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
		}

		try {
			byte[] coiInByte = enrollmentService.getCOI(master, false);

			/** send email and sms in case of coi */
			ContentAttachment contentAttachment = new ContentAttachment();
			contentAttachment.setContentInByte(coiInByte);
			contentAttachment.setFileName("Certificate-of-insurance-" + master.getUrn() + ".pdf");
			List<ContentAttachment> contentList = new ArrayList<ContentAttachment>();
			contentList.add(contentAttachment);

			if(!OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo())) {
				Long smsTmpId = null;
				String schemeName = null;
				if(!OPLUtils.isObjectNullOrEmpty(master.getSchemeId())) {
					 schemeName = SchemeMaster.getById(Long.valueOf(master.getSchemeId())).getShortName();
					if(schemeName.equals("PMSBY")) {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMSBY;
					}else {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMJJBY;
					}
				}

				notificationUtil.sendNotification(
					setEmailParameters(OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(), OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getName()) ? null : master.getApplicantInfo().getName(),
							schemeName,OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getTransAmount()) ? null : master.getLastTransactionDetails().getTransAmount(),
							OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getYear()) ? null : master.getLastTransactionDetails().getYear() + 1,master.getApplicationMasterOtherDetails().getSource(),OPLUtils.isObjectNullOrEmpty(master.getOrgId()) ? null : master.getOrgId()),
					OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getEmail()) ? null : master.getApplicantInfo().getEmail(),
					OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getMobileNumber()) ? null : master.getApplicantInfo().getMobileNumber(), JnsNotificationMasterUtil.EMAIL_CUST_ENROLLMENT_SUCESS,
							smsTmpId, contentList);
			}
		} catch (Exception e) {
			log.error("Exception while send notification or generate COI----------->", e);
		}

	}
	
	@Async
	@Override
	public void sendCoiToApplicantNewDb(ApplicationMasterBothSchemeProxy master,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantDetails,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomneeAddress) {
		try {
			byte[] coiInByte = enrollmentService.getCOINewDb(master, transactionDetailsV2,applicantDetails,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,nomneeAddress,false);

			/** send email and sms in case of coi */
			ContentAttachment contentAttachment = new ContentAttachment();
			contentAttachment.setContentInByte(coiInByte);
			contentAttachment.setFileName("Certificate-of-insurance-" + master.getUrn() + ".pdf");
			List<ContentAttachment> contentList = new ArrayList<ContentAttachment>();
			contentList.add(contentAttachment);

			if(!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2) && !OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
				Long smsTmpId = null;
				String schemeName = null;
				if(!OPLUtils.isObjectNullOrEmpty(master.getSchemeId())) {
					 schemeName = SchemeMaster.getById(master.getSchemeId()).getShortName();
					if(schemeName.equals("PMSBY")) {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMSBY;
					}else {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMJJBY;
					}
				}

				notificationUtil.sendNotification(
					setEmailParameters(OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(), OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getAcHolderName()) ? null : applicantPIDetails.getAcHolderName(),
							schemeName,OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getTransAmount()) ? null : transactionDetailsV2.getTransAmount(),
							OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getYear()) ? null : transactionDetailsV2.getYear() + 1,master.getSource(),OPLUtils.isObjectNullOrEmpty(master.getOrgId()) ? null : master.getOrgId()),
					OPLUtils.isObjectNullOrEmpty(applicantDetails.getEmail()) ? null : applicantDetails.getEmail(),
					OPLUtils.isObjectNullOrEmpty(applicantDetails.getMobileNumber()) ? null : applicantDetails.getMobileNumber(), JnsNotificationMasterUtil.EMAIL_CUST_ENROLLMENT_SUCESS,
							smsTmpId, contentList);
			}
		} catch (Exception e) {
			log.error("Exception while send notification or generate COI----------->", e);
		}

	}

	public Map<String, Object> setEmailParameters(String urn, String insuredName, String schemeName, Double ammount, Integer year, Integer source,Long orgId) {
//		log.info("entry in emailParameters()");
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("insuredName", insuredName);
		emailParameters.put("amountOfPremium", ammount);
		emailParameters.put("nameOfScheme", schemeName);
		emailParameters.put("urn", urn.substring(4));
		emailParameters.put("year", !OPLUtils.isObjectNullOrEmpty(year) ? year.toString() : "");
		emailParameters.put("source", source);
		emailParameters.put("orgId", orgId);
		return emailParameters;

	}

	@Override
	public CommonResponse getStageDetails(Long applicationId) throws InsuranceException {
		ApplicationMasterV3 master = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
		if (null == master) {
			return new CommonResponse("Its seems we found invalid application, Kindly refresh page and try again!!", ResponseStatus.BAD_REQUEST.getStatusId());
		}
		ApplicationMasterRequestV2 request = new ApplicationMasterRequestV2();
		BeanUtils.copyProperties(master, request);
		request.setUrn(master.getUrn());
		return new CommonResponse("Successfully fetched data!!", request, HttpStatus.OK.value(), true);
	}


/*	@Async
	@Override
	public CommonResponse publishedData(Long applicationId) {
		ApplicationMasterV3 master = masterRepository.findByIdAndIsActiveTrue(applicationId);
		if (OPLUtils.isObjectNullOrEmpty(master) || master.getStageId() != EnrollStageMaster.COMPLETED.getStageId()) {
			return new CommonResponse("Its seems this application has been not completed yet", HttpStatus.BAD_REQUEST.value());
		}
		

		try {

			String pythonApiCall = properties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
			boolean isPythonPushed = null != master.getApplicationMasterOtherDetails().getIsddPush() && master.getApplicationMasterOtherDetails().getIsddPush();
			SingleEnrollmentResponse singleEnrollResp = deDupeRegistryUtility.callSingleEnrollmentRequest(applicationId,master,pythonApiCall,isPythonPushed);
			if (!OPLUtils.isObjectNullOrEmpty(singleEnrollResp) && !OPLUtils.isObjectNullOrEmpty(singleEnrollResp.getStatus()) && singleEnrollResp.getStatus() == HttpStatus.OK.value()) {
				otherDetailsRepository.updateIsDDPushFlag(master.getId());
			}
		} catch (Exception e) {
			log.error("Published Data Error -->", e);
		}
		
		
//		if (pythonApiCall.equalsIgnoreCase("true") && !isPythonPushed) {
//			try {
//				//				String url = properties.getValueByCode(OPLUtils.SINGLE_ENROLLMENT_REQUEST);
//				ApplicationMasterRequestV2 masterRequestV2 = enrollmentService.getApplicationAllDetails(master.getId(), master);
//				SingleEnrollmentRequest enrollmentRequest = CommonUtils.getSingleEnrollmentReq(masterRequestV2);
//				//				CommonResponse commonResponse = CommonUtils.callSingleEnrollmentRequest(enrollmentRequest, url);
//				com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callSingleEnrollmentRequest(enrollmentRequest);
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus()) && Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
//					if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
//						SingleEnrollmentResponse singleEnrollResp = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), SingleEnrollmentResponse.class);
//						if (!OPLUtils.isObjectNullOrEmpty(singleEnrollResp) && !OPLUtils.isObjectNullOrEmpty(singleEnrollResp.getStatus()) && singleEnrollResp.getStatus() == HttpStatus.OK.value()) {
//							master.getApplicationMasterOtherDetails().setIsddPush(Boolean.TRUE);
//							masterRepository.save(master);
//						}
//					}
//				}
//			} catch (Exception e) {
//				log.error("Published Data Error -->", e);
//			}
//		}

		

		String url = properties.getValueByCode("PUSH_PULL_ENROLL_API_URL").concat(applicationId.toString());
		Boolean isSuccess = Boolean.FALSE;
		String message = null;
		Date curruntDate = new Date();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
			headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
			headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published Data For -->" + applicationId + "==========API URL ----------->" + url);
			CommonResponse commonResponse = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus() == HttpStatus.OK.value() && !OPLUtils.isObjectNullOrEmpty(commonResponse.getFlag()) && commonResponse.getFlag()) {
				isSuccess = Boolean.TRUE;
				masterRepository.updatePublishFlagAndModified(curruntDate, master.getId());
			} else {
				message = OPLUtils.isObjectNullOrEmpty(commonResponse) ? null : commonResponse.getMessage();
			}
		} catch (Exception e) {
			log.error("Exception While calling Public API :: ", e);
			message = "Not Able to call Service because of : ".concat(e.getLocalizedMessage());
		}

		PushReTryAudit pushReTryAudit = pushReTryAuditRepo.findFirstByTypeAndIsPushedFalseAndApplicationId(CommonUtils.PUSH_RE_TRY_APPLICATION, master.getId());
		if (isSuccess) {
			if (!OPLUtils.isObjectNullOrEmpty(pushReTryAudit)) {
				pushReTryAudit.setIsPushed(Boolean.TRUE);
				pushReTryAudit.setModifiedDate(curruntDate);
				pushReTryAuditRepo.save(pushReTryAudit);
			}
			return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
		} else { add details in retry table
			if (OPLUtils.isObjectNullOrEmpty(pushReTryAudit)) {
				pushReTryAudit = new PushReTryAudit();
			}
			pushReTryAudit.setApplicationId(master.getId());
			pushReTryAudit.setReTryCount(OPLUtils.isObjectNullOrEmpty(pushReTryAudit.getReTryCount()) ? CommonUtils.INT_0 : (pushReTryAudit.getReTryCount() + CommonUtils.INT_1));
			pushReTryAudit.setCreatedDate(curruntDate);
			pushReTryAudit.setType(CommonUtils.PUSH_RE_TRY_APPLICATION);
			pushReTryAudit.setIsPushed(Boolean.FALSE);
			pushReTryAudit.setMessage(message);
			pushReTryAuditRepo.save(pushReTryAudit);
		}

		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}*/

	@Override
	public CommonResponse getOptOutAccountHolderList(ApplicationMasterRequest appMstReq, AuthClientResponse authResp) {
		try {
			List<ApplicationMasterV3> applicationMasterList = null;
			List<ApplicationMasterBothSchemeProxy> appListNewList = null;
			ApplicationMasterV3 appMaster = null;
			ApplicationMasterBothSchemeProxy appMasterNewDB = null;
			
			String filter = appMstReq.getAccountNo();
			Long schemeId = appMstReq.getSchemeId();
			Map<String, Object> map = new HashMap<>();
			if (filter.contains("-")) {	

				// For Urn Only 
				appMaster = applicationMasterRepository.findFirstByOrgIdAndSchemeIdAndStageIdAndUrnAndIsActiveTrue(authResp.getUserOrgId(), appMstReq.getSchemeId().intValue(), EnrollStageMaster.COMPLETED.getStageId(), filter);
				String[] urn = filter.split("-");
				Long applicationId = Long.valueOf(urn[4]);
				
				if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
					Integer completedStatus = ApplicationStatus.ENROLL_COMPLETED.getId();
					if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
						PMSBY pmsby = pmsbyRepository.findByIdAndIsActiveTrue(applicationId);
						if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
							appMasterNewDB = MultipleJSONObjectHelper.getObjectFromObject(pmsby, ApplicationMasterBothSchemeProxy.class);
						}
					} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId()))  {
						PMJJBY pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(applicationId);
						if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
							appMasterNewDB = MultipleJSONObjectHelper.getObjectFromObject(pmjjby, ApplicationMasterBothSchemeProxy.class);
						}
					}
					if(OPLUtils.isObjectNullOrEmpty(appMasterNewDB) || (!Objects.equals(appMstReq.getOrgId(),appMasterNewDB.getOrgId())) && (!Objects.equals(completedStatus,appMasterNewDB.getStatus()))){
						log.info("data not found Application Code => {}", appMstReq.getAccountNo());
						return new CommonResponse("No Enrollment details found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
					}
					if(OPLUtils.isObjectNullOrEmpty(appMasterNewDB))  {
						log.info("data not found Application Code => {}", appMstReq.getAccountNo());
						return new CommonResponse("No Enrollment details found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
					}
				}
				if(!OPLUtils.isObjectNullOrEmpty(appMaster)) {
					applicationMasterList = new ArrayList<>(1);
					applicationMasterList.add(appMaster);
				}else {
					appListNewList = new ArrayList<>(1);
					appListNewList.add(appMasterNewDB);
				}

			} else {
				applicationMasterList = applicationMasterRepository
						.findFirstByOrgIdAndSchemeIdAndStageIdAndIsActiveTrueAndAccountNumber(authResp.getUserOrgId(),
								appMstReq.getSchemeId().intValue(), EnrollStageMaster.COMPLETED.getStageId(), filter);

				appListNewList = new ArrayList<>(1);
				if (OPLUtils.isListNullOrEmpty(applicationMasterList)) {
					appListNewList = new ArrayList<>();
					ApplicationMasterBothSchemeProxy proxy = null;
					if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
						List<PMSBY> pmsbyList = pmsbyRepository.findByOrgIdAndStatusAndIsActiveTrueAndAccountNumber(
								appMstReq.getOrgId(), ApplicationStatus.ENROLL_COMPLETED.getId(), filter);
						if (!OPLUtils.isListNullOrEmpty(pmsbyList)) {
							for (PMSBY pmsby : pmsbyList) {
								proxy = new ApplicationMasterBothSchemeProxy();
								proxy.setStatus(pmsby.getStatus());
								proxy.setUrn(pmsby.getUrn());
								proxy.setId(pmsby.getId());
								appListNewList.add(proxy);
							}
						}
					} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId())) {
						List<PMJJBY> pmjjbyList = pmjjbyRepository.findByOrgIdAndStatusAndIsActiveTrueAndAccountNumber(
								appMstReq.getOrgId(), ApplicationStatus.ENROLL_COMPLETED.getId(), filter);
						if (!OPLUtils.isListNullOrEmpty(pmjjbyList)) {
							for (PMJJBY pmjjby : pmjjbyList) {
								proxy = new ApplicationMasterBothSchemeProxy();
								proxy.setStatus(pmjjby.getStatus());
								proxy.setUrn(pmjjby.getUrn());
								proxy.setId(pmjjby.getId());
								appListNewList.add(proxy);
							}
						}
					}
				}
			}

			if (appMstReq.getType() == CommonUtils.INT_1) {
				List<Long> applicatioIdList = null;
				// check Application is already optout or not
				if (!OPLUtils.isListNullOrEmpty(applicationMasterList)) {
					applicatioIdList = applicationMasterList.stream()
							.filter(x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.OPT_OUT.getId()) || Objects.equals(x.getApplicationStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())))).map(y -> y.getId())
							.collect(Collectors.toList());
				}else {
					applicatioIdList = appListNewList.stream()
							.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId()) || Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())))).map(y -> y.getId())
							.collect(Collectors.toList());
				}
				
				if (!OPLUtils.isListNullOrEmpty(applicatioIdList) && !applicatioIdList.isEmpty() && applicationMasterList.size() == applicatioIdList.size()) {
					return new CommonResponse("this application is Already OptOut Or In-Process", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
				}
			}
			
			List<Long> applicationIds = null;
			if (!OPLUtils.isListNullOrEmpty(applicationMasterList)) {
				 List<Map<String, Object>> mapList = new ArrayList<>(applicationMasterList.size());
				 for (ApplicationMasterV3 appMst : applicationMasterList) {
					 map = new HashMap<>();
					 map.put("name", appMst.getApplicantInfo().getName());
					 map.put("cif", appMst.getCif());
					 map.put("accountNumber", appMst.getAccountNumber());
					 map.put("urn", appMst.getUrn());
					 map.put("id", appMst.getId());
					 mapList.add(map);
				}
				 return new CommonResponse("successfully get List", mapList, HttpStatus.OK.value(), Boolean.TRUE);
			}else {
				applicationIds = appListNewList.stream().map(Auditor::getId).collect(Collectors.toList());
				List<ApplicantPIDetails> applicantInfoListV2 =applicantPIDetailsRepository.findAllById(applicationIds);
				if (OPLUtils.isListNullOrEmpty(applicantInfoListV2)) {
					log.info("data not fount from ApplicantInfo ApplicationIds => {}", applicationIds);
					return new CommonResponse("Data not found from applicant Info", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				}
				List<Map<String, Object>> mapList = new ArrayList<>(applicantInfoListV2.size());
				for (ApplicantPIDetails x : applicantInfoListV2) {
					map = new HashMap<>();
					map.put("name", x.getAcHolderName());
					map.put("cif", x.getCif());
					map.put("accountNumber", x.getAccountNumber());
					map.put("id", x.getId());

					for (ApplicationMasterBothSchemeProxy proxy : appListNewList) {
						if (proxy.getId().equals(x.getId())) {
							map.put("urn", proxy.getUrn());
							break;
						}
					}
					mapList.add(map);
				}
				return new CommonResponse("successfully get List", mapList, HttpStatus.OK.value(), Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting while call getAccountHolderListOptOut", e);
			return new CommonResponse("Exception is getting while getAccountHolderListOptOut", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public CommonResponse getAccountHolderDetailsOptOut(ApplicationMasterRequest applicationMasterRequest, AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findFirstByIsActiveTrueAndAccountNumberAndCifAndSchemeIdAndStageId(applicationMasterRequest.getAccountNo(), applicationMasterRequest.getCif(),
					applicationMasterRequest.getSchemeId().intValue(), EnrollStageMaster.COMPLETED.getStageId());
			
			ApplicationMasterBothSchemeProxy appMasterNew =  new ApplicationMasterBothSchemeProxy();
			Long applicationId = null;
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				 appMasterNew = ereCommonService.getJnsMasterDataApplicationMaster(applicationMasterRequest.getSchemeId().longValue(), applicationMasterRequest.getApplicationId());
					if (OPLUtils.isObjectNullOrEmpty(appMasterNew)) {
					 log.info("data not fount from ApplicationMaster account => {}, cifNo {}", applicationMasterRequest.getAccountNo(), applicationMasterRequest.getCif());
					 return new CommonResponse("application not Found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				}else {
					applicationId = appMasterNew.getId();
				}
			}else {
				applicationId = applicationMaster.getId();
			}

			if (applicationMasterRequest.getType() == CommonUtils.INT_1) {
				if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
					// check Application is already optout or not
					if (Objects.equals(applicationMaster.getApplicationStatus(), ApplicationStatus.OPT_OUT.getId())) {
							return new CommonResponse("this application is Already OptOut", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
					}
				}else {
					if (Objects.equals(appMasterNew.getStatus(), ApplicationStatus.OPT_OUT.getId())) {
						return new CommonResponse("this application is Already OptOut", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
					}
				}

			} else if (applicationMasterRequest.getType() == CommonUtils.INT_2) {
				if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
					MiscellaneousAudit audit = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationMaster.getId(), MiscellaneousType.OPT_OUT.getId());
					if (!OPLUtils.isObjectNullOrEmpty(audit) && audit.getDateOfEffective().before(new Date())) {
						return new CommonResponse("this application is Already OptOut", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
					}
				}else {
						MiscellaneousAudit audit = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(appMasterNew.getId(), MiscellaneousType.OPT_OUT.getId());
						if (!OPLUtils.isObjectNullOrEmpty(audit) && audit.getDateOfEffective().before(new Date())) {
							return new CommonResponse("this application is Already OptOut", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
						}
				}
			}
//			if (applicationMasterRequest.getType() == CommonUtils.INT_2) {
				/** claim stage in process */
//				List<ClaimMasterV3> claimStageInProgress = claimMasterRepoV3
//						.findByClaimStageIdInAndIsActiveTrueAndApplicationMasterIdOrderByIdDesc(Arrays.asList(ClaimStageMaster.CLAIM_FORM.getStageId(), ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()), applicationMaster.getId());
			
				List<ClmMaster> claimStageInProgress = clmMasterRepo
						.findByStageIdInAndIsActiveTrueAndApplicationIdOrderByIdDesc(Arrays.asList(ClaimStageMaster.CLAIM_FORM.getStageId(),ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()), applicationId);
		
				if (!OPLUtils.isListNullOrEmpty(claimStageInProgress)) {
					return new CommonResponse("Claim Inpocess", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				}

				/** claim status in process */
//				List<ClaimMasterV3> claimStatusInProgress = claimMasterRepoV3.findByApplicationMasterIdAndIsActiveTrueAndClaimStatusInOrderByIdDesc(applicationMaster.getId(),
//						Arrays.asList(ClaimStatus.CLAIM_SEND_TO_INSURER.getId(), ClaimStatus.CLAIM_IN_PROGRESS.getId(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()));
				List<ClmMaster> claimStatusInProgress = clmMasterRepo.findByApplicationIdAndIsActiveTrueAndStatusInOrderByIdDesc(applicationId,
						Arrays.asList(ClaimStatus.CLAIM_SEND_TO_INSURER.getId(), ClaimStatus.CLAIM_IN_PROGRESS.getId(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()));
				if (!OPLUtils.isListNullOrEmpty(claimStatusInProgress)) {
					return new CommonResponse("Claim Inpocess", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				}
//			}
			Map<String, Object> map = new HashMap<>();
			if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				map.put("urn", applicationMaster.getUrn());
				ApplicantInfo applicantInfo = applicantInfoRepository.findByApplicationMasterId(applicationMaster.getId());
				if (OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
					log.info("data not fount from ApplicantInfo applicationId -> {}", applicationMaster.getId());
					return new CommonResponse("application not Found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
				}
				map.put("name", applicantInfo.getName());
				map.put("applicationId", applicationMaster.getId());
				map.put("enrollDate", applicationMaster.getEnrollmentDate());
				map.put("accountNumber", applicationMaster.getAccountNumber());
				map.put("dateOfRequest", new Date());
			}else {
				map.put("urn", appMasterNew.getUrn());
				map.put("name", applicationMasterRequest.getAccountHolderName());
				map.put("applicationId", appMasterNew.getId());
				map.put("enrollDate", appMasterNew.getEnrollmentDate());
				map.put("accountNumber", applicationMasterRequest.getAccountNo());
				map.put("dateOfRequest", new Date());
			}

			return new CommonResponse("successfully get List", map, HttpStatus.OK.value(), Boolean.TRUE);

		} catch (Exception e) {
			log.error("Exception is getting while call getAccountHolderListOptOut", e);
			return new CommonResponse("Exception is getting while getAccountHolderListOptOut", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public CommonResponse saveOptOut(OptOutProxy optOutProxy, AuthClientResponse authClientResponse) {
		try {
//			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(optOutProxy.getApplicationId());
			
			ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(optOutProxy.getSchemeId(), optOutProxy.getApplicationId());
			
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				return new CommonResponse("No Data Found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
			}
//			else if (Objects.equals(applicationMaster.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())) {
//				return new CommonResponse("this application is Already In Process", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
//			} else if (Objects.equals(applicationMaster.getStatus(), ApplicationStatus.OPT_OUT.getId())) {
//				return new CommonResponse("this application is Already OptOut", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
//			}
			
			MiscellaneousAudit msAdt = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationMaster.getId(), MiscellaneousType.OPT_OUT.getId());
			if(!OPLUtils.isObjectNullOrEmpty(msAdt)) {
				return new CommonResponse("Applicant has already Opted out of the "+ SchemeMaster.getById(optOutProxy.getSchemeId()).getShortName() + " Scheme", HttpStatus.ALREADY_REPORTED.value(), Boolean.FALSE);
			}
			
			ApplicantInfoV2 applicantInfoV2 = applicantInfoRepoV2.findById(applicationMaster.getId()).orElse(null);
			ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationMaster.getId()).orElse(null);
			if(OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
				applicantPIDetails = new ApplicantPIDetails();
				applicantPIDetails.setId(applicantInfoV2.getId());
				applicantPIDetails.setEnrollmentDate(new Date());
				applicantPIDetails.setCif(optOutProxy.getCif());
				applicantPIDetails.setAccountNumber(optOutProxy.getAccountNumber());
				applicantPIDetails.setAcHolderName(optOutProxy.getName());
				applicantPIDetailsRepository.save(applicantPIDetails);
			}
			
			//			applicationMaster.setApplicationStatus(ApplicationStatus.OPT_OUT_IN_PROCESS.getId());
			//			applicationMaster.setStatusChangeDate(new Date());
			//			applicationMaster.setModifiedDate(new Date());
			//			applicationMaster.setModifiedBy(authClientResponse.getUserId());
			//			masterRepository.save(applicationMaster);
//			applicationMasterRepository.updateOptOutStatus(ApplicationStatus.OPT_OUT_IN_PROCESS.getId(), applicationMaster.getId(), new Date());
			MiscellaneousAudit miscellaneousAudit = new MiscellaneousAudit().toBuilder().applicationId(optOutProxy.getApplicationId()).urn(optOutProxy.getUrn()).name(optOutProxy.getName()).type(MiscellaneousType.OPT_OUT.getId())
					.policyEffectiveDate(optOutProxy.getPolicyEffectiveDate()).accountNumber(optOutProxy.getAccountNumber()).dateOfRequest(optOutProxy.getDateOfRequest()).dateOfEffective(optOutProxy.getDateOfEffective())
					.createdBy(authClientResponse.getUserId()).createdDate(new Date()).modifiedBy(authClientResponse.getUserId()).modifiedDate(new Date()).isActive(Boolean.TRUE).build();
			miscellaneousAuditRepository.save(miscellaneousAudit);

			/* send email after save optout */
			notificationUtil.sendNotification(
					setsaveOptOutEmailParameters(OPLUtils.isObjectNullOrEmpty(optOutProxy.getUrn()) ? null : optOutProxy.getUrn(), OPLUtils.isObjectNullOrEmpty(optOutProxy.getName()) ? null : optOutProxy.getName(),
							OPLUtils.isObjectNullOrEmpty(optOutProxy.getSchemeId()) ? null : SchemeMaster.getById(optOutProxy.getSchemeId()).getShortName(),
							OPLUtils.isObjectNullOrEmpty(optOutProxy.getDateOfRequest()) ? null : optOutProxy.getDateOfRequest(), OPLUtils.isObjectNullOrEmpty(optOutProxy.getDateOfEffective()) ? null : optOutProxy.getDateOfEffective(),appMstrOtherDtlsRepoV3.getSouceByApplicationId(applicationMaster.getId()),
									OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())?null:applicationMaster.getOrgId()),
					OPLUtils.isObjectNullOrEmpty(applicantInfoV2.getEmail()) ? null : applicantInfoV2.getEmail(),
					OPLUtils.isObjectNullOrEmpty(applicantInfoV2.getMobileNumber()) ? null : applicantInfoV2.getMobileNumber(), JnsNotificationMasterUtil.EMAIL_CUST_OPT_OUT_SUCCESS, null, null);

			/** CALL WEBHOOK FOR BANK AND INSURER OPT OUT UPDATE STATUS */
			if (PhaseMode.checkPhase2(applicationMaster.getOrgId())) {
	            /**AFTER PUSH JNS MASTER OPT OUT FLAG SET FALSE*/
				ereCommonService.setOptOutPushFlagFalse(applicationMaster.getId());
	        	
				try {
					callWebhookForPushOptOutUpdateStatusBankAndInsurer(optOutProxy, applicationMaster, authClientResponse,applicantPIDetails.getCif());
				} catch (Exception e) {
					log.error("Exception is getting While webhook opt out update status ", e);
				}
			}
			
			return new CommonResponse("Request Submitted successfully", Boolean.TRUE, HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting while getting saveOptOut", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}
	
	public void callWebhookForPushOptOutUpdateStatusBankAndInsurer(OptOutProxy optOutProxy,ApplicationMasterBothSchemeProxy applicationMaster,AuthClientResponse authClientResponse,String cif) {
		
		/** PREPARE OPT OUT UPDATE STATUS REQUEST */
		OptOutUpdateStatusRequest updateStatusReq = prepareOptOutUpdateStatusRequest(optOutProxy,applicationMaster,cif);
		
		/**BANK WEBHOOK CALL FOR OPT OUT UPDATE STATUS*/
		if(OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource())) {			
			enrollmentService.optOutUpdateStatus(updateStatusReq, authClientResponse);
		}
		
		/**INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS*/
		updateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
		updateStatusReq.setIsInsurer(true);
		enrollmentService.optOutUpdateStatus(updateStatusReq, authClientResponse);
	}
	
	public OptOutUpdateStatusRequest prepareOptOutUpdateStatusRequest(OptOutProxy optOutProxy,ApplicationMasterBothSchemeProxy applicationMaster,String cif) {
		OptOutUpdateStatusRequest updateStatusReq=new OptOutUpdateStatusRequest();
		updateStatusReq.setAccountNumber(optOutProxy.getAccountNumber());
		updateStatusReq.setCif(cif);
		updateStatusReq.setEffectiveDate(!OPLUtils.isObjectNullOrEmpty(optOutProxy.getDateOfEffective()) ? optOutProxy.getDateOfEffective().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null);
		updateStatusReq.setUrn(optOutProxy.getUrn());
		updateStatusReq.setApplicationId(applicationMaster.getId());
		updateStatusReq.setOrgId(applicationMaster.getOrgId());
		updateStatusReq.setRequestDate(!OPLUtils.isObjectNullOrEmpty(optOutProxy.getDateOfRequest()) ? optOutProxy.getDateOfRequest().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null);
		return updateStatusReq;
	}

	public Map<String, Object> setsaveOptOutEmailParameters(String urn, String insuredName, String schemeName, Date dateOfRequest, Date dateOfEffect, Integer source,Long orgId) {
//		log.info("entry in emailParameters()");
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("insuredName", insuredName);
		emailParameters.put("nameOfScheme", schemeName);
		emailParameters.put("urn", urn);
		emailParameters.put("dateOfRequest", DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, dateOfRequest));
		emailParameters.put("dateOfEffect", DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, dateOfEffect));
		emailParameters.put("source", source);
		emailParameters.put("orgId", orgId);
		return emailParameters;
	}

	@Override
	public CommonResponse optOut(Date date) {
		try {
			//			List<Long> applicationIdList = miscellaneousAuditRepository.findApplicationIdByDateOfEffectiveAndType(DateUtils.setMidNightDate(date), MiscellaneousType.OPT_OUT.getId());
//			String formatDate = CommonUtils.sdf.format(date);
			//			List<Long> applicationIdList = miscellaneousAuditRepository.findApplicationIdByDateOfEffectiveAndType(formatDate, MiscellaneousType.OPT_OUT.getId());

			/*String pythonApiCall = properties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);

			if (pythonApiCall.equalsIgnoreCase("true")) {
				List<ApplicationMasterV3> applicationList = miscellaneousAuditRepository.findApplicationIdByDateOfEffectiveAndTypeFromAppMaster(formatDate, MiscellaneousType.OPT_OUT.getId());
				if (!OPLUtils.isListNullOrEmpty(applicationList)) {
					applicationList.forEach(applicationMaster -> {

						/*try {

							UpdateEnrollResponse updateEnrollResponse = deDupeRegistryUtility.callUpdateEnrollmentStatus(applicationMaster.getId(), pythonApiCall, applicationMaster, ApplicationStatus.OPT_OUT);

							if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse) && updateEnrollResponse.getStatus().equals(HttpStatus.OK.value()))
								otherDetailsRepository.updateIsDDStatusPushFlag(applicationMaster.getId());

						} catch (Exception e) {
							log.error("update update enrollment Status Error -->", e);
						}

						masterRepository.updateOptOutStatus(ApplicationStatus.OPT_OUT.getId(), applicationMaster.getId(), new Date());
					});
					log.info("{}  optOut Application", applicationList.size());
					return new CommonResponse("Successfully optOut", (applicationList.size() + " optOut Application"), HttpStatus.OK.value(), Boolean.TRUE);

				}
			} else {*/
			

			/**FETCH APPLICATION MASTER OPT OUT PMSBY APPLICATION*/
			List<Long> pmsbyAppIdLst = miscellaneousAuditRepository.findApplicationIdsByTypeAndIsActiveTruePmsby(MiscellaneousType.OPT_OUT.getId(),ApplicationStatus.OPT_OUT.getId());
			log.info("JNS_MASTER.PMSBY TOTAL APPLICATION SIZE ---> " + pmsbyAppIdLst.size());
			
			/**DEFINE LIMIT LIST SIZE*/
			int limitedSize = 1000;

			/**PROCESS OF PMSBY APPLICATIONS*/
			for (int i = 0; i < pmsbyAppIdLst.size(); i += limitedSize) {
				/**GET 1000 APPLICATIONS*/
				List<Long> pmsbyOneThousandAppId = pmsbyAppIdLst.subList(i, Math.min(i + limitedSize, pmsbyAppIdLst.size()));
				log.info("PICK JNS_MASTER.PMSBY 1000 APPLICATIONS SIZE ---> " + pmsbyOneThousandAppId.size());

				/**PROCESS OF 1000 APPLICATIONS UPDATE OPT OUT STATUS JNS_MASTER.PMSBY*/
				if(!OPLUtils.isListNullOrEmpty(pmsbyOneThousandAppId)) {
					log.info("UPDATE JNS_MASTER.PMSBY 1000 APPLICATIONS SIZE ---> " + pmsbyOneThousandAppId.size());
					pmsbyRepository.updateOptOutStatusByIds(ApplicationStatus.OPT_OUT.getId(), pmsbyOneThousandAppId, new Date());
				}
			}
				
				
			/**FETCH APPLICATION MASTER OPT OUT PMJJBY APPLICATION*/
			List<Long> pmjjbyAppIdLst = miscellaneousAuditRepository.findApplicationIdsByTypeAndIsActiveTruePmjjby(MiscellaneousType.OPT_OUT.getId(),ApplicationStatus.OPT_OUT.getId());
			log.info("JNS_MASTER.PMJJBY TOTAL APPLICATION SIZE ---> " + pmjjbyAppIdLst.size());
			
			/**PROCESS OF PMJJBY APPLICATIONS*/
			for (int i = 0; i < pmjjbyAppIdLst.size(); i += limitedSize) {
				/**GET 1000 APPLICATIONS*/
				List<Long> pmjjbyOneThousandAppId = pmjjbyAppIdLst.subList(i, Math.min(i + limitedSize, pmjjbyAppIdLst.size()));
				log.info("PICK JNS_MASTER.PMJJBY 1000 APPLICATIONS SIZE ---> " + pmjjbyOneThousandAppId.size());
				
				/**PROCESS OF 1000 APPLICATIONS UPDATE OPT OUT STATUS JNS_MASTER.PMJJBY*/
				if(!OPLUtils.isListNullOrEmpty(pmjjbyOneThousandAppId)) {
					log.info("UPDATE JNS_MASTER.PMJJBY 1000 APPLICATIONS SIZE ---> " + pmjjbyOneThousandAppId.size());
					pmjjbyRepository.updateOptOutStatusByIds(ApplicationStatus.OPT_OUT.getId(), pmjjbyOneThousandAppId, new Date());
				}
			}
				
			List<Long> allAppId = new ArrayList<>();
			allAppId.addAll(pmsbyAppIdLst);
			allAppId.addAll(pmjjbyAppIdLst);
			log.info("JNS_MASTER ALL TOTAL APPLICATION SIZE ---> " + allAppId.size());
			
			/**PROCESS OF ALL APPLICATIONS*/
			for (int i = 0; i < allAppId.size(); i += limitedSize) {
				/**GET 1000 APPLICATIONS*/
				List<Long> bothSchemeOneThousandAppId = allAppId.subList(i, Math.min(i + limitedSize, allAppId.size()));
				log.info("PICK JNS_MASTER ALL 1000 APPLICATIONS SIZE ---> " + bothSchemeOneThousandAppId.size());

				/**PROCESS OF 1000 APPLICATIONS UPDATE OPT OUT STATUS APPLICATION MASTER*/
				if(!OPLUtils.isListNullOrEmpty(bothSchemeOneThousandAppId)) {	
					log.info("UPDATE JNS_INSURANCE.APPLICATION_MASTER 1000 APPLICATIONS SIZE ---> " + bothSchemeOneThousandAppId.size());
					applicationMasterRepository.updateOptOutStatusByIds(ApplicationStatus.OPT_OUT.getId(), bothSchemeOneThousandAppId, new Date());
				}
			}
			log.info("UPDATED JNS_MASTER.PMSBY APPLICATION SIZE ---> " + pmsbyAppIdLst.size());
			log.info("UPDATED JNS_MASTER.PMJJBY APPLICATION SIZE ---> " + pmjjbyAppIdLst.size());
			log.info("UPDATED JNS_INSURANCE.APPLICATION_MASTER APPLICATION SIZE ---> " + allAppId.size());
			log.info("END OPT OUT SCHEDULER ---> ");
			//}

			return new CommonResponse(HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is gettting while optOut", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}
	//    @Override
	//    public void updateApplicationHistory(ApplicationMasterV3 master){
	//        ApplicationMasterHistory history = new ApplicationMasterHistory(master.getId(),master.getUrn(),master.getStageId(),master.getApplicationStatus());
	//        history.setCreatedDate(new Date());
	//        history.setId(sequenceService.generateSequence(ApplicationMasterHistory.SEQUENCE_NAME));
	//        if(!OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails())) {
	//            history.setTransactionUtr(master.getLastTransactionDetails().getTransactionUtr());
	//            history.setAmountOfTransaction(master.getLastTransactionDetails().getTransactionAmount());
	//            history.setDateOfTransaction(master.getLastTransactionDetails().getCreatedDate());
	//        }
	//        historyRepo.save(history);
	//    }
	//

	/*
	 * @Async
	 *
	 * @Override public void UploadStaticData(String req) throws InsuranceException{ Date curruntDate =
	 * new Date(); try { ApplicationMasterV3 applicationMaster =
	 * MultipleJSONObjectHelper.getObjectFromString(req, ApplicationMasterV3.class);
	 * applicationMaster.setEnrollDate(curruntDate);
	 * applicationMaster.setId(sequenceService.generateSequence(ApplicationMaster. SEQUENCE_NAME));
	 * applicationMaster.setStageId(EnrollStageMaster.COMPLETED.getStageId());
	 * applicationMaster.setApplicationStatus(ApplicationStatus.ENROLL_COMPLETED. getId());
	 * applicationMaster.setCreatedDate(curruntDate); applicationMaster.setModifiedDate(curruntDate);
	 * applicationMaster.setIsActive(Boolean.TRUE); applicationMaster.setIsPushed(Boolean.TRUE);
	 *
	 * applicationMaster.getLastTransactionDetails().setId(sequenceService.
	 * generateSequence(TransactionDetails.SEQUENCE_NAME));
	 * applicationMaster.getLastTransactionDetails().setTransactionTimestamp(
	 * CommonUtils.formatDate__sdf_yyyy_mm_dd__HH_mm(curruntDate));
	 * applicationMaster.setLastTransactionDetails(transactionDetailsRepo.save(
	 * applicationMaster.getLastTransactionDetails()));
	 * applicationMaster.setUrn(applicationMaster.getUrn().concat("-").concat(
	 * applicationMaster.getId().toString()));
	 * applicationMaster.getCustomerDetails().setName(applicationMaster.
	 * getCustomerDetails().getName().concat(applicationMaster.getId().toString()));
	 *
	 * NomineeMaster mst = new NomineeMaster();
	 * mst.setId(sequenceService.generateSequence(NomineeMaster.SEQUENCE_NAME));
	 * mst.setIsOtherClaimant(Boolean.FALSE); mst.setCreatedDate(curruntDate);
	 * mst.setApplicationMaster(applicationMaster); mst.setApplicationId(applicationMaster.getId());
	 * mst.setFirstName(CommonUtils.BULK); mst.setLastName(CommonUtils.TEST);
	 *
	 * nomineeMasterRepo.save(mst); ArrayList<NomineeMaster> nomineeMasters = new ArrayList<>();
	 * nomineeMasters.add(mst); applicationMaster.setNomineeMasters(nomineeMasters);
	 * masterRepository.save(applicationMaster); } catch (Exception e) { throw new RuntimeException(e);
	 * } }
	 */

//	public void pushApplicationHasError(int page, int count) {
//		Page<Long> appList = masterRepository.findAllByIsPushedNull(PageRequest.of(page, count));
//		if (!appList.isEmpty()) {
//			log.info("found the application which has not push [{}]", appList.getContent().size());
//			for (Long applicationId : appList) {
//				ApplicationMasterV3 master = masterRepository.findByIdAndIsActiveTrue(applicationId);
//
//				/* SEND EMAIL HERE */
//				sendCoiToApplicant(applicationId,master);
//
//				/* Push application to publish service */
//				pushApplication(applicationId);
//
//				/* Push Application to registry */
//				pushSingleEnrollmentToRegistry(applicationId,master);
//
//			}
//		} else {
//			log.info("No application pending for pushing");
//		}
//	}


	/* PUSHING FOR PYTHON */
	/*public void pushSingleEnrollmentToRegistry(Long applicationId, ApplicationMasterV3 master) {
		if (OPLUtils.isObjectNullOrEmpty(master) || master.getStageId() != EnrollStageMaster.COMPLETED.getStageId()) {
			return;
		}
		try {

			String pythonApiCall = properties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
			boolean isPythonPushed = null != master.getApplicationMasterOtherDetails().getIsddPush() && master.getApplicationMasterOtherDetails().getIsddPush();
			SingleEnrollmentResponse singleEnrollResp = deDupeRegistryUtility.callSingleEnrollmentRequest(applicationId, master, pythonApiCall, isPythonPushed);
			if (!OPLUtils.isObjectNullOrEmpty(singleEnrollResp) && !OPLUtils.isObjectNullOrEmpty(singleEnrollResp.getStatus()) && singleEnrollResp.getStatus() == HttpStatus.OK.value()) {
				otherDetailsRepository.updateIsDDPushFlag(master.getId());
			}
		} catch (Exception e) {
			log.error("Published Data Error -->", e);
		}*/


	@Override
	public void expireAssistedModeApplications() {
		ExpSchedulerAudit audit = new ExpSchedulerAudit();
		audit.setStartDate(currentDate);
		audit.setStatus("pending");
		audit.setApi(ExpSchedulerApiEnum.EXPIRE_ASSISTED_MODE_APPLICATIONS.getId());
		List<ApplicationMasterV3> applicationIdList = Collections.emptyList();
		try {
			log.info("ENTER INTO expireAssistedModeApplications() at {}", new Date());
			List<Integer> appStageId = new ArrayList<>();
			appStageId.add(EnrollStageMaster.COMPLETED.getStageId());
			appStageId.add(EnrollStageMaster.EXPIRED.getStageId());
			appStageId.add(EnrollStageMaster.REJECTED.getStageId());
			appStageId.add(EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId());
			appStageId.add(EnrollStageMaster.PREMIUM_DEDUCTION.getStageId());
			log.info("appStageId.toString() =>  '{}'",appStageId.toString());
			applicationIdList = applicationMasterRepository.findIdByIsActiveTrueAndStageIdNotInAndApplicationMasterOtherDetailsSourceIn(appStageId, Arrays.asList(2,4));
			log.info("TOTAL APPLICATIONS TO EXPIRE : " + applicationIdList.size());
			Date curruntDate = null;
			for (ApplicationMasterV3 applicationId : applicationIdList) {
				curruntDate = new Date();
				applicationMasterRepository.expireOtherModeApplications(applicationId.getId(), curruntDate);
				log.info("EXPIRED APPLICATION_ID  [{}] : ", applicationId.getId());
			}
			audit.setCompleteDate(currentDate);
			audit.setStatus("Completed");
			audit.setExpireCounts(OPLUtils.isListNullOrEmpty(applicationIdList) ? 0 : (long) applicationIdList.size());
		} catch (Exception e) {
			log.error("Error while expireAssistedModeApplications", e);
		} finally {
			Long auditId = expSchedulerAuditRepo.save(audit).getId();
			log.info("application Id List ==> '{}',    auditId '{}'", applicationIdList.stream().map(x->x.getId()).collect(Collectors.toList()), auditId);
			moveExpireEnrollment(applicationIdList, auditId, Boolean.TRUE);
		}
	}

//	@Async
	void moveExpireEnrollment(List<ApplicationMasterV3> applicationIdList, Long auditId, Boolean  isAssistedJourney) {
//		if (isAssistedJourney) {
			ExpiredEnrollment expiredEnrollment = null;
			for (ApplicationMasterV3 applicationMaster : applicationIdList) {
				log.info("moveExpireEnrollment isAssistedJourney --> '{}', applicationId--> '{}'", isAssistedJourney, applicationMaster.getId());
				expiredEnrollment = convertData(applicationMaster, new ExpiredEnrollment(), EnrollStageMaster.EXPIRED.getStageId(), ApplicationStatus.ENROLL_EXPIRED.getId());
				expiredEnrollmentRepository.save(expiredEnrollment);
			}
//		}
		ExpSchedulerAudit expSchedulerAudit = expSchedulerAuditRepo.findById(auditId).orElse(null);
		expSchedulerAudit.setIsMoveExpireEnroll(OPLUtils.isListNullOrEmpty(applicationIdList) ? Boolean.FALSE : Boolean.TRUE);
		expSchedulerAuditRepo.save(expSchedulerAudit);
	}

	@Override
	public void expireOtherChannelApplications() {

		ExpSchedulerAudit audit = new ExpSchedulerAudit();
		audit.setStartDate(currentDate);
		audit.setStatus("Pending");
		audit.setApi(ExpSchedulerApiEnum.EXPIRE_OTHER_CHANNEL_APPLICATIONS.getId());
		audit = expSchedulerAuditRepo.save(audit);
		try {
			log.info("ENTER INTO expireOtherChannelApplications() at {}", new Date());

			List<Integer> appStageId = new ArrayList<>();
			appStageId.add(EnrollStageMaster.COMPLETED.getStageId());
			appStageId.add(EnrollStageMaster.EXPIRED.getStageId());
			appStageId.add(EnrollStageMaster.REJECTED.getStageId());
			appStageId.add(EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId());

			LocalDate now = LocalDate.now();
			LocalDate thirty = now.minusDays(5);
			Date date = Date.from(thirty.atStartOfDay(ZoneId.systemDefault()).toInstant());
			// hello
			List<ApplicationMasterV3> applicationMasterList = applicationMasterRepository.findIdByIsActiveTrueAndStageIdNotInAndCreatedDateBeforeAndApplicationMasterOtherDetailsSource(appStageId, date, Source.OTHER_CHANNEL.getId());

			log.info("EXPIRING THE APPLICATION  --------------> COUNT [{}]", applicationMasterList.size());

			String pythonApiCall = properties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
			Date curruntDate = null;
			for (ApplicationMasterV3 applicationId : applicationMasterList) {

				try {
					/*UpdateEnrollResponse updateEnrollResponse = deDupeRegistryUtility.callUpdateEnrollmentStatus(applicationId,pythonApiCall,null, ApplicationStatus.ENROLL_EXPIRED);
					if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse) && !OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus()) && updateEnrollResponse.getStatus() == HttpStatus.OK.value()) {
						otherDetailsRepository.updateIsDDStatusPushFlag(applicationId);
					}*/

					curruntDate = new Date();
					applicationMasterRepository.expireOtherModeApplications(applicationId.getId(), curruntDate);
					log.info("Expired applicationId  [{}] : ", applicationId.getId());

				} catch (Exception e) {
					log.error("exception while expiring the applications -->", e);
				}


//				try {
//					if ("true".equalsIgnoreCase(pythonApiCall)) {
//						ApplicationMasterV3 applicationMaster = masterRepository.findByIdAndIsActiveTrue(applicationId);
//						UpdateEnrollRequest updateEnrollRequest = CommonUtils.getUpdateEnrollmentStatusReq(applicationMaster);
//						//						CommonResponse commonResponse = CommonUtils.callUpdateEnrollmentStatus(updateEnrollRequest,url);
//						com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callUpdateEnrollmentStatus(updateEnrollRequest);
//						if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus()) && Objects.equals(commonResponse.getStatus(), HttpStatus.OK.value())) {
//							if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData())) {
//								UpdateEnrollResponse updateEnrollResponse = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), UpdateEnrollResponse.class);
//								if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse) && !OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus()) && updateEnrollResponse.getStatus() == HttpStatus.OK.value()) {
//									otherDetailsRepository.updateIsDDStatusPushFlag(applicationId);
//								}
//							}
//						}
//					}
//					curruntDate = new Date();
//					masterRepository.expireOtherModeApplications(applicationId, curruntDate);
//					log.info("Expired applicationId  [{}] : ", applicationId);
//				} catch (Exception e) {
//					log.error("exception while expiring the applications -->", e);
//				}
			}
			audit.setCompleteDate(currentDate);
			audit.setStatus("Completed");
			audit.setExpireCounts(OPLUtils.isListNullOrEmpty(applicationMasterList) ? 0 : Long.valueOf(applicationMasterList.size()));
			Long auditId = expSchedulerAuditRepo.save(audit).getId();
			moveExpireEnrollment(applicationMasterList, auditId, Boolean.FALSE);

		} catch (Exception e) {
			log.error("Error while updateExpireStageIdInApplicationMasterForOtherChannel", e);
		}
	}

	@Override
	public void pushApplication(Long applicationId) {
		log.info("pushApplicationSqsUrl => {}",pushApplicationSqsUrl);
		log.info("applicationId => {}",applicationId);
		/* SQS */
//		queueMessagingTemplate.convertAndSend(pushApplicationSqsUrl, applicationId);


		/* Pushing application */
		String url = properties.getValueByCode("PUSH_PULL_ENROLL_API_URL").concat(applicationId.toString());
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
			headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
			headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published Data For -->" + applicationId + "==========API URL ----------->" + url);
			restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			log.error("Exception While calling Public API :: ", e);
		}
	}
	
	@Override
	public void pushNomineeUpdateApplication(Long applicationId,Long schemeId) {
		log.info("applicationId => {}",applicationId);
		
		/* Pushing application */
		String url = properties.getValueByCode("PUSH_PULL_NOMINEE_UPDATE_API_URL").concat(applicationId.toString()) + "/" + schemeId.toString();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
			headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
			headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published nominee update Data For -->" + applicationId + "==========API URL ----------->" + url);
			restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
		} catch (Exception e) {
			log.error("Exception While calling Public API :: ", e);
		}
	}
	
	


	public CommonResponse rejectApplication(ApplicationMasterV3 applicationMaster,AuthClientResponse authClientResponse) {
		try {
//			Optional<ApplicationMasterV3> applicationMasterOptional = applicationMasterRepository.findById(applicationMaster.getApplicationId());
//			if(applicationMasterOptional.isPresent()){
				ExpiredEnrollment expiredEnrollment = new ExpiredEnrollment();
				expiredEnrollment = convertData(applicationMaster, expiredEnrollment,EnrollStageMaster.REJECTED.getStageId(),ApplicationStatus.ENROLL_REJECTED.getId());
				expiredEnrollment.setModifiedBy(authClientResponse.getUserId());
				expiredEnrollmentRepository.save(expiredEnrollment);
				return new CommonResponse("successfully rejected application", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), Boolean.TRUE);
//			}
		} catch (Exception e) {
			log.error("error is getting while rejectApplication --> {}", applicationMaster.getId());
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	private ExpiredEnrollment convertData(ApplicationMasterV3 applicationMaster, ExpiredEnrollment expiredEnrollment,int stageId,int status) {
		expiredEnrollment.setStageId(stageId);
		expiredEnrollment.setSchemeId(applicationMaster.getSchemeId());
		expiredEnrollment.setId(applicationMaster.getId());
		expiredEnrollment.setUrn(applicationMaster.getUrn());
		expiredEnrollment.setOrgId(applicationMaster.getOrgId());
		expiredEnrollment.setInsurerOrgId(applicationMaster.getInsurerOrgId());
		expiredEnrollment.setBranchId(applicationMaster.getBranchId());
		expiredEnrollment.setStatus(status);
		log.info("applicationMaster.getStatusChangeDate().toString() --->  '{}'", applicationMaster.getStatusChangeDate().toString());
		expiredEnrollment.setStatusChangeDate(applicationMaster.getStatusChangeDate());
		expiredEnrollment.setMessage(applicationMaster.getMessage());
		expiredEnrollment.setPremiumAmount(applicationMaster.getPremiumAmount());
		expiredEnrollment.setSource(applicationMaster.getApplicationMasterOtherDetails().getSource());
		expiredEnrollment.setChannelId(applicationMaster.getApplicationMasterOtherDetails().getChannel());
		expiredEnrollment.setGenderId(applicationMaster.getApplicantInfo().getGenderId());
		expiredEnrollment.setBranchStateId(applicationMaster.getApplicationMasterOtherDetails().getBranchStateId());
		expiredEnrollment.setBranchCityId(applicationMaster.getApplicationMasterOtherDetails().getBranchCityId());
		expiredEnrollment.setBranchLhoId(applicationMaster.getApplicationMasterOtherDetails().getBranchLhoId());
		expiredEnrollment.setBranchRoId(applicationMaster.getApplicationMasterOtherDetails().getBranchRoId());
		expiredEnrollment.setBranchZoId(applicationMaster.getApplicationMasterOtherDetails().getBranchZoId());
		expiredEnrollment.setRuralUrbanId(applicationMaster.getApplicationMasterOtherDetails().getRuralUrbanId());
//		expiredEnrollment.setPolicyYear(DateUtils.fetchPolicyYear(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialYear(DateUtils.fetchFinancialYear(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setPolicyMonth(DateUtils.fetchMonth(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialMonth(DateUtils.fetchMonth(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setPolicyDay(DateUtils.fetchDay(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialDay(DateUtils.fetchDay(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setLastTransactionId(applicationMaster.getLastTransactionDetails().getId());
		expiredEnrollment.setCreatedDate(applicationMaster.getCreatedDate());
		expiredEnrollment.setCreatedBy(applicationMaster.getCreatedBy());
		expiredEnrollment.setModifiedDate(new Date());
//		expiredEnrollment.setModifiedBy(null);
		expiredEnrollment.setIsActive(Boolean.TRUE);
		expiredEnrollment.setDebitStatus(applicationMaster.getDebitStatus());
		return expiredEnrollment;
	}

	@Override
	public CommonResponse getConsentList(List<Integer> consentTypeId) {
		try {
			log.info("ENTER IN getConsentList -->");
		List<ConsentMaster> consentMaster = consentMasterRepository.findByTypeIdInAndIsActiveTrueAndCurrentActiveTrue(consentTypeId);
		List<ConsentMasterProxy> consentMasterProxyLst = new ArrayList<>();
		for (ConsentMaster domain : consentMaster) {
			ConsentMasterProxy consentMasterProxy = new ConsentMasterProxy();
			BeanUtils.copyProperties(domain, consentMasterProxy);
			consentMasterProxyLst.add(consentMasterProxy);
			}
		log.info("EXIT IN getConsentList -->");
		return new CommonResponse(Common.SUCCESS_FETCHED_DATA, consentMasterProxyLst, ResponseStatus.SUCCESS.getStatusId(), true);
	}catch (Exception e) {
		log.error("Error while getConsentList -->", e);		
	}
		return new CommonResponse("consent not found", ResponseStatus.BAD_REQUEST.getStatusId(), false);
	}
	
}
