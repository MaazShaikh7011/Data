package com.opl.jns.insurance.service.domain;


import lombok.*;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

/**
 * @author - Maaz Shaikh
 * @Date - 3/14/2023
 */

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "premium_master")
public class PremiumMaster {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "premium_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "premium_master_seq_gen", sequenceName = "premium_master_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "quarter_months")
    private String quarterMonths;

    @Column(name = "pmjjby_premium")
    private Double pmjjbyPrimium;

    @Column(name = "pmsby_premium")
    private Double pmsbyPremium;
    
    @Column(name = "type")
    private Integer type;

    @Column(name = "is_active")
    private Boolean isActive;
    
    @Column(name = "QUARTER_NO")
    private Integer quarterNo;


}
