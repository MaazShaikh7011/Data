package com.opl.jns.insurance.service.service.impl;

import java.io.IOException;
import java.text.ParseException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

//import io.awspring.cloud.messaging.listener.*;
//import io.awspring.cloud.messaging.listener.annotation.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
//import org.springframework.messaging.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.AccountHoldersDetail;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.insurer.GetCoiDetails.GetCoiRequest;
import com.opl.jns.api.proxy.insurer.GetCoiDetails.GetCoiResponse;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.api.model.BankAllApisResProxy;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ddregistry.api.model.dedupe.DedupApiReqProxy;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.ExpiredEnrollment;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.ApplicationType;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.ere.enums.DebitStatus;
import com.opl.jns.ere.enums.EnrollTypeEnum;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.PremiumMasterType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.SupportDashboardSearch;
import com.opl.jns.ere.repo.ApplicantInfoRepository;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.repo.NomineeDetailsRepositoryV3;
import com.opl.jns.ere.repo.TransactionDetailsRepositoryV3;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.ExpiredEnrollmentRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ApplicationQueryProxy;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.AccountHolderDetailsProxy;
import com.opl.jns.insurance.api.model.AccountHolderMappingRequest;
import com.opl.jns.insurance.api.model.AddressMasterRequest;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.CertificateInsDtlRequest;
import com.opl.jns.insurance.api.model.EnrollmentDetailsProxy;
import com.opl.jns.insurance.api.model.EnrollmentDtlProxy;
import com.opl.jns.insurance.api.model.ErrorStageProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.insurance.api.model.NomineeDetailsRequest;
import com.opl.jns.insurance.api.model.PolicyDetailsProxy;
import com.opl.jns.insurance.api.model.PremiumDeductionFailedProxy;
import com.opl.jns.insurance.api.model.RegenerateCoiProxy;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.insurance.api.model.v2.AccHolderListReq;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.api.model.v2.GetCoiReq;
import com.opl.jns.insurance.api.model.v2.PremiumPopupRequest;
import com.opl.jns.insurance.service.domain.PremiumMaster;
import com.opl.jns.insurance.service.repository.PremiumMasterRepository;
import com.opl.jns.insurance.service.service.ApplicationMasterService;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.insurance.service.utils.ErrorStageAuditUtils;
import com.opl.jns.insurance.service.utils.NotificationUtil;
import com.opl.jns.insurance.service.utils.ResponseStatus;
import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.model.PincodeMasterResponse;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.api.model.UserOrganisationPdfGenarateRequestResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.PatternUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.TransactionTypeEnum;
import com.opl.jns.utils.enums.UserTypeMaster;
import com.opl.jns.utils.model.COIRequest;
import com.opl.jns.webhook.client.WebHookClient;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;

/***
 * 
 *
 * @author ravi.thummar Date : 28/04/2023
 */

@Service
@Slf4j
public class EnrollmentServiceImpl implements EnrollmentService {

	public static final String RESEND_OTP_TIME_IN_SEC = "RESEND_OTP_TIME_IN_SEC";
	public static final String PMJJBY_ENROLLMENT_AGE_LIMIT = "PMJJBY_ENROLLMENT_AGE_LIMIT";
	public static final String PMSBY_ENROLLMENT_AGE_LIMIT = "PMSBY_ENROLLMENT_AGE_LIMIT";
	public static final String INSURER_START_DATE = "INSURER_START_DATE";
	public static final String EXCEPTION_MSG = "It seems like the application has encountered an error; please try again later.";
	public static final Integer[] inProcessOrCompletedApplication = new Integer[] { ApplicationStatus.ENROLL_IN_PROGRESS.getId()};
//	public static final Integer[] inProcessOrCompletedApplication = new Integer[] { ApplicationStatus.ENROLL_IN_PROGRESS.getId(), ApplicationStatus.ENROLL_COMPLETED.getId(),ApplicationStatus.OPT_OUT_IN_PROCESS.getId() }; - -removed rejected renewal in master and insurance .app in not reject issues
	public static final Random rand = new Random();

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepo;

	@Autowired
	private NomineeDetailsRepositoryV3 nomineeDetailsRepository;
	
	@Autowired
	private ApplicantInfoRepository applicantInfoRepository;

	@Autowired
	private ConfigProperties configProperties;

	@Autowired
	private static Validator validator;

	@Autowired
	private ErrorStageAuditUtils stageAuditUtils;

	@Autowired
	private PremiumMasterRepository premiumMasterRepo;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private UserManagementClient userManagementClient;

	@Autowired
	private BankApiClient bankApiClient;

	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private OneFormClient oneFormClient;

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private TransactionDetailsRepositoryV3 transactionRepo;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;
	
	@Autowired
	private ApplicationMasterService applicationMasterService;

	@Autowired
	private NotificationUtil notificationUtil;

	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private PDFGenerateClient pdfGenerateClient;
	
	@Autowired
	private WebHookClient webHookClient;
	
	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;
	
	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepositoryV2;
	
	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;
	
	@Autowired
	private AddressMasterRepositoryV2 addressMasterRepositoryV2;
	
	@Autowired
	private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;
	
	@Autowired
	private NomineePIDetailsRepository nomineePIDetailsRepository;
	
	@Autowired
	private ApplicationPushStatusRepo applicationPushStatusRepo;
	
	@Autowired
	private ExpiredEnrollmentRepository expiredEnrollmentRepository;
	
	@Autowired
	private PmsbyRepository pmsbyRepository;
	
	@Autowired
	private PmjjbyRepository pmjjbyRepository;
	
	@Autowired
	private ConsentMasterRepository consentMasterRepository;

	public CommonResponse updateEnrollmentVerificationType(Long applicationId, Integer typeOfVerification, AuthClientResponse authClientResponse) throws Exception {

		// CHECK TYPE OF VERIFICATION IS VALID OR NOT
		if (typeOfVerification != CommonUtils.ENROLLMENT_VERIFICATION_OTP && typeOfVerification != CommonUtils.ENROLLMENT_VERIFICATION_PHYSICAL) {
			log.info("Invalid Type of verification found -------------->" + typeOfVerification);
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_TYPE_OF_VERIFICATION, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}

		// CHECK APPLICATION DETAILS AVAILABLE OR NOT
		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		ApplicationMasterOtherDetailsV3 otherDetailsFetch = appMaster.getApplicationMasterOtherDetails();
		if (OPLUtils.isObjectNullOrEmpty(otherDetailsFetch)) {
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		boolean checkPhase2 = PhaseMode.checkPhase2(appMaster.getOrgId());

		// SET TYPE OF VERIFICATION
		otherDetailsFetch.setTypeOfVerification(typeOfVerification);

		appMaster.setModifiedDate(new Date());
		appMaster.setModifiedBy(authClientResponse.getUserId());

		// OTP VERIFICATION FLOW
		if (typeOfVerification == CommonUtils.ENROLLMENT_VERIFICATION_OTP) {

			/** UPDATE URN CODE HERE, IF GET OTP IS FAILED */
			appMaster.setUrn(generateUrnCode(appMaster.getSchemeId(), appMaster.getId()));
			appMaster = applicationMasterRepo.save(appMaster);

			/** CALL BANK API FOR SENT OTP PROCESS  */
			TriggerOtpRequest req = getTriggerOtpRequest(appMaster,checkPhase2);

			TriggerOtpResponse otp = null;

			try {
				otp = bankApiClient.triggerOTP(req, authClientResponse);
			} catch (Exception e) {
				log.error("Exception while SEND OTP -----> ", e);
				updateStageError(appMaster.getId(), appMaster.getStageId(), e.getMessage(), authClientResponse.getUserId());
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_GET_OTP, HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			if (!OPLUtils.isObjectNullOrEmpty(otp) && !OPLUtils.isObjectNullOrEmpty(otp.getStatus()) && otp.getStatus() == HttpStatus.OK.value() && Objects.equals(otp.getFlag(), Boolean.TRUE)) {

				String isDedupOn = ConfigProperties.getValues(CommonUtils.IS_DEDUP_ON);
				log.info("IS DEDUP ON---------------------->{} ", isDedupOn);
				List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
				List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());

				// RESPONSE CLASS VALIDATION
				StringBuilder validateResponse = validateResponse(otp);
				if(!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}

				// MOBILE NUMBER VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(otp.getMobileNumber()) && !isSkipUserIdsLst.contains(authClientResponse.getUserId()) && isDedupOn.equalsIgnoreCase("true")) {
					updateAppMasterErro(appMaster, "mobile number Not Found From Bank Response", authClientResponse.getUserId());
					return new CommonResponse("Mobile Number " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}else if(!Pattern.matches(PatternUtils.MOBILE_PATTERN_91, otp.getMobileNumber())) {
					updateAppMasterErro(appMaster, CommonUtils.INVALID_MOBILE_NO_ERROR, authClientResponse.getUserId());
					return new CommonResponse(CommonUtils.INVALID_MOBILE_NO_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}
				if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
					applicantInfoRepository.updateMobileNumberByApplicationId(OPLUtils.getValidMobileNumber(otp.getMobileNumber()), appMaster.getId());
				}
				return makeResponseBody(otp,appMaster);

			} else {
				return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(otp) ? otp.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_GET_OTP, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}
		} else {
			/** PHYSICAL VERIFICATION FLOW */
			applicationMasterRepo.save(appMaster);
			return new CommonResponse(CommonErrorMsg.Enrollment.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
		}
	}

	private CommonResponse makeResponseBody(TriggerOtpResponse otp,ApplicationMasterV3 appMaster) {
		Map<String, Object> res = new HashMap<>();
		res.put(CommonUtils.MOBILE_NUMBER, Objects.equals(appMaster.getApplicationMasterOtherDetails().getSource(),
				Source.JANSURAKSHA_DIY.getId()) ? otp.getMobileNumber()
						: OPLUtils.convertToMask(otp.getMobileNumber(), 4, "X"));
		res.put(CommonUtils.MESSAGE, otp.getMessage());
		res.put(CommonUtils.RESEND_OTP_TIME, configProperties.getValueByCode(RESEND_OTP_TIME_IN_SEC));
		return new CommonResponse(otp.getMessage(), res, HttpStatus.OK.value(), Boolean.TRUE);
	}

	private TriggerOtpRequest getTriggerOtpRequest(ApplicationMasterV3 appMaster,Boolean isPhase2) {
		TriggerOtpRequest req = new TriggerOtpRequest();
		req.setAccountNumber(appMaster.getAccountNumber());
		req.setUrn(appMaster.getUrn());
		req.setApplicationId(appMaster.getId());
		req.setDob(!OPLUtils.isObjectNullOrEmpty(appMaster.getDob()) ? (isPhase2 ? CommonUtils.sdf.format(appMaster.getDob()) : CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getDob())) : null);
		req.setOrgId(appMaster.getOrgId());
		return req;
	}

	public CommonResponse verifyOtp(VerfiyOtpRequest req, AuthClientResponse authRes) throws Exception {
		try {
			/* CHECK APPLICATION ID VALID OR NOT */
//			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());
			
			ApplicationQueryProxy appMaster = applicationMasterRepo.fetchVerifyApiDetailsById(req.getApplicationId());
			
			//AccountNumber,Dob,OrgId,Urn,StageId
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			appMaster.setApplicationId(req.getApplicationId());
			boolean checkPhase2 = PhaseMode.checkPhase2(appMaster.getOrgId());

			/* PREPARE BANK API REQUEST FOR OTP VERIFICATION */
			OTPRequest otpReq = OTPRequest.builder().applicationId(req.getApplicationId()).accountNumber(appMaster.getAccountNumber()).dob(appMaster.getDob() != null ? (checkPhase2 ? CommonUtils.sdf.format(appMaster.getDob()) : CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getDob())) : null)
					.verifyVerificationcode(req.getVerifyOTP()).orgId(appMaster.getOrgId()).urn(appMaster.getUrn()).build();

			authRes.setUserOrgId(req.getOrgId());
			VerifyOtpApiResponse vrfyRes = bankApiClient.verifyOtp(otpReq, authRes);
			if (OPLUtils.isObjectNullOrEmpty(vrfyRes) || (!OPLUtils.isObjectNullOrEmpty(vrfyRes.getStatus()) && (vrfyRes.getStatus() != HttpStatus.OK.value()))
					|| (!OPLUtils.isObjectNullOrEmpty(vrfyRes.getFlag()) && vrfyRes.getFlag().equals(Boolean.FALSE))) {
				updateStageError(req.getApplicationId(), appMaster.getStageId(), vrfyRes.getMessage(), req.getUserId());
				return new CommonResponse(null, vrfyRes.getMessage(), vrfyRes.getStatus());
			}
			if (OPLUtils.isListNullOrEmpty(vrfyRes.getAccountHolderDetails())) {
				updateStageError(req.getApplicationId(), appMaster.getStageId(), "No account holder details found", req.getUserId());
				return new CommonResponse(null, "Its seems we have not found account folder details by given account number!!", HttpStatus.BAD_REQUEST.value());
			}
			
			// RESPONSE CLASS VALIDATION
			StringBuilder validateResponse = validateResponse(vrfyRes);
			if(!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
				return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			return updateOtpOrPhysicalVerification(vrfyRes.getAccountHolderDetails(), appMaster, req.getUserId());
		} catch (Exception e) {
			log.error("Exception is getting While verify otp ", e);
			return new CommonResponse(EXCEPTION_MSG, ResponseStatus.EXCEPTION_IN_PROCESSING.getStatusId(), Boolean.FALSE);
		}
	}

	/**
	 * GENERATE URN LOGIC
	 *
	 * @param schemeId
	 * @param applicationId
	 * @return
	 * @throws InsuranceException
	 */
	private String generateUrnCode(Integer schemeId, Long applicationId) throws InsuranceException {
		if (null == applicationId || null == schemeId) {
			return null;
		}
		String id = "%03d".formatted(rand.nextInt(1000));
		return configProperties.getValueByCode(CommonUtils.JNS_APP_CODE_INITIAL).toUpperCase().concat(CommonUtils.CHAR_DASH).concat(SchemeMaster.getById(schemeId.longValue()).getShortName().toUpperCase()).concat(CommonUtils.CHAR_DASH)
				.concat(CommonUtils.getPolicyYearToYear()).concat(CommonUtils.CHAR_DASH).concat("%011d".formatted(applicationId)).concat(CommonUtils.CHAR_DASH).concat(id);
	}

	/**
	 * MAINTAIN STAGE ERROR AUDIT
	 */
	public void updateStageError(Long applicationId, Integer enrollStageId, String msg, Long modifiedBy) {
		EnrollStageMaster stage = null;
		if (enrollStageId != null) {
			stage = EnrollStageMaster.getStageMasterByStageId(enrollStageId);
		}
		stageAuditUtils.update(new ErrorStageProxy(applicationId, enrollStageId, stage != null ? stage.getStageName() : null, msg, modifiedBy));
	}

	/**
	 * VERIFY CUSTOMER BY PHYSICAL SIGNATURE
	 */
	public CommonResponse verifyPhysicalSignature(Long applicationId, AuthClientResponse authRes) throws Exception {
		try {

			/** CHECK APPLICATION ID IS VALID OR NOT */
//			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
			
			ApplicationQueryProxy appMaster = applicationMasterRepo.fetchVerifyApiDetailsById(applicationId);
			
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			appMaster.setApplicationId(applicationId);

			/** UPDATE URN CODE HERE, IF GET OTP IS FAILED */
			String generateUrnCode = generateUrnCode(appMaster.getSchemeId(), appMaster.getApplicationId());
			appMaster.setUrn(generateUrnCode);
//			appMaster = applicationMasterRepo.save(appMaster);
			int updateUrnByApplicationId = applicationMasterRepo.updateUrn(appMaster.getUrn(),appMaster.getOrgId(), appMaster.getSchemeId(), applicationId);
			
			if(OPLUtils.isObjectNullOrEmpty(updateUrnByApplicationId) || updateUrnByApplicationId ==0)
				return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			
			boolean checkPhase2 = PhaseMode.checkPhase2(appMaster.getOrgId());
			/** PREPARE REQUEST OF VERIFY PHYSICAL SIGNATURE */
			log.info("checkPhase2 -> {}", checkPhase2);
			OTPRequest otpReq = OTPRequest.builder().applicationId(appMaster.getApplicationId()).accountNumber(appMaster.getAccountNumber()).dob(appMaster.getDob() != null ? (checkPhase2 ? CommonUtils.sdf.format(appMaster.getDob()) : CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getDob())) : null)
					.orgId(appMaster.getOrgId()).urn(appMaster.getUrn()).signVerifiedByBank(CommonUtils.STR_YES).build();

			PhysicalVerificationResponse physVrfRes = bankApiClient.verifyPhysicalSignature(otpReq, authRes);
			log.info("bankClientVerifyOtp -> ", physVrfRes);
			if (OPLUtils.isObjectNullOrEmpty(physVrfRes) || (!OPLUtils.isObjectNullOrEmpty(physVrfRes.getStatus()) && (physVrfRes.getStatus() != HttpStatus.OK.value()))
					|| (!OPLUtils.isObjectNullOrEmpty(physVrfRes.getFlag()) && physVrfRes.getFlag().equals(Boolean.FALSE))) {
				updateStageError(appMaster.getApplicationId(), appMaster.getStageId(), physVrfRes.getMessage(), authRes.getUserId());
				return new CommonResponse(physVrfRes.getMessage(), Boolean.FALSE, physVrfRes.getStatus(), Boolean.FALSE);
			}

			// IN BANK API RESPONSE, ACCOUNT HOLDER DETAILS NOT FOUND
			if (OPLUtils.isListNullOrEmpty(physVrfRes.getAccountHolderDetails())) {
				updateStageError(appMaster.getApplicationId(), appMaster.getStageId(), "No account holder details found", authRes.getUserId());
				return new CommonResponse("Its seems we have not found account folder details by given account number!!", Boolean.FALSE, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			// RESPONSE CLASS VALIDATION
			StringBuilder validateResponse = validateResponse(physVrfRes);
			if(!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
				return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			
			return updateOtpOrPhysicalVerification(physVrfRes.getAccountHolderDetails(), appMaster, authRes.getUserId());
		} catch (Exception e) {
			log.error("Exception is getting While physical verification : ", e);
			return new CommonResponse(EXCEPTION_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
	}

	/**
	 * PREPARE ACCOUNT HOLDER BANK RESPONSE TO ACTUAL CLASS
	 *
	 * @param holderList
	 * @param appMaster
	 * @param userId
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	private CommonResponse updateOtpOrPhysicalVerification(List<AccountHoldersDetail> holderList, ApplicationQueryProxy appMaster, Long userId) {

		CommonResponse response = new CommonResponse();
		List<AccountHolderMappingRequest> holderMapReq = new ArrayList<AccountHolderMappingRequest>(holderList.size());
		holderList.forEach(val -> {

			holderMapReq.add(AccountHolderMappingRequest.builder().accountHolderName(val.getAccountHolderName()).applicationId(appMaster.getApplicationId()).cif(val.getCif()).customerAccountNumber(appMaster.getAccountNumber())
					.urnCode(appMaster.getUrn()).sizeOfACHolder(holderList.size()).dob(val.getDob()).gender(!OPLUtils.isObjectNullOrEmpty(val.getGender()) ? val.getGender() : null).pmjjbyExists(setApiResFlag(val.getPMJJBYexists()))
					.pmsbyExists(setApiResFlag(val.getPMSBYexists())).kycUpdated(setApiResFlag(val.getKYCUpdated())).build());
		});

		response.setMessage("SuccessFully Verified OTP");
		response.setStatus(HttpStatus.OK.value());
		response.setData(holderMapReq);
		response.setFlag(true);
		return response;
	}

	private boolean setApiResFlag(String flag) {
		if (!OPLUtils.isObjectNullOrEmpty(flag) && (flag.equalsIgnoreCase("Yes") || flag.equalsIgnoreCase("Y"))) {
			return true;
		}
		return false;
	}

	@Override
	public void updateAppMasterErro(ApplicationMasterV3 appMaster, String msg, Long userId) {
		appMaster.setMessage(msg);
		updateStageError(appMaster.getId(), appMaster.getStageId(), msg, userId);
		appMaster.setModifiedDate(new Date());
		appMaster.setModifiedBy(userId);
		applicationMasterRepo.save(appMaster);
	}

	public CommonResponse updateSelectedAccountHolder(AccountHolderMappingRequest selectedHolder, AuthClientResponse authRes) throws Exception {
		// FIND APPLICATION MASTER BY APPLICATION ID
		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(selectedHolder.getApplicationId());
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		if(appMaster.getStageId()!=EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId()) {
			return setDeDupeResponse(appMaster.getApplicationStatus(),appMaster,authRes.getUserId());
		}
		boolean checkPhase2 = PhaseMode.checkPhase2(appMaster.getOrgId());
		authRes.setUserOrgId(appMaster.getOrgId());
		// UPDATE ACCOUNT HOLDER ID AND CIF NUMBER
		ApplicantInfo cstDetails = appMaster.getApplicantInfo();
		cstDetails.setName(selectedHolder.getAccountHolderName());
		cstDetails.setIsPMJJBYExists(selectedHolder.getPmjjbyExists());
		cstDetails.setIsPMSBYExists(selectedHolder.getPmsbyExists());
		cstDetails.setIsKYCUpdate(selectedHolder.getKycUpdated());
		Date curruntDate = new Date();
		Date dob = null;
		if (!OPLUtils.isObjectNullOrEmpty(selectedHolder.getDob())) {
			if(!checkPhase2){				
				try {
					dob = CommonUtils.sdf_dd_MM_yyyy.parse(selectedHolder.getDob());
					cstDetails.setDob(CommonUtils.sdf_dd_MM_yyyy.parse(selectedHolder.getDob()));
				} catch (Exception e) {
					log.error("Invalid date format  ==> {},{}", selectedHolder.getDob(), e.getMessage());
					return new CommonResponse("Invalid date format fetch from bank", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			}else {
				try {
					dob = CommonUtils.sdf.parse(selectedHolder.getDob());
					cstDetails.setDob(CommonUtils.sdf.parse(selectedHolder.getDob()));
					log.info("cstDetails.getDob() : [{}]",cstDetails.getDob());
					log.info("dob : [{}]",dob);
				} catch (Exception e) {
					log.error("Invalid date format  ==> {},{}", selectedHolder.getDob(), e.getMessage());
					return new CommonResponse("Invalid date format fetch from bank", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			}
		} else {
			updateStageError(appMaster.getId(), appMaster.getStageId(), "Date of Birth of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed", authRes.getUserId());
			appMaster.setMessage("Date of Birth of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed");
			appMaster.setModifiedDate(curruntDate);
			appMaster.setModifiedBy(authRes.getUserId());
			applicationMasterRepo.save(appMaster);
			return new CommonResponse(CommonUtils.DOB_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
		}
		cstDetails.setModifiedBy(authRes.getUserId());
		cstDetails.setModifiedDate(curruntDate);

		appMaster.setCif(selectedHolder.getCif());
		appMaster.setApplicantInfo(cstDetails);
		appMaster.setModifiedDate(curruntDate);
		appMaster.setModifiedBy(authRes.getUserId());
		appMaster = applicationMasterRepo.save(appMaster);
		log.info("appMaster.getApplicantInfo().getDob() : [{}]",appMaster.getApplicantInfo().getDob());

		String isDedupOn = ConfigProperties.getValues(CommonUtils.IS_DEDUP_ON);
//		log.info("IS DEDUP ON---------------------->{} ", isDedupOn);
		List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
		List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());
		
		// Same Organization Check If CIF Enrollment Exist
		CommonResponse isDeDupe = checkDedupeOrgIdWithCif(appMaster, selectedHolder.getCif(), authRes);
		if (!OPLUtils.isObjectNullOrEmpty(isDeDupe) && !OPLUtils.isObjectNullOrEmpty(isDeDupe.getFlag()) && !isDeDupe.getFlag() && !isSkipUserIdsLst.contains(authRes.getUserId())) {
			return isDeDupe;
		}
		
		/**CHECK JNS MASTER DATA APPLICATION MASTER DEDUPE*/
		if(!isSkipUserIdsLst.contains(authRes.getUserId())) {
			String urn = ereCommonService.checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(appMaster.getSchemeId(), selectedHolder.getCif(), authRes.getUserOrgId());			
			if (!OPLUtils.isObjectNullOrEmpty(urn)) {
				return new CommonResponse(HttpStatus.ALREADY_REPORTED.getReasonPhrase(),
						ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
			}
		}

		// FIND ACCOUNT HOLDER DETAILS BY PRIMARY ID
		if (OPLUtils.isObjectNullOrEmpty(selectedHolder.getAccountHolderName())) {
			updateAppMasterErro(appMaster, "Account Holder Mapping Details Not Found.", authRes.getUserId());
			return new CommonResponse("Its seems we have not found data from given holder verification number!!", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
		}

		if (isDedupOn.equalsIgnoreCase("true") && !isSkipUserIdsLst.contains(authRes.getUserId())) {

			// KYC VALIDATION
			if (Boolean.FALSE.equals(selectedHolder.getKycUpdated())) {
				updateAppMasterErro(appMaster, "KYC IS NOT UPDATED", authRes.getUserId());
				String msg = "KYC of " + "(" + cstDetails.getName() + ")" + " is not updated in the bank CBS. Kindly ask the customer to update their KYC and then proceed.";
				return new CommonResponse(msg, ResponseStatus.KYC_NOT_UPDATED.getStatusId(), false);
			}

			// PMJJBY EXISTS VALIDATION
			if (appMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue() && selectedHolder.getPmjjbyExists() != null && Boolean.TRUE.equals(selectedHolder.getPmjjbyExists())) {
				updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authRes.getUserId());
				return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.KYC_NOT_UPDATED.getStatusId(), false);
			}

			// PMSBY EXISTS VALIDATION
			if (appMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue() && selectedHolder.getPmsbyExists() != null && Boolean.TRUE.equals(selectedHolder.getPmsbyExists())) {
				updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authRes.getUserId());
				return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.KYC_NOT_UPDATED.getStatusId(), false);
			}
		}
		CommonResponse validateAge = validateAge(appMaster, dob, selectedHolder, isDedupOn, isSkipUserIdsLst, authRes);
		if (!OPLUtils.isObjectNullOrEmpty(validateAge)) {
			return validateAge;
		}

		// CHECK INTERNAL DE-DUPE VALIDATION
		CommonResponse isExist = checkInternalDedup(appMaster, selectedHolder.getCif(), authRes.getUserId());
		if (!OPLUtils.isObjectNullOrEmpty(isExist)) {
			return isExist;
		}

		// FETCH SELECTED ACCOUNT HOLDER DETAILS
		CustomerDetailsRequest custReq = CustomerDetailsRequest.builder().applicationId(appMaster.getId()).accountNumber(appMaster.getAccountNumber()).cif(selectedHolder.getCif()).urn(appMaster.getUrn()).orgId(appMaster.getOrgId()).build();
		CustomerDetailsDataV3 bankClientRes = bankApiClient.getCustomerDetails(custReq, authRes);
		if (!OPLUtils.isObjectNullOrEmpty(bankClientRes) && !OPLUtils.isObjectNullOrEmpty(bankClientRes.getFlag()) && bankClientRes.getFlag().equals(Boolean.TRUE) && !OPLUtils.isObjectNullOrEmpty(bankClientRes.getAccountHolderDetails())) {
			AccountHolderDetailsResponseV3 wrap = bankClientRes.getAccountHolderDetails();
			log.info("Found Account Holder Details  ==> {}", wrap);

			// RESPONSE CLASS VALIDATION
			validator = Validation.buildDefaultValidatorFactory().getValidator();
			Set<ConstraintViolation<CustomerDetailsDataV3>> violations = validator.validate(bankClientRes);
			if (!violations.isEmpty()) {
				StringBuilder sb = new StringBuilder();
				StringBuilder sbFull = new StringBuilder();
				int count = 0;
				for (ConstraintViolation<CustomerDetailsDataV3> constraintViolation : violations) {
					if (sb.length() > 0) {
						if (count > 3) {
							sb.append("<br> " + constraintViolation.getMessage());
						}
						sbFull.append("<br> " + constraintViolation.getMessage());
					} else {
						sb.append(constraintViolation.getMessage());
						sbFull.append(constraintViolation.getMessage());
					}
					count++;
				}
				updateStageError(appMaster.getId(), appMaster.getStageId(), sbFull.toString(), authRes.getUserId());
				appMaster.setMessage(sbFull.toString());
				appMaster.setModifiedDate(new Date());
				appMaster.setModifiedBy(authRes.getUserId());
				applicationMasterRepo.save(appMaster);
				return new CommonResponse(sb.toString() + "<br><br>" + CommonUtils.FIELD_MISSING, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
			
			
			/*String pythonApiCall = configProperties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
			if (null != pythonApiCall && pythonApiCall.equalsIgnoreCase("true")) {
			ApiData apiData = deDupeRegistryUtility.callCheckDedupeRequest(appMaster,authRes,wrap,DeDupeApiCallType.UPDATE_SELECTED_ACCOUNT_HOLDER);
			
			if (apiData.getIsMatched().equalsIgnoreCase("Y")) {
				updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authRes.getUserId());
				return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
			}else if (apiData.getIsMatched().equalsIgnoreCase("E")) {
				updateAppMasterErro(appMaster,apiData.getMessage(), authRes.getUserId());
				return new CommonResponse(apiData.getMessage(), ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}
		}*/
			
//			String pythonApiCall = configProperties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
//			if (null != pythonApiCall && pythonApiCall.equalsIgnoreCase("true")) {
//				try {
//					//					String url = configProperties.getValueByCode(OPLUtils.CHECK_DE_DUPE);
//					DedupApiReqProxy DedupRequest = CommonUtils.getCheckDedupeReqForEnroll(appMaster, wrap);
//					//					CommonResponse commonResponse = CommonUtils.callCheckDedupeRequest(DedupRequest, url);
//					com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callCheckDedupeRequest(DedupRequest);
//					if (!OPLUtils.isObjectNullOrEmpty(commonResponse)) {
//						DedupApiResProxy apiResProxy = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), DedupApiResProxy.class);
//						if (!OPLUtils.isObjectNullOrEmptyOrDash(apiResProxy)) {
//							ApiData apiData = apiResProxy.getData(); // MultipleJSONObjectHelper.getObjectFromObject(apiResProxy.getData(),
//																		// ApiData.class);
//							if (!OPLUtils.isObjectNullOrEmpty(apiData) && !OPLUtils.isObjectNullOrEmpty(apiData.getIsMatched()) && apiData.getIsMatched().equalsIgnoreCase("Y")) {
//								updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authRes.getUserId());
//								return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
//							}
//						}
//					}
//
//				} catch (Exception e) {
//					log.error("update enrollment Data Error -->", e);
//				}
//			}

			if (!OPLUtils.isObjectNullOrEmpty(wrap.getKycID1())) {
				CommonResponse commonResponse = kycIdValidOrNot(wrap.getKycID1(), appMaster, authRes, "KYC ID1");
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse)) {
					return commonResponse;
				}
				if (!OPLUtils.isObjectNullOrEmpty(wrap.getKycID1number())) {
					CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(wrap.getKycID1(), wrap.getKycID1number(), appMaster, authRes, "KYC ID1");
					if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
						return commonResponsekycNo;
					}
				}
			}

			if (!OPLUtils.isObjectNullOrEmpty(wrap.getKycID2())) {
				CommonResponse commonResponse = kycIdValidOrNot(wrap.getKycID2(), appMaster, authRes, "KYC ID2");
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse)) {
					return commonResponse;
				}
				if (!OPLUtils.isObjectNullOrEmpty(wrap.getKycID2number())) {
					CommonResponse commonResponsekycNo = kycIdNumberValidOrNot(wrap.getKycID2(), wrap.getKycID2number(), appMaster, authRes, "KYC ID2");
					if (!OPLUtils.isObjectNullOrEmpty(commonResponsekycNo)) {
						return commonResponsekycNo;
					}
				}
			}

			/// DOB VALIDATION
			if (OPLUtils.isObjectNullOrEmpty(wrap.getDob())) {
				updateStageError(appMaster.getId(), appMaster.getStageId(), "Date of Birth of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed", authRes.getUserId());
				appMaster.setMessage("Date of Birth of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed");
				appMaster.setModifiedDate(new Date());
				appMaster.setModifiedBy(authRes.getUserId());
				applicationMasterRepo.save(appMaster);
				return new CommonResponse(CommonUtils.DOB_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
			}
			
			if(!isSkipUserIdsLst.contains(authRes.getUserId()) && isDedupOn.equalsIgnoreCase("true")) {
				// ACCOUNT HOLDER NAME VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getAccountHolderName())) {
					updateAppMasterErro(appMaster, "Account Holder Name Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("Account Holder Name " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// CIF VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getCif())) {
					updateAppMasterErro(appMaster, "CIF Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("CIF " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// CUSTOMER IFSC VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getCustomerIFSC())) {
					updateAppMasterErro(appMaster, "IFSC Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("IFSC " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// GENDER VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getGender())) {
					updateAppMasterErro(appMaster, "Gender Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("Gender " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// FATHER OR HUSBAND NAME VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getFatherHusbandName())) {
					updateAppMasterErro(appMaster, CommonUtils.FATHER_OR_HUSBAND_NAME_ERROR, authRes.getUserId());
					return new CommonResponse(CommonUtils.FATHER_OR_HUSBAND_NAME_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				validateAge = validateAge(appMaster, Date.from(wrap.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()), selectedHolder, isDedupOn, isSkipUserIdsLst, authRes);
				if (!OPLUtils.isObjectNullOrEmpty(validateAge)) {
					return validateAge;
				}

				if(!checkPhase2) {
					// FIRSTNAME VALIDATION
					if (OPLUtils.isObjectNullOrEmpty(wrap.getFirstName())) {
						updateAppMasterErro(appMaster, "FirstName Not Found From Bank Response", authRes.getUserId());
						return new CommonResponse("First Name of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
					}
					
					// RURAL URBAN SEMIURBAN METRO VALIDATION
					if (OPLUtils.isObjectNullOrEmpty(wrap.getRuralUrban())) {
						updateAppMasterErro(appMaster, CommonUtils.RURAL_SEMIURBAN_ERROR, authRes.getUserId());
						return new CommonResponse(CommonUtils.RURAL_SEMIURBAN_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
					}
				}
				
				// CONSENT FOR AUTO DEBIT VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getConsentForAutoDebit())) {
					updateAppMasterErro(appMaster, CommonUtils.CONSENT_FOR_AUTO_DEBIT_ERROR, authRes.getUserId());
					return new CommonResponse(CommonUtils.CONSENT_FOR_AUTO_DEBIT_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// KYC ID 1 VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getKycID1())) {
					updateAppMasterErro(appMaster, "KYC id 1 Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("KYC id 1 " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// KYC ID 1 NUMBER VALIDATION
				if ((OPLUtils.isObjectNullOrEmpty(wrap.getKycID1number()) && !wrap.getKycID1().equalsIgnoreCase(CommonUtils.AADHAR))) {
					updateAppMasterErro(appMaster, "KYC id 1 Number Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("KYC id 1 Number " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// ADDRESS LINE 1 NUMBER VALIDATION
				if (OPLUtils.isObjectNullOrEmpty(wrap.getAddressline1())) {
					updateAppMasterErro(appMaster, "Address Line 1 Number Not Found From Bank Response", authRes.getUserId());
					return new CommonResponse("Address Line 1 Number " + CommonUtils.CUSTOMER_ERROR, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
				}

				// CITY DISTRICT STATE PINCODE VALIDATION
					String missingName = CommonUtils.getCustomerDetailValidation(wrap);
					if (!OPLUtils.isObjectNullOrEmpty(missingName)) {
						String finalMsg = CommonUtils.CUSTOMER_DETAIL_ERROR1 + " (" + missingName + "). " + CommonUtils.CUSTOMER_DETAIL_ERROR2;
						updateAppMasterErro(appMaster, finalMsg, authRes.getUserId());
						return new CommonResponse(finalMsg, ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), false);
					}

			}
			
			/** if users is borrower than add branch details */
			String schemeName = SchemeMaster.getById(appMaster.getSchemeId().longValue()).getShortName();
			appMaster = addBranchDetailsForBorrower(wrap, appMaster, authRes);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				return new CommonResponse("Bank branch has not been given access for the " + schemeName + " scheme.", ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}

			// SAVE ACCOUT HOLDER DETAILS
			appMaster = saveAccHolderDtl(wrap, appMaster.getId(), authRes.getUserType(),checkPhase2);

			// SAVE NOMINEE DETAILS
			saveNomineeDetails(wrap, appMaster, authRes.getUserId(),checkPhase2);
			applicationMasterRepo.save(appMaster);
			return new CommonResponse("Successfully get Account Holder Details!!", HttpStatus.OK.value(), Boolean.TRUE);

		} else if (!OPLUtils.isObjectNullOrEmpty(bankClientRes)
				&& (!OPLUtils.isObjectNullOrEmpty(bankClientRes.getStatus())
						&& bankClientRes.getStatus() != HttpStatus.OK.value())
				|| (!OPLUtils.isObjectNullOrEmpty(bankClientRes.getFlag())
						&& bankClientRes.getFlag().equals(Boolean.FALSE))) {
			updateStageError(appMaster.getId(), appMaster.getStageId(), bankClientRes.getMessage(), authRes.getUserId());
			return new CommonResponse(bankClientRes.getMessage(), bankClientRes.getStatus(), false);
		}
		updateStageError(appMaster.getId(), appMaster.getStageId(), "Error while fetching account holder details from the bank", authRes.getUserId());
		return new CommonResponse("Unable to fetch A/C details due to error from bank", ResponseStatus.BAD_REQUEST.getStatusId(), false);
	}

	private CommonResponse validateAge(ApplicationMasterV3 appMaster, Date dob, AccountHolderMappingRequest selectedHolder, String isDedupOn, List<Long> isSkipUserIdsLst, AuthClientResponse authRes) {
		// CHECK ENROLLMENT AGE VALIDATION
		String enrollmentAgeLimit = null;
		if (appMaster.getSchemeId().intValue() == SchemeMaster.PMJJBY.getId()) {
			enrollmentAgeLimit = configProperties.getValueByCode(PMJJBY_ENROLLMENT_AGE_LIMIT);
		} else {
			enrollmentAgeLimit = configProperties.getValueByCode(PMSBY_ENROLLMENT_AGE_LIMIT);
		}
		String[] enrollmentAgeLimitArray = null;
		enrollmentAgeLimitArray = enrollmentAgeLimit.split(",");
		Boolean isAgeValid = OPLUtils.getAgeCriteriaValidation(appMaster.getSchemeId().intValue(), dob, null, enrollmentAgeLimitArray);
		if (Boolean.FALSE.equals(isAgeValid)) {
			String msg = null;
			if (selectedHolder.getSizeOfACHolder() > 1) {
				msg = CommonUtils.AGE_CRITERIA_MULTI;
			} else {
				msg = CommonUtils.AGE_CRITERIA_SINGLE;
			}
			updateAppMasterErro(appMaster, msg, authRes.getUserId());
			return new CommonResponse(msg, ResponseStatus.AGE_IN_VALID_ERROR.getStatusId(), false);
		}
		return null;
	}

	private CommonResponse checkInternalDedup(ApplicationMasterV3 appMaster, String cif, Long userId) {
		String isDedupOn = ConfigProperties.getValues(CommonUtils.IS_DEDUP_ON);
		List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
		List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());
		log.info("IS DEDUP ON---->{} ", isDedupOn);
		if (isDedupOn.equalsIgnoreCase("true") && !isSkipUserIdsLst.contains(userId)) {
			// findFirstByAccountNumberAndCifAndIsActiveTrueAndStageIdInAndSchemeIdOrderByIdDesc
			ApplicationQueryProxy queryProxy = applicationMasterRepo.fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusInAndIdNotIn(appMaster.getSchemeId(), appMaster.getAccountNumber(), cif,inProcessOrCompletedApplication,appMaster.getId());
			if (!OPLUtils.isObjectNullOrEmpty(queryProxy)) {
//				if(Objects.equals(applicationMaster.getApplicationStatus(), ApplicationStatus.OPT_OUT.getId()) || Objects.equals(applicationMaster.getApplicationStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())) {
//					MiscellaneousAudit miscellaneousAudit = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationMaster.getId(),MiscellaneousType.OPT_OUT.getId());
//					if(!OPLUtils.isObjectNullOrEmpty(miscellaneousAudit) && miscellaneousAudit.getDateOfEffective().after(new Date())) {
//						isApplicationExist = Boolean.TRUE;
//					}
//				}else {
//					isApplicationExist = Boolean.TRUE;
//				}
				if (Objects.equals(queryProxy.getApplicationStatus(), ApplicationStatus.ENROLL_IN_PROGRESS.getId())) {
					updateAppMasterErro(appMaster, CommonUtils.ALREADY_ENROLLMENT_INPROCESS, userId);
					return new CommonResponse(
							CommonUtils.ALREADY_ENROLLMENT_INPROCESS,
							ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
				} else if (Objects.equals(queryProxy.getApplicationStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())) {
					updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, userId);
					return new CommonResponse(
							CommonErrorMsg.Enrollment.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER,
							ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
				} else if (Objects.equals(queryProxy.getApplicationStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())) {
					updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_OPT_OUT_ERROR, userId);
					return new CommonResponse(
							CommonUtils.CUSTOMER_ALREADY_OPT_OUT_ERROR,
							ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
				}
			}
		}
		return null;
	}

	private CommonResponse setDeDupeResponse(Integer applicationStatus, ApplicationMasterV3 appMaster, Long userId) {
		if (Objects.equals(applicationStatus, ApplicationStatus.ENROLL_IN_PROGRESS.getId())) {
			return new CommonResponse(CommonUtils.ENROLLMENT_INITIATED_MSG, HttpStatus.BAD_REQUEST.value(), false);
		} else if (Objects.equals(applicationStatus, ApplicationStatus.ENROLL_COMPLETED.getId())
				|| Objects.equals(applicationStatus, ApplicationStatus.OPT_OUT_IN_PROCESS.getId())) {
			return new CommonResponse(CommonErrorMsg.Enrollment.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER,
					HttpStatus.BAD_REQUEST.value(), false);
		}
		return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(),
				Boolean.FALSE);
	}

	private ApplicationMasterV3 saveAccHolderDtl(AccountHolderDetailsResponseV3 wrap, Long applicationId, Long userType,boolean isPhase2) throws ParseException {
		try {
			ApplicationMasterV3 applicationMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);

			// Address
			AddressMasterV3 addressMaster = null;
			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo()) && !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress())) {
				addressMaster = applicationMaster.getApplicantInfo().getAddress();
			} else {
				addressMaster = new AddressMasterV3();
				addressMaster.setAppCreatedDate(applicationMaster.getCreatedDate());
			}
			addressMaster.setAddressLine1(wrap.getAddressline1());
			addressMaster.setAddressLine2(wrap.getAddressline2());
			addressMaster.setCityName(wrap.getCity());
			addressMaster.setCityId(wrap.getCityLGDCode());
			addressMaster.setDistrict(wrap.getDistrict());
			addressMaster.setDistrictLGDCode(wrap.getDistrictLGDCode());
			addressMaster.setStateName(wrap.getState());
			addressMaster.setStateLGDCode(wrap.getStateLGDCode());
			if (!OPLUtils.isObjectNullOrEmpty(wrap.getPincode())) {
				addressMaster.setPincode(wrap.getPincode().intValue());
			}
			// fetch state and city from oneform mappings
			try {
				if (!OPLUtils.isObjectNullOrEmpty(wrap.getPincode())) {
					PincodeMasterResponse pincodeMaster = oneFormClient.getFirstPincodeMasterDetailsByPincode(wrap.getPincode().toString());
					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
						addressMaster.setCityId(pincodeMaster.getCityId());
						addressMaster.setStateId(pincodeMaster.getStateId());
					}
				}
			} catch (Exception e) {
				log.error("Exception is getting While Nominee Pincode Details -------------------> {} and ------------------>  Exception is", wrap.getPincode(), e);
			}

			applicationMaster.getApplicantInfo().setAddress(addressMaster);

			// Account Holder Details
			ApplicantInfo customerDetails = applicationMaster.getApplicantInfo();
			customerDetails.setIfsc(wrap.getCustomerIFSC());
			customerDetails.setGenderId(Gender.fromBankValue(wrap.getGender()).getId());
			customerDetails.setFirstName(wrap.getFirstName());
			customerDetails.setMiddleName(wrap.getMiddleName());
			customerDetails.setLastName(wrap.getLastName());
			customerDetails.setFatherHusbandName(wrap.getFatherHusbandName());
			
			try {
				String mobileNumber = OPLUtils.getValidMobileNumber(wrap.getMobileNumber());
				if (Objects.equals(userType, UserTypeMaster.FUNDSEEKER.getId())) {
					/** this logic added for customer journey */
					if (!OPLUtils.isObjectNullOrEmpty(wrap.getMobileNumber())
							&& Pattern.compile(PatternUtils.MOBILE_PATTERN_91).matcher(mobileNumber).matches()) {
						customerDetails.setMobileNumber(mobileNumber);
					}
				} else {
					customerDetails.setMobileNumber(mobileNumber);
				}
			} catch (Exception e) {
				log.error("Exception is mobile number save in applicant info", e);
			}
			if(isPhase2) {
				customerDetails.setOccupation(wrap.getApplicantOccupation());
				customerDetails.setEmail(wrap.getEmailId());
			}else {
				customerDetails.setEmail(wrap.getEmailAddress());
			}
			customerDetails.setKycId1(wrap.getKycID1());
			customerDetails.setKycIdNumber1(wrap.getKycID1number());
			customerDetails.setKycId2(wrap.getKycID2());
			customerDetails.setKycIdNumber2(wrap.getKycID2number());
			customerDetails.setAadhaar(wrap.getAadhaarNumber());
			customerDetails.setPan(wrap.getPanNumber());
			//			customerDetails.setKycIdNumber3(wrap.getAadhaarNumber());
			customerDetails.setCkyc(wrap.getCkyc());
			customerDetails.setCkycNumber(wrap.getCkycNumber());
			customerDetails.setDob(Date.from(wrap.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()));
			applicationMaster.setApplicantInfo(customerDetails);

			ApplicationMasterOtherDetailsV3 otherDetailsFetch = applicationMaster.getApplicationMasterOtherDetails();

			if (OPLUtils.isObjectNullOrEmpty(otherDetailsFetch)) {
				otherDetailsFetch = new ApplicationMasterOtherDetailsV3();
				otherDetailsFetch.setId(applicationMaster.getId());
			}
			if(isPhase2) {
				otherDetailsFetch.setUserId2(wrap.getBcReferralId());
			}
			otherDetailsFetch.setConsentForAutoDebit(!OPLUtils.isObjectNullOrEmpty(wrap.getConsentForAutoDebit()) ? wrap.getConsentForAutoDebit() : null);
			otherDetailsFetch.setRuralUrbanSemi(!OPLUtils.isObjectNullOrEmpty(wrap.getRuralUrban()) ? wrap.getRuralUrban() : null);
			otherDetailsFetch.setApplicationMaster(applicationMaster);
			applicationMaster.setApplicationMasterOtherDetails(otherDetailsFetch);
			return applicationMaster;
		} catch (Exception e) {
			log.error("Exception is getting While save Account holder Data ", e);
		}
		return null;
	}

	private void saveNomineeDetails(AccountHolderDetailsResponseV3 wrap, ApplicationMasterV3 applicationMaster, Long userId,boolean isPhase2) throws OneFormException {
		NomineeDetails nDtl = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationMaster.getId(), NomineeType.NOMINEE.getId());
		if (OPLUtils.isObjectNullOrEmpty(nDtl)) {
			nDtl = new NomineeDetails();
			nDtl.setCreatedBy(userId);
			nDtl.setCreatedDate(new Date());
			nDtl.setIsActive(true);
			nDtl.setIsOtherClaimant(false);
			nDtl.setAppCreatedDate(applicationMaster.getCreatedDate());
		} else {
			nDtl.setModifiedBy(userId);
			nDtl.setModifiedDate(new Date());
		}
		nDtl.setType(NomineeType.NOMINEE.getId());
		nDtl.setApplicationMaster(applicationMaster);
		if(isPhase2) {
			nDtl.setName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeName()) ? wrap.getNomineeName() : null);
			nDtl.setMobileNumber(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeMobileNumber()) ? wrap.getNomineeMobileNumber() : null);
			nDtl.setEmail(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeEmailId()) ? wrap.getNomineeEmailId() : null);
		}else {
			nDtl.setFirstName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeFirstName()) ? wrap.getNomineeFirstName() : null);
			nDtl.setMiddleName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeMiddleName()) ? wrap.getNomineeMiddleName() : null);
			nDtl.setLastName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeLastName()) ? wrap.getNomineeLastName() : null);
			nDtl.setMobileNumber(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineemobileNumber()) ? wrap.getNomineemobileNumber() : null);
			nDtl.setEmail(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeemailAddress()) ? wrap.getNomineeemailAddress() : null);
		}
		nDtl.setDob(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeDateOfBirth()) ? Date.from(wrap.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()) : null);
		nDtl.setAadhaarNumber(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeaadhaarNumber()) ? wrap.getNomineeaadhaarNumber() : null);
		nDtl.setPanNumber(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineepanNumber()) ? wrap.getNomineepanNumber() : null);
		try {
			if (!OPLUtils.isObjectNullOrEmptyOrNAOrDash(wrap.getRelationOfNominee())) {
				nDtl.setRelationId(RelationShip.fromValue(wrap.getRelationOfNominee()).getId());
			}
		} catch (Exception e) {
			log.error("Exception while getting relationship of nominee id " + wrap.getRelationOfNominee(), e.getMessage());
		}

		AddressMasterV3 addressMaster = nDtl.getAddress();
		if (OPLUtils.isObjectNullOrEmpty(nDtl.getAddress())) {
			addressMaster = new AddressMasterV3();
			addressMaster.setAppCreatedDate(applicationMaster.getCreatedDate());
		}
		if(isPhase2) {
			addressMaster.setAddressLine1(!OPLUtils.isObjectNullOrEmpty(wrap.getAddressofNominee()) ? wrap.getAddressofNominee() : null);
		}else {
			addressMaster.setAddressLine1(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeaddressline1()) ? wrap.getNomineeaddressline1() : null);
			addressMaster.setAddressLine2(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeaddressline2()) ? wrap.getNomineeaddressline2() : null);
		}
		addressMaster.setPincode(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineepincode()) ? wrap.getNomineepincode().intValue() : null);
		addressMaster.setCityName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineecity()) ? wrap.getNomineecity() : null);
		addressMaster.setCityLGDCode(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineecityLGDCode()) ? wrap.getNomineecityLGDCode() : null);
		addressMaster.setDistrict(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineedistrict()) ? wrap.getNomineedistrict() : null);
		addressMaster.setDistrictLGDCode(!OPLUtils.isObjectNullOrEmpty(wrap.getDistrictLGDCode()) ? wrap.getDistrictLGDCode() : null);
		addressMaster.setStateName(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineestate()) ? wrap.getNomineestate() : null);
		addressMaster.setStateLGDCode(!OPLUtils.isObjectNullOrEmpty(wrap.getNomineestateLGDCode()) ? wrap.getNomineestateLGDCode() : null);
		nDtl.setAddress(addressMaster);

		nomineeDetailsRepository.save(nDtl);

		if (!OPLUtils.isObjectNullOrEmpty(wrap.getNomineeDateOfBirth()) && CommonUtils.getAgeBydob(
				Date.from(wrap.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant())) < 18) {
			NomineeDetails nDtl1 = new NomineeDetails();
			nDtl1.setName(wrap.getNameofGuardian());
			try {
				if (!OPLUtils.isObjectNullOrEmptyOrNAOrDash(wrap.getRelationshipofGuardian())) {
					if (isPhase2) {
						nDtl1.setRelationId(RelationShip.fromValue(wrap.getRelationshipOfGuardian()).getId());
					} else {
						nDtl1.setRelationId(RelationShip.fromValue(wrap.getRelationshipofGuardian()).getId());
					}
				}
			} catch (Exception e) {
				log.error("Exception while getting relationship of guardian id " + wrap.getRelationshipofGuardian(), e.getMessage());
			}
			nDtl1.setMobileNumber(!OPLUtils.isObjectNullOrEmpty(wrap.getGuardianMobileNumber()) ? wrap.getGuardianMobileNumber() : null);
			nDtl1.setEmail(!OPLUtils.isObjectNullOrEmpty(wrap.getGuardianEmailId()) ? wrap.getGuardianEmailId() : null);
			nDtl1.setType(NomineeType.GUARDIAN.getId());
			nDtl1.setIsActive(true);
			nDtl1.setAppCreatedDate(applicationMaster.getCreatedDate());
			AddressMasterV3 addressMasterGuardian = new AddressMasterV3();
			addressMasterGuardian.setAddressLine1(!OPLUtils.isObjectNullOrEmpty(wrap.getAddressofGuardian()) ? wrap.getAddressofGuardian() : null);
			addressMasterGuardian.setAppCreatedDate(applicationMaster.getCreatedDate());
			nDtl1.setAddress(addressMasterGuardian);
			nDtl1.setApplicationMaster(applicationMaster);
			nomineeDetailsRepository.save(nDtl1);
		}

	}

	@SuppressWarnings("deprecation")
	private Double getPremiumAmountBasedOnSchemeId(Date createdDate, Long schemeId, Integer source) {
		Integer currentMonth = (createdDate.getMonth() + CommonUtils.INT_1);
		PremiumMaster premiumMaster = null;
		if (!OPLUtils.isObjectNullOrEmpty(source) && source == Source.JANSURAKSHA_DIY.getId()) {
			premiumMaster = premiumMasterRepo.findFirstByTypeAndQuarterNo(PremiumMasterType.CUSTOMER.getId(), CommonUtils.getQuarterNo(currentMonth));
		} else {
			premiumMaster = premiumMasterRepo.findFirstByTypeAndQuarterNo(PremiumMasterType.BANK.getId(), CommonUtils.getQuarterNo(currentMonth));
		}
		Double premiumAmount = null;
		if (Objects.equals(schemeId, com.opl.jns.utils.enums.SchemeMaster.PMJJBY.getId())) {
			premiumAmount = premiumMaster.getPmjjbyPrimium();
		} else if (Objects.equals(schemeId, com.opl.jns.utils.enums.SchemeMaster.PMSBY.getId())) {
			premiumAmount = premiumMaster.getPmsbyPremium();
		}
		return premiumAmount;
	}

	/**
	 * NEED TO DISCUSS
	 */ // ravi test
	public CommonResponse saveApplicationFormDetails(ApplicationMasterRequest req, AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterV3 mst = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());
			if (OPLUtils.isObjectNullOrEmpty(mst)) {
				log.info("application Master Details not founds applicationId--> {}", req.getApplicationId());
				return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			if (OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo())) {
				log.info("Account holder details not founds applicationId--> {}", req.getApplicationId());
				updateStageError(mst.getId(), mst.getStageId(), "Account Details Not Found", req.getUserId());
				return new CommonResponse("Its seems we have not found account holder details from given application number!!", ResponseStatus.BAD_REQUEST.getStatusId());
			}

			boolean isNomineeUpdate = !OPLUtils.isObjectNullOrEmpty(req.getIsNomineeUpdate()) && req.getIsNomineeUpdate();

			// KYC 3 Update code write here
			ApplicantInfo customerDetails = mst.getApplicantInfo();

			customerDetails.setDisabilityStatus(req.getDisabilityStatus()); // added
			customerDetails.setDisabilityDetails(req.getDisabilityDetails());
			customerDetails.setIsNomineeDetailsSameEnroll(req.getIsNomineeDeatilsSameEnroll());

			customerDetails.setIsSameAppAddress(req.getIsSameApplicantAddress());
			mst.setApplicantInfo(customerDetails);
			if (isNomineeUpdate && !OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails())) {
				mst.getLastTransactionDetails().setCoiStorageId(null);				
			}
			if (isNomineeUpdate) {
				mst.setEnrollType(EnrollTypeEnum.ENDORSEMENT.getId());
			}	
			applicationMasterRepo.save(mst);
			if (!OPLUtils.isListNullOrEmpty(req.getNominee())) {

				/**
				 * NOMINEE_UPDATE TIME SET TYPE AS NOMINEE
				 */
				if (isNomineeUpdate) {					
					nomineeDetailsRepository.isActiveFalseByApplicationId(req.getApplicationId(), Arrays.asList(NomineeType.NOMINEE.getId(), NomineeType.GUARDIAN.getId()));
				}

				MiscellaneousAudit miscAudit = null;
				for(NomineeDetailsRequest nomineeDetReq : req.getNominee()) {
					NomineeDetails nomineeMaster = null;
					if (!OPLUtils.isObjectNullOrEmpty(mst.getId())) {
						nomineeMaster = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(mst.getId(), NomineeType.NOMINEE.getId());
					}
					try {
						saveNominee(nomineeMaster, nomineeDetReq, mst, req, isNomineeUpdate, authClientResponse);
					} catch (OneFormException e) {
						log.error("Exception is getting While save nominee data ", e);
					}
				}
			}
			// internal dedupe check
			if (!isNomineeUpdate) {
				CommonResponse isExist = checkInternalDedup(mst, mst.getCif(), authClientResponse.getUserId());
				if (!OPLUtils.isObjectNullOrEmpty(isExist) && Boolean.TRUE.equals(isNomineeUpdate != Boolean.TRUE)) {
					return isExist;
				}
			}
			return new CommonResponse("Data Saved Successfully.", HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting While save insurance data ", e);
		}
		return null;
	}
	
	public CommonResponse saveApplicationFormDetailsNewDb(ApplicationMasterRequest req, AuthClientResponse authClientResponse) {
		try {
			PMSBY pmsby = null;
			PMJJBY pmjjby = null;
			ApplicationMasterBothSchemeProxy mst = null;
			if (Objects.equals(req.getSchemeId(), SchemeMaster.PMSBY.getId())) {
				pmsby = pmsbyRepository.findByIdAndIsActiveTrue(req.getApplicationId());
				if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
					mst = MultipleJSONObjectHelper.getObjectFromObject(pmsby, ApplicationMasterBothSchemeProxy.class);
					mst.setSchemeId(SchemeMaster.PMSBY.getId());
				}
			} else if (Objects.equals(req.getSchemeId(), SchemeMaster.PMJJBY.getId())) {
				pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(req.getApplicationId());
				if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
					mst = MultipleJSONObjectHelper.getObjectFromObject(pmjjby,
							ApplicationMasterBothSchemeProxy.class);
					mst.setSchemeId(SchemeMaster.PMJJBY.getId());
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(mst)) {
				log.info("application Master Details not founds applicationId--> {} schemeId--> {}", req.getApplicationId(),req.getSchemeId());
				return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			ApplicantInfoV2 customerDetails = applicantInfoRepositoryV2.findById(req.getApplicationId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(customerDetails)) {
				log.info("Account holder details not founds applicationId--> {}", req.getApplicationId());
				updateStageError(mst.getId(), mst.getStatus(), "Account Details Not Found", req.getUserId());
				return new CommonResponse("Its seems we have not found account holder details from given application number!!", ResponseStatus.BAD_REQUEST.getStatusId());
			}

			boolean isNomineeUpdate = !OPLUtils.isObjectNullOrEmpty(req.getIsNomineeUpdate()) && req.getIsNomineeUpdate();

			customerDetails.setDisabilityStatus(req.getDisabilityStatus()); // added
			customerDetails.setDisabilityDetails(req.getDisabilityDetails());
			customerDetails.setIsNomineeDetailsSameEnroll(req.getIsNomineeDeatilsSameEnroll());
			customerDetails.setIsSameAppAddress(req.getIsSameApplicantAddress());
			applicantInfoRepositoryV2.save(customerDetails);
			
			
			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findById(mst.getLastTransactionId()).orElse(null);
			if (isNomineeUpdate && !OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
				transactionDetailsRepositoryV2.updateStorageIdInTransaction(null,mst.getLastTransactionId());
			}
			if (isNomineeUpdate) {
				mst.setEnrollType(EnrollTypeEnum.ENDORSEMENT.getId());
				if(Objects.equals(mst.getSchemeId(), SchemeMaster.PMSBY.getId())) {					
					pmsbyRepository.save(pmsby);
				}else if(Objects.equals(mst.getSchemeId(), SchemeMaster.PMJJBY.getId())) {
					pmjjbyRepository.save(pmjjby);
				}
			}
			AddressMasterV2 applicantAddress = addressMasterRepositoryV2.findById(customerDetails.getAddressId()).orElse(null);
			if (!OPLUtils.isListNullOrEmpty(req.getNominee())) {

				/**
				 * NOMINEE_UPDATE TIME SET TYPE AS NOMINEE
				 */
//				if (isNomineeUpdate) {					
//					nomineeDetailsRepositoryV2.isActiveFalseByApplicationId(req.getApplicationId());
//				}

				for(NomineeDetailsRequest nomineeDetReq : req.getNominee()) {
					NomineeDetailsV2 nomineeMaster = null;
					nomineeMaster = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(req.getApplicationId());
					try {
						saveNomineeNewDb(nomineeMaster, nomineeDetReq, mst, req, isNomineeUpdate, authClientResponse,transactionDetailsV2,customerDetails,applicantAddress);
					} catch (OneFormException e) {
						log.error("Exception is getting While save nominee data ", e);
					}
				}
			}
			return new CommonResponse("Data Saved Successfully.", HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting While save insurance data ", e);
		}
		return null;
	}

	public Map<String, Object> setNomineeUpdateEmailParameters(String urn, String insuredName, String schemeName, Date dateOfNomineeUpdate,Integer source) {
		log.info("entry in emailParameters()");
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("insuredName", insuredName);
		emailParameters.put("nameOfScheme", schemeName);
		emailParameters.put("urn", urn);
		emailParameters.put("dateOfNomineeUpdate", DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, dateOfNomineeUpdate));
		emailParameters.put("source", source);
		return emailParameters;
	}

	private MiscellaneousAudit saveNominee(NomineeDetails nomineeMaster, NomineeDetailsRequest nomineeDetReq, ApplicationMasterV3 applicationMaster, ApplicationMasterRequest req, boolean isNomineeUpdate, AuthClientResponse authClientResponse) throws OneFormException {
		if (OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
			nomineeMaster = new NomineeDetails();
			nomineeMaster.setIsActive(Boolean.TRUE);
			nomineeMaster.setCreatedDate(new Date());
			nomineeMaster.setCreatedBy(req.getModifiedBy());
			nomineeMaster.setIsOtherClaimant(false);
			nomineeMaster.setApplicationMaster(applicationMaster);
			nomineeMaster.setType(NomineeType.NOMINEE.getId());
			nomineeMaster.setAppCreatedDate(applicationMaster.getCreatedDate());
		} else {
			nomineeMaster.setModifiedBy(req.getModifiedBy());
			nomineeMaster.setModifiedDate(new Date());
			nomineeMaster.setIsOtherClaimant(false);
		}
		AddressMasterV3 nomneeAddress = null;
		if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())) {
				// Nominee Address phase 2
			if (PhaseMode.checkPhase2(applicationMaster.getOrgId())) {
				if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getAddress()) && !OPLUtils.isObjectNullOrEmpty(nomineeMaster.getAddress().getAddressLine1())) {
					nomneeAddress = nomineeMaster.getAddress();
				} else {
					nomneeAddress = new AddressMasterV3();
					nomneeAddress.setAppCreatedDate(applicationMaster.getCreatedDate());
				}
				nomneeAddress.setAddressLine1(nomineeDetReq.getAddressLine1());
			} else {
				// Nominee Address phase 1
				if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getAddress())) {
					nomneeAddress = nomineeMaster.getAddress();

				} else {
					nomneeAddress = new AddressMasterV3();
					nomneeAddress.setAppCreatedDate(applicationMaster.getCreatedDate());
				}
				nomneeAddress.setAddressLine1(nomineeDetReq.getAddress().getAddressLine1());
				nomneeAddress.setAddressLine2(nomineeDetReq.getAddress().getAddressLine2());
				nomneeAddress.setCityName(nomineeDetReq.getAddress().getCity());
				nomneeAddress.setCityLGDCode(nomineeDetReq.getAddress().getCityLgdCode());
				nomneeAddress.setDistrict(nomineeDetReq.getAddress().getDistrict());
				nomneeAddress.setDistrictLGDCode(nomineeDetReq.getAddress().getDistrictLgdCode());
				nomneeAddress.setStateName(nomineeDetReq.getAddress().getState());
				nomneeAddress.setStateLGDCode(nomineeDetReq.getAddress().getStateLgdCode());
				if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getAddress().getPincode())) {
					nomneeAddress.setPincode(nomineeDetReq.getAddress().getPincode().intValue());
				}
				// fetch state and city from oneform mappings
				try {
					if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getAddress().getPincode())) {
						PincodeMasterResponse pincodeMaster = oneFormClient.getFirstPincodeMasterDetailsByPincode(
								nomineeDetReq.getAddress().getPincode().toString());
						if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
							nomneeAddress.setCityId(pincodeMaster.getCityId());
							nomneeAddress.setStateId(pincodeMaster.getStateId());
						}
					}
				} catch (Exception e) {
					log.error(
							"Exception is getting While Nominee Pincode Details -------------------> {} and ------------------>  Exception is",
							nomineeDetReq.getAddress().getPincode(), e);
				}
			}
		}
	
		nomineeMaster.setAddress(nomneeAddress);

		if (PhaseMode.checkPhase2(applicationMaster.getOrgId())) {
			// Nominee Details Phase 2
			nomineeMaster.setName(nomineeDetReq.getName());
		}else {
			// Nominee Details Phase 1
			nomineeMaster.setFirstName(nomineeDetReq.getFirstName());
			nomineeMaster.setMiddleName(nomineeDetReq.getMiddleName());
			nomineeMaster.setLastName(nomineeDetReq.getLastName());
			nomineeMaster.setName((!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getFirstName()) ? nomineeDetReq.getFirstName() : "") + " " +
								  (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getMiddleName()) ? nomineeDetReq.getMiddleName() : "") + " " +
					 			  (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getLastName()) ? nomineeDetReq.getLastName() : "") );
		}
		nomineeMaster.setCorrectNomineeFirstName(nomineeDetReq.getCorrectNomineeFirstName());
		nomineeMaster.setCorrectNomineeMiddleName(nomineeDetReq.getCorrectNomineeMiddleName());
		nomineeMaster.setCorrectNomineeLastName(nomineeDetReq.getCorrectNomineeLastName());
		nomineeMaster.setDob(nomineeDetReq.getDateOfBirth());
		nomineeMaster.setAadhaarNumber(nomineeDetReq.getAadhaarNumber());
		nomineeMaster.setPanNumber(nomineeDetReq.getPanNumber());
		nomineeMaster.setMobileNumber(nomineeDetReq.getMobileNumber());
		nomineeMaster.setRelationId(nomineeDetReq.getRelationOfNomineeApplicant());
		nomineeMaster.setEmail(nomineeDetReq.getEmailIdOfNominee());
		

		/**
		 * NOMINEE_UPDATE TIME SET TYPE AS NOMINEE
		 */
		if (isNomineeUpdate) {
			nomineeMaster.setType(NomineeType.NOMINEE.getId());
		}

		nomineeMaster = nomineeDetailsRepository.save(nomineeMaster);

		/**
		 * if guardian details object found in database and application save time
		 * request class guardian detail null then already saved guardian set isActive false
		 */
		NomineeDetails nomineeDtl = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationMaster.getId(), NomineeType.GUARDIAN.getId());
		if(OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getNameOfGuardian()) && !OPLUtils.isObjectNullOrEmpty(nomineeDtl)) {
			nomineeDetailsRepository.isActiveFalseByApplicationId(applicationMaster.getId(), Arrays.asList(NomineeType.GUARDIAN.getId()));
		}
		
		if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getNameOfGuardian())) {
			if (OPLUtils.isObjectNullOrEmpty(nomineeDtl)) {
				nomineeDtl = new NomineeDetails();
				nomineeDtl.setIsActive(Boolean.TRUE);
				nomineeDtl.setCreatedDate(new Date());
				nomineeDtl.setCreatedBy(req.getModifiedBy());
				nomineeDtl.setApplicationMaster(applicationMaster);
				nomineeDtl.setAppCreatedDate(applicationMaster.getCreatedDate());
			}
			nomineeDtl.setName(nomineeDetReq.getNameOfGuardian());
			nomineeDtl.setRelationId(nomineeDetReq.getRelationShipOfGuardian());
			nomineeDtl.setMobileNumber(nomineeDetReq.getMobileNumberOfGuardian());
			nomineeDtl.setEmail(nomineeDetReq.getEmailIdOfGuardian());
			nomineeDtl.setType(NomineeType.GUARDIAN.getId());

			AddressMasterV3 guardianAddress = new AddressMasterV3();
			guardianAddress.setAddressLine1(nomineeDetReq.getAddressOfGuardian());
			guardianAddress.setAppCreatedDate(applicationMaster.getCreatedDate());
			nomineeDtl.setAddress(guardianAddress);
			nomineeDetailsRepository.save(nomineeDtl);
		}

		MiscellaneousAudit miscellaneousAudit = null;
		if (isNomineeUpdate) {
			miscellaneousAuditRepository.isActiveFalseByApplicationId(applicationMaster.getId(), MiscellaneousType.NOMINEE_UPDATE.getId());
			miscellaneousAudit = new MiscellaneousAudit();
			miscellaneousAudit.setApplicationId(applicationMaster.getId());
			miscellaneousAudit.setUrn(applicationMaster.getUrn());
			miscellaneousAudit.setNomineeId(nomineeMaster.getId());
			miscellaneousAudit.setAccountNumber(applicationMaster.getAccountNumber());
			miscellaneousAudit.setType(MiscellaneousType.NOMINEE_UPDATE.getId());
			miscellaneousAudit.setCreatedBy(req.getModifiedBy());
			miscellaneousAudit.setCreatedDate(new Date());
			miscellaneousAudit.setModifiedBy(req.getModifiedBy());
			miscellaneousAudit.setCreatedDate(new Date());
			miscellaneousAudit.setIsActive(true);
			miscellaneousAudit = miscellaneousAuditRepository.save(miscellaneousAudit);

			/* GENERATE COI  */
			getCOI(applicationMaster, true);

			/* PUSH APPLICATION */
			applicationMasterService.pushApplication(req.getApplicationId());

			/* SEND EMAIL HERE */
			applicationMasterService.sendCoiToApplicant(req.getApplicationId(),applicationMaster);
		}
		return miscellaneousAudit;
	}
	
	private void saveNomineeNewDb(NomineeDetailsV2 nomineeMaster, NomineeDetailsRequest nomineeDetReq,
			ApplicationMasterBothSchemeProxy applicationMaster, ApplicationMasterRequest req, boolean isNomineeUpdate,
			AuthClientResponse authClientResponse, TransactionDetailsV2 transactionDetailsV2,
			ApplicantInfoV2 applicantInfoV2,AddressMasterV2 applicantAddress) throws OneFormException {
		boolean checkPhase2 = PhaseMode.checkPhase2(applicationMaster.getOrgId());
		if (OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
			nomineeMaster = new NomineeDetailsV2();
			nomineeMaster.setId(nomineeDetailsRepositoryV2.getNextValMySequence());
			nomineeMaster.setApplicationId(applicationMaster.getId());
			nomineeMaster.setIsActive(Boolean.TRUE);
		} else {
			nomineeMaster.setModifiedBy(req.getModifiedBy());
			nomineeMaster.setModifiedDate(new Date());
		}
		nomineeMaster.setIsOtherClaimant(false);
		nomineeMaster.setMobileNumber(nomineeDetReq.getMobileNumber());
		nomineeMaster.setRelationId(nomineeDetReq.getRelationOfNomineeApplicant());
		nomineeMaster.setEmail(nomineeDetReq.getEmailIdOfNominee());

		NomineePIDetails nomineePIDtl = null;
		if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getId())) {
			nomineePIDtl = nomineePIDetailsRepository.findById(nomineeMaster.getId()).orElse(null);
		}
		if (OPLUtils.isObjectNullOrEmpty(nomineePIDtl)) {
			nomineePIDtl = new NomineePIDetails();
			nomineePIDtl.setId(nomineeMaster.getId());
			nomineePIDtl.setEnrollmentDate(new Date());
		}

		AddressMasterV2 nomneeAddress = null;
		AddressMasterV2 addressMasterV2 = null;
		if (!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getAddressId())) {
			addressMasterV2 = addressMasterRepositoryV2.findById(nomineeMaster.getAddressId()).orElse(null);
		}
		/** NOMINEE ADDRESS PHASE 2 */
		if (checkPhase2) {
			if (!OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
				nomneeAddress = addressMasterV2;
			} else {
				nomneeAddress = new AddressMasterV2();
				nomneeAddress.setId(addressMasterRepositoryV2.getNextValMySequence());
			}
			nomineePIDtl.setAddressLine1(nomineeDetReq.getAddressLine1());
			nomineeMaster.setAddressId(nomneeAddress.getId());
		} else {
			/** NOMINEE ADDRESS PHASE 1 */
			if (!OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
				nomneeAddress = addressMasterV2;

			} else {
				nomneeAddress = new AddressMasterV2();
				nomneeAddress.setId(addressMasterRepositoryV2.getNextValMySequence());			
				}
			nomineeMaster.setAddressId(nomneeAddress.getId());
			nomineePIDtl.setAddressLine1(nomineeDetReq.getAddress().getAddressLine1());
			nomineePIDtl.setAddressLine2(nomineeDetReq.getAddress().getAddressLine2());
			nomneeAddress.setCityName(nomineeDetReq.getAddress().getCity());
			nomneeAddress.setCityLGDCode(nomineeDetReq.getAddress().getCityLgdCode());
			nomneeAddress.setDistrict(nomineeDetReq.getAddress().getDistrict());
			nomneeAddress.setDistrictLGDCode(nomineeDetReq.getAddress().getDistrictLgdCode());
			nomneeAddress.setStateName(nomineeDetReq.getAddress().getState());
			nomneeAddress.setStateLGDCode(nomineeDetReq.getAddress().getStateLgdCode());
			if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getAddress().getPincode())) {
				nomneeAddress.setPincode(nomineeDetReq.getAddress().getPincode());
			}
			/** FETCH STATE AND CITY ONEFORM THROUGH */
			try {
				if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getAddress().getPincode())) {
					PincodeMasterResponse pincodeMaster = oneFormClient
							.getFirstPincodeMasterDetailsByPincode(nomineeDetReq.getAddress().getPincode().toString());
					if (!OPLUtils.isObjectNullOrEmpty(pincodeMaster)) {
						nomneeAddress.setCityId(pincodeMaster.getCityId());
						nomneeAddress.setStateId(pincodeMaster.getStateId());
					}
				}
			} catch (Exception e) {
				log.error(
						"Exception is getting While Nominee Pincode Details -------------------> {} and ------------------>  Exception is",
						nomineeDetReq.getAddress().getPincode(), e);
			}
		}

		if (checkPhase2) {
			/** NOMINEE DETAILS PHASE 2 */
			nomineePIDtl.setName(nomineeDetReq.getName());
		} else {
			/** NOMINEE DETAILS PHASE 1 */
			nomineePIDtl.setFirstName(nomineeDetReq.getFirstName());
			nomineePIDtl.setMiddleName(nomineeDetReq.getMiddleName());
			nomineePIDtl.setLastName(nomineeDetReq.getLastName());
			nomineePIDtl.setName(
					(!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getFirstName()) ? nomineeDetReq.getFirstName() : "")
							+ " "
							+ (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getMiddleName())
									? nomineeDetReq.getMiddleName()
									: "")
							+ " "
							+ (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getLastName()) ? nomineeDetReq.getLastName()
									: ""));
		}
		nomineePIDtl.setDob(nomineeDetReq.getDateOfBirth());

		/** SET GUARDIAN DETAILS AND ADDRESS */
		setGuardianDetails(nomineeMaster, nomineePIDtl, nomineeDetReq);

		ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationMaster.getId())
				.orElse(null);
			if(OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
				applicantPIDetails = new ApplicantPIDetails();
				applicantPIDetails.setId(applicationMaster.getId());
				applicantPIDetails.setEnrollmentDate(new Date());
			}
		if(checkPhase2) {			
			applicantPIDetails.setAcHolderName(req.getAccountHolderName());
			applicantPIDetails.setDob(req.getDob());
			applicantPIDetails.setAddressLine1(req.getAddress().getAddressLine1());
			applicantPIDetails.setAddressLine2(req.getAddress().getAddressLine2());
			applicantPIDetails.setKycId1(req.getKycId1());
			applicantPIDetails.setKycIdNumber1(req.getKycId1number());
			applicantPIDetails.setAccountNumber(req.getAccountNo());
			applicantPIDetailsRepository.save(applicantPIDetails);
		}
		
        /**AFTER PUSH JNS MASTER NOMINEE UPDATE FLAG SET FALSE*/
		ereCommonService.setNomineePushFlagFalse(applicationMaster.getId());
		
		if (isNomineeUpdate) {
			/** SAVE MISCELLANEOUS AUDIT DATA */
			saveMiscellaneousAuditData(req, applicantPIDetails, applicationMaster, nomineeMaster);

			/** GENERATE COI */
			getCOINewDb(applicationMaster, transactionDetailsV2, applicantInfoV2, applicantPIDetails, nomineeMaster,
					nomineePIDtl, applicantAddress,true);

			/** PUSH APPLICATION */
			applicationMasterService.pushNomineeUpdateApplication(req.getApplicationId(),req.getSchemeId());

			/** SEND EMAIL HERE */
			applicationMasterService.sendCoiToApplicantNewDb(applicationMaster, transactionDetailsV2, applicantInfoV2,
					applicantPIDetails, nomineeMaster, nomineePIDtl, applicantAddress);

			/** CALL WEBHOOK FOR BANK AND INSURER NOMINEE UPDATE STATUS */
			if (checkPhase2) {
				try {
					callWebhookForPushNomineeUpdateStatusBankAndInsurer(applicationMaster, nomineeMaster, nomineePIDtl, authClientResponse);
				} catch (Exception e) {
					log.error("Exception is getting While webhook nominee update status ", e);
				}
			}
			addressMasterRepositoryV2.save(nomneeAddress);
			nomineeDetailsRepositoryV2.save(nomineeMaster);
			nomineePIDetailsRepository.save(nomineePIDtl);
		}
	}
	
	public void setGuardianDetails(NomineeDetailsV2 nomineeMaster,NomineePIDetails nomineePIDtl, NomineeDetailsRequest nomineeDetReq) {
		if (!OPLUtils.isObjectNullOrEmpty(nomineeDetReq.getNameOfGuardian())) {
			nomineePIDtl.setGdName(nomineeDetReq.getNameOfGuardian());
			nomineeMaster.setGdRelationId(nomineeDetReq.getRelationShipOfGuardian());
			nomineeMaster.setGdMobile(nomineeDetReq.getMobileNumberOfGuardian());
			nomineeMaster.setGdEmail(nomineeDetReq.getEmailIdOfGuardian());
			nomineePIDtl.setGdAddress(nomineeDetReq.getAddressOfGuardian());
		}
	}
	
	public void saveMiscellaneousAuditData(ApplicationMasterRequest req,ApplicantPIDetails applicantPIDetails,ApplicationMasterBothSchemeProxy applicationMaster,NomineeDetailsV2 nomineeMaster) {
		miscellaneousAuditRepository.isActiveFalseByApplicationId(applicationMaster.getId(), MiscellaneousType.NOMINEE_UPDATE.getId());
		MiscellaneousAudit miscellaneousAudit = new MiscellaneousAudit();
		miscellaneousAudit.setApplicationId(applicationMaster.getId());
		miscellaneousAudit.setUrn(applicationMaster.getUrn());
		miscellaneousAudit.setNomineeId(nomineeMaster.getId());
		miscellaneousAudit.setAccountNumber(applicantPIDetails.getAccountNumber());
		miscellaneousAudit.setType(MiscellaneousType.NOMINEE_UPDATE.getId());
		miscellaneousAudit.setCreatedBy(req.getModifiedBy());
		miscellaneousAudit.setCreatedDate(new Date());
		miscellaneousAudit.setIsActive(true);
		miscellaneousAuditRepository.save(miscellaneousAudit);
	}
	
	public void callWebhookForPushNomineeUpdateStatusBankAndInsurer(ApplicationMasterBothSchemeProxy applicationMaster,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,
			AuthClientResponse authClientResponse) {

		/** PREPARE NOMINEE UPDATE STATUS REQUEST */
		NomineeUpdateStatusRequest nomineeUpdateStatusReq = prepareNomineeUpdateStatusRequest(applicationMaster,nomineeDetailsV2,nomineePIDetails);

		/** BANK WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		if(OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource())) {			
			nomineeUpdateStatus(nomineeUpdateStatusReq, authClientResponse);
		}

		/** INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		nomineeUpdateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
		nomineeUpdateStatusReq.setIsInsurer(true);
		nomineeUpdateStatus(nomineeUpdateStatusReq, authClientResponse);
	}
	
	public NomineeUpdateStatusRequest prepareNomineeUpdateStatusRequest(
			ApplicationMasterBothSchemeProxy applicationMaster, NomineeDetailsV2 nomineeDetailsV2,
			NomineePIDetails nomineePIDetails) {
		NomineeUpdateStatusRequest nomineeUpdateStatusReq = new NomineeUpdateStatusRequest();
		nomineeUpdateStatusReq.setApplicationId(applicationMaster.getId());
		nomineeUpdateStatusReq.setOrgId(applicationMaster.getOrgId());
		nomineeUpdateStatusReq.setUrn(applicationMaster.getUrn());
		nomineeUpdateStatusReq.setNomineeUpdateFlag("YES");
		nomineeUpdateStatusReq.setNomineeName(nomineePIDetails.getName());
		nomineeUpdateStatusReq.setNomineeDateOfBirth(!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getDob())
				? nomineePIDetails.getDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		nomineeUpdateStatusReq.setNomineeMobileNumber(nomineeDetailsV2.getMobileNumber());
		nomineeUpdateStatusReq.setNomineeEmailId(nomineeDetailsV2.getEmail());
		nomineeUpdateStatusReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getRelationId())
				? RelationShip.fromId(nomineeDetailsV2.getRelationId()).getValue()
				: null);
		nomineeUpdateStatusReq.setAddressOfNominee(nomineePIDetails.getAddressLine1());
		nomineeUpdateStatusReq.setNameOfGuardian(nomineePIDetails.getGdName());
		nomineeUpdateStatusReq.setAddressOfGuardian(nomineePIDetails.getGdAddress());
		nomineeUpdateStatusReq.setRelationshipOfGuardian(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getGdRelationId())
				? RelationShip.fromId(nomineeDetailsV2.getGdRelationId()).getValue()
				: null);
		nomineeUpdateStatusReq.setGuardianMobileNumber(nomineeDetailsV2.getGdMobile());
		nomineeUpdateStatusReq.setGuardianEmailId(nomineeDetailsV2.getGdEmail());
		return nomineeUpdateStatusReq;
	}

	public InsurerMstDetailsRequest getAccountHolderAndInsurerDetails(Long applicationId) throws InsuranceException {
		InsurerMstDetailsRequest req = new InsurerMstDetailsRequest();
//		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
		ApplicationQueryProxy appMaster = applicationMasterRepo.fetchAccountNoSchemeIdOrgIdByAppId(applicationId);
		req.setCustomerAccountNumber(appMaster.getAccountNumber());
		if (!OPLUtils.isObjectNullOrEmpty(appMaster)) {
			InsurerMstDetailsV3 mst = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(appMaster.getSchemeId().longValue(), appMaster.getOrgId(), new Date(), new Date());
			if (!OPLUtils.isObjectNullOrEmpty(mst)) {
				String organizationName = usersClient.getOrganizationName(mst.getInsurerOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
					req.setNameOfInsurerStr(organizationName);
				}
				req.setAssociatedAccNo(OPLUtils.convertToMask(mst.getAssociatedAccNo(), 4, "X"));
				req.setAssociatedIfscCode(mst.getAssociatedIfscCode());
			}
		}
		return req;
	}

	@Override
	public PremiumPopupRequest getPremiumPopupDetails(Long applicationId) throws Exception {
		PremiumPopupRequest req = new PremiumPopupRequest();
		ApplicationQueryProxy mst = applicationMasterRepo.fetchAccountNumberApplicantInfoFirstNameMiddleNameLastNameSchemeIdApplicationMasterOtherDetailsSourceById(applicationId);
		if (!OPLUtils.isObjectNullOrEmpty(mst)) {
			req.setApplicationId(applicationId);
			req.setCustomerAccountNumber(mst.getAccountNumber());
			req.setCustomerFullName((!OPLUtils.isObjectNullOrEmpty(mst.getFirstName()) ? mst.getFirstName() : "") + " " + (!OPLUtils.isObjectNullOrEmpty(mst.getMiddleName()) ? mst.getMiddleName() : "") + " "
					+ (!OPLUtils.isObjectNullOrEmpty(mst.getLastName()) ? mst.getLastName() : ""));

			Double premiumDtl = req.getPremiumAmount();
			if (OPLUtils.isObjectNullOrEmpty(premiumDtl)) {
				Long schemeId = OPLUtils.isObjectNullOrEmpty(mst.getSchemeId()) ? null : mst.getSchemeId().longValue();
				premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), schemeId, mst.getSource());
			}
			req.setPolicyEndYear(CommonUtils.getPolicyYear());
			req.setPremiumAmount(premiumDtl);
		}

		return req;
	}
	
	public PremiumPopupRequest getPremiumPopupDetails_old(Long applicationId) throws Exception {
		PremiumPopupRequest req = new PremiumPopupRequest();
		ApplicationMasterV3 mst = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
		if (!OPLUtils.isObjectNullOrEmpty(mst)) {
			req.setApplicationId(mst.getId());
			req.setCustomerAccountNumber(mst.getAccountNumber());
			if (OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo())) {
				req.setCustomerFullName((!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getFirstName()) ? mst.getApplicantInfo().getFirstName() : "") + " "
						+ (!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getMiddleName()) ? mst.getApplicantInfo().getMiddleName() : "") + " "
						+ (!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getLastName()) ? mst.getApplicantInfo().getLastName() : ""));
			}
			Double premiumDtl = req.getPremiumAmount();
			if (OPLUtils.isObjectNullOrEmpty(premiumDtl)) {
				Long schemeId = OPLUtils.isObjectNullOrEmpty(mst.getSchemeId()) ? null : mst.getSchemeId().longValue();
				premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), schemeId, mst.getApplicationMasterOtherDetails().getSource());
			}
			req.setPolicyEndYear(CommonUtils.getPolicyYear());
			req.setPremiumAmount(premiumDtl);
		}
		return req;
	}

	@Override
	public CommonResponse premiumDeduction(ApplicationMasterRequest req, AuthClientResponse authClientResponse) {
		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.info("Application Master Details not founds applicationId--> {}", req.getApplicationId());
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		if(!Arrays.asList(EnrollStageMaster.APPLICATION_FORM.getStageId(), 
				EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId()).contains(appMaster.getStageId())) {
			return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}

		/**INSERT PREMIUM DEDUCTION CONSENT MAPPING FOR ONLY BORROWER USER*/
		if(Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {			
			insertConsentMapping(appMaster.getSchemeId(),appMaster.getId(),authClientResponse.getUserId());
		}
		
		try {
			InsurerMstDetailsV3 insurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(appMaster.getSchemeId().longValue(), appMaster.getOrgId(), new Date(), new Date());
			if (OPLUtils.isObjectNullOrEmpty(insurerDetails)) {
				updateStageError(appMaster.getId(), appMaster.getStageId(), "Insurer details not found", req.getUserId());
				log.info("Insurer details not found --> " + req.getSchemeId() + "------------>" + appMaster.getOrgId());
				return new CommonResponse("Its seems we have not found insurer details for you bank, please try after sometime!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}
			
			/*ApiData apiData = deDupeRegistryUtility.callCheckDedupeRequest(appMaster, authClientResponse, null, DeDupeApiCallType.PREMIUM_DEDUCTION);
			if (apiData.getIsMatched().equalsIgnoreCase("Y")) {
				updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authClientResponse.getUserId());
				return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.BAD_REQUEST.getStatusId(), false);
			} else if (apiData.getIsMatched().equalsIgnoreCase("E")) {
				updateAppMasterErro(appMaster, apiData.getMessage(), authClientResponse.getUserId());
				return new CommonResponse(apiData.getMessage(), ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}*/

			PremiumDeductionResponse prmDetRes = callPremiumDeduction(req,  authClientResponse,appMaster,insurerDetails);
			if (!OPLUtils.isObjectNullOrEmpty(prmDetRes)) {
				if (OPLUtils.isObjectNullOrEmpty(prmDetRes.getStatus()) || (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getStatus()) && (prmDetRes.getStatus() != HttpStatus.OK.value()))
						|| (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getFlag()) && prmDetRes.getFlag().equals(Boolean.FALSE))) {

					/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
					appMaster.setMessage(prmDetRes.getMessage());
					premiumDeductionFailedStageUpdate(appMaster, req.getUserId(),Boolean.FALSE,null);
//					prmDetRes = runPremiumDeduction(appMaster.getId(),  authClientResponse, appMaster,insurerDetails);
					if ((!OPLUtils.isObjectNullOrEmpty(prmDetRes.getFlag()) && Boolean.FALSE.equals(prmDetRes.getFlag())) || prmDetRes.getStatus() != HttpStatus.OK.value()) {
						if (Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDSEEKER.getId())) {
							prmDetRes.setMessage("Transaction Failed - "+(!OPLUtils.isObjectNullOrEmpty(prmDetRes.getMessage()) ?prmDetRes.getMessage():"")+". Please contact your home branch.");
						}

						updateStageError(appMaster.getId(), appMaster.getStageId(), prmDetRes.getMessage(), req.getUserId());

						/* If Return Than We have to Save App Master */
						applicationMasterRepo.save(appMaster);
						return new CommonResponse(prmDetRes.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
					}					
				}
				/* RESPONSE CLASS VALIDATION */
				StringBuilder validateResponse = validateResponse(prmDetRes);
				if(!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
					premiumDeductionFailedStageUpdate(appMaster, req.getUserId(),Boolean.TRUE,validateResponse.toString());
					return new CommonResponse(validateResponse.toString(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
				}
				
				if(PhaseMode.checkPhase2(appMaster.getOrgId())){
					 /* DEBIT STATUS  */				
					if (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getDebitStatus()) && ((!DebitStatus.SUCEESSFUL_DEBIT.getId().equals(Integer.parseInt(prmDetRes.getDebitStatus()))) &&
							(!DebitStatus.DUE_TO_API_FAILURE.getId().equals(Integer.parseInt(prmDetRes.getDebitStatus()))))) {
						log.info("applicationMaster.getStatusChangeDate().toString() --->  '{}'", prmDetRes.getDebitStatus());
						ApplicationMasterRequestV2 appMasterReqV2 = new ApplicationMasterRequestV2();
						appMasterReqV2.setStageId(EnrollStageMaster.REJECTED.getStageId());
						appMasterReqV2.setApplicationId(appMaster.getId());
						appMasterReqV2.setDebitStatus(Integer.valueOf(prmDetRes.getDebitStatus()));
						CommonResponse response=applicationMasterService.updateStage(appMasterReqV2, authClientResponse);
						if(!OPLUtils.isObjectNullOrEmpty(response)) {
							applicationMasterRepo.updateDebitStatusByApplicationId(Integer.valueOf(prmDetRes.getDebitStatus()),DebitStatus.fromId(Integer.valueOf(prmDetRes.getDebitStatus())).getValue(),appMaster.getId());
						}
						return new CommonResponse("Enrolment Rejected - " + "(" + DebitStatus.fromId(Integer.valueOf(prmDetRes.getDebitStatus())).getValue() +")" , HttpStatus.NOT_ACCEPTABLE.value(), Boolean.FALSE);
					}
					
					if (DebitStatus.DUE_TO_API_FAILURE.getId().equals(Integer.parseInt(prmDetRes.getDebitStatus()))) {
						appMaster.setDebitStatus(Integer.valueOf(prmDetRes.getDebitStatus()));
						premiumDeductionFailedStageUpdate(appMaster, req.getUserId(),Boolean.TRUE,DebitStatus.fromId(Integer.valueOf(prmDetRes.getDebitStatus())).getValue());
						return new CommonResponse("Error occured - Please resume the journey from Transaction Failed", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
					}
				}
				
				if (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getTransactionAmount()) && prmDetRes.getTransactionAmount().equals("0")) {
					/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
					premiumDeductionFailedStageUpdate(appMaster, req.getUserId(),Boolean.TRUE,"Invalid Transaction Amount. Value must be non-zero numeric value.");
					return new CommonResponse("Invalid Transaction Amount. Value must be non-zero numeric value.", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
				}
				
				
				if (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getTransactionTimeStamp())) {
					try {
						Date transTimeStemp =null;
						if(PhaseMode.checkPhase2(appMaster.getOrgId())) {
							transTimeStemp = CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss
									.parse(prmDetRes.getTransactionTimeStamp());	
						}else {
							transTimeStemp = CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS
									.parse(prmDetRes.getTransactionTimeStamp());
						}
						

						if (OPLUtils.isObjectNullOrEmpty(transTimeStemp)) {
							/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
							premiumDeductionFailedStageUpdate(appMaster, req.getUserId(), Boolean.TRUE,"transactionTimeStamp date format is invalid");
							return new CommonResponse("transactionTimeStamp date format is invalid",
									HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
						}
						
						/** if transactionTimeStamp date is before policy start date then fail application */
						if (!OPLUtils.isObjectNullOrEmpty(insurerDetails.getPolicyStartDate()) && transTimeStemp.before(insurerDetails.getPolicyStartDate())) {
							/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
							premiumDeductionFailedStageUpdate(appMaster, req.getUserId(), Boolean.TRUE,"Transaction date cannot be before the policy year date. Kindly provide valid transaction time stamp.");
							return new CommonResponse("Transaction date cannot be before the policy year date. Kindly provide valid transaction time stamp.",
									HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
						}

						/** if transactionTimeStamp date is after current date then fail application */
						if (transTimeStemp.after(new Date())) {
							/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
							premiumDeductionFailedStageUpdate(appMaster, req.getUserId(), Boolean.TRUE,"Transaction date cannot be future dated. Kindly provide valid transaction time stamp.");
							return new CommonResponse("Transaction date cannot be future dated. Kindly provide valid transaction time stamp.",
									HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
						}
					} catch (Exception e) {
						log.error("transactionTimeStamp  format is invalid : {} ", e);

						/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
						premiumDeductionFailedStageUpdate(appMaster, req.getUserId(), Boolean.TRUE,"transactionTimeStamp date format is invalid");
						return new CommonResponse("transactionTimeStamp date format is invalid",
								HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
					}

				}
				
				/* SAVE PREMIUM DEDUCTION DATA Along WITH AppMaster 
				 *  Inside Method any error occurred than we stop */
				return savePremiumDeductionData(prmDetRes, appMaster, req.getUserId(), insurerDetails, authClientResponse, Boolean.FALSE);

			}

			/* UPDATE ENROLLMENT STAGE ID FOR PREMIUM DEDUCTION FAILED */
			premiumDeductionFailedStageUpdate(appMaster, req.getUserId(),Boolean.TRUE,"Unable to deduct premium due to error from bank");
			updateStageError(appMaster.getId(), appMaster.getStageId(), "Error while Premium deduction", req.getUserId());
			return new CommonResponse("Unable to deduct premium due to error from bank", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			
		} catch (Exception e) {
			updateStageError(appMaster.getId(), appMaster.getStageId(), e.getMessage(), req.getUserId());
			log.error("Exception is getting While save Premium data ", e);
			return new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	public void insertConsentMapping(Integer schemeId,Long applicationId,Long userId) {
			try {				
				if(schemeId==SchemeMaster.PMSBY.getId().longValue()) {			
					ereCommonService.insertDataConsentMappingTable(ConsentMappingProxy.builder().appTypeValue(applicationId).appType(ApplicationType.APPLICATION.getId()).userId(userId).consentTypeId(ConsentType.DIY_PREMIUM_PMSBY.getId()).build());
				}else {
					ereCommonService.insertDataConsentMappingTable(ConsentMappingProxy.builder().appTypeValue(applicationId).appType(ApplicationType.APPLICATION.getId()).userId(userId).consentTypeId(ConsentType.DIY_PREMIUM_PMJJBY.getId()).build());
				}
			}catch (Exception e) {
				log.info("ERROR WHILE SAVE CONSENT--> {}", applicationId);
			}
	}
	
	public void premiumDeductionFailedStageUpdate(ApplicationMasterV3 appMaster, Long userId,Boolean isSave,String failedMsg) {
		appMaster.setModifiedDate(new Date());
		appMaster.setModifiedBy(userId);
		appMaster.setStatusChangeDate(new Date());
		appMaster.setStageId(EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId());
		appMaster.setMessage(failedMsg);
		if (Boolean.TRUE.equals(isSave))
			applicationMasterRepo.save(appMaster);
		}
	
	
	public CommonResponse savePremiumDeductionData(PremiumDeductionResponse prmDetRes, ApplicationMasterV3 appMaster, Long userId, InsurerMstDetailsV3 insurerDetails, AuthClientResponse authClientResponse, Boolean isUpdateManually) throws Exception {
		try {
			
			TransactionDetailsV3 transactionDetails = getTransactionDetails(appMaster,userId,isUpdateManually,insurerDetails,prmDetRes);
			if(OPLUtils.isObjectNullOrEmpty(transactionDetails))
				return new CommonResponse("Unable to deduct premium due to details did not saved", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);

			/* updating History */
			//		masterServiceV2.updateApplicationHistory(appMaster);

			/* saving last transaction */
			appMaster.setPremiumAmount(transactionDetails.getTransAmount());
			appMaster.setInsurerOrgId(!OPLUtils.isObjectNullOrEmpty(insurerDetails.getInsurerOrgId()) ? insurerDetails.getInsurerOrgId() : null);
			appMaster.setLastTransactionDetails(transactionDetails);
			if(PhaseMode.checkPhase2(appMaster.getOrgId())){
				appMaster.setDebitStatus(Integer.valueOf(prmDetRes.getDebitStatus()));	
			}			
			
			/*  AFTER SUCCESS PREMIUM DEDUCTION UPDATE ENROLLMENT DATE AND COVER END DATE*/
			Date enrlDate = new Date();
			appMaster.setEnrollmentDate(transactionDetails.getTransTimeStamp());
			appMaster.setStatusChangeDate(enrlDate);
			//appMaster.getLastTransactionDetails().setCoverEndDate(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(CommonUtils.COVER_END_DATE) + CommonUtils.getPolicyYear() + "T23:59:59.999"));
			appMaster.getLastTransactionDetails().setCoverEndDate(insurerDetails.getPolicyEndDate());
			appMaster.getLastTransactionDetails().setCoverStartDate(transactionDetails.getTransTimeStamp());

			/*  UPDATE INSURANCE MASTER ID */
			appMaster.setStageId(EnrollStageMaster.PREMIUM_DEDUCTION.getStageId());
			appMaster.setModifiedDate(new Date());
			appMaster.setModifiedBy(userId);
			appMaster.getApplicationMasterOtherDetails()
					.setUserId1(Objects.equals(appMaster.getApplicationMasterOtherDetails().getSource(),
							Source.JANSURAKSHA_DIY.getId()) ? authClientResponse.getUserName()
									: authClientResponse.getEmail());

			/* UPLOAD COI */
			byte[] coi = getCOI(appMaster, true);
			if(coi != null) {
				applicationMasterRepo.save(appMaster);	
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception while saving Premium Deduction Data ------>", e);
		}
		premiumDeductionFailedStageUpdate(appMaster, userId,Boolean.TRUE,"Unable to deduct premium due to data or COI Generation failed.");
		return new CommonResponse("Unable to deduct premium due to data", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}



	private TransactionDetailsV3 getTransactionDetails(ApplicationMasterV3 appMaster, Long userId, Boolean isUpdateManually, InsurerMstDetailsV3 insurerDetails, PremiumDeductionResponse prmDetRes) {
		try {
			// Update Transaction details
			TransactionDetailsV3 transactionDetails = transactionRepo.findFirstByApplicationMasterIdAndTypeAndIsActiveTrue(appMaster.getId(), CommonUtils.TYPE_ENROLLMENT);
			Date curruntDate = new Date();
			if (OPLUtils.isObjectNullOrEmpty(transactionDetails)) {
				transactionDetails = new TransactionDetailsV3();
				transactionDetails.setCreatedBy(userId);
				transactionDetails.setCreatedDate(curruntDate);
				transactionDetails.setAppCreatedDate(appMaster.getCreatedDate());
			} else {
				transactionDetails.setModifiedBy(userId);
				transactionDetails.setModifiedDate(curruntDate);
			}
			transactionDetails.setIsUpdateManually(isUpdateManually);
			transactionDetails.setApplicationMaster(appMaster);
			transactionDetails.setInsurerMaster(insurerDetails);
			transactionDetails.setInsurerOrgId(insurerDetails.getInsurerOrgId());
			transactionDetails.setInsurerCode(insurerDetails.getInsurerCode());			
			transactionDetails.setTransUtr(prmDetRes.getTransactionUTR());

			Date date = null;
			if(PhaseMode.checkPhase2(appMaster.getOrgId())) {
				date = CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss
						.parse(prmDetRes.getTransactionTimeStamp());	
			}else {
				date = CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS
						.parse(prmDetRes.getTransactionTimeStamp());
			}
			transactionDetails.setYear(date.getYear()+CommonUtils.INT_1900);

			transactionDetails.setTransTimeStamp(date);
			transactionDetails.setTransComment(prmDetRes.getComment());
			transactionDetails.setType(TransactionTypeEnum.ENROLLMENT.getId());
			if (!OPLUtils.isObjectNullOrEmpty(prmDetRes.getTransactionAmount())) {
				transactionDetails.setTransAmount(Double.parseDouble(prmDetRes.getTransactionAmount()));
			}
			transactionDetails.setMasterPolicyNo(insurerDetails.getMasterPolicyNo());
			transactionDetails.setIsActive(Boolean.TRUE);
			
			return transactionDetails;
//			return transactionDetails = transactionRepo.save(transactionDetails);
			
		} catch (Exception e) {
			log.error(" TransactionDetails Details Did not Save  Error---",e);
			log.error(" TransactionDetails Details Did not Save  AppId---",appMaster.getId());
		}
		return null;
	}

	@Override
	public COIRequest getCOIData(Long applicationId) {
		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.error("APPLICATION MASTER IS NULL OR EMPTY ----------->" + applicationId);
			return null;
		}
		return getCOIData(appMaster);
	}

	private COIRequest getCOIData(ApplicationMasterV3 appMaster) {
		COIRequest coiReq = ereCommonService.generateCOIRequest(appMaster);
		if (OPLUtils.isObjectNullOrEmpty(coiReq)) {
			log.error("FOUND COI REQUEST IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		coiReq = pdfGenerateClient.setCOIOtherDetails(coiReq);
		return coiReq;
	}
	
	@Override
	public COIRequest getCOIDataNewDb(CertificateInsDtlRequest request) throws IOException {
		ApplicationMasterBothSchemeProxy appMaster = ereCommonService
				.getJnsMasterDataApplicationMaster(request.getSchemeId().longValue(), request.getApplicationId());
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.error("APPLICATION MASTER IS NULL OR EMPTY ----------->" + request.getApplicationId());
			return null;
		}
		TransactionDetailsV2 transDtl = transactionDetailsRepositoryV2.findById(appMaster.getLastTransactionId()).orElse(null);
		if (OPLUtils.isObjectNullOrEmpty(transDtl)) {
			log.error("TRANSACTION DETAILS IS NULL OR EMPTY ----------->" + appMaster.getLastTransactionId());
			return null;
		}
		ApplicantInfoV2 applicantInfo = applicantInfoRepositoryV2.findById(appMaster.getId()).orElse(null);
		if (OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
			log.error("APPLICANT INFO IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(appMaster.getId()).orElse(null);
		if (OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
			log.error("APPLICANT PI DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		NomineeDetailsV2 nomineeDetailsV2 = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appMaster.getId());
		if (OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2)) {
			log.error("NOMINEE DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		NomineePIDetails nomineePIDetails = nomineePIDetailsRepository.findById(nomineeDetailsV2.getId()).orElse(null);
		if (OPLUtils.isObjectNullOrEmpty(nomineePIDetails)) {
			log.error("NOMINEE PI DETAILS IS NULL OR EMPTY ----------->" + nomineeDetailsV2.getId());
			return null;
		}
		AddressMasterV2 addressMasterV2 = addressMasterRepositoryV2.findById(applicantInfo.getAddressId()).orElse(null);
		if (OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
			log.error("APPLICANT PI DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		return getCOIDataNewDb(appMaster,transDtl,applicantInfo,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,addressMasterV2);
	}

	private COIRequest getCOIDataNewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantInfoV2,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 applicantAddress) {
		COIRequest coiReq = ereCommonService.generateCOIRequestNewDb(appMaster,transactionDetailsV2,applicantInfoV2,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,applicantAddress);
		if (OPLUtils.isObjectNullOrEmpty(coiReq)) {
			log.error("FOUND COI REQUEST IS NULL OR EMPTY ----------->" + appMaster.getId());
			return null;
		}
		coiReq = pdfGenerateClient.setCOIOtherDetails(coiReq);
		return coiReq;
	}

	@Override
	public byte[] generateCOI(Long applicationId, boolean isFreshCreate) throws Exception {
		try {
			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("APPLICATION MASTER IS NULL OR EMPTY ----------->" + applicationId);
				return null;
			}
			return getCOI(appMaster, isFreshCreate);
		} catch (Exception e) {
			log.error("Exception while generate COI --> ", e);
		}
		return null;
	}
	
	@Override
	public byte[] generateCOINewDb(CertificateInsDtlRequest request, boolean isFreshCreate) throws Exception {
		try {
			ApplicationMasterBothSchemeProxy appMaster = ereCommonService
					.getJnsMasterDataApplicationMaster(request.getSchemeId().longValue(), request.getApplicationId());
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("APPLICATION MASTER IS NULL OR EMPTY ----------->" + request.getApplicationId());
				return null;
			}
			TransactionDetailsV2 transDtl = transactionDetailsRepositoryV2.findById(appMaster.getLastTransactionId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(transDtl)) {
				log.error("TRANSACTION DETAILS IS NULL OR EMPTY ----------->" + appMaster.getLastTransactionId());
				return null;
			}
			ApplicantInfoV2 applicantInfo = applicantInfoRepositoryV2.findById(appMaster.getId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
				log.error("APPLICANT INFO IS NULL OR EMPTY ----------->" + appMaster.getId());
				return null;
			}
			ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(appMaster.getId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
				log.error("APPLICANT PI DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
				return null;
			}
			NomineeDetailsV2 nomineeDetailsV2 = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appMaster.getId());
			if (OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2)) {
				log.error("NOMINEE DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
				return null;
			}
			NomineePIDetails nomineePIDetails = nomineePIDetailsRepository.findById(nomineeDetailsV2.getId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(nomineePIDetails)) {
				log.error("NOMINEE PI DETAILS IS NULL OR EMPTY ----------->" + nomineeDetailsV2.getId());
				return null;
			}
			AddressMasterV2 addressMasterV2 = addressMasterRepositoryV2.findById(nomineeDetailsV2.getAddressId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
				log.error("APPLICANT PI DETAILS IS NULL OR EMPTY ----------->" + appMaster.getId());
				return null;
			}
			return getCOINewDb(appMaster,transDtl,applicantInfo,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,addressMasterV2, isFreshCreate);
		} catch (Exception e) {
			log.error("Exception while generate COI --> ", e);
		}
		return null;
	}

	@Override
	public byte[] getCOI(ApplicationMasterV3 appMaster, boolean isFreshCreate) {
		try {
			// CHECK APPLICATION IS COMPLETED OR NOT
			if ((appMaster.getStageId() == EnrollStageMaster.COMPLETED.getStageId() || appMaster.getStageId() == EnrollStageMaster.PREMIUM_DEDUCTION.getStageId()) && !OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails())) {
				// READ FILE FROM DMS IF ALREADY CREATED
				if (!isFreshCreate) {
					Long coiStorageId = appMaster.getLastTransactionDetails().getCoiStorageId();
					if (coiStorageId != null) {
						return dmsClient.productDownloadDocuments(coiStorageId.toString());
					}
				}

				// FETCH COI REQUEST FROM APPLICATION MASTER
				COIRequest coiReq = ereCommonService.generateCOIRequest(appMaster);

				// GENERATE PDF FILE FROM PDF CLIENT
				CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
				if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
					appMaster.getLastTransactionDetails().setCoiStorageId(generateCOI.getId());
					return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
				} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
					log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
				} else {
					log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
				}
			} else {
				log.info("NOT ABLE TO GENERATE COI DUE TO NOT COMPLETED OR NOT UPDATE LAST TRANSACTION DETAILS --->" + appMaster.getId());
				return null;
			}
		} catch (Exception e) {
			log.error("Exception while generate COI ---------------->", e);
		}
		return null;
	}
	
	public byte[] getCOINewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantDetails,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 applicantAddress,Boolean isFreshCreate) {
		try {
			if (!isFreshCreate) {
				Long coiStorageId = transactionDetailsV2.getCoiStorageId();
				if (coiStorageId != null) {
					return dmsClient.productDownloadDocuments(coiStorageId.toString());
				}
			}
				// FETCH COI REQUEST FROM APPLICATION MASTER
				COIRequest coiReq = ereCommonService.generateCOIRequestNewDb(appMaster,transactionDetailsV2,applicantDetails,applicantPIDetails,nomineeDetailsV2,nomineePIDetails,applicantAddress);

				// GENERATE PDF FILE FROM PDF CLIENT
				CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
				if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
					transactionDetailsV2.setCoiStorageId(generateCOI.getId());
					transactionDetailsRepositoryV2.updateStorageIdInTransaction(generateCOI.getId(),appMaster.getLastTransactionId());
					return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
				} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
					log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
				} else {
					log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
				}
		} catch (Exception e) {
			log.error("Exception while generate COI ---------------->", e);
		}
		return null;
	}

	private PremiumDeductionResponse callPremiumDeduction(ApplicationMasterRequest req,  AuthClientResponse authClientResponse, ApplicationMasterV3 appMaster, InsurerMstDetailsV3 insurerDetails) {
//		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());

		if (OPLUtils.isObjectNullOrEmpty(req.getApplicationId()))
			appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());

		if (!OPLUtils.isObjectNullOrEmpty(appMaster)) {
//			InsurerMstDetailsV3 insurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(appMaster.getSchemeId().longValue(), appMaster.getOrgId(), new Date(),new Date());

			if (OPLUtils.isObjectNullOrEmpty(insurerDetails))
				insurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(appMaster.getSchemeId().longValue(), appMaster.getOrgId(), new Date(), new Date());

			if (!OPLUtils.isObjectNullOrEmpty(insurerDetails)) {
				BranchBasicDetailsRequest branchDetails = usersClient.getBranch(appMaster.getBranchId());
				Long schemeId = !OPLUtils.isObjectNullOrEmpty(appMaster.getSchemeId()) ? Long.valueOf(appMaster.getSchemeId()) : null;
				Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), schemeId, appMaster.getApplicationMasterOtherDetails().getSource());
				PremiumDeductionRequest prmReq = new PremiumDeductionRequest();
				prmReq.setApplicationId(appMaster.getId());
				prmReq.setCif(appMaster.getCif());
				prmReq.setCustomerAccountNumber(OPLUtils.convertToMask(appMaster.getAccountNumber(), 4, "X"));
				prmReq.setScheme(SchemeMaster.getById(schemeId).getShortName());
				prmReq.setInsurerCode(insurerDetails.getInsurerCode());
				prmReq.setUserId(Objects.equals(appMaster.getApplicationMasterOtherDetails().getSource(),
						Source.JANSURAKSHA_DIY.getId()) ? authClientResponse.getUserName()
								: authClientResponse.getEmail());
				prmReq.setBranchCode(branchDetails.getCode());
				prmReq.setPremiumAmount(premiumDtl);
				prmReq.setOrgId(appMaster.getOrgId());
				prmReq.setUrn(appMaster.getUrn());
				prmReq.setMode(Objects.equals(appMaster.getApplicationMasterOtherDetails().getSource(), Source.JANSURAKSHA_DIY.getId()) ? Source.JANSURAKSHA_DIY.getMode() : Source.JANSURAKSHA.getMode());
				try {
					return bankApiClient.getPremiumDeduction(prmReq, authClientResponse);
				} catch (IOException e) {
					log.error("Exception is getting While premium deduction Data ", e);
				}
			}
		}
		return null;
	}

	//	public CertificateInsData getCertiOfInsData(Long applicationId) {
	//		try {
	//			CertificateInsData certiVal = new CertificateInsData();
	//			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
	//			if (OPLUtils.isObjectNullOrEmpty(appMaster) || OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo())) {
	//				log.info("Application Master or Applicant Info is null or empty ------> " + applicationId);
	//				return null;
	//			}
	//			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails())
	//					&& !OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails().getChannelId())) {
	//				if (appMaster.getApplicationMasterOtherDetails().getChannelId()
	//						.equals(ChannelIdEnum.CUSTOMER_MOBILE.getShortName())
	//						|| appMaster.getApplicationMasterOtherDetails().getChannelId()
	//								.equals(ChannelIdEnum.CUSTOMER_WEB.getShortName())) {
	//					certiVal.setIsCustomerUser(true);
	//				} else {
	//					certiVal.setIsCustomerUser(false);
	//				}
	//			} else {
	//				certiVal.setIsCustomerUser(false);
	//			}
	//
	//			Long schemeId = appMaster.getSchemeId().longValue();
	//			certiVal.setMobileNo(appMaster.getApplicantInfo().getMobileNumber());
	//			certiVal.setDob(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getDob())
	//					? CommonUtils.sdf.format(appMaster.getApplicantInfo().getDob())
	//					: null);
	//			certiVal.setNameOfMember(setFullName(appMaster.getApplicantInfo().getFirstName(),
	//					appMaster.getApplicantInfo().getMiddleName(), appMaster.getApplicantInfo().getLastName()));
	//
	//			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycId1())) {
	//				if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
	//					certiVal.setKycName(KycDocument.AADHAR.getDisplayValue());
	//					certiVal.setKycValue("-");
	//				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.PAN.getKey())) {
	//					certiVal.setKycName(KycDocument.PAN.getDisplayValue());
	//					certiVal.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1())
	//							? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase()
	//							: "-");
	//				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
	//					certiVal.setKycName(KycDocument.PASSPORT.getDisplayValue());
	//					certiVal.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1())
	//							? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase()
	//							: "-");
	//				} else if (appMaster.getApplicantInfo().getKycId1()
	//						.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
	//					certiVal.setKycName(KycDocument.DRIVING_LICENCE.getDisplayValue());
	//					certiVal.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1())
	//							? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase()
	//							: "-");
	//				} else if (appMaster.getApplicantInfo().getKycId1()
	//						.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
	//					certiVal.setKycName(KycDocument.MGNREGA_CARD.getDisplayValue());
	//					certiVal.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1())
	//							? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase()
	//							: "-");
	//				} else if (appMaster.getApplicantInfo().getKycId1()
	//						.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
	//					certiVal.setKycName(KycDocument.VOTERS_ID_CARD.getDisplayValue());
	//					certiVal.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1())
	//							? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase()
	//							: "-");
	//				}
	//			}
	//			certiVal.setPremAmtPaid(appMaster.getPremiumAmount());
	//			certiVal.setAccountNo(appMaster.getAccountNumber());
	//			certiVal.setUrnNo(appMaster.getUrn());
	//			certiVal.setSchemeId(schemeId);
	//			certiVal.setDateOfComOfCover(appMaster.getEnrollmentDate());
	//
	//			AddressMasterV3 addMst = appMaster.getApplicantInfo().getAddress();
	//			certiVal.setAddress(getApplicantAddress(addMst));
	//
	//			InsurerMstDetailsV3 mst = insurerMstDetailsRepository
	//					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId,
	//							appMaster.getOrgId(), new Date(), new Date());
	//			certiVal.setMstPolicyNo(
	//					!OPLUtils.isObjectNullOrEmpty(mst) && !OPLUtils.isObjectNullOrEmpty(mst.getMasterPolicyNo())
	//							? mst.getMasterPolicyNo().toUpperCase()
	//							: null);
	//
	//			com.opl.jns.utils.common.CommonResponse organizationResponse = usersClient
	//					.getOrganizationById(appMaster.getLastTransactionDetails().getInsurerOrgId());
	//			if (!OPLUtils.isObjectNullOrEmpty(organizationResponse)
	//					&& organizationResponse.getStatus() == HttpStatus.OK.value()) {
	//				UserOrganisationMasterResponse objectFromObject = MultipleJSONObjectHelper
	//						.getObjectFromObject(organizationResponse.getData(), UserOrganisationMasterResponse.class);
	//				if (!OPLUtils.isObjectNullOrEmpty(objectFromObject)) {
	//					certiVal.setLogoUrl(!OPLUtils.isObjectNullOrEmpty(objectFromObject.getImagePath())
	//							? objectFromObject.getImagePath().trim()
	//							: null);
	//					certiVal.setNameOfInsurer(objectFromObject.getDisplayOrgName());
	//				}
	//			}
	//
	//			com.opl.jns.utils.common.CommonResponse bankResponse = usersClient
	//					.getOrganizationById(appMaster.getOrgId());
	//			if (!OPLUtils.isObjectNullOrEmpty(bankResponse) && bankResponse.getStatus() == HttpStatus.OK.value()) {
	//				UserOrganisationMasterResponse objectFromObject = MultipleJSONObjectHelper
	//						.getObjectFromObject(bankResponse.getData(), UserOrganisationMasterResponse.class);
	//				if (!OPLUtils.isObjectNullOrEmpty(objectFromObject)) {
	//					certiVal.setBankLogoUrl(!OPLUtils.isObjectNullOrEmpty(objectFromObject.getImagePath())
	//							? objectFromObject.getImagePath().trim()
	//							: null);
	//				}
	//			}
	//
	//			String orgResponse = usersClient.getOrganizationName(appMaster.getOrgId());
	//			if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
	//				certiVal.setNameOfBank(orgResponse);
	//			}
	//
	//			NomineeDetails nDtl = nomineeDetailsRepository
	//					.findByApplicationMasterIdAndTypeAndIsActiveTrue(appMaster.getId(), NomineeType.NOMINEE.getId());
	//			NomineeDetails nDtlOfGuardian = nomineeDetailsRepository
	//					.findByApplicationMasterIdAndTypeAndIsActiveTrue(appMaster.getId(), NomineeType.GUARDIAN.getId());
	//
	//			String strFullName = null;
	//			String age = null;
	//			if (!OPLUtils.isObjectNullOrEmpty(nDtl)) {
	//				strFullName = setFullName(nDtl.getFirstName(), nDtl.getMiddleName(), nDtl.getLastName());
	//				age = String.valueOf(CommonUtils.getAgeBydob(nDtl.getDob()));
	//
	//				if (!OPLUtils.isObjectNullOrEmpty(nDtlOfGuardian)) {
	//					certiVal.setNameOfGuardian(nDtlOfGuardian.getName());
	//					if (!OPLUtils.isObjectNullOrEmpty(nDtlOfGuardian.getRelationId())) {
	//						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,
	//								nDtlOfGuardian.getRelationId());
	//						certiVal.setRelationShipOfGuardian(relationShip);
	//					}
	//				}
	//			}
	//
	//			certiVal.setNameOfNominee(strFullName);
	//			certiVal.setAgeOfNominee(age);
	//			certiVal.setAnnuRenDate(configProperties.getValueByCode(CommonUtils.ANNUAL_RENEWAL_DATE));
	//			certiVal.setSumAssured(configProperties.getValueByCode(CommonUtils.PMJJBY_SUM_ASSURED));
	//			certiVal.setLienPeriod(configProperties.getValueByCode(CommonUtils.PMJJBY_LIEN_PERIOD));
	//			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoverEndDate())) {
	//				certiVal.setCoverEndDate(
	//						CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getLastTransactionDetails().getCoverEndDate()));
	//			}
	//			Long storageId = null;
	//			// UPLOAD COI FROM DMS
	//			if (OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoiStorageId())) {
	//				storageId = uploadCOIFromDMS(certiVal, appMaster);
	//			} else {
	//				storageId = appMaster.getLastTransactionDetails().getCoiStorageId();
	//			}
	//			log.info("GENERATE COI STORAGE ID ----------------------------->" + storageId);
	//			if (!OPLUtils.isObjectNullOrEmpty(storageId)) {
	//				certiVal.setCoiStorageId(storageId);
	//			}
	//			return certiVal;
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			log.error("Exception is getting While Get certificateInsData ", e.getMessage());
	//			return null;
	//		}
	//	}

	//	private byte[] generatePdf(String template, String fileName) {
	//		log.info("INSIDE generatePdf() --->");
	//		File file = new File(fileName + ".pdf");
	//		try {
	//			FontProvider provider = new FontProvider();
	//			provider.addSystemFonts();
	//			provider.addStandardPdfFonts();
	//			ConverterProperties converterProperties = new ConverterProperties();
	//			converterProperties.setFontProvider(provider);
	//			convertToPdf(template, new FileOutputStream(file), converterProperties);
	//			Resource resource = new UrlResource(file.toURI());
	//			String filePath = resource.getFile().getAbsolutePath();
	//
	//			log.info("END generatePdf() --->");
	//			if (OPLUtils.isObjectNullOrEmpty(filePath)) {
	//				return null;
	//			} else if (filePath.equals("empty")) {
	//				return new byte[10];
	//			} else {
	//				byte[] fileByte = Files.readAllBytes(Paths.get(filePath));
	//				file = new File(filePath);
	//				return fileByte;
	//			}
	//		} catch (Exception e) {
	//			e.printStackTrace();
	//			log.error("error is getting While generate PDF");
	//			return null;
	//		} finally {
	//			if (file.exists()) {
	//				boolean flag = file.delete();
	//				log.info("file.delete() status : {}", flag);
	//			}
	//		}
	//	}

	//	private String setFullName(String firstName, String middleName, String lastName) {
	//		return (!OPLUtils.isObjectNullOrEmpty(firstName) ? firstName : "") + " "
	//				+ (!OPLUtils.isObjectNullOrEmpty(middleName) ? middleName : "") + " "
	//				+ (!OPLUtils.isObjectNullOrEmpty(lastName) ? lastName : "");
	//	}

	//	private String setCertificateInTemplate(String template, CertificateInsData crtInsData) throws ParseException {
	//		if (!OPLUtils.isObjectNullOrEmpty(template)) {
	//			template = template.replace("$nameOfMember",
	//					OPLUtils.replaceStringIfNull(crtInsData.getNameOfMember(), ""));
	//			template = template.replace("$address", OPLUtils.replaceStringIfNull(crtInsData.getAddress(), ""));
	//
	////			template = template.replace("$aadharNo", OPLUtils.replaceStringIfNull(crtInsData.getAadharNo(), ""));
	//			if (!OPLUtils.isObjectNullOrEmpty(crtInsData.getKycName())) {
	//
	//				if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.AADHAR.getDisplayValue())) {
	////					template = template.replace("$kycName", OPLUtils.replaceStringIfNull(crtInsData.getKycName(), ""));
	//					template = template.replace("$kycName", KycDocument.AADHAR.getDisplayValue());
	//					template = template.replace("$kycValue", "-");
	//				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.PAN.getDisplayValue())) {
	//					template = template.replace("$kycName", KycDocument.PAN.getDisplayValue());
	//					template = template.replace("$kycValue",
	//							OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
	//				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.PASSPORT.getDisplayValue())) {
	//					template = template.replace("$kycName", KycDocument.PASSPORT.getDisplayValue());
	//					template = template.replace("$kycValue",
	//							OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
	//				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getDisplayValue())) {
	//					template = template.replace("$kycName", KycDocument.DRIVING_LICENCE.getDisplayValue());
	//					template = template.replace("$kycValue",
	//							OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
	//				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.MGNREGA_CARD.getDisplayValue())) {
	//					template = template.replace("$kycName", KycDocument.MGNREGA_CARD.getDisplayValue());
	//					template = template.replace("$kycValue",
	//							OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
	//				} else if (crtInsData.getKycName().equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getDisplayValue())) {
	//					template = template.replace("$kycName", KycDocument.VOTERS_ID_CARD.getDisplayValue());
	//					template = template.replace("$kycValue",
	//							OPLUtils.replaceStringIfNull(crtInsData.getKycValue().toUpperCase(), ""));
	//				}
	//			}
	//
	//			template = template.replace("$nameOfNominee",
	//					OPLUtils.replaceStringIfNull(crtInsData.getNameOfNominee(), ""));
	//			template = template.replace("$accountNo", OPLUtils.replaceStringIfNull(crtInsData.getAccountNo(), ""));
	//			template = template.replace("$dateOfComOfCover",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getDateOfComOfCover())
	//							? CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS.format(crtInsData.getDateOfComOfCover())
	//							: "");
	//			template = template.replace("$sumAssured", OPLUtils.replaceStringIfNull(crtInsData.getSumAssured(), ""));
	//			template = template.replace("$premAmtPaid", OPLUtils.replaceStringIfNull(crtInsData.getPremAmtPaid(), ""));
	//			template = template.replace("$mstPolicyNo", OPLUtils.replaceStringIfNull(crtInsData.getMstPolicyNo(), ""));
	//			template = template.replace("$urnNo", OPLUtils.replaceStringIfNull(crtInsData.getUrnNo(), ""));
	//			template = template.replace("$mobileNo", OPLUtils.replaceStringIfNull(crtInsData.getMobileNo(), ""));
	//			template = template.replace("$dob",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getDob())
	//							? CommonUtils.sdf_dd_MM_yyyy.format(CommonUtils.sdf.parse(crtInsData.getDob()))
	//							: "");
	//			template = template.replace("$nameOfBank", OPLUtils.replaceStringIfNull(crtInsData.getNameOfBank(), ""));
	//			String ageOfNominee = null != crtInsData.getAgeOfNominee()
	//					? crtInsData.getAgeOfNominee().equals("0") || crtInsData.getAgeOfNominee().equals("1")
	//							? crtInsData.getAgeOfNominee() + " Year"
	//							: crtInsData.getAgeOfNominee() + " Years"
	//					: "0 Year";
	//			template = template.replace("$ageOfNominee",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getAgeOfNominee()) ? ageOfNominee : "");
	//			template = template.replace("$coverAndDate",
	//					OPLUtils.replaceStringIfNull(crtInsData.getCoverEndDate(), ""));
	//			template = template.replace("$lienPeriod", OPLUtils.replaceStringIfNull(crtInsData.getLienPeriod(), ""));
	//			template = template.replace("$annuRenDate", OPLUtils.replaceStringIfNull(crtInsData.getAnnuRenDate(), ""));
	//			template = template.replace("$logoUrl", OPLUtils.replaceStringIfNull(crtInsData.getLogoUrl(), ""));
	//
	//			template = template.replace("$bankLogoUrl", OPLUtils.replaceStringIfNull(crtInsData.getBankLogoUrl(), ""));
	//
	//			template = template.replace("$nameOfInsurer",
	//					OPLUtils.replaceStringIfNull(crtInsData.getNameOfInsurer(), ""));
	//			template = template.replace("$schemeName",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getSchemeId())
	//							? com.opl.jns.utils.enums.SchemeMaster.getById(crtInsData.getSchemeId()).getName()
	//							: "");
	//			template = template.replace("$nameOfGuardian",
	//					OPLUtils.replaceStringIfNull(crtInsData.getNameOfGuardian(), ""));
	//			template = template.replace("$relationShipOfGuardian",
	//					OPLUtils.replaceStringIfNull(crtInsData.getRelationShipOfGuardian(), ""));
	//			template = template.replace("$isHideGuardian",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getNameOfGuardian()) ? "display: block;"
	//							: CommonUtils.DISPLAY_NONE);
	//
	//			template = template.replace("$isShowSign",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getIsCustomerUser()) && !crtInsData.getIsCustomerUser()
	//							? "display: block;"
	//							: CommonUtils.DISPLAY_NONE);
	//
	//			template = template.replace("$isHideSign",
	//					!OPLUtils.isObjectNullOrEmpty(crtInsData.getIsCustomerUser()) && crtInsData.getIsCustomerUser()
	//							? "display: block;"
	//							: CommonUtils.DISPLAY_NONE);
	//
	//		}
	//		return template;
	//	}

	/**
	 * 
	 * @param applicationId
	 * @param count
	 * @param authClientResponse
	 * @param appMaster
	 * @param insurerDetails 
	 * @param insurerDetails
	 * @return
	 */
	@SuppressWarnings("unused")
	private PremiumDeductionResponse runPremiumDeduction(Long applicationId, AuthClientResponse authClientResponse, ApplicationMasterV3 appMaster, InsurerMstDetailsV3 insurerDetails) {
//		ApplicationMasterV3 app = applicationMasterRepo.findByIdAndIsActiveTrueAndStageId(applicationId, EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId());

		if (OPLUtils.isObjectNullOrEmpty(appMaster))
			appMaster = applicationMasterRepo.findByIdAndIsActiveTrueAndStageId(applicationId, EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId());

		PremiumDeductionResponse resp = new PremiumDeductionResponse();
		ApplicationMasterRequest req = new ApplicationMasterRequest();
		req.setApplicationId(appMaster.getId());
		req.setSchemeId(!OPLUtils.isObjectNullOrEmpty(appMaster.getSchemeId()) ? Long.valueOf(appMaster.getSchemeId()) : null);
		req.setUserId(appMaster.getUserId());
		
		resp = callPremiumDeduction(req,  authClientResponse, appMaster, insurerDetails);
		if (!OPLUtils.isObjectNullOrEmpty(resp) && (!OPLUtils.isObjectNullOrEmpty(resp.getStatus()) && resp.getStatus().equals(HttpStatus.OK.value()))
				&& (!OPLUtils.isObjectNullOrEmpty(resp.getFlag()) && Boolean.TRUE.equals(resp.getFlag()))) {
			// in case of success update
			ApplicationMasterRequestV2 appMasterReq = new ApplicationMasterRequestV2();
			appMasterReq.setStageId(EnrollStageMaster.PREMIUM_DEDUCTION.getStageId());
			appMasterReq.setApplicationId(appMaster.getId());
			try {
				applicationMasterService.updateStage(appMasterReq, authClientResponse);
			} catch (Exception e) {
				log.info("Exception in updating stage while retrying app");
			}
		} else
			log.info("Premium Deduction Failed --",resp);
		
//		else {
//			if (count < 4) {
//				resp = runPremiumDeduction(appMaster.getId(), count, authClientResponse, appMaster,insurerDetails);
//			}
//		}
		return resp;
	}

	@Override
	public ApplicationMasterRequestV2 getApplicationFormDetails(Long applicationId, AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return null;
			}

			Long schemeId = null;
			ApplicationMasterRequestV2 mstReq = new ApplicationMasterRequestV2();
			BeanUtils.copyProperties(appMaster, mstReq);
			Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), appMaster.getSchemeId().longValue(), appMaster.getApplicationMasterOtherDetails().getSource());
			mstReq.setPremiumAmount(premiumDtl);
			mstReq.setEnrollDate(appMaster.getEnrollmentDate());
			mstReq.setMaxTransactionDate(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(INSURER_START_DATE) + CommonUtils.getCurrentPolicyYear() + "T00:00:00.00"));
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails())) {
				mstReq.setCoverEndDate(appMaster.getLastTransactionDetails().getCoverEndDate());
			}
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getSchemeId())) {
				schemeId = appMaster.getSchemeId().longValue();
				mstReq.setScheme(com.opl.jns.utils.enums.SchemeMaster.getById(schemeId).getShortName());
			}
			mstReq.setCreatedDate(appMaster.getStageId() == EnrollStageMaster.COMPLETED.getStageId() ? appMaster.getCreatedDate() : appMaster.getModifiedDate());
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo())) {
				mstReq.setUrn(appMaster.getUrn());
				mstReq.setEmail(appMaster.getApplicantInfo().getEmail());
				mstReq.setMobile(appMaster.getApplicantInfo().getMobileNumber());
				mstReq.setKyc(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getIsKYCUpdate()) && appMaster.getApplicantInfo().getIsKYCUpdate() ? "Yes" : "No");
				mstReq.setFirstName(appMaster.getApplicantInfo().getFirstName());
				mstReq.setMiddleName(appMaster.getApplicantInfo().getMiddleName());
				mstReq.setLastName(appMaster.getApplicantInfo().getLastName());
				mstReq.setFatherHusbandName(appMaster.getApplicantInfo().getFatherHusbandName());
				mstReq.setDob(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getDob()) ? appMaster.getApplicantInfo().getDob() : null);
				mstReq.setMobileNo(appMaster.getApplicantInfo().getMobileNumber());
				mstReq.setEmailAddress(appMaster.getApplicantInfo().getEmail());
				mstReq.setKycId1(appMaster.getApplicantInfo().getKycId1());
				mstReq.setKycId1number(appMaster.getApplicantInfo().getKycIdNumber1());
				mstReq.setKycId2(appMaster.getApplicantInfo().getKycId2());
				mstReq.setKycId2number(appMaster.getApplicantInfo().getKycIdNumber2());

				mstReq.setIsSameApplicantAddress(appMaster.getApplicantInfo().getIsSameAppAddress());
				mstReq.setDisabilityDetails(appMaster.getApplicantInfo().getDisabilityDetails());
				mstReq.setDisabilityStatus(appMaster.getApplicantInfo().getDisabilityStatus());
				mstReq.setIsNomineeDeatilsSameEnroll(appMaster.getApplicantInfo().getIsNomineeDetailsSameEnroll());

				mstReq = getRequiredOrgsDetails(mstReq, appMaster);

				mstReq.setAccountHolderName(appMaster.getApplicantInfo().getName());
				mstReq.setCustIfscCode(appMaster.getApplicantInfo().getIfsc());
				mstReq.setAccountNo(appMaster.getAccountNumber());
				mstReq.setAmount(appMaster.getPremiumAmount());
				if (OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getAddress())) {
					mstReq.setAddress(new AddressMasterRequest());
				} else {
					AddressMasterRequest req = new AddressMasterRequest();
					BeanUtils.copyProperties(appMaster.getApplicantInfo().getAddress(), req);
					req.setCity(appMaster.getApplicantInfo().getAddress().getCityName());
					req.setState(appMaster.getApplicantInfo().getAddress().getStateName());
					mstReq.setAddress(req);
				}
			}

			// FOR NOMINEE UPDATE DATA
			MiscellaneousAudit nomineeUpdatedData = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId, MiscellaneousType.NOMINEE_UPDATE.getId());
			if (!OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData)) {
				mstReq.setDateOfNomineeUpdate(nomineeUpdatedData.getCreatedDate());
			}

			// FOR OPT OUT DATA
			MiscellaneousAudit optOutData = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId, MiscellaneousType.OPT_OUT.getId());
			if (!OPLUtils.isObjectNullOrEmpty(optOutData)) {
				mstReq.setNomineeUpdateRequestDate(optOutData.getDateOfRequest());
				mstReq.setNomineeUpdateEffectiveDate(optOutData.getDateOfEffective());
			}

			NomineeDetails ndMst = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.NOMINEE.getId());
			NomineeDetails ndMstOfGuardian = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.GUARDIAN.getId());

			if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
				NomineeDetailsRequest ndReq = new NomineeDetailsRequest();
				BeanUtils.copyProperties(ndMst, ndReq);
				ndReq.setDateOfBirth(ndMst.getDob());
				ndReq.setEmailIdOfNominee(ndMst.getEmail());
				if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian)) {
					if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getRelationId())) {
						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMstOfGuardian.getRelationId());
						ndReq.setRelationShipOfGuardianStr(relationShip);
						ndReq.setRelationShipOfGuardian(ndMstOfGuardian.getRelationId());
					}
					ndReq.setMobileNumberOfGuardian(!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getMobileNumber()) ? ndMstOfGuardian.getMobileNumber() : null);
					ndReq.setEmailIdOfGuardian(!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getEmail()) ? ndMstOfGuardian.getEmail() : null);
					ndReq.setAddressOfGuardian(ndMstOfGuardian.getAddress().getAddressLine1());
					ndReq.setNameOfGuardian(ndMstOfGuardian.getName());
				}
				ndReq.setAge(!OPLUtils.isObjectNullOrEmpty(ndMst.getDob()) ? CommonUtils.getAgeBydob(ndMst.getDob()) : null);
				ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());

				if (!OPLUtils.isObjectNullOrEmpty(ndMst.getRelationId())) {
					String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getRelationId());
					ndReq.setRelationOfNomineeApplicantStr(relationShip);
					ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());
				}

				if (!OPLUtils.isObjectNullOrEmpty(appMaster.getOrgId())) {
					// Get Nominee Address phase 2
					if (PhaseMode.checkPhase2(appMaster.getOrgId())) {
						if (!OPLUtils.isObjectNullOrEmpty(ndMst.getAddress().getAddressLine1())) {
							ndReq.setAddressLine1(ndMst.getAddress().getAddressLine1());
						}
					} else {
						// Get Nominee Address phase 1
						if (!OPLUtils.isObjectNullOrEmpty(ndMst.getAddress())) {
							if (OPLUtils.isObjectNullOrEmpty(ndReq.getAddress())) {
								ndReq.setAddress(new AddressMasterRequest());
							}
							AddressMasterRequest req = new AddressMasterRequest();
							BeanUtils.copyProperties(ndMst.getAddress(), req);
							req.setCity(ndMst.getAddress().getCityName());
							req.setState(ndMst.getAddress().getStateName());
							ndReq.setAddress(req);
						}
					}
				}
			
				List<NomineeDetailsRequest> nomineeMasterList = new ArrayList<NomineeDetailsRequest>();
				nomineeMasterList.add(ndReq);
				mstReq.setNominee(nomineeMasterList);
			}
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getOrgId())) {
				String orgResponse = usersClient.getOrganizationName(appMaster.getOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
					mstReq.setBankName(orgResponse);
				}
			}
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getBranchId())) {
				BranchBasicDetailsRequest branchDetails = usersClient.getBranch(appMaster.getBranchId());
				if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
					mstReq.setBranchName(branchDetails.getName());
					mstReq.setIfscCode(branchDetails.getIfscCode());
				}
			} else {
				log.info("branchId not found from user Auth");
			}
			return mstReq;
		} catch (Exception e) {
			log.error("Exception is getting While Get insurance data ", e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	private ApplicationMasterRequestV2 getRequiredOrgsDetails(ApplicationMasterRequestV2 mstReq, ApplicationMasterV3 mst) throws Exception {

		List<Long> orgIds = new ArrayList<>();
		
		Long insuranceOrg = null;
		Long nameOfInsurerOrg = null;
		Long nameOfBankOrg = null;
		
		if(!OPLUtils.isObjectNullOrEmpty(mst.getSchemeId()) && !OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
			InsurerMstDetailsV3 insurerMstDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(mst.getSchemeId().longValue(), mst.getOrgId(), new Date(), new Date());
			if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails) && !OPLUtils.isObjectNullOrEmpty(insurerMstDetails.getInsurerOrgId())) {
				orgIds.add(insurerMstDetails.getInsurerOrgId());
				insuranceOrg = insurerMstDetails.getInsurerOrgId();
			}
		}
		

		if (!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails().getInsurerOrgId())) {
			orgIds.add(mst.getLastTransactionDetails().getInsurerOrgId());
			nameOfInsurerOrg = mst.getLastTransactionDetails().getInsurerOrgId();
		}

		if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
			orgIds.add(mst.getOrgId());
			nameOfBankOrg = mst.getOrgId();
		}

		UserOrganisationPdfGenarateRequestResponse genarateRequest = new UserOrganisationPdfGenarateRequestResponse();
		genarateRequest.setOrgIds(orgIds);
		CommonResponse organizationDetailsByOrgIds = usersClient.getOrganizationDetailsByOrgIds(genarateRequest);
		if (!OPLUtils.isObjectNullOrEmpty(organizationDetailsByOrgIds) && organizationDetailsByOrgIds.getStatus() == HttpStatus.OK.value()) {
			List<UserOrganisationMasterResponse> orgDetailsLst = MultipleJSONObjectHelper.getListOfObjects(MultipleJSONObjectHelper.getStringfromObject(organizationDetailsByOrgIds.getData()), null, UserOrganisationMasterResponse.class);

			for (UserOrganisationMasterResponse orgDetails : orgDetailsLst) {
				if (!OPLUtils.isObjectNullOrEmpty(orgDetails)
						&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getUserOrgId())) {

					if (!OPLUtils.isObjectNullOrEmpty(insuranceOrg) && insuranceOrg.equals(orgDetails.getUserOrgId())
							&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getDisplayOrgName())) {
						mstReq.setInsuranceName(orgDetails.getDisplayOrgName());
						mstReq.setNameOfInsurer(orgDetails.getDisplayOrgName());
//					else if (!OPLUtils.isObjectNullOrEmpty(nameOfInsurerOrg) && nameOfInsurerOrg.equals(orgDetails.getUserOrgId()) && !OPLUtils.isObjectNullOrEmpty(orgDetails.getDisplayOrgName()))
					} else if (!OPLUtils.isObjectNullOrEmpty(nameOfBankOrg)
							&& nameOfBankOrg.equals(orgDetails.getUserOrgId())
							&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getDisplayOrgName())) {
						mstReq.setNameOfBank(orgDetails.getDisplayOrgName());
					}

				}
			}

		}

		//		InsurerMstDetailsV3 insurerMstDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(mst.getSchemeId().longValue(), mst.getOrgId(), new Date(), new Date());
		//		if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails) && !OPLUtils.isObjectNullOrEmpty(insurerMstDetails.getInsurerOrgId())) {
		//			String organizationName = getOrgnaizationNameFromOrgId(insurerMstDetails.getInsurerOrgId());
		//			if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
		//				mstReq.setInsuranceName(organizationName);
		//			}
		//		}
		//		if (!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails().getInsurerOrgId())) {
		//			String organizationName = getOrgnaizationNameFromOrgId(mst.getLastTransactionDetails().getInsurerOrgId());
		//			if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
		//				mstReq.setNameOfInsurer(organizationName);
		//			}
		//		}
		//		mstReq.setNameOfBank(!OPLUtils.isObjectNullOrEmpty(mst.getOrgId()) ? getOrgnaizationNameFromOrgId(mst.getOrgId()) : null);

		return mstReq;
	}
	
	@SuppressWarnings("unchecked")
	private ApplicationMasterRequestV2 getRequiredOrgsDetailsNewDb(ApplicationMasterRequestV2 mstReq,
			ApplicationMasterBothSchemeProxy mst, Long schemeId) throws Exception {

		List<Long> orgIds = new ArrayList<>();

		Long insuranceOrg = null;
		Long nameOfInsurerOrg = null;
		Long nameOfBankOrg = null;

		if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
			InsurerMstDetailsV3 insurerMstDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId,
							mst.getOrgId(), new Date(), new Date());
			if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails)
					&& !OPLUtils.isObjectNullOrEmpty(insurerMstDetails.getInsurerOrgId())) {
				orgIds.add(insurerMstDetails.getInsurerOrgId());
				insuranceOrg = insurerMstDetails.getInsurerOrgId();
			}
		}

		if (!OPLUtils.isObjectNullOrEmpty(mst.getInsurerOrgId())) {
			orgIds.add(mst.getInsurerOrgId());
			nameOfInsurerOrg = mst.getInsurerOrgId();
		}

		if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
			orgIds.add(mst.getOrgId());
			nameOfBankOrg = mst.getOrgId();
		}

		UserOrganisationPdfGenarateRequestResponse genarateRequest = new UserOrganisationPdfGenarateRequestResponse();
		genarateRequest.setOrgIds(orgIds);
		CommonResponse organizationDetailsByOrgIds = usersClient.getOrganizationDetailsByOrgIds(genarateRequest);
		if (!OPLUtils.isObjectNullOrEmpty(organizationDetailsByOrgIds)
				&& organizationDetailsByOrgIds.getStatus() == HttpStatus.OK.value()) {
			List<UserOrganisationMasterResponse> orgDetailsLst = MultipleJSONObjectHelper.getListOfObjects(
					MultipleJSONObjectHelper.getStringfromObject(organizationDetailsByOrgIds.getData()), null,
					UserOrganisationMasterResponse.class);

			for (UserOrganisationMasterResponse orgDetails : orgDetailsLst) {
				if (!OPLUtils.isObjectNullOrEmpty(orgDetails)
						&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getUserOrgId())) {

					if (!OPLUtils.isObjectNullOrEmpty(insuranceOrg) && insuranceOrg.equals(orgDetails.getUserOrgId())
							&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getDisplayOrgName())) {
						mstReq.setInsuranceName(orgDetails.getDisplayOrgName());
						mstReq.setNameOfInsurer(orgDetails.getDisplayOrgName());
					} else if ((!OPLUtils.isObjectNullOrEmpty(nameOfBankOrg)
							&& nameOfBankOrg.equals(orgDetails.getUserOrgId())
							&& !OPLUtils.isObjectNullOrEmpty(orgDetails.getDisplayOrgName()))) {
						mstReq.setNameOfBank(orgDetails.getDisplayOrgName());
					}

				}
			}

		}
		return mstReq;
	}

	@SuppressWarnings("unused")
	private String getOrgnaizationNameFromOrgIds(Long orgId) {
		return usersClient.getOrganizationName(orgId);
	}

	public String getValueById(DropDownMasterKey key, Integer id) throws OneFormException {
		try {
			return oneFormClient.getNameByKeyAndObjId(key, id).getValue();
		} catch (Exception e) {
			log.error("Exception in fetching the values of [{}] and exception id :", id, e);
		}
		return null;
	}

	public CommonResponse kycIdValidOrNot(String kycId, ApplicationMasterV3 appMaster, AuthClientResponse authRes, String kycIdName) {
		if (!kycId.equalsIgnoreCase(KycDocument.PAN.getKey()) && !kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey()) && !kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())
				&& !kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey()) && !kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey()) && !kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			updateAppMasterErro(appMaster, kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA", authRes.getUserId());
			return new CommonResponse(kycIdName + " must be AADHAR / PAN / VOTERID  / DRIVINGL / PASSPORT / MGNREGA", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
		}
		return null;
	}

	public CommonResponse kycIdNumberValidOrNot(String kycId, String kycIdNumber, ApplicationMasterV3 appMaster, AuthClientResponse authRes, String kycIdName) {
		if (kycId.equalsIgnoreCase(KycDocument.PAN.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PAN_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid pan number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid pan number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.AADHAR_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid aadhar number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid aadhar number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.PASSPORT_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid passport number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid passport number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.VOTERS_ID_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid voter id number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid voter id number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.DRIVING_LICENCE_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid driving licence number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid driving licence number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		} else if (kycId.equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
			Pattern pattern = Pattern.compile(PatternUtils.MGNREGA_CARD_PATTERN);
			Matcher matcher = pattern.matcher(kycIdNumber);
			if (!matcher.matches()) {
				updateAppMasterErro(appMaster, kycIdName + " - Invalid mgnrega card number", authRes.getUserId());
				return new CommonResponse(kycIdName + " - Invalid mgnrega card number", ResponseStatus.CUSTOMER_DETAIL_NOT_VALID_ERROR.getStatusId(), Boolean.FALSE);
			}
		}
		return null;
	}

	@Override
	public CommonResponse premiumDeductionTransactionFailedCases(PremiumDeductionFailedProxy req, AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(req.getApplicationId());

			InsurerMstDetailsV3 insurerDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(req.getSchemeId().longValue(), appMaster.getOrgId(), new Date(), new Date());
			if (OPLUtils.isObjectNullOrEmpty(insurerDetails)) {
				updateStageError(appMaster.getId(), appMaster.getStageId(), "Insurer details not found", req.getUserId());
				log.info("Insurer details not found --> " + req.getSchemeId() + "------------>" + appMaster.getOrgId());
				return new CommonResponse("Its seems we have not found insurer details for you bank, please try after sometime!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}

			PremiumDeductionResponse premiumDeductionResponse = new PremiumDeductionResponse();
			BeanUtils.copyProperties(req, premiumDeductionResponse);

			return  savePremiumDeductionData(premiumDeductionResponse, appMaster, req.getUserId(), insurerDetails, authClientResponse, Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception while saving premium deduction data ", e);
		}
		return null;
	}

	//	public CommonResponse reponseValidation(Set<ConstraintViolation<T>> violations) {
	//            StringBuilder sb = new StringBuilder();
	//            violations.forEach(constraintViolation->{
	//            	if(sb.length()>0) {	            		
	//            		sb.append(", " +constraintViolation.getPropertyPath() + " ");
	//            		sb.append(constraintViolation.getMessage() + ", ");
	//            	}else {
	//            		sb.append(constraintViolation.getPropertyPath() + " ");
	//            		sb.append(constraintViolation.getMessage());
	//            	}
	//            });
	//            return new CommonResponse(sb.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
	//        }

	// For Admin pannel
	@Override
	public ApplicationMasterRequestV2 getApplicationAllDetails(Long applicationId, ApplicationMasterV3 mst) {
		try {
//			ApplicationMasterV3 mst = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
			
			
			if(OPLUtils.isObjectNullOrEmpty(mst))
				mst = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
			
			if (OPLUtils.isObjectNullOrEmpty(mst)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return null;
			}

			Long schemeId = null;
			ApplicationMasterRequestV2 mstReq = new ApplicationMasterRequestV2();
			BeanUtils.copyProperties(mst, mstReq);
			Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), mst.getSchemeId().longValue(), mst.getApplicationMasterOtherDetails().getSource());
			mstReq.setApplicationId(mst.getId());
			mstReq.setPremiumAmount(premiumDtl);
			mstReq.setEnrollDate(mst.getEnrollmentDate());
			mstReq.setMaxTransactionDate(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(INSURER_START_DATE) + CommonUtils.getCurrentPolicyYear() + "T00:00:00.00"));
			if (!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails())) {
				mstReq.setCoverEndDate(mst.getLastTransactionDetails().getCoverEndDate());
				mstReq.setYear(!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails().getInsurerMaster()) ? mst.getLastTransactionDetails().getInsurerMaster().getYear() : null);
			}
			if (!OPLUtils.isObjectNullOrEmpty(mst.getSchemeId())) {
				schemeId = mst.getSchemeId().longValue();
				mstReq.setScheme(com.opl.jns.utils.enums.SchemeMaster.getById(schemeId).getShortName());
			}
			mstReq.setCreatedDate((!OPLUtils.isObjectNullOrEmpty(mst.getStageId()) && mst.getStageId() == EnrollStageMaster.COMPLETED.getStageId()) ? mst.getCreatedDate() : mst.getModifiedDate());
			if (!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo())) {
				mstReq.setUrn(mst.getUrn());
				mstReq.setAadhar(mst.getApplicantInfo().getAadhaar());
				mstReq.setPan(mst.getApplicantInfo().getPan());
				mstReq.setKyc(!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getIsKYCUpdate()) && mst.getApplicantInfo().getIsKYCUpdate() ? "Yes" : "No");
				mstReq.setFirstName(mst.getApplicantInfo().getFirstName());
				mstReq.setMiddleName(mst.getApplicantInfo().getMiddleName());
				mstReq.setLastName(mst.getApplicantInfo().getLastName());
				mstReq.setFatherHusbandName(mst.getApplicantInfo().getFatherHusbandName());
				mstReq.setDob(!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getDob()) ? mst.getApplicantInfo().getDob() : null);
				mstReq.setMobileNo(mst.getApplicantInfo().getMobileNumber());
				mstReq.setEmailAddress(mst.getApplicantInfo().getEmail());
				mstReq.setKycId1(mst.getApplicantInfo().getKycId1());
				mstReq.setKycId1number(mst.getApplicantInfo().getKycIdNumber1());
				mstReq.setKycId2(mst.getApplicantInfo().getKycId2());
				mstReq.setKycId2number(mst.getApplicantInfo().getKycIdNumber2());

				mstReq.setIsSameApplicantAddress(mst.getApplicantInfo().getIsSameAppAddress());
				mstReq.setDisabilityDetails(mst.getApplicantInfo().getDisabilityDetails());
				mstReq.setDisabilityStatus(mst.getApplicantInfo().getDisabilityStatus());
				mstReq.setIsNomineeDeatilsSameEnroll(mst.getApplicantInfo().getIsNomineeDetailsSameEnroll());

				mstReq.setCif(mst.getCif());
//				mstReq.setGender(Gender.fromId(mst.getApplicantInfo().getGenderId()).getBankValue());
				mstReq.setGender(!OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getGenderId()) ? Gender.fromId(mst.getApplicantInfo().getGenderId()).getBankValue()  : null);
				mstReq.setCkyc(mst.getApplicantInfo().getCkyc());
				mstReq.setCkycNumber(mst.getApplicantInfo().getCkycNumber());

				mstReq = getRequiredOrgsDetails(mstReq, mst);
				
//				InsurerMstDetailsV3 insurerMstDetails = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(mst.getSchemeId().longValue(), mst.getOrgId(), new Date(), new Date());
//				if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails) && !OPLUtils.isObjectNullOrEmpty(insurerMstDetails.getInsurerOrgId())) {
//					String organizationName = getOrgnaizationNameFromOrgId(insurerMstDetails.getInsurerOrgId());
//					if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//						mstReq.setInsuranceName(organizationName);
//					}
//					mstReq.setInsurerOrgId(mst.getInsurerOrgId());
//				}
//				if (!OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails().getInsurerOrgId())) {
//					String organizationName = getOrgnaizationNameFromOrgId(mst.getLastTransactionDetails().getInsurerOrgId());
//					if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//						mstReq.setNameOfInsurer(organizationName);
//					}
//				}
//				//				mstReq.setMasterPolicyNo(insurerMstDetails.getMasterPolicyNo());
//				//				mstReq.setInsurerCode(insurerMstDetails.getInsurerCode());
//
//				mstReq.setNameOfBank(!OPLUtils.isObjectNullOrEmpty(mst.getOrgId()) ? getOrgnaizationNameFromOrgId(mst.getOrgId()) : null);
				
				
				mstReq.setAccountHolderName(mst.getApplicantInfo().getName());
				mstReq.setAccountNo(mst.getAccountNumber());
				mstReq.setAmount(mst.getPremiumAmount());
				if (OPLUtils.isObjectNullOrEmpty(mst.getApplicantInfo().getAddress())) {
					mstReq.setAddress(new AddressMasterRequest());
				} else {
					AddressMasterRequest req = new AddressMasterRequest();
					BeanUtils.copyProperties(mst.getApplicantInfo().getAddress(), req);
					req.setCity(mst.getApplicantInfo().getAddress().getCityName());
					req.setState(mst.getApplicantInfo().getAddress().getStateName());
					mstReq.setAddress(req);
				}
			}
			NomineeDetails ndMst = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.NOMINEE.getId());
			NomineeDetails ndMstOfGuardian = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.GUARDIAN.getId());

			if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
				NomineeDetailsRequest ndReq = new NomineeDetailsRequest();
				BeanUtils.copyProperties(ndMst, ndReq);
				ndReq.setDateOfBirth(ndMst.getDob());
				ndReq.setEmailIdOfNominee(ndMst.getEmail());
				if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian)) {
					if (!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getRelationId())) {
						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMstOfGuardian.getRelationId());
						ndReq.setRelationShipOfGuardianStr(relationShip);
						ndReq.setRelationShipOfGuardian(ndMstOfGuardian.getRelationId());
					}
					ndReq.setMobileNumberOfGuardian(!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getMobileNumber()) ? ndMst.getMobileNumber() : null);
					ndReq.setEmailIdOfGuardian(!OPLUtils.isObjectNullOrEmpty(ndMstOfGuardian.getEmail()) ? ndMstOfGuardian.getEmail() : null);
					ndReq.setAddressOfGuardian(ndMstOfGuardian.getAddress().getAddressLine1());
					ndReq.setNameOfGuardian(ndMstOfGuardian.getName());
				}
				ndReq.setAge(!OPLUtils.isObjectNullOrEmpty(ndMst.getDob()) ? CommonUtils.getAgeBydob(ndMst.getDob()) : null);
				ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());

				if (!OPLUtils.isObjectNullOrEmpty(ndMst.getRelationId())) {
					String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getRelationId());
					ndReq.setRelationOfNomineeApplicantStr(relationShip);
					ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());
				}

				if (!OPLUtils.isObjectNullOrEmpty(ndMst.getAddress())) {
					if (OPLUtils.isObjectNullOrEmpty(ndReq.getAddress())) {
						ndReq.setAddress(new AddressMasterRequest());
					}
					AddressMasterRequest req = new AddressMasterRequest();
					BeanUtils.copyProperties(ndMst.getAddress(), req);
					req.setCity(ndMst.getAddress().getCityName());
					req.setState(ndMst.getAddress().getStateName());
					ndReq.setAddress(req);
				}
				List<NomineeDetailsRequest> nomineeMasterList = new ArrayList<NomineeDetailsRequest>();
				nomineeMasterList.add(ndReq);
				mstReq.setNominee(nomineeMasterList);
			}

			TransactionDetailsV3 transactionDetails = mst.getLastTransactionDetails();
			// .findFirstByApplicationMasterIdAndTypeAndIsActiveTrue(mstReq.getId(),
			// CommonUtils.TYPE_ENROLLMENT);
			if (!OPLUtils.isObjectNullOrEmpty(transactionDetails)) {
				mstReq.setTransUtr(transactionDetails.getTransUtr());
				mstReq.setTransTimeStamp(transactionDetails.getTransTimeStamp());
				mstReq.setTransactionType(transactionDetails.getType());
				mstReq.setTransAmount(transactionDetails.getTransAmount());
				mstReq.setTransComment(transactionDetails.getTransComment());

				mstReq.setMasterPolicyNo(transactionDetails.getMasterPolicyNo());
				mstReq.setInsurerCode(transactionDetails.getInsurerCode());
				mstReq.setIsUpdateManually(transactionDetails.getIsUpdateManually());
				;
			}

			ApplicationMasterOtherDetailsV3 otherDetails = mst.getApplicationMasterOtherDetails();
			if (!OPLUtils.isObjectNullOrEmpty(otherDetails)) {
				mstReq.setSource(mst.getApplicationMasterOtherDetails().getSource());
				mstReq.setUserId1(otherDetails.getUserId1());
				mstReq.setUserId2(otherDetails.getUserId2());
				mstReq.setRuralUrbanSemi(otherDetails.getRuralUrbanSemi());
				mstReq.setChannelId(otherDetails.getChannelId());
				mstReq.setConsentForAutoDebit(otherDetails.getConsentForAutoDebit());
			}

			if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
				String orgResponse = usersClient.getOrganizationName(mst.getOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
					mstReq.setBankName(orgResponse);
				}
				mstReq.setOrgId(mst.getOrgId());
			}
			mstReq.setIfscCode(mst.getApplicantInfo().getIfsc());
			if (!OPLUtils.isObjectNullOrEmpty(mst.getBranchId())) {
				BranchBasicDetailsRequest branchDetails = usersClient.getBranch(mst.getBranchId());
				if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
					mstReq.setBranchName(branchDetails.getName());
//					mstReq.setIfscCode(branchDetails.getIfscCode());
				}
			} else {
				log.info("branchId not found from user Auth");
			}
			return mstReq;
		} catch (Exception e) {
			log.error("Exception is getting While Get insurance data ", e);
		}
		return null;
	}

	public static DedupApiReqProxy getCheckDedupeReq(ApplicationMasterV3 applicationMaster) {
		DedupApiReqProxy dedupRequest = new DedupApiReqProxy();
		dedupRequest.setKycId1(applicationMaster.getApplicantInfo().getKycId1());
		dedupRequest.setKycIdValue1(applicationMaster.getApplicantInfo().getKycIdNumber1());
		dedupRequest.setKycId2(applicationMaster.getApplicantInfo().getKycId2());
		dedupRequest.setKycIdValue2(applicationMaster.getApplicantInfo().getKycIdNumber2());
		dedupRequest.setCkycNumber(applicationMaster.getApplicantInfo().getCkycNumber());
		dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGender()) ? applicationMaster.getApplicantInfo().getGender().getValue() : null);
		dedupRequest.setFirstName(applicationMaster.getApplicantInfo().getFirstName());
		dedupRequest.setMiddleName(applicationMaster.getApplicantInfo().getMiddleName());
		dedupRequest.setLastName(applicationMaster.getApplicantInfo().getLastName());
		dedupRequest.setFatherHusbandName(applicationMaster.getApplicantInfo().getFatherHusbandName());
		dedupRequest.setMob(applicationMaster.getApplicantInfo().getMobileNumber());
		dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress()) ? applicationMaster.getApplicantInfo().getAddress().getPincode() : null);
		dedupRequest.setDob(CommonUtils.formatDate_sdf(applicationMaster.getApplicantInfo().getDob()));
		dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
		dedupRequest.setAccNo(applicationMaster.getAccountNumber());
		dedupRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
		dedupRequest.setAccountStatus("A");
		dedupRequest.setType("N");
		dedupRequest.setOrgId(applicationMaster.getOrgId());
		dedupRequest.setInsurerOrgId(applicationMaster.getInsurerOrgId());
		dedupRequest.setCif(applicationMaster.getCif());
		dedupRequest.setUrn(applicationMaster.getUrn());
		return dedupRequest;
	}

	private CommonResponse checkDedupeOrgIdWithCif(ApplicationMasterV3 applicationMasterNewRec, String cif, AuthClientResponse authRes) {
		ApplicationMasterV3 applicationMaster = applicationMasterRepo.findFirstByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusInAndIdNot(authRes.getUserOrgId(), applicationMasterNewRec.getSchemeId(), cif,
				inProcessOrCompletedApplication, applicationMasterNewRec.getId());
		if (!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
			return callEnrollmentDedupee(applicationMaster, authRes, applicationMasterNewRec);
		}
		return null;
	}

	public CommonResponse callEnrollmentDedupee(ApplicationMasterV3 applicationMaster, AuthClientResponse authRes, ApplicationMasterV3 applicationMasterNewRec) {
		if (Objects.equals(applicationMaster.getApplicationStatus(), ApplicationStatus.ENROLL_IN_PROGRESS.getId())) {
			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId()) && applicationMaster.getOrgId().equals(authRes.getUserOrgId())) {
				updateAppMasterErro(applicationMasterNewRec, CommonUtils.ALREADY_ENROLLMENT_INPROCESS, authRes.getUserId());
				return new CommonResponse(CommonUtils.ALREADY_ENROLLMENT_INPROCESS, ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
			} else {
				String organizationName = usersClient.getOrganizationName(applicationMaster.getOrgId());
				updateAppMasterErro(applicationMasterNewRec, CommonUtils.ALREADY_ENROLLMENT_INPROCESS + " with the bank (" + organizationName + ").", authRes.getUserId());
				return new CommonResponse(CommonUtils.ALREADY_ENROLLMENT_INPROCESS + " with the bank (" + organizationName + ").", "", ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
			}
		} else {
			updateAppMasterErro(applicationMasterNewRec, HttpStatus.ALREADY_REPORTED.getReasonPhrase(), authRes.getUserId());
			return new CommonResponse(HttpStatus.ALREADY_REPORTED.getReasonPhrase(), ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
		}
	}

	public ApplicationMasterV3 addBranchDetailsForBorrower(AccountHolderDetailsResponseV3 wrap, ApplicationMasterV3 appMaster, AuthClientResponse authRes) {
		ApplicationMasterOtherDetailsV3 otherDetailsFetch = appMaster.getApplicationMasterOtherDetails();
		if (Objects.equals(appMaster.getApplicationMasterOtherDetails().getSource(), Source.JANSURAKSHA_DIY.getId())) {
			Map<String, Object> branchData = userManagementClient.getBranchMappingByIfscCodeAndSchemeId(wrap.getCustomerIFSC(), appMaster.getSchemeId().longValue());
			if (!OPLUtils.isObjectNullOrEmpty(branchData)) {
				otherDetailsFetch.setBranchRoId(OPLUtils.isObjectNullOrEmpty(branchData.get("branchRoId")) ? null : Long.valueOf(branchData.get("branchRoId").toString()));
				otherDetailsFetch.setBranchZoId(OPLUtils.isObjectNullOrEmpty(branchData.get("branchZoId")) ? null : Long.valueOf(branchData.get("branchZoId").toString()));
				otherDetailsFetch.setBranchLhoId(OPLUtils.isObjectNullOrEmpty(branchData.get("branchLhoId")) ? null : Long.valueOf(branchData.get("branchLhoId").toString()));
				otherDetailsFetch.setBranchCityId(OPLUtils.isObjectNullOrEmpty(branchData.get("cityId")) ? null : Long.valueOf(branchData.get("cityId").toString()));
				otherDetailsFetch.setBranchStateId(OPLUtils.isObjectNullOrEmpty(branchData.get("stateId")) ? null : Long.valueOf(branchData.get("stateId").toString()));
				otherDetailsFetch.setBranchCode(OPLUtils.isObjectNullOrEmpty(branchData.get("branchCode")) ? null : branchData.get("branchCode").toString());
				otherDetailsFetch.setRuralUrbanId(OPLUtils.isObjectNullOrEmpty(branchData.get("ruralUrbanId")) ? null : Integer.valueOf(branchData.get("ruralUrbanId").toString()));
				otherDetailsFetch.setApplicationMaster(appMaster);
				appMaster.setBranchId(OPLUtils.isObjectNullOrEmpty(branchData.get("branchId")) ? null : Long.valueOf(String.valueOf(branchData.get("branchId"))));
				appMaster.setApplicationMasterOtherDetails(otherDetailsFetch);

			} else {
				return null;
			}
		}
		return appMaster;
	}

	public void regenerateOldCoi(RegenerateCoiProxy regenerateCoiProxy) throws Exception {

		Page<Long> applicationIdLst = applicationMasterRepo.getApplicationIdListByDateFilter(regenerateCoiProxy.getFromDate(), regenerateCoiProxy.getToDate(),
				PageRequest.of(regenerateCoiProxy.getPaginationFrom(), regenerateCoiProxy.getPaginationTo()));

		if (!applicationIdLst.isEmpty()) {
			applicationIdLst.forEach(x -> {
				try {
					pushStorageId(x);
				} catch (Exception e) {
					log.error("Exception While calling pushStorageId method :: ", e);
				}
			});
		}

	}

	@Async
	public void pushStorageId(Long applicationId) throws Exception {

		/**generate coi*/
		byte[] coiInByte = generateCOI(applicationId, true);

		ApplicationMasterV3 master = applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);

		if(!OPLUtils.isObjectNullOrEmpty(master.getSchemeId())) {
			ApplicationMasterBothSchemeProxy appMaster = ereCommonService
					.getJnsMasterDataApplicationMaster(master.getSchemeId().longValue(), applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(appMaster)) {
				TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findById(appMaster.getLastTransactionId()).get();
				transactionDetailsV2.setCoiStorageId(master.getLastTransactionDetails().getCoiStorageId());
				transactionDetailsRepositoryV2.save(transactionDetailsV2);
				if (SchemeMaster.PMSBY.getId() == master.getSchemeId().longValue()) {
					PMSBY pmsby = MultipleJSONObjectHelper.getObjectFromObject(appMaster, PMSBY.class);
					pmsbyRepository.save(pmsby);
				} else if (SchemeMaster.PMJJBY.getId() == master.getSchemeId().longValue()) {
					PMJJBY pmjjby = MultipleJSONObjectHelper.getObjectFromObject(appMaster, PMJJBY.class);
					pmjjbyRepository.save(pmjjby);
				}
			}
		}
		
		if (!OPLUtils.isObjectNullOrEmpty(master)) {
			String url = configProperties.getValueByCode("PUBLISH_DOMAIN").concat("pushStorageId/" + applicationId + "/" + master.getLastTransactionDetails().getCoiStorageId());
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
				headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
				headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
				RestTemplate restTemplate = new RestTemplate();
				CommonResponse commonResponse = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
				if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus() == HttpStatus.OK.value() && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && Boolean.TRUE.equals(commonResponse.getData())) {
					/* SEND EMAIL AND SMS IN CASE OF COI */
					ContentAttachment contentAttachment = new ContentAttachment();
					contentAttachment.setContentInByte(coiInByte);
					contentAttachment.setFileName("Certificate-of-insurance-" + master.getUrn() + ".pdf");

					List<ContentAttachment>attachementList = new ArrayList<>();
					attachementList.add(contentAttachment);
					/*SEND EMAIL*/
					String urn=OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn();
					String insuredName= OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getName()) ? null : master.getApplicantInfo().getName();
					String schemeName=OPLUtils.isObjectNullOrEmpty(master.getSchemeId()) ? null : SchemeMaster.getById(Long.valueOf(master.getSchemeId())).getShortName();
					Double amount=OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getTransAmount()) ? null : master.getLastTransactionDetails().getTransAmount();
					Integer year=OPLUtils.isObjectNullOrEmpty(master.getLastTransactionDetails().getYear()) ? null : master.getLastTransactionDetails().getYear() + 1;
					Long orgId=OPLUtils.isObjectNullOrEmpty(master.getOrgId()) ? null : master.getOrgId();

					Map<String, Object> emailParameters = new HashMap<>();
					emailParameters.put("insuredName", insuredName);
					emailParameters.put("amountOfPremium", amount);
					emailParameters.put("nameOfScheme", schemeName);
					emailParameters.put("urn", urn.substring(4));
					emailParameters.put("year", year);
					emailParameters.put("source", master.getApplicationMasterOtherDetails().getSource());
					emailParameters.put("orgId", orgId);

					Long smsTmpId = null;
					if(schemeName.equals("PMSBY")) {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMSBY;
					}else {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_ENROLLMENT_SUCESS_PMJJBY;
					}
					
					String email = OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getEmail()) ? null : master.getApplicantInfo().getEmail();
					String mobile = OPLUtils.isObjectNullOrEmpty(master.getApplicantInfo().getMobileNumber()) ? null : master.getApplicantInfo().getMobileNumber();
					notificationUtil.sendNotification(emailParameters,email,mobile, JnsNotificationMasterUtil.EMAIL_CUST_ENROLLMENT_SUCESS,
							smsTmpId, attachementList);
					log.info("StorageId is Pushed successfully");
				} else {
					String message = OPLUtils.isObjectNullOrEmpty(commonResponse) ? null : commonResponse.getMessage();
					log.info("Error in pushing StorageId for application [{}]: and message : [{}]", applicationId, message);
				}
			} catch (Exception e) {
				log.error("Exception While calling Public API :: ", e);
			}

		}
	}
	
	/** common method for response JAVAX validation*/
	public static <T> StringBuilder validateResponse(T object) throws ValidationException {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<T>> violations = validator.validate(object);

        if (!violations.isEmpty()) {
        	StringBuilder sb = new StringBuilder();
			for (ConstraintViolation<T> constraintViolation : violations) {
				if (sb.length() > 0) {
					sb.append(", " + constraintViolation.getMessage());
				} else {
					sb.append(constraintViolation.getMessage());
				}
			}
			return sb;
        }
		return null;
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<EnrollmentDetailsProxy> fetchEnrollmentDetails(EnrollmentDtlProxy enrollmentDtlProxy) {
		try {
			List<ApplicationMasterV3> applicationMasterV3 = applicationMasterRepo
					.findAllByUrn(enrollmentDtlProxy.getUrn());
			
			List<ApplicationMasterBothSchemeProxy> masterDataV3 = null;
			if(OPLUtils.isListNullOrEmpty(applicationMasterV3)) {
				PMSBY pmsby = pmsbyRepository.findByUrnAndIsActiveTrue(enrollmentDtlProxy.getUrn());
				if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
					List<PMSBY> pmsbyLst = Arrays.asList(pmsby);
					pmsbyLst = pmsbyLst.stream()
							.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())
									|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId())
									|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()))))
							.collect(Collectors.toList());
					masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
							MultipleJSONObjectHelper.getStringfromObject(pmsbyLst), null,
							ApplicationMasterBothSchemeProxy.class);
				}
					if (OPLUtils.isObjectNullOrEmpty(masterDataV3)) {
						PMJJBY pmjjby = pmjjbyRepository.findByUrnAndIsActiveTrue(enrollmentDtlProxy.getUrn());
						if(!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
							List<PMJJBY> pmjjbyLst = Arrays.asList(pmjjby);
							pmjjbyLst = pmjjbyLst.stream()
									.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())
											|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId())
											|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()))))
									.collect(Collectors.toList());
							if (!OPLUtils.isListNullOrEmpty(pmjjbyLst)) {
								masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
										MultipleJSONObjectHelper.getStringfromObject(pmjjbyLst), null,
										ApplicationMasterBothSchemeProxy.class);
							}
						}
					}
					if(!OPLUtils.isListNullOrEmpty(masterDataV3)) {
						List<EnrollmentDetailsProxy> enrollDtlLst = new ArrayList<>();
						for (ApplicationMasterBothSchemeProxy mst : masterDataV3) {
							EnrollmentDetailsProxy enrollmentDetails = new EnrollmentDetailsProxy();
							enrollmentDetails.setUrn(mst.getUrn());
							enrollmentDetails.setCreatedDate(getDateStr(mst.getCreatedDate()));
							enrollmentDetails.setModifiedDate(getDateStr(mst.getModifiedDate()));
							enrollmentDetails.setEnrollmentDate(getDateStr(mst.getEnrollmentDate()));
							enrollmentDetails.setEnrollStatus(ApplicationStatus.fromId(mst.getStatus()).getValue());
							
							TransactionDetailsV2 transactionDetails = transactionDetailsRepositoryV2.findById(mst.getLastTransactionId()).orElse(null);
							
							if(!OPLUtils.isObjectNullOrEmpty(transactionDetails)) {
								if (!OPLUtils.isObjectNullOrEmpty(mst.getEnrollType())) {
									enrollmentDetails
											.setTransactionDate(getDateStr(transactionDetails.getTransTimeStamp()));
									enrollmentDetails.setStatus(
											EnrollTypeEnum.fromId(mst.getEnrollType()).getValue());
								}
							}
							enrollmentDetails.setEnrollmentCompletedDate(
									!OPLUtils.isObjectNullOrEmpty(mst.getCompletionDate()) ? getDateStr(mst.getCompletionDate())
											: null);

							if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
								String orgResponse = usersClient.getOrganizationName(mst.getOrgId());
								if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
									enrollmentDetails.setBankName(orgResponse);
								}
							}
							if (!OPLUtils.isObjectNullOrEmpty(mst.getBranchId())) {
								BranchBasicDetailsRequest branchDetails = usersClient.getBranch(mst.getBranchId());
								if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
									enrollmentDetails.setBranchName(branchDetails.getName());
								}
							}
							
							if(!OPLUtils.isObjectNullOrEmpty(mst.getInsurerOrgId())) {						
								BranchAndOrgDetailsProxy orgDetls = userManagementClient.getOrganisationDetails(mst.getOrgId(),
										mst.getBranchId(), mst.getInsurerOrgId());
								if (!OPLUtils.isObjectNullOrEmpty(orgDetls)) {
									enrollmentDetails.setInsurer(orgDetls.getInsurerName());
								}
							}

							enrollmentDetails.setMode(Source.fromId(mst.getSource()).getMode());
							if(!OPLUtils.isObjectNullOrEmpty(mst.getPremiumAmount())) {						
								enrollmentDetails.setPremiumAmt(mst.getPremiumAmount() + "rs");
							}
							enrollmentDetails.setSchemeName(!OPLUtils.isObjectNullOrEmpty(pmsby) ? SchemeMaster.PMSBY.getShortName() : SchemeMaster.PMJJBY.getShortName());
//							enrollmentDetails
//									.setStageName(EnrollStageMaster.getStageMasterByStageId(mst.getStageId()).getStageName());
							
							ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(mst.getId()).orElse(null);
							if(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {								
								enrollmentDetails.setAccountNumber(OPLUtils.convertToMask(applicantPIDetails.getAccountNumber(), 4, "X"));
								enrollmentDetails.setCif(OPLUtils.convertToMask(applicantPIDetails.getCif(), 4, "X"));
							}
							
							ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(mst.getId())
									.orElse(null);
							if (!OPLUtils.isObjectNullOrEmpty(applicationPushStatus)
									&& !OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getMasterPush())) {
								enrollmentDetails
										.setPublished(Boolean.TRUE.equals(applicationPushStatus.getMasterPush()) ? "Yes" : "No");
								enrollmentDetails.setPublishedDate(applicationPushStatus.getMasterPushDate());
							}
							enrollmentDetails.setActive(
									!OPLUtils.isObjectNullOrEmpty(mst.getIsActive()) && Boolean.TRUE.equals(mst.getIsActive())
											? "Yes"
											: "No");

							BankAllApisResProxy fetchAllApisResponse = bankApiClient.fetchAllApisResponse(mst.getUrn());
							if (!OPLUtils.isObjectNullOrEmpty(fetchAllApisResponse)) {
								enrollmentDetails.setSendOtpRes(fetchAllApisResponse.getTriggerOtpRes());
								enrollmentDetails.setVerifyOtpRes(fetchAllApisResponse.getVerifyOtpRes());
								enrollmentDetails.setPhysicalVerificationRes(fetchAllApisResponse.getPhysicalVerificationRes());
								enrollmentDetails.setCustInfoRes(fetchAllApisResponse.getCustomerDetailsRes());
								enrollmentDetails.setPremiumDeductionRes(fetchAllApisResponse.getPremiumDeductionRes());
							}
							enrollDtlLst.add(enrollmentDetails);
						}
						return enrollDtlLst;
					}
			}else {
				if (!OPLUtils.isListNullOrEmpty(applicationMasterV3)) {
					List<EnrollmentDetailsProxy> enrollDtlLst = new ArrayList<>();
					for (ApplicationMasterV3 mst : applicationMasterV3) {
						EnrollmentDetailsProxy enrollmentDetails = new EnrollmentDetailsProxy();
						enrollmentDetails.setUrn(mst.getUrn());
						enrollmentDetails.setCreatedDate(getDateStr(mst.getCreatedDate()));
						enrollmentDetails.setModifiedDate(getDateStr(mst.getModifiedDate()));
						enrollmentDetails.setEnrollmentDate(getDateStr(mst.getEnrollmentDate()));
						enrollmentDetails.setEnrollStatus(ApplicationStatus.fromId(mst.getApplicationStatus()).getValue());
						if (!OPLUtils.isObjectNullOrEmpty(mst.getEnrollType()) && !OPLUtils.isObjectNullOrEmpty(mst.getLastTransactionDetails())) {
							enrollmentDetails
									.setTransactionDate(getDateStr(mst.getLastTransactionDetails().getTransTimeStamp()));
							enrollmentDetails.setStatus(
									EnrollTypeEnum.fromId(mst.getEnrollType()).getValue());
						}
						enrollmentDetails.setEnrollmentCompletedDate(
								!OPLUtils.isObjectNullOrEmpty(mst.getCompletionDate()) ? getDateStr(mst.getCompletionDate())
										: null);

						if (!OPLUtils.isObjectNullOrEmpty(mst.getOrgId())) {
							String orgResponse = usersClient.getOrganizationName(mst.getOrgId());
							if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
								enrollmentDetails.setBankName(orgResponse);
							}
						}
						if (!OPLUtils.isObjectNullOrEmpty(mst.getBranchId())) {
							BranchBasicDetailsRequest branchDetails = usersClient.getBranch(mst.getBranchId());
							if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
								enrollmentDetails.setBranchName(branchDetails.getName());
							}
						}
						
						if(!OPLUtils.isObjectNullOrEmpty(mst.getInsurerOrgId())) {						
							BranchAndOrgDetailsProxy orgDetls = userManagementClient.getOrganisationDetails(mst.getOrgId(),
									mst.getBranchId(), mst.getInsurerOrgId());
							if (!OPLUtils.isObjectNullOrEmpty(orgDetls)) {
								enrollmentDetails.setInsurer(orgDetls.getInsurerName());
							}
						}

						if(!OPLUtils.isObjectNullOrEmpty(mst.getApplicationMasterOtherDetails()) && !OPLUtils.isObjectNullOrEmpty(mst.getApplicationMasterOtherDetails().getSource())) {						
							enrollmentDetails
							.setMode(Source.fromId(mst.getApplicationMasterOtherDetails().getSource()).getMode());
						}
						if(!OPLUtils.isObjectNullOrEmpty(mst.getPremiumAmount())) {						
							enrollmentDetails.setPremiumAmt(mst.getPremiumAmount() + "rs");
						}
						enrollmentDetails.setSchemeName(SchemeMaster.getById(mst.getSchemeId().longValue()).getShortName());
						enrollmentDetails
								.setStageName(EnrollStageMaster.getStageMasterByStageId(mst.getStageId()).getStageName());
						enrollmentDetails.setAccountNumber(OPLUtils.convertToMask(mst.getAccountNumber(), 4, "X"));
						enrollmentDetails.setCif(OPLUtils.convertToMask(mst.getCif(), 4, "X"));
						
						ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(mst.getId())
								.orElse(null);
						if (!OPLUtils.isObjectNullOrEmpty(applicationPushStatus)
								&& !OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getMasterPush())) {
							enrollmentDetails
									.setPublished(Boolean.TRUE.equals(applicationPushStatus.getMasterPush()) ? "Yes" : "No");
							enrollmentDetails.setPublishedDate(applicationPushStatus.getMasterPushDate());
						}
						enrollmentDetails.setActive(
								!OPLUtils.isObjectNullOrEmpty(mst.getIsActive()) && Boolean.TRUE.equals(mst.getIsActive())
										? "Yes"
										: "No");

						BankAllApisResProxy fetchAllApisResponse = bankApiClient.fetchAllApisResponse(mst.getUrn());
						if (!OPLUtils.isObjectNullOrEmpty(fetchAllApisResponse)) {
							enrollmentDetails.setSendOtpRes(fetchAllApisResponse.getTriggerOtpRes());
							enrollmentDetails.setVerifyOtpRes(fetchAllApisResponse.getVerifyOtpRes());
							enrollmentDetails.setPhysicalVerificationRes(fetchAllApisResponse.getPhysicalVerificationRes());
							enrollmentDetails.setCustInfoRes(fetchAllApisResponse.getCustomerDetailsRes());
							enrollmentDetails.setPremiumDeductionRes(fetchAllApisResponse.getPremiumDeductionRes());
						}
						enrollDtlLst.add(enrollmentDetails);
					}
					return enrollDtlLst;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error while fetchEnrollmentDetails----------> " + e);
		}
		return null;

	} 
	
	/**date to string format*/
	public String getDateStr(Date date) {
		if (!OPLUtils.isObjectNullOrEmpty(date)) {
			return CommonUtils.sdf_dd_MM_yyyy_HH_mm_ss_SS.format(date);
		}
		return null;
	}
	
	@Override
	public List<EnrollmentDetailsProxy> fetchAllUrnByUrnAndStageId(EnrollmentDtlProxy enrollmentDtlProxy) {
		try {
			List<ApplicationMasterV3> applicationMasterV3 = null;
			List<ApplicationMasterBothSchemeProxy> masterDataV3 = null;
			List<ExpiredEnrollment> expiredData = null;
			Long appCount = 0l;
			if (Objects.equals(enrollmentDtlProxy.getType(), SupportDashboardSearch.URN.getId())) {
				return getSetAndUrnFilterData(enrollmentDtlProxy,masterDataV3,appCount,applicationMasterV3,expiredData);
			} else if (Objects.equals(enrollmentDtlProxy.getType(), SupportDashboardSearch.APPLICATION_ID.getId())) {
				return getSetAndApplicationIdFilterData(enrollmentDtlProxy,masterDataV3,appCount,applicationMasterV3,expiredData);
			} else if (Objects.equals(enrollmentDtlProxy.getType(), SupportDashboardSearch.ACCOUNT_NO.getId())) {
				return getSetAndAccountNumberFilterData(enrollmentDtlProxy, appCount, applicationMasterV3);
			} else {
				return getSetAndUserIdFilterData(enrollmentDtlProxy,masterDataV3,appCount,applicationMasterV3,expiredData);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error while fetchAllUrnByUrnAndStageId----------> " + e);
		}
		return Collections.emptyList();
	} 
	
	@SuppressWarnings("unchecked")
	public List<EnrollmentDetailsProxy> getSetAndUrnFilterData(EnrollmentDtlProxy enrollmentDtlProxy,
			List<ApplicationMasterBothSchemeProxy> masterDataV3, Long appCount,
			List<ApplicationMasterV3> applicationMasterV3, List<ExpiredEnrollment> expiredData)
			throws NumberFormatException, IOException {
		if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.COMPLETED) {
			PMSBY pmsby = pmsbyRepository.findByUrnAndIsActiveTrue(enrollmentDtlProxy.getSearchData());
			if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
				List<PMSBY> pmsbyLst = Arrays.asList(pmsby);
				pmsbyLst = pmsbyLst.stream()
						.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())
								|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId())
								|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()))))
						.collect(Collectors.toList());
				masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
						MultipleJSONObjectHelper.getStringfromObject(pmsbyLst), null,
						ApplicationMasterBothSchemeProxy.class);
			}
				if (OPLUtils.isObjectNullOrEmpty(masterDataV3)) {
					PMJJBY pmjjby = pmjjbyRepository.findByUrnAndIsActiveTrue(enrollmentDtlProxy.getSearchData());
					if(!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
						List<PMJJBY> pmjjbyLst = Arrays.asList(pmjjby);
						pmjjbyLst = pmjjbyLst.stream()
								.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())
										|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId())
										|| Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()))))
								.collect(Collectors.toList());
						if (!OPLUtils.isListNullOrEmpty(pmjjbyLst)) {
							masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
									MultipleJSONObjectHelper.getStringfromObject(pmjjbyLst), null,
									ApplicationMasterBothSchemeProxy.class);
						}						
					}
				}
			return setMstData(masterDataV3, appCount);
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.INPROCESS_TRANS_FAILED) {
			ApplicationMasterV3 masterV3= applicationMasterRepo.findByUrn(enrollmentDtlProxy.getSearchData());
			if (!OPLUtils.isObjectNullOrEmpty(masterV3)) {
				applicationMasterV3 = Arrays.asList(masterV3);
				applicationMasterV3 = applicationMasterV3.stream().filter(
						x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_IN_PROGRESS.getId()))))
						.collect(Collectors.toList());
			}
			return setApplicationData(applicationMasterV3, appCount);
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.REJECTED_EXPIRED) {
			ExpiredEnrollment expiredEnrollment= expiredEnrollmentRepository.findByUrnAndIsActiveTrue(enrollmentDtlProxy.getSearchData());
			if (!OPLUtils.isObjectNullOrEmpty(expiredEnrollment)) {
				expiredData = Arrays.asList(expiredEnrollment);
				expiredData = expiredData.stream()
						.filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_REJECTED.getId()))
								|| (Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_EXPIRED.getId()))))
						.collect(Collectors.toList());
			}
			return setExpiredData(expiredData, appCount);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<EnrollmentDetailsProxy> getSetAndUserIdFilterData(EnrollmentDtlProxy enrollmentDtlProxy,
			List<ApplicationMasterBothSchemeProxy> masterDataV3, Long appCount,
			List<ApplicationMasterV3> applicationMasterV3, List<ExpiredEnrollment> expiredData)
			throws NumberFormatException, IOException {
		if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.COMPLETED) {
			List<PMSBY> pmsbyLst = pmsbyRepository.findByCreatedByAndStatusInAndIsActiveTrue(enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_COMPLETED.getId(),ApplicationStatus.OPT_OUT.getId(),ApplicationStatus.OPT_OUT_IN_PROCESS.getId()),PageRequest.of(enrollmentDtlProxy.getPaginationFROM(), enrollmentDtlProxy.getPaginationTO()));
			if (!OPLUtils.isListNullOrEmpty(pmsbyLst)) {
				masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
						MultipleJSONObjectHelper.getStringfromObject(pmsbyLst), null,
						ApplicationMasterBothSchemeProxy.class);
				appCount = pmsbyRepository.countByCreatedByAndStatusInAndIsActiveTrue(enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_COMPLETED.getId(),ApplicationStatus.OPT_OUT.getId(),ApplicationStatus.OPT_OUT_IN_PROCESS.getId()));
				if (OPLUtils.isObjectNullOrEmpty(masterDataV3)) {
					List<PMJJBY> pmjjbyLst = pmjjbyRepository.findByCreatedByAndStatusInAndIsActiveTrue(enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_COMPLETED.getId(),ApplicationStatus.OPT_OUT.getId(),ApplicationStatus.OPT_OUT_IN_PROCESS.getId()),PageRequest.of(enrollmentDtlProxy.getPaginationFROM(), enrollmentDtlProxy.getPaginationTO()));
					if (!OPLUtils.isListNullOrEmpty(pmjjbyLst)) {
						masterDataV3 = MultipleJSONObjectHelper.getListOfObjects(
								MultipleJSONObjectHelper.getStringfromObject(pmjjbyLst), null,
								ApplicationMasterBothSchemeProxy.class);
					}
					appCount = pmjjbyRepository.countByCreatedByAndStatusInAndIsActiveTrue(enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_COMPLETED.getId(),ApplicationStatus.OPT_OUT.getId(),ApplicationStatus.OPT_OUT_IN_PROCESS.getId()));
				}
			}
			return setMstData(masterDataV3, appCount);
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.INPROCESS_TRANS_FAILED) {
			applicationMasterV3 = applicationMasterRepo.findAllByIsActiveTrueAndUserIdAndStatus(
					enrollmentDtlProxy.getUserId(),ApplicationStatus.ENROLL_IN_PROGRESS.getId(),PageRequest.of(enrollmentDtlProxy.getPaginationFROM(), enrollmentDtlProxy.getPaginationTO()));
			appCount = applicationMasterRepo.countByIsActiveTrueAndUserIdAndApplicationStatus(enrollmentDtlProxy.getUserId(),ApplicationStatus.ENROLL_IN_PROGRESS.getId());
			return setApplicationData(applicationMasterV3, appCount);
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.REJECTED_EXPIRED) {
			expiredData = expiredEnrollmentRepository.findAllByIsActiveTrueAndUserIdAndStatusIn(
					enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_EXPIRED.getId(),ApplicationStatus.ENROLL_REJECTED.getId()),PageRequest.of(enrollmentDtlProxy.getPaginationFROM(), enrollmentDtlProxy.getPaginationTO()));
			if (!OPLUtils.isListNullOrEmpty(expiredData)) {
				appCount = expiredEnrollmentRepository.countByCreatedByAndIsActiveTrueAndStatusIn(enrollmentDtlProxy.getUserId(),Arrays.asList(ApplicationStatus.ENROLL_EXPIRED.getId(),ApplicationStatus.ENROLL_REJECTED.getId()));
			}
			return setExpiredData(expiredData, appCount);
		}
		return Collections.emptyList();
	}
	
	public List<EnrollmentDetailsProxy> getSetAndAccountNumberFilterData(EnrollmentDtlProxy enrollmentDtlProxy,
			Long appCount,
			List<ApplicationMasterV3> applicationMasterV3) {
		applicationMasterV3 = applicationMasterRepo
				.findByIsActiveTrueAndAccountNumber(enrollmentDtlProxy.getSearchData());
		if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.COMPLETED) {
			applicationMasterV3 = applicationMasterV3.stream()
					.filter(x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_COMPLETED.getId())
							|| Objects.equals(x.getApplicationStatus(), ApplicationStatus.OPT_OUT.getId())
							|| Objects.equals(x.getApplicationStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId()))))
					.collect(Collectors.toList());
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.INPROCESS_TRANS_FAILED) {
			applicationMasterV3 = applicationMasterV3.stream().filter(
					x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_IN_PROGRESS.getId()))))
					.collect(Collectors.toList());
		} else if (enrollmentDtlProxy.getDisplayTypeId() == CommonUtils.REJECTED_EXPIRED) {
			applicationMasterV3 = applicationMasterV3.stream()
					.filter(x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_REJECTED.getId()))
							|| (Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_EXPIRED.getId()))))
					.collect(Collectors.toList());
		}
		return setApplicationData(applicationMasterV3, appCount);
	}

	public List<EnrollmentDetailsProxy> getSetAndApplicationIdFilterData(EnrollmentDtlProxy enrollmentDtlProxy,
			List<ApplicationMasterBothSchemeProxy> masterDataV3, Long appCount,
			List<ApplicationMasterV3> applicationMasterV3, List<ExpiredEnrollment> expiredData) throws NumberFormatException, IOException {
		if(enrollmentDtlProxy.getDisplayTypeId()==CommonUtils.COMPLETED) {	
			ApplicationMasterBothSchemeProxy masterDataApplicationMaster = null;
			masterDataApplicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMSBY.getId(),Long.valueOf(enrollmentDtlProxy.getSearchData()));
			if(OPLUtils.isObjectNullOrEmpty(masterDataApplicationMaster)) {
				masterDataApplicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMJJBY.getId(),Long.valueOf(enrollmentDtlProxy.getSearchData()));	
			}
			if(!OPLUtils.isObjectNullOrEmpty(masterDataApplicationMaster)) {
				masterDataV3=Arrays.asList(masterDataApplicationMaster);
				masterDataV3 = masterDataV3.stream().filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_COMPLETED.getId()) || Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT.getId()) || Objects.equals(x.getStatus(), ApplicationStatus.OPT_OUT_IN_PROCESS.getId())))).collect(Collectors.toList());
			}
			return setMstData(masterDataV3, appCount);
		}else if(enrollmentDtlProxy.getDisplayTypeId()==CommonUtils.INPROCESS_TRANS_FAILED) {
			ApplicationMasterV3 appMst= applicationMasterRepo.findByIdAndIsActiveTrue(Long.valueOf(enrollmentDtlProxy.getSearchData()));
			if(!OPLUtils.isObjectNullOrEmpty(appMst)) {						
				applicationMasterV3=Arrays.asList(appMst);
				applicationMasterV3 = applicationMasterV3.stream().filter(x -> ((Objects.equals(x.getApplicationStatus(), ApplicationStatus.ENROLL_IN_PROGRESS.getId())))).collect(Collectors.toList());
			}
			return setApplicationData(applicationMasterV3, appCount);
		}else if(enrollmentDtlProxy.getDisplayTypeId()==CommonUtils.REJECTED_EXPIRED) {
			ExpiredEnrollment expiredEnrollment = expiredEnrollmentRepository.findByIdAndIsActiveTrue(Long.valueOf(enrollmentDtlProxy.getSearchData()));
			if(!OPLUtils.isObjectNullOrEmpty(expiredEnrollment)) {						
				expiredData=Arrays.asList(expiredEnrollment);
				expiredData = expiredData.stream().filter(x -> ((Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_REJECTED.getId())) || (Objects.equals(x.getStatus(), ApplicationStatus.ENROLL_EXPIRED.getId())))).collect(Collectors.toList());
			}
			return setExpiredData(expiredData, appCount);
		}
		return null;
	}
	
	public List<EnrollmentDetailsProxy> setApplicationData(List<ApplicationMasterV3> applicationMasterV3,Long appCount) {
		if (!OPLUtils.isListNullOrEmpty(applicationMasterV3)) {
			List<EnrollmentDetailsProxy> enrollDtlLst = new ArrayList<>();
			for (ApplicationMasterV3 mst : applicationMasterV3) {
				EnrollmentDetailsProxy enrollmentDetails = new EnrollmentDetailsProxy();
				enrollmentDetails.setUrn(mst.getUrn());
				enrollmentDetails.setStageName(EnrollStageMaster.getStageMasterByStageId(mst.getStageId()).getStageName());
				enrollmentDetails.setStatus(ApplicationStatus.fromId(mst.getApplicationStatus()).getValue());
				enrollmentDetails.setTotalCount(appCount);
				enrollDtlLst.add(enrollmentDetails);
			}
			return enrollDtlLst;
		}
		return null;
	}
	
	public List<EnrollmentDetailsProxy> setMstData(List<ApplicationMasterBothSchemeProxy> applicationMasterV3,Long appCount) {
		if (!OPLUtils.isListNullOrEmpty(applicationMasterV3)) {
			List<EnrollmentDetailsProxy> enrollDtlLst = new ArrayList<>();
			for (ApplicationMasterBothSchemeProxy mst : applicationMasterV3) {
				EnrollmentDetailsProxy enrollmentDetails = new EnrollmentDetailsProxy();
				enrollmentDetails.setUrn(mst.getUrn());
//				enrollmentDetails.setStageName(EnrollStageMaster.getStageMasterByStageId(mst.getStageId()).getStageName());
				enrollmentDetails.setStatus(ApplicationStatus.fromId(mst.getStatus()).getValue());
				enrollmentDetails.setTotalCount(appCount);
				enrollDtlLst.add(enrollmentDetails);
			}
			return enrollDtlLst;
		}
		return null;
	}
	
	public List<EnrollmentDetailsProxy> setExpiredData(List<ExpiredEnrollment> expiredEnroll,Long appCount) {
		if (!OPLUtils.isListNullOrEmpty(expiredEnroll)) {
			List<EnrollmentDetailsProxy> enrollDtlLst = new ArrayList<>();
			for (ExpiredEnrollment mst : expiredEnroll) {
				EnrollmentDetailsProxy enrollmentDetails = new EnrollmentDetailsProxy();
				enrollmentDetails.setUrn(mst.getUrn());
				enrollmentDetails.setStageName(EnrollStageMaster.getStageMasterByStageId(mst.getStageId()).getStageName());
				enrollmentDetails.setStatus(ApplicationStatus.fromId(mst.getStatus()).getValue());
				enrollmentDetails.setTotalCount(appCount);
				enrollDtlLst.add(enrollmentDetails);
			}
			return enrollDtlLst;
		}
		return Collections.emptyList();
	}
	
	@Override
	public ApplicationMasterRequestV2 getApplicationFormDetailsNewDb(Long applicationId, Long schemeId,
			AuthClientResponse authClientResponse) {
		try {
			
			/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
			ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(schemeId, applicationId);
			
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return null;
			}

			ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Applicant info PI details not found by application id -->" + applicationId);
				return null;
			}

			ApplicantInfoV2 applicantDetails = applicantInfoRepositoryV2.findById(applicationId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
				log.error("Applicant info details not found by application id -->" + applicationId);
				return null;
			}

			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2
					.findByApplicationId(applicationId);

			ApplicationMasterRequestV2 mstReq = new ApplicationMasterRequestV2();
			BeanUtils.copyProperties(appMaster, mstReq);
			Double premiumDtl = getPremiumAmountBasedOnSchemeId(new Date(), schemeId, appMaster.getSource());
			mstReq.setPremiumAmount(premiumDtl);
			mstReq.setEnrollDate(appMaster.getEnrollmentDate());
			mstReq.setMaxTransactionDate(
					CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(configProperties.getValueByCode(INSURER_START_DATE)
							+ CommonUtils.getCurrentPolicyYear() + "T00:00:00.00"));
			if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
				mstReq.setCoverEndDate(transactionDetailsV2.getCoverEndDate());
			}
			mstReq.setScheme(com.opl.jns.utils.enums.SchemeMaster.getById(schemeId).getShortName());
			mstReq.setCreatedDate(appMaster.getCreatedDate());
			if (!OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
				mstReq.setUrn(appMaster.getUrn());
				mstReq.setEmail(applicantDetails.getEmail());
				mstReq.setMobile(applicantDetails.getMobileNumber());
				mstReq.setKyc(!OPLUtils.isObjectNullOrEmpty(applicantDetails.getIsKYCUpdate())
						&& Boolean.TRUE.equals(applicantDetails.getIsKYCUpdate()) ? "Yes" : "No");
				mstReq.setFirstName(applicantPIDetails.getFirstName());
				mstReq.setMiddleName(applicantPIDetails.getMiddleName());
				mstReq.setLastName(applicantPIDetails.getLastName());
				mstReq.setFatherHusbandName(applicantPIDetails.getFatherHusbandName());
				mstReq.setDob(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getDob()) ? applicantPIDetails.getDob()
						: null);
				mstReq.setMobileNo(applicantDetails.getMobileNumber());
				mstReq.setEmailAddress(applicantDetails.getEmail());
				mstReq.setKycId1(applicantPIDetails.getKycId1());
				mstReq.setKycId1number(applicantPIDetails.getKycIdNumber1());
				mstReq.setKycId2(applicantPIDetails.getKycId2());
				mstReq.setKycId2number(applicantPIDetails.getKycIdNumber2());

				mstReq.setIsSameApplicantAddress(applicantDetails.getIsSameAppAddress());
				mstReq.setDisabilityDetails(applicantDetails.getDisabilityDetails());
				mstReq.setDisabilityStatus(applicantDetails.getDisabilityStatus());
				mstReq.setIsNomineeDeatilsSameEnroll(applicantDetails.getIsNomineeDetailsSameEnroll());

				mstReq = getRequiredOrgsDetailsNewDb(mstReq, appMaster, schemeId);

				mstReq.setAccountHolderName(applicantPIDetails.getAcHolderName());
				mstReq.setCustIfscCode(applicantDetails.getIfsc());
				mstReq.setAccountNo(applicantPIDetails.getAccountNumber());
				mstReq.setAmount(appMaster.getPremiumAmount());

				AddressMasterV2 addressMasterV2 = addressMasterRepositoryV2.findById(applicantDetails.getAddressId())
						.orElse(null);
				if (OPLUtils.isObjectNullOrEmpty(addressMasterV2)) {
					mstReq.setAddress(new AddressMasterRequest());
				} else {
					AddressMasterRequest req = new AddressMasterRequest();
					BeanUtils.copyProperties(addressMasterV2, req);
					BeanUtils.copyProperties(applicantPIDetails, req);
					req.setCity(addressMasterV2.getCityName());
					req.setState(addressMasterV2.getStateName());
					mstReq.setAddress(req);
				}
			}

			// FOR NOMINEE UPDATE DATA
			MiscellaneousAudit nomineeUpdatedData = miscellaneousAuditRepository
					.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId,
							MiscellaneousType.NOMINEE_UPDATE.getId());
			if (!OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData)) {
				mstReq.setDateOfNomineeUpdate(nomineeUpdatedData.getCreatedDate());
			}

			// FOR OPT OUT DATA
			MiscellaneousAudit optOutData = miscellaneousAuditRepository
					.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId, MiscellaneousType.OPT_OUT.getId());
			if (!OPLUtils.isObjectNullOrEmpty(optOutData)) {
				mstReq.setNomineeUpdateRequestDate(optOutData.getDateOfRequest());
				mstReq.setNomineeUpdateEffectiveDate(optOutData.getDateOfEffective());
			}

			NomineeDetailsV2 ndMst = nomineeDetailsRepositoryV2.findByApplicationIdAndIsActiveTrue(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
				NomineePIDetails nomineePIDtl = nomineePIDetailsRepository.findById(ndMst.getId()).orElse(null);
				if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
					NomineeDetailsRequest ndReq = new NomineeDetailsRequest();
					BeanUtils.copyProperties(ndMst, ndReq);
					BeanUtils.copyProperties(nomineePIDtl, ndReq);
					ndReq.setDateOfBirth(nomineePIDtl.getDob());
					ndReq.setEmailIdOfNominee(ndMst.getEmail());
					if (!OPLUtils.isObjectNullOrEmpty(nomineePIDtl.getGdName())) {
						if (!OPLUtils.isObjectNullOrEmpty(ndMst.getGdRelationId())) {
							String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,
									ndMst.getGdRelationId());
							ndReq.setRelationShipOfGuardianStr(relationShip);
							ndReq.setRelationShipOfGuardian(ndMst.getGdRelationId());
						}
						ndReq.setMobileNumberOfGuardian(
								!OPLUtils.isObjectNullOrEmpty(ndMst.getGdMobile()) ? ndMst.getGdMobile() : null);
						ndReq.setEmailIdOfGuardian(
								!OPLUtils.isObjectNullOrEmpty(ndMst.getGdEmail()) ? ndMst.getGdEmail() : null);
						ndReq.setAddressOfGuardian(nomineePIDtl.getGdAddress());
						ndReq.setNameOfGuardian(nomineePIDtl.getGdName());
					}
					ndReq.setAge(!OPLUtils.isObjectNullOrEmpty(nomineePIDtl.getDob())
							? CommonUtils.getAgeBydob(nomineePIDtl.getDob())
							: null);
					ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());

					if (!OPLUtils.isObjectNullOrEmpty(ndMst.getRelationId())) {
						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP, ndMst.getRelationId());
						ndReq.setRelationOfNomineeApplicantStr(relationShip);
						ndReq.setRelationOfNomineeApplicant(ndMst.getRelationId());
					}

					AddressMasterV2 ndAddres = addressMasterRepositoryV2.findById(ndMst.getAddressId()).orElse(null);

					if (!OPLUtils.isObjectNullOrEmpty(ndAddres)) {
						if (OPLUtils.isObjectNullOrEmpty(ndReq.getAddress())) {
							ndReq.setAddress(new AddressMasterRequest());
						}
						AddressMasterRequest req = new AddressMasterRequest();
						BeanUtils.copyProperties(ndAddres, req);
						BeanUtils.copyProperties(nomineePIDtl, req);
						req.setCity(ndAddres.getCityName());
						req.setState(ndAddres.getStateName());
						ndReq.setAddress(req);
					}
					List<NomineeDetailsRequest> nomineeMasterList = new ArrayList<NomineeDetailsRequest>();
					nomineeMasterList.add(ndReq);
					mstReq.setNominee(nomineeMasterList);
				}
			}
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getOrgId())) {
				String orgResponse = usersClient.getOrganizationName(appMaster.getOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
					mstReq.setBankName(orgResponse);
				}
			}
			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getBranchId())) {
				BranchBasicDetailsRequest branchDetails = usersClient.getBranch(appMaster.getBranchId());
				if (!OPLUtils.isObjectNullOrEmpty(branchDetails)) {
					mstReq.setBranchName(branchDetails.getName());
					mstReq.setIfscCode(branchDetails.getIfscCode());
				}
			} else {
				log.info("branchId not found from user Auth");
			}
			return mstReq;
		} catch (Exception e) {
			log.error("Exception is getting While Get insurance data ", e);
		}
		return null;
	}

	@Override
	public CommonResponse fetchAccountHolderList(AccHolderListReq accHolderListReq,AuthClientResponse authClientResponse) {
		AccHolderListResponse accHolderList = null;
		try {
			AccHolderListRequest accHolderListRequest = new AccHolderListRequest();
			if (!OPLUtils.isObjectNullOrEmpty(accHolderListReq)
					&& !OPLUtils.isObjectNullOrEmpty(accHolderListReq.getAccountValue())) {
				if (OPLUtils.isNumeric(accHolderListReq.getAccountValue())) {
					accHolderListRequest.setAccountNumber(accHolderListReq.getAccountValue());
				} else {
					accHolderListRequest.setUrn(accHolderListReq.getAccountValue());
				}
				BeanUtils.copyProperties(accHolderListReq, accHolderListRequest);
			}
			try {
				accHolderList = bankApiClient.getAccHolderList(accHolderListRequest, authClientResponse);
			} catch (Exception e) {
				log.error("Exception while GET ACCOUNT HOLDER LIST -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			MultipleJSONObjectHelper.getStringfromObject(accHolderList);
			if (!OPLUtils.isObjectNullOrEmpty(accHolderList) && !OPLUtils.isObjectNullOrEmpty(accHolderList.getStatus()) 
					&& !OPLUtils.isObjectNullOrEmpty(accHolderList.getSuccess())
					&& accHolderList.getStatus() == HttpStatus.OK.value()
					&& accHolderList.getSuccess().equals(Boolean.TRUE)) {

				StringBuilder validateResponse = validateResponse(accHolderList);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(),
							Boolean.FALSE);
				}

				List<AccountHolderDetailsProxy> holderDetailsLst = new ArrayList<>();
				List<com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderDetails> accountHolderDetails= accHolderList
				.getAccountHolderList().stream().filter(a->SchemeMaster.getByCode(a.getScheme()).getId()==accHolderListReq.getSchemeId()).collect(Collectors.toList());
//				for (com.opl.api.banker.model.getAccountHolderList.AccountHolderDetails detailsProxy : accHolderList
//						.getAccountHolderList()) {
				for (com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderDetails detailsProxy : accountHolderDetails) {
					AccountHolderDetailsProxy holderDetailsProxy = new AccountHolderDetailsProxy();
					BeanUtils.copyProperties(detailsProxy, holderDetailsProxy);
					ApplicationMasterV3 firstByUrnAndIsActiveTrue = applicationMasterRepo.findFirstByUrnAndIsActiveTrue(detailsProxy.getUrn());
					if(!OPLUtils.isObjectNullOrEmpty(firstByUrnAndIsActiveTrue) && !OPLUtils.isObjectNullOrEmpty(firstByUrnAndIsActiveTrue.getId())){
						holderDetailsProxy.setApplicationId(firstByUrnAndIsActiveTrue.getId());
					}
					holderDetailsLst.add(holderDetailsProxy);
				}
				
				if(OPLUtils.isListNullOrEmpty(holderDetailsLst)) {
					return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
							HttpStatus.INTERNAL_SERVER_ERROR.value());
				}
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, holderDetailsLst,
						HttpStatus.OK.value(), Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While Get account holder details ", e);
		}
		return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(accHolderList) ? accHolderList.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	@Override
	public CommonResponse fetchPolicyDetails(PolicyDetailsRequest policyDetailsRequest,
			AuthClientResponse authClientResponse) {
		PolicyDetailsResponse policyDetails = null;
		try {
			try {
				policyDetails = bankApiClient.getPolicyDetails(policyDetailsRequest,authClientResponse);
				log.info("Policy Response ----->"+MultipleJSONObjectHelper.getStringfromObject(policyDetails));
			} catch (Exception e) {
				log.error("Exception while GET POLICY DETAILS -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_POLICY_DTL,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}

			if (!OPLUtils.isObjectNullOrEmpty(policyDetails) && !OPLUtils.isObjectNullOrEmpty(policyDetails.getStatus())
					&& policyDetails.getStatus() == HttpStatus.OK.value()
					&& policyDetails.getSuccess().equals(Boolean.TRUE)) {
				
				StringBuilder validateResponse = validateResponse(policyDetails);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, policyDetails, HttpStatus.OK.value(),
						Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While Get policy details ", e);
		}
		return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(policyDetails) ? policyDetails.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_POLICY_DTL, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	@Override
	public CommonResponse optOutUpdateStatus(OptOutUpdateStatusRequest outUpdateStatusReq,
			AuthClientResponse authClientResponse) {
		APIResponse optOutUpdateStatus = null;
		try {
			try {
				outUpdateStatusReq.setCommonUserId(authClientResponse.getUserId());
				optOutUpdateStatus = webHookClient.optOutUpdateStatus(outUpdateStatusReq);
			} catch (Exception e) {
				log.error("Exception while OPT OUT UPDATE STATUS -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_OPT_OUT_UPDATE_STATUS,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}

			if (!OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus) && !OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus.getStatus())
					&& optOutUpdateStatus.getStatus() == HttpStatus.OK.value()
					&& optOutUpdateStatus.getSuccess().equals(Boolean.TRUE)) {
				
				StringBuilder validateResponse = validateResponse(optOutUpdateStatus);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
				
				return new CommonResponse("opt out status updated successfully", HttpStatus.OK.value(),
						Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While opt out update status ", e);
		}
		return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(optOutUpdateStatus) ? optOutUpdateStatus.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_OPT_OUT_UPDATE_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	@Override
	public CommonResponse nomineeUpdateStatus(NomineeUpdateStatusRequest nomineeUpdateStatusReq,
			AuthClientResponse authClientResponse) {
		APIResponse nomineeUpdateStatus = null;
		try {
			try {
				nomineeUpdateStatusReq.setCommonUserId(authClientResponse.getUserId());
				nomineeUpdateStatus = webHookClient.nomineeUpdateStatus(nomineeUpdateStatusReq);
			} catch (Exception e) {
				log.error("Exception while NOMINEE UPDATE STATUS -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_OPT_OUT_UPDATE_STATUS,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}

			if (!OPLUtils.isObjectNullOrEmpty(nomineeUpdateStatus) && !OPLUtils.isObjectNullOrEmpty(nomineeUpdateStatus.getStatus())
					&& nomineeUpdateStatus.getStatus() == HttpStatus.OK.value()
					&& nomineeUpdateStatus.getSuccess().equals(Boolean.TRUE)) {
				
				StringBuilder validateResponse = validateResponse(nomineeUpdateStatus);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
				
				return new CommonResponse("nominee status updated successfully", HttpStatus.OK.value(),
						Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While nominee update status ", e);
		}
		return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(nomineeUpdateStatus) ? nomineeUpdateStatus.getMessage() : CommonErrorMsg.Enrollment.UNABLE_TO_NOMINEE_UPDATE_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	@Override
	public CommonResponse getNomineeUpdatedetails(PolicyDetailsRequest policyDetailsRequest,
			AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterRequestV2 mstReq = new ApplicationMasterRequestV2();
			PolicyDetailsResponse policyResponse = null;

			try {
				policyResponse = bankApiClient.getPolicyDetails(policyDetailsRequest, authClientResponse);
			} catch (Exception e) {
				log.error("Exception while GET POLICY DETAILS -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_POLICY_DTL,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}

			if (!OPLUtils.isObjectNullOrEmpty(policyResponse) && !OPLUtils.isObjectNullOrEmpty(policyResponse.getStatus())
					&& policyResponse.getStatus() == HttpStatus.OK.value()
					&& policyResponse.getSuccess().equals(Boolean.TRUE)) {
				
				StringBuilder validateResponse = validateResponse(policyResponse);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			if (!OPLUtils.isObjectNullOrEmpty(policyResponse)) {
				mstReq.setCustIfscCode(policyResponse.getCustomerIFSC());
				mstReq.setAccountHolderName(policyResponse.getAccountHolderName());
				mstReq.setGender(policyResponse.getGender());
				mstReq.setFatherHusbandName(policyResponse.getFatherHusbandName());
				mstReq.setDob(!OPLUtils.isObjectNullOrEmpty(policyResponse.getDob())
						? Date.from(policyResponse.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant())
						: null);
				mstReq.setMobileNo(policyResponse.getMobileNumber());
				mstReq.setEmail(!OPLUtils.isObjectNullOrEmpty(policyResponse.getEmailId()) ? policyResponse.getEmailId()
						: null);

				AddressMasterRequest addressreq = new AddressMasterRequest();
				addressreq.setAddressLine1(policyResponse.getAddressline1());
				addressreq.setAddressLine2(!OPLUtils.isObjectNullOrEmpty(policyResponse.getAddressline2())
						? policyResponse.getAddressline2()
						: null);
				addressreq.setCity(policyResponse.getCity());
				addressreq.setDistrict(policyResponse.getDistrict());
				addressreq.setState(policyResponse.getState());
				addressreq.setPincode(policyResponse.getPincode().intValue());
				mstReq.setAddress(addressreq);

				mstReq.setKycId1(policyResponse.getKycID1());
				mstReq.setKycId1number(policyResponse.getKycID1number());
				mstReq.setPan(!OPLUtils.isObjectNullOrEmpty(policyResponse.getPan()) ? policyResponse.getPan() : null);
				mstReq.setAadhar(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getAadhaar()) ? policyResponse.getAadhaar()
								: null);
				// panNumber,adharNumber not In request
				mstReq.setCkyc(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getCkyc()) ? policyResponse.getCkyc() : null);
				mstReq.setCkycNumber(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getCkyc()) ? policyResponse.getCkyc() : null);
				mstReq.setEnrollDate(
						Date.from(policyResponse.getFirstEnrollmentDate().atZone(ZoneId.systemDefault()).toInstant()));

				NomineeDetailsRequest nomineeReq = new NomineeDetailsRequest();
				nomineeReq.setName(policyResponse.getNomineeName());
				nomineeReq.setDateOfBirth(!OPLUtils.isObjectNullOrEmpty(policyResponse.getNomineeDateOfBirth())
						? Date.from(policyResponse.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant())
						: null);
				nomineeReq.setMobileNumber(!OPLUtils.isObjectNullOrEmpty(policyResponse.getNomineeMobileNumber())
						? policyResponse.getNomineeMobileNumber()
						: null);
				nomineeReq.setRelationOfNomineeApplicantStr(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getRelationshipOfNominee())
								? policyResponse.getRelationshipOfNominee()
								: null);
				if(!OPLUtils.isObjectNullOrEmpty(policyResponse.getRelationshipOfNominee())) {
					nomineeReq.setRelationOfNomineeApplicant(RelationShip.fromValue(policyResponse.getRelationshipOfNominee()).getId());		
				}
				
				nomineeReq.setEmailIdOfNominee(!OPLUtils.isObjectNullOrEmpty(policyResponse.getNomineeEmailId())
						? policyResponse.getNomineeEmailId()
						: null);
				nomineeReq.setAddressLine1(policyResponse.getAddressofNominee());
				nomineeReq.setNameOfGuardian(!OPLUtils.isObjectNullOrEmpty(policyResponse.getNameofGuardian())
						? policyResponse.getNameofGuardian()
						: null);
				nomineeReq.setAddressOfGuardian(!OPLUtils.isObjectNullOrEmpty(policyResponse.getAddressofGuardian())
						? policyResponse.getAddressofGuardian()
						: null);
				
				nomineeReq.setRelationShipOfGuardianStr(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getRelationshipofGuardian())
								? policyResponse.getRelationshipofGuardian()
								: null);
				
				if(!OPLUtils.isObjectNullOrEmpty(policyResponse.getRelationshipofGuardian())) {
					nomineeReq.setRelationShipOfGuardian(RelationShip.fromValue(policyResponse.getRelationshipofGuardian()).getId());		
				}
				
				nomineeReq.setMobileNumberOfGuardian(
						!OPLUtils.isObjectNullOrEmpty(policyResponse.getGuardianMobileNumber())
								? policyResponse.getGuardianMobileNumber()
								: null);
				nomineeReq.setEmailIdOfGuardian(!OPLUtils.isObjectNullOrEmpty(policyResponse.getGuardianEmailId())
						? policyResponse.getGuardianEmailId()
						: null);

				List<NomineeDetailsRequest> nomineeMasterList = new ArrayList<NomineeDetailsRequest>();
				nomineeMasterList.add(nomineeReq);
				mstReq.setNominee(nomineeMasterList);

				mstReq.setTransUtr(!OPLUtils.isObjectNullOrEmpty(policyResponse.getTransactionUTR())
						? policyResponse.getTransactionUTR()
						: null);
				mstReq.setTransAmount(!OPLUtils.isObjectNullOrEmpty(policyResponse.getTransactionAmount())
						? policyResponse.getTransactionAmount()
						: null);
				mstReq.setTransTimeStamp(!OPLUtils.isObjectListNull(policyResponse.getTransactionTimestamp()) ? 
						Date.from(policyResponse.getTransactionTimestamp().atZone(ZoneId.systemDefault()).toInstant()) : null);
				
				if(!OPLUtils.isObjectNullOrEmpty(policyDetailsRequest.getApplicationId())) {
					ApplicantInfoV2 applicantDetails = applicantInfoRepositoryV2.findById(policyDetailsRequest.getApplicationId()).orElse(null);
					if(!OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
						mstReq.setDisabilityDetails(applicantDetails.getDisabilityDetails());
						mstReq.setDisabilityStatus(applicantDetails.getDisabilityStatus());
					}
				}
				
				/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
				Long schemeId = OPLUtils.getSchemeIdFromUrn(policyDetailsRequest.getUrn());
				ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(schemeId, policyDetailsRequest.getApplicationId());
				
				if(!OPLUtils.isObjectNullOrEmpty(appMaster)) {					
					mstReq = getRequiredOrgsDetailsNewDb(mstReq, appMaster, schemeId);
				}
				
				return new CommonResponse("Successfully get Nominee update Details!!",
						mstReq, HttpStatus.OK.value(), true);
			}
		}
		} catch (Exception e) {
			// TODO: handle exception
			log.error("Exception is getting While Get Policy deatils  ", e);
		}
		return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_POLICY_DTL,
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
	
	
	@Override
	public CommonResponse getCoiDetails(GetCoiReq getCoiReq,
			AuthClientResponse authClientResponse) {
		GetCoiResponse getCoiResponse = null;
		COIRequest coiRequest = new COIRequest();
		try {
			GetCoiRequest getCoiRequest = new GetCoiRequest();
			if (!OPLUtils.isObjectNullOrEmpty(getCoiReq.getCif())) {
				BeanUtils.copyProperties(getCoiReq, getCoiRequest);
			}

			if (!OPLUtils.isObjectNullOrEmpty(getCoiRequest)) {
				ApplicationMasterBothSchemeProxy appMasterProxy=ereCommonService.getJnsMasterDataApplicationMaster(getCoiReq.getSchemeId(),getCoiReq.getApplicationId());
				if (!OPLUtils.isObjectNullOrEmpty(appMasterProxy)) {
					getCoiRequest.setOrgId(appMasterProxy.getInsurerOrgId());
					getCoiRequest.setIsInsurer(true);
				}else {
					return new CommonResponse("Invalid COI Details Request.", coiRequest, HttpStatus.BAD_REQUEST.value(),
							Boolean.FALSE);
				};
				getCoiRequest.setCommonUserId(authClientResponse.getUserId());
				getCoiResponse = webHookClient.getCOIDetails(getCoiRequest);
			}

			if (!OPLUtils.isObjectNullOrEmpty(getCoiResponse)
					&& !OPLUtils.isObjectNullOrEmpty(getCoiResponse.getStatus())
					&& getCoiResponse.getStatus() == HttpStatus.OK.value()
					&& getCoiResponse.getSuccess().equals(Boolean.TRUE)) {

				StringBuilder validateResponse = validateResponse(getCoiResponse);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(),
							Boolean.FALSE);
				}

				coiRequest.setNameOfMember(getCoiResponse.getAccountHolderName().toUpperCase());
				coiRequest.setAddress((!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getAddressline1())
						? getCoiResponse.getAddressline1().toUpperCase()
						: "")
						+ " ,"
						+ (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getAddressline2())
								? getCoiResponse.getAddressline2().toUpperCase()
								: "")
						+ " ,"
						+ (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getCity())
								? getCoiResponse.getCity().toUpperCase()
								: "")
						+ ","
						+ (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getDistrict())
								? getCoiResponse.getDistrict().toUpperCase()
								: "")
						+ ","
						+ (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getState())
								? getCoiResponse.getState().toUpperCase()
								: "")
						+ " "
						+ (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getPincode()) ? getCoiResponse.getPincode()
								: ""));

				coiRequest.setNameOfNominee(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getNomineeName())
						? getCoiResponse.getNomineeName().toUpperCase()
						: null);
				coiRequest.setMobileNo(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getMobileNumber())
						? getCoiResponse.getMobileNumber().toUpperCase()
						: null);
				coiRequest.setDob(
						!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getDob()) ? getCoiResponse.getDob().toString()
								: null);
				coiRequest.setNameOfGuardian(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getNameofGuardian())
						? getCoiResponse.getNameofGuardian().toUpperCase()
						: null);
				coiRequest.setRelationShipOfGuardian(
						!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getRelationshipOfGuardian())
								? getCoiResponse.getRelationshipOfGuardian().toUpperCase()
								: null);
				if (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getRelationshipOfGuardian())) {
					coiRequest
							.setRelationId(RelationShip.fromValue(getCoiResponse.getRelationshipOfGuardian()).getId());
				}
				coiRequest.setDateOfComOfCover(
						Date.from(getCoiResponse.getFirstEnrollmentDate().atZone(ZoneId.systemDefault()).toInstant()));
				//coiRequest.setKycName(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1()) ? 				getCoiResponse.getKycID1().toUpperCase() : null);
				//coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number()) ? 				getCoiResponse.getKycID1number() : null);	
				if (!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1())) {
					if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
						coiRequest.setKycName(KycDocument.AADHAR.getDisplayValue());
						coiRequest.setKycValue("-");
					} else if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.PAN.getKey())) {
						coiRequest.setKycName(KycDocument.PAN.getDisplayValue());
						coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number())
								? getCoiResponse.getKycID1number().toUpperCase()
								: "-");
					} else if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
						coiRequest.setKycName(KycDocument.PASSPORT.getDisplayValue());
						coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number())
								? getCoiResponse.getKycID1number().toUpperCase()
								: "-");
					} else if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
						coiRequest.setKycName(KycDocument.DRIVING_LICENCE.getDisplayValue());
						coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number())
								? getCoiResponse.getKycID1number().toUpperCase()
								: "-");
					} else if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
						coiRequest.setKycName(KycDocument.MGNREGA_CARD.getDisplayValue());
						coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number())
								? getCoiResponse.getKycID1number().toUpperCase()
								: "-");
					} else if (getCoiResponse.getKycID1().equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
						coiRequest.setKycName(KycDocument.VOTERS_ID_CARD.getDisplayValue());
						coiRequest.setKycValue(!OPLUtils.isObjectNullOrEmpty(getCoiResponse.getKycID1number())
								? getCoiResponse.getKycID1number().toUpperCase()
								: "-");
					}
				}

				if (!OPLUtils.isObjectNullOrEmpty(getCoiReq.getApplicationId())
						&& !OPLUtils.isObjectNullOrEmpty(getCoiReq.getSchemeId())) {

					/** GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER */
					Long schemeId = getCoiReq.getSchemeId().longValue();
					Long applicationId = getCoiReq.getApplicationId();
					ApplicationMasterBothSchemeProxy appMaster = ereCommonService
							.getJnsMasterDataApplicationMaster(schemeId, applicationId);

					if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
						log.error("Application  details not found by application id  FOR COI -->" + applicationId);
						return null;
					}
					ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationId)
							.orElse(null);
					if (OPLUtils.isObjectNullOrEmpty(applicantPIDetails)) {
						log.error("Applicant info PI details not found by application id -->" + applicationId);
						return null;
					}
					coiRequest.setApplicationId(appMaster.getId());
					coiRequest.setSchemeId(schemeId);
					coiRequest.setAccountNo(applicantPIDetails.getAccountNumber());
					coiRequest.setPremAmtPaid(appMaster.getPremiumAmount());
					coiRequest.setOrgId(appMaster.getOrgId());
					coiRequest.setInsurerOrgId(appMaster.getInsurerOrgId());
//					coiRequest.setInsurerOrgId(appMaster.getLastTransactionDetails().getInsurerOrgId());
					coiRequest.setUrnNo(appMaster.getUrn());
					coiRequest.setSignatureDate(appMaster.getModifiedDate());
//					coiRequest.setLastTransactionDetailsId(appMaster.getLastTransactionDetails().getId());
					coiRequest.setLastTransactionDetailsId(appMaster.getLastTransactionId());
					coiRequest.setBranchId(appMaster.getBranchId());

					TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2
							.findByApplicationId(applicationId);
					if (OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
						log.error("Trasanction Details Not Found By application id -->" + applicationId);
						return null;
					}

					coiRequest.setMstPolicyNo(!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)
							&& !OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getMasterPolicyNo())
									? transactionDetailsV2.getMasterPolicyNo().toUpperCase()
									: null);

					if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getCoverEndDate())) {
						coiRequest.setCoverEndDate(
								CommonUtils.sdf_dd_MM_yyyy.format(transactionDetailsV2.getCoverEndDate()));
					}

					NomineeDetailsV2 ndMst = nomineeDetailsRepositoryV2
							.findByApplicationIdAndIsActiveTrue(applicationId);
					String age = null;
					if (!OPLUtils.isObjectNullOrEmpty(ndMst)) {
						NomineePIDetails nomineePIDtl = nomineePIDetailsRepository.findById(ndMst.getId()).orElse(null);
						if (!OPLUtils.isObjectNullOrEmpty(nomineePIDtl)) {
							age = String.valueOf(CommonUtils.getAgeBydob(nomineePIDtl.getDob()));
							coiRequest.setAgeOfNominee(age);
						}
					}
					if (!OPLUtils.isObjectNullOrEmpty(appMaster.getChannelId())) {
						if (appMaster.getChannelId().equals(ChannelIdEnum.CUSTOMER_MOBILE.getShortName())
								|| appMaster.getChannelId().equals(ChannelIdEnum.CUSTOMER_WEB.getShortName()))
							coiRequest.setIsCustomerUser(true);
						else
							coiRequest.setIsCustomerUser(false);
					} else {
						coiRequest.setIsCustomerUser(false);
					}

					coiRequest = pdfGenerateClient.setCOIOtherDetails(coiRequest);
					byte[] regenerateCOI = getCOIBank(coiRequest, transactionDetailsV2);
					transactionDetailsRepositoryV2.save(transactionDetailsV2);
					return new CommonResponse("successfully get coi details", coiRequest, HttpStatus.OK.value(),
							Boolean.TRUE);
				}
			}
		} catch (Exception e) {
			log.error("Exception is getting While get coi details ", e);
		}
		return new CommonResponse(
				!OPLUtils.isObjectNullOrEmpty(getCoiResponse) ? getCoiResponse.getMessage()
						: CommonErrorMsg.Enrollment.UNABLE_TO_GET_COI_DETAILS,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	@Override
	public byte[] getCOIBank(COIRequest coiReq,TransactionDetailsV2 transactionDetailsV2) {
		try {
				// GENERATE PDF FILE FROM PDF CLIENT
			CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
				if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && 					generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
//					appMaster.getLastTransactionDetails().setCoiStorageId(generateCOI.getId());
					transactionDetailsV2.setCoiStorageId(generateCOI.getId());
					return Base64.getDecoder().decode(String.valueOf(generateCOI.getData()));
				} else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
					log.error("Error while generate PDF COI --> ", generateCOI.getMessage());
				} else {
					log.error("Error while generate PDF COI ", HttpStatus.SERVICE_UNAVAILABLE.value());
				}

		} catch (Exception e) {
			log.error("Exception while generate COI ---------------->", e);
		}
		return null;
	}
	@Override
	public byte[] generateCOIFromMaster(Long applicationId, Integer schemeId) throws Exception {
		try {
			ApplicationMasterBothSchemeProxy appMaster = ereCommonService
					.getJnsMasterDataApplicationMaster(schemeId.longValue(), applicationId);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("APPLICATION MASTER(pmsby OR pmjjby) IS NULL OR EMPTY ----------->" + applicationId);
				return null;
			}
			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2
					.findByApplicationId(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
				log.error("Trasanction Details Not Found By application id -->" + applicationId);
				return null;
			}
	
				Long coiStorageId = transactionDetailsV2.getCoiStorageId();
				if (coiStorageId != null) {
					return dmsClient.productDownloadDocuments(coiStorageId.toString());

			}
//			return getCOI(appMaster, isFreshCreate);
		} catch (Exception e) {
			log.error("Exception while generate COI --> ", e);
		}
		return null;
	}

	@Override
	public CommonResponse getPolicyDetails(String urn) {
		try {
			/**FETCH APPLICATION ID AND SCHEME ID BY URN*/
			Long applicationId = OPLUtils.getApplicationIdFromUrn(urn);
			Long schemeId = OPLUtils.getSchemeIdFromUrn(urn);

			/**FETCH JNS_MASTER.PMSBY/PMJJBY BY APPLICATION ID AND SCHEME ID*/
			ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService
					.getJnsMasterDataApplicationMaster(schemeId, applicationId);
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return new CommonResponse("The application details are not found.",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}

			/**FETCH JNS_MASTER.TRASACTION_DETAILS BY TRANSACTION ID*/
			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2
					.findById(applicationMaster.getLastTransactionId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
				log.error("Transaction details not found by transaction id -->"
						+ applicationMaster.getLastTransactionId());
				return new CommonResponse("The transaction details are not found.",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}

			/**FETCH BRANCH DETAILS BY BRANCH ID*/
			BranchBasicDetailsRequest branchDetails = usersClient.getBranch(applicationMaster.getBranchId());
			if (OPLUtils.isObjectNullOrEmpty(branchDetails)) {
				log.error("Branch details not found by transaction id -->" + applicationMaster.getLastTransactionId());
				return new CommonResponse("The branch details are not found.", HttpStatus.INTERNAL_SERVER_ERROR.value(),
						Boolean.FALSE);
			}

			/**FETCH INSURER NAME BY INSURER ORG ID*/
			String orgResponse = usersClient.getOrganizationName(applicationMaster.getInsurerOrgId());
			if (OPLUtils.isObjectNullOrEmpty(orgResponse)) {
				log.error("Insurer name not found by insurer org id -->" + applicationMaster.getInsurerOrgId());
				return new CommonResponse("The Insurer name are not found.", HttpStatus.INTERNAL_SERVER_ERROR.value(),
						Boolean.FALSE);
			}

			/**FETCH INSURER DETAILS BY SCHEME ID, ORG ID, POLICY START DATE AND POLICY END DATE*/
			InsurerMstDetailsV3 insurerDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId,
							applicationMaster.getOrgId(), new Date(), new Date());
			if (OPLUtils.isObjectNullOrEmpty(insurerDetails)) {
				log.error("Insurer details not found by insurer org id -->" + applicationMaster.getOrgId());
				return new CommonResponse("The Insurer details are not found.",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
			}

			/**SET ALL POLICY DETAILS IN PROXY*/
			PolicyDetailsProxy detailsProxy = new PolicyDetailsProxy(transactionDetailsV2.getMasterPolicyNo(),
					applicationMaster.getUrn(), branchDetails.getName(), branchDetails.getCode(),
					(!OPLUtils.isObjectNullOrEmpty(insurerDetails.getPolicyStartDate()) ? CommonUtils.sdf_dd_MM_YYYY.format(insurerDetails.getPolicyStartDate()) : null), orgResponse);
			
			log.info("END GET POLICY DETAILS API URN -------------> " + urn);
			return new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, detailsProxy, HttpStatus.OK.value(),
					Boolean.TRUE);

		} catch (Exception e) {
			log.error("Exception while GET POLICY DETAILS -----> ", e);
		}
		return new CommonResponse(
				"Its seems we have not found details by given information, kindly refresh page and try again",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	 /** GET-COI DETAILS IN OLDDB */
	/*
	if(!OPLUtils.isObjectNullOrEmpty(getCoiRequest.getApplicationId())) {
		ApplicationMasterV3 appMaster = applicationMasterRepo.findByIdAndIsActiveTrue(getCoiRequest.getApplicationId());
		Long schemeId = appMaster.getSchemeId().longValue();
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			return new CommonResponse(CommonErrorMsg.Enrollment.INVALID_APPLICATION_ID, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		coiRequest.setApplicationId(appMaster.getId());
		coiRequest.setSchemeId(schemeId);
		coiRequest.setAccountNo(appMaster.getAccountNumber());
		coiRequest.setPremAmtPaid(appMaster.getPremiumAmount());
		coiRequest.setOrgId(appMaster.getOrgId());
		coiRequest.setInsurerOrgId(appMaster.getLastTransactionDetails().getInsurerOrgId());
		coiRequest.setUrnNo(appMaster.getUrn());
		coiRequest.setSignatureDate(appMaster.getModifiedDate());
		coiRequest.setLastTransactionDetailsId(appMaster.getLastTransactionDetails().getId());
		coiRequest.setBranchId(appMaster.getBranchId());
		
		if(!OPLUtils.isObjectNullOrEmpty(appMaster.getOrgId())) {
			InsurerMstDetailsV3 mst = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId, appMaster.getOrgId(), new Date(), new Date());
			coiRequest.setMstPolicyNo(!OPLUtils.isObjectNullOrEmpty(mst) && !OPLUtils.isObjectNullOrEmpty(mst.getMasterPolicyNo()) ? mst.getMasterPolicyNo().toUpperCase() : null);	
		}
		if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoverEndDate())) {
			coiRequest.setCoverEndDate(CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getLastTransactionDetails().getCoverEndDate()));
		}
		String age = null;
		NomineeDetails nDtl = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(appMaster.getId(), com.opl.jns.ere.utils.CommonUtils.TYPE_NOMINEE);
		if(!OPLUtils.isObjectNullOrEmpty(nDtl)) {
			age = String.valueOf(CommonUtils.getAgeBydob(nDtl.getDob()));	
			coiRequest.setAgeOfNominee(age);
		}
		if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails()) && !OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails().getChannelId())) {
			if (appMaster.getApplicationMasterOtherDetails().getChannelId().equals(ChannelIdEnum.CUSTOMER_MOBILE.getShortName())|| appMaster.getApplicationMasterOtherDetails().getChannelId().equals(ChannelIdEnum.CUSTOMER_WEB.getShortName()))
				coiRequest.setIsCustomerUser(true);
			else
				coiRequest.setIsCustomerUser(false);
		} else {
			coiRequest.setIsCustomerUser(false);					
		}


			coiRequest = pdfGenerateClient.setCOIOtherDetails(coiRequest);
			byte[] regenerateCOI = getCOIBank(coiRequest,appMaster);
			return new CommonResponse("successfully get coi details",coiRequest, HttpStatus.OK.value(),
			Boolean.TRUE);
	} */
	
	/** NEW DB STURCTURE RELATED APPLICATION FORM DETAILS*/ /** DON'T REMOVE METHOD THIS METHOD USE FOR JNS-PHASE-2 */
	/*@Override
	public ApplicationViewProxy getApplicationFormDetailsNewDb(Long applicationId, Long schemeId,
			AuthClientResponse authClientResponse) {
		try {
			ApplicationMasterBothSchemeProxy appMaster = null;
			if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
				PMSBY pmsby = pmsbyRepository.findByIdAndIsActiveTrue(applicationId);
				if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
					appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmsby,
							ApplicationMasterBothSchemeProxy.class);
				}
			} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId())) {
				PMJJBY pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(applicationId);
				if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
					appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmjjby,
							ApplicationMasterBothSchemeProxy.class);
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return null;
			}

			ApplicantPIDetails applicantPIDetails = applicantPIDetailsRepository.findById(applicationId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Applicant info PI details not found by application id -->" + applicationId);
				return null;
			}

			ApplicantInfoV2 applicantDetails = applicantInfoRepositoryV2.findById(applicationId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(applicantDetails)) {
				log.error("Applicant info details not found by application id -->" + applicationId);
				return null;
			}

			InsurerMstDetailsV3 insurerDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId,
							appMaster.getOrgId(), new Date(), new Date());
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Insurer details not found by orgId -->" + appMaster.getOrgId());
				return null;
			}

			BranchBasicDetailsRequest branchDetails = usersClient.getBranch(appMaster.getBranchId());
			if (OPLUtils.isObjectNullOrEmpty(branchDetails)) {
				log.error("Branch details not found by application id -->" + applicationId);
				return null;
			}
			
			String organizationName = usersClient.getOrganizationName(appMaster.getInsurerOrgId());
			if (OPLUtils.isObjectNullOrEmpty(organizationName)) {
				log.error("Insurer name not found by insurer org id -->" + appMaster.getInsurerOrgId());
				return null;
			}

			ApplicationViewProxy applicationViewPxy = new ApplicationViewProxy();
			applicationViewPxy.setAccountHolderName(applicantPIDetails.getAcHolderName());
			applicationViewPxy.setUrn(appMaster.getUrn());
			applicationViewPxy.setSchemeName(SchemeMaster.getById(schemeId).getShortName());
			applicationViewPxy.setApplicationStatus(ApplicationStatus.fromId(appMaster.getStatus()).getValue());
			applicationViewPxy.setFirstEnrollmentDate(!OPLUtils.isObjectNullOrEmpty(appMaster.getEnrollmentDate()) ? CommonUtils.sdf_dd_MM_YYYY.format(appMaster.getEnrollmentDate()) : null);
			applicationViewPxy.setNameOfInsurer(organizationName);
			applicationViewPxy.setPremiumAmount(appMaster.getPremiumAmount());
			applicationViewPxy.setSource(Source.fromId(appMaster.getSource()).getValue());
			applicationViewPxy.setMasterPolicyNumber(insurerDetails.getMasterPolicyNo());
			applicationViewPxy.setBranchCode(branchDetails.getCode());
			applicationViewPxy.setUserId(applicantDetails.getUserId1());
			applicationViewPxy.setChannelId(appMaster.getChannelId());
			return applicationViewPxy;
		} catch (Exception e) {
			log.error("Exception is getting While Get insurance data ", e);
		}
		return null;
	}*/

	//	private static String getApplicantAddress(AddressMasterV3 addMst) {
	//		if (!OPLUtils.isObjectNullOrEmpty(addMst)) {
	//			return (!OPLUtils.isObjectNullOrEmpty(addMst.getAddressLine1()) ? addMst.getAddressLine1() : "")
	//					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getAddressLine2()) ? ", " + addMst.getAddressLine2() : "")
	//					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getCityName()) ? ", " + addMst.getCityName() : "")
	//					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getDistrict()) ? ", " + addMst.getDistrict() : "")
	//					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getStateName()) ? ", " + addMst.getStateName() : "")
	//					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getPincode()) ? ", " + addMst.getPincode() : "");
	//		}
	//		return null;
	//	}

	//	public static void main(String[] args) { // ^(?!\\d+$)([a-zA-Z0-9][a-zA-Z0-9 !@#$&()-‘./+,“]*)?$|^[0-9]*$
	//		Pattern pattern = Pattern.compile("^[A-Za-z0-9?/.,:@#&_=\\()'.-](\\s?[A-Za-z0-9?/.,:@#&_=\\()'.-]+)*$");
	//		Matcher matcher = pattern.matcher("A-1 fgfdgfd gdfdgfdg");
	//		System.out.println(matcher.matches());
	//	}
	

}
