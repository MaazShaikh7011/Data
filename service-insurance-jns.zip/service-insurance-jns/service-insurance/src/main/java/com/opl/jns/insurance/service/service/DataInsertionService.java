package com.opl.jns.insurance.service.service;

/**
 * @author - Maaz Shaikh
 * @Date - 7/4/2023
 */
public interface DataInsertionService {

    public void dataInsertion(int schemeId,int counter,Long orgId,Long insurerOrgId);

    public void claimDummyInsert(int schemeId, Long orgId);
}
