package com.opl.jns.insurance.service.boot;

import java.util.Arrays;
import java.util.stream.Collectors;

public class test {

    public static void main(String[] args) {
        String urn = "JNS-PMSBY-23-24-00000000856-979";
        Long applicationIdFromUrn = getApplicationIdFromUrn(urn);
        System.out.println(applicationIdFromUrn);


    }

    public static Long getApplicationIdFromUrn(String urn) {
        Long applicationId = null;
        try {
            applicationId = Long.valueOf(Arrays.stream(urn.split("-")).collect(Collectors.toList()).get(4).toString());
        } catch (Exception e) {
//            log.error("exception is getting while get application id from URN");
        }
        return applicationId;
    }
}
