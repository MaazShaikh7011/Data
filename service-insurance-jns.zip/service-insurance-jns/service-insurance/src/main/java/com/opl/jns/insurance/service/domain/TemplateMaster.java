package com.opl.jns.insurance.service.domain;


import lombok.*;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;


@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "template_master")
public class TemplateMaster {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "template_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "template_master_seq_gen", sequenceName = "template_master_seq_gen", allocationSize = 1)
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "scheme_id")
    private Long schemeId;

    @Column(name = "file_name")
    private String fileName;
    
    @Column(name = "type")
    private Integer type;

    @Lob
    @Column(name = "template")
    private String template;

    @Column(name = "is_active")
    private Boolean isActive;

}
