package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import com.opl.jns.config.utils.ConfigProperties;
//import com.opl.service.insurance.jns.repository.BranchDetailsRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Component
//@Slf4j
//public class DataInsertSchedular {
//
//	@Autowired
//	private BankWiseInsert ins;
//
//	@Autowired
//	private ConfigProperties configProperties;
//
//	@Autowired
//	private BranchDetailsRepository branchDetailsRepository;
//
////	@Value("${dummy.data.insert.total}")
////	private String totalRow;
//
//	@Scheduled(cron = "${dummy.data.insert.schedular}")
//	public void start() {
//		updateBranch();
//		String value = configProperties.getValue("DUMMY_DATA_INSERT_ENABLE");
//		if (value != null && "ON".equalsIgnoreCase(value)) {
//			log.info("ENTER IN DUMMY DATA SCHEDULAR");
//			String totalRow = configProperties.getValue("DUMMY_DATA_INSERT_TOTAL_ROW");
//			if (totalRow != null) {
//				log.info("ENTER IN DUMMY DATA SCHEDULAR FOUN TOTAL ROW   " + totalRow);
//				DataInsertBankEnum[] bankList = DataInsertBankEnum.getAll();
//				for (int i = 0; i < bankList.length; i++) {
//					DataInsertBankEnum bank = bankList[i];
//					ins.insert(bank.getSchemeId(), bank.getOrgId(), bank.getInsurerId(), Integer.valueOf(totalRow));
//				}
//			}
//		} else {
//			log.info("OFF DUMMY DATA SCHEDULAR");
//		}
//	}
//
//	private void updateBranch() {
//		log.info("Enter in update branch");
//		if(BranchIds.SBI16 != null && BranchIds.SBI16.size() > 0) {
//			log.info("Branch is already assign");
//			return;
//		}
//		List<Long> list = new ArrayList<>(
//				Arrays.asList(1L, 4L, 12L, 13L, 14L, 16L, 17L, 18L, 19L, 20L, 25L, 27L, 28L, 32L));
//		for (Long orgId : list) {
//			List<Long> ids = branchDetailsRepository.getIds(orgId);
//			BranchIds.setBranch(ids, orgId.intValue());
//		}
//		log.info("Enter in update branch completed");
//	}
//}
