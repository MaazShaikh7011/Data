package com.opl.jns.insurance.service.service.impl;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.UpdateTransactionRequest;
import com.opl.jns.api.proxy.insurer.UpdateDocQuery.ClaimStatusWebhook;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ere.domain.ClmAddressMaster;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmNomineeDetails;
import com.opl.jns.ere.domain.ClmNomineePIDetails;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.domain.ExpSchedulerAudit;
import com.opl.jns.ere.domain.PushReTryAudit;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.ApplicationType;
import com.opl.jns.ere.enums.CauseOfDeathDisability;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.ere.enums.ExpSchedulerApiEnum;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.PMJJBYRejectedClaimEnum;
import com.opl.jns.ere.enums.PMSBYRejectedClaimEnum;
import com.opl.jns.ere.enums.QueriedClaimEnum;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ClmDeDupeDetailsRepository;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.ClmNomineeDetailsRepository;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.repo.ExpSchedulerAuditRepo;
import com.opl.jns.ere.repo.PushReTryAuditRepo;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.ere.utils.DedupeDataResponse;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.AccountHolderMappingRequest;
import com.opl.jns.insurance.api.model.AddressMasterRequest;
import com.opl.jns.insurance.api.model.ClaimDeDupeDetails;
import com.opl.jns.insurance.api.model.ClaimDeDupeDetailsProxy;
import com.opl.jns.insurance.api.model.ClaimMasterRequest;
import com.opl.jns.insurance.api.model.ClaimRequest;
import com.opl.jns.insurance.api.model.ClaimStatusRequest;
import com.opl.jns.insurance.api.model.UpdateClaimAccountHolderRequest;
import com.opl.jns.insurance.api.model.v2.ClaimDashboardViewV2;
import com.opl.jns.insurance.service.service.ClaimMasterServiceV3;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.ClaimAbstract;
import com.opl.jns.insurance.service.utils.ClaimGetSetUtils;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.insurance.service.utils.NotificationUtil;
import com.opl.jns.insurance.service.utils.ResponseStatus;
import com.opl.jns.insurance.service.utils.dedupe.DeDupeRegistryUtilityV3;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

/***
 * 
 * @author Maulik Panchal Date : 20-02-2024
 */

@Slf4j
@Service
@Transactional
public class ClaimMasterServiceImplV3 extends ClaimAbstract implements ClaimMasterServiceV3 {

	public static final String PUSH_CLAIM_REVISED_DOCS = "PUSH_CLAIM_REVISED_DOCS";

	@Autowired
	private OneFormClient oneFormClient;

	@Autowired
	public ApplicationMasterRepositoryV3 masterRepository;

	@Autowired
	private ConfigProperties properties;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private PushReTryAuditRepo pushReTryAuditRepo;

	@Autowired
	private NotificationUtil notificationUtil;

	@Autowired
	private ClmMasterRepository clmMasterRepository;

	@Autowired
	private ExpSchedulerAuditRepo expSchedulerAuditRepo;

	@Autowired
	private DeDupeRegistryUtilityV3 deDupeRegistryUtilityV3;

	@Autowired
	private ClmDeDupeDetailsRepository clmDeDupeDetailsRepository;

	@Autowired
	private ClmNomineeDetailsRepository clmNomineeDetailsRepository;

	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 applicationMasterOtherDetailsRepository;

	@Autowired
	private EnrollmentService enrollmentService;
	
	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private UserManagementClient userManagementClient;
	
	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepoV2;
	
	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;
	
	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;
	
	@Autowired
	private AddressMasterRepositoryV2 addressMasterRepositoryV2;
	
	@Autowired
	private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;
	
	@Autowired
	private NomineePIDetailsRepository nomineePIDetailsRepository;
	
	@Autowired
	private PmsbyRepository pmsbyRepository;
	
	@Autowired
	private PmjjbyRepository pmjjbyRepository;
	
	@Autowired
	private WebHookClient webHookClient;
	
	@Autowired
	private ConsentMasterRepository consentMasterRepository;

	@SuppressWarnings("unchecked")
	@Override
	public CommonResponse getAccountHoldersList(ClaimRequest claimRequest, AuthClientResponse authClientResponse) {
		List<ApplicationMasterBothSchemeProxy> listOfObjects = null;
		try {
			if (claimRequest.getAccountValue().contains("-")) {
				if (OPLUtils.isListNullOrEmpty(listOfObjects)) {
					if (Objects.equals(claimRequest.getSchemeId(), SchemeMaster.PMSBY.getId())) {
						List<PMSBY> pmsbyLst = pmsbyRepository.findByUrnAndOrgIdAndStatusAndSourceNotAndIsActiveTrue(
								claimRequest.getAccountValue(), authClientResponse.getUserOrgId(),
								ApplicationStatus.ENROLL_COMPLETED.getId(),Source.LED.getId());
						if (!OPLUtils.isListNullOrEmpty(pmsbyLst)) {
							listOfObjects = MultipleJSONObjectHelper.getListOfObjects(
									MultipleJSONObjectHelper.getStringfromObject(pmsbyLst), null,
									ApplicationMasterBothSchemeProxy.class);
						}
					} else {
						List<PMJJBY> pmjjbyLst = pmjjbyRepository.findByUrnAndOrgIdAndStatusAndSourceNotAndIsActiveTrue(
								claimRequest.getAccountValue(), authClientResponse.getUserOrgId(),
								ApplicationStatus.ENROLL_COMPLETED.getId(),Source.LED.getId());
						if (!OPLUtils.isListNullOrEmpty(pmjjbyLst)) {
							listOfObjects = MultipleJSONObjectHelper.getListOfObjects(
									MultipleJSONObjectHelper.getStringfromObject(pmjjbyLst), null,
									ApplicationMasterBothSchemeProxy.class);
						}
					}
				}
			} else {
				if (Objects.equals(claimRequest.getSchemeId(), SchemeMaster.PMSBY.getId())) {
					List<PMSBY> pmsbyLst = pmsbyRepository.findByOrgIdAndStatusAndSourceNotAndIsActiveTrueAndAccountNumber(
							authClientResponse.getUserOrgId(), ApplicationStatus.ENROLL_COMPLETED.getId(),
							claimRequest.getAccountValue(),Source.LED.getId());
					if (!OPLUtils.isListNullOrEmpty(pmsbyLst)) {
						listOfObjects = MultipleJSONObjectHelper.getListOfObjects(
								MultipleJSONObjectHelper.getStringfromObject(pmsbyLst), null,
								ApplicationMasterBothSchemeProxy.class);
					}
				} else {
					List<PMJJBY> pmjjbyLst = pmjjbyRepository.findByOrgIdAndStatusAndSourceNotAndIsActiveTrueAndAccountNumber(
							authClientResponse.getUserOrgId(), ApplicationStatus.ENROLL_COMPLETED.getId(),
							claimRequest.getAccountValue(),Source.LED.getId());
					if (!OPLUtils.isListNullOrEmpty(pmjjbyLst)) {
						listOfObjects = MultipleJSONObjectHelper.getListOfObjects(
								MultipleJSONObjectHelper.getStringfromObject(pmjjbyLst), null,
								ApplicationMasterBothSchemeProxy.class);
					}
				}
			}

			if (OPLUtils.isListNullOrEmpty(listOfObjects)) {
				log.info("Data not found from account holder details");
				return new CommonResponse(
						"We are unable to find policy holder details for given account number / URN!!",
						HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
			}


			List<AccountHolderMappingRequest> holderMappingRequests = new ArrayList<>(listOfObjects.size());
			AccountHolderMappingRequest accountHolderMappingRequest = null;
			for (ApplicationMasterBothSchemeProxy applicationMaster : listOfObjects) {
				ApplicantPIDetails applicantPIInfo = applicantPIDetailsRepository.findById(applicationMaster.getId()).orElse(null);
				accountHolderMappingRequest = new AccountHolderMappingRequest();
				accountHolderMappingRequest.setCif(applicantPIInfo.getCif());
				accountHolderMappingRequest.setAccountHolderName(applicantPIInfo.getAcHolderName());
				accountHolderMappingRequest.setApplicationId(applicationMaster.getId());
				accountHolderMappingRequest.setCustomerAccountNumber(applicantPIInfo.getAccountNumber());
				accountHolderMappingRequest.setUrnCode(applicationMaster.getUrn());
				holderMappingRequests.add(accountHolderMappingRequest);
			}
			return new CommonResponse(CommonErrorMsg.Common.SUCCESS, holderMappingRequests, HttpStatus.OK.value(),
					true);

		} catch (Exception e) {
			log.error("Exception is getting while get account holder Details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		}
	}

	@Override
	public ClaimMasterRequest getClaimFromDetails(Long claimId) throws OneFormException, IOException {

		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
			return null;
		}
		boolean checkPhase2 = PhaseMode.checkPhase2(claimMaster.getOrgId());
		/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
		ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(claimMaster.getSchemeId().longValue(), claimMaster.getApplicationId());
		
		if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
			log.info("There is no enrollment for claimId: " + claimId);
			return null;
		}

		ClmNomineeDetails clmNomineeDetails = claimMaster.getClmNomineeDetails();
		ClmNomineePIDetails clmNomineePIDetails = claimMaster.getClmNomineeDetails().getClmNomineePIDetails();
		ClmDetails clmDetails = claimMaster.getClmDetails();
		ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();
		ClaimMasterRequest claimMasterReq = new ClaimMasterRequest();
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails())) {

			/** SET APPLICANT DETAILS */
			claimMasterReq = ClaimGetSetUtils.setApplicantDetails(claimMasterReq, appMaster, clmDetails,
					clmPIDetails);

			/** SET BASIC FIELDS */
			claimMasterReq = this.setBasicFields(claimMasterReq, claimMaster, appMaster);

			/** SET APPLICANT ADDRESS */
			claimMasterReq = ClaimGetSetUtils.setApplicantAddress(claimMasterReq, clmDetails, clmPIDetails);

			/** SET NOMINEE DETAILS */
			claimMasterReq = ClaimGetSetUtils.setNomineeAndGuardianDetails(claimMasterReq, clmNomineePIDetails,
					clmNomineeDetails,claimMaster,checkPhase2);

			/** SET CLAIM RELATED DETAILS */
			claimMasterReq = this.setClaimRelatedDetails(claimMasterReq, claimMaster, clmDetails,checkPhase2);
		}

		/** SET CLAIMANT DETAILS */
		claimMasterReq = ClaimGetSetUtils.setClaimantDetails(claimMaster, clmDetails, clmPIDetails,claimMasterReq,checkPhase2);

		return claimMasterReq;
	}

	@Override
	public CommonResponse saveClaimFormDetails(ClaimMasterRequest req) {

		if (OPLUtils.isObjectNullOrEmpty(req.getId())) {
			return new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING,
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		// UPDATE CLAIM DETAILS
		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(req.getId());
		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
			return new CommonResponse("Its seems we have not found claim details by given claim reference number",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

		/** UPDATE NOMINEE AND GUARDIAN */
		boolean checkPhase2 = PhaseMode.checkPhase2(claimMaster.getOrgId());
		ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();
		ClmDetails clmDetails = claimMaster.getClmDetails();
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
			ClmNomineeDetails nomineeDtls = claimMaster.getClmNomineeDetails();
			ClmNomineePIDetails nomineePIDtls = claimMaster.getClmNomineeDetails().getClmNomineePIDetails();
			if (!OPLUtils.isObjectNullOrEmpty(nomineeDtls)) {
				updateNomineeAndGuardianDetails(req, nomineeDtls, nomineePIDtls,checkPhase2);
			}
			if (!OPLUtils.isObjectNullOrEmpty(req.getIsClaimantSame()) && req.getIsClaimantSame().equals(Boolean.TRUE)
					&& !OPLUtils.isObjectNullOrEmpty(req.getNomineeData())) {
				/** SAVE CLAIMANT ADDRESS */
				AddressMasterRequest address = req.getClaimantData().getAddress();
				if(checkPhase2) {					
					clmPIDetails.setClmAddress(req.getClaimantData().getAddressLine1());
				}else {
					clmPIDetails.setClmAddressLine1(address.getAddressLine1());
					clmPIDetails.setClmAddressLine2(address.getAddressLine2());
				}

				/** SAVE CLAIMANT DETAILS */
				if(checkPhase2) {
					clmPIDetails.setClmName(req.getClaimantData().getFirstName());
				}else {
					clmPIDetails.setClmFirstName(req.getClaimantData().getFirstName());
					clmPIDetails.setClmMiddleName(req.getClaimantData().getMiddleName());
					clmPIDetails.setClmLastName(req.getClaimantData().getLastName());					
				}
				clmPIDetails.setClmDob(req.getClaimantData().getDateOfBirth());
				clmDetails.setClmGenderId(req.getClaimantData().getGenderId());
				clmDetails.setClmMobile(req.getClaimantData().getMobileNumber());
				clmDetails.setClmRelationId(req.getClaimantData().getRelationOfNomineeApplicant());
				clmDetails.setClmEmail(req.getClaimantData().getEmailIdOfNominee());
				
				if(!checkPhase2) {
					AddressMasterRequest claimantAddressProxy = req.getClaimantData().getAddress();
					ClmAddressMaster claimantAddress = null;
					if(OPLUtils.isObjectNullOrEmpty(clmDetails.getClaimantAddressMaster())) {						
						claimantAddress = new ClmAddressMaster();
					}else {
						claimantAddress = clmDetails.getClaimantAddressMaster();
					}
					claimantAddress.setCityId(claimantAddressProxy.getCityId());
					claimantAddress.setCityLGDCode(claimantAddressProxy.getCityLgdCode());
					claimantAddress.setCityName(claimantAddressProxy.getCity());
					claimantAddress.setDistrict(claimantAddressProxy.getDistrict());
					claimantAddress.setDistrictLGDCode(claimantAddressProxy.getDistrictLgdCode());
					claimantAddress.setPincode(claimantAddressProxy.getPincode());
					claimantAddress.setStateId(claimantAddressProxy.getStateId());
					claimantAddress.setStateLGDCode(claimantAddressProxy.getStateLgdCode());
					claimantAddress.setStateName(claimantAddressProxy.getState());
					clmDetails.setClaimantAddressMaster(claimantAddress);
				}

			}

		}

		clmDetails.setIsClaimantSame(req.getIsClaimantSame());
		ClmDetails claimDetail = claimMaster.getClmDetails();
		claimDetail.setDateTimeOfAccident(req.getDateAndTimeOfAccident());
		claimDetail.setDayOfAccident(req.getDayOfAccident());
		claimDetail.setDateOfDeath(req.getDateOfDeath());
		claimDetail.setPlaceOfOccurrence(req.getLocationOfLoss());
		claimDetail.setNatureOfLossId(req.getNatureOfLoss());
		claimDetail.setCauseOfDeathDisabilityId(req.getCauseOfDeathDisability());
		claimDetail.setTypeOfDisabilityId(
				!OPLUtils.isObjectNullOrEmpty(req.getTypeOfDisablity()) ? req.getTypeOfDisablity().intValue() : null);
		clmPIDetails.setClmAccountNumber(req.getClaimantBankAcNumber());
		clmPIDetails.setClmBranchIfsc(req.getCustIfscCode());
		clmPIDetails.setClmBankName(req.getNameOfBank());
		
		/** SET CLAIMANT KYC DOCUMENTS */
		if (!OPLUtils.isObjectNullOrEmpty(req.getKycDocId())) {
			clmPIDetails = ClaimGetSetUtils.manageClaimntKycDocuments(clmPIDetails, req);
		}

		claimDetail.setClmPIDetails(clmPIDetails);
		claimDetail.setIsNomineeNameCorrection(req.getIsNomineeSame());
		claimMaster.setFirstEnrollmentDate(req.getFirstEnrollmentDate());
		claimMaster.setModifiedDate(new Date());
		claimMaster.setModifiedBy(req.getModifiedBy());
		claimDetail.setClmMaster(claimMaster);
		claimMaster.setClmDetails(claimDetail);
		clmMasterRepository.save(claimMaster);

		/** CHECK AGE VALIDATION */
		Boolean isAgeValid = null;
		isAgeValid = this.checkAgeValidation(claimMaster, clmDetails, clmPIDetails, isAgeValid);

		if (Boolean.FALSE.equals(isAgeValid)) {
			return new CommonResponse(CommonUtils.AGE_CRITERIA_SINGLE, HttpStatus.CREATED.value(), false);
		}
		return new CommonResponse("Successfully saved Details!!", HttpStatus.OK.value(), true);
	}

	public ClaimMasterRequest getStage(Long claimId) {
		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
		if (null == claimMaster) {
			return null;
		}
		ClaimMasterRequest claimMasterRequest = new ClaimMasterRequest();
		BeanUtils.copyProperties(claimMaster, claimMasterRequest);
		claimMasterRequest.setClaimStageId(claimMaster.getStageId());
		claimMasterRequest.setClaimStatus(claimMaster.getStatus());
		claimMasterRequest.setApplicationId(claimMaster.getApplicationId());
		return claimMasterRequest;
	}

	@Override
	public CommonResponse updateStage(Long claimId, Long userId, String remarks) {

		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
		if (null == claimMaster) {
			return new CommonResponse("Its seems we found invalid claim details, Kindly refresh page and try again!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

		if (ClaimStageMaster.CLAIM_COMPLETED.getStageId() == claimMaster.getStageId()
				&& !Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())
				&& !Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {
			return new CommonResponse(
					"Its seems this claim application journey already completed. Kindly refresh page and try again!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}

		if (ClaimStageMaster.CLAIM_COMPLETED.getStageId() == claimMaster.getStageId()
				&& (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())
						|| Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_REJECTED.getId()))) {
			claimMaster.setStatus(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
		}

		if (ClaimStageMaster.CLAIM_EXPIRED.getStageId() == claimMaster.getStageId()) {
			return new CommonResponse(
					"Its seems this claim application is expired. Kindly refresh page and create new journey!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}


		/* Update History */
		updateClaimStatusAndStageHistory(claimMaster.getId());

		/**
		 * SET REMARK WHILE SEND BACK TO INSURER
		 */
		if(!OPLUtils.isObjectNullOrEmpty(remarks)){
			claimMaster.setRemarks(remarks);
		}

		ClaimStageMaster currentStage = ClaimStageMaster.getStageMasterByStageId(claimMaster.getStageId());
		Integer nextStage = claimMaster.getStageId();
		switch (currentStage) {
		case CLAIM_FORM:
			nextStage = ClaimStageMaster.CLAIM_COMPLETED.getStageId();

			claimMaster.setClaimDate(new Date());
			claimMaster.setPolicyYear(CommonUtils.fetchPolicyYear(claimMaster.getClaimDate()));
			claimMaster.setFinancialYear(CommonUtils.fetchFinancialYear(claimMaster.getClaimDate()));
			claimMaster.setPolicyMonth(CommonUtils.fetchMonth(claimMaster.getClaimDate()));
			claimMaster.setFinancialMonth(CommonUtils.fetchMonth(claimMaster.getClaimDate()));
			claimMaster.setPolicyDay(CommonUtils.fetchDay(claimMaster.getClaimDate()));
			claimMaster.setFinancialDay(CommonUtils.fetchDay(claimMaster.getClaimDate()));
			claimMaster.setStatus(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
			if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails())
					&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getClmPIDetails())) {
				log.info("Inside claim notification send");
				
				Long smsTmpId = null;
				String schemeName = null;
				if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getSchemeId())) {
					 schemeName = SchemeMaster.getById(Long.valueOf(claimMaster.getSchemeId())).getShortName();
					if(schemeName.equals(SchemeMaster.PMSBY.getShortName())) {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_REGISTRATION_SUCESS_PMSBY;
					}else {
						smsTmpId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_REGISTRATION_SUCESS_PMJJBY;
					}
				}
				if(schemeName.equals(SchemeMaster.PMJJBY.getShortName()) || (schemeName.equals(SchemeMaster.PMSBY.getShortName()) && claimMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId()))) {
					notificationUtil.sendNotification(
							setEmailParameters(
									OPLUtils.isObjectNullOrEmpty(claimMaster.getUrn()) ? null : claimMaster.getUrn(),
									OPLUtils.isObjectNullOrEmpty(
											claimMaster.getClmDetails().getClmPIDetails().getClmName()) ? claimMaster.getClmNomineeDetails().getClmNomineePIDetails().getName()
													: claimMaster.getClmDetails().getClmPIDetails().getClmName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getSchemeId()) ? null
											: SchemeMaster.getById(Long.valueOf(claimMaster.getSchemeId())).getShortName(),
									applicationMasterOtherDetailsRepository
											.getSouceByApplicationId(claimMaster.getApplicationId()),OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId()) ? null : claimMaster.getOrgId()),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getClmEmail()) ? claimMaster.getClmNomineeDetails().getEmail()
									: claimMaster.getClmDetails().getClmEmail(),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getClmMobile()) ? claimMaster.getClmNomineeDetails().getMobileNumber()
									: claimMaster.getClmDetails().getClmMobile(),
							JnsNotificationMasterUtil.EMAIL_CUST_CLAIM_REGISTRATION_SUCESS, smsTmpId, null);
				}
				else if(schemeName.equals(SchemeMaster.PMSBY.getShortName()) && claimMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())) {
					notificationUtil.sendNotification(
							setEmailParameters(
									OPLUtils.isObjectNullOrEmpty(claimMaster.getUrn()) ? null : claimMaster.getUrn(),
									OPLUtils.isObjectNullOrEmpty(
											claimMaster.getClmDetails().getClmPIDetails().getAcHolderName()) ? null
													: claimMaster.getClmDetails().getClmPIDetails().getAcHolderName(),
									OPLUtils.isObjectNullOrEmpty(claimMaster.getSchemeId()) ? null
											: SchemeMaster.getById(Long.valueOf(claimMaster.getSchemeId())).getShortName(),
									applicationMasterOtherDetailsRepository
											.getSouceByApplicationId(claimMaster.getApplicationId()),OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId()) ? null : claimMaster.getOrgId()),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApEmail()) ? null
									: claimMaster.getClmDetails().getApEmail(),
							OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApMobileNumber()) ? null
									: claimMaster.getClmDetails().getApMobileNumber(),
							JnsNotificationMasterUtil.EMAIL_CUST_CLAIM_REGISTRATION_SUCESS, smsTmpId, null);
				}
				
			}
			break;
		default:
			break;
		}
		claimMaster.setStageId(nextStage);
		claimMaster.setModifiedDate(new Date());
		claimMaster.setModifiedBy(userId);
		clmMasterRepository.save(claimMaster);

		return new CommonResponse("Successfully updated!!", nextStage, HttpStatus.OK.value(), true);
	}

	public Map<String, Object> setEmailParameters(String urn, String claimantName, String schemeName, Integer source,Long orgId) {
		log.info("entry in emailParameters()");
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("claimantName", claimantName);
		emailParameters.put("nameOfScheme", schemeName);
		emailParameters.put("urn", urn.substring(4));
		emailParameters.put("source", source);
		emailParameters.put("orgId", orgId);
		return emailParameters;
	}
	
	public Map<String, Object> setSmsParameters(String urn, Integer source,String status) {
		log.info("entry in emailParameters()");
		Map<String, Object> emailParameters = new HashMap<>();
		emailParameters.put("urn", urn.substring(4));
		emailParameters.put("source", source);
		emailParameters.put("statusUpdate", status);
		return emailParameters;
	}

	@Override
	public CommonResponse publishedClaimedData(Long claimId) throws InsuranceException {
		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
		if (OPLUtils.isObjectNullOrEmpty(claimMaster)
				|| claimMaster.getStageId() != ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
			return new CommonResponse("Its seems this claim has been not completed yet",
					HttpStatus.BAD_REQUEST.value());
		}

		String url = properties.getValueByCode("PUSH_PULL_CLAIM_API_URL") + claimMaster.getId();
		String message = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
			headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
			headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
			restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class)
					.getBody();
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus() == HttpStatus.OK.value()
//					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getFlag())
//					&& Boolean.TRUE.equals(commonResponse.getFlag())) {
//				claimMaster.setIsPushed(Boolean.TRUE);
//				isSuccess = Boolean.TRUE;
//				claimMaster.setModifiedDate(curruntDate);
//				clmMasterRepository.save(claimMaster);
//			} else {
//				message = OPLUtils.isObjectNullOrEmpty(commonResponse) ? null : commonResponse.getMessage();
//			}
		} catch (Exception e) {
			updateStageError(claimMaster.getApplicationId(), claimMaster.getId(), null,
					"PUBLISH API : " + e.getMessage(), claimMaster.getModifiedBy());
			log.error("Exception While calling Public API :: ", e);
			message = "Not Able to call Service because of : ".concat(e.getLocalizedMessage());
		}

		// PUSH DATA DD REGISTRY THROUGH PYTHON
//		try {
//			ApplicationMasterV3 applicationMaster = applicationMasterRepo
//					.findByIdAndIsActiveTrue(claimMaster.getApplicationId());
//			deDupeRegistryUtilityV3.callPushClaimRequest(claimMaster, applicationMaster);
//		} catch (Exception e) {
//			log.error("Error while push claim python API", claimMaster.getApplicationId(), e.getMessage());
//		}

//		PushReTryAudit pushReTryAudit = pushReTryAuditRepo.findFirstByTypeAndIsPushedFalseAndClaimIdOrderByIdDesc(
//				CommonUtils.PUSH_RE_TRY_CLAIM, claimMaster.getId());
//		if (Boolean.TRUE.equals(isSuccess)) {
//			if (!OPLUtils.isObjectNullOrEmpty(pushReTryAudit)) {
//				pushReTryAudit.setIsPushed(Boolean.TRUE);
//				pushReTryAudit.setModifiedDate(curruntDate);
//				pushReTryAuditRepo.save(pushReTryAudit);
//			}
//			return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
//		} else { // add details in retry table
//			if (OPLUtils.isObjectNullOrEmpty(pushReTryAudit)) {
//				pushReTryAudit = new PushReTryAudit();
//			}
//			pushReTryAudit.setApplicationId(claimMaster.getApplicationId());
//			pushReTryAudit.setClaimId(claimMaster.getId());
//			pushReTryAudit
//					.setReTryCount(OPLUtils.isObjectNullOrEmpty(pushReTryAudit.getReTryCount()) ? CommonUtils.INT_0
//							: (pushReTryAudit.getReTryCount() + CommonUtils.INT_1));
//			pushReTryAudit.setCreatedDate(curruntDate);
//			pushReTryAudit.setType(CommonUtils.PUSH_RE_TRY_CLAIM);
//			pushReTryAudit.setIsPushed(Boolean.FALSE);
//			pushReTryAudit.setMessage(message);
//			pushReTryAuditRepo.save(pushReTryAudit);
//		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public CommonResponse updateClaimAccountHolder(UpdateClaimAccountHolderRequest holderRequest, AuthClientResponse authClientResponse) {
		CommonResponse fetchPolicyDetails = null;
		ClmMaster clmMaster = null;
		try {
			
			/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
			ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(holderRequest.getSchemeId().longValue(), holderRequest.getApplicationId());

			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				return new CommonResponse("Its seems we have found invalid application details, please try again",
						HttpStatus.BAD_REQUEST.value(), false);
			}

			ApplicantInfoV2 applicantInfo = applicantInfoRepoV2.findById(appMaster.getId()).orElse(null);
			ApplicantPIDetails applicantPIInfo = applicantPIDetailsRepository.findById(applicantInfo.getId()).orElse(null);


			/** CHECK PMSBY DEDUPE */
			CommonResponse commonResponse = this.checkPMSBYDedupe(appMaster,holderRequest.getSchemeId());
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return commonResponse;
			}

			boolean isNew = false;
			ClmMaster clmMasterOldRec = clmMasterRepository
					.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(holderRequest.getApplicationId());
			if (clmMasterOldRec != null) {
				// CHECK FIRST SAME APPLICATION HAS CLAIM OR NOT
				CommonResponse deDupeResult = this.deDupeLogic(clmMasterOldRec);
				if (Boolean.FALSE.equals(deDupeResult.getFlag())) {
					updateStageError(appMaster.getId(), clmMasterOldRec.getId(), clmMasterOldRec.getStageId(),
							deDupeResult.getMessage(), authClientResponse.getUserId());
					return deDupeResult;
				}
				// CREATE NEW CLAIM FOR PMSBY DISABILITY
				if (SchemeMaster.PMSBY.getShortName().equals(deDupeResult.getMessage())) {
					isNew = true;
					clmMasterOldRec = null;
				}
			} else {
				isNew = true;
			}
			// CHECK CLAIM DE-DUPE
			CommonResponse claimDeDupeObj = null;
			if(PhaseMode.checkPhase2(appMaster.getOrgId())) {				
				claimDeDupeObj = this.claimDeDupe(appMaster, authClientResponse.getUserId(),holderRequest.getSchemeId(),holderRequest.getAccountNumber());
			}else {
				claimDeDupeObj = this.claimDeDupe(appMaster, authClientResponse.getUserId(),holderRequest.getSchemeId(),applicantPIInfo.getAccountNumber());
			}
			if (Boolean.FALSE.equals(claimDeDupeObj.getFlag())) {
				updateStageError(appMaster.getId(), clmMasterOldRec != null ? clmMasterOldRec.getId() : null,
						clmMasterOldRec != null ? clmMasterOldRec.getStageId() : null, claimDeDupeObj.getMessage(),
						authClientResponse.getUserId());
				return claimDeDupeObj;
			}

			if ((OPLUtils.isObjectNullOrEmpty(clmMasterOldRec) && isNew)
					|| (!OPLUtils.isObjectNullOrEmpty(clmMasterOldRec)
							&& Objects.equals(clmMasterOldRec.getStatus(), (ClaimStatus.CLAIM_EXPIRE.getId()))
							&& clmMasterOldRec.getStageId() == (ClaimStageMaster.CLAIM_EXPIRED.getStageId()))) {

				if(PhaseMode.checkPhase2(authClientResponse.getUserOrgId())) {
					PolicyDetailsRequest policyDetailsRequest = new PolicyDetailsRequest();

					/** PREPATE POLICE DETAILS REQUEST AND CALL BANK API */
					policyDetailsRequest = ClaimGetSetUtils.preparePolicyDetailsRequest(holderRequest,policyDetailsRequest);
					fetchPolicyDetails = enrollmentService.fetchPolicyDetails(policyDetailsRequest, authClientResponse);

					if (!OPLUtils.isObjectNullOrEmpty(fetchPolicyDetails) && fetchPolicyDetails.getStatus() == 200) {
						PolicyDetailsResponse policyDetails = MultipleJSONObjectHelper
								.getObjectFromObject(fetchPolicyDetails.getData(), PolicyDetailsResponse.class);
						if (!OPLUtils.isObjectNullOrEmpty(policyDetails)) {
							
							/**CHECK DATE OF DEATH OR DATE AND TIME OF ACCIDENT VALID OR NOT*/
							CommonResponse isValid = this.checkDateOfDeathOrAccidentValidOrNot(policyDetails,
									holderRequest);
							if (!OPLUtils.isObjectNullOrEmpty(isValid)) {
								return isValid;
							}

							/** SET CLAIM MASTER DETAILS USING APPLICATION MASTER TABLE */
							clmMaster = ClaimGetSetUtils.setClaimMaster(appMaster, authClientResponse,policyDetails,holderRequest.getSchemeId());

							/**
							 * SET CLAIM MASTER OTHER DETAILS USING APPLICATION MASTER OTHER DETAILS TABLE
							 */
							Map<String, Object> map = userManagementClient.getBranchMappingIds(clmMaster.getBranchId(),
									clmMaster.getSchemeId().longValue());
							clmMaster = ClaimGetSetUtils.setClaimMasterOtherDtl(clmMaster, map);

							/** SET CLAIM APPLICANT DETAILS USING APPLICANT INFO TABLE */
							ClmDetails clmDetails = ClaimGetSetUtils.setClaimDetails(clmMaster, policyDetails,map,authClientResponse,applicantInfo,holderRequest);
							clmMaster.setClmDetails(clmDetails);

							/** SET CLAIM APPLICANT PI DETAILS AND ADDRESS USING APPLICANT INFO TABLE */
							ClmPIDetails clmPIDetails = ClaimGetSetUtils.setClaimPIDetails(policyDetails, clmMaster,
									policyDetailsRequest);
							clmPIDetails.setClmDetails(clmDetails);
							clmDetails.setClmPIDetails(clmPIDetails);

							/** SET CLAIM NOMINEE DETAILS AND ADDRESS USING NOMINEE DETAILS TABLE */
							ClmNomineeDetails clmNomineeDetails = ClaimGetSetUtils.setNomineeAndGuardianDetails(clmMaster,
									policyDetails);
							clmMaster.setClmNomineeDetails(clmNomineeDetails);
							clmMaster = clmMasterRepository.save(clmMaster);
							
							/**INSERT CONSENT MAPPING*/
							insertConsentMapping(clmMaster.getId(),authClientResponse.getUserId());

						} else {
							return fetchPolicyDetails;
						}
					} else {
						return fetchPolicyDetails;
					}	
				}else {
					/** SET CLAIM MASTER DETAILS USING APPLICATION MASTER TABLE */
					clmMaster = ClaimGetSetUtils.setClaimMasterV2(appMaster, authClientResponse,holderRequest.getSchemeId());

					/**
					 * SET CLAIM MASTER OTHER DETAILS USING APPLICATION MASTER OTHER DETAILS TABLE
					 */
					Map<String, Object> map = userManagementClient.getBranchMappingIds(clmMaster.getBranchId(),
							clmMaster.getSchemeId().longValue());
					clmMaster = ClaimGetSetUtils.setClaimMasterOtherDtl(clmMaster, map);

					/** SET CLAIM APPLICANT DETAILS USING APPLICANT INFO TABLE */
					TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findById(appMaster.getLastTransactionId()).orElse(null);
					AddressMasterV2 addressMasterV2 = addressMasterRepositoryV2.findById(applicantInfo.getAddressId()).orElse(null);
					ClmDetails clmDetails = ClaimGetSetUtils.setClaimDetailsV2(clmMaster, map, authClientResponse.getEmail(), applicantInfo, appMaster.getGenderId(), holderRequest, transactionDetailsV2, addressMasterV2);
					clmMaster.setClmDetails(clmDetails);

					/** SET CLAIM APPLICANT PI DETAILS AND ADDRESS USING APPLICANT INFO TABLE */
					ClmPIDetails clmPIDetails = ClaimGetSetUtils.setClaimPIDetailsV2(clmMaster,applicantPIInfo,addressMasterV2);
					clmPIDetails.setClmDetails(clmDetails);
					clmDetails.setClmPIDetails(clmPIDetails);

					/** SET CLAIM NOMINEE DETAILS AND ADDRESS USING NOMINEE DETAILS TABLE */
					NomineeDetailsV2 nomineeDetailsV2 = nomineeDetailsRepositoryV2.findByApplicationIdAndIsActiveTrue(appMaster.getId());
					NomineePIDetails nomineePIDetailsV2 = nomineePIDetailsRepository.findById(nomineeDetailsV2.getId()).orElse(null);
					AddressMasterV2 nomineeAddMasterV2 = addressMasterRepositoryV2.findById(nomineeDetailsV2.getAddressId()).orElse(null);
					ClmNomineeDetails clmNomineeDetails = ClaimGetSetUtils.setNomineeAndGuardianDetailsV2(clmMaster,
							nomineeDetailsV2,nomineePIDetailsV2,nomineeAddMasterV2);
					clmMaster.setClmNomineeDetails(clmNomineeDetails);
					clmMaster = clmMasterRepository.save(clmMaster);
					
				}
				

			} else {
				clmMasterOldRec.setModifiedBy(authClientResponse.getUserId());
				clmMasterOldRec.setModifiedDate(new Date());
			}
			return new CommonResponse(CommonErrorMsg.Common.SUCCESS, !OPLUtils.isObjectNullOrEmpty(clmMaster) ? clmMaster.getId() : clmMasterOldRec.getId(), HttpStatus.OK.value(), true);
		} catch (Exception e) {
			updateStageError(holderRequest.getApplicationId(), null, null, "Claim Update Account Holder : " + e.getMessage(),
					authClientResponse.getUserId());
			log.error("Exception is getting while save claim account Holder Details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	public void insertConsentMapping(Long claimId,Long userId) {
		try {			
			ereCommonService.insertDataConsentMappingTable(ConsentMappingProxy.builder().appTypeValue(claimId).appType(ApplicationType.CLAIM.getId()).userId(userId).consentTypeId(ConsentType.BO_CLAIM.getId()).build());
		}catch (Exception e) {
			log.info("ERROR WHILE SAVE CONSENT--> {}", userId);
		}
	}
	
	@Override
	public CommonResponse findAllApprovedClaimDetailsByApplicationId(Long claimId) {
		if (OPLUtils.isObjectNullOrEmpty(claimId)) {
			return new CommonResponse("Its seems we found invalid claim id , Kindly refresh page and try again!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		List<ClaimMasterRequest> claimMasterHistory = new ArrayList<>();
		try {
			ClmMaster masterData = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
			if (OPLUtils.isObjectNullOrEmpty(masterData)) {
				return new CommonResponse("No claim history was found!!", ResponseStatus.BAD_REQUEST.getStatusId(),
						false);
			}
			List<ClmMaster> claimHisoryList = clmMasterRepository
					.findByApplicationIdAndIsActiveTrueAndStatusOrderByIdDesc(masterData.getApplicationId(),
							ClaimStatus.CLAIM_ACCEPTED.getId());
			if (!claimHisoryList.isEmpty()) {
				ClaimMasterRequest claimMasterRequest = null;
				for (ClmMaster claimMaster : claimHisoryList) {
					claimMasterRequest = new ClaimMasterRequest();
					BeanUtils.copyProperties(claimMaster, claimMasterRequest);
					claimMasterRequest.setTransactionUtr(claimMaster.getTransactionUTR());
					claimMasterRequest.setDateOfTransaction(claimMaster.getTransactionTimeStamp());
					claimMasterRequest.setAmountOfTransaction(claimMaster.getTransactionAmount());
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
						String typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,
								claimMaster.getClmDetails().getTypeOfDisabilityId());
						claimMasterRequest.setTypeOfDisablityValue(typeOfDisability);
					}
					claimMasterHistory.add(claimMasterRequest);
				}
				return new CommonResponse("Successfully get data !!", claimMasterHistory, HttpStatus.OK.value(), true);
			} else {
				return new CommonResponse("No claim history was found!!", ResponseStatus.BAD_REQUEST.getStatusId(),
						false);
			}
		} catch (Exception e) {
			log.error("Exception is getting while approved claim details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	private void updateStageError(Long applicationId, Long claimId, Integer claimStageId, String msg, Long modifiedBy) {
		@SuppressWarnings("unused")
		ClaimStageMaster stage = null;
		if (claimStageId != null) {
			stage = ClaimStageMaster.getStageMasterByStageId(claimStageId);
		}
		// stageAuditUtils.update(new ErrorStageProxy(applicationId, claimId,
		// claimStageId,stage != null ? stage.getStageName() : null, msg, modifiedBy));
	}

	@Override
	public CommonResponse findAllClaimHistoryByApplicationId(Long applicationId) {
		if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
			return new CommonResponse("Its seems we found invalid applicationId , Kindly refresh page and try again!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		List<ClaimMasterRequest> claimMasterHistory = new ArrayList<>();
		try {
			ClmMaster masterData = clmMasterRepository
					.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(masterData)
					&& masterData.getStageId() != EnrollStageMaster.PREMIUM_DEDUCTION.getStageId()
					&& masterData.getStageId() != EnrollStageMaster.REJECTED.getStageId()
					&& masterData.getStageId() != EnrollStageMaster.EXPIRED.getStageId()) {
				List<ClmMaster> claimHisoryList = clmMasterRepository
						.findByStageIdAndIsActiveTrueAndApplicationIdOrderByIdDesc(
								ClaimStageMaster.CLAIM_COMPLETED.getStageId(), masterData.getApplicationId());
				if (!claimHisoryList.isEmpty()) {
					ClaimMasterRequest claimMasterRequest = null;
					for (ClmMaster claimMaster : claimHisoryList) {
						claimMasterRequest = new ClaimMasterRequest();
						BeanUtils.copyProperties(claimMaster, claimMasterRequest);
						claimMasterRequest.setClaimStatus(claimMaster.getStatus());
						String typeOfDisability = null;
						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
							typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,
									claimMaster.getClmDetails().getTypeOfDisabilityId());
						}
						String typeOfVisValue = !OPLUtils
								.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())
								&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 2 ? "Death"
										: "Accidental Death";
						claimMasterRequest.setTypeOfDisablityValue(
								!OPLUtils.isObjectNullOrEmpty(typeOfDisability) ? typeOfDisability : typeOfVisValue);
						claimMasterHistory.add(claimMasterRequest);
					}
					return new CommonResponse("Successfully get data !!", claimMasterHistory, HttpStatus.OK.value(),
							true);
				}
			}
			return new CommonResponse("No claim history was found!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		} catch (Exception e) {
			log.error("Exception is getting while approved claim details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	@Override
	public CommonResponse fetchViewClaimDetailsByApplicationId(Long applicationId, Long claimId) throws ParseException {
		try {
			ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
//			ApplicationMasterV3 applicationMaster = applicationMasterRepo
//					.findByIdAndIsActiveTrue(claimMaster.getApplicationId());

			if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				boolean checkPhase2 = PhaseMode.checkPhase2(claimMaster.getOrgId());
				ClmNomineeDetails nomineeMaster = claimMaster.getClmNomineeDetails();

				ClaimDashboardViewV2 claimDashboardViewV2 = new ClaimDashboardViewV2();
				claimDashboardViewV2.setFullName(claimMaster.getClmDetails().getClmPIDetails().getAcHolderName());
				claimDashboardViewV2.setUrnNo(claimMaster.getUrn());
				if (claimMaster.getSchemeId() == SchemeMaster.PMSBY.getId().longValue()) {
					String typeOfDisability = null;
//					if(checkPhase2) {
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
						typeOfDisability = TypeOfDisability.fromId(claimMaster.getClmDetails().getTypeOfDisabilityId())
								.getValue();
					}
					String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
							&& claimMaster.getClmDetails().getNatureOfLossId() == NatureOfLoss.DISABILITY.getId() ? typeOfDisability : "-";
					claimDashboardViewV2.setTypeOfLoss(
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
									&& claimMaster.getClmDetails().getNatureOfLossId() == NatureOfLoss.DEATH.getId() ? "Accidental Death"
											: typeOfLoss);
//					}
//					else {
//						claimDashboardViewV2.setTypeOfLoss(CauseOfDeathDisability.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());						
//					}
					
				} else if (claimMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().longValue()) {
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
						String typeOfLoss = claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId()
								? "Accidental Death"
										: claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == CauseOfDeathDisabilityV2.SUICIDE.getId() ? "Suicide" : "-";
						claimDashboardViewV2.setTypeOfLoss(
								claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getId() ? "Death" : typeOfLoss);
//						if(checkPhase2) {							
//							claimDashboardViewV2.setTypeOfLoss(CauseOfDeathDisabilityV2.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
//						}else {
//							claimDashboardViewV2.setTypeOfLoss(CauseOfDeathDisability.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
//						}
					}
				}
				claimDashboardViewV2.setReceiveddate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
						? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate())
						: null);
				claimDashboardViewV2.setLastActionDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
						? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
						: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
				claimDashboardViewV2
						.setSchemeName(SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
				claimDashboardViewV2.setClaimStatus(claimMaster.getStatus());
				claimDashboardViewV2.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
						? CommonUtils.sdf_yyyy_MM_dd_T_HH_mm_ss_SS.format(claimMaster.getClaimDate())
						: null);
				claimDashboardViewV2.setIsClaimantSame(
						!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getIsClaimantSame())
								&& claimMaster.getClmDetails().getIsClaimantSame() == Boolean.TRUE ? "Yes" : "No");
				int ageByDob = !OPLUtils.isObjectNullOrEmpty(nomineeMaster)
						? CommonUtils.getAgeBydob(nomineeMaster.getClmNomineePIDetails().getDob())
						: CommonUtils.INT_0;
				claimDashboardViewV2.setNomineeAge(ageByDob);
				claimDashboardViewV2.setRejectCnt(
						!OPLUtils.isObjectNullOrEmpty(claimMaster.getRejectReopenCnt()) ? claimMaster.getRejectReopenCnt() : null);

				LinkedHashMap<String, Object> insuredDetails = new LinkedHashMap<>();
				ClmDetails clmDetails = claimMaster.getClmDetails();
				ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();

			//PhaseWise Show Details
				//phase1
				if(!checkPhase2) {
					// For Accepted and Rejected Deatils
					if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_ACCEPTED.getId())
							|| Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {

						insuredDetails.put("Scheme Name",
								SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
						insuredDetails.put("Insured Name", claimMaster.getClmDetails().getClmPIDetails().getAcHolderName());
						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerOrgId())) {
							String organizationName = usersClient.getOrganizationName(claimMaster.getInsurerOrgId());
							if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
								insuredDetails.put("Name of Insurer", organizationName);
							}
						}
						insuredDetails.put("Policy Inception Date",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getFirstEnrollmentDate())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getFirstEnrollmentDate())
										: null);
						insuredDetails.put("Branch Code", clmDetails.getBranchCode());
						insuredDetails.put("Date of Death",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClmDetails().getDateOfDeath())
										: null);
						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
								&& Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMJJBY.getId())) {
							if(checkPhase2) {							
								insuredDetails.put("Cause of Death", CauseOfDeathDisabilityV2
										.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
							}else {
								insuredDetails.put("Cause of Death", CauseOfDeathDisability
										.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
							}
						}
						insuredDetails.put("Date of Loading Claim",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate())
										: null);

						if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_ACCEPTED.getId())) {
							insuredDetails.put("Date of Payment",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
											: null);
							insuredDetails.put("UTR Number", claimMaster.getTransactionUTR());
							insuredDetails.put("Amount Approved",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionAmount())
											? OPLUtils.generateCurrency(claimMaster.getTransactionAmount().toString())
											: null);
							insuredDetails.put("Amount Claimed",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
											&& claimMaster.getClmDetails().getNatureOfLossId() == 2
											&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
													: "2,00,000");
						} else {
//							String rejectionReason = !OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerReason())
//									? claimMaster.getInsurerReason()
//									: "-";
							insuredDetails.put("Reason For Rejection",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId()) ? (claimMaster.getSchemeId().intValue()==SchemeMaster.PMSBY.getId() ? PMSBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue() : PMJJBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue())
											: null);
							insuredDetails.put("Rejection Date",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
											: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
						}
						claimDashboardViewV2.setInsuredDetails(insuredDetails);

						// For Accepted and Rejected Deatils pmsby
						LinkedHashMap<String, Object> pmsbyDetails = new LinkedHashMap<>();
						if (Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMSBY.getId())) {
							pmsbyDetails.put("Date of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.sdf_dd_MM_yyyy
													.format(claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
							pmsbyDetails.put("Time of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.HH_mm_ss
													.format(claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
							pmsbyDetails.put("Day of Accident", claimMaster.getClmDetails().getDayOfAccident());
							pmsbyDetails.put("Place Of Occurrence", claimMaster.getClmDetails().getPlaceOfOccurrence());
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())) {
								String natureOfLoss = NatureOfLoss.fromId(claimMaster.getClmDetails().getNatureOfLossId())
										.getValue();
								pmsbyDetails.put("Nature of Loss", natureOfLoss);
							}
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
								if(checkPhase2) {
									pmsbyDetails.put("Cause of Death/Disability", CauseOfDeathDisabilityV2
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}else {
									pmsbyDetails.put("Cause of Death/Disability", CauseOfDeathDisability
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}
							}
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
								String typeOfDiability = TypeOfDisability
										.fromId(claimMaster.getClmDetails().getTypeOfDisabilityId()).getValue();
								pmsbyDetails.put("Type of Disability", typeOfDiability);
							}
							claimDashboardViewV2.setPmsbyDetails(pmsbyDetails);
						}

					} else {
						//  CLAIM_IN_PROGRESS  AND CLAIM_SEND_BACK_BY_INSURER(Quired)
//						insuredDetails.put("First Name", clmPIDetails.getApFirstName());
//						insuredDetails.put("Middle Name", clmPIDetails.getApMiddleName());
//						insuredDetails.put("Last Name", clmPIDetails.getApLastName());
						insuredDetails.put("Insured Name", claimMaster.getClmDetails().getClmPIDetails().getAcHolderName());
						insuredDetails.put("Date of Birth",
								!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApDob())
										? CommonUtils.sdf_dd_MM_yyyy.format(clmPIDetails.getApDob())
										: null);
						insuredDetails.put("Mobile Number", clmDetails.getApMobileNumber());
						insuredDetails.put("Email ID", clmDetails.getApEmail());
						insuredDetails.put("Account Number", clmPIDetails.getClmAccountNumber());
						insuredDetails.put("Policy Inception Date",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getFirstEnrollmentDate())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getFirstEnrollmentDate())
										: null);
//						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId())) {
//							String organizationName = usersClient.getOrganizationName(claimMaster.getOrgId());
//							if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//								insuredDetails.put("Name of Bank", organizationName);
//							}
//						}
						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerOrgId())) {
							String organizationName = usersClient.getOrganizationName(claimMaster.getInsurerOrgId());
							if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
								insuredDetails.put("Name of Insurer", organizationName);
							}
						}
						claimDashboardViewV2.setInsuredDetails(insuredDetails);

						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmNomineeDetails())) {
							ClmNomineeDetails clmNomineeDetails = claimMaster.getClmNomineeDetails();
							ClmNomineePIDetails clmNomineePIDetails = claimMaster.getClmNomineeDetails()
									.getClmNomineePIDetails();
//							LinkedHashMap<String, Object> insuredAddress = new LinkedHashMap<>();
//							insuredAddress.put("Address Line 1", clmNomineePIDetails.getAddressLine1());
//							insuredAddress.put("Address Line 2", clmNomineePIDetails.getAddressLine2());
//							insuredAddress.put("City", clmNomineeDetails.getClmAddressMaster().getCityName());
//							insuredAddress.put("District", clmNomineeDetails.getClmAddressMaster().getDistrict());
//							insuredAddress.put("State", clmNomineeDetails.getClmAddressMaster().getStateName());
//							claimDashboardViewV2.setInsuredAddress(insuredAddress);
							if (!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails)) {
								LinkedHashMap<String, Object> nomineeDetails = new LinkedHashMap<>();
//								nomineeDetails.put("First Name", clmNomineePIDetails.getFirstName());
//								nomineeDetails.put("Middle Name", clmNomineePIDetails.getMiddleName());
//								nomineeDetails.put("Last Name ", clmNomineePIDetails.getLastName());
								nomineeDetails.put("Nominee Name ", clmNomineePIDetails.getName());
								nomineeDetails.put("Date of Birth",
										!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob())
												? CommonUtils.sdf_dd_MM_yyyy.format(clmNomineePIDetails.getDob())
												: null);
								nomineeDetails.put("Age",
										!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob()) && ageByDob == 0
												|| ageByDob == 1 ? ageByDob + " Year" : ageByDob + " Years");
								if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails)) {
									nomineeDetails.put("Mobile Number", clmNomineeDetails.getMobileNumber());
									nomineeDetails.put("Email ID", clmNomineeDetails.getEmail());
									String relationShipApp = RelationShip.fromId(clmNomineeDetails.getRelationId())
											.getValue();
									nomineeDetails.put("RelationShip With The Applicant", relationShipApp);
//									nomineeDetails.put("Nominee Gender",
//											null != clmPIDetails.getClmGenderId()
//													? Gender.fromId(clmPIDetails.getClmGenderId()).getValue()
//													: null);
								}

//								// FOR NOMINEE UPDATE DATA
//								MiscellaneousAudit nomineeUpdatedData = miscellaneousAuditRepository
//										.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId,
//												MiscellaneousType.NOMINEE_UPDATE.getId());
//								if (!OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData)) {
//									nomineeDetails.put("Date of Nominee Details updation",
//											!OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData.getCreatedDate())
//													? CommonUtils.sdf_dd_MM_yyyy.format(nomineeUpdatedData.getCreatedDate())
//													: null);
//								}
//								nomineeDetails.put("Relationship with Deceased",
//										null != clmNomineeDetails.getRelationId()
//												? RelationShip.fromId(clmNomineeDetails.getRelationId()).getValue()
//												: null);
								claimDashboardViewV2.setNomineeDetails(nomineeDetails);
							}
							LinkedHashMap<String, Object> guardianDetails = new LinkedHashMap<>();
							guardianDetails.put("Name", clmNomineePIDetails.getGdName());
							if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdRelationId())) {
								String relationShip = RelationShip.fromId(clmNomineeDetails.getGdRelationId()).getValue();
								guardianDetails.put("Relationship with Nominee", relationShip);
							}
							guardianDetails.put("Mobile Number", clmNomineeDetails.getGdMobile());
							guardianDetails.put("E-Mail ID", clmNomineeDetails.getGdEmail());
							claimDashboardViewV2.setGuardianDetails(guardianDetails);
						}
						LinkedHashMap<String, Object> claimantDetails = new LinkedHashMap<>();
						if(checkPhase2) {						
							claimantDetails.put("Claimant Name", clmPIDetails.getClmName());
						}else {
							claimantDetails.put("First Name", clmPIDetails.getClmFirstName());
							claimantDetails.put("Middle Name", clmPIDetails.getClmMiddleName());
							claimantDetails.put("Last Name", clmPIDetails.getClmLastName());
						}
						claimantDetails.put("Date of Birth",
								!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getClmDob())
										? CommonUtils.sdf_dd_MM_yyyy.format(clmPIDetails.getClmDob())
										: null);
//						int ageByDobClaimant = CommonUtils.getAgeBydob(clmPIDetails.getClmDob());
//						claimantDetails.put("Age",
//								!OPLUtils.isObjectNullOrEmpty(ageByDobClaimant) && ageByDobClaimant == CommonUtils.INT_0
//										|| ageByDobClaimant == CommonUtils.INT_1 ? ageByDobClaimant + " Year"
//												: ageByDobClaimant + " Years");
						claimantDetails.put("Mobile Number", clmDetails.getClmMobile());
						claimantDetails.put("Email ID", clmDetails.getClmEmail());
						claimantDetails.put("Relationship with Nominee",
								null != clmDetails.getClmRelationId() ? RelationShip.fromId(clmDetails.getClmRelationId())
										: null);
						claimantDetails.put("Claimant Gender",
								null != clmDetails.getClmGenderId()
										? Gender.fromId(clmDetails.getClmGenderId()).getValue()
										: null);
						claimDashboardViewV2.setClaimantDetails(claimantDetails);

						if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
							LinkedHashMap<String, Object> claimDetails = new LinkedHashMap<>();
							claimDetails.put("Date of Death",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath())
											? CommonUtils.sdf_dd_MM_yyyy
													.format(claimMaster.getClmDetails().getDateOfDeath())
											: null);
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
									&& Objects.equals(Long.valueOf(claimMaster.getSchemeId()),
											SchemeMaster.PMJJBY.getId())) {
								if(checkPhase2) {								
									claimDetails.put("Cause of Death", CauseOfDeathDisabilityV2
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}else {
									claimDetails.put("Cause of Death", CauseOfDeathDisability
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}
							}
							claimDetails.put("Date of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.sdf_dd_MM_yyyy
													.format(claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
							claimDetails.put("Time of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.HH_mm_ss
													.format(claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
//							claimDetails.put("Location of Loss", claimMaster.getClmDetails().getPlaceOfOccurrence());
							claimDetails.put("Place Of Occurrence", claimMaster.getClmDetails().getPlaceOfOccurrence());
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())) {
								String natureOfLoss = NatureOfLoss.fromId(claimMaster.getClmDetails().getNatureOfLossId())
										.getValue();
								claimDetails.put("Nature of Loss", natureOfLoss);
							}

							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
									&& Objects.equals(Long.valueOf(claimMaster.getSchemeId()),
											SchemeMaster.PMSBY.getId())) {
								if(checkPhase2) {
									claimDetails.put("Cause of Death/Disability", CauseOfDeathDisabilityV2
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}else {
									claimDetails.put("Cause of Death/Disability", CauseOfDeathDisability
											.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
								}
							}

							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
								String typeOfDiability = TypeOfDisability
										.fromId(claimMaster.getClmDetails().getTypeOfDisabilityId()).getValue();
								claimDetails.put("Type of Disability", typeOfDiability);
							}
							claimDashboardViewV2.setClaimDetails(claimDetails);

							LinkedHashMap<String, Object> claimantBankDetails = new LinkedHashMap<>();
							claimantBankDetails.put("Bank Name", clmPIDetails.getClmBankName());
							claimantBankDetails.put("IFSC", clmPIDetails.getClmBranchIfsc());
							claimantBankDetails.put("Bank A/C number", clmPIDetails.getClmAccountNumber());
							claimantBankDetails.put("Amount Claimed",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
											&& claimMaster.getClmDetails().getNatureOfLossId() == 2
											&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
													: "2,00,000");
							claimantBankDetails.put("Branch Code", clmDetails.getBranchCode());
							claimDashboardViewV2.setClaimantBankDetails(claimantBankDetails);

//							LinkedHashMap<String, Object> paymentDetails = new LinkedHashMap<>();
//							paymentDetails.put("Date of Payment",
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
//											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
//											: null);
//							paymentDetails.put("UTR Number", claimMaster.getTransactionUtr());
//							paymentDetails.put("Amount Approved",
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getAmountOfTransaction())
//											? OPLUtils.generateCurrency(claimMaster.getAmountOfTransaction().toString())
//											: null);
//							paymentDetails.put("Amount Claimed",
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
//											&& claimMaster.getClmDetails().getNatureOfLossId() == 2
//											&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
//													: "2,00,000");
//							paymentDetails.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//							paymentDetails.put("Insurer Status", claimMaster.getInsurerStatus());
//							claimDashboardViewV2.setPaymentDetails(paymentDetails);

//							LinkedHashMap<String, Object> rejectionDetails = new LinkedHashMap<>();
//							String rejectionReason = !OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerReason())
//									? claimMaster.getInsurerReason()
//									: "-";
//							rejectionDetails.put("Reason For Rejection",
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getMessage()) ? claimMaster.getMessage()
//											: rejectionReason);
//							rejectionDetails.put("Rejection Date",
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
//											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
//											: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//							claimDashboardViewV2.setRejectionDetails(rejectionDetails);

							//CLAIM_SEND_BACK_BY_INSURER(Quired)
							LinkedHashMap<String, Object> sentBackToBank = new LinkedHashMap<>();
							sentBackToBank.put("Reason for referring back by Insurer", !OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId()) ? QueriedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue() : null);
							sentBackToBank.put("Insurer status", claimMaster.getInsurerStatus());
							sentBackToBank.put("Query Date",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
											: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//							sentBackToBank.put("Comment By Bank ", claimMaster.getInsurerStatus());
//							sentBackToBank.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//							sentBackToBank.put("Insurer Status", claimMaster.getInsurerStatus());
							claimDashboardViewV2.setSentBackToBank(sentBackToBank);

							// FOR OPT OUT DATA
//							MiscellaneousAudit optOutData = miscellaneousAuditRepository
//									.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId,
//											MiscellaneousType.OPT_OUT.getId());
//							if (!OPLUtils.isObjectNullOrEmpty(optOutData)) {
//								LinkedHashMap<String, Object> optOut = new LinkedHashMap<>();
//								optOut.put("Request Date",
//										!OPLUtils.isObjectNullOrEmpty(optOutData.getDateOfRequest())
//												? CommonUtils.sdf_dd_MM_yyyy.format(optOutData.getDateOfRequest())
//												: null);
//								optOut.put("Effective Date",
//										!OPLUtils.isObjectNullOrEmpty(optOutData.getDateOfEffective())
//												? CommonUtils.sdf_dd_MM_yyyy.format(optOutData.getDateOfEffective())
//												: null);
//								claimDashboardViewV2.setOptOut(optOut);
//							}

						}
					}
				} else {
					// phase2
					insuredDetails.put("Policy Inception Date",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getFirstEnrollmentDate())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getFirstEnrollmentDate())
									: null);
					if (Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMSBY.getId())) {
						insuredDetails.put("Insured Mobile Number", clmDetails.getApMobileNumber());
					}
					if ((Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMSBY.getId())
							&& claimMaster.getClmDetails().getNatureOfLossId() == NatureOfLoss.DEATH.getId())
							|| Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMJJBY.getId())) {
						if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmNomineeDetails())) {
							ClmNomineeDetails clmNomineeDetails = claimMaster.getClmNomineeDetails();
							insuredDetails.put("Nominee Mobile Number ", clmNomineeDetails.getMobileNumber());
						}
						insuredDetails.put("Claimant Mobile Number", clmDetails.getClmMobile());				
					}
//						insuredDetails.put("Claimant Mobile Number", clmDetails.getClmMobile());						
					insuredDetails.put("Branch Code", clmDetails.getBranchCode());
					insuredDetails.put("Bank/Branch Email Id", clmDetails.getBranchEmailId());
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerOrgId())) {
						String organizationName = usersClient.getOrganizationName(claimMaster.getInsurerOrgId());
						if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
							insuredDetails.put("Name of Insurer", organizationName);
						}
					}
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId())) {
						String bankName = usersClient.getOrganizationName(claimMaster.getOrgId());
						if (!OPLUtils.isObjectNullOrEmpty(bankName)) {
							insuredDetails.put("Name of Bank", bankName);
						}
					}
					
//					claimDashboardViewV2.setInsuredDetails(insuredDetails);

					if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
						LinkedHashMap<String, Object> claimDetails = new LinkedHashMap<>();
						// scheme pmjjby
						if (Objects.equals(Long.valueOf(claimMaster.getSchemeId()), SchemeMaster.PMJJBY.getId())) {
							claimDetails
									.put("Date of Death",
											!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath())
													? CommonUtils.sdf_dd_MM_yyyy.format(
															claimMaster.getClmDetails().getDateOfDeath())
													: null);
							if (!OPLUtils
									.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
								claimDetails.put("Cause of Death", CauseOfDeathDisabilityV2
										.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
							}

						} else {
							// scheme pmsby
							claimDetails.put("Date of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.sdf_dd_MM_yyyy.format(
													claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
							claimDetails.put("Time of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.HH_mm_ss.format(
													claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
							claimDetails.put("Day of Accident", claimMaster.getClmDetails().getDayOfAccident());
							claimDetails.put("Place Of Occurrence", claimMaster.getClmDetails().getPlaceOfOccurrence());
							if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())) {
								String natureOfLoss = NatureOfLoss
										.fromId(claimMaster.getClmDetails().getNatureOfLossId()).getValue();
								claimDetails.put("Nature of Accident", natureOfLoss);

								if (Objects.equals((claimMaster.getClmDetails().getNatureOfLossId()),
										(NatureOfLoss.DEATH.getId()))) {
									// DEATH
									claimDetails.put("Date of Death",
											!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath())
													? CommonUtils.sdf_dd_MM_yyyy.format(
															claimMaster.getClmDetails().getDateOfDeath())
													: null);
									if (!OPLUtils.isObjectNullOrEmpty(
											claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
										claimDetails.put("Cause of Death",
												CauseOfDeathDisabilityV2.fromId(
														claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
														.getValue());
									}
								} else if (Objects.equals((claimMaster.getClmDetails().getNatureOfLossId()),
										NatureOfLoss.DISABILITY.getId())) {
									// Disability
									claimDetails.put("Cause of Disability",
											CauseOfDeathDisabilityV2
													.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
													.getValue());

									if (!OPLUtils
											.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
										String typeOfDiability = TypeOfDisability
												.fromId(claimMaster.getClmDetails().getTypeOfDisabilityId()).getValue();
										claimDetails.put("Type of Disability", typeOfDiability);
									}
								}
							}
						}
						claimDetails.put("Date of Lodging Claim",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate())
										: null);
						if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_ACCEPTED.getId())) {
							claimDetails.put("Date of Payment",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
											: null);
							claimDetails.put("UTR Number", claimMaster.getTransactionUTR());
							claimDetails.put("Amount Claimed",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
											&& claimMaster.getClmDetails().getNatureOfLossId() == 2
											&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
													: "2,00,000");
							claimDetails.put("Amount Approved",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionAmount())
											? OPLUtils.generateCurrency(claimMaster.getTransactionAmount().toString())
											: null);
						}
						if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {
							claimDetails.put("Reason For Rejection",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId())
											? (claimMaster.getSchemeId().intValue() == SchemeMaster.PMSBY.getId()
													? PMSBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId())
															.getValue()
													: PMJJBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId())
															.getValue())
											: null);
							claimDetails.put("Rejection Date",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
											? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
											: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
						}

						claimDetails.put("Claim Registration Date", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
								? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate())
								: null);

						claimDashboardViewV2.setClaimDetails(claimDetails);
					}
					if (Objects.equals(claimMaster.getStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
						// CLAIM_SEND_BACK_BY_INSURER(Quired)
						LinkedHashMap<String, Object> sentBackToBank = new LinkedHashMap<>();
						sentBackToBank.put("Reason for referring back by Insurer",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId())
										? QueriedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue()
										: null);
						sentBackToBank.put("Insurer status", claimMaster.getInsurerStatus());
						sentBackToBank.put("Query Date",
								!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
										? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
										: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
						claimDashboardViewV2.setSentBackToBank(sentBackToBank);
					}
					claimDashboardViewV2.setInsuredDetails(insuredDetails);
				}
		
				return new CommonResponse("Successfully get data !!", claimDashboardViewV2, HttpStatus.OK.value(),
						true);
			}
			return new CommonResponse("No data found!!", ResponseStatus.BAD_REQUEST.getStatusId(), false);
		} catch (Exception e) {
			log.error("Exception is getting while claim details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	public CommonResponse updateClaimStatus(ClaimStatusRequest claimStatusRequest, Long userId)
			throws OneFormException, IOException {
		ClmMaster master = clmMasterRepository.findByIdAndIsActiveTrue(claimStatusRequest.getClaimId());
		ClaimStatus appStatus = ClaimStatus.fromId(claimStatusRequest.getClaimStatus());
		if (OPLUtils.isObjectNullOrEmpty(appStatus)) {
			return new CommonResponse("Its seems we found invalid claim status, Kindly refresh page and try again!!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		if (Objects.equals(master.getStatus(), ClaimStatus.CLAIM_ACCEPTED.getId())) {
			return new CommonResponse("Its seems this claim already completed !!",
					ResponseStatus.BAD_REQUEST.getStatusId(), false);
		}
		if (Objects.equals(claimStatusRequest.getClaimStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {
			master.setRejectReopenCnt(
					!OPLUtils.isObjectNullOrEmpty(master.getRejectReopenCnt()) ? master.getRejectReopenCnt() + CommonUtils.INT_1
							: CommonUtils.INT_1);
		}
		if (Objects.equals(claimStatusRequest.getClaimStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
			master.setInsurerStatus(claimStatusRequest.getInsurerStatus());
		}
		try {
			if (!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getAmountOfTransaction())) {
				if (appStatus.getValue().equals(ClaimStatus.CLAIM_ACCEPTED.getValue())) {
					if (master.getSchemeId().intValue() == SchemeMaster.PMSBY.getId()
							&& !OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getNatureOfLossId())
							&& master.getClmDetails().getNatureOfLossId() == CommonUtils.NATURE_OF_LOSS_DISABLITY
							&& master.getClmDetails().getTypeOfDisabilityId() == CommonUtils.TYPE_OF_DISABLITY_ID) {
						if (claimStatusRequest.getAmountOfTransaction() > Long
								.parseLong(properties.getValueByCode("PMSBY_DISABLITY_CLAIM_AMOUNT"))) {
							return new CommonResponse(
									CommonUtils.APPROVED_CLAIM_AMOUNT_NOT_VALIDATE_MSG
											+ properties.getValueByCode("PMSBY_DISABLITY_CLAIM_AMOUNT") + " !!",
									ResponseStatus.AMOUNT_INVALID_ERROR.getStatusId(), false);
						}
					} else if (claimStatusRequest.getAmountOfTransaction() > Long
							.parseLong(properties.getValueByCode(CommonUtils.PMSBY_TOTAL_CLAIM_AMOUNT))) {
						return new CommonResponse(
								CommonUtils.APPROVED_CLAIM_AMOUNT_NOT_VALIDATE_MSG
										+ properties.getValueByCode(CommonUtils.PMSBY_TOTAL_CLAIM_AMOUNT) + " !!",
								ResponseStatus.AMOUNT_INVALID_ERROR.getStatusId(), false);
					}
					master.setTransactionUTR(claimStatusRequest.getTransactionUTR());
					master.setTransactionAmount(claimStatusRequest.getAmountOfTransaction());
					master.setTransactionTimeStamp(claimStatusRequest.getDateOfTransaction());
				}
			}
		} catch (Exception e) {
			return new CommonResponse("Claim not accepted", HttpStatus.BAD_REQUEST.value());
		}
		/* Update History */
		updateClaimStatusAndStageHistory(master.getId());

		master.setIsPortalThroughUpdatedStatus(true);
		master.setStatus(claimStatusRequest.getClaimStatus());
		master.setModifiedDate(new Date());
		master.setModifiedBy(userId);
		
		if (!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getStatusReason())) {
			master.setStatusReasonId(claimStatusRequest.getStatusReason());
//			String statusReason = oneFormClient
//					.getNameByKeyAndObjId(DropDownMasterKey.STATUS_REASON, master.getStatusReasonId()).getValue();
//			if (!OPLUtils.isObjectNullOrEmpty(statusReason)) {
//				master.setStatusReason(statusReason);
//			}
		}
		/**FIRST BANK CLAIM STATUS PUSH FLAG SET FALSE*/
		master.setIsBankClaimStatusPush(false);
		
		/**FIRST INSURER CLAIM STATUS PUSH FLAG SET FALSE*/
		master.setIsInsurerClaimStatusPush(false);
		
		clmMasterRepository.save(master);
		
		/**PUSH CLAIM STATUS TO BANK*/
		PushClaimStatustoBankReq bankReq = prepareRequestBankStatusUpdate(master,claimStatusRequest);
		webHookClient.pushClaimStatusToBank(bankReq);
		
		/**PUSH CLAIM STATUS TO INSURER*/
        ClaimStatusWebhook wbRequest = new ClaimStatusWebhook(master.getInsurerClaimId(),master.getId(),master.getUrn(), master.getStatus());
        wbRequest.setOrgId(master.getInsurerOrgId());
        wbRequest.setIsInsurer(true);
        wbRequest.setCommonUserId(master.getCreatedBy());
        wbRequest.setApplicationId(master.getApplicationId());
        wbRequest.setClaimRefId(master.getId());
        wbRequest.setRemarks(master.getRemarks());
        wbRequest.setMessage("Uploaded documents submitted successfully.");
        webHookClient.updateDocToInsurerForQuery(wbRequest);
		
		/**AFTER UPDATE STATUS SEND SMS*/
		if(master.getStatus() == ClaimStatus.CLAIM_ACCEPTED.getId()
				|| master.getStatus() == ClaimStatus.CLAIM_REJECTED.getId()
				|| master.getStatus() == ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()) {			
			sendSms(master);
		}

		/** update claim status call python api */
//		deDupeRegistryUtilityV3.callUpdateClaimStatusRequest(master);
		

		return new CommonResponse("Successfully updated!!", HttpStatus.OK.value(), true);
	}
	
	public PushClaimStatustoBankReq prepareRequestBankStatusUpdate(ClmMaster master,ClaimStatusRequest claimStatusRequest) {
		PushClaimStatustoBankReq bankReq=new PushClaimStatustoBankReq();				
		bankReq.setClaimId(master.getInsurerClaimId());
		bankReq.setClaimReferenceId(master.getId());
		bankReq.setClaimStatus(master.getStatus());	
		bankReq.setInsurerStatus(master.getInsurerStatus());
		bankReq.setReason(master.getStatusReasonId());
		bankReq.setUrn(master.getUrn());
		bankReq.setCommonUserId(master.getCreatedBy());
		bankReq.setOrgId(master.getOrgId());
		bankReq.setApplicationId(master.getApplicationId());
		UpdateTransactionRequest transactionRequest=new UpdateTransactionRequest();
		transactionRequest.setTransactionAmount(claimStatusRequest.getAmountOfTransaction());
		transactionRequest.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getDateOfTransaction()) ? claimStatusRequest.getDateOfTransaction().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null);
		transactionRequest.setTransactionUTR(claimStatusRequest.getTransactionUTR());
		bankReq.setTransactionDetails(transactionRequest);
		bankReq = WebHookClient.pushClmStausBnkManageRequest(bankReq);
		return bankReq;
	}
	
	public void sendSms(ClmMaster master) {
		log.info("Inside claim notification send");

		Long smsTmpId = null;
		String schemeName = null;
		if (!OPLUtils.isObjectNullOrEmpty(master.getSchemeId())) {
			schemeName = SchemeMaster.getById(Long.valueOf(master.getSchemeId())).getShortName();
			if (schemeName.equals(SchemeMaster.PMSBY.getShortName())) {
				smsTmpId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMSBY;
			} else {
				smsTmpId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMJJBY;
			}
		}
		if (schemeName.equals(SchemeMaster.PMJJBY.getShortName())
				|| (schemeName.equals(SchemeMaster.PMSBY.getShortName())
						&& master.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId()))) {
			notificationUtil.sendNotification(
					setSmsParameters(OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(),
							applicationMasterOtherDetailsRepository.getSouceByApplicationId(master.getApplicationId()),
							ClaimStatus.fromId(master.getStatus()).getShortValue()),
					null,
					OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getClmMobile())
							? master.getClmNomineeDetails().getMobileNumber()
							: master.getClmDetails().getClmMobile(),
					null, smsTmpId, null);
		} else if (schemeName.equals(SchemeMaster.PMSBY.getShortName())
				&& master.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())) {
			notificationUtil
					.sendNotification(
							setSmsParameters(OPLUtils.isObjectNullOrEmpty(master.getUrn()) ? null : master.getUrn(),
									applicationMasterOtherDetailsRepository.getSouceByApplicationId(master.getApplicationId()),
									ClaimStatus.fromId(master.getStatus()).getShortValue()),
							null, OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getApMobileNumber()) ? null
									: master.getClmDetails().getApMobileNumber(),
							null, smsTmpId, null);
		}
	}

	@Override
	public void pushRemainingClaim() {
		List<PushReTryAudit> claimList = pushReTryAuditRepo
				.findByIsPushedFalseAndReTryCountLessThanEqual(CommonUtils.INT_3);
		claimList.forEach(x -> {
			try {
				if (x.getType() == CommonUtils.PUSH_RE_TRY_CLAIM && !OPLUtils.isObjectNullOrEmpty(x.getClaimId())) {
					publishedClaimedData(x.getClaimId());
				}
			} catch (InsuranceException e) {
				throw new RuntimeException(e);
			}
		});
	}

	public String getValueById(DropDownMasterKey key, Integer id) throws OneFormException {
		return oneFormClient.getNameByKeyAndObjId(key, id).getValue();
	}

	@Override
	public void updateClaimStatusAndStageHistory(Long claimId) {
		/*
		 * ClaimMasterV3 master = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
		 * ClaimMasterHistory claimMasterHistory = new
		 * ClaimMasterHistory(master.getId(),master.getApplicationMaster().getId(),
		 * master.getClaimStageId(),master.getClaimStatus());
		 * claimMasterHistory.setCreatedDate(new Date());
		 * claimMasterHistory.setId(sequenceService.generateSequence(ClaimMasterHistory.
		 * SEQUENCE_NAME)); historyRepo.save(claimMasterHistory);
		 */
	}

	@Override
	public String fetchViewClaimDetailsByClaimId(String request, Long userId) {
		return null;
	}

	@Override
	public CommonResponse getAllClaimDetail(Long applicationId, Long claimId) throws ParseException {
		try {
			ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);

			ClaimDashboardViewV2 claimDashboardViewV2 = new ClaimDashboardViewV2();
			if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				boolean checkPhase2 = PhaseMode.checkPhase2(claimMaster.getOrgId());
				ClmDetails clmDetails = claimMaster.getClmDetails();
				ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();
				claimDashboardViewV2.setFullName(claimMaster.getClmDetails().getClmPIDetails().getAcHolderName());
				claimDashboardViewV2.setUrnNo(claimMaster.getUrn());
				if (claimMaster.getSchemeId().intValue() == SchemeMaster.PMSBY.getId()) {
					String typeOfDisability = null;
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
						typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,
								claimMaster.getClmDetails().getTypeOfDisabilityId());
					}
					String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
							&& claimMaster.getClmDetails().getNatureOfLossId() == 2 ? typeOfDisability : "-";
					claimDashboardViewV2.setTypeOfLoss(
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
									&& claimMaster.getClmDetails().getNatureOfLossId() == 1 ? "Accidental Death"
											: typeOfLoss);
				} else if (claimMaster.getSchemeId().intValue() == SchemeMaster.PMJJBY.getId()) {
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
						String typeOfLoss = claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == 1
								? "Accidental Death"
								: claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == 4 ? "Suicide" : "-";
						claimDashboardViewV2.setTypeOfLoss(
								claimMaster.getClmDetails().getCauseOfDeathDisabilityId() == 2 ? "Death" : typeOfLoss);
					}
				}
				claimDashboardViewV2.setReceiveddate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
						? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate())
						: null);
				claimDashboardViewV2.setLastActionDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
						? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
						: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
				claimDashboardViewV2.setSchemeName(
						SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
				claimDashboardViewV2.setSchemeId(claimMaster.getSchemeId());
				claimDashboardViewV2.setClaimStatus(claimMaster.getStatus());
				claimDashboardViewV2.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate())
						? CommonUtils.sdf_yyyy_MM_dd_T_HH_mm_ss_SS.format(claimMaster.getClaimDate())
						: null);
				claimDashboardViewV2.setIsClaimantSame(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getIsClaimantSame())
						&& claimMaster.getClmDetails().getIsClaimantSame() == Boolean.TRUE ? "Yes" : "No");
				int ageByDob = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmNomineeDetails())
						? CommonUtils.getAgeBydob(claimMaster.getClmNomineeDetails().getClmNomineePIDetails().getDob())
						: CommonUtils.INT_0;
				claimDashboardViewV2.setNomineeAge(ageByDob);
				claimDashboardViewV2.setRejectCnt(
						!OPLUtils.isObjectNullOrEmpty(claimMaster.getRejectReopenCnt()) ? claimMaster.getRejectReopenCnt() : null);
					LinkedHashMap<String, Object> insuredDetails = new LinkedHashMap<>();
					insuredDetails.put("Name", clmPIDetails.getAcHolderName());
					insuredDetails.put("First Name", clmPIDetails.getApFirstName());
					insuredDetails.put("Middle Name", clmPIDetails.getApMiddleName());
					insuredDetails.put("Last Name", clmPIDetails.getApLastName());
					insuredDetails.put("Father/Husband Name",
							clmPIDetails.getApFatherHusbandName());
					insuredDetails.put("Gender", Gender.fromId(clmDetails.getApGenderId()).getId());
					insuredDetails.put("Date of Birth",
							!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApDob())
									? CommonUtils.sdf_dd_MM_yyyy.format(clmPIDetails.getApDob())
									: null);
					insuredDetails.put("Mobile Number", clmDetails.getApMobileNumber());
					insuredDetails.put("Email ID", clmDetails.getApEmail());
					insuredDetails.put("Bank A/C Number", clmPIDetails.getApAccountNumber());
					insuredDetails.put("CIF", clmPIDetails.getApCif());
					insuredDetails.put("KYCID1", clmPIDetails.getApKycId1());
					insuredDetails.put("KYC1 Number", clmPIDetails.getApKycIdNumber1());
//					insuredDetails.put("KYCI21", clmPIDetails.getApKycId2());
//					insuredDetails.put(" KYC2 Number", applicationMaster.getApplicantInfo().getKycIdNumber2());
					insuredDetails.put("CKYC", !OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApCkycNumber()) ? "Yes" : "No");
					insuredDetails.put("CKYC Number", clmPIDetails.getApCkycNumber());
					insuredDetails.put("Pan", clmPIDetails.getApPan());
					insuredDetails.put("Adhar", clmPIDetails.getApAadhaar());

					insuredDetails.put(" Date of Enrollment",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getFirstEnrollmentDate())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getFirstEnrollmentDate())
									: null);
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId())) {
						String organizationName = usersClient.getOrganizationName(claimMaster.getOrgId());
						if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
							insuredDetails.put("Name of Bank", organizationName);
						}
					}
					if (!OPLUtils
							.isObjectNullOrEmpty(claimMaster.getInsurerOrgId())) {
						String organizationName = usersClient
								.getOrganizationName(claimMaster.getInsurerOrgId());
						if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
							insuredDetails.put("Name of Insurer", organizationName);
						}
					}
					claimDashboardViewV2.setInsuredDetails(insuredDetails);

				if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getApAddressMaster())) {
					LinkedHashMap<String, Object> insuredAddress = new LinkedHashMap<>();
					insuredAddress.put("Address Line 1",
							clmPIDetails.getApAddressLine1());
					insuredAddress.put("Address Line 2",
							clmPIDetails.getApAddressLine2());
					insuredAddress.put("City", clmDetails.getApAddressMaster().getCityName());
					insuredAddress.put("cityLGDCode",
							clmDetails.getApAddressMaster().getCityLGDCode());
					insuredAddress.put("District", clmDetails.getApAddressMaster().getDistrict());
					insuredAddress.put("DistrictLGDCode",
							clmDetails.getApAddressMaster().getDistrictLGDCode());
					insuredAddress.put("State", clmDetails.getApAddressMaster().getStateName());
					insuredAddress.put("stateLGDCode",
							clmDetails.getApAddressMaster().getStateLGDCode());
					insuredAddress.put("PinCode", clmDetails.getApAddressMaster().getPincode());
					claimDashboardViewV2.setInsuredAddress(insuredAddress);

				}
					ClmNomineeDetails clmNomineeDetails = claimMaster.getClmNomineeDetails();
					ClmNomineePIDetails clmNomineePIDetails = clmNomineeDetails.getClmNomineePIDetails();
					LinkedHashMap<String, Object> nomineeDetails = new LinkedHashMap<>();
					nomineeDetails.put("First Name", clmNomineePIDetails.getName());
//					nomineeDetails.put("Middle Name", clmNomineePIDetails.getMiddleName());
//					nomineeDetails.put("Last Name ", clmNomineePIDetails.getLastName());
					nomineeDetails.put("Date of Birth",
							!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob())
									? CommonUtils.sdf_dd_MM_yyyy.format(clmNomineePIDetails.getDob())
									: null);
					nomineeDetails.put("Age",
							!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob()) && ageByDob == 0 || ageByDob == 1
									? ageByDob + " Year"
									: ageByDob + " Years");
					nomineeDetails.put("Mobile Number", clmNomineeDetails.getMobileNumber());
					nomineeDetails.put("Email ID", clmNomineeDetails.getEmail());
					if (PhaseMode.checkPhase2(claimMaster.getOrgId())) {
						nomineeDetails.put("Correct Nominee FirstName ",clmNomineePIDetails.getCorrectNomineeName());
					}else {
						nomineeDetails.put("Correct Nominee FirstName ",clmNomineePIDetails.getCorrectNomineeFirstName());
						nomineeDetails.put("Correct Nominee MiddleName ", clmNomineePIDetails.getCorrectNomineeMiddleName());
						nomineeDetails.put("Correct Nominee LastName ", clmNomineePIDetails.getCorrectNomineeLastName());						
					}
					nomineeDetails.put("Relationship with Deceased",
							null != clmNomineeDetails.getRelationId() ? RelationShip.fromId(clmNomineeDetails.getRelationId()).getValue()
									: null);
					claimDashboardViewV2.setNomineeDetails(nomineeDetails);

					LinkedHashMap<String, Object> nomineeAddress = new LinkedHashMap<>();
					nomineeAddress.put("Address Line 1", clmNomineePIDetails.getAddressLine1());
					nomineeAddress.put("Address Line 2", clmNomineePIDetails.getAddressLine2());
//					nomineeAddress.put("City", clmNomineeDetails.getAddress().getCityName());
//					nomineeAddress.put("cityLGDCode", nomineeMaster.getAddress().getCityLGDCode());
//					nomineeAddress.put("District", nomineeMaster.getAddress().getDistrict());
//					nomineeAddress.put("DistrictLGDCode", nomineeMaster.getAddress().getDistrictLGDCode());
//					nomineeAddress.put("State", nomineeMaster.getAddress().getStateName());
//					nomineeAddress.put("stateLGDCode", nomineeMaster.getAddress().getStateLGDCode());
//					nomineeAddress.put("PinCode", nomineeMaster.getAddress().getPincode());
					claimDashboardViewV2.setNomineeAddress(nomineeAddress);

					if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdRelationId())) {
						LinkedHashMap<String, Object> guardianDetails = new LinkedHashMap<>();
						guardianDetails.put("Name", clmNomineePIDetails.getName());
						if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdRelationId())) {
							String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,
									clmNomineeDetails.getGdRelationId());
							guardianDetails.put("Relationship with Guardian", relationShip);
						}
						guardianDetails.put("Mobile Number of Guardian ", clmNomineeDetails.getGdMobile());
						guardianDetails.put("E-Mail ID of Guardian ", clmNomineeDetails.getGdEmail());
						claimDashboardViewV2.setGuardianDetails(guardianDetails);
					}

				if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getClmRelationId())) {
					LinkedHashMap<String, Object> claimantDetails = new LinkedHashMap<>();
					claimantDetails.put("First Name", clmPIDetails.getClmFirstName());
//					claimantDetails.put("Middle Name", claimantMaster.getMiddleName());
//					claimantDetails.put("Last Name", claimantMaster.getLastName());
					claimantDetails.put("Date of Birth",
							!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getClmDob())
									? CommonUtils.sdf_dd_MM_yyyy.format(clmPIDetails.getClmDob())
									: null);
					int ageByDobClaimant = CommonUtils.getAgeBydob(clmPIDetails.getClmDob());
					claimantDetails.put("Age",
							!OPLUtils.isObjectNullOrEmpty(ageByDobClaimant) && ageByDobClaimant == CommonUtils.INT_0
									|| ageByDobClaimant == CommonUtils.INT_1 ? ageByDobClaimant + " Year"
											: ageByDobClaimant + " Years");
					claimantDetails.put("Mobile Number", clmDetails.getClmMobile());
					claimantDetails.put("Email ID", clmDetails.getClmEmail());
					claimantDetails.put("Relationship with Claimant",
							null != clmDetails.getClmRelationId() ? RelationShip.fromId(clmDetails.getClmRelationId()).getValue()
									: null);
					claimantDetails.put("Relationship with Nominee",
							null != clmNomineeDetails.getRelationId() ? RelationShip.fromId(clmNomineeDetails.getRelationId()).getValue()
									: null);

						claimantDetails.put("Claimant KYCID1",clmPIDetails.getClmKycId1());
						claimantDetails.put("Claimant KYCNumber1",clmPIDetails.getClmKycIdNumber1());
						claimantDetails.put("Claimant KYCID2",clmPIDetails.getClmKycId2());
						claimantDetails.put("Claimant KYCNumbe2",clmPIDetails.getClmKycIdNumber2());
						claimDashboardViewV2.setClaimantDetails(claimantDetails);
					}

//					claimDashboardViewV2
//							.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//					claimDashboardViewV2
//							.setIsUpdateManually(applicationMaster.getLastTransactionDetails().getIsUpdateManually());
					if (!OPLUtils
							.isObjectNullOrEmpty(clmDetails.getApTransactionTimestamp())) {
						claimDashboardViewV2.setPremDebitDate(CommonUtils.sdf
								.format(clmDetails.getApTransactionTimestamp()));
						claimDashboardViewV2.setPremRemitDate(CommonUtils.sdf
								.format(clmDetails.getApTransactionTimestamp()));
					}

				if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
					LinkedHashMap<String, Object> claimDetails = new LinkedHashMap<>();
					claimDetails
							.put("Date of Accident",
									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
											? CommonUtils.sdf_dd_MM_yyyy.format(
													claimMaster.getClmDetails().getDateTimeOfAccident())
											: null);
					claimDetails.put("Day of Accident", claimMaster.getClmDetails().getDayOfAccident());

					claimDetails.put("Time of Accident",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident())
									? CommonUtils.HH_mm_ss.format(claimMaster.getClmDetails().getDateTimeOfAccident())
									: null);
					claimDetails.put("Location of Loss", claimMaster.getClmDetails().getPlaceOfOccurrence());

					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())) {
						String natureOfLoss = getValueById(DropDownMasterKey.NATURE_OF_LOSS,
								claimMaster.getClmDetails().getNatureOfLossId());
						claimDetails.put("Nature of Loss", natureOfLoss);
					}
					claimDetails.put("Date of Death",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClmDetails().getDateOfDeath())
									: null);
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
							&& Objects.equals(Long.valueOf(claimMaster.getSchemeId()),
									SchemeMaster.PMSBY.getId())) {
						if(checkPhase2) {
							claimDetails.put("Cause of Death/Disability", CauseOfDeathDisabilityV2
									.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
						}else {
							claimDetails.put("Cause of Death/Disability", CauseOfDeathDisability
									.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
						}
					}
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
							&& Objects.equals(Long.valueOf(claimMaster.getSchemeId()),
									SchemeMaster.PMJJBY.getId())) {
						if(checkPhase2) {
							claimDetails.put("Cause of Death", CauseOfDeathDisabilityV2
									.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
						}else {
							claimDetails.put("Cause of Death", CauseOfDeathDisability
									.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()).getValue());
						}
					}
					if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
						String typeOfDiability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,
								claimMaster.getClmDetails().getTypeOfDisabilityId());
						claimDetails.put("Type of Disability", typeOfDiability);

					}
					claimDashboardViewV2.setClaimDetails(claimDetails);

					LinkedHashMap<String, Object> claimantBankDetails = new LinkedHashMap<>();
					claimantBankDetails.put("Bank Name", clmPIDetails.getClmBankName());
					claimantBankDetails.put("IFSC", clmPIDetails.getClmBranchIfsc());
					claimantBankDetails.put("Bank A/C number",clmPIDetails.getClmAccountNumber());
					claimantBankDetails.put("Amount Claimed",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
									&& claimMaster.getClmDetails().getNatureOfLossId() == 2
									&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
											: "2,00,000");
					claimDashboardViewV2.setClaimantBankDetails(claimantBankDetails);

					LinkedHashMap<String, Object> paymentDetails = new LinkedHashMap<>();
					paymentDetails.put("Date of Payment",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
									: null);
					paymentDetails.put("UTR Number", claimMaster.getTransactionUTR());
					paymentDetails.put("Amount Approved",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionTimeStamp())
									? OPLUtils.generateCurrency(claimMaster.getTransactionTimeStamp().toString())
									: null);
					paymentDetails.put("Amount Claimed",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())
									&& claimMaster.getClmDetails().getNatureOfLossId() == 2
									&& claimMaster.getClmDetails().getTypeOfDisabilityId() == 1 ? "1,00,000"
											: "2,00,000");
					paymentDetails.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
					paymentDetails.put("Insurer Status", claimMaster.getInsurerStatus());
					claimDashboardViewV2.setPaymentDetails(paymentDetails);

					LinkedHashMap<String, Object> rejectionDetails = new LinkedHashMap<>();
					rejectionDetails.put("Reason For Rejection",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId()) ? (claimMaster.getSchemeId().intValue()==SchemeMaster.PMSBY.getId() ? PMSBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue() : PMJJBYRejectedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue())
									: null);
					rejectionDetails.put("Rejection Date",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
									: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
					claimDashboardViewV2.setRejectionDetails(rejectionDetails);

					LinkedHashMap<String, Object> sentBackToBank = new LinkedHashMap<>();
					sentBackToBank.put("Reason for referring back by Insurer", !OPLUtils.isObjectNullOrEmpty(claimMaster.getStatusReasonId()) ? QueriedClaimEnum.fromId(claimMaster.getStatusReasonId()).getValue() : null);
					sentBackToBank.put("Insurer status", claimMaster.getInsurerStatus());
					sentBackToBank.put("Query Date",
							!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate())
									? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate())
									: CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
					sentBackToBank.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
					sentBackToBank.put("Insurer Status", claimMaster.getInsurerStatus());
					claimDashboardViewV2.setSentBackToBank(sentBackToBank);
				}
			}
				return new CommonResponse("Successfully get data !!", claimDashboardViewV2, HttpStatus.OK.value(),
						true);
		} catch (Exception e) {
			log.error("Exception is getting while claim details", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	@Override
	public CommonResponse webHookClaimDocUpload(Long claimId, List<Long> docs) {
			/** re-push the docs only */
			CommonResponse rePushDocs = rePushDocs(claimId);

			if (!OPLUtils.isObjectNullOrEmpty(rePushDocs) && rePushDocs.getStatus() == HttpStatus.OK.value()) {
				return rePushDocs;
			}
			return null;
	}

	public CommonResponse rePushDocs(Long claimId) {
		/** re-push the docs only */
		CommonResponse updateClaimMaster = updateClaimMaster(claimId, PUSH_CLAIM_REVISED_DOCS);
		if (OPLUtils.isObjectNullOrEmpty(updateClaimMaster)) {
			return null;
		}
		return updateClaimMaster;
	}

	public CommonResponse updateClaimMaster(Long claimId, String urlPart) {
		String configUrl = properties.getValueByCode(urlPart);
		if (null != configUrl) {
			String url = configUrl + "/" + claimId;
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
				headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
				headers.set("isDecrypt", "true");
				headers.add("Accept", "application/json");
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<?> entity = new HttpEntity<>(headers);
				RestTemplate restTemplate = new RestTemplate();
				log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
				CommonResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class)
						.getBody();
				if (!OPLUtils.isObjectNullOrEmpty(response) && response.getStatus() == 200) {
					return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
				}
			} catch (Exception e) {
				log.error("Exception While calling claim push details api :: ", e);
			}
		}
		return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	/* Expire incomplete claim after 30days */
	public void expireClaimAfter30Days() {
		ExpSchedulerAudit audit = new ExpSchedulerAudit();
		audit.setApi(ExpSchedulerApiEnum.EXPIRE_CLAIM_AFTER_30_DAYS.getId());
		audit.setStartDate(new Date());
		audit.setStatus("Pending");
		audit = expSchedulerAuditRepo.save(audit);
		try {
			log.info("ENTER INTO updateClaimExpireStageId() AT {}", new Date());

			List<Integer> claimStageId = new ArrayList<>();
			claimStageId.add(ClaimStageMaster.CLAIM_COMPLETED.getStageId());
			claimStageId.add(ClaimStageMaster.CLAIM_EXPIRED.getStageId());

			LocalDate now = LocalDate.now();
			LocalDate thirty = now.minusDays(30);
			Date d = Date.from(thirty.atStartOfDay(ZoneId.systemDefault()).toInstant());

			clmMasterRepository.updateClaimStageIdForExpiration(claimStageId, new Date(), d);

			audit.setCompleteDate(new Date());
			audit.setStatus("Completed");
			expSchedulerAuditRepo.save(audit);
		} catch (Exception e) {
			log.error("Error while updateClaimExpireStageId", e);
		}
	}

	@Override
	public CommonResponse saveClaimDeDupeDetails(ClaimDeDupeDetailsProxy claimDeDupeDetailsProxy, Long userId) {
		try {
			ClmMaster findById = clmMasterRepository.findByIdAndStageIdAndIsActiveTrue(
					claimDeDupeDetailsProxy.getClaimId(), ClaimStageMaster.CLAIM_COMPLETED.getStageId());
			if (OPLUtils.isObjectNullOrEmpty(findById)) {
				log.warn("data not Found From Claim Master");
				return new CommonResponse("claim not found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
			}

			Integer updateCount = clmDeDupeDetailsRepository
					.isActiveFalseByClaimId(claimDeDupeDetailsProxy.getClaimId(), userId);
			if (updateCount > 0) {
				log.info("total Update Count ----> {}", updateCount);
			}

			com.opl.jns.ere.domain.ClmDeDupeDetails claimDeDupeDetails = new com.opl.jns.ere.domain.ClmDeDupeDetails();
			BeanUtils.copyProperties(claimDeDupeDetailsProxy, claimDeDupeDetails);
			claimDeDupeDetails.setClaimMaster(findById);
			claimDeDupeDetails.setIsActive(Boolean.TRUE);
			claimDeDupeDetails.setCreatedBy(userId);
			claimDeDupeDetails.setCreatedDate(new Date());
			com.opl.jns.ere.domain.ClmDeDupeDetails deDupeDetails = clmDeDupeDetailsRepository.save(claimDeDupeDetails);

			if (!OPLUtils.isObjectNullOrEmpty(deDupeDetails)) {
				// python claim dedupe check
				List<DedupeDataResponse> claimDedupApiResponse = ereCommonService.checkClaimDedupeData(findById.getId(),findById.getSchemeId().longValue(),claimDeDupeDetails.getDeathDisabilityCertificateReportNo(),claimDeDupeDetails.getFIRNo(),claimDeDupeDetails.getPanchnamaNo(),claimDeDupeDetails.getPostMortemReportNo(),claimDeDupeDetails.getDeathDisabilityCertificateReportDate(),claimDeDupeDetails.getFIRDate(),claimDeDupeDetails.getPanchnamaDate(),claimDeDupeDetails.getPostMortemReportDate());
				if (!OPLUtils.isListNullOrEmpty(claimDedupApiResponse)) {
					List<ClaimDeDupeDetails> claimDDDetailsLst = new ArrayList<>();
					claimDedupApiResponse.forEach(x -> {
						ClaimDeDupeDetails claimDDDetails = new ClaimDeDupeDetails();
						claimDDDetails.setDateOfLoss(x.getDateOfLoss());
						claimDDDetails.setIntimationDate(
								CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(x.getClaimInimationDate()));
						claimDDDetails.setType(Long.valueOf(NatureOfLoss.fromBankValue(x.getType()).getId()));
						claimDDDetails.setUrn(x.getUrn());
						claimDDDetails.setClaimStatus(Long.valueOf(x.getStatus()));
						claimDDDetails.setBeneficiaryBank(x.getBeneficiaryBank());
						claimDDDetailsLst.add(claimDDDetails);
					});
					return new CommonResponse("successfully save data", claimDDDetailsLst, HttpStatus.OK.value(),
							Boolean.TRUE);
				}

				}
				return new CommonResponse("successfully save data", deDupeDetails.getId(), HttpStatus.OK.value(),
						Boolean.TRUE);
//			}
		} catch (Exception e) {
			log.error("error is getting while save Claim Dedupe Details", e);
		}
		return new CommonResponse("error is getting while save Claim Dedupe Details",
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
	}

	@Override
	public CommonResponse getClaimDeDupeDetails(Long cliamId) {
		try {
			com.opl.jns.ere.domain.ClmDeDupeDetails deDupeDetails = clmDeDupeDetailsRepository
					.findByClaimMasterIdAndIsActiveTrue(cliamId);
			if (OPLUtils.isObjectNullOrEmpty(deDupeDetails)) {
				log.warn("data not Found From Claim Master");
				return new CommonResponse("data not Found From Claim Master", HttpStatus.NO_CONTENT.value(),
						Boolean.FALSE);
			}

			ClaimDeDupeDetailsProxy claimDeDupeDetailsProxy = new ClaimDeDupeDetailsProxy();
			BeanUtils.copyProperties(deDupeDetails, claimDeDupeDetailsProxy);
			claimDeDupeDetailsProxy.setClaimId(deDupeDetails.getClaimMaster().getId());
			return new CommonResponse("successfully save data", claimDeDupeDetailsProxy, HttpStatus.OK.value(),
					Boolean.TRUE);
		} catch (Exception e) {
			return new CommonResponse("error is getting while save Claim Dedupe Details",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
		}
	}

	@Override
	public CommonResponse UpdateStageWithRemarks(Long claimId, String remarks, Long userId) {
		try {
			return updateStage(claimId, userId, remarks);
		} catch (Exception e) {
			return new CommonResponse("error is getting while update stage and set remark",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
		}
	}

//	public CommonResponse claimDataMigrationNewDb() {
//		List<ClaimMasterV3> claimMasterV3 = null;
//		try {
//			claimMasterV3 = claimMasterRepo.findAll();
//			log.info("claim ids [{}]", claimMasterV3.stream().map(x -> x.getId()).collect(Collectors.toList()));
//			for (ClaimMasterV3 claim : claimMasterV3) {
//				try {
//
//					ClmMaster clmMaster = new ClmMaster();
//					ApplicationMasterV3 applicationMaster = claim.getApplicationMaster();
//					clmMaster.setUrn(applicationMaster.getUrn());
//					clmMaster.setApplicationId(applicationMaster.getId());
//					clmMaster.setOrgId(claim.getOrgId());
//					clmMaster.setSchemeId(claim.getSchemeId());
//					clmMaster.setBranchId(claim.getClaimBranchId());
//					clmMaster.setStatus(claim.getClaimStatus());
//					clmMaster.setStageId(claim.getClaimStageId());
//					clmMaster.setClaimDate(claim.getClaimDate());
//					clmMaster.setRejectReopenCnt(claim.getRejectCnt());
//					clmMaster.setIsPushed(claim.getIsPushed());
//					clmMaster.setTransactionAmount(claim.getAmountOfTransaction());
//					clmMaster.setClaimAmount(claim.getClaimAmount());
////					clmMaster.setInsurerClaimId(claim.getInsurerClaimId());
////					clmMaster.setStatusReasonId(claim.getInsurerReason());
//					clmMaster.setInsurerStatus(claim.getInsurerStatus());
////					clmMaster.setMessage(claim.getMessage());
//					clmMaster.setStatusReasonId(claim.getStatusReasonId());
//					clmMaster.setStatusReasonId(claim.getStatusReasonId());
//					clmMaster.setTransactionUTR(claim.getTransactionUtr());
//					clmMaster.setCreatedBy(claim.getCreatedBy());
//					clmMaster.setCreatedDate(claim.getCreatedDate());
//					clmMaster.setModifiedBy(claim.getModifiedBy());
//					clmMaster.setModifiedDate(claim.getModifiedDate());
//					clmMaster.setIsActive(claim.getIsActive());
//					clmMaster.setTransactionTimeStamp(claim.getDateOfTransaction());
//					clmMaster.setQueriedStorageId(claim.getQueriedStorageId());
//					clmMaster.setBranchStateId(claim.getClaimDetail().getBranchStateId());
//					clmMaster.setBranchCityId(claim.getClaimDetail().getBranchCityId());
//					clmMaster.setBranchLhoId(claim.getClaimDetail().getBranchLhoId());
//					clmMaster.setBranchRoId(claim.getClaimDetail().getBranchRoId());
//					clmMaster.setBranchZoId(claim.getClaimDetail().getBranchZoId());
//
//					Date date = null;
//					if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getCompletionDate())) {
//						date = applicationMaster.getCompletionDate();
//					} else {
//						date = applicationMaster.getStatusChangeDate();
//					}
//					clmMaster.setPolicyYear(CommonUtils.fetchPolicyYear(date));
//					clmMaster.setFinancialYear(CommonUtils.fetchFinancialYear(date));
//					clmMaster.setPolicyMonth(CommonUtils.fetchMonth(date));
//					clmMaster.setFinancialMonth(CommonUtils.fetchMonth(date));
//					clmMaster.setFinancialDay(CommonUtils.fetchDay(date));
//					clmMaster.setPolicyDay(CommonUtils.fetchDay(date));
//
//					/**
//					 * POLICY_YEAR FINANCIAL_YEAR POLICY_MONTH FINACIAL_MONTH POLICY_DAY
//					 * FINANCIAL_DAY
//					 */
//					clmMaster.setInsurerOrgId(claim.getApplicationMaster().getInsurerOrgId());
//
//					ApplicantInfo applicantInfo = claim.getApplicationMaster().getApplicantInfo();
//					ClmDetails clmDetails = new ClmDetails();
//					ClmAddressMaster addressMaster = new ClmAddressMaster();
//					AddressMasterV3 address = applicantInfo.getAddress();
//					addressMaster.setCityId(address.getCityId());
//					addressMaster.setCityLGDCode(address.getCityLGDCode());
//					addressMaster.setCityName(address.getCityName());
//					addressMaster.setDistrict(address.getDistrict());
//					addressMaster.setDistrictLGDCode(address.getDistrictLGDCode());
//					addressMaster.setPincode(address.getPincode());
//					addressMaster.setStateId(address.getStateId());
//					addressMaster.setStateLGDCode(address.getStateLGDCode());
//					addressMaster.setStateName(address.getStateName());
//					clmDetails.setApAddressMaster(addressMaster);
//					clmDetails.setId(clmMaster.getId());
//					clmDetails.setApEmail(applicantInfo.getEmail());
//					clmDetails.setApMobileNumber(applicantInfo.getMobileNumber());
//					clmDetails.setApFatherHusbandName(applicantInfo.getFatherHusbandName());
//					clmDetails.setApDisabilityDetails(applicantInfo.getDisabilityDetails());
//					clmDetails.setApDisabilityStatus(applicantInfo.getDisabilityStatus());
//					clmDetails.setApCustomerIfsc(applicantInfo.getIfsc());
//
//					Optional<NomineeDetails> claimantOptional = claim.getApplicationMaster().getNomineeDetails()
//							.stream().filter(a -> Boolean.TRUE.equals(a.getIsActive())
//									&& NomineeType.CLAIMANT.getId().equals(a.getType()))
//							.findFirst();
//					if (claimantOptional.isPresent()) {
//						NomineeDetails claimantDetails = claimantOptional.get();
//						clmDetails.setClmRelationId(claimantDetails.getRelationId());
//						clmDetails.setClmEmail(claimantDetails.getEmail());
//						clmDetails.setClmMobile(claimantDetails.getMobileNumber());
//					}
//
//					ClaimDetailV3 claimDetail = claim.getClaimDetail();
//					clmDetails.setDateOfDeath(claimDetail.getDateOfDeath());
//					clmDetails.setDateTimeOfAccident(claimDetail.getDateTimeOfAccident());
//					clmDetails.setDayOfAccident(claimDetail.getDayOfAccident());
//					clmDetails.setPlaceOfOccurrence(claimDetail.getLocationOfLoss());
//					clmDetails.setNatureOfLossId(claimDetail.getNatureOfLossId());
//					clmDetails.setTypeOfDisabilityId(claimDetail.getTypeOfDisablityId());
//					clmDetails.setCauseOfDeathDisabilityId(claimDetail.getCauseOfDeathDisabilityId());
//					clmDetails.setPremDebitDate(applicationMaster.getLastTransactionDetails().getTransTimeStamp());
//					clmDetails.setPremRemitDate(applicationMaster.getLastTransactionDetails().getTransTimeStamp());
//					clmDetails.setDateOfLodgingClaim(null);
//					Map<String, Object> map = userManagementClient.getBranchMappingIds(clmMaster.getBranchId(),
//							clmMaster.getSchemeId().longValue());
//					clmDetails.setBranchCode(OPLUtils.isObjectNullOrEmpty(map.get("branchCode")) ? null : map.get("branchCode").toString());
//					clmDetails.setBranchEmailId(!OPLUtils.isObjectNullOrEmpty(claim.getCreatedBy())
//							? UserEncryptAESUtility.decrypt(clmMasterRepository.getEmailByUserId(claim.getCreatedBy()))
//							: null);
//					clmDetails.setIsNomineeNameCorrection(claim.getClaimDetail().getIsNomineeSame());
//
//					ClmPIDetails clmPIDetails = new ClmPIDetails();
//					clmPIDetails.setId(clmDetails.getId());
//					clmPIDetails.setApAccountNumber(applicationMaster.getAccountNumber());
//					clmPIDetails.setApCif(applicationMaster.getCif());
//					clmPIDetails.setApFirstName(applicantInfo.getFirstName());
//					clmPIDetails.setApMiddleName(applicantInfo.getMiddleName());
//					clmPIDetails.setApLastName(applicantInfo.getLastName());
//					clmPIDetails.setAcHolderName(applicantInfo.getName());
//					clmPIDetails.setApKycId1(applicantInfo.getKycId1());
//					clmPIDetails.setApKycIdNumber1(applicantInfo.getKycIdNumber1());
//					clmPIDetails.setApPan(applicantInfo.getPan());
//					clmPIDetails.setApAadhaar(applicantInfo.getAadhaar());
//					clmPIDetails.setApCkycNumber(applicantInfo.getCkycNumber());
//					clmPIDetails.setApDob(applicantInfo.getDob());
//					clmPIDetails.setApGenderId(applicantInfo.getGenderId());
//					clmPIDetails.setApAddressLine1(applicantInfo.getAddress().getAddressLine1());
//					clmPIDetails.setApAddressLine2(applicantInfo.getAddress().getAddressLine2());
//
//					if (claimantOptional.isPresent()) {
//						NomineeDetails claimantDetails = claimantOptional.get();
//						clmPIDetails.setClmName(claimantDetails.getName());
//						clmPIDetails.setClmDob(claimantDetails.getDob());
//						clmPIDetails.setClmAddress(claimantDetails.getAddress().getAddressLine1());
//						clmPIDetails.setClmAccountNumber(claim.getClaimDetail().getClaimantBankAccountNumber());
//						clmPIDetails.setClmBankName(claim.getClaimDetail().getNameOfBank());
//						clmPIDetails.setClmBranchIfsc(claim.getClaimDetail().getCustIfscCode());
//						clmPIDetails.setClmGenderId(null);
//
//						// kyc details
//						Integer[] kycId = new Integer[2];
//						List<String> kycList = Arrays.asList(claim.getClaimDetail().getKycDocId().split(","));
//						KycDocument kycDocument1 = KycDocument.fromId(Integer.valueOf(kycList.get(0)));
//						kycId[0] = kycDocument1.getId();
//						String kycDocuments1 = getKycDoc(kycDocument1.getId(), claim.getClaimDetail());
//						clmPIDetails.setClmKycId1(kycId[0]);
//						clmPIDetails.setClmKycIdNumber1(kycDocuments1);
//
//						if (kycList.size() > 1) {
//							KycDocument kycDocument2 = KycDocument.fromId(Integer.valueOf(kycList.get(1)));
//							kycId[1] = kycDocument2.getId();
//							String kycDocuments2 = getKycDoc(kycDocument2.getId(), claim.getClaimDetail());
//							clmPIDetails.setClmKycId2(kycId[1]);
//							clmPIDetails.setClmKycIdNumber2(kycDocuments2);
//						} 
//					}
//					clmPIDetails.setClmDetails(clmDetails);
//					clmDetails.setClmPIDetails(clmPIDetails);
//
//					Optional<NomineeDetails> nomineeOptional = claim.getApplicationMaster().getNomineeDetails().stream()
//							.filter(a -> Boolean.TRUE.equals(a.getIsActive())
//									&& NomineeType.NOMINEE.getId().equals(a.getType()))
//							.findFirst();
//					if (nomineeOptional.isPresent()) {
//						NomineeDetails nomineeDetails = nomineeOptional.get();
//						ClmNomineeDetails clmNomineeDetails = new ClmNomineeDetails();
//						ClmAddressMaster nomineeAddress = new ClmAddressMaster();
//						AddressMasterV3 nmAddress = nomineeDetails.getAddress();
//						nomineeAddress.setCityId(nmAddress.getCityId());
//						nomineeAddress.setCityLGDCode(nmAddress.getCityLGDCode());
//						nomineeAddress.setCityName(nmAddress.getCityName());
//						nomineeAddress.setDistrict(nmAddress.getDistrict());
//						nomineeAddress.setDistrictLGDCode(nmAddress.getDistrictLGDCode());
//						nomineeAddress.setPincode(nmAddress.getPincode());
//						nomineeAddress.setStateId(nmAddress.getStateId());
//						nomineeAddress.setStateLGDCode(nmAddress.getStateLGDCode());
//						nomineeAddress.setStateName(nmAddress.getStateName());
//						clmNomineeDetails.setIsActive(true);
//						clmNomineeDetails.setClmAddressMaster(nomineeAddress);
//						clmNomineeDetails.setRelationId(nomineeDetails.getRelationId());
//						clmNomineeDetails.setMobileNumber(nomineeDetails.getMobileNumber());
//						clmNomineeDetails.setEmail(nomineeDetails.getEmail());
//
//						Optional<NomineeDetails> guardianOptional = claim.getApplicationMaster().getNomineeDetails()
//								.stream().filter(a -> Boolean.TRUE.equals(a.getIsActive())
//										&& NomineeType.GUARDIAN.getId().equals(a.getType()))
//								.findFirst();
//						if (guardianOptional.isPresent()) {
//							NomineeDetails guardianDetails = guardianOptional.get();
//							clmNomineeDetails.setGdRelationId(guardianDetails.getRelationId());
//							clmNomineeDetails.setGdMobile(guardianDetails.getMobileNumber());
//							clmNomineeDetails.setGdEmail(guardianDetails.getEmail());
//						}
//						clmNomineeDetails.setModifiedBy(null);
//						clmNomineeDetails.setModifiedDate(null);
//
//						ClmNomineePIDetails clmNomineePIDetails = new ClmNomineePIDetails();
//						clmNomineePIDetails.setId(clmNomineeDetails.getId());
//						clmNomineePIDetails.setFirstName(nomineeDetails.getFirstName());
//						clmNomineePIDetails.setMiddleName(nomineeDetails.getMiddleName());
//						clmNomineePIDetails.setLastName(nomineeDetails.getLastName());
//						clmNomineePIDetails.setName(nomineeDetails.getName());
//						clmNomineePIDetails.setDob(nomineeDetails.getDob());
//						clmNomineePIDetails.setAddressLine1(nomineeDetails.getAddress().getAddressLine1());
//						clmNomineePIDetails.setAddressLine2(nomineeDetails.getAddress().getAddressLine2());
//						if (guardianOptional.isPresent()) {
//							NomineeDetails guardianDetails = guardianOptional.get();
//							clmNomineePIDetails.setGdName(guardianDetails.getName());
//							clmNomineePIDetails.setGdAddress(guardianDetails.getAddress().getAddressLine1());
//						}
//						clmNomineeDetailsRepository.save(clmNomineeDetails);
//					}
//					clmDetails.setClmMaster(clmMaster);
//					clmMaster.setClmDetails(clmDetails);
//					clmMasterRepository.save(clmMaster);
//
//				} catch (Exception e) {
//					log.error("Exception is update data claim id {}", claim.getId());
//				}
//			}
//		} catch (Exception e) {
//			log.error("Exception is getting While claim data insert ", e);
//		}
//		return new CommonResponse("successfully inserted data",
//				!OPLUtils.isObjectNullOrEmpty(claimMasterV3) ? claimMasterV3.stream().map(x -> x.getId()) : null,
//				HttpStatus.OK.value(), Boolean.TRUE);
//	}

	private void updateNomineeAndGuardianDetails(ClaimMasterRequest req, ClmNomineeDetails nomineeDtls,
			ClmNomineePIDetails nomineePIDtls, boolean checkPhase2) {
		/**SET CORRECT NOMINEE NAME*/
		if (checkPhase2) {
			nomineePIDtls.setCorrectNomineeName(req.getNomineeData().getCorrectNomineeFirstName());
		} else {
			nomineePIDtls.setCorrectNomineeFirstName(req.getNomineeData().getCorrectNomineeFirstName());
			nomineePIDtls.setCorrectNomineeMiddleName(req.getNomineeData().getCorrectNomineeMiddleName());
			nomineePIDtls.setCorrectNomineeLastName(req.getNomineeData().getCorrectNomineeLastName());
		}
		/**SET NOMINEE DETAILS*/
		nomineePIDtls.setName(req.getNomineeData().getFirstName());
		nomineePIDtls.setDob(req.getNomineeData().getDateOfBirth());
		nomineeDtls.setMobileNumber(req.getNomineeData().getMobileNumber());
		nomineeDtls.setEmail(req.getNomineeData().getEmailIdOfNominee());
		nomineeDtls.setNomineeGenderId(req.getNomineeData().getNomineeGenderId());
		nomineeDtls.setRelationId(req.getNomineeData().getRelationOfNomineeApplicant());
		if (checkPhase2) {
			nomineePIDtls.setAddressLine1(req.getNomineeData().getAddressLine1());
		} else {
			nomineePIDtls.setAddressLine1(req.getNomineeData().getAddress().getAddressLine1());
		}
		
		/**SET GUARDIAN DETAILS*/
		nomineeDtls.setGdEmail(req.getNomineeData().getEmailIdOfGuardian());
		nomineeDtls.setGdMobile(req.getNomineeData().getMobileNumberOfGuardian());
		nomineePIDtls.setGdName(req.getNomineeData().getNameOfGuardian());
		nomineePIDtls.setGdAddress(req.getNomineeData().getAddressOfGuardian());
		nomineeDtls.setGdRelationId(req.getNomineeData().getRelationShipOfGuardian());
		
		nomineeDtls.setModifiedBy(req.getModifiedBy());
		nomineeDtls.setModifiedDate(new Date());
		nomineeDtls.setClmNomineePIDetails(nomineePIDtls);
		clmNomineeDetailsRepository.save(nomineeDtls);

	}

//	private String getKycDocuments(Integer kycId, ClaimDetailV3 claimDetailV3) {
//		String val = null;
//		if (Objects.equals(KycDocument.PAN.getId(), kycId)) {
//			val = claimDetailV3.getPan();
//		} else if (Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
//			val = claimDetailV3.getPassport();
//		} else if (Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
//			val = claimDetailV3.getDrivingLicense();
//		} else if (Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
//			val = claimDetailV3.getMgnerega();
//		} else if (Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
//			val = claimDetailV3.getVottingCardId();
//		}
//		return val;
//	}
//	
//	private static String getKycDoc(Integer kycId, ClaimDetailV3 req) {
//		String val = null;
//		if (Objects.equals(KycDocument.PAN.getId(), kycId)) {
//			val = req.getPan();
//		} else if (Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
//			val = req.getPassport();
//		} else if (Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
//			val = req.getDrivingLicense();
//		} else if (Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
//			val = req.getMgnerega();
//		} else if (Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
//			val = req.getVottingCardId();
//		}
//		return val;
//	}

}
