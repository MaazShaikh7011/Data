package com.opl.jns.insurance.service.utils.dedupe;

public enum DeDupeApiCallType {
	PREMIUM_DEDUCTION(1l, "Premium Deduction"), 
	UPDATE_SELECTED_ACCOUNT_HOLDER(2l, "update Selected Account Holder");

	private Long id;
	private String value;

	private DeDupeApiCallType(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static DeDupeApiCallType fromId(Long v) {
		for (DeDupeApiCallType c : DeDupeApiCallType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
}
