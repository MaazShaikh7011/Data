package com.opl.jns.insurance.service.service.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.InsurerMstDetailsProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.insurance.service.repository.ReportRepositoryV3;
import com.opl.jns.insurance.service.service.InsuranceMasterService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 6/15/2023
 */
@Slf4j
@Service
public class InsuranceMasterServiceImpl implements InsuranceMasterService {

	public static final String INSURER_START_DATE = "INSURER_START_DATE";
	public static final String INSURER_END_DATE = "INSURER_END_DATE";
	public static final String FINANCIAL_START_DATE = "FINANCIAL_START_DATE";
	public static final String FINANCIAL_END_DATE = "FINANCIAL_END_DATE";
	
	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private ConfigProperties properties;
	
	@Autowired
	private ReportRepositoryV3 reportRepositoryV3;

	// Get Insurance Mst Data
	@Override
	public InsurerMstDetailsRequest getInsurerMstDetailsById(Long id) throws InsuranceException {

		InsurerMstDetailsV3 mst = insurerMstDetailsRepository.findById(id).orElse(null);
		InsurerMstDetailsRequest insurerMstDetailsRequest = new InsurerMstDetailsRequest();
		if (mst != null) {
			BeanUtils.copyProperties(mst, insurerMstDetailsRequest);
		}

		return insurerMstDetailsRequest;
	}

	@Override
	public CommonResponse save(InsurerMstDetailsRequest req,AuthClientResponse authClientResponse) throws InsuranceException {

		log.info("<--- Enter in save Insurance Mst data --> ");
//	        int updaterow = insurerMstDetailsRepository.inActive(req.getSchemeId(), req.getOrgId(), req.getModifiedBy());

//	        log.info("<--- update save Mst data count [{}]---> ", updaterow);
		Long id = null;
		InsurerMstDetailsV3 insurerMstDetails = null;
		if (!OPLUtils.isObjectNullOrEmpty(req.getId())) {
			insurerMstDetails = insurerMstDetailsRepository.findById(req.getId()).orElse(null);
			if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails)) {
//				BeanUtils.copyProperties(req, insurerMstDetails, "id", "created_date", "modified_date", "is_active");
				BeanUtils.copyProperties(req, insurerMstDetails, "id", "createdDate", "modified_date", "is_active","createdBy");
				insurerMstDetails.setModifiedDate(new Date());
				insurerMstDetails.setModifiedBy(req.getModifiedBy());
			
			}
		} else {
			insurerMstDetails = new InsurerMstDetailsV3();
			BeanUtils.copyProperties(req, insurerMstDetails, "id", "created_date", "modified_date", "is_active");
			insurerMstDetails.setCreatedDate(new Date());
//			insurerMstDetails.setCreatedBy(req.getModifiedBy());
			insurerMstDetails.setCreatedBy(authClientResponse.getUserId());
			
		}
		insurerMstDetails.setYear(DateUtils.setDateFormat(DateFormat.YYYY, req.getPolicyStartDate()) + "-"
				+ DateUtils.setDateFormat(DateFormat.YY, req.getPolicyEndDate()));
		insurerMstDetails.setIsActive(true);	
		
		id = insurerMstDetailsRepository.save(insurerMstDetails).getId();

		log.info("<--- Exit from save Insurance Mst data ---> ");
		return new CommonResponse("Insurance data Created!!!", id, HttpStatus.OK.value(), true);
	}

	public CommonResponse getOrgMasterListByUserTypeId(Long userTypeId, Long schemeId) {
		return usersClient.getOrgMasterListByUserTypeId(userTypeId, schemeId);
	}
	
	public CommonResponse getOrganisationMstListByUserTypeId(Long userTypeId) {
		return usersClient.getOrganisationMstListByUserTypeId(userTypeId);
	}

//	@Override
//	public List<Map<String, Object>> fetchInsurerApplicationList(String request, Long userId) {
//		return spMasterRepository.spGetInsurerDetailList(request, userId);
//	}
	@Override
	public CommonResponse fetchInsurerApplicationList(String request, Long userId) {
        String spName = DBNameConstant.JNS_INSURANCE+".sp_get_insurer_details_list_v5";
        return new CommonResponse(reportRepositoryV3.getDataFromProducer(request, userId, spName), "SuccessFully get state wise report", HttpStatus.OK.value());
	}

	@Override
	public InsurerMstDetailsRequest getInsurerDetailsBySchemeIdAndOrgId(Long schemeId, Long orgId, Integer mode)
			throws InsuranceException, ParseException {

		InsurerMstDetailsV3 mst = insurerMstDetailsRepository
				.findFirstBySchemeIdAndOrgIdAndIsActiveTrueOrderByIdDesc(schemeId, orgId);
		InsurerMstDetailsRequest insurerMstDetailsRequest = new InsurerMstDetailsRequest();
		if (!OPLUtils.isObjectNullOrEmpty(mst)) {
			BeanUtils.copyProperties(mst, insurerMstDetailsRequest);
			if (mode == 1) {
				String policyStartYear = DateUtils.setDateFormat(DateFormat.YYYY,
						insurerMstDetailsRequest.getPolicyStartDate());
				String policyEndYear = DateUtils.setDateFormat(DateFormat.YYYY,
						insurerMstDetailsRequest.getPolicyEndDate());
				insurerMstDetailsRequest.setPolicyStartDate(
						CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(INSURER_START_DATE)
								+ (Integer.parseInt(policyStartYear) + CommonUtils.INT_1) + "T00:00:00.00"));
				insurerMstDetailsRequest.setPolicyEndDate(
						CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(INSURER_END_DATE)
								+ (Integer.parseInt(policyEndYear) + CommonUtils.INT_1) + "T23:59:59.999"));
			}
		} else {
			insurerMstDetailsRequest.setOrgId(orgId);
			insurerMstDetailsRequest.setSchemeId(schemeId);
			if (mode == 1) {
				int policyStartYear = CommonUtils.getCurrentPolicyYear();
				insurerMstDetailsRequest.setPolicyStartDate(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS
						.parse(properties.getValueByCode(INSURER_START_DATE) + policyStartYear + "T00:00:00.00"));
				insurerMstDetailsRequest.setPolicyEndDate(
						CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(INSURER_END_DATE)
								+ (policyStartYear + CommonUtils.INT_1) + "T23:59:59.999"));
			}
		}

		return insurerMstDetailsRequest;
	}

	@Override
	public CommonResponse getInsurerDataByStartAndEndDate(InsurerMstDetailsRequest insurerMstDetailsRequest)
			throws InsuranceException {

		if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetailsRequest.getMasterPolicyNo())) {
			List<InsurerMstDetailsV3> insurerMstDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndMasterPolicyNo(insurerMstDetailsRequest.getSchemeId(),
							insurerMstDetailsRequest.getOrgId(), insurerMstDetailsRequest.getMasterPolicyNo());
			Boolean policyAlreadyExist = false;
			for (InsurerMstDetailsV3 insDtl : insurerMstDetails) {
				if (OPLUtils.isObjectNullOrEmpty(insurerMstDetailsRequest.getId())
						|| !Objects.equals(insurerMstDetailsRequest.getId(), insDtl.getId())) {
					policyAlreadyExist = true;
				}
			}
			if (!OPLUtils.isListNullOrEmpty(insurerMstDetails) && policyAlreadyExist) {
				return new CommonResponse("SuccessFully get insured data!!!", CommonUtils.INT_1, HttpStatus.OK.value(),
						true);
			}
		}

		if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetailsRequest.getPolicyStartDate())
				&& !OPLUtils.isObjectNullOrEmpty(insurerMstDetailsRequest.getPolicyEndDate())) {
			List<InsurerMstDetailsV3> insurerMstDetailsList = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveAndPolicyStartDateBeforeAndPolicyEndDateAfter(
							insurerMstDetailsRequest.getSchemeId(), insurerMstDetailsRequest.getOrgId(), Boolean.TRUE,
							insurerMstDetailsRequest.getPolicyStartDate(), insurerMstDetailsRequest.getPolicyEndDate());
			if (!OPLUtils.isListNullOrEmpty(insurerMstDetailsList)) {
				return new CommonResponse("SuccessFully get insured data!!!", CommonUtils.INT_2, HttpStatus.OK.value(),
						true);
			}
		}

		return new CommonResponse("Data not found!!!", HttpStatus.OK.value(), false);

	}

	@Override
	public CommonResponse insurerStartAndEndDateValidation(InsurerMstDetailsRequest insurerMstDetailsRequest)
			throws InsuranceException, ParseException {

		Date policyStartDate = CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS
				.parse(properties.getValueByCode(INSURER_START_DATE) + (CommonUtils.getPolicyNextStartYear())
						+ "T00:00:00.00");
		Date policyEndDate = CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(
				properties.getValueByCode(INSURER_END_DATE) + (CommonUtils.getPolicyNextEndYear()) + "T23:59:59.00");
		List<InsurerMstDetailsV3> insurerMstDetailsList = insurerMstDetailsRepository
				.findBySchemeIdAndOrgIdAndIsActiveAndPolicyStartDateAndPolicyEndDate(
						insurerMstDetailsRequest.getSchemeId(), insurerMstDetailsRequest.getOrgId(), Boolean.TRUE,
						policyStartDate, policyEndDate);
		if (!OPLUtils.isListNullOrEmpty(insurerMstDetailsList)) {
			return new CommonResponse("SuccessFully get insured data!!!", Boolean.TRUE, HttpStatus.OK.value(), true);
		}

		return new CommonResponse("Data not found!!!", Boolean.FALSE, HttpStatus.OK.value(), false);

	}

	@Override
	public CommonResponse getPolicyAndFinancialYearDate(Integer type) throws InsuranceException, ParseException {

		@SuppressWarnings({ "rawtypes", "unchecked" })
		Map<String, Object> map = new HashMap();
		if(type==1) {			
			map.put(CommonUtils.POLICY_START_DATE, CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(INSURER_START_DATE) + (CommonUtils. getPolicyEndYear()-CommonUtils.INT_1)+"T00:00:00.00"));
			map.put(CommonUtils.POLICY_END_DATE, CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(INSURER_END_DATE) + (CommonUtils. getPolicyEndYear())+"T23:59:59.00"));
		}else if(type==2) {			
			map.put(CommonUtils.FINANCIAL_START_DATE, CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(FINANCIAL_START_DATE) + (CommonUtils. getFinancialEndYear()-CommonUtils.INT_1)+"T00:00:00.00"));
			map.put(CommonUtils.FINANCIAL_END_DATE, CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(properties.getValueByCode(FINANCIAL_END_DATE) + (CommonUtils. getFinancialEndYear())+"T23:59:59.00"));
		}

		return new CommonResponse(map, CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value());
	}
	
	@Override
	public CommonResponse getInsurerDetailsForClaim(InsurerMstDetailsProxy req)
			throws InsuranceException, ParseException {
		try {
			InsurerMstDetailsV3 insurerMstDetails = new InsurerMstDetailsV3();
			Date date = new Date();
//			date = CommonUtils.sdf.format(req.getDateOfDeath());
			if (!OPLUtils.isObjectNullOrEmpty(req.getDateOfDeath())) {
				insurerMstDetails = insurerMstDetailsRepository
						.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
								req.getSchemeId().longValue(), req.getOrgId(), req.getDateOfDeath(),
								req.getDateOfDeath());
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(req.getDateAndTimeOfAccident())) {
					insurerMstDetails = insurerMstDetailsRepository
							.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
									req.getSchemeId().longValue(), req.getOrgId(), req.getDateAndTimeOfAccident(),
									req.getDateAndTimeOfAccident());
				}
			}

			if (!OPLUtils.isObjectListNull(insurerMstDetails)) {
				CommonResponse organizationresponse = usersClient.getOrganizationById(insurerMstDetails.getInsurerOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(organizationresponse)) {
					UserOrganisationMasterResponse objectFromObject = MultipleJSONObjectHelper
							.getObjectFromObject(organizationresponse.getData(), UserOrganisationMasterResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(objectFromObject)) {
						req.setImagePath(objectFromObject.getImagePath());
					}
				}

				BeanUtils.copyProperties(insurerMstDetails, req);
				req.setCoverEndDate(insurerMstDetails.getPolicyEndDate());
				return new CommonResponse("SuccessFully get insured data!!!", req, HttpStatus.OK.value(),
						true);
			}
			return new CommonResponse("Data not found!!!", Boolean.FALSE, HttpStatus.OK.value(), false);

		} catch (Exception e) {
			log.error("Exception is getting while get  Insurer  Details For Claim ", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		}

	}

	@Override
	public CommonResponse getInsurerDetailsStartAndEndDate(InsurerMstDetailsProxy req)
			throws InsuranceException, ParseException {
		try {
			InsurerMstDetailsV3 insurerMstDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
							req.getSchemeId().longValue(), req.getOrgId(), new Date(), new Date());

			if (OPLUtils.isObjectNullOrEmpty(insurerMstDetails)) {
				return new CommonResponse("Data not found!!!", Boolean.FALSE, HttpStatus.OK.value(), false);
			}
			BeanUtils.copyProperties(insurerMstDetails, req);
			return new CommonResponse("SuccessFully get insured data!!!", req, HttpStatus.OK.value(), true);
		} catch (Exception e) {
			log.error("Exception is getting while get  InsurerDetails For StarEndDate ", e);
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		}
	}
}
