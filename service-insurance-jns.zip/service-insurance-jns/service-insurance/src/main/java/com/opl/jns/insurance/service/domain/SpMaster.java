package com.opl.jns.insurance.service.domain;


import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

@Entity
@Table(name = "sp_master")
@Setter
@Getter
public class SpMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id")
    private Long id;
    
    @Column(name = "request")
    String request; 
    
    @Column(name = "userId")
    Long userId;
    
    @Column(name = "spName")
    String spName;
}
