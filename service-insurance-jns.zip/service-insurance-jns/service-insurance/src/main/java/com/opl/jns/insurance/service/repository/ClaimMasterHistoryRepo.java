package com.opl.jns.insurance.service.repository;
//package com.opl.service.insurance.jns.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.opl.service.insurance.jns.domain.ClaimMasterHistory;
//
//public interface ClaimMasterHistoryRepo extends JpaRepository<ClaimMasterHistory, Long> {
//
//}
