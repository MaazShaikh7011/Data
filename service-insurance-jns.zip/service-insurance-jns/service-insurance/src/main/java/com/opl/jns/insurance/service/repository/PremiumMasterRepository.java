package com.opl.jns.insurance.service.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.insurance.service.domain.PremiumMaster;

public interface PremiumMasterRepository extends JpaRepository<PremiumMaster, Long> {

	PremiumMaster findFirstByTypeAndQuarterNo(Integer type,Integer quarterNo);

	List<PremiumMaster> findAllByType(Integer type);
}
