package com.opl.jns.insurance.service.service.impl;

import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.config.repository.UserOrganizationMasterRepoV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ConsentMaster;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.ere.enums.PremiumMasterType;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.utils.ApplicationQueryProxy;
import com.opl.jns.insurance.api.enums.QuarterEnum;
import com.opl.jns.insurance.api.model.ConsentDataProxy;
import com.opl.jns.insurance.api.model.EnrollmentListRequest;
import com.opl.jns.insurance.service.domain.PremiumMaster;
import com.opl.jns.insurance.service.repository.PremiumMasterRepository;
import com.opl.jns.insurance.service.repository.ReportRepositoryV3;
import com.opl.jns.insurance.service.service.CustomerService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.ApplicationStatus;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private PremiumMasterRepository premiumMasterRepo;

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepository;

	@Autowired
	private ConsentMasterRepository consentMasterRepository;

	@Autowired
	private ReportRepositoryV3 reportRepository;

	@Autowired
	private UsersClient usersClient;
	
	@Autowired
	private UserOrganizationMasterRepoV3 userOrgRepository;

	@Override
	public String getConsentDetails(Long applicationId) {
		try {
			ApplicationMasterV3 appMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Application master details not found by application id -->" + applicationId);
				return null;
			}

			/** set consent data */
			ConsentDataProxy consentDataProxy = new ConsentDataProxy();
			consentDataProxy = updateConsentData(consentDataProxy, appMaster);

			/** get insurer details */
			InsurerMstDetailsV3 mst = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
							appMaster.getSchemeId().longValue(), appMaster.getOrgId(), new Date(), new Date());

			if (OPLUtils.isObjectNullOrEmpty(mst)) {
				log.error("insurer master details not found by application id -->" + applicationId);
				return null;
			}else {				
				if (!OPLUtils.isObjectNullOrEmpty(mst)) {
					consentDataProxy.setMasterPolicyNumber(mst.getMasterPolicyNo());
					String organizationName = usersClient.getOrganizationName(mst.getInsurerOrgId());
					consentDataProxy.setInsurerName(organizationName);
				}
			}

			/** set and generate consent template */
//			TemplateMaster templateMaster = templateMasterRepository.findBySchemeIdAndTypeAndIsActiveTrue(appMaster.getSchemeId().longValue(), TemplateMasterType.CONSENT.getId());

			/** Now consent get from consent master */
			ConsentMaster consentMaster = null;
			try {
				if(appMaster.getSchemeId().longValue()==SchemeMaster.PMSBY.getId()) {
					consentMaster = consentMasterRepository.findByTypeIdAndIsActiveTrueAndCurrentActiveTrue(ConsentType.DIY_PREMIUM_PMSBY.getId());
				}else {
					consentMaster = consentMasterRepository.findByTypeIdAndIsActiveTrueAndCurrentActiveTrue(ConsentType.DIY_PREMIUM_PMJJBY.getId());
				}
			}catch (Exception e) {
				log.info("ERROR WHILE GET CONSENT FOR--> {}", ConsentType.DIY_PREMIUM_PMSBY.getValue());
			}
			if(!OPLUtils.isObjectNullOrEmpty(consentMaster)) {
				return setConsentTemplateData(consentMaster.getConsent(), consentDataProxy);
			}
		} catch (Exception e) {
			log.error("Exception While getting consent data ", e);
		}
		return null;

	}

	public ConsentDataProxy updateConsentData(ConsentDataProxy consentDataProxy, ApplicationMasterV3 appMaster) {

		/** set premium master data */
		List<PremiumMaster> premiumMasters = premiumMasterRepo.findAllByType(PremiumMasterType.CUSTOMER.getId());
		PremiumMaster firstQuater = premiumMasters.stream().filter(x -> x.getId() == QuarterEnum.FIRST__QUARTER.getId())
				.findFirst().orElse(null);
		PremiumMaster secondQuater = premiumMasters.stream().filter(x -> x.getId() == QuarterEnum.SECOND__QUARTER.getId())
				.findFirst().orElse(null);
		PremiumMaster thirdQuater = premiumMasters.stream().filter(x -> x.getId() == QuarterEnum.THIRD__QUARTER.getId())
				.findFirst().orElse(null);
		PremiumMaster fourthQuater = premiumMasters.stream().filter(x -> x.getId() == QuarterEnum.FOURTH__QUARTER.getId())
				.findFirst().orElse(null);
    @SuppressWarnings("deprecation")
		Integer currentMonth = (new Date().getMonth() + CommonUtils.INT_1);		
		PremiumMaster currentMonthAmt = premiumMasters.stream().filter(x -> x.getQuarterNo().equals( CommonUtils.getQuarterNo(currentMonth)))
				.findFirst().orElse(null);	
		
		if(OPLUtils.isObjectNullOrEmpty(currentMonthAmt) ||OPLUtils.isObjectNullOrEmpty(firstQuater) || OPLUtils.isObjectNullOrEmpty(secondQuater) || OPLUtils.isObjectNullOrEmpty(thirdQuater) || OPLUtils.isObjectNullOrEmpty(fourthQuater)) {
			log.error("quarters details not found -->");
			return null;
		}

		consentDataProxy.setSchemeId(appMaster.getSchemeId());
		/** set all quarters premium amount */
		if (appMaster.getSchemeId().equals(SchemeMaster.PMSBY.getId().intValue())) {
			consentDataProxy.setFirstQuarterMonthsAmount(firstQuater.getPmsbyPremium());
			consentDataProxy.setSecondQuarterMonthsAmount(secondQuater.getPmsbyPremium());
			consentDataProxy.setThirdQuarterMonthsAmount(thirdQuater.getPmsbyPremium());
			consentDataProxy.setFourthQuarterMonthsAmount(fourthQuater.getPmsbyPremium());
			consentDataProxy.setCurrentMonthsAmount(currentMonthAmt.getPmsbyPremium());
		} else if (appMaster.getSchemeId().equals(SchemeMaster.PMJJBY.getId().intValue())) {
			consentDataProxy.setFirstQuarterMonthsAmount(firstQuater.getPmjjbyPrimium());
			consentDataProxy.setSecondQuarterMonthsAmount(secondQuater.getPmjjbyPrimium());
			consentDataProxy.setThirdQuarterMonthsAmount(thirdQuater.getPmjjbyPrimium());
			consentDataProxy.setFourthQuarterMonthsAmount(fourthQuater.getPmjjbyPrimium());
			consentDataProxy.setCurrentMonthsAmount(currentMonthAmt.getPmjjbyPrimium());
		}

		/** set all quaters months name */
		consentDataProxy.setQuarterMonthsFirst(setMonthsString(firstQuater));
		consentDataProxy.setQuarterMonthsSecond(setMonthsString(secondQuater));
		consentDataProxy.setQuarterMonthsThird(setMonthsString(thirdQuater));
		consentDataProxy.setQuarterMonthsFourth(setMonthsString(fourthQuater));
		return consentDataProxy;
	}

	public String setMonthsString(PremiumMaster quater) {
		String[] months = quater.getQuarterMonths().split(",");
		return getMonthNameByMonthNo(Integer.valueOf(months[0])) + ", "
				+ getMonthNameByMonthNo(Integer.valueOf(months[1])) + " & "
				+ getMonthNameByMonthNo(Integer.valueOf(months[2]));
	}

	/** get month name by month number */
	public String getMonthNameByMonthNo(Integer month) {
		return new DateFormatSymbols().getMonths()[month - 1];

	}

	private String setConsentTemplateData(String template, ConsentDataProxy consentDataProxy) {
		if (!OPLUtils.isObjectNullOrEmpty(template)) {
			template = template.replace("$schemeName",
					OPLUtils.replaceStringIfNull(SchemeMaster.getById(consentDataProxy.getSchemeId().longValue()).getName(), ""));
			template = template.replace("$schemeShortName",
					OPLUtils.replaceStringIfNull(SchemeMaster.getById(consentDataProxy.getSchemeId().longValue()).getShortName(), ""));
			template = template.replace("$nameOfInsurer",
					OPLUtils.replaceStringIfNull(consentDataProxy.getInsurerName(), ""));
			template = template.replace("$masterPolicyNumber",
					OPLUtils.replaceStringIfNull(consentDataProxy.getMasterPolicyNumber().toUpperCase(), ""));
			template = template.replace("$firstQuaterMonths",
					OPLUtils.replaceStringIfNull(consentDataProxy.getQuarterMonthsFirst(), ""));
			template = template.replace("$wordFirstQuaterAmt",
//					OPLUtils.replaceStringIfNull(CommonUtils.convert_to_words(String.valueOf(consentDataProxy.getFirstQuarterMonthsAmount().intValue()).toCharArray()), ""));
					OPLUtils.replaceStringIfNull(consentDataProxy.getSchemeId()==1 ? "Rupees twenty" : "Rupees four hundred thirty-six only", ""));
			template = template.replace("$secondQuaterMonths",
					OPLUtils.replaceStringIfNull(consentDataProxy.getQuarterMonthsSecond(), ""));
			template = template.replace("$thirdQuaterMonths",
					OPLUtils.replaceStringIfNull(consentDataProxy.getQuarterMonthsThird(), ""));
			template = template.replace("$fourthQuaterMonths",
					OPLUtils.replaceStringIfNull(consentDataProxy.getQuarterMonthsFourth(), ""));
			template = template.replace("$currentMonths",
					OPLUtils.replaceStringIfNull(consentDataProxy.getCurrentMonths(), ""));
			template = template.replace("$firstQuaterMonthAmt",
					OPLUtils.replaceStringIfNull(consentDataProxy.getFirstQuarterMonthsAmount(), ""));
			template = template.replace("$secondQuaterMonthAmt",
					OPLUtils.replaceStringIfNull(consentDataProxy.getSecondQuarterMonthsAmount(), ""));
			template = template.replace("$thirdQuaterMonthAmt",
					OPLUtils.replaceStringIfNull(consentDataProxy.getThirdQuarterMonthsAmount(), ""));
			template = template.replace("$fourthQuaterMonthAmt",
					OPLUtils.replaceStringIfNull(consentDataProxy.getFourthQuarterMonthsAmount(), ""));
			template = template.replace("$currentMonthAmt",
					OPLUtils.replaceStringIfNull(consentDataProxy.getCurrentMonthsAmount(), ""));
		}
		return template;
	}


	@Override
	public CommonResponse getEnrollmentList(EnrollmentListRequest request, Long userId) throws Exception {
		try {
			String tableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am INNER JOIN "
					+ DBNameConstant.JNS_INSURANCE + ".applicant_info ai ON ai.application_id = am.id INNER JOIN "
					+ DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1 INNER JOIN "
					+ DBNameConstant.JNS_CONFIG + ".user_organisation_master uom ON uom.org_id = am.org_id " ;

			String countsTableQuery = " FROM " + DBNameConstant.JNS_INSURANCE + ".application_master am ";
			
			if (!OPLUtils.isObjectNullOrEmpty(request.getType()) && request.getType() != 4 && request.getType() != 3) {
				tableQuery += " LEFT JOIN (select ma.application_id, max(ma.created_date) as created_date from " + DBNameConstant.JNS_INSURANCE + ".miscellaneous_audit ma where is_active=1 group by ma.application_id) md ON md.application_id = am.ID";
				countsTableQuery += " LEFT JOIN (select ma.application_id, max(ma.created_date) as created_date from " + DBNameConstant.JNS_INSURANCE + ".miscellaneous_audit ma where is_active=1 group by ma.application_id) md ON md.application_id = am.ID";
			}

			String whereQuery = " WHERE am.is_active = 1  AND am.user_id = " + userId;
			if (!OPLUtils.isObjectNullOrEmpty(request.getSchemeId())) {
				whereQuery += " AND am.scheme_id = " + request.getSchemeId();
			}
			 if(OPLUtils.isObjectNullOrEmpty(request.getType())) {
				 whereQuery += " AND am.stage_id in (" + EnrollStageMaster.APPLICATION_FORM.getStageId() + "," + EnrollStageMaster.COMPLETED.getStageId() +"," + EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId() + ")"; 
			 }

			if (!OPLUtils.isObjectNullOrEmpty(request.getType())) {
				if (request.getType() == 1) {
					whereQuery += " and am.application_status not in  (" + ApplicationStatus.OPT_OUT.getId() + "," + ApplicationStatus.OPT_OUT_IN_PROCESS.getId() + " ) AND am.stage_id = " + EnrollStageMaster.COMPLETED.getStageId();
				}else if((request.getType() == 3) ){
					whereQuery += " AND am.stage_id IN (" + EnrollStageMaster.APPLICATION_FORM.getStageId() + "," + EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId() + " )";
				}else {
					whereQuery += " AND am.stage_id = " + EnrollStageMaster.COMPLETED.getStageId();
				}
			}
			if (!OPLUtils.isObjectNullOrEmpty(request.getSearchData())) {
				whereQuery += " AND  (am.urn =  '" +  request.getSearchData()   + "' OR am.account_number = " + DBNameConstant.JNS_USERS + ".\"encvalue\"('" + request.getSearchData() + "') )";
			}

//			String orderByQuery = " order by am.modified_date || am.created_date desc ";
			String orderByQuery = " order by am.modified_date desc ";
			
			String limitQuery = " OFFSET " + request.getPaginationFROM() + " ROWS FETCH NEXT " + request.getPaginationTO() + " ROWS ONLY";

			String selectCountQuery = "select (json_object('totalCount' value count(am.id))) ";
//			log.info( "Query : ==============> {}" + (selectCountQuery + tableQuery + whereQuery));
			String str = reportRepository.fetchCount(selectCountQuery + countsTableQuery + whereQuery);
			JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
			Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;

			String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
					+ " ,'urn' value urn,"
					+ "'applicationId' value applicationId,"
					+ "'id' value id,"
					+ "'enrollDate' value enrollDate,"
					+ "'scheme' value scheme,"
					+ " 'stageId' value stageId,"
					+ " 'schemeName' value schemeName,"
					+ " 'orgId' value orgId,"
					+ " 'orgName' value orgName,"
					+ " 'accountNumber' value accountNumber,"
					+ " 'dateOfRequest' value dateOfRequest,"
					+ " 'mobileNumber' value mobileNumber,"
					+ " 'modifiedDate' value modifiedDate,"
					+ " 'customerAccountNumber' value customerAccountNumber,"
					+ " 'message' value message,"
					+ (!OPLUtils.isObjectNullOrEmpty(request.getType()) && request.getType()!=4 && request.getType()!=3 ? " 'dateOfNomineeUpdation' value dateOfNomineeUpdation," : "")
					+ " 'name' value name )returning clob) FROM ( SELECT  am.id as applicationId,"
					+ "am.urn as urn,"
					+ "am.id as id,"
					+ DBNameConstant.JNS_USERS + ".\"decvalue\"(am.account_number) as accountNumber ,"
					+ DBNameConstant.JNS_USERS + ".\"decvalue\"(am.account_number) as customerAccountNumber ,"
					+ "am.enrollment_date as enrollDate,"
					+ "am.scheme_id as scheme,"
					+ "am.stage_id as stageId,"
					+ " to_char(SYSDATE, 'MM-DD-YYYY HH24:MI:SS') as dateOfRequest,"
					+ "sm.short_name as schemeName,"
					+ "am.org_id as orgId,"
					+ "uom.display_org_name as orgName,"
					+ "am.modified_date as modifiedDate,"
					+ "am.message as message,"
					+ (!OPLUtils.isObjectNullOrEmpty(request.getType()) && request.getType()!=4 && request.getType()!=3 ? "md.created_date AS dateOfNomineeUpdation," : "")
					+ DBNameConstant.JNS_USERS + ".\"decvalue\"(ai.mobile_number) as mobileNumber ,"
					+ DBNameConstant.JNS_USERS + ".\"decvalue\"(ai.name) as name ";

			String mainQuery = selectQuery + tableQuery + whereQuery + orderByQuery +limitQuery + ")";
//			log.info("Query ======> {}",mainQuery);

			String data = reportRepository.fetchOptOutApplication(mainQuery);
			return new CommonResponse("successfully get Data", data, HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting while get Enrollment List", e);
		}
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
	}
	
	 public List<Map<Long, String>> getOrganisationListByUserTypeId(Long userTypeId) {
	        return userOrgRepository.findByUserTypeIdAndIsActiveTrueAndIsBorrowerDisplayOrderByDisplayOrgNameAsc(userTypeId);
	    }

	@Override
	public CommonResponse getDashboardEnrollmentList(Long userId) throws Exception {
		try {
			/** fetch application master record*/
			List<ApplicationQueryProxy> applicationMstLst = applicationMasterRepository
					.findAllByIsActiveTrueAndUserIdAndStageIdIn(userId,
							Arrays.asList(EnrollStageMaster.APPLICATION_FORM.getStageId(),
									EnrollStageMaster.COMPLETED.getStageId(),
									EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId()));
			
			/** fetch schemeId and set schemeName */
			if(!OPLUtils.isListNullOrEmpty(applicationMstLst)) {				
				applicationMstLst.forEach(x -> {
					x.setSchemeName(SchemeMaster.getById(Long.valueOf(x.getSchemeId())).getShortName());
				});
			}
			
			return new CommonResponse("successfully get Data", applicationMstLst, HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception is getting while get Enrollment List", e);
		}
		
		return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value());
	}

	@Override
	public List<Map<String, String>> getOrganisationAndInsurerListByUserTypeId(Long userTypeId) {
		if(userTypeId == 6){
			return userOrgRepository.getCodeAndDisplayOrgName(userTypeId);
		} else {
			return userOrgRepository.getOrgIdAndDisplayOrgName(userTypeId);
		}
	}
}
