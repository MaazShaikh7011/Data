package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import javax.crypto.Cipher;
//import javax.crypto.SecretKey;
//import javax.crypto.SecretKeyFactory;
//import javax.crypto.spec.DESKeySpec;
//
//import javax.xml.bind.DatatypeConverter;
//
//import java.util.Base64;
//
//class DES{
//
//    Cipher ecipher;
//    Cipher dcipher;
//    private static final String ENCRYPTION_KEY = "0123456789abcdef0123456789abcdef0123456789abcdef01234567";
//
//    DES(SecretKey key) throws Exception {
//        ecipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
//        dcipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
//        ecipher.init(Cipher.ENCRYPT_MODE, key);
//        dcipher.init(Cipher.DECRYPT_MODE, key);
//    }
//
//    public String encrypt(String str) throws Exception {
//        // Encode the string into bytes using utf-8
//        byte[] utf8 = str.getBytes("UTF8");
//
//        // Encrypt
//        byte[] enc = ecipher.doFinal(utf8);
//
//        // Encode bytes to base64 to get a string
//
//        return Base64.getEncoder().encodeToString(enc);
//
//    }
//
//    public String decrypt(String str) throws Exception {
//        // Decode base64 to get bytes
//        byte[] dec = Base64.getDecoder().decode(str);
//
//        byte[] utf8 = dcipher.doFinal(dec);
//
//        // Decode using utf-8
//        return new String(utf8, "UTF8");
//    }
//
//    public static void main(String[] argv) throws Exception {
//        final String secretText = "sagarhrlovdvd sdskvb";
//        System.out.println("SecretText: " + secretText);
//        System.out.println(ENCRYPTION_KEY.length());
//        
////        String desKey = "0123456789abcdef0123456789abcdef0123456789abcdef"; // user value (24 bytes)  
//        byte[] keyBytes = DatatypeConverter.parseHexBinary(ENCRYPTION_KEY);
//
//        SecretKeyFactory factory = SecretKeyFactory.getInstance("DES");
//        SecretKey key = factory.generateSecret(new DESKeySpec(keyBytes));
//        
////        SecretKey key = KeyGenerator.getInstance("DES").generateKey();
////        SecretKey key = new SecretKeySpec(ENCRYPTION_KEY.getBytes(), "DES");
//        System.out.println(key);
//        DES encrypter = new DES(key);
//        String encrypted = encrypter.encrypt(secretText);
//        System.out.println("Encrypted Value: " + encrypted);
//        System.out.println("Decrypted: " + encrypter.decrypt(encrypted));
//        String decrypted = encrypter.decrypt("FMdA41OR68I=");
////        System.out.println("Decrypted: "+ decrypted);
////        String decrypted1= encrypter.decrypt("vDpwxu++AQOw+jL4Dk18jtiepRZQ+qM0");
////        String decrypted1= encrypter.decrypt("ospmcjw2RewmeTjKiwd/ng==");
//        System.out.println("Decrypted: " + decrypted);
//
//    }
//}