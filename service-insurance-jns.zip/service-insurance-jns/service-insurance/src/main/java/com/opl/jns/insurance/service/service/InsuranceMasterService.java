package com.opl.jns.insurance.service.service;

import java.text.ParseException;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.InsurerMstDetailsProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.utils.common.CommonResponse;

/**
 * @author - Maaz Shaikh
 * @Date - 6/15/2023
 */
public interface InsuranceMasterService {
	public InsurerMstDetailsRequest getInsurerMstDetailsById(Long id) throws InsuranceException;

	public CommonResponse save(InsurerMstDetailsRequest InsurerMstDetailsRequest,AuthClientResponse authClientResponse) throws InsuranceException;

	public CommonResponse getOrgMasterListByUserTypeId(Long userTypeId, Long schemeId);
	
	public CommonResponse getOrganisationMstListByUserTypeId(Long userTypeId);

//	public List<Map<String, Object>> fetchInsurerApplicationList(String request, Long userId);
	public  CommonResponse fetchInsurerApplicationList(String request,Long userId);

	public InsurerMstDetailsRequest getInsurerDetailsBySchemeIdAndOrgId(Long schemeId, Long orgId, Integer mode)
			throws InsuranceException, ParseException;

	public CommonResponse getInsurerDataByStartAndEndDate(InsurerMstDetailsRequest InsurerMstDetailsRequest)
			throws InsuranceException;

	public CommonResponse insurerStartAndEndDateValidation(InsurerMstDetailsRequest InsurerMstDetailsRequest)
			throws InsuranceException, ParseException;

	public CommonResponse getPolicyAndFinancialYearDate(Integer type) throws InsuranceException, ParseException;
	
	public CommonResponse getInsurerDetailsForClaim(InsurerMstDetailsProxy InsurerMstDetailsRequest)
			throws InsuranceException, ParseException;
	
	public CommonResponse getInsurerDetailsStartAndEndDate(InsurerMstDetailsProxy req)
			throws InsuranceException, ParseException;
}
