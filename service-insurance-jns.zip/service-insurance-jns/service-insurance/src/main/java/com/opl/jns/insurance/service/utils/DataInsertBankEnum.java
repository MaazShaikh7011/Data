package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import com.opl.jns.utils.enums.*;
//
//public enum DataInsertBankEnum {
//
//    SBI(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    BOB(17l, CommonUtils.NATIONAL_INSURER_ORG_ID, 2),
//    SBI_1(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    BOI(14l, CommonUtils.SUDI_LIFE_INSURER_ORG_ID, 2),
//    CENTRAL(25l, CommonUtils.LIC_INSURER_ORG_ID, 2),
//    SBI_2(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    CANERA(12l, CommonUtils.CANARA_HSBC_LIFE_INSURER_ORG_ID, 2),
//    HDFC(32l, CommonUtils.HDFC_LIFE_INSURER_ORG_ID, 2),
//    ICICI(4l, CommonUtils.ICIC_PRODENTIAL_INSURER_ORG_ID, 2),
//    INDIANBANK(13l, CommonUtils.UIIC_INSURER_ORG_ID, 2),
//    SBI_4(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    IOB(28l, CommonUtils.UNIVERSAL_SOMPO_INSURER_ORG_ID, 2),
//    MAHA(27l, CommonUtils.LIC_INSURER_ORG_ID, 2),
//    SBI_5(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    PNB(18l, CommonUtils.LIC_INSURER_ORG_ID, 2),
//    PSB(20l, CommonUtils.LIC_INSURER_ORG_ID, 2),
//    SBI_6(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2),
//    UBI(1l, CommonUtils.SUDI_LIFE_INSURER_ORG_ID, 2),
//    UCO(19l, CommonUtils.LIC_INSURER_ORG_ID, 2),
//	SBI_3(16l, CommonUtils.SBI_LIFE_INSURER_ORG_ID, 2);
//	
//	private final Long orgId;
//    private final Long insurerId;
//    private final Integer schemeId;
//
//    private DataInsertBankEnum(Long orgId, Long insurerId, Integer schemeId) {
//        this.orgId = orgId;
//        this.insurerId = insurerId;
//        this.schemeId = schemeId;
//    }
//
//    public static DataInsertBankEnum[] getAll() {
//        return values();
//    }
//
//    public Long getOrgId() {
//        return orgId;
//    }
//
//    public Long getInsurerId() {
//        return insurerId;
//    }
//
//    public Integer getSchemeId() {
//        return schemeId;
//    }
//}
