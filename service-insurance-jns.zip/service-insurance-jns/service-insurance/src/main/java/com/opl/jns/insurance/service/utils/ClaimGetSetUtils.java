package com.opl.jns.insurance.service.utils;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.ere.domain.ClmAddressMaster;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmNomineeDetails;
import com.opl.jns.ere.domain.ClmNomineePIDetails;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.insurance.api.model.AddressMasterRequest;
import com.opl.jns.insurance.api.model.ClaimMasterRequest;
import com.opl.jns.insurance.api.model.NomineeDetailsRequest;
import com.opl.jns.insurance.api.model.UpdateClaimAccountHolderRequest;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.UserTypeMaster;

public class ClaimGetSetUtils {

	/**
	 * SET USER DETAILS INTO API CLAIM MASTER TABLE SET
	 * 
	 * @param clmMaster
	 * @param map
	 */
	public static ClmMaster setClaimMasterOtherDtl(ClmMaster clmMaster, Map<String, Object> map) {
		// SET Branch Mapping Details
		clmMaster.setBranchStateId(
				OPLUtils.isObjectNullOrEmpty(map.get("stateId")) ? null : Long.valueOf(map.get("stateId").toString()));
		clmMaster.setBranchCityId(
				OPLUtils.isObjectNullOrEmpty(map.get("cityId")) ? null : Long.valueOf(map.get("cityId").toString()));
		clmMaster.setBranchLhoId(OPLUtils.isObjectNullOrEmpty(map.get("branchLhoId")) ? null
				: Long.valueOf(map.get("branchLhoId").toString()));
		clmMaster.setBranchRoId(OPLUtils.isObjectNullOrEmpty(map.get("branchRoId")) ? null
				: Long.valueOf(map.get("branchRoId").toString()));
		clmMaster.setBranchZoId(OPLUtils.isObjectNullOrEmpty(map.get("branchZoId")) ? null
				: Long.valueOf(map.get("branchZoId").toString()));
		return clmMaster;
	}

	/**
	 * SET POLICY DETAILS INTO API CLAIM MASTER TABLE SET
	 *
	 * @param appMaster
	 * @param authClientResponse
	 * @param policyDetails
	 * @param schemeId
	 * @return
	 */
	public static ClmMaster setClaimMaster(ApplicationMasterBothSchemeProxy appMaster, AuthClientResponse authClientResponse,PolicyDetailsResponse policyDetails,Integer schemeId) {
		ClmMaster clmMaster = new ClmMaster();
		clmMaster.setUrn(appMaster.getUrn());
		clmMaster.setApplicationId(appMaster.getId());
		clmMaster.setOrgId(appMaster.getOrgId());
		clmMaster.setSchemeId(schemeId);
		clmMaster.setBranchId(authClientResponse.getUserBranchId());
		clmMaster.setStatus(ClaimStatus.CLAIM_IN_PROGRESS.getId());
		clmMaster.setStageId(ClaimStageMaster.CLAIM_FORM.getStageId());
		clmMaster.setIsActive(Boolean.TRUE);
		clmMaster.setInsurerOrgId(appMaster.getInsurerOrgId());
		clmMaster.setFirstEnrollmentDate(!OPLUtils.isObjectNullOrEmpty(policyDetails.getFirstEnrollmentDate()) ? Date.from(policyDetails.getFirstEnrollmentDate().atZone(ZoneId.systemDefault()).toInstant()) : null);
		clmMaster.setCreatedBy(authClientResponse.getUserId());
		clmMaster.setCreatedDate(new Date());
		if(Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDPROVIDER.getId())) {			
			clmMaster.setSource(Source.JANSURAKSHA.getId());
		}
		return clmMaster;
	}

	/**
	 * SET POLICY DETAILS INTO API CLAIM DETAILS TABLE SET
	 * 
	 * @param clmMaster
	 * @param policyDetails
	 */
	public static ClmDetails setClaimDetails(ClmMaster clmMaster, PolicyDetailsResponse policyDetails,Map<String, Object> map,AuthClientResponse authClientResponse,ApplicantInfoV2 applicantInfo,UpdateClaimAccountHolderRequest holderRequest) {
		ClmDetails clmDetails = new ClmDetails();
		clmDetails.setId(clmMaster.getId());
		clmDetails.setApEmail(policyDetails.getEmailId());
		clmDetails.setApMobileNumber(policyDetails.getMobileNumber());
		clmDetails.setApGenderId(Gender.fromBankValue(policyDetails.getGender()).getId());
//		clmDetails.setApFatherHusbandName(policyDetails.getFatherHusbandName());
		if(!OPLUtils.isObjectNullOrEmpty(applicantInfo)) {			
			clmDetails.setApDisabilityDetails(applicantInfo.getDisabilityDetails());
			clmDetails.setApDisabilityStatus(applicantInfo.getDisabilityStatus());
//			clmDetails.setApFatherHusbandName(applicantInfo.getFatherHusbandName());
		}
		clmDetails.setApCustomerIfsc(policyDetails.getCustomerIFSC());
		clmDetails.setApTransactionUTR(policyDetails.getTransactionUTR());
		clmDetails.setApTransactionAmount(policyDetails.getTransactionAmount());
		clmDetails.setBranchCode(OPLUtils.isObjectNullOrEmpty(map.get("branchCode")) ? null : map.get("branchCode").toString());
		clmDetails.setBranchEmailId(authClientResponse.getEmail());
		clmDetails.setApTransactionTimestamp(!OPLUtils.isObjectNullOrEmpty(policyDetails.getTransactionTimestamp()) ? Date.from(policyDetails.getTransactionTimestamp().atZone(ZoneId.systemDefault()).toInstant()) : null);
		clmDetails.setPremDebitDate(clmDetails.getApTransactionTimestamp());
		clmDetails.setPremRemitDate(clmDetails.getApTransactionTimestamp());
		if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateOfDeath())) {
			clmDetails.setDateOfDeath(holderRequest.getDateOfDeath());
			clmDetails.setIsDateOfDeath(true);
		} else if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateAndTimeOfAccident())) {
			clmDetails.setDateTimeOfAccident(holderRequest.getDateAndTimeOfAccident());
			clmDetails.setIsDateTimeOfAccident(true);
		}
		clmDetails.setNatureOfLossId(holderRequest.getNatureOfLoss());

		ClmAddressMaster addressMaster = new ClmAddressMaster();
//		addressMaster.setCityId(policyDetails.getCityId());
//		addressMaster.setCityLGDCode(address.getCityLGDCode());
		addressMaster.setCityName(policyDetails.getCity());
		addressMaster.setDistrict(policyDetails.getDistrict());
//		addressMaster.setDistrictLGDCode(policyDetails.getDistrictLGDCode());
		addressMaster.setPincode(policyDetails.getPincode().intValue());
//		addressMaster.setStateId(policyDetails.getStateId());
//		addressMaster.setStateLGDCode(address.getStateLGDCode());
		addressMaster.setStateName(policyDetails.getState());
		clmDetails.setApAddressMaster(addressMaster);
		clmDetails.setClmMaster(clmMaster);
		return clmDetails;
	}

	/**
	 * SET POLICY DETAILS REQUEST AND RESPONSE INTO API CLAIM PI DETAILS TABLE SET
	 * 
	 * @param policyDetails
	 * @param clmMaster
	 * @param policyDetailsReq
	 */
	public static ClmPIDetails setClaimPIDetails(PolicyDetailsResponse policyDetails, ClmMaster clmMaster,
			PolicyDetailsRequest policyDetailsReq) {
		ClmPIDetails clmPIDetails = new ClmPIDetails();
		clmPIDetails.setId(clmMaster.getId());
		clmPIDetails.setApAccountNumber(policyDetailsReq.getAccountNumber());
		clmPIDetails.setApCif(policyDetailsReq.getCif());
//		clmPIDetails.setApFirstName(applicantInfo.getFirstName());
//		clmPIDetails.setApMiddleName(applicantInfo.getMiddleName());
//		clmPIDetails.setApLastName(applicantInfo.getLastName());
		clmPIDetails.setAcHolderName(policyDetails.getAccountHolderName());
		clmPIDetails.setApKycId1(policyDetails.getKycID1());
		clmPIDetails.setApKycIdNumber1(policyDetails.getKycID1number());
		clmPIDetails.setApPan(policyDetails.getPanNumber());
		clmPIDetails.setApAadhaar(policyDetails.getAadhaarNumber());
		clmPIDetails.setApCkycNumber(policyDetails.getCkycNumber());
		clmPIDetails.setApDob(Date.from(policyDetails.getDob().atStartOfDay(ZoneId.systemDefault()).toInstant()));
//		clmPIDetails.setApGenderId(Gender.fromBankValue(policyDetails.getGender()).getId());
		clmPIDetails.setApAddressLine1(policyDetails.getAddressline1());
		clmPIDetails.setApAddressLine2(policyDetails.getAddressline2());
		clmPIDetails.setApFatherHusbandName(policyDetails.getFatherHusbandName());
		return clmPIDetails;
	}

	/**
	 * SET POLICY DETAILS RESPONSE INTO API CLAIM NOMINEE AND GUARDIAN
	 * TABLE SET
	 * 
	 * @param clmMaster
	 * @param policyDetails
	 */
	public static ClmNomineeDetails setNomineeAndGuardianDetails(ClmMaster clmMaster,
			PolicyDetailsResponse policyDetails) {
		ClmNomineeDetails clmNomineeDetails = new ClmNomineeDetails();
		clmNomineeDetails.setRelationId(!OPLUtils.isObjectNullOrEmpty(policyDetails.getRelationshipOfNominee()) ? RelationShip.fromValue(policyDetails.getRelationshipOfNominee()).getId() : null);
		clmNomineeDetails.setMobileNumber(policyDetails.getNomineeMobileNumber());
		clmNomineeDetails.setEmail(policyDetails.getNomineeEmailId());
		clmNomineeDetails.setIsActive(Boolean.TRUE);

		ClmNomineePIDetails clmNomineePIDetails = new ClmNomineePIDetails();
//		clmNomineePIDetails.setFirstName(nomineeDetails.getFirstName());
//		clmNomineePIDetails.setMiddleName(nomineeDetails.getMiddleName());
//		clmNomineePIDetails.setLastName(nomineeDetails.getLastName());
		clmNomineePIDetails.setName(policyDetails.getNomineeName());
		clmNomineePIDetails.setDob(!OPLUtils.isObjectNullOrEmpty(policyDetails.getNomineeDateOfBirth()) ?
				Date.from(policyDetails.getNomineeDateOfBirth().atStartOfDay(ZoneId.systemDefault()).toInstant()) : null);

		clmNomineePIDetails.setAddressLine1(policyDetails.getAddressofNominee());
//		clmNomineePIDetails.setAddressLine2(nomineeAddress.getAddressLine2());

//		ClmAddressMaster clmAddressMaster = new ClmAddressMaster();
//		clmAddressMaster.setCityId(nomineeAddress.getCityId());
//		clmAddressMaster.setCityLGDCode(nomineeAddress.getCityLGDCode());
//		clmAddressMaster.setCityName(nomineeAddress.getCityName());
//		clmAddressMaster.setDistrict(nomineeAddress.getDistrict());
//		clmAddressMaster.setDistrictLGDCode(nomineeAddress.getDistrictLGDCode());
//		clmAddressMaster.setPincode(nomineeAddress.getPincode());
//		clmAddressMaster.setStateId(nomineeAddress.getStateId());
//		clmAddressMaster.setStateLGDCode(nomineeAddress.getStateLGDCode());
//		clmAddressMaster.setStateName(nomineeAddress.getStateName());
//		clmNomineeDetails.setClmAddressMaster(clmAddressMaster);
		clmNomineeDetails.setClmMaster(clmMaster);
		clmNomineePIDetails.setClmNomineeDetails(clmNomineeDetails);

		if (!OPLUtils.isObjectNullOrEmpty(policyDetails.getRelationshipofGuardian())) {
			clmNomineeDetails.setGdRelationId(RelationShip.fromValue(policyDetails.getRelationshipofGuardian()).getId());
		}
		clmNomineeDetails.setGdMobile(policyDetails.getGuardianMobileNumber());
		clmNomineeDetails.setGdEmail(policyDetails.getGuardianEmailId());
		clmNomineePIDetails.setGdName(policyDetails.getNameofGuardian());
		clmNomineePIDetails.setGdAddress(policyDetails.getAddressofGuardian());
		clmNomineeDetails.setClmNomineePIDetails(clmNomineePIDetails);
		return clmNomineeDetails;
	}


	/**
	 * SET APPLICANT DETAILS FROM APPLICATION AND CLAIM MASTER TABLE
	 *
	 * @param claimMasterReq
	 * @param appMaster
	 * @param clmDetails
	 * @param clmPIDetails
	 * @return
	 */
	public static ClaimMasterRequest setApplicantDetails(ClaimMasterRequest claimMasterReq,
			ApplicationMasterBothSchemeProxy appMaster, ClmDetails clmDetails, ClmPIDetails clmPIDetails) {
		claimMasterReq.setCustIfscCode(clmDetails.getApCustomerIfsc());
		claimMasterReq.setEnrollDate(appMaster.getEnrollmentDate());
		claimMasterReq.setAccountHolderName(clmPIDetails.getAcHolderName());
		claimMasterReq.setDob(clmPIDetails.getApDob());
		claimMasterReq.setMobileNo(clmDetails.getApMobileNumber());
		claimMasterReq.setEmailAddress(clmDetails.getApEmail());
		claimMasterReq.setCustAccountNo(clmPIDetails.getApAccountNumber());
		claimMasterReq.setCustIfsc(clmDetails.getApCustomerIfsc());
		return claimMasterReq;
	}

	/**
	 * SET APPLICANT ADDRESS FROM APPLICATION AND CLAIM MASTER TABLE
	 * 
	 * @param claimMasterReq
	 * @param clmDetails
	 * @param clmPIDetails
	 */
	public static ClaimMasterRequest setApplicantAddress(ClaimMasterRequest claimMasterReq, ClmDetails clmDetails,
			ClmPIDetails clmPIDetails) {
		AddressMasterRequest apAdd = new AddressMasterRequest();
		apAdd.setAddressLine1(clmPIDetails.getApAddressLine1());
		apAdd.setAddressLine2(clmPIDetails.getApAddressLine2());
		apAdd.setCity(clmDetails.getApAddressMaster().getCityName());
		apAdd.setDistrict(clmDetails.getApAddressMaster().getDistrict());
		apAdd.setState(clmDetails.getApAddressMaster().getStateName());
		apAdd.setPincode(clmDetails.getApAddressMaster().getPincode());
		claimMasterReq.setApAddress(apAdd);
		return claimMasterReq;
	}

	/**
	 * SET NOMINEE AND GUARDIAN FROM NOMINEE DETAILS TABLE
	 *
	 * @param claimMasterReq
	 * @param clmNomineePIDetails
	 * @param clmNomineeDetails
	 * @param clmMaster
	 * @param checkPhase2
	 * @return
	 */
	public static ClaimMasterRequest setNomineeAndGuardianDetails(ClaimMasterRequest claimMasterReq,
			ClmNomineePIDetails clmNomineePIDetails, ClmNomineeDetails clmNomineeDetails,ClmMaster clmMaster,boolean checkPhase2) {
		NomineeDetailsRequest nomineeReq = new NomineeDetailsRequest();
		nomineeReq.setName(clmNomineePIDetails.getName());
		nomineeReq.setFirstName(clmNomineePIDetails.getFirstName());
		nomineeReq.setMiddleName(clmNomineePIDetails.getMiddleName());
		nomineeReq.setLastName(clmNomineePIDetails.getLastName());
		nomineeReq.setDateOfBirth(clmNomineePIDetails.getDob());
		nomineeReq.setMobileNumber(clmNomineeDetails.getMobileNumber());
		nomineeReq.setNomineeGenderId(clmNomineeDetails.getNomineeGenderId());
		nomineeReq.setEmailIdOfNominee(clmNomineeDetails.getEmail());
		nomineeReq.setRelationOfNomineeApplicant(clmNomineeDetails.getRelationId());
		nomineeReq.setAddressLine1(clmNomineePIDetails.getAddressLine1());
		nomineeReq.setAge(!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob())
				? CommonUtils.getAgeBydob(clmNomineePIDetails.getDob())
				: null);
		if (!OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getIsNomineeNameCorrection())
				&& clmMaster.getClmDetails().getIsNomineeNameCorrection().equals(Boolean.TRUE)) {
			if(checkPhase2) {
				nomineeReq.setCorrectNomineeFirstName(clmNomineePIDetails.getCorrectNomineeName());
			}else {
				nomineeReq.setCorrectNomineeFirstName(clmNomineePIDetails.getCorrectNomineeFirstName());
				nomineeReq.setCorrectNomineeMiddleName(clmNomineePIDetails.getCorrectNomineeMiddleName());
				nomineeReq.setCorrectNomineeLastName(clmNomineePIDetails.getCorrectNomineeLastName());				
			}
		}
		
		if(!checkPhase2) {			
			AddressMasterRequest nomineeAddRequest = new AddressMasterRequest();
			nomineeAddRequest.setAddressLine1(clmNomineePIDetails.getAddressLine1());
			nomineeAddRequest.setAddressLine2(clmNomineePIDetails.getAddressLine2());
			ClmAddressMaster nomineeAddress = clmNomineeDetails.getClmAddressMaster();
			nomineeAddRequest.setCity(nomineeAddress.getCityName());
			nomineeAddRequest.setDistrict(nomineeAddress.getDistrict());
			nomineeAddRequest.setState(nomineeAddress.getStateName());
			nomineeAddRequest.setPincode(nomineeAddress.getPincode());
			nomineeReq.setAddress(nomineeAddRequest);
		}

		/** SET GUARDIAN DETAILS */
		if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdRelationId())) {
			nomineeReq.setRelationShipOfGuardian(clmNomineeDetails.getGdRelationId());
			nomineeReq
					.setRelationShipOfGuardianStr(RelationShip.fromId(clmNomineeDetails.getGdRelationId()).getValue());
			nomineeReq.setNameOfGuardian(clmNomineePIDetails.getGdName());
			nomineeReq.setMobileNumberOfGuardian(clmNomineeDetails.getGdMobile());
			nomineeReq.setAddressOfGuardian(clmNomineePIDetails.getGdAddress());
			nomineeReq.setEmailIdOfGuardian(clmNomineeDetails.getGdEmail());
		}
		claimMasterReq.setNomineeData(nomineeReq);
		return claimMasterReq;
	}

	/**
	 * SET CLAIMANT DATA FROM CLAIM TABLES
	 *
	 * @param claimMaster
	 * @param clmDetails
	 * @param clmPIDetails
	 * @param claimMasterReq
	 * @param checkPhase2
	 * @return
	 */
	public static ClaimMasterRequest setClaimantDetails(ClmMaster claimMaster, ClmDetails clmDetails,
			ClmPIDetails clmPIDetails,ClaimMasterRequest claimMasterReq,boolean checkPhase2) {
		NomineeDetailsRequest claimantReq = new NomineeDetailsRequest();
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getIsClaimantSame())
				&& claimMaster.getClmDetails().getIsClaimantSame().equals(Boolean.TRUE)) {
			if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmNomineeDetails())) {
				if(checkPhase2) {
					claimantReq.setFirstName(clmPIDetails.getClmName());
				}else {					
					claimantReq.setFirstName(clmPIDetails.getClmFirstName());
					claimantReq.setMiddleName(clmPIDetails.getClmMiddleName());
					claimantReq.setLastName(clmPIDetails.getClmLastName());
				}
				claimantReq.setDateOfBirth(clmPIDetails.getClmDob());
				claimantReq.setEmailIdOfNominee(clmDetails.getClmEmail());
				claimantReq.setMobileNumber(clmDetails.getClmMobile());
				claimantReq.setGenderId(clmDetails.getClmGenderId());
				if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getClmRelationId())) {
					claimantReq.setRelationOfNomineeApplicant(clmDetails.getClmRelationId());
					claimantReq.setRelationOfNomineeApplicantStr(
							RelationShip.fromId(clmDetails.getClmRelationId()).getValue());
				}
				AddressMasterRequest claimantAddRequest = new AddressMasterRequest();
				if(checkPhase2) {
					claimantAddRequest.setAddressLine1(clmPIDetails.getClmAddress());
				}else {					
					claimantAddRequest.setAddressLine1(clmPIDetails.getClmAddressLine1());
					claimantAddRequest.setAddressLine2(clmPIDetails.getClmAddressLine2());
				}
				
				if(!checkPhase2) {					
					ClmAddressMaster nomineeAddress = clmDetails.getClaimantAddressMaster();
					claimantAddRequest.setCity(nomineeAddress.getCityName());
					claimantAddRequest.setDistrict(nomineeAddress.getDistrict());
					claimantAddRequest.setState(nomineeAddress.getStateName());
					claimantAddRequest.setPincode(nomineeAddress.getPincode());
				}
				claimantReq.setAddress(claimantAddRequest);
			}
			claimMasterReq.setClaimantData(claimantReq);

		}
		return claimMasterReq;
	}

	/**
	 * SET CLAIMANT KYC DOCUMENT FROM CLAIM PI DETAILS 
	 * 
	 * @param clmPIDetails
	 * @param claimMasterReq
	 */
	public static ClmPIDetails manageClaimntKycDocuments(ClmPIDetails clmPIDetails, ClaimMasterRequest claimMasterReq) {

		Integer[] kycId = new Integer[2];
		List<String> kycList = Arrays.asList(claimMasterReq.getKycDocId().split(","));
		KycDocument kycDocument1 = KycDocument.fromId(Integer.valueOf(kycList.getFirst()));
		kycId[0] = kycDocument1.getId();
		String kycDocuments1 = getKycDoc(kycDocument1.getId(), claimMasterReq);
		clmPIDetails.setClmKycId1(kycId[0]);
		clmPIDetails.setClmKycIdNumber1(kycDocuments1);

		if (kycList.size() > 1) {
			KycDocument kycDocument2 = KycDocument.fromId(Integer.valueOf(kycList.get(1)));
			kycId[1] = kycDocument2.getId();
			String kycDocuments2 = getKycDoc(kycDocument2.getId(), claimMasterReq);
			clmPIDetails.setClmKycId2(kycId[1]);
			clmPIDetails.setClmKycIdNumber2(kycDocuments2);
		} else {
			clmPIDetails.setClmKycId2(null);
			clmPIDetails.setClmKycIdNumber2(null);
		}
		return clmPIDetails;
	}

	/**
	 * PREPARE POLICY DETAILS REQUEST
	 *
	 * @param holderRequest
	 * @param policyDetailsRequest
	 * @return
	 */
	public static PolicyDetailsRequest preparePolicyDetailsRequest(UpdateClaimAccountHolderRequest holderRequest,PolicyDetailsRequest policyDetailsRequest) {
		policyDetailsRequest.setAccountNumber(holderRequest.getAccountNumber());
		policyDetailsRequest.setAccountHolderName(holderRequest.getAccountHolderName());
		policyDetailsRequest.setCif(holderRequest.getCif());
		policyDetailsRequest.setUrn(holderRequest.getUrn());
		policyDetailsRequest.setOrgId(holderRequest.getOrgId());
		if(!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateAndTimeOfAccident())) {
			policyDetailsRequest.setTranDetailsReqdDate(holderRequest.getDateAndTimeOfAccident().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		}else if(!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateOfDeath())) {
			policyDetailsRequest.setTranDetailsReqdDate(holderRequest.getDateOfDeath().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		}
		return policyDetailsRequest;
	}

	
	private static String getKycDoc(Integer kycId, ClaimMasterRequest req) {
		String val = null;
		if (Objects.equals(KycDocument.PAN.getId(), kycId)) {
			val = req.getPan();
		} else if (Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
			val = req.getPaasport();
		} else if (Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
			val = req.getDrivingLicence();
		} else if (Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
			val = req.getMgnregaCard();
		} else if (Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
			val = req.getVoterIdCard();
		}
		return val;
	}

	/**
	 * SET POLICY DETAILS INTO API CLAIM MASTER TABLE SET
	 *
	 * @param appMaster
	 * @param authClientResponse
	 * @param schemeId
	 * @return
	 */
	public static ClmMaster setClaimMasterV2(ApplicationMasterBothSchemeProxy appMaster, AuthClientResponse authClientResponse,Integer schemeId) {
		ClmMaster clmMaster = new ClmMaster();
		clmMaster.setUrn(appMaster.getUrn());
		clmMaster.setApplicationId(appMaster.getId());
		clmMaster.setOrgId(appMaster.getOrgId());
		clmMaster.setSchemeId(schemeId);
		clmMaster.setBranchId(authClientResponse.getUserBranchId());
		clmMaster.setStatus(ClaimStatus.CLAIM_IN_PROGRESS.getId());
		clmMaster.setStageId(ClaimStageMaster.CLAIM_FORM.getStageId());
		clmMaster.setIsActive(Boolean.TRUE);
		clmMaster.setInsurerOrgId(appMaster.getInsurerOrgId());
		clmMaster.setFirstEnrollmentDate(appMaster.getEnrollmentDate());
		clmMaster.setCreatedBy(authClientResponse.getUserId());
		clmMaster.setCreatedDate(new Date());
		if(Objects.equals(authClientResponse.getUserType(), UserTypeMaster.FUNDPROVIDER.getId())) {			
			clmMaster.setSource(Source.JANSURAKSHA.getId());
		}
		return clmMaster;
	}


	/**
	 * SET POLICY DETAILS INTO API CLAIM DETAILS TABLE SET
	 *
	 * @param clmMaster
	 * @param map
	 * @param emailId
	 * @param applicantInfo
	 * @param holderRequest
	 * @param transactionDetailsV2
	 * @param addressMasterV2
	 * @return
	 */
	public static ClmDetails setClaimDetailsV2(ClmMaster clmMaster,Map<String, Object> map,String emailId,ApplicantInfoV2 applicantInfo, Integer genderId,UpdateClaimAccountHolderRequest holderRequest,TransactionDetailsV2 transactionDetailsV2,AddressMasterV2 addressMasterV2) {
		ClmDetails clmDetails = new ClmDetails();
		clmDetails.setId(clmMaster.getId());
		clmDetails.setApEmail(applicantInfo.getEmail());
		clmDetails.setApMobileNumber(applicantInfo.getMobileNumber());
		if(!OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
			clmDetails.setApDisabilityDetails(applicantInfo.getDisabilityDetails());
			clmDetails.setApDisabilityStatus(applicantInfo.getDisabilityStatus());
//			clmDetails.setApFatherHusbandName(applicantInfo.getFatherHusbandName()); // ravi
		}
		clmDetails.setApCustomerIfsc(applicantInfo.getIfsc());
		clmDetails.setApTransactionUTR(transactionDetailsV2.getTransUtr());
		clmDetails.setApTransactionAmount(transactionDetailsV2.getTransAmount());
		clmDetails.setBranchCode(OPLUtils.isObjectNullOrEmpty(map.get("branchCode")) ? null : map.get("branchCode").toString());
		clmDetails.setBranchEmailId(emailId);
		clmDetails.setApTransactionTimestamp(transactionDetailsV2.getTransTimeStamp());
		if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateOfDeath())) {
			clmDetails.setDateOfDeath(holderRequest.getDateOfDeath());
			clmDetails.setIsDateOfDeath(true);
		} else if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateAndTimeOfAccident())) {
			clmDetails.setDateTimeOfAccident(holderRequest.getDateAndTimeOfAccident());
			clmDetails.setIsDateTimeOfAccident(true);
		}
		clmDetails.setNatureOfLossId(holderRequest.getNatureOfLoss());

		ClmAddressMaster addressMaster = new ClmAddressMaster();
//		addressMaster.setCityId(policyDetails.getCityId());
//		addressMaster.setCityLGDCode(address.getCityLGDCode());
		addressMaster.setCityName(addressMasterV2.getCityName());
		addressMaster.setDistrict(addressMasterV2.getDistrict());
//		addressMaster.setDistrictLGDCode(policyDetails.getDistrictLGDCode());
		addressMaster.setPincode(addressMasterV2.getPincode().intValue());
//		addressMaster.setStateId(policyDetails.getStateId());
//		addressMaster.setStateLGDCode(address.getStateLGDCode());
		addressMaster.setStateName(addressMasterV2.getStateName());
		clmDetails.setApAddressMaster(addressMaster);
		clmDetails.setClmMaster(clmMaster);
		clmDetails.setApGenderId(genderId);
		return clmDetails;
	}

	/**
	 * SET POLICY DETAILS REQUEST AND RESPONSE INTO API CLAIM PI DETAILS TABLE SET
	 *
	 * @param clmMaster
	 * @param applicantPIInfo
	 * @param addressMasterV2
	 * @return
	 */
	public static ClmPIDetails setClaimPIDetailsV2(ClmMaster clmMaster,ApplicantPIDetails applicantPIInfo,AddressMasterV2 addressMasterV2) {
		ClmPIDetails clmPIDetails = new ClmPIDetails();
		clmPIDetails.setId(clmMaster.getId());
		clmPIDetails.setApAccountNumber(applicantPIInfo.getAccountNumber());
		clmPIDetails.setApCif(applicantPIInfo.getCif());
		clmPIDetails.setApFirstName(applicantPIInfo.getFirstName());
		clmPIDetails.setApMiddleName(applicantPIInfo.getMiddleName());
		clmPIDetails.setApLastName(applicantPIInfo.getLastName());
		clmPIDetails.setAcHolderName(applicantPIInfo.getAcHolderName());
		clmPIDetails.setApKycId1(applicantPIInfo.getKycId1());
		clmPIDetails.setApKycIdNumber1(applicantPIInfo.getKycIdNumber1());
		clmPIDetails.setApPan(applicantPIInfo.getPan());
		clmPIDetails.setApAadhaar(applicantPIInfo.getAadhaar());
		clmPIDetails.setApCkycNumber(applicantPIInfo.getCkycNumber());
		clmPIDetails.setApDob(applicantPIInfo.getDob());
//		clmPIDetails.setApGenderId(genderId);
		clmPIDetails.setApAddressLine1(applicantPIInfo.getAddressLine1());
		clmPIDetails.setApAddressLine2(applicantPIInfo.getAddressLine2());
		clmPIDetails.setApFatherHusbandName(applicantPIInfo.getFatherHusbandName());
		return clmPIDetails;
	}

	/**
	 * 	SET POLICY DETAILS RESPONSE INTO API CLAIM NOMINEE AND GUARDIAN
	 * 	TABLE SET
	 *
	 * @param clmMaster
	 * @param nomineeDetailsV2
	 * @param nomineePIDetailsV2
	 * @param nomineeAddMasterV2
	 * @return
	 */
	public static ClmNomineeDetails setNomineeAndGuardianDetailsV2(ClmMaster clmMaster,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetailsV2,AddressMasterV2 nomineeAddMasterV2) {
		ClmNomineeDetails clmNomineeDetails = new ClmNomineeDetails();
		clmNomineeDetails.setRelationId(nomineeDetailsV2.getRelationId());
		clmNomineeDetails.setMobileNumber(nomineeDetailsV2.getMobileNumber());
		clmNomineeDetails.setEmail(nomineeDetailsV2.getEmail());
		clmNomineeDetails.setIsActive(Boolean.TRUE);

		ClmNomineePIDetails clmNomineePIDetails = new ClmNomineePIDetails();
		clmNomineePIDetails.setFirstName(nomineePIDetailsV2.getFirstName());
		clmNomineePIDetails.setMiddleName(nomineePIDetailsV2.getMiddleName());
		clmNomineePIDetails.setLastName(nomineePIDetailsV2.getLastName());
		clmNomineePIDetails.setName(nomineePIDetailsV2.getName());
		clmNomineePIDetails.setDob(nomineePIDetailsV2.getDob());

		clmNomineePIDetails.setAddressLine1(nomineePIDetailsV2.getAddressLine1());
		clmNomineePIDetails.setAddressLine2(nomineePIDetailsV2.getAddressLine2());

		ClmAddressMaster clmAddressMaster = new ClmAddressMaster();
		clmAddressMaster.setCityId(nomineeAddMasterV2.getCityId());
		clmAddressMaster.setCityLGDCode(nomineeAddMasterV2.getCityLGDCode());
		clmAddressMaster.setCityName(nomineeAddMasterV2.getCityName());
		clmAddressMaster.setDistrict(nomineeAddMasterV2.getDistrict());
		clmAddressMaster.setDistrictLGDCode(nomineeAddMasterV2.getDistrictLGDCode());
		clmAddressMaster.setPincode(nomineeAddMasterV2.getPincode());
		clmAddressMaster.setStateId(nomineeAddMasterV2.getStateId());
		clmAddressMaster.setStateLGDCode(nomineeAddMasterV2.getStateLGDCode());
		clmAddressMaster.setStateName(nomineeAddMasterV2.getStateName());
		clmNomineeDetails.setClmAddressMaster(clmAddressMaster);
		clmNomineeDetails.setClmMaster(clmMaster);
		clmNomineePIDetails.setClmNomineeDetails(clmNomineeDetails);

		clmNomineeDetails.setGdRelationId(nomineeDetailsV2.getGdRelationId());
		clmNomineeDetails.setGdMobile(nomineeDetailsV2.getGdMobile());
		clmNomineeDetails.setEmail(nomineeDetailsV2.getGdEmail());
		clmNomineeDetails.setGdEmail(nomineeDetailsV2.getGdEmail());
		clmNomineePIDetails.setGdName(nomineePIDetailsV2.getName());
		clmNomineePIDetails.setGdAddress(nomineePIDetailsV2.getGdAddress());
		clmNomineeDetails.setClmNomineePIDetails(clmNomineePIDetails);
		return clmNomineeDetails;
	}

}
