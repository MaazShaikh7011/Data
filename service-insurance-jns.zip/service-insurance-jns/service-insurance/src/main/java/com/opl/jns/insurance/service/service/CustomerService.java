package com.opl.jns.insurance.service.service;

import java.util.List;
import java.util.Map;

import com.opl.jns.insurance.api.model.*;
import com.opl.jns.utils.common.*;

public interface CustomerService {

    public String getConsentDetails(Long applicationId);

    CommonResponse getEnrollmentList(EnrollmentListRequest request, Long userId) throws Exception;
    
    public List<Map<Long, String>> getOrganisationListByUserTypeId(Long userTypeId);

    public CommonResponse getDashboardEnrollmentList(Long userId) throws Exception;

    public List<Map<String, String>> getOrganisationAndInsurerListByUserTypeId(Long userTypeId);
}
