package com.opl.jns.insurance.service.schedulers;
//package com.opl.service.insurance.jns.schedulers;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Map.Entry;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import com.opl.service.insurance.jns.service.impl.BranchUpdateServiceImpl;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author - Maaz Shaikh
// * @Date - 6/26/2023
// */
//@Component
//@Slf4j
//public class BranchUpdateScheduler {
//
//	@Autowired
//	BranchUpdateServiceImpl branchUpdateService;
//
//	public static Map<Long, Integer> orgList;
//
//	static {
//		orgList = new HashMap<>();
////		orgList.put(1l, 0);
////		orgList.put(4l, 0);
////		orgList.put(12l, 0);
//		orgList.put(13l, 0);
////		orgList.put(14l, 0);
//		orgList.put(17l, 0);
//		orgList.put(18l, 0);
////		orgList.put(19l, 0);
////		orgList.put(20l, 0);
//		orgList.put(25l, 0);
//		orgList.put(27l, 0);
//		orgList.put(32l, 0);
//		orgList.put(16l, 0);
////    	orgList = Arrays.asList(16L,1L,4L,12L,13L,14L,17L,18L,19L,20L,25L,27L,32L);
//	}
//
////	@Scheduled(cron = "0 */59 * * * *")
//	@Scheduled(cron = "${branch.data.insert.schedular}")
//	public void pushApplicationsInCaseOfNotPushed() {
//		log.info("Scheduler started on {}", new Date());
//		Long orgId = getOrgId();
//		branchUpdateService.updateBranchIsInApplication(orgId);
//		updateOrgId(orgId);
//		log.info("Scheduler ended  on {}", new Date());
//	}
//
//	private Long getOrgId() {
//		Set<Entry<Long, Integer>> entrySet = orgList.entrySet();
//		for (Entry<Long, Integer> et : entrySet) {
//			if (et.getValue() == 0) {
//				return et.getKey();
//			}
//		}
//		return null;
//	}
//
//	private void updateOrgId(Long orgId) {
//		orgList.put(orgId, 1);
//	}
//}
