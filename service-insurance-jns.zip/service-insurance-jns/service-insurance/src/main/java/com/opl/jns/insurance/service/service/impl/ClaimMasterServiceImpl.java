package com.opl.jns.insurance.service.service.impl;
//package com.opl.service.insurance.jns.service.impl;
//
//
//
//import java.text.ParseException;
//import java.time.LocalDate;
//import java.time.ZoneId;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.LinkedHashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Objects;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.BeanUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.client.RestTemplate;
//
//import com.opl.api.banker.model.dedupe.DedupeRequest;
//import com.opl.api.dd.jns.model.dedupe.ClaimDedupApiResponse;
//import com.opl.jns.api.insurance.exception.InsuranceException;
//import com.opl.jns.api.insurance.model.AccountHolderMappingRequest;
//import com.opl.jns.api.insurance.model.AddressMasterRequest;
//import com.opl.jns.api.insurance.model.ClaimDeDupeDetailsProxy;
//import com.opl.jns.api.insurance.model.ClaimMasterRequest;
//import com.opl.jns.api.insurance.model.ClaimRequest;
//import com.opl.jns.api.insurance.model.ClaimStatusRequest;
//import com.opl.jns.api.insurance.model.NomineeDetailsRequest;
//import com.opl.jns.api.insurance.model.v2.ClaimDashboardViewV2;
//import com.opl.jns.common.api.auth.model.AuthClientResponse;
//import com.opl.jns.common.api.notification.utils.JnsNotificationMasterUtil;
//import com.opl.jns.common.api.oneform.exception.OneFormException;
//import com.opl.jns.common.api.oneform.utils.DropDownMasterKey;
//import com.opl.jns.common.client.oneform.OneFormClient;
//import com.opl.jns.common.client.user.management.UserManagementClient;
//import com.opl.jns.common.client.users.UsersClient;
//import com.opl.jns.config.utils.ConfigProperties;
//import com.opl.jns.ere.domain.AddressMasterV3;
//import com.opl.jns.ere.domain.ApplicationMasterV3;
//import com.opl.jns.ere.domain.ClaimDetailV3;
//import com.opl.jns.ere.domain.ClaimMasterV3;
//import com.opl.jns.ere.domain.ClaimStatusWebhookAudit;
//import com.opl.jns.ere.domain.MiscellaneousAudit;
//import com.opl.jns.ere.domain.NomineeDetails;
//import com.opl.jns.ere.domain.PushReTryAudit;
//import com.opl.jns.ere.enums.CauseOfDeathDisability;
//import com.opl.jns.ere.enums.KycDocument;
//import com.opl.jns.ere.enums.NatureOfLoss;
//import com.opl.jns.ere.enums.NomineeType;
//import com.opl.jns.ere.enums.RelationShip;
//import com.opl.jns.ere.enums.TypeOfDisability;
//import com.opl.jns.ere.enums.WebhookMasterEnum;
//import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
//import com.opl.jns.ere.repo.ClaimDeDupeDetailsRepository;
//import com.opl.jns.ere.repo.ClaimMasterRepoV3;
//import com.opl.jns.ere.repo.ClaimStatusWebhookAuditRepository;
//import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
//import com.opl.jns.ere.repo.NomineeDetailsRepositoryV3;
//import com.opl.jns.ere.repo.PushReTryAuditRepo;
//import com.opl.jns.insurance.api.published.publish.claim_dedupe_req_res.ClaimDeDupeDetails;
//import com.opl.jns.utils.common.CommonErrorMsg;
//import com.opl.jns.utils.common.CommonResponse;
//import com.opl.jns.utils.common.DateUtils;
//import com.opl.jns.utils.common.OPLUtils;
//import com.opl.jns.utils.enums.ClaimStageMaster;
//import com.opl.jns.utils.enums.ClaimStatus;
//import com.opl.jns.utils.enums.EnrollStageMaster;
//import com.opl.jns.utils.enums.MiscellaneousType;
//import com.opl.jns.utils.enums.SchemeMaster;
//import com.opl.service.insurance.jns.domain.ExpSchedulerAudit;
//import com.opl.service.insurance.jns.repository.ExpSchedulerAuditRepo;
//import com.opl.service.insurance.jns.service.ApplicationMasterService;
//import com.opl.service.insurance.jns.service.ClaimMasterService;
//import com.opl.service.insurance.jns.utils.CommonUtils;
//import com.opl.service.insurance.jns.utils.ExpSchedulerApiEnum;
//import com.opl.service.insurance.jns.utils.NotificationUtil;
//import com.opl.service.insurance.jns.utils.ResponseStatus;
//import com.opl.service.insurance.jns.utils.dedupe.DeDupeRegistryUtility;
//
//import lombok.extern.slf4j.Slf4j;
//
//
//
///***
// * 
// * @author paresh.radadiya , Maaz Shaikh
// * Date : 02-05-2023
// */
//
//@Slf4j
//@Service	
//@Transactional
//public class ClaimMasterServiceImpl implements ClaimMasterService {
//
//    public static final String PMJJBY_CLAIM_AGE_LIMIT = "PMJJBY_CLAIM_AGE_LIMIT";
//    public static final String PMSBY_CLAIM_AGE_LIMIT = "PMSBY_CLAIM_AGE_LIMIT";
//    public static final String PUSH_CLAIM_REVISED_DOCS = "PUSH_CLAIM_REVISED_DOCS";
//	
//	
//	@Autowired
//	private ClaimMasterRepoV3 claimMasterRepo;
//	
//	@Autowired
//	private ApplicationMasterRepositoryV3 applicationMasterRepo;
//	
//	@Autowired
//	private OneFormClient oneFormClient;
//
//	@Autowired
//	private NomineeDetailsRepositoryV3 nomineeDetailsRepository;
//	
//    @Autowired
//    public ApplicationMasterRepositoryV3 masterRepository;
//
//    @Autowired
//    private ConfigProperties properties;
//
//    @Autowired
//    private UsersClient usersClient;
//
//	@Autowired
//	private PushReTryAuditRepo pushReTryAuditRepo;
//
//    @Autowired
//    private ApplicationMasterService applicationMasterService;
//    
//	@Autowired
//	private UserManagementClient userManagementClient;
//	
//	@Autowired
//	private NotificationUtil notificationUtil;
//	
//	@Autowired
//	private ClaimStatusWebhookAuditRepository webhookAuditRepository;
//	
//	@Autowired
//	private MiscellaneousAuditRepository miscellaneousAuditRepository;
//	
//	@Autowired
//	private ExpSchedulerAuditRepo expSchedulerAuditRepo;
//	
//	@Autowired
//	private DeDupeRegistryUtility deDupeRegistryUtility;
//
//	@Autowired
//	private ClaimDeDupeDetailsRepository claimDeDupeDetailsRepository;
//
//	@Override
//	public CommonResponse getAccountHoldersList(ClaimRequest claimRequest, AuthClientResponse authClientResponse) {
//		try {
//			
//			List<ApplicationMasterV3> accountHolderDetails = applicationMasterRepo
//					.findAllByOrgIdAndSchemeIdAndIsActiveTrueAndAccountNumberAndStageId(authClientResponse.getUserOrgId(),
//							claimRequest.getSchemeId().intValue(),claimRequest.getAccountValue(), EnrollStageMaster.COMPLETED.getStageId());
//			if (accountHolderDetails.isEmpty()) {
//				accountHolderDetails = applicationMasterRepo.findAllByOrgIdAndSchemeIdAndUrnAndIsActiveTrueAndStageId(authClientResponse.getUserOrgId(),
//								claimRequest.getSchemeId().intValue(), claimRequest.getAccountValue(), EnrollStageMaster.COMPLETED.getStageId());
//				if (accountHolderDetails.isEmpty()) {
//					log.info("Data not found from account holder details");
//					return new CommonResponse("We are unable to find policy holder details for given account number / URN!!",
//							HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//				}
//			}
//
//			List<AccountHolderMappingRequest> holderMappingRequests = new ArrayList<>(accountHolderDetails.size());
//			AccountHolderMappingRequest accountHolderMappingRequest = null;
//			for (ApplicationMasterV3 applicationMaster: accountHolderDetails) {
//				accountHolderMappingRequest = new AccountHolderMappingRequest();
//				accountHolderMappingRequest.setCif(applicationMaster.getCif());
//				accountHolderMappingRequest.setAccountHolderName(applicationMaster.getApplicantInfo().getName());
//				accountHolderMappingRequest.setApplicationId(applicationMaster.getId());
//				accountHolderMappingRequest.setCustomerAccountNumber(applicationMaster.getAccountNumber());
//				accountHolderMappingRequest.setUrnCode(applicationMaster.getUrn());
//				holderMappingRequests.add(accountHolderMappingRequest);
//			}
//			return new CommonResponse(CommonErrorMsg.Common.SUCCESS, holderMappingRequests, HttpStatus.OK.value(),
//					true);
//
//		} catch (Exception e) {
//			log.error("Exception is getting while get account holder Details", e);
//			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//					false);
//		}
//	}
//	@Override
//	public ClaimMasterRequest getClaimFromDetails(Long claimId) throws OneFormException {
//
//		ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//			return null;
//		}
//		ClaimMasterRequest claimMasterReq = new ClaimMasterRequest();
//		if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail())) {			
//			ApplicationMasterV3 applicationMaster=applicationMasterRepo.findByIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId());
//			claimMasterReq.setClaimStatus(claimMaster.getClaimStatus());
//			claimMasterReq.setUrnCode(applicationMaster.getUrn());
//			claimMasterReq.setApplicationId(claimMaster.getApplicationMaster().getId());
//			claimMasterReq.setIsClaimantSame(claimMaster.getIsClaimantSame());
//			claimMasterReq.setIsNomineeSame(claimMaster.getClaimDetail().getIsNomineeSame());
//			claimMasterReq.setDateAndTimeOfAccident(claimMaster.getClaimDetail().getDateTimeOfAccident());
//			claimMasterReq.setDayOfAccident(claimMaster.getClaimDetail().getDayOfAccident());
//			claimMasterReq.setDateOfDeath(claimMaster.getClaimDetail().getDateOfDeath());
//			claimMasterReq.setLocationOfLoss(claimMaster.getClaimDetail().getLocationOfLoss());
//			claimMasterReq.setLossLocationPincode(claimMaster.getClaimDetail().getLossLocationPincode());
//			claimMasterReq.setNatureOfLoss(claimMaster.getClaimDetail().getNatureOfLossId());
//			claimMasterReq.setCauseOfDeathDisability(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId());
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//				claimMasterReq.setTypeOfDisablity(claimMaster.getClaimDetail().getTypeOfDisablityId().longValue());
//			}
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//				String typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,claimMaster.getClaimDetail().getTypeOfDisablityId());
//				claimMasterReq.setTypeOfDisablityValue(typeOfDisability);
//			}
//			claimMasterReq.setFirNo(claimMaster.getClaimDetail().getFirNo());
//			claimMasterReq.setClaimantBankAcNumber(claimMaster.getClaimDetail().getClaimantBankAccountNumber());
////			claimMasterReq.setBranchIfscCode(claimMaster.getClaimDetail().getBranchIfscCode());
//			claimMasterReq.setCustIfscCode(claimMaster.getClaimDetail().getCustIfscCode());
//			claimMasterReq.setNameOfBank(claimMaster.getClaimDetail().getNameOfBank());
//			claimMasterReq.setClaimantKycDetails(claimMaster.getClaimDetail().getClaimantKycDetails());
//			claimMasterReq.setPan(claimMaster.getClaimDetail().getPan());
//			claimMasterReq.setAadhar(claimMaster.getClaimDetail().getAadhar());
//			claimMasterReq.setPaasport(claimMaster.getClaimDetail().getPassport());
//			claimMasterReq.setDrivingLicence(claimMaster.getClaimDetail().getDrivingLicense());
//			claimMasterReq.setMgnregaCard(claimMaster.getClaimDetail().getMgnerega());
//			claimMasterReq.setVoterIdCard(claimMaster.getClaimDetail().getVottingCardId());
//			claimMasterReq.setKycDocId(claimMaster.getClaimDetail().getKycDocId());
//			try {
//				Integer docTypeId = null;
//				String docTitle = null;
//				if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//					if (applicationMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue()
//							&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())) {
//						docTitle = getValueById(DropDownMasterKey.NATURE_OF_LOSS,claimMaster.getClaimDetail().getNatureOfLossId());
//						docTypeId = claimMaster.getClaimDetail().getNatureOfLossId();
//					} else if (applicationMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()
//							&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId())) {
////						docTitle = getValueById(DropDownMasterKey.CAUSE_OF_DEATH,claimMaster.getClaimDetail().getCauseOfDeathDisabilityId());
//						docTitle = CauseOfDeathDisability.fromId(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()).getValue();
//						docTypeId = claimMaster.getClaimDetail().getCauseOfDeathDisabilityId();
//					}
//				}
//				claimMasterReq.setDocTypeId(docTypeId);
//				claimMasterReq.setDocTitle(docTitle);
//			} catch (Exception e) {
//				log.error("Exception is getting while get value from one form client", e);
//			}
//		}
//
//		// GET CLAIM MASTER DATA
//		claimMasterReq.setApplicationId(claimMaster.getApplicationMaster().getId());
//		claimMasterReq.setUrnCode(claimMaster.getApplicationMaster().getUrn());
//
//		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame())
//				&& claimMaster.getIsClaimantSame().equals(Boolean.TRUE)) {
//			// GET NOMINEE DATA
//			List<Integer> claimantAndGuardianType = new ArrayList<>();
//			claimantAndGuardianType.add(2);
//			claimantAndGuardianType.add(3);
//			List<NomineeDetails> claimantAndGuardianDataLst = nomineeDetailsRepository.findByApplicationMasterIdAndTypeInAndIsActiveTrue(claimMaster.getApplicationMaster().getId(), claimantAndGuardianType);
//			NomineeDetailsRequest nomineeReq = new NomineeDetailsRequest();
//			if (!OPLUtils.isListNullOrEmpty(claimantAndGuardianDataLst)) {
//			for(NomineeDetails claimantAndGuardianData : claimantAndGuardianDataLst) {
//				if(claimantAndGuardianData.getType()==2) {					
//					BeanUtils.copyProperties(claimantAndGuardianData, nomineeReq);
//					nomineeReq.setDateOfBirth(claimantAndGuardianData.getDob());
//					nomineeReq.setEmailIdOfNominee(claimantAndGuardianData.getEmail());
//					if(!OPLUtils.isObjectNullOrEmpty(claimantAndGuardianData.getRelationId())) {
//						nomineeReq.setRelationOfNomineeApplicant(claimantAndGuardianData.getRelationId());
//						String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,claimantAndGuardianData.getRelationId());
//						nomineeReq.setRelationOfNomineeApplicantStr(relationShip);
//					}
//					AddressMasterRequest masterRequest=new AddressMasterRequest();
//					BeanUtils.copyProperties(claimantAndGuardianData.getAddress(), masterRequest);
//					masterRequest.setCity(claimantAndGuardianData.getAddress().getCityName());
//					masterRequest.setState(claimantAndGuardianData.getAddress().getStateName());
//					nomineeReq.setAddress(masterRequest);
//				}
//				if(claimantAndGuardianData.getType()==3) {					
//						if(!OPLUtils.isObjectNullOrEmpty(claimantAndGuardianData.getRelationId())) {					
//							nomineeReq.setRelationShipOfGuardian(claimantAndGuardianData.getRelationId());
//							String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,claimantAndGuardianData.getRelationId());
//							nomineeReq.setRelationShipOfGuardianStr(relationShip);
//							nomineeReq.setNameOfGuardian(claimantAndGuardianData.getName());
////							nomineeReq.setAddressOfGuardian(claimantAndGuardianData.getAddressId());
//							nomineeReq.setMobileNumberOfGuardian(claimantAndGuardianData.getMobileNumber());
//							nomineeReq.setEmailIdOfGuardian(claimantAndGuardianData.getEmail());
//					}
//				}
//				}
//			}
//			claimMasterReq.setNomineeData(nomineeReq);
//		}
//		return claimMasterReq;
//	}
//	@Override
//	public CommonResponse saveClaimFormDetails(ClaimMasterRequest req) {
//
//		if (OPLUtils.isObjectNullOrEmpty(req.getId())) {
//			return new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING,
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//		// UPDATE CLAIM DETAILS
//		ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(req.getId());
//		if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//			return new CommonResponse("Its seems we have not found claim details by given claim reference number",
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//
//		// UPDATE ENROLLMENT NOMINEE MOBILE NUMBER
//		if (!OPLUtils.isObjectNullOrEmpty(claimMaster) && !OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getId())) {
////				NomineeDetails alreadyExists = nomineeDetailsRepository
////						.findByTypeAndApplicationMasterIdAndIsActiveTrue("2",claimMaster.getApplicationMaster().getId());
//				List<Integer> claimantAndGuardianType = new ArrayList<>();
//				claimantAndGuardianType.add(NomineeType.NOMINEE.getId());
//				claimantAndGuardianType.add(NomineeType.GUARDIAN.getId());
//				claimantAndGuardianType.add(NomineeType.CLAIMANT.getId());
//				List<NomineeDetails> nomineeAndclaimantAndGuardianDataLst = nomineeDetailsRepository.findByApplicationMasterIdAndTypeInAndIsActiveTrue(claimMaster.getApplicationMaster().getId(), claimantAndGuardianType);
//				if(!OPLUtils.isListNullOrEmpty(nomineeAndclaimantAndGuardianDataLst)) {
//					for(NomineeDetails nomineeAndclaimantAndGuardianData : nomineeAndclaimantAndGuardianDataLst) {
//						boolean isUpdate = false;
//						if(nomineeAndclaimantAndGuardianData.getType().equals(NomineeType.NOMINEE.getId())) {
////							if(!OPLUtils.isObjectNullOrEmpty(req.getRelationOfNomineeApplicantStr())) {
////								alreadyExists.setRelationOfNomineeApplicant(req.getRelationOfNomineeApplicantStr());
////								isUpdate = true;
////							}
//							if (!OPLUtils.isObjectNullOrEmpty(req.getCorrectNomineeFirstName())) {
//								nomineeAndclaimantAndGuardianData.setCorrectNomineeFirstName(req.getCorrectNomineeFirstName());
//								isUpdate = true;
//							}
//							if (!OPLUtils.isObjectNullOrEmpty(req.getCorrectNomineeMiddleName())) {
//								nomineeAndclaimantAndGuardianData.setCorrectNomineeMiddleName(req.getCorrectNomineeMiddleName());
//								isUpdate = true;
//							}
//							if (!OPLUtils.isObjectNullOrEmpty(req.getCorrectNomineeLastName())) {
//								nomineeAndclaimantAndGuardianData.setCorrectNomineeLastName(req.getCorrectNomineeLastName());
//								isUpdate = true;
//							}
//							if ((!OPLUtils.isObjectNullOrEmpty(req.getMobileOfNominee()) && OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getMobileNumber())) || 
//									(!OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getMobileNumber()) && !nomineeAndclaimantAndGuardianData.getMobileNumber().equals(req.getMobileOfNominee()))) {
//								nomineeAndclaimantAndGuardianData.setMobileNumber(req.getMobileOfNominee());
//								isUpdate = true;
//							}
//							if ((!OPLUtils.isObjectNullOrEmpty(req.getEmailOfNominee()) && OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getEmail())) ||
//									(!OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getEmail()) && !nomineeAndclaimantAndGuardianData.getEmail().equals(req.getEmailOfNominee()))) {
//								nomineeAndclaimantAndGuardianData.setEmail(req.getEmailOfNominee());
//								isUpdate = true;
//							}
//							if (isUpdate) {
//								nomineeAndclaimantAndGuardianData.setModifiedBy(req.getModifiedBy());
//								nomineeAndclaimantAndGuardianData.setModifiedDate(new Date());
//								nomineeDetailsRepository.save(nomineeAndclaimantAndGuardianData);
//							}
//						}
//						if(nomineeAndclaimantAndGuardianData.getType().equals(NomineeType.GUARDIAN.getId())) {
//							if ((!OPLUtils.isObjectNullOrEmpty(req.getMobileNumberOfGuardian()) && OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getMobileNumber())) || 
//									(!OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getMobileNumber()) && !nomineeAndclaimantAndGuardianData.getMobileNumber().equals(req.getMobileNumberOfGuardian()))) {
//								nomineeAndclaimantAndGuardianData.setMobileNumber(req.getMobileNumberOfGuardian());
//								isUpdate = true;
//							}
//							if ((!OPLUtils.isObjectNullOrEmpty(req.getEmailIdOfGuardian()) && OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getEmail())) ||
//									(!OPLUtils.isObjectNullOrEmpty(nomineeAndclaimantAndGuardianData.getEmail()) && !nomineeAndclaimantAndGuardianData.getEmail().equals(req.getEmailIdOfGuardian()))) {
//								nomineeAndclaimantAndGuardianData.setEmail(req.getEmailIdOfGuardian());
//								isUpdate = true;
//							}	
//							if (isUpdate) {
//								nomineeAndclaimantAndGuardianData.setModifiedBy(req.getModifiedBy());
//								nomineeAndclaimantAndGuardianData.setModifiedDate(new Date());
//								nomineeDetailsRepository.save(nomineeAndclaimantAndGuardianData);
//							}
//						}
//					}
//				}
//
//				NomineeDetails claimantData = nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(claimMaster.getApplicationMaster().getId(), NomineeType.CLAIMANT.getId());
//				if (!OPLUtils.isObjectNullOrEmpty(req.getIsClaimantSame()) && req.getIsClaimantSame().equals(Boolean.TRUE)) {
//					AddressMasterV3 alreadyExistsAdd = null;
//					if (!OPLUtils.isObjectNullOrEmpty(req.getNomineeData())) {
//						if(!OPLUtils.isObjectNullOrEmpty(claimantData)) {
//							alreadyExistsAdd = claimantData.getAddress();
//						}else {
//							alreadyExistsAdd = new AddressMasterV3();
//						}
//						// SAVE ADDRESS DETAILS
//						AddressMasterRequest address = req.getNomineeData().getAddress();
//						alreadyExistsAdd.setAddressLine1(address.getAddressLine1());
//						alreadyExistsAdd.setAddressLine2(address.getAddressLine2());
//						alreadyExistsAdd.setPincode(address.getPincode());
//						alreadyExistsAdd.setCityLGDCode(address.getCityLgdCode());
//						alreadyExistsAdd.setCityId(address.getCityId());
//						alreadyExistsAdd.setDistrict(address.getDistrict());
//						alreadyExistsAdd.setCityName(address.getCity());
//						alreadyExistsAdd.setStateName(address.getState());
//						alreadyExistsAdd.setStateId(address.getStateId());
//						alreadyExistsAdd.setStateLGDCode(address.getStateLgdCode());
//						if (!OPLUtils.isObjectNullOrEmpty(address.getPincode())) {
//							alreadyExistsAdd.setPincode(address.getPincode());
//						}
//						// SAVE NOMINEE DETAILS
//						if (!OPLUtils.isObjectNullOrEmpty(claimantData)) {
//							claimantData.setModifiedDate(new Date());
//							claimantData.setModifiedBy(req.getModifiedBy());
//						} else {
//							claimantData=new NomineeDetails();
//							claimantData.setApplicationMaster(applicationMasterRepo.findByIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId()));
//							claimantData.setIsOtherClaimant(true);
//							claimantData.setCreatedDate(new Date());
//							claimantData.setCreatedBy(req.getModifiedBy());
//							claimantData.setIsActive(true);
//						}
//						claimantData.setAddress(alreadyExistsAdd);
//						NomineeDetailsRequest nominee = req.getNomineeData();
//						claimantData.setFirstName(nominee.getFirstName());
//						claimantData.setMiddleName(nominee.getMiddleName());
//						claimantData.setLastName(nominee.getLastName());
//						claimantData.setDob(nominee.getDateOfBirth());
//						claimantData.setMobileNumber(nominee.getMobileNumber());
//						claimantData.setRelationId(nominee.getRelationOfNomineeApplicant());
//						claimantData.setType(NomineeType.CLAIMANT.getId());
//						claimantData.setEmail(nominee.getEmailIdOfNominee());
//						nomineeDetailsRepository.save(claimantData);
//				}
//			}
//
//			}
//
//			claimMaster.setIsClaimantSame(req.getIsClaimantSame());
//			ClaimDetailV3 claimDetail = claimMaster.getClaimDetail();
//			if(OPLUtils.isObjectNullOrEmpty(claimDetail)) {
//				claimDetail = new ClaimDetailV3();
//			}
//			claimDetail.setDateTimeOfAccident(req.getDateAndTimeOfAccident());	
//			claimDetail.setDayOfAccident(req.getDayOfAccident());
//			claimDetail.setDateOfDeath(req.getDateOfDeath());
//			claimDetail.setLocationOfLoss(req.getLocationOfLoss());
//			claimDetail.setLossLocationPincode(req.getLossLocationPincode());
//			claimDetail.setNatureOfLossId(req.getNatureOfLoss());
//			claimDetail.setCauseOfDeathDisabilityId(req.getCauseOfDeathDisability());
//			claimDetail.setTypeOfDisablityId(!OPLUtils.isObjectNullOrEmpty(req.getTypeOfDisablity()) ? req.getTypeOfDisablity().intValue():null);
//			claimDetail.setFirNo(req.getFirNo());
//			claimDetail.setKycDocId(req.getKycDocId());
//			claimDetail.setClaimantBankAccountNumber(req.getClaimantBankAcNumber());
////			claimDetail.setBranchIfscCode(req.getBranchIfscCode());
//			claimDetail.setCustIfscCode(req.getCustIfscCode());
//			claimDetail.setNameOfBank(req.getNameOfBank());
//			
//			claimDetail.setClaimantKycDetails(req.getClaimantKycDetails());
//			claimDetail.setPan(req.getPan());
//			claimDetail.setAadhar(req.getAadhar());
//			claimDetail.setPassport(req.getPaasport());
//			claimDetail.setDrivingLicense(req.getDrivingLicence());
//			claimDetail.setMgnerega(req.getMgnregaCard());
//			claimDetail.setVottingCardId(req.getVoterIdCard());
//			claimDetail.setIsNomineeSame(req.getIsNomineeSame());
//			claimDetail.setClaimMaster(claimMaster);
//			claimMaster.setClaimDetail(claimDetail);
//			claimMasterRepo.save(claimMaster);
//			
//			// CHECK CLAIM AGE VALIDATION
//    		String claimAgeLimit = null;
//    		String[] claimAgeLimitArray = null;
//    		Boolean isAgeValid = null;
//    		if(claimMaster.getApplicationMaster().getSchemeId().intValue()==SchemeMaster.PMJJBY.getId()) {
//    			claimAgeLimit = properties.getValueByCode(PMJJBY_CLAIM_AGE_LIMIT);
//    			claimAgeLimitArray = claimAgeLimit.split(",");
//        		isAgeValid = OPLUtils.getAgeCriteriaValidation(claimMaster.getApplicationMaster().getSchemeId().intValue(),
//        				claimMaster.getApplicationMaster().getApplicantInfo().getDob(),claimDetail.getDateOfDeath(),claimAgeLimitArray);
//    		}else {
//    			claimAgeLimit = properties.getValueByCode(PMSBY_CLAIM_AGE_LIMIT);
//    			claimAgeLimitArray = claimAgeLimit.split(",");
//        		isAgeValid = OPLUtils.getAgeCriteriaValidation(claimMaster.getApplicationMaster().getSchemeId().intValue(),
//        				claimMaster.getApplicationMaster().getApplicantInfo().getDob(),claimDetail.getDateTimeOfAccident(),claimAgeLimitArray);
//    		}
//
//    		if(Boolean.FALSE.equals(isAgeValid)) {
//    			return new CommonResponse(CommonUtils.AGE_CRITERIA_SINGLE, HttpStatus.CREATED.value(), false);
//    		}
//			return new CommonResponse("Successfully saved Details!!", HttpStatus.OK.value(), true);
//	}
////	@Override
////	public String fetchViewClaimDetailsByClaimId(String request, Long userId) {
////		log.info("CALL fetchViewClaimDetails('{}', {})", request, userId);
////		//return spMasterRepository.fetchViewClaimDetailsByClaimId(request, userId);
////		return null;
////	}   
////
//    public ClaimMasterRequest getStage(Long claimId) {
//        ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//        if (null == claimMaster) {
//            return null;
//        }
//        ClaimMasterRequest claimMasterRequest = new ClaimMasterRequest();
//        BeanUtils.copyProperties(claimMaster, claimMasterRequest);
//        claimMasterRequest.setApplicationId(!OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster()) ?  claimMaster.getApplicationMaster().getId() : null);
//        return claimMasterRequest;
//    }
//    @Override
//    public CommonResponse updateStage(Long claimId, Long userId) {
//        ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//        if (null == claimMaster) {
//            return new CommonResponse("Its seems we found invalid claim details, Kindly refresh page and try again!!",
//                    ResponseStatus.BAD_REQUEST.getStatusId(), false);
//        }
//
//        if (ClaimStageMaster.CLAIM_COMPLETED.getStageId() == claimMaster.getClaimStageId() && !Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()) && !Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {
//            return new CommonResponse("Its seems this claim application journey already completed. Kindly refresh page and try again!!",
//                    ResponseStatus.BAD_REQUEST.getStatusId(), false);
//        }
//
//        if (ClaimStageMaster.CLAIM_COMPLETED.getStageId() == claimMaster.getClaimStageId() && (Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId()) || Objects.equals(claimMaster.getClaimStatus(), ClaimStatus.CLAIM_REJECTED.getId()))) {
//            claimMaster.setClaimStatus(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//        }
//
//        if (ClaimStageMaster.CLAIM_EXPIRED.getStageId() == claimMaster.getClaimStageId()) {
//            return new CommonResponse("Its seems this claim application is expired. Kindly refresh page and create new journey!!",
//                    ResponseStatus.BAD_REQUEST.getStatusId(), false);
//        }
//
//		/* Update History*/
//		updateClaimStatusAndStageHistory(claimMaster.getId());
//
//        ClaimStageMaster currentStage = ClaimStageMaster.getStageMasterByStageId(claimMaster.getClaimStageId());
//        Integer nextStage = claimMaster.getClaimStageId();
//        switch (currentStage) {
//            case CLAIM_FORM:
//                nextStage = ClaimStageMaster.CLAIM_COMPLETED.getStageId();
//                
//                claimMaster.setClaimDate(new Date());
//                claimMaster.setClaimStatus(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//                if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster()) && !OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getApplicantInfo())) {
//                	notificationUtil.sendNotification(
//            				setEmailParameters(OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getUrn())? null : claimMaster.getApplicationMaster().getUrn(),
//            						OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getApplicantInfo().getFirstName()) ? null : claimMaster.getApplicationMaster().getApplicantInfo().getFirstName(),
//            						OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getSchemeId()) ? null : SchemeMaster.getById(Long.valueOf(claimMaster.getApplicationMaster().getSchemeId())).getShortName(),claimMaster.getApplicationMaster().getApplicationMasterOtherDetails().getSource()),
//            				OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getApplicantInfo().getEmail()) ? null : claimMaster.getApplicationMaster().getApplicantInfo().getEmail(),
//            				OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getApplicantInfo().getMobileNumber()) ? null : claimMaster.getApplicationMaster().getApplicantInfo().getMobileNumber(),
//            						JnsNotificationMasterUtil.EMAIL_CLAIM_SUCESS,JnsNotificationMasterUtil.SMS_CLAIM_SUCESS,null);
//                }
//                break;
//            default:
//                break;
//        }
//        claimMaster.setClaimStageId(nextStage);
//        claimMaster.setModifiedDate(new Date());
//        claimMaster.setModifiedBy(userId);
//        claimMasterRepo.save(claimMaster);
//        
//        
//      
//        return new CommonResponse("Successfully updated!!", nextStage, HttpStatus.OK.value(), true);
//    }
//
//	public Map<String, Object> setEmailParameters(String urn,String claimantName, String schemeName,Integer source)
//	{
//		log.info("entry in emailParameters()");
//		Map<String, Object> emailParameters = new HashMap<>();
//		emailParameters.put("claimantName", claimantName);
//		emailParameters.put("nameOfScheme", schemeName);
//		emailParameters.put("urn", urn.substring(4));
//		emailParameters.put("source", source);
//		return emailParameters;
//	}
//
//
//	@Override
//    public CommonResponse publishedClaimedData(Long claimId) throws InsuranceException {
//        ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//        if (OPLUtils.isObjectNullOrEmpty(claimMaster) || claimMaster.getClaimStageId() != ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
//            return new CommonResponse("Its seems this claim has been not completed yet",HttpStatus.BAD_REQUEST.value());
//        }
//
//        String url = properties.getValueByCode("PUSH_PULL_CLAIM_API_URL") + claimMaster.getId();
//		Boolean isSuccess = Boolean.FALSE;
//		String message = null;
//		Date curruntDate = new Date();
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.set(CommonUtils.PUBLISHED_REQ_AUTH, CommonUtils.STR_TRUE);
//            headers.set(CommonUtils.IS_DECRYPT, CommonUtils.STR_TRUE);
//            headers.add(CommonUtils.ACCEPT_HEADER_PUBLISHED, MediaType.APPLICATION_JSON_VALUE);
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
//            RestTemplate restTemplate = new RestTemplate();
//            log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
//            CommonResponse commonResponse = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus() == HttpStatus.OK.value()
//					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getFlag()) && commonResponse.getFlag()) {
//                claimMaster.setIsPushed(Boolean.TRUE);
//				isSuccess = Boolean.TRUE;
//                claimMaster.setModifiedDate(curruntDate);
//                claimMasterRepo.save(claimMaster);
//			}else {
//				message = OPLUtils.isObjectNullOrEmpty(commonResponse) ? null : commonResponse.getMessage();
//            }
//        } catch (Exception e) {
//            updateStageError(claimMaster.getApplicationMaster().getId(), claimMaster.getId(),null, "PUBLISH API : " + e.getMessage(), claimMaster.getModifiedBy());
//            log.error("Exception While calling Public API :: ", e);
//			message = "Not Able to call Service because of : ".concat(e.getLocalizedMessage());
//        }
//        
//     // PUSH DATA DD REGISTRY THROUGH PYTHON
//		try {						
//			deDupeRegistryUtility.callPushClaimRequest(claimMaster);
//		}catch (Exception e) {
//			log.error("Error while push claim python API", claimMaster.getApplicationMaster().getId(), e.getMessage());
//		}
//
//		PushReTryAudit pushReTryAudit = pushReTryAuditRepo.findFirstByTypeAndIsPushedFalseAndClaimIdOrderByIdDesc(CommonUtils.PUSH_RE_TRY_CLAIM, claimMaster.getId());
//		if(isSuccess){
//			if(!OPLUtils.isObjectNullOrEmpty(pushReTryAudit)){
//				pushReTryAudit.setIsPushed(Boolean.TRUE);
//				pushReTryAudit.setModifiedDate(curruntDate);
//				pushReTryAuditRepo.save(pushReTryAudit);
//			}
//			return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
//		}else{  // add details in retry table
//			if(OPLUtils.isObjectNullOrEmpty(pushReTryAudit)) {
//				pushReTryAudit = new PushReTryAudit();
//			}
//			pushReTryAudit.setApplicationId(claimMaster.getApplicationMaster().getId());
//			pushReTryAudit.setClaimId(claimMaster.getId());
//			pushReTryAudit.setReTryCount(OPLUtils.isObjectNullOrEmpty(pushReTryAudit.getReTryCount())? CommonUtils.INT_0:(pushReTryAudit.getReTryCount() + CommonUtils.INT_1));
//			pushReTryAudit.setCreatedDate(curruntDate);
//			pushReTryAudit.setType(CommonUtils.PUSH_RE_TRY_CLAIM);
//			pushReTryAudit.setIsPushed(Boolean.FALSE);
//			pushReTryAudit.setMessage(message);
//			pushReTryAuditRepo.save(pushReTryAudit);
//		}
//        return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
//    }
//
//    @Override
//    public CommonResponse updateClaimAccountHolder(Long applicationId, AuthClientResponse authClientResponse) {
//        try {
//            ApplicationMasterV3 applicationMaster = masterRepository.findByIdAndIsActiveTrue(applicationId);
//
//             nomineeDetailsRepository.findByApplicationMasterIdAndTypeAndIsActiveTrue(applicationId, NomineeType.NOMINEE.getId());
//            if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
//                return new CommonResponse("Its seems we have found invalid application details, please try again",HttpStatus.BAD_REQUEST.value(), false);
//            }
//            List<Integer> statusList = new ArrayList<>();
//            statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
//            statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//
//            // PMSBY Multi Claim Validation check(Max 2 claim allowed)
//            if (SchemeMaster.PMSBY.getId().intValue() == applicationMaster.getSchemeId()) {
//                Long count = claimMasterRepo.countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(applicationMaster.getId(), statusList);
//                if (!OPLUtils.isObjectNullOrEmpty(count) && count >= CommonUtils.LONG_2) {
//                    return new CommonResponse(CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),false);
//                }else {
//                    statusList.clear();
//                    statusList.add(ClaimStatus.CLAIM_IN_PROGRESS.getId());
//                     count = claimMasterRepo.countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(applicationMaster.getId(), statusList);
//                    if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
//                        return new CommonResponse(CommonUtils.CLAIM_SUBMISSION_IN_PROGRESS_MSG, HttpStatus.CREATED.value(),false);
//                    }
//                }
//            }
//            boolean isNew = false;
//            ClaimMasterV3 claimMaster = claimMasterRepo.findFirstByApplicationMasterIdAndIsActiveTrueOrderByIdDesc(applicationId);
//            if (claimMaster != null) {
//                // CHECK FIRST SAME APPLICATION HAS CLAIM OR NOT
//                CommonResponse deDupeResult = deDupeLogic(claimMaster);
//                if (!deDupeResult.getFlag()) {
//                    updateStageError(applicationMaster.getId(), claimMaster.getId(), claimMaster.getClaimStageId(),deDupeResult.getMessage(), authClientResponse.getUserId());
//                    return deDupeResult;
//                }
//                // CREATE NEW CLAIM FOR PMSBY DISABILITY
//                if("PMSBY".equals(deDupeResult.getMessage())) {
//                    isNew = true;
//                    claimMaster =null;
//                }
//            }else {
//                isNew = true;
//            }
//            // CHECK CLAIM DE-DUPE
//            CommonResponse claimDeDupeObj = claimDeDupe(applicationMaster,authClientResponse.getUserId());
//            if (Boolean.FALSE.equals(claimDeDupeObj.getFlag())) {
//                updateStageError(applicationMaster.getId(), claimMaster != null ? claimMaster.getId() : null,claimMaster != null ? claimMaster.getClaimStageId() : null,
//                        claimDeDupeObj.getMessage(), authClientResponse.getUserId());
//                return claimDeDupeObj;
//            }
//
//			if ((OPLUtils.isObjectNullOrEmpty(claimMaster) && isNew) || (!OPLUtils.isObjectNullOrEmpty(claimMaster)
//					&& Objects.equals(claimMaster.getClaimStatus(), (ClaimStatus.CLAIM_EXPIRE.getId()))
//					&& claimMaster.getClaimStageId()==(ClaimStageMaster.CLAIM_EXPIRED.getStageId()))) {
//                // CREATE CLAIM MASTER
//                claimMaster = new ClaimMasterV3();
//                claimMaster.setApplicationMaster(applicationMaster);
//                claimMaster.setCreatedBy(authClientResponse.getUserId());
//                claimMaster.setCreatedDate(new Date());
//                claimMaster.setIsActive(Boolean.TRUE);
//                claimMaster.setClaimStatus(ClaimStatus.CLAIM_IN_PROGRESS.getId());
//                claimMaster.setClaimBranchId(authClientResponse.getUserBranchId());
//
//				if(OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail())){
//					ClaimDetailV3 claimDetail= new ClaimDetailV3();
//					claimDetail.setClaimMaster(claimMaster);
//					claimMaster.setClaimDetail(claimDetail);
//				}
//
//				// SET Branch Mapping Details
//				Map<String, Object> map = userManagementClient.getBranchMappingIds(claimMaster.getClaimBranchId(), applicationMaster.getSchemeId().longValue());
//				if (!OPLUtils.isObjectNullOrEmpty(map)) {
//					claimMaster.getClaimDetail().setBranchRoId(OPLUtils.isObjectNullOrEmpty(map.get("branchRoId")) ? null : Long.valueOf(map.get("branchRoId").toString()));
//					claimMaster.getClaimDetail().setBranchZoId(OPLUtils.isObjectNullOrEmpty(map.get("branchZoId")) ? null : Long.valueOf(map.get("branchZoId").toString()));
//					claimMaster.getClaimDetail().setBranchLhoId(OPLUtils.isObjectNullOrEmpty(map.get("branchLhoId")) ? null : Long.valueOf(map.get("branchLhoId").toString()));
//					claimMaster.getClaimDetail().setBranchStateId(OPLUtils.isObjectNullOrEmpty(map.get("stateId")) ? null : Long.valueOf(map.get("stateId").toString()));
//					claimMaster.getClaimDetail().setBranchCityId(OPLUtils.isObjectNullOrEmpty(map.get("cityId")) ? null : Long.valueOf(map.get("cityId").toString()));
//				}
//
//				claimMaster.setSchemeId(applicationMaster.getSchemeId());
//				claimMaster.setOrgId(applicationMaster.getOrgId());
//                claimMaster.setClaimStageId(ClaimStageMaster.CLAIM_FORM.getStageId());
//                claimMaster.setIsActive(Boolean.TRUE);
//                claimMaster.setCreatedDate(new Date());
//                claimMaster.setCreatedBy(authClientResponse.getUserId());
//            } else {
//                claimMaster.setModifiedBy(authClientResponse.getUserId());
//                claimMaster.setModifiedDate(new Date());
//            }
//			claimMaster = claimMasterRepo.save(claimMaster);
//            return new CommonResponse(CommonErrorMsg.Common.SUCCESS, claimMaster.getId(), HttpStatus.OK.value(), true);
//        } catch (Exception e) {
//            updateStageError(applicationId, null, null, "Claim Update Account Holder : " + e.getMessage(), authClientResponse.getUserId());
//            log.error("Exception is getting while save claim account Holder Details", e);
//            return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
//        }
//    }
//
//	@Override
//	public CommonResponse findAllApprovedClaimDetailsByApplicationId(Long claimId) {
//		if (OPLUtils.isObjectNullOrEmpty(claimId)) {
//			return new CommonResponse("Its seems we found invalid claim id , Kindly refresh page and try again!!",ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//		List<ClaimMasterRequest> claimMasterHistory = new ArrayList<>();
//		try {
//			ClaimMasterV3 masterData = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//			if(OPLUtils.isObjectNullOrEmpty(masterData)){
//				return new CommonResponse("No claim history was found!!",ResponseStatus.BAD_REQUEST.getStatusId(), false);
//			}
//			List<ClaimMasterV3> claimHisoryList = claimMasterRepo.findByApplicationMasterIdAndIsActiveTrueAndClaimStatusOrderByIdDesc(masterData.getApplicationMaster().getId(), ClaimStatus.CLAIM_ACCEPTED.getId());
//			if(!claimHisoryList.isEmpty()) {
//				ClaimMasterRequest claimMasterRequest=null;
//				for (ClaimMasterV3 claimMaster : claimHisoryList) {
//					claimMasterRequest = new ClaimMasterRequest();
//					BeanUtils.copyProperties(claimMaster, claimMasterRequest);
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//						String typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,claimMaster.getClaimDetail().getTypeOfDisablityId());
//						claimMasterRequest.setTypeOfDisablityValue(typeOfDisability);
//					}
//					claimMasterHistory.add(claimMasterRequest);
//				}
//				return new CommonResponse("Successfully get data !!",claimMasterHistory, HttpStatus.OK.value() , true);
//			}else{
//				return new CommonResponse("No claim history was found!!",ResponseStatus.BAD_REQUEST.getStatusId(), false);
//			}
//		} catch (Exception e) {
//			log.error("Exception is getting while approved claim details", e);
//			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
//		}
//	}
//
//	private CommonResponse deDupeLogic(ClaimMasterV3 claimMaster) {
//        if (claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_FORM.getStageId() || claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()) {
//            return new CommonResponse(CommonUtils.CLAIM_INITIATED_MSG, HttpStatus.CREATED.value(), false);
//        } else if (claimMaster.getClaimStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
//            if (SchemeMaster.PMJJBY.getId().intValue() == claimMaster.getApplicationMaster().getSchemeId()) {
//                if(ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus()) && claimMaster.getClaimDetail().getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId())) {
//                    return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(), false);
//                }else if(ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus()) && claimMaster.getClaimDetail().getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId())) {
//                	return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_DEATH_MSG, HttpStatus.CREATED.value(), false);
//                }
//                long dateDiff = DateUtils.dateDiff(claimMaster.getClaimDetail().getDateOfDeath(), claimMaster.getApplicationMaster().getEnrollmentDate());
//                if(dateDiff>30) {
//                	if(ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {                		
//                		return new CommonResponse(CommonUtils.CLAIM_DEATH_PAID_MSG, HttpStatus.CREATED.value(), false);
//                	}else {
//                		return new CommonResponse(CommonUtils.CLAIM_DEATH_MSG, HttpStatus.CREATED.value(), false);
//                	}
//                }else {
//                	if(ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {                		
//                		return new CommonResponse(CommonUtils.CLAIM_ACCIDENTIAL_PAID_MSG, HttpStatus.CREATED.value(), false);
//                	}else {
//                		return new CommonResponse(CommonUtils.CLAIM_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(), false);
//                	}
//                }
//            } else {
//                // NATURE OF LOASS 1 : DEATH && 2 : DISABILITY
//                if(ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus()) && !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && claimMaster.getClaimDetail().getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.ACCIDENTAL.getId()) && claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
//                    return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(), false);
//                }
//                if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
//                    if(ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//                        return new CommonResponse(CommonUtils.DEATH +" " + CommonUtils.CLAIM_ALREADY_PAID_MSG, HttpStatus.CREATED.value(),false);
//                    }
//                    if(ClaimStatus.CLAIM_REJECTED.getId().equals(claimMaster.getClaimStatus())) {
//                        return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(),false);
//                    }
//                    if(ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getClaimStatus())) {
//                        return new CommonResponse(CommonUtils.DEATH +" " + CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),false);
//                    }
//                } else {
//                    if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
//                            && !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId()) && claimMaster.getClaimDetail().getTypeOfDisablityId().equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
//                        if(ClaimStatus.CLAIM_ACCEPTED.getId().equals(claimMaster.getClaimStatus())) {
//                            return new CommonResponse(CommonUtils.TOTAL_DISABILITY +" " + CommonUtils.CLAIM_ALREADY_PAID_MSG, HttpStatus.CREATED.value(),false);
//                        }
//                        if(ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(claimMaster.getClaimStatus())) {
//                            return new CommonResponse(CommonUtils.TOTAL_DISABILITY +" " + CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),false);
//                        }
//                    }else {
//                        List<Integer> statusList = new ArrayList<>();
//                        statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
//                        statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//                        Long count = claimMasterRepo.countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(claimMaster.getApplicationMaster().getId(), statusList);
//                        if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
//                            return new CommonResponse(CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),false);
//                        }
//                        // ------------------------------ NEED TO HANDLE THIS SCENARIO
//                        return new CommonResponse(SchemeMaster.PMSBY.getShortName(), HttpStatus.CREATED.value(), true);
//                    }
//                }
//                List<ClaimMasterV3> claimMastersLst  = claimMasterRepo.findByApplicationMasterIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId());
//            	Boolean isProcced = false;
//				if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId()) && claimMaster.getClaimDetail().getTypeOfDisablityId().equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
//					for(ClaimMasterV3 master : claimMastersLst) {
//							if(ClaimStatus.CLAIM_REJECTED.getId().equals(master.getClaimStatus())
//									&& (!OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getNatureOfLossId()) && master.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
//	//                                && !OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getTypeOfDisablityId()) && (master.getClaimDetail().getTypeOfDisablityId() == CommonUtils.INT_2 || master.getClaimDetail().getTypeOfDisablityId() == CommonUtils.INT_1))
//									&& !OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getTypeOfDisablityId()))
//							) {
//								isProcced = true;
//							}
//						}
//					}
//				if(isProcced.equals(Boolean.TRUE)) {
//					return new CommonResponse(SchemeMaster.PMSBY.getShortName(), HttpStatus.CREATED.value(), true);
//				}
//            }
//        }
//        return new CommonResponse(CommonUtils.PROCEED, HttpStatus.CREATED.value(), true);
//    }
//    /**
//     * Need to check
//     * @param applicationMaster
//     * @return
//     */
//    private CommonResponse claimDeDupe(ApplicationMasterV3 applicationMaster, Long userId) {
//        try {
//            String deDupeCheck = properties.getValue("CLAIM_DE_DUPE_ENABLE");
//            List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
//            List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());
//            if ((OPLUtils.isObjectNullOrEmpty(deDupeCheck) || "OFF".equals(deDupeCheck)) || isSkipUserIdsLst.contains(userId)) {
//                log.info("CLAIM DE-DUPE OFF------------------------>");
//                return new CommonResponse("Proceed", HttpStatus.CREATED.value(), true);
//            }
//			List<ClaimMasterV3> claimList = claimMasterRepo.findAllByApplicationMasterAccountNumberAndApplicationMasterSchemeIdAndIsActiveTrue(applicationMaster.getAccountNumber(), applicationMaster.getSchemeId());
//            for (ClaimMasterV3 claimMaster : claimList) {
//                CommonResponse claimDeDupe = deDupeLogic(claimMaster);
//                if (Boolean.FALSE.equals(claimDeDupe.getFlag())) {
//                    return claimDeDupe;
//                }
//            }
//        } catch (Exception e) {
//            log.error("Exception while check claim de-dupe --->", e);
//            updateStageError(applicationMaster.getId(), null, null, "CLAIM DEDUPE CHECK : " + e.getMessage(),
//                    applicationMaster.getUserId());
//            return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
//                    false);
//        }
//        return new CommonResponse("Proceed", HttpStatus.CREATED.value(), true);
//    }
//    private void updateStageError(Long applicationId, Long claimId, Integer claimStageId, String msg, Long modifiedBy) {
//        @SuppressWarnings("unused")
//		ClaimStageMaster stage = null;
//        if(claimStageId != null) {
//            stage = ClaimStageMaster.getStageMasterByStageId(claimStageId);
//        }
//        //stageAuditUtils.update(new ErrorStageProxy(applicationId, claimId, claimStageId,stage != null ? stage.getStageName() : null, msg, modifiedBy));
//    }
//
//    @Override
//	public CommonResponse findAllClaimHistoryByApplicationId(Long applicationId) {
//		if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
//			return new CommonResponse("Its seems we found invalid applicationId , Kindly refresh page and try again!!",
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//		List<ClaimMasterRequest> claimMasterHistory = new ArrayList<>();
//		try {
//			ClaimMasterV3 masterData = claimMasterRepo.findFirstByApplicationMasterIdAndIsActiveTrueOrderByIdDesc(applicationId);
//			if(!OPLUtils.isObjectNullOrEmpty(masterData) && masterData.getClaimStageId()!=EnrollStageMaster.PREMIUM_DEDUCTION.getStageId() && masterData.getClaimStageId()!=EnrollStageMaster.REJECTED.getStageId()
//					&& masterData.getClaimStageId()!=EnrollStageMaster.EXPIRED.getStageId()) {
//				List<ClaimMasterV3> claimHisoryList= claimMasterRepo.findByClaimStageIdAndIsActiveTrueAndApplicationMasterIdOrderByIdDesc( ClaimStageMaster.CLAIM_COMPLETED.getStageId(),masterData.getApplicationMaster().getId());
//				if(!claimHisoryList.isEmpty()) {
//					ClaimMasterRequest claimMasterRequest=null;
//					for (ClaimMasterV3 claimMaster : claimHisoryList) {
//						claimMasterRequest = new ClaimMasterRequest();
//						BeanUtils.copyProperties(claimMaster, claimMasterRequest);
//						String typeOfDisability = null;
//						if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//							typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,claimMaster.getClaimDetail().getTypeOfDisablityId());
//						}
//						String typeOfVisValue=!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()==2 ? "Death" : "Accidental Death";
//						claimMasterRequest.setTypeOfDisablityValue(!OPLUtils.isObjectNullOrEmpty(typeOfDisability) ? typeOfDisability : typeOfVisValue);
//						claimMasterHistory.add(claimMasterRequest);
//					}
//					return new CommonResponse("Successfully get data !!",claimMasterHistory, HttpStatus.OK.value() , true);
//				}
//			}
//			return new CommonResponse("No claim history was found!!",
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		} catch (Exception e) {
//			log.error("Exception is getting while approved claim details", e);
//			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
//		}
//	}
//    @Override
//	public CommonResponse fetchViewClaimDetailsByApplicationId(Long applicationId,Long claimId) throws ParseException {
//		try {
//			ClaimMasterV3 claimMaster=claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//			ApplicationMasterV3 applicationMaster=claimMaster.getApplicationMaster();
//			
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster) && !OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getId())) {
//				List<NomineeDetails> nomineeMasterList=nomineeDetailsRepository.findByApplicationMasterIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId());
//				NomineeDetails nomineeMaster = nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.NOMINEE.getId())).findFirst().orElse(null);
//				NomineeDetails claimantMaster = nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.CLAIMANT.getId())).findFirst().orElse(null);
//				NomineeDetails guardianDetail= nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.GUARDIAN.getId())).findFirst().orElse(null);
//				
//				ClaimDashboardViewV2 claimDashboardViewV2 = new ClaimDashboardViewV2();
//				claimDashboardViewV2.setFullName(applicationMaster.getApplicantInfo().getName());
//				claimDashboardViewV2.setUrnNo(applicationMaster.getUrn());
//				if(applicationMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
//					String typeOfDisability = null;
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//						typeOfDisability = TypeOfDisability.fromId(claimMaster.getClaimDetail().getTypeOfDisablityId()).getValue();
//					}
//					String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 ? typeOfDisability : "-";
//					claimDashboardViewV2.setTypeOfLoss(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==1 ? "Accidental Death" : typeOfLoss );
//				}else if(applicationMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue()) {
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId())) {		
//						String typeOfLoss=claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()==1 ? "Accidental Death" : "-";
//						claimDashboardViewV2.setTypeOfLoss(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()==2 ? "Death" :typeOfLoss );
//					}
//				}
//				claimDashboardViewV2.setReceiveddate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate()) : null);
//				claimDashboardViewV2.setLastActionDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//				claimDashboardViewV2.setSchemeName(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//				claimDashboardViewV2.setClaimStatus(claimMaster.getClaimStatus());
//				claimDashboardViewV2.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.sdf_yyyy_MM_dd_T_HH_mm_ss_SS.format(claimMaster.getClaimDate()) : null);
//				claimDashboardViewV2.setIsClaimantSame(!OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame()) && claimMaster.getIsClaimantSame()==Boolean.TRUE ? "Yes" : "No");
//				int ageByDob = !OPLUtils.isObjectNullOrEmpty(nomineeMaster) ? CommonUtils.getAgeBydob(nomineeMaster.getDob()) : CommonUtils.INT_0;
//				claimDashboardViewV2.setNomineeAge( ageByDob);
//				claimDashboardViewV2.setRejectCnt(!OPLUtils.isObjectNullOrEmpty(claimMaster.getRejectCnt())? claimMaster.getRejectCnt() : null);				
//				if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
//					LinkedHashMap<String, Object> insuredDetails = new LinkedHashMap<>();
//					insuredDetails.put("First Name", applicationMaster.getApplicantInfo().getFirstName());
//					insuredDetails.put("Middle Name", applicationMaster.getApplicantInfo().getMiddleName());
//					insuredDetails.put("Last Name", applicationMaster.getApplicantInfo().getLastName());
//					insuredDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(applicationMaster.getApplicantInfo().getDob()) : null);
//					insuredDetails.put("Mobile Number", applicationMaster.getApplicantInfo().getMobileNumber());
//					insuredDetails.put("Email ID", applicationMaster.getApplicantInfo().getEmail());
//					insuredDetails.put("Bank A/C Number", applicationMaster.getAccountNumber());
//					insuredDetails.put("Policy Inception Date", !OPLUtils.isObjectNullOrEmpty(applicationMaster.getEnrollmentDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(applicationMaster.getEnrollmentDate()) : null);
//		            if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())) {
//		            	String organizationName = usersClient.getOrganizationName(applicationMaster.getOrgId());
//		                if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//		                	insuredDetails.put("Name of Bank", organizationName);
//		                }
//		            }
//		            if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getInsurerOrgId())) {
//		            	String organizationName = usersClient.getOrganizationName(applicationMaster.getLastTransactionDetails().getInsurerOrgId());
//		                if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//		                	insuredDetails.put("Name of Insurer", organizationName);
//		                }
//		            }
//					claimDashboardViewV2.setInsuredDetails(insuredDetails);	
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
//					LinkedHashMap<String, Object> insuredAddress = new LinkedHashMap<>();
//					insuredAddress.put("Address Line 1", nomineeMaster.getAddress().getAddressLine1());
//					insuredAddress.put("Address Line 2", nomineeMaster.getAddress().getAddressLine2());
//					insuredAddress.put("City", nomineeMaster.getAddress().getCityName());
//					insuredAddress.put("District", nomineeMaster.getAddress().getDistrict());
//					insuredAddress.put("State", nomineeMaster.getAddress().getStateName());
//					claimDashboardViewV2.setInsuredAddress(insuredAddress);
//					
//					LinkedHashMap<String, Object> nomineeDetails = new LinkedHashMap<>();
//					nomineeDetails.put("First Name", nomineeMaster.getFirstName());
//					nomineeDetails.put("Middle Name", nomineeMaster.getMiddleName());
//					nomineeDetails.put("Last Name ", nomineeMaster.getLastName());
//					nomineeDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(nomineeMaster.getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(nomineeMaster.getDob()) : null);
//					nomineeDetails.put("Age", !OPLUtils.isObjectNullOrEmpty(nomineeMaster.getDob()) && ageByDob ==0 || ageByDob ==1 ? ageByDob + " Year" : ageByDob + " Years" );
//					nomineeDetails.put("Mobile Number", nomineeMaster.getMobileNumber());
//					nomineeDetails.put("Email ID", nomineeMaster.getEmail());
//					// FOR NOMINEE UPDATE DATA
//					MiscellaneousAudit nomineeUpdatedData = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId,MiscellaneousType.NOMINEE_UPDATE.getId());
//					if(!OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData)) {
//						nomineeDetails.put("Date of Nominee Details updation", !OPLUtils.isObjectNullOrEmpty(nomineeUpdatedData.getCreatedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(nomineeUpdatedData.getCreatedDate()) : null);
//					}
//					nomineeDetails.put("Relationship with Deceased", null != nomineeMaster.getRelationShip() ? nomineeMaster.getRelationShip().getValue() : null);
//					claimDashboardViewV2.setNomineeDetails(nomineeDetails);	
//					
//					if(!OPLUtils.isObjectNullOrEmpty(guardianDetail)) {						
//						LinkedHashMap<String, Object> guardianDetails = new LinkedHashMap<>();
//						guardianDetails.put("Name", guardianDetail.getName());
//						if(!OPLUtils.isObjectNullOrEmpty(guardianDetail.getRelationId())) {							
//							String relationShip = RelationShip.fromId(guardianDetail.getRelationId()).getValue();
//							guardianDetails.put("Relationship with Nominee", relationShip);
//						}
//						guardianDetails.put("Mobile Number", guardianDetail.getMobileNumber());
//						guardianDetails.put("E-Mail ID", guardianDetail.getEmail());
//						claimDashboardViewV2.setGuardianDetails(guardianDetails);
//					}
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(claimantMaster)) {			
//					LinkedHashMap<String, Object> claimantDetails = new LinkedHashMap<>();
//					claimantDetails.put("First Name", claimantMaster.getFirstName());
//					claimantDetails.put("Middle Name", claimantMaster.getMiddleName());
//					claimantDetails.put("Last Name", claimantMaster.getLastName());
//					claimantDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(claimantMaster.getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimantMaster.getDob()) : null);
//					int ageByDobClaimant = CommonUtils.getAgeBydob(claimantMaster.getDob());
//					claimantDetails.put("Age", !OPLUtils.isObjectNullOrEmpty(ageByDobClaimant) && ageByDobClaimant == CommonUtils.INT_0 || ageByDobClaimant == CommonUtils.INT_1 ? ageByDobClaimant + " Year" : ageByDobClaimant + " Years" );
//					claimantDetails.put("Mobile Number", claimantMaster.getMobileNumber());
//					claimantDetails.put("Email ID", claimantMaster.getEmail());
//					claimantDetails.put("Relationship with Nominee", null != nomineeMaster.getRelationShip() ? nomineeMaster.getRelationShip().getValue() : null);
//					claimDashboardViewV2.setClaimantDetails(claimantDetails);
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//					LinkedHashMap<String, Object> claimDetails = new LinkedHashMap<>();
//					claimDetails.put("Date of Accident", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//					claimDetails.put("Time of Accident", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.HH_mm_ss.format(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//					claimDetails.put("Location of Loss", claimMaster.getClaimDetail().getLocationOfLoss());
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())) {
//						String natureOfLoss = NatureOfLoss.fromId(claimMaster.getClaimDetail().getNatureOfLossId()).getValue();
//						claimDetails.put("Nature of Loss", natureOfLoss);
//					}
//					claimDetails.put("Date of Death", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateOfDeath()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDetail().getDateOfDeath()) : null);
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && Objects.equals(Long.valueOf(applicationMaster.getSchemeId()), SchemeMaster.PMSBY.getId())) {
//						claimDetails.put("Cause of Death/Disability", CauseOfDeathDisability.fromId(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()).getValue());
//					}
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && Objects.equals(Long.valueOf(applicationMaster.getSchemeId()), SchemeMaster.PMJJBY.getId())) {
//						claimDetails.put("Cause of Death", CauseOfDeathDisability.fromId(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()).getValue());
//					}
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//						String typeOfDiability = TypeOfDisability.fromId(claimMaster.getClaimDetail().getTypeOfDisablityId()).getValue();					
//						claimDetails.put("Type of Disability", typeOfDiability);
//					}
//					claimDashboardViewV2.setClaimDetails(claimDetails);		
//					
//					LinkedHashMap<String, Object> claimantBankDetails = new LinkedHashMap<>();
//					claimantBankDetails.put("Bank Name", claimMaster.getClaimDetail().getNameOfBank());
//					claimantBankDetails.put("IFSC", claimMaster.getClaimDetail().getCustIfscCode());
//					claimantBankDetails.put("Bank A/C number", claimMaster.getClaimDetail().getClaimantBankAccountNumber());
//					claimantBankDetails.put("Amount Claimed", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 && claimMaster.getClaimDetail().getTypeOfDisablityId()==1 ? "1,00,000" : "2,00,000");
//					claimDashboardViewV2.setClaimantBankDetails(claimantBankDetails);
//					
//					LinkedHashMap<String, Object> paymentDetails = new LinkedHashMap<>();
//					paymentDetails.put("Date of Payment", !OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : null);
//					paymentDetails.put("UTR Number", claimMaster.getTransactionUtr());
//					paymentDetails.put("Amount Approved", !OPLUtils.isObjectNullOrEmpty(claimMaster.getAmountOfTransaction()) ? OPLUtils.generateCurrency(claimMaster.getAmountOfTransaction().toString()) : null);
//					paymentDetails.put("Amount Claimed", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 && claimMaster.getClaimDetail().getTypeOfDisablityId()==1 ? "1,00,000" : "2,00,000");
//					paymentDetails.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//					paymentDetails.put("Insurer Status", claimMaster.getInsurerStatus());
//					claimDashboardViewV2.setPaymentDetails(paymentDetails);
//					
//					LinkedHashMap<String, Object> rejectionDetails = new LinkedHashMap<>();
//					String rejectionReason=!OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerReason()) ? claimMaster.getInsurerReason() : "-";
//					rejectionDetails.put("Reason For Rejection", !OPLUtils.isObjectNullOrEmpty(claimMaster.getMessage()) ? claimMaster.getMessage() : rejectionReason);
//					rejectionDetails.put("Rejection Date",!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//					claimDashboardViewV2.setRejectionDetails(rejectionDetails);
//					
//					LinkedHashMap<String, Object> sentBackToBank = new LinkedHashMap<>();
//					sentBackToBank.put("Reason for referring back by Insurer", claimMaster.getStatusReason());
//					sentBackToBank.put("Comment by Insurer", claimMaster.getMessage());
//					sentBackToBank.put("Query Date", !OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//					sentBackToBank.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//					sentBackToBank.put("Insurer Status", claimMaster.getInsurerStatus());
//					claimDashboardViewV2.setSentBackToBank(sentBackToBank);
//					
//					// FOR OPT OUT DATA
//					MiscellaneousAudit optOutData = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(applicationId,MiscellaneousType.OPT_OUT.getId());
//					if(!OPLUtils.isObjectNullOrEmpty(optOutData)) {
//						LinkedHashMap<String, Object> optOut = new LinkedHashMap<>();
//						optOut.put("Request Date", !OPLUtils.isObjectNullOrEmpty(optOutData.getDateOfRequest()) ? CommonUtils.sdf_dd_MM_yyyy.format(optOutData.getDateOfRequest()) : null);
//						optOut.put("Effective Date", !OPLUtils.isObjectNullOrEmpty(optOutData.getDateOfEffective()) ? CommonUtils.sdf_dd_MM_yyyy.format(optOutData.getDateOfEffective()) : null);	
//						claimDashboardViewV2.setOptOut(optOut);
//					}
//					
//				}
//				return new CommonResponse("Successfully get data !!",claimDashboardViewV2, HttpStatus.OK.value() , true);
//			}
//			return new CommonResponse("No data found!!",ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}catch (Exception e) {
//		log.error("Exception is getting while claim details", e);
//		return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}
//}
//	
//	public CommonResponse updateClaimStatus(ClaimStatusRequest claimStatusRequest, Long userId) throws OneFormException {
//		ClaimMasterV3 master = claimMasterRepo.findByIdAndIsActiveTrue(claimStatusRequest.getClaimId());
//		ClaimStatus appStatus = ClaimStatus.fromId(claimStatusRequest.getClaimStatus());
//		if (OPLUtils.isObjectNullOrEmpty(appStatus)) {
//			return new CommonResponse("Its seems we found invalid claim status, Kindly refresh page and try again!!",
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//		if (Objects.equals(master.getClaimStatus(), ClaimStatus.CLAIM_ACCEPTED.getId())) {
//			return new CommonResponse("Its seems this claim already completed !!",
//					ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}
//		if(Objects.equals(claimStatusRequest.getClaimStatus(), ClaimStatus.CLAIM_REJECTED.getId())) {
//			master.setRejectCnt(!OPLUtils.isObjectNullOrEmpty(master.getRejectCnt()) ? master.getRejectCnt() + CommonUtils.INT_1 : CommonUtils.INT_1);
//		}
//		try {
//			if (!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getAmountOfTransaction())) {
//				if (appStatus.getValue().equals(ClaimStatus.CLAIM_ACCEPTED.getValue())) {
//					if (master.getApplicationMaster().getSchemeId().intValue() == SchemeMaster.PMSBY.getId()
//							&& !OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getNatureOfLossId())
//							&& master.getClaimDetail().getNatureOfLossId() == CommonUtils.NATURE_OF_LOSS_DISABLITY && master.getClaimDetail().getTypeOfDisablityId() == CommonUtils.TYPE_OF_DISABLITY_ID) {
//						if (claimStatusRequest.getAmountOfTransaction() > Long
//								.parseLong(properties.getValueByCode("PMSBY_DISABLITY_CLAIM_AMOUNT"))) {
//							return new CommonResponse(
//									CommonUtils.APPROVED_CLAIM_AMOUNT_NOT_VALIDATE_MSG
//											+ properties.getValueByCode("PMSBY_DISABLITY_CLAIM_AMOUNT") + " !!",
//									ResponseStatus.AMOUNT_INVALID_ERROR.getStatusId(), false);
//						}
//					} else if (claimStatusRequest.getAmountOfTransaction() > Long
//							.parseLong(properties.getValueByCode(CommonUtils.PMSBY_TOTAL_CLAIM_AMOUNT))) {
//						return new CommonResponse(
//								CommonUtils.APPROVED_CLAIM_AMOUNT_NOT_VALIDATE_MSG
//										+ properties.getValueByCode(CommonUtils.PMSBY_TOTAL_CLAIM_AMOUNT) + " !!",
//								ResponseStatus.AMOUNT_INVALID_ERROR.getStatusId(), false);
//					}
//					master.setTransactionUtr(claimStatusRequest.getTransactionUTR());
//					master.setAmountOfTransaction(claimStatusRequest.getAmountOfTransaction());
//					master.setDateOfTransaction(claimStatusRequest.getDateOfTransaction());
//				}
//			} 
//		} catch (Exception e) {
//			return new CommonResponse("Claim not accepted", HttpStatus.BAD_REQUEST.value());
//		}
//		/* Update History*/
//		updateClaimStatusAndStageHistory(master.getId());
//
//		master.setClaimStatus(claimStatusRequest.getClaimStatus());
//		master.setModifiedDate(new Date());
//		master.setModifiedBy(userId);
//		if (!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getMessage())) {
//			master.setMessage(claimStatusRequest.getMessage());
//		}
//		if (!OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getStatusReason())) {
//			master.setStatusReasonId(claimStatusRequest.getStatusReason());
//			String statusReason = oneFormClient.getNameByKeyAndObjId(DropDownMasterKey.STATUS_REASON,
//					master.getStatusReasonId()).getValue();
//			if(!OPLUtils.isObjectNullOrEmpty(statusReason)) {
//				master.setStatusReason(statusReason);
//			}
//		}
//		claimMasterRepo.save(master);
//		
//		/** update claim status call python api*/
//		deDupeRegistryUtility.callUpdateClaimStatusRequest(master);
//		
//		return new CommonResponse("Successfully updated!!", HttpStatus.OK.value(), true);
//	}
//
//	public DedupeRequest createDedupeRequest(ApplicationMasterV3 applicationMaster, NomineeDetails nomineeMaster) throws ParseException {
//		DedupeRequest dedupeRequest = new DedupeRequest();
//    	dedupeRequest.setApplicationId(applicationMaster.getId());
//    	dedupeRequest.setAccountNumber(applicationMaster.getAccountNumber());
//    	dedupeRequest.setUrn(applicationMaster.getUrn());
//    	dedupeRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//		if(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo())) {
//			dedupeRequest.setAccountHolderName(applicationMaster.getApplicantInfo().getName());
//			dedupeRequest.setDob(CommonUtils.sdf_dd_MM_yyyy.format(applicationMaster.getApplicantInfo().getDob()));
//			dedupeRequest.setIdType1(applicationMaster.getApplicantInfo().getKycId1());
//			dedupeRequest.setIdType1number(applicationMaster.getApplicantInfo().getKycIdNumber1());
//			dedupeRequest.setIdType2(applicationMaster.getApplicantInfo().getKycId2());
//			dedupeRequest.setIdType2number(applicationMaster.getApplicantInfo().getKycIdNumber2());
//			dedupeRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress()) ? applicationMaster.getApplicantInfo().getAddress().getPincode().toString() : null);
//		}
//    	dedupeRequest.setNomineeName(nomineeMaster.getFirstName() + " "+ nomineeMaster.getLastName());
//    	dedupeRequest.setNomineeDOB(!OPLUtils.isObjectNullOrEmpty(nomineeMaster.getDob()) ? CommonUtils.sdf.format(nomineeMaster.getDob()) : null);
//    	dedupeRequest.setRegistrationDate(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getEnrollmentDate()) ? CommonUtils.sdf.format(applicationMaster.getEnrollmentDate()) : null);
//    	dedupeRequest.setOrgId(applicationMaster.getLastTransactionDetails().getInsurerOrgId());
//		return dedupeRequest;
//	}
//	@Override
//	public void pushRemainingClaim() {
//		List<PushReTryAudit> claimList = pushReTryAuditRepo.findByIsPushedFalseAndReTryCountLessThanEqual(CommonUtils.INT_3);
//		claimList.forEach(x -> {
//			try {
//				if (x.getType() == CommonUtils.PUSH_RE_TRY_CLAIM && !OPLUtils.isObjectNullOrEmpty(x.getClaimId())) {
//					publishedClaimedData(x.getClaimId());
//				}
//			} catch (InsuranceException e) {
//				throw new RuntimeException(e);
//			}
//		});
//	}
//
//	public String getValueById(DropDownMasterKey key,Integer id) throws OneFormException {
//		return oneFormClient.getNameByKeyAndObjId(key,id).getValue();
//	}
//	@Override
//	public void updateClaimStatusAndStageHistory(Long claimId){
//	/*	ClaimMasterV3 master = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//		ClaimMasterHistory claimMasterHistory = new ClaimMasterHistory(master.getId(),master.getApplicationMaster().getId(),master.getClaimStageId(),master.getClaimStatus());
//		claimMasterHistory.setCreatedDate(new Date());
//		claimMasterHistory.setId(sequenceService.generateSequence(ClaimMasterHistory.SEQUENCE_NAME));
//		historyRepo.save(claimMasterHistory);*/
//	}
//	@Override
//	public String fetchViewClaimDetailsByClaimId(String request, Long userId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
//	
//	@Override
//	public CommonResponse getAllClaimDetail(Long applicationId,Long claimId) throws ParseException {
//		try {
//			ApplicationMasterV3 applicationMaster=applicationMasterRepo.findByIdAndIsActiveTrue(applicationId);
//			ClaimMasterV3 claimMaster=claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster) && !OPLUtils.isObjectNullOrEmpty(claimMaster.getApplicationMaster().getId())) {
//				List<NomineeDetails> nomineeMasterList=nomineeDetailsRepository.findByApplicationMasterIdAndIsActiveTrue(claimMaster.getApplicationMaster().getId());
//				NomineeDetails nomineeMaster = nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.NOMINEE.getId())).findFirst().orElse(null);
//				NomineeDetails claimantMaster = nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.CLAIMANT.getId())).findFirst().orElse(null);
//				NomineeDetails guardianDetail= nomineeMasterList.stream().filter(n -> n.getType().equals(NomineeType.GUARDIAN.getId())).findFirst().orElse(null);
//
//				
//				ClaimDashboardViewV2 claimDashboardViewV2 = new ClaimDashboardViewV2();
//				claimDashboardViewV2.setFullName(applicationMaster.getApplicantInfo().getName());
//				claimDashboardViewV2.setUrnNo(applicationMaster.getUrn());
//				if(applicationMaster.getSchemeId()==1) {
//					String typeOfDisability = null;
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//						typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,claimMaster.getClaimDetail().getTypeOfDisablityId());
//					}
//					String typeOfLoss=!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 ? typeOfDisability : "-";
//					claimDashboardViewV2.setTypeOfLoss(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==1 ? "Accidental Death" : typeOfLoss  );
//				}else if(applicationMaster.getSchemeId()==2) {
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId())) {		
//						String  typeOfLoss=claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()==1 ? "Accidental Death" : "-";
//						claimDashboardViewV2.setTypeOfLoss(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()==2 ? "Death" : typeOfLoss);
//					}
//				}
//				claimDashboardViewV2.setReceiveddate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDate()) : null);
//				claimDashboardViewV2.setLastActionDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//				claimDashboardViewV2.setSchemeName(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//				claimDashboardViewV2.setSchemeId(applicationMaster.getSchemeId());;
//				claimDashboardViewV2.setClaimStatus(claimMaster.getClaimStatus());
//				claimDashboardViewV2.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.sdf_yyyy_MM_dd_T_HH_mm_ss_SS.format(claimMaster.getClaimDate()) : null);
//				claimDashboardViewV2.setIsClaimantSame(!OPLUtils.isObjectNullOrEmpty(claimMaster.getIsClaimantSame()) && claimMaster.getIsClaimantSame()==Boolean.TRUE ? "Yes" : "No");
//				int ageByDob = !OPLUtils.isObjectNullOrEmpty(nomineeMaster) ? CommonUtils.getAgeBydob(nomineeMaster.getDob()) : CommonUtils.INT_0;
//				claimDashboardViewV2.setNomineeAge( ageByDob);
//				claimDashboardViewV2.setRejectCnt(!OPLUtils.isObjectNullOrEmpty(claimMaster.getRejectCnt())? claimMaster.getRejectCnt() : null);				
//				if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
//					LinkedHashMap<String, Object> insuredDetails = new LinkedHashMap<>();
//					insuredDetails.put("First Name", applicationMaster.getApplicantInfo().getFirstName());
//					insuredDetails.put("Middle Name", applicationMaster.getApplicantInfo().getMiddleName());
//					insuredDetails.put("Last Name", applicationMaster.getApplicantInfo().getLastName());
//					insuredDetails.put("Father/Husband Name", applicationMaster.getApplicantInfo().getFatherHusbandName());
//					insuredDetails.put("Gender",applicationMaster.getApplicantInfo().getGender());
//					insuredDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(applicationMaster.getApplicantInfo().getDob()) : null);
//					insuredDetails.put("Mobile Number", applicationMaster.getApplicantInfo().getMobileNumber());
//					insuredDetails.put("Email ID", applicationMaster.getApplicantInfo().getEmail());
//					insuredDetails.put("Bank A/C Number", applicationMaster.getAccountNumber());
//					insuredDetails.put("CIF",applicationMaster.getCif());
//					insuredDetails.put("KYCID1", applicationMaster.getApplicantInfo().getKycId1());
//					insuredDetails.put("KYC1 Number", applicationMaster.getApplicantInfo().getKycIdNumber1());
//					insuredDetails.put("KYCI21", applicationMaster.getApplicantInfo().getKycId2());
//					insuredDetails.put(" KYC2 Number", applicationMaster.getApplicantInfo().getKycIdNumber2());
//					insuredDetails.put("CKYC", applicationMaster.getApplicantInfo().getCkyc());
//					insuredDetails.put("CKYC Number", applicationMaster.getApplicantInfo().getCkycNumber());
//					insuredDetails.put("Pan", applicationMaster.getApplicantInfo().getPan());
//					insuredDetails.put("Adhar", applicationMaster.getApplicantInfo().getAadhaar());
//					
//
//					insuredDetails.put(" Date of Enrollment", !OPLUtils.isObjectNullOrEmpty(applicationMaster.getEnrollmentDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(applicationMaster.getEnrollmentDate()) : null);
//		            if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())) {
//		            	String organizationName = usersClient.getOrganizationName(applicationMaster.getOrgId());
//		                if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//		                	insuredDetails.put("Name of Bank", organizationName);
//		                }
//		            }
//		            if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getInsurerOrgId())) {
//		            	String organizationName = usersClient.getOrganizationName(applicationMaster.getLastTransactionDetails().getInsurerOrgId());
//		                if (!OPLUtils.isObjectNullOrEmpty(organizationName)) {
//		                	insuredDetails.put("Name of Insurer", organizationName);
//		                }
//		            }
//					claimDashboardViewV2.setInsuredDetails(insuredDetails);	
//				}
//				
//				if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress())) {
//					LinkedHashMap<String, Object> insuredAddress = new LinkedHashMap<>();
//					insuredAddress.put("Address Line 1", applicationMaster.getApplicantInfo().getAddress().getAddressLine1());
//					insuredAddress.put("Address Line 2", applicationMaster.getApplicantInfo().getAddress().getAddressLine2());
//					insuredAddress.put("City", applicationMaster.getApplicantInfo().getAddress().getCityName());
//					insuredAddress.put("cityLGDCode", applicationMaster.getApplicantInfo().getAddress().getCityLGDCode());
//					insuredAddress.put("District",applicationMaster.getApplicantInfo().getAddress().getDistrict());
//					insuredAddress.put("DistrictLGDCode",applicationMaster.getApplicantInfo().getAddress().getDistrictLGDCode());
//					insuredAddress.put("State",applicationMaster.getApplicantInfo().getAddress().getStateName());
//					insuredAddress.put("stateLGDCode",applicationMaster.getApplicantInfo().getAddress().getStateLGDCode());
//					insuredAddress.put("PinCode",applicationMaster.getApplicantInfo().getAddress().getPincode());
//					claimDashboardViewV2.setInsuredAddress(insuredAddress);
//				
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
//					LinkedHashMap<String, Object> nomineeDetails = new LinkedHashMap<>();
//					nomineeDetails.put("First Name", nomineeMaster.getFirstName());
//					nomineeDetails.put("Middle Name", nomineeMaster.getMiddleName());
//					nomineeDetails.put("Last Name ", nomineeMaster.getLastName());
//					nomineeDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(nomineeMaster.getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(nomineeMaster.getDob()) : null);
//					nomineeDetails.put("Age", !OPLUtils.isObjectNullOrEmpty(nomineeMaster.getDob()) && ageByDob ==0 || ageByDob ==1 ? ageByDob + " Year" : ageByDob + " Years" );
//					nomineeDetails.put("Mobile Number", nomineeMaster.getMobileNumber());
//					nomineeDetails.put("Email ID", nomineeMaster.getEmail());
//					nomineeDetails.put("Correct Nominee FirstName ", nomineeMaster.getCorrectNomineeFirstName());
//					nomineeDetails.put("Correct Nominee MiddleName ", nomineeMaster.getCorrectNomineeMiddleName());
//					nomineeDetails.put("Correct Nominee LastName ", nomineeMaster.getCorrectNomineeLastName());
//					nomineeDetails.put("Relationship with Deceased", null != nomineeMaster.getRelationShip() ? nomineeMaster.getRelationShip().getValue() : null);
//					claimDashboardViewV2.setNomineeDetails(nomineeDetails);	
//					
//					LinkedHashMap<String, Object> nomineeAddress = new LinkedHashMap<>();
//					nomineeAddress.put("Address Line 1", nomineeMaster.getAddress().getAddressLine1());
//					nomineeAddress.put("Address Line 2", nomineeMaster.getAddress().getAddressLine2());
//					nomineeAddress.put("City", nomineeMaster.getAddress().getCityName());
//					nomineeAddress.put("cityLGDCode", nomineeMaster.getAddress().getCityLGDCode());
//					nomineeAddress.put("District", nomineeMaster.getAddress().getDistrict());
//					nomineeAddress.put("DistrictLGDCode",nomineeMaster.getAddress().getDistrictLGDCode());
//					nomineeAddress.put("State", nomineeMaster.getAddress().getStateName());
//					nomineeAddress.put("stateLGDCode",nomineeMaster.getAddress().getStateLGDCode());
//					nomineeAddress.put("PinCode",nomineeMaster.getAddress().getPincode());
//					claimDashboardViewV2.setNomineeAddress(nomineeAddress);
//					
//					if(!OPLUtils.isObjectNullOrEmpty(guardianDetail)) {						
//						LinkedHashMap<String, Object> guardianDetails = new LinkedHashMap<>();
//						guardianDetails.put("Name", guardianDetail.getName());
//						if(!OPLUtils.isObjectNullOrEmpty(guardianDetail.getRelationId())) {							
//							String relationShip = getValueById(DropDownMasterKey.RELEATION_SHIP,guardianDetail.getRelationId());
//							guardianDetails.put("Relationship with Guardian", relationShip);
//						}
//						guardianDetails.put("Mobile Number of Guardian ", guardianDetail.getMobileNumber());
//						guardianDetails.put("E-Mail ID of Guardian ", guardianDetail.getEmail());
//						claimDashboardViewV2.setGuardianDetails(guardianDetails);
//					}
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(claimantMaster)) {			
//					LinkedHashMap<String, Object> claimantDetails = new LinkedHashMap<>();
//					claimantDetails.put("First Name", claimantMaster.getFirstName());
//					claimantDetails.put("Middle Name", claimantMaster.getMiddleName());
//					claimantDetails.put("Last Name", claimantMaster.getLastName());
//					claimantDetails.put("Date of Birth", !OPLUtils.isObjectNullOrEmpty(claimantMaster.getDob()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimantMaster.getDob()) : null);
//					int ageByDobClaimant = CommonUtils.getAgeBydob(claimantMaster.getDob());
//					claimantDetails.put("Age", !OPLUtils.isObjectNullOrEmpty(ageByDobClaimant) && ageByDobClaimant == CommonUtils.INT_0 || ageByDobClaimant == CommonUtils.INT_1 ? ageByDobClaimant + " Year" : ageByDobClaimant + " Years" );
//					claimantDetails.put("Mobile Number", claimantMaster.getMobileNumber());
//					claimantDetails.put("Email ID", claimantMaster.getEmail());
//					claimantDetails.put("Relationship with Claimant", null !=  claimantMaster.getRelationShip() ? claimantMaster.getRelationShip().getValue() : null);
//					claimantDetails.put("Relationship with Nominee", null != nomineeMaster.getRelationShip() ? nomineeMaster.getRelationShip().getValue() : null);
//					
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getKycDocId())) {					
//						String[] strArray =  claimMaster.getClaimDetail().getKycDocId().split(",");  
//						claimantDetails.put("Claimant KYCID1",KycDocument.fromId(Integer.valueOf(strArray[0].trim())).getValue());
//						claimantDetails.put("Claimant KYCNumber1",getKycDocument(Integer.valueOf(strArray[0].trim()),claimMaster.getClaimDetail()));
//						if(strArray.length>1) {					
//							claimantDetails.put("Claimant KYCID2",!OPLUtils.isObjectNullOrEmpty(strArray[1].trim()) ? KycDocument.fromId(Integer.valueOf(strArray[1].trim())).getValue() : null);
//							claimantDetails.put("Claimant KYCNumbe2",getKycDocument(Integer.valueOf(strArray[1].trim()),claimMaster.getClaimDetail()));
//						}
//					}
//					claimDashboardViewV2.setClaimantDetails(claimantDetails);
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails())) {
//					claimDashboardViewV2.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//					claimDashboardViewV2.setIsUpdateManually(applicationMaster.getLastTransactionDetails().getIsUpdateManually());
//					if(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getLastTransactionDetails().getTransTimeStamp())) {					
//						claimDashboardViewV2.setPremDebitDate(CommonUtils.sdf.format(applicationMaster.getLastTransactionDetails().getTransTimeStamp()));
//						claimDashboardViewV2.setPremRemitDate(CommonUtils.sdf.format(applicationMaster.getLastTransactionDetails().getTransTimeStamp()));
//					}
//			
//				}
//				
//				if(!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
//					LinkedHashMap<String, Object> claimDetails = new LinkedHashMap<>();
//					claimDetails.put("Date of Accident", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//					claimDetails.put("Day of Accident", claimMaster.getClaimDetail().getDayOfAccident());
//
//					claimDetails.put("Time of Accident", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.HH_mm_ss.format(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//					claimDetails.put("Location of Loss", claimMaster.getClaimDetail().getLocationOfLoss());
//			
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId())) {
//						String natureOfLoss = getValueById(DropDownMasterKey.NATURE_OF_LOSS,claimMaster.getClaimDetail().getNatureOfLossId());
//						claimDetails.put("Nature of Loss", natureOfLoss);
//					}
//					claimDetails.put("Date of Death", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateOfDeath()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getClaimDetail().getDateOfDeath()) : null);
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && Objects.equals(Long.valueOf(applicationMaster.getSchemeId()), SchemeMaster.PMSBY.getId())) {
//						claimDetails.put("Cause of Death/Disability", CauseOfDeathDisability.fromId(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()).getValue());
//					}
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()) && Objects.equals(Long.valueOf(applicationMaster.getSchemeId()), SchemeMaster.PMJJBY.getId())) {
//						claimDetails.put("Cause of Death", CauseOfDeathDisability.fromId(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()).getValue());
//					}
//					if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//						String typeOfDiability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,claimMaster.getClaimDetail().getTypeOfDisablityId());
//						claimDetails.put("Type of Disability", typeOfDiability);
//					
//					}
//					claimDashboardViewV2.setClaimDetails(claimDetails);		
//					
//					LinkedHashMap<String, Object> claimantBankDetails = new LinkedHashMap<>();
//					claimantBankDetails.put("Bank Name", claimMaster.getClaimDetail().getNameOfBank());
//					claimantBankDetails.put("IFSC", claimMaster.getClaimDetail().getCustIfscCode());
//					claimantBankDetails.put("Bank A/C number", claimMaster.getClaimDetail().getClaimantBankAccountNumber());
//					claimantBankDetails.put("Amount Claimed", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 && claimMaster.getClaimDetail().getTypeOfDisablityId()==1 ? "1,00,000" : "2,00,000");
//					claimDashboardViewV2.setClaimantBankDetails(claimantBankDetails);
//					
//					LinkedHashMap<String, Object> paymentDetails = new LinkedHashMap<>();
//					paymentDetails.put("Date of Payment", !OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : null);
//					paymentDetails.put("UTR Number", claimMaster.getTransactionUtr());
//					paymentDetails.put("Amount Approved", !OPLUtils.isObjectNullOrEmpty(claimMaster.getAmountOfTransaction()) ? OPLUtils.generateCurrency(claimMaster.getAmountOfTransaction().toString()) : null);
//					paymentDetails.put("Amount Claimed", !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && claimMaster.getClaimDetail().getNatureOfLossId()==2 && claimMaster.getClaimDetail().getTypeOfDisablityId()==1 ? "1,00,000" : "2,00,000");
//					paymentDetails.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//					paymentDetails.put("Insurer Status", claimMaster.getInsurerStatus());
//					claimDashboardViewV2.setPaymentDetails(paymentDetails);
//					
//					LinkedHashMap<String, Object> rejectionDetails = new LinkedHashMap<>();
//					String rejectionReason=!OPLUtils.isObjectNullOrEmpty(claimMaster.getInsurerReason()) ? claimMaster.getInsurerReason() : "-";
//					rejectionDetails.put("Reason For Rejection", !OPLUtils.isObjectNullOrEmpty(claimMaster.getMessage()) ? claimMaster.getMessage() : rejectionReason );
//					rejectionDetails.put("Rejection Date",!OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//					claimDashboardViewV2.setRejectionDetails(rejectionDetails);
//					
//					LinkedHashMap<String, Object> sentBackToBank = new LinkedHashMap<>();
//					sentBackToBank.put("Reason for referring back by Insurer", claimMaster.getStatusReason());
//					sentBackToBank.put("Comment by Insurer", claimMaster.getMessage());
//					sentBackToBank.put("Query Date", !OPLUtils.isObjectNullOrEmpty(claimMaster.getModifiedDate()) ? CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getModifiedDate()) : CommonUtils.sdf_dd_MM_yyyy.format(claimMaster.getCreatedDate()));
//					sentBackToBank.put("Insurer Claim Id", claimMaster.getInsurerClaimId());
//					sentBackToBank.put("Insurer Status", claimMaster.getInsurerStatus());
//					claimDashboardViewV2.setSentBackToBank(sentBackToBank);
//				}
//				return new CommonResponse("Successfully get data !!",claimDashboardViewV2, HttpStatus.OK.value() , true);
//			}
//			return new CommonResponse("No data found!!",ResponseStatus.BAD_REQUEST.getStatusId(), false);
//		}catch (Exception e) {
//		log.error("Exception is getting while claim details", e);
//		return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}
//  }
//	
//	public String getKycDocument(Integer kycId, ClaimDetailV3 claimDetailV3) {
//    	if(Objects.equals(KycDocument.PAN.getId(), kycId)) {
//    		return claimDetailV3.getPan();
//    	}else if(Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
//    		return claimDetailV3.getPassport();
//    	}else if(Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
//    		return claimDetailV3.getDrivingLicense();
//    	}else if(Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
//    		return claimDetailV3.getMgnerega();
//    	}else if(Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
//    		return claimDetailV3.getVottingCardId();
//    	}
//		return null;
//    	
//    }
//	
//	
//	@Override
//	public CommonResponse webHookClaimDocUpload(Long claimId,List<Long> docs) {
//		ClaimMasterV3 claimMaster = claimMasterRepo.findByIdAndIsActiveTrue(claimId);
//	
//		if(!OPLUtils.isObjectNullOrEmpty(claimMaster) && claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())){
//			
//			/** update the re-uploaded docs in table */
//			claimMaster.setQueriedStorageId(!docs.isEmpty() ? docs.toString().replace('[',' ').replace(']',' ') : null);
//			claimMasterRepo.save(claimMaster);
//			
//			/** update audit for the webhook */
//			webhookAudit(claimMaster);
//			
//			/** re-push the docs only */
//			CommonResponse rePushDocs = rePushDocs(claimMaster.getId());
//
//			if(!OPLUtils.isObjectNullOrEmpty(rePushDocs) && rePushDocs.getStatus() == HttpStatus.OK.value()) {	
//				return rePushDocs;			
//			}
//			return null;
//		}
//		return null;
//	}
//	
//	public CommonResponse rePushDocs(Long claimId){
//		/** re-push the docs only */
//		CommonResponse updateClaimMaster = updateClaimMaster(claimId,PUSH_CLAIM_REVISED_DOCS);
//		if(OPLUtils.isObjectNullOrEmpty(updateClaimMaster)) {
//			return null;
//		}
//		return updateClaimMaster;
//	}
//	
//	public ClaimStatusWebhookAudit webhookAudit(ClaimMasterV3 claimMaster){
//		if(claimMaster.getClaimStatus().equals(ClaimStatus.CLAIM_SEND_BACK_BY_INSURER.getId())) {
////			ClaimStatusWebhookAudit audit = webhookAuditRepository.findByClaimIdAndWebhookMasterIdAndIsActiveTrue(claimMaster.getId(), WebhookMasterEnum.UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_OTHER_CHANEL_API.getId());
////			if(!OPLUtils.isObjectNullOrEmpty(audit) && (!OPLUtils.isObjectNullOrEmpty(type) && type==INT_1)) {
////				audit.setIsActive(Boolean.FALSE);
////				audit.setModifiedDate(new Date());
////				webhookAuditRepository.save(audit);
////			}
////			if(null == webhookAuditDmn){
////				webhookAuditDmn = new ClaimStatusWebhookAudit();
////				webhookAuditDmn.setCreatedDate(new Date());
////				webhookAuditDmn.setClaimId(claimMaster.getId());
////				webhookAuditDmn.setClaimStatus(claimMaster.getClaimStatus());
////				webhookAuditDmn.setIsActive(Boolean.TRUE);
////				webhookAuditDmn.setWebhookMasterId(WebhookMasterEnum.UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_OTHER_CHANEL_API.getId());
////			}else{
////				if(OPLUtils.isObjectNullOrEmpty(status) || (!OPLUtils.isObjectNullOrEmpty(status) && status!=INT_200)) {				
////					webhookAuditDmn.setIsActive(Boolean.TRUE);
////				}else {
////					webhookAuditDmn.setIsActive(Boolean.FALSE);
////				}
////				webhookAuditDmn.setModifiedDate(new Date());
////				webhookAuditDmn.setWebhookStatus(status);
////			}
//			ClaimStatusWebhookAudit webhookAuditDmn = new ClaimStatusWebhookAudit();
//			webhookAuditDmn.setCreatedDate(new Date());
//			webhookAuditDmn.setClaimId(claimMaster.getId());
//			webhookAuditDmn.setClaimStatus(claimMaster.getClaimStatus());
//			webhookAuditDmn.setIsActive(Boolean.FALSE);
//			webhookAuditDmn.setWebhookStatus(HttpStatus.OK.value());
//			webhookAuditDmn.setUrn(claimMaster.getApplicationMaster().getUrn());
//			webhookAuditDmn.setWebhookMasterId(WebhookMasterEnum.UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_ASSISTED_MODE.getId());
//			return webhookAuditRepository.save(webhookAuditDmn);
//		}
//		return null;
//	}
//	
//	public CommonResponse updateClaimMaster(Long claimId,String urlPart) {
//		 String configUrl = properties.getValueByCode(urlPart);
//		if(null != configUrl) {
//			String url = configUrl +"/"+ claimId;
//			try {
//				HttpHeaders headers = new HttpHeaders();
//				headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
//				headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
//				headers.set("isDecrypt", "true");
//				headers.add("Accept", "application/json");
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				HttpEntity<?> entity = new HttpEntity<>(headers);
//				RestTemplate restTemplate = new RestTemplate();
//				log.info("Published Data For -->" + claimId + "==========API URL ----------->" + url);
//				CommonResponse response = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
//				if (!OPLUtils.isObjectNullOrEmpty(response) && response.getStatus() == 200) {
//					return new CommonResponse("Successfully updated!!", HttpStatus.OK.value());
//				}
//			} catch (Exception e) {
//				log.error("Exception While calling claim push details api :: ", e);
//			}
//		}
//  	   	return new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value());
//	}
//
//	/* Expire incomplete claim after 30days*/
//	public void expireClaimAfter30Days() {
//	    ExpSchedulerAudit audit = new ExpSchedulerAudit();
//	    audit.setApi(ExpSchedulerApiEnum.EXPIRE_CLAIM_AFTER_30_DAYS.getId());
//	    audit.setStartDate(new Date());
//	    audit.setStatus("Pending");
//	    audit = expSchedulerAuditRepo.save(audit);
//		try {
//			log.info("ENTER INTO updateClaimExpireStageId() AT {}", new Date());
//
//			List<Integer> claimStageId = new ArrayList<>();
//			claimStageId.add(ClaimStageMaster.CLAIM_COMPLETED.getStageId());
//			claimStageId.add(ClaimStageMaster.CLAIM_EXPIRED.getStageId());
//
//			LocalDate now = LocalDate.now();
//			LocalDate thirty = now.minusDays(30);
//			Date d = Date.from(thirty.atStartOfDay(ZoneId.systemDefault()).toInstant());
//
//			claimMasterRepo.updateClaimStageIdForExpiration(claimStageId, new Date(), d);
//
//			audit.setCompleteDate(new Date());
//			audit.setStatus("Completed");
//			expSchedulerAuditRepo.save(audit);
//		} catch (Exception e) {
//			log.error("Error while updateClaimExpireStageId", e);
//		}
//	}
//
//	@Override
//	public CommonResponse saveClaimDeDupeDetails(ClaimDeDupeDetailsProxy claimDeDupeDetailsProxy, Long userId) {
//		try {
//			ClaimMasterV3 findById = claimMasterRepo.findByIdAndClaimStageIdAndIsActiveTrue(claimDeDupeDetailsProxy.getClaimId(), ClaimStageMaster.CLAIM_COMPLETED.getStageId());
//			if (OPLUtils.isObjectNullOrEmpty(findById)) {
//				log.warn("data not Found From Claim Master");
//				return new CommonResponse("claim not found", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
//			}
//
//			Integer updateCount = claimDeDupeDetailsRepository.isActiveFalseByClaimId(claimDeDupeDetailsProxy.getClaimId(), userId);
//			if (updateCount > 0) {
//				log.info("total Update Count ----> {}", updateCount);
//			}
//
//			com.opl.jns.ere.domain.ClaimDeDupeDetails claimDeDupeDetails = new com.opl.jns.ere.domain.ClaimDeDupeDetails();
//			BeanUtils.copyProperties(claimDeDupeDetailsProxy, claimDeDupeDetails);
//			claimDeDupeDetails.setClaimMaster(findById);
//			claimDeDupeDetails.setIsActive(Boolean.TRUE);
//			claimDeDupeDetails.setCreatedBy(userId);
//			claimDeDupeDetails.setCreatedDate(new Date());
//			com.opl.jns.ere.domain.ClaimDeDupeDetails deDupeDetails = claimDeDupeDetailsRepository.save(claimDeDupeDetails);
//			
//			if (!OPLUtils.isObjectNullOrEmpty(deDupeDetails)) {
//				// python claim dedupe check
//				ClaimDedupApiResponse claimDedupApiResponse = deDupeRegistryUtility.callClaimDedupeRequest(findById,
//						deDupeDetails);
//				if (claimDedupApiResponse.getIsDup().equals(Boolean.TRUE)) {
//					List<ClaimDeDupeDetails> claimDDDetailsLst = new ArrayList<>();
//					claimDedupApiResponse.getRecords().forEach(x -> {
//						if (!OPLUtils.isListNullOrEmpty(claimDedupApiResponse.getRecords())) {
//							ClaimMasterV3 claimMaster = claimMasterRepo
//									.findByIdAndIsActiveTrue(Long.valueOf(x.getClaimRefId()));
//
//							/** SET NOMINEE TYPE */
//							List<Integer> type = new ArrayList<>();
//							type.addAll(Arrays.asList(NomineeType.NOMINEE.getId(), NomineeType.GUARDIAN.getId(),
//									NomineeType.CLAIMANT.getId()));
//
//							/** GET NOMINEE DETAILS */
//							List<NomineeDetails> nomineeDetails = nomineeDetailsRepository
//									.findByApplicationMasterIdAndTypeInAndIsActiveTrue(
//											claimMaster.getApplicationMaster().getId(), type);
//							NomineeDetails nominee = nomineeDetails.stream()
//									.filter(n -> Objects.equals(n.getType(), NomineeType.NOMINEE.getId())).findFirst()
//									.orElse(null);
//							NomineeDetails guardian = nomineeDetails.stream()
//									.filter(n -> Objects.equals(n.getType(), NomineeType.GUARDIAN.getId())).findFirst()
//									.orElse(null);
//							NomineeDetails claimant = nomineeDetails.stream()
//									.filter(n -> Objects.equals(n.getType(), NomineeType.CLAIMANT.getId())).findFirst()
//									.orElse(null);
//
//							ClaimDeDupeDetails claimDDDetails = new ClaimDeDupeDetails();
//							claimDDDetails.setDateOfLoss(getDateOfLoss(claimMaster));
//							claimDDDetails.setIntimationDate(
//									CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(claimMaster.getClaimDate()));
//							Long disabilityId = !OPLUtils
//									.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())
//											? NatureOfLoss.DISABILITY.getId().longValue()
//											: null;
//							claimDDDetails.setType(
//									!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateOfDeath())
//											? Long.valueOf(NatureOfLoss.DEATH.getId())
//											: disabilityId);
//							claimDDDetails.setUrn(claimMaster.getApplicationMaster().getUrn());
//
//							String name = null;
//							if (!OPLUtils.isObjectNullOrEmpty(claimant)) {
//								name = setFullName(claimant.getFirstName(), claimant.getMiddleName(),
//										claimant.getLastName());
//							} else if (!OPLUtils.isObjectNullOrEmpty(guardian)) {
//								name = setFullName(guardian.getFirstName(), guardian.getMiddleName(),
//										guardian.getLastName());
//							} else if (!OPLUtils.isObjectNullOrEmpty(nominee)) {
//								name = setFullName(nominee.getFirstName(), nominee.getMiddleName(),
//										nominee.getLastName());
//							}
//
//							claimDDDetails.setBeneficiaryName(name);
//							claimDDDetails.setBeneficiaryBank(claimMaster.getClaimDetail().getNameOfBank());
//							claimDDDetailsLst.add(claimDDDetails);
//						}
//					});
//					return new CommonResponse("successfully save data", claimDDDetailsLst, HttpStatus.OK.value(),
//							Boolean.TRUE);
//				}
//				return new CommonResponse("successfully save data", deDupeDetails.getId(), HttpStatus.OK.value(),
//						Boolean.TRUE);
//			}
//		} catch (Exception e) {
//			log.error("error is getting while save Claim Dedupe Details", e);
//		}
//		return new CommonResponse("error is getting while save Claim Dedupe Details", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
//	}
//
//	
//	/**GET NATURE OF LOSS*/
//	public String getDateOfLoss(ClaimMasterV3 master) {
//		try {
//			if (master.getApplicationMaster().getSchemeId().intValue() == SchemeMaster.PMSBY.getId()) {
//				if (!OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getNatureOfLossId())
//						&& master.getClaimDetail().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
//					return CommonUtils.sdf.format(master.getClaimDetail().getDateOfDeath());
//				} else {
//					return CommonUtils.sdf.format(master.getClaimDetail().getDateTimeOfAccident());
//				}
//
//			} else if (master.getApplicationMaster().getSchemeId().intValue() == SchemeMaster.PMJJBY.getId()) {
//				return CommonUtils.sdf.format(master.getClaimDetail().getDateOfDeath());
//			}
//		} catch (Exception e) {
//			log.error("Error while getDateOfLoss() ", e);
//		}
//		return null;
//	}
//	
//	/**GET FULL NAME*/
//	private String setFullName(String firstName, String middleName, String lastName) {
//		return (!OPLUtils.isObjectNullOrEmpty(firstName) ? firstName : "") + " "
//				+ (!OPLUtils.isObjectNullOrEmpty(middleName) ? middleName : "") + " "
//				+ (!OPLUtils.isObjectNullOrEmpty(lastName) ? lastName : "");
//	}
//	
//	@Override
//	public CommonResponse getClaimDeDupeDetails(Long cliamId) {
//		try {
//			com.opl.jns.ere.domain.ClaimDeDupeDetails deDupeDetails = claimDeDupeDetailsRepository.findByClaimMasterIdAndIsActiveTrue(cliamId);
//			if (OPLUtils.isObjectNullOrEmpty(deDupeDetails)) {
//				log.warn("data not Found From Claim Master");
//				return new CommonResponse("data not Found From Claim Master", HttpStatus.NO_CONTENT.value(), Boolean.FALSE);
//			}
//
//			ClaimDeDupeDetailsProxy claimDeDupeDetailsProxy = new ClaimDeDupeDetailsProxy();
//			BeanUtils.copyProperties(deDupeDetails, claimDeDupeDetailsProxy);
//			claimDeDupeDetailsProxy.setClaimId(deDupeDetails.getClaimMaster().getId());
//			return new CommonResponse("successfully save data", claimDeDupeDetailsProxy, HttpStatus.OK.value(), Boolean.TRUE);
//		} catch (Exception e) {
//			return new CommonResponse("error is getting while save Claim Dedupe Details", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
//		}
//	}
//
//}
