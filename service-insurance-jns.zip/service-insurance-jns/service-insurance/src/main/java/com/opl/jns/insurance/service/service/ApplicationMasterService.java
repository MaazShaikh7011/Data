package com.opl.jns.insurance.service.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.OptOutProxy;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.utils.common.CommonResponse;

@Service
public interface ApplicationMasterService {

    public CommonResponse create(ApplicationMasterRequest req, AuthClientResponse authClientResponse) throws InsuranceException, Exception;

    public CommonResponse updateStage(ApplicationMasterRequestV2 appMasterReq, AuthClientResponse authClientResponse) throws InsuranceException;

    public CommonResponse getStageDetails(Long applicationId) throws InsuranceException;

//    public CommonResponse publishedData(Long applicationId);

    CommonResponse getOptOutAccountHolderList(ApplicationMasterRequest applicationMasterRequest, AuthClientResponse authClientResponse);

	public CommonResponse getAccountHolderDetailsOptOut(ApplicationMasterRequest applicationMasterRequest,
			AuthClientResponse authClientResponse);

	public CommonResponse saveOptOut(OptOutProxy optOutProxy, AuthClientResponse authClientResponse);
	
    public CommonResponse optOut(Date date);

//	public void UploadStaticData(String req) throws InsuranceException;

//    public void updateApplicationHistory(ApplicationMasterV3 master);

    public void sendCoiToApplicant(Long applicationId, ApplicationMasterV3 master);

//    public void pushApplicationHasError(int page,int count);

    void expireAssistedModeApplications();
    void expireOtherChannelApplications();

    void pushApplication(Long applicationId);
    
    void pushNomineeUpdateApplication(Long applicationId,Long schemeId);

//    CommonResponse rejectApplication(RejectionRequest rejectionRequest, AuthClientResponse authClientResponse);

    //void pushSingleEnrollmentToRegistry(Long applicationId, ApplicationMasterV3 master);

    public void sendCoiToApplicantNewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantDetails,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomneeAddress);
    
    CommonResponse getConsentList(List<Integer> consentTypeId);
}
