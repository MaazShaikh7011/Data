package com.opl.jns.insurance.service.schedulers;

//package com.opl.service.insurance.jns.schedulers;
//
//import java.util.Date;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import com.opl.jns.config.utils.EnvironmentUtils;
//import com.opl.service.insurance.jns.service.ApplicationMasterService;
//import com.opl.service.insurance.jns.service.ClaimMasterService;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author - Maaz Shaikh
// * @Date - 6/26/2023
// */
//@Component
//@Slf4j
//public class PushRetryScheduler {
//
//
//	@Autowired
//	ClaimMasterService claimMasterService;
//
//	@Autowired
//	ApplicationMasterService applicationMasterService;
//
//	/**
//	 * In case of any error, this scheduler re-try it max 3 times This scheduler run
//	 * at every minute
//	 */
//	@Scheduled(fixedDelay = 300000)
//	public void pushApplicationsInCaseOfNotPushed() {
//		String value = EnvironmentUtils.PUSH_READY_SCHEDULER_ENABLE.getValue();
//		if ("ON".equalsIgnoreCase(value)) {
//			log.info("application and claim scheduler for pushing the data =====> Start at :[{}]", new Date());
//
//			// Enrollment And COI
//			applicationMasterService.pushApplicationHasError(0,1000);
//
//			// Push Claim
//			claimMasterService.pushRemainingClaim();
//		} else {
//			log.info("PUSH READY APPLICATION SCHEDULE OFF FROM ENVIRONMENT PROPERTY");
//		}
//
//	}
//
////    /**
////     * Scheduler check the premium deduction Failure cases if exist then retry them 3 times
////     * its check every hour
////     * */
////    @Scheduled(cron = "0 0 * ? * *")
////    public void checkIfAnyApplicationFailedAtPremiumDeduction(){
////        log.info("checking if any application failed at premium deduction stage =====> Start at :[{}]",new Date());
////        envService.checkIfAnyApplicationFailedAtPremiumDeduction();
////    }
//
//}

