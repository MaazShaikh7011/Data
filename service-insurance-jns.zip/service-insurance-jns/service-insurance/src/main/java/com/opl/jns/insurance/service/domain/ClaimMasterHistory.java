package com.opl.jns.insurance.service.domain;
//package com.opl.service.insurance.jns.domain;
//
//import com.opl.jns.utils.constant.*;
//import lombok.*;
//
//import javax.persistence.*;
//import java.util.*;
//
//@Setter
//@Getter
//@EqualsAndHashCode(callSuper = false)
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "claim_master_history")
//public class ClaimMasterHistory {
//
//	@Id
//    @Column(name = "id")
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "claim_master_history_seq_gen")
//    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "claim_master_history_seq_gen", sequenceName = "claim_master_history_seq_gen", allocationSize = 1)
//    private Long id;
//
//
//	@Column(name = "claim_id", nullable = false)
//	private Long claimId;
//
//	@Column(name = "application_id", nullable = true)
//	private Long applicationId;
//
//	@Column(name = "claim_stage_id", nullable = true)
//	private Integer claimStageId;
//
//	@Column(name = "claim_status", nullable = true)
//	private Integer claimStatus;
//
//	@Column(name = "created_date", nullable = true)
//	private Date createdDate;
//
//
//	public ClaimMasterHistory(Long claimId, Long applicationId, Integer stageId, Integer claimStatus){
//		this.claimId = claimId;
//		this.applicationId = applicationId;
//		this.claimStageId = stageId;
//		this.claimStatus = claimStatus;
//	}
//}
