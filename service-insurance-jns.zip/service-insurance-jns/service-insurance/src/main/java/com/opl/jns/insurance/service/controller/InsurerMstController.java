package com.opl.jns.insurance.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.insurance.api.model.InsurerMstDetailsProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.insurance.service.service.InsuranceMasterService;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
// OLD : mst
@RequestMapping("/V3/insurer")
@Slf4j
public class InsurerMstController {

	@Autowired
	private InsuranceMasterService insuranceMasterService;

	/**
	 * FETCH INSURER DETAILS IN HO LOGIN
	 * 
	 * @param id
	 * @return OLD : getInsurerMstDetails
	 */
	@GetMapping(value = "/getInsurerMstDetailsById/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@SkipInterceptor
	public ResponseEntity<CommonResponse> get(@PathVariable Long id) {
		try {
			return new ResponseEntity<CommonResponse>(
					new CommonResponse("Successfully get Insurance mst Details!!",
							insuranceMasterService.getInsurerMstDetailsById(id), HttpStatus.OK.value(), true),
					HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while get Insurance mst details of Teaser Insuarance ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * UPDATE INSURER DETAILS (HO LOGIN)
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return OLD : saveInsurerMstDetails
	 */
	@PostMapping(value = "/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> save(@RequestBody InsurerMstDetailsRequest req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			req.setModifiedBy(authClientResponse.getUserId());
			return new ResponseEntity<>(insuranceMasterService.save(req,authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while save Insurance mst details of Teaser Insuarance ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * FETCH INSURER LIST
	 *
	 * @param userTypeId
	 * @param schemeId
	 * @return OLD : getInsurers
	 */
	@GetMapping(value = "/getOrgMasterListByUserTypeId/{userTypeId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getList(@PathVariable Long userTypeId,
			@PathVariable Long schemeId) {
		try {
			log.info("Enter in fetch Insurer details ------------------>");
			CommonResponse orgMasterList = insuranceMasterService.getOrgMasterListByUserTypeId(userTypeId, schemeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no orgMaster list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(orgMasterList, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getInsurerList :", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * FETCH BANK LIST
	 *
	 * @param userTypeId
	 * @param schemeId
	 * @return OLD : getInsurers
	 */
	@GetMapping(value = "/getOrganisationMstListByUserTypeId/{userTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getList(@PathVariable Long userTypeId) {
		try {
			log.info("Enter in fetch Insurer details ------------------>");
			CommonResponse orgMasterList = insuranceMasterService.getOrganisationMstListByUserTypeId(userTypeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no orgMaster list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(orgMasterList, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getInsurerList :", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * FETCH APPLICATION LIST FOR INSURER APPLICATION LIST
	 * 
	 * @param request
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/fetchInsurerApplicationList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchInsurerApplicationList(@RequestBody String request,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter In fetchInsurerApplicationList----------->");
			CommonResponse commonRes = insuranceMasterService.fetchInsurerApplicationList(request,
					authClientResponse.getUserId());
			if (OPLUtils.isObjectNullOrEmpty(commonRes)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems system has not found details by requested details",
								HttpStatus.OK.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA,
					commonRes.getData(), HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in fetchInsurerApplicationList :", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * FETCH INSURER DETAILS BY SCHEME ID AND ORG ID
	 * 
	 * @param schemeId
	 * @param orgId
	 * @param mode
	 * @return
	 */
	@GetMapping(value = "/getInsurerDetailsBySchemeIdAndOrgId/{schemeId}/{orgId}/{mode}", produces = MediaType.APPLICATION_JSON_VALUE)
	@SkipInterceptor
	public ResponseEntity<CommonResponse> getInsurerDetailsById(@PathVariable Long schemeId,
			@PathVariable Long orgId, @PathVariable Integer mode) {
		try {
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Insurance mst Details!!",
					insuranceMasterService.getInsurerDetailsBySchemeIdAndOrgId(schemeId, orgId, mode),
					HttpStatus.OK.value(), true), HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while get Insurance mst details of Teaser Insuarance ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * GET INSURER RECORD FOR VALIDATION
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/getInsurerDataByStartAndEndDate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getInsurerDataByStartAndEndDate(@RequestBody InsurerMstDetailsRequest req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			return new ResponseEntity<>(insuranceMasterService.getInsurerDataByStartAndEndDate(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while save Insurance mst details of Teaser Insuarance ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * GET INSURER POLICY START AND END DATE FOR VALIDATION
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/isInsurerDetailsExistForNextYear", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getInsurerStartAndEndDate(@RequestBody InsurerMstDetailsRequest req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			return new ResponseEntity<>(insuranceMasterService.insurerStartAndEndDateValidation(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while save Insurance mst details of Teaser Insuarance ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * POLICY AND FINANCIAL DATE
	 *
	 * @param type
	 * @return
	 */
	@GetMapping(value = "/getPolicyAndFinancialYearDate/{type}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getPolicyAndFinancialYearDate(@PathVariable Integer type) {
		try {
			log.info("Enter in policyAndFinancialYearDate ------->" + type);
			return new ResponseEntity<CommonResponse>(insuranceMasterService.getPolicyAndFinancialYearDate(type),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while policyAndFinancialYearDate ------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET INSURER POLICY START AND END DATE FOR Date of Deadth 
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/getInsurerDetailsForClaim", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getInsurerDetailsForClaim(@RequestBody InsurerMstDetailsProxy req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
//			if (OPLUtils.isObjectNullOrEmpty(req.getDateOfDeath())) {
//				return new ResponseEntity<CommonResponse>(
//						new CommonResponse("Its seems system has not found details by requested details",HttpStatus.OK.value()),HttpStatus.OK);
//			}
			return new ResponseEntity<>(insuranceMasterService.getInsurerDetailsForClaim(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Insurance mst details For Claim ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
	
	/**
	 * GET INSURER POLICY START AND END DATE  
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	
	@PostMapping(value = "/getInsurerDetailsStartAndEndDate", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getInsurerDetailsStartAndEndDate(@RequestBody InsurerMstDetailsProxy req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			return new ResponseEntity<>(insuranceMasterService.getInsurerDetailsStartAndEndDate(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Insurance mst details For StartDate and EndDate ==>", e);
			return new ResponseEntity<CommonResponse>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
}
