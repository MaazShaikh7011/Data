package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Map.Entry;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.stereotype.Component;
//
//import com.opl.service.insurance.jns.domain.BranchDetails;
//import com.opl.service.insurance.jns.repository.BranchDetailsRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Component
//@Slf4j
//public class UpdateMinMaxApplicationId {
//
//	@Autowired
//	private BranchDetailsRepository branchDetailsRepository;
//
////	@Async
////	public void updateMinMaxAppId() {
////
////		Map<Integer, Integer> orgList = new HashMap<>();
////		orgList.put(27, 58139);
////		orgList.put(1, 13063);
////		orgList.put(17, 11627);
////		orgList.put(12, 10567);
////		orgList.put(4, 10566);
////		orgList.put(18, 58139);
////		orgList.put(28, 58139);
////		orgList.put(13, 14792);
////		orgList.put(25, 58139);
////		orgList.put(32, 58139);
////		orgList.put(16, 7367);
////
////		Set<Entry<Integer, Integer>> entrySet = orgList.entrySet();
////		for (Entry<Integer, Integer> rt : entrySet) {
////			update(rt.getKey().longValue(), rt.getValue());
////		}
////
////	}
//	
//	@Async
//	public void update(Long orgId, Integer total) {
//		log.info("Enter for ORGID------------------------>" + orgId);
//		List<BranchDetails> allBranchDetails = branchDetailsRepository.findAllByOrgId(orgId);
//		int size = allBranchDetails.size();
//		log.info("FOUND TOTAL ------------------------>" + size);
//		int j = 1;
//		int i = 0;
//		for (BranchDetails branchDetails : allBranchDetails) {
//			log.info("ORG---------"+orgId+"------LOOP--------------->" + j + "-------FROM--------" + size);
//			i++;
//			branchDetails.setApplicationMin(Long.valueOf(i));
//			i = i + total;
//			branchDetails.setApplicationMax(Long.valueOf(i));
//			branchDetails.setIsUpdate(true);
//			branchDetailsRepository.save(branchDetails);
//			j++;
//		}
//	}
//}
