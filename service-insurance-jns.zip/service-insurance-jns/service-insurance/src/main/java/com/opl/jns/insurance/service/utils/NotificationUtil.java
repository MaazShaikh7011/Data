package com.opl.jns.insurance.service.utils;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.emailNotification.ContentAttachment;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class NotificationUtil {

	@Autowired
    private NotificationClient notificationClient;
		
	public void sendNotification(Map<String, Object> emailParameters, String toEmail, String toSms, Long emailTempId, Long smsTempId, List<ContentAttachment> attachments)
	{	
//		log.info("entry in sendNotification()");

		String[] toEmailAry = { toEmail };
		String[] toSmsAry = { 91 + toSms };

		NotificationRequest notificationRequest = new NotificationRequest();
		if(!OPLUtils.isObjectNullOrEmpty(toEmail) && !OPLUtils.isObjectNullOrEmpty(emailTempId)) {
			Notification emailNoti = NotificationClient.prepareRequestForSmsOrEmail(toEmailAry, emailParameters, emailTempId, attachments, NotificationType.EMAIL);
			notificationRequest.addNotification(emailNoti);
		}

		if(!OPLUtils.isObjectNullOrEmpty(toSms) && !OPLUtils.isObjectNullOrEmpty(smsTempId)) {
			Notification smsNoti = NotificationClient.prepareRequestForSmsOrEmail(toSmsAry, emailParameters, smsTempId, null, NotificationType.SMS);
			notificationRequest.addNotification(smsNoti);
		}

		if(!OPLUtils.isListNullOrEmpty(notificationRequest.getNotifications()) && !notificationRequest.getNotifications().isEmpty()) {
			 notificationClient.send(notificationRequest);
			 log.info("Notification sent successfully");
		}
	
	}
}