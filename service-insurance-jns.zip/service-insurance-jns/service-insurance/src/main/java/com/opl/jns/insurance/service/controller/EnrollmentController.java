package com.opl.jns.insurance.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.ere.service.UtilizeFuzzyApiService;
import com.opl.jns.insurance.api.model.AccountHolderMappingRequest;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.CertificateInsDtlRequest;
import com.opl.jns.insurance.api.model.EnrollmentDetailsProxy;
import com.opl.jns.insurance.api.model.EnrollmentDtlProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.insurance.api.model.PremiumDeductionFailedProxy;
import com.opl.jns.insurance.api.model.RegenerateCoiProxy;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.insurance.api.model.v2.AccHolderListReq;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.api.model.v2.GetCoiReq;
import com.opl.jns.insurance.api.model.v2.PremiumPopupRequest;
import com.opl.jns.insurance.service.service.ApplicationMasterService;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.insurance.service.utils.ResponseStatus;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.FuzzyApiStageEnum;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3/enrollment")
@Slf4j
public class EnrollmentController {

	@Autowired
	EnrollmentService enrollmentService;

	@Autowired
	ApplicationMasterService applicationMasterService;

	@Autowired
	private UtilizeFuzzyApiService utilizeFuzzyApiService;
	
	/**
	 * Second Screen
	 * 2. Borrower have to Select
	 * I.  Verification  Code
	 * II. Physical Signature Verification
	 *
	 * 2. Verification or  Physical Signature Verification  both call that after
	 *
	 */
	/**
	 *
	 * Update Enrollment Verification Type Send OTP / PHYSICAL VERIFICATION
	 *
	 * @param applicationId
	 * @param typeOfVerification
	 * @param authClientResponse
	 * @return
	 */
	@GetMapping(value = "/updateEnrollmentVerificationType/{applicationId}/{typeOfVerification}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> updateEnrollmentVerificationType(@PathVariable Long applicationId, @PathVariable Integer typeOfVerification,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationId) || OPLUtils.isObjectNullOrEmpty(typeOfVerification)) {
				log.error("Missing Requested parameter are missing in update enrollment verification type");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in update Enrollment Verification Type ------------>" + applicationId);
			return new ResponseEntity<CommonResponse>(enrollmentService.updateEnrollmentVerificationType(applicationId, typeOfVerification, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update enrollment verification type ---------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * 2.2
	 * if user select  2.2  Physical Signature Verification done
	 *
	 *  then api call here
	 */

	/**
	 * FETCH ACCOUNT HOLDER DETAILS IN ENROLLMENT JOURNEY WHILE PHYSICAL SIGNATURE
	 * VERIFICATION
	 *
	 * @param req
	 * @return
	 */
	@PostMapping(value = "/verifyPhysicalSignature", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> verifyPhysicalSignature(@RequestBody VerfiyOtpRequest req, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in verify physical signature details -----> " + req.getApplicationId());
			return new ResponseEntity<CommonResponse>(enrollmentService.verifyPhysicalSignature(req.getApplicationId(), authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while verify physical signature details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Second screen after Verification  Code
	 * if user selected 'Verification  Code' then otp verfy here
	 *
	 *  2.1 Verify OTP
	 * Verify OTP
	 *
	 * @param verifyOtpReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/verifyOtp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> verifyOtp(@RequestBody VerfiyOtpRequest verifyOtpReq, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in Verify OTP ------------> " + verifyOtpReq.getApplicationId());
			verifyOtpReq.setUserId(authClientResponse.getUserId());
			return new ResponseEntity<CommonResponse>(enrollmentService.verifyOtp(verifyOtpReq, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while verify Verification Code ------------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Resend OTP
	 *
	 * @param applicationId
	 * @param authClientResponse
	 * @return
	 */
	@GetMapping(value = "/resendOTP/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> resendOTP(@PathVariable Long applicationId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
				log.info("Application ID is null or empty in resend OTP API ");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in Resend OTP -------------->" + applicationId);
			return new ResponseEntity<CommonResponse>(enrollmentService.updateEnrollmentVerificationType(applicationId, CommonUtils.ENROLLMENT_VERIFICATION_OTP, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while resend OTP ------------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * 3. UPDATE SELECTED HOLDER DETAILS
	 * Third screen
	 * A/C Holder's Details
	 *
	 * After Physical Signature Verification or OTP
	 *
	 * borrower have to selected user on page
	 */

	/**
	 * UPDATE SELECTED HOLDER DETAILS
	 *
	 * @param selectedHolder
	 * @return
	 */
	@PostMapping(value = "/updateSelectedAccountHolder", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> updateSelectedAccountHolder(@RequestBody AccountHolderMappingRequest selectedHolder, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (null == selectedHolder.getApplicationId() || null == selectedHolder.getCif() || selectedHolder.getCif().isEmpty()) {
				log.error("Missing Requested parameter are missing in save selected holder details");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in save selected account holder details --------> " + selectedHolder.getApplicationId());
			CommonResponse commonResponse = enrollmentService.updateSelectedAccountHolder(selectedHolder, authClientResponse);
			return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update selected account holder details  ------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);

		}
	}

	/**
	 * 3.1 getApplicationFormDetails ( FETCH ENROLLMENT APPLICATION FORM DETAILS)
	 * FETCH ENROLLMENT APPLICATION FORM DETAILS
	 *
	 * @param applicationId
	 * @param authClientResponse
	 * @return
	 */
	@GetMapping(value = "/getApplicationFormDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getApplicationFormDetails(@PathVariable Long applicationId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in get application form details ---->" + applicationId);
			ApplicationMasterRequestV2 appMasterReq = enrollmentService.getApplicationFormDetails(applicationId, authClientResponse);
			if (appMasterReq == null) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems we have not found details by given information, kindly refresh page and try again", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Account Holder Details!!", appMasterReq, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Third Screen
	 * After select 'A/C Holder's Details' user have to fill details after save call this api
	 * 3.2 saveApplicationFormDetails (SAVE ENTOLLMENT APPLICATION FORM DETAILS)
	 */
	/**
	 * SAVE ENTOLLMENT APPLICATION FORM DETAILS
	 *
	 * @param appMasterReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/saveApplicationFormDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveApplicationFormDetails(@RequestBody ApplicationMasterRequest appMasterReq, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (CommonUtils.isObjectNull(appMasterReq.getApplicationId())) {
				log.error("ApplicationId is null or empty while saving application form details ---->");
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems we have not found mandatory request parameter, please try after some time", HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in save application form details ---->" + appMasterReq.getApplicationId());
			appMasterReq.setModifiedBy(authClientResponse.getUserId());
			return new ResponseEntity<CommonResponse>(enrollmentService.saveApplicationFormDetails(appMasterReq, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saving application form details ---->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Fifth Screen
	 * 5. getAccountHolderAndInsurerDetails (FETCH ACCOUNT HOLDER AND INSUER DETAILS BEFORE PREMIUM DEDUCTION)
	 *
	 * after submit premium details get Borrower Acc number and Insurer Company Details
	 */
	/**
	 *
	 * FETCH ACCOUNT HOLDER AND INSUER DETAILS BEFORE PREMIUM DEDUCTION
	 *
	 * @param applicationId
	 * @param httpServletRequest
	 * @return
	 */
	@GetMapping(value = "/getAccountHolderAndInsurerDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getAccountHolderAndInsurerDetails(@PathVariable Long applicationId, HttpServletRequest httpServletRequest) {
		try {
			InsurerMstDetailsRequest insurerDetails = enrollmentService.getAccountHolderAndInsurerDetails(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(insurerDetails)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.OK.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, insurerDetails, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getAccountHolderAndInsurerDetails :", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Fourth Sceern
	 * 4. getPremiumPopupDetails (FETCH PREMIUM DETAILS)
	 *
	 * after submit user details call this api for check Premium amount
	 */
	/**
	 *
	 * FETCH PREMIUM DETAILS
	 *
	 * @param applicationId
	 * @return
	 */
	@GetMapping(value = "/getPremiumPopupDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getPremiumPopupDetails(@PathVariable Long applicationId) {
		try {
			PremiumPopupRequest premiumDetails = enrollmentService.getPremiumPopupDetails(applicationId);
			if (OPLUtils.isObjectNullOrEmpty(premiumDetails)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems system has not found details by given application details, please try after sometime", HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully fetch details", premiumDetails, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getting getPremiumPopupDetails :", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Six Screen
	 * 6. premiumDeduction (PREMIUM DEDUCTION)
	 * premiumDeduction
	 * After select user acc no and Insurer Details on submit make premium Deduction
	 *
	 * IMP
	 * why we call 2 times updateStage and getStageDetails api on fronte end side
	 *
	 */
	/**
	 *
	 * PREMIUM DEDUCTION
	 *
	 * @param appMasterReq
	 * @return
	 * Utilize Fuzzy
	 */
	@PostMapping(value = "/premiumDeduction", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> premiumDeduction(@RequestBody ApplicationMasterRequest appMasterReq, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {

			if (CommonUtils.isObjectNull(appMasterReq.getApplicationId())) {
				log.error("ApplicationId is null or empty while premium deduction ---->");
				return new ResponseEntity<>(new CommonResponse("Its seems we have not found mandatory request parameter, please try after some time", HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			
			Boolean isValidate = utilizeFuzzyApiService.handleFuzzyApiCall(appMasterReq.getApplicationId(),EnrollStageMaster.PREMIUM_DEDUCTION,FuzzyApiStageEnum.IN_PROGRESS);
			if(Boolean.FALSE.equals(isValidate))
				return new ResponseEntity<>(new CommonResponse(CommonUtils.CUSTOMER_ALREADY_INPROCESSING_ERROR, ResponseStatus.BAD_REQUEST.getStatusId(), false), HttpStatus.OK);


			log.info("Enter in premium deduction ------->" + appMasterReq.getApplicationId());
				appMasterReq.setUserId(authClientResponse.getUserId());

				CommonResponse commonResponse = enrollmentService.premiumDeduction(appMasterReq, authClientResponse);

				/** if premium deduction successfully completed after update completed stage*/
				if(!OPLUtils.isObjectNullOrEmpty(commonResponse) && commonResponse.getStatus()==HttpStatus.OK.value()) {
					ApplicationMasterRequestV2 appMasterReqquest = new ApplicationMasterRequestV2(appMasterReq.getApplicationId(),EnrollStageMaster.COMPLETED.getStageId());
					try {
						CommonResponse updateStageRes = applicationMasterService.updateStage(appMasterReqquest, authClientResponse);
						if (!OPLUtils.isObjectNullOrEmpty(updateStageRes) && !OPLUtils.isObjectNullOrEmpty(updateStageRes.getStatus()) && updateStageRes.getStatus() == HttpStatus.OK.value() && !OPLUtils.isObjectNullOrEmpty(updateStageRes.getData())
								&& (Integer.parseInt(updateStageRes.getData().toString()) == EnrollStageMaster.COMPLETED.getStageId())) {
							log.info("DATA ARE MOVING INTO API FOR READY TO PUBLISH ------------------>");

							/* PUSH THE ENROLLMENT */
							applicationMasterService.pushApplication(appMasterReq.getApplicationId());

							/* SEND EMAIL HERE */
							applicationMasterService.sendCoiToApplicant(appMasterReq.getApplicationId(),null);

							/* PUSH APPLICATION TO REGISTRY */
							//applicationMasterService.pushSingleEnrollmentToRegistry(appMasterReq.getApplicationId(),null);
						}
					} catch (Exception e) {
						log.info("Exception in updating stage while retrying app");
					}
				}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while premium deduction ------->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}finally {
			utilizeFuzzyApiService.complateFuzzyApiCallStage(appMasterReq.getApplicationId(),EnrollStageMaster.PREMIUM_DEDUCTION,FuzzyApiStageEnum.completed);
		}
	}

	/**
	 * 
	 * 7. generateCOI
	 * 
	 * certificate-of-insurance
	 * final stage
	 * 
	 */

	/**
	 * 
	 * FETCH AND DOWNLOAD COI DETAILS BASED ON IS_DOWNLOAD FLAG
	 *
	 * @param request
	 * @param httpServletRequest
	 * @return
	 */
	@PostMapping(value = "/generateCOI", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> generateCOI(@RequestBody CertificateInsDtlRequest request, HttpServletRequest httpServletRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(request) || OPLUtils.isObjectNullOrEmpty(request.getApplicationId())) {
				log.info("ApplicationId or Request are null while generate or fetch COI details");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			if (!OPLUtils.isObjectNullOrEmpty(request.getIsDownload()) && Boolean.TRUE.equals(request.getIsDownload())) {
				log.info("Enter in generate COI cerificate ---------------->" + request.getApplicationId());
				byte[] generateCOI = enrollmentService.generateCOI(request.getApplicationId(), false);
				if (!OPLUtils.isObjectListNull(generateCOI))
					return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully generate COI certificate !!", generateCOI, HttpStatus.OK.value(), true), HttpStatus.OK);
				else
					return new ResponseEntity<CommonResponse>(new CommonResponse("Its seeems application encountered some error while downlow COI", null, HttpStatus.INTERNAL_SERVER_ERROR.value(), false), HttpStatus.OK);
			} else {
				log.info("Enter in fetch COI details ---------------->" + request.getApplicationId());
				return new ResponseEntity<CommonResponse>(new CommonResponse("Succefully fetch COI details", enrollmentService.getCOIData(request.getApplicationId()), HttpStatus.OK.value(), true), HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Exception while generate or fetch COI details  ---------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * 
	 * 7. generateCOINewDb
	 * 
	 * certificate-of-insurance
	 * final stage
	 * 
	 */

	/**
	 * 
	 * FETCH AND DOWNLOAD COI DETAILS BASED ON IS_DOWNLOAD FLAG
	 *
	 * @param request
	 * @param httpServletRequest
	 * @return
	 */
	@PostMapping(value = "/generateCOINewDb", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> generateCOINewDb(@RequestBody CertificateInsDtlRequest request, HttpServletRequest httpServletRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(request) || OPLUtils.isObjectNullOrEmpty(request.getApplicationId())) {
				log.info("ApplicationId or Request are null while generate or fetch COI details");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			if (!OPLUtils.isObjectNullOrEmpty(request.getIsDownload()) && Boolean.TRUE.equals(request.getIsDownload())) {
				log.info("Enter in generate COI cerificate ---------------->" + request.getApplicationId());
				byte[] generateCOI = enrollmentService.generateCOINewDb(request, false);
				if (!OPLUtils.isObjectListNull(generateCOI))
					return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully generate COI certificate !!", generateCOI, HttpStatus.OK.value(), true), HttpStatus.OK);
				else
					return new ResponseEntity<CommonResponse>(new CommonResponse("Its seeems application encountered some error while downlow COI", null, HttpStatus.INTERNAL_SERVER_ERROR.value(), false), HttpStatus.OK);
			} else {
				log.info("Enter in fetch COI details ---------------->" + request.getApplicationId());
				return new ResponseEntity<CommonResponse>(new CommonResponse("Succefully fetch COI details", enrollmentService.getCOIDataNewDb(request), HttpStatus.OK.value(), true), HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Exception while generate or fetch COI details  ---------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * 6.1 premiumDeductionTransactionFailedCases (PREMIUM DEDUCTION TRANSACTION FAILED CASES)
	 * PREMIUM DEDUCTION TRANSACTION FAILED CASES
	 *
	 * @param premiumDeductionFailedProxy
	 * @return
	 */
	@PostMapping(value = "/premiumDeductionTransactionFailedCases", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> premiumDeductionTransactionFailedCases(@RequestBody PremiumDeductionFailedProxy premiumDeductionFailedProxy,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in premium deduction ------->" + premiumDeductionFailedProxy.getApplicationId());
			premiumDeductionFailedProxy.setUserId(authClientResponse.getUserId());
			return new ResponseEntity<CommonResponse>(enrollmentService.premiumDeductionTransactionFailedCases(premiumDeductionFailedProxy, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while premium deduction ------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	//For Admin pannel
	@GetMapping(value = "/getApplicationAllDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getApplicationAllDetails(@PathVariable Long applicationId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in get application  details ---->" + applicationId);
			ApplicationMasterRequestV2 appMasterReq = enrollmentService.getApplicationAllDetails(applicationId,null);
			if (appMasterReq == null) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("Its seems we have not found details by given information, kindly refresh page and try again", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Account Holder Details!!", appMasterReq, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/regenerate/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> regenerate(@PathVariable Long applicationId) {
		try {
			enrollmentService.generateCOI(applicationId, true);
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Account Holder Details!!", null, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/regenerateForOldApplication", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> regenerateForOldApplication(@RequestBody RegenerateCoiProxy regenerateCoiProxy) {
		try {
			enrollmentService.regenerateOldCoi(regenerateCoiProxy);
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Account Holder Details!!", null, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	@PostMapping(value = "/regenerateAndPushCoi", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> regenerateAndPushCoi(@RequestBody List<Long> applicationIds) {
		try {
			for (Long applicationId:applicationIds) {
				log.info("Generating COI for application [{}] ",applicationId);
				enrollmentService.pushStorageId(applicationId);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully get Account Holder Details!!", null, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	
	/**
	 * FOR ADMIN PANEL USE ONLY
	 * FETCH ENROLLMENT DETAILS BY URN
	 * @param applicationId
	 * @param httpServletRequest
	 * @return
	 */
	@PostMapping(value = "/fetchEnrollmentDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchEnrollmentDetails(@RequestBody EnrollmentDtlProxy enrollmentDtlProxy) {
		try {
			List<EnrollmentDetailsProxy> enrollmentDetailsProxy = enrollmentService.fetchEnrollmentDetails(enrollmentDtlProxy);
			if (OPLUtils.isListNullOrEmpty(enrollmentDetailsProxy)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, enrollmentDetailsProxy, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getAccountHolderAndInsurerDetails :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * FOR ADMIN PANEL USE ONLY
	 * FETCH fetchAllUrn BY USERID AND STAGEID
	 * @param applicationId
	 * @param httpServletRequest
	 * @return
	 */
	@PostMapping(value = "/fetchAllUrnByUrnAndStageId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchAllUrn(@RequestBody EnrollmentDtlProxy enrollmentDtlProxy) {
		try {
			List<EnrollmentDetailsProxy> enrollmentDetailsProxy = enrollmentService.fetchAllUrnByUrnAndStageId(enrollmentDtlProxy);
			if (OPLUtils.isListNullOrEmpty(enrollmentDetailsProxy)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, enrollmentDetailsProxy, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while fetchAllUrnByUrnAndStageId :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * 3.1 getApplicationFormDetailsNewDb ( FETCH ENROLLMENT APPLICATION FORM DETAILS NEW DB)
	 * FETCH ENROLLMENT APPLICATION FORM DETAILS NEW DB 
	 *
	 * @param applicationId
	 * @param authClientResponse
	 * @return
	 */
	@GetMapping(value = "/getApplicationFormDetailsNewDb/{applicationId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getApplicationFormDetailsNewDb(@PathVariable Long applicationId,@PathVariable Long schemeId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in get application form details ---->" + applicationId);
			ApplicationMasterRequestV2 appMasterReq = enrollmentService.getApplicationFormDetailsNewDb(applicationId,schemeId, authClientResponse);
			if (appMasterReq == null) {
				return new ResponseEntity<>(new CommonResponse("Its seems we have not found details by given information, kindly refresh page and try again", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new CommonResponse("Successfully get Account Holder Details!!", appMasterReq, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Application Form Details ==>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET ACCOUNT HOLDER LIST
	 * @param accHolderListRequest
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/fetchAccountHolderList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchAccountHolderList(@Valid @RequestBody AccHolderListReq accHolderListRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse  = enrollmentService.fetchAccountHolderList(accHolderListRequest,authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while fetchAccountHolderList :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET POLICY DETAILS
	 * @param policyDetailsRequest
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/fetchPolicyDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchAccountHolderList(@Valid @RequestBody PolicyDetailsRequest policyDetailsRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse = enrollmentService.fetchPolicyDetails(policyDetailsRequest,authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while fetchPolicyDetails :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * OPT-OUT UPDATE STATUS
	 * @param outUpdateStatusReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/optOutUpdateStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> optOutUpdateStatus(@Valid @RequestBody OptOutUpdateStatusRequest outUpdateStatusReq,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse = enrollmentService.optOutUpdateStatus(outUpdateStatusReq,authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while optOutUpdateStatus :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * NOMINEE UPDATE STATUS
	 * @param nomineeUpdateStatusReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/nomineeUpdateStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> nomineeUpdateStatus(@Valid @RequestBody NomineeUpdateStatusRequest nomineeUpdateStatusReq,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse = enrollmentService.nomineeUpdateStatus(nomineeUpdateStatusReq,authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while nomineeUpdateStatus :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * GET NOMINEE DETAILS
	 * @param policyDetailsRequest
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/getNomineeUpdatedetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getNomineeUpdatedetails(@RequestBody PolicyDetailsRequest policyDetailsRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse = enrollmentService.getNomineeUpdatedetails(policyDetailsRequest,
					authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(
						new CommonResponse("Its seems system has not found details by requested details",
								HttpStatus.NOT_FOUND.value(), false),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while getNomineeUpdatedetails :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET COI DETAILS
	 * @param getCoiRequest
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/getCoiDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getCoiDetails(@Valid @RequestBody GetCoiReq getCoiReq,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			CommonResponse commonResponse = enrollmentService.getCoiDetails(getCoiReq,authClientResponse);
			if (OPLUtils.isObjectNullOrEmpty(commonResponse)) {
				return new ResponseEntity<>(new CommonResponse("Its seems system has not found details by requested details", HttpStatus.NOT_FOUND.value(), false), HttpStatus.OK);
			}
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getCoiRequest :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	
	@PostMapping(value = "/generateCOIFromMaster", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> generateCOIFromMaster(@RequestBody CertificateInsDtlRequest request, HttpServletRequest httpServletRequest) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(request) || OPLUtils.isObjectNullOrEmpty(request.getApplicationId())) {
				log.info("ApplicationId or Request are null while generate or fetch COI details");
				return new ResponseEntity<CommonResponse>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

				log.info("Enter in generate COI cerificate From Master ---------------->" + request.getApplicationId());
				byte[] generateCOI = enrollmentService.generateCOIFromMaster(request.getApplicationId(), request.getSchemeId());
				if (!OPLUtils.isObjectListNull(generateCOI))
					return new ResponseEntity<CommonResponse>(new CommonResponse("Successfully generate COI certificate !!", generateCOI, HttpStatus.OK.value(), true), HttpStatus.OK);
				else
					return new ResponseEntity<CommonResponse>(new CommonResponse("Its seeems application encountered some error while downlow COI", null, HttpStatus.INTERNAL_SERVER_ERROR.value(), false), HttpStatus.OK);
			
		} catch (Exception e) {
			log.error("Exception while generate or fetch COI details From Master   ---------->", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * nominee update save api
	 * saveApplicationFormDetailsNewDb (SAVE ENTOLLMENT APPLICATION FORM DETAILS)
	 */
	/**
	 * SAVE NOMINEE UPDATE APPLICATION FORM DETAILS
	 *
	 * @param appMasterReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/saveApplicationFormDetailsNewDb", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveApplicationFormDetailsNewDb(@RequestBody ApplicationMasterRequest appMasterReq, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (CommonUtils.isObjectNull(appMasterReq.getApplicationId())) {
				log.error("ApplicationId is null or empty while saving application form details ---->");
				return new ResponseEntity<>(new CommonResponse("Its seems we have not found mandatory request parameter, please try after some time", HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in save application form details new db ---->" + appMasterReq.getApplicationId());
			appMasterReq.setModifiedBy(authClientResponse.getUserId());
			return new ResponseEntity<>(enrollmentService.saveApplicationFormDetailsNewDb(appMasterReq, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saving application form details ---->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	
	/**
	 * NEW TAB POLICY SEARCH TAB GET POLICY DETAILS
	 */
	/**
	 * @param applicationId
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/getPolicyDetails/{urn}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getPolicyDetails(@PathVariable("urn") String urn) {
		try {
			log.info("ENTER IN GET POLICY DETAILS API URN -------------> " + urn);
			return new ResponseEntity<>(enrollmentService.getPolicyDetails(urn), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get policy details ---->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

}
