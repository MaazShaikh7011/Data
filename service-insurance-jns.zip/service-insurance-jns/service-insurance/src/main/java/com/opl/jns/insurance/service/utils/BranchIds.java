package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import java.util.List;
//
//public class BranchIds {
//
//	public static List<Long> SBI16 = null;
//	public static List<Long> BOB17 = null;
//	public static List<Long> BOI14 = null;
//	public static List<Long> MAHA27 = null;
//	public static List<Long> CANARA12 = null;
//	public static List<Long> CENTRAL25 = null;
//	public static List<Long> HDFC32 = null;
//	public static List<Long> ICICI4 = null;
//	public static List<Long> INDIANB13 = null;
//	public static List<Long> IOB28 = null;
//	public static List<Long> PNB18 = null;
//	public static List<Long> PSB20 = null;
//	public static List<Long> UCO19 = null;
//	public static List<Long> UBI1 = null;
//	
//	private static int generateRandomNumber(int min, int max) {
//		return min + (int) (Math.random() * ((max - min) + 1));
//	}
//	
//	public static Long getBranchId(Integer orgId) {
//		int rndNo = 0;
//		List<Long> branchIds = null;
//		switch (orgId) {
//		case 16:
//			rndNo = generateRandomNumber(0, SBI16.size()-1);
//			branchIds = SBI16;
//			break;
//		case 17:
//			rndNo = generateRandomNumber(0, BOB17.size()-1);
//			branchIds = BOB17;
//			break;
//		case 14:
//			rndNo = generateRandomNumber(0, BOI14.size()-1);
//			branchIds = BOI14;
//			break;
//		case 27:
//			rndNo = generateRandomNumber(0, MAHA27.size()-1);
//			branchIds = MAHA27;
//			break;
//		case 12:
//			rndNo = generateRandomNumber(0, CANARA12.size()-1);
//			branchIds = CANARA12;
//			break;
//		case 25:
//			rndNo = generateRandomNumber(0, CENTRAL25.size()-1);
//			branchIds = CENTRAL25;
//			break;
//		case 32:
//			rndNo = generateRandomNumber(0, HDFC32.size()-1);
//			branchIds = HDFC32;
//			break;
//		case 4:
//			rndNo = generateRandomNumber(0, ICICI4.size()-1);
//			branchIds = ICICI4;
//			break;
//		case 13:
//			rndNo = generateRandomNumber(0, INDIANB13.size()-1);
//			branchIds = INDIANB13;
//			break;
//		case 28:
//			rndNo = generateRandomNumber(0, IOB28.size()-1);
//			branchIds = IOB28;
//			break;
//		case 18:
//			rndNo = generateRandomNumber(0, PNB18.size()-1);
//			branchIds = PNB18;
//			break;
//		case 20:
//			rndNo = generateRandomNumber(0, PSB20.size()-1);
//			branchIds = PSB20;
//			break;
//		case 19:
//			rndNo = generateRandomNumber(0, UCO19.size()-1);
//			branchIds = UCO19;
//			break;
//		case 1:
//			rndNo = generateRandomNumber(0, UBI1.size()-1);
//			branchIds = UBI1;
//			break;
//
//		default:
//			break;
//		}
//		return null != branchIds ? branchIds.get(rndNo) : null;
//	}
//	
//	public static void setBranch(List<Long> branches, Integer orgId) {
//		switch (orgId) {
//		case 16:
//			SBI16 = branches;
//			break;
//		case 17:
//			BOB17 = branches;
//			break;
//		case 14:
//			BOI14 = branches;
//			break;
//		case 27:
//			MAHA27 = branches;
//			break;
//		case 12:
//			CANARA12 = branches;
//			break;
//		case 25:
//			CENTRAL25 = branches;
//			break;
//		case 32:
//			HDFC32 = branches;
//			break;
//		case 4:
//			ICICI4 = branches;
//			break;
//		case 13:
//			INDIANB13 = branches;
//			break;
//		case 28:
//			IOB28 = branches;
//			break;
//		case 18:
//			PNB18 = branches;
//			break;
//		case 20:
//			PSB20 = branches;
//			break;
//		case 19:
//			UCO19 = branches;
//			break;
//		case 1:
//			UBI1 = branches;
//			break;
//
//		default:
//			break;
//		}
//	}
//
//	public static List<Long> getSBI16() {
//		return SBI16;
//	}
//
//	public static void setSBI16(List<Long> sBI16) {
//		SBI16 = sBI16;
//	}
//
//	public static List<Long> getBOB17() {
//		return BOB17;
//	}
//
//	public static void setBOB17(List<Long> bOB17) {
//		BOB17 = bOB17;
//	}
//
//	public static List<Long> getBOI14() {
//		return BOI14;
//	}
//
//	public static void setBOI14(List<Long> bOI14) {
//		BOI14 = bOI14;
//	}
//
//	public static List<Long> getMAHA27() {
//		return MAHA27;
//	}
//
//	public static void setMAHA27(List<Long> mAHA27) {
//		MAHA27 = mAHA27;
//	}
//
//	public static List<Long> getCANARA12() {
//		return CANARA12;
//	}
//
//	public static void setCANARA12(List<Long> cANARA12) {
//		CANARA12 = cANARA12;
//	}
//
//	public static List<Long> getCENTRAL25() {
//		return CENTRAL25;
//	}
//
//	public static void setCENTRAL25(List<Long> cENTRAL25) {
//		CENTRAL25 = cENTRAL25;
//	}
//
//	public static List<Long> getHDFC32() {
//		return HDFC32;
//	}
//
//	public static void setHDFC32(List<Long> hDFC32) {
//		HDFC32 = hDFC32;
//	}
//
//	public static List<Long> getICICI4() {
//		return ICICI4;
//	}
//
//	public static void setICICI4(List<Long> iCICI4) {
//		ICICI4 = iCICI4;
//	}
//
//	public static List<Long> getINDIANB13() {
//		return INDIANB13;
//	}
//
//	public static void setINDIANB13(List<Long> iNDIANB13) {
//		INDIANB13 = iNDIANB13;
//	}
//
//	public static List<Long> getIOB28() {
//		return IOB28;
//	}
//
//	public static void setIOB28(List<Long> iOB28) {
//		IOB28 = iOB28;
//	}
//
//	public static List<Long> getPNB18() {
//		return PNB18;
//	}
//
//	public static void setPNB18(List<Long> pNB18) {
//		PNB18 = pNB18;
//	}
//
//	public static List<Long> getPSB20() {
//		return PSB20;
//	}
//
//	public static void setPSB20(List<Long> pSB20) {
//		PSB20 = pSB20;
//	}
//
//	public static List<Long> getUCO19() {
//		return UCO19;
//	}
//
//	public static void setUCO19(List<Long> uCO19) {
//		UCO19 = uCO19;
//	}
//
//	public static List<Long> getUBI1() {
//		return UBI1;
//	}
//
//	public static void setUBI1(List<Long> uBI1) {
//		UBI1 = uBI1;
//	}
//
//}
