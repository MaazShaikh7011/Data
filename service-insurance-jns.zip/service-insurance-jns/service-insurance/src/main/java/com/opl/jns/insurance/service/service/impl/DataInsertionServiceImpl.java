package com.opl.jns.insurance.service.service.impl;
//package com.opl.service.insurance.jns.service.impl;
//
//import com.opl.jns.common.client.user.management.UserManagementClient;
//import com.opl.jns.ere.domain.*;
//import com.opl.jns.ere.enums.*;
//import com.opl.jns.ere.repo.*;
//import com.opl.jns.utils.common.*;
//import com.opl.jns.utils.enums.*;
//import com.opl.service.insurance.jns.domain.BranchDetails;
//import com.opl.service.insurance.jns.repository.BranchDetailsRepository;
//import com.opl.service.insurance.jns.repository.ReportRepositoryV3;
//import com.opl.service.insurance.jns.service.*;
//import com.opl.service.insurance.jns.utils.*;
//import lombok.extern.slf4j.*;
//import org.springframework.beans.factory.annotation.*;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.scheduling.annotation.*;
//import org.springframework.stereotype.*;
//
//import java.text.*;
//import java.util.*;
//
///**
// * @author - Maaz Shaikh
// * @Date - 7/4/2023
// */
//
//@Service
//@Slf4j
//public class DataInsertionServiceImpl implements DataInsertionService {
//
//	public static final long CREATED_BY = 22l;
//	public static final String GMAIL_COM = "@gmail.com";
//	public static final String STRING = "12341235654";
//	public static final String ABCTY_1234_D = "ABCTY1234D";
//	public static final String AMBAWADI = "Ambawadi";
//	public static final String AHMEDABAD = "Ahmedabad";
//	public static final String GUJARAT = "Gujarat";
//	public static final int PINCODE = 380021;
//	public static final long CITY_ID = 783l;
//	public static final long STATE_ID = 12l;
//	public static final String AAAAA_2134_A = "AAAAA2134A";
//	public static final String PAN = "PAN";
//	public static final String AAAAA_2134_A1 = "AAAAA2134A_";
//	public static final String ABC = "ABC";
//	public static final String TEST = "Test";
//	public static final String STRING1 = "123456780000_";
//	public static final String PLATFORM = "platform";
//	public static final Random rand = new Random();
//	@Autowired
//	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepositoryV3;
//
//	@Autowired
//	private ApplicationMasterRepositoryV3 appMasterRepo;
//
//	@Autowired
//	ReportRepositoryV3 reportRepository;
//
//	@Autowired
//	private ClaimMasterRepoV3 claimMasterRepo;
//
//	@Autowired
//	private NomineeDetailsRepositoryV3 nomineeDetailsRepository;
//
//	@Autowired
//	private ClaimDetailRepoV3 claimDetailRepo;
//
//	@Autowired
//	private UserManagementClient userManagementClient;
//	
//	@Autowired
//	private BranchDetailsRepository branchDetailsRepository;
//
////	@Async
//	public void dataInsertion(int schemeId, int counter, Long orgId, Long insurerOrgId) {
//		Date curruntDate = new Date();
//		Date randomDate = getRandomeEnrollmentDate();
//		ApplicationMasterV3 appMaster = new ApplicationMasterV3();
//		appMaster.setSchemeId(schemeId);
//		appMaster.setAccountNumber("6449354548" + counter);
//		appMaster.setCif("OPL-" + counter);
//		appMaster.setOrgId(orgId);
//		appMaster.setInsurerOrgId(insurerOrgId);
//		appMaster.setCreatedDate(curruntDate);
//		appMaster.setModifiedDate(randomDate);
//		appMaster.setIsActive(Boolean.TRUE);
//		appMaster.setIsPushed(Boolean.TRUE);
//		appMaster.setStageId(EnrollStageMaster.COMPLETED.getStageId());
//		appMaster.setCreatedBy(CREATED_BY);
//		appMaster.setModifiedBy(CREATED_BY);
//		appMaster.setUserId(CREATED_BY);
//		appMaster.setDob(getRandomDate());
//		appMaster.setPremiumAmount(schemeId == 1 ? 20d : 436d);
//		appMaster.setApplicationStatus(2);
//		appMaster.setEnrollmentDate(randomDate);
//		appMaster.setStatusChangeDate(randomDate);
//		
//		
//		Long dummy = BranchIds.getBranchId(orgId.intValue());
//		Optional<BranchDetails> branchDetailsOps = branchDetailsRepository.findById(dummy);
//		if(!branchDetailsOps.isPresent()) {
//			log.info("BRANCH DETAILS NOT FOUND ------------------------------------------->");
//			return;
//		}
//		BranchDetails branchDetails = branchDetailsOps.get();
//		
//		Long branchId = branchDetails.getBranchId();
//		String branchCode = branchDetails.getBranchCode();
//		
//		String bankCode = getBankCode(orgId);
//		Calendar cal = Calendar.getInstance();
//		
//		appMaster.setBranchId(branchId);
//		
//		appMaster = appMasterRepo.save(appMaster);
//		String urn = schemeId == 1 ? "JNS-PMSSBY" : "JNS-PMJJBY";
//		urn = urn.concat(CommonUtils.CHAR_DASH).concat(CommonUtils.getPolicyYearToYear()).concat(CommonUtils.CHAR_DASH)
//				.concat(appMaster.getId().toString()).concat(CommonUtils.CHAR_DASH).concat(String.valueOf(counter));
//		appMaster.setUrn(urn);
//
//		ApplicationMasterOtherDetailsV3 otherDetails = new ApplicationMasterOtherDetailsV3();
//		otherDetails.setSource(Source.JANSURAKSHA.getId());
//		otherDetails.setTypeOfVerification(1);
//		otherDetails.setBranchCityId(branchDetails.getCityId());
//		otherDetails.setBranchStateId(branchDetails.getStateId());
//		otherDetails.setBranchCode(branchCode);
//		otherDetails.setBranchRoId(branchDetails.getRoId());
//		otherDetails.setBranchZoId(branchDetails.getZoId());
//		otherDetails.setOrgId(orgId);
//		otherDetails.setSchemeId(schemeId);
//		otherDetails.setBankCode(bankCode);
//		otherDetails.setChannelId(PLATFORM);
//
//		otherDetails.setApplicationMaster(appMaster);
//		appMaster.setApplicationMasterOtherDetails(otherDetails);
//		
//
//		// applicant info
//		ApplicantInfo info = new ApplicantInfo();
//		info.setGenderId(Gender.MALE.getId());
//		info.setAadhaar(STRING1 + counter);
//		info.setEmail(bankCode + counter + GMAIL_COM);
//		info.setDob(getRandomDate());
//		info.setFirstName(TEST + counter);
//		info.setPan(AAAAA_2134_A1 + counter);
//		info.setFatherHusbandName(ABC);
//		info.setIfsc(bankCode + counter);
//		info.setIsActive(Boolean.TRUE);
//		info.setIsPMJJBYExists(schemeId == 2 ? Boolean.TRUE : Boolean.FALSE);
//		info.setIsPMSBYExists(schemeId == 1 ? Boolean.TRUE : Boolean.FALSE);
//		info.setIsKYCUpdate(Boolean.TRUE);
//		info.setKycId1(PAN);
//		info.setKycIdNumber1(AAAAA_2134_A);
//		info.setMobileNumber(generatePhoneNumber());
//		info.setName(info.getFirstName());
//		info.setCreatedBy(CREATED_BY);
//		info.setModifiedBy(CREATED_BY);
//		info.setCreatedDate(curruntDate);
//		info.setModifiedDate(randomDate);
//		// set applicant Address
//		AddressMasterV3 address = getAddressMaster();
//		address.setApplicantInfo(info);
//		info.setAddress(address);
//		info.setApplicationMaster(appMaster);
//		appMaster.setApplicantInfo(info);
//
//		// setting nominee and guardian
//		List<NomineeDetails> nomineeList = new ArrayList<>(2);
//		nomineeList.add(prepareNomineeOfAnyType(counter, NomineeType.NOMINEE, appMaster));
//		nomineeList.add(prepareNomineeOfAnyType(counter, NomineeType.GUARDIAN, appMaster));
//		appMaster.setNomineeDetails(nomineeList);
//
//		// set transaction details
//		TransactionDetailsV3 details = new TransactionDetailsV3();
//		details.setCoverStartDate(curruntDate);
//
//
//		InsurerMstDetailsV3 mst = insurerMstDetailsRepositoryV3
//				.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
//						appMaster.getSchemeId().longValue(), appMaster.getOrgId(), policyStartDate(), policyEndDate());
//		if (OPLUtils.isObjectNullOrEmpty(mst)) {
//			mst = insurerMstDetailsRepositoryV3
//					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
//							appMaster.getSchemeId().longValue(), 13l, policyStartDate(), policyEndDate());
//		}
//		details.setMasterPolicyNo(mst.getMasterPolicyNo());
//		details.setType(EnrollmentType.ENROLLMENT.getId());
//		details.setInsurerOrgId(insurerOrgId);
//
//		Calendar coverEndDate = Calendar.getInstance();
//		coverEndDate.set(2023,6,31);
//		details.setCoverEndDate(cal.getTime());
//		details.setMasterPolicyNo(mst.getMasterPolicyNo());
//		Double amount = schemeId == 1 ? 20.0 : 430.0;
//		details.setTransAmount(amount);
//		details.setInsurerMaster(mst);
//		details.setTransTimeStamp(curruntDate);
//		details.setYear(curruntDate.getYear());
//		details.setTransUtr("UTR_" + counter);
//		details.setCoiStorageId(2941l);
//		details.setIsActive(Boolean.TRUE);
//		details.setCreatedDate(curruntDate);
//		details.setModifiedDate(randomDate);
//		details.setApplicationMaster(appMaster);
//		appMaster.setLastTransactionDetails(details);
//		appMasterRepo.save(appMaster);
//	}
//
//	private static Date policyStartDate() {
//		Calendar calendar = Calendar.getInstance();
//		calendar.set(2023, 8, 1);
//		return calendar.getTime();
//	}
//
//	private static Date policyEndDate() {
//		Calendar calendar = Calendar.getInstance();
//		calendar.set(2023, 8, 25);
//		return calendar.getTime();
//	}
//	
//	private String getBankCode(Long orgId) {
//		int org = orgId.intValue();
//		String bankCode = null;
//		switch (org) {
//		case 1:
//			bankCode = "UBI";
//			break;
//		case 4:
//			bankCode = "ICI";
//			break;
//		case 12:
//			bankCode = "CANARA";
//			break;
//		case 14:
//			bankCode = "BOI";
//			break;
//		case 16:
//			bankCode = "SBI";
//			break;
//		case 17:
//			bankCode = "BOB";
//			break;
//		case 18:
//			bankCode = "PNB";
//			break;
//		case 19:
//			bankCode = "UCO";
//			break;
//		case 20:
//			bankCode = "PSB";
//			break;
//		case 25:
//			bankCode = "CENTRAL";
//			break;
//		case 27:
//			bankCode = "MAHARASHTRA";
//			break;
//		case 28:
//			bankCode = "IOB";
//			break;
//		case 32:
//			bankCode = "HDFC";
//			break;
//		case 13:
//			bankCode = "IB";
//			break;
//		default:
//			break;
//		}
//		return bankCode;
//	}
//	
//	
//
////    @Override
//	public void claimDummyInsert(int schemeId, Long orgId) {
//		try {
//			List<ApplicationMasterV3> applicationMasterList = appMasterRepo.getApplicationIdBySchemeIdAndOrgId(orgId,
//					schemeId, PageRequest.of(0, 1));
//			ApplicationMasterV3 applicationMaster = applicationMasterList.get(0);
//			ClaimMasterV3 claimMaster = new ClaimMasterV3();
//			claimMaster.setApplicationMaster(applicationMaster);
//			claimMaster.setCreatedBy(1L);
//			claimMaster.setCreatedDate(new Date());
//			claimMaster.setIsActive(Boolean.TRUE);
//			claimMaster.setClaimStatus(ClaimStatus.CLAIM_ACCEPTED.getId());
//			claimMaster.setClaimDate(new Date());
//			claimMaster.setIsPushed(Boolean.FALSE);
//			claimMaster.setIsClaimantSame(Boolean.TRUE);
//			claimMaster.setAmountOfTransaction(200000d);
//			claimMaster.setDateOfTransaction(new Date());
//			claimMaster.setTransactionUtr("123123123" + applicationMaster.getId());
//
//			Long branchId;
//			switch (orgId.intValue()) {
//			case 1:
//				branchId = 6056L;
//				break;
//			case 4:
//				branchId = 6055L;
//				break;
//			case 14:
//				branchId = 6162L;
//				break;
//			case 16:
//				branchId = 6160L;
//				break;
//			case 17:
//				branchId = 6052L;
//				break;
//			case 18:
//				branchId = 6139L;
//				break;
//			case 19:
//				branchId = 6140L;
//				break;
//			case 25:
//				branchId = 6L;
//				break;
//			case 27:
//				branchId = 6147L;
//				break;
//			case 28:
//				branchId = 6161L;
//				break;
//			case 32:
//				branchId = 6159L;
//				break;
//			default:
//				branchId = 1L;
//			}
//			claimMaster.setClaimBranchId(branchId);
//
//			ClaimDetailV3 claimDetail = getClaimDetail(applicationMaster, claimMaster);
//			claimMaster.setClaimDetail(claimDetail);
//
//			// SET Branch Mapping Details
//			Map<String, Object> map = userManagementClient.getBranchMappingIds(claimMaster.getClaimBranchId(),
//					Long.valueOf(schemeId));
//			if (!OPLUtils.isObjectNullOrEmpty(map)) {
//				claimMaster.getClaimDetail().setBranchRoId(OPLUtils.isObjectNullOrEmpty(map.get("branchRoId")) ? null
//						: Long.valueOf(map.get("branchRoId").toString()));
//				claimMaster.getClaimDetail().setBranchZoId(OPLUtils.isObjectNullOrEmpty(map.get("branchZoId")) ? null
//						: Long.valueOf(map.get("branchZoId").toString()));
//				claimMaster.getClaimDetail().setBranchLhoId(OPLUtils.isObjectNullOrEmpty(map.get("branchLhoId")) ? null
//						: Long.valueOf(map.get("branchLhoId").toString()));
//				claimMaster.getClaimDetail().setBranchStateId(OPLUtils.isObjectNullOrEmpty(map.get("stateId")) ? null
//						: Long.valueOf(map.get("stateId").toString()));
//				claimMaster.getClaimDetail().setBranchCityId(OPLUtils.isObjectNullOrEmpty(map.get("cityId")) ? null
//						: Long.valueOf(map.get("cityId").toString()));
//			}
//
//			claimMaster.setSchemeId(schemeId);
//			claimMaster.setOrgId(orgId);
//			claimMaster.setClaimStageId(ClaimStageMaster.CLAIM_COMPLETED.getStageId());
//			claimMaster.setIsActive(Boolean.TRUE);
//			claimMaster.setCreatedDate(new Date());
//			claimMaster.setCreatedBy(1L);
//			claimMasterRepo.save(claimMaster);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	private static ClaimDetailV3 getClaimDetail(ApplicationMasterV3 applicationMaster, ClaimMasterV3 claimMaster) {
//		ClaimDetailV3 claimDetail = new ClaimDetailV3();
//		claimDetail.setDateTimeOfAccident(new Date());
//		claimDetail.setDayOfAccident("1");
//		claimDetail.setDateOfDeath(new Date());
//		claimDetail.setLocationOfLoss("Ahmedabad");
//		claimDetail.setLossLocationPincode(382345L);
//		claimDetail.setNatureOfLossId(1);
//		claimDetail.setCauseOfDeathDisabilityId(1);
//		claimDetail.setTypeOfDisablityId(1);
//		claimDetail.setFirNo(1L);
//		claimDetail.setKycDocId("1");
//		claimDetail.setClaimantBankAccountNumber("123548879" + applicationMaster.getId());
//		claimDetail.setCustIfscCode("BARB0BAPUNA");
//		claimDetail.setNameOfBank("State Bank Of India");
//		claimDetail.setClaimantKycDetails("Aadhaar Card");
//		claimDetail.setPan("HHJUY9861F");
//		claimDetail.setAadhar("9865894895" + applicationMaster.getId());
//		claimDetail.setPassport("TEST PASSPORT RV");
//		claimDetail.setDrivingLicense("2018111" + applicationMaster.getId());
//		claimDetail.setMgnerega("TEST" + applicationMaster.getId());
//		claimDetail.setVottingCardId("TEST" + applicationMaster.getId());
//		claimDetail.setIsNomineeSame(Boolean.TRUE);
//		claimDetail.setClaimMaster(claimMaster);
//		return claimDetail;
//	}
//
//	private static Date getRandomeEnrollmentDate() {
//		GregorianCalendar gc = new GregorianCalendar();
//		gc.set(Calendar.YEAR, 2023);
//		int dayOfYear = randBetween(1, gc.getActualMaximum(Calendar.DAY_OF_YEAR));
//		gc.set(Calendar.DAY_OF_YEAR, dayOfYear);
//		return gc.getTime();
//	}
//
//	private static Date getRandomDate() {
//		GregorianCalendar gc = new GregorianCalendar();
//		int year = randBetween(1940, 2023);
//		gc.set(Calendar.YEAR, year);
//		int dayOfYear = randBetween(1, gc.getActualMaximum(Calendar.DAY_OF_YEAR));
//		gc.set(Calendar.DAY_OF_YEAR, dayOfYear);
//		return gc.getTime();
//	}
//
//	private static int randBetween(int start, int end) {
//		return start + (int) Math.round(Math.random() * (end - start));
//	}
//
//	private static NomineeDetails prepareNomineeOfAnyType(double counter, NomineeType type,
//			ApplicationMasterV3 applicationMaster) {
//		NomineeDetails nomineeDetails = new NomineeDetails();
//		nomineeDetails.setEmail(type.getValue() + counter + GMAIL_COM);
//		nomineeDetails.setMobileNumber(generatePhoneNumber());
//		nomineeDetails.setFirstName(type.getValue() + counter);
//		nomineeDetails.setType(type.getId());
//		nomineeDetails.setDob(getRandomDate());
//		nomineeDetails.setRelationId(RelationShip.BROTHER.getId());
//		nomineeDetails.setAadhaarNumber(STRING + counter);
//		nomineeDetails.setIsOtherClaimant(Boolean.FALSE);
//		nomineeDetails.setPanNumber(ABCTY_1234_D + counter);
//		nomineeDetails.setAddress(getAddressMaster());
//		nomineeDetails.setName(nomineeDetails.getFirstName());
//		nomineeDetails.setIsActive(Boolean.TRUE);
//		nomineeDetails.setCreatedBy(CREATED_BY);
//		nomineeDetails.setModifiedBy(CREATED_BY);
//		nomineeDetails.setCreatedDate(new Date());
//		nomineeDetails.setModifiedDate(new Date());
//		nomineeDetails.setApplicationMaster(applicationMaster);
//		return nomineeDetails;
//	}
//
//	private static AddressMasterV3 getAddressMaster() {
//		AddressMasterV3 address = new AddressMasterV3();
//		address.setAddressLine1(AMBAWADI);
//		address.setCityName(AHMEDABAD);
//		address.setDistrict(AHMEDABAD);
//		address.setStateName(GUJARAT);
//		address.setCityId(CITY_ID);
//		address.setStateId(STATE_ID);
//		address.setPincode(PINCODE);
//		return address;
//	}
//
//	private static String generatePhoneNumber() {
//		
//		int num1 = (rand.nextInt(7) + 1) * 100 + (rand.nextInt(8) * 10) + rand.nextInt(8);
//		int num2 = rand.nextInt(743);
//		int num3 = rand.nextInt(10000);
//		DecimalFormat df3 = new DecimalFormat("000"); // 3 zeros
//		DecimalFormat df4 = new DecimalFormat("0000"); // 4 zeros
//		return df3.format(num1) + df3.format(num2) + df4.format(num3);
//	}
//
//}
