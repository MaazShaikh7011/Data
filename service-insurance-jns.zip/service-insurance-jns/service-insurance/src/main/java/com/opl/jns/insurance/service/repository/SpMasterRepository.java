package com.opl.jns.insurance.service.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.*;

import com.opl.jns.insurance.service.domain.SpMaster;

public interface SpMasterRepository extends JpaRepository<SpMaster, Long> {

	@Query(value = "CALL spGetInsurerDetailList(:filterJSON ,:userId)", nativeQuery = true)
	public List<Map<String, Object>> spGetInsurerDetailList(String filterJSON, Long userId);

	// TODO this will remove after branch updated in dummy applications
	@Query(nativeQuery = true,value = "select id from  JNS_USERS.BRANCH_MASTER where ORG_ID=:orgId and is_active=1")
	public List<Long> getBranchList(@Param("orgId") Long orgId);


}
