package com.opl.jns.insurance.service.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.insurance.service.service.DeDupeRegistryService;
import com.opl.jns.insurance.service.service.EnrollmentService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DeDupeRegistryServiceImpl implements DeDupeRegistryService {

	@Autowired
	public EnrollmentService enrollmentService;

	@Autowired
	public DedupeRegistryClient dedupeRegistryClient;

	/**
	 * first run this method and push single Enrollment
	 * 
	 *  Push Data on Python
	 * @param x2 
	 */
	/*@Async
	public void rePushSingleEnrollmentApplication(Long id, ApplicationMasterV3 appMaster) {
			try {
				if(OPLUtils.isObjectNullOrEmpty(appMaster))
					appMaster = masterRepository.findByIdAndIsActiveTrue(id);
				log.info("ENTER IN REGISTRY PUSHED APPLICATION -------------->" + appMaster.getId());
				if (appMaster.getIsActive() && EnrollStageMaster.COMPLETED.getStageId() == appMaster.getStageId()) {
					SingleEnrollmentResponse callSingleEnrollmentRequest = deDupeRegistryUtility.callSingleEnrollmentRequest(id, appMaster, "true", false);
					if (!OPLUtils.isObjectNullOrEmpty(callSingleEnrollmentRequest)) {
						if (!OPLUtils.isObjectNullOrEmpty(callSingleEnrollmentRequest.getStatus()) && callSingleEnrollmentRequest.getStatus() == HttpStatus.OK.value()) {
							log.info("SUCCESSFULLY REGISTRY PUSHED APPLICATION -------------->" + appMaster.getId());
							appOtherDetailsRepoV3.updateIsDDPushFlag(id);
						} else {
							log.info("APPLICATION ID -->" + appMaster.getId() + " --- RE-PUSHED IN REGISTRY ---> " + callSingleEnrollmentRequest.getStatus());
						}
					} else {
						log.info("APPLICATION ID -->" + appMaster.getId() + " --- SINGLE ENROLLMENT RESPONSE NULL ---> ");
					}
				} else {
					log.info("APPLICATION ID -->" + appMaster.getId() + " --- APPLICATION ISACTIVE IS FALSE OR NOT COMPLETED ---> ");
				}
			} catch (Exception e) {
				log.error("Single Enrollment Data Error -->", e);
			}
	}*/

	/**
	 * first run this method and previous push single Enrollment data status check if valid or not 
	 */
	/*@Async
	public void rePushUpdateEnrollmentStatusApplication(Long id) {
		Optional<ApplicationMasterV3> findById = masterRepository.findById(id);
		if (findById.isPresent()) {
			ApplicationMasterV3 appMaster = findById.get();
			log.info("ENTER IN REGISTRY PUSHED STATUS APPLICATION -------------->" + appMaster.getId());
			if (appMaster.getIsActive() && EnrollStageMaster.COMPLETED.getStageId() == appMaster.getStageId()) {
				try {
					UpdateEnrollResponse updateEnrollResponse = deDupeRegistryUtility.callUpdateEnrollmentStatus(id, "true", appMaster, ApplicationStatus.ENROLL_COMPLETED);
					if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse)) {
						if (!OPLUtils.isObjectNullOrEmpty(updateEnrollResponse.getStatus()) && updateEnrollResponse.getStatus() == HttpStatus.OK.value()) {
							log.info("SUCCESSFULLY REGISTRY PUSHED STATUS APPLICATION -------------->" + appMaster.getId());
							appOtherDetailsRepoV3.updateIsDDStatusPushFlag(id);
						} else if (updateEnrollResponse.getStatus() == HttpStatus.ACCEPTED.value() && "No matching URN Found in the data".equals(updateEnrollResponse.getMessage())) {
							log.info("APPLICATION ID -->" + appMaster.getId() + " --- RE-PUSHED IN REGISTRY ---> " + updateEnrollResponse.getStatus());
							rePushSingleEnrollmentApplication(id, appMaster);
						} else {
							log.error("NOT STATUS FOUND --------------->STATUS -->" + updateEnrollResponse.getStatus() + "---MSG---" + updateEnrollResponse.getMessage());
						}
					} else {
						log.error("RESPONSE NULL OR EMPTY -------------->" + appMaster.getId());
					}
				} catch (Exception e) {
					log.error("update update enrollment Status Error -->", e);
				}

			}
		}

	}*/
}
