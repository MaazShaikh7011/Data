package com.opl.jns.insurance.service.schedulers;

import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.opl.jns.config.utils.EnvironmentUtils;
import com.opl.jns.ere.repo.ApplicationMasterOtherDetailsRepositoryV3;
import com.opl.jns.insurance.service.service.DeDupeRegistryService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DeDupeRegistryScheduler {

	/*@Autowired
	private DeDupeRegistryService deDupeRegService;

	@Autowired
	private ApplicationMasterOtherDetailsRepositoryV3 appMstrOtherDetailsRepo;

	/**
	 * RE-PUSH NEW ENROLLMENT IN DE_DUPE REGISTRY IN CASE OF FAILED
	 * 
	 * @throws IOException
	 */


	//	@Scheduled(cron = "0 0 0 * * ?")
	/*@Scheduled(fixedDelay = 120000)


	public void rePushPhythonApiOnMidNight() throws IOException {
		String value = EnvironmentUtils.DE_DUPE_REGISTRY_SCHEDULER_ENABLE.getValue();
		if (value != null && "ON".equalsIgnoreCase(value)) {
			//update(0, 700);
		} else {
			log.info("DE-DUPE SCHEDULE OFF FROM ENVIRONMENT PROPERTY");
		}
	}

	/*public void update(int page, int totalNumber) {
		log.info("rePushPhythonApiOnMidNight application scheduler =====> Start at :[{}]", new Date());
		Page<Long> ids = appMstrOtherDetailsRepo.getIdsByIsDedupePushFalse(PageRequest.of(page, totalNumber));
		if (!ids.isEmpty()) {
			log.info("FOUND TOTAL APPLICATION WHICH NOT PUSHED IN REGISTRY--------------->" + ids.getSize());
			for (Long applicationId : ids) {
				deDupeRegService.rePushSingleEnrollmentApplication(applicationId, null);
			}
		}
		Page<Long> idsStatus = appMstrOtherDetailsRepo.getIdsByIsDedupeStatusPushFalse(PageRequest.of(page, totalNumber));
		if (!idsStatus.isEmpty()) {
			log.info("FOUND TOTAL APPLICATION WHICH NOT PUSHED IN REGISTRY--------------->" + idsStatus.getSize());
			for (Long applicationId : idsStatus) {
				deDupeRegService.rePushUpdateEnrollmentStatusApplication(applicationId);
			}
		}
	}*/

}
