package com.opl.jns.insurance.service.utils;

import java.io.IOException;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.enums.CauseOfDeathDisability;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.insurance.api.model.ClaimMasterRequest;
import com.opl.jns.insurance.api.model.UpdateClaimAccountHolderRequest;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.utils.DropDownMasterKey;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.users.api.model.UserOrganisationMasterResponse;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

@Component
@Transactional
@Slf4j
public abstract class ClaimAbstract {

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private OneFormClient oneFormClient;

	@Autowired
	private ConfigProperties properties;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepo;

	@Autowired
	private ClmMasterRepository clmMasterRepository;
	
	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	public static final String PMJJBY_CLAIM_AGE_LIMIT = "PMJJBY_CLAIM_AGE_LIMIT";
	public static final String PMSBY_CLAIM_AGE_LIMIT = "PMSBY_CLAIM_AGE_LIMIT";

	protected ClaimMasterRequest setBasicFields(ClaimMasterRequest claimMasterReq, ClmMaster claimMaster,
			ApplicationMasterBothSchemeProxy appMaster) throws IOException {
		/** SET BANK NAME */
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getOrgId())) {
			String orgResponse = usersClient.getOrganizationName(claimMaster.getOrgId());
			if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
				claimMasterReq.setCustBankName(orgResponse);
			}
		}

		/** FOR OPT OUT DATA */
		MiscellaneousAudit optOutData = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(
				appMaster.getId(), MiscellaneousType.OPT_OUT.getId());
		if (!OPLUtils.isObjectNullOrEmpty(optOutData)) {
			claimMasterReq.setNomineeUpdateRequestDate(optOutData.getDateOfRequest());
			claimMasterReq.setNomineeUpdateEffectiveDate(optOutData.getDateOfEffective());
		}
		
		/**SET COVER END DATE*/
		claimMasterReq = setCoverEndDate(claimMasterReq,claimMaster);

		/** SET INSURER NAME */
		CommonResponse organizationDetailsByOrgIds = usersClient.getOrganizationById(claimMaster.getInsurerOrgId());
		if (!OPLUtils.isObjectNullOrEmpty(organizationDetailsByOrgIds)
				&& organizationDetailsByOrgIds.getStatus() == HttpStatus.OK.value()) {
			UserOrganisationMasterResponse orgDetails = MultipleJSONObjectHelper
					.getObjectFromObject(organizationDetailsByOrgIds.getData(), UserOrganisationMasterResponse.class);
			claimMasterReq.setInsuranceName(orgDetails.getDisplayOrgName());
		}
		return claimMasterReq;
	}
	
	protected  ClaimMasterRequest setCoverEndDate(ClaimMasterRequest claimMasterReq,ClmMaster claimMaster) {
		ClmDetails clmDetails = claimMaster.getClmDetails();
		InsurerMstDetailsV3 insurerMstDetails = new InsurerMstDetailsV3();
		if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateOfDeath())) {
			insurerMstDetails = insurerMstDetailsRepository
					.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
							claimMaster.getSchemeId().longValue(), claimMaster.getOrgId(), clmDetails.getDateOfDeath(),
							clmDetails.getDateOfDeath());
		} else {
			if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateTimeOfAccident())) {
				insurerMstDetails = insurerMstDetailsRepository
						.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(
								claimMaster.getSchemeId().longValue(), claimMaster.getOrgId(), clmDetails.getDateTimeOfAccident(),
								clmDetails.getDateTimeOfAccident());
			}
		}
		
		if (!OPLUtils.isObjectNullOrEmpty(insurerMstDetails)) {
			claimMasterReq.setCoverEndDate(insurerMstDetails.getPolicyEndDate());
		}
		return claimMasterReq;
	}

	protected ClaimMasterRequest setClaimRelatedDetails(ClaimMasterRequest claimMasterReq, ClmMaster claimMaster,
			ClmDetails clmDetails,boolean checkPhase2) throws IOException, OneFormException {
		claimMasterReq.setFirstEnrollmentDate(claimMaster.getFirstEnrollmentDate());
		claimMasterReq.setClaimStatus(claimMaster.getStatus());
		claimMasterReq.setUrnCode(claimMaster.getUrn());
		claimMasterReq.setApplicationId(claimMaster.getApplicationId());
		claimMasterReq.setIsClaimantSame(clmDetails.getIsClaimantSame());
		claimMasterReq.setIsNomineeSame(clmDetails.getIsNomineeNameCorrection());
		claimMasterReq.setDateAndTimeOfAccident(clmDetails.getDateTimeOfAccident());
		claimMasterReq.setDayOfAccident(clmDetails.getDayOfAccident());
		claimMasterReq.setDateOfDeath(clmDetails.getDateOfDeath());
		claimMasterReq.setLocationOfLoss(clmDetails.getPlaceOfOccurrence());
		claimMasterReq.setNatureOfLoss(clmDetails.getNatureOfLossId());
		claimMasterReq.setCauseOfDeathDisability(clmDetails.getCauseOfDeathDisabilityId());
		if (!OPLUtils.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId())) {
			claimMasterReq.setTypeOfDisablity(clmDetails.getTypeOfDisabilityId().longValue());
		}
		if (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
			String typeOfDisability = getValueById(DropDownMasterKey.TYPE_OF_DISABILITY,
					claimMaster.getClmDetails().getTypeOfDisabilityId());
			claimMasterReq.setTypeOfDisablityValue(typeOfDisability);
		}
		claimMasterReq.setClaimantBankAcNumber(claimMaster.getClmDetails().getClmPIDetails().getClmAccountNumber());
		claimMasterReq.setCustIfscCode(claimMaster.getClmDetails().getClmPIDetails().getClmBranchIfsc());
		claimMasterReq.setNameOfBank(claimMaster.getClmDetails().getClmPIDetails().getClmBankName());
		claimMasterReq.setClmKycId1(claimMaster.getClmDetails().getClmPIDetails().getClmKycId1());
		claimMasterReq.setClmKycIdNumber1(claimMaster.getClmDetails().getClmPIDetails().getClmKycIdNumber1());
		claimMasterReq.setClmKycId2(claimMaster.getClmDetails().getClmPIDetails().getClmKycId2());
		claimMasterReq.setClmKycIdNumber2(claimMaster.getClmDetails().getClmPIDetails().getClmKycIdNumber2());
		claimMasterReq.setIsDateOfDeath(claimMaster.getClmDetails().getIsDateOfDeath());
		claimMasterReq.setIsDateTimeOfAccident(claimMaster.getClmDetails().getIsDateTimeOfAccident());
		try {
			Integer docTypeId = null;
			String docTitle = null;
			if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				if (claimMaster.getSchemeId() == SchemeMaster.PMSBY.getId().intValue()
						&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId())) {
					docTitle = getValueById(DropDownMasterKey.NATURE_OF_LOSS,
							claimMaster.getClmDetails().getNatureOfLossId());
					docTypeId = claimMaster.getClmDetails().getNatureOfLossId();
				} else if (claimMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().intValue()
						&& !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())) {
					if(checkPhase2) {
						docTitle = CauseOfDeathDisabilityV2.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
								.getValue();
					}else {
						docTitle = CauseOfDeathDisability.fromId(claimMaster.getClmDetails().getCauseOfDeathDisabilityId())
								.getValue();
					}
					docTypeId = claimMaster.getClmDetails().getCauseOfDeathDisabilityId();
				}
			}
			claimMasterReq.setDocTypeId(docTypeId);
			claimMasterReq.setDocTitle(docTitle);
		} catch (Exception e) {
			log.error("Exception is getting while get value from one form client", e);
		}
		return claimMasterReq;
	}

	protected Boolean checkAgeValidation(ClmMaster claimMaster, ClmDetails clmDetails, ClmPIDetails clmPIDetails,
			Boolean isAgeValid) {
		String claimAgeLimit = null;
		String[] claimAgeLimitArray = null;
		if (claimMaster.getSchemeId().intValue() == SchemeMaster.PMJJBY.getId()) {
			claimAgeLimit = properties.getValueByCode(PMJJBY_CLAIM_AGE_LIMIT);
			claimAgeLimitArray = claimAgeLimit.split(",");
			isAgeValid = OPLUtils.getAgeCriteriaValidation(claimMaster.getSchemeId().intValue(),
					clmPIDetails.getApDob(), clmDetails.getDateOfDeath(), claimAgeLimitArray);
		} else {
			claimAgeLimit = properties.getValueByCode(PMSBY_CLAIM_AGE_LIMIT);
			claimAgeLimitArray = claimAgeLimit.split(",");
			isAgeValid = OPLUtils.getAgeCriteriaValidation(claimMaster.getSchemeId().intValue(),
					clmPIDetails.getApDob(), clmDetails.getDateTimeOfAccident(), claimAgeLimitArray);
		}
		return isAgeValid;
	}

	protected CommonResponse checkPMSBYDedupe(ApplicationMasterBothSchemeProxy appMaster,Integer schemeId) {
		List<Integer> statusList = new ArrayList<>();
		statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
		statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());

		// PMSBY Multi Claim Validation check(Max 2 claim allowed)
		if (SchemeMaster.PMSBY.getId().intValue() == schemeId) {
			Long count = clmMasterRepository
					.countByApplicationIdAndIsActiveTrueAndStatusIn(appMaster.getId(), statusList);
			if (!OPLUtils.isObjectNullOrEmpty(count) && count >= CommonUtils.LONG_2) {
				return new CommonResponse(CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG, HttpStatus.CREATED.value(),
						false);
			} else {
				statusList.clear();
				statusList.add(ClaimStatus.CLAIM_IN_PROGRESS.getId());
				count = clmMasterRepository.countByApplicationIdAndIsActiveTrueAndStatusIn(
						appMaster.getId(), statusList);
				if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
					return new CommonResponse(CommonUtils.CLAIM_SUBMISSION_IN_PROGRESS_MSG, HttpStatus.CREATED.value(),
							false);
				}
			}
		}
		return null;
	}

	protected CommonResponse deDupeLogic(ClmMaster clmMaster) {
		
		if(!OPLUtils.isObjectNullOrEmpty(clmMaster.getSource()) && !Objects.equals(clmMaster.getSource(), Source.JANSURAKSHA.getId())) {
			if(Objects.equals(clmMaster.getStatus(), ClaimStatus.CLAIM_IN_PROGRESS.getId())) {
				return new CommonResponse(CommonUtils.CLAIM_INITIATED_OTR_SRC_MSG, HttpStatus.CREATED.value(), false);
			}
		}
		if (clmMaster.getStageId() == ClaimStageMaster.CLAIM_FORM.getStageId()
				|| clmMaster.getStageId() == ClaimStageMaster.CLAIM_UPLOAD_DOCUMENT.getStageId()) {
			return new CommonResponse(CommonUtils.CLAIM_INITIATED_MSG, HttpStatus.CREATED.value(), false);
		} else if (clmMaster.getStageId() == ClaimStageMaster.CLAIM_COMPLETED.getStageId()) {
			if (SchemeMaster.PMJJBY.getId().intValue() == clmMaster.getSchemeId()) {
				if (ClaimStatus.CLAIM_REJECTED.getId().equals(clmMaster.getStatus()) && clmMaster.getClmDetails()
						.getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId())) {
					return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG,
							HttpStatus.CREATED.value(), false);
				} else if (ClaimStatus.CLAIM_REJECTED.getId().equals(clmMaster.getStatus()) && clmMaster.getClmDetails()
						.getCauseOfDeathDisabilityId().equals(CauseOfDeathDisability.DEATH.getId())) {
					return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_DEATH_MSG, HttpStatus.CREATED.value(),
							false);
				}
				ApplicationMasterV3 applicationMaster = applicationMasterRepo
						.findByIdAndIsActiveTrue(clmMaster.getApplicationId());
				long dateDiff = DateUtils.dateDiff(clmMaster.getClmDetails().getDateOfDeath(),
						applicationMaster.getEnrollmentDate());
				if (dateDiff > 30) {
					if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(clmMaster.getStatus())) {
						return new CommonResponse(CommonUtils.CLAIM_DEATH_PAID_MSG, HttpStatus.CREATED.value(), false);
					} else {
						return new CommonResponse(CommonUtils.CLAIM_DEATH_MSG, HttpStatus.CREATED.value(), false);
					}
				} else {
					if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(clmMaster.getStatus())) {
						return new CommonResponse(CommonUtils.CLAIM_ACCIDENTIAL_PAID_MSG, HttpStatus.CREATED.value(),
								false);
					} else {
						return new CommonResponse(CommonUtils.CLAIM_ACCIDENTIAL_MSG, HttpStatus.CREATED.value(), false);
					}
				}
			} else {
				// NATURE OF LOASS 1 : DEATH && 2 : DISABILITY
				if (ClaimStatus.CLAIM_REJECTED.getId().equals(clmMaster.getStatus())
						&& !OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getCauseOfDeathDisabilityId())
						&& clmMaster.getClmDetails().getCauseOfDeathDisabilityId()
								.equals(CauseOfDeathDisabilityV2.ACCIDENTAL.getId())
						&& clmMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
					return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG,
							HttpStatus.CREATED.value(), false);
				}
				if (!OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getNatureOfLossId())
						&& clmMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DEATH.getId())) {
					if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(clmMaster.getStatus())) {
						return new CommonResponse(CommonUtils.DEATH + " " + CommonUtils.CLAIM_ALREADY_PAID_MSG,
								HttpStatus.CREATED.value(), false);
					}
					if (ClaimStatus.CLAIM_REJECTED.getId().equals(clmMaster.getStatus())) {
						return new CommonResponse(CommonUtils.CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG,
								HttpStatus.CREATED.value(), false);
					}
					if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(clmMaster.getStatus())) {
						return new CommonResponse(CommonUtils.CLAIM_DEATH_MSG,
								HttpStatus.CREATED.value(), false);
					}
				} else {
					if (!OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getNatureOfLossId())
							&& clmMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
							&& !OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getTypeOfDisabilityId())
							&& clmMaster.getClmDetails().getTypeOfDisabilityId()
									.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
						if (ClaimStatus.CLAIM_ACCEPTED.getId().equals(clmMaster.getStatus())) {
							return new CommonResponse(
									CommonUtils.TOTAL_DISABILITY + " " + CommonUtils.CLAIM_ALREADY_PAID_MSG,
									HttpStatus.CREATED.value(), false);
						}
						if (ClaimStatus.CLAIM_SEND_TO_INSURER.getId().equals(clmMaster.getStatus())) {
							return new CommonResponse(CommonUtils.TOTAL_DISABILITY_MSG,
									HttpStatus.CREATED.value(), false);
						}
					} else {
						List<Integer> statusList = new ArrayList<>();
						statusList.add(ClaimStatus.CLAIM_ACCEPTED.getId());
						statusList.add(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
						Long count = clmMasterRepository.countByApplicationIdAndIsActiveTrueAndStatusIn(
								clmMaster.getApplicationId(), statusList);
						if (!OPLUtils.isObjectNullOrEmpty(count) && count > CommonUtils.LONG_2) {
							return new CommonResponse(CommonUtils.CLAIM_SUM_INSURED_EXHUSTED_MSG,
									HttpStatus.CREATED.value(), false);
						}
						// ------------------------------ NEED TO HANDLE THIS SCENARIO
						return new CommonResponse(SchemeMaster.PMSBY.getShortName(), HttpStatus.CREATED.value(), true);
					}
				}
				List<ClmMaster> clmMastersLst = clmMasterRepository
						.findByApplicationIdAndIsActiveTrue(clmMaster.getApplicationId());
				Boolean isProcced = false;
				if (!OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getNatureOfLossId())
						&& clmMaster.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
						&& clmMaster.getClmDetails().getTypeOfDisabilityId()
								.equals(TypeOfDisability.TOTAL_DISABILITY.getId())) {
					for (ClmMaster master : clmMastersLst) {
						if (ClaimStatus.CLAIM_REJECTED.getId().equals(master.getStatus())
								&& (!OPLUtils.isObjectNullOrEmpty(master.getClmDetails().getNatureOfLossId()) && master
										.getClmDetails().getNatureOfLossId().equals(NatureOfLoss.DISABILITY.getId())
								// &&
								// !OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getTypeOfDisablityId())
								// && (master.getClaimDetail().getTypeOfDisablityId() == CommonUtils.INT_2 ||
								// master.getClaimDetail().getTypeOfDisablityId() == CommonUtils.INT_1))
										&& !OPLUtils
												.isObjectNullOrEmpty(master.getClmDetails().getTypeOfDisabilityId()))) {
							isProcced = true;
						}
					}
				}
				if (isProcced.equals(Boolean.TRUE)) {
					return new CommonResponse(SchemeMaster.PMSBY.getShortName(), HttpStatus.CREATED.value(), true);
				}
			}
		}
		return new CommonResponse(CommonUtils.PROCEED, HttpStatus.CREATED.value(), true);
	}

	/**
	 * Need to check
	 * 
	 * @param applicationMaster
	 * @return
	 */
	protected CommonResponse claimDeDupe(ApplicationMasterBothSchemeProxy appMaster, Long userId,Integer schemeId,String accountNo) {
		try {
			String deDupeCheck = properties.getValue("CLAIM_DE_DUPE_ENABLE");
			List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
			List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());
			if ((OPLUtils.isObjectNullOrEmpty(deDupeCheck) || "OFF".equals(deDupeCheck))
					|| isSkipUserIdsLst.contains(userId)) {
				log.info("CLAIM DE-DUPE OFF------------------------>");
				return new CommonResponse("Proceed", HttpStatus.CREATED.value(), true);
			}
			List<ClmMaster> clmList = clmMasterRepository
					.findAllByClmDetailsClmPIDetailsApAccountNumberAndSchemeIdAndIsActiveTrue(accountNo, schemeId);
			for (ClmMaster claimMaster : clmList) {
				CommonResponse claimDeDupe = deDupeLogic(claimMaster);
				if (Boolean.FALSE.equals(claimDeDupe.getFlag())) {
					return claimDeDupe;
				}
			}
		} catch (Exception e) {
			log.error("Exception while check claim de-dupe --->", e);
			updateStageError(appMaster.getId(), null, null, "CLAIM DEDUPE CHECK : " + e.getMessage(),
					appMaster.getCreatedBy());
			return new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		}
		return new CommonResponse("Proceed", HttpStatus.CREATED.value(), true);
	}
	
	protected CommonResponse checkDateOfDeathOrAccidentValidOrNot(PolicyDetailsResponse policyDetails,
			UpdateClaimAccountHolderRequest holderRequest) {
		Date firstEnrollDate = Date
				.from(policyDetails.getFirstEnrollmentDate().atZone(ZoneId.systemDefault()).toInstant());
		if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateOfDeath()) && holderRequest.getDateOfDeath().before(firstEnrollDate)) {
			return new CommonResponse(
					"Date of death cannot be before the first enrollment date. Kindly provide valid date of death.",
					HttpStatus.BAD_REQUEST.value(), false);
		}  else if (!OPLUtils.isObjectNullOrEmpty(holderRequest.getDateAndTimeOfAccident())
				&& (holderRequest.getDateAndTimeOfAccident().before(firstEnrollDate))) {
			return new CommonResponse(
					"Date and time of accident date cannot be before the first enrollment date. Kindly provide valid date and time of accident.",
					HttpStatus.BAD_REQUEST.value(), false);

		}else if (OPLUtils.isObjectNullOrEmpty(policyDetails.getTransactionTimestamp()) || OPLUtils.isObjectNullOrEmpty(policyDetails.getTransactionUTR()) || OPLUtils.isObjectNullOrEmpty(policyDetails.getTransactionAmount())) {
			return new CommonResponse(
					"Bank Error - TransactionTimestamp, TransactionUTR and TransactionAmount  are mandatory fields.",
					HttpStatus.BAD_REQUEST.value(), false);

		}
		return null;
	}

	private void updateStageError(Long applicationId, Long claimId, Integer claimStageId, String msg, Long modifiedBy) {
		@SuppressWarnings("unused")
		ClaimStageMaster stage = null;
		if (claimStageId != null) {
			stage = ClaimStageMaster.getStageMasterByStageId(claimStageId);
		}
	}

	public String getValueById(DropDownMasterKey key, Integer id) throws OneFormException {
		return oneFormClient.getNameByKeyAndObjId(key, id).getValue();
	}
}
