package com.opl.jns.insurance.service.utils;
//package com.opl.service.insurance.jns.utils;
//
//import lombok.*;
//
//import java.util.*;
//
///**
// * @author - Maaz Shaikh
// * @Date - 8/16/2023
// */
//@Setter
//@Getter
//@NoArgsConstructor
//@AllArgsConstructor
//public class BranchUpdateRequest {
//    private Long orgId;
//    private Long branchId;
//    private List<Long> applicationList;
//
//}
