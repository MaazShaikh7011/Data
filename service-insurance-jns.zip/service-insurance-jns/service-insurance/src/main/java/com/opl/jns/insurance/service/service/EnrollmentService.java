package com.opl.jns.insurance.service.service;

import java.io.IOException;
import java.util.List;

import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.insurance.api.exception.InsuranceException;
import com.opl.jns.insurance.api.model.AccountHolderMappingRequest;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.CertificateInsDtlRequest;
import com.opl.jns.insurance.api.model.EnrollmentDetailsProxy;
import com.opl.jns.insurance.api.model.EnrollmentDtlProxy;
import com.opl.jns.insurance.api.model.InsurerMstDetailsRequest;
import com.opl.jns.insurance.api.model.PremiumDeductionFailedProxy;
import com.opl.jns.insurance.api.model.RegenerateCoiProxy;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.insurance.api.model.v2.AccHolderListReq;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.api.model.v2.GetCoiReq;
import com.opl.jns.insurance.api.model.v2.PremiumPopupRequest;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.model.COIRequest;

/***
 * 
 * @author paresh.radadiya Date : 28/04/2023
 */
public interface EnrollmentService {

	public CommonResponse updateEnrollmentVerificationType(Long applicationId, Integer typeOfVerification, AuthClientResponse authClientResponse) throws Exception;

	public CommonResponse verifyOtp(VerfiyOtpRequest req, AuthClientResponse authClientResponse) throws Exception;

	public CommonResponse verifyPhysicalSignature(Long applicationId, AuthClientResponse authClientResponse) throws Exception;

	public CommonResponse updateSelectedAccountHolder(AccountHolderMappingRequest selectedHolder, AuthClientResponse authClientResponse) throws Exception;

	public InsurerMstDetailsRequest getAccountHolderAndInsurerDetails(Long applicationId) throws InsuranceException;

	public ApplicationMasterRequestV2 getApplicationFormDetails(Long applicationId, AuthClientResponse authClientResponse);

	public CommonResponse saveApplicationFormDetails(ApplicationMasterRequest req, AuthClientResponse authClientResponse);

	public PremiumPopupRequest getPremiumPopupDetails(Long applicationId) throws Exception;

	public CommonResponse premiumDeduction(ApplicationMasterRequest req,  AuthClientResponse authClientResponse);

	public CommonResponse premiumDeductionTransactionFailedCases(PremiumDeductionFailedProxy req, AuthClientResponse authClientResponse);

	//    public byte[] downloadCertificateOfInsurance(CertificateInsDtlRequest request);

	//    public CertificateInsData getCertiOfInsData(Long applicationId);

	public void updateStageError(Long applicationId, Integer enrollStageId, String msg, Long modifiedBy);

	//    public void expireInProgressApplication();

	//	Boolean checkIfAnyApplicationFailedAtPremiumDeduction(Long applicationId, int count,
	//			AuthClientResponse authClientResponse);
	public ApplicationMasterRequestV2 getApplicationAllDetails(Long applicationId, ApplicationMasterV3 applicationMaster);

	//    public void regenerateCoi();

	public COIRequest getCOIData(Long applicationId);
	
	public COIRequest getCOIDataNewDb(CertificateInsDtlRequest request) throws IOException;

	public byte[] generateCOI(Long applicationId, boolean isFreshCreate) throws Exception;
	
	public byte[] generateCOINewDb(CertificateInsDtlRequest request, boolean isFreshCreate) throws Exception;

	public byte[] getCOI(ApplicationMasterV3 appMaster, boolean isFreshCreate);

	public void regenerateOldCoi(RegenerateCoiProxy regenerateCoiProxy) throws Exception;
	
	public void updateAppMasterErro(ApplicationMasterV3 appMaster, String msg, Long userId);

	public void pushStorageId(Long applicationId) throws Exception;

	public List<EnrollmentDetailsProxy> fetchEnrollmentDetails(EnrollmentDtlProxy enrollmentDtlProxy);

	public List<EnrollmentDetailsProxy> fetchAllUrnByUrnAndStageId(EnrollmentDtlProxy enrollmentDtlProxy);
	
	public ApplicationMasterRequestV2 getApplicationFormDetailsNewDb(Long applicationId,Long schemeId, AuthClientResponse authClientResponse);

	public CommonResponse fetchAccountHolderList(AccHolderListReq accHolderListRequest,AuthClientResponse authClientResponse);

	public CommonResponse fetchPolicyDetails(PolicyDetailsRequest policyDetailsRequest,
			AuthClientResponse authClientResponse);

	public CommonResponse optOutUpdateStatus(OptOutUpdateStatusRequest outUpdateStatusReq,
			AuthClientResponse authClientResponse);

	public CommonResponse nomineeUpdateStatus(NomineeUpdateStatusRequest nomineeUpdateStatusReq,
			AuthClientResponse authClientResponse);

	public CommonResponse getNomineeUpdatedetails(PolicyDetailsRequest policyDetailsRequest,
			AuthClientResponse authClientResponse);
	
	public CommonResponse getCoiDetails(GetCoiReq getCoiReq,
			AuthClientResponse authClientResponse);

	public byte[] getCOIBank(COIRequest coiReq,TransactionDetailsV2 transactionDetailsV2);

	public byte[] generateCOIFromMaster(Long applicationId,Integer integer) throws Exception;
	
	public CommonResponse saveApplicationFormDetailsNewDb(ApplicationMasterRequest req, AuthClientResponse authClientResponse);
	
	public byte[] getCOINewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantInfoV2, ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomneeAddress,Boolean isFreshCreate);
	
	public CommonResponse getPolicyDetails(String urn);
}
