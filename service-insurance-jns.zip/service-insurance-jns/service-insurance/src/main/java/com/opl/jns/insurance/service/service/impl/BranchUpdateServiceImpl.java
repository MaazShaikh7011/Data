package com.opl.jns.insurance.service.service.impl;

import java.util.Date;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.insurance.service.domain.BranchDetails;
import com.opl.jns.insurance.service.repository.BranchDetailsRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 8/16/2023
 */
@Service
@Slf4j
@Transactional
public class BranchUpdateServiceImpl {

	@Autowired
	ApplicationMasterRepositoryV3 appRepo;

	@Autowired
	BranchDetailsRepository branchDetailsRepository;

	@Async
	public void updateBranchIsInApplication(Long orgId) {
		if (orgId == null) {
			return;
		}
//		log.info("ORG ID ------------->" + orgId + "-------- start Time ----------------->", new Date());
//		List<BranchDetails> allBranchDetails = branchDetailsRepository.findAllByOrgIdAndIsUpdateFalse(orgId);
//		log.info("ORG ID ------------->" + orgId + "TOTAL FOUND ------->" + allBranchDetails.size());
//		int i = 1;
//		for (BranchDetails br : allBranchDetails) {
//
//			log.info("ORG ID ------------->" + orgId + "--------Total ------->" + i + " ------------>"
//					+ br.getBranchId());
//			appRepo.updateBranchIdOnApplication(br.getBranchId(), br.getOrgId(), br.getApplicationMin(),
//					br.getApplicationMax());
//			appRepo.updateBranchRoZoIdOnApplicationMasterOtherDetails(br.getRoId(), br.getZoId(), br.getOrgId(),
//					br.getApplicationMin(), br.getApplicationMax());
//			br.setIsUpdate(Boolean.TRUE);
//			branchDetailsRepository.save(br);
//			i += 1;
//		}

		log.info("ORG ID ------------->" + orgId + " ---------end Time ----------------->", new Date());
	}

	public void updateLimitData(Integer id) {
		String status = "IN PROGRESS";
		BranchDetails br = branchDetailsRepository.findByIdAndIsUpdateFalse(id.longValue());
		if(br == null) {
			status = "NOT FOUND";
			log.info("ID------------------>" + id + "------------------" + status);
			return;
		}
		appRepo.updateBranchIdOnApplication(br.getBranchId(), br.getOrgId(), br.getApplicationMin(),
				br.getApplicationMax());
		
		if (br.getRoId() != null && br.getZoId() != null) {
			status = "BOTH COMPLETED";
			appRepo.updateBranchRoZoIdOnApplicationMasterOtherDetails(br.getRoId(), br.getZoId(), br.getOrgId(),
					br.getApplicationMin(), br.getApplicationMax());
		} else if (br.getRoId() != null && br.getZoId() == null) {
			status = "ONLY RO COMPLETED";
			appRepo.updateBranchRoIdOnApplicationMasterOtherDetails(br.getRoId(), br.getOrgId(),
					br.getApplicationMin(), br.getApplicationMax());
		} else if (br.getRoId() == null && br.getZoId() != null) {
			status = "ONLY ZO COMPLETED";
			appRepo.updateBranchZoIdOnApplicationMasterOtherDetails(br.getZoId(), br.getOrgId(),
					br.getApplicationMin(), br.getApplicationMax());
		} else {
			status = "ONLY APP MASTER COMPLETED";
		}
		
		br.setIsUpdate(Boolean.TRUE);
		branchDetailsRepository.save(br);
		log.info("ID------------------>" + id + "------------------" + status);
	}

	@Transactional
	public void update(BranchDetails br) {
//        appRepo.updateBranchIdOnApplication(br.getBranchId(),br.getOrgId(),br.getApplicationMin(),br.getApplicationMax());
//        appRepo.updateBranchRoZoIdOnApplicationMasterOtherDetails(br.getRoId(),br.getZoId(),br.getOrgId(),br.getApplicationMin(),br.getApplicationMax());
//        br.setIsUpdate(Boolean.TRUE);
//        branchDetailsRepository.save(br);
	}

}
