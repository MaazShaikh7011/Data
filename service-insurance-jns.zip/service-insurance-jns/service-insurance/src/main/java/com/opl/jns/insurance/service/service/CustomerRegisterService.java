package com.opl.jns.insurance.service.service;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.utils.common.CommonResponse;

/**
 * @author Maulik Panchal
 */
@Service
public interface CustomerRegisterService {

	public CommonResponse accountHolderSelectionDetails(AccountHolderSelectionDetailsRequest accountHolderSelRequest)
			throws IOException;

	public CommonResponse create(ApplicationMasterRequest req, AuthClientResponse authClientResponse) throws Exception;

	public CommonResponse updateEnrollmentVerificationType(Long applicationId, AuthClientResponse authClientResponse)
			throws Exception;

	public CommonResponse verifyOtp(VerfiyOtpRequest req, AuthClientResponse authClientResponse) throws Exception;

}
