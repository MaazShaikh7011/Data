package com.opl.jns.insurance.service.domain;


import lombok.*;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import java.util.*;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "error_stage_audit")
public class ErrorStageAudit {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "error_stage_audit_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "error_stage_audit_seq_gen", sequenceName = "error_stage_audit_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "application_id")
    private Long applicationId;

    @Column(name = "claim_id")
    private Long claimId;

    @Column(name = "stage_id")
    private Integer stageId;

    @Column(name = "stage_name")
    private String stageName;

    @Column(name = "message")
    private String message;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    @Column(name = "modified_by", nullable = true)
    private Long modifiedBy;

}
