package com.opl.jns.insurance.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.opl.jns.insurance.service.domain.BranchDetails;

public interface BranchDetailsRepository extends JpaRepository<BranchDetails, Long> {

	public List<BranchDetails> findAllByIsUpdateFalse();
	
	public BranchDetails findByIdAndIsUpdateFalse(Long id);

	public List<BranchDetails> findAllByOrgId(Long orgId);

	public List<BranchDetails> findAllByOrgIdAndIsUpdateFalse(Long orgId);
	
	@Query(value ="select branch_id from usr_insurance.branch_details where org_id =:orgId group by branch_id", nativeQuery=true)
	public List<Long> getIds(Long orgId);

	@Query(value ="select * from usr_insurance.branch_details where is_update = 0 order by id desc OFFSET :start ROWS FETCH NEXT :total ROWS ONLY", nativeQuery=true)
	public List<BranchDetails> getLimitData(Integer start, Integer total);
}
