package com.opl.jns.insurance.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.insurance.service.service.CustomerRegisterService;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Maulik Panchal
 */
@RestController
@RequestMapping("/custReg")
@Slf4j
public class CustomerRegisterController {

	@Autowired
	private CustomerRegisterService customerRegisterService;

	/**
	 * First Screen Where user add Account Number, Bank, scheme and dob
	 * 
	 * Bank Account Details
	 * 
	 * 1. First call with Account Number, Bank, scheme and dob
	 */

	/**
	 * CREATE APPLICATION WHILE DIY ENROLLMENT JOURNEY
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> create(@RequestBody ApplicationMasterRequest req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in create application account number ------------> {} " + req.getAccountNo());
			return new ResponseEntity<>(customerRegisterService.create(req, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in creating the application : ", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Resend OTP
	 *
	 * @param applicationId
	 * @param authClientResponse
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/resendOTP/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> resendOTP(@PathVariable Long applicationId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in resendOTP application applicationId ------------> {} " + applicationId);
			if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
				log.info("Application ID is null or empty in resend OTP API ");
				return new ResponseEntity<>(new CommonResponse(CommonErrorMsg.Common.MANDATORY_DETAILS_MISSING,
						HttpStatus.BAD_REQUEST.value(), false), HttpStatus.OK);
			}
			log.info("Enter in Resend OTP -------------->" + applicationId);
			return new ResponseEntity<>(
					customerRegisterService.updateEnrollmentVerificationType(applicationId, authClientResponse),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while resend OTP ------------->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Second screen after Verification Code if user selected 'Verification Code'
	 * then otp verfy here
	 * 
	 * 2.1 Verify OTP Verify OTP
	 * 
	 * @param verifyOtpReq
	 * @param authClientResponse
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/verifyOtp", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> verifyOtp(@RequestBody VerfiyOtpRequest verifyOtpReq,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in Verify OTP ------------> " + verifyOtpReq.getApplicationId());
			verifyOtpReq.setUserId(authClientResponse.getUserId());
			return new ResponseEntity<>(customerRegisterService.verifyOtp(verifyOtpReq, authClientResponse),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while verify OTP ------------->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * Third screen after registration completed
	 * 
	 * get account holder selection details in bucket
	 * 
	 * @param AccountHolderSelectionDetailsRequest
	 * @return
	 */
	@PostMapping(value = "/accountHolderSelectionDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> accountHolderSelectionDetails(
			@RequestBody AccountHolderSelectionDetailsRequest accountHolderSelRequest) {
		try {
			log.info("Enter in accountHolderSelectionDetails ------------> "+ accountHolderSelRequest.getUrn());
			return new ResponseEntity<>(customerRegisterService.accountHolderSelectionDetails(accountHolderSelRequest),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while accountHolderSelectionDetails ------------->", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

}
