package com.opl.jns.insurance.service.utils.dedupe;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.ddregistry.api.model.claimDedupe.ClaimDedupApiProxy;
import com.opl.jns.ddregistry.api.model.dedupe.ClaimDedupApiResponse;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.TransactionDetailsProxy;
import com.opl.jns.ddregistry.api.model.updateClaimStatus.UpdateClaimStatusProxy;
import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ClmDeDupeDetails;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author sandip.bhetariya
 *
 */
@Slf4j
@Service
public class DeDupeRegistryUtilityV3 {

	@Autowired
	private DedupeRegistryClient dedupeRegistryClient;

	@Lazy
	@Autowired
	private EnrollmentService enrollmentService;

	
//	public CommonResponse callPushClaimRequest(ClmMaster claimMaster,ApplicationMasterV3 applicationMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callPushClaimRequest(getcallClaimPushRequestData(claimMaster,applicationMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);	
//			}
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		} catch (Exception e) {
//			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		}
//}
//	
//	private PushClaimProxy getcallClaimPushRequestData(ClmMaster claimMaster,ApplicationMasterV3 applicationMaster) {
//		PushClaimProxy pushClaimProxy = new PushClaimProxy();
//		ClmDetails clmDetails = claimMaster.getClmDetails();
//		ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();
//		pushClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
//		pushClaimProxy.setUrn(claimMaster.getUrn());
//		pushClaimProxy.setScheme(SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
//		pushClaimProxy.setGender(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApGenderId()) ?  Gender.fromId(clmPIDetails.getApGenderId()).getBankValue() : null);
//		pushClaimProxy.setApplicantAccNo(clmPIDetails.getApAccountNumber());
//		pushClaimProxy.setOrgId(claimMaster.getOrgId());
//		pushClaimProxy.setApplicantDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(clmPIDetails.getApDob()));
//		pushClaimProxy.setInsurerOrgId(claimMaster.getInsurerOrgId());
//		pushClaimProxy.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//		pushClaimProxy.setApplicantfirstName(clmPIDetails.getApFirstName());
//		pushClaimProxy.setApplicantmiddleName(clmPIDetails.getApMiddleName());
//		pushClaimProxy.setApplicantlastName(clmPIDetails.getApLastName());
//		pushClaimProxy.setDateofDeath(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateOfDeath()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClmDetails().getDateOfDeath()) : null);
//		pushClaimProxy.setDateofAccident(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getDateTimeOfAccident()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClmDetails().getDateTimeOfAccident()) : null);
//		pushClaimProxy.setClaimStatusId(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//		pushClaimProxy.setEnrollmentDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(applicationMaster.getCompletionDate()));
//		if(claimMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
//			String typeOfDisability = null;
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getTypeOfDisabilityId())) {
//				typeOfDisability = TypeOfDisability.fromId(claimMaster.getClmDetails().getTypeOfDisabilityId()).getValue();
//			}
//			String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId()) && Objects.equals(claimMaster.getClmDetails().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId()) ? typeOfDisability : "-";
//			pushClaimProxy.setClaimType(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getNatureOfLossId()) && Objects.equals(claimMaster.getClmDetails().getNatureOfLossId(), NatureOfLoss.DEATH.getId()) ? "Accidental Death" : typeOfLoss );
//		}else if(claimMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue() && (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getCauseOfDeathDisabilityId()))) {		
//				String typeOfLoss=Objects.equals(claimMaster.getClmDetails().getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId()) ? CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getValue() : "-";
//				pushClaimProxy.setClaimType(Objects.equals(claimMaster.getClmDetails().getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getId()) ? CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue() :typeOfLoss );
//			
//		}
//		pushClaimProxy.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDate()) : null);
//		return pushClaimProxy;
//	}
	
	
	public CommonResponse callUpdateClaimStatusRequest(ClmMaster claimMaster) {
		try {
			CommonResponse commonResponse = dedupeRegistryClient.callUpdateClaimStatusRequest(getcallUpdateClaimRequestData(claimMaster));

			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);	
			}
			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
		} catch (Exception e) {
			log.error(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG + "------>", e);
			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
		}
}
	
	private UpdateClaimStatusProxy getcallUpdateClaimRequestData(ClmMaster claimMaster) {
		UpdateClaimStatusProxy updateClaimProxy = new UpdateClaimStatusProxy();
	
		updateClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
		updateClaimProxy.setUrn(claimMaster.getUrn());
		updateClaimProxy.setClaimStatus(claimMaster.getStatus());
		updateClaimProxy.setReason(claimMaster.getStatusReasonId());
	
		TransactionDetailsProxy transactionDetailsProxy = new TransactionDetailsProxy();
		transactionDetailsProxy.setTransactionAmount(!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionAmount())
				? claimMaster.getTransactionAmount().longValue()
				: null);
		transactionDetailsProxy.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionTimeStamp())
				? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(claimMaster.getTransactionTimeStamp())
				: null);
		transactionDetailsProxy.setTransactionUTR(claimMaster.getTransactionUTR());
	
		updateClaimProxy.setTransactionDetails(transactionDetailsProxy);
		return updateClaimProxy;
	}
	
	
	public ClaimDedupApiResponse callClaimDedupeRequest(ClmMaster claimMaster,ClmDeDupeDetails deDupeDetails,ApplicationMasterV3 applicationMaster) {
		try {
			CommonResponse commonResponse = dedupeRegistryClient.callClaimDedupeRequest(getcallClaimDedupeRequestData(claimMaster,deDupeDetails,applicationMaster));
			
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())) {
				ClaimDedupApiResponse claimDedupApiResponse = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), ClaimDedupApiResponse.class);
				if(!OPLUtils .isObjectNullOrEmpty(claimDedupApiResponse) && claimDedupApiResponse.getIsDup().equals(Boolean.TRUE)) {
					log.info("De Dupe details found for account number [{}] and response is : [{}]",claimMaster.getClmDetails().getClmPIDetails().getApAccountNumber(),MultipleJSONObjectHelper.getStringfromObject(claimDedupApiResponse));
				}
				return claimDedupApiResponse;
			} else {
				log.error(!OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
				return new ClaimDedupApiResponse(false, !OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
			}
		} catch (Exception e) {
			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
			return new ClaimDedupApiResponse(false, CommonUtils.CLAIM_DUPE_EXCEPTION_MSG);
		}
}

	private ClaimDedupApiProxy getcallClaimDedupeRequestData(ClmMaster claimMaster,ClmDeDupeDetails deDupeDetails,ApplicationMasterV3 applicationMaster) {
			ClaimDedupApiProxy dedupRequest = new ClaimDedupApiProxy();
			ClmDetails clmDetails = claimMaster.getClmDetails();
			ClmPIDetails clmPIDetails = claimMaster.getClmDetails().getClmPIDetails();
			dedupRequest.setKycId1(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApKycId1()) ?  clmPIDetails.getApKycId1().toUpperCase() : clmPIDetails.getApKycId1());
			dedupRequest.setKycIdValue1(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApKycIdNumber1()) ? clmPIDetails.getApKycIdNumber1().toUpperCase() : clmPIDetails.getApKycIdNumber1());
//			dedupRequest.setKycId2(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApKycId2()) ? applicationMaster.getApplicantInfo().getKycId2().toUpperCase() : applicationMaster.getApplicantInfo().getKycId2());
//			dedupRequest.setKycIdValue2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycIdNumber2()) ? applicationMaster.getApplicantInfo().getKycIdNumber2().toUpperCase() : applicationMaster.getApplicantInfo().getKycIdNumber2());
			dedupRequest.setCkycNumber(clmPIDetails.getApCkycNumber());
			dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(clmDetails.getApGenderId()) ? Gender.fromId(clmDetails.getApGenderId()).getBankValue()  : null);
			dedupRequest.setFirstName(clmPIDetails.getAcHolderName());
			dedupRequest.setMiddleName(clmPIDetails.getApMiddleName());
			dedupRequest.setLastName(clmPIDetails.getApLastName());
			dedupRequest.setFatherHusbandName(clmPIDetails.getApFatherHusbandName());
			dedupRequest.setMob(clmDetails.getApMobileNumber());
			dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(clmDetails.getApAddressMaster()) ? clmDetails.getApAddressMaster().getPincode() : null);
			dedupRequest.setDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(clmPIDetails.getApDob()));
			dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
			dedupRequest.setAccNo(clmPIDetails.getApAccountNumber());
			dedupRequest.setScheme(SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
			dedupRequest.setAccountStatus("A");
			dedupRequest.setType("N");
			dedupRequest.setOrgId(claimMaster.getOrgId());
			dedupRequest.setInsurerOrgId(claimMaster.getInsurerOrgId());
			dedupRequest.setCif(clmPIDetails.getApCif());
			dedupRequest.setUrn(claimMaster.getUrn());
			dedupRequest.setEnrollmentDate(CommonUtils.formatDate_sdf(applicationMaster.getEnrollmentDate()));
			dedupRequest.setDateOfDeath(CommonUtils.formatDate_sdf(claimMaster.getClmDetails().getDateOfDeath()));
			dedupRequest.setDateOfAccident(CommonUtils.formatDate_sdf(claimMaster.getClmDetails().getDateTimeOfAccident()));
			dedupRequest.setIsNameMatch("true");
			dedupRequest.setClaimTypeId(getClaimTypeId(claimMaster));
			dedupRequest.setClaimReferenceId(claimMaster.getId().toString());
			dedupRequest.setFirNo(deDupeDetails.getFIRNo());
			dedupRequest.setFirDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getFIRDate()));
			dedupRequest.setPanchnamaNo(deDupeDetails.getPanchnamaNo());
			dedupRequest.setPanchnamaDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getPanchnamaDate()));
			dedupRequest.setPostMortemReportNo(deDupeDetails.getPostMortemReportNo());
			dedupRequest.setPostMortemReportDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getPostMortemReportDate()));
			dedupRequest.setDeathOrdisabilityCertificateReportNo(deDupeDetails.getDeathDisabilityCertificateReportNo());
			dedupRequest.setDeathOrdisabilityCertificateReportDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getDeathDisabilityCertificateReportDate()));
			return dedupRequest;
	}
	
	private Integer getClaimTypeId(ClmMaster claimMaster) {
		if (claimMaster.getSchemeId() == SchemeMaster.PMSBY.getId().longValue()) {
			if (Objects.equals(claimMaster.getClmDetails().getNatureOfLossId(), NatureOfLoss.DEATH.getId())) {
				return 4;
			} else if (Objects.equals(claimMaster.getClmDetails().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
					&& Objects.equals(claimMaster.getClmDetails().getTypeOfDisabilityId(), TypeOfDisability.PARTIAL_DISABILITY
							.getId())) {
				return 2;
			} else if (Objects.equals(claimMaster.getClmDetails().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
					&& Objects.equals(claimMaster.getClmDetails().getTypeOfDisabilityId(), TypeOfDisability.TOTAL_DISABILITY
							.getId())) {
				return 3;
			}

		} else if (claimMaster.getSchemeId() == SchemeMaster.PMJJBY.getId().longValue()) {
			if (Objects.equals(claimMaster.getClmDetails().getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getId())) {
				return 1;
			} else if (Objects.equals(claimMaster.getClmDetails()
					.getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId())) {
				return 5;
			}
		}
		return null;
	}
	
	
}
