package com.opl.jns.insurance.service.controller;
//package com.opl.service.insurance.jns.controller;
//
//import com.opl.jns.config.utils.*;
//import com.opl.jns.utils.common.*;
//import com.opl.service.insurance.jns.service.*;
//import com.opl.service.insurance.jns.utils.*;
//import lombok.extern.slf4j.*;
//import org.springframework.beans.factory.annotation.*;
//import org.springframework.http.*;
//import org.springframework.web.bind.annotation.*;
//
//import javax.servlet.http.*;
//
//@RestController
//@RequestMapping("/v3/data")
//@Slf4j
//public class DataInsertionController {
//
//	@Autowired
//	private DataInsertionService service;
//
//	@Autowired
//	BankWiseInsert ins;
//
//	@RequestMapping(value = "/insert", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> migrateNominee(@RequestBody DataInsertRequest req, HttpServletRequest httpServletRequest) {
//		try {
////			log.info("Enter into migrateClaimData");
//			service.dataInsertion(req.getSchemeId(),req.getCounter(),req.getOrgId(),req.getInsurerOrgId());
//			return new ResponseEntity<CommonResponse>( HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while get Account Holder ==>", e);
//			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//		}
//	}
//	@SkipInterceptor
//	@RequestMapping(value = "/insertEnrollment", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> insertEnrollment(@RequestBody DataInsertRequest req, HttpServletRequest httpServletRequest) {
//		try {
////			log.info("Enter into migrateClaimData");
////			ins.start(req.getCount());
//			DataInsertBankEnum[] bankList = DataInsertBankEnum.getAll();
//			for (int i = 0; i < bankList.length; i++) {
//				DataInsertBankEnum bank = bankList[i];
//				ins.insert(bank.getSchemeId(), bank.getOrgId(), bank.getInsurerId(), req.getCount());
//			}
//			return new ResponseEntity<CommonResponse>( HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while get Account Holder ==>", e);
//			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//		}
//	}
//
//	@RequestMapping(value = "/claimDummyInsert", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> claimDummyInsert(@RequestBody DataInsertRequest req, HttpServletRequest httpServletRequest) {
//		try {
//			service.claimDummyInsert(req.getSchemeId(),req.getOrgId());
//			return new ResponseEntity<CommonResponse>(HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while get Account Holder ==>", e);
//			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//		}
//	}
//}
