package com.opl.jns.insurance.service.service;

import com.opl.jns.ere.domain.ApplicationMasterV3;

public interface DeDupeRegistryService {

	/*public void rePushSingleEnrollmentApplication(Long id, ApplicationMasterV3 appMaster);

	public void rePushUpdateEnrollmentStatusApplication(Long id);*/


}
