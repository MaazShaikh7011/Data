package com.opl.jns.insurance.service.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.insurance.api.model.v2.SearchRequest;
import com.opl.jns.insurance.service.service.CommonService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/v3/common")
@Slf4j
public class CommonController {

    @Autowired
    CommonService commonService;

    @PostMapping(value = "/getBySearch", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<CommonResponse> getBySearchFilter(@RequestBody String request,
                                                                          @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws IOException {
        try {
            SearchRequest searchRequest = MultipleJSONObjectHelper.getObjectFromString(request, SearchRequest.class);

            if (OPLUtils.isObjectNullOrEmpty(searchRequest) || OPLUtils.isObjectNullOrEmpty(searchRequest.getSearchType()) || OPLUtils.isObjectNullOrEmpty(searchRequest.getSearchValue())) {
                log.info("Search Request can not be null or Empty ");
                return new ResponseEntity<CommonResponse>(
                        new CommonResponse("Search Request can not be null or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }

            log.info("Enter getBySearchFilter() ---------------->" + searchRequest.getSearchValue());
            CommonResponse commonResponse = null;
            if(!OPLUtils.isObjectNullOrEmpty(searchRequest)) {            	
            	if (!OPLUtils.isObjectNullOrEmpty(searchRequest.getIsEnrollment())
            			&& Boolean.TRUE.equals(searchRequest.getIsEnrollment())) {
            		commonResponse = commonService.getBySearchFilterNew(request, authClientResponse.getUserId());
            	} else if(!OPLUtils.isObjectNullOrEmpty(searchRequest.getIsClaim())
            			&& Boolean.TRUE.equals(searchRequest.getIsClaim())){
            		commonResponse = commonService.getBySearchFilterNewForClaim(request, authClientResponse.getUserId());
            	}else {
            		commonResponse = commonService.getbySearchFilter(searchRequest, authClientResponse);
            	}
            }
            return new ResponseEntity<>(commonResponse, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while getBySearchFilter ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
}
