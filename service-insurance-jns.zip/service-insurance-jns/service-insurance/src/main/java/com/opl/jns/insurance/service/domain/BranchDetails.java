package com.opl.jns.insurance.service.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "branch_details")
public class BranchDetails {

	@Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "branch_details_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "branch_details_seq_gen", sequenceName = "branch_details_seq_gen", allocationSize = 1)
    private Long id;

	@Column(name = "branch_id")
	private Long branchId;

	@Column(name = "ro_id")
	private Long roId;

	@Column(name = "zo_id")
	private Long zoId;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "application_min")
	private Long applicationMin;

	@Column(name = "application_max")
	private Long applicationMax;

	@Column(name = "is_update")
	private Boolean isUpdate;
	
	@Column(name = "branch_code")
	private String branchCode;
	
	@Column(name = "state_id")
	private Long stateId;
	
	@Column(name = "city_id")
	private Long cityId;

}
