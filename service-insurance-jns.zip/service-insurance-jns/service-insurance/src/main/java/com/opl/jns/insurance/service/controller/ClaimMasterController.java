package com.opl.jns.insurance.service.controller;


import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.insurance.api.model.ClaimDeDupeDetailsProxy;
import com.opl.jns.insurance.api.model.ClaimMasterRequest;
import com.opl.jns.insurance.api.model.ClaimRequest;
import com.opl.jns.insurance.api.model.ClaimStatusRequest;
import com.opl.jns.insurance.api.model.UpdateClaimAccountHolderRequest;
import com.opl.jns.insurance.service.service.ClaimMasterServiceV3;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ClaimStageMaster;

import lombok.extern.slf4j.Slf4j;


/***
 * 
 * @author paresh.radadiya
 * @author maaz.shaikh
 * @date 02-05-2023
 * 
 */
@RestController
@RequestMapping("/v3/claim")
@Slf4j
public class ClaimMasterController {
  
	//@Autowired
	//private ClaimMasterService claimService;
  
	@Autowired
	private ClaimMasterServiceV3 claimServiceV3;
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;

	/**
	 * FETCH ACCOUNT HOLDER DETAILS BY ACCOUNT NUMBER
	 * 
	 * @param claimRequest
	 * @param httpServletRequest
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/getAccountHoldersList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getAccountHoldersList(@RequestBody ClaimRequest claimRequest,
			HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimRequest)
					|| OPLUtils.isObjectNullOrEmpty(claimRequest.getAccountValue())) {
				log.info("Account Number is null or empty while fetching accoung holder details in claim journey!!");
				return new ResponseEntity<>(
						new CommonResponse("Account Number or URN code missing!!!!", HttpStatus.BAD_REQUEST.value(), false),
						HttpStatus.OK);
			}
			log.info("Enter in get account holder details by account number in claim process---> "
					+ claimRequest.getAccountValue());
			return new ResponseEntity<>(
					claimServiceV3.getAccountHoldersList(claimRequest, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get Account Holder ==>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * FETCH CALIM FORM DETAILS
	 * @return CommonResponse
	 */
	@GetMapping(value = "/getClaimFromDetails/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getClaimFromDetails(@PathVariable Long claimId) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimId)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			log.info("Enter in fetch claim form details -------------->" + claimId);
			return new ResponseEntity<>(new CommonResponse("Successfully get Claim Details!!", claimServiceV3.getClaimFromDetails(claimId),
					HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while fetch claim details ==>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * SAVE CLAIM FORM DETAILS
	 * 
	 * @param req
	 * @return CommonResponse
	 */
	@PostMapping(value = "/saveClaimFormDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveClaimFormDetails(@RequestBody ClaimMasterRequest req,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			req.setModifiedBy(authClientResponse.getUserId());
			CommonResponse commonResponse = claimServiceV3.saveClaimFormDetails(req);
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);

		}
	}
	@PostMapping(value = "/fetchViewClaimDetailsByApplicationId", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchViewClaimDetailsByApplicationId(@RequestBody String request,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter In fetchViewClaimDetailsByApplicationId()");
			String fetchedClaimDetails = claimServiceV3.fetchViewClaimDetailsByClaimId(request,authClientResponse.getUserId());
			if (OPLUtils.isObjectNullOrEmpty(fetchedClaimDetails)) {
				return new ResponseEntity<>(
						new CommonResponse("Its seems system has not found details by requested details",
								HttpStatus.OK.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, fetchedClaimDetails,
					HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in fetchViewClaimDetailsByApplicationId :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

    /**
     * FETCH CURRENT APPLICATION MASTER DETAILS
     *
     * @param claimId
     * @return
     */
    @GetMapping(value = "/getStage/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getStageDetails(@PathVariable Long claimId) {
        try {
            log.info("Enter in get stage for the claimId -->" + claimId);
            ClaimMasterRequest stage = claimServiceV3.getStage(claimId);
            if(OPLUtils.isObjectNullOrEmpty(stage)) {
                return new ResponseEntity<>(new CommonResponse("Its seems we have not found claim details by given claim number", HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
            }
            return new ResponseEntity<>(new CommonResponse("Successfully fetched", stage, HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get stage details ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    /**
     * UPDATE CLAIM STAGE
     * @param claimMasterRequest
     * @param authClientResponse
     * @return
     */
    @PostMapping(value = "/updateStage", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateStage(@RequestBody ClaimMasterRequest claimMasterRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            log.info("Enter in update claim stage for the application -->" + claimMasterRequest.getId());
            CommonResponse response = claimServiceV3.updateStage(claimMasterRequest.getId(),authClientResponse.getUserId(), null);
            if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
                    && response.getStatus() == HttpStatus.OK.value()
                    && !OPLUtils.isObjectNullOrEmpty(response.getData())
                    && (Integer.parseInt(response.getData().toString()) == ClaimStageMaster.CLAIM_COMPLETED.getStageId())) {
                log.info("DATA ARE MOVING INTO API FOR READY TO PUBLISH ------------------>");
                claimServiceV3.publishedClaimedData(claimMasterRequest.getId());
            }
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while claim update stage ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
    /**
     * UPDATE CLAIM SELECTED ACCOUNT HOLDER DETAILS
     *
     * @param authClientResponse
     * @return CommonResponse
     */
    @PostMapping(value = "/updateClaimAccountHolder", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateClaimAccountHolder(@RequestBody UpdateClaimAccountHolderRequest holderRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(holderRequest)) {
                return new ResponseEntity<>(new CommonResponse("Account Number or URN code missing!!!!", HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
            }
            return new ResponseEntity<>(claimServiceV3.updateClaimAccountHolder(holderRequest, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get Account Holder ==>", e);
            return new ResponseEntity<>(
                    new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }
    @GetMapping(value = "/findAllClaimHistoryByApplicationId/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> findAllClaimHistoryByApplicationId(@PathVariable Long applicationId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(claimServiceV3.findAllClaimHistoryByApplicationId(applicationId) , HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}

	/**
	 * Find All Approved claim detail by customer account number
	 *
	 * @param claimId
	 * @param authClientResponse 
	 * @return CommonResponse
	 */
	@GetMapping(value = "/findAllApprovedClaimDetailsByClaimId/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> findAllApprovedClaimDetailsByClaimId(@PathVariable Long claimId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		ResponseEntity<CommonResponse> result;
		try {
		   if (OPLUtils.isObjectNullOrEmpty(claimId)) {
			   result = new ResponseEntity<>(new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),HttpStatus.OK);
		   } else {
			   result = new ResponseEntity<>(claimServiceV3.findAllApprovedClaimDetailsByApplicationId(claimId), HttpStatus.OK);
		   }
		} catch (Exception e) {
			result = new ResponseEntity<>(new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
		return result;
	}

	/**
	 * Find Claim View Details By Application Id
	 *
	 * @param applicationId
	 * @param authClientResponse 
	 * @return CommonResponse
	 */
    @GetMapping(value = "/fetchViewClaimDetailsByApplicationId/{applicationId}/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchViewClaimDetailsByApplicationId(@PathVariable Long applicationId,@PathVariable Long claimId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(claimServiceV3.fetchViewClaimDetailsByApplicationId(applicationId,claimId) , HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
    
	/**
	 * UPDATE APPLICATION STATUS (FOR CLAIM JOURNEY)
	 * @param applicationId
	 * @param applicationStatus
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/updateClaimStatus", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> updateClaimStatus(@RequestBody ClaimStatusRequest claimStatusRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if(OPLUtils.isObjectNullOrEmpty(claimStatusRequest) && OPLUtils.isObjectNullOrEmpty(claimStatusRequest.getClaimId())) {			
				return new ResponseEntity<>(
						new CommonResponse("Its seems we have not found claim details by given claim number", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			log.info("Enter in update claimId status -->" + claimStatusRequest.getClaimId());
			return new ResponseEntity<>(
					claimServiceV3.updateClaimStatus(claimStatusRequest, authClientResponse.getUserId()),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update claim status ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 *
	 * @param claimDeDupeDetails
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/saveClaimDeDupeDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveClaimDeDupeDetails(@RequestBody ClaimDeDupeDetailsProxy claimDeDupeDetails,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		authClientResponse.setUserId(1L);
		try {
			if(OPLUtils.isObjectNullOrEmpty(claimDeDupeDetails) && OPLUtils.isObjectNullOrEmpty(claimDeDupeDetails.getClaimId())) {
				return new ResponseEntity<>(
						new CommonResponse("Its seems we have not found claim details by given claim number", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			log.info("Enter in update claimId status -->" + claimDeDupeDetails.getClaimId());
			return new ResponseEntity<>(
					claimServiceV3.saveClaimDeDupeDetails(claimDeDupeDetails, authClientResponse.getUserId()),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update claim status ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 *
	 * @param claimId
	 * @return
	 */
	@GetMapping(value = "/getClaimDeDupeDetails/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getClaimDeDupeDetails(@PathVariable Long claimId) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimId)) {
				return new ResponseEntity<>(
						new CommonResponse("Its seems we have not found claim details by given claim number",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			log.info("Enter in update claimId status -->" + claimId);
			return new ResponseEntity<>(claimServiceV3.getClaimDeDupeDetails(claimId), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update claim status ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	
//	ClaimDeDupeDetails
	
	/**
	 * Find Claim View Details By Application Id
	 *
	 * @param applicationId
	 * @param authClientResponse 
	 * @return CommonResponse
	 */
    @GetMapping(value = "/getAllClaimDetail/{applicationId}/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getAllClaimDetail(@PathVariable Long applicationId,@PathVariable Long claimId,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(claimServiceV3.getAllClaimDetail(applicationId,claimId) , HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
    

	   @GetMapping(value = "/pushClaimData/{claimId}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<CommonResponse> pushClaimData(@PathVariable Long claimId) {
		   
		   try {
	            log.info("Enter in update claim stage for the application -->" + claimId);
	            CommonResponse response = claimServiceV3.updateStage(claimId,null, null);
	            if (!OPLUtils.isObjectNullOrEmpty(response) && !OPLUtils.isObjectNullOrEmpty(response.getStatus())
	                    && response.getStatus() == HttpStatus.OK.value()
	                    && !OPLUtils.isObjectNullOrEmpty(response.getData())
	                    && (Integer.parseInt(response.getData().toString()) == ClaimStageMaster.CLAIM_COMPLETED.getStageId())) {
	                log.info("DATA ARE MOVING INTO API FOR READY TO PUBLISH ------------------>");
	                claimServiceV3.publishedClaimedData(claimId);
	            }
	            return new ResponseEntity<>(response, HttpStatus.OK);
	        } catch (Exception e) {
	            log.error("Exception while claim update stage ------>", e);
	            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
	        }
	    }
	   
	   @PostMapping(value = "/webHookClaimDocUpload", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<CommonResponse> webHookClaimDocUpload(@RequestBody Map<String,Object> request ,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
	        try {

	        	log.info("Enter in update webHookClaimDocUpload -->" + request);
	        	if(OPLUtils.isObjectNullOrEmpty(request)) {
	        		return new ResponseEntity<>(
							new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
							HttpStatus.OK);
	        	}
	        	Object claimId =  request.get("claimId");
	        	@SuppressWarnings("unchecked")
				List<Long> docs= (List<Long>) request.get("docs");
	        	
	        	if(OPLUtils.isObjectNullOrEmpty(claimId)) {
	        		return new ResponseEntity<>(
							new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
							HttpStatus.OK);
	        	}
	        	if(OPLUtils.isListNullOrEmpty(docs)) {
	        		return new ResponseEntity<>(
							new CommonResponse("Please update and upload any one document.", HttpStatus.BAD_REQUEST.value()),
							HttpStatus.OK);
	        	}
	        	
	        	/**UPDATE STORAGE ID IN TABLE*/
	    		ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(Long.valueOf(claimId.toString()));
				/** update the re-uploaded docs in table */
				claimMaster
						.setQueriedStorageId(!docs.isEmpty() ? docs.toString().replace('[', ' ').replace(']', ' ') : null);
				clmMasterRepository.save(claimMaster);
				
	        	CommonResponse response = claimServiceV3.webHookClaimDocUpload(Long.valueOf(claimId.toString()),docs);
	            if(OPLUtils.isObjectNullOrEmpty(response)) {
	            	return new ResponseEntity<>(
							new CommonResponse("Something went wrong.", HttpStatus.BAD_REQUEST.value()),
							HttpStatus.OK);
	            }
	            return new ResponseEntity<>(response, HttpStatus.OK);
	        } catch (Exception e) {
	            log.error("Exception while webHookClaimDocUpload ------>", e);
	            return new ResponseEntity<>(
						new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
	        }
	    }
	   
//	   @GetMapping(value = "/claimDataMigrationNewDb", produces = MediaType.APPLICATION_JSON_VALUE)
//	    public ResponseEntity<CommonResponse> claimDataMigrationNewDb() {
//		   
//		   try {
//	            log.info("Enter in claimDataMigrationNewDb -->" );
//	            CommonResponse response = claimServiceV3.claimDataMigrationNewDb();
//	            return new ResponseEntity<>(response, HttpStatus.OK);
//	        } catch (Exception e) {
//	            log.error("Exception while claimDataMigrationNewDb ------>", e);
//	            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//	        }
//	    }

	@PostMapping(value = "/UpdateStageWithRemarks", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> UpdateStageWithRemarks(@RequestBody Map<String,Object> request,
																 @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(request)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}

			Object claimId = request.get("claimId");
			Object remarks = request.get("remarks");

			if (OPLUtils.isObjectNullOrEmpty(claimId) || OPLUtils.isObjectNullOrEmpty(remarks)) {
				return new ResponseEntity<>(
						new CommonResponse(CommonErrorMsg.Common.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}

			CommonResponse response = claimServiceV3.UpdateStageWithRemarks(Long.valueOf(claimId.toString()), remarks.toString(), authClientResponse.getUserId());
			if (OPLUtils.isObjectNullOrEmpty(response)) {
				return new ResponseEntity<>(
						new CommonResponse("Something went wrong.", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while webHookClaimDocUpload ------>", e);
			return new ResponseEntity<>(
					new CommonResponse(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
		}
	}
}
