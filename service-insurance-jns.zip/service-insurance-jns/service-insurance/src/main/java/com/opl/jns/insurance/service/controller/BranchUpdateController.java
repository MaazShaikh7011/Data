package com.opl.jns.insurance.service.controller;
//package com.opl.service.insurance.jns.controller;
//
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.Map.Entry;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.opl.service.insurance.jns.domain.BranchDetails;
//import com.opl.service.insurance.jns.repository.BranchDetailsRepository;
//import com.opl.service.insurance.jns.service.impl.BranchUpdateServiceImpl;
//import com.opl.service.insurance.jns.utils.BranchUpdateRequest;
//import com.opl.service.insurance.jns.utils.UpdateMinMaxApplicationId;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author - Maaz Shaikh
// * @Date - 8/16/2023
// */
//
//@RestController
//@Slf4j
//public class BranchUpdateController {
//
//	@Autowired
//	BranchUpdateServiceImpl branchUpdateServiceImpl;
//
//	@Autowired
//	private UpdateMinMaxApplicationId applicationId;
//
//	@Autowired
//	BranchDetailsRepository branchDetailsRepository;
//
//	@GetMapping(value = "/updateMinMaxAPP")
//	public ResponseEntity<Boolean> updateMinMaxAPP() {
//		Map<Integer, Integer> orgList = new HashMap<>();
//		orgList.put(27, 58139);
//		orgList.put(1, 13063);
//		orgList.put(17, 11627);
//		orgList.put(12, 10567);
//		orgList.put(4, 10566);
//		orgList.put(18, 58139);
//		orgList.put(28, 58139);
//		orgList.put(13, 14792);
//		orgList.put(25, 58139);
//		orgList.put(32, 58139);
//		orgList.put(16, 7367);
//		Set<Entry<Integer, Integer>> entrySet = orgList.entrySet();
//		for (Entry<Integer, Integer> rt : entrySet) {
//			applicationId.update(rt.getKey().longValue(), rt.getValue());
//		}
//		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
//	}
//
//	@GetMapping(value = "/updateBranch/{orgId}")
//	public ResponseEntity<Boolean> updateBranchMaster(@PathVariable("orgId") Long orgId) {
//
//		branchUpdateServiceImpl.updateBranchIsInApplication(orgId);
//		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
//	}
//	
//	@GetMapping(value = "/updateLimitData/{from}/{to}")
//	public ResponseEntity<Boolean> updateLimitData(@PathVariable("from") Integer from,@PathVariable("to") Integer to) {
//
//		for (int i = from; i <= to; i++) {
//			branchUpdateServiceImpl.updateLimitData(i);	
//		}
//		log.info("UPDATE LIMIT FROM ------------>" + from + "-----TO------"+ to + "-----------COMPLETED");
//		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
//	}
//
//	@GetMapping(value = "/updateBranches/{orgId}")
//	public ResponseEntity<Boolean> updateBranches(@PathVariable("orgId") Long orgId) {
//
//		List<BranchDetails> allBranchDetails = branchDetailsRepository.findAllByOrgIdAndIsUpdateFalse(orgId);
//		int i = 1;
//		for (BranchDetails br: allBranchDetails) {
//			log.info("updating count [{}] in APP_MST branch [{}] ",i,br.getBranchId());
//			branchUpdateServiceImpl.update(br);
//			i++;
//		}
//		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
//	}
//
//}
