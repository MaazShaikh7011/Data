package com.opl.jns.insurance.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.insurance.service.domain.ErrorStageAudit;

public interface ErrorStageAuditRepository extends JpaRepository<ErrorStageAudit, Long> {

}
