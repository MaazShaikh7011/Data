package com.opl.jns.insurance.service.service;
//package com.opl.service.insurance.jns.service;
//
//import com.opl.jns.api.insurance.exception.*;
//import com.opl.jns.api.insurance.model.*;
//import com.opl.jns.common.api.auth.model.*;
//import com.opl.jns.common.api.oneform.exception.*;
//import com.opl.jns.utils.common.*;
//
//import java.text.*;
//import java.util.List;
//
///***
// * 
// * @author paresh.radadiya
// * @author Maaz Shaikh Date : 02-05-2023
// */
//public interface ClaimMasterService {
//
//	public CommonResponse getAccountHoldersList(ClaimRequest claimRequest, AuthClientResponse authClientResponse);
//
//	public ClaimMasterRequest getClaimFromDetails(Long claimId) throws OneFormException;
//
//	public CommonResponse saveClaimFormDetails(ClaimMasterRequest req);
//
//	String fetchViewClaimDetailsByClaimId(String request, Long userId);
//
//	public ClaimMasterRequest getStage(Long claimId);
//
//	public CommonResponse updateStage(Long claimId, Long userId);
//
//	public CommonResponse publishedClaimedData(Long claimId) throws InsuranceException;
//
//	public CommonResponse updateClaimAccountHolder(Long applicationId, AuthClientResponse authClientResponse);
//	
//	public CommonResponse findAllClaimHistoryByApplicationId(Long applicationId);
//
//	public CommonResponse findAllApprovedClaimDetailsByApplicationId(Long claimId);
//	
//	public CommonResponse fetchViewClaimDetailsByApplicationId(Long applicationId,Long claimId) throws ParseException;
//	
//	public CommonResponse updateClaimStatus(ClaimStatusRequest claimStatusRequest, Long userId) throws OneFormException;
//
//	public void pushRemainingClaim();
//
//	public void updateClaimStatusAndStageHistory(Long claimId);
//	
//	public CommonResponse getAllClaimDetail(Long applicationId,Long claimId) throws ParseException;
//
//	public CommonResponse webHookClaimDocUpload(Long claimId,List<Long> docs);
//
//	public void expireClaimAfter30Days();
//
//	public CommonResponse saveClaimDeDupeDetails(ClaimDeDupeDetailsProxy claimDeDupeDetails, Long userId);
//
//	public CommonResponse getClaimDeDupeDetails(Long claimId);
//
//}
