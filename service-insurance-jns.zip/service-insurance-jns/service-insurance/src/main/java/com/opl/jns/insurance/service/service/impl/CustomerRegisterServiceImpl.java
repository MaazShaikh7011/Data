package com.opl.jns.insurance.service.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.api.proxy.banks.v3.verifyOtp.AccountHoldersDetail;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.enums.ApplicationType;
import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.insurance.api.model.AccountHolderMappingRequest;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.VerfiyOtpRequest;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.service.service.ApplicationMasterService;
import com.opl.jns.insurance.service.service.CustomerRegisterService;
import com.opl.jns.insurance.service.service.EnrollmentService;
import com.opl.jns.insurance.service.utils.CommonUtils;
import com.opl.jns.users.api.model.SignUpRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg.Common;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;
/**
 * @author Maulik Panchal
 */

@Service
@Slf4j
public class CustomerRegisterServiceImpl implements CustomerRegisterService {
	
	public static final List<String> DUMMY_ACC_NO = Arrays.asList("90161910780000001","90161910780000002","90161910780000003","90161910780000004","90161910780000005","90161910780000006","90161910780000007","90161910780000008","90161910780000009","90161910780000010");

	@Autowired
	private ApplicationMasterService applicationMasterService;

	@Autowired
	private EnrollmentService enrollmentService;

	@Autowired
	private BankApiClient bankApiClient;

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepositoryV3;
	
	@Autowired
	private UsersClient usersClient;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	@Autowired
	private ConsentMasterRepository consentMasterRepository;

	@Override
	public CommonResponse create(ApplicationMasterRequest req, AuthClientResponse authClientResponse) throws Exception {
		CommonResponse commonResponse = null;
		try {
			authClientResponse.setUserType(UserTypeMaster.FUNDSEEKER.getId());

			/** for static journey flag */
			String isTesting = ConfigProperties.getIsDiySignUpSkipJourneyFlags();
			if ((!OPLUtils.isObjectNullOrEmpty(isTesting) && "TRUE".equalsIgnoreCase(isTesting)) || DUMMY_ACC_NO.contains(req.getAccountNo())) {
				authClientResponse.setUserId(22l);
//        			authClientResponse.setUserId(6341l);
			}

			/** call create application */
			try {
				commonResponse = applicationMasterService.create(req, authClientResponse);
			} catch (Exception e) {
				log.error("Exception in create application accountNo {} : ", req.getAccountNo(), e);
				return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& commonResponse.getStatus() == HttpStatus.OK.value()) {
				ApplicationMasterRequestV2 applicationMasterReq = MultipleJSONObjectHelper
						.getObjectFromObject(commonResponse.getData(), ApplicationMasterRequestV2.class);
				
				if (!OPLUtils.isObjectNullOrEmpty(applicationMasterReq.getStageId())
						&& applicationMasterReq.getStageId() != EnrollStageMaster.APPLICATION_FORM.getStageId()
						&& applicationMasterReq.getStageId() != EnrollStageMaster.PREMIUM_DEDUCTION.getStageId()
						&& applicationMasterReq.getStageId() != EnrollStageMaster.PREMIUM_DEDUCTION_FAILED
								.getStageId()) {					
					/** update stage OTP VERIFICATION */
					ApplicationMasterRequestV2 appMasterReq = new ApplicationMasterRequestV2(
							applicationMasterReq.getId(), EnrollStageMaster.OTP_VERIFICATION.getStageId());
					CommonResponse updateStageRes = updateStage(appMasterReq, authClientResponse);
					if (updateStageRes.getFlag() == Boolean.FALSE) {
						return updateStageRes;
					}
					
					/** if DIY journey call trigger OTP */
					commonResponse = tiggerOtp(applicationMasterReq, commonResponse, authClientResponse);
				}
				
				}
		} catch (Exception e) {
			log.error("Exception in create application account number {} : ", req.getAccountNo(), e);
			return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		return commonResponse;
	}

	public CommonResponse tiggerOtp(ApplicationMasterRequestV2 applicationMasterReq, CommonResponse commonResponse,
			AuthClientResponse authClientResponse) throws IOException {
		CommonResponse commonResponseTrigOtp = null;
		try {
			commonResponseTrigOtp = enrollmentService.updateEnrollmentVerificationType(applicationMasterReq.getId(),
					CommonUtils.ENROLLMENT_VERIFICATION_OTP, authClientResponse);
		} catch (Exception e) {
			log.error("Exception in trigger OTP applicationId {} : ", applicationMasterReq.getId(), e);
			return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}

		/** update response mobile number and resend otp time */
		if (!OPLUtils.isObjectNullOrEmpty(commonResponseTrigOtp)
				&& !OPLUtils.isObjectNullOrEmpty(commonResponseTrigOtp.getStatus())
				&& commonResponseTrigOtp.getStatus() == HttpStatus.OK.value()) {
			Map<String, Object> mapFromString = MultipleJSONObjectHelper
					.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(commonResponseTrigOtp.getData()));
			if (!OPLUtils.isObjectNullOrEmpty(mapFromString)
					&& (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData()))) {
				ApplicationMasterRequestV2 objectFromObject = MultipleJSONObjectHelper
						.getObjectFromObject(commonResponse.getData(), ApplicationMasterRequestV2.class);
				
				SignUpRequest signUpRequest = new SignUpRequest();
				signUpRequest.setMobile(!OPLUtils.isObjectNullOrEmpty(mapFromString.get(CommonUtils.MOBILE_NUMBER))
						? mapFromString.get(CommonUtils.MOBILE_NUMBER).toString()
						: null);
				
				/**check mobile number already exists in USERS table*/
				CommonResponse checkMobile = usersClient.checkMobile(signUpRequest);
				if(!OPLUtils.isObjectNullOrEmpty(checkMobile) && !OPLUtils.isObjectNullOrEmpty(checkMobile.getStatus())
						&& checkMobile.getStatus()!=HttpStatus.OK.value()) {
					return new CommonResponse(checkMobile.getMessage(), HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
				
				objectFromObject
						.setMobileNumber(!OPLUtils.isObjectNullOrEmpty(mapFromString.get(CommonUtils.MOBILE_NUMBER))
								? OPLUtils.convertToMask(mapFromString.get(CommonUtils.MOBILE_NUMBER).toString(), 4, "X").toString()
								: null);
				objectFromObject
						.setResendOTPTime(!OPLUtils.isObjectNullOrEmpty(mapFromString.get(CommonUtils.RESEND_OTP_TIME))
								? mapFromString.get(CommonUtils.RESEND_OTP_TIME).toString()
								: null);
				commonResponse.setData(objectFromObject);

			}
		}else {
			return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(commonResponseTrigOtp.getMessage()) ? commonResponseTrigOtp.getMessage() : CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		return commonResponse;
	}

	@Override
	public CommonResponse verifyOtp(VerfiyOtpRequest req, AuthClientResponse authClientResponse) throws Exception {
		authClientResponse.setUserType(UserTypeMaster.FUNDSEEKER.getId());
		CommonResponse commonResponse = null;
		try {
			/** for static journey flag */
			String isTesting = ConfigProperties.getIsDiySignUpSkipJourneyFlags();
			ApplicationMasterV3 applicationMasterV3 = applicationMasterRepositoryV3.findByIdAndIsActiveTrue(req.getApplicationId());
			if ((!OPLUtils.isObjectNullOrEmpty(isTesting) && "TRUE".equalsIgnoreCase(isTesting)) || (!OPLUtils.isObjectNullOrEmpty(applicationMasterV3) && DUMMY_ACC_NO.contains(applicationMasterV3.getAccountNumber()))) {
				authClientResponse.setUserId(22l);
//        			authClientResponse.setUserId(6341l);
			}

			/** call verify otp */
			commonResponse = enrollmentService.verifyOtp(req, authClientResponse);
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus() == HttpStatus.OK.value())) {
				ApplicationMasterRequestV2 appMasterReq = new ApplicationMasterRequestV2(req.getApplicationId(),
						EnrollStageMaster.ACCOUNT_HOLDER_SELECTION.getStageId());
				CommonResponse updateStageRes = updateStage(appMasterReq, authClientResponse);
				if (updateStageRes.getFlag() == Boolean.FALSE) {
					return updateStageRes;
				}
				ApplicationMasterRequestV2 appMasterRequest = new ApplicationMasterRequestV2();
				appMasterRequest.setMobile(applicationMasterV3.getApplicantInfo().getMobileNumber());
				appMasterRequest.setUrn(applicationMasterV3.getUrn());
				commonResponse.setData(appMasterRequest);
			}
		} catch (Exception e) {
			log.error("Exception in verify OTP applicationId {} : ", req.getApplicationId(), e);
			return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
		return commonResponse;
	}

	@Override
	public CommonResponse updateEnrollmentVerificationType(Long applicationId, AuthClientResponse authClientResponse)
			throws Exception {
		authClientResponse.setUserType(UserTypeMaster.FUNDSEEKER.getId());

		try {
			/** for static journey flag */
			String isTesting = ConfigProperties.getIsDiySignUpSkipJourneyFlags();

			if ((!OPLUtils.isObjectNullOrEmpty(isTesting) && "TRUE".equalsIgnoreCase(isTesting))) {
				authClientResponse.setUserId(22l);
//        			authClientResponse.setUserId(6341l);
			}

			/** call and return tigger otp response */
			return enrollmentService.updateEnrollmentVerificationType(applicationId,
					CommonUtils.ENROLLMENT_VERIFICATION_OTP, authClientResponse);
		} catch (Exception e) {
			log.error("Exception in resend OTP applicationId {} : ", applicationId, e);
		}
		return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
	}

	@Override
	public CommonResponse accountHolderSelectionDetails(AccountHolderSelectionDetailsRequest accountHolderSelRequest)
			throws IOException {

		try {
			/** bank client call for fetch verify otp response from bucket */
			VerifyOtpApiResponse verifyOtpApiResponse = bankApiClient.fetchVerifyOtpResponse(accountHolderSelRequest);
			if (!OPLUtils.isObjectNullOrEmpty(verifyOtpApiResponse) && !OPLUtils.isObjectNullOrEmpty(verifyOtpApiResponse.getStatus())
					&& verifyOtpApiResponse.getStatus() == HttpStatus.OK.value()) {
				/** prepare verify otp response */
				return getAccountHolderRes(accountHolderSelRequest, verifyOtpApiResponse);
			}
		} catch (Exception e) {
			log.error("Exception in get account holder selection details urn, userId {} {} : ",
					accountHolderSelRequest.getUrn(), accountHolderSelRequest.getUserId(), e);
		}

		return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
	}

	private CommonResponse getAccountHolderRes(AccountHolderSelectionDetailsRequest accountHolderSelRequest,
			VerifyOtpApiResponse verifyOtpApiResponse) throws IOException {

		CommonResponse response = null;
		if (!OPLUtils.isObjectNullOrEmpty(verifyOtpApiResponse)) {

			ApplicationMasterV3 appMaster = applicationMasterRepositoryV3
					.findFirstByUrnAndIsActiveTrue(accountHolderSelRequest.getUrn());
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.error("Application master details not found by urn -->" + accountHolderSelRequest.getUrn());
				return null;
			} else {
				/** update userId for new DIY journey */
				applicationMasterRepositoryV3.updateUserIdByApplicationId(accountHolderSelRequest.getUserId(),
						appMaster.getId());
			}

			/** prepare and set account holder details */
			List<AccountHoldersDetail> holderList = verifyOtpApiResponse.getAccountHolderDetails();
			List<AccountHolderMappingRequest> holderMapReq = new ArrayList<>(holderList.size());
			response = new CommonResponse();
			holderList.forEach(val -> {
				holderMapReq.add(AccountHolderMappingRequest.builder().accountHolderName(val.getAccountHolderName())
						.applicationId(appMaster.getId()).cif(val.getCif())
						.customerAccountNumber(appMaster.getAccountNumber()).urnCode(appMaster.getUrn())
						.sizeOfACHolder(holderList.size()).dob(val.getDob())
						.gender(!OPLUtils.isObjectNullOrEmpty(val.getGender()) ? val.getGender() : null)
						.pmjjbyExists(setApiResFlag(val.getPMJJBYexists()))
						.pmsbyExists(setApiResFlag(val.getPMSBYexists())).kycUpdated(setApiResFlag(val.getKYCUpdated()))
						.build());
			});

			response.setMessage("SuccessFully Get Data");
			response.setStatus(HttpStatus.OK.value());
			response.setData(holderMapReq);
			response.setFlag(true);
		}
		
		/**INSERT DATA IN CONSENT MAPPING*/
		insertConsentMapping(accountHolderSelRequest.getUserId());
		
		return response;

	}
	
	private void insertConsentMapping(Long userId) {
		try {			
			/**PRIVACY POLICY*/
			ConsentMappingProxy consentMappingProxy = ConsentMappingProxy.builder().appTypeValue(userId).appType(ApplicationType.USER.getId()).userId(userId).consentTypeId(ConsentType.USER_SIGNUP_PRIVACY_POLICY.getId()).build();
			ereCommonService.insertDataConsentMappingTable(consentMappingProxy);
			
			/**TERMS AND CONDITION*/
			consentMappingProxy.setConsentTypeId(ConsentType.USER_SIGNUP_TERM_CONDITION.getId());
			ereCommonService.insertDataConsentMappingTable(consentMappingProxy);
			
			/**DISCLAIMER*/
			consentMappingProxy.setConsentTypeId(ConsentType.USER_SIGNUP_DISCLAIMER.getId());
			ereCommonService.insertDataConsentMappingTable(consentMappingProxy);
		}catch (Exception e) {
			log.info("ERROR WHILE SAVE CONSENT--> {}", userId);
		}
	}

	private boolean setApiResFlag(String flag) {
		if (!OPLUtils.isObjectNullOrEmpty(flag) && (flag.equalsIgnoreCase("Yes") || flag.equalsIgnoreCase("Y"))) {
			return true;
		}
		return false;
	}

	private CommonResponse updateStage(ApplicationMasterRequestV2 appMasterReq, AuthClientResponse authClientResponse) {
		try {
			CommonResponse updateStageRes = applicationMasterService.updateStage(appMasterReq, authClientResponse);
			if (!OPLUtils.isObjectNullOrEmpty(updateStageRes)
					&& updateStageRes.getStatus() == HttpStatus.OK.value()) {
				return new CommonResponse(Common.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
			}
			return new CommonResponse(!OPLUtils.isObjectNullOrEmpty(updateStageRes.getMessage()) ? updateStageRes.getMessage()
							: CommonUtils.GENERIC_ERROR_MSG,
					HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		} catch (Exception e) {
			log.info("Exception in updating stage while retrying app : ", e);
			return new CommonResponse(CommonUtils.GENERIC_ERROR_MSG, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
		}
	}

	@SuppressWarnings("unused")
	private boolean isTestingMode(Long userId) {
		String isTesting = ConfigProperties.getBankApiTestingModeFlags();
		List<String> isSkipUserIdIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
		List<Long> isSkipUserIdsLst = isSkipUserIdIds.stream().map(Long::parseLong).collect(Collectors.toList());
		if ((!OPLUtils.isObjectNullOrEmpty(isTesting) && "TRUE".equals(isTesting))
				|| isSkipUserIdsLst.contains(userId)) {
			return true;
		}
		return false;
	}
}
