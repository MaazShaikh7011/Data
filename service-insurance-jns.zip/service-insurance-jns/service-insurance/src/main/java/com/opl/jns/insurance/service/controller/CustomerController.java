package com.opl.jns.insurance.service.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.insurance.api.model.EnrollmentListRequest;
import com.opl.jns.insurance.service.service.CustomerService;
import com.opl.jns.users.api.utils.UsersCommonUtils;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3/cust")
@Slf4j
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	/**
	 * get consent form with values by applicationId
	 * @param applicationId
	 * @return
	 */
	@GetMapping(value = "/getConsentData/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getConsentData(@PathVariable Long applicationId) {
		try {
			log.info("Enter in get getConsentData ---->" + applicationId);
			String consentDataProxy = customerService.getConsentDetails(applicationId);
			if (consentDataProxy == null) {
				return new ResponseEntity<>(new CommonResponse(
						"Its seems we have not found details by given information, kindly refresh page and try again",
						HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new CommonResponse("Successfully get consent Details!!",
					consentDataProxy, HttpStatus.OK.value(), true), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get consent Details ==>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * get EnrollmentList For WEB DIY Journey
	 * 
	 * @param authClientResponse
	 * @param userId
	 * @return
	 */
	@PostMapping(value = "/getEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getEnrollmentList(@RequestBody EnrollmentListRequest request, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (authClientResponse == null || authClientResponse.getUserId() == null) {
				return new ResponseEntity<CommonResponse>(new CommonResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			return new ResponseEntity<>(customerService.getEnrollmentList(request, authClientResponse.getUserId()),HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getEnrollmentList ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * get getOrganisationList By UserTypeId 
	 * 
	 * @param userTypeId
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/getOrganisationListByUserTypeId/{userTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrganisationListByUserTypeId(@PathVariable Long userTypeId) {
		try {
			log.info("Enter in getOrganisationListByUserTypeId details ------------------>");
			List<Map<Long, String>> orgMasterList = customerService.getOrganisationListByUserTypeId(userTypeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no insurer list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Success", orgMasterList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getOrganisationListByUserTypeId :", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * get mobile application dashboard list For MOBILE DIY Journey
	 * 
	 * @param authClientResponse
	 * @param userId
	 * @return
	 */
	@PostMapping(value = "/getDashboardEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getDashboardEnrollmentList(@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			if (authClientResponse == null || authClientResponse.getUserId() == null) {
				return new ResponseEntity<>(new CommonResponse(UsersCommonUtils.INVALID_REQUEST, HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}

			return new ResponseEntity<>(customerService.getDashboardEnrollmentList(authClientResponse.getUserId()),HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getDashboardEnrollmentList ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/getOrganisationAndInsurerListByUserTypeId/{userTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getOrganisationAndInsurerListByUserTypeId(@PathVariable Long userTypeId) {
		try {
			log.info("Enter in getOrganisationListByUserTypeId details ------------------>");
			List<Map<String, String>> orgMasterList = customerService.getOrganisationAndInsurerListByUserTypeId(userTypeId);
			if (OPLUtils.isObjectNullOrEmpty(orgMasterList)) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Its seems there is no insurer list available in the system",
								HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<CommonResponse>(new CommonResponse("Success", orgMasterList, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getOrganisationListByUserTypeId :", e);
			return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
