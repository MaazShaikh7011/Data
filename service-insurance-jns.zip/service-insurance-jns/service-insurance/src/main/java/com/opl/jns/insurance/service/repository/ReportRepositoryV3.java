package com.opl.jns.insurance.service.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@Repository
public interface ReportRepositoryV3{
	String getDataFromProducer(String request, Long userId, String spName);
	
	public List<Object> fetchListOfDataFromDb(String query);
	String fetchOptOutApplication(String query);
	String fetchCount(String query);
}
