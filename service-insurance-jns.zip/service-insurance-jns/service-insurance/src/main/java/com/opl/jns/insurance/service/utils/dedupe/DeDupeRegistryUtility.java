package com.opl.jns.insurance.service.utils.dedupe;
//package com.opl.service.insurance.jns.utils.dedupe;
//
//import java.util.Objects;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Lazy;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//import com.opl.api.dd.jns.model.claimDedupe.ClaimDedupApiProxy;
//import com.opl.api.dd.jns.model.dedupe.ClaimDedupApiResponse;
//import com.opl.api.dd.jns.model.pushClaim.PushClaimProxy;
//import com.opl.api.dd.jns.model.updateClaimStatus.TransactionDetailsProxy;
//import com.opl.api.dd.jns.model.updateClaimStatus.UpdateClaimStatusProxy;
//import com.opl.client.dd.DedupeRegistryClient;
//import com.opl.jns.ere.domain.ApplicationMasterV3;
//import com.opl.jns.ere.domain.ClaimDeDupeDetails;
//import com.opl.jns.ere.domain.ClaimMasterV3;
//import com.opl.jns.ere.enums.CauseOfDeathDisability;
//import com.opl.jns.ere.enums.Gender;
//import com.opl.jns.ere.enums.NatureOfLoss;
//import com.opl.jns.ere.enums.TypeOfDisability;
//import com.opl.jns.utils.common.CommonErrorMsg;
//import com.opl.jns.utils.common.CommonResponse;
//import com.opl.jns.utils.common.MultipleJSONObjectHelper;
//import com.opl.jns.utils.common.OPLUtils;
//import com.opl.jns.utils.enums.ClaimStatus;
//import com.opl.jns.utils.enums.SchemeMaster;
//import com.opl.service.insurance.jns.service.EnrollmentService;
//import com.opl.service.insurance.jns.utils.CommonUtils;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author sandip.bhetariya
// *
// */
//@Slf4j
//@Service
//public class DeDupeRegistryUtility {
//
//	@Autowired
//	private DedupeRegistryClient dedupeRegistryClient;
//
//	@Lazy
//	@Autowired
//	private EnrollmentService enrollmentService;
//
//	
//	/*public ApiData callCheckDedupeRequest(ApplicationMasterV3 appMaster, AuthClientResponse authRes, AccountHolderDetailsResponse wrap, DeDupeApiCallType deDupeApiCallType) {
//
//		/**
//		 * Y - Match Found
//		 * 
//		 * N- Not Match
//		 * 
//		 * E - Error or condition did not match
//
//		 */
//		/*String pythonApiCall = configProperties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
//
//		if (null != pythonApiCall && pythonApiCall.equalsIgnoreCase("true")) {
//			try {
//				if (OPLUtils.isObjectNullOrEmpty(deDupeApiCallType)) {
//					log.info(CommonUtils.INVALID_OR_BAD_REQUEST_ONE_OR_MORE_PARAMETER_IS_EMPTY + "   -->" + appMaster.getId());
//					return new ApiData("E", CommonUtils.INVALID_OR_BAD_REQUEST_ONE_OR_MORE_PARAMETER_IS_EMPTY);
//				}
//
//				com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callCheckDedupeRequest(getcallCheckDedupeRequestData(appMaster, wrap, deDupeApiCallType));
//
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//						&& (commonResponse.getStatus() == HttpStatus.OK.value() || commonResponse.getStatus() == HttpStatus.NO_CONTENT.value())) {
//					ApiData apiData = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), ApiData.class);
//					if (!OPLUtils.isObjectNullOrEmpty(apiData) && OPLUtils.isObjectNullOrEmpty(apiData.getIsMatched())) {
//						log.error(CommonUtils.DE_DUPE_EXCEPTION_MSG + "-->" + appMaster.getId());
//						return new ApiData("E", CommonUtils.DE_DUPE_EXCEPTION_MSG);
//					}
//					if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()))
//						apiData.setMessage(commonResponse.getMessage());
//
//
//					log.info("De Dupe details found for account number [{}] and response is : [{}]",appMaster.getAccountNumber(),MultipleJSONObjectHelper.getStringfromObject(apiData));
//					return apiData;
//				} else if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus()) && commonResponse.getStatus() == HttpStatus.BAD_REQUEST.value()) {
//					log.error(commonResponse.getMessage());
//					return new ApiData("E", commonResponse.getMessage());
//				} else {
//					log.error(!OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.DE_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//					return new ApiData("E", !OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.DE_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//				}
//
//			} catch (Exception e) {
//				log.error(CommonUtils.DE_DUPE_EXCEPTION_MSG + "------>", e);
//				return new ApiData("E", CommonUtils.DE_DUPE_EXCEPTION_MSG);
//			}
//		} else {
//			log.info("Python testing Mode is ON so skiping dedupe call");
//			return new ApiData("N", "Python testing Mode is ON so skiping dedupe call");
//		}
//	}*/
//
//
//	/*public UpdateEnrollResponse callUpdateEnrollmentStatus(Long applicationId, String pythonApiCall, ApplicationMasterV3 applicationMaster, 
//			ApplicationStatus applicationStatus) throws Exception {
//		if ("true".equalsIgnoreCase(pythonApiCall)) {
//			if (OPLUtils.isObjectNullOrEmpty(applicationMaster))
//				applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
//
//			//			ApplicationMasterV3 applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
//
//
////			UpdateEnrollRequest updateEnrollRequest = CommonUtils.getUpdateEnrollmentStatusReq(applicationMaster);
//			UpdateEnrollRequest enrollRequest = new UpdateEnrollRequest();
//			enrollRequest.setApplicationId(applicationMaster.getId());
//			enrollRequest.setUrn(applicationMaster.getUrn());
//			enrollRequest.setStatus(applicationStatus.getId());
//			enrollRequest.setReason(applicationStatus.getValue());
//			enrollRequest.setDateOfEnrollment(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getEnrollmentDate()) ? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(applicationMaster.getEnrollmentDate()) : null);
//			
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callUpdateEnrollmentStatus(enrollRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus()) 
//					&& (commonResponse.getStatus()== HttpStatus.OK.value() || commonResponse.getStatus()== HttpStatus.ACCEPTED.value())) {
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData()))
//					return MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), UpdateEnrollResponse.class);
//			}
//		}
//		return null;
//	}*/
//
//	/*public SingleEnrollmentResponse callSingleEnrollmentRequest(Long applicationId, ApplicationMasterV3 applicationMaster, String pythonApiCall, boolean isPythonPushed) throws Exception {
//
//		if (pythonApiCall.equalsIgnoreCase("true") && !isPythonPushed) {
//
//			if (OPLUtils.isObjectNullOrEmpty(applicationMaster))
//				applicationMaster = applicationMasterRepository.findByIdAndIsActiveTrue(applicationId);
//
//			ApplicationMasterRequestV2 masterRequestV2 = enrollmentService.getApplicationAllDetails(applicationMaster.getId(), applicationMaster);
//			SingleEnrollmentRequest enrollmentRequest = CommonUtils.getSingleEnrollmentReq(masterRequestV2);
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callSingleEnrollmentRequest(enrollmentRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus()) 
//					&& (commonResponse.getStatus()== HttpStatus.OK.value() || commonResponse.getStatus()== HttpStatus.ACCEPTED.value())) {
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse.getData()))
//					return MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), SingleEnrollmentResponse.class);
//			}
//		}
//		return null;
//	}*/
//
//	/*private DedupApiReqProxy getcallCheckDedupeRequestData(ApplicationMasterV3 applicationMaster, AccountHolderDetailsResponse wrap, DeDupeApiCallType deDupeApiCallType) {
//		DedupApiReqProxy dedupRequest = new DedupApiReqProxy();
//		if (deDupeApiCallType.getId().equals(DeDupeApiCallType.PREMIUM_DEDUCTION.getId())) {
//			dedupRequest.setKycId1(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId1()) ?  applicationMaster.getApplicantInfo().getKycId1().toUpperCase() : applicationMaster.getApplicantInfo().getKycId1());
//			dedupRequest.setKycIdValue1(applicationMaster.getApplicantInfo().getKycIdNumber1());
//			dedupRequest.setKycId2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId2()) ? applicationMaster.getApplicantInfo().getKycId2().toUpperCase() : applicationMaster.getApplicantInfo().getKycId2());
//			dedupRequest.setKycIdValue2(applicationMaster.getApplicantInfo().getKycIdNumber2());
//			dedupRequest.setCkycNumber(applicationMaster.getApplicantInfo().getCkycNumber());
//			dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId()) ? Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue()  : null);
//			dedupRequest.setFirstName(applicationMaster.getApplicantInfo().getFirstName());
//			dedupRequest.setMiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//			dedupRequest.setLastName(applicationMaster.getApplicantInfo().getLastName());
//			dedupRequest.setFatherHusbandName(applicationMaster.getApplicantInfo().getFatherHusbandName());
//			dedupRequest.setMob(applicationMaster.getApplicantInfo().getMobileNumber());
//			dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress()) ? applicationMaster.getApplicantInfo().getAddress().getPincode() : null);
//			dedupRequest.setDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//			dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
//			dedupRequest.setAccNo(applicationMaster.getAccountNumber());
//			dedupRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//			dedupRequest.setAccountStatus("A");
//			dedupRequest.setType("N");
//			dedupRequest.setOrgId(applicationMaster.getOrgId());
//			dedupRequest.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//			dedupRequest.setCif(applicationMaster.getCif());
//			dedupRequest.setUrn(applicationMaster.getUrn());
//		} else if (deDupeApiCallType.getId().equals(DeDupeApiCallType.UPDATE_SELECTED_ACCOUNT_HOLDER.getId())) {
//			dedupRequest.setKycId1(!OPLUtils.isObjectNullOrEmpty(wrap.getKycID1()) ?  wrap.getKycID1().toUpperCase() : wrap.getKycID1());
//			dedupRequest.setKycIdValue1(wrap.getKycID1number());
//			dedupRequest.setKycId2(!OPLUtils.isObjectNullOrEmpty(wrap.getKycID2()) ? wrap.getKycID2().toUpperCase() : wrap.getKycID2());
//			dedupRequest.setKycIdValue2(wrap.getKycID2number());
//			dedupRequest.setCkycNumber(wrap.getCkycNumber());
//			dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(wrap.getGender()) ? Gender.fromBankValue(wrap.getGender()).getBankValue() : null);
//			dedupRequest.setFirstName(wrap.getFirstName());
//			dedupRequest.setMiddleName(wrap.getMiddleName());
//			dedupRequest.setLastName(wrap.getLastName());
//			dedupRequest.setFatherHusbandName(wrap.getFatherHusbandName());
//			dedupRequest.setMob(wrap.getMobileNumber());
//			dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(wrap.getPincode()) ? wrap.getPincode().intValue() : null);
//			dedupRequest.setDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(wrap.getDob()));
//			dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
//			dedupRequest.setAccNo(applicationMaster.getAccountNumber());
//			dedupRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//			dedupRequest.setAccountStatus("A");
//			dedupRequest.setType("N");
//			dedupRequest.setCif(applicationMaster.getCif());
//			dedupRequest.setUrn(applicationMaster.getUrn());
//			dedupRequest.setOrgId(applicationMaster.getOrgId());
//			dedupRequest.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//		}
//		return dedupRequest;
//
//	}
//	*/
//
//
//	/*public CommonResponse callCheckDedupeRequest_old(ApplicationMasterV3 appMaster, AuthClientResponse authRes, AccountHolderDetailsResponse wrap, DeDupeApiCallType deDupeApiCallType) {
//		String pythonApiCall = configProperties.getValueByCode(OPLUtils.IS_PYTHON_API_CALL);
//		if (null != pythonApiCall && pythonApiCall.equalsIgnoreCase("true")) {
//			try {
//
//				if (OPLUtils.isObjectNullOrEmpty(deDupeApiCallType)) {
//					log.info("Exception in fetching the values   -->" + appMaster.getId());
//					return new CommonResponse("Exception in fetching the values", ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
//				}
//				com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callCheckDedupeRequest(getcallCheckDedupeRequestData(appMaster, wrap, deDupeApiCallType));
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse)) {
//					DedupApiResProxy apiResProxy = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), DedupApiResProxy.class);
//					if (!OPLUtils.isObjectNullOrEmptyOrDash(apiResProxy) && !OPLUtils.isObjectNullOrEmpty(apiResProxy.getData())) {
//						ApiData apiData = apiResProxy.getData();
//						if (!OPLUtils.isObjectNullOrEmpty(apiData) && !OPLUtils.isObjectNullOrEmpty(apiData.getIsMatched()) && apiData.getIsMatched().equalsIgnoreCase("Y")) {
//							enrollmentService.updateAppMasterErro(appMaster, CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, authRes.getUserId());
//							return new CommonResponse(CommonUtils.CUSTOMER_ALREADY_ENROLLED_ERROR, ResponseStatus.APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER.getStatusId(), false);
//						}
//					}else {
//						log.error("call Check Dedupe Request Error -->");
//						return new CommonResponse("Call Check Dedupe Error", ResponseStatus.EXCEPTION_IN_PROCESSING.getStatusId(), false);
//					}
//				}else {
//					log.error("call Check Dedupe Response Error -->");
//					return new CommonResponse("Call Check Dedupe Response Error", ResponseStatus.EXCEPTION_IN_PROCESSING.getStatusId(), false);
//				}
//
//			} catch (Exception e) {
//				log.error("call Check Dedupe Request Error -->", e);
//				return new CommonResponse("Call Check Dedupe Error", ResponseStatus.EXCEPTION_IN_PROCESSING.getStatusId(), false);
//			}
//		} else
//			log.info("Python testing Mode is ON so skiping dedupe call");
//		return null;
//	}*/
//
//	
//	public CommonResponse callPushClaimRequest(ClaimMasterV3 claimMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callPushClaimRequest(getcallClaimPushRequestData(claimMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);	
//			}
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		} catch (Exception e) {
//			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		}
//}
//	
//	private PushClaimProxy getcallClaimPushRequestData(ClaimMasterV3 claimMaster) {
//		ApplicationMasterV3 applicationMaster = claimMaster.getApplicationMaster();
//		PushClaimProxy pushClaimProxy = new PushClaimProxy();
//		pushClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
//		pushClaimProxy.setUrn(applicationMaster.getUrn());
//		pushClaimProxy.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//		pushClaimProxy.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId()) ?  Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue() : null);
//		pushClaimProxy.setApplicantAccNo(applicationMaster.getAccountNumber());
//		pushClaimProxy.setOrgId(applicationMaster.getOrgId());
//		pushClaimProxy.setApplicantDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//		pushClaimProxy.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//		pushClaimProxy.setMasterPolicyNumber(applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
//		pushClaimProxy.setApplicantfirstName(applicationMaster.getApplicantInfo().getFirstName());
//		pushClaimProxy.setApplicantmiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//		pushClaimProxy.setApplicantlastName(applicationMaster.getApplicantInfo().getLastName());
//		pushClaimProxy.setDateofDeath(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateOfDeath()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDetail().getDateOfDeath()) : null);
//		pushClaimProxy.setDateofAccident(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getDateTimeOfAccident()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDetail().getDateTimeOfAccident()) : null);
//		pushClaimProxy.setClaimStatusId(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
//		pushClaimProxy.setEnrollmentDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(applicationMaster.getCompletionDate()));
//		if(applicationMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
//			String typeOfDisability = null;
//			if(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getTypeOfDisablityId())) {
//				typeOfDisability = TypeOfDisability.fromId(claimMaster.getClaimDetail().getTypeOfDisablityId()).getValue();
//			}
//			String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId()) ? typeOfDisability : "-";
//			pushClaimProxy.setClaimType(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getNatureOfLossId()) && Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DEATH.getId()) ? "Accidental Death" : typeOfLoss );
//		}else if(applicationMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue() && (!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId()))) {		
//				String typeOfLoss=Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId()) ? CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getValue() : "-";
//				pushClaimProxy.setClaimType(Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId()) ? CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getValue() :typeOfLoss );
//			
//		}
//		pushClaimProxy.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDate()) : null);
//		return pushClaimProxy;
//	}
//	
//	
//	public CommonResponse callUpdateClaimStatusRequest(ClaimMasterV3 claimMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callUpdateClaimStatusRequest(getcallUpdateClaimRequestData(claimMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);	
//			}
//			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		} catch (Exception e) {
//			log.error(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		}
//}
//	
//	private UpdateClaimStatusProxy getcallUpdateClaimRequestData(ClaimMasterV3 claimMaster) {
//		UpdateClaimStatusProxy updateClaimProxy = new UpdateClaimStatusProxy();
//	
//		updateClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
//		updateClaimProxy.setUrn(claimMaster.getApplicationMaster().getUrn());
//		updateClaimProxy.setClaimStatus(claimMaster.getClaimStatus());
//		updateClaimProxy.setReason(claimMaster.getStatusReasonId());
//	
//		TransactionDetailsProxy transactionDetailsProxy = new TransactionDetailsProxy();
//		transactionDetailsProxy.setTransactionAmount(!OPLUtils.isObjectNullOrEmpty(claimMaster.getAmountOfTransaction())
//				? claimMaster.getAmountOfTransaction().longValue()
//				: null);
//		transactionDetailsProxy.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(claimMaster.getDateOfTransaction())
//				? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(claimMaster.getDateOfTransaction())
//				: null);
//		transactionDetailsProxy.setTransactionUTR(claimMaster.getTransactionUtr());
//	
//		updateClaimProxy.setTransactionDetails(transactionDetailsProxy);
//		return updateClaimProxy;
//	}
//
//	
//	
//	public ClaimDedupApiResponse callClaimDedupeRequest(ClaimMasterV3 claimMaster,ClaimDeDupeDetails deDupeDetails) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callClaimDedupeRequest(getcallClaimDedupeRequestData(claimMaster,deDupeDetails));
//			
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())) {
//				ClaimDedupApiResponse claimDedupApiResponse = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), ClaimDedupApiResponse.class);
//				if(claimDedupApiResponse.getIsDup().equals(Boolean.TRUE)) {						
//					log.info("De Dupe details found for account number [{}] and response is : [{}]",claimMaster.getApplicationMaster().getAccountNumber(),MultipleJSONObjectHelper.getStringfromObject(claimDedupApiResponse));
//				}
//				return claimDedupApiResponse;
//			} else {
//				log.error(!OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//				return new ClaimDedupApiResponse(false, !OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//			}
//		} catch (Exception e) {
//			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//			return new ClaimDedupApiResponse(false, CommonUtils.CLAIM_DUPE_EXCEPTION_MSG);
//		}
//}
//
//	private ClaimDedupApiProxy getcallClaimDedupeRequestData(ClaimMasterV3 claimMaster,ClaimDeDupeDetails deDupeDetails) {
//		ApplicationMasterV3 applicationMaster = claimMaster.getApplicationMaster();
//			ClaimDedupApiProxy dedupRequest = new ClaimDedupApiProxy();
//			dedupRequest.setKycId1(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId1()) ?  applicationMaster.getApplicantInfo().getKycId1().toUpperCase() : applicationMaster.getApplicantInfo().getKycId1());
//			dedupRequest.setKycIdValue1(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycIdNumber1()) ? applicationMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : applicationMaster.getApplicantInfo().getKycIdNumber1());
//			dedupRequest.setKycId2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId2()) ? applicationMaster.getApplicantInfo().getKycId2().toUpperCase() : applicationMaster.getApplicantInfo().getKycId2());
//			dedupRequest.setKycIdValue2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycIdNumber2()) ? applicationMaster.getApplicantInfo().getKycIdNumber2().toUpperCase() : applicationMaster.getApplicantInfo().getKycIdNumber2());
//			dedupRequest.setCkycNumber(applicationMaster.getApplicantInfo().getCkycNumber());
//			dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId()) ? Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue()  : null);
//			dedupRequest.setFirstName(applicationMaster.getApplicantInfo().getFirstName());
//			dedupRequest.setMiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//			dedupRequest.setLastName(applicationMaster.getApplicantInfo().getLastName());
//			dedupRequest.setFatherHusbandName(applicationMaster.getApplicantInfo().getFatherHusbandName());
//			dedupRequest.setMob(applicationMaster.getApplicantInfo().getMobileNumber());
//			dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress()) ? applicationMaster.getApplicantInfo().getAddress().getPincode() : null);
//			dedupRequest.setDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//			dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
//			dedupRequest.setAccNo(applicationMaster.getAccountNumber());
//			dedupRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//			dedupRequest.setAccountStatus("A");
//			dedupRequest.setType("N");
//			dedupRequest.setOrgId(applicationMaster.getOrgId());
//			dedupRequest.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//			dedupRequest.setCif(applicationMaster.getCif());
//			dedupRequest.setUrn(applicationMaster.getUrn());
//			dedupRequest.setEnrollmentDate(CommonUtils.formatDate_sdf(applicationMaster.getEnrollmentDate()));
//			dedupRequest.setDateOfDeath(CommonUtils.formatDate_sdf(claimMaster.getClaimDetail().getDateOfDeath()));
//			dedupRequest.setDateOfAccident(CommonUtils.formatDate_sdf(claimMaster.getClaimDetail().getDateTimeOfAccident()));
//			dedupRequest.setIsNameMatch("true");
//			dedupRequest.setClaimTypeId(getClaimTypeId(claimMaster));
//			dedupRequest.setClaimReferenceId(claimMaster.getId().toString());
//			dedupRequest.setFirNo(deDupeDetails.getFIRNo());
//			dedupRequest.setFirDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getFIRDate()));
//			dedupRequest.setPanchnamaNo(deDupeDetails.getPanchnamaNo());
//			dedupRequest.setPanchnamaDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getPanchnamaDate()));
//			dedupRequest.setPostMortemReportNo(deDupeDetails.getPostMortemReportNo());
//			dedupRequest.setPostMortemReportDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getPostMortemReportDate()));
//			dedupRequest.setDeathOrdisabilityCertificateReportNo(deDupeDetails.getDeathDisabilityCertificateReportNo());
//			dedupRequest.setDeathOrdisabilityCertificateReportDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(deDupeDetails.getDeathDisabilityCertificateReportDate()));
//			return dedupRequest;
//	}
//	
//	private Integer getClaimTypeId(ClaimMasterV3 claimMaster) {
//		if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMSBY.getId().longValue()) {
//			if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DEATH.getId())) {
//				return 4;
//			} else if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
//					&& Objects.equals(claimMaster.getClaimDetail().getTypeOfDisablityId(), TypeOfDisability.PARTIAL_DISABILITY
//							.getId())) {
//				return 2;
//			} else if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
//					&& Objects.equals(claimMaster.getClaimDetail().getTypeOfDisablityId(), TypeOfDisability.TOTAL_DISABILITY
//							.getId())) {
//				return 3;
//			}
//
//		} else if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMJJBY.getId().longValue()) {
//			if (Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId())) {
//				return 1;
//			} else if (Objects.equals(claimMaster.getClaimDetail()
//					.getCauseOfDeathDisabilityId(), CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId())) {
//				return 5;
//			}
//		}
//		return null;
//	}
//	
//	
//
//}
