package com.opl.jns.insurance.service.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.repo.ApplicantInfoRepository;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.insurance.api.model.v2.SearchRequest;
import com.opl.jns.insurance.service.repository.ReportRepositoryV3;
import com.opl.jns.insurance.service.service.CommonService;
import com.opl.jns.insurance.service.utils.ResponseStatus;
import com.opl.jns.users.api.model.UsersRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;

/***
 * 
 * @author Ravi.dafda
 * @date 11-08-2023
 */

@Component
@Slf4j
public class CommonServiceImpl implements CommonService {

	@Autowired
	private ApplicationMasterRepositoryV3 masterRepository;

	@Autowired
	private ApplicantInfoRepository applicantInfoRepository;
	
	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;
	
	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepoV2;

	@Autowired
	ReportRepositoryV3 reportRepository;
	
	@Autowired
	private EreCommonService ereCommonService;
	
	@Autowired
	private UsersClient usersClient;
	
	@Cacheable(value = "rpt_getbySearchFilter", key = "{#searchRequest, #authClientResponse}")
	@Override
	public CommonResponse getbySearchFilter(SearchRequest searchRequest, AuthClientResponse authClientResponse) {

		List<ApplicationMasterV3> applicationMasterList = new ArrayList<>();
		
		List<ApplicantInfo> applicantInfoList = new ArrayList<>();

		if (!OPLUtils.isObjectNullOrEmpty(searchRequest) && !OPLUtils.isObjectNullOrEmpty(searchRequest.getSearchType())
				&& !OPLUtils.isObjectNullOrEmpty(searchRequest.getSearchValue())) {

			Integer typeOfSearch = searchRequest.getSearchType();
			String searchValue = searchRequest.getSearchValue();
			String searchTypeAsStr = searchRequest.getSearchTypeAsStr();
			
			switch (typeOfSearch) {
			case 1:
				applicationMasterList = masterRepository.findByIsActiveTrueAndAccountNumber(searchValue);
				break;

			case 2:
				applicationMasterList = masterRepository.findAllByUrn(searchValue);
				break;

			case 3:
				applicantInfoList = applicantInfoRepository.findByMobileNumberAndIsActiveTrue(searchValue);
				break;
			case 4:
				applicantInfoList = applicantInfoRepository.findByPanAndIsActiveTrue(searchValue);
				break;
			case 5:
				applicantInfoList = applicantInfoRepository.findByKycId1AndKycIdNumber1AndIsActiveTrue(searchTypeAsStr, searchValue);
				if(OPLUtils.isListNullOrEmpty(applicantInfoList)) {
					applicantInfoList = applicantInfoRepository.findByKycId2AndKycIdNumber2AndIsActiveTrue(searchTypeAsStr, searchValue);
				}
				break;

			default:
				log.info("Not any default details found ::::::::> ");
				break;
			}
			
			List<Map<String, Object>> reqlist = new ArrayList<>();
			
			if (!OPLUtils.isObjectListNull(applicationMasterList)) {

				applicationMasterList.forEach(x -> {
					Map<String, Object> map = new HashMap<>();
					
					String mobileNumber = (!OPLUtils.isObjectNullOrEmpty(x.getApplicantInfo().getMobileNumber())
							? x.getApplicantInfo().getMobileNumber() : null);
					String fullName = (!OPLUtils.isObjectNullOrEmpty(x.getApplicantInfo().getName())
							? x.getApplicantInfo().getName() : null);
					
					map.put("applicationId", x.getId());
					map.put("fullName", fullName);
					map.put("urnNumber", x.getUrn());

					map.put("accountNumber", x.getAccountNumber());
					map.put("contactDetails", mobileNumber);
					map.put("schemeId", x.getSchemeId());
					
//	Need to discuss ------------------->
					map.put("lastModifyDate", x.getModifiedDate());
					map.put("status", x.getIsActive());
					
					reqlist.add(map);
				});

				return new CommonResponse("successfully get List", reqlist, ResponseStatus.SUCCESS.getStatusId(),
						Boolean.TRUE);
			}
			
			else if(!OPLUtils.isObjectListNull(applicantInfoList)) {
				
				applicantInfoList.forEach(info -> {
					
					String urnNumber = (!OPLUtils.isObjectNullOrEmpty(info.getApplicationMaster().getUrn()) ? 
							info.getApplicationMaster().getUrn() : null);
					Long applicationId = (!OPLUtils.isObjectNullOrEmpty(info.getApplicationMaster().getId()) ? 
							info.getApplicationMaster().getId() : null);
					
					Map<String, Object> infoMap = new HashMap<>();
					
					infoMap.put("applicationId", applicationId);
					infoMap.put("fullName", info.getName());
					infoMap.put("urnNumber", urnNumber);
					
					infoMap.put("accountNumber", info.getApplicationMaster().getAccountNumber());
					infoMap.put("contactDetails", info.getMobileNumber());
					infoMap.put("schemeId", info.getApplicationMaster().getSchemeId());
//	Need to discuss ------------------->
					
					infoMap.put("lastModifyDate", info.getApplicationMaster().getModifiedDate() != null ? info.getApplicationMaster().getModifiedDate() : null );
					infoMap.put("status", info.getApplicationMaster().getIsActive());
					
					reqlist.add(infoMap);					
				});	
				
				return new CommonResponse("successfully get List", reqlist, ResponseStatus.SUCCESS.getStatusId(),
						Boolean.TRUE);
			}
			else {

				return new CommonResponse("requested data not found", ResponseStatus.BAD_REQUEST.getStatusId(), false);
			}

		} else {
			return new CommonResponse("request can not be null or empty", ResponseStatus.BAD_REQUEST.getStatusId(),
					false);
		}

//		return null;
	}

//	@SuppressWarnings("unchecked")
//	@Override
//	public CommonResponse getBySearchFilterNew(String request, Long userId) {
//		try {
//			JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
//            Integer stageId = filterJSON.has("stageId") ? filterJSON.get("stageId").asInt() : null;
//            String spName = null;
//            if (!OPLUtils.isObjectNullOrEmpty(stageId)) {
//   			 spName = !OPLUtils.isObjectNullOrEmpty(stageId) 
// 					? (stageId == EnrollStageMaster.COMPLETED.getStageId() 
// 					? DBNameConstant.JNS_INSURANCE + ".sp_get_by_search_filter_list_v5"
// 							: (stageId == EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId() 
// 							? DBNameConstant.JNS_INSURANCE + ".sp_get_transaction_fail_by_search_filter_v5" 
// 									: DBNameConstant.JNS_INSURANCE + ".sp_get_by_search_filter_reject_list_v5"))
// 							: DBNameConstant.JNS_INSURANCE + ". "; 
//   			String data = reportRepository.getDataFromProducer(request, userId, spName);
//			Map<String, Object> map = null;
//			if (!OPLUtils.isObjectNullOrEmpty(data)) {
//				map = MultipleJSONObjectHelper.getObjectFromString(data, Map.class);
//			} else {
//				return new CommonResponse("No data found", null, HttpStatus.OK.value(), Boolean.TRUE);	
//			}
//			return new CommonResponse("SuccessFully get enrollment data", map, HttpStatus.OK.value(), Boolean.TRUE);
//            }else {
//            	//search For Opt-out
//            	spName = DBNameConstant.JNS_INSURANCE + ".SP_GET_BY_SEARCH_FILTER_OPT" ;
//            	String data = reportRepository.getDataFromProducer(request, userId, spName);
//    			List<Map<String, Object>> mapList = null;
//    			if (!OPLUtils.isObjectNullOrEmpty(data)) {
//    				mapList = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
//    			} else {
//    				return new CommonResponse("No data found", null, HttpStatus.OK.value(), Boolean.TRUE);	
//    			}
//    			return new CommonResponse("SuccessFully get enrollment data", mapList, HttpStatus.OK.value(), Boolean.TRUE);
//            }
//		} catch (Exception e) {
//			return new CommonResponse("Error is getting while call sp_get_by_search_filter_list_v5", HttpStatus.INTERNAL_SERVER_ERROR.value());
//		}
//	}
	
	@SuppressWarnings("unchecked")
	@Override
	public CommonResponse getBySearchFilterNew(String request, Long userId) {
		try {
			JsonNode filterJSON = MultipleJSONObjectHelper.getObjectFromString(request, JsonNode.class);
            Integer stageId = filterJSON.has("stageId") ? filterJSON.get("stageId").asInt() : null;
            Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
            Integer searchType = filterJSON.has("searchType") ? filterJSON.get("searchType").asInt() : null;
            String searchValue = filterJSON.has("searchValue") ? filterJSON.get("searchValue").asText() : null;
            String spName = null;
			if (!OPLUtils.isObjectNullOrEmpty(stageId)) {
				if (stageId == EnrollStageMaster.COMPLETED.getStageId()) {
					return setAndReturnCompletedApp(schemeId, searchValue, searchType, userId, request, spName);
				} else if (stageId == EnrollStageMaster.PREMIUM_DEDUCTION_FAILED.getStageId()) {
					spName = DBNameConstant.JNS_INSURANCE + ".sp_get_transaction_fail_by_search_filter_v5";
				} else {
					spName = DBNameConstant.JNS_INSURANCE + ".sp_get_by_search_filter_reject_list_v5";
				}
   			String data = reportRepository.getDataFromProducer(request, userId, spName);
   			List<Map<String, Object>> mapList = null;
			if (!OPLUtils.isObjectNullOrEmpty(data)) {
				mapList = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
			} else {
				return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);	
			}
			return new CommonResponse("SuccessFully get enrollment data", mapList, HttpStatus.OK.value(), Boolean.TRUE);
            }else {
            	//search For Opt-out
            	spName = DBNameConstant.JNS_INSURANCE + ".SP_GET_BY_SEARCH_FILTER_OPT" ;
            	String data = reportRepository.getDataFromProducer(request, userId, spName);
    			List<Map<String, Object>> mapList = null;
    			if (!OPLUtils.isObjectNullOrEmpty(data)) {
    				mapList = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
    			} else {
    				return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);	
    			}
    			return new CommonResponse("SuccessFully get enrollment data", mapList, HttpStatus.OK.value(), Boolean.TRUE);
            }
		} catch (Exception e) {
			log.info("fsdfsdfsdfsdfsdfsd {}", e);
			return new CommonResponse("Error is getting while call sp_get_by_search_filter_list_v5", HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
	
	@SuppressWarnings("unchecked")
	public CommonResponse setAndReturnCompletedApp(Long schemeId,String searchValue,Integer searchType,Long userId,String request,String spName) throws IOException {
		List<Long> appIdLst = new ArrayList<>();
		if (!OPLUtils.isObjectNullOrEmpty(searchType)) {
			/**FIND DATA URN WISE*/
			if (searchType == 2) {
				if(!searchValue.contains("-")) {
					return new CommonResponse("Enter valid urn", null, HttpStatus.OK.value(), Boolean.TRUE);
				}
				ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService
						.getJnsMasterDataApplicationMaster(schemeId,
								OPLUtils.getApplicationIdFromUrn(searchValue));
				if (!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
					appIdLst.add(applicationMaster.getId());
				}
			/**FIND DATA ACCOUNT NUMBER WISE*/
			} else if (searchType == 1) {
				List<ApplicantPIDetails> appPiDtl = applicantPIDetailsRepository
						.findByAccountNumber(searchValue);
				if(!OPLUtils.isListNullOrEmpty(appPiDtl)) {					
					List<Long> appIdList = appPiDtl.stream().map(x -> x.getId()).collect(Collectors.toList());
					appIdLst = appIdList;
				}
			/**FIND DATA MOBILE NUMBER WISE*/
			} else if (searchType == 3) {
				List<ApplicantInfoV2> appInfoDtl = applicantInfoRepoV2.findByMobileNumber(searchValue);
				if(!OPLUtils.isListNullOrEmpty(appInfoDtl)) {					
					List<Long> appIdList = appInfoDtl.stream().map(x -> x.getId()).collect(Collectors.toList());
					appIdLst = appIdList;
				}
			/**FIND DATA ACCOUNT HOLDER NAME WISE*/
			} else if (searchType == 4) {
				List<ApplicantPIDetails> appPiDtl = applicantPIDetailsRepository
						.findByAcHolderName(searchValue);
				if(!OPLUtils.isListNullOrEmpty(appPiDtl)) {					
					List<Long> appIdList = appPiDtl.stream().map(x -> x.getId()).collect(Collectors.toList());
					appIdLst = appIdList;
				}
			}
			
			/**FETCH USER DETAILS BY USER ID*/
			UsersRequest userDetails = usersClient.getUserDetailsByUserId(userId);
			List<Long> appIdFltrLst = new ArrayList<>();
			if(!OPLUtils.isListNullOrEmpty(appIdLst)) {
				for(Long applicationId : appIdLst) {
					ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService
							.getJnsMasterDataApplicationMaster(schemeId,applicationId);
					if(!OPLUtils.isObjectNullOrEmpty(applicationMaster)) {									
						if(Objects.equals(userDetails.getUserType(), UserTypeMaster.FUNDPROVIDER.getId())) {
							if(!Objects.equals(applicationMaster.getOrgId(), userDetails.getUserOrgId())) {
								continue;
							}
							
							if(!OPLUtils.isObjectNullOrEmpty(userDetails.getUserRoleId()) && !Objects.equals(userDetails.getUserRoleId(), UserRoleMaster.HEAD_OFFICE.getId())) {
								if(Objects.equals(userDetails.getUserRoleId(), UserRoleMaster.BRANCH_CHECKER.getId())) {
									if(!Objects.equals(applicationMaster.getBranchId(), userDetails.getBranchId())) {
										continue;
									}
								}else if(Objects.equals(userDetails.getUserRoleId(), UserRoleMaster.RO.getId())) {
									if(!Objects.equals(applicationMaster.getBranchRoId(), userDetails.getBranchId())) {
										continue;
									}
								}else if(Objects.equals(userDetails.getUserRoleId(), UserRoleMaster.ZO.getId())) {
									if(!Objects.equals(applicationMaster.getBranchZoId(), userDetails.getBranchId())) {
										continue;
									}
								}else if(Objects.equals(userDetails.getUserRoleId(), UserRoleMaster.LOCAL_HEAD_OFFICE.getId())) {
									if(!Objects.equals(applicationMaster.getBranchLhoId(), userDetails.getBranchId())) {
										continue;
									}
								}else {
									return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);
								}
							}
						}else if(Objects.equals(userDetails.getUserType(), UserTypeMaster.INSURER.getId())) {
							if(!Objects.equals(applicationMaster.getInsurerOrgId(), userDetails.getUserOrgId())) {
								continue;
							}
						}else {
							return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);
						}
						appIdFltrLst.add(applicationMaster.getId());
					}
				}
			}
			if(!OPLUtils.isListNullOrEmpty(appIdFltrLst)) {				
				Map<String, Object> map = new HashMap<>();
				map.put("applicationIdLst", appIdFltrLst.toString().replace("[", "").replace("]", ""));
				map.put("schemeId", schemeId);
				Object objectFromMap = MultipleJSONObjectHelper.getObjectFromMap(map, Object.class);
				request = MultipleJSONObjectHelper.getStringfromObject(objectFromMap);
				
				spName = DBNameConstant.JNS_INSURANCE + ".sp_get_by_search_filter_list_v5";
				String data = reportRepository.getDataFromProducer(request, userId, spName);
				List<Map<String, Object>> mapList = null;
				if (!OPLUtils.isObjectNullOrEmpty(data)) {
					mapList = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
				} else {
					return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);	
				}
				return new CommonResponse("SuccessFully get enrollment data", mapList, HttpStatus.OK.value(), Boolean.TRUE);
			}else {
				return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);
			}
		}
		return new CommonResponse("No data found", null, HttpStatus.NO_CONTENT.value(), Boolean.TRUE);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public CommonResponse getBySearchFilterNewForClaim(String request, Long userId) {
		try {
			String spName = DBNameConstant.JNS_INSURANCE + ".sp_get_by_search_filter_list_for_claim_v5";
			String data = reportRepository.getDataFromProducer(request, userId, spName);
			List<Map<String, Object>> mapList = null;
			if (!OPLUtils.isObjectNullOrEmpty(data)) {
				mapList = MultipleJSONObjectHelper.getListOfObjects(data, null, Map.class);
			}
			return new CommonResponse("SuccessFully get claim data", mapList, HttpStatus.OK.value(), Boolean.TRUE);
		} catch (Exception e) {
			return new CommonResponse("Error is getting while call sp_get_by_search_filter_list_for_claim_v5", HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}
}
