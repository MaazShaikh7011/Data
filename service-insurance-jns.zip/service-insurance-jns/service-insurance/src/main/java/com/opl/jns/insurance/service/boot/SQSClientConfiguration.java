package com.opl.jns.insurance.service.boot;
//package com.opl.service.insurance.jns.boot;
//
//import com.amazonaws.auth.AWSStaticCredentialsProvider;
//import com.amazonaws.auth.BasicAWSCredentials;
//import com.amazonaws.regions.*;
//import com.amazonaws.services.sqs.*;
//import io.awspring.cloud.messaging.config.*;
//import io.awspring.cloud.messaging.core.*;
//import io.awspring.cloud.messaging.listener.*;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.*;
//import org.springframework.messaging.converter.*;
//import org.springframework.messaging.handler.annotation.support.*;
//import org.springframework.messaging.handler.invocation.*;
//
//import java.io.*;
//import java.util.*;
//
//@Configuration
//public class SQSClientConfiguration {
//    @Value("${app.config.aws.access_key_id}")
//    private String awsAccessKeyId;
//    @Value("${app.config.aws.secret_key_id}")
//    private String awsSecretKeyId;
//
//    @Bean
//    public QueueMessagingTemplate queueMessagingTemplate() throws IOException {
//        return new QueueMessagingTemplate(amazonSQSAsync());
//    }
//    @Bean
//    @Primary
//    public AmazonSQSAsync amazonSQSAsync() throws IOException {
//        return AmazonSQSAsyncClientBuilder.standard().withRegion(Regions.AP_SOUTH_1)
//                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsAccessKeyId,awsSecretKeyId)))
//                .build();
//    }
//
//    @Bean
//    public SimpleMessageListenerContainer simpleMessageListenerContainer() throws IOException {
//        SimpleMessageListenerContainer msgListenerContainer = simpleMessageListenerContainerFactory().createSimpleMessageListenerContainer();
//        msgListenerContainer.setMessageHandler(queueMessageHandler());
//        return msgListenerContainer;
//    }
//
//    @Bean
//    public SimpleMessageListenerContainerFactory simpleMessageListenerContainerFactory() throws IOException {
//        SimpleMessageListenerContainerFactory msgListenerContainerFactory = new SimpleMessageListenerContainerFactory();
//        msgListenerContainerFactory.setAmazonSqs(amazonSQSAsync());
//        msgListenerContainerFactory.setMaxNumberOfMessages(1);
//        msgListenerContainerFactory.setAutoStartup(true);
//        msgListenerContainerFactory.setWaitTimeOut(5);
//        msgListenerContainerFactory.setVisibilityTimeout(30);
//        return msgListenerContainerFactory;
//    }
//
//    @Bean
//    public QueueMessageHandler queueMessageHandler() throws IOException {
//        QueueMessageHandlerFactory queueMsgHandlerFactory = new QueueMessageHandlerFactory();
//        queueMsgHandlerFactory.setAmazonSqs(amazonSQSAsync());
//        QueueMessageHandler queueMessageHandler = queueMsgHandlerFactory.createQueueMessageHandler();
//        List<HandlerMethodArgumentResolver> list = new ArrayList<>();
//        HandlerMethodArgumentResolver resolver = new PayloadArgumentResolver(new MappingJackson2MessageConverter());
//        list.add(resolver);
//        queueMessageHandler.setArgumentResolvers(list);
//        return queueMessageHandler;
//    }
//
//
//
//
//}