package com.opl.jns.insurance.service.schedulers;

import com.opl.jns.config.utils.*;
import com.opl.jns.insurance.service.service.*;
import com.opl.jns.insurance.service.service.impl.ClaimMasterServiceImplV3;

import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;

@Component
@Slf4j
public class ExpirationScheduler {

	@Autowired
	private ClaimMasterServiceImplV3 claimService;

	@Autowired
	private ApplicationMasterService applicationMasterService;

	/**
	 * Scheduler for expiring application at midnight 9. 0 0 21 * * * 0 1 0 * * *
	 */
	@Scheduled(cron = "${expireApplicationCron}")
	public void expireApplicationsOnMidNight() {
		log.info("START Expire Scheduler --------------------------------------> ");
		String value =EnvironmentUtils.EXPIRE_APPLICATION_SCHEDULER_ENABLE.getValue();
		if (value != null && "ON".equalsIgnoreCase(value)) {
			log.info("expiring in-progress application scheduler =====> Start at :[{}]", new Date());

			/*Expire Assisted mode incomplete applications after 12 PM */
			applicationMasterService.expireAssistedModeApplications();

			/* Expire Other channel Incomplete Applications  after 5days*/
			applicationMasterService.expireOtherChannelApplications();

			/* Expire incomplete Claims after 30 days */
			claimService.expireClaimAfter30Days();
		} else {
			log.info("EXPIRED APPLICATION SCHEDULE OFF FROM ENVIRONMENT PROPERTY");
		}
		log.info("END Expire Scheduler --------------------------------------> ");
	}


}
