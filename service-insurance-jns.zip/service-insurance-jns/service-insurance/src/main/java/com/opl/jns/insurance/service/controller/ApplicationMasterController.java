package com.opl.jns.insurance.service.controller;

import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.insurance.api.model.ApplicationMasterRequest;
import com.opl.jns.insurance.api.model.OptOutProxy;
import com.opl.jns.insurance.api.model.consentDataRequest;
import com.opl.jns.insurance.api.model.v2.ApplicationMasterRequestV2;
import com.opl.jns.insurance.service.schedulers.DeDupeRegistryScheduler;
import com.opl.jns.insurance.service.service.ApplicationMasterService;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3/application")
@Slf4j
public class ApplicationMasterController {

	@Autowired
	private ApplicationMasterService applicationMasterService;

	@Autowired
	private DeDupeRegistryScheduler deDupeRegistryScheduler;
	
	/**
	 * UPDATE ENROLLMENT AND CLAIM JOURNEY STAGE
	 * 
	 * @param appMasterReq
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/updateStage", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> updateStage(@RequestBody ApplicationMasterRequestV2 appMasterReq, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			log.info("Enter in update stage for the application -->" + appMasterReq.getApplicationId());
			appMasterReq.setModifiedBy(authClientResponse.getUserId());
			CommonResponse response = applicationMasterService.updateStage(appMasterReq, authClientResponse);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while update stage ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * FETCH CURRENT APPLICATION MASTER DETAILS
	 * @param applicationId
	 * @return
	 */
	@GetMapping(value = "/getStageDetails/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getStageDetails(@PathVariable Long applicationId) {
		try {
			log.info("Enter in get stage for the application -->" + applicationId);
			return new ResponseEntity<>(applicationMasterService.getStageDetails(applicationId), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get stage details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * First Screen Where user add Account Number and dob
	 * 
	 * Bank Account Details
	 * 
	 *  1. First call with Account Number and dob
	 */

	/**
	 * CREATE APPLICATION WHILE ENROLLMENT JOURNEY
	 * 
	 * @param req
	 * @param authClientResponse
	 * @return
	 */
	@PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> create(@RequestBody ApplicationMasterRequest req, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			return new ResponseEntity<CommonResponse>(applicationMasterService.create(req, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in creating the application : ", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	/*
	 * @SkipInterceptor
	 * 
	 * @PostMapping(value = "/bulkInsert", produces = MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<CommonResponse> create(@RequestBody String req) { try {
	 * applicationMasterService.UploadStaticData(req); return new
	 * ResponseEntity<CommonResponse>(HttpStatus.OK); } catch (Exception e) {
	 * log.error("Exception in creating the application : ", e); return new
	 * ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK); } }
	 */

	@PostMapping(value = "/getAccountHolderListOptOut", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getAccountHolderListOptOut(@RequestBody ApplicationMasterRequest applicationMasterRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			//			authClientResponse.setUserOrgId(13L);
			if (OPLUtils.isObjectNullOrEmpty(applicationMasterRequest.getAccountNo())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("please enter account no or urn code", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<CommonResponse>(applicationMasterService.getOptOutAccountHolderList(applicationMasterRequest, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getAccountHolderListOptOut : ", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getAccountHolderDetailsOptOut", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getAccountHolderDetailsOptOut(@RequestBody ApplicationMasterRequest applicationMasterRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			//			authClientResponse.setUserOrgId(13L);
			if (OPLUtils.isObjectNullOrEmpty(applicationMasterRequest.getAccountNo()) || OPLUtils.isObjectNullOrEmpty(applicationMasterRequest.getCif())) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("please enter account no and cif number", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<CommonResponse>(applicationMasterService.getAccountHolderDetailsOptOut(applicationMasterRequest, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in getAccountHolderDetailsOptOut : ", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/saveOptOut", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveOptOut(@RequestBody OptOutProxy optOutProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		try {
			//			authClientResponse.setUserOrgId(13L);
			if (OPLUtils.isObjectNullOrEmpty(optOutProxy)) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("please enter account no and cif number", HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<CommonResponse>(applicationMasterService.saveOptOut(optOutProxy, authClientResponse), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in saveOptOut : ", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	@GetMapping(value = "/sendCoi/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> sendCoi(@PathVariable Long applicationId) {
		try {
			log.info("Enter in get stage for the application -->" + applicationId);
			applicationMasterService.sendCoiToApplicant(applicationId,null);
			return new ResponseEntity<>(null, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get stage details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/*@GetMapping(value = "/rePushPythonApiApp/{page}/{count}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> rePushPythonApiApp(@PathVariable("page") Integer page, @PathVariable("count") Integer count) {
		try {
			//deDupeRegistryScheduler.update(page, count);
			return new ResponseEntity<>(null, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while rePushPythonApiApp details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}*/

	/**
	 * RE_PUSH APPLICATION WHICH HAS ERROR IN PUSHING EARLIER
	 * @return
	 */
//	@GetMapping(value = "/pushApp/{page}/{count}", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<CommonResponse> pushApp(@PathVariable("page") Integer page, @PathVariable("count") Integer count) {
//		try {
//			log.info("Enter in push app -->");
//			applicationMasterService.pushApplicationHasError(page, count);
//			return new ResponseEntity<>(HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while get stage details ------>", e);
//			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
//		}
//	}

	/**
	 * PUSH APPLICATION WHICH HAS ERROR IN PUSHING EARLIER
	 * @return
	 */
	@GetMapping(value = "/expireAssistedModeApplication", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> expireAssistedModeApplication() {
		try {
			log.info("Enter in push app -->");
			applicationMasterService.expireAssistedModeApplications();
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			log.error("", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * PUSH APPLICATION WHICH HAS ERROR IN PUSHING EARLIER
	 * @return
	 */
	@GetMapping(value = "/expireOtherChannelApplication", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> expireOtherChannelApplication() {
		try {
			log.info("Enter in push app -->");
			applicationMasterService.expireOtherChannelApplications();
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get stage details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET REGISTER PAGE CONSENT PAGE HTML
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/getConsentList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getConsentList(@RequestBody consentDataRequest consentDataRequest) {
		try {
			log.info("Enter in getConsentList -->");
			return new ResponseEntity<>(applicationMasterService.getConsentList(consentDataRequest.getConsentType()),HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while get stage details ------>", e);
			return new ResponseEntity<CommonResponse>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**FOR TESTING PURPOSE*/
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/ping/{orgId}/{source}")
	public JSONObject ping(@PathVariable("orgId") Long orgId,@PathVariable("source") Long source) {
		log.info("CHECK SERVICE STATUS =====================>");
		JSONObject obj = new JSONObject();
		obj.put("status", 200);
		obj.put("message", "Service is working fine!!");
		obj.put("isBankCall", OPLUtils.isBankCall(orgId, source));
		return obj;
	}

}
