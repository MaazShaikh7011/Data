package com.opl.jns.insurance.service.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;
import com.opl.jns.webhook.client.WebHookClient;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableConfigurationProperties(ApplicationProperties.class)
@EnableScheduling
@EnableAsync
public class ServiceInsuranceApplication {

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private ConfigProperties configService;


    @Bean
    CommandLineRunner run() {
        return args -> {
            configService.setAllValue();
        };
    }

    public static void main(String[] args) {
        SpringApplication.run(ServiceInsuranceApplication.class, args);
    }

    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

//    @Bean
//    public AnsLogsClient clientLogs() {
//        AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
//        applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//        return ansLogsClient;
//    }

    @Bean
    public BankApiClient bankClient() {
        BankApiClient bankClient = new BankApiClient(URLConfig.fetchURL(URLMaster.BANK_API));
//        BankApiClient bankClient = new BankApiClient("http://localhost:8053/bankapi");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(bankClient);
        return bankClient;
    }
    
    @Bean
    public UsersClient usersClient() {
        UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
        return usersClient;
    }

    @Bean
    public OneFormClient oneFormClient() {
        OneFormClient oneFormClient = new OneFormClient(URLConfig.fetchURL(URLMaster.ONE_FORM));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(oneFormClient);
        return oneFormClient;
    }

    @Bean
    public DMSClient dMSClient() {
        DMSClient dmsClient = new DMSClient(URLConfig.fetchURL(URLMaster.DMS));
//    	DMSClient dmsClient = new DMSClient("http://localhost:8052/dms");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(dmsClient);
        return dmsClient;
    }
    @Bean
    public UserManagementClient userManagementClient() {
        UserManagementClient userManagementClient = new UserManagementClient(URLConfig.fetchURL(URLMaster.USER_MANAGEMENT));
//        UserManagementClient userManagementClient = new UserManagementClient("http://localhost:8061/user-management");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(userManagementClient);
        return userManagementClient;
    }
    @Bean
    public NotificationClient notificationClient() {
    	NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
//        UserManagementClient userManagementClient = new UserManagementClient("http://localhost:8061/user-management");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
        return notificationClient;
    }

    @Bean
    public PDFGenerateClient pdfGenerateClient() {
    	PDFGenerateClient pdfGenerateClient = new PDFGenerateClient(URLConfig.fetchURL(URLMaster.PDF_GENARATE));
//        PDFGenerateClient pdfGenerateClient = new PDFGenerateClient("http://localhost:8073/pdf/generate");
    	applicationContext.getAutowireCapableBeanFactory().autowireBean(pdfGenerateClient);
    	return pdfGenerateClient;
    }
    
    @Bean
    public DedupeRegistryClient dedupeRegistryClient() {
    	DedupeRegistryClient dedupeRegistryClient = new DedupeRegistryClient(URLConfig.fetchURL(URLMaster.DD_REGISTRY));
//        PDFGenerateClient pdfGenerateClient = new PDFGenerateClient("http://localhost:8073/pdf/generate");
    	applicationContext.getAutowireCapableBeanFactory().autowireBean(dedupeRegistryClient);
    	return dedupeRegistryClient;
    }
    
    @Bean
    public WebHookClient webHookClient() {
    	WebHookClient webHookClient = new WebHookClient("http://localhost:8068/wb/jns");
//    	WebHookClient webHookClient = new WebHookClient(URLConfig.fetchURL(URLMaster.WEBHOOK));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(webHookClient);
        return webHookClient;
    }
}

