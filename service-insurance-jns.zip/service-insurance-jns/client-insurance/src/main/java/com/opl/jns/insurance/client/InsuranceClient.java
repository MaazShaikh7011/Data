package com.opl.jns.insurance.client;

public class InsuranceClient {

}
