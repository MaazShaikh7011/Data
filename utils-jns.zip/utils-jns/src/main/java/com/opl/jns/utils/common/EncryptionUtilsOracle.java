package com.opl.jns.utils.common;

import java.nio.charset.StandardCharsets;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Convert;
import jakarta.persistence.Converter;
import jakarta.persistence.EntityManager;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


@Convert
public class EncryptionUtilsOracle  implements AttributeConverter<String, String>{
	private static final String ALGORITHM = "AES";
	private static final String CHAR_ENCODING = "UTF-8";
	private static final String KEY = "C@p!ta@W0rld#AES";
	
	private static final Logger logger = LoggerFactory.getLogger(EncryptionUtils.class);

//	@Autowired
//	private EntityManager entityManager;
	
//	public EncryptionUtils(EntityManager entityManager) {
//		this.entityManager = entityManager;
//	}
	
	// DO NOT TOUCH THIS CONSTRUCTOR. OTHERWISE IT WILL CRASH THE APPLICATION
//	public EncryptionUtils() {
//		
//	}
	
	public String convertToDatabaseColumn(String plainText) {
		// do some encryption
//		try {
//			logger.info("is Entity Manage Null from Utils? ................. {}" ,entityManager == null);
//			String result = (String)entityManager.createNativeQuery("select ̥.F_ENCRYPT(:plainText) FROM dual")
//			.setParameter("plainText", plainText).getSingleResult();
//			logger.info("Decrypted? ................. {}" ,result);
//			return result;
//		} catch (Exception e) {
//			logger.error("error while encrypting data " ,e);
//			logger.error("error while encrypting data " + plainText);
//		}
		try {
			//return new String(Hex.decodeHex(encryptedText.toCharArray()));
			//return plainText == null ? null : new String(Hex.encodeHex(plainText.getBytes(StandardCharsets.UTF_8), false));
			return plainText;
		} catch (Exception e) {
			logger.info("Exception while encrypt data :: Error is :: [{}]", e.getMessage());
		}
		return null;
		//return new String(Hex.encodeHex(plainText.getBytes(StandardCharsets.UTF_8), false));
	}

	public String convertToEntityAttribute(String encryptedText) {
		// do some decryption
//		try {
//			logger.info("is Entity Manage Null from Utils? .................{}" ,entityManager == null);
//			String result = (String)entityManager.createNativeQuery("select b4l_config.F_DECRYPT(:encryptedText) FROM dual").setParameter("encryptedText", encryptedText).getSingleResult();
//			logger.info("Encrypted? ................. {}" ,result);
//			return result;			
//		} catch (Exception e) {
//			logger.error("error while decrypting data " ,e);
//			logger.error("error while decrypting data " + encryptedText);
//		}
		try {
			//return new String(Hex.decodeHex(encryptedText.toCharArray()));
			//return encryptedText == null ? null : new String(Hex.decodeHex(encryptedText.toCharArray()));
			return encryptedText;
		} catch (Exception e) {
			logger.info("Exception while decrypt data :: Error is :: [{}]", e.getMessage());
		}
		return null;
	}
}
