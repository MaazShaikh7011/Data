package com.opl.jns.utils.enums;

public enum ApplicationStatus {

	ENROLL_IN_PROGRESS(1, "Created (Enrollment in Progress)"),
	ENROLL_COMPLETED(2, "Enrolled (Enrollment Completed)"),
	ENROLL_EXPIRED(3, "Expired (Enrollment Expired)"),
	PARTIALLY_CLAIMED(4, "Partially Claimed (In case of disability)"),
	// ENROLL_EXPIRED(4, "Enroll Expired"),
	CLAIMED(5, "Claimed"),
	OPT_OUT(6, "Opt-Out"),
	ACCOUNT_INACTIVE(7, "Account Inactive"),
	INSUFFICIENT_BALANCE(8, "Insufficient Balance"),
	ACCOUNT_HOLDER_DECEASED(9, "Account Holder Deceased"),
	RENEWED(10, "Renewed"),
	DE_DUPE_FAILED(11, "De-dupe Failed"),
	ENROLL_REJECTED(12, "Rejected"),
	OPT_OUT_IN_PROCESS(13, "In Process Opt-Out ");

	private Integer id;
	private String value;

	private ApplicationStatus(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ApplicationStatus fromId(Integer v) {
		for (ApplicationStatus c : ApplicationStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ApplicationStatus[] getAll() {
		return ApplicationStatus.values();
	}

}
