package com.opl.jns.utils.enums;

public enum TransactionTypeEnum {

	ENROLLMENT(1,  "Enrollment", "E", "ENROLL"),
	RENEWAL(2, "Renewal", "R", "RENEWAL"),
	CLAIM(3, "Claim", "C", "CLAIM");

	private final Integer id;
	private final String name;
	private final String shortName;
	private final String type;

	private TransactionTypeEnum(Integer id, String name, String shortName, String type) {
		this.id = id;		
		this.name = name;
		this.shortName = shortName;
		this.type = type;
		
	}

	public Integer getId() {
		return id;
	}


	public String getName() {
		return name;
	}

	public String getShortName() {
		return shortName;
	}

	public String getType() {
		return type;
	}

	public static TransactionTypeEnum getById(Long v) {
		for (TransactionTypeEnum c : TransactionTypeEnum.values()) {
			if (c.id.equals(v.intValue())) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static TransactionTypeEnum getByCode(String v) {
		for (TransactionTypeEnum c : TransactionTypeEnum.values()) {
			if (c.shortName.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static TransactionTypeEnum getByType(String v) {
		for (TransactionTypeEnum c : TransactionTypeEnum.values()) {
			if (c.type.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SchemeMaster[] getAll() {
		return SchemeMaster.values();
	}

}
