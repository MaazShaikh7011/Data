package com.opl.jns.utils.enums;

public enum ClaimStatus {

	CLAIM_IN_PROGRESS(5, "Claim In Progress", ""),
	CLAIM_SEND_TO_INSURER(6, "Claim Send to Insurer", ""),
	CLAIM_SEND_BACK_BY_INSURER(7, "Claim Send back by insurer", "Queried"),
	CLAIM_REJECTED(8, "Claim Rejected", "Rejected"),
	CLAIM_HOLD(9, "Claim Hold", ""),
	CLAIM_ACCEPTED(10, "Claim Accpeted", "Approved"),
	CLAIM_INSURER_IN_PROGRESS(11, "Claim Insurer In Progress", "In process"),
	CLAIM_EXPIRE(12, "Expire", "");

	private Integer id;
	private String value;
	private String shortValue;

	private ClaimStatus(Integer id, String value, String shortValue) {
		this.id = id;
		this.value = value;
		this.shortValue = shortValue;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getShortValue() {
		return shortValue;
	}

	public static ClaimStatus fromId(Integer v) {
		for (ClaimStatus c : ClaimStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ClaimStatus[] getAll() {
		return ClaimStatus.values();
	}

}
