package com.opl.jns.utils.constant;

public class DBNameConstant {

	public static final String JNS_USERS = "JNS_USERS";
	public static final String JNS_ONEFORM = "jns_oneform";
	public static final String JNS_OTP = "JNS_OTP";

	public static final String JNS_INSURANCE = "JNS_INSURANCE";
	public static final String JNS_REPORTS = "jns_reports";
	public static final String JNS_BANK_API = "JNS_BANK_API";

	public static final String JNS_PUBLISH_API = "jns_publish_api";
	public static final String JNS_CONFIG = "JNS_CONFIG";
	public static final String JNS_DMS = "JNS_DMS";
	public static final String JNS_REGISTRY_API = "JNS_REGISTRY_API";
	public static final String JNS_DD_REGISTRY = "USR_DD_REGISTRY";
	public static final String JNS_ADMIN_PANEL = "JNS_ADMIN_PANEL";
	public static final String JNS_NOTIFICATION = "JNS_NOTIFICATION";
	
	public static final String JNS_PDF_GENERATE = "JNS_PDF_GENERATE";

	public static final String JNS_MASTER_DATA = "JNS_MASTER";
	
	public static final String JNS_WEBHOOK_API = "JNS_WEBHOOK_API";
	
	public static final String JNS_PUSH_SCHEDULER = "JNS_PUSH_SCHEDULER";
	public static final String JNS_CRM = "JNS_CRM";

}
