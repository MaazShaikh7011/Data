package com.opl.jns.utils.common;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import jakarta.persistence.AttributeConverter;
import jakarta.xml.bind.DatatypeConverter;

public class desOracle implements AttributeConverter<String, String>{

//    Cipher ecipher;
//    Cipher dcipher;
    private static final String ENCRYPTION_KEY = "0123456789abcdef0123456789abcdef0123456789abcdef01234567";



    public String encrypt(String str) throws Exception {
    	
    	 byte[] keyBytes = DatatypeConverter.parseHexBinary(ENCRYPTION_KEY);

         SecretKeyFactory factory = SecretKeyFactory.getInstance("DES");
         SecretKey key = factory.generateSecret(new DESKeySpec(keyBytes));
         
        Cipher ecipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
         ecipher.init(Cipher.ENCRYPT_MODE, key);
    	
        // Encode the string into bytes using utf-8
        byte[] utf8 = str.getBytes("UTF8");

        // Encrypt
        byte[] enc = ecipher.doFinal(utf8);

        // Encode bytes to base64 to get a string

        return Base64.getEncoder().encodeToString(enc);

    }

    public String decrypt(String str) throws Exception {
    	byte[] keyBytes = DatatypeConverter.parseHexBinary(ENCRYPTION_KEY);

        SecretKeyFactory factory = SecretKeyFactory.getInstance("DES");
        SecretKey key = factory.generateSecret(new DESKeySpec(keyBytes));
    	
        Cipher dcipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
    	  dcipher.init(Cipher.DECRYPT_MODE, key);
        // Decode base64 to get bytes
        byte[] dec = Base64.getDecoder().decode(str);

        byte[] utf8 = dcipher.doFinal(dec);

        // Decode using utf-8
        return new String(utf8, "UTF8");
    }

//    public static void main(String[] argv) throws Exception {
//        final String secretText = "sagarhrlovdvd sdskvb";
//        System.out.println("SecretText: " + secretText);
// 
//        
////        String desKey = "0123456789abcdef0123456789abcdef0123456789abcdef"; // user value (24 bytes)  
////        byte[] keyBytes = DatatypeConverter.parseHexBinary(ENCRYPTION_KEY);
////
////        SecretKeyFactory factory = SecretKeyFactory.getInstance("DES");
////        SecretKey key = factory.generateSecret(new DESKeySpec(keyBytes));
////        
//////        SecretKey key = KeyGenerator.getInstance("DES").generateKey();
//////        SecretKey key = new SecretKeySpec(ENCRYPTION_KEY.getBytes(), "DES");
////        System.out.println(key);
////        DES encrypter = new DES(key);
//        String encrypted = ;
//        System.out.println("Encrypted Value: " + encrypted);
//        System.out.println("Decrypted: " + decrypt(encrypted));
//        String decrypted = decrypt(encrypted);
//        System.out.println("Decrypted: "+ decrypted);
////        String decrypted1= decrypt("vDpwxu++AQOw+jL4Dk18jtiepRZQ+qM0");
////        String decrypted1= decrypt("ospmcjw2RewmeTjKiwd/ng==");
////        System.out.println("Decrypted: " + decrypted1);
//
//    }

	@Override
	public String convertToDatabaseColumn(String attribute) {
		// TODO Auto-generated method stub
		try {
			return encrypt(attribute);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		// TODO Auto-generated method stub
		try {
			return  decrypt(dbData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}