package com.opl.jns.utils.enums;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */
public enum MiscellaneousType {

    OPT_OUT(1, "Opt Out", 6),
    NOMINEE_UPDATE(2, "Nominee Update", 0),
    ACCOUNT_INACTIVE(3, "Account Inactive", 7),
    INSUFFICIENT_BALANCE(4, "Insufficient Balance", 8),
    ACCOUNT_HOLDER_DECEASED(5, "Account Holder Deceased", 9);

    private Integer id;
    private String value;
    private Integer applicationStatus;

    private MiscellaneousType(Integer id, String value, Integer applicationStatus) {
        this.id = id;
        this.value = value;
        this.applicationStatus = applicationStatus;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public Integer getApplicationStatus() {
        return applicationStatus;
    }

    public static MiscellaneousType fromId(Integer v) {
        for (MiscellaneousType c : MiscellaneousType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static MiscellaneousType fromApplicationStatus(Integer v) {
        for (MiscellaneousType c : MiscellaneousType.values()) {
            if (c.applicationStatus.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static MiscellaneousType[] getAll() {
        return MiscellaneousType.values();
    }
}
