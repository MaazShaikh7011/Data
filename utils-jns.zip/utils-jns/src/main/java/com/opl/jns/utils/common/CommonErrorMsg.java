package com.opl.jns.utils.common;

public class CommonErrorMsg {

	public interface Common {
		public static final String SUCCESS = "Success";
		public static final String SUCCESS_FETCHED_DATA = "Successfully fetched data";
		public static final String FAILED = "Failed";
		public static final String INVALID_REQUEST = "Invalid Request !";
		public static final String APPLICATION_NOT_FOUND = "Application not found!!!";
		public static String TECHNICAL_ERROR = "The application seems to have a problem while processing your request, please try again later";
		public static String MANDATORY_DETAILS_MISSING = "Its seems mandatory details not found in request parameter, please try after sometime";
	}

	public interface Enrollment {
		public static final String SUCCESS = "Successfully update Details";
		public static final String UNABLE_TO_GET_OTP = "Unable to send OTP to Registered mobile No. due to error from bank";
		public static final String INVALID_APPLICATION_ID = "Its seems we have found invalid application. Please referesh the page and try again";
		public static final String INVALID_TYPE_OF_VERIFICATION = "Its seems we have found invalid type of verification, please try after some time";
		public static final String APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER = "Customer is already enrolled with Scheme";
		public static final String UNABLE_TO_FETCH_HOLDER_DTL = "Unable to fetch account holder details due to error from bank";
		public static final String UNABLE_TO_FETCH_POLICY_DTL = "Unable to fetch policy details due to error from bank";
		public static final String UNABLE_TO_OPT_OUT_UPDATE_STATUS = "Unable opt out status update due to error from bank";
		public static final String UNABLE_TO_NOMINEE_UPDATE_STATUS = "Unable nominee status update due to error from bank";
		public static final String UNABLE_TO_GET_COI_DETAILS = "Unable get coi details due to error from bank";
	}

	public interface Claim {

	}

}
