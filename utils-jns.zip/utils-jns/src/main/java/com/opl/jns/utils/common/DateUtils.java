package com.opl.jns.utils.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtils {

	private static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

	public interface DateFormat {
		public static final String DD_MMMM_YYYY_HH_MM_AAA = "dd MMMM yyyy hh:mm aaa"; // 02 May 2020 11:00 AM
		public static final String DD_MM_YYYY = "dd/MM/yyyy"; // 25/08/2020
		public static final String DD_MMM_YYYY = "dd-MMM-yyyy"; // 29-Sep-1988
		public static final String YYYY_MM_DD = "yyyy-MM-dd"; // 1988-09-29
		public static final String YYYY = "yyyy"; // 1988
		public static final String YY = "yy"; // 88
		public static final String DD_M_YYYY_HH_MM_SS = "dd-M-yyyy hh:mm:ss"; // 02-1-2018 06:07:59
		public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss"; // 1988-09-29 06:07:59
		public static final String 	YYYY_MM_DD_T_HH_MM_SS_SSSSX ="yyyy-MM-dd'T'HH:mm:ss.SSSSX";	// 2022-07-12T00:00:00.000+00:00
		public static final String 	YYYY_MM_DD_T_HH_MM_SS_Z = "yyyy-MM-dd'T'HH:mm:ss'Z'";	// 2022-07-12T00:00:00.000+00:00
		
	}

	public static String setDateFormat(String dateFormat, Date date) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(dateFormat)) {
				dateFormat = DateFormat.DD_MMMM_YYYY_HH_MM_AAA;
			}
			return new SimpleDateFormat(dateFormat).format(date);
		} catch (Exception e) {
			logger.error("Exception while set date format " + e.getMessage());
			return null;
		}
	}
	
	public static Date parse(String date, String dateFormat) {
		try {
			return new SimpleDateFormat(dateFormat).parse(date);
		} catch (Exception e) {
			logger.info("Input date -->" + date + "-----Dateformat----->" + dateFormat);
			logger.error("Exception while parse date -->" + e.getMessage());
		}
		return null;
	}

	public static Integer monthDiff(Date fromDate, Date toDate) {
		Calendar c = Calendar.getInstance();
		c.setTime(fromDate);

		Calendar c2 = Calendar.getInstance();
		c2.setTime(toDate);

		Period between = Period.between(LocalDate.of(c.get(Calendar.YEAR), c.get(Calendar.MONTH), 1),
				LocalDate.of(c2.get(Calendar.YEAR), c2.get(Calendar.MONTH), 1));
		return between.getMonths();
	}

	public static long dateDiff(Date from, Date to) {
		long diffMiliSec = from.getTime() - to.getTime();
		return TimeUnit.DAYS.convert(diffMiliSec, TimeUnit.MILLISECONDS);
	}

	public static Integer getAgeFromBirthDate(Date date) {
		if (date != null) {
			Integer years = 0;
			Calendar birthDay = Calendar.getInstance();
			birthDay.setTime(date);
			Calendar today = Calendar.getInstance();
			today.setTime(new Date());

			Integer yearsInBetween = today.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
			Integer monthsDiff = 1;
			// monthsDiff = monthsDiff + today.get(Calendar.MONTH) - 12;
			monthsDiff = monthsDiff + today.get(Calendar.MONTH) - birthDay.get(Calendar.MONTH);
			Integer ageInMonths = yearsInBetween * 12 + monthsDiff;
			years = ageInMonths / 12;
			return years;
		} else {
			return null;
		}
	}

	public static Date getUtilsDateFromStringDate(String date) {
		try {
			return (new SimpleDateFormat(DateFormat.YYYY_MM_DD_T_HH_MM_SS_SSSSX)).parse(date);
		} catch (Exception e) {
			logger.error("Exception while set date format {} ", e.getMessage());
			return null;
		}
	}

	/**
	 *
	 * @param :- "2023-06-05"
	 * @return :- 2023-06-05T00:00:00Z
	 */
	public static String getISOFormatDate(String date) throws ParseException {
		return new SimpleDateFormat(DateFormat.YYYY_MM_DD_T_HH_MM_SS_Z).format(new SimpleDateFormat("yyyy-MM-dd").parse(date));
	}

	/**
	 *
	 * @param "new Date()"
	 * @return date With set 00:00:00
	 */
	public static Date setMidNightDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		return calendar.getTime();
//		calendar.set(Calendar.MILLISECOND, 0);
//		calendar.set(Calendar.HOUR, 0);
	}
}
