package com.opl.jns.utils.common;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.icu.text.NumberFormat;

public class ObjectConvertMaster {

	private static final Logger logger = LoggerFactory.getLogger(ObjectConvertMaster.class);
	
	public static <T extends Object> T convert(Object obj, Class<T> type) {
		return type.cast(obj);
	}

	public static Long toLong(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				if (obj instanceof BigInteger value) {
					return value.longValue();
				} else if (obj instanceof Integer) {
					Integer value = toInteger(obj);
					if(value != null) {
						return value.longValue();
					}
				} else {
					return (Long) obj;
				}
			}
		} catch (Exception e) {
			logger.error("Exception While toLong :- " + obj + ",  Message :- " + e.getMessage());
		}
		return null;
	}

	public static String toString(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				if (obj instanceof String value) {
					return value;
				} else {
					return String.valueOf(obj);
				}
			}
		} catch (Exception e) {
			logger.error("Exception while toString :- " + obj + " Message :- " + e.getMessage());
		}
		return null;
	}

	public static Boolean toBoolean(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				return (Boolean) obj;
			}
		} catch (Exception e) {
			logger.error("Exception while toBoolean :- " + obj + " Message :- " + e.getMessage());
		}
		return Boolean.FALSE;
	}

	public static Integer toInteger(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				if (obj instanceof BigInteger value) {
					return value.intValue();
				} else {
					return (Integer) obj;
				}
			}
		} catch (Exception e) {
			logger.error("Exception while toInteger :- " + obj + " Message :- " + e.getMessage());
		}
		return null;
	}

	public static Date toDate(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				if (obj instanceof Long long1) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTimeInMillis(long1);
					return calendar.getTime();
				}
				return (Date) obj;
			}
		} catch (Exception e) {
			logger.error("Exception while toDate :- " + obj + " Message :- " + e.getMessage());
		}
		return null;
	}

	public static Double toDouble(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				if (obj instanceof BigDecimal value) {
					return value.doubleValue();
				} else {
					return (Double) obj;
				}
			}
		} catch (Exception e) {
			logger.error("Exception while toDouble :- " + obj + " Message :- " + e.getMessage());
		}
		return null;
	}

	public static String toJson(Object obj) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(obj)) {
				ObjectMapper Obj = new ObjectMapper();
				String jsonStr = Obj.writeValueAsString(obj);
				return jsonStr;
			}
		} catch (IOException e) {
			logger.error("Exception while toJson Message :- " + e.getMessage());
		}
		return null;
	}

	public static Object toIndianCurrencyWithDecimal(Object value) {
		if (value != null) {
			NumberFormat formatter = NumberFormat.getNumberInstance(Locale.of("en", "IN"));
			formatter.setMinimumFractionDigits(2);
			return formatter.format(value);
		} else {
			return "-";
		}
	}

}
