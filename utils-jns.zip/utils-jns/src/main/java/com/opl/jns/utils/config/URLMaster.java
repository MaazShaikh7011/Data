package com.opl.jns.utils.config;

public enum URLMaster {
	
	DMS(1, 8052, "/dms"),
	ONE_FORM(2, 8053, "/oneform"),
	AUTH(3, 8054, "/auth"),
	LOGS(4, 8055, "/logs"),
	NOTIFICATION (1, 8056, "/notification"),
	OTP (5, 8057, "/otp"),
	BANK_API(6, 8058, "/bankapi"),
	USERS(7, 8059, "/users"),
	INSURANCE(8, 8060, "/insurance"),
	USER_MANAGEMENT (9, 8061, "/user-management"),
	ADMIN_PANEL(10, 8064, "/admin-panel"),
	WEBHOOK(11, 8068, "/wb/jns"),
	PDF_GENARATE(12, 8073, "/pdf/generate"),
	REGISTRY(12, 8065, "/api/registry"),
	PUBLISH_INSURANCE(13, 8050, "/api/jns"),
	DD_REGISTRY(13, 8070, "/dd/registry/jns");

	

	private Integer id;
	private Integer port;
	private String contextPath;

	private URLMaster(Integer id, Integer port, String contextPath) {
		this.id = id;
		this.port = port;
		this.contextPath = contextPath;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getContextPath() {
		return contextPath;
	}

	public void setContextPath(String contextPath) {
		this.contextPath = contextPath;
	}

}
