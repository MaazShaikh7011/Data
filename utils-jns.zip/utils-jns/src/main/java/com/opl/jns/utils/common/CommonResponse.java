package com.opl.jns.utils.common;

import java.io.Serializable;

/**
 * USE FOR COMMON REPONSE IN ALL REPOSITORY
 * 
 * @author harshit
 *
 */
public class CommonResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private static CommonResponse commonResponse = null;

	private Long id;

	private String message;

	private Object data;

	private Integer status;

	private Boolean flag;

	public CommonResponse() {
		super();
	}

	public static CommonResponse TECHNICAL_ERROR() {
		if (commonResponse == null) {
			commonResponse = new CommonResponse(CommonErrorMsg.Common.TECHNICAL_ERROR, 500, false);
		}
		return commonResponse;
	}

	public CommonResponse(String message, Integer status) {
		super();
		this.message = message;
		this.status = status;
	}

	public CommonResponse(Object data, String message, Integer status) {
		this(message, status);
		this.data = data;
	}

	public CommonResponse(String message, Object data, Integer status, Boolean flag) {
		this(data, message, status);
		this.flag = flag;
	}

	public CommonResponse(String message, Integer status, Boolean flag) {
		this(message, status);
		this.flag = flag;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
