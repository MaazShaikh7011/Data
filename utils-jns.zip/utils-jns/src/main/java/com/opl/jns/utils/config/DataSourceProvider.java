package com.opl.jns.utils.config;

import com.opl.jns.utils.common.EncryptionUtils;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ENVMode;

public class DataSourceProvider {

//	private static String databaseName = null;
//	private static String userName = null;
//	private static String password = null;
//
//	private static String databaseNameMongo = null;
//	private static String databaseHostMongo = null;
//	private static int databasePortMongo = 0;
//	private static String userNameMongo = null;
//	private static String passwordMongo = null;
//
//	private static String databaseNamePushPull = null;
//	private static String userNamePushPull = null;
//	private static String passwordPushPull = null;
//	private static final String URL_KEY = "JNS_DB_URL";
//	private static final String MONGO_DB_NAME = "JNS_MONGO_DB_NAME";
//	private static final String MONGO_AUTHENTICATION_DB = "admin";
//	private static final String MONGO_DB_HOST = "JNS_MONGO_DB_HOST";
//	private static final String MONGO_DB_PORT = "JNS_MONGO_DB_PORT";
//	private static final String MONGO_USER_NAME_KEY = "JNS_MONGO_DB_USER_NAME";
//	private static final String MONGO_PASS_KEY = "JNS_MONGO_DB_USER_PASS";
//	private static final String USER_NAME_KEY = "JNS_DB_USER_NAME";
//	private static final String PASS_KEY = "JNS_DB_USER_PASS";
//	private static final String URL_KEY_PUSH_PULL = "JNS_DB_URL_PUSH_PULL";
//	private static final String USER_NAME_KEY_PUSH_PULL = "JNS_DB_USER_NAME_PUSH_PULL";
//	private static final String PASS_KEY_PUSH_PULL = "JNS_DB_USER_PASS_PUSH_PULL";

	private static String dbUrlOracle = null;
	private static ENVMode envMode = null;
	private static String ansAppServerDomain = null;

	private static final String ORACLE_URL_KEY = "JNS_ORACLE_URL";
	private static final String ORACLE_ENV_MODE = "JNS_ORACLE_ENV_MODE";

	private static String databaseName = null;
	private static String userName = null;
	private static String password = null;
	private static final String DB_URL = "NABARD_DB_URL";
	private static final String DB_USERNAME = "NABARD_DB_USERNAME";
	private static final String DB_PASSWORD = "NABARD_DB_PASSWORD";
	private static final String JNS_APP_SERVER_DOMAIN = "JNS_APP_SERVER_DOMAIN";

	private static String decryptKey(String key) {
		String value = System.getenv(key);
		EncryptionUtils cryptoConverter = new EncryptionUtils();
		return cryptoConverter.convertToEntityAttribute(value);
	}

//	public static String getDatabaseName() {
//		if (null == databaseName) {
//			databaseName = decryptKey(URL_KEY);
//			return databaseName;
//		} else {
//			return databaseName;
//		}
//	}
//
//	public static String getUserName() {
//		if (null == userName) {
//			userName = decryptKey(USER_NAME_KEY);
//			return userName;
//		} else {
//			return userName;
//		}
//	}
//
//	public static String getPassword() {
//		if (null == password) {
//			password = decryptKey(PASS_KEY);
//			return password;
//		} else {
//			return password;
//		}
//	}
//
//	public static String getDatabaseNamePushPull() {
//		if (null == databaseNamePushPull) {
//			databaseNamePushPull = decryptKey(URL_KEY_PUSH_PULL);
//			return databaseNamePushPull;
//		} else {
//			return databaseNamePushPull;
//		}
//	}
//
//	public static String getUserNamePushPull() {
//		if (null == userNamePushPull) {
//			userNamePushPull = decryptKey(USER_NAME_KEY_PUSH_PULL);
//			return userNamePushPull;
//		} else {
//			return userNamePushPull;
//		}
//	}
//
//	public static String getPasswordPushPull() {
//		if (null == passwordPushPull) {
//			passwordPushPull = decryptKey(PASS_KEY_PUSH_PULL);
//			return passwordPushPull;
//		} else {
//			return passwordPushPull;
//		}
//	}

//	public static String getMongoDatabaseName() {
//		if (null == databaseNameMongo) {
//			databaseNameMongo = decryptKey(MONGO_DB_NAME);
//		}
//		return databaseNameMongo;
//	}
//	public static String getMongoDatabaseHost() {
//		if (null == databaseHostMongo) {
//			databaseHostMongo = decryptKey(MONGO_DB_HOST);
//		}
//		return databaseHostMongo;
//	}
//	public static int getMongoDatabasePort() {
//		if (databasePortMongo == 0) {
//			String portStr = decryptKey(MONGO_DB_PORT);
//			databasePortMongo = !OPLUtils.isObjectNullOrEmptyOrDash(portStr) ? Integer.valueOf(portStr) : 0;
//		}
//		return databasePortMongo;
//	}
//	public static String getMongoAuthenticationDatabase() {
//		return MONGO_AUTHENTICATION_DB;
//	}
//
//	public static String getMongoUserName() {
//		if (null == userNameMongo) {
//			userNameMongo = decryptKey(MONGO_USER_NAME_KEY);
//		}
//		return userNameMongo;
//	}
//
//	public static char[] getMongoPassword() {
//		if (null == passwordMongo) {
//			passwordMongo = decryptKey(MONGO_PASS_KEY);
//		}
//		return passwordMongo.toCharArray();
//	}

	/* Oracle config */
	public static String getDbUrlOracle() {
		if (null == dbUrlOracle) {
			dbUrlOracle = decryptKey(ORACLE_URL_KEY);
		}
		return dbUrlOracle;
	}

	public static ENVMode getEnvMode() {
		if (null == envMode) {
			String mode = decryptKey(ORACLE_ENV_MODE);
			return OPLUtils.isObjectNullOrEmpty(mode) ? ENVMode.P : ENVMode.fromName(mode);
		} else {
			return envMode;
		}
	}

	/**
	 * Mysql Nabard Support
	 * @return
	 */
	public static String getDatabaseURL() {
		if (null == databaseName) {
			databaseName = decryptKey(DB_URL);
			return databaseName;
		} else {
			return databaseName;
		}
	}

	public static String getUserName() {
		if (null == userName) {
			userName = decryptKey(DB_USERNAME);
			return userName;
		} else {
			return userName;
		}
	}

	public static String getPassword() {
		if (null == password) {
			password = decryptKey(DB_PASSWORD);
			return password;
		} else {
			return password;
		}
	}
	
    public static String getAnsAppServerDomain() {
        if (null == ansAppServerDomain) {
            ansAppServerDomain = decryptKey(JNS_APP_SERVER_DOMAIN);
            return ansAppServerDomain;
        } else {
            return ansAppServerDomain;
        }
    }

}
