package com.opl.jns.utils.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class COIRequest {

	private String nameOfMember;
	private String address;
	private String aadharNo;
	private String nameOfNominee;
	private String accountNo;
	private Date dateOfComOfCover;
	private String sumAssured;
	private Double premAmtPaid;
	private String mstPolicyNo;
	private String logoUrl;
	private String bankLogoUrl;
	private String nameOfInsurer;
	private Integer nameOfInsurerId;
	private String urnNo;
	private String mobileNo;
	private String dob;
	private String nameOfBank;
	private String nameOfGuardian;
	private String relationShipOfGuardian;
	private String ageOfNominee;
	private String coverEndDate;
	private Date signatureDate;
	private String lienPeriod;
	private String annuRenDate;
	private Long coiStorageId;
	private Long schemeId;
	private Long applicationId;

	private String kycName;
	private String kycValue;
	private Boolean isCustomerUser;
	
	private Long lastTransactionDetailsId;

	/**
	 * for get data from client
	 */
	private Integer relationId;
	private Long insurerOrgId;
	private Long orgId;
	private Long branchId;
	private String branchCode;
	private String branchAddress;
}
