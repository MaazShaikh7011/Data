package com.opl.jns.utils.enums;

public enum VersionMaster {
	V1, V2, V3
}
