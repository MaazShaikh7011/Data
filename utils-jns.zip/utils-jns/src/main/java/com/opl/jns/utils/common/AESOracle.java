package com.opl.jns.utils.common;



import lombok.extern.slf4j.*;

import java.nio.charset.*;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import jakarta.persistence.AttributeConverter;


 
@Slf4j
public class AESOracle implements AttributeConverter<String, String> {

	private static final String ALGORITHM = "AES";
	private static final String KEY = "C@p!ta@W0rld#AES";
	private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";

    public static String encrypt(String data) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			byte[] keyBytes = Arrays.copyOf(KEY.getBytes(StandardCharsets.US_ASCII), 16);
			cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keyBytes, ALGORITHM), new IvParameterSpec(keyBytes));
			byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
			return Base64.getEncoder().encodeToString(encryptedBytes);
		}catch (Exception e){
			log.error("Exception while encrypting : [{}] ",data);
			e.printStackTrace();
		}
		return null;
    }

    public static String decrypt(String encryptedData) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			byte[] keyBytes = Arrays.copyOf(KEY.getBytes(StandardCharsets.US_ASCII), 16);
			cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, ALGORITHM), new IvParameterSpec(keyBytes));
			byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
			return new String(decryptedBytes, StandardCharsets.UTF_8);
		}catch (Exception e){
			log.error("Exception while decrypting : [{}] ",encryptedData);
			e.printStackTrace();
		}
		return null;
    }

	@Override
	public String convertToDatabaseColumn(String attribute) {

		if (attribute != null) {
			try {
				return encrypt(attribute);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		if(dbData!= null) {
			try {
				return decrypt(dbData);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

//	public static void main(String[] args) throws Exception {
//		String s ="RH1WjbYSi27t3EQPMJ/DQLcqBC7/KnboV/h6KkNkzI8=";
//		System.out.println(decrypt(s));
//	}
}