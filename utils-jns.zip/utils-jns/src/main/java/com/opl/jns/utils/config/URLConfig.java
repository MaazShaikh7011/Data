package com.opl.jns.utils.config;

import java.net.InetAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opl.jns.utils.common.EncryptionUtils;
import com.opl.jns.utils.common.OPLUtils;

public class URLConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(URLConfig.class);
	public static final String JNS_ENVIRONMENT_NAME = "JNS_ENVIRONMENT_NAME";
	public static final String AUTH_URL = "AUTH_URL";
	public static final String PROD = "PROD";

	private static String JNS_URL_SERVICE_TYPE = "JNS_URL_SERVICE_TYPE";
	private static String SERVICE_TYPE_LOCAL = "LOCALHOST";
	private static String SERVICE_TYPE_IPS = "IPS";
	private static String SERVICE_TYPE_DOMAIN = "DOMAIN";
	private static final String DOMAIN_URL = "JNS_DOMAIN_URL";
	private static final String PRODUCTION_CONTEXT_PATH = "PRODUCTION_CONTEXT_PATH";

	public static String fetchURL(URLMaster master) {
		if (master == null) {
			LOGGER.info("URL MASTER IS NULL OR EMPTY");
			return null;
		}
		try {
			String prod = System.getenv(JNS_ENVIRONMENT_NAME);
			if(master == URLMaster.AUTH && !OPLUtils.isObjectNullOrEmpty(prod) && prod.equalsIgnoreCase(PROD)){
				return System.getenv(AUTH_URL);
			}

			String serviceType = System.getenv(JNS_URL_SERVICE_TYPE);
			if (SERVICE_TYPE_LOCAL.equals(serviceType)) {
				return "http://localhost:".concat(getURL(master,serviceType));
			} else if (SERVICE_TYPE_IPS.equals(serviceType)) {
				String serverIp = InetAddress.getLocalHost().getHostAddress().trim();
				return "http://" + serverIp + ":" + getURL(master,serviceType);
			} else {
				String domainUrl = decryptKey(DOMAIN_URL);
				return domainUrl.concat(getURL(master,serviceType));
			}
		} catch (Exception e) {
			LOGGER.error("Exception while FETCH URL ---> ", e);
		}
		return null;
	}

	private static String getURL(URLMaster master, String serviceType) {
		String prodContextPath = decryptKey(PRODUCTION_CONTEXT_PATH);
		if (OPLUtils.isObjectNullOrEmpty(prodContextPath)) {
			if (SERVICE_TYPE_LOCAL.equals(serviceType) || SERVICE_TYPE_IPS.equals(serviceType)) {
				return master.getPort() + master.getContextPath();
			} else {
				return master.getContextPath();
			}
		}
		if (SERVICE_TYPE_LOCAL.equals(serviceType) || SERVICE_TYPE_IPS.equals(serviceType)) {
			return master.getPort() + prodContextPath + master.getContextPath();
		} else {
			return prodContextPath + master.getContextPath();
		}
	}

	private static String decryptKey(String key) {
		String value = System.getenv(key);
		EncryptionUtils cryptoConverter = new EncryptionUtils();
		return cryptoConverter.convertToEntityAttribute(value);
	}

}
