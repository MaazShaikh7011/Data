package com.opl.jns.utils.common;

public class SchemaMaster {
	
	public static final String USERS = "users";
	public static final String LOAN_APPLICATION = "loan_application";
	public static final String OTP_LOGS = "otp_service";
	public static final String NOTIFICATION = "notification";

}
