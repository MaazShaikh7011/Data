package com.opl.jns.utils.enums;

public enum UserTypeMaster {
	FUNDSEEKER(1l, "FundSeeker"), 
	FUNDPROVIDER(2l, "Fund Provider"),
	NODEL_AGENCY(3l, "Nodel Agency"),
	MINISTRY(4l, "Ministry"),
	ADMIN_PANEL(5l, "Admin Panel"),
	INSURER(6l, "Insurer"),
	COUNCIL(7l, "Council"),
	ULB(8l, "Urban Local Body"),
	BANK_PARTNER(9l,"Partner");

	private Long id;
	private String value;

	private UserTypeMaster(Long id, String value) {
		this.id = id;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static UserTypeMaster fromId(Long v) {
		for (UserTypeMaster c : UserTypeMaster.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
}
