package com.opl.jns.utils.common;

/**
 * @author jaimin.darji
 * 5/11/2021
 */
public class EncryptionRequest {
    String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
