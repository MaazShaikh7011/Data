package com.opl.jns.utils.common;

import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.persistence.AttributeConverter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateEncryptorAes implements AttributeConverter<Date, String> {

    public DateEncryptorAes() {
    }
//    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");



    public String convertToDatabaseColumn(Date attribute) {
        try {
            if (attribute != null) {
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return AESOracle.encrypt(sdf1.format(attribute));
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }

        return null;
    }

    public Date convertToEntityAttribute(String dbData) {
        try {
            if (dbData != null) {
                String dateStr = AESOracle.decrypt(dbData);
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return !OPLUtils.isObjectNullOrEmpty(dateStr)  ? sdf1.parse(dateStr) : null;
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }
        return null;
    }

//    public static void main(String[] args)  {
//        for (int i=0; i<10000; i++){
////            System.out.println(i);
//            int finalI = i;
//            new Thread(() -> {
//                try {
//                    DateEncryptorAes a = new DateEncryptorAes();
//                    String s = "RH1WjbYSi27t3EQPMJ/DQLcqBC7/KnboV/h6KkNkzI8=";
//                    log.info("count [{}] and date  [{}]" , finalI, a.convertToEntityAttribute(s));
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }).start();
//        }
//    }

}
