package com.opl.jns.utils.common;

public class PatternUtils {
	
	// PATTERN
	public static final String PAN_PATTERN = "[A-Z]{3}P[A-Z]{1}[0-9]{4}[A-Z]{1}";
	public static final String AADHAR_PATTERN = "^[0-9]{12}$";
	public static final String PASSPORT_PATTERN = "^[a-zA-Z]{1}[0-9]{7}$";
	public static final String VOTERS_ID_CARD_PATTERN = "^[A-Z]{3}\\d{7}$";
	public static final String DRIVING_LICENCE_PATTERN = "^(([A-Z]{2}[0-9]{2})(-| |)|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$";
	public static final String MGNREGA_CARD_PATTERN = "[A-Z]{2}-[0-9]{1,4}-[0-9]{1,4}-[0-9]{1,4}-[0-9]{1,8}\\/[0-9]{1,8}";
	public static final String IFSC_PATTERN = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$";
	public static final String EMAIL_PATTERN = "^([a-zA-Z0-9])[\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}";
	public static final String MOBILE_NO_PATTERN = "^[6789]\\d{9}";
	public static final String BRANCH_CODE_PATTERN = "^[a-zA-Z0-9]+$";
    public static final String ONLY_SPACE_NOT_ALLOWED_PATTERN = "^[a-zA-Z0-9 !@#$&()‘./+,“-]+[a-zA-Z0-9!@#$&()‘./+,“-]*[a-zA-Z0-9!@#$&()‘./+,“-]*$";
    public static final String ONLY_SPACE_NOT_ALLOWED_SOME_SPE_CHAR_ALLOWED_PATTERN = "^[a-zA-Z0-9][a-zA-Z0-9&,-/.\\\"\\(\\) ]*$";
    public static final String ONLY_SPACE_NOT_ALLOWED_SPE_CHAR_ALLOWED_PATTERN = "^[a-zA-Z0-9/.,:@#&_=()\\\\\\\"'-]+[a-zA-Z0-9/.,: @#&_=()\\\\\\\"'-]*[a-zA-Z0-9/.,:@#&_=()\\\\\\\"'-]*$";    
    public static final String ONLY_ALPHABETS_WITH_SPACE_ALLOWED = "^[a-zA-Z.'/-]+[a-zA-Z .'/-]*[a-zA-Z.'/-]*$";
    public static final String ONLY_ALPHABETS_WITH_SPACE_ALLOWED_1 = "^[a-zA-Z]+[a-zA-Z .'/-]*[a-zA-Z.'/-]*$";
    public static final String ONLY_ALPHANUMERIC_ALLOWED = "^[a-zA-Z0-9]*$";
    public static final String ONLY_ALPHABETS_ALLOWED = "^[A-Za-z]+$";
    public static final String ONLY_NUMBERS_ALLOWED = "[0-9]+";
    public static final String MOBILE_PATTERN_91 = "^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$";
    public static final String TIME_PATTERN = "^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$";

}
