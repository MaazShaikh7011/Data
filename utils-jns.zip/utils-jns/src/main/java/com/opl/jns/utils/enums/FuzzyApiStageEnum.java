package com.opl.jns.utils.enums;

public enum FuzzyApiStageEnum {

	IN_PROGRESS(1, "In Progress", "Current Call is in progress."), completed(2, "Completed", "Current Call is completed");

	private int id;
	private String code;
	private String value;

	private FuzzyApiStageEnum(int i, String code, String value) {
		this.id = i;
		this.code = code;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getCode() {
		return code;
	}

	public static FuzzyApiStageEnum fromId(int v) {
		for (FuzzyApiStageEnum c : FuzzyApiStageEnum.values()) {
			if (c.id == v) {
				return c;
			}
		}
		return null;
	}

	public static FuzzyApiStageEnum[] getAll() {
		return FuzzyApiStageEnum.values();
	}

}
