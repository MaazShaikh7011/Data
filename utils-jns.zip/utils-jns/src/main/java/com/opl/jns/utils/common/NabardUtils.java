package com.opl.jns.utils.common;

import java.util.Date;

import lombok.extern.slf4j.Slf4j;

/**
 * TO ENCRYP, DECRYPT AND VALIDATE NABARD DESTINATION REQUEST HEADER KEY FOR
 * NABARD MIDDLE LAYER
 * 
 * @author harshit.suhagiya
 * @date 10-Jul-2024
 * @time 2:56:18 pm
 */
@Slf4j
public class NabardUtils {

	/*
	 * START REQ HEADER WHEN REQUEST COMES FROM JANSURAKSHA TO NABARD MIDDLE LAYER
	 */
	public final static String REQ_JNS_DEST_ORG_KEY = "jnsnabarddestorg";
	/*
	 * END REQ HEADER WHEN REQUEST COMES FROM JANSURAKSHA TO NABARD MIDDLE LAYER
	 */

	/**
	 * ENCRYPT ORG ID WITH CURRENT TIME (MILISECOND)
	 * 
	 * @param orgId
	 * @return
	 */
	public static String encrypt(Long orgId) {
		if (OPLUtils.isObjectNullOrEmpty(orgId)) {
			return null;
		}
		Date date = new Date();
		String value = new StringBuilder().append(date.getTime()).append(":").append(orgId).toString();
		return new EncryptionUtils().convertToDatabaseColumn(value);
	}

	/**
	 * DECRYPT HEADER ORG VALUE AND VALIDATE WITH CURRENT TIME STAMP
	 * 
	 * @param value        (Header value received in the header of request from
	 *                     jansuraksha)
	 * @param diffMilliSec (Pass millisecond to check valid request within the time
	 *                     frame or it will take default 60K millisecond by default)
	 * @return
	 */
	public static Long decryptAndValidate(String value, Long diffMilliSec) {
		if (OPLUtils.isObjectNullOrEmpty(value)) {
			return null;
		}
		EncryptionUtils encryptUtils = new EncryptionUtils();
		String encrValue = encryptUtils.convertToEntityAttribute(value);

		String[] split = encrValue.split(":");
		Long time = Long.valueOf(split[0]);
		Long orgId = Long.valueOf(split[1]);
		if (diffMilliSec == null) {
			diffMilliSec = 60000l;
		}
		Date date = new Date();
		if ((date.getTime() - time) > diffMilliSec) {
//			log.info("The request is taking longer than expected to reach the destination");
			log.info("Destination org key is not matched with current timestamp");
			return null;
		}
		return orgId;
	}

//	public static void main(String[] args) throws InterruptedException {
//		String encpValue = NabardUtils.encrypt(16l);
//		System.out.println(encpValue);
//		Thread.sleep(1936);
//		Long orgId = NabardUtils.decryptAndValidate(encpValue, 2000l);
//		System.out.println(orgId);
//	}

}
