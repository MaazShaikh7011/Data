package com.opl.jns.utils.enums;

public enum ClaimStageMaster {

	CLAIM_REGISTRATION(10, "claim registration"),
	CLAIM_FORM(11, "Claim Form"), 
	CLAIM_UPLOAD_DOCUMENT(12, "Claim Upload Document"),
	CLAIM_COMPLETED(14, "Claim completed"),
	CLAIM_EXPIRED(15, "Claim Expired");

	private int stageId;
	private String stageName;

	ClaimStageMaster(int stageId, String stageName) {
		this.stageId = stageId;
		this.stageName = stageName;
	}

	public static ClaimStageMaster getStageMasterByStageId(int stageId) {
		for (ClaimStageMaster c : ClaimStageMaster.values()) {
			if (c.stageId == stageId) {
				return c;
			}
		}
		return null;
	}

	public int getStageId() {
		return this.stageId;
	}

	public String getStageName() {
		return this.stageName;
	}

}
