package com.opl.queue.controller;

import com.opl.queue.utils.SqsJSONObjectHelper;
import com.opl.queue.config.SQSEncryptionUtils;
import com.opl.queue.utils.SqsUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sqs")
public class SqsController {


    @PostMapping(value = "/encryptRequest",produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> encryptRequest(@RequestBody Object request){
        try {
            String requestStr = SqsJSONObjectHelper.getStringfromObject(request);
            String encrypt = SQSEncryptionUtils.encrypt(requestStr);
            return new ResponseEntity<>(encrypt, HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>("Error in encrypt requested String ", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value="/decryptRequest",produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> decryptRequest(@RequestBody String request){
        try {
            String decryptRes = SQSEncryptionUtils.decrypt(request);
            return new ResponseEntity<>(decryptRes, HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>("Error in decrypt requested String ", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getCurrentSqsConfig")
    public ResponseEntity<String> getCurrentSqsConfig(){
        String getenv = System.getenv(SqsUtils.JNS_PUSH_API_SQS_CONFIG);
        String decryptSqsConfig = SQSEncryptionUtils.decrypt(getenv);
        return new ResponseEntity<>(decryptSqsConfig, HttpStatus.OK);
    }

}
