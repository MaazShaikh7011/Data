package com.opl.queue.proxy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SQSQueueMsgProxy implements Serializable {

	private static final long serialVersionUID = -3397277240573316284L;

	private Long orgId;

	private String name;

	private String url;
}
