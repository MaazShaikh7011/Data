package com.opl.queue.config;

import com.opl.queue.proxy.SqsConfiguration;
import com.opl.queue.utils.SqsJSONObjectHelper;
import com.opl.queue.utils.SqsUtils;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SQSEncryptionUtils {
	private static final String ALGORITHM = "AES";
	private static final String KEY = "C@p!tta@W0rld#AESSS";
	public static final String MD5 = "MD5";

	private static final Logger logger = (Logger) LoggerFactory.getLogger(SQSEncryptionUtils.class);

	/**
	 * ENCRYPT PLAIN TEXT
	 *
	 * @param plainText
	 * @return
	 */
	public static String encrypt(String plainText) {
		try {
			if (!SqsUtils.isObjectNullOrEmpty(plainText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.ENCRYPT_MODE, key);

				byte[] cleartext = plainText.getBytes(StandardCharsets.UTF_8);
				byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(Hex.encodeHex(ciphertextBytes));
			}
		} catch (Exception e) {
			logger.error("Error while encrypting data : " + plainText, e);
		}
		return null;
	}

	/**
	 * DECRYPT TEXT
	 *
	 * @param encryptedText
	 * @return
	 */
	public static String decrypt(String encryptedText) {
		try {
			if (!SqsUtils.isObjectNullOrEmpty(encryptedText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);
				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.DECRYPT_MODE, key);
				return new String(cipher.doFinal(Hex.decodeHex(encryptedText.toCharArray())));
			}
		} catch (Exception e) {
			logger.error("Error while decrypting data : " + encryptedText, e);
		}
		return null;
	}

	public static Map<String,Object> encryptSqsConfiguration(List<SqsConfiguration> sqsConfigList) {
			for(SqsConfiguration sqsConfig:sqsConfigList) {
				String[] split = sqsConfig.getUrl().split("/");
				String sqsName = split.length > 0 ? split[split.length - 1] : null;
				sqsConfig.withName(sqsName).withRegion("ap-south-1");
			}

			try {
				String plainSqsStr = SqsJSONObjectHelper.getStringfromObject(sqsConfigList);
				String encrypt = encrypt(plainSqsStr);
				Map<String, Object> result = new HashMap<>();
				result.put("plainSqsString", plainSqsStr);
				result.put("encryptedSqsString", encrypt);
				return result;
			} catch (IOException e) {
				logger.info("Exception while encrypting sqs string ", e);
			}

		return null;
	}

	public static void main(String[] args) {
//		String url = "https://sqs.ap-south-1.amazonaws.com/134564335904/JANSURAKSHA_QA_SQS_BANK_UNION";
//		String[] split = url.split("/");
//		System.out.println("sqs name : "+split[split.length - 1]);
		SQSEncryptionUtils utils = new SQSEncryptionUtils();

		// single qa sqs
//		String data = utils.decrypt("f8aea71b4816198f222b6ef9066bb3c4ab4826786e21c6a77fff129fb752052d91d938727cf3e7d3f0e7eee93f79a6ff97304e233f7df2b166adb9bf9aeb8d758bbf00e4a9f68da7d7b49b71b01dfc811dd41569355e5cd9c4a613897ec43b9b2f3686bde50fa8501cbf8e2c5f257e555582608cdd9f14291011da10825e1f2bdd472f0ff1d7b27c5304665aed4140e532d0039d6a47180f6d70b2ae1e080e068f426288d9706fbca649abc5eeb94a63145d56c9ac9f5198f8e8cd448930c60c8ba1bbcf28234df278d197c9ebd4546cd20fca31a0c73f63032ceafeda546cc15b623f8f924e2cae572ace707922d6f45efb720306150231765113c3000054d8");

//		QA sqs
		String data = utils.decrypt("6441a554b389f2e192eaa91f26fd9de0ade0c81231f01f64b75a9daebee9e28b6e75745ff1f1f423104401fddc110f44f539aa4f5318fb934d65b61b1f9de417c25c331e6471c06259a4ffd747da207481b053715711c2545710b6f923ccc09d6e49a855a8e28e26596c1eacde7f058aeb63ae8d8988f8fe6fd837e2490d910814e2ed01f8671841384b3ecd2f318ba7362c131fa78a3994ef260af7a2d37e8387625442af120bcd45ed71afbe145457d05296f9052ce36752edcc3890ad4dd7c70d4c416cabed2acccafd98bb0d855680523d194293d559994d9a00dda934a612d953aea0047de16a8445857efa365eb40122fc5eabe0ad16ff4434ad11c307bfb48dd533fecc3f669f63909e8959e428c506c176c9ca99ef247de9fc0359ae4baab42c15b20990aa22a58cf2909717fa6d6c6d28d7d6593e4e55965d35c40267570d830bbe8cc42ef9d0eb6d1269d00656487e4a6a89bc53099ea7af7121a65b4a19b129b5ecaa6bfb0e3ad8447b1390a9474116cdcb44f6ab0938e24ae3a7834ebfd0d1d6336d19b6110b0e7a544e61c66de82659abdbf202edd23a85b182db78dfc19edbeef99490cdcd451585b0547c8e4bfdc3e221d61d0a9ba5c532de75c047436980e8d1b320e5fc8898a502bc3338046f3837cb89f4a22b333afc4f18aa90d28f31af352cf86c658c077ff6e482e265d09f3e52e59e7522ebac6d883b5749af4e3350ef65289b7cf4f0287a173df7d5403c3af45125d86c00f3ae4897304e233f7df2b166adb9bf9aeb8d758bbf00e4a9f68da7d7b49b71b01dfc819464b28d5e1d972edfc0a357282ba8f7a538265eaa863b15e71dabcd5a65e0574801d5a6f6ba7cb1cbf48f8e3650184e090643afacbe063e75798728b6ae8ead362c131fa78a3994ef260af7a2d37e83367285dc1b5153983e38754772e66f8dd05296f9052ce36752edcc3890ad4dd7c70d4c416cabed2acccafd98bb0d855680523d194293d559994d9a00dda934a612d953aea0047de16a8445857efa365eb40122fc5eabe0ad16ff4434ad11c307bfb48dd533fecc3f669f63909e8959e428c506c176c9ca99ef247de9fc0359ae4baab42c15b20990aa22a58cf2909717fa6d6c6d28d7d6593e4e55965d35c40267570d830bbe8cc42ef9d0eb6d1269d0500bf2f7105c309c9f876040f7120b785b4a19b129b5ecaa6bfb0e3ad8447b13fec23fbf150bceda8e38b64a9ef41273834ebfd0d1d6336d19b6110b0e7a544e61c66de82659abdbf202edd23a85b182db78dfc19edbeef99490cdcd451585b0547c8e4bfdc3e221d61d0a9ba5c532de5a8001d655e74e19c5e82a30a9dd471979926a620b1323304547fb4a0f423c1818aa90d28f31af352cf86c658c077ff6f8c20d563ff3f4ef19f71711661fbac93b5749af4e3350ef65289b7cf4f0287a5ec458f5605741523722d2ac3d4234b4364f8095c4c6608dac77fa94da3d3e5e0f412e3803f6c70aa8603bfd9df862d4528062d224cb8bb667b7a0434f47c3f06aed2b3b192ccb94916bb106e801eaa92ef57767552a3c6b5d20b3a682e2363bd0192a094b8e4df550c054229152b261c029fa8acd4f8233fc9948bf2e192358ee3bd6ea49c25a1ba813c92e92aa810beb63ae8d8988f8fe6fd837e2490d9108bcd81366ec76d9d199fee1e0aec162bc6b6aeb49776abce13e903cc9222e509d166c56c71e8a04e745dacdd944b9342833d164f1816fc5d070ad80a24e1318a32fe2e807fa671c076cc45627b42e9c23250d52f045b78005b90d218ed129e6a1328b9c291a937f78567e015fbe5e7af6abc67925ad2077479632a4824cc85f69d8fc54b7e42b7c33935df57080657350ade0c81231f01f64b75a9daebee9e28bbdc755def344a7e50e8d9615b36007f345050ce4b35287b55a98d40abb1cdf69fde0d97fc429949e8bcc369d2719922ebee4f9da472843ff5c8e7fba65b5e1ebfbdfbb6d7b32b229564ac9dec6f4dc245b4a19b129b5ecaa6bfb0e3ad8447b1352ce25cb688a54394481ac8266bf25df9d572771a87a85c36beedd753cf77aff18aa90d28f31af352cf86c658c077ff645bcbd6cb6ef135577ce811b0213e3cb3b5749af4e3350ef65289b7cf4f0287ac73874f467323afe810e8183192b1bcf834ebfd0d1d6336d19b6110b0e7a544e61c66de82659abdbf202edd23a85b182db78dfc19edbeef99490cdcd451585b0547c8e4bfdc3e221d61d0a9ba5c532de61cd34843cb44ae6b5f5a9b90a78c9c702e4215d7d2fc90721ac99485f1bf36d67570d830bbe8cc42ef9d0eb6d1269d0cc74583d6f0dc3f9e80352ad2c6b3dc05b4a19b129b5ecaa6bfb0e3ad8447b1352ce25cb688a54394481ac8266bf25dfe9f4d3737fd02514077ee1be57b1c241c25c331e6471c06259a4ffd747da207481b053715711c2545710b6f923ccc09d6e49a855a8e28e26596c1eacde7f058aeb63ae8d8988f8fe6fd837e2490d91085c6d576e77812164b5d0479c39301f0c9b3d7defc687bbc83625e5db4038f590b0396152b8508bf7ea0262cdbe47ebc7e04c1593ac96060e8580172a8e27c8b5698a5e6ae3f625fcafa15a56451ed8cfd3691be6a44f9eee81c5e60c6382fe89ef839f73e49ba6ed45dfd8cda59e971271f7a8a157c0cb5dcaf63b5b16ca0d8e29f653e6bd06e8c103eb9bf33bc983b41f2fc012a6fe7d9a4c336aeb049a0afe757bea389a29946450d696c9d73f8baddb9c23e4b099dda205e395e534eb910003f7afc74b3a8792ba335c732da7dff3acb471cc19811d21d0f5b43b16a4683b46209d925245d2eb1069b782f762ab5ef0b994fa612d8ed64e8bf0f4263d016f594198faaaacbfe7e225b87d1dc8604aa0994ba7e17f3cd3913bd386754b2200fb34386553d1df5e155e0f61d1429d3dcf9a1c2437144d4574fe5727b95c3c1e3a286316e4895c42f8ee60fabfd630c64cf1244ac36552d3175061038514cde85b623f8f924e2cae572ace707922d6f436c42d0387450ad24aead79d981df5f1235277d5960a51c01a284a0b04e5fb972632e0965280e972109bca6b1bd157b0669362753e101f89615394f791bfd4540d48bf7dd137f932c45b4fb5b81918c913371afbfaee3ee6c172d28b61151774fea8a08f89963d470b50b8ce7c8ec622246a49cf882a375507530dfe2e7a7d53239a7ccbebeb447817a26b17d46ef43b601fdae83715ee91e31711991322dd3a18aa90d28f31af352cf86c658c077ff6b85114ae0db3401b134342f4134466382c244c8c97500a807c9b81b58f2c1ceb11860309fddad20284ab41c27acb74a5fde0d3cd10c36fb5249ce1e70bbda3c69598fee69e65f3cf28435e84d3847c3ab47b0db9b3c2b01ea50dd08a9befea52ea3f22c9e1ff5e7093ae6e0173c3d1a62c244c8c97500a807c9b81b58f2c1ceb11860309fddad20284ab41c27acb74a569e175cadbfdfaaee2d39c53cffbf25ccd26b94f971a46cba1447ddd8f7beb7935238d243e77310d5102dffd00fec6c369b5ba2a4cffd112410504c3cd1646e367055bb0c6d38cd67b7df638fa0a96b9cb41df7301334e7c049d787423c1e8939598fee69e65f3cf28435e84d3847c3ab47b0db9b3c2b01ea50dd08a9befea52ea3f22c9e1ff5e7093ae6e0173c3d1a62c244c8c97500a807c9b81b58f2c1cebb3e164bf82507293643865b57fe0fc19cc9bee6b0a7fd344370ef4bddee0de1518aa90d28f31af352cf86c658c077ff6e6891d5e187d2e9bdf50132c4a8f57fd2c244c8c97500a807c9b81b58f2c1ceba6b3ba146255c242f8362f3294f47e8982ffeb8708ae314d6531362e89d5b4e0c25c331e6471c06259a4ffd747da207481b053715711c2545710b6f923ccc09d6e49a855a8e28e26596c1eacde7f058abb9f0718cdaa7ac729b47fdfc6de6b721abd6b4b803568e8326c05e0a9cf0cb582908e2a80e3c05e10ccdc5b6b28f41911318a0a069d9a79de03b69fc3831ab0569976c31e55e038f8c51bcdc5061949bb9f0718cdaa7ac729b47fdfc6de6b72e965bb506a37cbdff2a576b70bde47ffecefb506e86ff67a717611e141405a25c25c331e6471c06259a4ffd747da207481b053715711c2545710b6f923ccc09d6e49a855a8e28e26596c1eacde7f058abb9f0718cdaa7ac729b47fdfc6de6b72e965bb506a37cbdff2a576b70bde47ff601fdae83715ee91e31711991322dd3a18aa90d28f31af352cf86c658c077ff6e0e7290866903bd56b4cb03576a49b9c2c244c8c97500a807c9b81b58f2c1ceb11860309fddad20284ab41c27acb74a5aad009d66869682c013e4973fa9355b69598fee69e65f3cf28435e84d3847c3ab47b0db9b3c2b01ea50dd08a9befea52ea3f22c9e1ff5e7093ae6e0173c3d1a62c244c8c97500a807c9b81b58f2c1ceb11860309fddad20284ab41c27acb74a54ed9fbf82ba8c4b130cf96f7dfb3280acd26b94f971a46cba1447ddd8f7beb79bfbd5126caf7565d7636c68fc679248e69b5ba2a4cffd112410504c3cd1646e3290bf04cecacac82356bee6a5b226afc849a22216103d9cffa5ccd8472ba8a95093913e584140b5d652f5dca9ffb8f261fb6d7f67f5072386c93c5a6ec5290a11b07d36ef5c0a59386d03188d0b5c579014e4630258d3bb1e13aff1cec988612f3d66779c96e0f8719817e8e464d28ba362c131fa78a3994ef260af7a2d37e839858d0eb937f1fe6d16d4b8de2cf523898d1ebb718e4376bd38d6dcf86e435519b792c1f0b3525610b808fadad0fdc57dbc2eb5c5a61e0a07866b2d80f866e14fde0d97fc429949e8bcc369d2719922ebee4f9da472843ff5c8e7fba65b5e1ebfbdfbb6d7b32b229564ac9dec6f4dc245b4a19b129b5ecaa6bfb0e3ad8447b136ddcdef8c8241357d09321d23ea8a93d82908e2a80e3c05e10ccdc5b6b28f41911318a0a069d9a79de03b69fc3831ab09a461ba81812a8c873992f339c14fa59bb9f0718cdaa7ac729b47fdfc6de6b72357194fcab50858ad3fa182ef443049d834ebfd0d1d6336d19b6110b0e7a544e61c66de82659abdbf202edd23a85b182db78dfc19edbeef99490cdcd451585b0547c8e4bfdc3e221d61d0a9ba5c532de51eba386d7f22231b9b93bd244a639e9a487ce2f0fc33e188a343dbbebf0785a03f7afc74b3a8792ba335c732da7dff34e7365cb78ab875ef2f8f4b0a9e6485346209d925245d2eb1069b782f762ab5e52364a52056525e371b509263314130aa8e82ade6a155362fce883c74fcf5d420d48bf7dd137f932c45b4fb5b81918c913371afbfaee3ee6c172d28b61151774fea8a08f89963d470b50b8ce7c8ec622246a49cf882a375507530dfe2e7a7d5352364a52056525e371b509263314130afe7726672fec77632288de733a141a24c92e2a2e65ad2f816be7014110cd71afe384fc91a0ac58e423d141915feec4a8");
		System.out.println("Decrypted Data \n -------------------------------------");
		System.out.println(data);
//
//		System.out.println();
//
//		String sqsString="[{\"orgId\":1,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_UNION\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_UNION\",\"region\":\"ap-south-1\"},{\"orgId\":12,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"region\":\"ap-south-1\"},{\"orgId\":13,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_IND\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_IND\",\"region\":\"ap-south-1\"},{\"orgId\":14,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"region\":\"ap-south-1\"},{\"orgId\":16,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"region\":\"ap-south-1\"},{\"orgId\":17,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_BOB\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_BOB\",\"region\":\"ap-south-1\"},{\"orgId\":18,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_PNB\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_PNB\",\"region\":\"ap-south-1\"},{\"orgId\":19,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"region\":\"ap-south-1\"},{\"orgId\":20,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"region\":\"ap-south-1\"},{\"orgId\":25,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_CNTRL\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_CNTRL\",\"region\":\"ap-south-1\"},{\"orgId\":27,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_PBCS\",\"region\":\"ap-south-1\"},{\"orgId\":28,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_DFLT_IUB\",\"region\":\"ap-south-1\"},{\"orgId\":188,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_UIIC\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_UIIC\",\"region\":\"ap-south-1\"},{\"orgId\":189,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_LIC\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_LIC\",\"region\":\"ap-south-1\"},{\"orgId\":196,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_SC\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_SC\",\"region\":\"ap-south-1\"},{\"orgId\":201,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_INDFRST\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_INDFRST\",\"region\":\"ap-south-1\"},{\"orgId\":208,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_SBILIFE\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_SBILIFE\",\"region\":\"ap-south-1\"},{\"orgId\":210,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_SC\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_SC\",\"region\":\"ap-south-1\"},{\"orgId\":217,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_FU\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_FU\",\"region\":\"ap-south-1\"},{\"orgId\":226,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_NIC\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_NIC\",\"region\":\"ap-south-1\"},{\"orgId\":236,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_NIA\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_NIA\",\"region\":\"ap-south-1\"},{\"orgId\":237,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_ORCL\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_ORCL\",\"region\":\"ap-south-1\"},{\"orgId\":238,\"name\":\"JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_FU\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_INSURER_DEFAULT_FU\",\"region\":\"ap-south-1\"}]";
		// production
//		String sqsString="[{\"orgId\":13,\"name\":\"JANSURAKSHA_PROD_SQS_BANK_IND\",\"url\":\"https://sqs.ap-south-1.amazonaws.com/408630132378/JANSURAKSHA_PROD_SQS_BANK_IND\",\"region\":\"ap-south-1\"}]";
//		String encrypt = utils.encrypt(sqsString);
//		System.out.println("EncryptedData \n -------------------------------------");
//		System.out.println(encrypt);

	}
}
