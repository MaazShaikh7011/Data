package com.opl.queue.proxy;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "orgId",
        "name",
        "url",
        "region"
})
@Getter
@Setter
public class SqsConfiguration implements Serializable {

    @JsonProperty("orgId")
    public Integer orgId;
    @JsonProperty("name")
    public String name;
    @JsonProperty("url")
    public String url;
    @JsonProperty("region")
    public String region;
    private final static long serialVersionUID = 5131506204341332164L;

    public SqsConfiguration withOrgId(Integer orgId) {
        this.orgId = orgId;
        return this;
    }

    public SqsConfiguration withName(String name) {
        this.name = name;
        return this;
    }

    public SqsConfiguration withUrl(String url) {
        this.url = url;
        return this;
    }

    public SqsConfiguration withRegion(String region) {
        this.region = region;
        return this;
    }

}