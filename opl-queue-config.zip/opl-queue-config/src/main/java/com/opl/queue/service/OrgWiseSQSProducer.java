package com.opl.queue.service;

import com.opl.queue.proxy.SQSQueueListProxy;
import com.opl.queue.proxy.SQSQueueMsgProxy;
import com.opl.queue.utils.SqsUtils;
import io.awspring.cloud.sqs.operations.SqsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class OrgWiseSQSProducer {

	@Autowired
	private SQSQueueListProxy queueListProxy;

	@Autowired
	private SqsTemplate sqsTemplate;

	/**
	 * PRODUCE DATA IN AWS SQS
	 *
	 * @param request -- should be JSON String
	 * @param orgId  -- Queue will filter based on this org
	 * @return String  -- in case of SUCCESS it will return STRING 'Success'  otherwise return error
	 */
	public String produceByOrg(String request,Long orgId) {
		try {
			if (SqsUtils.isObjectNullOrEmpty(orgId)) {
				log.error("PUSH ENROLLMENT BANK DETAILS NOT FOUND ----->");
				return "Bank Details Not Found !!";
			}
			SQSQueueMsgProxy queue = queueListProxy.filter(orgId);
			if (SqsUtils.isObjectNullOrEmpty(queue)) {
				queue = queueListProxy.filter(-1l);
			}
			log.info("Pushing data on Queue : {}",queue.getName());
			if (SqsUtils.isObjectNullOrEmpty(queue)) {
				log.error("PUSH ENROLLMENT AWS SQS NOT FOUND BY ORGANIZATION ID OR -1 ----->");
				return "Its seems AWS SQS queue not found !!";
			}
			log.info("PUSH ENROLLMENT URL ----------------> {}" , queue.getUrl());
			SQSQueueMsgProxy finalQueue = queue;
			sqsTemplate.send(to -> to.queue(finalQueue.getName()).payload(request));
			return "Success";
		} catch (Exception e) {
			e.printStackTrace();
			log.error("PUSH ENROLLMENT EXCEPTION AWS SQS: ", e);
			return "Its seems the application encountered some error";
		}
	}
}
