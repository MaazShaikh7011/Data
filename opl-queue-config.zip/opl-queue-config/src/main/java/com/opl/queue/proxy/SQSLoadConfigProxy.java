package com.opl.queue.proxy;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SQSLoadConfigProxy {

	private Long orgId;
	private String name;
	private String url;
	private String accessKey;
	private String secretKey;
	private String region;

}
