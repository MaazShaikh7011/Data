package com.opl.queue.proxy;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CommonRequest implements Serializable {

    private String referenceId;
    private String urn;
    private Long applicationId;
    private Boolean isInsurer;
    public Long claimRefId;
    private String sourceId;
    private Long orgId;
    @JsonProperty("token")
    private String token;
    private Long commonUserId;
    @JsonProperty("storageId")
    private Long storageId;

    public CommonRequest(Long applicationId, Long orgId) {
        this.applicationId = applicationId;
        this.orgId = orgId;
    }

}
