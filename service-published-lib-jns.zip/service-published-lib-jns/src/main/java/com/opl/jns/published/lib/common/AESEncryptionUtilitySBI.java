/*******************************************************************************
 * Created By Hitesh Dharecha
 * Modified By Akshay Patel
 * Created Time Oct 19, 2016 | 12:02:00 PM
 *   
 * Copyright (c) 2016 Logiciel Solutions
 * All Rights Reserved.
 *  
 * This software is the confidential and proprietary information
 * of Logiciel Solutions.  Use of this software is governed
 * by the terms and conditions of the license statement and limited
 * warranty furnished with the software.
 *   
 * IN PARTICULAR, YOU WILL INDEMNIFY AND HOLD LOGICIEL SOLUTIONS,
 * ITS RELATED COMPANIES AND ITS SUPPLIERS, HARMLESS FROM AND
 * AGAINST ANY CLAIMS OR LIABILITIES ARISING OUT OF OR RESULTING
 * FROM THE USE, MODIFICATION, OR DISTRIBUTION OF PROGRAMS OR FILES
 * CREATED FROM, BASED ON, AND/OR DERIVED FROM THIS SOURCE CODE FILE.
 *  
 * Contributors:
 *     Hitesh Dharecha
 *******************************************************************************/
package com.opl.jns.published.lib.common;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AESEncryptionUtilitySBI {

	private static final Logger logger = LoggerFactory.getLogger(AESEncryptionUtilitySBI.class);
	private String transformation ;
	private String ivStr;
	
	private final static String ALGORITHM = "AES";
	private final static String CHAR_ENCODING = "UTF-8";

	public int AES_KEY_SIZE = 256;
	public int GCM_IV_LENGTH = 12;
	public int GCM_TAG_LENGTH = 16;
	
	public AESEncryptionUtilitySBI() {
		
	}
	public AESEncryptionUtilitySBI(String transformation) {
		this.transformation = transformation;
	}
	
	public AESEncryptionUtilitySBI(String milis, String transformation) {
		this.transformation = transformation;
		this.ivStr = milis.substring(0, 16);
	}

	public String encrypt(String plainText)throws InvalidKeyException, InvalidAlgorithmParameterException, UnsupportedEncodingException,
			IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {

		SecretKeySpec skeySpec = new SecretKeySpec(generateKey(), ALGORITHM);
		byte[] iv;
		if(ivStr == null || ivStr.isEmpty()) {
			iv = plainText.substring(0,16).getBytes();
			plainText  = plainText.substring(16);
		}else {
			iv = ivStr.getBytes();
		}
		Cipher cipher = Cipher.getInstance(transformation);
		if(transformation.contains("GCM")){
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, gcmParameterSpec);
		}else {
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivspec);
		}
		byte[] plainTextbytes = plainText.getBytes(CHAR_ENCODING);
		byte[] encryptedBytes = cipher.doFinal(plainTextbytes);
		byte[] array = ByteBuffer.allocate(iv.length+encryptedBytes.length)
        .put(iv)
        .put(encryptedBytes)
        .array();
		return Base64.getEncoder().encodeToString(array);
	}

	public String decrypt(String encryptedText)throws InvalidKeyException, InvalidAlgorithmParameterException, UnsupportedEncodingException,
			IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
		SecretKeySpec skeySpec = new SecretKeySpec(generateKey(), ALGORITHM);
		byte[] iv;
		if(ivStr == null || ivStr.isEmpty()) {
			iv = encryptedText.substring(0,16).getBytes();
			encryptedText  = encryptedText.substring(16);
		}else {
			iv= ivStr.getBytes();
		}
		Cipher cipher = Cipher.getInstance(transformation);
		if(transformation.contains("GCM")){
			GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, gcmParameterSpec);
		}else {
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivspec);
		}
		byte[] cipheredBytes = Base64.getDecoder().decode(encryptedText);
		byte[] decryptedBytes = cipher.doFinal(cipheredBytes);
		return new String(decryptedBytes, CHAR_ENCODING);
	}

	// Need to check with .NET API as below method added as per SBI Guidlines
	private byte[] generateKey() {
		try {
			String hex = "26f1ac75f77c22ebc66e2359c13ea9955ebd5e2bd7fbe50e5b3ac2977a772302";
			byte[] bytes = new byte[hex.length()/2];
			for (int i = 0; i < hex.length()/2; i++) {
				
				bytes[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
			}
			
			return bytes;

		} catch (Exception e) {
			logger.info("Error Msg [{}]", e);
		}
		return null;
	}
    
}