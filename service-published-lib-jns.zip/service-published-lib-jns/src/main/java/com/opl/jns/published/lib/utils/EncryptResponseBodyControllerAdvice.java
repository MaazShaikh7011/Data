package com.opl.jns.published.lib.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.domain.ErrorLog;
import com.opl.jns.published.lib.repository.ApiUsersRepository;
import com.opl.jns.published.lib.service.LogService;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.common.SymAsymEncryption;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class EncryptResponseBodyControllerAdvice implements ResponseBodyAdvice<Object> {

	@Autowired
	private ApiUsersRepository apiUsersRepo;

	@Autowired
	private LogService logService;

	private static final Long SBI_ORG_ID = 16L;
	public static final String REGISTRY_TRANSACTION = "/api/registry/v2/updateTransactionDetails";
	public static final String PUBLISH_APPLICATION = "/api/jns/v1/getApplicationDetails";
	public static final String PUBLISH_DOCUMENTS = "/api/jns/v1/getUploadedDocuments";

	/**
	 * This is set to false, it will not go this class again.
	 */
	@Override
	public boolean supports(MethodParameter methodParameter, @SuppressWarnings("rawtypes") Class aClass) {
		return true;
	}

	/**
	 * SET NULL IN PLAIN REQUEST LARGE OBJECT TO AVOID PAYLOAD SIZE ISSUE
	 *
	 * @param requestURI
	 * @param decryptBd
	 * @return
	 */
	private String setNullForLargeObject(String requestURI, String decryptBd) {
		if (requestURI.equals(REGISTRY_TRANSACTION) || requestURI.equals(PUBLISH_APPLICATION)
				|| requestURI.equals(PUBLISH_DOCUMENTS)) {
			return OPLJSONUtils.setNull(decryptBd, "document");

		}
		return decryptBd;
	}

	@Override
	public Object beforeBodyWrite(Object body, MethodParameter methodParameter, MediaType mediaType, Class aClass,
			ServerHttpRequest serverHttpRequest, ServerHttpResponse serverHttpResponse) {

		HttpServletResponse servletRes = ((ServletServerHttpResponse) serverHttpResponse).getServletResponse();
		HttpServletRequest servletReq = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		/* SKIP SWAGGER URLS */
		boolean isSwaggerUrl = APIAuthUtils.checkSwaggerURL(servletReq.getRequestURI());
		if (isSwaggerUrl) {
			servletReq.setAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER,true);
			return body;
		}

		/* SKIP ACTUATOR URLS */
		if (servletReq.getAttribute(APIAuthUtils.REQ_ATR_IS_ACTUATOR) != null) {
			return body;
		}

		servletRes.setHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE);

		ApiUsers apiUsers = null;
		String plainBody = "";
		try {
			/*
			 * FETCH API USER ID FROM REQUEST ATTRIBUTE (SET FROM INTERCEPTOR PREHANDLE
			 * METHOD)
			 */
			Long apiUserId = APIAuthUtils.getHeaderAttribute(servletReq, APIAuthUtils.REQ_ATR_APP_USER_ID, Long.class);

			/* FETCH API USER (SET IN DECRYPTION REQUEST CLASS) */
			if (apiUserId != null) {
				apiUsers = apiUsersRepo.findById(apiUserId).get();
			}

			plainBody = MultipleJSONObjectHelper.getStringfromObject(body);

			if (servletReq.getHeader(APIAuthUtils.REQ_AUTH) != null
					&& servletReq.getHeader(APIAuthUtils.REQ_AUTH).equals("true")) {
				return body;
			} else {
				/* SET PLAIN RESPONSE WITH REMOVE LARGE VALUE */
				String removeLargeObj = plainBody;
				servletReq.setAttribute(APIAuthUtils.RESPONSE_PLAIN_BODY,
						setNullForLargeObject(servletReq.getRequestURI(), removeLargeObj));

				/* IF THIS FLAG IS TRUE THEN NO NEEDS TO ENCRYPT RESPONSE */
				String skipEnc = servletReq.getHeader(APIAuthUtils.REQ_HEADER_ENCRYPTION_SKIP);
				if (skipEnc != null && skipEnc.equals("true")) {
					servletReq.setAttribute(APIAuthUtils.RESPONSE_ENCRYPT_BODY, plainBody);
					return body;
				} else {

					/* ENCRYPT RESPONSE */
					String encData = encryptRes(plainBody, apiUsers.getPublicKey(), servletReq);
					if (OPLUtils.isObjectNullOrEmpty(encData)) {
						throw new Exception("Exception while encrypt response");
					}

					/* SET ENCRYPT RESPONSE IN META DATA FORMS */
					Map<String, Object> response = new HashMap<>();
					response.put(AuthCredentialUtils.META_DATA, encData);

					/* SET REQUEST REFERENCE NUMBNER FOR SBI */
					if (apiUsers.getOrganizationMaster().getOrgId() == SBI_ORG_ID) {
						Object attribute = servletReq.getAttribute(APIAuthUtils.REQ_REF_NUMBER);
						if (!OPLUtils.isObjectNullOrEmpty(attribute)) {
							response.put(APIAuthUtils.REQ_REF_NUMBER, String.valueOf(attribute));
						}
					}
					/* WRITE REPONSE IN HTTP RESPONSE CLASS */
					try (OutputStream stream = serverHttpResponse.getBody()) {
						byte[] jsonRes = MultipleJSONObjectHelper.getStringfromObject(response).getBytes("UTF-8");
						String encryptRespBody = new String(jsonRes);
						servletReq.setAttribute(APIAuthUtils.RESPONSE_ENCRYPT_BODY, encryptRespBody);
						stream.write(jsonRes);
						stream.flush();
						return null;
					} catch (Exception e) {
						log.error("EXCEPTION WHILE WRITE ENCRYPT RESPONSE :-  ", e);
					}
				}
			}
		} catch (JsonProcessingException e) {
			log.error("JSON PARSE EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		} catch (IOException e) {
			log.error("IO EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE ENCRYPT RESPONSE :-  ", e);
		} finally {
			updateErrorLog(servletReq, apiUsers, plainBody);
		}
		return body;
	}

	/**
	 * UPDATE ERROR LOGS
	 * 
	 * @param servletReq
	 * @param apiUsers
	 * @param preReqLogs
	 */
//	@Async
	private void updateErrorLog(HttpServletRequest servletReq, ApiUsers apiUsers, String plainBody) {
		try {
			Object swaggerObj = servletReq.getAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER);
			boolean isSwaggerUrl = !OPLUtils.isObjectNullOrEmpty(swaggerObj) && (boolean) swaggerObj;
			Map<String, Object> map = null;
			if (!servletReq.getRequestURI().contains("saveAll") && !OPLUtils.isObjectNullOrEmpty(plainBody)) {
				map = MultipleJSONObjectHelper.getMapFromString(plainBody);
				if (map.get("status") != null) {
                    String statusStr = String.valueOf(map.get("status"));
                    if (!isSwaggerUrl){
						Integer resStatus = Integer.parseInt(statusStr);
						if (resStatus != HttpStatus.OK.value()) {
							servletReq.setAttribute(APIAuthUtils.RESPONSE_STATUS, resStatus);
							ErrorLog errorLog = new ErrorLog();
							if (apiUsers != null) {
								errorLog.setApiUsers(apiUsers);
								errorLog.setOrgId(apiUsers.getOrganizationMaster().getOrgId().intValue());
							}
							errorLog.setCreatedDate(new Date());
							if (map.get(AuthCredentialUtils.MESSAGE) == null
									|| map.get(AuthCredentialUtils.MESSAGE).equals("null")) {
								String resMsg = (String) map.get("data");
								servletReq.setAttribute(APIAuthUtils.DECRYPTION_MSG, resMsg);
								errorLog.setErrorMsg(resMsg);
							} else {
								String resMsg = (String) map.get(AuthCredentialUtils.MESSAGE);
								servletReq.setAttribute(APIAuthUtils.DECRYPTION_MSG, resMsg);
								errorLog.setErrorMsg(resMsg);
//							    errorLog.setErrorMsg((String) map.get(AuthCredentialUtils.MESSAGE));
							}
							errorLog.setReqUrl(servletReq.getRequestURI());
							logService.logError(errorLog);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVE ERROR LOGS IN ENCRYPT RESPONSE CLASS :- ", e);
		}
	}

	/**
	 * ENCRYPT RESPONSE
	 * 
	 * @param body
	 * @param publicKey
	 * @return
	 */
	private String encryptRes(String body, String publicKey, HttpServletRequest servletReq) {
		try {
			ApiUsers oplUser = apiUsersRepo.findFirstByIsInternalUserTrue();
			if (oplUser == null) {
				servletReq.setAttribute(APIAuthUtils.DECRYPTION_MSG, "OPL User Not Found While Decrypt Request");
//				reqLogs.setMessage("OPL User Not Found While Decrypt Request");
				return null;
			}
			return new SymAsymEncryption().encrypt(body, oplUser.getPrivateKey(), publicKey);
		} catch (Exception e) {
			log.info("FAILED TO DECRYPT REQUEST:: ", e);
			servletReq.setAttribute(APIAuthUtils.DECRYPTION_MSG, e.getMessage());
//			reqLogs.setMessage(e.getMessage());
		}
		return null;
	}

}
