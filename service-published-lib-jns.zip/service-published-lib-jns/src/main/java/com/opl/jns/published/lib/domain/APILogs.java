package com.opl.jns.published.lib.domain;

import java.io.Serializable;
import java.util.Date;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author ravi.thummar 10/5/2023
 */
@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "api_logs_dec", indexes = {})
public class APILogs implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_logs_dec_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "api_logs_dec_seq_gen", sequenceName = "api_logs_dec_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "context_path", nullable = true)
	private String contextPath;

	@Column(name = "request_url", nullable = true)
	private String requestUrl;

//	@Lob
	@Column(name = "request_ip", nullable = true)
	private String requestIp;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "account_number", nullable = true)
	private String accountNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "cif", nullable = true)
	private String cif;
	
	@Column(name = "urn", nullable = true)
	private String urn;

	@Column(name = "response_status", nullable = true)
	private Integer responseStatus;

	@Column(name = "response_time", nullable = true)
	private Long responseTime;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "application_reference_id", nullable = true)
	private Long applicationReferenceId;

	@Column(name = "token", nullable = true)
	private String token;
	
	@Column(name = "request_token", nullable = true)
	private String requestToken;

//    @OneToOne(cascade = CascadeType.ALL,mappedBy = "logAudit",fetch = FetchType.LAZY)
//    private RequestResponseAudit requestResponseAudit;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "api_user_id", nullable = true)
	private ApiUsers apiUsers;

	@Column(name = "req_ref_num", nullable = true)
	private String reqRefNum;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "message", nullable = true)
	private String message;

	@Column(name = "storage_id", nullable = true)
	private Long storageId;
//    @Column(name = "api_user_id", nullable = true)
//    private Long apiUserId;

	public APILogs() {
		super();
		this.createdDate = new Date();
	}

}
