package com.opl.jns.published.lib.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.repository.ApiUsersRepository;
import com.opl.jns.published.lib.service.LogService;
import com.opl.jns.published.utils.common.ApiRequest;
import com.opl.jns.published.utils.common.ApiResponse;
import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.common.SymAsymEncryption;
import com.opl.jns.published.utils.config.PhaseMode;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AuthenticationInterceptor implements HandlerInterceptor {

	@Autowired
	private ApiUsersRepository apiUsersRepository;

	@Autowired
	private LogService logService;

//	@Autowired
//	private UploadPayload uploadPayload;

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		log.info("REQUEST URL ---------------------------- :- " + request.getRequestURI());
		request.setAttribute(APIAuthUtils.REQUEST_RECEIVED_TIME, new Date().getTime());

		/* CHECK SWAGGER URL OR NOT */
		if (APIAuthUtils.checkSwaggerURL(request.getRequestURI())) {
			request.setAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER, Boolean.TRUE);
			return Boolean.TRUE;
		}

		/* HANDLE /actuator METHODS */
		if (request.getRequestURI().contains("actuator")) {
			// logger.info("For accuator : {}" , request.getRequestURI());
			request.setAttribute(APIAuthUtils.REQ_ATR_IS_ACTUATOR, Boolean.TRUE);
			return Boolean.TRUE;
		}

		HandlerMethod method = null;
		if (handler instanceof HandlerMethod handlerMethod) {
			method = handlerMethod;
		}

		/* SKIP TOKEN AUTHENTICATION IF METHOD HAVE SkipInterceptor ANNOTATION */
		if (method != null && method.getMethod().isAnnotationPresent(SkipInterceptor.class)) {
			request.setAttribute(AuthCredentialUtils.SESSION_OBJ_KEY,
					new ApiResponse(HttpStatus.OK.value(), "Success"));
			return Boolean.TRUE;
		}

		/* HANDLE /error METHODS */
		if (request.getRequestURI().contains("/error")) {
			log.error("ERROR FOR REQUEST URL ----------------- :-" + request.getRequestURI());
			return failed(response);
		}

		/* CHECK INTERNAL CLIENT CALL */
		if (AuthCredentialUtils.isClient(request)) {
			request.setAttribute(AuthCredentialUtils.SESSION_OBJ_KEY,
					new ApiResponse(HttpStatus.OK.value(), "Success"));
			return Boolean.TRUE;
		}

		/* FETCH API USERNAME AND API KEY */
		ApiRequest apiRequest = AuthCredentialUtils.httpResToAuthReq(request);
		if (apiRequest == null) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			log.error("BAD REQUEST, TOKEN IS NULL OR EMPTY ----------------- :-" + request.getRequestURI());
			logService.failureLogs(request, "Username or api-key is null or empty!", null);
			return failed(response);
		}

		log.info("USER: " + apiRequest.getUsername() + " REQUEST START FOR: " + request.getRequestURI());
		ApiUsers apiUser = apiUsersRepository.findFirstByUserNameAndApiKeyAndIsActiveOrderByIdDesc(
				apiRequest.getUsername(), apiRequest.getApiKey(), true);
		if (apiUser != null) {
			/* CHECK IP IS WHITELISTED OR NOT */
			if (APIAuthUtils.isClientIpMatched(request, apiUser.getIps())) {
				request.setAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID, apiUser.getId());
				return success(request, response, apiUser);
			} else {
				String fromIP = "";
				if (request.getAttribute(APIAuthUtils.REQ_ATR_IPS_FAILED) != null) {
					fromIP = String.valueOf(request.getAttribute(APIAuthUtils.REQ_ATR_IPS_FAILED));
				}
				log.error(apiUser.getId() + " IP NOT WHITELISTED ----------------- :-" + request.getRequestURI()
						+ "--------" + fromIP);
				logService.failureLogs(request, "IP is not whitelisted", apiUser);
				return failed(response);
			}
		} else {
			log.error("USER NOT FOUND ----------------- :-" + request.getRequestURI());
			logService.failureLogs(request, "API user not found", null);
			return failed(response);
		}
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		request.setAttribute(APIAuthUtils.RESPONSE_TIME, new Date().getTime());
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable Exception ex) throws Exception {
		// SKIP SWAGGER URLS
		if (request.getAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER) != null) {
			return;
		}
		if (request.getAttribute(APIAuthUtils.REQ_ATR_IS_ACTUATOR) != null) {
			return;
		}
		// ONLY AUTHENTICATE REQUEST ALLOW FOR AUDIT BY API USER TABLE
		if (OPLUtils.isObjectNullOrEmpty(request.getAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID))) {
			return;
		}

		handleDecrypReqError(request, response);

		/* SAVE AUDIT */
		auditHandler(request, response, ex);

		/* AFTER AUDIT REMOVE VALUES FROM SERVLET */
		request.removeAttribute(APIAuthUtils.REQUEST_RECEIVED_TIME);
		request.removeAttribute(APIAuthUtils.REQUEST_PLAIN_BODY);
		request.removeAttribute(APIAuthUtils.RESPONSE_PLAIN_BODY);
		request.removeAttribute(APIAuthUtils.RESPONSE_ENCRYPT_BODY);
		request.removeAttribute(APIAuthUtils.RESPONSE_STATUS);
		request.removeAttribute(APIAuthUtils.RESPONSE_TIME);
		request.removeAttribute(APIAuthUtils.REQ_ATR_ORG_ID);
		request.removeAttribute(APIAuthUtils.REQ_ATR_TOKEN);
		request.removeAttribute(AuthCredentialUtils.REQUEST);
		request.removeAttribute(APIAuthUtils.REQ_ATR_DEC_FAILED);
		request.removeAttribute(AuthCredentialUtils.DEC_FAILED_RES_ADDED);
		request.removeAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER);
		request.removeAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID);
		request.removeAttribute(AuthCredentialUtils.SESSION_OBJ_KEY);
		request.removeAttribute(APIAuthUtils.REQ_ATR_LOG_ID);
		request.removeAttribute(AuthCredentialUtils.SCHEME_ID);
		request.removeAttribute(AuthCredentialUtils.MESSAGE);
		request.removeAttribute(APIAuthUtils.REQ_ATR_IPS_FAILED);
		request.removeAttribute(APIAuthUtils.DECRYPTION_MSG);
		request.removeAttribute(APIAuthUtils.REQ_REF_NUMBER);
	}

	private Boolean success(HttpServletRequest request, HttpServletResponse response, ApiUsers apiUsers)
			throws IOException {

		// FOR SBI NEED TO ADD REQUEST REFERENCE NUMNER IN HEADER
		if (!OPLUtils.isObjectNullOrEmpty(apiUsers.getOrganizationMaster().getOrgId())) {
			request.setAttribute(APIAuthUtils.REQ_ATR_ORG_ID, apiUsers.getOrganizationMaster().getOrgId());
			if (apiUsers.getOrganizationMaster().getOrgId() == APIAuthUtils.SBI_ORG_ID
					&& !OPLUtils.isObjectNullOrEmpty(request.getHeader(APIAuthUtils.REQ_REF_NUMBER))) {
				request.setAttribute(APIAuthUtils.REQ_REF_NUMBER, request.getHeader(APIAuthUtils.REQ_REF_NUMBER));
			}
		}
		return true;
	}

	private Boolean failed(HttpServletResponse response) {
//		log.warn("Unauthorized Request, Invalid Access");
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		return false;
	}

	private void auditHandler(HttpServletRequest request, HttpServletResponse response, Exception ex)
			throws ParseException, IOException {

		/* PREPARE REQUEST INFORMATION IN CLASS */
		PreRequestLogs reqLogs = prepareLogs(request);

		/* SET REQUESTED TIME */
		Long createdDate = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.REQUEST_RECEIVED_TIME, Long.class);
		if(!OPLUtils.isObjectNullOrEmpty(createdDate)) {
			reqLogs.setCreatedDate(new Date(createdDate));
		}

		/* SET RESPONES TIME */
		Long responseDate = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.RESPONSE_TIME, Long.class);
		if(!OPLUtils.isObjectNullOrEmpty(responseDate)) {
			reqLogs.setResponseDate(new Date(responseDate));
		}

		if(!OPLUtils.isObjectNullOrEmpty(responseDate) && !OPLUtils.isObjectNullOrEmpty(createdDate)) {
			reqLogs.setResponseTime(responseDate - createdDate);
		}

		/*
		 * FETCH API USER ID FROM REQUEST ATTRIBUTE (SET FROM INTERCEPTOR PREHANDLE
		 * METHOD)
		 */
		Long apiUserId = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.REQ_ATR_APP_USER_ID, Long.class);
		ApiUsers apiUser = null;
		if(!OPLUtils.isObjectNullOrEmpty(apiUserId)) {
			apiUser = apiUsersRepository.findById(apiUserId).get();
			reqLogs.setApiUserId(apiUser.getId());
			reqLogs.setOrgId(!OPLUtils.isObjectNullOrEmpty(apiUser.getOrganizationMaster())
					? apiUser.getOrganizationMaster().getOrgId()
					: null);
		}

		reqLogs.setRequestUrl(request.getRequestURI());
		reqLogs.setRequestHeader(reqLogs.getRequestHeader());
		reqLogs.setEncryptedRequest(getRequestAttribute(APIAuthUtils.REQUEST_ENCRYPT_BODY, request));
		reqLogs.setPlainRequest(getRequestAttribute(APIAuthUtils.REQUEST_PLAIN_BODY, request));
		reqLogs.setEncryptedResponse(getRequestAttribute(APIAuthUtils.RESPONSE_ENCRYPT_BODY, request));
		reqLogs.setPlainResponse(getRequestAttribute(APIAuthUtils.RESPONSE_PLAIN_BODY, request));
		/* SET REQ TOKEN */
		String requestAttribute = getRequestAttribute(APIAuthUtils.REQ_REF_NUMBER, request);
		requestAttribute = !OPLUtils.isObjectNullOrEmpty(requestAttribute) && !PhaseMode.checkPhase2Enroll(reqLogs.getOrgId()) ? requestAttribute : getRequestAttribute(APIAuthUtils.REQ_ATR_TOKEN, request);
		reqLogs.setReqToken(requestAttribute);
		String storageId = getRequestAttribute(APIAuthUtils.STORAGE_ID, request);
		if(!OPLUtils.isObjectNullOrEmpty(storageId)) {
			reqLogs.setStorageId(Long.valueOf(storageId));
		}

		/* IN CASE OF ERROR RECEIVED */
		if (!OPLUtils.isObjectNullOrEmpty(ex)) {
			reqLogs.setError(ExceptionUtils.getStackTrace(ex));
		}

		Integer resStatus = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.RESPONSE_STATUS, Integer.class);
		if (OPLUtils.isObjectNullOrEmpty(resStatus)) {
			reqLogs.setResponseStatus(response.getStatus());
		} else {
			reqLogs.setResponseStatus(resStatus);
		}
		/* MEANS DECRYPTION ERROR */
		String msg = getRequestAttribute(APIAuthUtils.DECRYPTION_MSG, request);
		if (!OPLUtils.isObjectNullOrEmpty(msg)) {
			reqLogs.setMessage(msg);
		}
		/* INSERT LOGS */
		logService.insertRequestLogs(reqLogs, apiUser);
	}

	public String getRequestAttribute(String attributeName, HttpServletRequest request) {
		Object attributeVal = request.getAttribute(attributeName);
		if (!OPLUtils.isObjectNullOrEmpty(attributeVal)) {
			return attributeVal.toString();
		}
		return null;
	}

	private Map<String, String> getHeaders(HttpServletRequest servletRequest) {
		Enumeration<String> headerNames = servletRequest.getHeaderNames();
		Map<String, String> requestHeader = new HashMap<>();
		if (!OPLUtils.isObjectNullOrEmpty(headerNames)) {
			while (headerNames.hasMoreElements()) { // For Set Request Header
				String key = headerNames.nextElement();
				String value = servletRequest.getHeader(key);
				requestHeader.put(key, value);
			}
		}
		return requestHeader;
	}

	private PreRequestLogs prepareLogs(HttpServletRequest servletReq) {
		PreRequestLogs reqLog = new PreRequestLogs();
		reqLog.setContextPath(servletReq.getContextPath());
		reqLog.setRequestUrl(servletReq.getRequestURI());
		reqLog.setRequestIp(String.valueOf(servletReq.getAttribute(APIAuthUtils.REQ_ATR_IPS)));
		reqLog.setCreatedDate(new Date());
		reqLog.setRequestHeader(getHeaders(servletReq).toString());
		reqLog.setApiKey(servletReq.getHeader(APIAuthUtils.REQ_HEADER_API_KEY));
		reqLog.setUserName(servletReq.getHeader(APIAuthUtils.REQ_HEADER_USERNAME));
		return reqLog;
	}

	/**
	 * HANDLE DECRYP REQUEST ERROR
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	private boolean handleDecrypReqError(HttpServletRequest request, HttpServletResponse response) {
		if (OPLUtils.isObjectNullOrEmpty(request.getAttribute(APIAuthUtils.REQ_ATR_DEC_FAILED))) {
			return true;
		}
		ApiUsers apiUsers = null;
		try (OutputStream stream = response.getOutputStream()) {
			CommonResponse commonResponse = new CommonResponse();
			commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			commonResponse.setMessage("Failed to read request");
			if (request.getHeader(APIAuthUtils.REQ_HEADER_ENCRYPTION_SKIP) != null
					&& request.getHeader(APIAuthUtils.REQ_HEADER_ENCRYPTION_SKIP).toString().equals("true")) {
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				String resp = MultipleJSONObjectHelper.getStringfromObject(commonResponse);
				request.setAttribute(APIAuthUtils.RESPONSE_PLAIN_BODY, resp);
				byte[] jsonRes = resp.getBytes("UTF-8");
				stream.write(jsonRes);
				stream.flush();
			} else {
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				Long apiUserId = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.REQ_ATR_APP_USER_ID, Long.class);
				apiUsers = apiUsersRepository.findById(apiUserId).get();
				String s = MultipleJSONObjectHelper.getStringfromObject(commonResponse);
				request.setAttribute(APIAuthUtils.RESPONSE_PLAIN_BODY, s);
//				preReqLogs.setPlainResponse(s);
				SymAsymEncryption symAsymEncryption = new SymAsymEncryption();
				String encData = symAsymEncryption.encrypt(s, SymAsymEncryption.OPL_PRIVATE_KEY,
						apiUsers.getPublicKey());
				Map<String, Object> responseMap = new HashMap<String, Object>();
				responseMap.put(AuthCredentialUtils.META_DATA, encData);
				String res = MultipleJSONObjectHelper.getStringfromObject(responseMap);
				request.setAttribute(APIAuthUtils.RESPONSE_ENCRYPT_BODY, res);
//				preReqLogs.setResponseResult(res);
				stream.write(res.getBytes("UTF-8"));
				stream.flush();
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		}
		return false;
	}

}
