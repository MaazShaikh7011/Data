package com.opl.jns.published.lib.domain;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "api_config_master", indexes = {},catalog = "JNS_CONFIG",schema = "JNS_CONFIG")
public class ApiConfigMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_config_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "api_config_master_seq_gen", sequenceName = "api_config_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "code", nullable = true)
	private String code;
	@Column(name = "value", nullable = true)
	private String value;
	@Column(name = "is_active", nullable = true)
	private Boolean isActive;


	// API CONSTANT
	@Transient
	public static Long APPLICATION_CALL_RESTRICTION = 1l;
	@Transient
	public static Long COI_URL = 2l;
	@Transient
	public static Long TOKEN_EXPIRES_TIME = 3l;
	@Transient
	public static Long IS_SAVE_REQ_RES_FOR_PUBLISH = 4l;

}
