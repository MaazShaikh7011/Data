package com.opl.jns.published.lib.domain;

import java.io.Serializable;
import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author ravi.thummar 10/5/2023
 */
/* CREATED DATE 22 NOV */
@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "api_storage_dec", indexes = {})
public class APIStorage implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_storage_dec_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "api_storage_dec_seq_gen", sequenceName = "api_storage_dec_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "log_audit_id", nullable = true)
	private Long logAudit;

	@Column(name = "storage_id", nullable = true)
	private String storageId;

	@Column(name = "type_id", nullable = true)
	private Integer typeId;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	public APIStorage() {
		super();
	}

	public APIStorage(String token) {
		super();
		this.createdDate = new Date();
	}

}
