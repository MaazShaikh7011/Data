package com.opl.jns.published.lib.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.persistence.AttributeConverter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateEncrypterAes implements AttributeConverter<Date, String> {

//    public DateEncrypterAes() {
//    }
//    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public String convertToDatabaseColumn(Date attribute) {
        try {
            if (attribute != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return AESEncryption.encrypt(sdf.format(attribute));
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }

        return null;
    }

    public Date convertToEntityAttribute(String dbData) {
        try {
            if (dbData != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dateStr = AESEncryption.decrypt(dbData);
//                log.info("decrypted date  => [{}]",dateStr);
                return sdf.parse(dateStr);
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }

        return null;
    }

//    public static void main(String[] args) {
//        String s = "8V5DBbMXocTzu9NFAu7CnUryD8xZcJJ91MkntZAvMuI=";
//        DateEncrypterAes aes = new DateEncrypterAes();
//        aes.convertToEntityAttribute(s);
//    }
}
