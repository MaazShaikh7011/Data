//package com.opl.jns.published.lib.service;
//
//
//import com.opl.jns.published.lib.domain.*;
//
///**
// * @author jaimin.darji
// * 5/4/2021
// */
//public interface RequestLogService {
//
//    public static final int REQUEST = 1;
//
//    public static final int RESPONSE = 2;
//
//    public void logError(ErrorLog errorLog);
//}
