package com.opl.jns.published.lib.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * SET KEY VALUE NULL FROM JSON STRING
 * 
 * @author harshit.suhagiya
 * @date 11-Sep-2023
 */
@Slf4j
public class OPLJSONUtils {

	private static final String GET_OBJECT_EXC = "EXCEPTION WHILE GET OBJECT USING KEY - ";
	private static final String SET_NULL_VALUE_EXC = "EXCEPTION WHILE SET NULL VALUE IN JSON - ";

	/**
	 * FETCH OBJECT FROM JSON STRING USING KEY
	 * 
	 * @param json
	 * @param key
	 * @return
	 */
	public static String getObjectUsingKey(String json, String key) {
		try {
			// PARSE THE JSON STRING
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(json);

			/// GET THE OBJECT ASSOCIATED WITH THE TARGET KEY
			JsonNode targetObject = jsonNode.get(key);

			// CONVERT THE EXTRACTED OBJECT BACK TO A JSON STRING (OPTIONAL)
			return objectMapper.writeValueAsString(targetObject);
		} catch (Exception e) {
			log.error(GET_OBJECT_EXC, e);
		}
		return json;
	}

	/**
	 * SET NULL VALUE IN JSON STRING USING KEY
	 * 
	 * @param json
	 * @param keys
	 * @return
	 */
	public static String setNull(String json, String... keys) {
		try {
			// PARSE THE JSON STRING
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(json);

			// RECURSIVELY SET THE KEY'S VALUE TO NULL
			String[] key = keys;
			for (String k : key) {
				recursivelySetNull(jsonNode, k);
			}
			// CONVERT THE MODIFIED JSON BACK TO A STRING
			return objectMapper.writeValueAsString(jsonNode);
		} catch (Exception e) {
			log.error(SET_NULL_VALUE_EXC, e);
		}
		return json;
	}

	private static void recursivelySetNull(JsonNode node, String targetKey) {
		if (node.isObject()) {
			// IF THE NODE IS AN OBJECT, ITERATE THROUGH ITS FIELDS
			node.fields().forEachRemaining(entry -> {
				if (entry.getKey().equals(targetKey)) {
					((com.fasterxml.jackson.databind.node.ObjectNode) node).putNull(targetKey);
				} else {
					recursivelySetNull(entry.getValue(), targetKey);
				}
			});
		} else if (node.isArray()) {
			// IF THE NODE IS AN ARRAY, ITERATE THROUGH ITS ELEMENTS
			node.elements().forEachRemaining(element -> recursivelySetNull(element, targetKey));
		}
	}

}
