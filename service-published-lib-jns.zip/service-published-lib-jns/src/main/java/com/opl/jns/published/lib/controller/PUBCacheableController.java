package com.opl.jns.published.lib.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.published.lib.utils.SkipInterceptor;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PUBCacheableController {

	@Autowired
	private CacheManager cacheManager;

	@SkipInterceptor
	@GetMapping(value = "/clearCachePUB")
	public String clearCache() {
		for (String name : cacheManager.getCacheNames()) {
			cacheManager.getCache(name).clear();
			log.info("{} CACHE CLEARED", name);
		}
		log.info("ALL CACHE CLEARED ON {}", new Date());
		return "ALL CACHE CLEARED";
	}

}
