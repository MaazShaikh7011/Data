package com.opl.jns.published.lib.utils;

public enum ConfigType {
    BANK_CONFIG(1),
    INSURER_CONFIG(2);

    int configType;

    ConfigType(int configType){
        this.configType = configType;
    }

    public int getConfigType() {
        return configType;
    }
}
