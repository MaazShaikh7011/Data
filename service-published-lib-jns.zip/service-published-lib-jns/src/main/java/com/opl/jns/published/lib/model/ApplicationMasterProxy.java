package com.opl.jns.published.lib.model;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ApplicationMasterProxy implements Serializable {
	
	private final static long serialVersionUID = 6208189995076386414L;
	
	@NotNull
	@Schema(allowableValues = { "True", "False" })
    public Boolean deDupeStatus;
    @NotNull
    @Size(min = 0, max = 255)
    public String deDupeMsg;
    
    @NotNull
    @Size(min = 21, max = 32)
    public String urn;    
    
}