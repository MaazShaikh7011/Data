package com.opl.jns.published.lib.utils;

import java.util.Date;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author jaimin.darji 5/5/2021
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PreRequestLogs {

	private Long id;
	private String contextPath;
	private String requestUrl;
	private String requestHeader;
	private String encryptedRequest;
	private String plainRequest;
	private String encryptedResponse;
	private String plainResponse;
	private String error;

	private String requestArgs;
	private String requestIp;
	private Long orgId;
	private String responseHeader;
	private Integer responseStatus;
	private String failureReason;
	private String responseResult;
	private Long responseTime; // milliseconds
	private Date createdDate;
	private Date responseDate;
	private Long apiUserId;
	private Long applicationReferenceId;
	private String reqRefNum;
	private String apiKey;
	private String userName;
	private String message;
	private String urn;
	private String accountNumber;
	private String secretKey;
	private Map<String, String> reqHeader;
	private String reqToken;
	private Long storageId;
	
	public PreRequestLogs(Long orgId, Long apiUserId,Long applicationReferenceId,Date createdDate,String reqRefNum,String urn,String accountNumber, String reqToken) {
		super();
		this.orgId = orgId;
		this.apiUserId = apiUserId;
		this.applicationReferenceId=applicationReferenceId;
		this.createdDate=createdDate;
		this.reqRefNum=reqRefNum;
		this.urn=urn;
		this.accountNumber=accountNumber;
		this.reqToken=reqToken;
	}

	
	
	
}
