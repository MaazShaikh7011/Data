/*package com.opl.jns.published.lib.controller;


import com.opl.jns.published.lib.utils.*;
import org.json.simple.*;
import org.slf4j.*;
import org.springframework.web.bind.annotation.*;

@RestController
public class PingController {

	private static final Logger logger = LoggerFactory.getLogger(PingController.class);

	@SkipInterceptor
	@GetMapping(value = "/ping")
	public JSONObject ping() {
		logger.info("CHECK SERVICE STATUS =====================>");
		JSONObject obj = new JSONObject();
		obj.put("status", 200);
		obj.put("message", "Service is working fine!!");
		return obj;
	}

}
*/
