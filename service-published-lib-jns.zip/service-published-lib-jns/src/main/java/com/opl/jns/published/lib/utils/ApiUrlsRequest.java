package com.opl.jns.published.lib.utils;


import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiUrlsRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String baseUrl;
	private String triggerOtp;
	private String verifyOtp;
	private String customerDetails;
	private String premiumDeduction;
	private String physicalVerification;
	private String checkDedupe;
	private String pushEnrollment;
	private String pushClaim;
	private String updateClaimStatus;

}
