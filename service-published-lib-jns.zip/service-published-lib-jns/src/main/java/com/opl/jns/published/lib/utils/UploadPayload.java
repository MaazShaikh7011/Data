package com.opl.jns.published.lib.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.jns.published.lib.domain.APILogs;
import com.opl.jns.published.lib.domain.APIStorage;
import com.opl.jns.published.lib.model.PayloadStorageProxy;
import com.opl.jns.published.lib.repository.PayloadAuditRepository;
import com.opl.jns.published.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UploadPayload {

	@Autowired
	private PayloadAuditRepository payloadAuditRepo;

	@Autowired
	private BucketStorageUtils bucketStorageUtils;

	/**
	 * SAVE REQUEST AND RESPONSE LOGS IN S3 BUCKET
	 * 
	 * @param reqLogAudit
	 * @param type
	 * @param preReqLog
	 */
	@Async
	public void updateReqResS3(APILogs reqLogAudit, int type, PreRequestLogs preReqLog) {

		// WRITE CODE FOR SAVING PAYLOAD IN S3 BUCKET
		APIStorage reqResAudit = new APIStorage(reqLogAudit.getToken());
		reqResAudit.setLogAudit(reqLogAudit.getId());
		reqResAudit.setTypeId(type);

		String generateUUID = OPLUtils.generateUUID();

		PayloadStorageProxy payStrgProxy = new PayloadStorageProxy();
		payStrgProxy.setReqLogAuditId(reqLogAudit.getId());
		payStrgProxy.setReferenceId(generateUUID);
//		payStrgProxy.setType(type);
		if (APIAuthUtils.PAYLOAD_TYPE_REQ == type) {
			payStrgProxy.setHeader(preReqLog.getRequestHeader());
			payStrgProxy.setPlainPayload(preReqLog.getRequestArgs());
			payStrgProxy.setEncryptPayload(preReqLog.getPlainRequest());
		} else {
			payStrgProxy.setHeader(preReqLog.getResponseHeader());
			payStrgProxy.setPlainPayload(preReqLog.getResponseResult());
			payStrgProxy.setEncryptPayload(preReqLog.getPlainResponse());
		}
		bucketStorageUtils.upload(EnvironmentUtils.REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME.getValue(), payStrgProxy,
				generateUUID);
		reqResAudit.setStorageId(generateUUID);
//		reqResAudit.setPayload("null");
		payloadAuditRepo.save(reqResAudit);
	}

	@Async
	public void insertReqResS3(APILogs reqLogAudit, PreRequestLogs preReqLog) {
		// WRITE CODE FOR SAVING PAYLOAD IN S3 BUCKET
		APIStorage reqResAudit = new APIStorage(reqLogAudit.getToken());
		reqResAudit.setLogAudit(reqLogAudit.getId());

		String generateUUID = OPLUtils.generateUUID();

		/* PREPARING REQUEST TO UPLOAD */
		PayloadStorageProxy payStrgProxy = preparePayloadStorageProxy(reqLogAudit, preReqLog, generateUUID);

		/* UPLOAD */
		bucketStorageUtils.upload(EnvironmentUtils.REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME.getValue(), payStrgProxy, generateUUID);

		/* SAVE LOGS */
		reqResAudit.setStorageId(generateUUID);
		payloadAuditRepo.save(reqResAudit);
	}

	private static PayloadStorageProxy preparePayloadStorageProxy(APILogs reqLogAudit, PreRequestLogs preReqLog, String generateUUID) {
		PayloadStorageProxy payStrgProxy = new PayloadStorageProxy();
		payStrgProxy.setReqLogAuditId(reqLogAudit.getId());
		payStrgProxy.setReferenceId(generateUUID);
		payStrgProxy.setHeader(preReqLog.getRequestHeader());
		payStrgProxy.setPlainPayload(preReqLog.getPlainRequest());
		payStrgProxy.setEncryptPayload(preReqLog.getEncryptedRequest());
		payStrgProxy.setEncryptResponse(preReqLog.getEncryptedResponse());
		payStrgProxy.setPlainResponse(preReqLog.getPlainResponse());
		payStrgProxy.setError(preReqLog.getError());
		payStrgProxy.setSecretKey(preReqLog.getSecretKey());
		payStrgProxy.setUrl(preReqLog.getRequestUrl());
		return payStrgProxy;
	}


	/**
	 * SAVE REQUEST AND RESPONSE LOGS IN ORACLE DB
	 * 
	 * @param reqLogAudit
	 * @param type
	 * @param preReqLog
	 */
//	@Async
//	public void updateReqResOracle(RequestLogAudit reqLogAudit, int type, PreRequestLogs preReqLog) {
//		PayloadAudit reqResAudit = new PayloadAudit(reqLogAudit.getToken());
//		reqResAudit.setLogAudit(reqLogAudit.getId());
//		reqResAudit.setTypeId(type);
//
//		if (APIAuthUtils.PAYLOAD_TYPE_REQ == type) {
//			reqResAudit.setPayloadHeader(preReqLog.getRequestHeader());
//			reqResAudit.setPayloadParams(preReqLog.getRequestArgs());
//			reqResAudit.setPayload(preReqLog.getPlainRequest());
//		} else {
//			reqResAudit.setPayloadHeader(preReqLog.getResponseHeader());
//			reqResAudit.setPayloadParams(preReqLog.getResponseResult());
//			reqResAudit.setPayload(preReqLog.getPlainResponse());
//		}
//		if (OPLUtils.isObjectNullOrEmpty(reqResAudit.getPayload())) {
//			reqResAudit.setPayload("null");
//		}
//		payloadAuditRepo.save(reqResAudit);
//	}
}
