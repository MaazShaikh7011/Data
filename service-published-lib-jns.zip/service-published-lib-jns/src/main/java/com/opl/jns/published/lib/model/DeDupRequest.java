package com.opl.jns.published.lib.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DeDupRequest implements Serializable {

	public String token;
    public String accNo;
    public String cif;
    public String urn;
    public Long applicationReferenceId;
    public String accountNumber;
    
    private final static long serialVersionUID = -9020492356609251905L;

}
