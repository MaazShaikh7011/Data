package com.opl.jns.published.lib.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 8/3/2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class HttpApiResponse {
    int status;
    String response;
    String errorResponse;

}
