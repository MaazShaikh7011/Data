package com.opl.jns.published.lib.model;

import java.io.Serializable;

//@Setter
//@Getter
public class PayloadStorageProxy implements Serializable {

	private static final long serialVersionUID = 54654684321351L;

	private Long reqLogAuditId;
	private String referenceId;
	private String header;
	private String url;
	private String secretKey;
	private String plainPayload;
	private String encryptPayload;
	private String plainResponse;
	private String encryptResponse;
	private String error;
	

	public Long getReqLogAuditId() {
		return reqLogAuditId;
	}

	public void setReqLogAuditId(Long reqLogAuditId) {
		this.reqLogAuditId = reqLogAuditId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getPlainPayload() {
		return plainPayload;
	}

	public void setPlainPayload(String plainPayload) {
		this.plainPayload = plainPayload;
	}

	public String getEncryptPayload() {
		return encryptPayload;
	}

	public void setEncryptPayload(String encryptPayload) {
		this.encryptPayload = encryptPayload;
	}

	public String getPlainResponse() {
		return plainResponse;
	}

	public void setPlainResponse(String plainResponse) {
		this.plainResponse = plainResponse;
	}

	public String getEncryptResponse() {
		return encryptResponse;
	}

	public void setEncryptResponse(String encryptResponse) {
		this.encryptResponse = encryptResponse;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

}
