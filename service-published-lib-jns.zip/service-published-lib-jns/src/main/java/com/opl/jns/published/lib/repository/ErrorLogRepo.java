package com.opl.jns.published.lib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.published.lib.domain.ErrorLog;

public interface ErrorLogRepo extends JpaRepository<ErrorLog,Long> {
}
