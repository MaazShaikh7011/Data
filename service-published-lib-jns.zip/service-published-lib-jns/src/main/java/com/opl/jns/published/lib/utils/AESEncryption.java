package com.opl.jns.published.lib.utils;


import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import jakarta.persistence.AttributeConverter;

public class AESEncryption implements AttributeConverter<String, String> {

	private static final String ALGORITHM = "AES";
	private static final String KEY = "opl@pub#jns!#AES";
	private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
	public static final String ASCII = "ASCII";
//	private  static Cipher cipher = null;
//
//	static{
//		try {
//			cipher = Cipher.getInstance(TRANSFORMATION);
//		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//			throw new RuntimeException(e);
//		}
//	}

    public static String encrypt(String data) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
    	byte[] keyBytes = Arrays.copyOf(KEY.getBytes(ASCII), 16);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keyBytes, ALGORITHM),new IvParameterSpec(keyBytes));
        byte[] encryptedBytes = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return new String(Base64.getEncoder().encodeToString(encryptedBytes));
    }

    public static String decrypt(String encryptedData) throws Exception {
		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
    	byte[] keyBytes = Arrays.copyOf(KEY.getBytes(ASCII), 16);
		cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyBytes, ALGORITHM),new IvParameterSpec(keyBytes));
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }

	@Override
	public String convertToDatabaseColumn(String attribute) {
		try {
			if(attribute!= null) {
				return encrypt(attribute);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		try {
			if(dbData!= null) {
				return decrypt(dbData);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
}