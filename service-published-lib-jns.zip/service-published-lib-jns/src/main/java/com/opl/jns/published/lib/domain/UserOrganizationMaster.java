package com.opl.jns.published.lib.domain;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "user_organisation_master", indexes = {
		@Index(columnList = "org_id,is_active",name = "USR_ORG_MST_ORG_ACT")
},catalog = "JNS_CONFIG",schema = "JNS_CONFIG")
public class UserOrganizationMaster implements Serializable {

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_organisation_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "user_organisation_master_seq_gen", sequenceName = "user_organisation_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "organisation_name", nullable = true)
	private String organisationName;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@Column(name = "display_org_name", nullable = true)
	private String displayOrgName;

	@Column(name = "user_type_id", nullable = true)
	private Long userTypeId;

	@Column(name = "org_type", nullable = true)
	private Long orgType;

	@Column(name = "code", nullable = true)
	private String bankCode;

	@OneToMany(mappedBy = "organizationMaster")
	private List<ApiUsers> apiUsers;
	
	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "is_reverse_api_activated", nullable = true)
	private Boolean isReverseApiActivated;
	

	
}
