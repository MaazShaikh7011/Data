package com.opl.jns.published.lib.repository;

public interface ApiAuditRepo {

	String fetchTotalCount(String query);
	
	String fetchList(String query);

	
}
