package com.opl.jns.published.lib.service.impl;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.repository.ApiUsersRepository;
import com.opl.jns.published.lib.service.PublishedLibService;
import com.opl.jns.published.lib.utils.ApiUrlsRequest;
import com.opl.jns.published.lib.utils.ConfigType;
import com.opl.jns.published.lib.utils.HttpApiResponse;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.common.SymAsymEncryption;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 8/3/2023
 */
@Service
@Slf4j
public class PublishedLibServiceImpl implements PublishedLibService {
    @Autowired
    ApiUsersRepository apiUsersRepository;

    public static final String STATUS = "status";
    public static final String RESPONSE = "response";
    public static final String METADATA = "metadata";
    public static final int INT_1 = 1;
    public static final int INT_2 = 2;
    public static final RestTemplate restTemplate = new RestTemplate();

    public static final SymAsymEncryption symAsymEncryption = new SymAsymEncryption();


    public <T>T decryptResponse(String response,Long apiUserId,Class<?> classType) throws InvalidAlgorithmParameterException, IllegalBlockSizeException, NoSuchPaddingException, IOException, NoSuchAlgorithmException, BadPaddingException, InvalidKeySpecException, SignatureException, InvalidKeyException, NoSuchProviderException, CertificateException {
        try {
            ApiUsers oplUser = apiUsersRepository.findFirstByIsInternalUserTrue();
            ApiUsers apiUser = apiUsersRepository.findById(apiUserId).orElse(null);
            if(OPLUtils.isObjectNullOrEmpty(apiUser)){
                return null;
            }
            String plainResp = symAsymEncryption.decrypt(response,oplUser.getPrivateKey(),apiUser.getPublicKey());
            log.info("Response Decrypted : {}",plainResp);
            return MultipleJSONObjectHelper.getObjectFromString(plainResp,classType);
        }catch (Exception e){
            log.info("Exception in decrypting the request : ",e);
            throw e;
        }

    }

    public String encryptRequest(Object request) throws InvalidAlgorithmParameterException, IllegalBlockSizeException, NoSuchPaddingException, IOException, NoSuchAlgorithmException, BadPaddingException, InvalidKeySpecException, SignatureException, InvalidKeyException, NoSuchProviderException {
        try {
            ApiUsers oplUser = apiUsersRepository.findFirstByIsInternalUserTrue();
            String s = MultipleJSONObjectHelper.getStringfromObject(request);
            return  symAsymEncryption.encrypt(s, oplUser.getPrivateKey(), oplUser.getPublicKey());
        }catch (Exception e){
            log.info("Exception in encrypting the request : ",e);
            throw e;
        }

    }

    public <T>T callService(Long orgId,Long apiUserId,Object commonRequest,ConfigType type,Class<?> typeClass){
     try {
         ApiUsers apiUser = apiUsersRepository.findFirstByOrganizationMasterOrgIdAndConfigType(orgId, type.getConfigType());
         HttpApiResponse response ;
         if (OPLUtils.isObjectNullOrEmpty(apiUser)) {
             return null;
         }
         // getting header from db if any
         Map<String, String> headers = (!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(apiUser.getHeaderConfig()) ? com.opl.jns.utils.common.MultipleJSONObjectHelper.getObjectFromString(apiUser.getHeaderConfig(), Map.class) : Collections.EMPTY_MAP);
         ApiUrlsRequest apiUrlsRequest = null != apiUser.getUrlConfig() ? com.opl.jns.utils.common.MultipleJSONObjectHelper.getObjectFromString(apiUser.getUrlConfig(), ApiUrlsRequest.class) : null;

         // construct url
         String url = apiUrlsRequest.getBaseUrl().concat(apiUrlsRequest.getUpdateClaimStatus());

         // prepare request body
         Map<String, String> encryptedReq = new HashMap<>(INT_1);
         encryptedReq.put(METADATA, encryptRequest(commonRequest));

         // call service
         response = httpServiceCall(url, encryptedReq, headers);
         log.info("Status : {}", response.getStatus());
         log.info("Response  : {}", response.getResponse());
         log.info("Error Message : {}", response.getErrorResponse());

         if (response.getStatus() == HttpStatus.OK.value() && null == response.getErrorResponse()) {
             //decode response
             return decryptResponse(response.getResponse(), apiUserId, typeClass);
         }


     }catch (Exception e){
        log.error("Excepting in encrypting the request for calling API : ",e);
     }finally {

     }

     return null;
    }






    public HttpApiResponse httpServiceCall(String url, Object commonRequest, Map<String, String> headerMap) throws  IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if(!com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(headerMap)) {
            headers.setAll(headerMap);
        }
        HttpEntity<Object> entity = new HttpEntity<>(commonRequest, headers);
        log.info("URL is :[{}]", url);
        log.info("Encrypted Request is :{}", com.opl.jns.utils.common.MultipleJSONObjectHelper.getStringfromObject(entity));

        HttpApiResponse response = new HttpApiResponse();
        try {
            ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            response.setStatus(exchange.getStatusCodeValue());
            response.setResponse(exchange.getBody());
        } catch(HttpStatusCodeException e) {
            log.info("status code received in exception [{}] ===> ",e.getStatusCode().value());
            ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
            response.setStatus(resp.getStatusCode().value());
            response.setResponse(resp.getBody());

            if(e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
                    || e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE){
                response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
            }

            log.info("resp.getStatusCode().value() ==>  [{}] ===> ",resp.getStatusCode().value());
        } catch (ResourceAccessException  http) {
            log.info("http.getCause() TIMEOUT ===> ",http.getCause());
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            if(http.getCause() instanceof SocketTimeoutException){
                response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
                response.setErrorResponse(http.getCause().getLocalizedMessage());
            }
        }
        log.info("Response status [{}] received from url [{}] ", response.getStatus(), url);
        return response;
    }

}
