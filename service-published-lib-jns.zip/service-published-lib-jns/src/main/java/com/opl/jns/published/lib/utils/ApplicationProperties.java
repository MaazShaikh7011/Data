package com.opl.jns.published.lib.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "com.jns.common.config")
public class ApplicationProperties {

	// DB CONFIGURATION PROPERTIES
	private String dbDriver;
	private String dbUrl;
	private String dbUrlPushPull;
	private String dbMaxConnections;
	private String dbMinConnections;
	private String dbMaxPartitions;
	private String dbMaxLifetimeInMillis;
	private String dbConnectionTimeoutInMillis;

	// HIBERNATE PROPERTIES
	private String hibernateDialect;
	private String hibernateFormatSql;
	private String hibernateHbm2ddl;
	private String hibernateEJBNamingStrategy;
	private String hibernateShowSql;
	private String hibernateEnableLazyLoadNoTrans;
	private String hibernateParamNullPassing;

	// DOMAIN AND REPOSITORY PROPERTIES
	private String domainPackageName;
	private String domainPackageNamePushPull;
	private String repositoryPackageName;
	private String repositoryPackageNamePushPull;


	/**
	 * Oracle Configuration for insurance
	 */
	private String insuranceHibernateHbm2ddlOrcl;
	private String insuranceDbNameOrcl;
	private String insuranceDbPassOrcl;
	private String insuranceDomainPackageNameOrcl;

	/**
	 * Oracle Configuration for Publish API
	 */
	private String publishApiHibernateHbm2ddlOrcl;
	private String publishApiDbNameOrcl;
	private String publishApiDbPassOrcl;
	private String publishApiDomainPackageNameOrcl;



	/*
	*  SET BATCH INSERT & UPDATE PROPERTIES
	* */
	private String hibernateOrderInserts;
	private String hibernateOrderUpdates;
	private String hibernateGenerateStatistics;
	private String hibernateBatchVersionedData;
	private String hibernateJdbcBatchSize;
}
