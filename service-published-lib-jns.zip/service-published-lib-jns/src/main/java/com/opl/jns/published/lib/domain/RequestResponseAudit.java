package com.opl.jns.published.lib.domain;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.annotations.ColumnTransformer;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author ravi.thummar 10/5/2023
 */

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "request_response_audit", indexes = {})
public class RequestResponseAudit implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "request_response_audit_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "request_response_audit_seq_gen", sequenceName = "request_response_audit_seq_gen", allocationSize = 1)
	private Long id;

//    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    @JoinColumn(name = "log_audit_id")
//    private RequestLogAudit logAudit;

	@Column(name = "log_audit_id", nullable = true)
	private Long logAudit;

	@Lob
	@Column(name = "request_header", nullable = true)
	private String requestHeader;

	@Lob
	@Column(name = "request_params", nullable = true)
	private String requestParams;

	@Lob
	@Column(name = "response_header", nullable = true)
	private String responseHeader;

	@Lob
	@Column(name = "response_result", nullable = true)
	private String responseResult;

	@ColumnTransformer(read = "OPLUNCOMPRESS(response)", write = "OPLCOMPRESS(?)")
	@Column(name = "response", columnDefinition = "blob ")
	private String response;

	@ColumnTransformer(read = "OPLUNCOMPRESS(request)", write = "OPLCOMPRESS(?)")
	@Column(name = "request", columnDefinition = "blob ")
	private String request;

	@Column(name = "token", nullable = true)
	private String token;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	public RequestResponseAudit() {
		super();
	}

	public RequestResponseAudit(String token) {
		super();
		this.token = token;
		this.createdDate = new Date();
	}

}
