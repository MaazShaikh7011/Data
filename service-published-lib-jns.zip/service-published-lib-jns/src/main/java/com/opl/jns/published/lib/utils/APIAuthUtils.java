package com.opl.jns.published.lib.utils;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import com.opl.jns.published.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class APIAuthUtils {

	/* ---------------- START REQUEST HEADERS ---------------- */
	public final static String REQ_AUTH = "ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo";
	public final static String RESPONSE_PLAIN_BODY = "plainResponseBody";
	public final static String RESPONSE_STATUS = "responseStatus";
//	public final static String RESPONSE_MESSAGE = "responseMessage";
	public final static String RESPONSE_ENCRYPT_BODY = "encryptedResponseBody";
	public final static String REQUEST_PLAIN_BODY = "plainRequestBody";
	public final static String REQUEST_ENCRYPT_BODY = "encryptedRequestBody";
	public final static String REQUEST_RECEIVED_TIME = "requestReceivedTime";
	public final static String RESPONSE_TIME = "responseTime";

	public static final String DECRYPTION_MSG = "DECRYPTION_MSG";
	private static final String REGISTRY_DOCUMENTS = "/api/registry/v2/claimUploadDocuments";

	public static final String REQ_HEADER_USERNAME = "user-name";
	public static final String REQ_HEADER_API_KEY = "api-key";
	public static final String REQ_HEADER_ENCRYPTION_SKIP = "skipEnc";
	public final static String REQ_HEADER_DECRYPTION_SKIP = "isDecrypt";
	/* ---------------- END REQUEST HEADERS ---------------- */

	/* REQUEST ATTRIBUTES */
	public final static String REQ_ATR_IS_SWAGGER = "REQ_ATR_IS_SWAGGER";
	public final static String REQ_ATR_IS_ACTUATOR = "REQ_ATR_IS_ACTUATOR";
	public static final String REQ_ATR_DEC_FAILED = "REQ_ATR_DEC_FAILED";
//	public static final String REQ_ATR_DEC_FAILED_MSG = "REQ_ATR_DEC_FAILED_MSG";
	public static final String REQ_ATR_DEC_REASON = "REQ_ATR_DEC_REASON";
	public final static String REQ_ATR_LOG_ID = "REQ_ATR_LOG_ID";
	public final static String REQ_ATR_APP_USER_ID = "REQ_ATR_APP_USER_ID";
	public final static String REQ_ATR_ORG_ID = "REQ_ATR_ORG_ID";
	public final static String REQ_ATR_IPS = "REQ_ATR_IPS";
	public final static String REQ_ATR_IPS_FAILED = "REQ_ATR_IPS_FAILED";
	public final static String REQ_ATR_TOKEN = "REQ_ATR_TOKEN";

	/* SBI REQUEST REFERENCE NUMBER */
	public static final String REQ_REF_NUMBER = "referencenumber";

	public static final Long SBI_ORG_ID = 16L;

	/* PAYLOAD AUDIT TYPE */
	public static final int PAYLOAD_TYPE_REQ = 1;
	public static final int PAYLOAD_TYPE_RES = 2;

	public static final String STORAGE_ID = "STORAGE_ID";

	public static final List<String> SWAGGER_URLS = new ArrayList<String>(8);
	static {
		SWAGGER_URLS.add("/api-docs".toLowerCase());
		SWAGGER_URLS.add("/swagger-ui".toLowerCase());
		// SWAGGER_URLS.add("/push-pull/msme/swagger-ui.html".toLowerCase());
		SWAGGER_URLS.add("/swagger-resources".toLowerCase());
		SWAGGER_URLS.add("/swagger-ui/index.html".toLowerCase());
		SWAGGER_URLS.add("/webjars".toLowerCase());
		SWAGGER_URLS.add("/favicon.ico".toLowerCase());
		SWAGGER_URLS.add("/login".toLowerCase());
		SWAGGER_URLS.add("/api-dashboard".toLowerCase());
		SWAGGER_URLS.add("/ready-application".toLowerCase());
		SWAGGER_URLS.add("/excel".toLowerCase());
		SWAGGER_URLS.add("/actuator".toLowerCase());
	}
	
	public static <T> T getHeaderAttribute(HttpServletRequest servletReq, String headerKey, Class<T> t) {
		Object attribute = servletReq.getAttribute(headerKey);
		if (!OPLUtils.isObjectNullOrEmpty(attribute)) {
			return (T) attribute;
		}
		return null;
	}
	
	public static boolean checkSwaggerURL(String reqURI) {
		for (String s : APIAuthUtils.SWAGGER_URLS) {
			if (reqURI.contains(s)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isClientIpMatched(HttpServletRequest request, String ipList) {
		try {
			// FETCH FIRST ROW FROM AUTH DETAILS TABLE FOR CHECK IP ADDRESS
			if (ipList == null) {
				return false;
			}
			List<String> fromIPList = new ArrayList<>();

			String[] split = ipList.split("\\,");
			String[] IP_HEADER_CANDIDATES = { "X-FORWARDED-FOR", "X-Forwarded-For", "x-forwarded-for", "HTTP_FORWARDED",
					"HTTP_FORWARDED_FOR", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP",
					"Proxy-Client-IP", "WL-Proxy-Client-IP", "HTTP_CLIENT_IP", "HTTP_VIA", "REMOTE_ADDR" };
			for (String headerName : IP_HEADER_CANDIDATES) {
				String val = request.getHeader(headerName);
				if (val != null) {
					fromIPList.add(val);
					for (String ip : split) {
						if (!OPLUtils.isObjectNullOrEmpty(val) && !OPLUtils.isObjectNullOrEmpty(ip)
								&& val.contains(ip.trim())) {
							request.setAttribute(REQ_ATR_IPS, val);
							return true;
						}
					}
				}
			}
			String remoteAddr = request.getRemoteAddr();

			if (remoteAddr != null) {
				fromIPList.add(remoteAddr);
				for (String ip : split) {
					if (remoteAddr.contains(ip)) {
						request.setAttribute(REQ_ATR_IPS, remoteAddr);
						return true;
					}
				}
			}
			String falseIps = null;
			for (String s : fromIPList) {
				if(!OPLUtils.isObjectNullOrEmpty(falseIps)) {
					falseIps+="," + s;
					
				}else {
					falseIps=s;	
				}				
			}
			request.setAttribute(REQ_ATR_IPS_FAILED, falseIps);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE CHECK WHITELIST IP ADDRESS :1 ", e);
		}
		return false;
	}

}
