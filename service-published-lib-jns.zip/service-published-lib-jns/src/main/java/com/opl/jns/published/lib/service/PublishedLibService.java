package com.opl.jns.published.lib.service;

import com.opl.jns.published.lib.utils.ConfigType;

public interface PublishedLibService {

    public <T>T callService(Long orgId,Long apiUserId,Object commonRequest,ConfigType type,Class<?> typeClass);
}
