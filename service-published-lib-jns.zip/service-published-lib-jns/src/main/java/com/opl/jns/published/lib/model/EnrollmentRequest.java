package com.opl.jns.published.lib.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 4/25/2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EnrollmentRequest implements Serializable {

    private final static long serialVersionUID = -4357839815853867628L;
    
    public String token;
    public String urn;
    public CustomerDetails customerDetails;

}