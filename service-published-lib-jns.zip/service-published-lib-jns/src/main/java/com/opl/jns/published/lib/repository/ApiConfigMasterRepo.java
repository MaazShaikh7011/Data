package com.opl.jns.published.lib.repository;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.published.lib.domain.ApiConfigMaster;

public interface ApiConfigMasterRepo extends JpaRepository<ApiConfigMaster, Long> {

	@Cacheable(value = "API_APICONFIG_FIND_BY_ID_AND_ACTIVE")
	ApiConfigMaster findByIdAndIsActiveTrue(Long id);

	@Cacheable(value = "API_APICONFIG_FIND_BY_CODE_AND_ACTIVE")
	ApiConfigMaster findByCodeAndIsActiveTrue(String code);
}
