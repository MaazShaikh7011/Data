package com.opl.jns.published.lib.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.published.lib.repository.ApiAuditRepo;
import com.opl.jns.published.lib.repository.PayloadAuditRepository;
import com.opl.jns.published.lib.service.ApiAuditDetailService;

import lombok.extern.slf4j.Slf4j;

@Transactional
@Slf4j
@Service
public class ApiAuditDetailServiceImpl implements ApiAuditDetailService {
	
	@Autowired
	ApiAuditRepo apiauditRepo;
	
	@Autowired
	PayloadAuditRepository payloadAuditRepository;

		public static final String AUDIT_API = " '/api/jns/publish/fetchPublishApiAuditDetailList'";
		public static final String APP_API = " '/api/jns/publish/fetchPublishedAppList'";
		public static final String CLIAM_API = " '/api/jns/publish/fetchPublishedClaimList'";
		public static final String GET_APP_API = " '/api/jns/get/v3/fetchPublishedAppList'";
		public static final String GET_CLIAM_API = " '/api/jns/get/v3/fetchPublishedClaimList'";
	 

//	@Override
//	public CommonResponse getPublishReqRes(Long auditId, boolean isRegistry) {
//		List<APIStorage> findByLogAudit = payloadAuditRepository.findByLogAudit(auditId);
//		if (!OPLUtils.isObjectNullOrEmpty(findByLogAudit)) {
//			HttpHeaders headers = new HttpHeaders();
//			headers.set("ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo", "true");
////	            headers.set("isDecrypt", "true");
////	            headers.set("skipEnc", "true");
//			headers.add("Accept", "application/json");
//			headers.setContentType(MediaType.APPLICATION_JSON);
//			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
//			Map<String, Object> map = new HashMap<>();
//			map.put("reqLogAuditId", auditId);
//			int i = 0;
//			String urlDomain = isRegistry ? URLConfig.fetchURL(URLMaster.REGISTRY) : URLConfig.fetchURL(URLMaster.PUBLISH_INSURANCE);
////			String urlType = isRegistry ? "/api/registry" : "/api/jns";
//			for (APIStorage payloadAudit : findByLogAudit) {
//				String url = urlDomain + "/opl/bucket/deseriablize/" + payloadAudit.getStorageId();
//				Map<String, Object> body = new RestTemplate().exchange(url, HttpMethod.GET, entity, Map.class).getBody();
//				if (!OPLUtils.isObjectNullOrEmpty(body)) {
//					map.put(payloadAudit.getTypeId() == 1 ? "encryptRequest" : "encryptResponse", !OPLUtils.isObjectNullOrEmpty(body.get("plainPayload")) ? body.get("plainPayload").toString() : null);
//					map.put(payloadAudit.getTypeId() == 1 ? "plainRequest" : "plainResponse", !OPLUtils.isObjectNullOrEmpty(body.get("encryptPayload")) ? body.get("encryptPayload").toString() : null);
//					if (i == 0) {
//						map.put("referenceId", !OPLUtils.isObjectNullOrEmpty(body.get("referenceId")) ? body.get("referenceId").toString() : null);
//						map.put("header", !OPLUtils.isObjectNullOrEmpty(body.get("header")) ? body.get("header").toString() : null);
//					}
//					i++;
//				}
//			}
//			return new CommonResponse(map, "Successfully Get Data", HttpStatus.OK.value());
//		}
//		return new CommonResponse("Successfully Get Data", HttpStatus.NO_CONTENT.value());
//	}

}
