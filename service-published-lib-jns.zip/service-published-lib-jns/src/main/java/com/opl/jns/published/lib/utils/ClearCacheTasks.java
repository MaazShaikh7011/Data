package com.opl.jns.published.lib.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableCaching
public class ClearCacheTasks {

	@Autowired
	private CacheManager cacheManager;

	private static final Logger log = LoggerFactory.getLogger(ClearCacheTasks.class);

	@Scheduled(cron = "0 5 0/1 * * ?") // every 1 hour at 5 min
	public void run() {
		log.info("--------------------- IN CLEAR CACHE SCHEDULER ---------------------" + new Date());
		Integer hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
		for (String name : cacheManager.getCacheNames()) {
			List<String> cacheName = new ArrayList<>();
			if (cacheManager.getCache(name).getName().contains("API")
					&& (hour.equals(9) || hour.equals(12) || hour.equals(15) || hour.equals(18) || hour.equals(21))) {
				cacheName.add(cacheManager.getCache(name).getName());
				cacheManager.getCache(name).clear();
			} else if (!cacheManager.getCache(name).getName().contains("API")) {
				cacheName.add(cacheManager.getCache(name).getName());
				cacheManager.getCache(name).clear();
			}
			log.info("--------------------- REMOVED CACHE --------------------- : " + cacheName.toString());
		}
		log.info("--------------------- EXIT FROM CLEAR CACHE SCHEDULER ---------------------" + new Date());
	}
}
