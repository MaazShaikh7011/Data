package com.opl.jns.published.lib.repository.impl;

import java.sql.Clob;

import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.opl.jns.published.lib.repository.ApiAuditRepo;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ApiAuditRepoImpl implements ApiAuditRepo {
	
	 @Qualifier("emFR")
	 @Autowired
	 EntityManager entityManager;
	 
	 
	    @Override
	    public String fetchTotalCount(String query) {
	        return (String) entityManager.createNativeQuery(query).getSingleResult();
	    }
	 
	   @Override
	    public String fetchList(String query) {
	        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
	    }


}
