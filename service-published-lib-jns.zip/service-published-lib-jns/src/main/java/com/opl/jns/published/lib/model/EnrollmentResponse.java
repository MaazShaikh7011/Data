package com.opl.jns.published.lib.model;

import com.opl.jns.published.utils.common.RegistryResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EnrollmentResponse extends RegistryResponse {
    private ApplicationMasterProxy data;

    public void setStatusAndMessageAndSuccessAndData(String message,Integer status,Boolean success,ApplicationMasterProxy data){
        setStatusAndMessageAndSuccess(message,status,success);
        this.data = data;
    }

    public EnrollmentResponse(String s, ApplicationMasterProxy applicationMasterProxy, int value, Boolean aFalse) {
        super(s,applicationMasterProxy,value,aFalse);
        this.data=applicationMasterProxy;
    }

    public EnrollmentResponse(String message, int status, Boolean success) {
        super(message,status,success);
    }

    public EnrollmentResponse(String message, ApplicationMasterProxy data, Integer status, Boolean success) {
        super(message,data,status,success);
        this.data=data;
    }
}