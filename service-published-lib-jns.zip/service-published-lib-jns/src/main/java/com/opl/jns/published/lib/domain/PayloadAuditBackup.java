package com.opl.jns.published.lib.domain;

import java.io.Serializable;
import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author ravi.thummar 10/5/2023
 */
/* BACKUP DATE 22 NOV */
@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit", indexes = {})
public class PayloadAuditBackup implements Serializable {

	private static final long serialVersionUID = -231629146676600012L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payload_audit_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "payload_audit_seq_gen", sequenceName = "payload_audit_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "log_audit_id", nullable = true)
	private Long logAudit;

	@Column(name = "storage_id", nullable = true)
	private String storageId;

	@Column(name = "type_id", nullable = true)
	private Integer typeId;

//	@Lob
//	@Column(name = "payload_header", nullable = true)
//	private String payloadHeader;
//
//	@Lob
//	@Column(name = "payload_params", nullable = true)
//	private String payloadParams;
//
//	@ColumnTransformer(read = "OPLUNCOMPRESS(payload)", write = "OPLCOMPRESS(?)")
//	@Column(name = "payload", columnDefinition = "blob ")
//	private String payload;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	public PayloadAuditBackup() {
		super();
	}

	public PayloadAuditBackup(String token) {
		super();
		this.createdDate = new Date();
	}

}
