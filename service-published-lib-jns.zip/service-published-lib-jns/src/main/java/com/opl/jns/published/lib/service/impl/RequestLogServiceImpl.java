//package com.opl.jns.published.lib.service.impl;
//
//import com.opl.jns.published.lib.domain.*;
//import com.opl.jns.published.lib.repository.*;
//import com.opl.jns.published.lib.service.*;
//import com.opl.jns.published.lib.utils.*;
//import com.opl.jns.published.utils.common.*;
//import lombok.extern.slf4j.*;
//import org.springframework.beans.*;
//import org.springframework.beans.factory.annotation.*;
//import org.springframework.stereotype.*;
//import org.springframework.transaction.annotation.*;
//
//import java.util.*;
//
///**
// * @author Maaz Shaikh 5/4/2021
// */
//
//@Service
//@Transactional
//@Slf4j
//public class RequestLogServiceImpl implements RequestLogService {
//
//	@Autowired
//	private RequestLogAuditRepository requestLogAuditRepository;
//
//	@Autowired
//	private RequestResponseAuditRepository requestResponseAuditRepository;
//
//	@Autowired
//	ErrorLogRepo errorLogRepository;
//
//	@Autowired
//	private ApiConfigMasterRepo configRepo;
//
//	private final String IS_SAVED_REQ_RES_FOR_PUBLISHED = "is_save_req_res_for_publish";
//
//	public Long updateRequestLogs(PreRequestLogs appLogReq, int type) {
//
//		try {
//			ApiConfigMaster apiConfig = configRepo.findByCodeAndIsActiveTrue(IS_SAVED_REQ_RES_FOR_PUBLISHED);
//			log.info("In Update Request logs");
//			RequestLogAudit requestLogAudit = null;
//			if (appLogReq.getId() == null) {
//				requestLogAudit = new RequestLogAudit();
//				requestLogAudit.setCreatedDate(new Date());
//			} else {
//				requestLogAudit = requestLogAuditRepository.findById(appLogReq.getId()).orElse(null);
//				requestLogAudit.setResponseTime((new Date().getTime() - requestLogAudit.getCreatedDate().getTime()));
//			}
//
//			if (type == 1) {
//				BeanUtils.copyProperties(appLogReq, requestLogAudit, "id", "createdDate", "responseTime");
//			} else {
//				BeanUtils.copyProperties(appLogReq, requestLogAudit, "id", "requestUrl", "requestHeader", "requestArgs",
//						"requestArgs", "logAuditId", "apiUserId", "requestIp", "createdDate", "responseTime");
//			}
//
////			log.info("RequestLogAudit Id:: " + save.getId());
//
//			if (!OPLUtils.isObjectNullOrEmpty(apiConfig) && !OPLUtils.isObjectNullOrEmpty(apiConfig.getValue())
//					&& apiConfig.getValue().equalsIgnoreCase("TRUE")) {
//				// For save Request and Response with compressed
//				RequestResponseAudit requestResponseAudit = null;
//				if (requestLogAudit.getLogAuditId() == null) {
//					requestResponseAudit = new RequestResponseAudit();
//					requestResponseAudit.setCreatedDate(new Date());
//				} else {
//					Optional<RequestResponseAudit> findById = requestResponseAuditRepository
//							.findById(requestLogAudit.getLogAuditId());
//					if (!findById.isPresent()) {
//						requestResponseAudit = new RequestResponseAudit();
////                          requestResponseAudit.setLogAudit(requestLogAudit);
//						requestResponseAudit.setCreatedDate(new Date());
//					} else {
//						requestResponseAudit = findById.get();
//					}
//				}
//
//				if (type == 1) {
//					requestResponseAudit.setRequestHeader(appLogReq.getRequestHeader());
//					requestResponseAudit.setRequestParams(appLogReq.getRequestArgs());
//					BeanUtils.copyProperties(appLogReq, requestLogAudit, "id", "createdDate", "responseTime");
//				} else {
//					requestResponseAudit.setResponseHeader(appLogReq.getResponseHeader());
//					requestResponseAudit.setResponseResult(appLogReq.getResponseResult());
//					BeanUtils.copyProperties(appLogReq, requestLogAudit, "id", "requestUrl", "requestHeader",
//							"requestArgs", "requestArgs", "logAuditId", "apiUserId", "requestIp", "createdDate",
//							"responseTime");
//					log.info("--- response for log id::" + appLogReq.getId() + " response value ::"
//							+ appLogReq.getResponseResult());
//				}
////				requestResponseAudit.setLogAudit(save);
//				requestResponseAudit = requestResponseAuditRepository.save(requestResponseAudit);
//				requestLogAudit.setLogAuditId(requestResponseAudit.getId());
//				requestLogAudit = requestLogAuditRepository.save(requestLogAudit);
//			}
////            if (!OPLUtils.isObjectNullOrEmpty(appLogReq.getApiUserId())) {
////                if ((DataSourceProvider.getAnsAppServerDomain().equals("https://www.jansamarth.in") && appLogReq.getApiUserId().intValue() == 2) ||
////                        (DataSourceProvider.getAnsAppServerDomain().equals("https://uat-opl-atmanirbhar.instantmseloans.in") && appLogReq.getApiUserId().intValue() == 3)) {
////                    requestResponseAuditRepository.saveAndFlush(requestResponseAudit);
////                }
////            }
//			// log.info("RequestResponseAudit Id:: " + requestResponseAudit.getId());
//			log.info("End Update Request logs");
//			return requestLogAudit.getId();
//		} catch (Exception e) {
//			log.error("Error while save Logs {}", e);
//		}
//		return null;
//	}
//
//	public void logError(ErrorLog errorLog) {
//		log.info("Saving error log....");
//		try {
//			errorLogRepository.save(errorLog);
//		} catch (Exception e) {
//			log.error("Failed to save error log:: " + e.getMessage());
//		}
//	}
//}
