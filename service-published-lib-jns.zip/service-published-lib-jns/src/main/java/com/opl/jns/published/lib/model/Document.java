package com.opl.jns.published.lib.model;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author maaz.shaikh
 * @Date  5/7/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Document implements Serializable {

    @NotNull
//    @Min(1)
    public Long documentId;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    public String documentType;

    @NotNull
    @NotEmpty
    @Size(min = 0,max = 255)
    @Schema(allowableValues ={"pdf"},description = "pdf")
    public String contentType;

    @NotNull
    @NotEmpty
    public byte[] document;
    private final static long serialVersionUID = -2484884962226128489L;

}
