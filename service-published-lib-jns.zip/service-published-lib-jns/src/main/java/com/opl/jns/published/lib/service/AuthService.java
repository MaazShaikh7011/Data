package com.opl.jns.published.lib.service;


import org.springframework.data.domain.Page;

import com.opl.jns.published.lib.domain.APILogs;

public interface AuthService {
    Page<APILogs> findPaginated(Long apiUserId, Integer pageNo, int pageSize);
}
