package com.opl.jns.published.lib.utils;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.opl.jns.published.lib.service.impl.CustomAuthenticationProvider;


@EnableWebSecurity
@Configuration
public class WebSecurityConfig {

    @Value("${server.servlet.context-path}")
    String contextPath;

    @Autowired
    private CustomAuthenticationProvider authProvider;

    private static final String[] AUTH_LIST = { //
            "/api-docs", //
            "/api-docs/**",            
            "/swagger-ui", //
            "/swagger-resources", //
            "/swagger-resources/**", //
            "/swagger-ui/index.html", //
            "/swagger-ui/**", //
            "/webjars",
            "/webjars/**",
            "/favicon.ico",
            "/swagger-ui/3.47.1/index.html"
    };

//
//        @Autowired
//        private AuthDetailService authDetailService;

//    @Autowired
//    public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {
//        auth.jdbcAuthentication().passwordEncoder(new BCryptPasswordEncoder())
//                .dataSource(dataSource)
//                .usersByUsernameQuery("select username, password, enabled from users where username=?")
//                .authoritiesByUsernameQuery("select username, role from users where username=?")
//        ;
//    }

//    @Bean
//    public DaoAuthenticationProvider authProvider() {
//        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
//        authProvider.setUserDetailsService(userDetailsService);
//        authProvider.setPasswordEncoder(passwordEncoder());
//        return authProvider;
//    }


    /*~~(Migrate manually based on https://spring.io/blog/2022/02/21/spring-security-without-the-websecurityconfigureradapter)~~>*/
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authProvider);
        //auth.authenticationProvider(authProvider());
        //auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
        // auth.inMemoryAuthentication().withUser("user").password(passwordEncoder().encode("password")).roles("USER").and().withUser("admin")
        // .password(passwordEncoder().encode("admin")).roles("USER", "ADMIN");
    }

//    @Bean
//    public AuthenticationFailureHandler authenticationFailureHandler() {
//        return new CustomAuthenticationFailureHandler();
//    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    //
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable())
				.authorizeHttpRequests(requests -> requests.requestMatchers(AUTH_LIST).authenticated()
						.requestMatchers("/**").permitAll().anyRequest().authenticated())
				.formLogin(login -> login.loginPage("/login"))
				.logout(logout -> logout.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
						.logoutSuccessUrl(
								"/swagger-ui/index.html?configUrl=" + contextPath + "/v3/api-docs/swagger-config")
						.invalidateHttpSession(true));
//        .authenticationManager(new ProviderManager(authProvider));
		return http.build();
        // TODO remove authentication
     /*   http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/**").permitAll()
                .anyRequest().authenticated(); */


//        http.csrf().disable()
//                .authorizeRequests()
//                .antMatchers(AUTH_LIST).authenticated().antMatchers("/**").permitAll()
//                .anyRequest().authenticated().and().httpBasic();
//          HeadersConfigurer<HttpSecurity> headers = http.headers();
//
//
//headers.defaultsDisabled();
//
//
//
///*          headers.frameOptions().deny();
//          headers.featurePolicy("geolocation 'self'");
//          headers.referrerPolicy();
//          //http.csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).disable();
//          http.csrf().disable();*/
//
//
//         /*headers
//          .cacheControl().and().frameOptions().sameOrigin();*/
//
//
//          headers.contentTypeOptions();
//          headers.httpStrictTransportSecurity();
          //headers.httpStrictTransportSecurity().maxAgeInSeconds(31536000);
            //headers.httpStrictTransportSecurity().includeSubDomains(true);
//
//
//
// headers
//            .contentSecurityPolicy("script-src 'self' 'unsafe-inline' 'unsafe-eval'; https://localhost.com; object-src 'self' https://localhost.com; report-uri ");
//
//
//            //   /csp-report-endpoint/
//            headers.xssProtection().block(true);
//
//
//headers
//            .addHeaderWriter(new StaticHeadersWriter ("X-Content-Security-Policy","default-src 'self' 'unsafe-inline' 'unsafe-eval'"))
//            .addHeaderWriter(new StaticHeadersWriter("X-Custom-Security-Header","header-value"))
//            .addHeaderWriter(new StaticHeadersWriter("X-WebKit-CSP","default-src 'self' 'unsafe-eval'"));
//
//
//
//            headers
//            .addHeaderWriter(new XFrameOptionsHeaderWriter(XFrameOptionsMode.SAMEORIGIN));
//
//            http.requiresChannel()
//            .requestMatchers(r -> r.getHeader("X-Forwarded-Proto") != null)
//            .requiresSecure();
//            headers.addHeaderWriter(new ClearSiteDataHeaderWriter(ClearSiteDataHeaderWriter.Directive.CACHE,
//                      ClearSiteDataHeaderWriter.Directive.COOKIES,
//                      ClearSiteDataHeaderWriter.Directive.STORAGE));
//           RequestMatcher matcher = new AntPathRequestMatcher("/error");
//            DelegatingRequestMatcherHeaderWriter headerWriter =
//          new DelegatingRequestMatcherHeaderWriter(matcher,new XFrameOptionsHeaderWriter());
//
//
           //headers.
            //.addHeaderWriter(headerWriter);
//            http.httpBasic() // it indicate basic authentication is requires
//            .and()
//            .authorizeRequests()
//            .antMatchers(
//                    HttpMethod.GET,
//                    "/v3/api-docs/**",
//                    "/swagger-ui/**",
//                    "/swagger-ui.html",
//                    "/swagger-resources/**",
//                    "/swagger-ui/index.html",
//                    "/webjars/**",
//                    "favicon.ico"
//            ).authenticated().and().authorizeRequests().anyRequest().permitAll().and().requestMatchers()
//            .anyRequest();




      }


//      @Bean
//      @Override
//      public UserDetailsService userDetailsService() {
//
//          PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
////          AuthDetail authDetail = authDetailService.getAuthDtailByIsActiveIsTrue();
//          final User.UserBuilder userBuilder = User.builder().passwordEncoder(encoder::encode);
//          UserDetails user = userBuilder
//              .username("testuser")
//              .password("test@123")
//              .roles("ADMIN")
//              .build();
//          return new InMemoryUserDetailsManager(user);
//      }

}
