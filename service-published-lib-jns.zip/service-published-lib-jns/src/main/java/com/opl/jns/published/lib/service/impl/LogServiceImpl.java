package com.opl.jns.published.lib.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.opl.jns.published.lib.domain.APILogs;
import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.domain.ErrorLog;
import com.opl.jns.published.lib.model.DeDupRequest;
import com.opl.jns.published.lib.model.EnrollmentRequest;
import com.opl.jns.published.lib.model.EnrollmentResponse;
import com.opl.jns.published.lib.repository.ErrorLogRepo;
import com.opl.jns.published.lib.repository.RequestLogAuditRepository;
import com.opl.jns.published.lib.service.LogService;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.lib.utils.EnvironmentUtils;
import com.opl.jns.published.lib.utils.PreRequestLogs;
import com.opl.jns.published.lib.utils.UploadPayload;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar Date : 10-05-2023
 */

@Service
@Slf4j
public class LogServiceImpl implements LogService {

	private static final String ENROLLMENT_REQUEST_URL_V2 = "/api/registry/v2/enrollment";
	private static final String DE_DEUPE_REQUEST_URL_V2 = "/api/registry/v2/de-dupe";
	private static final String UPDATE_TRANSACTION_REQUEST_URL_V2 = "/api/registry/v2/updateTransactionDetails";
	private static final String GET_APPLICATION_DETAILS_URL_V1 = "/api/jns/v1/getApplicationDetails";
	private static final String ENROLLMENT_REQUEST_URL_V3 = "/api/registry/v3/enrollmentDetails";
	private static final String UPDATE_TRANSACTION_REQUEST_URL_V3 = "/api/registry/v3/updateTransactionDetails";
	private static final String CLAIM_REQUEST_URL_V3 = "/api/registry/v3/claimDetails";
	private static final String CLAIM_UPLOAD_DOC_REQUEST_URL_V3 = "/api/registry/v3/claimUploadDocuments";
	private static final String CLAIM_STATUS_REQUEST_URL_V3 = "/api/registry/v3/insurerUpdateClaimStatus";
	private static final String UPDATE_ENROLLMENT_STATUS_V3 = "/api/registry/v3/updateEnrolmentAcStatus";
	private static final String CLAIM_DE_DUPE_V3 = "/api/registry/v3/claimDedupeApi";
	
	@Autowired
	private RequestLogAuditRepository reqLogAuditRepo;

	@Autowired
	private ErrorLogRepo errorLogRepository;

	@Autowired
	private UploadPayload uploadPayload;

	@Async
	public void logError(ErrorLog errorLog) {
		try {
			errorLogRepository.save(errorLog);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVING ERROR LOGS :-", e);
		}
	}

	public APILogs failureLogs(HttpServletRequest request, String message, ApiUsers apiUsers) {
		PreRequestLogs preReqLogs = new PreRequestLogs();
		preReqLogs.setContextPath(request.getContextPath());
		preReqLogs.setRequestUrl(request.getRequestURI());
		if (request.getAttribute(APIAuthUtils.REQ_ATR_IPS_FAILED) != null) {
			preReqLogs.setRequestIp(String.valueOf(request.getAttribute(APIAuthUtils.REQ_ATR_IPS_FAILED)));
		}
		if (apiUsers != null) {
			preReqLogs.setOrgId(apiUsers.getOrganizationMaster().getId());
		}
		Long createdDate = APIAuthUtils.getHeaderAttribute(request, APIAuthUtils.REQUEST_RECEIVED_TIME, Long.class);
		if(createdDate != null) {
			preReqLogs.setCreatedDate(new Date(createdDate));	
		} else {
			preReqLogs.setCreatedDate(new Date());
		}
		preReqLogs.setResponseDate(new Date());
		preReqLogs.setResponseTime(preReqLogs.getResponseDate().getTime() - preReqLogs.getCreatedDate().getTime());
		preReqLogs.setApiKey(request.getHeader(APIAuthUtils.REQ_HEADER_API_KEY));
		preReqLogs.setUserName(request.getHeader(APIAuthUtils.REQ_HEADER_USERNAME));
		preReqLogs.setMessage(message);
		return insertRequestLogs(preReqLogs, apiUsers);
	}

	public APILogs insertRequestLogs(PreRequestLogs preReqLog, ApiUsers apiUser) {
		try {
			APILogs reqLogAudit = new APILogs();
			BeanUtils.copyProperties(preReqLog, reqLogAudit, "id", "createdDate");
//			Date curruntDate = new Date();
			reqLogAudit.setToken(UUID.randomUUID().toString());
			if (apiUser != null) {
				reqLogAudit.setApiUsers(apiUser);
			}
			reqLogAudit.setCreatedDate(preReqLog.getCreatedDate());
			reqLogAudit.setModifiedDate(preReqLog.getResponseDate());
			reqLogAudit.setResponseTime(preReqLog.getResponseTime());
			reqLogAudit.setOrgId(preReqLog.getOrgId());
			reqLogAudit.setRequestToken(preReqLog.getReqToken());
			/* SET URN CIF ACC-NO */
			setUrnCifAndAccNo(preReqLog, reqLogAudit);
			
			if(!OPLUtils.isObjectNullOrEmpty(reqLogAudit.getMessage()) && reqLogAudit.getMessage().length() > 255) {
				reqLogAudit.setMessage(reqLogAudit.getMessage().substring(0, 253));
			}

			/* SAVE */
			reqLogAudit = reqLogAuditRepo.save(reqLogAudit);

			/* SAVE/UPDATE REQUEST AND RESPONSE PAYLOAD */
			String value = EnvironmentUtils.PUBLISH_LIB_REQ_RES_ENABLE.getValue();
			if (!OPLUtils.isObjectNullOrEmpty(value) && !"NONE".equalsIgnoreCase(value)
					&& !OPLUtils.isObjectNullOrEmpty(apiUser)) {
				if ("S3".equalsIgnoreCase(value)) {
					uploadPayload.insertReqResS3(reqLogAudit, preReqLog);
				}
			}

			return reqLogAudit;
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVING REQUEST RESPONSE LOGS - ", e);
		}
		return null;
	}

	public APILogs setUrnCifAndAccNo(PreRequestLogs preReqLog, APILogs reqLogAudit) throws IOException {
		if (!OPLUtils.isObjectNullOrEmpty(preReqLog) && !OPLUtils.isObjectNullOrEmpty(preReqLog.getRequestUrl())) {
			if (preReqLog.getRequestUrl().equals(ENROLLMENT_REQUEST_URL_V2) || preReqLog.getRequestUrl().equals(ENROLLMENT_REQUEST_URL_V3)) {
				if (!OPLUtils.isObjectNullOrEmpty(preReqLog.getPlainRequest())) {
					EnrollmentRequest enrollmentRequest = MultipleJSONObjectHelper
							.getObjectFromString(preReqLog.getPlainRequest(), EnrollmentRequest.class);
					if (!OPLUtils.isObjectNullOrEmpty(enrollmentRequest)
							&& !OPLUtils.isObjectNullOrEmpty(enrollmentRequest.getCustomerDetails())) {
						reqLogAudit.setAccountNumber(enrollmentRequest.getCustomerDetails().getAccountNumber());
						reqLogAudit.setCif(enrollmentRequest.getCustomerDetails().getCif());
					}
				}
			} else if (preReqLog.getRequestUrl().equals(DE_DEUPE_REQUEST_URL_V2)) {
				if (!OPLUtils.isObjectNullOrEmpty(preReqLog.getPlainRequest())) {
					DeDupRequest deDupRequest = MultipleJSONObjectHelper
							.getObjectFromString(preReqLog.getPlainRequest(), DeDupRequest.class);
					if (!OPLUtils.isObjectNullOrEmpty(deDupRequest)) {
						reqLogAudit.setAccountNumber(deDupRequest.getAccNo());
						reqLogAudit.setCif(deDupRequest.getCif());
					}
				}
			} else if (preReqLog.getRequestUrl().equals(UPDATE_TRANSACTION_REQUEST_URL_V2)
					|| preReqLog.getRequestUrl().equals(UPDATE_TRANSACTION_REQUEST_URL_V3)
					|| preReqLog.getRequestUrl().equals(CLAIM_REQUEST_URL_V3)
					|| preReqLog.getRequestUrl().equals(CLAIM_UPLOAD_DOC_REQUEST_URL_V3)
					|| preReqLog.getRequestUrl().equals(CLAIM_STATUS_REQUEST_URL_V3)
					|| preReqLog.getRequestUrl().equals(UPDATE_ENROLLMENT_STATUS_V3)
					|| preReqLog.getRequestUrl().equals(CLAIM_DE_DUPE_V3)) {
				if (!OPLUtils.isObjectNullOrEmpty(preReqLog.getPlainRequest())) {
					DeDupRequest deDupRequest = MultipleJSONObjectHelper
							.getObjectFromString(preReqLog.getPlainRequest(), DeDupRequest.class);
					if (!OPLUtils.isObjectNullOrEmpty(deDupRequest)) {
						reqLogAudit.setUrn(deDupRequest.getUrn());
						if(!OPLUtils.isObjectNullOrEmpty(deDupRequest.getCif())) {
							reqLogAudit.setCif(deDupRequest.getCif());
						}
						if(!OPLUtils.isObjectNullOrEmpty(deDupRequest.getAccountNumber())) {
							reqLogAudit.setAccountNumber(deDupRequest.getAccountNumber());
						}
					}
				}
			} else if (preReqLog.getRequestUrl().equals(GET_APPLICATION_DETAILS_URL_V1)) {
				if (!OPLUtils.isObjectNullOrEmpty(preReqLog.getPlainRequest())) {
					DeDupRequest deDupRequest = MultipleJSONObjectHelper
							.getObjectFromString(preReqLog.getPlainRequest(), DeDupRequest.class);
					if (!OPLUtils.isObjectNullOrEmpty(deDupRequest)) {
						reqLogAudit.setApplicationReferenceId(deDupRequest.getApplicationReferenceId());
					}
				}
			}
		}
		return reqLogAudit;
	}

	public APILogs setUrn(PreRequestLogs preReqLog, APILogs reqLogAudit) throws IOException {
		if (!OPLUtils.isObjectNullOrEmpty(preReqLog) && !OPLUtils.isObjectNullOrEmpty(preReqLog.getRequestUrl())) {
			if (preReqLog.getRequestUrl().equals(ENROLLMENT_REQUEST_URL_V2)) {
				if (!OPLUtils.isObjectNullOrEmpty(preReqLog.getPlainResponse())) {
					EnrollmentResponse enrollmentResponse = MultipleJSONObjectHelper
							.getObjectFromString(preReqLog.getPlainResponse(), EnrollmentResponse.class);
					if (!OPLUtils.isObjectNullOrEmpty(enrollmentResponse)
							&& !OPLUtils.isObjectNullOrEmpty(enrollmentResponse.getData())
							&& !OPLUtils.isObjectNullOrEmpty(enrollmentResponse.getStatus())
							&& enrollmentResponse.getStatus() == 200) {
						reqLogAudit.setUrn(enrollmentResponse.getData().getUrn());
					}
				}
			}
		}
		return reqLogAudit;
	}

}
