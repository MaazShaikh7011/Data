package com.opl.jns.published.lib.domain;

import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "error_log", indexes = {})
public class ErrorLog {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "error_log_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "error_log_seq_gen", sequenceName = "error_log_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "application_reference_id", nullable = true)
	private Long applicationReferenceId;

//    @Column(name = "api_user_id", nullable = true)
//    private Long apiUserId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "api_user_id", nullable = true)
	private ApiUsers apiUsers;

	@Column(name = "org_id", nullable = true)
	private Integer orgId;
	@Column(name = "req_url", nullable = true)
	private String reqUrl;

//    @Lob
	@Column(name = "error_msg", nullable = true)
	private String errorMsg;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

}
