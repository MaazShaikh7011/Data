package com.opl.jns.published.lib.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.published.lib.domain.APILogs;

/**
 * @author ravi.thummar,Maaz Shaikh
 * Date : 10-05-2023
 */

@Repository
public interface RequestLogAuditRepository extends JpaRepository<APILogs, Long> {

    Page<APILogs> findByApiUsersIdOrderByIdDesc(Long apiUserId, Pageable pageable);

    List<APILogs> findByApplicationReferenceIdAndApiUsersIdAndResponseStatusAndCreatedDateGreaterThanEqual(Long applicationReferenceId, Long apiUserId, Integer status, Date fromDate);

    APILogs findFirstById(Long id);


    Page<APILogs> findByRequestUrlOrderByIdDesc(String requestUrl,Pageable pageable);
}
