package com.opl.jns.published.lib.service;

public interface ApiAuditDetailService {

//  CommonResponse getPublishReqRes(Long auditId, boolean isRegistry);
  
}
