package com.opl.jns.published.lib.utils;

public enum EnvironmentUtils {

	PUSH_READY_SCHEDULER_ENABLE("PUSH_READY_SCHEDULER_ENABLE"),
	PUBLISH_LIB_REQ_RES_ENABLE("PUBLISH_LIB_REQ_RES_ENABLE"), // NONE/S3/ORACLE
	REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");

	private final String code;

	EnvironmentUtils(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getValue() {
		return System.getenv(this.code);
	}

}
