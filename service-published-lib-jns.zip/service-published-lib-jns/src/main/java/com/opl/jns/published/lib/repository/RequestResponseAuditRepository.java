package com.opl.jns.published.lib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.published.lib.domain.RequestResponseAudit;

/**
 * @author Maaz Shaikh
 * Date : 15-07-2023
 */

@Repository
public interface RequestResponseAuditRepository extends JpaRepository<RequestResponseAudit, Long> {

//    RequestResponseAudit findByLogAuditId(Long logAuditId);
}
