package com.opl.jns.published.lib.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.opl.jns.published.lib.domain.APILogs;
import com.opl.jns.published.lib.repository.RequestLogAuditRepository;
import com.opl.jns.published.lib.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private RequestLogAuditRepository requestLogAuditRepository;


    @Override
    public Page<APILogs> findPaginated(Long apiUserId, Integer pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo - 1, pageSize);
        return requestLogAuditRepository.findByApiUsersIdOrderByIdDesc(apiUserId, pageable);
    }
}
