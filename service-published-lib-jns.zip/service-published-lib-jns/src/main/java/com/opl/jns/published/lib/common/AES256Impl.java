package com.opl.jns.published.lib.common;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class AES256Impl {
	
	private static final Logger  logger = LoggerFactory.getLogger(AES256Impl.class);
	
	private Cipher c;
	private IvParameterSpec IV;
	private SecretKey s_KEY;

	public AES256Impl() {
		try {
			c = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			logger.info("-------> Ciper {} " , c);
			IV = generateIV();
			logger.info("-------> IV {} " , IV);
			s_KEY = generateKEY();
			logger.info("-------> key {} " , s_KEY);
		} catch (Exception e) {
			logger.error("Error/Exception in contructor() ======> MSG ==> {} " , e);
			
		}
	}


	public byte[] encrypt(String strToEncrypt) {
		try {
			byte[] byteToEncrypt = strToEncrypt.getBytes();
			logger.info("-------> Ciper {} " , c);
			logger.info("-------> IV {} ", IV);
			logger.info("-------> key {} " , s_KEY);

			c.init(Cipher.ENCRYPT_MODE, s_KEY, IV);

			return c.doFinal(byteToEncrypt);
		} catch (Exception e) {
			logger.error("Error/Exception in encrypt() ======> MSG ==> {} " , e);
			return null;
		}

	}

	public String decrypt(byte[] byteToDecrypt) {
		try {
			c.init(Cipher.DECRYPT_MODE, s_KEY, IV);

			byte[] plainByte = c.doFinal(byteToDecrypt);

			return new String(plainByte, "UTF-8");
		} catch (Exception e) {
			logger.error("Error/Exception in decrypt() ======> MSG ==> {} " , e);
			return null;
		}

	}

	private IvParameterSpec generateIV() {

		byte[] byteIV = "1234567891234567".getBytes();

		IV = new IvParameterSpec(byteIV);

		return IV;
	}

	private SecretKey generateKEY() {

		try {
			//KeyGenerator keyGen = KeyGenerator.getInstance("AES"); // A
			String hex = "92C336F2209922C378F3D46A5121A2E81068A123413A579711DA8A32474558B7";
			byte[] bytes = new byte[hex.length() / 2];
			for (int i = 0; i < hex.length() / 2; i++)
				bytes[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
			SecretKey originalKey = new SecretKeySpec(bytes, "AES");
			logger.info("original Key-------------> {}  " ,  originalKey);
			return originalKey;
		} catch (Exception e) {
			logger.error("Error/Exception in generateKEY() ======> MSG ==> {} " , e);
			return null;
		}

	}

	public static Map<String, String> generateNewUser(String plainUserName) {
		Map<String, String> stringStringMap = new HashMap<>();
		try {
			String iv = Base64.getEncoder().encodeToString(new AES256Impl().encrypt(String.valueOf(System.nanoTime())));
			AESEncryptionUtilitySBI aesEncryptionUtilitySBI = new AESEncryptionUtilitySBI(iv, "AES/CBC/PKCS5Padding");
			stringStringMap.put("userName", aesEncryptionUtilitySBI.encrypt(plainUserName));
			stringStringMap.put("apiKey", UUID.randomUUID().toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stringStringMap;
	}

	public static void main(String[] args) throws InvalidKeyException, InvalidAlgorithmParameterException, UnsupportedEncodingException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
		Scanner scanner= new Scanner(System.in);
		System.out.print("Enter String to encrypt:: ");
		String stringToEnc =  scanner.nextLine();
		String iv = Base64.getEncoder().encodeToString(new AES256Impl().encrypt(String.valueOf(System.nanoTime())));
		AESEncryptionUtilitySBI aesEncryptionUtilitySBI = new AESEncryptionUtilitySBI(iv, "AES/CBC/PKCS5Padding");
		String encUserName = aesEncryptionUtilitySBI.encrypt(stringToEnc);
		String encUserApiKey = UUID.randomUUID().toString();
		System.out.println("User Name:: " + encUserName);
		System.out.println("User API Key:: " + encUserApiKey);
	}
	
}
