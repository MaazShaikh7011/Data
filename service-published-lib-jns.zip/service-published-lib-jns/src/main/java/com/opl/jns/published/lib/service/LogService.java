package com.opl.jns.published.lib.service;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.opl.jns.published.lib.domain.APILogs;
import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.domain.ErrorLog;
import com.opl.jns.published.lib.utils.PreRequestLogs;

/**
 * @author ravi.thummar Date : 10-05-2023
 */

@Service
public interface LogService {

//	APILogs updateRequestLogs(PreRequestLogs requestLogReq, int type, ApiUsers apiUser);

	void logError(ErrorLog errorLog);


	APILogs insertRequestLogs(PreRequestLogs requestLogReq, ApiUsers apiUser);
	
	public APILogs failureLogs(HttpServletRequest request, String message, ApiUsers apiUsers);
}
