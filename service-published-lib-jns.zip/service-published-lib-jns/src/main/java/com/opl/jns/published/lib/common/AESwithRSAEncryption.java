package com.opl.jns.published.lib.common;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AESwithRSAEncryption {

	private static final String JCE_PROVIDER = "BC";
	private static final int SYMMETRIC_KEY_SIZE = 256;
	
	private static final String PASS = "12345";

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	public static String encrypt(String metaDATA, String privateFile)
			throws NoSuchAlgorithmException, NoSuchProviderException, Exception {
		String encryptedData = null;
		byte[] sessionkey = generateSessionKey();
		// byte length should be 32
//		String encryptedSessionKey=encryptSessionKey(Base64.getEncoder().encodeToString(sessionkey), getRSAprivaetKeys("E://SIDBIPRAYASPrivate.pfx","12345".toCharArray()));
		/// apps/services/service-loans/template/SIDBIPRAYASPrivate.pfx
		String encryptedSessionKey = encryptSessionKey(Base64.getEncoder().encodeToString(sessionkey),
				getRSAprivaetKeys(privateFile, PASS.toCharArray()));
		byte[] encryptedMetaData = aesEncrypt(metaDATA.getBytes(), sessionkey, null);
		encryptedData = encryptedSessionKey + ":" + Base64.getEncoder().encodeToString(encryptedMetaData);
		return encryptedData;

	}

	public static String encryptSessionKey(String plainAESKey, PrivateKey privateKey) throws Exception {
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(1, privateKey);
		byte[] encVal = cipher.doFinal(plainAESKey.getBytes());
		String encryptedValue = Base64.getEncoder().encodeToString(encVal);
		return encryptedValue;
	}

	private static byte[] aesEncrypt(byte[] original, byte[] key, byte[] iv) throws Exception {
		if (key == null || (key.length != 16 && key.length != 24 && key.length != 32)) {
			return null;
		}
		if (iv != null && iv.length != 16) {
			return null;
		}

		SecretKeySpec keySpec = null;
		Cipher cipher = null;
		if (iv != null) {
			keySpec = new SecretKeySpec(key, "AES/CBC/PKCS7Padding");
			cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(iv));
		} else {
			keySpec = new SecretKeySpec(key, "AES/ECB/PKCS7Padding");
			cipher = Cipher.getInstance("AES/ECB/PKCS7Padding");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
		}

		return cipher.doFinal(original);
	}

	public static PrivateKey getRSAprivaetKeys(String private_key_file, char[] pass) throws Exception {
		// System.out.println("private_key_file========>" + private_key_file);
		Map<String, Object> keys = null;
		PrivateKey privateKey = null;
		try {
			BouncyCastleProvider provider = new BouncyCastleProvider();
			Security.addProvider(provider);
			KeyStore ks = KeyStore.getInstance("PKCS12", provider.getName());
			ks.load(new FileInputStream(private_key_file), pass);

			String alias = (String) ks.aliases().nextElement();
			privateKey = (PrivateKey) ks.getKey(alias, pass);

			keys = new HashMap<String, Object>();
			keys.put("private", privateKey);
		} catch (Exception e) {
			e.printStackTrace();
//				keys.put("Error", e.getMessage());
		}
		return privateKey;
	}

	private static byte[] generateSessionKey() throws NoSuchAlgorithmException, NoSuchProviderException {
		KeyGenerator kgen = KeyGenerator.getInstance("AES", JCE_PROVIDER);
		kgen.init(SYMMETRIC_KEY_SIZE);
		SecretKey key = kgen.generateKey();
		byte[] symmKey = key.getEncoded();
		return symmKey;
	}

//	    private static byte[] generateSessionKey() throws NoSuchAlgorithmException, NoSuchProviderException {
//			String JCE_PROVIDER = "BC";
//			int SYMMETRIC_KEY_SIZE = 256;
//	        KeyGenerator kgen = KeyGenerator.getInstance("AES", JCE_PROVIDER);
//	        kgen.init(SYMMETRIC_KEY_SIZE);
//	        SecretKey key = kgen.generateKey();
//	        byte[] symmKey = key.getEncoded();
//	         return symmKey;
//	    }
//	public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchProviderException, Exception {
//		String plainText = "Harsukh Ghumaliya";
//		System.out.println(plainText);
//		String encrypt = encrypt(plainText, "", "12345");
//		System.out.println("144encrypt ===========>" + encrypt);
//		String decrypt = AESwithRSADecryption1.decrypt(encrypt);
//		System.out.println("149decrypt=======> " + decrypt);
//	}

	private static String privateKey1 = """
			MIIJRAIBADANBgkqhkiG9w0BAQEFAASCCS4wggkqAgEAAoICAQDPzUDqVm4n2zE6
			ZbgqE0F3uNEjrA1w1XvjjJTmYV2NQOL6IfVUu/4onGg1FXQWacLC3W9IaKzU5PuQ
			lY8WPeS3PfvbdGqj2P/mK6wPLvoas25Q/SOjMMU7fsucEJANCcCIY3UtnLS063sB
			XDsHITZW6uW4WkryPxtgFDGgiIAR7OJzrra0xHF7qa1sq+HvaCMiFf0cgi5HHao8
			iud8Vcb6fq9vK81yNYXYKCsfd12FfdcXhX1Hyri5oHKWhuxjOymcELUawMEuPbgi
			CIU2qUVz4sDSwt86xtOzCEJJegFFZXgx0p9h/NcIxi3Ikq3YH9NAso3ciY4pSdq+
			+EdFCTwISDc+PEEIvHrFk8Dr6RayUe9mJRVIPpEIxuUd7qEBvYn09oUntQJCkxqP
			9CwwN2eRea5bQlQKjKwCagyXDqPrAmlY9oiUcCi7JEO14En1EYlOkbEOzd1jkpsU
			iPhMxIBna9MZkIeuwnr4Xjvyr4XT0F/EtrQ0yioLnq/d475KxQJwkI4lsCnDrzuE
			LDfKvvTxNhyW/OXotc8NGZ3xYbI2Oa2nK3Wgl+hktNiaEWRHH8aVrdQPyWjp6bom
			Uj4mS/K/RDLxW5gVHxTtPWZqqCayqqW77B76f/Aa4nkNLnPIX8AWminkTsC+L/8H
			PBkxhMVdtgnBr5E/MnwbYSo4P5atSQIDAQABAoICAAGWqxlfgcYSOeUdY/QGY6i7
			o/Wm2g9zwlex+m1sbx+mUFXjLpHwQfgjgfRt7o5BTrjYooImMrQJ8BZh3k8oN/hi
			o+tAj5QjE4m56b3P+R99IanC1aPouolC5eGSitderLceM4YevY7oge83ukfKrDSr
			5QeswQfrDZWFcf+tK3V3nx+NRV5KZiew21+KTNbcr/ARxPaT1DC8/FEsKqrbqQK/
			Ny4dYput5xEI9ZNvASsFFEDcx2FmHlVk8ZtO+r2jdST5R7klohRtalvwPrx1PM+u
			+xRhYv17CaFDveX75ciXBv0yg/9mxGoPwcfXvzZ4v8+tzcHS12BfbSmqkjjn4iqW
			gT2QOCkf0cg3B595074Qcm0q+vEedn1RdhWlH8rz/asRylCt4pKIjx8sJ8LX9AYf
			OxGtI7YmkAEHcHhYpJ76DqXU8STcaJH7scnYW0705BcJ51ndukFayCJJqn5XOzIJ
			R1AHqmwkXrqcgMpl78KCUQ2gJHeZjQi5KwLapNUFkkMDRtKuKIx1E3Z5Gj7xDx2U
			Z2mfrv63X4Uroy6izUfR9Tj8+WxnBSb5X5lWnDEgIshNDnRBTNiQ9uMVYijj25uR
			WKYaEoaMPUVBW0qrLRpjEtbW/TNHTmlOkUFo05PmMasYMY73Bqkvo6XLUPHKORCJ
			umq9oxDyJlg1j0q3SNQRAoIBAQD5VEcF1iz22CyoaSSCCp9Z1nnu3dXDBgO3QKwg
			YARepuKO/J3ceqOhNmeoc4XIpLgN2HWyEWeJkXd43+/y0xZBm3qyVknrg23+C1uK
			AlwAhYLwHKhiDVP7XnQFabR6P+7oeWfzJRR3Y11V0vkZBWZvHGwJQ3kpuzFcfQd1
			bUEKbKOQGjtQ1nnJ6bz1fzm+AcwYDlwTN+bmVB0C/f2JLTyIGVCUPvZxhHvA+wtL
			5MKII4OHg5GRHAFjoszFnkb16TPXZAT4T9qupWKQvHJpVYYrxSNbnsOw3uY07tl2
			2+8GqX2gIDrPx3swEEwurWk6zpa623E0iAQeFVVc/dQdwtg1AoIBAQDVXIspReR4
			A6pjgWu1HYC7jRyMATuZ5Aq0/lKHg+Nr2t2KFVQXQGGPctuB60DOYbmcR+RvXAmU
			JHXD9Asz2TNy0P2lS24BGqBNrp/BgbB4NWVwU5+cSyokhzG74FkRxTA5FI3bfksy
			oZRFhaPiC7JSqxq/ycZZFUqSC/3z15iYtzoTcWHzZFjn6kew/QPRZky1Txw0ejGn
			gMq02QrZErWcm4T9MuUyXs2aJsZceghB1vepP/uI+7skxhRt123j1bfnVRTlxZyq
			x7AqmJVjNpIXCH8accUc5PLFx4f8lOxe7hU3BX5GckFQPbX2DK+tKwTqV3bGwmsA
			UyxCxIWP66tFAoIBAQCBtBsCaUmY3BpXPeM1FyuQg6eI4LQsMTvLoAQrD2gWiUCA
			29+Pa+klm3TPR9GH8FCjO0D28mDnStpY8j4UF0WTubtZfNQVhZi5uNTU9adAyjO0
			j2P1JjPTJ265xiSSGCJDo6y060w7U2Chng/huVJxaNq28vfcArqJ/6zapIxaTOvF
			si+7POe8ZzDakWXLd4nh1c6GXOVsWsOA4/p52yOLNYgapqpzoVTzrmVRBN9CDR+G
			ZqZaU7RRTcay40TM9pT2bty7BGehxP2Ch9YI/+m9aV+ccPoiT8J4NOzCDWXKFG/6
			1eliX8aw2TmYarO8WO5GpJO+nSdvMu/mYVFwbgUlAoIBAQCmuaZVHjSmQ9cF4sBT
			yzYpWN+R1/THEJf9Ty8Wjk1Mnr63hGstsDWMbuhw4XDG1T7BjLxI+NbTWJpeAXov
			je7SLdXHMOZJHpFdorNb9wf7J16ZI/95lpLb8HlAotN3O2uvbwxbFJmWewTuPrwN
			i65RQzun2viP7D9VWOGdhj/MNoG/Z75u/18p+r0C5PPy0cnndGZJ66KZjd7Y6zG6
			5w/bzPtjED5h2gs4BkzDPujs6hqlu0XHiU54MgEMxGcuvnby4l1uH7mJCnnzD0DN
			QntuXElWVMj/Bzleq8jr60O5+rnBQR2n1uiK1241UzyESTWSGb7LGmma22Oe2Qq1
			qCcxAoIBAQCirAvf4fqEiOQkxpJDGZieiOtq7vjTK9T4/w9WUIBAis8oDgUoAU2k
			rBmw31dqDwfDADktbwQC6XdR/VVM9rMdmQ+I9h6Ggr7MAlDQn55OHFKIH8js6Zfe
			p0kCURvCMUTssGQvftalIA63HTlsFf7T36hAtE8F1C4U+sOojn4NpBtYLKrMka8s
			SW9u7LLgbCvcPVcanS6zCieQv1zKJM1GzurwqqFEnqcp6gLk++PLViafUbNEw7ca
			LiaaRRVmmfOHFqdnMDgcVV45ZRdEQqY5VoeIF+zj5nJz3nIqu+JC9PGhqcC+TYM4
			7wj+EBsnYO2fnHn3Psp9CUvY/G/qFFJq\
			""";

}