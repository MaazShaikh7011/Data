package com.opl.jns.published.lib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.published.lib.domain.BankApiResponse;

public interface BankApiResponseRepository extends JpaRepository<BankApiResponse,Long>{

	BankApiResponse findByApiIdAndOrgId(Long apiId, Long orgId);

}
