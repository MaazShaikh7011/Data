package com.opl.jns.published.lib.utils;

import java.util.ArrayList;
import java.util.List;

public enum SchemeMasterIds {

    ALL_SCHEME(-1L, -1L, "All Scheme", "All", -1),
    PMSBY(1L, 1L, "Pradhan Mantri Suraksha Bima Yojana", "PMSBY", 1),
    PMJJBY(2L, 1L, "Pradhan Mantri Jeevan Jyoti Bima Yojana", "PMJJBY", 1);

    private final Long id;
    private final Long loanMasterId;
    private final String name;
    private final String shortName;
    private final Integer bussinessTypeId;

    public static final List<SchemeMasterIds> SCHEME_LIST  = new ArrayList<SchemeMasterIds>(13);
    static {
        SCHEME_LIST.add(PMJJBY);
        SCHEME_LIST.add(PMSBY);
        SCHEME_LIST.add(ALL_SCHEME);
    }

    private SchemeMasterIds(Long id, Long loanMasterId, String name, String shortName, Integer bussinessTypeId) {
        this.id = id;
        this.loanMasterId = loanMasterId;
        this.name = name;
        this.shortName = shortName;
        this.bussinessTypeId = bussinessTypeId;
    }

    public Long getId() {
        return this.id;
    }

    public Long getLoanMasterId() {
        return this.loanMasterId;
    }

    public String getName() {
        return this.name;
    }

    public String getShortName() {
        return this.shortName;
    }

    public Integer getBussinessTypeId() {
        return this.bussinessTypeId;
    }

    public static SchemeMasterIds getById(Long v) {
        SchemeMasterIds[] var1 = values();
        int var2 = var1.length;

        for (int var3 = 0; var3 < var2; ++var3) {
            SchemeMasterIds c = var1[var3];
            if (c.id.equals(v)) {
                return c;
            }
        }

        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static SchemeMasterIds[] getAll() {
        return values();
    }
}
