package com.opl.jns.published.lib.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.opl.jns.published.lib.domain.APILogs;
import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.domain.UserOrganizationMaster;
import com.opl.jns.published.lib.repository.ApiUsersRepository;
import com.opl.jns.published.lib.repository.UserOrganizationMasterRepository;
import com.opl.jns.published.lib.service.AuthService;
import com.opl.jns.published.lib.utils.AuthCredentialUtils;
import com.opl.jns.published.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AuthController {

    public static final String AUTHENTICATION_NOT_AVAILABLE = "Authentication no available =====================>";

    public static final String EXIT_FROM_DASHBOARD = "Exit from dashboard =====================>";

    public static final String SUCCESS = "success";

    public static final String DASHBOARD = "dashboard";

    @Autowired
    private ApiUsersRepository apiUsersRepository;

    @Autowired
    private AuthService authService;
    
    @Autowired
    private UserOrganizationMasterRepository userOrganizationMasterRepository;

    @GetMapping("/login")
    public String login() {
        log.info("Entry in Login Page =====================>");
        return "login";
    }

    @GetMapping(value = {"/api-dashboard", "/api-dashboard/{pageNo}"})
    public String apiDashboard(@PathVariable(required = false) Integer pageNo, Model model, HttpServletRequest request) {

        log.info("Entry in dashboard =====================>");
        int pageSize = 10;
        if (!OPLUtils.isObjectNullOrEmpty(pageNo)) {
            if (pageNo == 0) {
                pageNo = 1;
            }
        } else {
            pageNo = 1;
        }
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (OPLUtils.isObjectNullOrEmpty(auth) || OPLUtils.isObjectNullOrEmpty(auth.getName())) {
            log.info(AUTHENTICATION_NOT_AVAILABLE);
            model.addAttribute(SUCCESS, "No");
            log.info(EXIT_FROM_DASHBOARD);
            return DASHBOARD;
        }
        if (!OPLUtils.isObjectNullOrEmpty(auth.getName()) && auth.getName().equals("api.user")) {
            log.info(AUTHENTICATION_NOT_AVAILABLE);
            model.addAttribute(SUCCESS, "NotAuthenticated");
            log.info(EXIT_FROM_DASHBOARD);
            return DASHBOARD;
        }
        String username = auth.getName();
        ApiUsers apiUsers = apiUsersRepository.findByLoginNameAndIsActive(username, Boolean.TRUE);
        if (!OPLUtils.isObjectNullOrEmpty(apiUsers) && !OPLUtils.isObjectNullOrEmpty(apiUsers.getId())) {
            String organizationName = StringUtils.EMPTY;
            if (!OPLUtils.isObjectNullOrEmpty(apiUsers.getOrganizationMaster())) {
                UserOrganizationMaster userOrganizationMaster = userOrganizationMasterRepository.findByOrgId(apiUsers.getOrganizationMaster().getOrgId());
                if (!OPLUtils.isObjectNullOrEmpty(userOrganizationMaster)) {
                    organizationName = userOrganizationMaster.getDisplayOrgName();
                }
            }
            Page<APILogs> page = authService.findPaginated(apiUsers.getId(), pageNo, pageSize);
            List<APILogs> listOfRequestAudit = page.getContent();
            int totalPages = page.getTotalPages();
            int pageNumber = 0;
            if (pageNo == 1) {
                pageNumber = pageNo;
            } else if (pageNo == page.getTotalPages()) {
                pageNumber = pageNo - 2;
            } else {
                pageNumber = pageNo - 1;
            }
            int pageNumbers = pageNo - 1;
            int[] body;
            if (page.getTotalPages() > 7) {
                int[] head = (pageNumber > 4) ? new int[]{1, -1} : new int[]{1, 2, 3};
                int[] bodyBefore = (pageNumber > 4 && pageNumber < totalPages - 1) ? new int[]{pageNumber - 2, pageNumber - 1} : new int[]{};
                int[] bodyCenter = (pageNumber > 3 && pageNumber < totalPages - 2) ? new int[]{pageNumber} : new int[]{};
                int[] bodyAfter = (pageNumber > 2 && pageNumber < totalPages - 3) ? new int[]{pageNumber + 1, pageNumber + 2} : new int[]{};
                int[] tail = (pageNumber < totalPages - 3) ? new int[]{-1, totalPages} : new int[]{totalPages - 2, totalPages - 1, totalPages};
                body = AuthCredentialUtils.merge(head, bodyBefore, bodyCenter, bodyAfter, tail);
            } else {
                body = new int[page.getTotalPages()];
                for (int i = 0; i < page.getTotalPages(); i++) {
                    body[i] = 1 + i;
                }
            }
            model.addAttribute("bankName", organizationName);
            model.addAttribute("listOfRequestAudit", listOfRequestAudit);
            model.addAttribute(SUCCESS, "Yes");
            model.addAttribute("userName", !OPLUtils.isObjectNullOrEmpty(apiUsers.getUserName()) ? apiUsers.getUserName() : "");
            model.addAttribute("apiKey", !OPLUtils.isObjectNullOrEmpty(apiUsers.getApiKey()) ? apiUsers.getApiKey() : "");
            model.addAttribute("totalPages", page.getTotalPages());
            model.addAttribute("pageNumbers", pageNumber);
            model.addAttribute("pageNo", pageNumbers);
            model.addAttribute("body", body);
            model.addAttribute("page", page);
            model.addAttribute("contextPath", request.getContextPath());
            log.info(EXIT_FROM_DASHBOARD);
            return DASHBOARD;
        }
        model.addAttribute(SUCCESS, "No");
        log.info(EXIT_FROM_DASHBOARD);
        return DASHBOARD;
    }
    
//    @GetMapping(value = {"/ready-application", "/ready-application/{pageNo}"})
//    public String getListOfReadyApplication(@PathVariable(value = "pageNo", required = false) Integer pageNo, Model model, HttpServletRequest request) {
//
//    	 log.info("Entry in ready-application =====================>");
//    	 int pageSize = 10;
//         if (!OPLUtils.isObjectNullOrEmpty(pageNo)) {
//             if (pageNo == 0) {
//                 pageNo = 1;
//             }
//         } else {
//             pageNo = 1;
//         }
//         Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//         if (OPLUtils.isObjectNullOrEmpty(auth) || OPLUtils.isObjectNullOrEmpty(auth.getName())) {
//             log.info(AUTHENTICATION_NOT_AVAILABLE);
//             model.addAttribute(SUCCESS, "No");
//             log.info("Exit in ready-application =====================>");
//             return READYAPPLICATION;
//         }
//         if (!OPLUtils.isObjectNullOrEmpty(auth.getName()) && auth.getName().equals("api.user")) {
//             log.info(AUTHENTICATION_NOT_AVAILABLE);
//             model.addAttribute(SUCCESS, "NotAuthenticated");
//             log.info("Exit in ready-application =====================>");
//             return READYAPPLICATION;
//         }
//         String username = auth.getName();
//         ApiUsers apiUsers = apiUsersRepository.findByLoginNameAndIsActive(username, Boolean.TRUE);
//         if (!OPLUtils.isObjectNullOrEmpty(apiUsers) && !OPLUtils.isObjectNullOrEmpty(apiUsers.getId())) {
//             String organizationName = StringUtils.EMPTY;
//             if (!OPLUtils.isObjectNullOrEmpty(apiUsers.getOrgId())) {
//                 Optional<UserOrganizationMaster> userOrganizationMaster = userOrganizationMasterRepositoryV2.findById(apiUsers.getOrgId());
//                 if (userOrganizationMaster.isPresent() && !OPLUtils.isObjectNullOrEmpty(userOrganizationMaster.get().getDisplayOrgName())) {
//                     organizationName = userOrganizationMaster.get().getDisplayOrgName();
//                 }
//             }
//
//             Page<ReadyApplicationMaster> page = authService.findReadyApplicationPaginated(apiUsers.getOrgId(), pageNo, pageSize);
//             List<ReadyApplicationMaster> listOfReadyApplication = page.getContent();
//
//             int totalPages = page.getTotalPages();
//             int pageNumber = 0;
//             if (pageNo == 1) {
//                 pageNumber = pageNo;
//             } else if (pageNo == page.getTotalPages()) {
//                 pageNumber = pageNo - 2;
//             } else {
//                 pageNumber = pageNo - 1;
//             }
//             int pageNumbers = pageNo - 1;
//             int[] body;
//             if (page.getTotalPages() > 7) {
//                 int[] head = (pageNumber > 4) ? new int[]{1, -1} : new int[]{1, 2, 3};
//                 int[] bodyBefore = (pageNumber > 4 && pageNumber < totalPages - 1) ? new int[]{pageNumber - 2, pageNumber - 1} : new int[]{};
//                 int[] bodyCenter = (pageNumber > 3 && pageNumber < totalPages - 2) ? new int[]{pageNumber} : new int[]{};
//                 int[] bodyAfter = (pageNumber > 2 && pageNumber < totalPages - 3) ? new int[]{pageNumber + 1, pageNumber + 2} : new int[]{};
//                 int[] tail = (pageNumber < totalPages - 3) ? new int[]{-1, totalPages} : new int[]{totalPages - 2, totalPages - 1, totalPages};
//                 body = AuthCredentialUtils.merge(head, bodyBefore, bodyCenter, bodyAfter, tail);
//             } else {
//                 body = new int[page.getTotalPages()];
//                 for (int i = 0; i < page.getTotalPages(); i++) {
//                     body[i] = 1 + i;
//                 }
//             }
//             model.addAttribute("bankName", organizationName);
//             model.addAttribute("listOfReadyApplication", listOfReadyApplication);
//             model.addAttribute(SUCCESS, "Yes");
//             model.addAttribute("userName", !OPLUtils.isObjectNullOrEmpty(apiUsers.getUserName()) ? apiUsers.getUserName() : "");
//             model.addAttribute("apiKey", !OPLUtils.isObjectNullOrEmpty(apiUsers.getApiKey()) ? apiUsers.getApiKey() : "");
//             model.addAttribute("totalPages", page.getTotalPages());
//             model.addAttribute("pageNumbers", pageNumber);
//             model.addAttribute("pageNo", pageNumbers);
//             model.addAttribute("body", body);
//             model.addAttribute("page", page);
//             model.addAttribute("contextPath", request.getContextPath());
//             log.info("Exit in ready-application =====================>");
//             return READYAPPLICATION;
//         }
//        model.addAttribute(SUCCESS, "No");
//        log.info("Exit in ready-application =====================>");
//        return READYAPPLICATION;
//
//    }
//
//    @GetMapping("/excel")
//    public String exportToExcel(HttpServletResponse response,Model model) throws IOException {
//        log.info("Entry in exportToExcel to ready-application =====================>");
//        try {
//            response.setContentType("application/octet-stream");
//            DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
//            String currentDateTime = dateFormatter.format(new Date());
//
//            String headerKey = "Content-Disposition";
//            String headerValue = "attachment; filename=ready_application_" + currentDateTime + ".xlsx";
//            response.setHeader(headerKey, headerValue);
//
//            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//            if (OPLUtils.isObjectNullOrEmpty(auth) || OPLUtils.isObjectNullOrEmpty(auth.getName())) {
//                log.info(AUTHENTICATION_NOT_AVAILABLE);
//                log.info("Exit in exportToExcel to ready-application =====================>");
//                model.addAttribute(SUCCESS, "No");
//                return "redirect:" + "/ready-application";
//            }
//            if ((!OPLUtils.isObjectNullOrEmpty(auth.getName()) && auth.getName().equals("api.user")) || (!OPLUtils.isObjectNullOrEmpty(auth.getName()) && auth.getName().equals("anonymousUser"))) {
//                log.info(AUTHENTICATION_NOT_AVAILABLE);
//                log.info("Exit in exportToExcel to ready-application =====================>");
//                model.addAttribute(SUCCESS, "NotAuthenticated");
//                return "redirect:" + "/ready-application";
//            }
//            String username = auth.getName();
//            List<ReadyApplicationMaster> masterList = new ArrayList<>();
//            ApiUsers apiUsers = apiUsersRepository.findByLoginNameAndIsActive(username, Boolean.TRUE);
//            if (!OPLUtils.isObjectNullOrEmpty(apiUsers) && !OPLUtils.isObjectNullOrEmpty(apiUsers.getOrgId())) {
//                masterList = authService.findReadyApplication(apiUsers.getOrgId());
//            }
//            log.info("<===============Start write excel file =====================>");
//            ReadyApplicationExcelExporter excelExporter = new ReadyApplicationExcelExporter(masterList);
//            excelExporter.export(response);
//            response.flushBuffer();
//            log.info("<===============End write excel file =====================>");
//            model.addAttribute(SUCCESS, "Download Successfully.");
//            return null;
//        } catch (Exception e) {
//            log.error("Something went wrong.", e);
//            return "redirect:" + "/ready-application";
//        }
//    }

    @GetMapping(value = "/requestResponseDetails/{logAuditId}")
    public String requestResponseAPI(@PathVariable Integer logAuditId, Model model) {
        log.info("Entry in dashboard =====================>");
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (OPLUtils.isObjectNullOrEmpty(auth) || OPLUtils.isObjectNullOrEmpty(auth.getName())) {
            log.info(AUTHENTICATION_NOT_AVAILABLE);
            model.addAttribute(SUCCESS, "No");
            log.info(EXIT_FROM_DASHBOARD);
            return DASHBOARD;
        }
        String username = auth.getName();
        ApiUsers apiUsers = apiUsersRepository.findByLoginNameAndIsActive(username, Boolean.TRUE);
        if (!OPLUtils.isObjectNullOrEmpty(apiUsers) && !OPLUtils.isObjectNullOrEmpty(apiUsers.getId())) {
            log.info(EXIT_FROM_DASHBOARD);
            return DASHBOARD;
        }
        model.addAttribute(SUCCESS, "No");
        log.info(EXIT_FROM_DASHBOARD);
        return DASHBOARD;
    }
}
