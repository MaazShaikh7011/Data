package com.opl.jns.published.lib.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rohit.prajapati
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class CommonRequest {

	private Long applicationId;
	private Long orgId;
	private Long userId;
	private Boolean isInsurer;
	
	@JsonProperty("token")
	private String token;
	
	/** SBI USE ONLY **/
	@JsonProperty("SOURCE_ID")
	private String sourceId;

}
