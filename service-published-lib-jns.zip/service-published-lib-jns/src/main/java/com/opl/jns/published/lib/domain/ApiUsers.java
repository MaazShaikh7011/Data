package com.opl.jns.published.lib.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/* CREATED DATE 22 NOV */
@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "api_users", indexes = {
		@Index(columnList = "user_name,api_key,is_active", name = DBNameConstant.JNS_CONFIG
				+ "_api_users_usrnm_apiky_actv_idx"),
		@Index(columnList = "login_name,password,is_active", name = DBNameConstant.JNS_CONFIG
				+ "_api_users_lgnm_pass_actv_idx"),
		@Index(columnList = "login_name,is_active", name = DBNameConstant.JNS_CONFIG + "_api_users_lgnm_actv_idx"),
		@Index(columnList = "org_id", name = DBNameConstant.JNS_CONFIG + "_api_users_orgid_idx"),
		@Index(columnList = "is_internal_user", name = DBNameConstant.JNS_CONFIG + "_api_users_intnlusr_idx"),
		@Index(columnList = "org_id,config_type", name = DBNameConstant.JNS_CONFIG
				+ "_api_users_org_cnfg_idx") }, catalog = DBNameConstant.JNS_CONFIG, schema = DBNameConstant.JNS_CONFIG)
public class ApiUsers implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "api_users_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_CONFIG, name = "api_users_seq_gen", sequenceName = "api_users_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "user_name", nullable = true)
	private String userName;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "org_id", referencedColumnName = "org_id")
	private UserOrganizationMaster organizationMaster;

	@Column(name = "public_key", nullable = true)
	private String publicKey;

	@Column(name = "private_key", nullable = true)
	private String privateKey;

	@Column(name = "api_key", nullable = true)
	private String apiKey;

	@Column(name = "ips", nullable = true)
	private String ips;

	@Column(name = "is_internal_user", nullable = true)
	private Boolean isInternalUser;

	/**
	 * login name and password used for swagger
	 */
	@Column(name = "login_name", nullable = true)
	private String loginName;

	@Column(name = "password", nullable = true)
	private String password;

	@Column(name = "URL_CONFIG", nullable = true)
	private String urlConfig;

	@Column(name = "header_config")
	private String headerConfig;

	@Column(name = "time_out_config")
	private String timeOutConfig;

	@Column(name = "config_type")
	private Integer configType;

	/**
	 * Audit fields
	 */
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@OneToMany(mappedBy = "apiUsers", fetch = FetchType.LAZY)
	private List<ErrorLog> errorLogs;

	@OneToMany(mappedBy = "apiUsers", fetch = FetchType.LAZY)
	private List<APILogs> requestLogAudits;

}
