package com.opl.jns.published.lib.utils;

import java.net.ConnectException;
import java.sql.SQLNonTransientConnectionException;

import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.opl.jns.published.utils.common.CommonResponse;

@ControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(DataAccessResourceFailureException.class)
    public ResponseEntity<CommonResponse> handleDbConnResourceException(DataAccessResourceFailureException e){
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setMessage("We are under schedule maintenance. Please try after sometime");
        commonResponse.setData("We are under schedule maintenance. Please try after sometime");
        commonResponse.setSuccess(false);
        commonResponse.setStatus(503);
        return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
    }

    @ExceptionHandler(ConnectException.class)
    public ResponseEntity<CommonResponse> handleDbConnectionException(ConnectException e){
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setMessage("We are under schedule maintenance. Please try after sometime");
        commonResponse.setData("We are under schedule maintenance. Please try after sometime");
        commonResponse.setSuccess(false);
        commonResponse.setStatus(503);
        return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
    }

    @ExceptionHandler(SQLNonTransientConnectionException.class)
    public ResponseEntity<CommonResponse> handleDbSqlTransactionException(SQLNonTransientConnectionException e){
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.setMessage("We are under schedule maintenance. Please try after sometime");
        commonResponse.setData("We are under schedule maintenance. Please try after sometime");
        commonResponse.setSuccess(false);
        commonResponse.setStatus(503);
        return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
    }

}
