
package com.opl.jns.published.lib.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.poi.util.BoundedInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;

import com.opl.jns.published.lib.domain.ApiUsers;
import com.opl.jns.published.lib.repository.ApiUsersRepository;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.common.RegistryResponse;
import com.opl.jns.published.utils.common.SymAsymEncryption;
import com.opl.jns.published.utils.config.PhaseMode;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class DecryptRequestBodyControllerAdvice implements RequestBodyAdvice {

	private static final String REGISTRY_DOCUMENTS = "/api/registry/v2/claimUploadDocuments";

	@Autowired
	private ApiUsersRepository apiUsersRepository;

	/**
	 * Load profile information
	 */

	/**
	 * This is set to false, it will not go this class again. return
	 * methodParameter.getMethod().isAnnotationPresent(SecurityParameter.class);
	 */
	@Override
	public boolean supports(MethodParameter methodParameter, Type type,
			Class<? extends HttpMessageConverter<?>> aClass) {
		return true;

	}

	@Override
	public HttpInputMessage beforeBodyRead(HttpInputMessage httpInputMsg, MethodParameter methodParameter, Type type,
			Class<? extends HttpMessageConverter<?>> aClass) throws IOException {

		HttpServletRequest servletRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		/* SKIP SWAGGER URLS */
		if (servletRequest.getAttribute(APIAuthUtils.REQ_ATR_IS_SWAGGER) != null) {
			return httpInputMsg;
		}

		/* SKIP ACTUATOR URLS */
		if (servletRequest.getAttribute(APIAuthUtils.REQ_ATR_IS_ACTUATOR) != null) {
			return httpInputMsg;
		}

		/*
		 * FETCH API USER ID FROM REQUEST ATTRIBUTE (SET FROM INTERCEPTOR PREHANDLE
		 * METHOD)
		 */
		Long apiUserId = APIAuthUtils.getHeaderAttribute(servletRequest, APIAuthUtils.REQ_ATR_APP_USER_ID, Long.class);
		log.info("apiUserId :: {} ", apiUserId);

		/* FETCH REQUETS DECRYPT BODY */
		String body = getBody(httpInputMsg);
		servletRequest.setAttribute(APIAuthUtils.REQUEST_ENCRYPT_BODY, body);

		String decryptText = null;
		String auditDecryptText = null;
		if (decryptFlag(httpInputMsg)) { /* CHECK DECRYPT FLAG ON | OFF */
			decryptText = body;
			auditDecryptText= body;
		} else {
			/* FETCH API USER OBJECT BY API USER ID FOR DECRYPT */
			ApiUsers apiUser = apiUsersRepository.findById(apiUserId).get();
			
			/* DECRYPT REQUEST */
			decryptText = decryptReq(body, apiUser.getPublicKey(), servletRequest);
			if (OPLUtils.isObjectNullOrEmpty(decryptText)) {
				servletRequest.setAttribute(APIAuthUtils.REQ_ATR_DEC_FAILED, Boolean.TRUE);
				servletRequest.setAttribute(APIAuthUtils.RESPONSE_TIME, new Date().getTime());
//				throw new IOException("Exception while decrypt request body");
			} else {
				/* SET NULL VALUE IN LARGE OBJECT TO AVOID STORAGE ISSUE */
				if (REGISTRY_DOCUMENTS.equals(servletRequest.getRequestURI())) {
					auditDecryptText = OPLJSONUtils.setNull(decryptText, "document");	
				}else {
					auditDecryptText=decryptText;
				}
			}
		}
		/* SET REQUEST PLAIN BODY IN REQUEST ATTBT */
		servletRequest.setAttribute(APIAuthUtils.REQUEST_PLAIN_BODY, auditDecryptText);

		/* CAST FOR SETTING TOKEN IN CASE OF INVALID REQUEST PASSED */
		Long headerAttribute = APIAuthUtils.getHeaderAttribute(servletRequest, APIAuthUtils.REQ_ATR_ORG_ID, Long.class);
		boolean phaseMode2 = false;
		if(!OPLUtils.isObjectNullOrEmpty(headerAttribute)) {			
			phaseMode2 =PhaseMode.checkPhase2Enroll(headerAttribute);
		}
		if (phaseMode2) {
			try {
				RegistryResponse requestForToken = MultipleJSONObjectHelper.getObjectFromString(auditDecryptText,
						RegistryResponse.class);
				if (!OPLUtils.isObjectNullOrEmpty(requestForToken) 
						&& !OPLUtils.isObjectNullOrEmpty(requestForToken.getToken())) {
					servletRequest.setAttribute(APIAuthUtils.REQ_ATR_TOKEN, requestForToken.getToken());
				} else {
					if(!OPLUtils.isObjectNullOrEmpty(servletRequest.getRequestURI()) && servletRequest.getRequestURI().contains("/v3/")) {
						throw new MissingServletRequestParameterException("Token", "String");
					}
				}
			} catch (MissingServletRequestParameterException e) {
				log.info("FAILED TOKEN NULL:: " + e + "==========auditDecryptText ----------->" + auditDecryptText);
				servletRequest.setAttribute(APIAuthUtils.RESPONSE_TIME, new Date().getTime());
				throw new IOException("Token is missing");
			} catch (Exception e) {
				log.info("FAILED TO SET TOKEN:: " + e + "==========auditDecryptText ----------->" + auditDecryptText);
			}
		} else {
			servletRequest.setAttribute(APIAuthUtils.REQ_ATR_TOKEN, UUID.randomUUID().toString());
		}

		ValidateHttpInputMessage validateHttpInputMessage = new ValidateHttpInputMessage(httpInputMsg);
		if(!OPLUtils.isObjectNullOrEmpty(decryptText)) {
			validateHttpInputMessage.setBody(IOUtils.toInputStream(decryptText, "UTF-8"));
		}else{
			log.info("Getting Error while decrypting the request body ");
		}
		servletRequest.setAttribute(APIAuthUtils.RESPONSE_TIME, new Date().getTime());
		return validateHttpInputMessage;

	}

	/**
	 * CHECK DECRYPT REQUEST FLAG ON | OFF
	 * 
	 * @param httpInputMsg
	 * @return
	 */
	private boolean decryptFlag(HttpInputMessage httpInputMsg) {
		HttpHeaders headers = httpInputMsg.getHeaders();

		if (headers.containsKey(APIAuthUtils.REQ_HEADER_DECRYPTION_SKIP.toLowerCase()) && "true"
				.equals(headers.get(APIAuthUtils.REQ_HEADER_DECRYPTION_SKIP.toLowerCase()).getFirst().toString())) {
			return true;
		}
		if (headers.containsKey(APIAuthUtils.REQ_AUTH)
				&& "true".equals(headers.get(APIAuthUtils.REQ_AUTH).getFirst().toString())) {
			return true;
		}
		return false;
	}

	/**
	 * DECRYPT REQUEST
	 * 
	 * @param body
	 * @param publicKey
	 * @param reqLogs
	 * @return
	 */
	private String decryptReq(String body, String publicKey, HttpServletRequest servletRequest) {
		try {
			/* FETCH OPL INTERNAL USER FOR OPL PUBLIC KEY */
			ApiUsers oplUser = apiUsersRepository.findFirstByIsInternalUserTrue();
			if (oplUser == null) {
				servletRequest.setAttribute(APIAuthUtils.DECRYPTION_MSG, "OPL User Not Found While Decrypt Request");
				return null;
			}
			@SuppressWarnings("rawtypes")
			Map encDataMap = MultipleJSONObjectHelper.getObjectFromString(body, Map.class);
			if (!OPLUtils.isObjectNullOrEmpty(encDataMap) && !encDataMap.isEmpty()
					&& encDataMap.containsKey(AuthCredentialUtils.META_DATA)) {
				String encryptedRequest = encDataMap.get(AuthCredentialUtils.META_DATA).toString();
				return new SymAsymEncryption().decrypt(encryptedRequest, oplUser.getPrivateKey(), publicKey);
			} else {
				log.info("Request is not valid to decrypt");
				servletRequest.setAttribute(APIAuthUtils.DECRYPTION_MSG, "Request is not valid to decrypt");
			}
		} catch (Exception e) {
			log.info("FAILED TO DECRYPT REQUEST:: ", e);
			servletRequest.setAttribute(APIAuthUtils.DECRYPTION_MSG, e.getMessage());
		}
		return null;
	}

	/**
	 * FETCH REQUEST BODY
	 * 
	 * @param httpInputMessage
	 * @return
	 * @throws IOException
	 */
	private String getBody(HttpInputMessage httpInputMessage) throws IOException {
		if (httpInputMessage.getHeaders().getOrEmpty("Content-Type") != null && httpInputMessage.getHeaders()
				.getOrEmpty("Content-Type").contains(MediaType.MULTIPART_FORM_DATA_VALUE)) {
			StringBuilder requestBody = new StringBuilder();
			try (InputStream bounded = new BoundedInputStream(httpInputMessage.getBody(), 1_048_576);
					BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bounded));) {
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					requestBody.append(line);
				}
				return String.valueOf(requestBody);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			return IOUtils.toString(httpInputMessage.getBody(), "UTF-8");
		}
		return null;
	}

	@Override
	public Object afterBodyRead(Object o, HttpInputMessage httpInputMessage, MethodParameter methodParameter, Type type,
			Class<? extends HttpMessageConverter<?>> aClass) {
		return o;
	}

	@Override
	public Object handleEmptyBody(Object o, HttpInputMessage httpInputMessage, MethodParameter methodParameter,
			Type type, Class<? extends HttpMessageConverter<?>> aClass) {
		return o;
	}

	class ValidateHttpInputMessage implements HttpInputMessage {
		HttpHeaders headers;
		InputStream body;

		public ValidateHttpInputMessage(HttpInputMessage httpInputMessage) {
			this.headers = httpInputMessage.getHeaders();

		}

		@Override
		public InputStream getBody() {
			return body;
		}

		@Override
		public HttpHeaders getHeaders() {
			return headers;
		}

		public void setBody(InputStream body) {
			this.body = body;
		}

		public void setHeaders(HttpHeaders headers) {
			this.headers = headers;
		}

	}

}
