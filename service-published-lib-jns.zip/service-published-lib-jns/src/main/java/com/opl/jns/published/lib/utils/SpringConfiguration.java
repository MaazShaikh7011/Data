package com.opl.jns.published.lib.utils;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableAsync
public class SpringConfiguration implements WebMvcConfigurer {

	@Bean
	AuthenticationInterceptor authenticationInterceptor() {
		return new AuthenticationInterceptor();
	}

	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(authenticationInterceptor()).addPathPatterns("/**");
	}

/*
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
		resolvers.add(new RequestDataResolver());
	}

	 @Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		 converters.add(new RequestResponseConverter());
	 }
*/


//		@Bean
//	public MappedInterceptor mappedInterceptor() {
//		return new MappedInterceptor(null, // => maps to any repository
//				authenticationInterceptor());
//	}
}
