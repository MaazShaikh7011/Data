package com.opl.jns.published.lib.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.UUID;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

import com.opl.jns.published.utils.common.ApiRequest;
import com.opl.jns.published.utils.common.OPLUtils;

public class AuthCredentialUtils {

	private static final Logger logger = LoggerFactory.getLogger(AuthCredentialUtils.class);

	public static final String REGISTRY_CONTEXT_PATH = "/api/registry";
	public static final String PUBLISH_CONTEXT_PATH = "/api/jns";

	public static final String REQUEST_HEADER_AUTHENTICATE = "ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo";
	public static final String REQUEST_HEADER_AUTHENTICATE_VALUE = "true";
	public final static String SESSION_OBJ_KEY = "user";
	public final static String REQUEST = "request";
	public final static String APP_REF_ID = "applicationReferenceId";
	public final static String MESSAGE = "message";
//	public final static String INVALID_DATA = "invalidData";
	public final static String DEC_FAILED_RES_ADDED = "decFailedResAdded";
	public final static String TMP_DATA = "tmp";
	public final static String FROM_IP = "fromIp";
	public final static String META_DATA = "meta-data";
	public final static String SCHEME_ID = "schemeId";
	public final static String MAX_CALL_REACH = "maximum_call_reach";
	public final static String APPLICATION_CALL_RESTRICTION_NO = "APPLICATION_CALL_RESTRICTION";
	public final static String IN_ACTIVE_API = "in_active_api";
	public final static String IN_ACTIVE_MSG = "in_active_msg";
	public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static String generateRandomToken() {
		return UUID.randomUUID().toString();
	}

	public final class AppRequestHeader {
		private AppRequestHeader() {
			// Nothing to do for X and Y
		}

		public static final String MOBILE_NO = "mobile";
		public static final String MODEL_NO = "model";
		public static final String MOBILE_OS = "os";
		public static final String OS_VERSION = "osvrsn";
		public static final String IMEI_NO = "imei";
		public static final String REQUEST_NO = "req";
		public static final String AUTH_TOKEN = "tk";
	}

	public static void setClient(HttpHeaders headers) {
		headers.set(REQUEST_HEADER_AUTHENTICATE, REQUEST_HEADER_AUTHENTICATE_VALUE);
	}

	public static boolean isClient(HttpServletRequest request) {
		String reqAuth = request.getHeader(REQUEST_HEADER_AUTHENTICATE);
		if (reqAuth != null && reqAuth != "" && REQUEST_HEADER_AUTHENTICATE_VALUE.equals(reqAuth)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	/**
	 * THIS METHOD IS CHECK TOKEN IS NOT NULL AND SET ALL TOKENS IN AUTH REQUEST
	 * MODEL CLASS THIS IS METHOD IS USE IN AUTHENTICATION INTECEPTOR CLASS FOR
	 * AUTHENTICATE TOKEN AND REQUEST
	 *
	 * @return AuthRequest
	 */
	public static ApiRequest httpResToAuthReq(HttpServletRequest request) {
		if (request == null) {
			return null;
		}
		try {
			String username = request.getHeader(APIAuthUtils.REQ_HEADER_USERNAME);
			String apiKey = request.getHeader(APIAuthUtils.REQ_HEADER_API_KEY);
			if (OPLUtils.isObjectNullOrEmpty(apiKey) || OPLUtils.isObjectNullOrEmpty(username)) {
				return null;
			}
			ApiRequest apiRequest = new ApiRequest();
			apiRequest.setUsername(username);
			apiRequest.setApiKey(apiKey);
			return apiRequest;
		} catch (Exception e) {
			logger.error("Exception while Convert HttpResponse To AuthRequest -> ", e);
			return null;
		}
	}

	public static int[] merge(int[]... intarrays) {
		return Arrays.stream(intarrays).flatMapToInt(Arrays::stream).toArray();
	}

}
