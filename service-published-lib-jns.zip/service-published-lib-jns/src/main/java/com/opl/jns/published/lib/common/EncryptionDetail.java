package com.opl.jns.published.lib.common;

public class EncryptionDetail {

	public String headerKey;

	public String encryptionRequestBody;

	public String digitalSignature;

	private String userName;

	private String password;

	// new added 18-07-2020
	private String privatekey;

	private String publickey;

	public String getHeaderKey() {
		return headerKey;
	}

	public void setHeaderKey(String headerKey) {
		this.headerKey = headerKey;
	}

	public String getEncryptionRequestBody() {
		return encryptionRequestBody;
	}

	public void setEncryptionRequestBody(String encryptionRequestBody) {
		this.encryptionRequestBody = encryptionRequestBody;
	}

	public String getDigitalSignature() {
		return digitalSignature;
	}

	public void setDigitalSignature(String digitalSignature) {
		this.digitalSignature = digitalSignature;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrivatekey() {
		return privatekey;
	}

	public void setPrivatekey(String privatekey) {
		this.privatekey = privatekey;
	}

	public String getPublickey() {
		return publickey;
	}

	public void setPublickey(String publickey) {
		this.publickey = publickey;
	}

	@Override
	public String toString() {
		return "EncryptionDetail [headerKey=" + headerKey + ", encryptionRequestBody=" + encryptionRequestBody
				+ ", digitalSignature=" + digitalSignature + ", userName=" + userName + ", password=" + password
				+ ", privatekey=" + privatekey + ", publickey=" + publickey + "]";
	}

}