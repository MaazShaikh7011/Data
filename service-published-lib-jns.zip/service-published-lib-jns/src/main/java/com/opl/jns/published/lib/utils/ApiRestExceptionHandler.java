package com.opl.jns.published.lib.utils;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.METHOD_NOT_ALLOWED;
import static org.springframework.http.HttpStatus.UNSUPPORTED_MEDIA_TYPE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import jakarta.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.PublishResponse;


@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class ApiRestExceptionHandler extends ResponseEntityExceptionHandler {


    private final static Logger log = LoggerFactory.getLogger(ApiRestExceptionHandler.class);
    /**
     * Handle MissingServletRequestParameterException. Triggered when a 'required' request parameter is missing.
     *
     * @param ex      MissingServletRequestParameterException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders headers,
            HttpStatusCode status, WebRequest request) {
        String error = ex.getParameterName() + " parameter is missing";
        CommonResponse commonResponse = getResponseClass(request);
        commonResponse.setMessage(error);
        commonResponse.setStatus(BAD_REQUEST.value());
        return buildResponseEntity(commonResponse);
    }


    /**
     * Handle HttpMediaTypeNotSupportedException. This one triggers when JSON is invalid as well.
     *
     * @param ex      HttpMediaTypeNotSupportedException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
            HttpMediaTypeNotSupportedException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        StringBuilder builder = new StringBuilder();
        builder.append(ex.getContentType());
        builder.append(" Media type is not supported. Supported media types are ");
        ex.getSupportedMediaTypes().forEach(t -> builder.append(t).append(", "));
        CommonResponse commonResponse = getResponseClass(request);
        commonResponse.setMessage(builder.substring(0, builder.length() - 2));
        commonResponse.setStatus(UNSUPPORTED_MEDIA_TYPE.value());
        return buildResponseEntity(commonResponse);
    }

    /**
     * Handle MethodArgumentNotValidException. Triggered when an object fails @Valid validation.
     *
     * @param ex      the MethodArgumentNotValidException that is thrown when @Valid validation fails
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        CommonResponse commonResponse = getResponseClass(request);
        List<String> errorMessages = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getField().concat(" ").concat(x.getDefaultMessage())).collect(Collectors.toList());
        commonResponse.setMessage(errorMessages.stream().collect(Collectors.joining(", ", "", "")));
        commonResponse.setStatus(BAD_REQUEST.value());
        commonResponse.setSuccess(false);
        return buildResponseEntity(commonResponse);
    }


    /**
     * Handle HttpMessageNotReadableException. Happens when request JSON is malformed.
     *
     * @param ex      HttpMessageNotReadableException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
        log.info("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());

        String error = "It seems that request is not properly formed";
        CommonResponse commonResponse = getResponseClass(request);
        if(ex.getCause() instanceof InvalidFormatException){
            List<String> fieldsWithInvalidData  = new ArrayList<>();
            List<JsonMappingException.Reference> referenceList = ((InvalidFormatException)ex.getCause()).getPath();
            if(referenceList != null){
                fieldsWithInvalidData  = referenceList.stream().map(JsonMappingException.Reference::getFieldName).collect(Collectors.toList());
            }
            String invalidFieldsLstStr =fieldsWithInvalidData.toString();
            if(invalidFieldsLstStr != null){
                invalidFieldsLstStr =invalidFieldsLstStr.replace("[","").replace("]","");
                invalidFieldsLstStr += " field contains invalid value";
            }
            commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
            commonResponse.setMessage(invalidFieldsLstStr);
            commonResponse.setSuccess(Boolean.FALSE);
            return buildResponseEntityApiSuccess(commonResponse,HttpStatus.OK.value());
        }
        commonResponse.setMessage(error);
        commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
        return buildResponseEntity(commonResponse);
    }

    /**
     * Handle HttpMessageNotWritableException.
     *
     * @param ex      HttpMessageNotWritableException
     * @param headers HttpHeaders
     * @param status  HttpStatus
     * @param request WebRequest
     * @return the ApiError object
     */
    protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        String error = "Error writing Response output";
        CommonResponse commonResponse = getResponseClass(request);
        commonResponse.setMessage(error);
        commonResponse.setStatus(INTERNAL_SERVER_ERROR.value());
        return buildResponseEntity(commonResponse);
    }

    /**
     * Handle NoHandlerFoundException.
     *
     * @param ex
     * @param headers
     * @param status
     * @param request
     * @return
     */
    protected ResponseEntity<Object> handleNoHandlerFoundException(
            NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        CommonResponse apiError = getResponseClass(request);
        apiError.setStatus(BAD_REQUEST.value());
        apiError.setMessage("Could not find the %s method for URL %s".formatted(ex.getHttpMethod(), ex.getRequestURL()));
        apiError.setMessage(ex.getMessage());
        return buildResponseEntity(apiError);
    }



    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
                                                                         HttpHeaders headers, HttpStatusCode status, WebRequest request) {

        CommonResponse apiError = getResponseClass(request);
        apiError.setStatus(METHOD_NOT_ALLOWED.value());
        apiError.setMessage("Requested Method not supported");
        StringBuilder builder = new StringBuilder();
        Set<HttpMethod> supportedHttpMethods = ex.getSupportedHttpMethods();
        if(null != supportedHttpMethods) {
            supportedHttpMethods.forEach(t -> builder.append(t).append(", "));
        }
        apiError.setMessage(ex.getMessage());
        return buildResponseEntity(apiError);
    }


    private ResponseEntity<Object> buildResponseEntity(CommonResponse commonResponse) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        commonResponse.setSuccess(Boolean.FALSE);
        return new ResponseEntity<>(commonResponse, headers,HttpStatus.OK.value());
    }

    private ResponseEntity<Object> buildResponseEntityApiSuccess(CommonResponse commonResponse,Integer status) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        /*String data = null;
        try {
            data = MultipleJSONObjectHelper.getStringfromObject(commonResponse);
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        return new ResponseEntity<>(commonResponse, headers,HttpStatus.OK.value());
    }

    private CommonResponse  getResponseClass(WebRequest request){
        ServletWebRequest servletWebRequest = (ServletWebRequest) request;
    log.info("{} to {}", servletWebRequest.getHttpMethod(), servletWebRequest.getRequest().getServletPath());
        String contextPath = servletWebRequest.getContextPath();

        CommonResponse commonResponse = null;
        if(contextPath.equals(AuthCredentialUtils.REGISTRY_CONTEXT_PATH)){
            commonResponse = new PublishResponse();
            if(null != servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN,ServletRequestAttributes.SCOPE_REQUEST)) {
                ((PublishResponse) commonResponse).setToken(servletWebRequest.getAttribute(APIAuthUtils.REQ_ATR_TOKEN, ServletRequestAttributes.SCOPE_REQUEST).toString());

            }
            ((PublishResponse) commonResponse).setTimestamp(AuthCredentialUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(new Date()));
        }else{
            commonResponse = new CommonResponse();
        }
        return commonResponse;
    }

    /* Added handler for CRM service*/
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Object> handleConstraintViolation(ConstraintViolationException ex, WebRequest request) {
        CommonResponse apiError = getResponseClass(request);
        apiError.setStatus(BAD_REQUEST.value());
        apiError.setMessage(ex.getMessage());
        return buildResponseEntity(apiError);
    }

}
