package com.opl.jns.published.lib.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.published.lib.domain.ApiUsers;

@Repository
public interface ApiUsersRepository extends JpaRepository<ApiUsers, Long> {

	@Cacheable(value = "API_APIUSERS_FIND_BY_USERNAME_KEY_ISACTIVE")
	ApiUsers findFirstByUserNameAndApiKeyAndIsActiveOrderByIdDesc(String userName, String apiKey, Boolean isActive);

	@Cacheable(value = "API_APIUSERS_FIND_BY_ID")
	Optional<ApiUsers> findById(Long id);	
	
	ApiUsers findFirstById(Long id);

	ApiUsers findByLoginNameAndPasswordAndIsActive(String loginName, String password, Boolean isActive);

	ApiUsers findByLoginNameAndIsActive(String loginName, Boolean isActive);

	ApiUsers findFirstByOrganizationMasterOrgId(Long orgId);

	@Cacheable(value = "API_APIUSERS_FIND_INTERNAL_USER")
	ApiUsers findFirstByIsInternalUserTrue();

	ApiUsers findFirstByOrganizationMasterOrgIdAndConfigType(Long orgId, Integer configType);
	
	List<ApiUsers> findAllByIsActiveTrue();

}
