package com.opl.jns.auth.api.exception;

public class TokenNotFountException extends RuntimeException {

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public TokenNotFountException(String message){
			super(message);
		}
}
