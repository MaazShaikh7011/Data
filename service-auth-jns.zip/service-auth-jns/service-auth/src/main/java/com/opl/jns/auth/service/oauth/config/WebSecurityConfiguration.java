//package com.opl.ans.common.service.auth.oauth.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.WebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//import config.com.opl.jns.auth.service.PasswordEncoderUtils;
//
//@Configuration
//public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {
//
//	@Autowired
//	UserDetailsService userDetailsService;
//
//	@Bean
//	protected AuthenticationManager getAuthenticationManager() throws Exception {
//		return super.authenticationManagerBean();
//	}
//
//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		return new PasswordEncoderUtils();
//	}
//
//	/*~~(Migrate manually based on https://spring.io/blog/2022/02/21/spring-security-without-the-websecurityconfigureradapter)~~>*/@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
//	}
//
//	@Override
//	public void configure(WebSecurity web) throws Exception {
//				web.ignoring().requestMatchers("/actuator/**", "/getRefreshToken", "/getAccessToken", "/checkAccessToken", "/logoutUser", "/getTokenByLoginToken", "/getTokenByLoginTokenForSidbi", "/getByLoginToken", "/getLastLoginDetailsFromUserId", "/getTokensByUserId", "/check_user_loggined", "/checkAuthStarted", "/updateCustomerInTokenMapping", "/getTokenForBankerAsPartner"
//				);
//	}
//
//}
