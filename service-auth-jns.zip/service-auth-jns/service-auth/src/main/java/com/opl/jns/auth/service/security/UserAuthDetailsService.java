package com.opl.jns.auth.service.security;

import java.util.Collections;
import java.util.Map;
import java.util.regex.Pattern;

import com.opl.jns.auth.service.domain.User;
import com.opl.jns.auth.service.repositories.UserRepository;
import com.opl.jns.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.utils.AuthCredentialUtils;

@Service("UserAuthDetailsService")
public class UserAuthDetailsService implements UserDetailsService {

	private final Logger log = LoggerFactory.getLogger(UserAuthDetailsService.class);
	private static final String USER = "User ";
	private static final String IS_NOT_ACTIVATED = " is not activated";

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String un) throws UsernameNotFoundException {

		String[] pwd = un.toString().split(Pattern.quote("$"));

		Map<String, String> map = AuthCredentialUtils.getUserName(pwd[0]);
		String username = map.get(AuthCredentialUtils.USER_NAME);
		String isEmail = map.get(AuthCredentialUtils.IS_EMAIL);

		Long userTypeId = Long.valueOf(pwd[1]);

		// find user object by user name
		User user = null;
		if (AuthCredentialUtils.IS_EMAIL_TRUE_VALUE.equals(isEmail)) {
			user = userRepository.getByCaseSensitiveEmailAndUserTypeMasterId(username, userTypeId);
		} else {
			user = userRepository.findOneByMobileAndUserTypeMasterId(username, userTypeId);
		}
		if (user == null) {
			log.info(USER + username + " was not found in the database");
			throw new UsernameNotFoundException(USER + username + " was not found in the database");
		}

		if (OPLUtils.isObjectNullOrEmpty(user.getIsActive()) || !user.getIsActive()) {
			log.info(USER + username + IS_NOT_ACTIVATED);
			throw new UserNotActivatedException(USER + username + IS_NOT_ACTIVATED);
		}

		String pass = user.getPassword();
		if (AuthCredentialUtils.IS_EMAIL_FALSE_VALUE.equals(isEmail) && user.getPassword() == null) {
			pass = AuthCredentialUtils.TEMP_PP;
		}

		// send user name and password to user security class for check valid or not
		return new org.springframework.security.core.userdetails.User(username, pass, Collections.emptyList());

	}
}
