package com.opl.jns.auth.service.repositories;

import com.opl.jns.auth.service.domain.UserMobileFcmMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserMobileFcmMappingRepository extends JpaRepository<UserMobileFcmMapping,Long> {

	@Modifying
	@Query("UPDATE UserMobileFcmMapping set isActive = false, modifiedDate = CURRENT_TIMESTAMP WHERE token =:token and isActive = true")
	public int inActiveByToken(@Param("token") String token);
	
}
