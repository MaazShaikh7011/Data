package com.opl.jns.auth.service.service;

import com.opl.jns.auth.api.model.UserRequest;

public interface UserService {

	public UserRequest findOneByEmailByUserTypeId(String email, Long userTypeId);
}
