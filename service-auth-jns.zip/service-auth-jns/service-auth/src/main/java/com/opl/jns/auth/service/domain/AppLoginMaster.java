package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "app_login_master")
public class AppLoginMaster implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_login_master_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "app_login_master_auth_seq_gen", sequenceName = "app_login_master_auth_seq", allocationSize = 1)
    private Long id;

    @Column(name = "email", columnDefinition = "varchar(200) default ''")
    private String email;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "user_type")
    private Long userType;

    @Column(name = "token", columnDefinition = "varchar(500) default ''")
    private String token;

    @Column(name = "mobile_no", columnDefinition = "varchar(20) default ''")
    private String mobileNo;

    @Column(name = "imei_no", columnDefinition = "varchar(100) default ''")
    private String imeiNo;

    @Column(name = "model_no", columnDefinition = "varchar(100) default ''")
    private String modelNo;

    @Column(name = "mobile_os", columnDefinition = "varchar(100) default ''")
    private String mobileOs;

    @Column(name = "os_version", columnDefinition = "varchar(100) default ''")
    private String osVersion;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "login_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date loginDate;

    @Column(name = "is_active")
    private Boolean isActive;

    public AppLoginMaster(String email, String token, Date loginDate) {
        this.email = email;
        this.token = token;
        this.loginDate = loginDate;
    }

}
