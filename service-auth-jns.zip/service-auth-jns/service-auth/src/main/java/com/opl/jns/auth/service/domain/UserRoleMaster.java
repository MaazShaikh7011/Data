package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the user_role_master database table.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_role_master")
public class UserRoleMaster implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_role_master_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_role_master_auth_seq_gen", sequenceName = "user_role_master_auth_seq", allocationSize = 1)
    @Column(name = "role_id")
    private Long roleId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "role_name", columnDefinition = "varchar(255) default ''")
    private String roleName;

    @Column(name = "display_name", columnDefinition = "varchar(255) default ''")
    private String displayName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date")
    private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date")
    private Date modifiedDate;

}