package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the user_type_master database table.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_type_master")
public class UserTypeMaster implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_type_master_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_type_master_auth_seq_gen", sequenceName = "user_type_master_auth_seq", allocationSize = 1)
    private Long id;

    @Column(columnDefinition = "varchar(250) default ''")
    private String code;

    @Column(name = "created_by")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @Column(columnDefinition = "varchar(500) default ''")
    private String description;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_display_on_login")
    private Boolean isDisplayOnLogin;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedDate;

    @Column(columnDefinition = "varchar(200) default ''")
    private String name;

    public UserTypeMaster(Long id) {
        this.id = id;
    }
//
//	public User addUser(User user) {
//		getUsers().add(user);
//		user.setUserTypeMaster(this);
//
//		return user;
//	}
//
//	public User removeUser(User user) {
//		getUsers().remove(user);
//		user.setUserTypeMaster(null);
//
//		return user;
//	}

}