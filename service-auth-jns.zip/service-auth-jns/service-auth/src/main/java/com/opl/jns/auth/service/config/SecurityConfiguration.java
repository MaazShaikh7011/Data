package com.opl.jns.auth.service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring()
                .requestMatchers("/actuator/**",
                        "/getRefreshToken",
                        "/getAccessToken",
                        "/checkAccessToken",
                        "/logoutUser",
                        "/getTokenByLoginToken",
                        "/getTokenByLoginTokenForSidbi",
                        "/getByLoginToken",
                        "/getLastLoginDetailsFromUserId",
                        "/getTokensByUserId",
                        "/check_user_loggined",
                        "/checkAuthStarted",
                        "/updateCustomerInTokenMapping",
                        "/getTokenForBankerAsPartner",
                        "/getLoginTimeIncrese");
    }

}
