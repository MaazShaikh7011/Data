package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "users")
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "users_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS,name = "users_auth_seq_gen", sequenceName = "users_auth_seq", allocationSize = 1)
    @Column(name = "user_id")
    private Long userId;

    @Convert(converter = AESOracle.class)
    @Column(name = "email", columnDefinition = "varchar(255) default ''")
    private String email;

    @Convert(converter = AESOracle.class)
    @Column(columnDefinition = "varchar(255) default ''")
    private String mobile;

    @Column(columnDefinition = "varchar(255) default ''")
    private String password;

    @Convert(converter = AESOracle.class)
    @Column(columnDefinition = "varchar(50) default ''")
    private String username;

    @Convert(converter = AESOracle.class)
    @Column(name = "first_name", columnDefinition = "varchar(200) default ''")
    private String firstName;

    @Convert(converter = AESOracle.class)
    @Column(name = "last_name", columnDefinition = "varchar(200) default ''")
    private String lastName;

    @Convert(converter = AESOracle.class)
    @Column(name = "middle_name", columnDefinition = "varchar(200) default ''")
    private String middleName;

    @Column(name = "last_business_type_id")
    private Integer lastBusinessTypeId;

    @Column(name = "terms_accepted")
    private Boolean termsAccepted;

    @Column(name = "otp_verified")
    private Boolean otpVerified;

    @Column(name = "email_verified")
    private Boolean emailVerified;

    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @Column(name = "is_locked")
    private Boolean isLocked;

    @Column(name = "login_counter")
    private Integer loginCounter;

    @Column(name = "campaign_code", columnDefinition = "varchar(100) default ''")
    private String campaignCode;

    @Column(name = "password1", columnDefinition = "varchar(255) default ''")
    private String password1;

    @Column(name = "password2", columnDefinition = "varchar(255) default ''")
    private String password2;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "sign_up_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date signUpDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_org_id", referencedColumnName = "user_org_id")
    private UserOrganisationMaster userOrgId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_role_id", referencedColumnName = "role_id")
    private UserRoleMaster userRoleId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_type_id", referencedColumnName = "id")
    private UserTypeMaster userTypeMaster;

    @Column(name = "is_pass_changed")
    private Boolean isPassChanged;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedDate;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_by")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", referencedColumnName = "id")
    private BranchMaster branchId;


}
