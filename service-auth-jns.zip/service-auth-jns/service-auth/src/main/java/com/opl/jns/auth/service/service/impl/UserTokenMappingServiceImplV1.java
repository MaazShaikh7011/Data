package com.opl.jns.auth.service.service.impl;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpStatusCodeException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.api.model.CustomUserTokenMapping;
import com.opl.jns.auth.api.model.LogResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.auth.api.utils.EncodeDecodeHelper;
import com.opl.jns.auth.service.domain.User;
import com.opl.jns.auth.service.domain.UserMobileFcmMapping;
import com.opl.jns.auth.service.domain.UserTokenMapping;
import com.opl.jns.auth.service.repositories.UserMobileFcmMappingRepository;
import com.opl.jns.auth.service.repositories.UserRepository;
import com.opl.jns.auth.service.repositories.UserTokenMappingRepository;
import com.opl.jns.auth.service.service.TokenService;
import com.opl.jns.auth.service.service.UserTokenMappingServiceV1;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class UserTokenMappingServiceImplV1 implements UserTokenMappingServiceV1 {

//	private static final Random random = new Random();
	private static final SecureRandom random = new SecureRandom();
	private static final Long MARKET_PLACE = 1L;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserTokenMappingRepository userTokenMappingRepository;

	@Autowired
	private UserMobileFcmMappingRepository userMobileFcmMappingRepo;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private TokenService tokenService;

	@Value("${com.opl.test.mode}")
	private String testMode;

	@Autowired
	private JwtEncoder jwtEncoder;
	
	@Override
	public AuthClientResponse checkAccessToken(AuthRequest req) {
		UserTokenMapping userTokenMapping = userTokenMappingRepository.findByUserNameAndLoginTokenAndActive(req.getUsername(),
				req.getLoginToken(), true);
		AuthClientResponse response = new AuthClientResponse();
		if (userTokenMapping == null) {
			return response;
		} else {
			if (testMode != null && "ON".equals(testMode)) {
				response.setUserId(userTokenMapping.getUserId());
				response.setUserType(userTokenMapping.getUserType());
				response.setUserRoleId(userTokenMapping.getUserRoleId());
				response.setUserOrgId(userTokenMapping.getUserOrgId());
				response.setUserBranchId(userTokenMapping.getUserBranchId());
				return response;
			}
			User user = userRepository.findById(userTokenMapping.getUserId()).orElse(null);
			if (user != null) {
				response.setUserRoleId(user.getUserRoleId() != null ? user.getUserRoleId().getRoleId() : null);
				response.setLastBusinessTypeId(user.getLastBusinessTypeId());
				response.setEmail(user.getEmail());
				response.setUserName(user.getUsername());
				response.setMobile(user.getMobile());
				String name = !OPLUtils.isObjectNullOrEmpty(user.getFirstName()) ? user.getFirstName() : "";
				name = name + (!OPLUtils.isObjectNullOrEmpty(user.getMiddleName()) ? " " + user.getMiddleName() : "");
				name = name + (!OPLUtils.isObjectNullOrEmpty(user.getLastName()) ? " " + user.getLastName() : "");
				response.setName(!OPLUtils.isObjectNullOrEmpty(user.getLastName()) ? name : user.getUsername());
				response.setUserOrgId(user.getUserOrgId() != null ? user.getUserOrgId().getUserOrgId() : null);
				response.setUserBranchId(user.getBranchId() != null ? user.getBranchId().getId() : null);
			}
			response.setUserId(userTokenMapping.getUserId());
			response.setUserType(userTokenMapping.getUserType());
			response.setClientUserId(userTokenMapping.getClientUserId());
			return response;
		}
	}

//	public void updateAccessToken(CustomUserTokenMapping mapping) {
//		userTokenMappingRepository.updateAccessToken(mapping.getUserName(), mapping.getRefreshToken(),
//				mapping.getAccessToken(), mapping.getExpiresIn(), mapping.getLoginToken());
//	}

	@Override
	public AuthResponse createNewUserWithToken(CustomUserTokenMapping mapping, AuthResponse response) {

		Map<String, String> map = AuthCredentialUtils.getUserName(mapping.getUserName());
		String userName = map.get(AuthCredentialUtils.USER_NAME);
		String isEmail = map.get(AuthCredentialUtils.IS_EMAIL);

		UserTokenMapping userTokenMapping = new UserTokenMapping();
		BeanUtils.copyProperties(mapping, userTokenMapping, "id", "active");
		userTokenMapping.setUserName(userName);
		User user = null;
		if (AuthCredentialUtils.IS_EMAIL_TRUE_VALUE.equals(isEmail)) {
			user = userRepository.getByCaseSensitiveEmailAndUserTypeMasterId(userName, mapping.getUserTypeId());
		} else {
			user = userRepository.findOneByMobileAndUserTypeMasterId(userName, mapping.getUserTypeId());
		}
		userTokenMapping.setActive(true);
		userTokenMapping.setLoginDate(new Date());
		userTokenMapping.setUserIp(mapping.getUserIp());
		userTokenMapping.setUserBrowser(mapping.getUserBrowser());
		userTokenMapping.setDomainIsactive(mapping.isDomainLogin());
		Integer randomNumber = getRandomNumber();
		userTokenMapping.setLoginToken(randomNumber);
		if (user != null) {
			userTokenMapping.setUserId(user.getUserId());
			userTokenMapping.setUserType(user.getUserTypeMaster().getId());
			if (!OPLUtils.isObjectNullOrEmpty(user.getUserOrgId())) {
				response.setUserOrgId(user.getUserOrgId().getUserOrgId());
				userTokenMapping.setUserOrgId(user.getUserOrgId().getUserOrgId());
			}
			if (!OPLUtils.isObjectNullOrEmpty(user.getBranchId())) {
				response.setUserBranchId(user.getBranchId().getId());
				userTokenMapping.setUserBranchId(user.getBranchId().getId());
			}
			if (!OPLUtils.isObjectNullOrEmpty(user.getUserRoleId())) {
				response.setUserRoleId(user.getUserRoleId().getRoleId());
				userTokenMapping.setUserRoleId(user.getUserRoleId().getRoleId());
			}
			response.setUserType(user.getUserTypeMaster().getId());
			response.setUserId(user.getUserId());
		}
		userTokenMapping.setMobileOs(mapping.getMobileOs());
		userTokenMapping.setImeiNo(mapping.getImeiNo());
		userTokenMapping.setModelNo(mapping.getModelNo());
		userTokenMapping.setOsVersion(mapping.getOsVersion());
		userTokenMapping.setAppVersion(mapping.getAppVersion());
		userTokenMapping.setBrowserVersion(mapping.getBrowserVersion());
		userTokenMapping.setDevice(mapping.getDevice());
		userTokenMapping.setDeviceType(mapping.getDeviceType());
		userTokenMapping.setDeviceOs(mapping.getDeviceOs());
		userTokenMapping.setDeviceOsVersion(mapping.getDeviceOsVersion());
		userTokenMapping.setUserAgent(mapping.getUserAgent());
		userTokenMapping.setCampaignCode(mapping.getCampaignCode());
		userTokenMapping.setCampaignMasterId(mapping.getCampaignMasterId());
		userTokenMapping.setIsMobileLogin(mapping.isMobileLogin());
		userTokenMapping.setMobileFcmToken(mapping.getFcmToken());
		userTokenMappingRepository.save(userTokenMapping);
		/**
		 * UPDATE FCM TOKEN FOR MOBILE LOGIN
		 */
		if (mapping.isMobileLogin() && user != null && mapping.getFcmToken() != null) {
			userMobileFcmMappingRepo.inActiveByToken(mapping.getFcmToken());
			UserMobileFcmMapping usermobileFcmMap = new UserMobileFcmMapping();
			usermobileFcmMap.setUserId(user.getUserId());
			usermobileFcmMap.setToken(mapping.getFcmToken());
			usermobileFcmMap.setActive(true);
			usermobileFcmMap.setCreatedDate(new Date());
			userMobileFcmMappingRepo.save(usermobileFcmMap);
		}
		response.setLoginToken(randomNumber);
		response.setUserName(userName);
		response.setStatus(HttpStatus.OK.value());
		return response;
	}

	@Override
	public AuthResponse getTokenByLoginToken(Integer loginToken) {
		UserTokenMapping userTokenMapping = userTokenMappingRepository.getTokenByLoginToken(loginToken);
		AuthResponse response = new AuthResponse();
		if (userTokenMapping != null) {
			userTokenMappingRepository.inactiveDomainLogin(loginToken);
			response.setAccess_token(userTokenMapping.getAccessToken());
			response.setLoginToken(userTokenMapping.getLoginToken());
			response.setRefresh_token(userTokenMapping.getRefreshToken());
			response.setExpires_in(String.valueOf(userTokenMapping.getExpiresIn()));
			response.setUserType(userTokenMapping.getUserType());
			response.setEmail(userTokenMapping.getUserName());
			response.setUserOrgId(userTokenMapping.getUserOrgId());
			response.setUserRoleId(userTokenMapping.getUserRoleId());
			response.setUserBranchId(userTokenMapping.getUserBranchId());
		}
		return response;
	}

	@Override
	public AuthResponse getTokenByLoginTokenForSidbi(Integer loginToken) {
		UserTokenMapping userTokenMapping = userTokenMappingRepository.getByLoginToken(loginToken);
		if (userTokenMapping != null) {
			AuthResponse response = new AuthResponse();
			response.setAccess_token(userTokenMapping.getAccessToken());
			response.setLoginToken(userTokenMapping.getLoginToken());
			response.setRefresh_token(userTokenMapping.getRefreshToken());
			response.setExpires_in(String.valueOf(userTokenMapping.getExpiresIn()));
			response.setUserType(userTokenMapping.getUserType());
			response.setEmail(userTokenMapping.getUserName());
			response.setUserOrgId(userTokenMapping.getUserOrgId());
			response.setUserRoleId(userTokenMapping.getUserRoleId());
			response.setUserBranchId(userTokenMapping.getUserBranchId());
			return response;
		}
		return null;
	}

	@Override
	public AuthResponse getByLoginToken(Integer loginToken) {
		UserTokenMapping userTokenMapping = userTokenMappingRepository.getByLoginToken(loginToken);
		AuthResponse response = new AuthResponse();
		if (userTokenMapping != null) {
			response.setAccess_token(userTokenMapping.getAccessToken());
			response.setLoginToken(userTokenMapping.getLoginToken());
			response.setRefresh_token(userTokenMapping.getRefreshToken());
			response.setExpires_in(String.valueOf(userTokenMapping.getExpiresIn()));
			response.setUserType(userTokenMapping.getUserType());
			response.setEmail(userTokenMapping.getUserName());
			response.setUserOrgId(userTokenMapping.getUserOrgId());
			response.setUserRoleId(userTokenMapping.getUserRoleId());
			response.setUserBranchId(userTokenMapping.getUserBranchId());
		}
		return response;
	}

	@Override
	public void logoutuser(AuthRequest req) {
		UserTokenMapping tokenMapping = userTokenMappingRepository.findByUserNameAndLoginTokenAndActive(
				req.getUsername(), req.getLoginToken(), true);
		if (tokenMapping != null) {
			tokenMapping.setActive(Boolean.FALSE);
			tokenMapping.setLogoutDate(new Date());
			userTokenMappingRepository.save(tokenMapping);
			/**
			 * INACTIVE PREVIOUS TOKEN FOR MOBILE LOGIN
			 */
			if (tokenMapping.getIsMobileLogin() != null && tokenMapping.getIsMobileLogin()
					&& tokenMapping.getMobileFcmToken() != null) {
				userMobileFcmMappingRepo.inActiveByToken(tokenMapping.getMobileFcmToken());
			}
		} else {
			log.info("While Logout Not Found Object From UserName -> " + req.getUsername() + " --- RefreshToken --> "
					+ req.getRefreshToken() + "----- LoginToken -----> " + req.getLoginToken());
		}
		// userTokenMappingRepository.logoutUser(req.getUsername(),req.getRefreshToken(),req.getLoginToken());
	}

	@Override
	public boolean isUserAlreadyActive(String userName, String refreshToken) {
		Long count = userTokenMappingRepository.isUserAlreadyActive(userName, refreshToken);
		return count > 0;
	}

	private Integer getRandomNumber() {
		Integer randomNumber = 1000000 + random.nextInt(9000000);
		Long count = userTokenMappingRepository.checkLoginToken(randomNumber);
		if (count > 0) {
			getRandomNumber();
		}
		return 1000000 + random.nextInt(9000000);
	}

	@Override
	public LogResponse getLastLoginDetailsFromUserId(Long userId) {
		LogResponse response = new LogResponse();
		UserTokenMapping lastLoginDetails = userTokenMappingRepository.getLastLoginDetailsFromUserId(userId);
		if (lastLoginDetails != null) {
			response.setUserEmail(lastLoginDetails.getUserName());
			response.setLoginDate(lastLoginDetails.getLoginDate());
			response.setUserId(lastLoginDetails.getUserId());
		}
		return response;
	}

	@Override
	public AuthResponse getTokensByUserId(Long userId) {
		AuthResponse response = null;
		UserTokenMapping lastLoginDetails = userTokenMappingRepository.findFirstByUserIdAndActiveOrderByIdDesc(userId,
				true);
		if (lastLoginDetails != null) {
			response = new AuthResponse();
			response.setEmail(EncodeDecodeHelper.encode(lastLoginDetails.getUserName()));
			response.setRefresh_token(EncodeDecodeHelper.encode(lastLoginDetails.getRefreshToken()));
			response.setAccess_token(EncodeDecodeHelper.encode(lastLoginDetails.getAccessToken()));
			response.setLoginToken(lastLoginDetails.getLoginToken());
			response.setUserId(lastLoginDetails.getUserId());
		}
		return response;
	}

	@Override
	public boolean checkUserLogginedOrNot(Long userId) {
		Long id = userTokenMappingRepository.checkUserLogginedOrNot(userId);
		return id > 0;
	}

	@Override
	public boolean inActiveAllSessionByUserName(String userName) {
		userTokenMappingRepository.inActiveAllSessionByUserName(
				AuthCredentialUtils.getUserName(userName).get(AuthCredentialUtils.USER_NAME));
		return false;
	}

//	@Override
//	public Integer updateCustomerInTokenMapping(AuthRequest req) {
//		return userTokenMappingRepository.updateCustomerId(req.getClientUserId(), req.getUsername(),
//				req.getAccessToken(), req.getLoginToken()) ? 1 : 0;
//	}

	@Override
	public boolean inActiveAllSessionByUserNameAndUserType(String userName, Long userType) {
		userTokenMappingRepository.inActiveAllSessionByUserName(
				AuthCredentialUtils.getUserName(userName).get(AuthCredentialUtils.USER_NAME), userType);
		return false;
	}

	/**
	 * GENERATE ACCESS TOKEN USING USER CREDENTIALS
	 */
	@Override
	public AuthResponse getRefreshToken(AuthRequest authRequest) {
		log.info("Enter in Get RefreshToken When User Try To Login===================>" + authRequest.getUsername());
		try {
			Authentication auth = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername().concat("$").concat(authRequest.getUserTypeId().toString()), authRequest.getPassword()));
//			AuthResponse authResponse = tokenService.generateJwt(auth, authRequest.getTokenAccessLifeMiniuts(),
//					authRequest.getTokenRefreshMiniutes());
			AuthResponse authResponse = tokenService.generateJwt(auth, 30, 30);

			inActiveAllSessionByUserName(authRequest.getUsername());
			authResponse = createNewUserWithToken(bindResponseInCustomObject(authResponse, authRequest), authResponse);
			log.info("Successfully Generate Refreshtoken-----------------" + authResponse.getUserName());
			return authResponse;
		} catch (HttpStatusCodeException e) {
			log.info("HttpStatusCodeException ------------------> {}", e);
		} catch (Exception e) {
			log.info("Get RefreshToken, UserName ------------------> " + authRequest.getUsername());
			log.error("Throw Exception While Generate Refresh Token When Login User ---------> {}", e);
		}
		return null;
	}

	/**
	 * 
	 */
//	@Override
//	public AuthResponse getAccessToken(AuthRequest authRequest) {
//		log.info("Enter in Get getAccessToken() From Refresh Token.");
//		try {
//			AuthResponse response = tokenService.generateAccessToken(authRequest);
//			if (!OPLUtils.isObjectNullOrEmpty(response)) {
//				updateAccessToken(bindResponseInCustomObject(response, authRequest));
//				log.info("Successfully Generate Accesstoken---" + authRequest.getUsername());
//			}
//			return response;
//		} catch (Exception e) {
//			log.info(
//					"Method :- GetAccessToken, AccessToken----->{} ---UserName --> {} -->RefershToken-->{} -- Login Token -->{}",
//					authRequest.getAccessToken(), authRequest.getUsername(), authRequest.getRefreshToken(),
//					authRequest.getLoginToken());
//			log.error("Throw Exception While Generate New Access Token : ", e);
//
//			return null;
//		}
//	}

	@Override
	public AuthClientResponse validateOAuthAccessToken(AuthRequest req) {
		// if oauth check token is valid then we check our custom user token
		// mapping table using username and accesstoken

		boolean isValid = false;
		if (testMode != null && "ON".equals(testMode)) {
			isValid = true;
		} else {
			isValid = validateAccessTokenWithOauth(req);
		}

		AuthClientResponse response = new AuthClientResponse();
		if (isValid) {
			response = checkAccessToken(req);
			if (response.getUserId() != null) {
				response.setAuthenticate(true);
			} else {
				log.info(
						"Method :- GetAccessToken, AccessToken----->{} ---UserName -->{} -->RefershToken-->{} -- Login Token -->{}",
						req.getAccessToken(), req.getUsername(), req.getRefreshToken(), req.getLoginToken());
				log.warn("Check AccessToken on Every Request, Invalid Accesstoken or Refreshtoken or Logintoken");
				response.setAuthenticate(false);
			}
			return response;
		}
		log.info(
				"Method :- GetAccessToken, AccessToken----->{} ---UserName -->{}-->RefershToken-->{}-- Login Token -->{}",
				req.getAccessToken(), req.getUsername(), req.getRefreshToken(), req.getLoginToken());
		log.warn("Check AccessToken on Every Request, AccessToken is Expire or Invalid");
		response.setAuthenticate(false);

		return response;
	}

	@Override
	public AuthClientResponse logoutOAuthUser(AuthRequest request) {
		log.info("Enter in Logout User------------------>");
		AuthClientResponse response = new AuthClientResponse();
		response.setAuthenticate(false);
		try {
			if (StringUtils.hasText(request.getAccessToken()) && StringUtils.hasText(request.getUsername())) {
				if (isUserAlreadyActive(request.getUsername(), request.getRefreshToken())) {
//					OAuth2AccessToken oAuth2AccessToken = tokenStore.readAccessToken(request.getAccessToken());
//					if (oAuth2AccessToken != null) {
//						tokenStore.removeAccessToken(oAuth2AccessToken);
//					}
				}

				logoutuser(request);

				log.info("Successfully logoutUser----" + request.getUsername() + "---LoginToken----"
						+ request.getLoginToken());
				response.setAuthenticate(true);
			} else {
				log.info("Method :- GetAccessToken, AccessToken----->" + request.getAccessToken() + "---UserName -->"
						+ request.getUsername() + "-->RefershToken-->" + request.getRefreshToken()
						+ "-- Login Token -->" + request.getLoginToken());
				log.warn("Logout User, Token and username not valid");
				response.setMessage("Token and username is not valid");
			}
			return response;
		} catch (Exception e) {
			log.info("Method :- GetAccessToken, AccessToken----->" + request.getAccessToken() + "---UserName -->"
					+ request.getUsername() + "-->RefershToken-->" + request.getRefreshToken() + "-- Login Token -->"
					+ request.getLoginToken());
			log.error("Throw exception while logout user : ", e);
			return response;
		}
	}

	@Override
	public AuthResponse getTokenForPartner(AuthRequest authRequest) {
		try {
			Authentication auth = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername().concat("$").concat(authRequest.getUserTypeId().toString()), authRequest.getPassword()));
			AuthResponse authResponse = tokenService.generateJwt(auth, authRequest.getTokenAccessLifeMiniuts(),
					authRequest.getTokenRefreshMiniutes());
			inActiveAllSessionByUserNameAndUserType(authRequest.getUsername(), authRequest.getUserTypeId());
			authResponse = createNewUserWithToken(bindResponseInCustomObject(authResponse, authRequest), authResponse);
			log.info("Successfully Generate PartnerToken-----------------" + authResponse.getUserName());
			return authResponse;
		} catch (HttpStatusCodeException e) {
			log.info("HttpStatusCodeException ------------------> {}", e);

		} catch (Exception e) {
			log.info("Get PartnerToken, UserName ------------------> " + authRequest.getUsername());
			log.error("Throw Exception While Generate Partner Token  ---------> {}", e);
		}
		return null;
	}

	/**
	 * CALL OAUTH FOR VALIDATION ACCESS TOKEN
	 * 
	 * @param req
	 * @return
	 */
	private boolean validateAccessTokenWithOauth(AuthRequest req) {
		try {
//			VALIDATE TOKEN IN OAUTH-2
//			String url = UrlsAns.getLocalIpAddress(UrlType.AUTH).concat(AuthCredentialUtils.OAUTH_CHECK_TOKEN_URI);
//
//			HttpHeaders headers = createHeader(req.getClientId(), req.getClientSecret());
//			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//			MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
//			params.add(AuthCredentialUtils.OAUTH_PARAM_TOKEN, req.getAccessToken());
//
//			HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(params, headers);
//			RestTemplate restTemplate = new RestTemplate();
//			restTemplate.postForEntity(url, requestEntity, String.class);
//			return Boolean.TRUE;
			Boolean isAccessTokenExpire = tokenService.isTokenExpired(req.getAccessToken(), req.getUsername());
			if (isAccessTokenExpire) {
				log.info("Access Token is expired going to check refresh Token for userName ::::------> {}",
						req.getUsername());
				Boolean isRefreshTokenExpire = tokenService.isTokenExpired(req.getRefreshToken(), req.getUsername());
				if (isRefreshTokenExpire) {
					log.info("Refresh Token is expired for userName ::::------> {}", req.getUsername());
					return false;
				} else {
					log.info("Going to generate Access token as refresh token is not expired");
					req.setRefreshToken(req.getRefreshToken());
					AuthResponse authResponse = tokenService.generateAccessToken(req);
					if (!OPLUtils.isObjectNullOrEmpty(authResponse)) {
						userTokenMappingRepository.updateAccessToken(authResponse.getUserName(), authResponse.getRefresh_token(),
								authResponse.getAccess_token(), authResponse.getExpires_in(), req.getLoginToken());
						log.info("Successfully Generate Access token--- for User Name =========" + req.getUsername());
					}
					return true;
				}
			}
			log.info("Access token is Valid for User Name =========" + req.getUsername());
			return true;
		} catch (Exception e) {
			log.info("Throw Exception while check access token");
			return false;
		}
	}

	/**
	 * CONVERT RESPONSE TO CUSTOM OBJECT
	 * 
	 * @param response
	 * @param req
	 * @return
	 */
	private CustomUserTokenMapping bindResponseInCustomObject(AuthResponse response, AuthRequest req) {
		CustomUserTokenMapping mapping = new CustomUserTokenMapping();
		mapping.setUserName(req.getUsername());
		mapping.setRefreshToken(response.getRefresh_token());
		mapping.setAccessToken(response.getAccess_token());
		mapping.setExpiresIn(response.getExpires_in());
		mapping.setLoginToken(req.getLoginToken());
		mapping.setUserIp(req.getUserIp());
		mapping.setUserBrowser(req.getUserBrowser());
		mapping.setDomainLogin(req.getIsDomainLogin());
		mapping.setMobileOs(req.getMobileOs());
		mapping.setAppVersion(req.getAppVersion());
		mapping.setImeiNo(req.getImeiNo());
		mapping.setModelNo(req.getModelNo());
		mapping.setOsVersion(req.getOsVersion());
		mapping.setUserTypeId(req.getUserTypeId());
		mapping.setBrowserVersion(req.getBrowserVersion());
		mapping.setDevice(req.getDevice());
		mapping.setDeviceType(req.getDeviceType());
		mapping.setDeviceOs(req.getDeviceOs());
		mapping.setDeviceOsVersion(req.getDeviceOsVersion());
		mapping.setUserAgent(req.getUserAgent());
		mapping.setCampaignCode(req.getCampaignCode());
		mapping.setCampaignMasterId(req.getCampaignMasterId() != null ? req.getCampaignMasterId() : MARKET_PLACE);
		mapping.setMobileLogin(req.getIsMobileLogin());
		mapping.setFcmToken(req.getFcmToken());
		return mapping;
	}

	/**
	 * CONVERT RESPONSE STRING TO AuthResponse OBJECT
	 * 
	 * @param response
	 * @return
	 */
	private AuthResponse responseAdapter(String response) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			return mapper.readValue(response, AuthResponse.class);
		} catch (Exception e) {
			log.info("Response String -----------------> " + response);
			if (response.contains("DefaultOAuth2AccessToken")) {
				return MultipleJSONObjectHelper.xmlStringToPojo(response, AuthResponse.class);
			}
			log.error("Throw exception when convert string response to object : ", e);
			return null;
		}
	}

//	/**
//	 * CREATE REQUEST HEADER FOR AUTHORIZATION
//	 * 
//	 * @param clientId
//	 * @param clientSecret
//	 * @return
//	 */
//	private HttpHeaders createHeader(String clientId, String clientSecret) {
//		String authSecret = clientId + ":" + clientSecret;
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("authorization", "Basic " + Base64Utils.encodeToString(authSecret.getBytes()));
//		headers.set("cache-control", "no-cache");
//		return headers;
//	}
	@Override
	public AuthResponse getLoginTimeIncrese(AuthRequest request) {
		try {
			UserTokenMapping userTokenMapping = userTokenMappingRepository.findFirstByUserIdAndActiveOrderByIdDesc(request.getUserId(),true);
			AuthResponse response = new AuthResponse();
			if (userTokenMapping != null) {
				Jwt accessToken = getToken(userTokenMapping.getUserName(),30l, "ROLE_ACCESS_TOKEN");
				Jwt refreshToken = getToken(userTokenMapping.getUserName(), 30l, "ROLE_REFRESH_TOKEN");

				response.setAccess_token(accessToken.getTokenValue());
				response.setRefresh_token(refreshToken.getTokenValue());
				if (!OPLUtils.isObjectNullOrEmpty(accessToken.getExpiresAt())) {
					response.setExpires_in(String.valueOf(accessToken.getExpiresAt().getEpochSecond()));
				}
//				Integer randomNumber = getRandomNumber();
//				response.setLoginToken(randomNumber);
				response.setLoginToken(userTokenMapping.getLoginToken());
				response.setUserName(userTokenMapping.getUserName());
				if (!OPLUtils.isObjectNullOrEmpty(response)) {
				userTokenMappingRepository.updateAccessToken(userTokenMapping.getUserName(), response.getRefresh_token(),
						response.getAccess_token(), response.getExpires_in(), userTokenMapping.getLoginToken());
				log.info("Successfully Generate Access token--- for User Name =========" + request.getUsername());
			}
			}
			return response;
		} catch (Exception e) {
			log.error("Throw exception when Update Login Time  : ", e);
			return null;
		}

	}
	public Jwt getToken(String userName, Long expiration, String scope) {
		Instant now = Instant.now();
		JwtClaimsSet claims = JwtClaimsSet.builder().issuer("self").issuedAt(now)
				.expiresAt(now.plusSeconds(expiration * 60)).subject(userName).claim("roles", scope).build();
		return jwtEncoder.encode(JwtEncoderParameters.from(claims));
	}

}
