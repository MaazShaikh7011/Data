package com.opl.jns.auth.service.repositories;

import com.opl.jns.auth.service.domain.User;
import com.opl.jns.utils.constant.DBNameConstant;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

//	@Query(value = "SELECT * FROM "+ DBNameConstant.JNS_USERS +".users WHERE UPPER(CAST((AES_DECRYPT(UNHEX(email),'C@p!ta@W0rld#AES')) AS CHAR)) = UPPER(:email) AND user_type_id = :userTypeId",nativeQuery = true)
//    User getByCaseSensitiveEmailAndUserTypeMasterId(@Param("email") String email, @Param("userTypeId")  Long userTypeId);

	@Cacheable(value = "oauth_userDetailsById", key = "{#userId}")
	public Optional<User> findById(Long userId);

	@Query(value = "select ur from User ur where ur.email = :email AND ur.userTypeMaster.id = :userTypeId")
	User getByCaseSensitiveEmailAndUserTypeMasterId(@Param("email") String email, @Param("userTypeId")  Long userTypeId);

	public User findOneByEmailAndUserTypeMasterId(String email, Long userTypeId);
	
	@Query("select ur from User ur where ur.email =:email and ur.password =:password")
	public User getUserByEmailAndPassword(@Param("email") String email,@Param("password") String password);
	
	public User findOneByMobileAndUserTypeMasterId(String mobileNumber, Long userTypeId);
	
	@Query("select ur from User ur where ur.mobile =:mobile")
	public User getUserByMobile(@Param("mobile") String mobile);
	
//	@Query(value = "SELECT user_role_id,last_business_type_id FROM users WHERE user_id =:userId", nativeQuery = true)
//	public Object[] getRoleAndBusinessTypeId(@Param("userId") Long userId);
}
