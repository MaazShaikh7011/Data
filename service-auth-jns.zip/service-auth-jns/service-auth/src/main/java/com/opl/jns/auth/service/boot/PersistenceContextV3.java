package com.opl.jns.auth.service.boot;

import com.opl.jns.utils.config.DataSourceProvider;
import com.opl.jns.utils.enums.ENVMode;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.sql.init.dependency.DependsOnDatabaseInitialization;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages= {PersistenceContextV3.$_COM_JNS_SERVICE_REPOSITORY_PACKAGE}, entityManagerFactoryRef = "emFR", transactionManagerRef = "tmr")
public class PersistenceContextV3 {

	public static final String $_COM_JNS_SERVICE_REPOSITORY_PACKAGE = "${com.jns.service.repository-package}";
//	@Autowired
//	private ApplicationProperties properties;



	public static final String ORACLE_JDBC_ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
	public static final String ORG_HIBERNATE_DIALECT_ORACLE_12_C_DIALECT = "org.hibernate.dialect.Oracle12cDialect";
	public static final String ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY = "org.hibernate.cfg.ImprovedNamingStrategy";
	public static final String HIBERNATE_HQL_BULK_ID_STRATEGY = "hibernate.hql.bulk_id_strategy";
	public static final String ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY = "org.hibernate.hql.spi.id.inline.InlineIdsOrClauseBulkIdStrategy";
	public static final String NONE = "none";
	public static final String CREATE = "create";
	public static final String UPDATE = "update";
	public static final String SELECT_1_FROM_DUAL = "SELECT 1 FROM DUAL";
	private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	private static final String PROPERTY_NAME_HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
	private static final String PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
	private static final String PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY = "hibernate.ejb.naming_strategy";
	private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_NAME_HIBERNATE_LAZY_LOAD = "hibernate.enable_lazy_load_no_trans";

	private static final String ENTITY_MANAGER_REFERENCE = "emFR";
	private static final String DATASTORE = "dsEcr";
	private static final String TRANSACTION_MANAGER_REFERENCE = "tmr";

	protected static final String PROPERTY_NAME_DATABASE_MAX_CONNECTIONS = "capitaworld.auth.db.maxconnections";
	protected static final String PROPERTY_NAME_DATABASE_MAX_LIFETIME = "capitaworld.auth.db.maxlifetimeinmillis";
	protected static final String PROPERTY_NAME_DATABASE_CONNECTION_TIMEOUT = "capitaworld.auth.db.connectiontimeoutinmillis";
	protected static final String PROPERTY_NAME_DATABASE_MINIMUM_IDLE = "capitaworld.auth.db.minimumIdle";
	protected static final String PROPERTY_NAME_DATABASE_MAAXIMUM_POOL_SIZE = "capitaworld.auth.db.maximumpoolsize";
	protected static final String PROPERTY_NAME_DATABASE_IDLE_TIMEOUT = "capitaworld.auth.db.idelTimeout";
	
	private static final String PROPERTY_ENTITY_PACKAGES_TO_SCAN = "com.opl.jns.auth.service.domain";
	
	@Autowired
	private Environment environment;
	
	@Bean(name = DATASTORE)
	@Primary
    public DataSource dataSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName(ORACLE_JDBC_ORACLE_DRIVER);
        System.out.println("-------------------------DB-MAIN - ORACLE------------------>" + DataSourceProvider.getDbUrlOracle());
        System.out.println("-------------------------User/Pwd - ORACLE------------------>" + environment.getProperty("com.jns.common.config.oracleDbName")+"/"+environment.getProperty("com.jns.common.config.oracleDbPass"));
		dataSource.setJdbcUrl(DataSourceProvider.getDbUrlOracle());
		dataSource.setUsername(environment.getProperty("com.jns.common.config.oracleDbName"));
		dataSource.setPassword(environment.getProperty("com.jns.common.config.oracleDbPass"));
        dataSource.setConnectionTestQuery(SELECT_1_FROM_DUAL);
		dataSource.setMaximumPoolSize(Integer.parseInt(environment.getProperty(PROPERTY_NAME_DATABASE_MAX_CONNECTIONS)));
		dataSource.setMaxLifetime(Long.parseLong(environment.getProperty(PROPERTY_NAME_DATABASE_MAX_LIFETIME)));
		dataSource.setConnectionTimeout(Long.parseLong(environment.getProperty(PROPERTY_NAME_DATABASE_CONNECTION_TIMEOUT)));
		dataSource.setMinimumIdle(Integer.parseInt(environment.getProperty(PROPERTY_NAME_DATABASE_MINIMUM_IDLE)));
		dataSource.setMaximumPoolSize(Integer.parseInt(environment.getProperty(PROPERTY_NAME_DATABASE_MAAXIMUM_POOL_SIZE)));
		dataSource.setIdleTimeout(Long.parseLong(environment.getProperty(PROPERTY_NAME_DATABASE_IDLE_TIMEOUT)));
        return dataSource;
    }


	@Bean(name = TRANSACTION_MANAGER_REFERENCE)
	@DependsOn(DATASTORE)
	@Primary
	@DependsOnDatabaseInitialization
	public JpaTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return transactionManager;
	}

	@Bean(name = ENTITY_MANAGER_REFERENCE)
	@DependsOn(DATASTORE)
	@Primary
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

		entityManagerFactoryBean.setDataSource(dataSource());
		entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		entityManagerFactoryBean.setPackagesToScan(PROPERTY_ENTITY_PACKAGES_TO_SCAN);

		Properties jpaProperties = new Properties();
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_DIALECT, ORG_HIBERNATE_DIALECT_ORACLE_12_C_DIALECT);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_FORMAT_SQL,environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_FORMAT_SQL));
		ENVMode envMode = DataSourceProvider.getEnvMode();
//		if(envMode.equals(ENVMode.P)) {
//			// To prevent unwanted DDL Operation in database on Production.
//			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO, NONE);
//		}else {
//			if(properties.getHibernateHbm2ddl().equals(CREATE)) {
//				properties.setHibernateHbm2ddl(UPDATE);
//			}
//			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO,properties.getHibernateHbm2ddlOracle()); // remove this
//		}
		
//		if(properties.getHibernateHbm2ddl().equals(CREATE)) {
//			properties.setHibernateHbm2ddl(UPDATE);
//		}
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO,environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO)); // remove this

		jpaProperties.put(PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY, ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL,environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_SHOW_SQL));
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_LAZY_LOAD,environment.getRequiredProperty(PROPERTY_NAME_HIBERNATE_LAZY_LOAD));
		jpaProperties.put(HIBERNATE_HQL_BULK_ID_STRATEGY, ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY);
		entityManagerFactoryBean.setJpaProperties(jpaProperties);
		return entityManagerFactoryBean;
	}
}
