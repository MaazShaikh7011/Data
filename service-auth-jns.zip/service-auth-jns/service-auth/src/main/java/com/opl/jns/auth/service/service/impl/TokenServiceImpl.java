package com.opl.jns.auth.service.service.impl;

import java.time.Instant;

import com.opl.jns.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;
import com.opl.jns.auth.service.service.TokenService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;

@Service
public class TokenServiceImpl implements TokenService {

	private static final Logger logger = LoggerFactory.getLogger(TokenServiceImpl.class);

	@Autowired
	private JwtEncoder jwtEncoder;

	@Autowired
	private JwtDecoder jwtDecoder;

	public AuthResponse generateJwt(Authentication auth, Integer tokenAccessLifeMiniuts, Integer tokenRefreshMiniutes) {
		AuthResponse response = new AuthResponse();
		Jwt accessToken = getToken(auth, tokenAccessLifeMiniuts.longValue(), "ROLE_ACCESS_TOKEN");
		Jwt refreshToken = getToken(auth, tokenRefreshMiniutes.longValue(), "ROLE_REFRESH_TOKEN");

		response.setAccess_token(accessToken.getTokenValue());
		response.setRefresh_token(refreshToken.getTokenValue());
		if (!OPLUtils.isObjectNullOrEmpty(accessToken.getExpiresAt())) {
			response.setExpires_in(String.valueOf(accessToken.getExpiresAt().getEpochSecond()));
		}
		return response;
	}

	public AuthResponse generateAccessToken(AuthRequest auth) {
		AuthResponse response = null;
		if (!this.isTokenExpired(auth.getRefreshToken(), auth.getUsername())) {
			response = new AuthResponse();
			Jwt accessToken = getTokenAccessToken(auth, auth.getTokenAccessLifeMiniuts().longValue(),
					"ROLE_ACCESS_TOKEN");
			response.setAccess_token(accessToken.getTokenValue());
			if (!OPLUtils.isObjectNullOrEmpty(accessToken.getExpiresAt())) {
				response.setExpires_in(String.valueOf(accessToken.getExpiresAt().getEpochSecond()));
			}
			response.setRefresh_token(auth.getRefreshToken());
		}
		return response;
	}

	public Jwt getToken(Authentication auth, Long expiration, String scope) {
		Instant now = Instant.now();
		JwtClaimsSet claims = JwtClaimsSet.builder().issuer("self").issuedAt(now)
				.expiresAt(now.plusSeconds(expiration * 60)).subject(auth.getName()).claim("roles", scope).build();
		return jwtEncoder.encode(JwtEncoderParameters.from(claims));
	}

	public Jwt getTokenAccessToken(AuthRequest auth, Long expiration, String scope) {
		Instant now = Instant.now();
		JwtClaimsSet claims = JwtClaimsSet.builder().issuer("Opliinnovate").issuedAt(now)
				.expiresAt(now.plusSeconds(expiration)).subject(auth.getUsername()).claim("roles", scope).build();
		return jwtEncoder.encode(JwtEncoderParameters.from(claims));
	}

	@Override
	public Boolean isTokenExpired(String token, String userName) {
		try {
			Jwt decode = jwtDecoder.decode(token);
			logger.info("Token decoded successfully for user name ::: {}", userName);
			if (!OPLUtils.isObjectNullOrEmpty(decode) && !OPLUtils.isObjectNullOrEmpty(decode.getExpiresAt())) {
				return decode.getExpiresAt().isBefore(Instant.now());
			}
			return true;
		} catch (MalformedJwtException e) {
			logger.error("Invalid JWT token: {}", e.getMessage());
		} catch (ExpiredJwtException e) {
			logger.error("JWT token is expired: {}", e.getMessage());
		} catch (UnsupportedJwtException e) {
			logger.error("JWT token is unsupported: {}", e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error("JWT claims string is empty: {}", e.getMessage());
		} catch (Exception e) {
			logger.error("JWT token is expired :::: {}", e.getMessage());
		}
		return true;
	}

}
