package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_mobile_fcm_mapping")
public class UserMobileFcmMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_mobile_fcm_mapping_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_mobile_fcm_mapping_auth_seq_gen", sequenceName = "user_mobile_fcm_mapping_auth_seq", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "token", columnDefinition = "varchar(555) default ''")
    private String token;

    @Column(name = "is_active")
    private boolean isActive;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedDate;

}
