package com.opl.jns.auth.service.service;

import org.springframework.security.core.Authentication;

import com.opl.jns.auth.api.model.AuthRequest;
import com.opl.jns.auth.api.model.AuthResponse;

/**
 * @author AnkitKapadiya
 * @Date 3/6/2024
 */
public interface TokenService {

    AuthResponse generateJwt(Authentication auth,Integer tokenAccessLifeMiniuts,Integer tokenRefreshMiniutes);

    AuthResponse generateAccessToken(AuthRequest auth);

    Boolean isTokenExpired(String token,String userName);

}
