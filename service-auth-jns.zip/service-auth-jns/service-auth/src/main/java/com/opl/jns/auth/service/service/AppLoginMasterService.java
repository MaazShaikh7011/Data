package com.opl.jns.auth.service.service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.model.MobileAppLoginRequest;
import com.opl.jns.auth.api.model.MobilelAppLoginResponse;


public interface AppLoginMasterService {

	public MobilelAppLoginResponse login (MobileAppLoginRequest request);
	
	public AuthClientResponse checkToken(MobileAppLoginRequest request);
	
	public boolean logout(String token);

	public void addRequest(MobileAppLoginRequest request);
	
	public MobileAppLoginRequest checkMobileNumberActiveForLogin(String mobileNumber, Long userTypeId);
	
}
