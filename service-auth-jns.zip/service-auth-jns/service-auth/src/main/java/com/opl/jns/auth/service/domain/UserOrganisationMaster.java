package com.opl.jns.auth.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * The persistent class for the user_organisation_master database table.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_organisation_master")
public class UserOrganisationMaster implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "users_auth_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "users_auth_seq_gen", sequenceName = "users_auth_seq", allocationSize = 1)
    @Column(name = "user_org_id")
    private Long userOrgId;

    @Column(name = "organisation_name", columnDefinition = "varchar(15+0) default ''")
    private String organisationName;

    @Column(name = "display_org_name", columnDefinition = "varchar(150) default ''")
    private String displayOrgName;

    @Column(name = "organisation_code", columnDefinition = "varchar(55) default ''")
    private String organisationCode;

    @Column(name = "org_type")
    private Integer orgType;

    // bi-directional many-to-one association to UserTypeMaster
    @ManyToOne
    @JoinColumn(name = "user_type_id", referencedColumnName = "id")
    private UserTypeMaster userTypeMaster;

    @Column(name = "username", columnDefinition = "varchar(155) default ''")
    private String username;

    @Column(name = "password", columnDefinition = "varchar(155) default ''")
    private String password;

    @Column(name = "uat_url", columnDefinition = "varchar(500) default ''")
    private String uatUrl;

    @Column(name = "production_url", columnDefinition = "varchar(500) default ''")
    private String productionUrl;

    @Column(name = "is_reverse_api_activated")
    private Boolean isReverseApiActivated;

    @Column(name = "code_lang")
    private Integer codeLanguage;

    @Column(name = "config", columnDefinition = "varchar(600) default ''")
    private String config;

    @Column(name = "general_fields", columnDefinition = "varchar(500) default ''")
    private String generalFields;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date modifiedDate;

    @Column(name = "is_active")
    private Boolean isActive;

    @Lob
    @Column(name = "general_config")
    private String generalConfig;

    @Column(name = "control_block_msme", columnDefinition = "varchar(555) default ''")
    private String controlBlockMsme;

    @Column(name = "control_block_ntb", columnDefinition = "varchar(555) default ''")
    private String controlBlockNtb;

    @Column(name = "campaign_type")
    private Long campaignType;

}