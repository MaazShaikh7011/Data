package com.opl.jns.ere.repo;

import java.util.Date;
import java.util.List;

//import javax.validation.constraints.NotNull;

import jakarta.validation.constraints.NotNull;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.InsurerMstDetailsV3;

public interface InsurerMstDetailsRepositoryV3 extends JpaRepository<InsurerMstDetailsV3, Long> {

	// ##index JNS_INSURANCE_insurer_mst_details_schemeId_orgId_actv_policy_start_end_date_idx
	@Cacheable(value = "INSURER_MASTER_FETCH_BY_SCHM_ORG_ACTV_PSTART_PEND_CACHE")
	InsurerMstDetailsV3 findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(Long schemeId, Long orgId,Date policyStartDate,Date policyEndDate);

	InsurerMstDetailsV3 findFirstBySchemeIdAndOrgIdAndIsActiveTrueOrderByIdDesc(Long schemeId, Long orgId);


	List<InsurerMstDetailsV3> findBySchemeIdAndOrgIdAndIsActiveAndPolicyStartDateBeforeAndPolicyEndDateAfter(
			Long schemeId, Long orgId, Boolean inActive, Date policyStartDate, Date policyEndDate);


	List<InsurerMstDetailsV3> findBySchemeIdAndOrgIdAndIsActiveAndPolicyStartDateAndPolicyEndDate(Long schemeId,
			Long orgId, Boolean inActive, Date policyStartDate, Date policyEndDate);


	List<InsurerMstDetailsV3> findBySchemeIdAndOrgIdAndIsActiveTrueAndMasterPolicyNo(Long schemeId, Long orgId,
			String policyNo);

	InsurerMstDetailsV3 findFirstByMasterPolicyNoAndIsActiveTrue(String masterPolicyNo);

	InsurerMstDetailsV3 findByInsurerCode(@NotNull String insurerCode);
	

//	@Query("select distinct(imd.orgId) from InsurerMstDetailsV3 imd where imd.nameOfInsurer =:insurerOrgId and imd.isActive = true")
//	public List<Long> getOrgIdByInsurerOrgId(@Param("insurerOrgId")Integer insurerOrgId);
//
//	@Transactional
//	@Modifying
//	@Query("UPDATE InsurerMstDetailsV3 SET isActive = false, modifiedDate = SYSDATE(), modifiedBy = :modifiedBy WHERE schemeId =:schemeId AND orgId = :orgId AND isActive = true")
//	public int inActive(@Param("schemeId") Long schemeId, @Param("orgId") Long orgId, @Param("modifiedBy") Long modifiedBy);

}
