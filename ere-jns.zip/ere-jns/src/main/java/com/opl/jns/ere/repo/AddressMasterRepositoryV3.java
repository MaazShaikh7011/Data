package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.*;
import org.springframework.data.jpa.repository.*;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
public interface AddressMasterRepositoryV3 extends JpaRepository<AddressMasterV3, Long> {
}
