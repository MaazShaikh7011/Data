package com.opl.jns.ere.domain.v2;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

@MappedSuperclass
@Getter
@Setter
public class AuditorV2 {

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	public AuditorV2() {
		super();
	}

	public AuditorV2(Long createdBy, Date createdDate, Boolean isActive) {
		super();
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.isActive = isActive;
	}

}
