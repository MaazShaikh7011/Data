package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "miscellaneous_audit",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
		@Index(columnList = "application_id,type,is_active", name = DBNameConstant.JNS_INSURANCE+ "_misc_adt_appid_type_isactive_idx")
})
public class MiscellaneousAudit {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "miscellaneous_audit_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "miscellaneous_audit_seq_gen", sequenceName = "miscellaneous_audit_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "application_id")
    private Long applicationId;

    @Column(name = "urn")
    private String urn;

    @Convert(converter = AESOracle.class)
    @Column(name = "account_number")
    private String accountNumber;

    @Convert(converter = AESOracle.class)
    @Column(name = "name")
    private String name;
    
    @Convert(converter = DateEncryptorAes.class)
    @Column(name = "dob")
    private Date dob;
    
    @Convert(converter = AESOracle.class)
    @Column(name = "cif")
    private String cif;
    
    @Column(name = "account_status")
    private Integer accountStatus;
    
    @Column(name = "reason")
    private String reason;
    
    @Column(name = "request_token")
    private String requestToken;

    @Column(name = "policy_effective_date")
    private Date policyEffectiveDate;

    @Column(name = "date_of_request")
    private Date dateOfRequest;

    @Column(name = "date_of_effective")
    private Date dateOfEffective;

    @Column(name = "type")
    private Integer type;

    @Column(name = "nominee_id")
    private Long nomineeId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "modified_Date")
    private Date modifiedDate;

    @Column(name = "is_active")
    private Boolean isActive;
    
    @Column(name = "is_insurer_status_pushed")
    private Boolean isInsurerStatusPushed;
    
    @Column(name = "is_bank_status_pushed")
    private Boolean isBankStatusPushed;
    
    /**
	 * REFERE Source ENUM
	 */
	@Column(name = "source")
	private Integer source;

}
