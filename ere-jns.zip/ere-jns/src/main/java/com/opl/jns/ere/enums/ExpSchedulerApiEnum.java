package com.opl.jns.ere.enums;

public enum ExpSchedulerApiEnum {

	EXPIRE_ASSISTED_MODE_APPLICATIONS(1, "Expire Assisted Mode Applications"), 
	EXPIRE_OTHER_CHANNEL_APPLICATIONS(2, "Expire OtherChannel Applications"), 
	EXPIRE_CLAIM_AFTER_30_DAYS(3, "Expire Claim After 30Days"),
	PUSH_FAIL_SCHEDULAR(4, "Push Fail Schedular");

	private Integer id;
	private String value;

	private ExpSchedulerApiEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
		
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static ExpSchedulerApiEnum fromId(Integer v) {
		for (ExpSchedulerApiEnum c : ExpSchedulerApiEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ExpSchedulerApiEnum[] getAll() {
		return ExpSchedulerApiEnum.values();
	}
}
