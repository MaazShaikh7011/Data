package com.opl.jns.ere.enums;

public enum DebitStatus {
	SUCEESSFUL_DEBIT(1, "Successful Debit"),
	DUE_TO_API_FAILURE(2, "Due to API failure"),
	BALANCE_INSUFFICIENT(3, "Balance insufficient"),
	ACCOUNT_CLOSED(4, "Account Closed"),
	ACCOUNT_DORMANT(5, "Account Dormant"),
	ACCOUNT_FROZEN(6, "Account Frozen"),
	NO_DEBIT_AC(7, "No debit Account"),
	NO_DEBIT_OTHER_REASON(8, "No debit due to other reason");

	private Integer id;
	private String value;

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	private DebitStatus(Integer id,String value) {
		this.id = id;
		this.value=value;
	}

	public static DebitStatus fromId(Integer v) {
		for (DebitStatus c : DebitStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static DebitStatus[] getAll() {
		return DebitStatus.values();
	}
	
	public static DebitStatus fromValue(String v) {
		for (DebitStatus c : DebitStatus.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v : null);
	}
}
