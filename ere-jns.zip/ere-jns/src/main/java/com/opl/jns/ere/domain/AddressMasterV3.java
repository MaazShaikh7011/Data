package com.opl.jns.ere.domain;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.*;
import lombok.*;

import jakarta.persistence.*;
import java.util.Date;

/**  
 * @author ravi.thummar
 * Date : 15-06-2023
 */

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "address_master",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
//        @Index(columnList = "pincode", name = "pincode_add_mst_idx"),
//        @Index(columnList = "city_lgd_code", name = "city_lgd_code_add_mst_idx"),
//        @Index(columnList = "state_lgd_code", name = "state_lgd_code_add_mst_idx"),
//        @Index(columnList = "city_id", name = "city_id_add_mst_idx"),
//        @Index(columnList = "state_id", name = "state_id_add_mst_idx"),
//        @Index(columnList = "district_lgd_code", name = "district_lgd_code_add_mst_idx")

})
public class AddressMasterV3 {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "add_mst_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "add_mst_seq_gen", sequenceName = "add_mst_seq_gen", allocationSize = 1)
    private Long id;

    @Convert(converter = AESOracle.class)
    @Column(name = "address_line_1", length = 500, nullable = true)
    private String addressLine1;

    @Convert(converter = AESOracle.class)
    @Column(name = "address_line_2", length = 500, nullable = true)
    private String addressLine2;

    @Column(name = "district", length = 500, nullable = true)
    private String district;

    @Column(name = "city_name", length = 500, nullable = true)
    private String cityName;

    @Column(name = "state_name", length = 500, nullable = true)
    private String stateName;

    @Column(name = "pincode")
    private Integer pincode;

    @Column(name = "city_lgd_code", length = 20, nullable = true)
    private Long cityLGDCode;

    @Column(name = "state_lgd_code", length = 20, nullable = true)
    private Long stateLGDCode;

    @Column(name = "city_id", length = 200, nullable = true)
    private Long cityId;

    @Column(name = "state_id", length = 200, nullable = true)
    private Long stateId;

    @Column(name = "district_lgd_code", length = 20, nullable = true)
    private Long districtLGDCode;

    @Column(name = "app_created_date", nullable = true)
    private Date appCreatedDate;
    
    @OneToOne(mappedBy = "address")
    private ApplicantInfo applicantInfo;

    @Override
    public String toString() {
        return "";
    }
}
