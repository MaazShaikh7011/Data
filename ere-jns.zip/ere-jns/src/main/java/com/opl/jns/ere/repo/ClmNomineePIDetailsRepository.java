package com.opl.jns.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.ClmNomineePIDetails;

public interface ClmNomineePIDetailsRepository extends JpaRepository<ClmNomineePIDetails, Long> {

}
