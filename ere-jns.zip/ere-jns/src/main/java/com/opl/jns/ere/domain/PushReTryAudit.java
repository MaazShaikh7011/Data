package com.opl.jns.ere.domain;

import com.fasterxml.jackson.annotation.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.*;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "push_retry_audit", schema = DBNameConstant.JNS_INSURANCE, indexes = {
        @Index(columnList = "type,is_pushed", name = DBNameConstant.JNS_INSURANCE + "_type_pushed"),
        @Index(columnList = "is_pushed,re_try_count", name = DBNameConstant.JNS_INSURANCE + "_pushed_retry_count"),
        @Index(columnList = "type,application_id,is_pushed", name = DBNameConstant.JNS_INSURANCE + "_type_application_pushed"),
        @Index(columnList = "type,is_pushed,claim_id", name = DBNameConstant.JNS_INSURANCE + "_type_pushed_claim")
})
public class PushReTryAudit implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "push_retry_audit_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "push_retry_audit_seq_gen", sequenceName = "push_retry_audit_seq_gen", allocationSize = 1)
    private Long id;
    @Column(name = "application_id")
    private Long applicationId;
    @Column(name = "claim_id")
    private Long claimId;
    @Column(name = "type")
    private Integer type;
    @Column(name = "re_try_count")
    private Integer reTryCount;
    @JsonIgnore
    @Column(name = "created_date")
    private Date createdDate;
    @JsonIgnore
    @Column(name = "modified_date")
    private Date modifiedDate;
    @Column(name = "message")
    private String message;
    @Column(name = "is_pushed")
    private Boolean isPushed;

}
