package com.opl.jns.ere.domain.v2;

import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "application_push_status", schema = DBNameConstant.JNS_MASTER_DATA)
public class ApplicationPushStatusV2 {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_push_status_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "app_push_status_seq_gen", sequenceName = "app_push_status_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "APPLICATION_ID", nullable = true)
	private Long applicationId;

	@Column(name = "ORG_TYPE", nullable = true)
	private Integer orgType;

	@Column(name = "TYPE", nullable = true)
	private Integer type;

	@Column(name = "PUSH_DATE", nullable = true)
	private Date pushDate;

	@Column(name = "IS_ACTIVE", nullable = true)
	private Boolean isActive;
	
}
