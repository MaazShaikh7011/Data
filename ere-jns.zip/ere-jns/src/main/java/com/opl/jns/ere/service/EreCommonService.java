package com.opl.jns.ere.service;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.EnrollPushType;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.ere.utils.DedupeDataResponse;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.model.COIRequest;

public interface EreCommonService {

	COIRequest generateCOIRequest(ApplicationMasterV3 appMaster);

	void saveStorageIdInLastTransactionDetails(Long storageId,Long lastTransactionDetailsId);
	
	public boolean updateEnrollPushStatus(EnrollPushType enrollPush, Long appId, boolean status, Date date);
	
	public boolean updateEnrollPushStatusWithStatusCode(EnrollPushType enrollPush, Long appId, boolean status, Date date, Integer statusCode);
	
	public ApplicationMasterBothSchemeProxy getJnsMasterDataApplicationMaster(Long schemeId,Long applicationId) throws IOException;

	public void insertApplcationPushStatus(Long applicationId,Integer phaseMode);
	
	public String checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(Integer schemeId,String cif,Long orgId) throws IOException;

	public CommonResponse checkPremiumDeductionStatus(ApplicationMasterV3 appMaster,Long userId,Integer statgeId,Integer status) throws IOException;
	
	COIRequest generateCOIRequestNewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantInfoV2,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomneeAddress);
	
	public List<DedupeDataResponse> checkClaimDedupeData(Long claimId, Long schemeId, String certiNo,String firNo, String panchnamaNo,String postMtrmReportNo,Date certiDate,Date firDate, Date panchnamaDate,Date postMtrmReportDate);
	
	public void setNomineePushFlagFalse(Long applicationId);
	
	public void setOptOutPushFlagFalse(Long applicationId);
	
	public void setBankClaimStatusPushFlagFalse(Long applicationId);
	
	public void setInsurerClaimStatusPushFlagFalse(Long applicationId);
	
	public void insertEnrollAndClaimPushStatusInMaster(Long appId, boolean status, Integer type,Integer orgType, Date pushDate);
	
	public void insertDataConsentMappingTable(ConsentMappingProxy consentMappingProxy);
	
	public boolean updateApplicationFailedAudit(Integer apiTypeId, Long appId, Long orgId);
	
}
	