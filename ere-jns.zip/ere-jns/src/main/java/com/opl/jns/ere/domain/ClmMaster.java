package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clm_master", schema = DBNameConstant.JNS_INSURANCE)
public class ClmMaster extends Auditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "clm_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "clm_master_seq_gen", sequenceName = "clm_master_seq_gen", allocationSize = 1)
	private Long id;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "clmMaster", optional = false)
	@PrimaryKeyJoinColumn
	private ClmDetails clmDetails;

	@OneToOne(mappedBy = "clmMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private ClmNomineeDetails clmNomineeDetails;
	
	@Column(name = "urn", nullable = true)
	private String urn;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "scheme_id", nullable = true)
	private Integer schemeId;

	@Column(name = "branch_id", nullable = true)
	private Long branchId;

	@Column(name = "status", nullable = true)
	private Integer status;

	@Column(name = "stage_id", nullable = true)
	private Integer stageId;

	@Column(name = "claim_date", nullable = true)
	private Date claimDate;

	@Column(name = "reject_reopen_cnt", nullable = true)
	private Integer rejectReopenCnt;

	@Column(name = "is_pushed")
	private Boolean isPushed;

	@Column(name = "transaction_amount", nullable = true)
	private Double transactionAmount;

	@Column(name = "claim_amount", nullable = true)
	private Double claimAmount;

	@Column(name = "insurer_claim_id", nullable = true)
	private String insurerClaimId;

	@Column(name = "insurer_status", nullable = true)
	private String insurerStatus;

	@Column(name = "status_reason_id", nullable = true)
	private Integer statusReasonId;

	@Column(name = "transaction_utr", nullable = true)
	private String transactionUTR;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "transaction_time_stamp", nullable = true)
	private Date transactionTimeStamp;
	
	@Column(name = "FIRST_ENROLLMENT_DATE", nullable = true)
	private Date firstEnrollmentDate;

	@Column(name = "queried_storage_id")
	private String queriedStorageId;

	@Column(name = "branch_state_id", nullable = true)
	private Long branchStateId;

	@Column(name = "branch_city_id", nullable = true)
	private Long branchCityId;

	@Column(name = "branch_lho_id", nullable = true)
	private Long branchLhoId;

	@Column(name = "branch_ro_id", nullable = true)
	private Long branchRoId;

	@Column(name = "branch_zo_id", nullable = true)
	private Long branchZoId;

	@Column(name = "policy_year", nullable = true)
	private Integer policyYear;

	@Column(name = "financial_year", nullable = true)
	private Integer financialYear;

	@Column(name = "policy_month", nullable = true)
	private Integer policyMonth;

	@Column(name = "financial_month", nullable = true)
	private Integer financialMonth;

	@Column(name = "policy_day", nullable = true)
	private Integer policyDay;

	@Column(name = "financial_day", nullable = true)
	private Integer financialDay;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Column(name = "IS_INSURER_CLAIM_STATUS_PUSH", nullable = true)
	private Boolean isInsurerClaimStatusPush;
	
	@Column(name = "IS_BANK_CLAIM_STATUS_PUSH", nullable = true)
	private Boolean isBankClaimStatusPush;
	
	@Column(name = "IS_INSURER_CLAIM_PUSH", nullable = true)
	private Boolean isInsurerClaimPush = false;
	
	@Column(name = "IS_BANK_CLAIM_PUSH", nullable = true)
	private Boolean isBankClaimPush = false;
	
	@Column(name = "IS_INSURER_CLAIM_STATUS_PUSH_DATE", nullable = true)
	private Date isInsurerClaimStatusPushDate;
	
	@Column(name = "IS_BANK_CLAIM_STATUS_PUSH_DATE", nullable = true)
	private Date isBankClaimStatusPushDate;
	
	@Column(name = "IS_INSURER_CLAIM_PUSH_DATE", nullable = true)
	private Date isInsurerClaimPushDate;
	
	@Column(name = "IS_BANK_CLAIM_PUSH_DATE", nullable = true)
	private Date isBankClaimPushDate;
	
	@Column(name = "IS_PORTAL_THROUGH_UPDATED_STATUS", nullable = true)
	private Boolean isPortalThroughUpdatedStatus = false;
	
	@Column(name = "source", nullable = true)
    private Integer source;

	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "phase_mode")
	private Integer phaseMode;
}
