//package com.opl.jns.ere.repo;
//
//import com.opl.jns.ere.domain.*;
//import org.springframework.data.jpa.repository.*;
//
//public interface ClaimDetailRepoV3 extends JpaRepository<ClaimDetailV3, Long> {
//
//	ClaimDetailV3 findByClaimMasterId(Long id);
//
//}
