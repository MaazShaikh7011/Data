package com.opl.jns.ere.enums;

public enum OrgType {
	BANK(1, "Bank"), INSURER(2, "Insurer");

	private Integer id;
	private String value;

	private OrgType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static OrgType fromId(Integer v) {
		for (OrgType c : OrgType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static OrgType[] getAll() {
		return OrgType.values();
	}
}
