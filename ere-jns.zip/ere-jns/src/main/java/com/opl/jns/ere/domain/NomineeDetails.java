package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PostLoad;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nominee_details",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
		@Index(columnList = "application_id,type,is_Other_Claimant", name = DBNameConstant.JNS_INSURANCE+ "_nominee_dtls_appid_type_isothclmnt_idx"),
		@Index(columnList = "application_id,type,is_active", name = DBNameConstant.JNS_INSURANCE+ "_APP_ID_TYPE_ID_IS_ACTIVE"),
		@Index(columnList = "application_id,is_active", name = DBNameConstant.JNS_INSURANCE+ "_NOMINEE_APP_MST_ID_IS_ACTIVE"),
		@Index(columnList = "ADDRESS_ID", name = DBNameConstant.JNS_INSURANCE+ "_NOMINEE_ADDRESS_ID"),
		@Index(columnList = "is_active", name = DBNameConstant.JNS_INSURANCE+ "_NOMINEE_is_active"),
		@Index(columnList = "APPLICATION_ID,TYPE,IS_OTHER_CLAIMANT", name = DBNameConstant.JNS_INSURANCE+ "_NOMINEE_DTLS_APPID_TYPE_ISOTHCLMNT_IDX")
})
public class NomineeDetails extends Auditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nominee_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "nominee_details_seq_gen", sequenceName = "nominee_details_seq_gen", allocationSize = 1)
	private Long id;

    @Convert(converter = AESOracle.class)
	@Column(name = "first_name", nullable = true)
	private String firstName;

    @Convert(converter = AESOracle.class)
	@Column(name = "middle_name", nullable = true)
	private String middleName;

    @Convert(converter = AESOracle.class)
	@Column(name = "last_name", nullable = true)
	private String lastName;

	@Column(name = "correct_nominee_first_name", nullable = true)
	private String correctNomineeFirstName;

	@Column(name = "correct_nominee_middle_name", nullable = true)
	private String correctNomineeMiddleName;

	@Column(name = "correct_nominee_last_name", nullable = true)
	private String correctNomineeLastName;

    @Convert(converter = AESOracle.class)
	@Column(name = "mobile_number", nullable = true)
	private String mobileNumber;

    @Convert(converter = AESOracle.class)
	@Column(name = "email", nullable = true)
	private String email;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "dob", nullable = true)
	private Date dob;

    @Convert(converter = AESOracle.class)
	@Column(name = "name", nullable = true)
	private String name;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Transient
	private NomineeType nomineeType;

	@Transient
	private RelationShip relationShip;

	@PostLoad
	void fillTransient() {
		if (type != null) {
			this.nomineeType = NomineeType.fromId(type);
		}
		if (null != relationId) {
			this.relationShip = RelationShip.fromId(relationId);
		}
	}

	@Column(name = "is_Other_Claimant", nullable = true)
	private Boolean isOtherClaimant;

    @Convert(converter = AESOracle.class)
	@Column(name = "aadhar_number", nullable = true)
	private String aadhaarNumber;

    @Convert(converter = AESOracle.class)
	@Column(name = "pan_number", nullable = true)
	private String panNumber;

	@Column(name = "relation_id", nullable = true)
	private Integer relationId;

	@Column(name = "app_created_date", nullable = true)
	private Date appCreatedDate;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private ApplicationMasterV3 applicationMaster;

	@OneToOne(cascade = CascadeType.ALL)
	private AddressMasterV3 address;

}
