package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.ConsentMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsentMappingRepository extends JpaRepository<ConsentMapping,Long> {
	
	public ConsentMapping findByAppTypeValueAndConsentIdTypeIdAndConsentIdIsActiveTrue(Long appTypeVal,Integer consentId);
	
}

