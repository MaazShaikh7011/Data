package com.opl.jns.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.ClmPIDetails;

public interface ClmPIDetailsRepository extends JpaRepository<ClmPIDetails, Long> {

}
