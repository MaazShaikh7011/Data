package com.opl.jns.ere.enums;

public enum KycDocument {

	PAN(1, "PAN","Pan Number","PAN"),
	AADHAR(2, "AADHAR","Aadhar Number","AADHAR"),
	PASSPORT(3, "PASSPORT","Passport Number","PASSPORT"),
	DRIVING_LICENCE(4, "DRIVING LICENCE","Driving Licence Number","DRIVINGL"),
	MGNREGA_CARD(5, "MGNREGA CARD","MGNREGA Number","MGNREGA"),
	VOTERS_ID_CARD(6, "VOTER’S ID CARD","Voter Id Number","VOTERID");


	private Integer id;
	private String value;
	private String key;
	private String displayValue;

	private KycDocument(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	private KycDocument(Integer id, String value, String displayValue) {
		this.id = id;
		this.value = value;
		this.displayValue = displayValue;
	}

	private KycDocument(Integer id, String value, String displayValue, String key) {
		this.id = id;
		this.value = value;		
		this.displayValue = displayValue;
		this.key = key;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getDisplayValue() {
		return displayValue;
	}

	public String getKey() {
		return key;
	}


	public static KycDocument fromId(Integer v) {
		for (KycDocument c : KycDocument.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static KycDocument fromBankValue(String v) {
		for (KycDocument c : KycDocument.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static KycDocument[] getAll() {
		return KycDocument.values();
	}

}
