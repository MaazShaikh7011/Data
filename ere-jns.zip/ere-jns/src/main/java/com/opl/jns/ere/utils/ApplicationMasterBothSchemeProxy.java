package com.opl.jns.ere.utils;

import java.util.Date;

import com.opl.jns.ere.domain.Auditor;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ApplicationMasterBothSchemeProxy extends Auditor {

	private Long id;
	private String urn;
	private Long orgId;
	private Long insurerOrgId;
	private Long branchId;
	private Integer status;
	private Date statusChangeDate;
	private Date enrollmentDate;
	private Date completionDate;
	private String message;
	private Double premiumAmount;
	private Integer source;
	private String channelId;
	private Integer genderId;
	private Long branchStateId;
	private Long branchCityId;
	private Long branchLhoId;
	private Long branchRoId;
	private Long branchZoId;
	private Date renwalDate;
	private Integer renewalRejectionType;
	private String ruralUrban;
	private Integer policyYear;
	private Integer financialYear;
	private Integer policyMonth;
	private Integer financialMonth;
	private Integer policyDay;
	private Integer financialDay;
	private Long lastTransactionId;
	private Date createdDate;
	private Long createdBy;
	private Date modifiedDate;
	private Long modifiedBy;
	private Boolean isActive;
	private Integer enrollType;
	private Long schemeId;

}
