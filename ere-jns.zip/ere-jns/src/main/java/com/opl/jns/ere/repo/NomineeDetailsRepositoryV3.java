package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.NomineeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
public interface NomineeDetailsRepositoryV3 extends JpaRepository<NomineeDetails, Long> {

	List<NomineeDetails> findByApplicationMasterIdAndTypeInAndIsActiveTrue(final long applicationId,
			List<Integer> type);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE NomineeDetails SET isActive = FALSE WHERE applicationMaster.id = :applicationId AND type IN(:type)")
//	@Query(value="UPDATE nominee_details nd SET is_active = 0 WHERE nd.application_id = :applicationId", nativeQuery = true)
	void isActiveFalseByApplicationId(@Param("applicationId") Long applicationId, @Param("type") List<Integer> type);	

}
