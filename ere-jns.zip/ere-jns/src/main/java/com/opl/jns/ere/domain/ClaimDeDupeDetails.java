//package com.opl.jns.ere.domain;
//
//import com.opl.jns.utils.constant.DBNameConstant;
//import lombok.*;
//import lombok.extern.slf4j.Slf4j;
//
//import javax.persistence.*;
//import java.util.Date;
//
///**
// * @author RaviThummar
// */
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//@NoArgsConstructor
//@AllArgsConstructor
////@Entity
//@Builder(toBuilder = true)
////@Table(name = "claim_dedupe_details", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE, indexes = {
////        @Index(columnList = "claim_id", name = DBNameConstant.JNS_INSURANCE + "claim_dedupe_details_id_idx")})
//@Slf4j
//public class ClaimDeDupeDetails extends Auditor {
//
//    @Id
//    @Column(name = "id")
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "claim_dedupe_details_seq_gen")
//    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "claim_dedupe_details_seq_gen", sequenceName = "claim_dedupe_details_seq_gen", allocationSize = 1)
//    private Long id;
//
////    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
////    @JoinColumn(name = "claim_id", referencedColumnName = "id")
//
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "claim_id")
//    private ClaimMasterV3 claimMaster;
//
//    @Column(name = "hospitalisation_date", nullable = true)
//    private Date hospitalisationDate;
//
//    @Column(name = "fir_no", nullable = true)
//    private String fIRNo;
//
//    @Column(name = "fir_date", nullable = true)
//    private Date fIRDate;
//
//    @Column(name = "panchnama_no", nullable = true)
//    private String panchnamaNo;
//
//    @Column(name = "panchnama_date", nullable = true)
//    private Date panchnamaDate;
//
//    @Column(name = "post_mortem_report_no", nullable = true)
//    private String postMortemReportNo;
//
//    @Column(name = "post_mortem_report_date", nullable = true)
//    private Date postMortemReportDate;
//
//    @Column(name = "death_disability_certificate_report_no", nullable = true)
//    private String deathDisabilityCertificateReportNo;
//
//    @Column(name = "death_disability_certificate_report_date", nullable = true)
//    private Date deathDisabilityCertificateReportDate;
//
//}
