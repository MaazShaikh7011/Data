package com.opl.jns.ere.enums;

public enum PMSBYRejectedClaimEnum {

	REASON_1(1, "Duplicate claim"),
	REASON_2(2, "Death due to suicide"),
	REASON_3(3, "Death is not due to accident"),
	REASON_4(4, "Disability not due to accident"),
	REASON_5(5, "Disability not permanent"),
	REASON_6(6, "Death / disability due to accident, not established by documents submitted"),
	REASON_7(7, "Others");
	
	private Integer id;
	private String value;

	private PMSBYRejectedClaimEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static PMSBYRejectedClaimEnum fromId(Integer v) {
		for (PMSBYRejectedClaimEnum c : PMSBYRejectedClaimEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PMSBYRejectedClaimEnum[] getAll() {
		return PMSBYRejectedClaimEnum.values();
	}
}
