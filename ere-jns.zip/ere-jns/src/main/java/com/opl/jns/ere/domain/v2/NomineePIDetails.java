package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author Krunal Prajapati Date : 19-01-2024
 */

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nominee_pi_details", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class NomineePIDetails implements Serializable {

	private static final long serialVersionUID = -9150719521774084752L;

	@Id
	@Column(name = "id")
	private Long id;

	@Convert(converter = AESOracle.class)
	@Column(name = "first_name", nullable = false, columnDefinition = "varchar(255) default ''")
	private String firstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "middle_name", nullable = false, columnDefinition = "varchar(255) default ''")
	private String middleName;

	@Convert(converter = AESOracle.class)
	@Column(name = "last_name", nullable = false, columnDefinition = "varchar(255) default ''")
	private String lastName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "name", nullable = false, columnDefinition = "varchar(255) default ''")
	private String name;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "dob", nullable = true)
	private Date dob;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_1", nullable = true, columnDefinition = "varchar(255) default ''")
	private String addressLine1;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_2", nullable = true, columnDefinition = "varchar(255) default ''")
	private String addressLine2;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdName;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_address", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdAddress;
	
	@Column(name = "enrollment_date", nullable = true)
	private Date enrollmentDate;

}
