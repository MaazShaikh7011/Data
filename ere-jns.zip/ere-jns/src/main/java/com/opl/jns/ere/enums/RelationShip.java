package com.opl.jns.ere.enums;

public enum RelationShip {

    FATHER(1, "Father"),
    MOTHER(2, "Mother"),
    SON(3, "Son"),
    DAUGHTER(4, "Daughter"),
    UNCLE(5, "Uncle"),
    AUNT(6, "Aunt"),
    BROTHER(7, "Brother"),
    SISTER(8, "Sister"),
    GRAND_FATHER(9, "Grand father"),
    WIFE(10, "Wife"),
    NEPHEW(11, "Nephew"),
    NIECE(12, "Niece"),
    HUSBAND(13, "Husband"),
    GRAND_MOTHER(14, "Grand mother"),
    GRAND_SON(15, "Grand son"),
    GRAND_DAUGHTER(16, "Grand daughter"),
    MOTHER_IN_LAW(17, "Mother in law"),
    FATHER_IN_LAW(18, "Father in law"),
    BROTHER_IN_LAW(19, "Brother in law"),
    SISTER_IN_LAW(20, "Sister in law"),
    OTHERS(21, "Others");




    private Integer id;
    private String value;

    private RelationShip(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static RelationShip fromId(Integer v) {
        for (RelationShip c : RelationShip.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static RelationShip fromValue(String v) {
        for (RelationShip c : RelationShip.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v : null);
    }

    public static RelationShip[] getAll() {
        return RelationShip.values();
    }
}
