package com.opl.jns.ere.domain;


import java.util.Date;

import com.opl.jns.ere.enums.ApplicationType;
import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PostLoad;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author krunal.prajapati
 * Date : 19-06-2024
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "consent_mapping",schema = DBNameConstant.JNS_MASTER_DATA,indexes = {})
public class ConsentMapping {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "consent_mapping_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "consent_mapping_seq_gen", sequenceName = "consent_mapping_seq_gen", allocationSize = 1)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "consent_id")
    private ConsentMaster consentId;

    @Column(name = "consent_date", nullable = true)
    private Date consentDate;

    @Column(name = "app_type_value", nullable = true)
    private Long appTypeValue;

    @Column(name = "app_type", nullable = true)
    private Integer appType;
    
    @Column(name = "user_id", nullable = true)
    private Long userId;

    @Transient
    private ApplicationType applicationType;

    @PostLoad
    void fillTransient() {
        if (applicationType != null) {
            this.applicationType = ApplicationType.fromId(appType);
        }
    }
}
