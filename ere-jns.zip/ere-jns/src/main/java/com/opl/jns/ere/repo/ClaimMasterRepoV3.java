//package com.opl.jns.ere.repo;
//
//import com.opl.jns.ere.domain.*;
//import org.springframework.data.jpa.repository.*;
//import org.springframework.data.repository.query.Param;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.util.*;
//
///***
// *
// * @author Maaz Shaikh , Paresh Radadiya
// * Date : 03-05-2023
// */
//public interface ClaimMasterRepoV3 extends JpaRepository<ClaimMasterV3, Long> {
//
//	// ## JNS_INSURANCE_claim_mst_clmstg_actv_idx
//	public List<ClaimMasterV3> findAllByIsActiveTrue();
//
//	public ClaimMasterV3 findByIdAndIsActiveTrue(long claimId);
//	
//	public ClaimMasterV3 findByIdAndClaimStageIdAndIsActiveTrue(long claimId, int claimStageId);
//
//	//	## JNS_INSURANCE_app_mst_urn_actv_idx
//    public ClaimMasterV3 findFirstByApplicationMasterUrnAndApplicationMasterIsActiveTrueAndIsActiveTrueOrderByIdDesc(String urn);
//    public List<ClaimMasterV3> findByClaimStatusAndApplicationMasterIdOrderByIdDesc(Integer claimStatus, Long applicationId);
//
//	public List<ClaimMasterV3> findByApplicationMasterIdAndIsActiveTrue(Long applicationId);
//
//	public ClaimMasterV3 findFirstByApplicationMasterIdAndIsActiveTrueOrderByIdDesc(Long applicationId);
//
//	public List<ClaimMasterV3> findByApplicationMasterIdAndIsActiveTrueAndClaimStatusOrderByIdDesc(Long applicationId,
//			Integer claimStatus);
//	
//	public List<ClaimMasterV3> findByApplicationMasterIdAndIsActiveTrueAndClaimStatusInOrderByIdDesc(Long applicationId,
//			List<Integer> claimStatus);
//	
//	public List<ClaimMasterV3> findByClaimStageIdInAndIsActiveTrueAndApplicationMasterIdOrderByIdDesc(List<Integer> claimStatus,Long applicationId);
//
//	// ## JNS_INSURANCE_claim_mst_clmstg_actv_idx
//	public List<ClaimMasterV3> findByClaimStageIdAndIsActiveTrueAndApplicationMasterIdOrderByIdDesc(Integer claimStatus,Long applicationId);
//
//	// ## JNS_INSURANCE_claim_mst_clmstg_actv_idx
//	public Long countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(Long applicationId, List<Integer> status);
//
//	public List<ClaimMasterV3> findAllByApplicationMasterAccountNumberAndApplicationMasterSchemeIdAndIsActiveTrue(
//			String customerAccountNumber, Integer schemeId);
//
//	public List<ClaimMasterV3> findAllByClaimStageIdAndIsActiveTrue(Integer stageId);
//
//
//	@Transactional
//	@Modifying
//	@Query("UPDATE ClaimMasterV3 SET claimStageId = 15, claimStatus = 12,modifiedDate = :modifiedDate WHERE claimStageId not in (:stageIds) and isActive = true and createdDate < :maxDateRange")
//	public void updateClaimStageIdForExpiration(@Param("stageIds") List<Integer> stageIds, @Param("modifiedDate") Date modifiedDate, @Param("maxDateRange") Date maxDateRange);
//
//	public List<ClaimMasterV3> findByApplicationMasterIdAndIsActiveTrueAndClaimStageIdOrderByIdDesc(Long id,
//			int stageId);
//	
//}
