package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * MAINTAIN APPLICATION PUSH STATUS AND DATE FOR MASTER, BANK AND INSURER SIDE
 * 
 * @author harshit.suhagiya
 * @date 01-Mar-2024
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_push_status", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ApplicationPushStatus {

	/* APPLICATION MASTER ID */
	// NEED TO CREATE RANGE PARTITIONS FOR THIS ID
	@Id
	@Column(name = "id")
	private Long id;

	/* MASTER REPOSITORY PUSH DATA STATUS */
	@Column(name = "master_push")
	private Boolean masterPush = false;
	@Column(name = "master_push_date")
	private Date masterPushDate;

	/* BANK PUSH DATA STATUS */
	@Column(name = "bank_push")
	private Boolean bankPush = false;
	@Column(name = "bank_push_status")
	private Integer bankPushStatus;
	@Column(name = "bank_push_date")
	private Date bankPushDate;

	/* INSURER PUSH DATA STATUS */
	@Column(name = "insurer_push")
	private Boolean insurerPush = false;
	@Column(name = "insurer_push_status")
	private Integer insurerPushStatus;
	@Column(name = "insurer_push_date")
	private Date insurerPushDate;

	/* OPT-OUT BANK PUSH DATA STATUS */
	@Column(name = "bank_opt_out_push")
	private Boolean bankOptOutPush;
	@Column(name = "bank_opt_out_push_date")
	private Date bankOptOutPushDate;

	/* OPT-OUT INSURER PUSH DATA STATUS */
	@Column(name = "insurer_opt_out_push")
	private Boolean insurerOptOutPush;
	@Column(name = "insurer_opt_out_push_date")
	private Date insurerOptOutPushDate;

	/* NOMINEE BANK UPDATE PUSH DATA STATUS */
	@Column(name = "bank_nmn_dtls_push")
	private Boolean bankNmnDtlsPush;
	@Column(name = "bank_nmn_dtls_push_date")
	private Date bankNmnDtlsPushDate;

	/* NOMINEE INSURER UPDATE PUSH DATA STATUS */
	@Column(name = "insurer_nmn_dtls_push")
	private Boolean insurerNmnDtlsPush;
	@Column(name = "insurer_nmn_dtls_push_date")
	private Date insurerNmnDtlsPushDate;
	
	@Column(name = "phase_mode")
	private Integer phaseMode;

}
