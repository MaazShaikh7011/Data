package com.opl.jns.ere.domain.v2;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * @author :- Ravi Thummar
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "expired_enrollment", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA, indexes = {})
public class ExpiredEnrollment extends AuditorV2 implements Serializable {

    private static final long serialVersionUID = -165876546464642L;

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "urn", nullable = true, columnDefinition = "varchar(50) default ''")
    private String urn;

    @Column(name = "org_id", nullable = false)
    private Long orgId;

    @Column(name = "insurer_org_id", nullable = true)
    private Long insurerOrgId;

    @Column(name = "branch_id", nullable = true)
    private Long branchId;

    @Column(name = "status", nullable = true)
    private Integer status;

    @Column(name = "status_change_date", nullable = true)
    private Date statusChangeDate;

    @Column(name = "message", nullable = true, columnDefinition = "varchar(255) default ''")
    private String message;

    @Column(name = "premium_amount", nullable = true)
    private Double premiumAmount;

    @Column(name = "source", nullable = true)
    private Integer source;

    @Column(name = "channel_id", nullable = true) // , columnDefinition = "varchar(100) default ''"
    private Long channelId;

    @Column(name = "gender_id", nullable = true)
    private Integer genderId;

    @Column(name = "branch_state_id", nullable = true)
    private Long branchStateId;

    @Column(name = "branch_city_id", nullable = true)
    private Long branchCityId;

    @Column(name = "branch_lho_id", nullable = true)
    private Long branchLhoId;

    @Column(name = "branch_ro_id", nullable = true)
    private Long branchRoId;

    @Column(name = "branch_zo_id", nullable = true)
    private Long branchZoId;

    @Column(name = "rural_urban", nullable = true)
    private Integer ruralUrbanId;

    @Column(name = "stage_id", nullable = true)
    private Integer stageId;

    @Column(name = "scheme_id", nullable = true)
    private Integer schemeId;

	@Column(name = "debit_status", nullable = true)
	private Integer debitStatus;
}
