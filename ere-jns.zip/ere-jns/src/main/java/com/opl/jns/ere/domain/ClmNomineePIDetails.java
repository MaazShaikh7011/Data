package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CLM_NOMINEE_PI_DETAILS", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmNomineePIDetails {

	@Id
	@Column(name = "id")
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@MapsId
	@JoinColumn(name = "id")
	private ClmNomineeDetails clmNomineeDetails;

	@Convert(converter = AESOracle.class)
	@Column(name = "first_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String firstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "middle_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String middleName;

	@Convert(converter = AESOracle.class)
	@Column(name = "last_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String lastName;

	@Convert(converter = AESOracle.class)
	@Column(name = "name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String name;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "dob", nullable = true)
	private Date dob;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_1", nullable = true, columnDefinition = "varchar(255) default ''")
	private String addressLine1;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_2", nullable = true, columnDefinition = "varchar(255) default ''")
	private String addressLine2;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdName;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_address", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdAddress;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "correct_nominee_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String correctNomineeName;

	@Convert(converter = AESOracle.class)
	@Column(name = "correct_nominee_first_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String correctNomineeFirstName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "correct_nominee_middle_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String correctNomineeMiddleName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "correct_nominee_last_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String correctNomineeLastName;

}
