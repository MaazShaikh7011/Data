package com.opl.jns.ere.repo.v2;

import java.util.Date;

import org.springframework.stereotype.Repository;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
@Repository
public interface ReportRepository {
	String getDataFromProducer(Long claimId, Long schemeId, String certiNo,String firNo, String panchnamaNo,String postMtrmReportNo,Date certiDate,Date firDate, Date panchnamaDate,Date postMtrmReportDate, String spName);
}
