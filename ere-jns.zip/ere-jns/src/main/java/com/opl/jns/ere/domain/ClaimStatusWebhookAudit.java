package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author Maaz Shaikh
 * Date : 04-08-2023
 */
@Setter
@Getter
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "claim_status_webhook_audit",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
})
public class ClaimStatusWebhookAudit {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "claim_status_audit_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "claim_status_audit_master_seq_gen", sequenceName = "claim_status_audit_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "claim_id", nullable = false)
	private Long claimId;

	@Column(name = "claim_status", nullable = false)
	private Integer claimStatus;

	@Column(name = "webhook_master_id",nullable = false)
	private int webhookMasterId;
    
	@Column(name = "webhook_status", nullable = true)
	private Integer webhookStatus;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;
	
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@Column(name = "urn", nullable = true)
	private String urn;
	
	@Column(name = "req_ref_num", nullable = true)
	private String requestRefNumber;
	
	@Column(name = "secret_key", nullable = true)
	private String secretKey;
}
