//package com.opl.jns.ere.repo;
//
//import com.opl.jns.ere.domain.ClaimDeDupeDetails;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.transaction.annotation.Transactional;
//
//public interface ClaimDeDupeDetailsRepository extends JpaRepository<ClaimDeDupeDetails, Long> {
//
//    ClaimDeDupeDetails findByClaimMasterIdAndIsActiveTrue(Long id);
//
//    @Transactional
//    @Modifying
//    @Query("UPDATE ClaimDeDupeDetails SET isActive = 0, modifiedDate = CURRENT_TIMESTAMP, modifiedBy = :userId WHERE claimMaster.id =:claimId AND isActive = 1")
//    Integer isActiveFalseByClaimId(@Param("claimId") Long claimId, @Param("userId") Long userId);
//
//}
