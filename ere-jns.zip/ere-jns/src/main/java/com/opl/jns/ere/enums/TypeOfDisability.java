package com.opl.jns.ere.enums;

public enum TypeOfDisability {

	PARTIAL_DISABILITY(1, "Partial permanent"),
	TOTAL_DISABILITY(2, "Total permanent");


	private Integer id;
	private String value;

	private TypeOfDisability(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static TypeOfDisability fromId(Integer v) {
		for (TypeOfDisability c : TypeOfDisability.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static TypeOfDisability fromBankValue(String v) {
		for (TypeOfDisability c : TypeOfDisability.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static TypeOfDisability[] getAll() {
		return TypeOfDisability.values();
	}

}
