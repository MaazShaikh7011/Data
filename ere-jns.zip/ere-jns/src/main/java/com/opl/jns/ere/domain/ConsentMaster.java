package com.opl.jns.ere.domain;

import java.util.Date;

import com.opl.jns.ere.enums.ConsentType;
import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.PostLoad;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * @author krunal.prajapati
 * Date : 19-06-2024
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "consent_master",schema = DBNameConstant.JNS_MASTER_DATA,indexes = {})
public class ConsentMaster {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "consent_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "consent_master_seq_gen", sequenceName = "consent_master_seq_gen", allocationSize = 1)
    private Long id;

    @Lob
    @Column(name = "consent", nullable = true)
    private String consent;

    @Column(name = "version", nullable = true)
    private Long version;

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "lang", nullable = true)
    private String lang;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "type_id", nullable = false)
    private Integer typeId;

    @Column(name = "current_active", nullable = true)
    private Boolean currentActive;

    @Transient
    private ConsentType consentType;

    @PostLoad
    void fillTransient() {
        if (consentType != null) {
            this.consentType = consentType.fromId(typeId);
        }
    }

}
