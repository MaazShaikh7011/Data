package com.opl.jns.ere.domain;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author - Maaz Shaikh
 * @Date - 3/8/2023
 */

@MappedSuperclass
@Getter
@Setter
public class Auditor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = true)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;
	
	public Auditor() {
		super();
	}

	public Auditor(Long createdBy, Date createdDate, Boolean isActive) {
		super();
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.isActive = isActive;
	}

}
