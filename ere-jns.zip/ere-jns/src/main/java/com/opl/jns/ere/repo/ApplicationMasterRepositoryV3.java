package com.opl.jns.ere.repo;


import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.utils.ApplicationQueryProxy;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
public interface ApplicationMasterRepositoryV3 extends JpaRepository<ApplicationMasterV3, Long> {

	// ##index SYS_C006282 (SYSTEM GENERATED)
	ApplicationMasterV3 findByIdAndIsActiveTrue(final long applicationId);

	// ##index NO NEED
//	List<ApplicationMasterV3> findAllByIsActiveTrue();
//
//	// ##index JNS_INSURANCE_APP_MST_STG_ACTV_IDX
//	List<ApplicationMasterV3> findAllByStageIdAndIsActiveTrue(final int stageId);

	// --------------------- START FILTER FROM URN ---------------------

	// ##index JNS_INSURANCE_APP_MASTER_URN_ACTV_STG_IDX
	List<ApplicationMasterV3> findAllByUrn(String urn);
	
	ApplicationMasterV3 findByUrn(String urn);

	// ##index JNS_INSURANCE_APP_MASTER_URN_ACTV_STG_IDX
	ApplicationMasterV3 findFirstByUrnAndIsActiveTrue(String urn);

	// ##index JNS_INSURANCE_APP_MASTER_ORG_SCHM_URN_STG_ACTV_IDX
	ApplicationMasterV3 findFirstByOrgIdAndSchemeIdAndStageIdAndUrnAndIsActiveTrue(final long orgId, final int schemeId, final int stageId, String urn);

	// ##index JNS_INSURANCE_APP_MASTER_ORG_SCHM_URN_STG_ACTV_IDX
	List<ApplicationMasterV3> findAllByOrgIdAndSchemeIdAndUrnAndIsActiveTrueAndStageId(final long orgId,
			final int schemeId, String urn, final int stageId);

	// --------------------- END FILTER FROM URN ---------------------

	// --------------------- START FILTER FROM ACCOUNT NUMBER ---------------------

	// ##index JNS_INSURANCE_APP_MASTER_ORG_SCHM_ACTV_ACC_STG_IDX
	List<ApplicationMasterV3> findFirstByOrgIdAndSchemeIdAndStageIdAndIsActiveTrueAndAccountNumber(final long orgId,final int schemeId, final int stageId, String accountNo);

	// ##index JNS_INSURANCE_APP_MASTER_ACTV_ACC_CIF_STS_IDX
	ApplicationMasterV3 findFirstByIsActiveTrueAndAccountNumberAndCifAndSchemeIdAndStageId(String accountNo, String cif, final int schemeId, final int stageId);
	
	ApplicationMasterV3 findFirstByIsActiveTrueAndAccountNumberAndCifAndSchemeIdAndStageIdNotIn(String accountNo, String cif, final int schemeId,final Integer[] stageId);
	
	// ##index JNS_INSURANCE_app_master_org_schm_actv_cif_stg_idx
//	ApplicationMasterV3 findFirstByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusInAndApplicationMasterOtherDetailsSource(final long orgId,final int schemeId, String cif, final Integer[] applicationStatus,final Integer source);
	
	ApplicationMasterV3 findFirstByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusInAndIdNot(final long orgId,final int schemeId, String cif, final Integer[] applicationStatus,Long applicationId);
	
	Long countByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatus(final long orgId,final int schemeId, String cif, final Integer applicationStatus);
	
	ApplicationMasterV3 findFirstByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusInAndStageIdNotInAndIdNot(final long orgId,final int schemeId, String cif, final Integer[] applicationStatus,final Integer[] stageId,Long applicationId);

	// ##index JNS_INSURANCE_APP_MASTER_SCHM_ACTV_ACC_CIF_STS_IDX
//	ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusInAndApplicationMasterOtherDetailsSource(int schmeId,String accountNumber, String cif, final Integer[] applicationStatus,final Integer source);

	// ##index JNS_INSURANCE_APP_MASTER_SCHM_ACTV_ACC_STG_CIF_IDX
	ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdInAndCifOrderByIdDesc(
			final int schemeId, String accountNumber, Integer[] completedStage,String cif);

	// ##index JNS_INSURANCE_APP_MASTER_ORG_SCHM_ACTV_ACC_STG_IDX
	List<ApplicationMasterV3> findAllByOrgIdAndSchemeIdAndIsActiveTrueAndAccountNumberAndStageId(final long orgId,final int schemeId, String accountNumber, final int stageId);

	// ##index JNS_INSURANCE_APP_MASTER_SCHM_ACTV_ACC_STG_USR_IDX
//	ApplicationMasterV3 findFirstBySchemeIdAndStageIdNotInAndAccountNumberAndUserIdAndEnrollmentDateIsNullAndIsActiveTrueOrderByIdDesc(
//			final int schemeId,Integer[] stagethatnotincludeinapplicationcreation, String custAccNo, final long userId);

	ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdOrderByIdDesc(
			final int schemeId, String custAccNo,Integer[] stageThatNotIncludeInApplicationCreation, final long userId);

	ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdAndOrgIdOrderByIdDesc(
			final int schemeId, String custAccNo,Integer[] stageThatNotIncludeInApplicationCreation, final long userId, final long orgId);
	
	ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndUserIdNotNullAndOrgIdOrderByIdDesc(
			final int schemeId, String custAccNo,Integer[] stageThatNotIncludeInApplicationCreation, final long orgId);
	
	// ##index JNS_INSURANCE_APP_MASTER_ACTV_ACC_CIF_STS_IDX
	List<ApplicationMasterV3> findByIsActiveTrueAndAccountNumber(String accountNo);
	
	ApplicationMasterV3 findFirstByIsActiveTrueAndAccountNumber(String accountNo);

	// --------------------- END FILTER FROM ACCOUNT NUMBER ---------------------

//	List<ApplicationMasterV3> findByIsActiveTrueAndStageIdNotInAndApplicationMasterOtherDetailsSource(List<Integer> stageIdList, Integer source);

//	@Query("select id from ApplicationMasterV3 where isActive=True And stageId Not In (:stageId) And createdDate <  :date And applicationMasterOtherDetails.source=:source")
//	List<Long> findIdByIsActiveTrueAndStageIdNotInAndCreatedDateBeforeAndApplicationMasterOtherDetailsSource(@Param("stageId") List<Integer> stageIdList,@Param("date") Date createdDate,@Param("source") Integer source);

//	@Query("select am from ApplicationMasterV3 am where isActive=True And stageId Not In (:stageId) And createdDate <  :date And applicationMasterOtherDetails.source=:source")
	List<ApplicationMasterV3> findIdByIsActiveTrueAndStageIdNotInAndCreatedDateBeforeAndApplicationMasterOtherDetailsSource(@Param("stageId") List<Integer> stageIdList,@Param("date") Date createdDate,@Param("source") Integer source);
//	List<ApplicationMasterV3> findByIsActiveTrueAndStageIdNotInAndCreatedDateBeforeAndApplicationMasterOtherDetailsSource(List<Integer> stageIdList,Date createdDate, Integer source);


	// ##index JNS_INSURANCE_APP_MASTER_ACTV_ACC_STG_CRD_IDX
	ApplicationMasterV3 findByIdAndIsActiveTrueAndStageId(Long applicationId,int stageId);

//    @Query("SELECT am FROM ApplicationMasterV3 am LEFT JOIN ClaimMasterV3 cm on cm.applicationMaster.id <> am.id WHERE am.orgId = :orgId AND am.schemeId = :schemeId AND am.isActive = True AND am.stageId = 6")
//    List<ApplicationMasterV3> getApplicationIdBySchemeIdAndOrgId(@Param("orgId") Long orgId, @Param("schemeId") int schemeId, Pageable pageable);
    
    //Index JNS_INSURANCE_app_master_schm_actv_acc_stg_cif_idx
    ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndCif(final int schemeId,String accountNo, final Integer[] stageId, String cif);
    
    
    

	@Modifying
	@Query(nativeQuery = true,value = "update JNS_INSURANCE.Application_master set BRANCH_ID=:branchId where ORG_ID=:orgId and scheme_id = 2 and id between :minApp and :maxApp")
	int updateBranchIdOnApplication(@Param("branchId") Long branchId,@Param("orgId") Long orgId,@Param("minApp") Long minApp,@Param("maxApp") Long maxApp);

	@Modifying
	@Query(nativeQuery = true,value = "update JNS_INSURANCE.Application_master_other_details set BRANCH_RO_ID=:branchRoId,BRANCH_ZO_ID=:branchZoId where ORG_ID=:orgId and scheme_id = 2 and APPLICATION_MASTER_ID between :minApp and :maxApp")
	int updateBranchRoZoIdOnApplicationMasterOtherDetails(@Param("branchRoId") Long branchRoId,@Param("branchZoId") Long branchZoId,@Param("orgId") Long orgId,@Param("minApp") Long minApp,@Param("maxApp") Long maxApp);
	
	@Modifying
	@Query(nativeQuery = true,value = "update JNS_INSURANCE.Application_master_other_details set BRANCH_RO_ID=:branchRoId where ORG_ID=:orgId and scheme_id = 2 and APPLICATION_MASTER_ID between :minApp and :maxApp")
	int updateBranchRoIdOnApplicationMasterOtherDetails(@Param("branchRoId") Long branchRoId,@Param("orgId") Long orgId,@Param("minApp") Long minApp,@Param("maxApp") Long maxApp);
	
	@Modifying
	@Query(nativeQuery = true,value = "update JNS_INSURANCE.Application_master_other_details set BRANCH_ZO_ID=:branchZoId where ORG_ID=:orgId and scheme_id = 2 and APPLICATION_MASTER_ID between :minApp and :maxApp")
	int updateBranchZoIdOnApplicationMasterOtherDetails(@Param("branchZoId") Long branchZoId,@Param("orgId") Long orgId,@Param("minApp") Long minApp,@Param("maxApp") Long maxApp);

	@Query("select id from ApplicationMasterV3 a where a.stageId=6 and lastTransactionDetails.coiStorageId is null")
	List<Long> findAllByStageIdAndLastTransactionDetailsCoiStorageIdIsNull();

//	@Query("select id from ApplicationMasterV3 a where a.stageId=6 and (isPushed is null or isPushed=0 )")
//	public Page<Long> findAllByIsPushedNull(PageRequest page);
//
//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3 SET isPushed =1 ,modifiedDate =:date WHERE id =:applicationId ")
//	int updatePublishFlagAndModified(@Param("date") Date date,@Param("applicationId") Long applicationId);
//
//
//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3 SET isPushed =1,isPushedToMaster=1 ,modifiedDate =:date WHERE id =:applicationId ")
//	int updatePublishFlagAndMasterDataFlagAndModified(@Param("date") Date date,@Param("applicationId") Long applicationId);


	@Query(nativeQuery = true,value = """
			select m.URN from JNS_INSURANCE.APPLICATION_MASTER m\s
			inner join JNS_INSURANCE.TRANSACTION_DETAILS d on d.id = m.LAST_TRANSACTION_ID
			where m.stage_id=6 and (d.TRANS_TIME_STAMP is null OR D.TRANS_UTR IS NULL)\
			""")
	public List<String> findUrnByStageCompletedAndTransactionUtrIsNull();

//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3 SET isPushed =0  WHERE urn =:urn ")
//	int updatePublishFlagFalseByUrn(@Param("urn") String urn);

//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3  set stageId=7,applicationStatus=3,statusChangeDate=:modifiedDate,modifiedDate=:modifiedDate WHERE isActive=true and stageId not in (:stageIds) AND applicationMasterOtherDetails.source=2")
//	int expireAssistedModeApplications(@Param("stageIds") List<Integer> stageIds, @Param("modifiedDate") Date modifiedDate);

//	@Query("select id from ApplicationMasterV3  WHERE isActive = true and stageId not in (:stageIds) AND applicationMasterOtherDetails.source in(2,4)")
//	public List<Long> fetchApplicationsIdTobeExpire(@Param("stageIds") List<Integer> stageIds);

//	@Query("select am from ApplicationMasterV3 am WHERE isActive = true and stageId not in (:stageIds) AND applicationMasterOtherDetails.source in(2,4)")
	public List<ApplicationMasterV3> findIdByIsActiveTrueAndStageIdNotInAndApplicationMasterOtherDetailsSourceIn(@Param("stageIds") List<Integer> stageIds, @Param("sourceId") List<Integer> sourceId);
	
	@Query("select id from ApplicationMasterV3  WHERE isActive = true AND stageId=6 AND enrollmentDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24: MI') AND enrollmentDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24: MI')")
	public Page<Long> getApplicationIdListByDateFilter(@Param("fromDate") String fromDate,@Param("toDate") String toDate,Pageable pageable);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 ap SET ap.stageId = 7, ap.applicationStatus = 3,ap.statusChangeDate =:modifiedDate,ap.modifiedDate = :modifiedDate WHERE ap.id=:applicationId and ap.stageId <> 6 and ap.applicationStatus <> 2 and ap.isActive = true")
	public void expireOtherModeApplications(@Param("applicationId") Long applicationId, @Param("modifiedDate") Date modifiedDate);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 ap SET ap.applicationStatus =:applicationStatus,ap.statusChangeDate =:modifiedDate,ap.modifiedDate = :modifiedDate WHERE ap.id=:applicationId and ap.isActive = true ")
	public void updateOptOutStatus(@Param("applicationStatus") Integer applicationStatus,@Param("applicationId") Long applicationId, @Param("modifiedDate") Date modifiedDate);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 ap SET ap.applicationStatus =:applicationStatus,ap.statusChangeDate =:modifiedDate,ap.modifiedDate = :modifiedDate WHERE ap.id IN (:applicationIds) and ap.isActive = true ")
	public void updateOptOutStatusByIds(@Param("applicationStatus") Integer applicationStatus,@Param("applicationIds") List<Long> applicationIds, @Param("modifiedDate") Date modifiedDate);
	
	@Query("select new com.opl.jns.ere.utils.ApplicationQueryProxy(accountNumber,schemeId,orgId) from ApplicationMasterV3  WHERE id =:applicationId and isActive = true")
	ApplicationQueryProxy fetchAccountNoSchemeIdOrgIdByAppId(@Param("applicationId") Long applicationId);

	@Query("select new com.opl.jns.ere.utils.ApplicationQueryProxy(schemeId,accountNumber,applicantInfo.firstName,applicantInfo.middleName,applicantInfo.lastName,applicationMasterOtherDetails.source) from ApplicationMasterV3  WHERE id =:applicationId and isActive = true ")
	ApplicationQueryProxy fetchAccountNumberApplicantInfoFirstNameMiddleNameLastNameSchemeIdApplicationMasterOtherDetailsSourceById(@Param("applicationId") Long applicationId);

	@Query("select new com.opl.jns.ere.utils.ApplicationQueryProxy(orgId,accountNumber,dob,urn,stageId,schemeId) from ApplicationMasterV3  WHERE id =:applicationId and isActive = true ")
	ApplicationQueryProxy fetchVerifyApiDetailsById(@Param("applicationId") Long applicationId);
	
	@Query("""
			select new com.opl.jns.ere.utils.ApplicationQueryProxy(id,orgId,urn,applicationStatus) from ApplicationMasterV3\
			 WHERE orgId =:orgId and schemeId =:schemeId and isActive = true and cif = :cif and applicationStatus IN (:applicationStatus)\
			""")
	ApplicationQueryProxy fetchEnromentValidateByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusIn(@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId,@Param("cif")  String cif,@Param("applicationStatus") Integer[] applicationStatus);
	
	@Query("""
			select new com.opl.jns.ere.utils.ApplicationQueryProxy(orgId,urn,applicationStatus) from ApplicationMasterV3\
			 WHERE schemeId =:schemeId and isActive = true and accountNumber =:accountNumber  and cif = :cif and applicationStatus IN (:applicationStatus) and id NOT IN (:applicationId)\
			""")
	ApplicationQueryProxy fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusInAndIdNotIn(@Param("schemeId") Integer schemeId,@Param("accountNumber") String accountNumber,@Param("cif")  String cif,@Param("applicationStatus") Integer[] applicationStatus,@Param("applicationId") Long applicationId);
	
	@Query("""
			select new com.opl.jns.ere.utils.ApplicationQueryProxy(id, orgId,urn,applicationStatus) from ApplicationMasterV3\
			 WHERE schemeId =:schemeId and isActive = true and accountNumber =:accountNumber  and cif = :cif and applicationStatus IN (:applicationStatus)\
			""")
	ApplicationQueryProxy fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndCifAndApplicationStatusIn(@Param("schemeId") Integer schemeId,@Param("accountNumber") String accountNumber,@Param("cif")  String cif,@Param("applicationStatus") Integer[] applicationStatus);

//	@Query("select new com.opl.jns.ere.utils.ApplicationQueryProxy(orgId,urn,applicationStatus) from ApplicationMasterV3"
//			+ " WHERE schemeId =:schemeId and isActive = true and accountNumber =:accountNumber and stageId NOT IN (:stageId)  and cif = :cif and applicationMasterOtherDetails.source=:source")
//	ApplicationQueryProxy fetchEnromentValidateBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndCif(@Param("schemeId") Integer schemeId,
//			@Param("accountNumber") String accountNumber,@Param("stageId") Integer[] stageId,@Param("cif") String cif,@Param("source") Integer source);
	
	//ApplicationMasterV3 findFirstBySchemeIdAndIsActiveTrueAndAccountNumberAndStageIdNotInAndCif(final int schemeId,String accountNo, final Integer[] stageId, String cif);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 SET urn =:urn WHERE orgId =:orgId and schemeId =:schemeId and id =:applicationId")
	int updateUrn(@Param("urn") String urn,@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId,@Param("applicationId") Long applicationId);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 SET userId =:userId   WHERE id =:applicationId and isActive = true  ")
	int updateUserIdByApplicationId(@Param("userId") Long userId,@Param("applicationId") Long applicationId);

	// ##index JNS_INSURANCE_APP_MST_IS_ACTIVE_USER_ID_STAGE_ID
	@Query("select new com.opl.jns.ere.utils.ApplicationQueryProxy(id,schemeId,applicantInfo.name,stageId) from ApplicationMasterV3  WHERE isActive = true and userId =:userId and stageId in (:stageId)")
	public List<ApplicationQueryProxy> findAllByIsActiveTrueAndUserIdAndStageIdIn(@Param("userId") Long applicationId,@Param("stageId") List<Integer> stageId);

	// ##index JNS_INSURANCE_APP_MST_IS_ACTIVE_USER_ID_STAGE_ID
	@Query("select am from ApplicationMasterV3 am WHERE am.isActive = true and am.userId =:userId and am.stageId = :stageId order by id desc")
	public List<ApplicationMasterV3> findAllByIsActiveTrueAndUserIdAndStageId(@Param("userId") Long userId,@Param("stageId") Integer stageId,Pageable pageble);
	
	@Query("select am from ApplicationMasterV3 am WHERE am.isActive = true and am.userId =:userId order by id desc")
	public List<ApplicationMasterV3> findAllByIsActiveTrueAndUserId(@Param("userId") Long userId);
	
	@Query("select am from ApplicationMasterV3 am WHERE am.isActive = true and am.userId =:userId and am.applicationStatus = :applicationStatus order by id desc")
	public List<ApplicationMasterV3> findAllByIsActiveTrueAndUserIdAndStatus(@Param("userId") Long userId,@Param("applicationStatus") Integer applicationStatus,Pageable pageble);

	@Query(nativeQuery = true,value = "select to_timestamp(push_ready_date) from JNS_PUBLISH_API.APPLICATION_MASTER where application_id = :appId")
	String getPushReadyDate(@Param("appId") Long appId);
	
	Long countByIsActiveTrueAndUserIdAndApplicationStatus(Long userId,Integer status);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterV3 SET debitStatus =:debitStatus,message =:message WHERE id =:applicationId and isActive = true")
	int updateDebitStatusByApplicationId(@Param("debitStatus") Integer debitStatus,@Param("message") String message,@Param("applicationId") Long applicationId);
	
//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3 SET isBankEnrollStatusPush =1,modifiedDate =:date WHERE id =:applicationId ")
//	int updateEnrollBankPushFlagAndModified(@Param("date") Date date,@Param("applicationId") Long applicationId);
	
//	@Transactional
//	@Modifying
//	@Query("UPDATE ApplicationMasterV3 SET isInsurerEnrollStatusPush =1,modifiedDate =:date WHERE id =:applicationId ")
//	int updateEnrollInsurerPushFlagAndModified(@Param("date") Date date,@Param("applicationId") Long applicationId);
}
