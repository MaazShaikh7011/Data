package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author Krunal Prajapati Date : 19-01-2024
 */

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nominee_details", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class NomineeDetailsV2 implements Serializable {

	private static final long serialVersionUID = -2449104695937200593L;

	@Id
	@Column(name = "id")
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NOMINEE_DETAILS_SEQ_GEN")
	//@SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "NOMINEE_DETAILS_SEQ_GEN", sequenceName = "NOMINEE_DETAILS_SEQ_GEN", allocationSize = 1)
	private Long id;

	@Column(name = "application_id", nullable = false)
	private Long applicationId;

	@Column(name = "address_id", nullable = true)
	private Long addressId;

	@Column(name = "relation_id", nullable = true)
	private Integer relationId;

	@Convert(converter = AESOracle.class)
	@Column(name = "mobile_number", nullable = true, columnDefinition = "varchar(255) default ''")
	private String mobileNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "email", nullable = true, columnDefinition = "varchar(255) default ''")
	private String email;

	@Column(name = "is_Other_Claimant", nullable = false)
	private Boolean isOtherClaimant;

	@Column(name = "gd_relation_id", nullable = true)
	private Integer gdRelationId;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_mobile", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdMobile;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_email", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdEmail;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

}
