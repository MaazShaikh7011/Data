package com.opl.jns.ere.repo.v2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.opl.jns.ere.domain.v2.AddressMasterV2;



public interface AddressMasterRepositoryV2 extends JpaRepository<AddressMasterV2, Long>{
	
	@Query(value = "SELECT add_mst_seq_gen.nextval FROM dual", nativeQuery = true)
    public Long getNextValMySequence();

}
