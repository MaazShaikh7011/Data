package com.opl.jns.ere.enums;

public enum YesNo {

	YES(1, "YES","Y"),
	NO(2, "NO","N"),
	N(2, "NO","NO"),
	Y(1, "YES","YES");
		

	private Integer id;
	private String value;
	private final String shortName;

	private YesNo(Integer id, String value, String shortName) {
		this.id = id;
		this.value = value;
		this.shortName = shortName;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getShortName() {
		return shortName;
	}

	public static YesNo fromId(Integer v) {
		for (YesNo c : YesNo.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static YesNo fromShortName(String v) {
		for (YesNo c : YesNo.values()) {
			if (c.shortName.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	public static YesNo fromValue(String v) {
		for (YesNo c : YesNo.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static YesNo[] getAll() {
		return YesNo.values();
	}

}
