package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clm_dedupe_details", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmDeDupeDetails extends Auditor {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "clm_dedupe_details_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "clm_dedupe_details_seq_gen", sequenceName = "clm_dedupe_details_seq_gen", allocationSize = 1)
    private Long id;

//    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
//    @JoinColumn(name = "claim_id", referencedColumnName = "id")

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "claim_id")
    private ClmMaster claimMaster;

    @Column(name = "hospitalisation_date", nullable = true)
    private Date hospitalisationDate;

    @Column(name = "fir_no", nullable = true)
    private String fIRNo;

    @Column(name = "fir_date", nullable = true)
    private Date fIRDate;

    @Column(name = "panchnama_no", nullable = true)
    private String panchnamaNo;

    @Column(name = "panchnama_date", nullable = true)
    private Date panchnamaDate;

    @Column(name = "post_mortem_report_no", nullable = true)
    private String postMortemReportNo;

    @Column(name = "post_mortem_report_date", nullable = true)
    private Date postMortemReportDate;

    @Column(name = "death_disability_certificate_report_no", nullable = true)
    private String deathDisabilityCertificateReportNo;

    @Column(name = "death_disability_certificate_report_date", nullable = true)
    private Date deathDisabilityCertificateReportDate;

}
