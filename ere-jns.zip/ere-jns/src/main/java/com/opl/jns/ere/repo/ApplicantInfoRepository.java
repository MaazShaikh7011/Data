package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.*;

import java.util.List;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
public interface ApplicantInfoRepository extends JpaRepository<ApplicantInfo, Long> {

	List<ApplicantInfo> findAllByApplicationMasterIdInAndIsActiveTrue(List<Long> applicationIds);

	List<ApplicantInfo> findByMobileNumberAndIsActiveTrue(String mobileNumber);

	List<ApplicantInfo> findByKycId1AndKycIdNumber1AndIsActiveTrue(String kycId, String kycIdNumber);

	List<ApplicantInfo> findByPanAndIsActiveTrue(String searchValue);

	List<ApplicantInfo> findByKycId2AndKycIdNumber2AndIsActiveTrue(String searchTypeAsStr, String searchValue);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicantInfo SET mobileNumber =:mobileNo WHERE applicationMaster.id =:applicationId and isActive=true")
	int updateMobileNumberByApplicationId(@Param("mobileNo") String mobileNo,@Param("applicationId") Long applicationId);
	
	
}
