package com.opl.jns.ere.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.UtilizeFuzzyApiCall;

public interface UtilizeFuzzyApiCallRepository extends JpaRepository<UtilizeFuzzyApiCall, Long> {

	Optional<UtilizeFuzzyApiCall> findByApplicationIdAndStageIdAndStatus(Long applicationId, int stageId, Integer id);
	
	Optional<UtilizeFuzzyApiCall> findByApplicationIdAndStageId(Long applicationId, int stageId);
	
	Optional<UtilizeFuzzyApiCall> findByApplicationId(Long applicationId);

}
