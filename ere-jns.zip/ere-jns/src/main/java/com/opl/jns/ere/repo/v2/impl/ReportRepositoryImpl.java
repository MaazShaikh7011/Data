package com.opl.jns.ere.repo.v2.impl;

import java.sql.Clob;
import java.util.Date;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.opl.jns.ere.repo.v2.ReportRepository;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
@Repository
@Slf4j
public class ReportRepositoryImpl implements ReportRepository {

	@Qualifier("emFR")
	@Autowired
	EntityManager entityManager;

	@Override
	public String getDataFromProducer(Long claimId, Long schemeId, String certiNo,String firNo, String panchnamaNo,String postMtrmReportNo,Date certiDate,Date firDate, Date panchnamaDate,Date postMtrmReportDate, String spName) {
		try {
			log.info("spName {}, claimId-> {}, schemeId-> {}", spName, claimId, schemeId);
			StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
			storedProcedureQuery.registerStoredProcedureParameter("claim_id", Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("scheme_id", Long.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("death_disability_certi_no", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("fir_no", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("panchnama_no", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("postmoterm_report_no", String.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("death_disability_certi_date", Date.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("fir_date", Date.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("panchnama_date", Date.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("postmoterm_report_date", Date.class, ParameterMode.IN);
			storedProcedureQuery.registerStoredProcedureParameter("result_json", Clob.class, ParameterMode.OUT);
			storedProcedureQuery.setParameter("claim_id", claimId);
			storedProcedureQuery.setParameter("scheme_id", schemeId);
			storedProcedureQuery.setParameter("death_disability_certi_no", certiNo);
			storedProcedureQuery.setParameter("fir_no", firNo);
			storedProcedureQuery.setParameter("panchnama_no", panchnamaNo);
			storedProcedureQuery.setParameter("postmoterm_report_no", postMtrmReportNo);
			storedProcedureQuery.setParameter("death_disability_certi_date", certiDate);
			storedProcedureQuery.setParameter("fir_date", firDate);
			storedProcedureQuery.setParameter("panchnama_date", panchnamaDate);
			storedProcedureQuery.setParameter("postmoterm_report_date", postMtrmReportDate);
			storedProcedureQuery.execute();
			return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result_json"));
		} catch (Exception e) {
			log.error("Exception is getting while Call SP", e);
		}
		return null;
	}
}
