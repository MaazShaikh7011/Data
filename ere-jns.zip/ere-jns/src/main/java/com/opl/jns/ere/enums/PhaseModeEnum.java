package com.opl.jns.ere.enums;

public enum PhaseModeEnum {
	PHASE_1(1, "Phase 1"), PHASE_2(2, "Phase 2");

	private Integer id;
	private String value;

	private PhaseModeEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static PhaseModeEnum fromId(Integer v) {
		for (PhaseModeEnum c : PhaseModeEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PhaseModeEnum[] getAll() {
		return PhaseModeEnum.values();
	}
}
