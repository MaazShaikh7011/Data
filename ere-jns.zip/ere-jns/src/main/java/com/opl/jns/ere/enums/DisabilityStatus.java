package com.opl.jns.ere.enums;

public enum DisabilityStatus {


	YES(1, "YES","Y"),
	NO(2, "YES","YES"),
	y(3, "NO","NO"),
	N(4, "NO","N"),
	NULL(5, "NO","Null");

	private Integer id;
	private String value;
	private final String Status;
	
	private DisabilityStatus(Integer id, String value, String status) {
		this.id = id;
		this.value = value;
		Status = status;
	}
	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getStatus() {
		return Status;
	}
	
	public static DisabilityStatus fromId(Integer v) {
		for (DisabilityStatus c : DisabilityStatus.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static DisabilityStatus fromStatus(String v) {
		for (DisabilityStatus c : DisabilityStatus.values()) {
			if (c.Status.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static DisabilityStatus[] getAll() {
		return DisabilityStatus.values();
	}
	
}
