package com.opl.jns.ere.enums;

public enum Gender {

	MALE(1, "Male","M"),
	FEMALE(2, "Female","F"),
	THIRD_GENDER(3, "Other","T");
	

	private Integer id;
	private String value;
	private final String bankValue;

	private Gender(Integer id, String value, String bankValue) {
		this.id = id;
		this.value = value;
		this.bankValue = bankValue;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getBankValue() {
		return bankValue;
	}

	public static Gender fromId(Integer v) {
		for (Gender c : Gender.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Gender fromBankValue(String v) {
		for (Gender c : Gender.values()) {
			if (c.bankValue.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static Gender[] getAll() {
		return Gender.values();
	}

}
