package com.opl.jns.ere.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.*;

import jakarta.persistence.*;
import java.util.Date;

/**
 * @author sandip.bhetariya
 *
 */
@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
//findByApplicationIdAndStageIdAndStatus
@Table(name = "utilize_fuzzy_api_call",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
		@Index(columnList = "application_id,stage_id,status", name = DBNameConstant.JNS_INSURANCE + "utilize_fuzzy_api_call_appid_stageid_status_idx"),
		@Index(columnList = "application_id,stage_id", name = DBNameConstant.JNS_INSURANCE + "utilize_fuzzy_api_call_appid_stageid_idx"),
		@Index(columnList = "application_id", name = DBNameConstant.JNS_INSURANCE + "utilize_fuzzy_api_call_appid_idx"),
})
public class UtilizeFuzzyApiCall {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "utilize_fuzzy_api_call_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "utilize_fuzzy_api_call_seq_gen", sequenceName = "utilize_fuzzy_api_call_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "application_id")
	private Long applicationId;

	@Column(name = "stage_id", nullable = false)
	private Integer stageId;

	@Column(name = "status", nullable = false)
	private Integer status;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;
}
