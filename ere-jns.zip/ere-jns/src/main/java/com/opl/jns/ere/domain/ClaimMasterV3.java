//package com.opl.jns.ere.domain;
//
//import java.util.Date;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Convert;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Index;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//
//import com.opl.jns.utils.common.AESOracle;
//import com.opl.jns.utils.common.DateEncryptorAes;
//import com.opl.jns.utils.constant.DBNameConstant;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//import lombok.NoArgsConstructor;
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "claim_master",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
//		@Index(columnList = "application_id,is_active,claim_status", name = DBNameConstant.JNS_INSURANCE + "_claim_mst_appid_actv_clmsts_idx"),
//		@Index(columnList = "claim_stage_id,is_active", name = DBNameConstant.JNS_INSURANCE + "_claim_mst_clmstg_actv_idx"),
//		@Index(columnList = "is_active", name = DBNameConstant.JNS_INSURANCE + "_claim_mst_clmstg_actv_idx"),
//		@Index(columnList = "claim_status,application_id", name = DBNameConstant.JNS_INSURANCE + "_claim_mst_clm_status_app_id")
//})
//public class ClaimMasterV3 extends Auditor {
//
//	@Id
//	@Column(name = "id")
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "claim_master_seq_gen")
//	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "claim_master_seq_gen", sequenceName = "claim_master_seq_gen", allocationSize = 1)
//	private Long id;
//
//	@OneToOne(cascade = CascadeType.MERGE)
//	@JoinColumn(name = "application_id", referencedColumnName = "id")
//	private ApplicationMasterV3 applicationMaster;
//
//	@OneToOne(mappedBy = "claimMaster", cascade = CascadeType.ALL)
//	private ClaimDetailV3 claimDetail;
//	
//	@Column(name = "scheme_id", nullable = true)
//	private Integer schemeId;
//	
//	@Column(name = "org_id", nullable = true)
//	private Long orgId;
//
//	/**
//	 * CLAIM JOURNEY STAGE ID
//	 */
//	@Column(name = "claim_stage_id", nullable = true)
//	private Integer claimStageId;
//
//	/**
//	 * CLAIM BANK BRANCH ID
//	 */
//	@Column(name = "claim_branch_id", nullable = true)
//	private Long claimBranchId;
//
//	/**
//	 * CLAIM BANK ID
//	 */
////    @Column(name = "org_id", nullable = true)
////    private Long orgId;
//
//	/**
//	 * INSURER ORG ID
//	 */
////    @Column(name = "insurer_org_id", nullable = true)
////    private Long insurerOrgId;
//
////    @Column(name = "other_claimant_id", nullable = true)
////    private Long otherClaimantId;
//
//	/**
//	 * CLAIM JOURNEY COMPLETION DATE
//	 */
//	@Column(name = "claim_date", nullable = true)
//	private Date claimDate;
//
//	/**
//	 * CLAIM AMOUNT (CALCULATED BY JANSURAKSHA PLATFORM)
//	 */
//	@Column(name = "claim_amount", nullable = true)
//	private Double claimAmount;
//
//	/**
//	 * JANSURAKSHA CLAIM STATUS (MANAGE CLAIM DASHBOARD)
//	 */
//	@Column(name = "claim_status", nullable = true)
//	private Integer claimStatus;
//
//	@Column(name = "message", nullable = true)
//	private String message;
//
//	@Column(name = "is_pushed")
//	private Boolean isPushed;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API AFTER CLAIM PAYMENT DEDUCTION
//	 */
//	@Column(name = "transaction_utr", nullable = true)
//	private String transactionUtr;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API AFTER CLAIM PAYMENT DEDUCTION
//	 */
//	@Convert(converter = DateEncryptorAes.class)
//	@Column(name = "date_of_transaction", nullable = true)
//	private Date dateOfTransaction;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API AFTER CLAIM PAYMENT DEDUCTION
//	 */
//	@Column(name = "amount_of_transaction", nullable = true)
//	private Double amountOfTransaction;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API (UPDATE CLAIM STATUS API)
//	 */
//	@Column(name = "insurer_claim_id", nullable = true)
//	private String insurerClaimId;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API (UPDATE CLAIM STATUS API)
//	 */
//	@Column(name = "insurer_status", nullable = true)
//	private String insurerStatus;
//
//	/**
//	 * RECIEVED FROM INSURER REVERSE API (UPDATE CLAIM STATUS API)
//	 */
//	@Column(name = "insurer_reason", nullable = true)
//	private String insurerReason;
//
//	/**
//	 * SEND BACK TO BANK REASON ID
//	 */
//	@Column(name = "status_reason_id", nullable = true)
//	private Integer statusReasonId;
//
//	/**
//	 * SEND BACK TO BANK REASON (IN CASE OF OTHER SELECTION)
//	 */
//	@Column(name = "status_reason", nullable = true)
//	private String statusReason;
//
//	/**
//	 * TO MAINTAIN REOPEN OPTION FOR 2 TIMES REJECTION ONLY
//	 */
//	@Column(name = "reject_cnt")
//	private Integer rejectCnt;
//
//	@Column(name = "is_claimant_same", nullable = true)
//	private Boolean isClaimantSame;
//
//	@Column(name = "queried_storage_id")
//	private String queriedStorageId;
//	
//	@Column(name = "IS_BANK_STATUS_PUSH")
//	private Boolean isBankStatusPush;
//	
//	@Column(name = "IS_INSURER_STATUS_PUSH")
//	private Boolean isInsurerStatusPush;
//
////    @Column(name = "duplicate_found")
////    private String duplicateFound;
//
////    @Column(name = "account_holder_name")
////    private String accountHolderName;
//
////    @Column(name = "customer_account_number")
////    private String customerAccountNumber;
//
////    @Column(name = "schme_id")
////    private Integer schemeId;
//
////    @Column(name = "cif")
////    private String cif;
//
////    @Column(name = "mobile_number")
////    private String mobileNumber;
//
////    @Column(name = "urn")
////    private String urn;
//
//}
