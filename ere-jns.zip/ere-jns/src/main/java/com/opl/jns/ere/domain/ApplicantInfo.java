package com.opl.jns.ere.domain;

import com.opl.jns.ere.enums.*;
import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author ravi.thummar
 * Date : 15-06-2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "applicant_info",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE,indexes = {
        @Index(columnList = "application_id" , name = DBNameConstant.JNS_INSURANCE + "_app_info_app_id_idx"),
        @Index(columnList = "mobile_number,is_active" , name = DBNameConstant.JNS_INSURANCE + "_app_info_mobile_number_is_active_idx"),
        @Index(columnList = "kyc_id_1,kyc_id_number_1" , name = DBNameConstant.JNS_INSURANCE + "_app_info_kyc_id_kyc_id_number_1_idx"),
        @Index(columnList = "address_id" , name = DBNameConstant.JNS_INSURANCE + "_app_info_address_id_idx"),
        @Index(columnList = "KYC_ID_2,KYC_ID_NUMBER_2,IS_ACTIVE" , name = DBNameConstant.JNS_INSURANCE +  "_APP_INFO_KCY_ID_2_KYC_ID_NUMBER_2_IDX"),
        @Index(columnList = "PAN,IS_ACTIVE" , name = DBNameConstant.JNS_INSURANCE +  "_app_info_pan_act_idx")
})
public class ApplicantInfo {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "applicant_info_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "applicant_info_seq_gen", sequenceName = "applicant_info_seq_gen", allocationSize = 1)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private ApplicationMasterV3 applicationMaster;
    
//  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//	@JoinColumn(name = "application_id")
//	private ApplicationMasterV3 applicationMaster;

    @Convert(converter = AESOracle.class)
    @Column(name = "name", nullable = true)
    private String name;

    @Convert(converter = AESOracle.class)
    @Column(name = "first_name", nullable = true)
    private String firstName;

    @Convert(converter = AESOracle.class)
    @Column(name = "middle_name", nullable = true)
    private String middleName;

    @Convert(converter = AESOracle.class)
    @Column(name = "last_name", nullable = true)
    private String lastName;
    
    @Convert(converter = AESOracle.class)
    @Column(name = "father_husband_name", nullable = true)
    private String fatherHusbandName;

    @Column(name = "ifsc", nullable = true)
    private String ifsc;

    @Column(name = "is_kyc_update", nullable = true)
    private Boolean isKYCUpdate;

    @Column(name = "is_pmjjby_exists", nullable = true)
    private Boolean isPMJJBYExists;

    @Column(name = "is_pmsby_exists", nullable = true)
    private Boolean isPMSBYExists;

    @Column(name = "gender_id", nullable = true)
    private Integer genderId;

    @Transient
    private Gender gender;

    @PostLoad
    void fillTransient() {
        if (gender != null) {
            this.gender = Gender.fromId(genderId);
        }
//        if (ckyc != null) {
//            this.ckyc = YesNo.fromId(ckycId);
//        }
//        if (disabilityStatus != null) {
//            this.disabilityStatus = YesNo.fromId(disabilityStatusId);
//        }
    }

    @Convert(converter = AESOracle.class)
    @Column(name = "mobile_number", nullable = true)
    private String mobileNumber;

    @Convert(converter = AESOracle.class)
    @Column(name = "email", nullable = true)
    private String email;

    @Convert(converter = AESOracle.class)
    @Column(name = "kyc_id_1", nullable = true)
    private String kycId1;
    
//    @Convert(converter = AESOracle.class)
//    @Column(name = "kyc_id_3_id", nullable = true)
//    private Long kycId3Id;

    @Convert(converter = AESOracle.class)
    @Column(name = "kyc_id_number_1", nullable = true)
    private String kycIdNumber1;

    @Convert(converter = AESOracle.class)
    @Column(name = "kyc_id_2", nullable = true)
    private String kycId2;

    @Convert(converter = AESOracle.class)
    @Column(name = "kyc_id_number_2", nullable = true)
    private String kycIdNumber2;

//    @Convert(converter = AESOracle.class)
//    @Column(name = "kyc_id_3", nullable = true)
//    private String kycId3;
//
//    @Convert(converter = AESOracle.class)
//    @Column(name = "kyc_id_number_3", nullable = true)
//    private String kycIdNumber3;

    @Convert(converter = AESOracle.class)
    @Column(name = "pan", nullable = true)
    private String pan;

    @Convert(converter = AESOracle.class)
    @Column(name = "aadhaar", nullable = true)
    private String aadhaar;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
    private AddressMasterV3 address;

    @Column(name = "is_same_app_address", nullable = true)
    private Boolean isSameAppAddress;

	@Convert(converter = DateEncryptorAes.class)
    @Column(name = "dob", nullable = true)
    private Date dob;
    
    @Column(name = "ckyc", nullable = true)
    private String ckyc;
   
    @Column(name = "created_by", nullable = true)
    private Long createdBy;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "modified_by", nullable = true)
    private Long modifiedBy;

    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;
    
    @Column(name = "disability_status",nullable = false)
    private String disabilityStatus;
    
    @Column(name = "disability_details",nullable = false)
    private String disabilityDetails;
    
    @Column(name = "ckyc_number",nullable = true)
    private String ckycNumber;  

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;
    
    @Column(name = "is_nominee_same_enroll", nullable = true)
    private Boolean isNomineeDetailsSameEnroll;
    
    @Convert(converter = AESOracle.class)
    @Column(name = "occupation",nullable = true)
    private String occupation;

    @Column(name = "app_created_date", nullable = true)
    private Date appCreatedDate;

    @Override
    public String toString() {
        return "";
    }
}
