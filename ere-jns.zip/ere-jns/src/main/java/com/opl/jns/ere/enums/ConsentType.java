package com.opl.jns.ere.enums;

public enum ConsentType {
    DIY_PREMIUM_PMSBY(1, "DIY - Premium - PMSBY"),
    DIY_PREMIUM_PMJJBY(2, "DIY - Premium - PMJJBY "),
    USER_SIGNUP_PRIVACY_POLICY(3, "USER - Signup - Privacy - Policy"),
    USER_SIGNUP_TERM_CONDITION(4, "USER - Signup - Term - Condition"),
    USER_SIGNUP_DISCLAIMER(5, "USER - Signup - Disclaimer"),
    BO_ENROLLMENT(6, "BO - Enrollment"),
    BO_CLAIM(7, "BO - Claim");


    private Integer id;
    private String value;


    private ConsentType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static ConsentType fromId(Integer v) {
        for (ConsentType c : ConsentType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static ConsentType fromValue(String v) {
        for (ConsentType c : ConsentType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static ConsentType[] getAll() {
        return ConsentType.values();
    }

}
