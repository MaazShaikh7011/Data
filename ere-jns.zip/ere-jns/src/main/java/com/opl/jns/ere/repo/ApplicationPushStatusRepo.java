package com.opl.jns.ere.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ApplicationPushStatus;

public interface ApplicationPushStatusRepo extends JpaRepository<ApplicationPushStatus, Long> {

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET masterPush =:status, masterPushDate =:date WHERE id =:appId ")
	int updateMasterPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("date") Date date);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET bankPush =:status, bankPushDate =:date WHERE id =:appId ")
	int updateBankPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("date") Date date);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET bankPush =:status, bankPushDate =:date, bankPushStatus =:bankPushStatus WHERE id =:appId ")
	int updateBankPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("bankPushStatus") Integer bankPushStatus, @Param("date") Date date);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET bankPushStatus =:bankPushStatus WHERE id =:appId ")
	int updateBankPushStatus(@Param("appId") Long appId, @Param("bankPushStatus") Integer bankPushStatus);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET insurerPush =:status, insurerPushDate =:date WHERE id =:appId ")
	int updateInsurerPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("date") Date date);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET insurerPush =:status, insurerPushDate =:date, insurerPushStatus =:insurerPushStatus WHERE id =:appId ")
	int updateInsurerPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("insurerPushStatus") Integer insurerPushStatus, @Param("date") Date date);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET insurerPushStatus =:insurerPushStatus WHERE id =:appId ")
	int updateInsurerPushStatus(@Param("appId") Long appId, @Param("insurerPushStatus") Integer insurerPushStatus);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET bankOptOutPush =:status, bankOptOutPushDate =:date WHERE id =:appId ")
	int updateBankOptOutPushFlag(@Param("appId") Long appId, @Param("status") boolean status, @Param("date") Date date);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET insurerOptOutPush =:status, insurerOptOutPushDate =:date WHERE id =:appId ")
	int updateInsurerOptOutPushFlag(@Param("appId") Long appId, @Param("status") boolean status,
			@Param("date") Date date);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET bankNmnDtlsPush =:status, bankNmnDtlsPushDate =:date WHERE id =:appId ")
	int updateBankNmnDtlsPushFlag(@Param("appId") Long appId, @Param("status") boolean status,
			@Param("date") Date date);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationPushStatus SET insurerNmnDtlsPush =:status, insurerNmnDtlsPushDate =:date WHERE id =:appId ")
	int updateInsurerNmnDtlsPushFlag(@Param("appId") Long appId, @Param("status") boolean status,
			@Param("date") Date date);
	
	@Query("select a.id from ApplicationPushStatus a where a.masterPush=false ")
	public Page<Long> findAllByIsPushedNull(Pageable pageable);

	/**FOR SCHEDULAR USE*/
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join ApplicationMasterV3 am on am.id=a.id and am.insurerOrgId != 226 "
			+ " where (a.bankPush=false or a.insurerPush=false) "			
			+ " and (a.masterPushDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and a.masterPushDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankInsurerPushNull(@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.isActive=true and am.insurerOrgId=:orgId and a.insurerPush=false and a.masterPushDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and a.masterPushDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and a.phaseMode=2")
	public List<Long> findAllByPMSBYInsurerPushNullAndOrgId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true "
			+ " where am.isActive=true and am.insurerOrgId=:orgId and a.insurerPush=false and a.masterPushDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and a.masterPushDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and a.phaseMode=2")
	public List<Long> findAllByPMJJBYInsurerPushNullAndOrgId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.isActive=true and am.orgId=:orgId and a.bankPush=false and a.masterPushDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and a.masterPushDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and a.phaseMode=2")
	public List<Long> findAllByPMSBYBankPushNullAndOrgId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true "
			+ " where am.isActive=true and am.orgId=:orgId and a.bankPush=false and a.masterPushDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and a.masterPushDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and a.phaseMode=2")
	public List<Long> findAllByPMJJBYBankPushNullAndOrgId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	/**FOR SCHEDULAR USE*/
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " where (a.bankOptOutPush=false or a.insurerOptOutPush=false) and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankInsurerOptOutPushNull(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.orgId=:orgId and a.bankOptOutPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankPMSBYOptOutPushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true "
			+ " where am.orgId=:orgId and a.bankOptOutPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankPMJJBYOptOutPushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.insurerOrgId=:orgId and a.insurerOptOutPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByInsurerPMSBYOptOutPushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true "
			+ " where am.insurerOrgId=:orgId and a.insurerOptOutPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByInsurerPMJJBYOptOutPushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	/**FOR SCHEDULAR USE*/
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " where (a.bankNmnDtlsPush=false or a.insurerNmnDtlsPush=false) and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankInsurerNomineeUpdatePushNull(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.orgId=:orgId and a.bankNmnDtlsPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankPMSBYNomineeUpdatePushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true  "
			+ " where am.orgId=:orgId and a.bankNmnDtlsPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByBankPMJJBYNomineeUpdatePushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMSBY am on am.id=a.id and am.isActive=true "
			+ " where am.insurerOrgId=:orgId and a.insurerNmnDtlsPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByInsurerPMSBYNomineeUpdatePushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select a.id from ApplicationPushStatus a "
			+ " inner join MiscellaneousAudit mo on mo.applicationId=a.id and mo.type =:type and mo.isActive=true "
			+ " inner join PMJJBY am on am.id=a.id and am.isActive=true "
			+ " where am.insurerOrgId=:orgId and a.insurerNmnDtlsPush=false and (mo.createdDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and mo.createdDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and a.phaseMode=2")
	public List<Long> findAllByInsurerPMJJBYNomineeUpdatePushNullAndOrgId(@Param("type") Integer type,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId);
	
	@Query("select asp.id from ApplicationPushStatus asp "
			+ " inner join ApplicationMasterV3 am on am.id=asp.id "
			+ " where asp.masterPushDate >= TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and asp.masterPushDate <= TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') "
			+ "and asp.bankPush = false and asp.bankPushStatus is null order by asp.masterPushDate asc")
	public List<Long> fetchPendingBankPushAppIds(@Param("fromDate") String fromDate,@Param("toDate") String toDate, Pageable pageable);
	
	@Query("select asp.id from ApplicationPushStatus asp "
			+ " inner join ApplicationMasterV3 am on am.id=asp.id"
			+ " where asp.masterPushDate >= TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and asp.masterPushDate <= TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') "
			+ "and asp.insurerPush = false and asp.insurerPushStatus is null order by asp.masterPushDate asc")
	public List<Long> fetchPendingInsurerPushAppIds(@Param("fromDate") String fromDate,@Param("toDate") String toDate, Pageable pageable);

}