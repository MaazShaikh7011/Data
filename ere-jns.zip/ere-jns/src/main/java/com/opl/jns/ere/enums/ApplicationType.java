package com.opl.jns.ere.enums;

public enum ApplicationType {

        APPLICATION(1, "application"),
        USER(2, "user"),
        CLAIM(3, "claim");

        private Integer id;
        private String value;


        private ApplicationType(Integer id, String value) {
            this.id = id;
            this.value = value;
        }
    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static ApplicationType fromId(Integer v) {
        for (ApplicationType c : ApplicationType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static ApplicationType fromValue(String v) {
        for (ApplicationType c : ApplicationType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static ApplicationType[] getAll() {
        return ApplicationType.values();
    }

}
