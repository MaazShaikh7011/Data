package com.opl.jns.ere.repo.v2;

import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Krunal Prajapati
 * Date : 19-01-2024
 */


public interface NomineeDetailsRepositoryV2 extends JpaRepository<NomineeDetailsV2, Long> {

	NomineeDetailsV2 findByApplicationIdAndIsActiveTrue(final long applicationId);
	NomineeDetailsV2 findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(final long applicationId);

//	@Transactional
//	@Modifying(clearAutomatically = true)
//	@Query("UPDATE NomineeDetailsV2 SET isActive = FALSE WHERE applicationId = :applicationId")
//	void isActiveFalseByApplicationId(@Param("applicationId") Long applicationId);
	
	@Query(value = "SELECT nominee_details_seq_gen.nextval FROM dual", nativeQuery = true)
    public Long getNextValMySequence();

}
