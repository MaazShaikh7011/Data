package com.opl.jns.ere.enums;

public enum QueriedClaimEnum {

	QUERY_1(1, "Complete claim documents not submitted by claimants"),
	QUERY_2(2, "Claim documents not forwarded by banks to insurer"),
	QUERY_3(3, "Deceased’s name mismatch with death certificate"),
	QUERY_4(4, "Nominee’s name differs in enrolment & claim form"),
	QUERY_5(5, "KYC proof of nominee not submitted"),
	QUERY_6(6, "NEFT account details of nominee not submitted"),
	QUERY_7(7, "Title to claim money not clear"),
	QUERY_8(8, "NEFT Rejected");

	private Integer id;
	private String value;

	private QueriedClaimEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static QueriedClaimEnum fromId(Integer v) {
		for (QueriedClaimEnum c : QueriedClaimEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static QueriedClaimEnum[] getAll() {
		return QueriedClaimEnum.values();
	}
}
