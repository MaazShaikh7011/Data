package com.opl.jns.ere.enums;

/**
 * THIS ENUM IS USED TO UPDATE ENROLLMENT AND CLAIM PUSH STATUS TO THE INTERNAL, BANKS AND
 * INSURER (TABLE: ApplicationPushStatusV2)
 * 
 * @author maulik.panchal
 * @date 07-June-2024
 */
public enum EnrollAndClaimPushType {

	MASTER_PUSH(1, "Enrollment Master Push"),
	ENROLL_BANK_PUSH(2, "Enrollment Bank Push"),
	ENROLL_INSURER_PUSH(3, "Enrollment Insurer Push"),
	BANK_OPT_OUT_PUSH(4, "Bank OPT OUT Push"),
	INSURER_OPT_OUT_PUSH(5, "Insurer OPT OUT Push"),
	BANK_NMN_DTLS_PUSH(6, "Bank Nominee Details Push"),
	INSURER_NMN_DTLS_PUSH(7, "Insurer Nominee Details Push"),
	CLAIM_BANK_PUSH(8, "Claim Bank Push"),
	CLAIM_INSURER_PUSH(9, "Claim Insurer Push"),
	CLAIM_BANK_STATUS_PUSH(10, "Bank Claim Status Push"),
	CLAIM_INSURER_STATUS_PUSH(11, "Insurer Claim Status Push");

	private Integer id;
	private String value;

	private EnrollAndClaimPushType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EnrollAndClaimPushType fromId(Integer id) {
		for (EnrollAndClaimPushType c : EnrollAndClaimPushType.values()) {
			if (c.id.equals(id)) {
				return c;
			}
		}
		throw new IllegalArgumentException(id != null ? id.toString() : null);
	}

	public static EnrollAndClaimPushType[] getAll() {
		return EnrollAndClaimPushType.values();
	}
}
