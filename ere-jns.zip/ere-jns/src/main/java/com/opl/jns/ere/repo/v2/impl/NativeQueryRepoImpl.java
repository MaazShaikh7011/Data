package com.opl.jns.ere.repo.v2.impl;

import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.*;
import java.io.IOException;
import java.util.Objects;

@Slf4j
@Transactional
@Component("NativeQueryRepoImpl")
public class NativeQueryRepoImpl {

    @PersistenceContext
    private EntityManager entityManager;


    public String getUrn(Long orgId, String cif, Integer schemeId) {
        try {

            String QUERY = """
                     select p.urn from $SCHEME p \
                     inner join jns_master.applicant_pi_details api on api.id=p.id and api.cif=jns_users."encvalue"('$cif') \
                     where p.org_id=$orgId and p.status=2 and p.is_active=1 and p.source != 3\
                    """;
            String SCHEME = "";
            if(schemeId == SchemeMaster.PMJJBY.getId().intValue()) {
                SCHEME = "jns_master.pmjjby";
            } else {
                SCHEME = "jns_master.pmsby";
            }
            QUERY = QUERY.replace("$SCHEME", SCHEME);
            QUERY = QUERY.replace("$orgId", orgId.toString());
            QUERY = QUERY.replace("$cif", cif);
            Object singleResult = entityManager.createNativeQuery(QUERY).getSingleResult();
            if(!OPLUtils.isObjectNullOrEmpty(singleResult)) {
                return String.valueOf(singleResult);
            }
        } catch (Exception e) {
            log.error("NoResultException | IOException for ORG --> {}, schemeId --> {}, CIF --> {} ----- {}", orgId,schemeId,cif, e.getMessage());
        }
        return null;
    }
    public static void main(String[] args) {
		System.out.println(  (Objects.equals(2, SchemeMaster.PMJJBY.getId())));
	}
}


