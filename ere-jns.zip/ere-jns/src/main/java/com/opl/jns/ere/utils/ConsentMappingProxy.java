package com.opl.jns.ere.utils;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class ConsentMappingProxy {
	private Long id;
	private Long consentId;
	private Date consentDate;
	private Long appTypeValue;
	private Integer appType;
	private Long userId;
	private Integer consentTypeId;
}
