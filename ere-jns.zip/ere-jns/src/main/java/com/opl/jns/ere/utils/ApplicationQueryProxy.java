package com.opl.jns.ere.utils;

import java.util.Date;

public class ApplicationQueryProxy {

	
	/**
	 * DO NOT MOVE CLASS ANYWHERE IF YOU NEED TO MOVE CLASS THAN UPDATE PATH ON AppMaster Repo
	 */

	/* Master */
	private Long applicationId;
	private Integer schemeId;
	private String schemeName;
	private Long orgId;
	private String accountNumber;
	private Date dob;
	private String urn;
	private Integer stageId;
	private Integer applicationStatus;

	/* applicantInfo */
	private String firstName;
	private String middleName;
	private String lastName;
	private String name;

	/* applicationMasterOtherDetails */
	private Integer source;

	/**
	 * DO NOT REMOVE THIS CONSTRUCTOR DUE TO USE IN QUERY
	 * 
	 * fetchAccountNoSchemeIdOrgIdByAppId
	 * 
	 * new com.opl.jns.ere.utils.ApplicationQueryProxy(accountNumber,schemeId,orgId)
	 * 
	 * @param schemeId
	 * @param orgId
	 * @param customerAccountNumber
	 */
	public ApplicationQueryProxy(String accountNumber, Integer schemeId, Long orgId) {
		this.accountNumber = accountNumber;
		this.schemeId = schemeId;
		this.orgId = orgId;
	}

	/**
	 * DO NOT REMOVE THIS CONSTRUCTOR DUE TO USE IN QUERY
	 * 
	 * fetchAccountNumberApplicantInfoFirstNameMiddleNameLastNameSchemeIdApplicationMasterOtherDetailsSourceById
	 * 
	 * new com.opl.jns.ere.utils.ApplicationQueryProxy(schemeId,accountNumber,applicantInfo.firstName,applicantInfo.middleName,applicantInfo.lastName,applicationMasterOtherDetails.source)
	 * 
	 * @param applicationId
	 * @param schemeId
	 * @param accountNumber
	 * @param firstName
	 * @param middleName
	 * @param lastName
	 * @param source
	 */

	public ApplicationQueryProxy(Integer schemeId, String accountNumber, String firstName, String middleName, String lastName, Integer source) {
		this.schemeId = schemeId;
		this.accountNumber = accountNumber;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.source = source;
	}

	// AccountNumber,Dob,OrgId,Urn,StageId

	/**
	 * DO NOT REMOVE THIS CONSTRUCTOR DUE TO USE IN QUERY
	 * 
	 * fetchVerifyApiDetailsById
	 * 
	 * new com.opl.jns.ere.utils.ApplicationQueryProxy(orgId,accountNumber,dob,urn,stageId)
	 * 
	 * @param orgId
	 * @param accountNumber
	 * @param dob
	 * @param urn
	 * @param stageId
	 */
	public ApplicationQueryProxy(Long orgId, String accountNumber, Date dob, String urn, Integer stageId, Integer schemeId) {
		this.orgId = orgId;
		this.accountNumber = accountNumber;
		this.dob = dob;
		this.urn = urn;
		this.stageId = stageId;
		this.schemeId = schemeId;
	}
	
	
	/**
	 * DO NOT REMOVE THIS CONSTRUCTOR DUE TO USE IN QUERY
	 * 
	 * fetchEnromentValidateByOrgIdAndSchemeIdAndIsActiveTrueAndCifAndApplicationStatusIn
	 * 
	 * new com.opl.jns.ere.utils.ApplicationQueryProxy(orgId,urn,applicationStatus)
	 * 
	 * @param orgId
	 * @param urn
	 */
	public ApplicationQueryProxy(Long orgId, String urn, Integer applicationStatus) {
		this.orgId = orgId;
		this.urn = urn;
		this.applicationStatus = applicationStatus;
	}
	public ApplicationQueryProxy(Long applicationId, Long orgId, String urn, Integer applicationStatus) {
		this.applicationId = applicationId;
		this.orgId = orgId;
		this.urn = urn;
		this.applicationStatus = applicationStatus;
	}
	
	/**
	 * DO NOT REMOVE THIS CONSTRUCTOR DUE TO USE IN QUERY
	 * 
	 * findAllByIsActiveTrueAndUserIdAndStageIdIn
	 * 
	 * new com.opl.jns.ere.utils.ApplicationQueryProxy(applicationId,schemeId,name)
	 * 
	 * @param orgId
	 * @param urn
	 */
	public ApplicationQueryProxy(Long applicationId, Integer schemeId, String name, Integer stageId) {
		this.applicationId = applicationId;
		this.schemeId = schemeId;
		this.name = name;
		this.stageId = stageId;
	}

	public ApplicationQueryProxy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Integer getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(Integer schemeId) {
		this.schemeId = schemeId;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getSource() {
		return source;
	}

	public void setSource(Integer source) {
		this.source = source;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getUrn() {
		return urn;
	}

	public void setUrn(String urn) {
		this.urn = urn;
	}

	public Integer getStageId() {
		return stageId;
	}

	public void setStageId(Integer stageId) {
		this.stageId = stageId;
	}

	public Integer getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(Integer applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
