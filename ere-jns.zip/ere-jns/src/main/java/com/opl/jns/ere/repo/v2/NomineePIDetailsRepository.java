package com.opl.jns.ere.repo.v2;

import com.opl.jns.ere.domain.v2.*;
import org.springframework.data.jpa.repository.*;


/**
 * @author Krunal Prajapati
 * Date : 19-01-2024
 */

public interface NomineePIDetailsRepository extends JpaRepository<NomineePIDetails, Long> {

}
