package com.opl.jns.ere.domain;

import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author Maaz Shaikh
 * Date : 04-08-2023
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "webhook_master",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {

})
public class WebhookMaster {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "webhook_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "webhook_master_seq_gen", sequenceName = "webhook_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "value", nullable = true)
	private String value;

}
