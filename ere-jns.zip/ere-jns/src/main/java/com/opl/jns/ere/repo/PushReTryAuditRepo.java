package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.*;
import org.springframework.data.jpa.repository.*;

import java.util.*;

/***
 *
 * @author Maaz Shaikh
 * Date : 12-05-2023
 */

public interface PushReTryAuditRepo extends JpaRepository<PushReTryAudit, Long> {

    List<PushReTryAudit> findByTypeAndIsPushedFalse(Integer type);
    List<PushReTryAudit> findByIsPushedFalseAndReTryCountLessThanEqual(int count);
    PushReTryAudit findFirstByTypeAndIsPushedFalseAndApplicationId(Integer type, Long applicationId);
    PushReTryAudit findByTypeAndIsPushedFalseAndClaimId(Integer type, Long claimId);
    PushReTryAudit findFirstByTypeAndIsPushedFalseAndClaimIdOrderByIdDesc(Integer type, Long claimId);
}
