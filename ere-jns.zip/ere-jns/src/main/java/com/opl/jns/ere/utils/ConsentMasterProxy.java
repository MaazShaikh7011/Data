package com.opl.jns.ere.utils;

import java.util.Date;

import lombok.Data;

@Data
public class ConsentMasterProxy {

	private Long id;
	private String consent;
	private Long version;
	private Boolean isActive;
	private Date createdDate;
	private String lang;
	private String type;
	private Integer typeId;
	private Boolean currentActive;

}
