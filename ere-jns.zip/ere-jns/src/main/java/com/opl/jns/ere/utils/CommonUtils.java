package com.opl.jns.ere.utils;

import java.sql.SQLNonTransientConnectionException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import org.springframework.dao.DataAccessResourceFailureException;

import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.EnrollStageMaster;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtils {

	public static final String COVER_END_DATE = "COVER_END_DATE";

	public static final DateFormat sdf_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
	public static final SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	public static final SimpleDateFormat sdf_yyyy_mm_dd__HH_mm=new SimpleDateFormat("yyyy-MM-dd HH:mm");
	public static final DateFormat sdf_yyyy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS");
	public static final DateFormat sdf_dd_MM_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss");
	public static final DateFormat sdf_dd_MM_yyyy_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final DateFormat HH_mm_ss = new SimpleDateFormat("HH:mm:ss");
	private static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";


	public static final String JNS_APP_CODE_INITIAL = "JNS_APP_CODE_INITIAL";
	public static final String CHAR_DASH = "-";
	public static final int INT_0 = 0;
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;
	public static final int INT_3 = 3;
	public static final int INT_4 = 4;
	public static final int INT_5 = 5;
	public static final int INT_6 = 6;
	public static final int INT_7 = 7;
	public static final int INT_8 = 8;
	
	public static final int FIRST__QUATER = INT_5;
	public static final int SECOND__QUATER = INT_6;
	public static final int THIRD__QUATER = INT_7;
	public static final int FOURTH__QUATER = INT_8;
	
	public static final int TYPE_NOMINEE = INT_1;
	public static final int TYPE_OTHER_CLAIMENT = INT_2;
	public static final int TYPE_GUARDIAN= INT_3;

	public static final String APPLICATION_ID = "applicationId";
	public static final String PRODUCT_DOCUMENT_MAPPING_ID = "productDocumentMappingId";
	public static final String USER_TYPE = "userType";
	public static final String ORIGINAL_FILE_NAME = "originalFileName";
	public static final long PRODUCT_DOCUMENT_ID = 68L;

	public static final int PUSH_RE_TRY_APPLICATION = INT_1;
	public static final int PUSH_RE_TRY_CLAIM = INT_2;
	public static final long LONG_0 = 0l;
	public static final long LONG_1 = 1l;
	public static final long LONG_2 = 2l;

	public static final int ENROLLMENT_VERIFICATION_OTP  = 1; 
	public static final int ENROLLMENT_VERIFICATION_PHYSICAL = 2;
	
	public static final Integer TYPE_ENROLLMENT = 1;	
	public static final int TYPE_RENEWAL = 2;

	private static final Integer APPLICATION_STATUS = 2;
    public static final String STR_YES = "Yes";
	public static final String STR_NO = "No";
    public static final String STR_Y = "Y";
	public static final String STR_N = "N";
    public static final String MOBILE_NUMBER = "mobileNumber";
	public static final String MESSAGE = "message";
	public static final String RESEND_OTP_TIME = "resendOTPTime";
	public static final String USER_ORG_ID = "userOrgId";
	public static final String ORGANISATION_NAME = "organisationName";
	public static final int INT_200 = 200;
	public static final String PREMIUM_DEDUCTED_SUCCESSFULLY ="Premium deducted successfully";
	public static final String UNABLE_TO_DEDUCT_PREMIUM_DUE_TO_ERROR_FROM_BANK ="Unable to deduct premium due to error from bank";
	public static final String UNABLE_TO_DEDUCT_PREMIUM_DUE_TO_SYSTEM_ISSUE ="Unable to deduct premium due to system issue";
	public static final String ENROLLMENT_INITIATED_MSG = "Enrollement already initiated, go to Save application and proceed.";
	public static final String AGE_CRITERIA_SINGLE="As per bank records, you have exceeded the age criteria for the selected scheme. You will not be able to proceed here.";
	public static final String AGE_CRITERIA_MULTI="As per bank records, you have exceeded the age criteria for the selected scheme. Do you wish to select for any other A/C holder";
	public static final String DOB_ERROR="Date of Birth of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed";
	public static final String FIRSTNAME_ERROR="First Name of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed";
	public static final String CUSTOMER_DETAIL_ERROR1="Required details are missing";
	public static final String CUSTOMER_ALREADY_ENROLLED_ERROR="Customer is already enrolled with Scheme";
	public static final String CUSTOMER_ERROR="of the selected A/C holder is not found in the Bank CBS. Please check in Bank CBS records and then proceed here.";
	public static final String FATHER_OR_HUSBAND_NAME_ERROR="Father/Husband's Name of the selected A/C holder is not found in the Bank CBS. Please update Bank CBS records to proceed";
	public static final String RURAL_SEMIURBAN_ERROR="Rural/Urban/SemiUrban/Metro classification is required for the selected A/C holder.";
	public static final String CONSENT_FOR_AUTO_DEBIT_ERROR="Consent for Autodebit is mandatory for enrollment.";
	public static final String CUSTOMER_DETAIL_ERROR2="Please update CBS records to proceed. ";
	public static final String ALREADY_ENROLLMENT_INPROCESS="Already Enrollment Inprocess.";
	public static final String DE_DUPE_EXCEPTION_MSG = "It seems an error occured in De-dupe response; please try again later.";
	public static final String CLAIM_DUPE_EXCEPTION_MSG = "It seems an error occured in claim De-dupe response; please try again later.";
	public static final String UPDATE_CLAIM_EXCEPTION_MSG = "It seems an error occured in update claim response; please try again later.";
	public static final String CITY ="City";
	public static final String DISTRICT ="District";
	public static final String STATE ="State";
	public static final String PINCODE ="Pincode";
	public static final String AADHAR ="Aadhar";
	public static final String ANNUAL_RENEWAL_DATE = "ANNUAL_RENEWAL_DATE";
	public static final String PMJJBY_SUM_ASSURED = "PMJJBY_SUM_ASSURED";
	public static final String PMJJBY_LIEN_PERIOD = "PMJJBY_LIEN_PERIOD";
	public static final Long ORG_TYPE_INSURER = 3L;
    public static final Long ORG_TYPE_BANK = 1L;

	/** Response messages*/

	public static final String APPLICATION_ALREADY_IN_PROGRESS_ON_GIVEN_CUSTOMER_ID = "application already in-progress on given customerId";
	public static final String APPLICATION_CREATED = "application Created!!!";
	public static final String IS_DEDUP_ON = "IS_DEDUP_ON";
	public static final String SKIP_ALL_TESTING_AND_DE_DUPE_MODE = "SKIP_ALL_TESTING_AND_DE_DUPE_MODE";
	public static final String TESTING_MODE_ON_OFF = "TESTING_MODE_ON_OFF";

	public static final Integer[] CompletedStage = new Integer[]{EnrollStageMaster.COMPLETED.getStageId()};
	public static final Integer[] CompletedStageWithClaim = new Integer[]{EnrollStageMaster.COMPLETED.getStageId(),EnrollStageMaster.EXPIRED.getStageId(),EnrollStageMaster.REJECTED.getStageId(),14};
	public static final Integer[] stageThatNotIncludeInApplicationCreation = new Integer[]{EnrollStageMaster.COMPLETED.getStageId(),EnrollStageMaster.EXPIRED.getStageId(),EnrollStageMaster.REJECTED.getStageId()};;


	//Claim Search Type
	public static final Integer CLAIM_ACCOUNT_NO = 1;
	public static final Integer CLAIM_URN = 2;
	public static final String CLAIM_INITIATED_MSG = "Claim has already been initiated for the selected Account Holder";
	public static final String CLAIM_ALREADY_COMPLETE_MSG = "Claim has already complete for the selected holder !!";
	public static final String CLAIM_ALREADY_PAID_MSG = "Claim has already been paid for the selected A/C holder !!";
	public static final String CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_ALREADY_REJETED_DEATH_MSG = "Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_SUM_INSURED_EXHUSTED_MSG = "Sum Insured has been exhausted for the selected A/C holder.";
	public static final String CLAIM_SUBMISSION_IN_PROGRESS_MSG = "Kindly complete the claim application that is pending for submission and then proceed here.";
	public static final String CLAIM_DEATH_MSG = "Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_DEATH_PAID_MSG = "Death Claim has already been paid for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_MSG = "Accidental Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_PAID_MSG = "Accidental Death Claim has already been paid for the selected A/C holder";
	public static final String DEATH = "Death";
	public static final String TOTAL_DISABILITY = "Total Disability";
	public static final String PMSBY_TOTAL_CLAIM_AMOUNT = "PMSBY_TOTAL_CLAIM_AMOUNT";
	public static final String PROCEED = "Proceed";	
	public static final int NATURE_OF_LOSS_DISABLITY = 2;
	public static final int TYPE_OF_DISABLITY_ID = 1;
	public static final String APPROVED_CLAIM_AMOUNT_NOT_VALIDATE_MSG = "Amount of transaction is must be less then";
	public static final int PREMIUM_DEDUCTION_FAILED_STAGE = 15;
	public static final String STR_TRUE = "true";
	public static final String PUBLISHED_REQ_AUTH = "ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo";
	public static final String IS_DECRYPT = "isDecrypt";
	public static final String ACCEPT_HEADER_PUBLISHED = "Accept";
	public static final String FIELD_MISSING = "Invalid or incomplete data fetched from CBS. To proceed, please update CBS.";

	public static final String DATA_NOT_FOUND = "data not found";

    public static final String BULK = "Bulk";
	public static final String TEST = "Test";

	public static final String PMSBY_SAMPLE="{\"urn\":\"JSN-5454546545\",\"schemeId\":1,\"schemeName\":\"PMSBY\",\"customerAccountNumber\":\"755454545\",\"orgId\":1,\"orgName\":\"Union BANK\",\"userId\":123123,\"branchId\":40,\"branchName\":\"C G Road\",\"branchRoId\":25,\"branchZoId\":26,\"stageId\":6,\"typeOfVerification\":2,\"isPushed\":true,\"applicationStatus\":2,\"createdBy\":65326,\"modifiedBy\":664598,\"isActive\":true,\"customerDetails\":{\"cif\":\"30228825114\",\"customerAccountNumber\":\"755454545\",\"customerIfsc\":\"UBIN0559556\",\"name\":\"Ravi-\",\"isPMJJBYExists\":false,\"isPMSBYExists\":false,\"isKYCUpdate\":false,\"dob\":\"1994-06-19\",\"gender\":1,\"genderName\":\"Male\",\"firstName\":\"Ravi\",\"middleName\":\" \",\"lastName\":\"Thummer\",\"mobileNumber\":\"9722232445\",\"emailAddress\":\"ravi@opl.com\",\"kycId1\":\"AADHAR\",\"kycId1Number\":\"65986326565\",\"kycId2\":\"PAN\",\"kycId2Number\":\"EPHPS8545L\",\"pan\":\"EPHPS8545L\",\"aadhaarNumber\":\"65986326565\",\"address\":{\"addressLine1\":\"7, Vishnupark Society\",\"addressLine2\":\"Near Madhav Mall\",\"district\":\"Ahmedabad\",\"districtLgdCode\":123,\"city\":\"Ahmedabad\",\"cityLgdCode\":12,\"cityId\":65465,\"state\":\"Gujarat\",\"stateLgdCode\":122,\"stateId\":5656,\"pincode\":380021}},\"lastTransactionDetails\":{\"insurerMasterId\":46849562222,\"insurerName\":\"UIIC\",\"insurerOrgId\":188,\"masterPolicyNo\":\"987654321\",\"insurerAccountNumber\":\"12345678\",\"insurerIfsc\":\"UBIN0559556\",\"transactionUtr\":\"69865465456654\",\"transactionAmount\":114,\"transactionTimeStamp\":\"2023-05-11 12:05:00\"}}";
	public static final String PMJJBY_SAMPLE="{\"urn\":\"JSN-5454546545\",\"schemeId\":2,\"schemeName\":\"PMJJBY\",\"customerAccountNumber\":\"755454545\",\"orgId\":1,\"orgName\":\"Union bank\",\"userId\":123123,\"branchId\":40,\"branchName\":\"C G Road\",\"stageId\":6,\"branchRoId\":25,\"branchZoId\":26,\"typeOfVerification\":2,\"isPushed\":true,\"applicationStatus\":2,\"createdBy\":65326,\"modifiedBy\":664598,\"isActive\":true,\"customerDetails\":{\"cif\":\"30228825114\",\"customerAccountNumber\":\"755454545\",\"customerIfsc\":\"UBIN0559556\",\"name\":\"Ravi-\",\"isPMJJBYExists\":false,\"isPMSBYExists\":false,\"isKYCUpdate\":false,\"dob\":\"1994-06-19\",\"gender\":1,\"genderName\":\"Male\",\"firstName\":\"Ravi\",\"middleName\":\" \",\"lastName\":\"Thummer\",\"mobileNumber\":\"9722232445\",\"emailAddress\":\"ravi@opl.com\",\"kycId1\":\"AADHAR\",\"kycId1Number\":\"65986326565\",\"kycId2\":\"PAN\",\"kycId2Number\":\"EPHPS8545L\",\"pan\":\"EPHPS8545L\",\"aadhaarNumber\":\"65986326565\",\"address\":{\"addressLine1\":\"7, Vishnupark Society\",\"addressLine2\":\"Near Madhav Mall\",\"district\":\"Ahmedabad\",\"districtLgdCode\":123,\"city\":\"Ahmedabad\",\"cityLgdCode\":12,\"cityId\":65465,\"state\":\"Gujarat\",\"stateLgdCode\":122,\"stateId\":5656,\"pincode\":380021}},\"lastTransactionDetails\":{\"insurerMasterId\":46849562222,\"insurerName\":\"SUDI\",\"insurerOrgId\":210,\"masterPolicyNo\":\"987654321\",\"insurerAccountNumber\":\"12345678\",\"insurerIfsc\":\"UBIN0559556\",\"transactionUtr\":\"69865465456654\",\"transactionAmount\":436,\"transactionTimeStamp\":\"2023-05-11 12:05:00\"}}";
	
	public static final String POLICY_START_DATE = "policyStartDate";
	public static final String POLICY_END_DATE = "policyEndDate";
	public static final String FINANCIAL_START_DATE = "financialStartDate";
	public static final String FINANCIAL_END_DATE = "financialEndDate";
	
	// PATTERN
	public static final String PAN_PATTERN = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
	public static final String AADHAR_PATTERN = "^[0-9]{12}$";
	public static final String PASSPORT_PATTERN = "^[a-zA-Z]{1}[0-9]{6,9}$";
	public static final String VOTERS_ID_CARD_PATTERN = "^[A-Z]{3}\\d{7}$";
	public static final String DRIVING_LICENCE_PATTERN = "^(([A-Z]{2}[0-9]{2})(-| |)|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$";
	public static final String MGNREGA_CARD_PATTERN = "[A-Z]{2}-[0-9]{1,4}-[0-9]{1,4}-[0-9]{1,4}-[0-9]{1,8}\\/[0-9]{1,8}";
	public static final String IFSC_PATTERN = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$";
	public static final int SCHEME_ID_PMJJBY = 2;
	public static final int SCHEME_ID_PMSBY = 1;
	public static final String INSERTING_COUNT = "inserting count : ";
	public static final long SUDI_LIFE_INSURER_ORG_ID = 210L;
	public static final long NEW_INDIA_ASSURANCEINSURER_ORG_ID = 236L;
	public static final long CANARA_HSBC_LIFE_INSURER_ORG_ID = 196L;
	public static final long LIC_INSURER_ORG_ID = 189L;
	public static final long HDFC_ERGO_INSURER_ORG_ID = 219L;
	public static final long HDFC_LIFE_INSURER_ORG_ID = 199L;
	public static final long ICIC_LOMBARD_INSURER_ORG_ID = 220L;
	public static final long ICIC_PRODENTIAL_INSURER_ORG_ID = 200L;
	public static final long UIIC_INSURER_ORG_ID = 188L;
	public static final long UNIVERSAL_SOMPO_INSURER_ORG_ID = 238L;
	public static final long SBI_LIFE_INSURER_ORG_ID = 208L;
	public static final long FUTURE_GENRALI_INSURER_ORG_ID = 217L;
	public static final long THE_ORIENTAL_INSURER_ORG_ID = 237L;
	
	public static final Long SBI_BANK_ID = 16l;

	public static boolean isDBConnectionError(Object e){
        return (e instanceof SQLNonTransientConnectionException || e instanceof DataAccessResourceFailureException);
    }
    
	public static boolean isObjectNull(Object value) {
		return (value == null
				|| (value instanceof String s
						? (s.isEmpty() || "".equalsIgnoreCase(s.trim()) || "null".equalsIgnoreCase(value.toString())
								|| "undefined".equals(value))
						: false));
	}
	

	private static String concateString(String msg,String concateStr) {
		if(!OPLUtils.isObjectNullOrEmpty(msg)) {
			msg+=", "+concateStr;	
		}else {
			msg=concateStr;
		}
		return msg; 
	}
	public static int getAgeBydob(Date date) {
		if(!OPLUtils.isObjectNullOrEmpty(date)) {
			LocalDate currentDate = LocalDate.now();
			LocalDate birthDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			if ((birthDate != null) && (currentDate != null)) {
				return Period.between(birthDate, currentDate).getYears();
			}
		}
		return 0;
	}
	
	public static int getCurrentPolicyYear() {
		int month=(YearMonth.now().getMonthValue());
		int s =Year.now().getValue();
		if(month <= 5) {
			s = s - 1;
		}
		return s;
	}
	
	public static int getPolicyYear() {
		int month=(YearMonth.now().getMonthValue());
		int s =Year.now().getValue();
		if(month > 5) {
			s = s + 1;
		}
		return s;
	}
	
	public static String getPolicyYearToYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue();
		int nextYear=current;
		if(month > 5) {
			nextYear = current + 1;
		}else {
			current =current - 1;
		}
		return (current%100)+CommonUtils.CHAR_DASH+(nextYear%100);
	}
	public static int getPolicyNextStartYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue()+1;		
		if(month <= 6) {		
			current =current - 1;
		}
		return current;
	}
	public static int getPolicyNextEndYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue()+1;
		int nextYear=current;
		if(month > 6) {
			nextYear = current + 1;
		}
		return nextYear;
	}
	
	public static int getFinancialEndYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue();		
		if(month > 3) {		
			current =current + 1;
		}
		return current;
	}
	public static int getPolicyEndYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue();
		int nextYear=current;
		if(month > 5) {
			nextYear = current + 1;
		}
		return nextYear;
	}
    public static <T> T checkStringAndCast(String value, Class<T> type) throws ParseException{
        if(!OPLUtils.isObjectNullOrEmpty(value) && !value.equalsIgnoreCase("na") && !value.equals("-") && !value.equals("|") && !value.equals("0")){
			if(type.equals(Date.class)) {
				return (T) DateUtils.getUtilsDateFromStringDate(value);
			}else {
				return type.cast(value);
			}
        }
        return null;
    }

	public static <T>T handleNull(Object value,Class<T> type){
		if(!OPLUtils.isObjectNullOrEmpty(value)){
			return type.cast(value);
		}
		return null;
	}

	public static String handledNullForString(String value){
		if(!OPLUtils.isObjectNullOrEmpty(value)){
			return value;
		}
		return null;
	}

	public static Date parseDateFromString(String date) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(date)) {
				sdf.parse(sdf.format(date));
			}
		} catch (ParseException e) {
			log.info("Exception in parsing date : ", e);
		}
		return null;
	}
	public static String formatDate_sdf(Date date) {
		if (!OPLUtils.isObjectNullOrEmpty(date)) {
			return sdf.format(date);
		}
		return null;
	}
	public static String formatDate_sdf_dd_mm_yyyy(Date date) {
		if (!OPLUtils.isObjectNullOrEmpty(date)) {
			return sdf_dd_MM_yyyy.format(date);
		}
		return null;
	}

	public static String formatDate__sdf_yyyy_mm_dd__HH_mm(Date date) {
		if (!OPLUtils.isObjectNullOrEmpty(date)) {
			 return sdf_yyyy_mm_dd__HH_mm.format(date);
		}
		return null;
	}
	public static Date parseDateFromString_sdf_dd_MM_yyyy(String date) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(date)) {
				sdf_dd_MM_yyyy.parse(date);
			}
		} catch (ParseException e) {
			log.info("Exception in parsing date : ", e);
		}
		return null;
	}
	public static Date parseDateFromString_sdf_yyyy_MM_dd_T_HH_mm_ss_SS(String date) {
		try {
			if (!OPLUtils.isObjectNullOrEmpty(date)) {
				sdf_yyyy_MM_dd_T_HH_mm_ss_SS.parse(date);
			}
		} catch (ParseException e) {
			log.info("Exception in parsing date : ", e);
		}
		return null;
	}
	
	public static String formatDate_sdf_yyyy_MM_dd_HH_mm_ss(Date date) {
		if (!OPLUtils.isObjectNullOrEmpty(date)) {
			 return sdf_yyyy_MM_dd_HH_mm_ss.format(date);
		}
		return null;
	}
	
	

	
	public static StringBuffer convert_to_words(char[] num) {
		StringBuffer fullWord = new StringBuffer();
		int len = num.length;

		// Base cases
		if (len == 0) {
			fullWord.append("empty string");
			return fullWord;
		}
		if (len > 4) {
			fullWord.append("Length more than 4 is not supported");
			return fullWord;
		}
		
		fullWord.append("Rupees ");

		String[] single_digits = new String[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
				"nine" };

		String[] two_digits = new String[] { "", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
				"sixteen", "seventeen", "eighteen", "nineteen" };

		String[] tens_multiple = new String[] { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
				"eighty", "ninety" };

		String[] tens_power = new String[] { "hundred", "thousand" };

		if (len == 1) {
			fullWord.append(single_digits[num[0] - '0']);
		}

		int x = 0;
		while (x < num.length) {
			if (len >= 3) {
				if (num[x] - '0' != 0) {
					fullWord.append(single_digits[num[x] - '0'] + " ");
					fullWord.append(tens_power[len - 3] + " ");
				}
				--len;
			}

			else {

				if (num[x] - '0' == 1) {
					int sum = num[x] - '0' + num[x + 1] - '0';
					fullWord.append(two_digits[sum]);
				}

				else if (num[x] - '0' == 2 && num[x + 1] - '0' == 0) {
					fullWord.append("twenty");
				}

				else {
					int i = (num[x] - '0');
					if (i > 0) {
						fullWord.append(tens_multiple[i] + " ");
					} else {
						fullWord.append("");
					}
					++x;
					if (num[x] - '0' != 0)
					fullWord.append(single_digits[num[x] - '0']);
				}
			}
			++x;
		}
		return fullWord;
	}
	
	public static String locaDateTimeToString(LocalDateTime localDateTime) {
		if(!OPLUtils.isObjectNullOrEmpty(localDateTime)) {			
			return DateTimeFormatter.ofPattern(DATE_TIME_PATTERN, Locale.GERMANY).format(localDateTime);
		}
		return null;
	}

//public static void main(String[] args) {
//	int year = 50;
//	int month = 5;
//	int day = 30;
//	
//	if(year < 50) {
//		System.out.println("success");
//	}else if(year == 50) {
//		if(month <= 5) {
//			if(day <= 29) {
//				System.out.println("success");
//			}
//		}
//	}
//}


	public static final long NATIONAL_INSURER_ORG_ID = 226L;
	public static final long INDIA_FIRST_LIFE_INSURER_ORG_ID = 201L;
}
