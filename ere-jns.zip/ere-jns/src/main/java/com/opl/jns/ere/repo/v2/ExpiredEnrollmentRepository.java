package com.opl.jns.ere.repo.v2;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.ere.domain.v2.ExpiredEnrollment;

/**
 * @author :- Ravi Thummar
 */

public interface ExpiredEnrollmentRepository extends JpaRepository<ExpiredEnrollment, Long> {
	
	ExpiredEnrollment findByUrnAndIsActiveTrue(String urn);
	
	ExpiredEnrollment findByIdAndIsActiveTrue(Long applicationId);
	
	Long countByCreatedByAndIsActiveTrueAndStatusIn(Long userId,List<Integer> applicationStatus);
	
	List<ExpiredEnrollment> findByCreatedByAndIsActiveTrue(Long userId);
	
	@Query("select am from ExpiredEnrollment am WHERE am.isActive=true and am.createdBy =:userId and am.status in (:applicationStatus) order by id desc")
	public List<ExpiredEnrollment> findAllByIsActiveTrueAndUserIdAndStatusIn(@Param("userId") Long userId,@Param("applicationStatus") List<Integer> applicationStatus,Pageable pageble);

}
