package com.opl.jns.ere.enums;

public enum PMJJBYRejectedClaimEnum {

	REASON_1(1, "Complete claim documents not submitted by claimants"),
	REASON_2(2, "Death during lien period"),
	REASON_3(3, "Death not established by documents submitted"),
	REASON_4(4, "Others");
	
	private Integer id;
	private String value;

	private PMJJBYRejectedClaimEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static PMJJBYRejectedClaimEnum fromId(Integer v) {
		for (PMJJBYRejectedClaimEnum c : PMJJBYRejectedClaimEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PMJJBYRejectedClaimEnum[] getAll() {
		return PMJJBYRejectedClaimEnum.values();
	}
}
