package com.opl.jns.ere.enums;

public enum NomineeType {

	NOMINEE(1, "Nominee"), CLAIMANT(2, "Claimant"), GUARDIAN(3, "Gaurdian");

	private Integer id;
	private String value;

	private NomineeType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static NomineeType fromId(Integer v) {
		for (NomineeType c : NomineeType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static NomineeType[] getAll() {
		return NomineeType.values();
	}
}
