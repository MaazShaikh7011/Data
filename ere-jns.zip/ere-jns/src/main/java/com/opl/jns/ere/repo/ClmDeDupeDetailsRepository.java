package com.opl.jns.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ClmDeDupeDetails;

public interface ClmDeDupeDetailsRepository extends JpaRepository<ClmDeDupeDetails, Long> {

	ClmDeDupeDetails findByClaimMasterIdAndIsActiveTrue(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE ClmDeDupeDetails SET isActive=false, modifiedDate = CURRENT_TIMESTAMP, modifiedBy = :userId WHERE claimMaster.id =:claimId AND isActive=true")
    Integer isActiveFalseByClaimId(@Param("claimId") Long claimId, @Param("userId") Long userId);

}
