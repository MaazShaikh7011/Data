package com.opl.jns.ere.utils;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DedupeDataResponse {

	@JsonProperty("CLAIM_ID")
	private Long claimId;

	@JsonProperty("URN")
	private String urn;

	@JsonProperty("CLAIM_INTIMATION_DATE")
	private Date claimInimationDate;

	@JsonProperty("TYPE")
	private String type;
	
	@JsonProperty("DATE_OF_LOSS")
	private String dateOfLoss;

	@JsonProperty("BENEFICIARY_BANK")
	private String beneficiaryBank;
	
	@JsonProperty("STAGE_ID")
	private Integer stageId;
	
	@JsonProperty("STATUS")
	private Integer status;
	
	@JsonProperty("INSURER_ORG_ID")
	private Integer insurerOrgId;
	
	@JsonProperty("ORG_ID")
	private Integer orgId;
	
	@JsonProperty("IS_ACTIVE")
	private Boolean isActive;
}
