package com.opl.jns.ere.enums;

public enum RuralUrbanEnum {
	RURAL(1, "Rural"),
	URBAN(2, "Urban");

	private Integer id;
	private String value;

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	private RuralUrbanEnum(Integer id,String value) {
		this.id = id;
		this.value=value;
	}

	public static RuralUrbanEnum fromId(Integer v) {
		for (RuralUrbanEnum c : RuralUrbanEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static RuralUrbanEnum[] getAll() {
		return RuralUrbanEnum.values();
	}
	
	public static RuralUrbanEnum fromValue(String v) {
		for (RuralUrbanEnum c : RuralUrbanEnum.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v : null);
	}
}
