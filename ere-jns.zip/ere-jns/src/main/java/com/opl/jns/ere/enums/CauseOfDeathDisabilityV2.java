package com.opl.jns.ere.enums;

import com.opl.jns.utils.enums.*;

public enum CauseOfDeathDisabilityV2 {

	ACCIDENTAL_30_DAYS(1, "Accidental death within 30 days of lien period",SchemeMaster.PMJJBY.getId()),
	NATURAL_DEATH_NON_ACCIDENTAL(2, "Natural Death/Non Accidental",SchemeMaster.ALL_SCHEME.getId()),
	ACCIDENTAL(3, "Accidental",SchemeMaster.PMSBY.getId()),
	SUICIDE(4, "Suicide",SchemeMaster.ALL_SCHEME.getId());

    private Integer id;
    private String value;

    private Long schemeId;

    private CauseOfDeathDisabilityV2(Integer id, String value,Long schemeId) {
        this.id = id;
        this.value = value;
        this.schemeId = schemeId;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static CauseOfDeathDisabilityV2 fromId(Integer v) {
        for (CauseOfDeathDisabilityV2 c : CauseOfDeathDisabilityV2.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static CauseOfDeathDisabilityV2 fromBankValue(String v) {
        for (CauseOfDeathDisabilityV2 c : CauseOfDeathDisabilityV2.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static CauseOfDeathDisabilityV2[] getAll() {
        return CauseOfDeathDisabilityV2.values();
    }

}