package com.opl.jns.ere.repo.v2;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.v2.ApplicationPushStatusV2;

public interface ApplicationPushStatusV2Repo extends JpaRepository<ApplicationPushStatusV2, Long> {

}