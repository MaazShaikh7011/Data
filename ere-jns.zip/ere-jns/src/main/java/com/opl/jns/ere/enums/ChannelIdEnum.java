package com.opl.jns.ere.enums;

public enum ChannelIdEnum {	
	BRANCH_ASSISTED_JNS(1l, "Branch Assisted","Branch Assisted"),
	FROM_LEGACY(2l, "From Legacy","From Legacy"),
	CUSTOMER_WEB(3l, "DIY Web","DIY Web"),
	CUSTOMER_MOBILE(4l, "DIY Mobile","DIY Mobile"),
	BC(5l, "BC","BC"),
	ATM(6l, "ATM","ATM"),
	MB(7l, "MB","MB"),
	WEB(9l, "WEB","WEB"),
	EB(10l, "EB","EB"),
	SMS(11l, "SMS","SMS"),
	WHATSAPP(12l, "WHATSAPP","WHATSAPP"),
	BRANCH(13l, "BRANCH","BRANCH"),
	TAB(14l, "TAB","TAB"),
	CSP(15l, "CSP","CSP"),
	WEBSITE(16l, "WEBSITE","WEBSITE"),
	MISSCALL(17l, "MISSCALL","MISSCALL"),
	DBU(18l, "DBU","DBU"),
	FI(19l, "FI","FI"),
	OTHER(20l, "Other","Other");

	private Long id;
	private String shortName;
	private String value;

	private ChannelIdEnum(Long id, String value,String shortName) {
		this.id = id;
		this.value = value;
		this.shortName=shortName;
	}

	public Long getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getShortName() {
		return shortName;
	}

	public static ChannelIdEnum fromId(Long v) {
		for (ChannelIdEnum c : ChannelIdEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ChannelIdEnum[] getAll() {
		return ChannelIdEnum.values();
	}
}
