package com.opl.jns.ere.enums;

public enum NatureOfLoss {

	DEATH(1, "Death"),
	DISABILITY(2, "Disability");


	private Integer id;
	private String value;

	private NatureOfLoss(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static NatureOfLoss fromId(Integer v) {
		for (NatureOfLoss c : NatureOfLoss.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static NatureOfLoss fromBankValue(String v) {
		for (NatureOfLoss c : NatureOfLoss.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static NatureOfLoss[] getAll() {
		return NatureOfLoss.values();
	}

}
