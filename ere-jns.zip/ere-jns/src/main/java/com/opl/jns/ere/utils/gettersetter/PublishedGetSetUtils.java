package com.opl.jns.ere.utils.gettersetter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequestV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.RuralUrbanEnum;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TransactionType;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

public class PublishedGetSetUtils {

	public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final int INT_1900 = 1900;
	public static final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	public static PushEnrollmentDetailsRequestV3 setAppMstDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			ApplicationMasterV3 appMaster) {
		pushDataReq.setApplicationId(appMaster.getId());
		pushDataReq.setCommonUserId(appMaster.getUserId());
		pushDataReq.setOrgId(appMaster.getOrgId());
		pushDataReq.setUrn(appMaster.getUrn());
		pushDataReq.setPolicyYear(!OPLUtils.isObjectNullOrEmpty(appMaster.getCompletionDate())
				? String.valueOf(fetchPolicyYear(appMaster.getCompletionDate()))
				: null);
		pushDataReq.setFirstEnrollmentDate(!OPLUtils.isObjectNullOrEmpty(appMaster.getCompletionDate())
				? sdf_yyyy_MM_dd_HH_mm_ss.format(appMaster.getCompletionDate())
				: null);
		pushDataReq.setSchemeName(SchemeMaster.getById(appMaster.getSchemeId().longValue()).getShortName());
		pushDataReq.setAccountNumber(appMaster.getAccountNumber());
		pushDataReq.setCif(appMaster.getCif());
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setApplicantInfoDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			ApplicantInfo applicantInfo) {
		pushDataReq.setCustomerIFSC(applicantInfo.getIfsc());
		pushDataReq.setAccountHolderName(applicantInfo.getName());
		pushDataReq.setGender(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getGenderId())
				? Gender.fromId(applicantInfo.getGenderId()).getBankValue()
				: null);
		pushDataReq.setFatherHusbandName(applicantInfo.getFatherHusbandName());
		pushDataReq.setDob(
				!OPLUtils.isObjectNullOrEmpty(applicantInfo.getDob()) ? sdf.format(applicantInfo.getDob()) : null);
		pushDataReq.setMobileNumber(applicantInfo.getMobileNumber());
		pushDataReq.setEmailId(applicantInfo.getEmail());
		if (!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
			pushDataReq.setAddressLine1(applicantInfo.getAddress().getAddressLine1());
			pushDataReq.setAddressLine2(applicantInfo.getAddress().getAddressLine2());
			pushDataReq.setPincode(formatPincode(applicantInfo.getAddress().getPincode()));
			pushDataReq.setCity(applicantInfo.getAddress().getCityName());
			pushDataReq.setDistrict(applicantInfo.getAddress().getDistrict());
			pushDataReq.setState(applicantInfo.getAddress().getStateName());
		}
		pushDataReq.setKycID1(applicantInfo.getKycId1());
		pushDataReq.setKycID1Number(applicantInfo.getKycIdNumber1());
		pushDataReq.setPan(
				!OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan()) ? YesNo.YES.getValue() : YesNo.NO.getValue());
		pushDataReq.setPanNumber(applicantInfo.getPan());
		pushDataReq.setAadhaar(
				!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar()) ? YesNo.YES.getValue() : YesNo.NO.getValue());
		pushDataReq.setAadhaarNumber(applicantInfo.getAadhaar());
		pushDataReq.setDisabilityStatus(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getDisabilityStatus())
				? YesNo.fromShortName(applicantInfo.getDisabilityStatus()).getValue()
				: YesNo.NO.getValue());
		pushDataReq.setDisabilityDetails(applicantInfo.getDisabilityDetails());
		pushDataReq.setApplicantOccupation(applicantInfo.getOccupation());
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setOtherDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			ApplicationMasterOtherDetailsV3 appOtherDtl) {

		if (!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getSource())
				&& appOtherDtl.getSource().equals(Source.OTHER_CHANNEL.getId())) {
			pushDataReq.setSource(Source.OTHER_CHANNEL.getMode());
			pushDataReq.setMode(null);
		} else {
			pushDataReq.setSource(Source.JANSURAKSHA.getMode());
			pushDataReq.setMode(Source.fromId(appOtherDtl.getSource()).getMode());
		}
		pushDataReq.setBranchCode(appOtherDtl.getBranchCode());
		pushDataReq.setBankCode(appOtherDtl.getBankCode());
		pushDataReq.setConsentForAutoDebit("Yes");
		pushDataReq.setUserId1(appOtherDtl.getUserId1());
		pushDataReq.setUserId2(appOtherDtl.getUserId2());
		pushDataReq.setChannelId(!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getChannel())
				? ChannelIdEnum.fromId(appOtherDtl.getChannel()).getShortName()
				: null);
		pushDataReq.setRuralUrban(!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getRuralUrbanId())
				? RuralUrbanEnum.fromId(appOtherDtl.getRuralUrbanId()).getValue()
				: null);
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setTransactionDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			TransactionDetailsV3 transactionDetails) {
		pushDataReq.setInsurerCode(transactionDetails.getInsurerCode());
		pushDataReq.setTransactionUTR(transactionDetails.getTransUtr());
		pushDataReq.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(transactionDetails.getTransTimeStamp())
				? sdf_yyyy_MM_dd_HH_mm_ss.format(transactionDetails.getTransTimeStamp())
				: null);
		pushDataReq.setTransactionAmount(transactionDetails.getTransAmount());
		pushDataReq.setTransactionType(TransactionType.NEW_ENROLLMENT.getKey());
		pushDataReq.setMasterPolicyNumber(transactionDetails.getMasterPolicyNo());
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setNomineeDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			List<NomineeDetails> nomineeLst) {
		Optional<NomineeDetails> nomineeOptional = nomineeLst.stream()
				.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.NOMINEE.getId().equals(a.getType()))
				.findFirst();
		if (nomineeOptional.isPresent()) {
			NomineeDetails nomineeDtl = nomineeOptional.get();
			pushDataReq.setNomineeName(nomineeDtl.getName());
			pushDataReq.setNomineeDateOfBirth(
					!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getDob()) ? sdf.format(nomineeDtl.getDob()) : null);
			pushDataReq.setNomineeMobileNumber(nomineeDtl.getMobileNumber());
			pushDataReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getRelationId())
					? RelationShip.fromId(nomineeDtl.getRelationId()).getValue()
					: null);
			pushDataReq.setNomineeEmailId(nomineeDtl.getEmail());
			pushDataReq.setAddressofNominee(
					!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getAddress()) ? nomineeDtl.getAddress().getAddressLine1()
							: null);
		}
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setGuardianDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			List<NomineeDetails> guardianLst) {
		Optional<NomineeDetails> guardianOptional = guardianLst.stream()
				.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.GUARDIAN.getId().equals(a.getType()))
				.findFirst();
		if (guardianOptional.isPresent()) {
			NomineeDetails guardianDtl = guardianOptional.get();
			pushDataReq.setNameofGuardian(guardianDtl.getName());
			pushDataReq.setAddressOfGuardian(
					!OPLUtils.isObjectNullOrEmpty(guardianDtl.getAddress()) ? guardianDtl.getAddress().getAddressLine1()
							: null);
			pushDataReq.setRelationShipOfGuardian(!OPLUtils.isObjectNullOrEmpty(guardianDtl.getRelationId())
					? RelationShip.fromId(guardianDtl.getRelationId()).getValue()
					: null);
			pushDataReq.setGuardianMobileNumber(guardianDtl.getMobileNumber());
			pushDataReq.setGuardianEmailId(guardianDtl.getEmail());
		}
		return pushDataReq;
	}

	static int fetchPolicyYear(Date date) {
		int currentMonth = date.getMonth();
		int currentYear = date.getYear() + INT_1900;
		if (currentMonth > Calendar.MAY) {
			currentYear = currentYear + 1;
		}
		return currentYear;
	}
	
	public static String formatPincode(Integer pincode) {
		if (!OPLUtils.isObjectNullOrEmpty(pincode)) {
			return "%06d".formatted(pincode);
		}
		return null;
	}
	
}
