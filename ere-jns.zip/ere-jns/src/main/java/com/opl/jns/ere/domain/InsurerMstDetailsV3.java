package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "insurer_mst_details",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE,indexes = {
		@Index(columnList = "scheme_id,org_id,is_active,policy_start_date,policy_end_date", name = DBNameConstant.JNS_INSURANCE
				+ "_insurer_mst_details_schemeId_orgId_actv_policy_start_end_date_idx"),	
//        @Index(columnList = "org_id", name = "org_id_ins_mst_idx"),
//        @Index(columnList = "insurer_org_id", name = "insurer_org_id_ins_mst_idx"),
//        @Index(columnList = "scheme_id", name = "scheme_id_ins_mst_idx"),
})
public class InsurerMstDetailsV3 extends Auditor{


    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "insurer_mst_details_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "insurer_mst_details_seq_gen", sequenceName = "insurer_mst_details_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "scheme_id")
    private Long schemeId;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "insurer_org_id")
    private Long insurerOrgId;

    @Column(name = "insurer_code")
    private String insurerCode;

    @Convert(converter = AESOracle.class)
    @Column(name = "insurer_address")
    private String insurerAddress;

    @Column(name = "pincode")
    private Long pincode;

    @Convert(converter = AESOracle.class)
    @Column(name = "head_name")
    private String headName;

    @Convert(converter = AESOracle.class)
    @Column(name = "head_email")
    private String headEmail;

    @Convert(converter = AESOracle.class)
    @Column(name = "head_contact_no")
    private String headContactNo;

    @Convert(converter = AESOracle.class)
    @Column(name = "head_mobile_no")
    private String headMobileNo;
    
    @Convert(converter = AESOracle.class)
    @Column(name = "associated_acc_holder_name")  
    private String associatedAccHolderName;

    @Convert(converter = AESOracle.class)
    @Column(name = "associated_acc_no")    
    private String associatedAccNo;

    @Convert(converter = AESOracle.class)
    @Column(name = "associated_ifsc_code")    
    private String associatedIfscCode;

    @Convert(converter = AESOracle.class)
    @Column(name = "master_policy_no")    
    private String masterPolicyNo;

    @Column(name = "policy_start_date")
    private Date policyStartDate;

    @Column(name = "policy_end_date")
    private Date policyEndDate;

    @Column(name = "year")
    private String year;

//    @JsonManagedReference
//    @OneToMany(mappedBy = "insurerMaster",fetch = FetchType.LAZY)
//    private List<TransactionDetailsV3> transactionDetails;
}
