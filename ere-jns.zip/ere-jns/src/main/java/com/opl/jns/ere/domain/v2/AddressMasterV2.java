package com.opl.jns.ere.domain.v2;

import com.opl.jns.utils.constant.*;
import lombok.*;

import java.io.Serializable;

import jakarta.persistence.*;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "address_master", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class AddressMasterV2 implements Serializable {

	private static final long serialVersionUID = 7341160037461570410L;

	@Id
	@Column(name = "id")
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ADD_MST_SEQ_GEN")
//	@SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "ADD_MST_SEQ_GEN", sequenceName = "ADD_MST_SEQ_GEN", allocationSize = 1)
	private Long id;

	@Column(name = "city_id", length = 200, nullable = true)
	private Long cityId;

	@Column(name = "city_lgd_code", length = 20, nullable = true)
	private Long cityLGDCode;

	@Column(name = "city_name", length = 500, nullable = true)
	private String cityName;

	@Column(name = "district", length = 500, nullable = true)
	private String district;

	@Column(name = "district_lgd_code", length = 20, nullable = true)
	private Long districtLGDCode;

	@Column(name = "pincode")
	private Integer pincode;

	@Column(name = "state_id", length = 200, nullable = true)
	private Long stateId;

	@Column(name = "state_lgd_code", length = 20, nullable = true)
	private Long stateLGDCode;

	@Column(name = "state_name", length = 500, nullable = true)
	private String stateName;

}
