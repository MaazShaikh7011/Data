package com.opl.jns.ere.repo;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.TransactionDetailsV3;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
public interface TransactionDetailsRepositoryV3 extends JpaRepository<TransactionDetailsV3, Long> {

	TransactionDetailsV3 findFirstByApplicationMasterIdAndTypeAndIsActiveTrue(Long applicationId, Integer typeId);

	@Transactional
	@Modifying
	@Query(nativeQuery = true,value = "update JNS_INSURANCE.TRANSACTION_DETAILS set TRANS_UTR=JNS_USERS.\"encvalue\"(:utr),TRANS_TIME_STAMP=JNS_USERS.\"encvalue\"(:tstamp) where id=:id")
	void updateTransTimeStamp(@Param("utr") String utr,@Param("tstamp") String tstamp,@Param("id") Long id);


	@Transactional
	@Modifying
	@Query(value = "update TransactionDetailsV3 set coiStorageId=:storageId where id=:id")
	void updateStorageIdInTransaction(@Param("storageId") Long utr,@Param("id") Long id);
	
	@Transactional
	@Modifying
	@Query(value = "update TransactionDetailsV3 set transTimeStamp=:transTimeStamp where id=:transId")
	void updateTransTimeStampById(@Param("transId") Long transId,@Param("transTimeStamp") Date transTimeStamp);
	
}
