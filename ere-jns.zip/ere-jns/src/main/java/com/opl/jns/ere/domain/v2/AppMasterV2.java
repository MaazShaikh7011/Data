package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.SequenceGenerator;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public class AppMasterV2 extends AuditorV2 implements Serializable {

	private static final long serialVersionUID = -165456464641L;

	@Id
	@Column(name = "id")	
	private Long id;

	/**
	 * UNIQUE URN NUMBER SAMPLE: JNS-PMSBY-23-24-00004894942-509
	 */
	@Column(name = "urn", nullable = true, columnDefinition = "varchar(50) default ''")
	private String urn;

	@Column(name = "org_id", nullable = false)
	private Long orgId;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Column(name = "branch_id", nullable = true)
	private Long branchId;

	@Column(name = "status", nullable = true)
	private Integer status;

	@Column(name = "status_change_date", nullable = true)
	private Date statusChangeDate;

	/**
	 * ENROLLMENT DATE IS COI PROCESSING DATE OR TRANSACTION DATE
	 */
	@Column(name = "enrollment_date", nullable = true)
	private Date enrollmentDate;

	/**
	 * COI GENERATE DATE
	 */
	@Column(name = "completion_date", nullable = true)
	private Date completionDate;

	@Column(name = "message", nullable = true, columnDefinition = "varchar(255) default ''")
	private String message;

	@Column(name = "premium_amount", nullable = true)
	private Double premiumAmount;

	/**
	 * REFERE Source ENUM
	 */
	@Column(name = "source", nullable = true)
	private Integer source;

	/**
	 * CHANNEL ID RECIEVED FROM OTHER CHANNEL APIs
	 */
	@Column(name = "channel_id", nullable = true)
	private Long channelId;

	@Column(name = "gender_id", nullable = true)
	private Integer genderId;

	@Column(name = "branch_state_id", nullable = true)
	private Long branchStateId;

	@Column(name = "branch_city_id", nullable = true)
	private Long branchCityId;

	@Column(name = "branch_lho_id", nullable = true)
	private Long branchLhoId;

	@Column(name = "branch_ro_id", nullable = true)
	private Long branchRoId;

	@Column(name = "branch_zo_id", nullable = true)
	private Long branchZoId;

	@Column(name = "renewal_date", nullable = true)
	private Date renwalDate;

	@Column(name = "renewal_rejection_type", nullable = true)
	private Integer renewalRejectionType;

	@Column(name = "rural_urban", nullable = true)
	private Integer ruralUrban;

	@Column(name = "policy_year", nullable = true)
	private Integer policyYear;

	@Column(name = "financial_year", nullable = true)
	private Integer financialYear;

	@Column(name = "policy_month", nullable = true)
	private Integer policyMonth;

	@Column(name = "financial_month", nullable = true)
	private Integer financialMonth;

	@Column(name = "policy_day", nullable = true)
	private Integer policyDay;

	@Column(name = "financial_day", nullable = true)
	private Integer financialDay;

	/**
	 * LATEST TRANSACTION DETAILS PRIMARY ID
	 */
	@Column(name = "last_transaction_id", nullable = true)
	private Long lastTransactionId;
	
	@Column(name = "enroll_type", nullable = true)
	private Integer enrollType;

}
