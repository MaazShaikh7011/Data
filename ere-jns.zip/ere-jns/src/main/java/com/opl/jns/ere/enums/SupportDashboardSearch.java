package com.opl.jns.ere.enums;

public enum SupportDashboardSearch {

	EMAIL(1, "Email"), MOBILE_NO(2, "Mobile number"), URN(3, "URN"), APPLICATION_ID(4, "ApplicationId"),
	ACCOUNT_NO(5, "Account number"),USERNAME(6, "Username");

	private Integer id;
	private String value;

	private SupportDashboardSearch(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SupportDashboardSearch fromId(Integer v) {
		for (SupportDashboardSearch c : SupportDashboardSearch.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SupportDashboardSearch fromValue(String v) {
		for (SupportDashboardSearch c : SupportDashboardSearch.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v : null);
	}

	public static SupportDashboardSearch[] getAll() {
		return SupportDashboardSearch.values();
	}
}
