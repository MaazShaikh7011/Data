package com.opl.jns.ere.enums;

public enum TransactionType {
	
	NEW_ENROLLMENT(1,"N","New Enrollment"),RENEWAL(2,"R","Renewal");

	private Integer id;
	private String key;
	private String value;

	private TransactionType(Integer id,String key, String value) {
		this.id = id;
		this.key = key;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getKey() {
		return key;
	}

	public static TransactionType fromId(Integer v) {
		for (TransactionType c : TransactionType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static TransactionType[] getAll() {
		return TransactionType.values();
	}
}
