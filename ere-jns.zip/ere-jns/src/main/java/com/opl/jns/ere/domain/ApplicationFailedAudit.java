package com.opl.jns.ere.domain;

import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_failed_audit", schema = DBNameConstant.JNS_INSURANCE)
public class ApplicationFailedAudit {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_failed_audit_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "application_failed_audit_seq_gen", sequenceName = "application_failed_audit_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "api_type", nullable = true)
	private Integer apiType;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "push_failed_date", nullable = true)
	private Date pushFailedDate;

	@Column(name = "is_retry", nullable = true)
	private Boolean isRetry;

	@Column(name = "retry_date", nullable = true)
	private Date retryDate;

}
