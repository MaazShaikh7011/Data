package com.opl.jns.ere.repo.v2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.v2.ApplicantInfoV2;

/**
 * @author maulik.panchal Date : 19-01-2024
 */
public interface ApplicantInfoRepoV2 extends JpaRepository<ApplicantInfoV2, Long> {
	
	List<ApplicantInfoV2> findByMobileNumber(String mobileNo);

	
}
