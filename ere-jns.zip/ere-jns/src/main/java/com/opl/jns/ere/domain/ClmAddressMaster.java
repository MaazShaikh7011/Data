package com.opl.jns.ere.domain;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CLM_ADDRESS_MASTER", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmAddressMaster implements Serializable {

	private static final long serialVersionUID = 7341160037461570410L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CLM_ADD_MST_SEQ_GEN")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "CLM_ADD_MST_SEQ_GEN", sequenceName = "CLM_ADD_MST_SEQ_GEN", allocationSize = 1)
	private Long id;

	@Column(name = "city_id", length = 200, nullable = true)
	private Long cityId;

	@Column(name = "city_lgd_code", length = 20, nullable = true)
	private Long cityLGDCode;

	@Column(name = "city_name", length = 500, nullable = true)
	private String cityName;

	@Column(name = "district", length = 500, nullable = true)
	private String district;

	@Column(name = "district_lgd_code", length = 20, nullable = true)
	private Long districtLGDCode;

	@Column(name = "pincode")
	private Integer pincode;

	@Column(name = "state_id", length = 200, nullable = true)
	private Long stateId;

	@Column(name = "state_lgd_code", length = 20, nullable = true)
	private Long stateLGDCode;

	@Column(name = "state_name", length = 500, nullable = true)
	private String stateName;

}
