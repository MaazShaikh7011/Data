package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clm_details", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmDetails {

	@Id
	@Column(name = "id")
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@MapsId
	@JoinColumn(name = "id")
	private ClmMaster clmMaster;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "clmDetails", optional = false)
	@PrimaryKeyJoinColumn
	private ClmPIDetails clmPIDetails;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "ap_address_id", referencedColumnName = "id")
	private ClmAddressMaster apAddressMaster;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "claimant_address_id", referencedColumnName = "id")
	private ClmAddressMaster claimantAddressMaster;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_email", nullable = true)
	private String apEmail;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_mobile_number", nullable = true)
	private String apMobileNumber;

	@Column(name = "ap_disability_details")
	private String apDisabilityDetails;

	@Column(name = "ap_disability_status")
	private String apDisabilityStatus;

	@Column(name = "ap_customer_ifsc", nullable = true)
	private String apCustomerIfsc;
	
	@Column(name = "ap_transactionUtr", nullable = true)
	private String apTransactionUTR;

	@Column(name = "ap_transaction_amount", nullable = true)
	public Double apTransactionAmount;

	@Column(name = "ap_transaction_time_stamp", nullable = true)
	private Date apTransactionTimestamp;
	
	@Column(name = "ap_gender_id")
	private Integer apGenderId;

	@Column(name = "is_claimant_same", nullable = true)
	private Boolean isClaimantSame;

	@Column(name = "clm_relation_id", nullable = true)
	private Integer clmRelationId;

	@Column(name = "clm_email", nullable = true)
	private String clmEmail;

	@Column(name = "clm_mobile", nullable = true)
	private String clmMobile;
	
	@Column(name = "clm_gender_id")
	private Integer clmGenderId;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "date_of_death", nullable = true)
	private Date dateOfDeath;
	
	@Column(name = "is_date_of_death", nullable = true)
	private Boolean isDateOfDeath;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "date_time_of_accident", nullable = true)
	private Date dateTimeOfAccident;
	
	@Column(name = "is_date_time_of_accident", nullable = true)
	private Boolean isDateTimeOfAccident;

	@Column(name = "day_of_accident", nullable = true)
	private String dayOfAccident;

	@Column(name = "place_of_occurrence", nullable = true)
	private String placeOfOccurrence;

	@Column(name = "nature_of_loss_id", nullable = true)
	private Integer natureOfLossId;

	@Column(name = "type_of_disability_id", nullable = true)
	private Integer typeOfDisabilityId;

	@Column(name = "cause_of_death_disability_id", nullable = true)
	private Integer causeOfDeathDisabilityId;

	@Column(name = "prem_debit_date", nullable = true)
	private Date premDebitDate;

	@Column(name = "prem_remit_date", nullable = true)
	private Date premRemitDate;

	@Column(name = "date_of_lodging_claim", nullable = true)
	private Date dateOfLodgingClaim;

	@Column(name = "branch_code", nullable = true)
	private String branchCode;

	@Column(name = "branch_email_id", nullable = true)
	private String branchEmailId;

	@Column(name = "is_nominee_name_correction", nullable = true)
	private Boolean isNomineeNameCorrection;
	
}
