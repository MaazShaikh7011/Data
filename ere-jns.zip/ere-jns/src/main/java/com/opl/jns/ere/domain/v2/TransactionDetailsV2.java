package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "transaction_details", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class TransactionDetailsV2 extends AuditorV2 implements Serializable {

	private static final long serialVersionUID = 7488119854443745218L;

	@Id
	@Column(name = "id")
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "JNS_TXN_DTLS_SEQ_GEN")
	//@SequenceGenerator(schema = DBNameConstant.JNS_MASTER_DATA, name = "JNS_TXN_DTLS_SEQ_GEN", sequenceName = "JNS_TXN_DTLS_SEQ_GEN", allocationSize = 1)
	private Long id;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "insurer_master_id", nullable = true)
	private Long insurerMasterId;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Convert(converter = AESOracle.class)
	@Column(name = "master_policy_no", nullable = true)
	private String masterPolicyNo;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Column(name = "coi_storage_id", nullable = true)
	private Long coiStorageId;

	@Column(name = "insurer_code")
	private String insurerCode;

	@Column(name = "year", nullable = true)
	private Integer year;

	@Column(name = "cover_start_date", nullable = true)
	private Date coverStartDate;

	@Column(name = "cover_end_date", nullable = true)
	private Date coverEndDate;

	@Column(name = "trans_amount", nullable = true)
	private Double transAmount;

	@Column(name = "trans_comment", nullable = true)
	private String transComment;

	@Column(name = "trans_time_stamp", nullable = true)
	private Date transTimeStamp;

	@Convert(converter = AESOracle.class)
	@Column(name = "trans_utr", nullable = true)
	private String transUtr;

}
