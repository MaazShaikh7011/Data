package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author maulik.panchal Date : 19-01-2024
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "APPLICANT_INFO", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class ApplicantInfoV2 implements Serializable {

	private static final long serialVersionUID = 7488119854443800218L;

	@Id
	@Column(name = "id")
	private Long id;

	/**
	 * PRIMARY ID OF AddressMasterV2
	 */
	@Column(name = "address_id")
	private Long addressId;

	@Convert(converter = AESOracle.class)
	@Column(name = "email", nullable = true, columnDefinition = "varchar(100) default ''")
	private String email;

	@Convert(converter = AESOracle.class)
	@Column(name = "mobile_number", nullable = true, columnDefinition = "varchar(100) default ''")
	private String mobileNumber;

//	@Convert(converter = AESOracle.class)
	@Column(name = "ifsc", nullable = true, columnDefinition = "varchar(50) default ''")
	private String ifsc;

	@Column(name = "is_nominee_same_enroll", nullable = true)
	private Boolean isNomineeDetailsSameEnroll;

	@Column(name = "disability_status", nullable = false, columnDefinition = "varchar(10) default ''")
	private String disabilityStatus;

	@Column(name = "disability_details", nullable = false, columnDefinition = "varchar(255) default ''")
	private String disabilityDetails;

	@Column(name = "is_kyc_update", nullable = true)
	private Boolean isKYCUpdate;

	@Column(name = "is_pmjjby_exists", nullable = true)
	private Boolean isPMJJBYExists;

	@Column(name = "is_pmsby_exists", nullable = true)
	private Boolean isPMSBYExists;

	@Column(name = "is_same_app_address", nullable = true)
	private Boolean isSameAppAddress;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Convert(converter = AESOracle.class)
	@Column(name = "user_id_1", nullable = true, columnDefinition = "varchar(255) default ''")
	private String userId1;

	@Convert(converter = AESOracle.class)
	@Column(name = "user_id_2", nullable = true, columnDefinition = "varchar(255) default ''")
	private String userId2;

	@Column(name = "is_diy_premium_consent", nullable = true)
	private Boolean isDiyPremiumConsent;

	@Column(name = "type_of_verification", nullable = true)
	private Integer typeOfVerification;

	@Column(name = "consent_for_auto_debit", nullable = true, columnDefinition = "varchar(10) default ''")
	private String consentForAutoDebit;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "occupation",nullable = true)
    private String occupation;

}
