package com.opl.jns.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.ClmNomineeDetails;

public interface ClmNomineeDetailsRepository extends JpaRepository<ClmNomineeDetails, Long> {


}
