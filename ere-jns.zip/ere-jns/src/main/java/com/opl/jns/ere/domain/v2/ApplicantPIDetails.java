package com.opl.jns.ere.domain.v2;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author maulik.panchal Date : 19-01-2024
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "APPLICANT_PI_DETAILS", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA)
public class ApplicantPIDetails implements Serializable {

	private static final long serialVersionUID = 7611523435726470296L;

	@Id
	@Column(name = "id")
	private Long id;

	@Convert(converter = AESOracle.class)
	@Column(name = "account_number", nullable = true, columnDefinition = "varchar(255) default ''")
	private String accountNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "cif", nullable = true, columnDefinition = "varchar(255) default ''")
	private String cif;

	@Convert(converter = AESOracle.class)
	@Column(name = "ac_holder_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String acHolderName;

	@Convert(converter = AESOracle.class)
	@Column(name = "first_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String firstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "middle_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String middleName;

	@Convert(converter = AESOracle.class)
	@Column(name = "last_name", nullable = true, columnDefinition = "varchar(100) default ''")
	private String lastName;

	@Convert(converter = AESOracle.class)
	@Column(name = "pan", nullable = true, columnDefinition = "varchar(255) default ''")
	private String pan;

	@Convert(converter = AESOracle.class)
	@Column(name = "aadhaar", nullable = true, columnDefinition = "varchar(255) default ''")
	private String aadhaar;

	@Column(name = "ckyc_number", nullable = true, columnDefinition = "varchar(255) default ''")
	private String ckycNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "kyc_id_1", nullable = true, columnDefinition = "varchar(100) default ''")
	private String kycId1;

	@Convert(converter = AESOracle.class)
	@Column(name = "kyc_id_number_1", nullable = true, columnDefinition = "varchar(255) default ''")
	private String kycIdNumber1;

	@Convert(converter = AESOracle.class)
	@Column(name = "kyc_id_2", nullable = true, columnDefinition = "varchar(100) default ''")
	private String kycId2;

	@Convert(converter = AESOracle.class)
	@Column(name = "kyc_id_number_2", nullable = true, columnDefinition = "varchar(255) default ''")
	private String kycIdNumber2;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "dob", nullable = true)
	private Date dob;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_1", length = 500, nullable = true, columnDefinition = "varchar(500) default ''")
	private String addressLine1;

	@Convert(converter = AESOracle.class)
	@Column(name = "address_line_2", length = 500, nullable = true, columnDefinition = "varchar(500) default ''")
	private String addressLine2;
	
	@Column(name = "enrollment_date", nullable = true)
	private Date enrollmentDate;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "father_husband_name", nullable = true, columnDefinition = "varchar(255) default ''")
	private String fatherHusbandName;

}
