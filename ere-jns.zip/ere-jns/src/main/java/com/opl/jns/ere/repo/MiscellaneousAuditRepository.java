package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author ravi.thummar
 * Date : 05-07-2023
 */
public interface MiscellaneousAuditRepository extends JpaRepository<MiscellaneousAudit, Long> {

//    @Query("select DISTINCT m.applicationId from MiscellaneousAudit m where m.dateOfEffective<=:dateOfEffective AND m.type=:type")
//    List<Long> findApplicationIdByDateOfEffectiveAndType(@Param("dateOfEffective") Date dateOfEffective, @Param("type") Integer type);

    @Query("select DISTINCT m.applicationId from MiscellaneousAudit m where m.dateOfEffective<=TO_DATE(:dateOfEffective, 'YYYY-MM-DD')  AND m.type=:type")
    List<Long> findApplicationIdByDateOfEffectiveAndType(@Param("dateOfEffective") String dateOfEffective, @Param("type") Integer type);

    MiscellaneousAudit findFirstByApplicationIdAndTypeAndIsActiveTrue(Long applicationId, Integer id);
    
    List<MiscellaneousAudit> findByApplicationIdAndTypeInAndIsActiveTrue(Long applicationId, List<Integer> id);
    
    @Query("""
		    select DISTINCT m.applicationId from MiscellaneousAudit m \
		    inner join PMSBY pm on pm.id=m.applicationId and pm.status !=:applicationStatus and pm.isActive=true \
		    where m.type=:type and m.isActive=true\
		    """)
    public List<Long> findApplicationIdsByTypeAndIsActiveTruePmsby(@Param("type") Integer type,@Param("applicationStatus") Integer applicationStatus);
    
    @Query("""
		    select DISTINCT m.applicationId from MiscellaneousAudit m \
		    inner join PMJJBY pm on pm.id=m.applicationId and pm.status !=:applicationStatus and pm.isActive=true \
		    where m.type=:type and m.isActive=true\
		    """)
    public List<Long> findApplicationIdsByTypeAndIsActiveTruePmjjby(@Param("type") Integer type,@Param("applicationStatus") Integer applicationStatus);
    
    @Query("""
		    select am from ApplicationMasterV3 am WHERE am.id IN (select m.applicationId from MiscellaneousAudit m where m.dateOfEffective<=TO_DATE(:dateOfEffective, 'YYYY-MM-DD')  \
		    AND m.type=:type) and am.isActive = true and am.applicationStatus!=6\
		    """)
    List<ApplicationMasterV3> findApplicationIdByDateOfEffectiveAndTypeFromAppMaster(@Param("dateOfEffective") String dateOfEffective, @Param("type") Integer type);
    
    @Query("""
		    select DISTINCT am.id from ApplicationMasterV3 am WHERE am.id IN (select m.applicationId from MiscellaneousAudit m where m.dateOfEffective<=TO_DATE(:dateOfEffective, 'YYYY-MM-DD')  \
		    AND m.type=:type) and am.isActive = true and am.applicationStatus!=6\
		    """)
    List<Long> findApplicationIdsByDateOfEffectiveAndTypeFromAppMaster(@Param("dateOfEffective") String dateOfEffective, @Param("type") Integer type);
    
	@Transactional
	@Modifying
	@Query("UPDATE MiscellaneousAudit SET isBankStatusPushed=true,modifiedDate =:date WHERE id =:id")
	int updateBankFlagAndModified(@Param("date") Date date,@Param("id") Long id);
	
	@Transactional
	@Modifying
	@Query("UPDATE MiscellaneousAudit SET isInsurerStatusPushed=true,modifiedDate =:date WHERE id =:id")
	int updateInsurerFlagAndModified(@Param("date") Date date,@Param("id") Long id);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE MiscellaneousAudit SET isActive = FALSE WHERE applicationId = :applicationId AND type =:type")
	void isActiveFalseByApplicationId(@Param("applicationId") Long applicationId, @Param("type") Integer type);
	

}
