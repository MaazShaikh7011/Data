package com.opl.jns.ere.enums;

public enum EnrollTypeEnum {
	
	NEW_ENROLLMENT(1,"N","New Enrollment"), ENDORSEMENT(2,"E","Endorsement");

	private Integer id;
	private String key;
	private String value;

	private EnrollTypeEnum(Integer id,String key, String value) {
		this.id = id;
		this.key = key;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
	
	public String getKey() {
		return key;
	}

	public static EnrollTypeEnum fromId(Integer v) {
		for (EnrollTypeEnum c : EnrollTypeEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static EnrollTypeEnum[] getAll() {
		return EnrollTypeEnum.values();
	}
}
