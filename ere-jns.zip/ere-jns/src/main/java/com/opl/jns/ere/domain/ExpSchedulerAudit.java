package com.opl.jns.ere.domain;


import java.util.Date;

import com.opl.jns.utils.constant.DBNameConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "exp_scheduler_audit")
public class ExpSchedulerAudit {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "exp_scheduler_audit_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "exp_scheduler_audit_seq_gen", sequenceName = "exp_scheduler_audit_seq_gen", allocationSize = 1)
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start_date")
    private Date startDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "complete_date")
    private Date completeDate;

    @Column(name = "expire_counts")
    private Long expireCounts;

    @Column(name = "status")
    private String status;

    @Column(name = "api")
    private Integer api;

    @Column(name = "is_move_expire_enroll")
    private Boolean isMoveExpireEnroll;

}
