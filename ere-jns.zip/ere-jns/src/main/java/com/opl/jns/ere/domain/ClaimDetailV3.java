//package com.opl.jns.ere.domain;
//
//import java.util.Date;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Convert;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Index;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.PostLoad;
//import javax.persistence.SequenceGenerator;
//import javax.persistence.Table;
//import javax.persistence.Transient;
//
//import com.opl.jns.ere.enums.CauseOfDeathDisability;
//import com.opl.jns.ere.enums.KycDocument;
//import com.opl.jns.ere.enums.NatureOfLoss;
//import com.opl.jns.ere.enums.TypeOfDisability;
//import com.opl.jns.utils.common.AESOracle;
//import com.opl.jns.utils.common.DateEncryptorAes;
//import com.opl.jns.utils.constant.DBNameConstant;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.EqualsAndHashCode;
//import lombok.NoArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//@Data
//@EqualsAndHashCode(callSuper = false)
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
//@Table(name = "claim_detail",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
//		@Index(columnList = "claim_id", name = DBNameConstant.JNS_INSURANCE + "clm_dtls_claim_id_idx") })
//@Slf4j
//public class ClaimDetailV3 {
//
//	@Id
//	@Column(name = "id")
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "claim_detail_seq_gen")
//	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "claim_detail_seq_gen", sequenceName = "claim_detail_seq_gen", allocationSize = 1)
//	private Long id;
//
//	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@JoinColumn(name = "claim_id", referencedColumnName = "id")
//	private ClaimMasterV3 claimMaster;
//
//	@Column(name = "claimant_bank_account_number", nullable = true)
//	private String claimantBankAccountNumber;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "pan", nullable = true)
//	private String pan;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "aadhar", nullable = true)
//	private String aadhar;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "passport", nullable = true)
//	private String passport;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "mgnerega", nullable = true)
//	private String mgnerega;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "driving_license", nullable = true)
//	private String drivingLicense;
//
//    @Convert(converter = AESOracle.class)
//	@Column(name = "votting_card_id", nullable = true)
//	private String vottingCardId;
//
//	@Column(name = "location_of_loss", nullable = true)
//	private String locationOfLoss;
//
//	@Column(name = "loss_location_pincode", nullable = true)
//	private Long lossLocationPincode;
//
//	@Column(name = "nature_of_loss_id", nullable = true)
//	private Integer natureOfLossId;
//
//	@Column(name = "cause_of_death_disability_id", nullable = true)
//	private Integer causeOfDeathDisabilityId;
//
//	@Column(name = "type_of_disability_id", nullable = true)
//	private Integer typeOfDisablityId;
//
//	@Transient
//	private KycDocument kycDocument1;
//	@Transient
//	private KycDocument kycDocument2;
//	@Transient
//	private NatureOfLoss natureOfLoss;
//	@Transient
//	private CauseOfDeathDisability causeOfDeathDisability;
//	@Transient
//	private TypeOfDisability typeOfDisability;
//
//	@PostLoad
//	void fillTransient() {
//		if (natureOfLossId != null) {
//			this.natureOfLoss = NatureOfLoss.fromId(natureOfLossId);
//		}
//		if (causeOfDeathDisabilityId != null) {
//			this.causeOfDeathDisability = CauseOfDeathDisability.fromId(causeOfDeathDisabilityId);
//		}
//
//		if (typeOfDisablityId != null) {
//			log.info("typeOfDisablityId --------------------- -->" + typeOfDisablityId);
//			this.typeOfDisability = TypeOfDisability.fromId(typeOfDisablityId);
//		}
//
//	}
//
//	@Convert(converter = DateEncryptorAes.class)
//	@Column(name = "date_time_of_accident", nullable = true)
//	private Date dateTimeOfAccident;
//
//	@Column(name = "day_of_accident", nullable = true)
//	private String dayOfAccident;
//
//	@Convert(converter = DateEncryptorAes.class)
//	@Column(name = "date_of_death", nullable = true)
//	private Date dateOfDeath;
//
//	@Column(name = "fir_no", nullable = true)
//	private Long firNo;
//
//	@Column(name = "claimant_kyc_details", nullable = true)
//	private String claimantKycDetails;
//
//	@Column(name = "name_of_bank", nullable = true)
//	private String nameOfBank;
//
////	@Column(name = "branch_ifsc_code", nullable = true)
////	private String branchIfscCode;
//	
//	@Column(name = "cust_ifsc_code", nullable = true)
//	private String custIfscCode;
//
//	@Column(name = "kyc_doc_id", nullable = true)
//	private String kycDocId;
//
//	@Column(name = "branch_ro_id")
//	private Long branchRoId;
//
//	@Column(name = "branch_zo_id")
//	private Long branchZoId;
//
//	@Column(name = "branch_lho_id")
//	private Long branchLhoId;
//
//	@Column(name = "branch_state_id")
//	private Long branchStateId;
//
//	@Column(name = "branch_city_id")
//	private Long branchCityId;
//
//	@Column(name = "is_nominee_same", nullable = true)
//	private Boolean isNomineeSame;
//
//}
