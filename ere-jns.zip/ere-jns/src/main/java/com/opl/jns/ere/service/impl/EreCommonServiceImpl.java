package com.opl.jns.ere.service.impl;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicationFailedAudit;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.ConsentMapping;
import com.opl.jns.ere.domain.ConsentMaster;
import com.opl.jns.ere.domain.InsurerMstDetailsV3;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.ApplicationPushStatusV2;
import com.opl.jns.ere.domain.v2.ExpiredEnrollment;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.EnrollPushType;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.PhaseModeEnum;
import com.opl.jns.ere.repo.ApplicationFailedAuditRepository;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.ConsentMappingRepository;
import com.opl.jns.ere.repo.ConsentMasterRepository;
import com.opl.jns.ere.repo.InsurerMstDetailsRepositoryV3;
import com.opl.jns.ere.repo.NomineeDetailsRepositoryV3;
import com.opl.jns.ere.repo.TransactionDetailsRepositoryV3;
import com.opl.jns.ere.repo.v2.ApplicationPushStatusV2Repo;
import com.opl.jns.ere.repo.v2.ExpiredEnrollmentRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.ReportRepository;
import com.opl.jns.ere.repo.v2.impl.NativeQueryRepoImpl;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.ere.utils.ConsentMappingProxy;
import com.opl.jns.ere.utils.DedupeDataResponse;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.model.COIRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EreCommonServiceImpl implements EreCommonService {

	@Autowired
	private InsurerMstDetailsRepositoryV3 insurerMstDetailsRepository;

	@Autowired
	private TransactionDetailsRepositoryV3 transactionRepo;
	
	@Autowired
	private ApplicationPushStatusRepo appPushStatusRepo;
	
	@Autowired
	private ApplicationPushStatusV2Repo appPushStatusV2Repo;
	
	@Autowired
	private PmsbyRepository pmsbyRepository;
	
	@Autowired
	private PmjjbyRepository pmjjbyRepository;

	@Autowired
	private NativeQueryRepoImpl nativeQueryRepo;
	
	@Autowired
	private ExpiredEnrollmentRepository expiredEnrollmentRepository;
	
	@Autowired
	private ReportRepository reportRepository;
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;
	
	@Autowired
	private ConsentMappingRepository consentMappingRepository;
	
	@Autowired
	private ConsentMasterRepository consentMasterRepository;
	
	@Autowired
	private ApplicationFailedAuditRepository applicationFailedAuditRepo;
	
	@Override
	public COIRequest generateCOIRequest(ApplicationMasterV3 appMaster) {
		try {

			if ((appMaster.getStageId() != EnrollStageMaster.COMPLETED.getStageId() && appMaster.getStageId() != EnrollStageMaster.PREMIUM_DEDUCTION.getStageId()) || OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails())) {
				log.info("Current Application is not completed or not updated last transaction details ----------->" + appMaster.getId());
				return null;
			}

			COIRequest response = new COIRequest();
			response.setApplicationId(appMaster.getId());

			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails()) && !OPLUtils.isObjectNullOrEmpty(appMaster.getApplicationMasterOtherDetails().getChannelId())) {
				if (appMaster.getApplicationMasterOtherDetails().getChannelId().equals(ChannelIdEnum.CUSTOMER_MOBILE.getShortName())|| appMaster.getApplicationMasterOtherDetails().getChannelId().equals(ChannelIdEnum.CUSTOMER_WEB.getShortName()))
					response.setIsCustomerUser(true);
				else
					response.setIsCustomerUser(false);
			} else
				response.setIsCustomerUser(false);

			response.setLastTransactionDetailsId(appMaster.getLastTransactionDetails().getId());
			Long schemeId = appMaster.getSchemeId().longValue();
			response.setMobileNo(appMaster.getApplicantInfo().getMobileNumber());
			response.setDob(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getDob()) ? CommonUtils.sdf.format(appMaster.getApplicantInfo().getDob()) : null);
			if (PhaseMode.checkPhase2Enroll(appMaster.getOrgId())) {
				// phase 2
				response.setNameOfMember(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getName()) ? appMaster.getApplicantInfo().getName().toUpperCase() : null);
			} else {
				// phase 1
				 String strFullName = setFullName(appMaster.getApplicantInfo().getFirstName(), appMaster.getApplicantInfo().getMiddleName(), appMaster.getApplicantInfo().getLastName());
				response.setNameOfMember(!OPLUtils.isObjectNullOrEmpty(strFullName) ? strFullName.toUpperCase() : null);
			}

			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycId1())) {
				if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
					response.setKycName(KycDocument.AADHAR.getDisplayValue());
					response.setKycValue("-");
				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.PAN.getKey())) {
					response.setKycName(KycDocument.PAN.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1()) ? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : "-");
				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
					response.setKycName(KycDocument.PASSPORT.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1()) ? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : "-");
				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
					response.setKycName(KycDocument.DRIVING_LICENCE.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1()) ? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : "-");
				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
					response.setKycName(KycDocument.MGNREGA_CARD.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1()) ? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : "-");
				} else if (appMaster.getApplicantInfo().getKycId1().equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
					response.setKycName(KycDocument.VOTERS_ID_CARD.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(appMaster.getApplicantInfo().getKycIdNumber1()) ? appMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : "-");
				}
			}

			response.setPremAmtPaid(appMaster.getPremiumAmount());
			response.setAccountNo(appMaster.getAccountNumber());
			response.setUrnNo(appMaster.getUrn());
			response.setSchemeId(schemeId);
			response.setDateOfComOfCover(appMaster.getEnrollmentDate());
			response.setSignatureDate(appMaster.getModifiedDate());
			response.setBranchId(appMaster.getBranchId());

			AddressMasterV3 addMst = appMaster.getApplicantInfo().getAddress();
			response.setAddress(!OPLUtils.isObjectNullOrEmpty(getApplicantAddress(addMst)) ? getApplicantAddress(addMst).toUpperCase() : null);
			
			if(!OPLUtils.isObjectNullOrEmpty( appMaster.getOrgId())) {
				InsurerMstDetailsV3 mst = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId, appMaster.getOrgId(), new Date(), new Date());
				response.setMstPolicyNo(!OPLUtils.isObjectNullOrEmpty(mst) && !OPLUtils.isObjectNullOrEmpty(mst.getMasterPolicyNo()) ? mst.getMasterPolicyNo().toUpperCase() : null);	
			}

		
			Optional<NomineeDetails> ndMstDtl = appMaster.getNomineeDetails().stream().filter(x->x.getIsActive() && (Objects.equals(x.getType(), NomineeType.NOMINEE.getId()))).findFirst();
			Optional<NomineeDetails> ndMstOfGuardianDtl = appMaster.getNomineeDetails().stream().filter(x->x.getIsActive() && (Objects.equals(x.getType(), NomineeType.GUARDIAN.getId()))).findFirst();
			
			String strFullName = null;
			String age = null;
			if (ndMstDtl.isPresent()) {
				NomineeDetails nDtl = ndMstDtl.get();
				if (PhaseMode.checkPhase2Enroll(appMaster.getOrgId())) {
					// phase 2
					response.setNameOfNominee(!OPLUtils.isObjectNullOrEmpty(nDtl.getName()) ? nDtl.getName().toUpperCase() : null);
				} else {
					// phase 1
					strFullName = setFullName(nDtl.getFirstName(), nDtl.getMiddleName(), nDtl.getLastName());
					response.setNameOfNominee(!OPLUtils.isObjectNullOrEmpty(strFullName) ? strFullName.toUpperCase() : null);
				}
				age = String.valueOf(CommonUtils.getAgeBydob(nDtl.getDob()));
				if (ndMstOfGuardianDtl.isPresent()) {
					NomineeDetails nDtlOfGuardian = ndMstOfGuardianDtl.get();
					response.setNameOfGuardian(nDtlOfGuardian.getName().toUpperCase());
					if (!OPLUtils.isObjectNullOrEmpty(nDtlOfGuardian.getRelationId()))
						response.setRelationId(nDtlOfGuardian.getRelationId());
				}
			}

			response.setAgeOfNominee(age);
			

			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getInsurerOrgId()))
				response.setInsurerOrgId(appMaster.getLastTransactionDetails().getInsurerOrgId());

			response.setOrgId(appMaster.getOrgId());

			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoverEndDate()))
				response.setCoverEndDate(CommonUtils.sdf_dd_MM_yyyy.format(appMaster.getLastTransactionDetails().getCoverEndDate()));
			
			return response;
		} catch (Exception e) {
			log.error("Error while set application details in COI request class ------->", e);
		}
		return null;
	}
	
	
	@Override
	public COIRequest generateCOIRequestNewDb(ApplicationMasterBothSchemeProxy appMaster,TransactionDetailsV2 transactionDetailsV2,ApplicantInfoV2 applicantInfoV2,ApplicantPIDetails applicantPIDetails,NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 applicantAddress) {
		try {

			COIRequest response = new COIRequest();
			response.setApplicationId(appMaster.getId());

			if (!OPLUtils.isObjectNullOrEmpty(appMaster.getChannelId())) {
				if (appMaster.getChannelId().equals(ChannelIdEnum.CUSTOMER_MOBILE.getShortName())|| appMaster.getChannelId().equals(ChannelIdEnum.CUSTOMER_WEB.getShortName()))
					response.setIsCustomerUser(true);
				else
					response.setIsCustomerUser(false);
			} else
				response.setIsCustomerUser(false);

			response.setLastTransactionDetailsId(transactionDetailsV2.getId());
			Long schemeId = appMaster.getSchemeId();
			response.setMobileNo(applicantInfoV2.getMobileNumber());
			response.setDob(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getDob()) ? CommonUtils.sdf.format(applicantPIDetails.getDob()) : null);
			if (PhaseMode.checkPhase2Enroll(appMaster.getOrgId())) {
				// phase 2
				response.setNameOfMember(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getAcHolderName()) ? applicantPIDetails.getAcHolderName().toUpperCase() : null);
			} else {
				// phase 1
				 String strFullName = setFullName(applicantPIDetails.getFirstName(), applicantPIDetails.getMiddleName(), applicantPIDetails.getLastName());
				response.setNameOfMember(!OPLUtils.isObjectNullOrEmpty(strFullName) ? strFullName.toUpperCase() : null);
			}

			if (!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycId1())) {
				if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.AADHAR.getKey())) {
					response.setKycName(KycDocument.AADHAR.getDisplayValue());
					response.setKycValue("-");
				} else if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.PAN.getKey())) {
					response.setKycName(KycDocument.PAN.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycIdNumber1()) ? applicantPIDetails.getKycIdNumber1().toUpperCase() : "-");
				} else if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.PASSPORT.getKey())) {
					response.setKycName(KycDocument.PASSPORT.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycIdNumber1()) ? applicantPIDetails.getKycIdNumber1().toUpperCase() : "-");
				} else if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.DRIVING_LICENCE.getKey())) {
					response.setKycName(KycDocument.DRIVING_LICENCE.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycIdNumber1()) ? applicantPIDetails.getKycIdNumber1().toUpperCase() : "-");
				} else if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.MGNREGA_CARD.getKey())) {
					response.setKycName(KycDocument.MGNREGA_CARD.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycIdNumber1()) ? applicantPIDetails.getKycIdNumber1().toUpperCase() : "-");
				} else if (applicantPIDetails.getKycId1().equalsIgnoreCase(KycDocument.VOTERS_ID_CARD.getKey())) {
					response.setKycName(KycDocument.VOTERS_ID_CARD.getDisplayValue());
					response.setKycValue(!OPLUtils.isObjectNullOrEmpty(applicantPIDetails.getKycIdNumber1()) ? applicantPIDetails.getKycIdNumber1().toUpperCase() : "-");
				}
			}

			response.setPremAmtPaid(appMaster.getPremiumAmount());
			response.setAccountNo(applicantPIDetails.getAccountNumber());
			response.setUrnNo(appMaster.getUrn());
			response.setSchemeId(schemeId);
			response.setDateOfComOfCover(appMaster.getEnrollmentDate());
			response.setSignatureDate(appMaster.getModifiedDate());
			response.setBranchId(appMaster.getBranchId());

			response.setAddress(!OPLUtils.isObjectNullOrEmpty(getApplicantAddressNewDb(applicantAddress,applicantPIDetails.getAddressLine1(),applicantPIDetails.getAddressLine2())) ? getApplicantAddressNewDb(applicantAddress,applicantPIDetails.getAddressLine1().toUpperCase(),applicantPIDetails.getAddressLine2()).toUpperCase() : null);
			
			if(!OPLUtils.isObjectNullOrEmpty( appMaster.getOrgId())) {
				InsurerMstDetailsV3 mst = insurerMstDetailsRepository.findBySchemeIdAndOrgIdAndIsActiveTrueAndPolicyStartDateBeforeAndPolicyEndDateAfter(schemeId, appMaster.getOrgId(), new Date(), new Date());
				response.setMstPolicyNo(!OPLUtils.isObjectNullOrEmpty(mst) && !OPLUtils.isObjectNullOrEmpty(mst.getMasterPolicyNo()) ? mst.getMasterPolicyNo().toUpperCase() : null);	
			}

			String strFullName = null;
			String age = null;
			if (!OPLUtils.isObjectNullOrEmpty(nomineePIDetails)) {
				if (PhaseMode.checkPhase2Enroll(appMaster.getOrgId())) {
					// phase 2
					response.setNameOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getName()) ? nomineePIDetails.getName().toUpperCase() : null);
				} else {
					// phase 1
					strFullName = setFullName(nomineePIDetails.getFirstName(), nomineePIDetails.getMiddleName(), nomineePIDetails.getLastName());
					response.setNameOfNominee(!OPLUtils.isObjectNullOrEmpty(strFullName) ? strFullName.toUpperCase() : null);
				}
				age = String.valueOf(CommonUtils.getAgeBydob(nomineePIDetails.getDob()));
				if (!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getGdName())) {
					response.setNameOfGuardian(nomineePIDetails.getGdName().toUpperCase());
					if (!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getGdRelationId()))
						response.setRelationId(nomineeDetailsV2.getGdRelationId());
				}
			}

			response.setAgeOfNominee(age);
			response.setInsurerOrgId(appMaster.getInsurerOrgId());
			response.setOrgId(appMaster.getOrgId());

			if (!OPLUtils.isObjectNullOrEmpty(transactionDetailsV2.getCoverEndDate()))
				response.setCoverEndDate(CommonUtils.sdf_dd_MM_yyyy.format(transactionDetailsV2.getCoverEndDate()));
			
			return response;
		} catch (Exception e) {
			log.error("Error while set application details in COI request class ------->", e);
		}
		return null;
	}

	private String setFullName(String firstName, String middleName, String lastName) {
		return (!OPLUtils.isObjectNullOrEmpty(firstName) ? firstName : "") + " " + (!OPLUtils.isObjectNullOrEmpty(middleName) ? middleName : "") + " " + (!OPLUtils.isObjectNullOrEmpty(lastName) ? lastName : "");
	}

	private static String getApplicantAddress(AddressMasterV3 addMst) {
		if (!OPLUtils.isObjectNullOrEmpty(addMst)) {
			return (!OPLUtils.isObjectNullOrEmpty(addMst.getAddressLine1()) ? addMst.getAddressLine1() : "") + (!OPLUtils.isObjectNullOrEmpty(addMst.getAddressLine2()) ? ", " + addMst.getAddressLine2() : "")
					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getCityName()) ? ", " + addMst.getCityName() : "") + (!OPLUtils.isObjectNullOrEmpty(addMst.getDistrict()) ? ", " + addMst.getDistrict() : "")
					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getStateName()) ? ", " + addMst.getStateName() : "") + (!OPLUtils.isObjectNullOrEmpty(addMst.getPincode()) ? ", " + addMst.getPincode() : "");
		}
		return null;
	}
	
	private static String getApplicantAddressNewDb(AddressMasterV2 addMst,String addressLine1,String addressLine2) {
		if (!OPLUtils.isObjectNullOrEmpty(addMst)) {
			return (!OPLUtils.isObjectNullOrEmpty(addressLine1) ? addressLine1 : "") + (!OPLUtils.isObjectNullOrEmpty(addressLine2) ? ", " + addressLine2 : "")
					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getCityName()) ? ", " + addMst.getCityName() : "") + (!OPLUtils.isObjectNullOrEmpty(addMst.getDistrict()) ? ", " + addMst.getDistrict() : "")
					+ (!OPLUtils.isObjectNullOrEmpty(addMst.getStateName()) ? ", " + addMst.getStateName() : "") + (!OPLUtils.isObjectNullOrEmpty(addMst.getPincode()) ? ", " + addMst.getPincode() : "");
		}
		return null;
	}

	@Override
	@Transactional
	public void saveStorageIdInLastTransactionDetails(Long storageId, Long lastTransactionDetailsId) {
		transactionRepo.updateStorageIdInTransaction(storageId, lastTransactionDetailsId);
	}
	
	@Override
	public boolean updateEnrollPushStatus(EnrollPushType enrollPush, Long appId, boolean status, Date date) {
		try {
			ApplicationPushStatus applPushStatus = null;
			Optional<ApplicationPushStatus> findById = appPushStatusRepo.findById(appId);
			boolean newApp = false;
			if(findById.isEmpty()) {
				newApp = true;
				applPushStatus = new ApplicationPushStatus();
				applPushStatus.setId(appId);
				/**IF APPLICATION IS LED*/
				if (enrollPush == EnrollPushType.BANK_OPT_OUT_PUSH || enrollPush == EnrollPushType.INSURER_OPT_OUT_PUSH
						|| enrollPush == EnrollPushType.BANK_NMN_DTLS_PUSH
						|| enrollPush == EnrollPushType.INSURER_NMN_DTLS_PUSH) {
					applPushStatus.setPhaseMode(PhaseModeEnum.PHASE_2.getId());
					applPushStatus.setMasterPush(true);
					applPushStatus.setMasterPushDate(date);
					applPushStatus.setBankPush(true);
					applPushStatus.setBankPushStatus(HttpStatus.OK.value());
					applPushStatus.setBankPushDate(date);
					applPushStatus.setInsurerPush(true);
					applPushStatus.setInsurerPushStatus(HttpStatus.OK.value());
					applPushStatus.setInsurerPushDate(date);
				}
			} else {
				applPushStatus = findById.get();
			}
			switch (enrollPush) {
			case MASTER_PUSH:
				if(newApp) {
					applPushStatus.setMasterPush(status);
					applPushStatus.setMasterPushDate(date);
				} else {
					appPushStatusRepo.updateMasterPushFlag(appId, status, date);
				}
				break;
			case BANK_PUSH:
				if(newApp) {
					applPushStatus.setBankPush(status);
					applPushStatus.setBankPushDate(date);
					applPushStatus.setBankPushStatus(status ? HttpStatus.OK.value() 
							: HttpStatus.INTERNAL_SERVER_ERROR.value());
				} else {
					appPushStatusRepo.updateBankPushFlag(appId, status, status ? HttpStatus.OK.value() 
							: HttpStatus.INTERNAL_SERVER_ERROR.value(), date);
				}
				break;
			case INSURER_PUSH:
				if(newApp) {
					applPushStatus.setInsurerPush(status);
					applPushStatus.setInsurerPushDate(date);
					applPushStatus.setInsurerPushStatus(status ? HttpStatus.OK.value() 
							: HttpStatus.INTERNAL_SERVER_ERROR.value());
				} else {
					appPushStatusRepo.updateInsurerPushFlag(appId, status, status ? HttpStatus.OK.value() 
							: HttpStatus.INTERNAL_SERVER_ERROR.value(), date);
				}
				break;
			case BANK_OPT_OUT_PUSH:
				if(newApp) {
					applPushStatus.setBankOptOutPush(status);
					applPushStatus.setBankOptOutPushDate(date);	
				} else {
					appPushStatusRepo.updateBankOptOutPushFlag(appId, status, date);
				}
				break;
			case INSURER_OPT_OUT_PUSH:
				if(newApp) {
					applPushStatus.setInsurerOptOutPush(status);
					applPushStatus.setInsurerOptOutPushDate(date);	
				} else {
					appPushStatusRepo.updateInsurerOptOutPushFlag(appId, status, date);
				}
				break;
			case BANK_NMN_DTLS_PUSH:
				if(newApp) {
					applPushStatus.setBankNmnDtlsPush(status);
					applPushStatus.setBankNmnDtlsPushDate(date);	
				} else {
					appPushStatusRepo.updateBankNmnDtlsPushFlag(appId, status, date);
				}
				break;
			case INSURER_NMN_DTLS_PUSH:
				if(newApp) {
					applPushStatus.setInsurerNmnDtlsPush(status);
					applPushStatus.setInsurerNmnDtlsPushDate(date);	
				} else {
					appPushStatusRepo.updateInsurerNmnDtlsPushFlag(appId, status, date);
				}
				break;
			default:
				break;
			}
			if(newApp) {
				appPushStatusRepo.save(applPushStatus);
			}
			return true;
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PUSH ENROLLMENT PUSH STATUS: ",e);
		}
		return false;
	}
	
	@Override
	public boolean updateEnrollPushStatusWithStatusCode(EnrollPushType enrollPush, Long appId, boolean status, Date date, Integer statusCode) {
		try {
			switch (enrollPush) {
			case BANK_PUSH:
				appPushStatusRepo.updateBankPushStatus(appId, statusCode);
				break;
			case INSURER_PUSH:
				appPushStatusRepo.updateInsurerPushStatus(appId, statusCode);
				break;
			default:
				break;
			}
			return true;
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PUSH ENROLLMENT PUSH STATUS: ",e);
		}
		return false;
	}

	/**GET NEW DATABASE JNS_MASTER_DATA APPLICATION MASTER*/
	@Override
	public ApplicationMasterBothSchemeProxy getJnsMasterDataApplicationMaster(Long schemeId,Long applicationId) throws IOException {
		ApplicationMasterBothSchemeProxy appMaster = null;
		if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId())) {
			PMSBY pmsby = pmsbyRepository.findByIdAndIsActiveTrue(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
				appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmsby, ApplicationMasterBothSchemeProxy.class);
				appMaster.setSchemeId(schemeId);
			}
		} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId())) {
			PMJJBY pmjjby = pmjjbyRepository.findByIdAndIsActiveTrue(applicationId);
			if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
				appMaster = MultipleJSONObjectHelper.getObjectFromObject(pmjjby,
						ApplicationMasterBothSchemeProxy.class);
				appMaster.setSchemeId(schemeId);
			}
		}
		return appMaster;
	}
	
	@Override
	public void insertApplcationPushStatus(Long applicationId,Integer phaseMode) {
		ApplicationPushStatus applicationPushStatus = new ApplicationPushStatus();
		applicationPushStatus.setId(applicationId);
		applicationPushStatus.setPhaseMode(phaseMode);
		appPushStatusRepo.save(applicationPushStatus);
		log.info("INSERTED APPLICATION PUSH STATUS TABLE APPLICATION ID -----------> ", applicationId);
	}
	
	@Override
	public String checkDedupeOrgIdWithCifUsingJnsMasterAppMaster(Integer schemeId, String cif, Long orgId)
			throws IOException {
//		Integer completedStatus = ApplicationStatus.ENROLL_COMPLETED.getId();
		return nativeQueryRepo.getUrn(orgId, cif, schemeId);
//		String urn = null;
//		if (Objects.equals(schemeId, SchemeMaster.PMSBY.getId().intValue())) {
//			urn = pmsbyRepository.getByOrgIdAndStatusAndCifAndSourceAndIsActiveTrue(orgId, completedStatus, cif);
//		} else if (Objects.equals(schemeId, SchemeMaster.PMJJBY.getId().intValue())) {
//			urn = pmjjbyRepository.getByOrgIdAndStatusAndCifAndSourceAndIsActiveTrue(orgId, completedStatus, cif);
//		}
//		return urn;
	}

	@Override
	public CommonResponse checkPremiumDeductionStatus(ApplicationMasterV3 appMaster,Long userId,Integer stageId,Integer status) throws IOException {
		try {
			ExpiredEnrollment expiredEnrollment = new ExpiredEnrollment();
			expiredEnrollment = convertData(appMaster, expiredEnrollment,stageId,status);
//			expiredEnrollment.setModifiedBy(authClientResponse.getUserId());
			expiredEnrollment.setModifiedBy(userId);
			expiredEnrollmentRepository.save(expiredEnrollment);
			return new CommonResponse("successfully rejected application", HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value(), Boolean.TRUE);
//		}
	} catch (Exception e) {
		log.error("error is getting while rejectApplication --> {}", appMaster.getId());
	}
	return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}
	
	
	private ExpiredEnrollment convertData(ApplicationMasterV3 applicationMaster, ExpiredEnrollment expiredEnrollment,int stageId,int status) {
		expiredEnrollment.setStageId(stageId);
		expiredEnrollment.setSchemeId(applicationMaster.getSchemeId());
		expiredEnrollment.setId(applicationMaster.getId());
		expiredEnrollment.setUrn(applicationMaster.getUrn());
		expiredEnrollment.setOrgId(applicationMaster.getOrgId());
		expiredEnrollment.setInsurerOrgId(applicationMaster.getInsurerOrgId());
		expiredEnrollment.setBranchId(applicationMaster.getBranchId());
		expiredEnrollment.setStatus(status);
		log.info("applicationMaster.getStatusChangeDate().toString() --->  '{}'", applicationMaster.getStatusChangeDate().toString());
		expiredEnrollment.setStatusChangeDate(applicationMaster.getStatusChangeDate());
		expiredEnrollment.setMessage(applicationMaster.getMessage());
		expiredEnrollment.setPremiumAmount(applicationMaster.getPremiumAmount());
		expiredEnrollment.setSource(applicationMaster.getApplicationMasterOtherDetails().getSource());
		expiredEnrollment.setChannelId(applicationMaster.getApplicationMasterOtherDetails().getChannel());
		expiredEnrollment.setGenderId(applicationMaster.getApplicantInfo().getGenderId());
		expiredEnrollment.setBranchStateId(applicationMaster.getApplicationMasterOtherDetails().getBranchStateId());
		expiredEnrollment.setBranchCityId(applicationMaster.getApplicationMasterOtherDetails().getBranchCityId());
		expiredEnrollment.setBranchLhoId(applicationMaster.getApplicationMasterOtherDetails().getBranchLhoId());
		expiredEnrollment.setBranchRoId(applicationMaster.getApplicationMasterOtherDetails().getBranchRoId());
		expiredEnrollment.setBranchZoId(applicationMaster.getApplicationMasterOtherDetails().getBranchZoId());
		expiredEnrollment.setRuralUrbanId(applicationMaster.getApplicationMasterOtherDetails().getRuralUrbanId());
//		expiredEnrollment.setPolicyYear(DateUtils.fetchPolicyYear(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialYear(DateUtils.fetchFinancialYear(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setPolicyMonth(DateUtils.fetchMonth(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialMonth(DateUtils.fetchMonth(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setPolicyDay(DateUtils.fetchDay(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setFinancialDay(DateUtils.fetchDay(applicationMaster.getCompletionDate()));
//		expiredEnrollment.setLastTransactionId(applicationMaster.getLastTransactionDetails().getId());
		expiredEnrollment.setCreatedDate(applicationMaster.getCreatedDate());
		expiredEnrollment.setCreatedBy(applicationMaster.getCreatedBy());
		expiredEnrollment.setModifiedDate(new Date());
//		expiredEnrollment.setModifiedBy(null);
		expiredEnrollment.setIsActive(Boolean.TRUE);
		expiredEnrollment.setDebitStatus(applicationMaster.getDebitStatus());
		return expiredEnrollment;
	}
	
	@Override
	public List<DedupeDataResponse> checkClaimDedupeData(Long claimId, Long schemeId, String certiNo,String firNo, String panchnamaNo,String postMtrmReportNo,Date certiDate,Date firDate, Date panchnamaDate,Date postMtrmReportDate) {
		try {
			String spName = DBNameConstant.JNS_INSURANCE + ".check_claim_dedupe";
			String data = reportRepository.getDataFromProducer(claimId, schemeId, certiNo,firNo, panchnamaNo,postMtrmReportNo,certiDate,firDate,panchnamaDate,postMtrmReportDate, spName);
			List<DedupeDataResponse> dedupeList = null;
			if(!OPLUtils.isObjectNullOrEmpty(data)) {				
				JSONObject jsonObject = new JSONObject(data);
				String str = jsonObject.getString("DATA");
				if(OPLUtils.isObjectNullOrEmpty(str)) {
					return Collections.emptyList();
				}
				if (!OPLUtils.isObjectNullOrEmpty(data)) {
					dedupeList = MultipleJSONObjectHelper.getListOfObjects(str, null, DedupeDataResponse.class);
				}
			}
			return dedupeList;
		} catch (Exception e) {
			log.error("Error is getting while call check_claim_dedupe --> {}", e);
			return Collections.emptyList();
		}
	}
	
	@Override
	public void setNomineePushFlagFalse(Long applicationId) {
		Date curruntDate = new Date();
		try {            		
			updateEnrollPushStatus(EnrollPushType.BANK_NMN_DTLS_PUSH, applicationId,false, curruntDate);
		}catch (Exception e) {
			log.error("EXCEPTION WHILE BANK NOMINEE DTLS PUSH FLAG UPDATE ---->", e);
		}
		try {            		
			updateEnrollPushStatus(EnrollPushType.INSURER_NMN_DTLS_PUSH, applicationId, false, curruntDate);
		}catch (Exception e) {
			log.error("EXCEPTION WHILE INSURER NOMINEE DTLS PUSH FLAG UPDATE ---->", e);
		}
	}
	
	@Override
	public void setOptOutPushFlagFalse(Long applicationId) {
		Date curruntDate = new Date();
		try {            		
			updateEnrollPushStatus(EnrollPushType.BANK_OPT_OUT_PUSH, applicationId, false, curruntDate);
		}catch (Exception e) {
			log.error("EXCEPTION WHILE BANK OPT OUT DTLS PUSH FLAG UPDATE ---->", e);
		}
		try {            		
			updateEnrollPushStatus(EnrollPushType.INSURER_OPT_OUT_PUSH, applicationId, false, curruntDate);
		}catch (Exception e) {
			log.error("EXCEPTION WHILE INSURER OPT OUT DTLS PUSH FLAG UPDATE ---->", e);
		}
	}
	
	
	@Override
	public void setInsurerClaimStatusPushFlagFalse(Long claimId) {
		Date curruntDate = new Date();
			try {            		
				clmMasterRepository.updateClaimInsurerPushFlagAndModified(curruntDate, claimId, false);
			}catch (Exception e) {
				log.error("EXCEPTION WHILE INSURER CLAIM STATUS PUSH FLAG UPDATE ---->", e);
			}
}
	@Override
	public void setBankClaimStatusPushFlagFalse(Long claimId) {
		Date curruntDate = new Date();
			try {
				clmMasterRepository.updateClaimBankPushFlagAndModified(curruntDate, claimId, false);
			}catch (Exception e) {
				log.error("EXCEPTION WHILE BANK CLAIM STATUS PUSH FLAG UPDATE ---->", e);
			}
}
	
	/**BANK AND INSURER PUSH FLAG DATA INSERT IN MASTER*/
	@Override
	public void insertEnrollAndClaimPushStatusInMaster(Long appId, boolean status, Integer type,Integer orgType, Date pushDate) {
		try {
			log.info("ENTER JNS MASTER APPLICATION PUSH STATUS TABLE APPLICATION ID -----------> "+ appId);
			ApplicationPushStatusV2 applicationPushStatusV2 = ApplicationPushStatusV2.builder().applicationId(appId).orgType(orgType).type(type).pushDate(pushDate)
					.isActive(true).build();
			appPushStatusV2Repo.save(applicationPushStatusV2);
			log.info("INSERTED JNS MASTER APPLICATION PUSH STATUS TABLE APPLICATION ID -----------> "+ appId);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PUSH ENROLLMENT OR CLAIM PUSH STATUS: ", e);
		}
	}
	
	/**INSERT INTO CONSENT_MAPPING*/
	@SuppressWarnings("static-access")
	@Override
	public void insertDataConsentMappingTable(ConsentMappingProxy consentMappingProxy) {
		try {
			log.info("ENTER INSERT CONSENT MAPPING TABLE -----------> "+ consentMappingProxy.getAppTypeValue());
			log.info("CONSENT TYPE ID -----------> "+ consentMappingProxy.getConsentTypeId());
			
			/**FETCH CONSENT MASTER FOR SAVE CONSENT MAPPING*/
			ConsentMaster consentMaster = consentMasterRepository.findByTypeIdAndIsActiveTrueAndCurrentActiveTrue(consentMappingProxy.getConsentTypeId());
			if(!OPLUtils.isObjectNullOrEmpty(consentMaster)) {
				/**FETCH CONSENT MAPPING FOR UPDATE CONSENT MAPPING*/
				ConsentMapping conMapping = consentMappingRepository.findByAppTypeValueAndConsentIdTypeIdAndConsentIdIsActiveTrue(consentMappingProxy.getAppTypeValue(),consentMaster.getTypeId());
				if(OPLUtils.isObjectNullOrEmpty(conMapping)) {
					conMapping = ConsentMapping.builder().consentId(consentMaster).consentDate(new Date()).appTypeValue(consentMappingProxy.getAppTypeValue())
							.appType(consentMappingProxy.getAppType()).userId(consentMappingProxy.getUserId()).build();
				}else {					
					conMapping.builder().consentId(consentMaster).consentDate(new Date()).appTypeValue(consentMappingProxy.getAppTypeValue())
					.appType(consentMappingProxy.getAppType()).userId(consentMappingProxy.getUserId()).build();
				}
				consentMappingRepository.save(conMapping);
				log.info("INSERTED CONSENT MAPPING TABLE -----------> "+ consentMappingProxy.getAppTypeValue());
			}else {
				log.info("CONSENT MASTER IS NULL CONSENT TYPE ID -----------> "+ consentMappingProxy.getConsentTypeId());
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE insertDataConsentMappingTable: ", e);
		}
	}
	
	@Override
	public boolean updateApplicationFailedAudit(Integer apiTypeId, Long appId, Long orgId) {
		try {
			ApplicationFailedAudit applicationFailedAudit = null;
			ApplicationFailedAudit appFailedAudit = applicationFailedAuditRepo.findByApplicationIdAndApiType(appId,
					apiTypeId);
			if (OPLUtils.isObjectNullOrEmpty(appFailedAudit)) {
				applicationFailedAudit = new ApplicationFailedAudit();
				applicationFailedAudit.setApplicationId(appId);
				applicationFailedAudit.setOrgId(orgId);
				applicationFailedAudit.setIsRetry(false);
				applicationFailedAudit.setPushFailedDate(new Date());
				applicationFailedAudit.setApiType(apiTypeId);
				applicationFailedAuditRepo.save(applicationFailedAudit);
			} else {
				applicationFailedAuditRepo.updateApplicationFailedAudit(new Date(), appFailedAudit.getId());
			}
			return true;
		} catch (Exception e) {
			log.error("EXCEPTION WHILE APPLICATION PUSH AUDIT: ", e);
		}
		return false;
	}
	
}
