package com.opl.jns.ere.utils;

import java.io.Serializable;

public class WebHookPayloadProxy implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String request;
	private String plainRequest;
	private String response;
	private String plainResponse;
	private String requestHeader;
	private String url;
	private String requestRefNumber;
	private String secretKey;

	private Long logAuditId;

	private String referenceId;

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Long getLogAuditId() {
		return logAuditId;
	}

	public void setLogAuditId(Long logAuditId) {
		this.logAuditId = logAuditId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getPlainRequest() {
		return plainRequest;
	}

	public void setPlainRequest(String plainRequest) {
		this.plainRequest = plainRequest;
	}

	public String getPlainResponse() {
		return plainResponse;
	}

	public void setPlainResponse(String plainResponse) {
		this.plainResponse = plainResponse;
	}

	public String getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(String requestHeader) {
		this.requestHeader = requestHeader;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getRequestRefNumber() {
		return requestRefNumber;
	}

	public void setRequestRefNumber(String requestRefNumber) {
		this.requestRefNumber = requestRefNumber;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	
}
