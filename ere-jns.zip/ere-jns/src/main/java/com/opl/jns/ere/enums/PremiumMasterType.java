package com.opl.jns.ere.enums;

public enum PremiumMasterType {

	CUSTOMER(1, "cutomer"),
	BANK(2, "bank");

    private Integer id;
    private String value;

    private PremiumMasterType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static PremiumMasterType fromId(Integer v) {
        for (PremiumMasterType c : PremiumMasterType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static PremiumMasterType fromValue(String v) {
        for (PremiumMasterType c : PremiumMasterType.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v : null);
    }

    public static PremiumMasterType[] getAll() {
        return PremiumMasterType.values();
    }

}
