package com.opl.jns.ere.enums;

public enum Source {
	OTHER_CHANNEL(1, "Enrolment through other channel","ETOC","Other Channel"), JANSURAKSHA(2, "JanSuraksha Portal","JNS","Assisted"),  LED(3, "Legacy Data"," LED","LED"), JANSURAKSHA_DIY(4, "JanSuraksha Portal DIY","JNSDIY","DIY");

	private Integer id;
	private String shortName;
	private String value;
	private String mode;

	private Source(Integer id, String value,String shortName,String mode) {
		this.id = id;
		this.value = value;
		this.shortName=shortName;
		this.mode=mode;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public String getShortName() {
		return shortName;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public static Source fromId(Integer v) {
		for (Source c : Source.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static Source[] getAll() {
		return Source.values();
	}
}
