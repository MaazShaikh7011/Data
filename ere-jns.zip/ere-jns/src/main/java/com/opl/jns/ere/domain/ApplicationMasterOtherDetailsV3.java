package com.opl.jns.ere.domain;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import java.util.Date;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "application_master_other_details",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE,indexes = {
		@Index(columnList = "source", name = DBNameConstant.JNS_INSURANCE +"_APP_MST_OTHER_SRC_IDX"),
		@Index(columnList = "ORG_ID,SCHEME_ID,source", name = DBNameConstant.JNS_INSURANCE +"_APP_MST_OTHER_ORG_SCH_SRC_IDX"),
		@Index(columnList = "ORG_ID,SCHEME_ID,APPLICATION_MASTER_ID", name = DBNameConstant.JNS_INSURANCE +"_APP_MST_OTHER_ORG_SCH_APP_MST_ID_IDX"),
		@Index(columnList = "ORG_ID,SCHEME_ID,BRANCH_STATE_ID", name = DBNameConstant.JNS_INSURANCE +"_APP_MST_OTHER_ORG_SCH_BR_ID_IDX"),
//		@Index(columnList = "type_of_verification", name = "type_of_verification_app_mst_other_idx"),
//		@Index(columnList = "branch_ro_id", name = "branch_ro_id_app_mst_other_idx"),
//		@Index(columnList = "branch_zo_id", name = "branch_zo_id_app_mst_other_idx"),
//		@Index(columnList = "branch_lho_id", name = "branch_lho_id_app_mst_other_idx"),
//		@Index(columnList = "branch_state_id", name = "branch_state_id_app_mst_other_idx"),
//		@Index(columnList = "branch_city_id", name = "branch_city_id_app_mst_other_idx")
})
public class ApplicationMasterOtherDetailsV3 {

	  	@Id
	  	@Column(name = "application_master_id")
	  	private Long id;

	    @OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	    @MapsId
	    @JoinColumn(name = "application_master_id")
	  	private ApplicationMasterV3 applicationMaster;
	    
		@Column(name = "scheme_id", nullable = true)
		private Integer schemeId;
		
		@Column(name = "org_id", nullable = true)
		private Long orgId;

	  	@Column(name = "source", nullable = true)
	    private Integer source;

	    @Column(name = "type_of_verification", nullable = true)
	    private Integer typeOfVerification;

	    @Column(name = "branch_ro_id", nullable = true)
	    private Long branchRoId;

	    @Column(name = "branch_zo_id", nullable = true)
	    private Long branchZoId;

	    @Column(name = "branch_lho_id", nullable = true)
	    private Long branchLhoId;
	    
	    @Column(name = "branch_state_id", nullable = true)
	    private Long branchStateId;
	    
	    @Column(name = "branch_city_id", nullable = true)
	    private Long branchCityId;
	    
	    @Column(name = "consent_for_auto_debit", nullable = true)
	    private String consentForAutoDebit;

	    @Column(name = "rural_urban_semi", nullable = true)
	    private String ruralUrbanSemi;
	    
	    @Column(name = "rural_urban_id", nullable = true)
	    private Integer ruralUrbanId;
	    
	    @Column(name = "channel_id", nullable = true)
	    private String channelId;
	    
	    @Column(name = "channel", nullable = true)
	    private Long channel;
	    
	    @Column(name = "bank_code", nullable = true)
	    private String bankCode;
	    
	    @Column(name = "branch_code", nullable = true)
	    private String branchCode;
	    
	    @Column(name = "branch_IFSC", nullable = true)
	    private String branchIFSC;
	    
	    @Column(name = "user_id_1", nullable = true)
	    private String userId1;
	    
	    @Column(name = "user_id_2", nullable = true)
	    private String userId2;
	    
		@Column(name = "is_dd_push", columnDefinition = "boolean default false")
		private Boolean isddPush = false;

		@Column(name = "is_dd_status_push", columnDefinition = "boolean default false")
		private Boolean isddStatusPush = false;

		@Column(name = "app_created_date", nullable = true)
		private Date appCreatedDate;
	     
}
