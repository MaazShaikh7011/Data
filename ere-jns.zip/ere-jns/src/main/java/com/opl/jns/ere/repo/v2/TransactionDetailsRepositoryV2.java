package com.opl.jns.ere.repo.v2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.v2.TransactionDetailsV2;


public interface TransactionDetailsRepositoryV2 extends JpaRepository<TransactionDetailsV2, Long> {

	TransactionDetailsV2 findByApplicationId(Long applicationId);
	TransactionDetailsV2 findFirstByApplicationIdOrderByIdDesc(Long applicationId);
	
	@Transactional
	@Modifying
	@Query(value = "update TransactionDetailsV2 set coiStorageId=:storageId where id=:id")
	void updateStorageIdInTransaction(@Param("storageId") Long utr,@Param("id") Long id);
}
