package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.*;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author ravi.thummar Date : 15-06-2023
 */

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "transaction_details",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
		@Index(columnList = "application_id,type,is_active", name = DBNameConstant.JNS_INSURANCE + "txn_dtls_appid_type_is_active_idx"),
		@Index(columnList = "insurer_master_id", name = DBNameConstant.JNS_INSURANCE + "insurer_master_id_idx"),
		@Index(columnList = "application_id,is_active", name = DBNameConstant.JNS_INSURANCE + "_TXN_DTLS_APPID_TYPE_IDX"),
})
public class TransactionDetailsV3 extends Auditor {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "transaction_details_seq_gen", sequenceName = "transaction_details_seq_gen", allocationSize = 1)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "application_id", nullable = false)
	private ApplicationMasterV3 applicationMaster;

	@Column(name = "cover_start_date", nullable = true)
	private Date coverStartDate;

	@Column(name = "cover_end_date", nullable = true)
	private Date coverEndDate;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Column(name = "year", nullable = true)
	private Integer year;

	@Convert(converter = AESOracle.class)
	@Column(name = "trans_utr", nullable = true)
	private String transUtr;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "trans_time_stamp", nullable = true)
	private Date transTimeStamp;

	@Column(name = "trans_amount", nullable = true)
	private Double transAmount;

	@Column(name = "trans_comment", nullable = true)
	private String transComment;

	@Column(name = "coi_storage_id", nullable = true)
	private Long coiStorageId;

    @Convert(converter = AESOracle.class)
	@Column(name = "master_policy_no", nullable = true)
	private String masterPolicyNo;

	@OneToOne(mappedBy = "lastTransactionDetails", cascade = CascadeType.ALL)
	private ApplicationMasterV3 applicationMasterV3;

	@ManyToOne
	@JoinColumn(name = "insurer_master_id", nullable = true)
	private InsurerMstDetailsV3 insurerMaster;

	@Column(name = "insurer_code")
	private String insurerCode;
	
	@Column(name = "is_update_manually", columnDefinition = "boolean default false")
	private Boolean isUpdateManually = false;

	@Column(name = "app_created_date", nullable = true)
	private Date appCreatedDate;

}
