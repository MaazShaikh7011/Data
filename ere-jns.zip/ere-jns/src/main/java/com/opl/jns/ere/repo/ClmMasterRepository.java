package com.opl.jns.ere.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.utils.constant.DBNameConstant;

public interface ClmMasterRepository extends JpaRepository<ClmMaster, Long> {
	
	public ClmMaster findByIdAndIsActiveTrue(long claimId);
	
	public ClmMaster findByIdAndOrgIdAndIsActiveTrue(long claimId,Long orgId);
	
	public ClmMaster findByIdAndInsurerOrgIdAndIsActiveTrue(long claimId,Long insurerOrgId);

	public ClmMaster findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(Long applicationId);
	
	public ClmMaster findFirstByUrnAndIsActiveTrueOrderByIdDesc(String urn);
	
	public Long countByApplicationIdAndIsActiveTrueAndStatusIn(Long applicationId, List<Integer> status);
	
	public List<ClmMaster> findByApplicationIdAndIsActiveTrue(Long applicationId);
	
	public List<ClmMaster> findAllByClmDetailsClmPIDetailsApAccountNumberAndSchemeIdAndIsActiveTrue(
			String customerAccountNumber, Integer schemeId);
	
	public List<ClmMaster> findByApplicationIdAndIsActiveTrueAndStatusOrderByIdDesc(Long applicationId,
			Integer claimStatus);
	
	public List<ClmMaster> findByStageIdAndIsActiveTrueAndApplicationIdOrderByIdDesc(Integer claimStatus,Long applicationId);
	
	public List<ClmMaster> findByStageIdInAndIsActiveTrueAndApplicationIdOrderByIdDesc(List<Integer> claimStatus,Long applicationId);
	public List<ClmMaster> findByApplicationIdAndIsActiveTrueAndStatusInOrderByIdDesc(Long applicationId,List<Integer> claimStatus);
	
	public ClmMaster findByIdAndStageIdAndIsActiveTrue(long claimId, int claimStageId);
	
//	@Query(nativeQuery = true,value = "select email from JNS_USERS.USERS where user_id=(:userId)")
//	public String getEmailByUserId(@Param("userId") Long userId);
	
    @Query(value = "SELECT email FROM "+DBNameConstant.JNS_USERS+".users WHERE user_id =:userId",nativeQuery = true)
    public String getEmailByUserId(@Param("userId") Long userId);
    
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET isBankClaimPush=:status,isBankClaimPushDate =:date WHERE id =:claimId")
	int updateClaimBankFlagAndModified(@Param("date") Date date,@Param("claimId") Long claimId,@Param("status") Boolean status);
	
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET isInsurerClaimPush=:status,isInsurerClaimPushDate =:date WHERE id =:claimId")
	int updateClaimInsurerFlagAndModified(@Param("date") Date date,@Param("claimId") Long claimId,@Param("status") Boolean status);
    
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET isBankClaimStatusPush=:status,isBankClaimStatusPushDate =:date WHERE id =:claimId")
	int updateClaimBankPushFlagAndModified(@Param("date") Date date,@Param("claimId") Long claimId,@Param("status") Boolean status);
	
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET isInsurerClaimStatusPush=:status,isInsurerClaimStatusPushDate =:date WHERE id =:claimId")
	int updateClaimInsurerPushFlagAndModified(@Param("date") Date date,@Param("claimId") Long claimId,@Param("status") Boolean status);
	
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET isPushed=true,modifiedDate =:date WHERE id =:claimId")
	int updatePushFlagAndModified(@Param("date") Date date,@Param("claimId") Long claimId);
	
	@Transactional
	@Modifying
	@Query("UPDATE ClmMaster SET stageId = 15, status = 12,modifiedDate = :modifiedDate WHERE stageId not in (:stageIds) and isActive = true and createdDate < :maxDateRange")
	public void updateClaimStageIdForExpiration(@Param("stageIds") List<Integer> stageIds, @Param("modifiedDate") Date modifiedDate, @Param("maxDateRange") Date maxDateRange);
	
	@Query("select id from ClmMaster a where (a.isBankClaimPush=false or a.isInsurerClaimPush=false)  and (claimDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and claimDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and stageId=:stageId and phaseMode=2")
	public List<Long> findAllByIsBankInsurerPushFlagNull(@Param("stageId") Integer stageId,@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select id from ClmMaster a where a.orgId=:orgId and a.schemeId=:schemeId and a.isBankClaimPush=false and (claimDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and claimDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and stageId=:stageId and phaseMode=2")
	public List<Long> findAllByIsBankPushFlagNullAndOrgIdAndSchemeId(@Param("stageId") Integer stageId,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId);
	
	@Query("select id from ClmMaster a where a.insurerOrgId=:orgId and a.schemeId=:schemeId and a.isInsurerClaimPush=false  and (claimDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and claimDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and stageId=:stageId and phaseMode=2")
	public List<Long> findAllByIsInsurerPushFlagNullAndOrgIdAndSchemeId(@Param("stageId") Integer stageId,@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId);
	
	@Query("select id from ClmMaster a where a.isInsurerClaimStatusPush=false and (modifiedDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and modifiedDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and phaseMode=2")
	public List<Long> findAllByIsInsurerStatusFlagNull(@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select id from ClmMaster a where a.insurerOrgId=:orgId and a.schemeId=:schemeId and a.isInsurerClaimStatusPush=false and (modifiedDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and modifiedDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and phaseMode=2")
	public List<Long> findAllByIsInsurerStatusFlagNullAndOrgIdAndSchemeId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId);
	
	@Query("select id from ClmMaster a where a.isBankClaimStatusPush=false and (modifiedDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and modifiedDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and phaseMode=2")
	public List<Long> findAllByIsBankStatusFlagNull(@Param("fromDate") String fromDate,@Param("toDate") String toDate);
	
	@Query("select id from ClmMaster a where a.orgId=:orgId and a.schemeId=:schemeId and a.isBankClaimStatusPush=false and (modifiedDate<=TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') and modifiedDate>=TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS')) and phaseMode=2")
	public List<Long> findAllByIsBankStatusAndOrgIdFlagNullAndOrgIdAndSchemeId(@Param("fromDate") String fromDate,@Param("toDate") String toDate,@Param("orgId") Long orgId,@Param("schemeId") Integer schemeId);

}
