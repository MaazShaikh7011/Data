package com.opl.jns.ere.repo;

import com.opl.jns.ere.domain.ConsentMaster;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsentMasterRepository extends JpaRepository<ConsentMaster,Long> {
    ConsentMaster findByTypeIdAndIsActiveTrueAndCurrentActiveTrue(Integer type);
    
    List<ConsentMaster> findByTypeIdInAndIsActiveTrueAndCurrentActiveTrue(List<Integer> type);

}
