package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CLM_PI_DETAILS", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmPIDetails {

	@Id
	@Column(name = "id")
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@MapsId
	@JoinColumn(name = "id")
	private ClmDetails clmDetails;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_account_number", nullable = true)
	private String apAccountNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_cif", nullable = true)
	private String apCif;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_first_name", nullable = true)
	private String apFirstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_middle_name", nullable = true)
	private String apMiddleName;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_last_name", nullable = true)
	private String apLastName;

	@Convert(converter = AESOracle.class)
	@Column(name = "ac_holder_name", nullable = true)
	private String acHolderName;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_kyc_id_1", nullable = true)
	private String apKycId1;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_kyc_id_number_1", nullable = true)
	private String apKycIdNumber1;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_pan", nullable = true)
	private String apPan;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_aadhaar", nullable = true)
	private String apAadhaar;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_ckyc_number", nullable = true)
	private String apCkycNumber;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "ap_dob", nullable = true)
	private Date apDob;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_address_line_1", nullable = true)
	private String apAddressLine1;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_address_line_2", nullable = true)
	private String apAddressLine2;

	@Convert(converter = AESOracle.class)
	@Column(name = "clm_name", nullable = true)
	private String clmName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "clm_first_name", nullable = true)
	private String clmFirstName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "clm_middle_name", nullable = true)
	private String clmMiddleName;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "clm_last_name", nullable = true)
	private String clmLastName;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "clm_dob", nullable = true)
	private Date clmDob;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "clm_address", nullable = true)
	private String clmAddress;
	
	@Convert(converter = AESOracle.class)
	@Column(name = "clm_address_line_1", nullable = true, columnDefinition = "varchar(255) default ''")
	private String clmAddressLine1;

	@Convert(converter = AESOracle.class)
	@Column(name = "clm_address_line_2", nullable = true, columnDefinition = "varchar(255) default ''")
	private String clmAddressLine2;

	@Convert(converter = AESOracle.class)
	@Column(name = "clm_account_number", nullable = true)
	private String clmAccountNumber;

	@Column(name = "clm_bank_name", nullable = true)
	private String clmBankName;

	@Column(name = "clm_branch_ifsc", nullable = true)
	private String clmBranchIfsc;

	@Column(name = "clm_kyc_id_1", nullable = true)
	private Integer clmKycId1;

	@Convert(converter = AESOracle.class)
	@Column(name = "clm_kyc_id_number_1", nullable = true)
	private String clmKycIdNumber1;

	@Column(name = "clm_kyc_id_2", nullable = true)
	private Integer clmKycId2;

	@Convert(converter = AESOracle.class)
	@Column(name = "clm_kyc_id_number_2", nullable = true)
	private String clmKycIdNumber2;

	@Convert(converter = AESOracle.class)
	@Column(name = "ap_father_husband_name", nullable = true)
	private String apFatherHusbandName;
}
