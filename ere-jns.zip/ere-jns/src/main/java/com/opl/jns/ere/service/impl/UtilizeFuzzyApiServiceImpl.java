package com.opl.jns.ere.service.impl;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.UtilizeFuzzyApiCall;
import com.opl.jns.ere.repo.UtilizeFuzzyApiCallRepository;
import com.opl.jns.ere.service.UtilizeFuzzyApiService;
import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.FuzzyApiStageEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * @author sandip.bhetariya
 *
 */

@Transactional
@Slf4j
@Service
public class UtilizeFuzzyApiServiceImpl implements UtilizeFuzzyApiService {

	@Autowired
	private UtilizeFuzzyApiCallRepository utilizeFuzzyApiCallRepository;

	@Override
	public Boolean handleFuzzyApiCall(Long applicationId, EnrollStageMaster stage, FuzzyApiStageEnum fuzzyApiStageEnum) throws Exception {
		log.info(" START HANDLE FUZZY API CALL   ApplicationId-->", applicationId);
		try {

			Optional<UtilizeFuzzyApiCall> data = utilizeFuzzyApiCallRepository.findByApplicationId(applicationId);
			if (data.isPresent()) {
				UtilizeFuzzyApiCall utilizeFuzzyApiCall = data.get();
				if (utilizeFuzzyApiCall.getStageId() == stage.getStageId() && Objects.equals(utilizeFuzzyApiCall.getStatus(), fuzzyApiStageEnum.getId())) {
					log.info(" CURRENT APPLICATION ALREADY IN PROGRESS ---  ApplicationId-->", applicationId);
					return Boolean.FALSE;
				} else if (utilizeFuzzyApiCall.getStageId() == stage.getStageId()) {
					utilizeFuzzyApiCall.setStatus(fuzzyApiStageEnum.getId());
					utilizeFuzzyApiCallRepository.save(utilizeFuzzyApiCall);
					return Boolean.TRUE;					
				} else {
					utilizeFuzzyApiCall.setStageId(stage.getStageId());
					utilizeFuzzyApiCall.setStatus(fuzzyApiStageEnum.getId());
					utilizeFuzzyApiCallRepository.save(utilizeFuzzyApiCall);
					return Boolean.TRUE;
				}

			} else {
				utilizeFuzzyApiCallRepository.save(UtilizeFuzzyApiCall.builder().applicationId(applicationId).stageId(stage.getStageId()).status(fuzzyApiStageEnum.getId()).createdDate(new Date()).build());
				log.info(" CURRENT APPLICATION ALREADY IS NEW ---  ApplicationId-->", applicationId);
				return Boolean.TRUE;
			}

			//			Optional<UtilizeFuzzyApiCall> findById = utilizeFuzzyApiCallRepository.findByApplicationIdAndStageIdAndStatus(applicationId, stage.getStageId(), fuzzyApiStageEnum.getId());
			//			if (findById.isPresent()) {
			//				log.info(" CURRENT APPLICATION ALREADY IN PROGRESS ---  ApplicationId-->", applicationId);
			//				return Boolean.FALSE;
			//			} else {
			//				utilizeFuzzyApiCallRepository.save(UtilizeFuzzyApiCall.builder().applicationId(applicationId).stageId(stage.getStageId()).status(fuzzyApiStageEnum.getId()).createdDate(new Date()).build());
			//				log.info(" CURRENT APPLICATION ALREADY IS NEW ---  ApplicationId-->", applicationId);
			//				return Boolean.TRUE;
			//			}

		} catch (Exception e) {
			log.error("HANDLE FUZZY API CALL GOT ERROR ---  ApplicationId-->" + applicationId, e);
			return Boolean.FALSE;
		} finally {
			log.info("STOP HANDLE FUZZY API CALL   ApplicationId-->", applicationId);
		}
	}

	@Override
	public void complateFuzzyApiCallStage(Long applicationId, EnrollStageMaster stage, FuzzyApiStageEnum fuzzyApiStageEnum) {
		try {

			log.info(" START COMPLATE FUZZY API CALL   ApplicationId-->", applicationId);
			Optional<UtilizeFuzzyApiCall> findById = utilizeFuzzyApiCallRepository.findByApplicationIdAndStageIdAndStatus(applicationId, stage.getStageId(), FuzzyApiStageEnum.IN_PROGRESS.getId());
			if (findById.isPresent()) {
				UtilizeFuzzyApiCall utilizeFuzzyApiCall = findById.get();
				utilizeFuzzyApiCall.setStatus(fuzzyApiStageEnum.getId());
				utilizeFuzzyApiCall.setModifiedDate(new Date());
				utilizeFuzzyApiCallRepository.save(utilizeFuzzyApiCall);
			}

		} catch (Exception e) {
			log.error("COMPLATE FUZZY API CALL GOT ERROR ---  ApplicationId-->" + applicationId, e);
		} finally {
			log.info("STOP HANDLE FUZZY API CALL   ApplicationId-->", applicationId);
		}
	}

}
