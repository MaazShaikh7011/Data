package com.opl.jns.ere.domain.v2;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author maaz.shaikh
 */

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "pmjjby", schema = DBNameConstant.JNS_MASTER_DATA, catalog = DBNameConstant.JNS_MASTER_DATA, indexes = {})
public class PMJJBY extends AppMasterV2 {

	private static final long serialVersionUID = -165876546464641L;

}
