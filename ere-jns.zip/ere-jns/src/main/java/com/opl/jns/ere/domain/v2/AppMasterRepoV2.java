package com.opl.jns.ere.domain.v2;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppMasterRepoV2<T extends AppMasterV2, ID> extends JpaRepository<T, ID> {

	T findByIdAndIsActiveTrue(final long id);
	
//	T findFirstByOrgIdAndIsActiveTrueAndCifAndStatus(final long orgId, String cif, final Integer applicationStatus);
	
	List<T> findByUrnAndOrgIdAndStatusAndIsActiveTrue(String urn,Long orgId,Integer status);
	
	List<T> findByUrnAndOrgIdAndStatusAndSourceNotAndIsActiveTrue(String urn,Long orgId,Integer status,Integer source);
	
	T findByUrnAndIsActiveTrue(String urn);
	
	List<T> findByOrgIdAndStatusInAndIsActiveTrue(Long orgId,List<Integer> status);
	
	List<T> findByCreatedByAndStatusInAndIsActiveTrue(Long userId,List<Integer> status,Pageable pageble);
	
	Long countByCreatedByAndStatusInAndIsActiveTrue(Long userId,List<Integer> status);

}
