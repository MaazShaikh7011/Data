package com.opl.jns.ere.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author krunal.prajapati 10/23/2023
 */

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit_webhook",schema = DBNameConstant.JNS_INSURANCE,catalog = DBNameConstant.JNS_INSURANCE, indexes = {
})
public class PayloadAuditWebHook implements Serializable {

		private static final long serialVersionUID = -2316291656766000221L;

		@Id
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payload_audit_webhook_seq_gen")
		@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "payload_audit_webhook_seq_gen", sequenceName = "payload_audit_webhook_seq_gen", allocationSize = 1)
		private Long id;

		@Column(name = "log_audit_id", nullable = true)
		private Long logAudit;

		@Column(name = "storage_id", nullable = true)
		private String storageId;

		@Column(name = "type_id", nullable = true)
		private Integer typeId;

		@Column(name = "created_date", nullable = true)
		private Date createdDate;

		@Column(name = "success", nullable = true)
		private Boolean success;

		public PayloadAuditWebHook() {
			super();
		}

		public PayloadAuditWebHook(String token) {
			super();
			this.createdDate = new Date();
		}

	}
