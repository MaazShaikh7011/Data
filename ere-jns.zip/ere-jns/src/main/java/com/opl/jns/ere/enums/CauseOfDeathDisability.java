package com.opl.jns.ere.enums;

import com.opl.jns.utils.enums.SchemeMaster;

public enum CauseOfDeathDisability {

	ACCIDENTAL_30_DAYS(1, "Accidental death within 30 days of lien period", SchemeMaster.PMJJBY.getId()),
	DEATH(2, "Death",SchemeMaster.PMJJBY.getId()),
	ACCIDENT(3, "Accidental",SchemeMaster.PMSBY.getId());

    private Integer id;
    private String value;
    private Long schemeId;

    private CauseOfDeathDisability(Integer id, String value, Long schemeId) {
        this.id = id;
        this.value = value;
        this.schemeId = schemeId;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static CauseOfDeathDisability fromId(Integer v) {
        for (CauseOfDeathDisability c : CauseOfDeathDisability.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static CauseOfDeathDisability fromBankValue(String v) {
        for (CauseOfDeathDisability c : CauseOfDeathDisability.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static CauseOfDeathDisability[] getAll() {
        return CauseOfDeathDisability.values();
    }

}
