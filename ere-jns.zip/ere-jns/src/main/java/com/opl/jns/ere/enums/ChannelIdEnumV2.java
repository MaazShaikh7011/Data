package com.opl.jns.ere.enums;

public enum ChannelIdEnumV2 {	
	BC(5l, "BC"),
	BRANCH_ASSITED(1l, "Branch Assisted"),
	DIY_MOBILE(4l, "DIY Mobile"),
	DIY_WEB(3l, "DIY Web"),
	EBANKING(10l, "EBANKING"),
	MOBILE(7l, "MOBILE"),
	BC_CHANNEL(5l, "BC-Channel"),
	MOB(7l, "MOB"),
	MB(7l, "MB"),
	F(19l, "F"),
	I(10l, "I"),
	M(7l, "M"),
	BRANCH(5l, "Branch"),
	WEBSITE(9l, "Website"),
	G(7l, "G"),
	KBS(5l, "KBS"),
	CB(5l, "CB"),
	FI(19l, "FI"),
	IN(10l, "IN"),
	CDCIBWY(10l, "CDCIBWY"),
	CDCIDBU(18l, "CDCIDBU"),
	CDCIFIT(5l, "CDCIFIT"),
	CDCIMBS(7l, "CDCIMBS"),
	CDCIWHT(12l, "CDCIWHT");
	
	private Long id;
	private String shortName;

	private ChannelIdEnumV2(Long id,String shortName) {
		this.id = id;
		this.shortName=shortName;
	}

	public Long getId() {
		return id;
	}

	public String getShortName() {
		return shortName;
	}

	public static ChannelIdEnumV2 fromId(Integer v) {
		for (ChannelIdEnumV2 c : ChannelIdEnumV2.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ChannelIdEnumV2[] getAll() {
		return ChannelIdEnumV2.values();
	}
	
	 public static ChannelIdEnumV2 fromValue(String v) {
	        for (ChannelIdEnumV2 c : ChannelIdEnumV2.values()) {
	            if (c.shortName.equalsIgnoreCase(v)) {
	                return c;
	            }
	        }
	        throw new IllegalArgumentException(v != null ? v : null);
	    }
}
