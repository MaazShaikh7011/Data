package com.opl.jns.ere.enums;

public enum TemplateMasterType {

	COI(1, "coi"),
    CONSENT(2, "consent");

    private Integer id;
    private String value;

    private TemplateMasterType(Integer id, String value) {
        this.id = id;
        this.value = value;
    }

    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public static TemplateMasterType fromId(Integer v) {
        for (TemplateMasterType c : TemplateMasterType.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static TemplateMasterType fromValue(String v) {
        for (TemplateMasterType c : TemplateMasterType.values()) {
            if (c.value.equalsIgnoreCase(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v : null);
    }

    public static TemplateMasterType[] getAll() {
        return TemplateMasterType.values();
    }
}
