package com.opl.jns.ere.domain;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CLM_NOMINEE_DETAILS", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE)
public class ClmNomineeDetails {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "clm_nominee_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "clm_nominee_details_seq_gen", sequenceName = "clm_nominee_details_seq_gen", allocationSize = 1)
	private Long id;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "claim_id")
	private ClmMaster clmMaster;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "address_id", referencedColumnName = "id")
	private ClmAddressMaster clmAddressMaster;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "clmNomineeDetails", optional = false)
	@PrimaryKeyJoinColumn
	private ClmNomineePIDetails clmNomineePIDetails;

	@Column(name = "relation_id", nullable = true)
	private Integer relationId;

	@Convert(converter = AESOracle.class)
	@Column(name = "mobile_number", nullable = true, columnDefinition = "varchar(255) default ''")
	private String mobileNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "email", nullable = true, columnDefinition = "varchar(255) default ''")
	private String email;

	@Column(name = "gd_relation_id", nullable = true)
	private Integer gdRelationId;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_mobile", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdMobile;

	@Convert(converter = AESOracle.class)
	@Column(name = "gd_email", nullable = true, columnDefinition = "varchar(255) default ''")
	private String gdEmail;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = false)
	private Boolean isActive;

	@Column(name = "nominee_gender_id")
	private Integer nomineeGenderId;
}
