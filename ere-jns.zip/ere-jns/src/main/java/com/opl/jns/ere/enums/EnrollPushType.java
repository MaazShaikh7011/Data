package com.opl.jns.ere.enums;

/**
 * THIS ENUM IS USED TO UPDATE ENROLLMENT PUSH STATUS TO THE INTERNAL, BANKS AND
 * INSURER (TABLE: ApplicationPushStatus)
 * 
 * @author harshit.suhagiya
 * @date 01-Mar-2024
 */
public enum EnrollPushType {

	MASTER_PUSH(1, "Master Push"), BANK_PUSH(2, "Bank Push"), INSURER_PUSH(3, "Insurer Push"),
	BANK_OPT_OUT_PUSH(4, "Bank OPT OUT Push"), INSURER_OPT_OUT_PUSH(5, "Insurer OPT OUT Push"),
	BANK_NMN_DTLS_PUSH(6, "Bank Nominee Details Push"), INSURER_NMN_DTLS_PUSH(7, "Insurer Nominee Details Push"),
	PUSH_CLAIM_TO_BANK(13, "Bank Claim Push"), PUSH_CLAIM_TO_INSURER(15, "Insurer Claim Push"),
	PUSH_CLAIM_STATUS_TO_BANK(11, "Bank Claim Status Push"), PUSH_CLAIM_STATUS_TO_INSURER(16, "Insurer Claim Status Push");

	private Integer id;
	private String value;

	private EnrollPushType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static EnrollPushType fromId(Integer id) {
		for (EnrollPushType c : EnrollPushType.values()) {
			if (c.id.equals(id)) {
				return c;
			}
		}
		throw new IllegalArgumentException(id != null ? id.toString() : null);
	}

	public static EnrollPushType[] getAll() {
		return EnrollPushType.values();
	}
}
