package com.opl.jns.ere.repo.v2;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.v2.AppMasterRepoV2;
import com.opl.jns.ere.domain.v2.PMJJBY;

/**
 * @author maaz.shaikh
 *
 */
public interface PmjjbyRepository extends AppMasterRepoV2<PMJJBY, Long> {

//	@Query(value = "select p.urn from jns_master.pmjjby p "
//			+ "inner join jns_master.applicant_pi_details api on api.id=p.id and api.cif=jns_users.\"encvalue\"(:cif) "
//			+ "where p.org_id=:orgId and p.status=:applicationStatus and p.is_active=1 and p.source != 3", nativeQuery = true)
//	public String getByOrgIdAndStatusAndCifAndSourceAndIsActiveTrue(@Param("orgId") Long orgId,@Param("applicationStatus") Integer applicationStatus,@Param("cif") String cif);


	@Query("""
			select p from PMJJBY p 
			inner join ApplicantPIDetails api on api.id=p.id and api.accountNumber=:accountNumber 
			where p.orgId=:orgId and p.status=:applicationStatus and p.isActive=true 
			""")
	public List<PMJJBY> findByOrgIdAndStatusAndIsActiveTrueAndAccountNumber(@Param("orgId") Long orgId,@Param("applicationStatus") Integer applicationStatus,@Param("accountNumber") String accountNumber);
	
	@Query("""
		     select p from PMJJBY p 
			 inner join ApplicantPIDetails pd on pd.id = p.id and pd.accountNumber=:accountNumber 
			 where p.orgId=:orgId and p.status=:applicationStatus and p.source!=:source and p.isActive=true 
			 """)
	public List<PMJJBY> findByOrgIdAndStatusAndSourceNotAndIsActiveTrueAndAccountNumber(@Param("orgId") Long orgId,@Param("applicationStatus") Integer applicationStatus,@Param("accountNumber") String accountNumber,@Param("source") Integer source);

	@Transactional
	@Modifying
	@Query("UPDATE PMJJBY ap SET ap.status =:applicationStatus,ap.statusChangeDate =:modifiedDate,ap.modifiedDate = :modifiedDate WHERE ap.id IN (:applicationIds) and ap.isActive = true ")
	public void updateOptOutStatusByIds(@Param("applicationStatus") Integer applicationStatus,@Param("applicationIds") List<Long> applicationIds, @Param("modifiedDate") Date modifiedDate);
	
	
	@Query("SELECT DISTINCT branchRoId FROM PMJJBY p WHERE p.completionDate BETWEEN :startDate AND :endDate AND p.orgId=:orgId AND branchRoId IS NOT NULL")
	public List<Long> getRoIdList(@Param("orgId") Long orgId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
	
	@Query("SELECT DISTINCT branchZoId FROM PMJJBY p WHERE p.completionDate BETWEEN :startDate AND :endDate AND p.orgId=:orgId AND branchZoId IS NOT NULL")
	public List<Long> getZoIdList(@Param("orgId") Long orgId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
}
