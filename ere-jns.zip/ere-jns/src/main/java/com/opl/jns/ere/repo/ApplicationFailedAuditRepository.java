package com.opl.jns.ere.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ApplicationFailedAudit;

public interface ApplicationFailedAuditRepository extends JpaRepository<ApplicationFailedAudit, Long> {

	ApplicationFailedAudit findByApplicationIdAndApiType(Long appId, Integer apiType);

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationFailedAudit SET retryDate =:date, isRetry=true WHERE id =:id ")
	int updateApplicationFailedAudit(@Param("date") Date date, @Param("id") Long id);

	@Query("select asp.applicationId from ApplicationFailedAudit asp "
			+ " where asp.pushFailedDate >= TO_DATE(:fromDate, 'YYYY-MM-DD HH24:MI:SS') and asp.pushFailedDate <= TO_DATE(:toDate, 'YYYY-MM-DD HH24:MI:SS') "
			+ "and asp.apiType=:type and asp.isRetry = false order by asp.pushFailedDate asc")
	public List<Long> fetchFailedApplication(@Param("fromDate") String fromDate, @Param("toDate") String toDate,
			@Param("type") Integer type, Pageable pageable);
}
