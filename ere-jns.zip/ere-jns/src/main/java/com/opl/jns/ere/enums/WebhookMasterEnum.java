package com.opl.jns.ere.enums;

/**
 * @author Maaz Shaikh
 * Date : 04-08-2023
 */
public enum WebhookMasterEnum {

	UPDATE_CLAIM_STATUS_TO_BANK_BY_INSURER(1),
	UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_OTHER_CHANEL_API(2),
	UPDATE_CLAIM_STATUS_AND_DOCS_TO_JS_BY_BANK_THROUGH_ASSISTED_MODE(3),
	UPDATE_CLAIM_STATUS_TO_INSURER_BY_JS(4);


	private Integer id;

	private WebhookMasterEnum(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public static WebhookMasterEnum fromId(Integer v) {
		for (WebhookMasterEnum c : WebhookMasterEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static WebhookMasterEnum[] getAll() {
		return WebhookMasterEnum.values();
	}

}
