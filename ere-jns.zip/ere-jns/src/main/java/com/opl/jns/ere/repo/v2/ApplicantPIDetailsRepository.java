package com.opl.jns.ere.repo.v2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.v2.ApplicantPIDetails;

/**
 * @author maulik.panchal Date : 19-01-2024
 */
public interface ApplicantPIDetailsRepository extends JpaRepository<ApplicantPIDetails, Long> {

	List<ApplicantPIDetails> findByAccountNumber(String accountNo);
	
	List<ApplicantPIDetails> findByAcHolderName(String name);
}
