package com.opl.jns.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.ere.domain.ClmAddressMaster;

public interface ClmAddressMasterRepository extends JpaRepository<ClmAddressMaster, Long> {

}
