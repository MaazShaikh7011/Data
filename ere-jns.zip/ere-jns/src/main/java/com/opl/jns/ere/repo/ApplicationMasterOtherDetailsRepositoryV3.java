package com.opl.jns.ere.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;

public interface ApplicationMasterOtherDetailsRepositoryV3
		extends JpaRepository<ApplicationMasterOtherDetailsV3, Long> {

	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterOtherDetailsV3 SET isddPush = true,isddStatusPush = true WHERE id =:id")
	public void updateIsDDPushFlag(@Param("id") Long id);
	
	@Transactional
	@Modifying
	@Query("UPDATE ApplicationMasterOtherDetailsV3 SET isddStatusPush = true WHERE id =:id")
	public void updateIsDDStatusPushFlag(@Param("id") Long id);
	
	@Query("select source from ApplicationMasterOtherDetailsV3 a where a.id =:applicationId")
	public Integer getSouceByApplicationId(@Param("applicationId") Long applicationId); 
	
	@Query("select id from ApplicationMasterOtherDetailsV3 a where a.applicationMaster.stageId = 6 and a.isddStatusPush=false order by id asc")
	Page<Long> getIdsByIsDedupeStatusPushFalse(PageRequest page);
	
	@Query("select id from ApplicationMasterOtherDetailsV3 a where a.applicationMaster.stageId = 6 and a.isddPush=false order by id asc")
	Page<Long> getIdsByIsDedupePushFalse(PageRequest page);

}
