package com.opl.jns.ere.enums;

public enum SupportAuditAction {

	EMAIL_EDIT(1, "Email edited"), MOBILE_NO_EDIT(2, "Mobile number edited"), USER_LOCK_UNLOCK(3, "user lock/unlock"),
	PASSWORD_RESET(4, "password reseted");

	private Integer id;
	private String value;

	private SupportAuditAction(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static SupportAuditAction fromId(Integer v) {
		for (SupportAuditAction c : SupportAuditAction.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static SupportAuditAction fromValue(String v) {
		for (SupportAuditAction c : SupportAuditAction.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v : null);
	}

	public static SupportAuditAction[] getAll() {
		return SupportAuditAction.values();
	}
}
