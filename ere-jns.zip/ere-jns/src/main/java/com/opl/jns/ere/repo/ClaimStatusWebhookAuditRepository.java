package com.opl.jns.ere.repo;

import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.ere.domain.ClaimStatusWebhookAudit;

/**
 * @author Maaz Shaikh
 * Date : 04-08-2023
 */
public interface ClaimStatusWebhookAuditRepository extends JpaRepository<ClaimStatusWebhookAudit, Long> {
	
	List<ClaimStatusWebhookAudit> findAllByWebhookStatusAndIsActiveTrue(Integer status);
	
    @Query("select cs from ClaimStatusWebhookAudit cs where cs.webhookStatus NOT IN (:claimStatus) and cs.isActive=true order by id")
    public List<ClaimStatusWebhookAudit> findAllByWebhookStatusAndWebhookMasterIdIsActiveTrue(@Param("claimStatus") Integer claimStatus);
	
    
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ClaimStatusWebhookAudit SET isActive=false WHERE claimId =:claimId AND isActive=true")
	void isActiveFalseByClaimId(@Param("claimId") Long claimId);

	ClaimStatusWebhookAudit findFirstByClaimIdAndWebhookMasterIdAndIsActiveTrue(Long claimId,Integer webhookStatusId);

	ClaimStatusWebhookAudit findByIdAndIsActiveTrue(Long logId);	
}
