package com.opl.jns.ere.service;

import com.opl.jns.utils.enums.EnrollStageMaster;
import com.opl.jns.utils.enums.FuzzyApiStageEnum;

/**
 * @author sandip.bhetariya
 *
 */
public interface UtilizeFuzzyApiService {

	Boolean handleFuzzyApiCall(Long applicationId, EnrollStageMaster stage, FuzzyApiStageEnum fuzzyApiStageEnum) throws Exception;

	void complateFuzzyApiCallStage(Long applicationId, EnrollStageMaster premiumDeduction, FuzzyApiStageEnum completed);

}
