package com.opl.jns.ere.domain;

import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * @author ravi.thummar Date : 15-06-2023
 */

@Setter
@Getter
//@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_master", schema = DBNameConstant.JNS_INSURANCE, catalog = DBNameConstant.JNS_INSURANCE, indexes = {
		@Index(columnList = "urn,is_active,stage_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_urn_actv_stg_idx"),
		@Index(columnList = "org_Id,scheme_id,urn,is_active,stage_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_org_schm_urn_stg_actv_idx"),
		@Index(columnList = "org_Id,scheme_id,is_active,account_number,stage_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_org_schm_actv_acc_stg_idx"),
		@Index(columnList = "org_Id,scheme_id,is_active,cif,application_status", name = DBNameConstant.JNS_INSURANCE + "_app_master_org_schm_actv_cif_sts_idx"),
		@Index(columnList = "is_active,account_number,cif,application_status", name = DBNameConstant.JNS_INSURANCE + "_app_master_actv_acc_cif_sts_idx"),
		@Index(columnList = "scheme_id,is_active,account_number,cif,application_status", name = DBNameConstant.JNS_INSURANCE + "_app_master_schm_actv_acc_cif_sts_idx"),
		@Index(columnList = "scheme_id,is_active,account_number,stage_id,user_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_schm_actv_acc_stg_usr_idx"),
		@Index(columnList = "is_active,account_number,stage_id,cif", name = DBNameConstant.JNS_INSURANCE + "_app_master_actv_acc_stg_cif_idx"),
		@Index(columnList = "scheme_id,is_active,account_number,stage_id,cif", name = DBNameConstant.JNS_INSURANCE + "_app_master_schm_actv_acc_stg_cif_idx"),
		@Index(columnList = "is_active,stage_id,created_date", name = DBNameConstant.JNS_INSURANCE + "_app_master_actv_acc_stg_crd_idx"),
		@Index(columnList = "insurer_org_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_insorg_idx"),
		@Index(columnList = "org_id,scheme_id,stage_id,modified_date,is_active,branch_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_org_schm_stg_mfd_actv_brn"),
		@Index(columnList = "org_id,scheme_id,stage_id,status_change_date,is_active,branch_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_org_schm_stg_scd_actv_brn"),
		@Index(columnList = "org_id,scheme_id,stage_id,branch_id", name = DBNameConstant.JNS_INSURANCE + "_APP_MST_ORG_SCH_BRANCH_IDX"),
		@Index(columnList = "org_id,scheme_id,stage_id,branch_id", name = DBNameConstant.JNS_INSURANCE + "_APP_MST_ORG_SCH_BRANCH_IDX"),
		@Index(columnList = "org_id,scheme_id,id", name = DBNameConstant.JNS_INSURANCE + "_APP_MASTER_ORG_SCHM_ID"),
		@Index(columnList = "last_transaction_id", name = DBNameConstant.JNS_INSURANCE + "_app_master_last_transaction_id_idx"),
		@Index(columnList = "is_active,user_id,stage_id", name = DBNameConstant.JNS_INSURANCE + "_APP_MST_IS_ACTIVE_USER_ID_STAGE_ID"),
		@Index(columnList = "is_active,user_id", name = DBNameConstant.JNS_INSURANCE + "_APP_MST_IS_ACTIVE_USER_ID"),

})
public class ApplicationMasterV3 extends Auditor {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "application_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_INSURANCE, name = "application_master_seq_gen", sequenceName = "application_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "urn", nullable = true)
	private String urn;

	@Column(name = "scheme_id", nullable = true)
	private Integer schemeId;

	@Convert(converter = AESOracle.class)
	@Column(name = "account_number", nullable = true)
	private String accountNumber;

	@Convert(converter = AESOracle.class)
	@Column(name = "cif", nullable = true)
	private String cif;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "user_id", nullable = true)
	private Long userId;

	@Column(name = "branch_id", nullable = true)
	private Long branchId;

	@Column(name = "stage_id", nullable = true)
	private Integer stageId;

	@Column(name = "enrollment_date", nullable = true)
	private Date enrollmentDate;
	
	@Column(name = "completion_date", nullable = true)
	private Date completionDate;

	@Convert(converter = DateEncryptorAes.class)
	@Column(name = "dob", nullable = true)
	private Date dob;

	@Column(name = "premium_amount", nullable = true)
	private Double premiumAmount;

//	@Column(name = "is_pushed", nullable = true)
//	private Boolean isPushed;
//
//	@Column(name = "IS_PUSHED_TO_MASTER", nullable = true)
//	private Boolean isPushedToMaster;


	@Column(name = "application_status", nullable = true)
	private Integer applicationStatus;

	@Column(name = "status_change_date", nullable = true)
	private Date statusChangeDate;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	@Column(name = "message", nullable = true)
	private String message;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;
	
	@Column(name = "IS_BANK_ENROLL_STATUS_PUSH", nullable = true)
	private Boolean isBankEnrollStatusPush;
	
	@Column(name = "IS_INSURER_ENROLL_STATUS_PUSH", nullable = true)
	private Boolean isInsurerEnrollStatusPush;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "applicationMaster", optional = false)
	@PrimaryKeyJoinColumn
	private ApplicationMasterOtherDetailsV3 applicationMasterOtherDetails;

//	cascade = CascadeType.ALL
//	@LazyGroup("applicant")
//	@LazyToOne(LazyToOneOption.FALSE)
//	@LazyCollection(LazyCollectionOption.FALSE)
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "applicationMaster")
	private ApplicantInfo applicantInfo;

	@OneToMany(mappedBy = "applicationMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<NomineeDetails> nomineeDetails;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "last_transaction_id")
	private TransactionDetailsV3 lastTransactionDetails;

	@OneToMany(mappedBy = "applicationMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<TransactionDetailsV3> transactions;
	
	@Column(name = "enroll_type", nullable = true)
	private Integer enrollType;
	
	@Column(name = "debit_status", nullable = true)
	private Integer debitStatus;
}
