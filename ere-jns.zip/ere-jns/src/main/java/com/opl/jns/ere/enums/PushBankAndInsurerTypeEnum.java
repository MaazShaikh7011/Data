package com.opl.jns.ere.enums;

public enum PushBankAndInsurerTypeEnum {

	ENROLLMENT_PUSH(1, "Enrollment push"), OPT_OUT_PUSH(2, "Opt-out push"),
	NOMINEE_UPDATE_PUSH(3, "Nominee update push"), CLAIM_PUSH(4, "Claim push"),
	CLAIM_STATUS_PUSH_BANK_INSURER(5, "Claim status push bank/insurer");

	private Integer id;
	private String value;

	private PushBankAndInsurerTypeEnum(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static PushBankAndInsurerTypeEnum fromId(Integer v) {
		for (PushBankAndInsurerTypeEnum c : PushBankAndInsurerTypeEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static PushBankAndInsurerTypeEnum fromBankValue(String v) {
		for (PushBankAndInsurerTypeEnum c : PushBankAndInsurerTypeEnum.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static PushBankAndInsurerTypeEnum[] getAll() {
		return PushBankAndInsurerTypeEnum.values();
	}

}
