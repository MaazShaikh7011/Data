package com.opl.jns.nabard.bank.external.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "9. NomineeUpdate API", description = "API to update Bank/Insurer for Nominee updation from JS portal")
public class OtherChannelNomineeUpdateController {

	@Autowired
	public FactoryService factoryService;

	@PostMapping(value = "/updateNomineeAPI", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = Constants.STR_19, summary = Constants.NOMINEE_UPDATE_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_NOMINEE_EXAMPLE, description = Constants.UPDATE_NOMIEE_DESC),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = NomieeUpdateResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_NOMINEE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<NomieeUpdateResponse> updateNomineeAPI(
			@Valid @RequestBody NomineeUpdateRequest nomineeRequest, HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL NOMINEE UPDATE DETAILS ----------------> " + nomineeRequest.getToken());
		NomieeUpdateResponse nomieeUpdateResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(nomineeRequest.getOrgId())) {
				return new ResponseEntity<>(
						new NomieeUpdateResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			nomieeUpdateResponse = factoryService.otherChannelNomineeUpdate(nomineeRequest, nomineeRequest.getToken());
			log.info("END OTHER CHANNEL NOMINEE UPDATE DETAILS ----------------> " + nomieeUpdateResponse.getToken());
			return new ResponseEntity<>(nomieeUpdateResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL NOMINEE UPDATE DETAILS REQUEST  ---"
					+ nomieeUpdateResponse.getToken() + "---", e);
			return new ResponseEntity<>(
					new NomieeUpdateResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

}
