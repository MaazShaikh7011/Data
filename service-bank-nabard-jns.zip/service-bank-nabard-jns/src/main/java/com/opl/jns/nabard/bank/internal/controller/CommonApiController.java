package com.opl.jns.nabard.bank.internal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "2. Common API", description = "For Opt-out, Nominee Update, COI regeneration and Assisted Mode Claim registration ")
public class CommonApiController {

	@Autowired
	private FactoryService factoryService;

	@PostMapping(value = "/getAccHolderList")
	@Operation(operationId = Constants.STR_9, summary = CommonUtils.GET_ACC_HOLDERlIST, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.GET_ACC_HOLDERlIST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_ACC_HOLDER_LIST),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = AccHolderListResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.GET_ACC_HOLDERlIST_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_ACC_HOLDER_LIST),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<AccHolderListResponse> getAccHolderList(
			@Valid @RequestBody AccHolderListRequest accHolderListRequest, HttpServletRequest httpServletRequest) {
		log.info("START GET ACCOUNT HOLDER LIST ----------------> " + accHolderListRequest.getToken());
		AccHolderListResponse getAccHolderLstRes = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getOrgId())) {
				return new ResponseEntity<>(
						new AccHolderListResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			if (!OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getAccountNumber())
					&& OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getDob())) {
				return new ResponseEntity<>(
						new AccHolderListResponse(HttpStatus.BAD_REQUEST.value(), "dob can not be null", false),
						HttpStatus.OK);
			}
			getAccHolderLstRes = factoryService.getAccHolderList(accHolderListRequest, accHolderListRequest.getToken());
			log.info("END GET ACCOUNT HOLDER LIST ----------------> " + getAccHolderLstRes.getToken());
			return new ResponseEntity<>(getAccHolderLstRes, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET ACCOUNT HOLDER LIST REQUEST  ---" + getAccHolderLstRes.getToken() + "---",
					e);
			return new ResponseEntity<>(
					new AccHolderListResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getPolicyDetails")
	@Operation(operationId = Constants.STR_10, summary = CommonUtils.POLICY_DETAILS_FETCH, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.POLICY_DETAILS_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_UPDATE_OPTOUT),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PolicyDetailsResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.POLICY_DETAILS_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_POLICY_HOLDER),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PolicyDetailsResponse> getPolicyDetails(
			@Valid @RequestBody PolicyDetailsRequest policyDetailsRequest, HttpServletRequest httpServletRequest) {
		log.info("START GET POLICY DETAILS ----------------> " + policyDetailsRequest.getToken());
		PolicyDetailsResponse policyDetailsResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(policyDetailsRequest.getOrgId())) {
				return new ResponseEntity<>(
						new PolicyDetailsResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			policyDetailsResponse = factoryService.getPolicyDetails(policyDetailsRequest,
					policyDetailsRequest.getToken());
			log.info("END GET POLICY DETAILS ----------------> " + policyDetailsRequest.getToken());
			return new ResponseEntity<>(policyDetailsResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET POLICY DETAILS REQUEST  ---" + policyDetailsResponse.getToken() + "---", e);
			return new ResponseEntity<>(
					new PolicyDetailsResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

}
