package com.opl.jns.nabard.bank.external.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "7. Other Channel Claims API", description = "List Of Other Channel api")
public class OtherChannelClaimController {

	@Autowired
	public FactoryService factoryService;

	@PostMapping("/claimDetails")
	@Operation(operationId = Constants.STR_13, summary = Constants.CLAIM_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_GUARDIAN_CLAIMAINT),

	})), responses = {
			@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimDetailsResProxyV3.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

			),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
							@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED),
							@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
			@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<ClaimDetailsResProxyV3> claimDocuments(
			@Valid @RequestBody ClaimDetailsReqProxyV3 claimDetailsProxy, HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL CLAIM DETAILS ----------------> " + claimDetailsProxy.getToken());
		ClaimDetailsResProxyV3 claimDetailsResProxy = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimDetailsProxy.getOrgId())) {
				return new ResponseEntity<>(
						new ClaimDetailsResProxyV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			claimDetailsResProxy = factoryService.otherChannelClaimDetails(claimDetailsProxy,
					claimDetailsProxy.getToken());
			log.info("END OTHER CHANNEL CLAIM DETAILS----------------> " + claimDetailsResProxy.getToken());
			return new ResponseEntity<>(claimDetailsResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL CLAIM DETAILS REQUEST  ---" + claimDetailsResProxy.getToken()
					+ "---", e);
			return new ResponseEntity<>(new ClaimDetailsResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping("/claimUploadDocuments")
	@Operation(operationId = Constants.STR_14, summary = Constants.CLAIM_UPLOAD_DOCUMENTS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_CLAIM), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = APIResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<APIResponse> claimUploadDocuments(
			@Valid @RequestBody ClaimUploadDocsReqProxyV3 claimUploadDocuments, HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL CLAIM UPLOAD DOCUMENTS ----------------> " + claimUploadDocuments.getToken());
		APIResponse registryResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimUploadDocuments.getOrgId())) {
				return new ResponseEntity<>(new APIResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			registryResponse = factoryService.otherChannelClaimUploadDoc(claimUploadDocuments,
					claimUploadDocuments.getToken());
			log.info("END OTHER CHANNEL CLAIM UPLOAD DOCUMENTS----------------> " + registryResponse.getToken());
			return new ResponseEntity<>(registryResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL CLAIM UPLOAD DOCUMENTS REQUEST  ---" + registryResponse.getToken()
					+ "---", e);
			return new ResponseEntity<>(
					new APIResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

}
