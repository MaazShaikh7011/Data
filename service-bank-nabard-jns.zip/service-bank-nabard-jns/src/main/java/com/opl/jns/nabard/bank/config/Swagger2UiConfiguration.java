package com.opl.jns.nabard.bank.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.ResourceTransformer;
import org.springframework.web.servlet.resource.ResourceTransformerChain;
import org.springframework.web.servlet.resource.TransformedResource;

import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.Paths;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.servers.Server;
import jakarta.servlet.http.HttpServletRequest;

@Configuration
public class Swagger2UiConfiguration implements WebMvcConfigurer {

	private static final String TOKEN_IS_NULL = "Token is null";

	private static final String REQUEST_DECRYPTION_KEY_IS_NULL = "Request decryption Key is null";

	private static final String TOKEN_EXPIRED = "Token is Expired";

	private static final String APPLICATION_EMPTY_MSG = "ApplicationId is null or empty ";

	private static final String API_TYPE_ID_IS_EMPTY = "Api Type is null or empty ";

	private static final String UNAUTHORIZED = "Invalid bank username and password";

	private static final String ILLEGAL_REQUEST = "Illegal Request (it contain zunk character)";

	private static final String INVALID_API_TYPE_MSG = "Invalid apiTypId";

	private static final String REQUEST_DATA_IS_EMPTY = "Request data is empty";

	private static final String DECRYTIPON_DATA_IS_EMPTY = "Decrytion data is empty";

	private static final String API_AUTH_REQ_IS_NULL = "Api Auth is null";

	private static final String APPLICATION_JSON = "application/json";

	private static final String[] BAD_REQUEST = new String[] { TOKEN_IS_NULL, REQUEST_DECRYPTION_KEY_IS_NULL,
			DECRYTIPON_DATA_IS_EMPTY, API_TYPE_ID_IS_EMPTY, APPLICATION_EMPTY_MSG, INVALID_API_TYPE_MSG,
			ILLEGAL_REQUEST, API_AUTH_REQ_IS_NULL };

	private static final String[] UNAUTHORIZEDs = new String[] { UNAUTHORIZED, TOKEN_EXPIRED, };

	private static final String[] NO_CONTENT = new String[] { REQUEST_DATA_IS_EMPTY };

	@Value("${server.servlet.context-path}")
	String contextPath;	
	
	@Bean
	public GroupedOpenApi publicApiV3() {
		return GroupedOpenApi.builder()
				.addOpenApiCustomizer(sort())
				.group("Jansuraksha-Bank-API V3")
				.packagesToScan("com.opl.jns.nabard.bank.controller")
				.addOperationCustomizer(customizeHeader()).build();
	}
//	@Bean
//	public GroupedOpenApi publicApiV2() {
//		return GroupedOpenApi.builder()
//				.addOpenApiCustomizer(sort())
//				.group("Jansuraksha-Bank-API V2")
//				.packagesToScan("com.opl.jns.service.assitedjourney.v2.controller")
//				.addOperationCustomizer(customizeHeader()).build();
//	}
//	@Bean
//	public GroupedOpenApi publicApiV1() {
//		return GroupedOpenApi.builder()
//				.group("Jansuraksha-Bank-API V1")
//				.packagesToScan("com.opl.jns.service.assitedjourney.v1.controller")
//				.addOperationCustomizer(customizeHeader()).build();
//	}

	@Bean
	public OpenAPI customOpenAPI() {
		Contact contact = new Contact();
//		  contact.name("API Dashboard");
//		  contact.setUrl(contextPath + "/api-dashboard");
		contact.setEmail("");
		// return new OpenAPI().addServersItem(new Server().url("http://localhost:8050"
		// + contextPath))

		return new OpenAPI().addServersItem(new Server().url("http://localhost:8070/" + contextPath.substring(1))).info(new Info()
				.title("JanSurksha Bank Api").contact(contact)
				.description("""
						JanSurksha Bank API document includes two schemes:\
						<b><br>1.PMSBY (Pradhan Mantri Suraksha Bima Yojana)\
						<br>2.PMJJBY (Pradhan Mantri Jeevan Jyoti Bima Yojana)\
						<br><br> All the APIs published by banks with encryption/decryption standard shared by OPL team\
						<br><br>This is only for ready reference of Request and Response of respective API. Note:Do not use try out feature.\
						""")
				.termsOfService(""));
	}

	@Bean
	public OpenApiCustomizer sort() {
		return openApi -> openApi.setPaths(
				(Paths) openApi.getPaths().entrySet()
						.stream()
						.sorted(Comparator.comparingInt(pathItem -> {
							Operation op = null;
							if(!OPLUtils.isObjectNullOrEmpty(pathItem.getValue().getPost())){
								op = pathItem.getValue().getPost();
							}else if(!OPLUtils.isObjectNullOrEmpty(pathItem.getValue().getGet())){
								op = pathItem.getValue().getGet();
							}
							if (!OPLUtils.isObjectNullOrEmpty(op) && !OPLUtils.isObjectNullOrEmpty(op.getOperationId())) {
								return Integer.parseInt(op.getOperationId());
							}
							return 0;
						}))
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (x, y) -> y, Paths::new))
		);
	}

	/**
	 * Error.INVALID - If any exception is occur then always INVALID(10001) response
	 * return as custom HTTPS status code
	 */
	@Bean
	public OperationCustomizer customerGlobalHeaderOpenApiCustomiser() {

		return (operation, handlerMethod) -> {
			ApiResponses apiResponses = new ApiResponses();
			apiResponses
					.addApiResponse(HttpStatus.UNAUTHORIZED.value() + "",
							new ApiResponse().description(Arrays.toString(UNAUTHORIZEDs))
									.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
					.addApiResponse(HttpStatus.NO_CONTENT.value() + "",
							new ApiResponse().description(Arrays.toString(NO_CONTENT))
									.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
					.addApiResponse(HttpStatus.BAD_REQUEST.value() + "",
							new ApiResponse().description(Arrays.toString(BAD_REQUEST))
									.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))

					.addApiResponse("",
							new ApiResponse().description("")
									.content(new Content().addMediaType("/*", new MediaType())))
					.addApiResponse(HttpStatus.UNAUTHORIZED.value() + "",
							new ApiResponse().description("true or some custome message")
									.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
					.addApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value() + "",
							new ApiResponse().description("any exception is occur")
									.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
					.addApiResponse(HttpStatus.OK.value() + "", new ApiResponse().description("true and api info")
							.content(new Content().addMediaType(APPLICATION_JSON, new MediaType())));
			operation.responses(apiResponses);
			return operation;
		};
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/swagger-ui/**")
				.addResourceLocations("classpath:/META-INF/resources/webjars/swagger-ui/").resourceChain(true);

	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/swagger-ui/").setViewName("forward:" + "/swagger-ui/index.html");
	}

	@Bean
	public OperationCustomizer customizeHeader() {

		return (operation, handlerMethod) -> {
			Schema<?> type = new Schema<>().type("string");
			return operation
					.addParametersItem(new Parameter().name("user-name").in("header").required(true)
							.description("required to be shared ").schema(type))
					.addParametersItem(new Parameter().name("api-key").in("header").required(true)
							.description("required to be shared").schema(type));
		};
	}

	public static class IndexPageTransformer implements ResourceTransformer {
		
		@Value("${api.version}")
		String apiVersion;

		private String overwriteDefaultUrl(String html) {
			return html.replace("https://petstore.swagger.io/v2/swagger.json", "/v3/api-docs");
		}

		@Override
		public Resource transform(HttpServletRequest httpServletRequest, Resource resource,
				ResourceTransformerChain resourceTransformerChain) throws IOException {
			if (resource.getURL().toString().endsWith("/index.html&urls.primaryName=Jansuraksha-Bank-API "+apiVersion)) {
				String html = IOUtils.toString(resource.getInputStream(), StandardCharsets.UTF_8);
				html = overwriteDefaultUrl(html);
				return new TransformedResource(resource, html.getBytes());
			} else {
				return resource;
			}
		}
	}
}
