package com.opl.jns.nabard.bank.boot;

import com.opl.jns.nabard.config.updated.common.utils.dbconfig.ApplicationProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = { "com.opl" })
@EnableScheduling
@EnableAsync
@EnableCaching
@EnableConfigurationProperties(ApplicationProperties.class)
public class BankNabardMain {
	public static void main(String[] args) {
		SpringApplication.run(BankNabardMain.class, args);
	}

}
