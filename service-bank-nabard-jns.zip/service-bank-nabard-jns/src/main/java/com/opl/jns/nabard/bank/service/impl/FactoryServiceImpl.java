package com.opl.jns.nabard.bank.service.impl;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.service.ManageRequestBankWise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;

@Service
@Transactional
public class FactoryServiceImpl implements FactoryService {

	public static final int INDIAN_BANK = 13;
	public static final int CENTRAL_BANK = 25;
	public static final int UNION_BANK = 1;
	public static final int BANK_OF_BARODA = 17;
	public static final int ICICI_BANK = 4;
	public static final int BANK_OF_INDIA = 14;
	public static final int BANK_OF_MAHARASHTRA = 27;
	public static final int CANARA_BANK = 12;
	public static final int INDIAN_OVERSEAS_BANK = 28;
	public static final int PUNJAB_SIND_BANK = 20;
	public static final int PUNJAB_NATIONAL_BANK = 18;
	public static final int UCO_BANK = 19;
	public static final int HDFC_BANK_LTD = 32;
	public static final int SBI_BANK = 16;
	public static final int PUNJAB_NATIONAL_BANK1 = 501;

	@Autowired
	private CommonBankAPIServiceImpl commonBankAPIServiceImpl;

	@Override
	public VerifyOtpApiResponse varifyOtp(OTPRequest otpRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(otpRequest.getOrgId()).verifyOtpRequest(otpRequest, referenceId, null);
	}

	@Override
	public TriggerOtpResponse triggerOtp(TriggerOtpRequest triggerOtpRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(triggerOtpRequest.getOrgId()).triggerOtpRequest(triggerOtpRequest, referenceId, null);
	}

	@Override
	public CustomerDetailsDataV3 getCustomerDetailsV3(CustomerDetailsRequest custDetailsReq, String referenceId)
			throws CommonException, IOException {
		return getInstance(custDetailsReq.getOrgId()).customerDetailsRequestV3(custDetailsReq, referenceId, null);
	}

	@Override
	public PremiumDeductionResponse getPremiumDeduction(PremiumDeductionRequest premDeductionReq, String referenceId)
			throws CommonException, IOException {
		return getInstance(premDeductionReq.getOrgId()).premiumDeductionRequest(premDeductionReq, referenceId, null);

	}

	@Override
	public PhysicalVerificationResponse getPhysicalVerification(OTPRequest otpRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(otpRequest.getOrgId()).getPhysicalVerification(otpRequest, referenceId, null);
	}

	@Override
	public AccHolderListResponse getAccHolderList(AccHolderListRequest holderListRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(holderListRequest.getOrgId()).getAccHolderList(holderListRequest, referenceId, null);
	}

	@Override
	public PolicyDetailsResponse getPolicyDetails(PolicyDetailsRequest policyDetailsRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(policyDetailsRequest.getOrgId()).getPolicyDetails(policyDetailsRequest, referenceId, null);
	}

	@Override
	public APIResponse pushEnrollment(PushEnrollmentDetailsRequest pushEnrollmentDetailsRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(pushEnrollmentDetailsRequest.getOrgId()).pushEnrollmentRequest(pushEnrollmentDetailsRequest,
				referenceId, null);
	}

	@Override
	public APIResponse nomineeUpdateStatus(NomineeUpdateStatusRequest nomineeUpdateStatusRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(nomineeUpdateStatusRequest.getOrgId()).nomineeUpdateStatus(nomineeUpdateStatusRequest,
				referenceId, null);
	}

	@Override
	public APIResponse optOutUpdateStatus(OptOutUpdateStatusRequest outUpdateStatusRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(outUpdateStatusRequest.getOrgId()).optOutUpdateStatus(outUpdateStatusRequest, referenceId,
				null);
	}

	@Override
	public APIResponse pushClaim(PushClaimDetailsRequest pushClaimReq, String referenceId)
			throws CommonException, IOException {
		return getInstance(pushClaimReq.getOrgId()).pushClaimRequest(pushClaimReq, referenceId, null);
	}

	@Override
	public APIResponse pushClaimStatustoBank(PushClaimStatustoBankReq pushClaimStatustoBankReq, String referenceId)
			throws CommonException, IOException {
		return getInstance(pushClaimStatustoBankReq.getOrgId()).pushClaimStatustoBank(pushClaimStatustoBankReq,
				referenceId, null);
	}

	@Override
	public EnrollmentResProxyV3 otherChannelEnrollment(EnrollmentReqProxyV3 enrollmentReqProxy, String referenceId)
			throws CommonException, IOException {
		return getInstance(enrollmentReqProxy.getOrgId()).otherChannelEnrollment(enrollmentReqProxy, referenceId, null);
	}

	@Override
	public UpdateTransResProxyV3 otherChannelUpdateTransaction(UpdateTransReqProxyV3 transactionRequest,
			String referenceId) throws CommonException, IOException {
		return getInstance(transactionRequest.getOrgId()).otherChannelUpdateTransaction(transactionRequest, referenceId,
				null);
	}

	@Override
	public UpdateStatusResProxyV3 otherChannelUpdateEnrollStatus(UpdateStatusReqProxyV3 statusApiReq,
			String referenceId) throws CommonException, IOException {
		return getInstance(statusApiReq.getOrgId()).otherChannelUpdateEnrollStatus(statusApiReq, referenceId, null);
	}

	@Override
	public ClaimDetailsResProxyV3 otherChannelClaimDetails(ClaimDetailsReqProxyV3 claimDetailsReqProxy,
			String referenceId) throws CommonException, IOException {
		return getInstance(claimDetailsReqProxy.getOrgId()).otherChannelClaimDetails(claimDetailsReqProxy, referenceId,
				null);
	}

	@Override
	public APIResponse otherChannelClaimUploadDoc(ClaimUploadDocsReqProxyV3 claimUploadDocuments, String referenceId)
			throws CommonException, IOException {
		return getInstance(claimUploadDocuments.getOrgId()).otherChannelClaimUploadDoc(claimUploadDocuments,
				referenceId, null);
	}

	@Override
	public MisEnrollmentResProxyV3 misEnrollmentDetails(MisEnrollmentReqV3 applicationRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(applicationRequest.getOrgId()).misEnrollmentDetails(applicationRequest, referenceId, null);
	}

	@Override
	public NomieeUpdateResponse otherChannelNomineeUpdate(NomineeUpdateRequest nomineeRequest, String referenceId)
			throws CommonException, IOException {
		return getInstance(nomineeRequest.getOrgId()).otherChannelNomineeUpdate(nomineeRequest, referenceId, null);
	}

	public ManageRequestBankWise getInstance(Long orgId) throws CommonException {
		ManageRequestBankWise instance = null;
		switch (orgId.intValue()) {
//		case INDIAN_BANK:
//			instance = IndianBankApiServiceImpl;
//			break;
//		case ICICI_BANK:
//			instance = iciciBankApiServiceImpl;
//			break;
//		case HDFC_BANK_LTD:
//			instance = hdfcBankApiServiceImpl;
//			break;
//		case SBI_BANK:
//			instance = sbiBankApiServiceImpl;
//			break;	
		case CENTRAL_BANK:
		case UNION_BANK:
		case BANK_OF_BARODA:
		case BANK_OF_MAHARASHTRA:
		case CANARA_BANK:
		case INDIAN_OVERSEAS_BANK:
		case PUNJAB_SIND_BANK:
		case PUNJAB_NATIONAL_BANK:
		case UCO_BANK:
		case BANK_OF_INDIA:
		case PUNJAB_NATIONAL_BANK1:
			instance = commonBankAPIServiceImpl;
			break;
		default:
			throw new CommonException("ORG IS NULL OR BANK IMPLEMENTATION NOT FOUND ");
		}
		return instance;

	}

}
