package com.opl.jns.nabard.bank.service.impl;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import com.opl.jns.nabard.bank.utils.APIAbsractLayer;
import com.opl.jns.nabard.config.updated.restcall.service.RestAPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;

@Service
@Transactional
public class CommonBankAPIServiceImpl extends APIAbsractLayer {

	@Autowired
	private RestAPIService restAPIService;

	@Override
	public TriggerOtpResponse triggerOtpRequest(TriggerOtpRequest triggerOtpReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.triggerOtpRequest(restAPIService, triggerOtpReq, referenceId, null, requestFactory);
	}

	@Override
	public VerifyOtpApiResponse verifyOtpRequest(OTPRequest otpRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.verifyOtpRequest(restAPIService, otpRequest, referenceId, null, requestFactory);
	}

	@Override
	public CustomerDetailsDataV3 customerDetailsRequestV3(CustomerDetailsRequest custDetailsReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.customerDetailsRequestV3(restAPIService, custDetailsReq, referenceId, null, requestFactory);
	}

	@Override
	public PremiumDeductionResponse premiumDeductionRequest(PremiumDeductionRequest premDeducReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.premiumDeductionRequest(restAPIService, premDeducReq, referenceId, null, requestFactory);
	}

	@Override
	public PhysicalVerificationResponse getPhysicalVerification(OTPRequest phyVrfReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.getPhysicalVerification(restAPIService, phyVrfReq, referenceId, null, requestFactory);
	}

	@Override
	public AccHolderListResponse getAccHolderList(AccHolderListRequest holderListRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.getAccHolderList(restAPIService, holderListRequest, referenceId, null, requestFactory);
	}

	@Override
	public PolicyDetailsResponse getPolicyDetails(PolicyDetailsRequest policyDetailsRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.getPolicyDetails(restAPIService, policyDetailsRequest, referenceId, null, requestFactory);
	}

	@Override
	public APIResponse pushEnrollmentRequest(PushEnrollmentDetailsRequest pushEnrollmentDetailsRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.pushEnrollmentRequest(restAPIService, referenceId, pushEnrollmentDetailsRequest, null,
				requestFactory);
	}

	@Override
	public APIResponse nomineeUpdateStatus(NomineeUpdateStatusRequest nomineeUpdateStatusRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.nomineeUpdateStatus(restAPIService, nomineeUpdateStatusRequest, referenceId, null, requestFactory);
	}

	@Override
	public APIResponse optOutUpdateStatus(OptOutUpdateStatusRequest outUpdateStatusRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.optOutUpdateStatus(restAPIService, outUpdateStatusRequest, referenceId, null, requestFactory);
	}

	@Override
	public APIResponse pushClaimRequest(PushClaimDetailsRequest pushClaimDetailsRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.pushClaimRequest(restAPIService, pushClaimDetailsRequest, referenceId, null, requestFactory);
	}

	@Override
	public APIResponse pushClaimStatustoBank(PushClaimStatustoBankReq pushClaimStatustoBankReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.pushClaimStatustoBank(restAPIService, pushClaimStatustoBankReq, referenceId, null, requestFactory);
	}

	@Override
	public EnrollmentResProxyV3 otherChannelEnrollment(EnrollmentReqProxyV3 enrollmentReqProxy, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelEnrollment(restAPIService, enrollmentReqProxy, referenceId, null, requestFactory);
	}

	@Override
	public UpdateTransResProxyV3 otherChannelUpdateTransaction(UpdateTransReqProxyV3 transactionRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelUpdateTransaction(restAPIService, transactionRequest, referenceId, null,
				requestFactory);
	}

	@Override
	public UpdateStatusResProxyV3 otherChannelUpdateEnrollStatus(UpdateStatusReqProxyV3 statusApiReq,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelUpdateEnrollStatus(restAPIService, statusApiReq, referenceId, null, requestFactory);
	}

	@Override
	public ClaimDetailsResProxyV3 otherChannelClaimDetails(ClaimDetailsReqProxyV3 claimDetailsResProxy,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelClaimDetails(restAPIService, claimDetailsResProxy, referenceId, null, requestFactory);
	}

	@Override
	public APIResponse otherChannelClaimUploadDoc(ClaimUploadDocsReqProxyV3 claimUploadDocuments, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelClaimUploadDoc(restAPIService, claimUploadDocuments, referenceId, null, requestFactory);
	}

	@Override
	public MisEnrollmentResProxyV3 misEnrollmentDetails(MisEnrollmentReqV3 enrollmentReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.misEnrollmentDetails(restAPIService, enrollmentReq, referenceId, null, requestFactory);
	}

	@Override
	public NomieeUpdateResponse otherChannelNomineeUpdate(NomineeUpdateRequest nomineeRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		return this.otherChannelNomineeUpdate(restAPIService, nomineeRequest, referenceId, null, requestFactory);
	}
}
