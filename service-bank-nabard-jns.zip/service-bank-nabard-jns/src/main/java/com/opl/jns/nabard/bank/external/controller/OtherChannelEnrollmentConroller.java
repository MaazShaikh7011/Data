package com.opl.jns.nabard.bank.external.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "6. Other Channel Enrollments API", description = "List Of Registry Api")
public class OtherChannelEnrollmentConroller {

	@Autowired
	public FactoryService factoryService;

	@PostMapping("/enrollmentDetails")
	@Operation(operationId = Constants.STR_15, summary = Constants.ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, description = Constants.PLAIN_REQUEST_DOB_DATE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_ENROLLMENT, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<EnrollmentResProxyV3> pushEnrollment(
			@Valid @RequestBody EnrollmentReqProxyV3 enrollmentReqProxy, HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL ENROLLMENT ----------------> " + enrollmentReqProxy.getToken());
		EnrollmentResProxyV3 enrollmentResProxy = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(enrollmentReqProxy.getOrgId())) {
				return new ResponseEntity<>(
						new EnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			enrollmentResProxy = factoryService.otherChannelEnrollment(enrollmentReqProxy,
					enrollmentReqProxy.getToken());
			log.info("END OTHER CHANNEL ENROLLMENT----------------> " + enrollmentResProxy.getToken());
			return new ResponseEntity<>(enrollmentResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL ENROLLMENT REQUEST  ---" + enrollmentResProxy.getToken() + "---",
					e);
			return new ResponseEntity<>(
					new EnrollmentResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping("/updateTransactionDetails")
	@Operation(operationId = Constants.STR_16, summary = Constants.UPDATE_TRANSACTION_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE, description = Constants.UPDATE_TRASACTION_DESC),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateTransResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }

					),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })

	public ResponseEntity<UpdateTransResProxyV3> saveTransaction(
			@Valid @RequestBody UpdateTransReqProxyV3 transactionRequest, HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL UPDATE TRANSACTION ----------------> " + transactionRequest.getToken());
		UpdateTransResProxyV3 updateTransResProxy = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(transactionRequest.getOrgId())) {
				return new ResponseEntity<>(
						new UpdateTransResProxyV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			updateTransResProxy = factoryService.otherChannelUpdateTransaction(transactionRequest,
					transactionRequest.getToken());
			log.info("END OTHER CHANNEL UPDATE TRANSACTION----------------> " + updateTransResProxy.getToken());
			return new ResponseEntity<>(updateTransResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL UPDATE TRANSACTION REQUEST  ---" + updateTransResProxy.getToken()
					+ "---", e);
			return new ResponseEntity<>(
					new UpdateTransResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping("/updateEnrolmentAcStatus")
	@Operation(operationId = Constants.STR_17, summary = Constants.UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateStatusResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<UpdateStatusResProxyV3> updateStatus(@Valid @RequestBody UpdateStatusReqProxyV3 statusApiReq,
			HttpServletRequest httpServletRequest) {
		log.info("START OTHER CHANNEL UPDATE ENROLLMENT STATUS ----------------> " + statusApiReq.getToken());
		UpdateStatusResProxyV3 updateStatusResProxy = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(statusApiReq.getOrgId())) {
				return new ResponseEntity<>(
						new UpdateStatusResProxyV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			updateStatusResProxy = factoryService.otherChannelUpdateEnrollStatus(statusApiReq, statusApiReq.getToken());
			log.info("END OTHER CHANNEL UPDATE ENROLLMENT STATUS----------------> " + updateStatusResProxy.getToken());
			return new ResponseEntity<>(updateStatusResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE OTHER CHANNEL UPDATE ENROLLMENT STATUS REQUEST  ---"
					+ updateStatusResProxy.getToken() + "---", e);
			return new ResponseEntity<>(new UpdateStatusResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

}
