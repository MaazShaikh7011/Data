package com.opl.jns.nabard.bank.internal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.nabard.config.updated.common.utils.security.SecurityUtility;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "3. DIY Opt-out", description = "API to update Bank/Insurer for Applicant Opt out from JS portal or Customer journey ")
public class EnrollmentDiyController {

	@Autowired
	public FactoryService factoryService;

	@PostMapping(value = "/optOutUpdateStatus")
	@Operation(operationId = Constants.STR_12, summary = CommonUtils.OPT_OUT_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.OPT_OUT_STATUS_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_UPDATE_OPTOUT),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = APIResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.OPT_OUT_STATUS_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE_TIME),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<APIResponse> optOutStatus(
			@Valid @RequestBody OptOutUpdateStatusRequest outUpdateStatusRequest,
			HttpServletRequest httpServletRequest) {
		log.info("START Opt Out Update Status ----------------> " + outUpdateStatusRequest.getToken());
		APIResponse commonResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(outUpdateStatusRequest.getOrgId())) {
				return new ResponseEntity<>(new APIResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false,
						outUpdateStatusRequest.getToken()), HttpStatus.OK);
			}
			commonResponse = factoryService.optOutUpdateStatus(outUpdateStatusRequest,
					outUpdateStatusRequest.getToken());
			log.info("END Opt Out Update Status ----------------> " + commonResponse.getToken());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE Opt Out Update Status ---" + commonResponse.getToken() + "---", e);
			return new ResponseEntity<>(new APIResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					CommonErrorMsg.Common.TECHNICAL_ERROR, false, commonResponse.getToken()), HttpStatus.OK);
		}
	}

}
