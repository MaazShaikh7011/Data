package com.opl.jns.nabard.bank.internal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "5. Push Claim API", description = "List of APIs for Assisted/Other channel Claims journey")
public class AssitedModeClaimApiController {

	@Autowired
	public FactoryService factoryService;

	@PostMapping(value = "/pushClaimDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = Constants.STR_7, summary = CommonUtils.PUSH_CLAIM_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION_PUSH_CLAIM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = APIResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_PUSH_PLAIN_RESPONSE_200, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })

	public ResponseEntity<APIResponse> consumeClaimDetails(
			@Valid @RequestBody PushClaimDetailsRequest claimDetailsRequest, HttpServletRequest httpServletRequest) {
		log.info("START PUSH CLAIM ----------------> " + claimDetailsRequest.getToken());
		APIResponse commonResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(claimDetailsRequest.getOrgId())) {
				return new ResponseEntity<>(new APIResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false,
						claimDetailsRequest.getToken()), HttpStatus.OK);
			}
			commonResponse = factoryService.pushClaim(claimDetailsRequest, claimDetailsRequest.getToken());

			log.info("END PUSH CLAIM ----------------> " + commonResponse.getToken());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PUSH CLAIM ---" + commonResponse.getToken() + "---", e);
			return new ResponseEntity<>(new APIResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					CommonErrorMsg.Common.TECHNICAL_ERROR, false, commonResponse.getToken()), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/pushClaimStatustoBank", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = Constants.STR_8, summary = CommonUtils.PUSH_CLAIM_STATUS_TO_BANK, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.UPDATE_CLAIM_STATUS_INSURE_PLAIN_REQUEST_EXAMPLE, description = Constants.RASON_ENUM),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = APIResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.UPDATE_CLAIM_STATUS_RESPONSE_EXAMPLE, description = Constants.INSURER_UPDATE_CLAIM_STATUS_BANK),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })

	public ResponseEntity<APIResponse> updateClaimDocument(
			@Valid @RequestBody PushClaimStatustoBankReq pushClaimStatustoBankReq,
			HttpServletRequest httpServletRequest) {
		log.info("START Push Claim Status To Bank ----------------> " + pushClaimStatustoBankReq.getToken());
		APIResponse commonResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(pushClaimStatustoBankReq.getOrgId())) {
				return new ResponseEntity<>(new APIResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false,
						pushClaimStatustoBankReq.getToken()), HttpStatus.OK);
			}
			commonResponse = factoryService.pushClaimStatustoBank(pushClaimStatustoBankReq,
					pushClaimStatustoBankReq.getToken());

			log.info("END Push Claim Status To Bank  ----------------> " + commonResponse.getToken());
			return new ResponseEntity<>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE Push Claim Status To Bank  ---" + commonResponse.getToken() + "---", e);
			return new ResponseEntity<>(new APIResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					CommonErrorMsg.Common.TECHNICAL_ERROR, false, commonResponse.getToken()), HttpStatus.OK);
		}
	}

}
