package com.opl.jns.nabard.bank.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.http.HttpStatus;

import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.nabard.config.updated.apiconfig.enums.APIType;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtils {

	public static final DateFormat sdf_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
	public static final DateFormat YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");

	public static final String TRIGGER_OTP = "Trigger to Bank to send verification code to the RMN with the requested Bank A/C";
	public static final String VERIFY_OTP = "To verify verification code sent to the RMN with the requested Bank A/C";
	public static final String GET_CUSTOMER_DETAILS = "To fetch  details of the ETB customer from the Bank records";
	public static final String PREMIUM_DEDUCT = "To trigger debit premium from ETB customer's A/C and credit to Insurer's/pool A/C confirmation";
	public static final String PHYSICAL_VERIFICATION = "To verify signature of the applicant with the requested Bank A/C";
	public static final String TRIGGER_OTP_DIY = "To send OTP to the RMN with the requested Bank A/C";
	public static final String VERIFY_OTP_DIY = "To verify OTP sent to the RMN with the requested Bank A/C";
	public static final String PUSH_ENROLLMENT_DEATILS = "pushEnrollmentDetails";
	public static final String GET_ACC_HOLDERlIST = "To fetch A/C holder list from Bank records";
	public static final String OPT_OUT_STATUS = "To update Bank/Insurer for the Opt Out request by the Applicant";
	public static final String FETCH_ENROLLMENT_MISAPI = "fetchEnrollmentMIS";
	public static final String FETCH_CLAIM_MISAPI = "fetchClaimMIS";
	public static final String POLICY_DETAILS_FETCH = "To fetch Enrolment details of the Applicant from Bank records";
	public static final String FETCH_INSURED_DETAILS = "API to fetch Insured Details.";
	public static final String PUSH_GRIEVANCE = "API to push Grievance.";
	public static final String UPDATE_GRIEVANCE_STATUS = "API to update Grievance Status.";
	public static final String NOMINEE_UPDATE_STATUS = "To push Nominee update details to Bank/Insurer";
	public static final String GET_COI_DETAILS = "To fetch COI details of the Applicant from Insurer records";
	public static final String PUSH_CLAIM_DETAILS = "To push successful Claim registration details and documents to Banks/Insurers";
	public static final String PUSH_CLAIM_STATUS_TO_BANK = "To update claim status to Bank from JS portal";
	public static final String PUSH_ENROLLMENT = "To push successful enrolment details to Bank/Insurer";
	public static final String ORG_MSG = "ORG ID is null or empty";

	public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
	public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

	public static CustomerDetailsDataV3 setAccountHolderDtlV3(AccountHolderDetailsV3 accDtl,
			AccountHolderDetailsResponseV3 res, CustomerDetailsDataV3 detailResp, Long orgId)
			throws ParseException, java.text.ParseException {
		res.setPincode(CommonUtils.checkStringAndCast(accDtl.getPincode(), Long.class, orgId));
		try {
			res.setDob(CommonUtils.checkStringAndCast(accDtl.getDob(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Applicant's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Applicant's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		try {
			res.setNomineeDateOfBirth(checkStringAndCast(accDtl.getNomineeDateOfBirth(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Nominee's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Nominee's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		detailResp.setAccountHolderDetails(res);
		return detailResp;
	}

	public static <T> T checkStringAndCast(String value, Class<T> type, Long orgId) throws ParseException {
		if (!OPLUtils.isObjectNullOrEmpty(value) && !value.equalsIgnoreCase("na") && !value.equals("-")
				&& !value.equals("|") && !value.equals("0")) {
			if (type.equals(Boolean.class)) {
				return (T) Boolean.valueOf(value);
			} else if (type.equals(Integer.class)) {
				return (T) Integer.valueOf(value);
			} else if (type.equals(Double.class)) {
				return (T) Double.valueOf(value);
			} else if (type.equals(Long.class)) {
				return (T) Long.valueOf(value);
			} else if (type.equals(Date.class)) {
				return (T) sdf_dd_MM_yyyy.parse(value);
			} else if (type.equals(LocalDate.class)) {
				if (PhaseMode.checkPhase2(orgId)) {
					return (T) LocalDate.parse(value);
				} else {
					String reformattedStr = YYYY_MM_DD.format(sdf_dd_MM_yyyy.parse(value));
					return (T) LocalDate.parse(reformattedStr);
				}
			}
		}
		return null;
	}

	public static String printLogs(Long orgId, APIType apiId, String refNum) {
		return "---REFID---" + refNum + "---ORG_ID---" + orgId + "---API_ID---" + apiId.toString() + "----";
	}

}
