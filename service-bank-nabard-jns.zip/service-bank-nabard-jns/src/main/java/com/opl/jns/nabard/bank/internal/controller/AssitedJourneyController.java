package com.opl.jns.nabard.bank.internal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.nabard.config.updated.apiconfig.enums.APIType;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "1. Assisted Mode Enrolment API", description = "List of APIs for Banker Assisted journey on JanSuraksha platform ")
public class AssitedJourneyController {

	@Autowired
	private FactoryService factoryService;

	@PostMapping(value = "/triggerVerificationCode")
	@Operation(operationId = Constants.STR_1, summary = CommonUtils.TRIGGER_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.TRIGGER_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.TRIGGER_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = TriggerOtpResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.TRIGGER_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) })

	})
	public ResponseEntity<TriggerOtpResponse> triggerOTP(@Valid @RequestBody TriggerOtpRequest triggerOtpRequest,
			HttpServletRequest httpServletRequest) {
		log.info("START TRIGGER OTP ----------------> " + triggerOtpRequest.getToken());
		TriggerOtpResponse triggerOtpResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(triggerOtpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new TriggerOtpResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			triggerOtpResponse = factoryService.triggerOtp(triggerOtpRequest, triggerOtpRequest.getToken());
			log.info("END TRIGGER OTP ----------------> " + triggerOtpRequest.getToken());
			return new ResponseEntity<>(triggerOtpResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE TRIGGER OTP ---" + triggerOtpResponse.getToken() + "---", e);
			return new ResponseEntity<>(
					new TriggerOtpResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping(value = "/verifyVerificationCode")
	@Operation(operationId = Constants.STR_2, summary = CommonUtils.VERIFY_OTP, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.VERIFY_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.VERIFY_OTP_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = VerifyOtpApiResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.VERIFY_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<VerifyOtpApiResponse> verifyOTP(@Valid @RequestBody OTPRequest otpRequest,
			HttpServletRequest httpServletRequest) {
		log.info("START VERIFY OTP ----------------> " + otpRequest.getToken());
		VerifyOtpApiResponse verifyOtpApiResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new VerifyOtpApiResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			verifyOtpApiResponse = factoryService.varifyOtp(otpRequest, otpRequest.getToken());
			log.info("END VERIFY OTP ----------------> " + otpRequest.getToken());
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE VERIFY OTP ---" + verifyOtpApiResponse.getToken() + "---", e);
			return new ResponseEntity<>(
					new VerifyOtpApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping(value = "/physicalSignatureVerification")
	@Operation(operationId = Constants.STR_3, summary = CommonUtils.PHYSICAL_VERIFICATION, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PHYSICAL_REQUEST_EXAMPLE, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.PHYSICAL_VERIFICATION_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PhysicalVerificationResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PHYSICAL_RESPONSE_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PhysicalVerificationResponse> physicalVerification(@Valid @RequestBody OTPRequest otpRequest,
			HttpServletRequest httpServletRequest) {
		log.info("START VERIFY PHYSICAL SIGNATURE ----------------> " + otpRequest.getToken());
		PhysicalVerificationResponse verifyOtpApiResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new PhysicalVerificationResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			verifyOtpApiResponse = factoryService.getPhysicalVerification(otpRequest, otpRequest.getToken());
			log.info("END VERIFY PHYSICAL SIGNATURE----------------> " + verifyOtpApiResponse.getToken());
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error(
					"EXCEPTION WHILE VERIFY PHYSICAL SIGNATURE REQUEST  ---" + verifyOtpApiResponse.getToken() + "---",
					e);
			return new ResponseEntity<>(new PhysicalVerificationResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getCustomerDetails")
	@Operation(operationId = Constants.STR_4, summary = CommonUtils.GET_CUSTOMER_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CUSTOMER_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.CUSTOMER_RECORD_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CustomerDetailsDataV3.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CUSTOMER_RESPONSE_SUCCESS, description = Constants.PLAIN_REQUEST_LBL_DATE_FORMAT),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<CustomerDetailsDataV3> getCustomerDetails(
			@Valid @RequestBody CustomerDetailsRequest customerDetailsRequest, HttpServletRequest httpServletRequest) {
		log.info("START GET CUSTOMER DETAILS ----------------> " + customerDetailsRequest.getToken());
		CustomerDetailsDataV3 customerDetailsResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(customerDetailsRequest.getOrgId())) {
				return new ResponseEntity<>(
						new CustomerDetailsDataV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			customerDetailsResponse = factoryService.getCustomerDetailsV3(customerDetailsRequest,
					customerDetailsRequest.getToken());
			log.info("END GET CUSTOMER DETAILS ----------------> " + customerDetailsResponse.getToken());
			return new ResponseEntity<>(customerDetailsResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET CUSTOMER DETAILS --- " + customerDetailsResponse.getToken() + "---", e);
			return new ResponseEntity<>(
					new CustomerDetailsDataV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}

	}

	@PostMapping(value = "/premiumDeduction")
	@Operation(operationId = Constants.STR_5, summary = CommonUtils.PREMIUM_DEDUCT, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PREMIUM_REQUEST_EXAMPLE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
							+ Constants.PAYMENT_DATA_MESSAGE, content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = PremiumDeductionResponse.class), examples = {
											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PREMIUM_RESPONSE_SUCCESS, description = Constants.PREMEMIUM_RESPONSE_DESC),
											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<PremiumDeductionResponse> premiumDeduction(
			@Valid @RequestBody PremiumDeductionRequest premiumDeductionRequest,
			HttpServletRequest httpServletRequest) {
		log.info("START PREMIUM DEDUCTION REQUEST ----------------> " + premiumDeductionRequest.getToken());
		PremiumDeductionResponse premiumDeductionResponse = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(premiumDeductionRequest.getOrgId())) {
				return new ResponseEntity<>(
						new PremiumDeductionResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			premiumDeductionResponse = factoryService.getPremiumDeduction(premiumDeductionRequest,
					premiumDeductionRequest.getToken());
			log.info("END PREMIUM DEDUCTION REQUEST ----------------> " + premiumDeductionResponse.getToken());
			return new ResponseEntity<>(premiumDeductionResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PREMIUM DEDUCTION REQUEST ---" + premiumDeductionResponse.getToken() + "---", e);
			return new ResponseEntity<>(new PremiumDeductionResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/pushEnrollmentDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(operationId = Constants.STR_6, summary = CommonUtils.PUSH_ENROLLMENT, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_EXAMPLE, description = Constants.PUSH_ENROLLMENT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = APIResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PUSH_ENROLLMENT_DEATILS_SUCCESS, description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) })

	})
	public ResponseEntity<APIResponse> consumeEnrollmentDetails(
			@Valid @RequestBody PushEnrollmentDetailsRequest enrollmentRequest, HttpServletRequest httpServletRequest) {
		APIResponse res = null;
		log.info("START PUSH PUSH ENROLLMENT  " + CommonUtils.printLogs(enrollmentRequest.getOrgId(),
				APIType.B_EN_CM_PUSH_ENRL_DTLS, enrollmentRequest.getToken()));
		try {
			if (OPLUtils.isObjectNullOrEmpty(enrollmentRequest.getOrgId())) {
				return new ResponseEntity<>(new APIResponse(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false,
						enrollmentRequest.getToken()), HttpStatus.OK);
			}
			res = factoryService.pushEnrollment(enrollmentRequest, enrollmentRequest.getReferenceId());

			log.info("END PUSH ENROLLMENT REQUEST ----------------> " + res.getToken());
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE  PUSH ENROLLMENT ---" + res.getToken() + "---", e);
			return new ResponseEntity<>(new APIResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					CommonErrorMsg.Common.TECHNICAL_ERROR, false, res.getToken()), HttpStatus.OK);
		}
	}

}
