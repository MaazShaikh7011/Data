package com.opl.jns.nabard.bank.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Constants {

	public static final String CUSTOMER_REQUEST_EXAMPLE = "{\"accountNumber\":\"45455545\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String PHYSICAL_REQUEST_EXAMPLE = "{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"signVerifiedByBank\": \"YES\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final String CUSTOMER_RESPONSE_SUCCESS = "{\"status\":200,\"message\":\"string\",\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"accountHolderDetails\":{\"cif\":\"stringstri\",\"customerIFSC\":\"XXXX000000\",\"accountHolderName\":\"string\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"string\",\"emailId\":\"string\",\"addressline1\":\"string\",\"addressline2\":\"string\",\"city\":\"string\",\"district\":\"string\",\"state\":\"string\",\"pincode\":382350,\"kycID1\":\"DRIVINGL\",\"kycID1number\":\"string\",\"pan\":\"YES\",\"panNumber\":\"XXXXX0000X\",\"aadhaar\":\"YES\",\"aadhaarNumber\":\"stringstri\",\"applicantOccupation\":\"string\",\"nomineeName\":\"string\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"9899999999\",\"relationshipOfNominee\":\"string\",\"nomineeEmailId\":\"xyz@abc.com\",\"addressofNominee\":\"string\",\"nameofGuardian\":\"string\",\"addressofGuardian\":\"string\",\"relationshipOfGuardian\":\"string\",\"guardianMobileNumber\":\"7544454578\",\"guardianEmailId\":\"abc@gmail.com\",\"bcReferralId\":\"string\",\"consentForautodebit\":\"YES\"}}";
	public static final String PHYSICAL_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": \"true\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}]}";
	public static final String PREMIUM_REQUEST_EXAMPLE = "{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"mode\": \"DIY\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String PREMIUM_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"debitStatus\": 1,\"transactionUTR\": \"string\",\"transactionTimeStamp\": \"2023-11-27 16:05:22\",\"transactionAmount\": \"string\",\"comment\": \"string\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String TRIGGER_REQUEST_EXAMPLE = "{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String TRIGGER_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\",\"mobileNumber\": \"7565544547\"}";
	public static final String VERIFY_REQUEST_EXAMPLE = "{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"verifyVerificationcode\": \"454315\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final String VERIFY_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String GET_ACC_HOLDERlIST_EXAMPLE = "{\"accountNumber\": \"2222222222\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String GET_ACC_HOLDERlIST_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderList\": [{\"accountNumber\": \"2222222222\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"policyInceptionDate\": \"2000-08-08 15:24:58\",\"scheme\": \"PMSBY\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String CLAIM_DETAILS_PLAIN_REQUEST_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"branchCode\":\"string\",\"branchName\":\"string\",\"bankBranchEmailId\":\"xyz@gmail.com\",\"cif\":\"45465454\",\"schemeName\":\"string\",\"bankCode\":\"784521\",\"customerAccountNumber\":\"string\",\"customerIFSC\":\"AAAD0FDFF\",\"accountHolderName\":\"Rock\",\"fatherHusbandName\":\"Rajeshbhai\",\"dob\":\"2000-08-08\",\"gender\":\"M\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressline1\":\"Isanpur\",\"addressline2\":\"Isanpur\",\"pincode\":385445,\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"kycId1\":\"PAN\",\"kycID1number\":\"AAGFV5271N\",\"pan\":\"Y\",\"panNumber\":\"FMXUU7878A\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"784512458956\",\"ckyc\":\"Y\",\"ckycNumber\":\"548537793745\",\"nomineeName\":\"string\",\"nomineeGender\":\"M\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"addressOfNominee\":\"nikol,ahemedabad\",\"relationshipOfNominee\":\"Husband\",\"nomineeNameCorrection\":\"Y\",\"correctNomineeName\":\"string\",\"nameofGuardian*\":\"string\",\"addressofGuardian\":\"Iskon,ahemedabad\",\"relationShipOfGuardian\":\"Wife\",\"guardianMobileNumber\":\"7598898956\",\"guardianEmailId\":\"rajesh@opl.com\",\"claimantName\":\"string\",\"claimantDateOfBirth\":\"2000-08-08\",\"relationshipOfClaimant\":\"string\",\"claimantMobileNumber\":\"string\",\"claimantEmailId\":\"xyz@gmail.com.com\",\"claimantKYC1\":\"string\",\"claimantAddress\":\"Iskon,ahemedabad\",\"claimantKYCNumber1\":\"string\",\"claimantGender\":\"M\",\"dateOfAccident\":\"2000-08-08\",\"timeOfAccident\":\"16:12:10\",\"dayOfAccident\":\"Sunday\",\"placeOfOccurence\":\"string\",\"natureOfAccident\":\"string\",\"dateOfDeath\":\"2023-05-16 09:16:54\",\"causeOfDeath\":\"string\",\"causeOfDeathDisability\":\"string\",\"typeOfDisability\":\"string\",\"claimantBankAccountNumber\":\"string\",\"claimantBankName\":\"string\",\"claimantBranchIFSC\":\"string\",\"premDebitDate\":\"2000-08-08\",\"premRemitDate\":\"2000-08-08\",\"dateOfLodgingClaim\":\"2000-08-08\",\"firstEnrollmentDate\":\"2023-05-14 08:25:17\",\"transactionTimestamp\":\"2023-05-14 00:00:00\",\"transactionAmount\":\"418\",\"transactionUTR\":\"S343423\",\"insurerCode\":\"44444\",\"token\":\"String\"}";
	public static final String CLAIM_DOCUMENTS_PLAIN_REQUEST_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":123,\"remarks\":\"\",\"documentList\":[{\"documentType\":\"string\",\"documentId\":\"0\",\"contentType\":\"string\",\"document\":[\"string\"]}],\"token\":\"string\"}";
	public static final String CLAIM_DOCUMENTS_PLAIN_RESPONSE_SUCCESS = "{\"message\":\"success\",\"status\":200,\"success\":true,\"token\":\"3321156485\",\"timestamp\":\"2023-05-05 16:12:10\"}";
	public static final String UPDATE_NOMINEE_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000003373-236\",\"accountNumber\":\"852852852\",\"nomineeUpdateFlag\":\"YES\",\"accountHolderName\":\"Rock\",\"dob\":\"2023-08-08\",\"customerIFSC\":\"IDIB000D088\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"pincode\":\"385445\",\"kycID1\":\"PAN\",\"kycID1Number\":\"AAGFV5271N\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"policyInceptionDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2023-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"nomineeEmailId\":\"rajesh@opl.com\",\"relationshipOfNominee\":\"Wife\",\"addressofNominee\":\"Isanpur\",\"nameofGuardian\":\"helooooooooooooooooooooo\",\"addressOfGuardian\":\"Isanpur\",\"relationShipOfGuardian\":\"Son\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"channelId\":\"BC\",\"userId1\":\"paresh@opl.com\",\"token\":\"JNS5546546645654645654654645\"}";
	public static final String UPDATE_NOMINEE_SUCCESS = "{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"string\",\"timeStamp\": \"2023-11-27 16:05:22\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}}";

	public static final String DIY_TRIGGER_REQUEST_EXAMPLE = "{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"purpose\": \"NEW ENROLLMENT\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String DIY_TRIGGER_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"mobileNumber\": \"7565544547\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String DIY_VERIFY_REQUEST_EXAMPLE = "{\"accountNumber\": \"11111111111\",\"dob\": \"2000-08-08\",\"verifyVerificationcode\": \"454315\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"accHolderDtlsReq\":\"YES\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String DIY_VERIFY_RESPONSE_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": true,\"accountHolderDetails\": [{\"accountHolderName\": \"string\",\"cif\": \"stringstri\",\"dob\": \"2000-08-08\",\"gender\": \"M\",\"PMJJBYexists\": \"YES\",\"PMSBYexists\": \"YES\",\"KYCUpdated\": \"YES\"}],\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String OPT_OUT_STATUS_EXAMPLE = "{\"accountNumber\": \"2222222222\",\"cif\":\"5454554\",\"urn\": \"JNS-XXXXX-00-00-00000000000-000\",\"effectiveDate\": \"2000-08-08 00:00:00\",\"requestDate\": \"2000-08-08 00:00:00\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String OPT_OUT_STATUS_SUCCESS = "{\"status\": 200,\"message\": \"string\",\"success\": \"true\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String GET_COI_EXAMPLE = "{\"accountNumber\":\"11111111111\",\"cif\":\"5454554\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"dob\":\"2000-08-08\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String GET_COI_SUCCESS = "{\"accountHolderName\":\"nimesh\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7569987896\",\"addressline1\":\"Isanpur\",\"addressline2\":\"Isanpur\",\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"pincode\":385445,\"kycID1\":\"PAN\",\"kycID1number\":\"FMXOO9090A\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nameofGuardian\":\"rock\",\"relationshipOfGuardian\":\"Son\",\"status\": 200,\"message\": \"string\",\"flag\": true,\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"Timestamp\":\"2000-08-08 15:24:58\"}";

	public static final String NOMINEE_UPDATE_SUCCESS = "{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String NOMINEE_UPDATE_STATUS_EXAMPLE = "{\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"nomineeUpdateFlag\":\"YES\",\"nomineeName\":\"harsh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7845124512\",\"relationshipOfNominee\":\"WIFE\",\"nomineeEmailId\":\"xyz@gmail.com\",\"addressOfNominee\":\"jarkhand\",\"nameOfGuardian\":\"rahul\",\"addressOfGuardian\":\"jamanagar\",\"relationshipOfGuardian\":\"HUSBAND\",\"guardianMobileNumber\":\"7845895623\",\"guardianEmailId\":\"xyz@gmail.com\"}";
	public static final String CLAIM_PUSH_PLAIN_REQUEST_EXAMPLE = "{\"claimReferenceId\":\"452134531\",\"masterPolicyNumber\":\"56556555556\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"schemeName\":\"PMSBY\",\"customerAccountNumber\":\"784512451245\",\"customerBankname\":\"Union\",\"customerIFSC\":\"UBIN0994599\",\"accountHolderName\":\"nimesh\",\"dob\":\"2000-08-08\",\"gender\":\"M\",\"insurerCode\":\"784512\",\"bankCode\":\"784521\",\"branchCode\":\"784512\",\"bankBranchEmailId\":\"xyx@opl.com\", \"mobileNumber\":\"7845124512\",\"emailID\":\"xyx@opl.com\",\"addressline1\":\"A-2 new\",\"addressline2\":\"old city\",\"pincode\":\"382415\",\"city\":\"ahmedabad\",\"district\":\"gujarat\",\"state\":\"gujarat\",\"kycID1\":\"PAN\",\"kycID1number\":\"FMXOO9090A\",\"pan\":\"Y\",\"panNumber\":\"FMXUU7878A\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"784512458956\",\"ckyc\":\"Y\",\"ckycNumber\":\"78451245124512\",\"nomineeName\":\"harsh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeGender\":\"M\",\"nomineeMobileNumber\":\"7845124512\",\"relationshipOfNominee\":\"BROTHER\",\"nomineeEmailId\":\"sss@opl.com\",\"addressofNominee\":\"new delhi\",\"correctNomineeName\":\"rahul\",\"nameofGuardian\":\"harsh\",\"addressOfGuardian\":\"new mumbai\",\"relationShipOfGuardian\":\"SON\",\"guardianMobileNumber\":\"8956234512\",\"guardianEmailId\":\"www@opl.com\",\"claimantName\":\"rajesh\",\"claimantAddress\":\"rajasatstan\",\"claimantDateOfBirth\":\"2000-08-08\",\"relationshipOfClaimant\":\"WIFE\",\"claimantMobileNumber\":\"8945154512\",\"claimantEmailId\":\"ttt@opl.com\",\"claimantKYC1\":\"PAN\",\"claimantKYCNumber1\":\"FDXII8989A\",\"claimantKYC2\":\"AADHAR\",\"claimantKycNumber2\":\"784512458956\",\"claimantGender\":\"M\",\"dateOfAccident\":\"2000-08-08\",\"timeOfAccident\":\"02:20:45\",\"dayOfAccident\":\"Sunday\",\"placeOfOccurence\":\"delhi\",\"natureOfAccident\":\"done\",\"dateOfDeath\":\"2000-08-08 15:24:58\",\"causeOfDeath\":\"Suicide\",\"causeOfDeathDisability\":\"Suicide\",\"typeOfDisability\":\"Total permanent\",\"claimantBankAccountNumber\":\"784512451245\",\"claimantBankName\":\"Union\",\"claimantBranchIFSC\":\"UBIN0995999\",\"premDebitDate\":\"2000-08-08\",\"premRemitDate\":\"2000-08-08\",\"dateOfLodgingClaim\":\"2000-08-08\",\"documents\":[{\"documentType\":\"claimDocuments\",\"contentType\":\"pdf\",\"documentId\":\"7845124512\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}]}";
	public static final String CLAIM_PUSH_PLAIN_RESPONSE_200 = "{\"message\":\"success\",\"success\":true,\"status\":\"200\",\"success\":true,\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\":\"2023-11-27 16:05:22\"}";

	public static final String UPDATE_CLAIM_STATUS_INSURE_PLAIN_REQUEST_EXAMPLE = "{\"claimReferenceId\":123,\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimStatus\":1,\"insurerStatus\":\"String\",\"reason\":1,\"claimId\":\"456789\",\"transactionDetails\":{\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"transactionUTR\":\"string\"},\"token\":\"string\"}";
	public static final String UPDATE_CLAIM_STATUS_RESPONSE_EXAMPLE = "{\"message\":\"String\",\"status\":\"200\",\"token\":\"string\",\"timeStamp\": \"2023-11-27 16:05:22\",\"success\":\"true\"}";

	public static final String PUSH_ENROLLMENT_DEATILS_EXAMPLE = "{\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"policyYear\":\"2022\",\"insurerCode\":\"78451\",\"transactionUTR\":\"string\",\"transactionTimeStamp\":\"2023-05-16 09:16:54\",\"transactionAmount\":0,\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"source\":\"Other channel\",\"mode\": \"DIY\",\"transactionType\":\"N\",\"masterPolicyNumber\":\"56556555556\",\"schemeName\":\"string\",\"branchCode\":\"string\",\"bankCode\":\"784521\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"1051\",\"userId2\":\"1051\",\"channelId\":\"string\",\"ruralUrban\":\"Rural\",\"accountNumber\":\"*******8243\",\"cif\":\"5454554\",\"customerIFSC\":\"AAAD0FDFF\",\"accountHolderName\":\"Rock\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7569987896\",\"emailId\":\"rock@opl.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"pincode\":385445,\"city\":\"Isanpur\",\"district\":\"Isanpur\",\"state\":\"Gujarat\",\"kycID1\":\"PAN\",\"kycID1Number\":\"AAGFV5271N\",\"pan\":\"Y\",\"panNumber\":\"string\",\"aadhaar\":\"Y\",\"aadhaarNumber\":\"string\", \"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringsssss\", \"applicantOccupation\":\"worker\",\"nomineeName\":\"Rajesh\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"7598898956\",\"relationshipOfNominee\":\"Wife\",\"nomineeEmailId\":\"rajesh@opl.com\",\"addressofNominee\":\"Isanpur\",\"nameofGuardian\":\"rock\",\"addressOfGuardian\":\"Isanpur\",\"relationShipOfGuardian\":\"Son\",\"guardianMobileNumber\":\"7854489625\",\"guardianEmailId\":\"paresh@opl.com\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"} }";
	public static final String PUSH_ENROLLMENT_DEATILS_SUCCESS = "{\"message\": \"string\",\"status\": 200,\"success\":true,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";

	public static final String POLICY_DETAILS_REQUEST_EXAMPLE = "{\"accountNumber\": \"*******8243\",\"accountHolderName\": \"string\",\"cif\":\"5454554\",\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\",\"dob\": \"2000-08-08\",\"tranDetailsReqdDate\": \"2000-08-08 00:00:00\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String POLICY_DETAILS_RESPONSE_SUCCESS = "{\"customerIFSC\":\"XXXX000000\",\"accountHolderName\":\"string\",\"gender\":\"M\",\"fatherHusbandName\":\"RameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"string\",\"emailId\":\"string\",\"addressline1\":\"string\",\"addressline2\":\"string\",\"city\":\"string\",\"district\":\"string\",\"state\":\"string\",\"pincode\":382350,\"kycID1\":\"DRIVINGL\",\"kycID1number\":\"string\",\"pan\":\"YES\",\"panNumber\":\"XXXXX0000X\",\"aadhaar\":\"YES\",\"aadhaarNumber\":\"784512457845\",\"ckyc\":\"YES\",\"ckycNumber\":\"78451245124512\",\"firstEnrollmentDate\":\"2023-05-16 09:16:54\",\"nomineeName\":\"string\",\"nomineeDateOfBirth\":\"2000-08-08\",\"nomineeMobileNumber\":\"9899999999\",\"relationshipOfNominee\":\"string\",\"nomineeEmailId\":\"xyz@abc.com\",\"addressofNominee\":\"string\",\"nameofGuardian\":\"string\",\"addressofGuardian\":\"string\",\"relationshipofGuardian\":\"string\",\"guardianMobileNumber\":\"7544454578\",\"guardianEmailId\":\"abc@gmail.com\",\"status\": 200,\"success\":true,\"message\": \"string\",\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"transactionAmount\": 418,\"transactionUTR\": \"202368754654\",\"transactionTimestamp\": \"2023-11-27 16:05:22\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String FETCH_INSURED_DETAILS_REQUEST_EXAMPLE = "{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final String FETCH_INSURED_DETAILS_RESPONSE_SUCCESS = "{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final String PUSH_GRIEVANCE_REQUEST_EXAMPLE = "{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final String PUSH_GRIEVANCE_RESPONSE_SUCCESS = "{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final String UPDATE_GRIEVANCE_STATUS_REQUEST_EXAMPLE = "{\"cif\": \"string\",\"customerAccountNumber\": \"*******8243\",\"insurerCode\": \"8243\",\"userId\": \"2514\",\"branchCode\": \"2514\",\"scheme\": \"PMSBY\",\"premiumAmount\": 0,\"urn\": \"JNS-PMJJBY-23-24-00000000001-123\"}";
	public static final String UPDATE_GRIEVANCE_STATUS_RESPONSE_SUCCESS = "{\"message\":\"succss\",\"data\":{},\"status\":200,\"success\":true}";
	public static final String CLAIM_DE_DUP_PLAIN_REQUEST_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"claimReferenceId\":\"123\",\"hospitalisationDate\":\"2023-11-27 16:05:22\",\"firNo\":\"String\",\"firDate\":\"2023-11-27 16:05:22\",\"panchnamaNo\":\"String\",\"panchnamaDate\":\"2023-11-27 16:05:22\",\"postMortemReportNo\":\"String\",\"postMortemReportDate\":\"2023-11-27 16:05:22\",\"deathCertificateReportNo\":\"String\",\"deathCertificateReportDate\":\"2023-11-27 16:05:22\",\"documentReceivingDate\":\"2023-11-27 16:05:22\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";
	public static final String CLAIM_DE_DUP_PLAIN_RESPONSE_SUCCESS = "{\"message\":\"Success\",\"success\":true,\"status\":200,\"data\":{\"dedupeCheck\":true,\"isMatchWith\":{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"intimationDate\":\"\",\"type\":1,\"claimStatus\":1,\"dateOfLoss\":\"\",\"beneficiaryName\":\"{Nominee/Guardian/Claimant Name}\",\"beneficiaryBank\":\"\"}},\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String ENROLLMENT_PLAIN_RESPONSE_SUCCESS = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"message\":\"string\",\"status\":0,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"string\"}";
	public static final String UPDATE_TRANSACTION_PLAIN_REQUEST_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"debitStatus\": 1,\"transactionTimeStamp\":\"2023-05-05 16:12:10\",\"transactionAmount\":0,\"masterPolicyNumber\":\"string\",\"insurerCode\":\"44444\",\"transactionUTR\":\"string\",\"transactionType\":\"string\",\"token\":\"string\"}";
	public static final String UPDATE_TRANSACTION_PLAIN_RESPONSE_SUCCESS = "{\"message\":\"succss\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-23 07:01:00\",\"token\":\"ae75100d-57d4-436b-9c57-06f25be04f3f\",\"coi\":{\"documentType\":\"coi\",\"contentType\":\"pdf\",\"document\":\"JVBERi0xLjcKJeLjz9MKNSAwIG9isssaaadadrwreterrtertewwerwrwrwwa\"}}";
	public static final String CLAIM_DETAILS_PLAIN_RESPONSE_SUCCESS = "{\"message\":\"success\",\"status\":200,\"data\":{\"claimReferenceId\":123},\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"3321156485\",\"success\":true}";
	public static final String CLAIM_DETAILS_PLAIN_RESPONSE_DEDUPE_FAILED = "{\"message\":\"De-dupe failed reason\",\"status\":\"400\",\"success\":\"true\",\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"asdasdasdsadsad\"}";
	public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
	public static final String MIS_ENROLLMENT_DETAILS = "To give mis Enrollment details";
	public static final String MIS_ENROLLMENT_API_PLAIN_REQUEST = "{\"type\":\"ENROLL|RENEWAL\",\"token\":\"sdfsdfsdfsdfsdfsdf\",\"fromDate\":\"2023-05-07 00:00:00\",\"toDate\":\"2023-05-14 00:00:00\",\"districtList\":[{\"districtCode\":25,\"pmsby\":{\"elgSvngAccHldr\":100,\"elgPMJDYHldr\":200,\"ruralMale\":5646,\"ruralFemale\":5646,\"ruralTransG\":5646,\"urbanFemale\":5646,\"urbanlMale\":5646,\"urbanlTransG\":5646,\"totalEnrolment\":46564,\"prmclctdruralMale\":5646,\"prmclctdruralFemale\":5646,\"prmclctdruralTransG\":5646,\"prmclctdurbanFemale\":5646,\"prmclctdurbanlMale\":5646,\"prmclctdurbanlTransG\":5646,\"totalPrmclctdNwErollment\":46564,\"recordsTransmittedToInsurer\":546,\"premiumPaidToInsurer\":5654,\"aadharSeeded\":46564,\"mobileSeeded\":46564,\"emailSeeded\":46564,\"pmjdyEnrolled\":46564,\"mgnregaEnrolled\":46564,\"mudraEnrolled\":46564,\"kccEnrolled\":46564,\"otherSchemeEnrolled\":46564,\"insufficientAcHolders\":500,\"caste\":{\"sc\":0,\"st\":41654,\"general\":655654,\"obc\":564646},\"nomineeAvlb\":54654},\"pmjjby\":{\"elgSvngAccHldr\":100,\"elgPMJDYHldr\":200,\"ruralMale\":5646,\"ruralFemale\":5646,\"ruralTransG\":5646,\"urbanFemale\":5646,\"urbanlMale\":5646,\"urbanlTransG\":5646,\"totalEnrolment\":46564,\"prmclctdruralMale\":5646,\"prmclctdruralFemale\":5646,\"prmclctdruralTransG\":5646,\"prmclctdurbanFemale\":5646,\"prmclctdurbanlMale\":5646,\"prmclctdurbanlTransG\":5646,\"totalPrmclctdNwErollment\":46564,\"recordsTransmittedToInsurer\":546,\"premiumPaidToInsurer\":5654,\"aadharSeeded\":46564,\"mobileSeeded\":46564,\"emailSeeded\":46564,\"pmjdyEnrolled\":46564,\"mgnregaEnrolled\":46564,\"mudraEnrolled\":46564,\"kccEnrolled\":46564,\"otherSchemeEnrolled\":46564,\"insufficientAcHolders\":500,\"caste\":{\"sc\":0,\"st\":41654,\"general\":655654,\"obc\":564646},\"nomineeAvlb\":54654}}]}";
	public static final String PLAIN_REQUEST_MIS_LBL = "<br>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br>‘insufficientAcHolders’ mandatory in case of Renewals only.<br><br>All the 765 districts to be sent by the Banks. In case of No data, Banks to send “0” as value in API.<br><br>District code wise data for both schemes to be sent by the Bank.<br><br>In case of duplicate entries, API will fail.<br>";

	public static final String UPDATE_STATUS = "Update Status";
	public static final String UPDATE_STATUS_PLAIN_REQUEST_EXAMPLE = "{\"urn\":\"JNS-PMJJBY-23-24-00000000001-123\",\"status\":7,\"reason\":\"string\"}";
	public static final String UPDATE_STATUS_PLAIN_RESPONSE_SUCCESS = "{\"message\":\"string\",\"status\":200,\"success\":true,\"timestamp\":\"2023-05-05 16:12:10\",\"token\":\"8002adc6-8540-4b46-9cb5-7e89cd1eab67\"}";

	public static final String PLAIN_RESPONSE_400 = "{\"message\": \"It seems that request is not properly formed.\",\"status\": 400,\"success\": false,\"token\": \"8002adc6-8540-4b46-9cb5-7e89cd1eab67\",\"timeStamp\": \"2023-11-27 16:05:22\"}";
	public static final String PLAIN_RESPONSE_401 = "{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false,\"flag\":false}";
	public static final String MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY = "Invalid or Bad Request.One or more parameter is empty.";
	public static final String COMMON_DOCUMENT_MESSAGE = "Get Upload Documents Response";
	public static final String DE_DUP_API_MESSAGE = "To check de-dupe validation for enrollment, claim and renewal";
	public static final String CLAIM_DETAILS = "To send claim registration details to JS portal by Banks Other Channel";
	public static final String CLAIM_UPLOAD_DOCUMENTS = "To send claim documents to JS portal via Banks Other Channel";

	public static final String PLAIN_REQUEST_LBL = "Plain Request";
	public static final String PLAIN_RESPONSE_LBL = "Plain Response";
	public static final String PLAIN_REQUEST_LBL_DATE = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u>";
	public static final String PLAIN_REQUEST_LBL_DATE_FORMAT = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u> <br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u> <br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456<br><br>If Nominee is minor then Guardian details would be mandatory.";
	public static final String UPDATE_TRASACTION_DESC = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><b>debitStatus</b> >>> <b>Enum :</b> <br>For Enum 1 - COI will Generate<br>For Enum 2 - The case will be moved to failed and reattempt for COI to be done<br>For Enum 3 to 8 - The reponse will have success with COI null. The case will be moved to Rejected";

	public static final String PLAIN_REQUEST_LBL_DATE_TIME = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss<b><u><br>";
	public static final String PREMEMIUM_RESPONSE_DESC = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><b>debitStatus</b> >>> <b>Enum :</b> <br>For Enum 1 - COI will Generate<br>For Enum 2 - The case will be moved to failed and reattempt for COI to be done<br>For Enum 3 to 8 - The reponse will have success with COI null. The case will be moved to Rejected";
	public static final String PLAIN_REQUEST_LBL_ACC_HOLDER_LIST = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><u><br><br><u><b>URN</b> is mandatory</u><br><br><u><b>Policy inception date should be the of the current Policy Year.</b></u>";
	public static final String DATE_FORMAT_DESCRIPTION_AND_OTHER = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Repudiated and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved claims</b><u><br>";
	public static final String REQUEST_EXAMPLES_DESC = "Request examples";
	public static final String DATE_FORMAT_DESCRIPTION = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b>";
	public static final String PUSH_CLAIMSTATUS_TO_BANK = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b><br><br><u><b>Reason is mandatory for Rejected and Queried claims</b><br><br><b><u>Transaction details are mandatory for Approved Claims</b><u><br>";
	public static final String PLAIN_REQUEST_GUARDIAN_CLAIMAINT = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Guardian details mandatory in case Nominee is minor.</b><u><br><br><u><b>Claimant details mandatory in case Nominee is pre deceased.</b><u><br><br><u><b>Correct Nominee name is mandatory in case Nominee name correction is required</b><u><br><br><u><b>Only Date of death and Cause of Death are mandatory for PMJJBY claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims.</b><u><br>";
	public static final String PLAIN_REQUEST_DOB_GUARDIAN_CLAIMAINT = "<u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Guardian details mandatory in case Nominee is minor.</b><u><br><br><u><b>Claimant details mandatory in case Nominee is pre deceased.</b><u><br><br><u><b>Correct Nominee name is mandatory in case Nominee name correction is required</b><u><br><br><u><b>Only Date of death and Cause of Death are mandatory for PMJJBY claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims.</b><u><br><br><u><b>Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims.</b><u><br>";

	public static final String UPDATE_NOMIEE_DESC = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>If Nominee is minor then Guardian details are mandatory.</u><br><br><u>Policy inception date will be of the current PY.</u><br><br><u>Branch code and Address in the revised COI will be of the Enrolment branch. If not available, then will show NULL.</u>";
	public static final String NOMINEE_UPDATE_DETAILS = "Published by JS portal. To be added in the Other channel Swagger";
	public static final String DOB_DATE_FORMAT_DESCRIPTION_ACC_HOLDER_LIST = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Account Number & DOB OR URN is mandatory</b></u>";
	public static final String DOB_DATE_FORMAT_DESCRIPTION_UPDATE_OPTOUT = "<u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>URN</b> is mandatory</u><br>";
	public static final String DOB_DATE_FORMAT_DESCRIPTION = "<br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>If Nominee is minor then Guardian details would be mandatory.</u>";
	public static final String INSURER_UPDATE_CLAIM_STATUS_BANK = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Reason is mandatory for Rejected and Queried claims</u><br><br><u>Transaction details are mandatory for Approved claims</u><br><br><u>Mandatory for Insurers not using JS portal for claims; if using JS portal then the API is optional</u><br><br>"
			+ "<p><b>reason</b> >>>  <b>Enum :</b> <br>" + "  <b>Queried Claims:</b> <br>"
			+ "				1. Complete claim documents not submitted by claimants, <br>"
			+ "				2. Claim documents not forwarded by banks to insurer, <br>"
			+ "				3. Deceased’s name mismatch with death certificate, <br>"
			+ "				4. Nominee’s name differs in enrolment & claim form, <br>"
			+ "				5. KYC proof of nominee not submitted, <br>"
			+ "				6. NEFT account details of nominee not submitted, <br>"
			+ "				7. Title to claim money not clear, <br>" + "				8. NEFT Rejected </p>"
			+ " <p> <b>Rejected claims:</b> <br>" + "  <b>PMJJBY scheme: </b> <br>"
			+ "				1. Complete claim documents not submitted by claimants, <br>"
			+ "				2. Death during lien period, <br>"
			+ "				3. Death not established by documents submitted, <br>" + "				4. Others <br>"
			+ "  <b>PMSBY scheme: </b> <br>" + "				1. Duplicate claim, <br>"
			+ "				2. Death due to suicide, <br>" + "				3. Death is not due to accident, <br>"
			+ "				4. Disability not due to accident ,<br>"
			+ "				5. Disability not permanent ,<br>"
			+ "				6. Death / disability due to accident, not established by documents submitted ,<br>"
			+ "				7. Others";
	public static final String DOB_DATE_FORMAT_DESCRIPTION_POLICY_HOLDER = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><b><u>If tranDetailsReqdDate is sent in request, then transactionAmount, transactionUTR and transactionTimestamp is mandatory.</u></b><br><br><u>If Nominee is minor then Guardian details would be mandatory.</u>";
	public static final String DOB_DATE_FORMAT_DESCRIPTION_PUSH_CLAIM = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br>"
			+ "<br> Guardian details mandatory in case Nominee is minor."
			+ "<br> Claimant details mandatory in case Nominee is pre deceased."
			+ "<br> Correct Nominee name is mandatory in case Nominee name correction is required"
			+ "<br> Only Date of death and Cause of Death are mandatory for PMJJBY claims."
			+ "<br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Date of Death are mandatory for PMSBY Death Claims."
			+ "<br> Date, Time, Day, Place and Nature of accident; Cause of Death/disability and Type of Disability are mandatory for PMSBY Disability Claims"
			+ "<br><br><br><p><b>documentList</b> >>> <b>documentId</b> >>> <b>Enum :</b> <br>"
			+ "				4 - Signed and dully filled Claim cum discharge Form *, <br>"
			+ "				5 - Death Certificate *, <br>" + "				6 - Hospital Discharge Summary *,\r\n <br>"
			+ "				7 - Certificate issued by last attending Registered Medical Practitioner *,\r\n <br>"
			+ "				8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *,\r\n <br>"
			+ "				9 - FIR/Panchnama *,\r\n <br>"
			+ "				10 - Hospital Records with deceased complete details *,\r\n <br>"
			+ "				11 - KYC of Insured member *,\r\n <br>"
			+ "				12 - KYC of Nominee/Claimant *,\r\n <br>"
			+ "				13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *,\r\n <br>"
			+ "				14 - Nominee Death Certificate *,\r\n <br>"
			+ "				15 - Legal Heir Certificate *,\r\n <br>" + "				16 - Others *,\r\n <br>"
			+ "				17 - Disability Certificate issued by Civil Surgeon *,\r\n <br>"
			+ "				18 - Hospital records supporting the disability *,\r\n <br>"
			+ "				19 - Checklist  *,\r\n <br>"
			+ "				20 - Copy of Passbook of Insured *,\r\n <br>"
			+ "				21 - Post mortem Report *,\r\n <br>"
			+ "				22 - Aadhar/PAN of Nominee/Claimant *,\r\n<br>"
			+ "				23 - Aadhar/PAN of Insured Member *</p>";
	public static final String PUSH_ENROLLMENT_DESCRIPTION = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u>Disability status & Disability details mandatory only in PMSBY</u><br><br><u>For Assisted mode enrollment – user id 1 will be banker login id and user id 2 will be ‘bcreferralid’ if sent by Bank</u><br><br><u>For Other channel enrollments – user id 1 and user id 2 will be as per sent by Bank</u><br><br><u>Mode will be optional in case \"Other channel\" is sent in Source data field. Otherwise Mode will ne mandatory.</u><br><br><u>If Nominee is minor then Guardian details would be mandatory.</u>";
	public static final String RASON_ENUM = "<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br>"
			+ "<p><b>reason</b> >>>  <b>Enum :</b> <br>" + "  <b>Queried Claims:</b> <br>"
			+ "				1. Complete claim documents not submitted by claimants, <br>"
			+ "				2. Claim documents not forwarded by banks to insurer, <br>"
			+ "				3. Deceased’s name mismatch with death certificate, <br>"
			+ "				4. Nominee’s name differs in enrolment & claim form, <br>"
			+ "				5. KYC proof of nominee not submitted, <br>"
			+ "				6. NEFT account details of nominee not submitted, <br>"
			+ "				7. Title to claim money not clear, <br>" + "				8. NEFT Rejected </p>"
			+ " <p> <b>Rejected claims:</b> <br>" + "  <b>PMJJBY scheme: </b> <br>"
			+ "				1. Complete claim documents not submitted by claimants, <br>"
			+ "				2. Death during lien period, <br>"
			+ "				3. Death not established by documents submitted, <br>" + "				4. Others <br>"
			+ "  <b>PMSBY scheme: </b> <br>" + "				1. Duplicate claim, <br>"
			+ "				2. Death due to suicide, <br>" + "				3. Death is not due to accident, <br>"
			+ "				4. Disability not due to accident ,<br>"
			+ "				5. Disability not permanent ,<br>"
			+ "				6. Death / disability due to accident, not established by documents submitted ,<br>"
			+ "				7. Others";
	public static final String PLAIN_REQUEST_CLAIM = """
			<u>Date Format should be <b>yyyy-MM-dd HH:mm:ss</b></u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>Remarks is mandatory for Query revert claims</b></u><br>\
			<br><br><b> Review Example Description : documentList >>> documentId >>> Enum :</b> <br> \
			 4 - Signed and dully filled Claim cum discharge Form *, <br>\
			 5 - Death Certificate *, <br>\
			 6 - Hospital Discharge Summary *, <br>\
			 7 - Certificate issued by last attending Registered Medical Practitioner *,<br>\
			 8 - Certificate issued by District Magistrate/Collector/Deputy Commissioner *,<br>\
			 9 - FIR/Panchnama *, <br>\
			 10 - Hospital Records with deceased complete details *, <br>\
			 11 - KYC of Insured member *, <br>\
			 12 - KYC of Nominee/Claimant *, <br>\
			 13 - Passbook of A/C or cancelled cheque of the A/C of nominee /appointee/claimant *, <br>\
			 14 - Nominee Death Certificate *, <br>\
			 15 - Legal Heir Certificate *, <br>\
			 16 - Others *, <br>\
			 17 - Disability Certificate issued by Civil Surgeon *, <br>\
			 18 - Hospital records supporting the disability *, <br>\
			 19 - Checklist  *, <br>\
			 20 - Copy of Passbook of Insured *, <br>\
			 21 - Post mortem Report *, <br>\
			 22 - Aadhar/PAN of Nominee/Claimant *,<br>\
			 23 - Aadhar/PAN of Insured Member *</p><br>\
			""";
	public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";
	public static final String ENROLLMENT_DETAILS = "To push Enrolment details of the ETB customer to JS portal via other channels of the Bank";
	public static final String PLAIN_REQUEST_DOB_DATE = "Date Format should be <b> yyyy-MM-dd HH:mm:ss</b><u><br><br><u>Date Of Birth Date Format should be <b>yyyy-MM-dd</b></u><br><br><u><b>If Nominee is minor then Guardian details are mandtory.</b><u><br><br><u><b>disabilityStatus and disabitlityDetails are mandatory for PMSBY and not applicable for PMJJBY.</b><u><br><br><b>If disabilitystatus is Yes(Y) then disabilitydetails is mandatory and if disablitystatus is No(N) then disabilitydetails will be null.</b><br><br>Driving license format <b>SS-RRYYYYNNNNNNN , SSRRYYYYNNNNNNN</b>  OR <b>SSRR YYYYNNNNNNN (5th Character is Space)</b> Ex: RJ-1320120123456, RJ1320120123456 OR RJ13 20120123456";
	public static final String ENROLLMENT_PLAIN_REQUEST_EXAMPLE = "{\"token\":\"string\",\"customerDetails\":{\"accountNumber\":\"565888744\",\"cif\":\"stringstri\",\"customerIFSC\":\"string\",\"accountHolderName\":\"Rajeshbhai\",\"gender\":\"M\",\"fatherHusbandName\":\"RRameshBhai\",\"dob\":\"2000-08-08\",\"mobileNumber\":\"7567794689\",\"emailId\":\"xyz@gmail.com\",\"addressLine1\":\"Isanpur\",\"addressLine2\":\"Isanpur\",\"city\":\"Ahmedabad\",\"district\":\"string\",\"state\":\"Gujarat\",\"pincode\":382443,\"disabilityStatus\":\"Y\",\"disabilityDetails\":\"stringstri\",\"applicantOccupation\":\"worker\"},\"kycDetails\":{\"kycId1\":\"PAN\",\"kycIdValue1\":\"AAGFV5271N\",\"panNumber\":\"AAGFV5271N\",\"aadhaarNumber\":\"548537793745\"},\"nomineeDetails\":{\"nomineeName\":\"Rajesh\",\"dob\":\"2000-08-08\",\"mobile\":\"8787854563\",\"relationShip\":\"Father\",\"emailId\":\"abc@gmail.com\",\"addressOfNominee\":\"nikol,ahemedabad\"},\"guardianDetails\":{\"guradianName\":\"Rock\",\"addressofGuardian\":\"Isanpur\",\"relationShip\":\"Father\",\"mobile\":\"7568898968\",\"emailId\":\"xyz@mail.com\"},\"otherDetails\":{\"schemeName\":\"string\",\"bankCode\":\"string\",\"branchCode\":\"string\",\"consentForAutoDebit\":\"Yes\",\"userId1\":\"string\",\"userId2\":\"string\",\"channelId\":\"string\"}}";
	public static final String ENCRYPTED_REQUEST_EXAMPLE = "{\n \"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
	public static final String ENCRYPTED_RESPONSE = "{\n\"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";
	public static final String UPDATE_TRANSACTION_DETAILS = "To push the successful transaction details for the premium debit from customer's A/C";

	public static final String COMMON_DATA_MESSAGE_ENROLLMENT = """
			In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
			1. 200 - Success
			2. 208 - Already Reported(Customer is already enrolled with Scheme or Enrollment in process with other bank.)
			3. 500 - Internal Server Error
			4. 400 - Parameter Missing in Request (Bad Request)
			5. 400 - Invalid Application Reference Id  (Bad Request)\
			""";

	public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
	public static final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	public static final String DATE_FORMAT_DESCRIPTION_DATE = "<u>Date Format should be <b>dd/MM/yyyy<b><u>";

	public static final String COMMON_DATA_MESSAGE_DE_DUPE = """
			In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
			1. 200 - Success
			2. 204 - Data(de-dupe) Not Found.
			3. 500 - Internal Server Error
			4. 400 - Parameter Missing in Request (Bad Request)
			5. 400 - Invalid Application Reference Id  (Bad Request)\
			""";

	public static final String COMMON_DATA_MESSAGE = """
			In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
			1. 200 (flag: true) - Success
			2. 500 (flag: false) - Internal Server Error
			3. 400 (flag: false) - Parameter Missing in Request (Bad Request)
			4. 400 (flag: false) - Request Header is Null or Invalid  (Bad Request)\
			""";

	public static final String TRIGGER_OTP_DATA_MESSAGE = """


			Trigger OTP error code:

			1. 400 (flag: false) - Account Number Invalid
			2. 400 (flag: false) - Account Inactivated
			3. 400 (flag: false) - Mobile number is not linked with requested account number
			4. 500 (flag: false) - Internal server error while sending OTP
			""";

	public static final String VERIFY_OTP_DATA_MESSAGE = """


			Verify OTP error code:

			1. 400 (flag: false) - Account Number Invalid
			2. 400 (flag: false) - Account Inactivated
			3. 400 (flag: false) - Invalid OTP\s
			4. 500 (flag: false) - Internal server error while verifying OTP
			""";

	public static final String PHYSICAL_VERIFICATION_DATA_MESSAGE = """


			Physical Signature Verification error code:

			1. 400 (flag: false) - Account Number Invalid
			2. 400 (flag: false) - Account Inactivated
			3. 400 (flag: false) - No account holder details found\s
			""";

	public static final String CUSTOMER_RECORD_DATA_MESSAGE = """


			Customer Record error code:

			1. 400 (flag: false) - Account Number Invalid
			2. 400 (flag: false) - Account Inactivated
			3. 400 (flag: false) - CIF null or invalid found\s
			5. 400 (flag: false) - No data found from account number and CIF\s
			""";

	public static final String PAYMENT_DATA_MESSAGE = """


			Premium Deduction error code:

			1. 400 (flag: false) - Account Number Invalid
			2. 400 (flag: false) - Account Inactivated
			3. 400 (flag: false) - Insurer Account Number Invalid
			4. 400 (flag: false) - Insurer Account Inactivated
			5. 500 (flag: false) - Insernal server error while payment deduction\s
			""";

	public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
	public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";

	public static final String STATUS = "status";

	public static final String SUCCESS = "Success";

	public static final String FAILED = "Failed";
	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";

	public static final String STR_1 = "1";
	public static final String STR_2 = "2";
	public static final String STR_3 = "3";
	public static final String STR_4 = "4";
	public static final String STR_5 = "5";
	public static final String STR_6 = "6";
	public static final String STR_7 = "7";
	public static final String STR_8 = "8";
	public static final String STR_9 = "9";
	public static final String STR_10 = "10";
	public static final String STR_11 = "11";
	public static final String STR_12 = "12";
	public static final String STR_13 = "13";
	public static final String STR_14 = "14";
	public static final String STR_15 = "15";
	public static final String STR_16 = "16";
	public static final String STR_17 = "17";
	public static final String STR_18 = "18";
	public static final String STR_19 = "19";
	public static final String STR_20 = "20";
	public static final String STR_21 = "21";
	public static final String STR_22 = "22";
	public static final String STR_23 = "23";
	public static final String STR_24 = "24";
	public static final String STR_25 = "25";
	public static final String STR_26 = "26";

	public static final String STRING_400 = "400";
	public static final String STRING_200 = "200";
	public static final String STRING_401 = "401";

}