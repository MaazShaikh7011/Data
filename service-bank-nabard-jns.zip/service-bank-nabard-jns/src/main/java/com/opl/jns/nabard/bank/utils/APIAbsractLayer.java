package com.opl.jns.nabard.bank.utils;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestFactory;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import com.opl.jns.nabard.bank.service.ManageRequestBankWise;
import com.opl.jns.nabard.config.updated.apiconfig.enums.APIType;
import com.opl.jns.nabard.config.updated.restcall.service.RestAPIService;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class APIAbsractLayer implements ManageRequestBankWise {

	public TriggerOtpResponse triggerOtpRequest(RestAPIService restAPIService, TriggerOtpRequest triggerOtpReq,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		log.info("START TRIGGER OTP REQUEST "
				+ CommonUtils.printLogs(triggerOtpReq.getOrgId(), APIType.B_EN_AS_TRIGGER_OTP, referenceId));
		TriggerOtpResponse triggerOtpRes = new TriggerOtpResponse();

		Long orgId = triggerOtpReq.getOrgId();
		triggerOtpReq.setOrgId(null);
		triggerOtpReq.setApplicationId(null);

		return restAPIService.post(triggerOtpReq, orgId, APIType.B_EN_AS_TRIGGER_OTP, triggerOtpRes, referenceId,
				additionalHeaders, requestFactory);
	}

	public VerifyOtpApiResponse verifyOtpRequest(RestAPIService restAPIService, OTPRequest otpRequest,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		log.info("START VERIFY OTP REQUEST "
				+ CommonUtils.printLogs(otpRequest.getOrgId(), APIType.B_EN_AS_VERIFY_OTP, referenceId));

		VerifyOtpApiResponse verifyOtpApiRes = new VerifyOtpApiResponse();

		Long orgId = otpRequest.getOrgId();
		otpRequest.setOrgId(null);
		otpRequest.setApplicationId(null);

		return restAPIService.post(otpRequest, orgId, APIType.B_EN_AS_VERIFY_OTP, verifyOtpApiRes, referenceId,
				additionalHeaders, requestFactory);
	}

	public CustomerDetailsDataV3 customerDetailsRequestV3(RestAPIService restAPIService,
			CustomerDetailsRequest custDetailsReq, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {

		log.info("START GET CUSTOMER DETAILS REQUEST "
				+ CommonUtils.printLogs(custDetailsReq.getOrgId(), APIType.B_EN_AS_GET_CUSTOMER_DTLS, referenceId));

		Long orgId = custDetailsReq.getOrgId();
		custDetailsReq.setOrgId(null);
		custDetailsReq.setApplicationId(null);

		CustomerDetailsResponseV3 custDetailsRes = new CustomerDetailsResponseV3();
		custDetailsRes = restAPIService.post(custDetailsReq, orgId, APIType.B_EN_AS_GET_CUSTOMER_DTLS, custDetailsRes,
				referenceId, additionalHeaders, requestFactory);

		CustomerDetailsDataV3 detailResp = new CustomerDetailsDataV3();
		BeanUtils.copyProperties(custDetailsRes, detailResp);

		if (Boolean.TRUE
				.equals(!OPLUtils.isObjectNullOrEmpty(custDetailsRes.getSuccess()) && custDetailsRes.getSuccess()
						&& !OPLUtils.isObjectNullOrEmpty(custDetailsRes.getStatus()))
				&& custDetailsRes.getStatus() == HttpStatus.OK.value()) {
			AccountHolderDetailsV3 accDtl = custDetailsRes.getAccountHolderDetails();
			if (!OPLUtils.isObjectNullOrEmpty(accDtl)) {
				AccountHolderDetailsResponseV3 res = new AccountHolderDetailsResponseV3();
				BeanUtils.copyProperties(accDtl, res);
				try {
					detailResp = CommonUtils.setAccountHolderDtlV3(accDtl, res, detailResp, custDetailsReq.getOrgId());
				} catch (Exception e) {
					detailResp.setMessage(
							"It seems the application encounter error while getting account holder details from bank API response, please try after some time");
					detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					log.error("Exception while converting account holder details -->", e);
				}
			} else {
				detailResp.setMessage(
						"Its seems we have not found customer details from CBS, Please attempt the operation again after some time");
				detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}
		return detailResp;
	}

	public PremiumDeductionResponse premiumDeductionRequest(RestAPIService restAPIService,
			PremiumDeductionRequest premDeducReq, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {

		log.info("START PREMIUM DEDUCT REQUEST "
				+ CommonUtils.printLogs(premDeducReq.getOrgId(), APIType.B_EN_AS_PREMIUM_DEDUCT, referenceId));

		PremiumDeductionResponse premDeductRes = new PremiumDeductionResponse();

		Long orgId = premDeducReq.getOrgId();
		premDeducReq.setOrgId(null);
		premDeducReq.setApplicationId(null);

		return restAPIService.post(premDeducReq, orgId, APIType.B_EN_AS_PREMIUM_DEDUCT, premDeductRes, referenceId,
				additionalHeaders, requestFactory);
	}

	public PhysicalVerificationResponse getPhysicalVerification(RestAPIService restAPIService, OTPRequest phyVrfReq,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {

		log.info("START PHYSICAL VERIFICATION REQUEST "
				+ CommonUtils.printLogs(phyVrfReq.getOrgId(), APIType.B_EN_AS_PHYSICAL_SIGN, referenceId));

		PhysicalVerificationResponse physclVrfyRes = new PhysicalVerificationResponse();

		Long orgId = phyVrfReq.getOrgId();
		phyVrfReq.setOrgId(null);
		phyVrfReq.setApplicationId(null);

		return restAPIService.post(phyVrfReq, orgId, APIType.B_EN_AS_PHYSICAL_SIGN, physclVrfyRes, referenceId,
				additionalHeaders, requestFactory);

	}

	public AccHolderListResponse getAccHolderList(RestAPIService restAPIService, AccHolderListRequest accHolderListReq,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {

		log.info("START GET ACCOUNT HOLDER LIST REQUEST "
				+ CommonUtils.printLogs(accHolderListReq.getOrgId(), APIType.B_EN_AS_GET_ACC_HLDR_DTLS, referenceId));

		AccHolderListResponse accHolderListResponse = new AccHolderListResponse();

		Long orgId = accHolderListReq.getOrgId();
		accHolderListReq.setOrgId(null);
		accHolderListReq.setApplicationId(null);

		return restAPIService.post(accHolderListReq, orgId, APIType.B_EN_AS_GET_ACC_HLDR_DTLS, accHolderListResponse,
				referenceId, additionalHeaders, requestFactory);

	}

	public PolicyDetailsResponse getPolicyDetails(RestAPIService restAPIService,
			PolicyDetailsRequest policyDetailsRequest, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {

		log.info("START GET POLICY DETAILS REQUEST "
				+ CommonUtils.printLogs(policyDetailsRequest.getOrgId(), APIType.B_EN_AS_GET_POLICY_DTLS, referenceId));

		PolicyDetailsResponse policyDetailsResponse = new PolicyDetailsResponse();

		Long orgId = policyDetailsRequest.getOrgId();
		policyDetailsRequest.setOrgId(null);
		policyDetailsRequest.setApplicationId(null);

		PolicyDetailsResponse detailsResponse = restAPIService.post(policyDetailsRequest, orgId,
				APIType.B_EN_AS_GET_POLICY_DTLS, policyDetailsResponse, referenceId, additionalHeaders, requestFactory);
		log.info("START GET POLICY DETAILS RESPONSE ----------------> " + detailsResponse);
		return detailsResponse;

	}

	public APIResponse pushEnrollmentRequest(RestAPIService restAPIService, String referenceId,
			PushEnrollmentDetailsRequest pushEnrollRequest, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = pushEnrollRequest.getOrgId();
		String refId = pushEnrollRequest.getReferenceId();
		pushEnrollRequest.setApplicationId(null);
		pushEnrollRequest.setReferenceId(null);
		log.info("START PUSH ENROLLMENTREQUEST " + CommonUtils.printLogs(orgId, APIType.B_EN_CM_PUSH_ENRL_DTLS, refId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(pushEnrollRequest, orgId, APIType.B_EN_CM_PUSH_ENRL_DTLS, commonResponse, refId,
				additionalHeaders, requestFactory);

	}

	public APIResponse nomineeUpdateStatus(RestAPIService restAPIService,
			NomineeUpdateStatusRequest nomineeUpdateStatusRequest, String referenceId,
			Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		Long orgId = nomineeUpdateStatusRequest.getOrgId();
		nomineeUpdateStatusRequest.setOrgId(null);
		nomineeUpdateStatusRequest.setApplicationId(null);
		log.info("START UPDATE NOMINEE STATUS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.B_EN_DIY_NMN_UPDT_STS, referenceId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(nomineeUpdateStatusRequest, orgId, APIType.B_EN_DIY_NMN_UPDT_STS, commonResponse,
				referenceId, additionalHeaders, requestFactory);

	}

	public APIResponse optOutUpdateStatus(RestAPIService restAPIService,
			OptOutUpdateStatusRequest outUpdateStatusRequest, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = outUpdateStatusRequest.getOrgId();
		outUpdateStatusRequest.setOrgId(null);
		outUpdateStatusRequest.setApplicationId(null);
		log.info("START UPDATE OPT OUT STATUS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.B_EN_DIY_OPT_OUT_UPDT_STS, referenceId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(outUpdateStatusRequest, orgId, APIType.B_EN_DIY_OPT_OUT_UPDT_STS, commonResponse,
				referenceId, additionalHeaders, requestFactory);

	}

	public APIResponse pushClaimRequest(RestAPIService restAPIService, PushClaimDetailsRequest claimDetailsRequest,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		Long orgId = claimDetailsRequest.getOrgId();
		claimDetailsRequest.setOrgId(null);
		claimDetailsRequest.setApplicationId(null);
		claimDetailsRequest.setUserId(null);
		log.info(
				"START PUSH CLAIM REQUEST " + CommonUtils.printLogs(orgId, APIType.B_CL_CM_PUSH_CLM_DTLS, referenceId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(claimDetailsRequest, orgId, APIType.B_CL_CM_PUSH_CLM_DTLS, commonResponse,
				referenceId, additionalHeaders, requestFactory);

	}

	public APIResponse pushClaimStatustoBank(RestAPIService restAPIService,
			PushClaimStatustoBankReq pushClaimStatustoBankReq, String referenceId,
			Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		Long orgId = pushClaimStatustoBankReq.getOrgId();
		pushClaimStatustoBankReq.setOrgId(null);
		pushClaimStatustoBankReq.setApplicationId(null);
		log.info("START PUSH CLAIM STATUS TO BANK REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.B_CL_AS_CLM_STS, referenceId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(pushClaimStatustoBankReq, orgId, APIType.B_CL_AS_CLM_STS, commonResponse,
				referenceId, additionalHeaders, requestFactory);

	}

	public EnrollmentResProxyV3 otherChannelEnrollment(RestAPIService restAPIService,
			EnrollmentReqProxyV3 enrollmentReqProxy, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = enrollmentReqProxy.getOrgId();
		enrollmentReqProxy.setOrgId(null);
		enrollmentReqProxy.setApplicationId(null);
		log.info("START OTHER CHANNEL ENROLLMENT BANK REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_EN_OC_ENROLLMENT, referenceId));
		EnrollmentResProxyV3 commonResponse = new EnrollmentResProxyV3();
		return restAPIService.post(enrollmentReqProxy, orgId, APIType.J_EN_OC_ENROLLMENT, commonResponse, referenceId,
				additionalHeaders, requestFactory);
	}

	public UpdateTransResProxyV3 otherChannelUpdateTransaction(RestAPIService restAPIService,
			UpdateTransReqProxyV3 transactionRequest, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = transactionRequest.getOrgId();
		transactionRequest.setOrgId(null);
		transactionRequest.setApplicationId(null);
		log.info("START OTHER CHANNEL UPDATE TRANSACTION BANK REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_EN_OC_UPDT_TRNSCN_DTLS, referenceId));
		UpdateTransResProxyV3 commonResponse = new UpdateTransResProxyV3();
		return restAPIService.post(transactionRequest, orgId, APIType.J_EN_OC_UPDT_TRNSCN_DTLS, commonResponse,
				referenceId, additionalHeaders, requestFactory);
	}

	public UpdateStatusResProxyV3 otherChannelUpdateEnrollStatus(RestAPIService restAPIService,
			UpdateStatusReqProxyV3 statusReqProxy, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = statusReqProxy.getOrgId();
		statusReqProxy.setOrgId(null);
		statusReqProxy.setApplicationId(null);
		log.info("START OTHER CHANNEL UPDATE ENROLLMENT STATUS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_EN_OC_UPDT_ENR_STS, referenceId));
		UpdateStatusResProxyV3 commonResponse = new UpdateStatusResProxyV3();
		return restAPIService.post(statusReqProxy, orgId, APIType.J_EN_OC_UPDT_ENR_STS, commonResponse, referenceId,
				additionalHeaders, requestFactory);
	}

	public ClaimDetailsResProxyV3 otherChannelClaimDetails(RestAPIService restAPIService,
			ClaimDetailsReqProxyV3 claimDetailsReq, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = claimDetailsReq.getOrgId();
		claimDetailsReq.setOrgId(null);
		claimDetailsReq.setApplicationId(null);
		log.info("START OTHER CHANNEL CLAIM DETAILS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_CL_OC_CLM_DTLS, referenceId));
		ClaimDetailsResProxyV3 commonResponse = new ClaimDetailsResProxyV3();
		return restAPIService.post(claimDetailsReq, orgId, APIType.J_CL_OC_CLM_DTLS, commonResponse, referenceId,
				additionalHeaders, requestFactory);
	}

	public APIResponse otherChannelClaimUploadDoc(RestAPIService restAPIService,
			ClaimUploadDocsReqProxyV3 uploadDocsReq, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = uploadDocsReq.getOrgId();
		uploadDocsReq.setOrgId(null);
		uploadDocsReq.setApplicationId(null);
		log.info("START OTHER CHANNEL CLAIM UPLOAD DOCUMENTS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_CL_OC_CLM_UPLD_DOCS, referenceId));
		APIResponse commonResponse = new APIResponse();
		return restAPIService.post(uploadDocsReq, orgId, APIType.J_CL_OC_CLM_UPLD_DOCS, commonResponse, referenceId,
				additionalHeaders, requestFactory);
	}

	public MisEnrollmentResProxyV3 misEnrollmentDetails(RestAPIService restAPIService, MisEnrollmentReqV3 enrollmentReq,
			String referenceId, Map<String, String> additionalHeaders, ClientHttpRequestFactory requestFactory)
			throws CommonException, IOException {
		Long orgId = enrollmentReq.getOrgId();
		enrollmentReq.setOrgId(null);
		enrollmentReq.setApplicationId(null);
		log.info("START MIS ENROLLMENT DETAILS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_EN_CM_MIS_ENRL_DTLS, referenceId));
		MisEnrollmentResProxyV3 commonResponse = new MisEnrollmentResProxyV3();
		return restAPIService.post(enrollmentReq, orgId, APIType.J_EN_CM_MIS_ENRL_DTLS, commonResponse, referenceId,
				additionalHeaders, requestFactory);
	}

	public NomieeUpdateResponse otherChannelNomineeUpdate(RestAPIService restAPIService,
			NomineeUpdateRequest nomineeUpdateRequest, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException {
		Long orgId = nomineeUpdateRequest.getOrgId();
		nomineeUpdateRequest.setOrgId(null);
		nomineeUpdateRequest.setApplicationId(null);
		log.info("START MIS ENROLLMENT DETAILS REQUEST "
				+ CommonUtils.printLogs(orgId, APIType.J_EN_OC_UPDT_NMN_DTLS, referenceId));
		NomieeUpdateResponse commonResponse = new NomieeUpdateResponse();
		return restAPIService.post(nomineeUpdateRequest, orgId, APIType.J_EN_OC_UPDT_NMN_DTLS, commonResponse,
				referenceId, additionalHeaders, requestFactory);
	}

}
