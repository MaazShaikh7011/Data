package com.opl.jns.nabard.bank.external.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.Response400;
import com.opl.jns.api.proxy.banks.v1.Response401;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import com.opl.jns.nabard.bank.service.FactoryService;
import com.opl.jns.nabard.bank.utils.CommonUtils;
import com.opl.jns.nabard.bank.utils.Constants;
import com.opl.jns.nabard.config.updated.common.utils.security.SecurityUtility;
import com.opl.jns.utils.common.OPLUtils;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
@Tag(name = "8. MIS Office", description = "List of Mis api")
public class MisController {

	@Autowired
	public FactoryService factoryService;

	@PostMapping("/misEnrollmentDetails")
	@Operation(operationId = Constants.STR_18, summary = Constants.MIS_ENROLLMENT_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.MIS_ENROLLMENT_API_PLAIN_REQUEST, description = Constants.PLAIN_REQUEST_MIS_LBL),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STRING_200, description = Constants.COMMON_DATA_MESSAGE_ENROLLMENT, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = EnrollmentResProxyV3.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_RESPONSE_SUCCESS),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Response400.PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STRING_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)) }) })
	public ResponseEntity<MisEnrollmentResProxyV3> misEnrollmentApi(
			@Valid @RequestBody MisEnrollmentReqV3 applicationRequest, HttpServletRequest httpServletRequest) {
		log.info("START MIS ENROLLMENT DETAILS ----------------> " + applicationRequest.getToken());
		MisEnrollmentResProxyV3 enrollmentResProxy = null;
		try {
			if (OPLUtils.isObjectNullOrEmpty(applicationRequest.getOrgId())) {
				return new ResponseEntity<>(
						new MisEnrollmentResProxyV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			enrollmentResProxy = factoryService.misEnrollmentDetails(applicationRequest, applicationRequest.getToken());
			log.info("END MIS ENROLLMENT DETAILS ----------------> " + enrollmentResProxy.getToken());
			return new ResponseEntity<>(enrollmentResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE MIS ENROLLMENT DETAILS REQUEST  ---" + enrollmentResProxy.getToken() + "---", e);
			return new ResponseEntity<>(new MisEnrollmentResProxyV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

}