package com.opl.jns.nabard.bank.service;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponse;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponse;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequest;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponse;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReq;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequest;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponse;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequest;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponse;
import com.opl.jns.api.proxy.common.APIResponse;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.detail.ClaimDetailsResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.claim.uploaddocs.ClaimUploadDocsReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.enrolldtls.EnrollmentResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomieeUpdateResponse;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.nomineeupdt.NomineeUpdateRequest;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updateenrollstatus.UpdateStatusResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransReqProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.otherchannel.enrollment.updatetrans.UpdateTransResProxyV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentReqV3;
import com.opl.jns.api.proxy.jansuraksha.v3.others.mis.enrollment.MisEnrollmentResProxyV3;
import org.springframework.http.client.ClientHttpRequestFactory;

import java.io.IOException;

public interface ManageRequestBankWise {

	public TriggerOtpResponse triggerOtpRequest(TriggerOtpRequest triggerOtpRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public VerifyOtpApiResponse verifyOtpRequest(OTPRequest otpRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public CustomerDetailsDataV3 customerDetailsRequestV3(CustomerDetailsRequest customerDetailsRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public PremiumDeductionResponse premiumDeductionRequest(PremiumDeductionRequest premiumDeductionRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public PhysicalVerificationResponse getPhysicalVerification(OTPRequest otpRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public AccHolderListResponse getAccHolderList(AccHolderListRequest holderListRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public PolicyDetailsResponse getPolicyDetails(PolicyDetailsRequest policyDetailsRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse pushEnrollmentRequest(PushEnrollmentDetailsRequest pushEnrollmentDetailsRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse nomineeUpdateStatus(NomineeUpdateStatusRequest nomineeUpdateStatusRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse optOutUpdateStatus(OptOutUpdateStatusRequest outUpdateStatusRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse pushClaimRequest(PushClaimDetailsRequest pushClaimDetailsRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse pushClaimStatustoBank(PushClaimStatustoBankReq pushClaimStatustoBankReq, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public EnrollmentResProxyV3 otherChannelEnrollment(EnrollmentReqProxyV3 enrollmentReqProxy, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public UpdateTransResProxyV3 otherChannelUpdateTransaction(UpdateTransReqProxyV3 transactionRequest,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public UpdateStatusResProxyV3 otherChannelUpdateEnrollStatus(UpdateStatusReqProxyV3 statusApiReq,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public ClaimDetailsResProxyV3 otherChannelClaimDetails(ClaimDetailsReqProxyV3 claimDetailsResProxy,
			String referenceId, ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public APIResponse otherChannelClaimUploadDoc(ClaimUploadDocsReqProxyV3 claimUploadDocuments, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public MisEnrollmentResProxyV3 misEnrollmentDetails(MisEnrollmentReqV3 applicationRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;

	public NomieeUpdateResponse otherChannelNomineeUpdate(NomineeUpdateRequest nomineeRequest, String referenceId,
			ClientHttpRequestFactory requestFactory) throws CommonException, IOException;
}
