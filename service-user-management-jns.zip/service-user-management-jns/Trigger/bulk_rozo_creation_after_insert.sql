create or replace TRIGGER JNS_USERS."bulk_rozo_creation_after_insert"
AFTER INSERT ON JNS_USERS.BULK_ROZO_CREATION
REFERENCING NEW AS NEW
FOR EACH ROW
DECLARE
   vParentBranchID NUMBER(19);
        vUserID NUMBER(19);
        vHOBranchID NUMBER(10);
        vLHOBranchID NUMBER(10);
BEGIN




	IF :NEW.is_active = 1 THEN

		SELECT branch_ho_id into vHOBranchID FROM jns_users.branch_product_mapping WHERE branch_ho_id IS NOT NULL AND user_org_id = :NEW.org_id AND rownum <= 1;
		SELECT DISTINCT branch_lho_id into vLHOBranchID FROM jns_users.branch_product_mapping WHERE branch_id = :NEW.branch_zo_id AND user_org_id = :NEW.org_id AND is_active=1;

		DELETE FROM jns_users.branch_product_mapping WHERE branch_id=:NEW.branch_id AND business_id=:NEW.business_type_id AND sch_type_id=:NEW.scheme_id AND user_org_id=:NEW.org_id;
		-- SQLINES LICENSE FOR EVALUATION USE ONLY
		INSERT INTO jns_users.branch_product_mapping (branch_id,business_id,sch_type_id,user_org_id,branch_ro_id,branch_zo_id,branch_lho_id,branch_ho_id,created_date,is_active)
		SELECT :NEW.branch_id,:NEW.business_type_id,:NEW.scheme_id,:NEW.org_id,:NEW.branch_ro_id,:NEW.branch_zo_id,vLHOBranchID,vHOBranchID,SYSTIMESTAMP,1 FROM DUAL;

		-- SQLINES DEMO *** .tblBranchChildParentMapping (branchID,branchROID,branchZOID,branchHOID,orgID,business_type_id)
	-- SQLINES DEMO *** chID,:NEW.ROBranchDBID,:NEW.ZOBranchDBID,:NEW.HOBranchDBID,:NEW.orgID,:NEW.BusinessTypeID FROM DUAL;

		IF :NEW.user_role_id = 5 THEN

			IF :NEW.branch_ro_id  > 0 AND :NEW.branch_ro_id IS NOT NULL THEN

				vUserID:=0;
				SELECT user_id into vUserID FROM jns_users.users WHERE email=:NEW.ro_email;

				IF (vUserID = 0 OR vUserID IS NULL) THEN

				    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    				INSERT INTO jns_users.users
					(email,password,mobile,user_type_id,user_org_id,user_role_id,branch_id,first_name,middle_name,last_name,sign_up_date,is_pass_changed,terms_accepted,is_active,created_date,otp_verified,email_verified)
					SELECT TRIM(:NEW.ro_email),'e10adc3949ba59abbe56e057f20f883e',:NEW.ro_mobile,2,:NEW.org_id,
					(SELECT role_id FROM jns_users.user_role_master WHERE TRIM(UPPER(role_name))='RO' AND is_active=1),:NEW.branch_ro_id,'Regional',NULL,'Officer',SYSTIMESTAMP,1,1,1,SYSTIMESTAMP,1,1
				    FROM DUAL
				    WHERE :NEW.ro_email NOT IN
				    (SELECT email FROM jns_users.users WHERE email IS NOT NULL AND (user_org_id=:NEW.org_id OR user_org_id IS NULL));

--				      vUserID := LAST_INSERT_ID();
                           vUserID :=USERS_MANA_SEQ.nextval;
--                      SELECT LAST_INSERT_ID() INTO vUserID from dual;

				    -- SQLINES DEMO *** THEN
	-- SQLINES DEMO *** sers.fund_provider_details(user_id,organization_name,created_date,modified_date,is_active,profile_filled,is_profile_locked)
	-- SQLINES DEMO *** D,(SELECT organisation_name FROM user_organisation_master WHERE user_org_id=:NEW.org_id),NOW(),NOW(),1,1,1
	-- 				FROM DUAL
	-- SQLINES DEMO ***  NOT IN (SELECT DISTINCT user_id FROM users.fund_provider_details);
	-- 			    END IF;

				  END IF;

				  UPDATE jns_users.users SET branch_id=:NEW.branch_ro_id WHERE user_id=vUserID;

				  DELETE FROM jns_users.user_role_product_mapping WHERE user_id=vUserID AND business_id=:NEW.business_type_id AND scheme_id=:NEW.scheme_id;
				  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  				INSERT INTO jns_users.user_role_product_mapping (user_id,user_role_id,business_id,scheme_id,created_date,is_active)
				  SELECT vUserID,(SELECT role_id FROM jns_users.user_role_master WHERE TRIM(UPPER(role_name))='RO' AND is_active=1),:NEW.business_type_id,:NEW.scheme_id,SYSTIMESTAMP,1 FROM DUAL;


			END IF;

			IF :NEW.branch_zo_id > 0 AND :NEW.branch_zo_id IS NOT NULL THEN

				vUserID:=0;
				SELECT user_id into vUserID FROM jns_users.users WHERE email=:NEW.zo_email;

				IF (vUserID = 0 OR vUserID IS NULL) THEN

				   -- SQLINES LICENSE FOR EVALUATION USE ONLY
   				INSERT INTO jns_users.users
					(email,password,mobile,user_type_id,user_org_id,user_role_id,branch_id,first_name,middle_name,last_name,sign_up_date,is_pass_changed,terms_accepted,is_active,created_date,otp_verified,email_verified)
					SELECT TRIM(:NEW.zo_email),'e10adc3949ba59abbe56e057f20f883e',:NEW.zo_mobile,2,:NEW.org_id,
					(SELECT role_id FROM jns_users.user_role_master WHERE TRIM(UPPER(role_name))='ZO' AND is_active=1),:NEW.branch_zo_id,'Zonal',NULL,'Officer',SYSTIMESTAMP,1,1,1,SYSTIMESTAMP,1,1
				    FROM DUAL
				    WHERE :NEW.zo_email NOT IN
				    (SELECT email FROM jns_users.users WHERE email IS NOT NULL AND (user_org_id=:NEW.org_id OR user_org_id IS NULL));

--				     vUserID := LAST_INSERT_ID();

                    vUserID :=USERS_MANA_SEQ.nextval;
				    -- SQLINES DEMO *** THEN
	-- SQLINES DEMO *** sers.fund_provider_details(user_id,organization_name,created_date,modified_date,is_active,profile_filled,is_profile_locked)
	-- SQLINES DEMO *** D,(SELECT organisation_name FROM user_organisation_master WHERE user_org_id=:NEW.org_id),NOW(),NOW(),1,1,1
	-- 				FROM DUAL
	-- SQLINES DEMO ***  NOT IN (SELECT DISTINCT user_id FROM users.fund_provider_details);
	-- 			    END IF;

				 END IF;

				 UPDATE jns_users.users SET branch_id=:NEW.branch_zo_id WHERE user_id=vUserID;

				 DELETE FROM jns_users.user_role_product_mapping WHERE user_id=vUserID AND business_id=:NEW.business_type_id AND scheme_id=:NEW.scheme_id;
				  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  				INSERT INTO jns_users.user_role_product_mapping (user_id,user_role_id,business_id,scheme_id,created_date,is_active)
				  SELECT vUserID,(SELECT role_id FROM jns_users.user_role_master WHERE TRIM(UPPER(role_name))='ZO' AND is_active=1),:NEW.business_type_id,:NEW.scheme_id,SYSTIMESTAMP,1 FROM DUAL;
			END IF;
			END IF;
	END IF;
    END;