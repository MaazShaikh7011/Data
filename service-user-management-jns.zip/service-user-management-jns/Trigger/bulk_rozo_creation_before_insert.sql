create or replace TRIGGER JNS_USERS."bulk_rozo_creation_before_insert"
BEFORE INSERT ON JNS_USERS.BULK_ROZO_CREATION
    REFERENCING NEW AS NEW
    FOR EACH ROW
    DECLARE
    vUserID NUMBER(10);
    vBOBranchID NUMBER(10);
    vZOBranchID NUMBER(10);
    vROBranchID NUMBER(10);
    vHOBranchID NUMBER(10);
BEGIN

    IF :NEW.user_role_id = 14 THEN
		IF :NEW.branch_code IS NOT NULL THEN
			IF (:NEW.ro_code IS NULL) THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO cannot be null';
			END IF;
		END IF;

--		:NEW.branch_code := TRIM(SUBSTRING_INDEX(:NEW.branch_code, ".", 1));
--		:NEW.ro_code := TRIM(SUBSTRING_INDEX(:NEW.ro_code, ".", 1));
--		:NEW.zo_code := TRIM(SUBSTRING_INDEX(:NEW.zo_code, ".", 1));

        :NEW.branch_code := TRIM(REGEXP_SUBSTR(:NEW.branch_code,'[^.]+',1,1));
		:NEW.ro_code := TRIM(REGEXP_SUBSTR(:NEW.ro_code,'[^.]+',1,1));
		:NEW.zo_code := TRIM(REGEXP_SUBSTR(:NEW.zo_code,'[^.]+',1,1));


		vZOBranchID:=0;
		vROBranchID:=0;

		SELECT branch_ho_id into vHOBranchID FROM jns_users.branch_product_mapping WHERE branch_ho_id IS NOT NULL AND user_org_id = :NEW.org_id AND rownum <= 1;

		IF (:NEW.branch_code IS NULL) THEN
			:NEW.is_active := 0;
			:NEW.msg := 'Branch Code cannot be null';
		END IF;

		IF :NEW.branch_code IS NOT NULL THEN

			SELECT id into vBOBranchID FROM jns_users.branch_master WHERE CODE=:NEW.branch_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=1 AND rownum <= 1;

			IF (vBOBranchID = 0 OR vBOBranchID IS NULL) THEN
				:NEW.is_active := 0;
				:NEW.msg := 'Branch is not valid';
			END IF;

			IF (vBOBranchID IS NOT NULL) THEN
				SELECT DISTINCT branch_id into vBOBranchID FROM jns_users.branch_product_mapping WHERE branch_id=vBOBranchID AND user_org_id=:NEW.org_id AND branch_zo_id = :NEW.branch_zo_id AND is_active=1;

				IF (vBOBranchID = 0 OR vBOBranchID IS NULL) THEN
					:NEW.is_active := 0;
					:NEW.msg := 'BO is not mapped with current ZO';
				END IF;
			END IF;
		END IF;

-- SQLINES DEMO *** =(SELECT id FROM jns_users.branch_master WHERE CODE=:NEW.branch_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=1 limit 1);

-- SQLINES DEMO *** ranchID)>1) then
-- SQLINES DEMO *** ive = 0;
-- SQLINES DEMO *** 'Multiple entries of  Branchcode';
-- 		END IF;

		:NEW.branch_id := vBOBranchID;

		-- SQLINES DEMO *** IS NULL THEN
-- SQLINES DEMO *** ive = 0;
-- SQLINES DEMO *** 'Branch is not valid';
-- 		END IF;

		SELECT id into vZOBranchID FROM jns_users.branch_master WHERE CODE=:NEW.zo_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=3;

		:NEW.branch_zo_id:=vZOBranchID;

		IF :NEW.branch_zo_id=0 OR :NEW.branch_zo_id IS NULL THEN
			vZOBranchID := vHOBranchID;
		END IF;

		IF :NEW.ro_code IS NOT NULL THEN

			SELECT id into vROBranchID FROM jns_users.branch_master WHERE CODE=:NEW.ro_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=2;

			IF (vROBranchID = 0 OR vROBranchID IS NULL) THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO is not valid';
			END IF;

			IF (vROBranchID IS NOT NULL) THEN
				SELECT DISTINCT branch_id into vROBranchID FROM jns_users.branch_product_mapping WHERE branch_id=vROBranchID AND user_org_id=:NEW.org_id AND branch_zo_id = :NEW.branch_zo_id AND is_active=1;

				IF (vROBranchID = 0 OR vROBranchID IS NULL) THEN
					:NEW.is_active := 0;
					:NEW.msg := 'RO is not mapped with current ZO';
				END IF;
			END IF;
		END IF;

		IF :NEW.is_active = 1 THEN
			:NEW.msg := 'Saved Succesfully';
		END IF;

		:NEW.branch_ro_id:=vROBranchID;

	ELSE


		IF :NEW.branch_code IS NOT NULL THEN
			IF (:NEW.ro_code IS NULL AND :NEW.zo_code IS NULL) THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO and ZO details cannot be null';
			END IF;
		END IF;

		IF :NEW.ro_code IS NOT NULL THEN
			IF :NEW.ro_email IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO Email cannot be null';
			ELSIF :NEW.ro_mobile IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO Mobile cannot be null';
			ELSIF :NEW.ro_name IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO Name cannot be null';
			ELSIF :NEW.ro_address IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO Address cannot be null';
			ELSIF :NEW.ro_pincode IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO pincode cannot be null';
			ELSIF :NEW.ro_city_id IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO City cannot be null';
			ELSIF :NEW.ro_state_id IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'RO State cannot be null';
			END IF;
		END IF;

		IF :NEW.zo_code IS NOT NULL THEN
			IF :NEW.zo_email IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO Email cannot be null';
			ELSIF :NEW.zo_mobile IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO Mobile cannot be null';
			ELSIF :NEW.zo_name IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO Name cannot be null';
			ELSIF :NEW.zo_address IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO Address cannot be null';
			ELSIF :NEW.zo_pincode IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO pincode cannot be null';
			ELSIF :NEW.zo_city_id IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO City cannot be null';
			ELSIF :NEW.zo_state_id IS NULL THEN
				:NEW.is_active := 0;
				:NEW.msg := 'ZO State cannot be null';
			END IF;
		END IF;

		:NEW.ro_email := TRIM(:NEW.ro_email);
--		:NEW.ro_mobile := TRIM(SUBSTRING_INDEX(:NEW.ro_mobile, ".", 1));
        :NEW.ro_mobile := TRIM(REGEXP_SUBSTR(:NEW.ro_mobile,'[^.]+',1,1));
		:NEW.zo_email := TRIM(:NEW.zo_email);
--		:NEW.zo_mobile := TRIM(SUBSTRING_INDEX(:NEW.zo_mobile, ".", 1));
--		:NEW.branch_code := TRIM(SUBSTRING_INDEX(:NEW.branch_code, ".", 1));
--		:NEW.ro_code := TRIM(SUBSTRING_INDEX(:NEW.ro_code, ".", 1));
--		:NEW.zo_code := TRIM(SUBSTRING_INDEX(:NEW.zo_code, ".", 1));
        :NEW.zo_mobile :=  TRIM(REGEXP_SUBSTR(:NEW.zo_mobile,'[^.]+',1,1));
		:NEW.branch_code := TRIM(REGEXP_SUBSTR(:NEW.branch_code,'[^.]+',1,1));
		:NEW.ro_code := TRIM(REGEXP_SUBSTR(:NEW.ro_code,'[^.]+',1,1));
		:NEW.zo_code := TRIM(REGEXP_SUBSTR(:NEW.zo_code,'[^.]+',1,1));

		vZOBranchID:=0;
		vROBranchID:=0;

		SELECT branch_ho_id into vHOBranchID FROM jns_users.branch_product_mapping WHERE branch_ho_id IS NOT NULL AND user_org_id = :NEW.org_id AND rownum <= 1;

		SELECT id into vBOBranchID FROM jns_users.branch_master WHERE CODE=:NEW.branch_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=1 AND rownum <= 1;
		:NEW.branch_id := vBOBranchID;

		IF (:NEW.branch_code IS NULL) THEN
			:NEW.is_active := 0;
			:NEW.msg := 'Branch Code cannot be null';
		END IF;

		IF :NEW.branch_id IS NULL THEN
			:NEW.is_active := 0;
			:NEW.msg := 'Branch cannot be null';
		END IF;

		SELECT id into vZOBranchID FROM jns_users.branch_master WHERE CODE=:NEW.zo_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=3;

		-- SQLINES DEMO *** S NOT NULL AND vZOBranchID > 0) THEN
	-- SQLINES DEMO *** ve = 0;
	-- SQLINES DEMO *** ZO already exists in system';
	--
	-- 	end if;

		IF ((vZOBranchID = 0 OR vZOBranchID IS NULL) AND :NEW.zo_code IS NOT NULL AND LENGTH(TRIM(:NEW.zo_code))>0 AND :NEW.is_active = 1) THEN

			-- SQLINES LICENSE FOR EVALUATION USE ONLY
			INSERT INTO jns_users.branch_master
			(CODE,NAME,org_id,street_name,country_id,state_id,city_id,pincode,is_active,is_deleted,created_on,modified_date,msme,pl,parent_branch_id,branch_type)
			SELECT TRIM(CAST(:NEW.zo_code AS CHAR(200))),TRIM(:NEW.zo_name),:NEW.org_id,TRIM(:NEW.zo_address),'101',:NEW.zo_state_id,:NEW.zo_city_id,:NEW.zo_pincode,
			1,0,SYSTIMESTAMP,SYSTIMESTAMP,1,0,vHOBranchID,3
			FROM DUAL;

			vZOBranchID := BRANCH_MASTER_SEQ.nextval;

		END IF;

		:NEW.branch_zo_id:=vZOBranchID;

		IF :NEW.branch_zo_id=0 OR :NEW.branch_zo_id IS NULL THEN
			vZOBranchID := vHOBranchID;
		END IF;

		SELECT id into vROBranchID FROM jns_users.branch_master WHERE CODE=:NEW.ro_code AND org_id=:NEW.org_id AND is_active=1 AND branch_type=2;

		-- SQLINES DEMO *** S NOT NULL AND vROBranchID > 0) THEN
	-- SQLINES DEMO *** ve = 0;
	-- SQLINES DEMO *** RO already exists in system';
	-- 	END IF;

		IF ((vROBranchID = 0 OR vROBranchID IS NULL ) AND :NEW.ro_code IS NOT NULL AND LENGTH(TRIM(:NEW.ro_code))>0 AND :NEW.is_active = 1) THEN

			-- SQLINES LICENSE FOR EVALUATION USE ONLY
			INSERT INTO jns_users.branch_master
			(CODE,NAME,org_id,street_name,country_id,state_id,city_id,pincode,is_active,is_deleted,created_on,modified_date,msme,pl,parent_branch_id,branch_type)
			SELECT TRIM(CAST(:NEW.ro_code AS CHAR(200))),TRIM(:NEW.ro_name),:NEW.org_id,TRIM(:NEW.ro_address),'101',:NEW.ro_state_id,:NEW.ro_city_id,:NEW.ro_pincode,
			1,0,SYSTIMESTAMP,SYSTIMESTAMP,1,0,vZOBranchID,2
			FROM DUAL;

			vZOBranchID := BRANCH_MASTER_SEQ.nextval;

		END IF;

		:NEW.branch_ro_id:=vROBranchID;

	END IF;

    END;