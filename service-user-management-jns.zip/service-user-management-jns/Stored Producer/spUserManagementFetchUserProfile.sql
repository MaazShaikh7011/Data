DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchUserProfile`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchUserProfile`(IN userId BIGINT,IN businessTypeId BIGINT)
BEGIN
	
		SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(
		'userId',us.`user_id`,
		'email',users.decValue(us.email),
		'mobile',users.decValue(us.mobile),
		'firstName',users.decValue(`us`.`first_name`),
		'middleName',`us`.`middle_name`,
		'lastName',users.decValue(`us`.`last_name`),
		'signupDate',us.`sign_up_date`,
		'modifiedDate',us.`modified_date`,
		'isActive',CASE WHEN us.`is_active` THEN 'true' ELSE 'false' END,
		'branchId',bh.`id`,
		'branchName',bh.`name`,
		'branchCode',bh.`code`,
		'ifscCode',bh.`ifsc_code`,
		'city',ct.`city_name`,
		'state',st.`state_name`,
		'roleId',m.`user_role_id`,
		'userType',role.`display_name`,
		'isLocked',CASE WHEN us.`is_locked` THEN 'true' ELSE 'false' END,
		'LastLoginDate',(SELECT u.`login_date` FROM users.`user_token_mapping` u WHERE u.`user_id` = us.user_id ORDER BY u.id DESC LIMIT 1),
		'roleProductList',(SELECT JSON_ARRAYAGG(business_type_id) AS businessTypeList FROM users.user_role_product_mapping WHERE user_id = us.user_id GROUP BY user_id),
		'branchType',bh.branch_type,
		'branchROId',bm.branch_ro_id,
		'branchZOId',bm.branch_zo_id,
		'branchHOId',bm.branch_ho_id,
		'ROName',bro.name,
		'ZOName',bzo.name,
		'HOName',bho.name,
		'ROCode',bro.code,
		'ZOCode',bzo.code,
		'HOCode',bho.code,
		'passwordResetDate',us.`password_reset_date`,
		'userLockedDate',us.`user_locked_date`,
		'userUnlockedDate',us.`user_unlocked_date`,
		'adminCity',ct1.`city_name`,
		'adminState',st1.`state_name`)) AS CHAR)
		FROM users.`users` us 
		LEFT JOIN users.`user_role_master` role ON role.`role_id` = us.user_role_id
		LEFT JOIN users.`branch_master` bh ON bh.`id` = us.`branch_id`
		LEFT JOIN users.`branch_product_mapping` bm ON bh.`id` = bm.`branch_id` AND bm.business_type_id =businessTypeId
		LEFT JOIN users.`branch_master` bro ON bro.`id` = bm.`branch_ro_id`
		LEFT JOIN users.`branch_master` bzo ON bzo.`id` = bm.`branch_zo_id`
		LEFT JOIN users.`branch_master` bho ON bho.`id` = bm.`branch_ho_id`
		LEFT JOIN one_form.`city` ct ON ct.`id` = bh.`city_id`
		LEFT JOIN one_form.`state` st ON st.`id` = bh.`state_id`
		LEFT JOIN users.user_role_product_mapping m ON m.user_id = us.user_id
		LEFT JOIN one_form.`city` ct1 ON ct1.`id` = (SELECT city_id FROM `users`.`branch_master` WHERE branch_type=4 AND org_id=(SELECT org_id FROM `users`.`users` WHERE user_id=userId) ORDER BY id DESC LIMIT 1)
		LEFT JOIN one_form.`state` st1 ON st1.`id` = (SELECT city_id FROM `users`.`branch_master` WHERE branch_type=4 AND org_id=(SELECT org_id FROM `users`.`users` WHERE user_id=userId) ORDER BY id DESC LIMIT 1)
		WHERE us.user_id =userId AND m.business_type_id =businessTypeId
		ORDER BY us.user_id DESC;

	END$$

DELIMITER ;