DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBranchCountForTier`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBranchCountForTier`(IN orgId INT, IN schemeId INT)
BEGIN
		SELECT 
		CAST(JSON_ARRAYAGG(JSON_OBJECT(
		'lho',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master bm ON bpm.branch_id = bm.id 
WHERE bm.org_id =orgId AND bm.is_active = TRUE AND bm.branch_type = 6 AND bpm.sch_type_id = schemeId),
		'branch',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master bm ON bpm.branch_id = bm.id 
WHERE bm.org_id =orgId AND bm.is_active = TRUE AND bm.branch_type = 1 AND bpm.sch_type_id = schemeId),
		'ro',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master bm ON bpm.branch_id = bm.id 
WHERE bm.org_id =orgId AND bm.is_active = TRUE AND bm.branch_type = 2 AND bpm.sch_type_id = schemeId),
		'zo',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master bm ON bpm.branch_id = bm.id 
WHERE bm.org_id =orgId AND bm.is_active = TRUE AND bm.branch_type = 3 AND bpm.sch_type_id = schemeId))) AS CHAR) AS result
		FROM DUAL; 
	END$$

DELIMITER ;