DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBranchCounts`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBranchCounts`(IN orgId INT, IN businessTypeId INT)
BEGIN
		SELECT 
		CAST(JSON_ARRAYAGG(JSON_OBJECT(
		'branch',(SELECT COUNT(DISTINCT(branch_id)) FROM users.branch_product_mapping WHERE user_org_id = orgId AND business_type_id = businessTypeId AND is_active = TRUE),
		'ro',(SELECT COUNT(DISTINCT(branch_ro_id)) FROM users.branch_product_mapping WHERE user_org_id = orgId AND business_type_id = businessTypeId AND is_active = TRUE),
		'zo',(SELECT COUNT(DISTINCT(branch_zo_id)) FROM users.branch_product_mapping WHERE user_org_id = orgId AND business_type_id = businessTypeId AND is_active = TRUE))) AS CHAR) AS result
		FROM DUAL; 
	END$$

DELIMITER ;