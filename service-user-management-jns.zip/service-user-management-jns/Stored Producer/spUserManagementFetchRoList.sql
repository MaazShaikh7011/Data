DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchRoList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchRoList`(IN orgId INT, IN businessTypeId INT)
BEGIN
		
SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('roId',b.id,
				      'roName',b.name,
				      'roCode',b.code,
				      'users',users.fn_count_ro_user(b.id),
				      'zoName',zo.name,
				      'state',s.state_name, 
				      'city',c.city_name,
				      'status',IF(b.is_active IS TRUE,'TRUE','FALSE'))) AS CHAR)
				FROM users.branch_master b 
				LEFT JOIN one_form.state s ON b.state_id = s.id 
				LEFT JOIN one_form.city c ON b.city_id = c.id 
				INNER JOIN `users`.`branch_product_mapping` bpm ON bpm.branch_id = b.id 
				LEFT JOIN users.branch_master zo ON bpm.branch_zo_id = b.id AND b.branch_type = 3
				WHERE b.is_active = TRUE AND b.org_id = orgId AND b.branch_type = 2 AND bpm.business_type_id = businessTypeId;
	END$$

DELIMITER ;