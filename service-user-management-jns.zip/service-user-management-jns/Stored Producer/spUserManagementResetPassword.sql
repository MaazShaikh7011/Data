DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementResetPassword`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementResetPassword`(IN emailID VARCHAR(50),OUT result VARCHAR(100))
BEGIN
	DECLARE vRandNumber INT;
	DECLARE vUserId INT;
	DECLARE vNewPassword VARCHAR(35);
	DECLARE vDisplayPassword VARCHAR(35);
	DECLARE vCurrentPassword VARCHAR(35);
	DECLARE vPassword1 VARCHAR(35);
	
	SET vRandNumber = (SELECT FLOOR((RAND() * 5)+1));
	
	SELECT pwd, opwd INTO vNewPassword, vDisplayPassword FROM users.`tblPwd` WHERE id=6;
	
	-- SET vNewPassword = (SELECT pwd FROM users.`tblPwd` WHERE id=vRandNumber);
-- 	SET vDisplayPassword = (SELECT opwd FROM users.`tblPwd` WHERE id=vRandNumber);
	
	
	SELECT `password`, user_id, `password1` INTO vCurrentPassword, vUserId,vPassword1 FROM users.users WHERE users.decValue(email) = emailID AND user_type_id = 2;
	
	-- SET vCurrentPassword = (SELECT `password` FROM users.users WHERE users.decValue(email) = emailID and user_type_id = 2);
-- 	SET vUserId = (SELECT user_id FROM users.users WHERE users.decValue(email) = emailID AND user_type_id = 2);
-- 	SET vPassword1 = (SELECT `password1` FROM users.users WHERE users.decValue(email) = emailID AND user_type_id = 2);
	
	IF vNewPassword IS NOT NULL AND LENGTH(vNewPassword) > 0 THEN
	   UPDATE users.`users` SET `password_reset_date`=NOW(),`password` = vNewPassword, password1 = vCurrentPassword, password2 = vPassword1 WHERE users.decValue(email)=emailID AND user_type_id = 2;
	   INSERT INTO users.user_password_change_log(`user_id` , `password` , `created_on` ) VALUES (vUserId, vNewPassword, NOW());	   
	   SET result = vDisplayPassword;
	ELSE
	   SET result = "Try Again....";
	
	END IF;
		
    END$$

DELIMITER ;