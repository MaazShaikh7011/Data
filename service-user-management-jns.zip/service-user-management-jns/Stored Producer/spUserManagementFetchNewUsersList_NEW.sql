DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchNewUsersList_NEW`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchNewUsersList_NEW`(IN fromDate VARCHAR(255),IN toDate VARCHAR(255),IN orgId BIGINT, IN businessTypeId BIGINT,IN roleType INT,IN noPagination VARCHAR(255), IN paginationFROM TEXT, IN paginationTO TEXT,IN schemeId BIGINT,IN columnFilter TEXT)
BEGIN

	SET @selectCountQuery = ' SELECT COUNT(*) INTO @totalCount ';
	
	SET @selectDataQuery = 'us.`user_id` as userId,CONCAT(`users`.`decValue`(us.`first_name`)," ",`users`.`decValue`(us.`last_name`)) as userName,`users`.`decValue`(us.`email`) as email,
					`users`.`decValue`(us.`mobile`) as mobile,us.`sign_up_date` as signupDate,CASE WHEN m.`is_active` THEN "true" ELSE "false" END as isActive,bh.id as branchId,bh.`name` as branchName,
					 bh.`code` as branchCode,ct.`city_name` as city,st.`state_name` as state,role.`display_name` as userType,us.`user_role_id` as roleTypeId,CASE WHEN us.is_locked THEN "true" ELSE "false" END as isLocked,
					 (SELECT u.`login_date` FROM users.`user_token_mapping` u WHERE u.`user_id` = us.user_id ORDER BY u.id DESC LIMIT 1) as lastLogin,bh.id as zoBranchId,bh.name as zoBranchName,
					 bh.code as zoBranchCode,bh.id as roBranchId,bh.name as roBranchName,bh.code as roBranchCode,ct1.`city_name` as adminCity,st1.`state_name` as adminState';
		
	SET @tableQuery = ' FROM users.`users` us 
				     LEFT JOIN users.`user_role_master` role ON role.`role_id` = us.user_role_id
				     LEFT JOIN users.`branch_master` bh ON bh.`id` = us.`branch_id`
				     LEFT JOIN one_form.`city` ct ON ct.`id` = bh.`city_id`
				     LEFT JOIN one_form.`state` st ON st.`id` = bh.`state_id`
				     LEFT JOIN users.user_role_product_mapping m ON m.user_id = us.user_id 
				     LEFT JOIN one_form.`city` ct1 ON ct1.`id` = (SELECT city_id FROM `users`.`branch_master` WHERE branch_type=4 AND org_id=(select user_org_id from user.users where user_id=us.user_id) ORDER BY id DESC LIMIT 1)
		                     LEFT JOIN one_form.`state` st1 ON st1.`id` = (SELECT state_id FROM `users`.`branch_master` WHERE branch_type=4 AND org_id=10 ORDER BY id DESC LIMIT 1)';

	IF roleType = 1 THEN -- ALL USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		' AND m.`user_role_id` IN (5,8,9,12,13,14,17) AND m.`user_role_id` NOT IN (10,11) AND us.`user_type_id` = 2 ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
				
	ELSEIF roleType = 2 THEN  -- ADMIN USERS (MAKER/CHECKER)
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (10,11) ',
		' AND us.is_active = TRUE AND m.`user_role_id` IN (10,11) ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
						
	ELSEIF roleType = 5 THEN -- HO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (5) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (5) ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
	ELSEIF roleType = 6 THEN -- ZO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 3 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (14) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (14) ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
	ELSEIF roleType = 7 THEN -- RO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 2 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (13) ',
		' AND us.is_active = TRUE AND m.`user_role_id` IN (13) ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
						
	ELSEIF roleType = 9 THEN -- BO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 1 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (8,9) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (8,9) ',
				' AND us.created_date BETWEEN "',fromDate,'" and "',toDate,'"');
						
	END IF;
	
	IF ((IFNULL(columnFilter->"$.userEmail", NULL) IS NOT NULL) AND (columnFilter->"$.userEmail" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND `users`.`decValue`(us.`email`) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userEmail"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.city", NULL) IS NOT NULL) AND (columnFilter->"$.city" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND ct.`city_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.city"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.state", NULL) IS NOT NULL) AND (columnFilter->"$.state" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND st.`state_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.state"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.mobile", NULL) IS NOT NULL) AND (columnFilter->"$.mobile" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND `users`.`decValue`(us.`mobile`) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.mobile"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.userRole", NULL) IS NOT NULL) AND (columnFilter->"$.userRole" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND role.`display_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userRole"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.userName", NULL) IS NOT NULL) AND (columnFilter->"$.userName" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND CONCAT(`users`.`decValue`(us.`first_name`)," ",`users`.`decValue`(us.`last_name`)) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userName"),'%''');
	END IF;
	-- IF ((IFNULL(columnFilter->"$.status", NULL) IS NOT NULL) AND (columnFilter->"$.status" IS NOT NULL))
	-- THEN
	--	SET @whereClause = CONCAT(@whereClause, ' AND  us.`is_active` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.status"),'%''');
	-- END IF;
  
		SET @totalCountQuery =  CONCAT(@selectCountQuery, @tableQuery, @whereClause);
		
		PREPARE cntstmt FROM @totalCountQuery;
		EXECUTE cntstmt;

		SET @orderBy = ' ORDER BY us.modified_date DESC';	

		IF (IFNULL(noPagination, NULL) IS NOT NULL AND noPagination IS NOT NULL AND noPagination != '') 
		THEN
		  SET @limit = ' ';  
		ELSE
		SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
		END IF;

		SET @query = CONCAT('SELECT ',' @totalCount AS totalCount, ',@selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
		-- select @query;
		PREPARE stmt1 FROM @query;
		EXECUTE stmt1;	
	

END$$

DELIMITER ;