DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBranchList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBranchList`(IN orgId INT, IN businessTypeId INT)
BEGIN
		SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('branchId',bm.id, 
						       'branchCode',bm.code, 
							'branchName',bm.name,  
							'userCount',(users.fn_count_maker(bm.id) + users.fn_count_checker(bm.id)),
							'roName',ro.name,
							'zoName',zo.name,
							'state',s.state_name, 
							'city',c.city_name,
							'status',IF(bm.is_active IS TRUE,'TRUE','FALSE'))) AS CHAR)
		FROM   users.branch_master bm 
		LEFT JOIN one_form.state s 
		ON bm.state_id = s.id 
		LEFT JOIN one_form.city c 
		ON bm.city_id = c.id 
		INNER JOIN `users`.`branch_product_mapping` bpm 
		ON bpm.branch_id = bm.id 
		LEFT JOIN users.branch_master ro ON bpm.branch_ro_id = bm.id AND bm.branch_type = 2
		LEFT JOIN users.branch_master zo ON bpm.branch_zo_id = bm.id AND bm.branch_type = 3
		WHERE  bm.org_id=orgId AND bm.is_active = TRUE AND bpm.business_type_id =businessTypeId AND bm.branch_type = 1 AND bpm.is_active = TRUE ORDER BY bm.name ASC ;
	END$$

DELIMITER ;