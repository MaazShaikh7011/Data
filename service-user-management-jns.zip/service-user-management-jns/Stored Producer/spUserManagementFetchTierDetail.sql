DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchTierDetail`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchTierDetail`(IN orgId INT, IN businessTypeId INT,IN `type` INT,IN fromDate DATETIME,IN toDate DATETIME)
BEGIN
		IF(`type` = 1)THEN
				SELECT 
				CAST(JSON_ARRAYAGG(JSON_OBJECT(
				'branchId',br.id ,  
				      'branchCode',br.code , 
				       'branchName',br.name , 
				       'roId',rob.id   ,
				       'roCode',rob.code ,
				       'roName',rob.name ,
				       'zoId',zob.id   ,
				       'zoCode',zob.code ,
				       'zoName',zob.name,
				       'createdDate',bm.created_date )) AS CHAR)
				FROM users.branch_product_mapping bm 
				LEFT JOIN users.branch_master rob ON bm.branch_ro_id = rob.id AND rob.branch_type = 2 AND rob.is_active = TRUE
				LEFT JOIN users.branch_master br ON bm.branch_id = br.id AND br.branch_type = 1 AND br.is_active = TRUE
				LEFT JOIN users.branch_master zob ON bm.branch_zo_id = zob.id AND zob.branch_type = 3 AND zob.is_active = TRUE
				WHERE bm.user_org_id = orgId AND bm.business_type_id =businessTypeId AND bm.is_active = TRUE AND br.id IS NOT NULL 
				AND rob.id IS NULL AND zob.id IS NULL AND (bm.created_date BETWEEN fromDate AND toDate)
				ORDER BY bm.created_date DESC;
		ELSEIF(`type` = 2)THEN
				SELECT 
				CAST(JSON_ARRAYAGG(JSON_OBJECT(
				'branchId',br.id ,  
				      'branchCode',br.code , 
				       'branchName',br.name , 
				       'roId',rob.id   ,
				       'roCode',rob.code ,
				       'roName',rob.name ,
				       'zoId',zob.id   ,
				       'zoCode',zob.code ,
				       'zoName',zob.name,
				       'createdDate',bm.created_date )) AS CHAR)
				FROM users.branch_product_mapping bm 
				LEFT JOIN users.branch_master rob ON bm.branch_ro_id = rob.id AND rob.branch_type = 2 AND rob.is_active = TRUE
				LEFT JOIN users.branch_master br ON bm.branch_id = br.id AND br.branch_type = 1 AND br.is_active = TRUE
				LEFT JOIN users.branch_master zob ON bm.branch_zo_id = zob.id AND zob.branch_type = 3 AND zob.is_active = TRUE
				WHERE bm.user_org_id = orgId AND bm.business_type_id =businessTypeId AND bm.is_active = TRUE AND br.id IS NOT NULL 				
				AND rob.id IS NOT NULL AND zob.id IS NOT NULL AND (bm.created_date BETWEEN fromDate AND toDate)
				ORDER BY bm.created_date DESC;
		ELSE 
				SELECT '' FROM DUAL;
		END IF;			
	END$$

DELIMITER ;