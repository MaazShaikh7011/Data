DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchNewUsersList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchNewUsersList`(IN orgId BIGINT, IN businessTypeId BIGINT,IN roleType INT,IN noPagination VARCHAR(255), IN paginationFROM TEXT, IN paginationTO TEXT,IN schemeId BIGINT,IN columnFilter TEXT)
BEGIN

	SET @selectCountQuery = ' SELECT COUNT(*) INTO @totalCount ';
	
	SET @selectDataQuery = 'us.`user_id` as userId,CONCAT(`users`.`decValue`(us.`first_name`)," ",`users`.`decValue`(us.`last_name`)) as userName,`users`.`decValue`(us.`email`) as email,
					`users`.`decValue`(us.`mobile`) as mobile,us.`sign_up_date` as signupDate,CASE WHEN us.`is_active` THEN "true" ELSE "false" END as isActive,bh.id as branchId,bh.`name` as branchName,
					 bh.`code` as branchCode,ct.`city_name` as city,st.`state_name` as state,role.`display_name` as userType,us.`user_role_id` as roleTypeId,CASE WHEN us.is_locked THEN "true" ELSE "false" END as isLocked,
					 (SELECT u.`login_date` FROM users.`user_token_mapping` u WHERE u.`user_id` = us.user_id ORDER BY u.id DESC LIMIT 1) as lastLogin,
					 ZO.id as zoBranchId,
					 ZO.name as zoBranchName,
					 ZO.code as zoBranchCode,
					 RO.id as roBranchId,
					 RO.name as roBranchName,
					 RO.code as roBranchCode';
		
	SET @tableQuery = CONCAT(' FROM users.`users` us 
				     LEFT JOIN users.`user_role_master` role ON role.`role_id` = us.user_role_id
				     LEFT JOIN users.`branch_master` bh ON bh.`id` = us.`branch_id`
				     LEFT JOIN one_form.`city` ct ON ct.`id` = bh.`city_id`
				     LEFT JOIN one_form.`state` st ON st.`id` = bh.`state_id`
				     LEFT JOIN users.user_role_product_mapping m ON m.user_id = us.user_id
				     LEFT JOIN `users`.`user_organisation_master` um on um.`user_org_id` = us.`user_org_id`
				     LEFT JOIN `users`.`branch_product_mapping` BMAP ON BMAP.branch_id = us.branch_id AND BMAP.sch_type_id = ',schemeId,'
				     LEFT JOIN `users`.`branch_master` RO ON RO.id = BMAP.branch_ro_id
				     LEFT JOIN `users`.`branch_master` ZO ON ZO.id = BMAP.branch_zo_id ');
	
	IF roleType = 1 THEN -- ALL USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		' AND m.`user_role_id` IN (5,8,9,12,13,14,17,10,11,15) AND us.`user_type_id` = 2 ');
				
	ELSEIF roleType = 2 THEN  -- ADMIN USERS (MAKER/CHECKER)
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (10,11) ',
		' AND us.is_active = TRUE AND m.`user_role_id` IN (10,11) ');
						
	ELSEIF roleType = 5 THEN -- HO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (5) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (5) ');
	ELSEIF roleType = 6 THEN -- ZO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 3 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (14) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (14) ');
	ELSEIF roleType = 7 THEN -- RO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 2 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (13) ',
		' AND us.is_active = TRUE AND m.`user_role_id` IN (13) ');
						
	ELSEIF roleType = 9 THEN -- BO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 1 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		-- ' AND us.is_active = TRUE AND m.is_active = TRUE AND m.`user_role_id` IN (8,9) ',
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (8,9) ');

	ELSEIF roleType = 8 THEN -- HO USERS
		SET @whereClause  = CONCAT(' WHERE us.`user_org_id` = ',orgId,' and bh.branch_type = 6 AND bh.is_active AND m.business_type_id = ',businessTypeId,
		' AND m.scheme_id = ',schemeId,
		' AND us.is_active = TRUE  AND m.`user_role_id` IN (15) ');
				
	END IF;
	
--   For date RANGE
	IF ((IFNULL(columnFilter->"$.fromDate", NULL) IS NOT NULL) AND columnFilter->"$.fromDate" IS NOT NULL AND (IFNULL(columnFilter->"$.toDate", NULL) IS NOT NULL) AND columnFilter->"$.toDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND (DATE(us.created_date) BETWEEN ', columnFilter->"$.fromDate", ' AND ', columnFilter->"$.toDate",' OR DATE(us.modified_date) BETWEEN ',columnFilter->"$.fromDate",' AND ',columnFilter->"$.toDate",')');
	ELSEIF (columnFilter->"$.fromDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND DATE(us.created_date) = ', columnFilter->"$.fromDate");
	END IF;
		
	
	IF ((IFNULL(columnFilter->"$.userEmail", NULL) IS NOT NULL) AND (columnFilter->"$.userEmail" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND `users`.`decValue`(us.`email`) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userEmail"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.city", NULL) IS NOT NULL) AND (columnFilter->"$.city" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND ct.`city_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.city"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.state", NULL) IS NOT NULL) AND (columnFilter->"$.state" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND st.`state_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.state"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.mobile", NULL) IS NOT NULL) AND (columnFilter->"$.mobile" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND `users`.`decValue`(us.`mobile`) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.mobile"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.userRole", NULL) IS NOT NULL) AND (columnFilter->"$.userRole" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND role.`display_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userRole"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.userName", NULL) IS NOT NULL) AND (columnFilter->"$.userName" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND CONCAT(`users`.`decValue`(us.`first_name`)," ",`users`.`decValue`(us.`last_name`)) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.userName"),'%''');
	END IF;
	-- IF ((IFNULL(columnFilter->"$.status", NULL) IS NOT NULL) AND (columnFilter->"$.status" IS NOT NULL))
	-- THEN
	--	SET @whereClause = CONCAT(@whereClause, ' AND  us.`is_active` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.status"),'%''');
	-- END IF;
  
		SET @totalCountQuery =  CONCAT(@selectCountQuery, @tableQuery, @whereClause);
		
		PREPARE cntstmt FROM @totalCountQuery;
		EXECUTE cntstmt;

		SET @orderBy = ' ORDER BY us.user_id DESC';	

		IF (IFNULL(noPagination, NULL) IS NOT NULL AND noPagination IS NOT NULL AND noPagination != '') 
		THEN
		  SET @limit = ' ';  
		ELSE
		SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
		END IF;

		SET @query = CONCAT('SELECT ',' @totalCount AS totalCount, ',@selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
		-- select @query;
		PREPARE stmt1 FROM @query;
		EXECUTE stmt1;	
	

END$$

DELIMITER ;