DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchAllOffices_NEW`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchAllOffices_NEW`(IN orgId BIGINT,IN businessTypeId BIGINT, IN branchType INT,IN noPagination VARCHAR(255), IN paginationFROM TEXT, IN paginationTO TEXT,IN schemeId BIGINT,IN columnFilter TEXT)
BEGIN
	SET @selectCountQuery = ' SELECT COUNT(*) INTO @totalCount ';

				
	IF branchType = 5 THEN -- ALL Branches
	
		SET @selectDataQuery = ' bm.`id` as branchId, bm.`code` as branchCode,bm.`name` as branchName,bm.`branch_type` as branchTypeId,IF (bm.`branch_type` = 1 ,"Branch Office",IF (bm.`branch_type` = 2 ,"Regional Office",IF (bm.`branch_type` = 3 ,"Zonal Office","-"))) as branchType,
				bm.`street_name` as address,bm.`pincode` as pincode,bm.`ifsc_code` as ifsc,bm.`contact_person_email` as email,bm.`telephone_no` as contactNo,
				bm.`contact_person_name` as contactPersonName,CASE WHEN bm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city,st.`state_name` as state,
				(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) as totalUsers,
				ZO.id as zoBranchId,
				 ZO.name as zoBranchName,
				 ZO.code as zoBranchCode,
				 RO.id as roBranchId,
				 RO.name as roBranchName,
				 RO.code as roBranchCode ';
		
		SET @tableQuery = ' FROM 
				    users.branch_product_mapping b 
				    LEFT JOIN `users`.`branch_master` RO ON RO.id = b.branch_ro_id
				    LEFT JOIN `users`.`branch_master` ZO ON ZO.id = b.branch_zo_id
				    LEFT JOIN users.branch_master bm ON b.branch_id = bm.id
				    LEFT JOIN one_form.`city` ct ON ct.`id` = bm.`city_id`
				    LEFT JOIN one_form.`state` st ON st.`id` = bm.`state_id` ';
				  
		SET @whereClause  = CONCAT(' WHERE bm.org_id = ',orgId,' AND b.business_type_id = ',businessTypeId,' AND b.sch_type_id = ',schemeId);
				
	ELSEIF branchType = 1 THEN  -- BO TYPE BRANCH
		
		SET @selectDataQuery = ' bm.`id` as branchId,bm.`code` as branchCode,bm.`name` as branchName,bm.`branch_type` as branchTypeId,"Branch Office" as branchType,bm.`street_name` as address,bm.`pincode` as pincode,bm.`ifsc_code` as ifsc,
					bm.`contact_person_email` as email, bm.`telephone_no` as contactNo, bm.`contact_person_name` as contactPersonName,
					CASE WHEN bm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city, st.`state_name` as state, 
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.`user_role_id` = 9 AND us.`is_active` = TRUE AND us.branch_id = bm.id) as branchChecker,
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.`user_role_id` = 8 AND us.`is_active` = TRUE AND us.branch_id = bm.id) as branchMaker,
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) as totalUsers,
					ZO.id as zoBranchId,
					 ZO.name as zoBranchName,
					 ZO.code as zoBranchCode,
					 RO.id as roBranchId,
					 RO.name as roBranchName,
					 RO.code as roBranchCode ';
					
		SET @tableQuery = ' FROM users.branch_product_mapping b
					LEFT JOIN `users`.`branch_master` RO ON RO.id = b.branch_ro_id
					LEFT JOIN `users`.`branch_master` ZO ON ZO.id = b.branch_zo_id
					LEFT JOIN users.branch_master bm ON b.branch_id = bm.id
					LEFT JOIN one_form.`city` ct ON ct.`id` = bm.`city_id`
					LEFT JOIN one_form.`state` st ON st.`id` = bm.`state_id` ';
				  
		SET @whereClause  = CONCAT(' WHERE b.user_org_id = ',orgId,' AND bm.branch_type = ',branchType,' AND b.business_type_id = ',businessTypeId,
				' AND b.sch_type_id = ',schemeId);
		
	
	ELSEIF branchType = 2 THEN -- RO TYPE BRANCH
	
		SET @selectDataQuery = ' bm.`id` as branchId,bm.`code` as branchCode,bm.`name` as branchName,bm.`branch_type` as branchTypeId,"Regional Office" as branchType,bm.`street_name` as address,bm.`pincode` as pincode,bm.`ifsc_code` as ifsc,
					bm.`contact_person_email` as email, bm.`telephone_no` as contactNo, bm.`contact_person_name` as contactPersonName,
					CASE WHEN bm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city, st.`state_name` as state, 
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) as totalUsers,
					ZO.id as zoBranchId,
					 ZO.name as zoBranchName,
					 ZO.code as zoBranchCode,
					 RO.id as roBranchId,
					 RO.name as roBranchName,
					 RO.code as roBranchCode';
					
		SET @tableQuery = ' FROM users.branch_product_mapping b
					LEFT JOIN `users`.`branch_master` RO ON RO.id = b.branch_ro_id
					LEFT JOIN `users`.`branch_master` ZO ON ZO.id = b.branch_zo_id
					LEFT JOIN users.branch_master bm ON bm.id = b.branch_id
					LEFT JOIN one_form.`city` ct ON ct.`id` = bm.`city_id`
					LEFT JOIN one_form.`state` st ON st.`id` = bm.`state_id`';
							  
		SET @whereClause  = CONCAT(' WHERE b.user_org_id = ',orgId,' AND bm.branch_type = ',branchType,' AND b.business_type_id = ',businessTypeId,
				' AND b.sch_type_id = ',schemeId);
				
	
	ELSEIF branchType = 3 THEN -- ZO TYPE BRANCH
	
		SET @selectDataQuery = ' bm.`id` as branchId, bm.`code` as branchCode,bm.`name` as branchName,bm.`branch_type` as branchTypeId,"Zonal Office" as branchType,
				bm.`street_name` as address,bm.`pincode` as pincode,bm.`ifsc_code` as ifsc,bm.`contact_person_email` as email,bm.`telephone_no` as contactNo,
				bm.`contact_person_name` as contactPersonName,CASE WHEN bm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city,st.`state_name` as state,
				(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) as totalUsers,
				ZO.id as zoBranchId,
				 ZO.name as zoBranchName,
				 ZO.code as zoBranchCode,
				 RO.id as roBranchId,
				 RO.name as roBranchName,
				 RO.code as roBranchCode';
	
		 SET @tableQuery = ' FROM users.branch_product_mapping b 
					LEFT JOIN `users`.`branch_master` RO ON RO.id = b.branch_ro_id
					LEFT JOIN `users`.`branch_master` ZO ON ZO.id = b.branch_zo_id
					LEFT JOIN users.branch_master bm ON bm.id = b.branch_id
					LEFT JOIN one_form.`city` ct ON ct.`id` = bm.`city_id`
					LEFT JOIN one_form.`state` st ON st.`id` = bm.`state_id` ';
		
		SET @whereClause  = CONCAT(' WHERE b.user_org_id = ',orgId,' AND bm.branch_type = ',branchType,' AND b.business_type_id = ',businessTypeId,
				' AND b.sch_type_id = ',schemeId);
				
				
	ELSEIF branchType = 6 THEN -- LHO TYPE BRANCH
	
		SET @selectDataQuery = ' bm.`id` as branchId, bm.`code` as branchCode,bm.`name` as branchName,bm.`branch_type` as branchTypeId,"Lead Head Office" as branchType,
				bm.`street_name` as address,bm.`pincode` as pincode,bm.`ifsc_code` as ifsc,bm.`contact_person_email` as email,bm.`telephone_no` as contactNo,
				bm.`contact_person_name` as contactPersonName,CASE WHEN bm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city,st.`state_name` as state,
				(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) as totalUsers,
				ZO.id as zoBranchId,
				ZO.name as zoBranchName,
				ZO.code as zoBranchCode,
				RO.id as roBranchId,
				RO.name as roBranchName,
				RO.code as roBranchCode';
	
		 SET @tableQuery = ' FROM users.branch_product_mapping b 
					LEFT JOIN `users`.`branch_master` RO ON RO.id = b.branch_ro_id
					LEFT JOIN `users`.`branch_master` ZO ON ZO.id = b.branch_zo_id
					LEFT JOIN users.branch_master bm ON bm.id = b.branch_id
					LEFT JOIN one_form.`city` ct ON ct.`id` = bm.`city_id`
					LEFT JOIN one_form.`state` st ON st.`id` = bm.`state_id` ';
		
		SET @whereClause  = CONCAT(' WHERE b.user_org_id = ',orgId,' AND bm.branch_type = ',branchType,' AND b.business_type_id = ',businessTypeId,
				' AND b.sch_type_id = ',schemeId);
		
	END IF;
	
	IF ((IFNULL(columnFilter->"$.branchName", NULL) IS NOT NULL) AND (columnFilter->"$.branchName" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND bm.`name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.branchName"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.branchCode", NULL) IS NOT NULL) AND (columnFilter->"$.branchCode" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND bm.`code` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.branchCode"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.totalUser", NULL) IS NOT NULL) AND (columnFilter->"$.totalUser" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND (SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bm.id) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.totalUser"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.city", NULL) IS NOT NULL) AND (columnFilter->"$.city" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND ct.`city_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.city"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.state", NULL) IS NOT NULL) AND (columnFilter->"$.state" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND st.`state_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.state"),'%''');
	END IF;
	
	-- IF ((IFNULL(columnFilter->"$.status", NULL) IS NOT NULL) AND (columnFilter->"$.status" IS NOT NULL))
	-- THEN
	--	SET @whereClause = CONCAT(@whereClause, ' AND  us.`is_active` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.status"),'%''');
	-- END IF;
	
--   For date RANGE
	IF (columnFilter->"$.fromDate" IS NOT NULL AND columnFilter->"$.toDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND (DATE(bm.created_on) BETWEEN ', columnFilter->"$.fromDate", ' AND ', columnFilter->"$.toDate",' OR DATE(bm.modified_date) BETWEEN ',columnFilter->"$.fromDate",' AND ',columnFilter->"$.toDate",')');
	ELSEIF (columnFilter->"$.fromDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND DATE(bm.created_on) = ', columnFilter->"$.fromDate");
	END IF;	
		
		
	SET @totalCountQuery =  CONCAT(@selectCountQuery, @tableQuery, @whereClause);
	
	PREPARE cntstmt FROM @totalCountQuery;
	EXECUTE cntstmt;

	SET @orderBy = ' ORDER BY bm.id DESC';	

	IF (IFNULL(noPagination, NULL) IS NOT NULL AND noPagination IS NOT NULL AND noPagination != '') 
	THEN
	  SET @limit = ' ';  
	ELSE
	SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
	END IF;

	SET @query = CONCAT('SELECT ',' @totalCount AS totalCount, ',@selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
-- 	select @query;
-- 	INSERT INTO `users`.`temp` (val, val2) VALUES ('@query',@query);
	PREPARE stmt1 FROM @query;
	EXECUTE stmt1;	
	
	
	END$$

DELIMITER ;