DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchSingleBranchDetail`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchSingleBranchDetail`(IN branchId BIGINT, IN businessTypeId INT)
BEGIN
		SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('branchId',b.id,
					'branchName',b.name,
					'branchCode',b.code,
					'roName',ro.name,
					'roCode',ro.code,
					-- 'email',IF (b.contact_person_email is not null,users.decValue(b.contact_person_email),''),
					'email',b.contact_person_email,
					'contactNo',b.contact_person_number,
					'contactPersonName',b.`contact_person_name`,
					'branchCreation',b.`created_on`,
					'branchModification',b.`modified_date`,
					'address',b.street_name,
					'ifscCode',b.`ifsc_code`,
					'pincode',b.`pincode`,
					'state',s.state_name, 
					'city',c.city_name,
					'stateId',s.`id`, 
					'cityId',c.`id`,
					'regionId',b.region_id,
					'maker',(users.fn_count_maker(b.id)),
					'checker',(users.fn_count_checker(b.id)),
					'loanType',bs.`display_name`,
					'businessTypeId',bpm.business_type_id,
					'roId',bpm.`branch_ro_id`,
					'zoId',bpm.`branch_zo_id`,
					'zoName',zo.name,
					'zoCode',zo.code,
					'lhoId',bpm.`branch_lho_id`,
					'lhoName',lho.name,
					'lhoCode',lho.code,
					'roName',(SELECT b1.name FROM `users`.`branch_master` b1 WHERE b1.id=bpm.`branch_ro_id`),
					'selectedScheme',(SELECT JSON_ARRAYAGG( s1.sch_type_id) FROM users.branch_product_mapping s1 WHERE s1.branch_id = b.id  AND s1.user_org_id = b.org_id),
					'pendingProposal',IF(businessTypeId=5,
						(SELECT COUNT(`proposal_id`) FROM `loan_application_details`.`hl_proposal_details` WHERE proposal_status_id = 1 AND is_active = TRUE AND
						 branch_id IN(SELECT branch_id FROM users.branch_product_mapping WHERE branch_id = branchId AND business_type_id = businessTypeId)),
						 IF(businessTypeId=9,
						 (SELECT COUNT(`proposal_id`) FROM `loan_application_details`.`edu_proposal_details` WHERE proposal_status_id = 1 AND is_active = TRUE AND
						 branch_id IN(SELECT branch_id FROM users.branch_product_mapping WHERE branch_id = branchId AND business_type_id = businessTypeId)),0))
					))AS CHAR) AS result
					FROM users.branch_master b
					INNER JOIN `users`.`branch_product_mapping` bpm ON bpm.branch_id = b.id AND business_type_id = businessTypeId
					LEFT JOIN users.branch_master ro ON bpm.branch_ro_id = ro.id AND ro.branch_type = 2
					LEFT JOIN users.branch_master zo ON bpm.branch_zo_id = zo.id AND zo.branch_type = 3
					LEFT JOIN users.branch_master lho ON bpm.branch_lho_id = lho.id AND lho.branch_type = 6
					LEFT JOIN users.`business_master` bs ON bs.`business_type_master_id` = bpm.business_type_id
					LEFT JOIN one_form.state s ON b.state_id = s.id 
					LEFT JOIN one_form.city c ON b.city_id = c.id 
					WHERE b.id = branchId;
	END$$

DELIMITER ;