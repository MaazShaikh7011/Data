DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBoRoOfficesfromRoZoId`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBoRoOfficesfromRoZoId`(IN branchId INT,IN userRoleId INT,IN orgId BIGINT)
BEGIN

	SET @selectDataQuery = 'SELECT DISTINCT(bm.code) AS branchCode ';
	
	SET @tableQuery = ' FROM users.branch_master bm
				LEFT JOIN users.branch_product_mapping bpm ON bpm.branch_id = bm.id ';
				
	SET @whereClause = CONCAT(' WHERE bm.`org_id` = ',orgId,' AND bm.is_active = TRUE '); 
					
	IF userRoleId = 14 THEN
	
		SET @whereClause  = CONCAT(@whereClause,' AND bm.branch_type = 2 
									AND bm.id IN ( SELECT DISTINCT branch_id FROM users.branch_product_mapping WHERE branch_zo_id = ',branchId,') '  );
										
	ELSEIF userRoleId = 13 THEN
		
		SET @whereClause  = CONCAT(@whereClause,' AND bm.branch_type = 1
									AND bm.id IN ( SELECT DISTINCT branch_id FROM users.branch_product_mapping WHERE branch_ro_id = ',branchId,') '  );

	END IF;
	
	SET @orderBy = ' ORDER BY bm.id DESC';	
	
	SET @query = CONCAT(@selectDataQuery, @tableQuery, @whereClause, @orderBy);
--   	select @query;
	PREPARE stmt1 FROM @query;
	EXECUTE stmt1;	
-- 	CALL users.spUserManagementFetchBoRoOfficesfromRoZoId(191498,14,37)
	
	END$$

DELIMITER ;