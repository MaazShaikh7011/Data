DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBankAdminUserList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBankAdminUserList`(IN userId INT, IN businessTypeId INT)
BEGIN
    
	DECLARE vb_role_id INT;
	DECLARE vb_branch_id INT;
	DECLARE vb_org_id INT;
	
	
	SELECT `user_role_id`,`branch_id`,`user_org_id` INTO vb_role_id,vb_branch_id,vb_org_id FROM users.`users`  WHERE `user_id` = userId;
	
	
	
	SET @vb_query = CONCAT("SELECT us.`user_id`,us.`email`,us.`mobile`,us.`sign_up_date`,us.`is_active`,bh.`name`,bh.`code`,ct.`city_name`,st.`state_name`,role.`display_name`,`is_locked`, us.`last_access_business_type_id`,
		 (SELECT u.`login_date` FROM users.`user_token_mapping` u WHERE u.`user_id` = us.user_id ORDER BY u.id DESC LIMIT 1) as lastLogin 
		FROM users.`users` us 
		LEFT JOIN users.`user_role_master` role ON role.`role_id` = us.user_role_id
		LEFT JOIN users.`branch_master` bh ON bh.`id` = us.`branch_id`
		LEFT JOIN one_form.`city` ct ON ct.`id` = bh.`city_id`
		LEFT JOIN one_form.`state` st ON st.`id` = bh.`state_id`
		LEFT JOIN users.user_role_product_mapping m ON m.user_id = us.user_id
		WHERE us.`user_org_id` = ", vb_org_id," AND m.business_type_id = ",businessTypeId ," AND m.`user_role_id` IN (5,8,9,12,13,14,17) and m.`user_role_id` NOT IN (10,11) AND us.`user_type_id` = 2 ");
	
	IF (vb_role_id = 5 OR vb_role_id = 10 OR vb_role_id = 11 OR vb_role_id = 20) THEN
		SET @vb_query = CONCAT(@vb_query," ORDER BY us.user_id DESC");
	ELSEIF(vb_role_id = 13) THEN -- for RO
		SET @vb_query = CONCAT(@vb_query," AND us.branch_id IN( select bpm.branch_id from users.`branch_product_mapping` bpm where bpm.`business_type_id` = ",businessTypeId," AND bpm.`user_org_id`= ",vb_org_id," AND bpm.`branch_ro_id`= ",vb_branch_id,") ORDER BY us.user_id DESC");
	ELSEIF(vb_role_id = 14) THEN -- for ZO
		SET @vb_query = CONCAT(@vb_query," AND us.branch_id IN( select bpm.branch_id from users.`branch_product_mapping` bpm where bpm.`business_type_id` = ",businessTypeId," AND bpm.`user_org_id`= ",vb_org_id," AND bpm.`branch_zo_id`= ",vb_branch_id,") ORDER BY us.user_id DESC");
	ELSE	
		SET @vb_query = "select '' from dual";
	END IF; 
	PREPARE stmt1 FROM @vb_query;
	EXECUTE stmt1;
    END$$

DELIMITER ;