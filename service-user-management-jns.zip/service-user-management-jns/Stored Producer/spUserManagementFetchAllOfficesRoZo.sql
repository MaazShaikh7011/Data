DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchAllOfficesRoZo`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchAllOfficesRoZo`(IN userId INT,IN orgId BIGINT,IN businessTypeId BIGINT, IN branchType INT,IN noPagination VARCHAR(255), IN paginationFROM TEXT, IN paginationTO TEXT,IN schemeId BIGINT,IN columnFilter TEXT)
BEGIN
	
	SELECT branch_id,user_role_id INTO @branchId, @userRoleId FROM users.users WHERE user_id = userId;
	
	SET @selectDataQuery = ' bbm.`code` AS branchCode,bbm.`name` AS branchName,bbm.`branch_type` AS branchTypeId,bbm.`contact_person_email` AS email,bbm.`telephone_no` AS contactNo,
				bbm.`contact_person_name` AS contactPersonName,
				(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bbm.id) as totalUsers,
				CASE WHEN bbm.`is_active` THEN "true" ELSE "false" END as isActive,ct.`city_name` as city,
				st.`state_name` as state, bbm.`street_name` as address,bbm.`pincode` as pincode,bbm.`ifsc_code` as ifsc, 
				ZO.name as zoBranchName,
				ZO.code as zoBranchCode,
				RO.id as roBranchId,
				RO.name as roBranchName,
				RO.code as roBranchCode, ';
	
	SET @tableQuery = ' INNER JOIN users.branch_master bbm ON bbm.id = bpm.branch_id
					LEFT JOIN `users`.`branch_master` RO ON RO.id = bpm.branch_ro_id
					LEFT JOIN `users`.`branch_master` ZO ON ZO.id = bpm.branch_zo_id
					LEFT JOIN one_form.`city` ct ON ct.`id` = bbm.`city_id`
					LEFT JOIN one_form.`state` st ON st.`id` = bbm.`state_id` ';
					
	SET @whereClause  = CONCAT(' WHERE bbm.org_id = ',orgId,' AND bpm.business_type_id = ',businessTypeId,' AND bpm.sch_type_id = ',schemeId);
	
	IF @userRoleId = 13 THEN
					
		IF branchType = 1 THEN
			SET @tableQuery = CONCAT( ' FROM users.`branch_product_mapping` bpm INNER JOIN users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = ',branchType,@tableQuery );
		ELSEIF branchType = 5 THEN
			
			SET @tableQuery = CONCAT( ' FROM users.`branch_product_mapping` bpm INNER JOIN users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = 1 ', @tableQuery);
		END IF;
					
		SET @whereClause  = CONCAT(@whereClause,' AND bpm.branch_ro_id = ',@branchId);
	
	ELSEIF @userRoleId = 14 THEN  
		IF branchType = 1 THEN
			SET @tableQuery = CONCAT(' FROM (
							SELECT DISTINCT bpmp1.branch_id , bm.branch_type AS branchTypeId, bpmp1.branch_ro_id, bpmp1.branch_zo_id, bm.org_id AS orgId, 
							bpmp1.business_type_id, bpmp1.sch_type_id
							FROM users.`branch_product_mapping` bpmp1
							INNER JOIN users.branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = ', branchType,' 
							WHERE bpmp1.branch_zo_id = ',@branchId,' AND bpmp1.sch_type_id = ', schemeId,'  
						
							UNION ALL
			
							SELECT DISTINCT bpmp.branch_id, bm.branch_type AS branchTypeId, bpmp.branch_ro_id AS branchRoId, bpmp.branch_zo_id AS branchZoId, bm.org_id AS orgId,
							bpmp.business_type_id, bpmp.sch_type_id FROM users.`branch_product_mapping` bpmp1
							INNER JOIN users.`branch_product_mapping` bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = ', schemeId,' 
							INNER JOIN users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = ', branchType,' 
							WHERE bpmp1.branch_zo_id = ',@branchId,'  AND bpmp1.sch_type_id = ', schemeId,'  
						) bpm ', @tableQuery);
						
		ELSEIF branchType = 2 THEN
		
			SET @tableQuery = CONCAT(' FROM users.`branch_product_mapping` bpm
							INNER JOIN users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = ', branchType,
							@tableQuery);
			
			SET @whereClause  = CONCAT(@whereClause,' AND bpm.branch_zo_id = ',@branchId);
			
		ELSEIF branchType = 5 THEN
		
			SET @tableQuery = CONCAT(' FROM (
							SELECT DISTINCT bpmp1.branch_id, bm.branch_type AS branchTypeId, bpmp1.branch_ro_id, bpmp1.branch_zo_id, bm.org_id AS orgId, 
							bpmp1.business_type_id, bpmp1.sch_type_id
							FROM users.`branch_product_mapping` bpmp1
							INNER JOIN users.branch_master bm ON bm.id = bpmp1.branch_id AND bm.branch_type IN(1,2)
							WHERE bpmp1.branch_zo_id = ',@branchId,' AND bpmp1.sch_type_id = ', schemeId,'  
						
							 UNION ALL
 			
							SELECT DISTINCT bpmp.branch_id, bm.branch_type AS branchTypeId, bpmp.branch_ro_id, bpmp.branch_zo_id, bm.org_id AS orgId,
							bpmp.business_type_id, bpmp.sch_type_id FROM users.`branch_product_mapping` bpmp1
							INNER JOIN users.`branch_product_mapping` bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = ', schemeId,' 
 							INNER JOIN users.branch_master bm ON bm.id = bpmp.branch_id AND bm.branch_type IN(1,2)
							WHERE bpmp1.branch_zo_id = ',@branchId,'  AND bpmp1.sch_type_id = ', schemeId,'  

						) bpm ', @tableQuery);

		END IF;
		
	END IF;
		
	IF branchType = 5 THEN -- ALL Branches
	
		SET @selectDataQuery = CONCAT(@selectDataQuery, ' IF (bbm.`branch_type` = 1 ,"Branch Office",IF (bbm.`branch_type` = 2 ,"Regional Office",IF (bbm.`branch_type` = 3 ,"Zonal Office","-"))) as branchType ');		
				
	ELSEIF branchType = 1 THEN  -- BO TYPE BRANCH
		
		SET @selectDataQuery = CONCAT(@selectDataQuery, ' "Branch Office" as branchType, 
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.`user_role_id` = 9 AND us.`is_active` = TRUE AND us.branch_id = bbm.id) as branchChecker,
					(SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.`user_role_id` = 8 AND us.`is_active` = TRUE AND us.branch_id = bbm.id) as branchMaker ');
				  
		SET @whereClause  = CONCAT(@whereClause, ' AND bbm.branch_type = ',branchType);
		
	
	ELSEIF branchType = 2 THEN -- RO TYPE BRANCH
	
		SET @selectDataQuery = CONCAT(@selectDataQuery, ' "Regional Office" as branchType ');
					
		SET @whereClause  = CONCAT(@whereClause, ' AND bbm.branch_type = ',branchType);
				
	
	ELSEIF branchType = 3 THEN -- ZO TYPE BRANCH
	
		SET @selectDataQuery = CONCAT(@selectDataQuery, ' "Zonal Office" as branchType ');
	
		SET @whereClause  = CONCAT(@whereClause, ' AND bbm.branch_type = ',branchType);
		
	END IF;
	
	IF ((IFNULL(columnFilter->"$.branchName", NULL) IS NOT NULL) AND (columnFilter->"$.branchName" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND bbm.`name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.branchName"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.branchCode", NULL) IS NOT NULL) AND (columnFilter->"$.branchCode" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND bbm.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.branchCode"),'%'' ');
	END IF;
	IF ((IFNULL(columnFilter->"$.totalUser", NULL) IS NOT NULL) AND (columnFilter->"$.totalUser" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND (SELECT COUNT(us.user_id) FROM users.`users` us WHERE us.branch_id = bbm.id) LIKE ''%', JSON_UNQUOTE(columnFilter->"$.totalUser"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.city", NULL) IS NOT NULL) AND (columnFilter->"$.city" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND ct.`city_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.city"),'%''');
	END IF;
	IF ((IFNULL(columnFilter->"$.state", NULL) IS NOT NULL) AND (columnFilter->"$.state" IS NOT NULL))
	THEN
		SET @whereClause = CONCAT(@whereClause, ' AND st.`state_name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.state"),'%''');
	END IF;
	
	-- IF ((IFNULL(columnFilter->"$.status", NULL) IS NOT NULL) AND (columnFilter->"$.status" IS NOT NULL))
	-- THEN
	--	SET @whereClause = CONCAT(@whereClause, ' AND  us.`is_active` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.status"),'%''');
	-- END IF;
	
--   For date RANGE
	IF (columnFilter->"$.fromDate" IS NOT NULL AND columnFilter->"$.toDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND (DATE(bm.created_on) BETWEEN ', columnFilter->"$.fromDate", ' AND ', columnFilter->"$.toDate",' OR DATE(bm.modified_date) BETWEEN ',columnFilter->"$.fromDate",' AND ',columnFilter->"$.toDate",')');
	ELSEIF (columnFilter->"$.fromDate" IS NOT NULL) THEN
		SET @whereClause = CONCAT(@whereClause, ' AND DATE(bm.created_on) = ', columnFilter->"$.fromDate");
	END IF;	

	SET @orderBy = ' ORDER BY bbm.id DESC';	

	IF (IFNULL(noPagination, NULL) IS NOT NULL AND noPagination IS NOT NULL AND noPagination != '') 
	THEN
	  SET @limit = ' ';  
	ELSE
	SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
	END IF;
	
	
	SET @totalCountQuery =  CONCAT('SELECT COUNT(DISTINCT bpm.branch_id) INTO @totalCount ', @tableQuery, @whereClause);
-- 	select @totalCountQuery;
	PREPARE cntstmt FROM @totalCountQuery;
	EXECUTE cntstmt;

	SET @query = CONCAT('SELECT DISTINCT bpm.branch_id AS branchId, ',' @totalCount AS totalCount, ',@selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
--   	select @query;
-- 	INSERT INTO `users`.`temp` (val, val2) VALUES ('@query',@query);
	PREPARE stmt1 FROM @query;
	EXECUTE stmt1;	
-- 	CALL users.spUserManagementFetchAllOfficesRoZo(75672,37,9,5,NULL,0,100,1,NULL)
	
	END$$

DELIMITER ;