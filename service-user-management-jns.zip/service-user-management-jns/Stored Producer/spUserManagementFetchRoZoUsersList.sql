CREATE OR REPLACE PROCEDURE JNS_USERS.SPUSERMANAGEMENTFETCHROZOUSERSLIST(
	orgId IN NUMBER,
	businessTypeId IN NUMBER,
	roleType IN NUMBER,
	noPagination IN VARCHAR2,
	paginationFROM IN VARCHAR2,
	paginationTO IN VARCHAR2,
	schemeId IN NUMBER,
	userid IN NUMBER,
	columnFilter IN CLOB,
	result out clob
 )AS

	selectCountQuery CLOB;
	tableQuery CLOB;
	whereClause  CLOB;
	totalCountQuery CLOB;
	orderBy CLOB;
	limitQuery CLOB;
	totalcount number;
	selectDataQuery CLOB;
	finalQuery CLOB;
	mainQuery clob;
	query2 clob;
	userroleid NUMBER;
	usertypeid NUMBER;
	branchId NUMBER;
BEGIN

    SELECT user_role_id,user_type_id,branch_id INTO userroleid,usertypeid,branchId FROM jns_users.users WHERE user_id = userid AND is_active = 1;

	selectCountQuery := ' SELECT sum(COUNT(Distinct us.user_id))  ';
	-- CONCAT(CAST((AES_DECRYPT(UNHEX(jns_users."decvalue"(us.first_name)),"C@p!ta@W0rld#AES")) AS CHAR)
	selectDataQuery := 'us.user_id as userId,concat(jns_users."decvalue"(us.first_name),jns_users."decvalue"(us.last_name))as userName,jns_users."decvalue"(us.email) as email,
					jns_users."decvalue"(us.mobile) as mobile,us.sign_up_date as signupDate,CASE WHEN m.is_active=1 THEN 1 ELSE 0 END as isActive,bh.id as branchId,bh.name as branchName,um.display_org_name AS orgName,um.user_org_id AS orgId,
					 bh.code as branchCode,ct.name as city,st.name as state,role.display_name as userType,us.user_role_id as roleTypeId,CASE WHEN us.is_locked=1 THEN ''true'' ELSE ''false'' END as isLocked,
 					 (SELECT u.login_date FROM jns_users.user_token_mapping u WHERE u.user_id = us.user_id ORDER BY u.id DESC offset 0 rows fetch next 1 row only) as lastLogin,
					 ZO.id as zoBranchId,
					 ZO.name as zoBranchName,
					 ZO.code as zoBranchCode,
					 RO.id as roBranchId,
					 RO.name as roBranchName,
					 RO.code as roBranchCode';

	tableQuery := ' FROM jns_users.users us
                    INNER JOIN JNS_USERS.user_role_master role ON role.role_id = us.user_role_id
                    INNER JOIN JNS_USERS.branch_master bh ON bh.id = us.branch_id
                    LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ct ON ct.id = bh.city_id
                    LEFT JOIN JNS_ONEFORM.lgd_state st ON st.id = bh.state_id
                    LEFT JOIN JNS_USERS.user_role_product_mapping m ON m.user_id = us.user_id
                    LEFT JOIN JNS_USERS.user_organisation_master um on um.user_org_id = us.user_org_id
                    LEFT JOIN JNS_USERS.branch_product_mapping BMAP ON BMAP.branch_id = us.branch_id AND BMAP.sch_type_id = '|| schemeId ||'
                    LEFT JOIN JNS_USERS.branch_master RO ON RO.id = BMAP.branch_ro_id
                    LEFT JOIN JNS_USERS.branch_master ZO ON ZO.id = BMAP.branch_zo_id  ';

    whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' AND m.business_id = ' ||businessTypeId || ' AND m.scheme_id = ' ||schemeId ||'';

 IF userroleid = 13 THEN
	IF (roleType = 9 OR roleType = 1) THEN -- ALL USERS
		whereClause  := whereClause || ' AND bh.branch_type = 1 AND m.user_role_id IN (9) AND BMAP.branch_id IN(SELECT DISTINCT bpm1.branch_id  FROM jns_users.branch_product_mapping bpm1 inner join JNS_USERS.branch_master bm on bm.id = bpm1.branch_id and bm.branch_type = 1 WHERE bpm1.sch_type_id = '|| schemeid ||' AND bpm1.branch_ro_id =  ' ||branchId || ' ' || ' )';
END IF;
ELSIF userroleid = 14 THEN
	IF roleType = 9 THEN  -- SQLINES DEMO *** R/CHECKER)
		whereClause  := whereClause || '  AND bh.branch_type = 1 AND m.user_role_id IN (9)
							  AND BMAP.branch_id IN(

				     SELECT DISTINCT bpm.branchId  FROM (
							SELECT DISTINCT bpmp1.branch_id AS branchId , bm.branch_type AS branchTypeId
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = 1 AND sch_type_id = '|| schemeId ||'
							WHERE bpmp1.branch_zo_id = ' || branchId || ' AND bpmp1.sch_type_id = '|| schemeId ||'

							UNION ALL

							SELECT DISTINCT bpmp.branch_id AS branchId, bm.branch_type AS branchTypeId
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = '|| schemeId ||'
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = 1
							WHERE bpmp1.branch_zo_id = '|| branchId || '  AND bpmp1.sch_type_id = '|| schemeId || '
					) bpm

				     )   ';
        ELSIF roleType = 7 THEN
        whereClause  := whereClause || ' AND bh.branch_type = 2 AND m.user_role_id IN (13) AND BMAP.branch_id IN(SELECT DISTINCT branch_id  FROM JNS_USERS.branch_product_mapping WHERE branch_zo_id = ' || branchId || ' ) ';

        ELSIF roleType = 1 THEN
        whereClause  := whereClause || ' AND (bh.branch_type = 2 OR bh.branch_type = 1) AND m.user_role_id IN(13,9)
			AND BMAP.branch_id IN(


				     SELECT DISTINCT bpm.branchId  FROM (
							SELECT DISTINCT bpmp1.branch_id AS branchId , bm.branch_type AS branchTypeId
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp1.branch_id AND sch_type_id = '|| schemeId ||'
							WHERE bpmp1.branch_zo_id = '|| branchId ||' AND bpmp1.sch_type_id = ' || schemeId ||'

							UNION ALL

							SELECT DISTINCT bpmp.branch_id AS branchId, bm.branch_type AS branchTypeId
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = '|| schemeId ||'
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = 1
							WHERE bpmp1.branch_zo_id = '|| branchId ||'  AND bpmp1.sch_type_id = '|| schemeId ||'
					) bpm

			 ) ';

	END IF;
    END IF;
--   For date RANGE


	IF (JSON_VALUE(columnFilter,'$.fromDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate')  IS NOT NULL) THEN
		whereClause := whereClause || ' AND (DATE(us.created_date) BETWEEN ' || JSON_VALUE(columnFilter,'$.fromDate') || ' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||' OR DATE(us.modified_date) BETWEEN ' ||JSON_VALUE(columnFilter,'$.fromDate') ||' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||')';
	ELSIF (JSON_VALUE(columnFilter,'$.fromDate' )IS NOT NULL ) THEN
		whereClause := whereClause || ' AND DATE(us.created_date) = ' || JSON_VALUE(columnFilter,'$.fromDate');
	END IF;


	IF ((JSON_VALUE(columnFilter,'$.userName') IS NOT NULL)) THEN
 		whereClause := whereClause || ' AND (
			lower(jns_users."decvalue"(us.email)) LIKE ''%' || lower(JSON_VALUE(columnFilter,'$.userName')) ||'%''
			OR lower(jns_users."decvalue"(us.first_name)) LIKE ''%' || lower(JSON_VALUE(columnFilter,'$.userName')) ||'%''
            OR jns_users."decvalue"(us.mobile) LIKE ''%' || JSON_VALUE(columnFilter,'$.userName') ||'%''
            OR lower(jns_users."decvalue"(us.last_name)) LIKE ''%' || lower(JSON_VALUE(columnFilter,'$.userName')) ||'%'')
		';
	END IF;

    IF ((JSON_VALUE(columnFilter,'$.userRoleId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_role_id LIKE ''%' || JSON_VALUE(columnFilter,'$.userRoleId') ||'%'')
		';
    END IF;

     IF ((JSON_VALUE(columnFilter,'$.userTypeId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_type_id = ' || JSON_VALUE(columnFilter,'$.userTypeId') ||')
		';
    END IF;

         IF ((JSON_VALUE(columnFilter,'$.userOrgId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_org_id = ' || JSON_VALUE(columnFilter,'$.userOrgId') ||')
		';
    END IF;


		totalCountQuery :=  selectCountQuery || tableQuery || whereClause ||' GROUP BY m.is_active ' ;
   --   dbms_output.put_line(whereClause);
     -- dbms_output.put_line(totalCountQuery);
-- SQLINES DEMO *** untQuery;
		EXECUTE IMMEDIATE  totalCountQuery into totalcount;
--    EXECUTE IMMEDIATE totalcountquery;

		orderBy := ' ORDER BY us.user_id DESC';

		IF (noPagination IS NOT NULL OR noPagination != '')
		THEN
		  limitQuery := ' ';
		ELSE
            limitQuery := ' OFFSET '
                   || paginationfrom
                   || ' ROWS FETCH NEXT '
                   || paginationto
                   || ' ROWS ONLY';
		END IF;

        finalQuery := 'SELECT Distinct ' || case WHEN totalCount is null then 0 else totalCount end||' AS totalCount, ' ||selectDataQuery || tableQuery || whereClause || orderBy
        || limitQuery
        ;
-- 		select @query;
--    dbms_output.put_line(finalQuery);

        mainQuery:='SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalCount''VALUE totalCount,
        			''userId''VALUE userId,
					''userName''VALUE userName,
					''email''VALUE email,
					''mobile''VALUE mobile,
					''signupDate''VALUE signupDate,
					''isActive'' VALUE isActive,
					''branchId''VALUE branchId,
					''branchName''VALUE branchName,
					 ''branchCode''VALUE branchCode,
					''city''VALUE city,
					''state''VALUE state,
					''userType''VALUE userType,
					''roleTypeId''VALUE roleTypeId,
					''orgName''VALUE orgName,
					''orgId''VALUE orgId,
					''isLocked'' VALUE isLocked,
 					 ''lastLogin''VALUE lastLogin,
                     ''zoBranchId''VALUE zoBranchId,
					 ''zoBranchName''VALUE zoBranchName,
					 ''zoBranchCode''VALUE zoBranchCode,
					 ''roBranchId''VALUE roBranchId,
					 ''roBranchName''VALUE roBranchName,
					 ''roBranchCod''VALUE roBranchCode)RETURNING CLOB) from ('||finalquery||')';
                      DBMS_OUTPUT.PUT_LINE(mainQuery);
		EXECUTE IMMEDIATE  mainQuery into result;


--       DBMS_OUTPUT.PUT_LINE(mainQuery);
-- SQLINES DEMO *** rManagementBankUsersList(1, 1, 1, NULL, 0, 10, 1, '{}');
END SPUSERMANAGEMENTFETCHROZOUSERSLIST;