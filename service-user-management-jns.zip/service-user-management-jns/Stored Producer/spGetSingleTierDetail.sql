DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spGetSingleTierDetail`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spGetSingleTierDetail`(IN branchId BIGINT(20), IN roId BIGINT(20),IN zoId BIGINT(20))
BEGIN
		/*SELECT 
		CAST(JSON_ARRAYAGG(JSON_OBJECT(
		'branch',
		(SELECT JSON_OBJECT('branchCode',b.`code`,'branchName',b.`name`,'ifsc_code',b.ifsc_code,'stateId',b.state_id,'stateName',s.state_name,'cityId',b.city_id,'cityName',c.city_name,'branchAddress',b.street_name)
		FROM users.branch_master b
		LEFT JOIN one_form.state s ON b.state_id = s.id 
		LEFT JOIN one_form.city c ON b.city_id = c.id 
		WHERE b.id = branchId),
		'ro',
		if(roId < 0,'NULL',
		(SELECT JSON_OBJECT('roCode',b.code,'roName',b.name,'stateId',b.state_id,'stateName',s.state_name,'cityId',b.city_id,'cityName',c.city_name,'roAddress',b.street_name)
		FROM users.branch_master b 
		LEFT JOIN one_form.state s ON b.state_id = s.id 
		LEFT JOIN one_form.city c ON b.city_id = c.id 
		WHERE b.id = roId)),
		'zo',
		IF(zoId < 0,'NULL',
		(SELECT JSON_OBJECT('zoCode',b.code,'zoName',b.name,'stateId',b.state_id,'stateName',s.state_name,'cityId',b.city_id,'cityName',c.city_name,'zoAddress',b.street_name)
		FROM users.branch_master b 
		LEFT JOIN one_form.state s ON b.state_id = s.id 
		LEFT JOIN one_form.city c ON b.city_id = c.id 
		WHERE b.id = zoId)) )) AS CHAR)
		FROM DUAL;*/
		
		DECLARE branchJson VARCHAR(3000);
		DECLARE roJson VARCHAR(3000);
		DECLARE zoJson VARCHAR(3000);
	
		SELECT JSON_OBJECT('branchCode',b.`code`,'branchName',b.`name`,'ifsc_code',b.ifsc_code,'stateId',b.state_id,'stateName',s.state_name,'cityId',b.city_id,'cityName',c.city_name,'branchAddress',b.street_name)
		INTO @branchJson
		FROM users.branch_master b
		LEFT JOIN one_form.state s ON b.state_id = s.id 
		LEFT JOIN one_form.city c ON b.city_id = c.id 
		WHERE b.id = branchId;
			
		
		IF(roId < 0) THEN
			SET @roJson = '{}';
		ELSE
			SELECT JSON_OBJECT('roId',b.id,'roCode',b.code,'roName',b.name,'roStateId',b.state_id,'roStateName',s.state_name,'roCityId',b.city_id,'roCityName',c.city_name,'roAddress',b.street_name)
			INTO @roJson
			FROM users.branch_master b 
			LEFT JOIN one_form.state s ON b.state_id = s.id 
			LEFT JOIN one_form.city c ON b.city_id = c.id 
			WHERE b.id = roId;
		END IF;
		
		IF(zoId < 0) THEN
			SET @zoJson = '{}';
		ELSE
			SELECT JSON_OBJECT('zoId',b.id,'zoCode',b.code,'zoName',b.name,'zoStateId',b.state_id,'zoStateName',s.state_name,'zoCityId',b.city_id,'zoCityName',c.city_name,'zoAddress',b.street_name)
			INTO @zoJson
			FROM users.branch_master b 
			LEFT JOIN one_form.state s ON b.state_id = s.id 
			LEFT JOIN one_form.city c ON b.city_id = c.id 
			WHERE b.id = zoId;
		END IF;
			
		SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('branch',CAST(@branchJson AS JSON),'ro',CAST(@roJson AS JSON),'zo',CAST(@zoJson AS JSON))) AS CHAR) FROM DUAL;
		
	END$$

DELIMITER ;