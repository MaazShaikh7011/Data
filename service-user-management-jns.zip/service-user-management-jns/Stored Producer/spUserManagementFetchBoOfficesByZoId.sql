DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchBoOfficesByZoId`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchBoOfficesByZoId`(IN branchId INT,IN orgId BIGINT)
BEGIN
	
	SET @selectDataQuery = 'SELECT DISTINCT(bm.code) AS branchCode ';
	
	SET @tableQuery = ' FROM users.branch_master bm
				LEFT JOIN users.branch_product_mapping bpm ON bpm.branch_id = bm.id ';
					
	SET @whereClause  = CONCAT(' WHERE bm.`org_id` = ',orgId,' AND bm.is_active = TRUE AND bm.branch_type = 1 
								AND bm.id IN ( SELECT DISTINCT bpm.branchId  FROM (
										SELECT DISTINCT bpmp1.branch_id AS branchId
												FROM users.`branch_product_mapping` bpmp1
												INNER JOIN users.branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = 1
												WHERE bpmp1.branch_zo_id = ',branchId,'
												
												UNION ALL
												
												SELECT DISTINCT bpmp.branch_id AS branchId
												FROM users.`branch_product_mapping` bpmp1
												INNER JOIN users.`branch_product_mapping` bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id 
												INNER JOIN users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = 1
												WHERE bpmp1.branch_zo_id = ',branchId,' 
										) bpm ) '  );

	SET @orderBy = ' ORDER BY bm.id DESC';	
	
	SET @query = CONCAT(@selectDataQuery, @tableQuery, @whereClause, @orderBy);
--   	select @query;
-- 	INSERT INTO `users`.`temp` (val, val2) VALUES ('@query',@query);
	PREPARE stmt1 FROM @query;
	EXECUTE stmt1;	
-- 	CALL users.spUserManagementFetchBoOfficesByZoId(75672,37)
	
	END$$

DELIMITER ;