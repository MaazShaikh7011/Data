DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchSingleZoDetail`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchSingleZoDetail`(IN branchId BIGINT, IN businessTypeId INT)
BEGIN
		
			SELECT 
			CAST(JSON_ARRAYAGG(JSON_OBJECT(
			'zoId',b.id,
			'zoName',b.name,
			'zoCode',b.code,
			'state',s.state_name, 
			'city',c.city_name,
			'stateId',s.`id`, 
			'cityId',c.`id`,
			'branchCreation',b.`created_on`,
			'branchModification',b.`modified_date`,
			'activeRo',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master b ON bpm.branch_id = b.id WHERE bpm.branch_zo_id = branchId AND bpm.business_type_id = businessTypeId AND b.branch_type = 2),
			'roDetails',(SELECT JSON_ARRAYAGG(JSON_OBJECT('userId',u.user_id,
-- 					'userName',CONCAT(u.first_name,' ',u.last_name),
					'userName',CONCAT(decValue(u.first_name),' ',decValue(u.last_name)),
					'email',decValue(u.email),
					'mobile',decValue(u.mobile),
					'isActive',IF(u.`is_active` IS TRUE,'TRUE','FALSE'),
					'roName',b.`name`,
					'roCode',b.`code`,
					'city',c.city_name,
					'userType',r.`display_name`,
					'state',s.state_name))
					FROM users.users u 
					LEFT JOIN `users`.`branch_master` b ON u.`branch_id`=b.id
					LEFT JOIN one_form.state s ON b.state_id = s.id 
					LEFT JOIN one_form.city c ON b.city_id = c.id 
					LEFT JOIN `users`.`user_role_master` r ON u.`user_role_id` = r.role_id
					WHERE u.branch_id IN (SELECT DISTINCT(bpm.branch_id) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master b ON bpm.branch_id = b.id WHERE bpm.branch_zo_id = branchId AND bpm.business_type_id = businessTypeId AND b.branch_type = 2)),
			'boDetails',(SELECT JSON_ARRAYAGG(JSON_OBJECT('userId',u.user_id,
					'userName',CONCAT(decValue(u.first_name),' ',decValue(u.last_name)),
					'email',decValue(u.email),
					'mobile',decValue(u.mobile),
					'isActive',IF(u.`is_active` IS TRUE,'TRUE','FALSE'),
					'boName',b.`name`,
					'boCode',b.`code`,
					'city',c.city_name,
					'state',s.state_name,
					'userType',r.`display_name`,
					'roleName',r.`display_name`))
					FROM users.users u
					LEFT JOIN `users`.`branch_master` b ON u.`branch_id`=b.id
					LEFT JOIN one_form.state s ON b.state_id = s.id 
					LEFT JOIN one_form.city c ON b.city_id = c.id 
					LEFT JOIN `users`.`user_role_master` r ON u.`user_role_id` = r.role_id
					WHERE branch_id IN (SELECT DISTINCT(bpm.branch_id) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master b ON bpm.branch_id = b.id WHERE bpm.branch_ro_id IN 
					(SELECT DISTINCT(bpm.branch_id) FROM users.branch_product_mapping bpm INNER JOIN users.branch_master b ON bpm.branch_id = b.id 
					WHERE bpm.branch_zo_id = branchId AND bpm.business_type_id = businessTypeId AND b.branch_type = 2 AND bpm.business_type_id = businessTypeId))),
			'activeBo',(SELECT COUNT(DISTINCT(bpm.branch_id)) FROM users.branch_product_mapping bpm LEFT JOIN users.branch_master b ON bpm.branch_id = b.id WHERE bpm.branch_ro_id IN 
			(SELECT DISTINCT(bpm.branch_id) FROM users.branch_product_mapping bpm INNER JOIN users.branch_master b ON bpm.branch_id = b.id 
			WHERE bpm.branch_zo_id = branchId AND bpm.business_type_id = businessTypeId AND b.branch_type = 2 AND bpm.business_type_id = businessTypeId)),
			'pendingProposal',
			IF(businessTypeId=5,
			(SELECT COUNT(`proposal_id`) FROM `loan_application_details`.`hl_proposal_details` WHERE proposal_status_id = 1 AND is_active = TRUE AND
			 branch_id IN(SELECT branch_id FROM users.branch_product_mapping WHERE branch_zo_id = branchId AND business_type_id = businessTypeId)),
			 IF(businessTypeId=9,
			 (SELECT COUNT(`proposal_id`) FROM `loan_application_details`.`edu_proposal_details` WHERE proposal_status_id = 1 AND is_active = TRUE AND
			 branch_id IN(SELECT branch_id FROM users.branch_product_mapping WHERE branch_zo_id = branchId AND business_type_id = businessTypeId)),0)),
			'status',IF(b.is_active IS TRUE,'TRUE','FALSE') )) AS CHAR) AS result
			FROM users.branch_master b 
			LEFT JOIN one_form.state s ON b.state_id = s.id 
			LEFT JOIN one_form.city c ON b.city_id = c.id 
			WHERE b.id = branchId;
	END$$

DELIMITER ;