DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchZoList`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchZoList`(IN orgId INT, IN businessTypeId INT)
BEGIN
		SELECT 
		CAST(JSON_ARRAYAGG(JSON_OBJECT(
		'zoId',b.id,
		'zoName',b.name,
		'zoCode',b.code,
		'state',s.state_name, 
		'city',c.city_name,
		'userCount',(SELECT COUNT(user_id) FROM users.users WHERE branch_id = b.id AND is_active = TRUE AND is_self_active = TRUE),
		'status',IF(b.is_active IS TRUE,'TRUE','FALSE'))) AS CHAR)
		FROM users.branch_master b 
		LEFT JOIN one_form.state s ON b.state_id = s.id 
		LEFT JOIN one_form.city c ON b.city_id = c.id 
		WHERE b.branch_type = 3 AND b.org_id = orgId AND b.is_active = TRUE;
	END$$

DELIMITER ;