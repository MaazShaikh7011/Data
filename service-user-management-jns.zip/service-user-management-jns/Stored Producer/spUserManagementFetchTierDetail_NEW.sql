DELIMITER $$

USE `users`$$

DROP PROCEDURE IF EXISTS `spUserManagementFetchTierDetail_NEW`$$

CREATE DEFINER=`dbsidbi`@`%` PROCEDURE `spUserManagementFetchTierDetail_NEW`(IN orgId INT, IN businessTypeId INT,IN `type` INT, IN noPagination VARCHAR(255), IN paginationFROM TEXT, IN paginationTO TEXT,IN schemeId BIGINT,IN columnFilter TEXT)
BEGIN

    SELECT GROUP_CONCAT(branch_type) INTO @branchType FROM users.tier_mapping_permission WHERE org_id = orgId AND is_active = TRUE;
    
    SET @selectCountQuery = ' SELECT COUNT(*) INTO @totalCount ';
    
    SET @selectDataQuery='';
    SET @headerName = '{"isFirst":"isFirst"';
    IF (0 < FIND_IN_SET('1',@branchType)) THEN 
	SET @selectDataQuery = CONCAT(@selectDataQuery,
			   'br.id as branchId,
			   ''BO Code'' as boHeaderCode,
			   ''BO Name'' as boHeaderName,
			    br.code as branchCode,
			    br.name as branchName,');
	SET @headerName = CONCAT(@headerName,',"boHeaderCode":"BO Code","boHeaderName": "BO Name" ');
    
    END IF;
    IF (0 < FIND_IN_SET('2',@branchType)) THEN 
    
	SET @selectDataQuery = CONCAT(@selectDataQuery,'rob.id as roId,
			 ''RO Code'' as roHeaderCode,
			 ''RO Name'' as roHeaderName,
			    rob.code as roCode,
			    rob.name as roName,');
	SET @headerName = CONCAT(@headerName,',"roHeaderCode":"RO Code","roHeaderName": "RO Name" ');
    
    END IF;
    
    IF (0 < FIND_IN_SET('3',@branchType)) THEN 
    
	SET @selectDataQuery = CONCAT(@selectDataQuery,'zob.id as zoId,
			 ''ZO Code'' as zoHeaderCode,
			 ''ZO Name'' as zoHeaderName,
			    zob.code as zoCode,
			    zob.name as zoName,');
	SET @headerName = CONCAT(@headerName,',"zoHeaderCode":"ZO Code","zoHeaderName": "ZO Name" ');
    
    END IF;
    
    IF (0 < FIND_IN_SET('6',@branchType)) THEN 
    
	SET @selectDataQuery = CONCAT(@selectDataQuery,'lho.id as lhoId,
			 ''LHO Code'' as lhoHeaderCode,
			 ''LHO Name'' as lhoHeaderName,
			    lho.code as lhoCode,
			    lho.name as lhoName,');
	SET @headerName = CONCAT(@headerName,',"lhoHeaderCode":"LHO Code","lhoHeaderName": "LHO Name" ');
    END IF;
    
    SET @headerName = CONCAT(@headerName,'}');
    
    SET @selectDataQuery = CONCAT(@selectDataQuery,'bm.created_date as createdDate ');
		
    SET @tableQuery = ' FROM users.branch_product_mapping bm 
				LEFT JOIN users.branch_master rob ON bm.branch_ro_id = rob.id AND rob.branch_type = 2 AND rob.is_active = TRUE
				LEFT JOIN users.branch_master br ON bm.branch_id = br.id AND br.branch_type = 1 AND br.is_active = TRUE
				LEFT JOIN users.branch_master zob ON bm.branch_zo_id = zob.id AND zob.branch_type = 3 AND zob.is_active = TRUE
				LEFT JOIN users.branch_master lho ON bm.branch_lho_id = lho.id AND lho.branch_type = 6 AND lho.is_active = TRUE';
		IF (`type` = 1)THEN
				SET @whereClause  = CONCAT(' WHERE bm.user_org_id = ',orgId,' AND bm.business_type_id = ',businessTypeId,
				' AND bm.sch_type_id = ',schemeId,
				' and bm.is_active = TRUE AND br.id IS NOT NULL AND (rob.id IS NULL AND zob.id IS NULL AND lho.id IS NULL)');
		ELSEIF(`type` = 2)THEN
				SET @whereClause  = CONCAT(' WHERE bm.user_org_id = ',orgId,' AND bm.business_type_id = ',businessTypeId,
				' AND bm.sch_type_id = ',schemeId,
				' and bm.is_active = TRUE AND br.id IS NOT NULL AND (rob.id IS NOT NULL OR zob.id IS NOT NULL OR lho.id IS NOT NULL)');
		ELSE 
				SELECT '' FROM DUAL;
		END IF;	
		
		
--   For date RANGE
		IF (columnFilter->"$.fromDate" IS NOT NULL AND columnFilter->"$.toDate" IS NOT NULL) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(bm.created_date) BETWEEN ', columnFilter->"$.fromDate", ' AND ', columnFilter->"$.toDate");
		ELSEIF (columnFilter->"$.fromDate" IS NOT NULL) THEN
			SET @whereClause = CONCAT(@whereClause, ' AND DATE(bm.created_date) = ', columnFilter->"$.fromDate");
		END IF;	
--	BO
		IF (columnFilter->"$.boName" IS NOT NULL)
		THEN			
			SET @whereClause = CONCAT(@whereClause,'AND (br.`name` LIKE ''%', JSON_UNQUOTE(columnFilter->"$.boName"),'%'' OR br.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.boName"),'%'')');	
		END IF;
--		IF ((IFNULL(columnFilter->"$.boCode", NULL) IS NOT NULL) AND (columnFilter->"$.boCode" IS NOT NULL))
-- 		THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND br.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.boCode"),'%''');
-- 		END IF;
--	RO
		IF ((IFNULL(columnFilter->"$.roName", NULL) IS NOT NULL) AND (columnFilter->"$.roName" IS NOT NULL))
		THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (rob.name LIKE ''%', JSON_UNQUOTE(columnFilter->"$.roName"),'%'' OR rob.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.roName"),'%'')');
		END IF;
--		IF ((IFNULL(columnFilter->"$.roCode", NULL) IS NOT NULL) AND (columnFilter->"$.roCode" IS NOT NULL))
-- 		THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND rob.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.roCode"),'%''');
-- 		END IF;
--	ZO
		IF ((IFNULL(columnFilter->"$.zoName", NULL) IS NOT NULL) AND (columnFilter->"$.zoName" IS NOT NULL))
		THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (zob.name LIKE ''%', JSON_UNQUOTE(columnFilter->"$.zoName"),'%'' OR zob.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.zoName"),'%'')');
		END IF;
-- 		IF ((IFNULL(columnFilter->"$.zoCode", NULL) IS NOT NULL) AND (columnFilter->"$.zoCode" IS NOT NULL))
-- 		THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND zob.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.zoCode"),'%''');
-- 		END IF;
		
--	LHO
		IF ((IFNULL(columnFilter->"$.lhoName", NULL) IS NOT NULL) AND (columnFilter->"$.lhoName" IS NOT NULL))
		THEN
			SET @whereClause = CONCAT(@whereClause, ' AND (lho.name LIKE ''%', JSON_UNQUOTE(columnFilter->"$.lhoName"),'%'' OR lho.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.lhoName"),'%'')');
		END IF;
-- 		IF ((IFNULL(columnFilter->"$.lhoCode", NULL) IS NOT NULL) AND (columnFilter->"$.lhoCode" IS NOT NULL))
-- 		THEN
-- 			SET @whereClause = CONCAT(@whereClause, ' AND lho.code LIKE ''%', JSON_UNQUOTE(columnFilter->"$.lhoCode"),'%''');
-- 		END IF;
			
		SET @totalCountQuery =  CONCAT(@selectCountQuery, @tableQuery, @whereClause);
		
		PREPARE cntstmt FROM @totalCountQuery;
		EXECUTE cntstmt;

		SET @orderBy = ' ORDER BY bm.created_date DESC';	

		IF (IFNULL(noPagination, NULL) IS NOT NULL AND noPagination IS NOT NULL AND noPagination != '') 
		THEN
		  SET @limit = ' ';  
		ELSE
		SET @limit = CONCAT( ' LIMIT ', paginationFROM, ' , ' , paginationTO);
		END IF;

		IF (0 < @totalCount) THEN
			SET @query = CONCAT('SELECT ',' @totalCount AS totalCount, @headerName as headerName, ',@selectDataQuery, @tableQuery, @whereClause, @orderBy, @limit);
		ELSE
			SET @query = CONCAT('SELECT ', ' @totalCount AS totalCount, @headerName as headerName ');
		END IF;

-- 		select @query;
		PREPARE stmt1 FROM @query;
		EXECUTE stmt1;		
    END$$

DELIMITER ;