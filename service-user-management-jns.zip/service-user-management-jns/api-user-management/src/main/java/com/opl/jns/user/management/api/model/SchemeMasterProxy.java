package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SchemeMasterProxy implements Serializable {
	
	private Long id;
	
	private Long schemeId;

    private Integer businessTypeId;
    
    private String businessTypeName;

    private Integer businessId;

    private String name;

    private String shortName;

    private String description;

    private String descriptionHtml;

    private String schemeInfoDescriptionHtml;

    private String imgPath;

    private String path;

    private Long createdBy;

    private Long modifiedBy;

    private Date createdDate;

    private Date modifiedDate;

    private Integer orgType;

    private boolean isActive;

    private Integer ministryId;

    private boolean isFacilitator;

    private String ministryName;

    private boolean isUlb;

    public SchemeMasterProxy(Long schemeId, String name, String shortName, Integer ministryId, boolean isFacilitator,boolean isUlb) {
        this.schemeId = schemeId;
        this.name = name;
        this.shortName = shortName;
        this.ministryId = ministryId;
        this.isFacilitator = isFacilitator;
        this.isUlb = isUlb;
    }
}
