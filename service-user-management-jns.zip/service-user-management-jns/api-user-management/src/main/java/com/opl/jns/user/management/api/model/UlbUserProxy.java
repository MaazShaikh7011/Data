package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UlbUserProxy implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long userId;
    private String email;
    private String mobile;
    private String firstName;
    private String middleName;
    private String lastName;
    private Boolean isActive;
    private Long ulbLgdCode;
    private Long stateLgdCode;
    private Long districtLgdCode;
    private Long  ulbRole;
}
