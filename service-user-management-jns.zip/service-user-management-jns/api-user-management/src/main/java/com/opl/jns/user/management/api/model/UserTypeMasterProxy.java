package com.opl.jns.user.management.api.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class UserTypeMasterProxy {
	
	private Long id;

	private String code;

	private Long createdBy;

	private Date createdDate;

	private String description;

	private Boolean isActive;

	private Boolean isDisplayOnLogin;

	private Long modifiedBy;

	private Date modifiedDate;

	private String name;


}
