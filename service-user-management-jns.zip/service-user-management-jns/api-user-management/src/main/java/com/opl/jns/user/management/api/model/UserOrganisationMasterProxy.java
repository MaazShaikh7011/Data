package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserOrganisationMasterProxy {
    private Long userOrgId;

    private String organisationName;

    private String displayOrgName;

    private String organisationCode;

    private Integer orgType;

    private Long userTypeId;

    private String username;

    private String password;

    private String uatUrl;

    private String productionUrl;

    private Boolean isReverseApiActivated;

    private Integer codeLanguage;

    private String config;

    private String generalFields;

    private Long modifiedBy;

    private Timestamp modifiedDate;

    private boolean isActive;

    private String generalConfig;

    private String controlBlockMsme;

    private String controlBlockNtb;

    private Long campaignType;

    public UserOrganisationMasterProxy(Long userOrgId, String organisationName) {
        this.userOrgId = userOrgId;
        this.organisationName = organisationName;
    }

    public UserOrganisationMasterProxy(String orgCode, String organisationName) {
        this.organisationCode=orgCode;
        this.organisationName = organisationName;
    }
}
