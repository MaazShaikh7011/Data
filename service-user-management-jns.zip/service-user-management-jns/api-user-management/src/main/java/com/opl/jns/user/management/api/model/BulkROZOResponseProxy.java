package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;



/**
 * Created by pooja.patel on 24-09-2020.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BulkROZOResponseProxy {

    private Long id;
    private Long orgId;
    private Long branchId;
    private String branchCode;
    private Long branchROId;
    private String ROCode;
    private String ROEmail;
    private String ROMobile;
    private String ROName;
    private String ROAddress;
    private Integer ROPincode;
    private Integer ROCityId;
    private Integer ROStateId;
    private Long branchZOId;
    private String ZOCode;
    private String ZOEmail;
    private String ZOMobile;
    private String ZOName;
    private String ZOAddress;
    private Integer ZOPincode;
    private Integer ZOCityId;
    private Integer ZOStateId;
    private Integer businessTypeId;
    private Date createdDate;
    private Boolean isActive;
    private String message;
    private Long fileId;
    private Long userRoleId;
    private String createdByBranchId;
    private String originalFileName;

}
