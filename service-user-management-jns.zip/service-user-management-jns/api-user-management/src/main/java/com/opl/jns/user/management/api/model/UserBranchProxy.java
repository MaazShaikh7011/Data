package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class UserBranchProxy {

	public Long branchId;
	public String branchCode;
	private String branchName;
	private Integer branchType;
	private Integer cityId;
	public Integer stateId;
	public String ContactPersonEmail;
	public String ContactPersonName;
	public String ContactPersonNumber;
}
