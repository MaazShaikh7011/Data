package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BranchTypeMasterRequest {
    private Long id;

    private Long orgId;

    private String branchType;

    private Boolean isActive;

    private Boolean isSelected;

    private Boolean isDisplay;

    private Boolean isChecked;

}
