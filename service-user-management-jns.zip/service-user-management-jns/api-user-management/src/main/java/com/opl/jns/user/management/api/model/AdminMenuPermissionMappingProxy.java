package com.opl.jns.user.management.api.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminMenuPermissionMappingProxy {

    private Long id;
    private Long menuId;
    private Long typeId;
    private Long roleId;
    private Boolean isActive;
    private Integer schemeId;
    private List<Long> idsList;
}
