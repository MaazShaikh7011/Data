package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleMasterProxy {

    private Long roleId;

    private String roleName;

    private Long createdBy;

    private Date createdDate;

    private Long modifiedBy;

    private Date modifiedDate;

    private Boolean isActive;

    private String displayName;

    private Boolean isAdminDisplay;

    private Boolean adminUserDetailsRole;

    private Boolean bankAdminUserDetailsRole;

    private Integer branchType;

    private String displayOfficeName;

    public RoleMasterProxy(Long roleId, String roleName) {
        this.roleId = roleId;
        this.roleName = roleName;
    }
}
