package com.opl.jns.user.management.api.model.partner;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartnerProxy {

	private Long userId;
	private String name;
	private String email;
	private String mobileNo;
	private List<Long> schemeId;
	private Long loggedInUserId;
	private Long orgId;
	private Long modifiedBy;
	private Date modifiedDate;
	private Boolean isActive;
	private Long createdBy;
	private Date createdDate;
	private Long userType;
	private Long userRoleId;
	private String pan;
	
	// 1 for partner and 2 for client
	private Long typeId;
	private List<Map<String, Object>> roleProductList;
}
