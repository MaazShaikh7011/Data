package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;



/**
 * Created by pooja.patel on 24-09-2020.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BulkBranchResponseProxy {

    private Long id;
    private String branchType;
    private String email;
    private String mobile;
    private String branchName;
    private String branchCode;
    private String ifscCode;
    private String address;
    private String pincode;
    private Integer state;
    private Integer city;
    private String roCode;
    private String zoCode;
    private Long orgId;
    private Long businessTypeId;
    private Date dateTime;
    private Boolean isActive;
    private String message;
    private Long fileId;
    private String schemeName;
    private Long userRoleId;
    private String createdByBranchId;
    private String originalFileName;

}
