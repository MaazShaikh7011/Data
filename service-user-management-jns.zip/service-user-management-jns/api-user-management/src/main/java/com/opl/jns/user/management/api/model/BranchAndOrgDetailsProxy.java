package com.opl.jns.user.management.api.model;

import lombok.*;

import java.util.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BranchAndOrgDetailsProxy {

	private String bankName;
	private String bankCode;

	private String insurerName;
	private String insurerCode;

	private String branchName;
}
