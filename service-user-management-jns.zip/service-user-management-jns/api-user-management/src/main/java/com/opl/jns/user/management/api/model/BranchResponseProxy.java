package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BranchResponseProxy {

    public String branchId;
    public String branchName;
    public String branchCode;
    public String numberOfUsers;
    public String roName;
    public String zoName;
    public String city;
    public String state;
    public String status;

}
