package com.opl.jns.user.management.api.method;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonMethods {
    public boolean isValidContactNo(String contactNo) {
        Pattern pattern = Pattern.compile("^\\d{10}$");
        Matcher matcher = pattern.matcher(contactNo);
        if (matcher.matches())
            return contactNo.startsWith("6") || contactNo.startsWith("7") || contactNo.startsWith("8")
                    || contactNo.startsWith("9");
        else
            return false;
    }
}

