package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class TierMappingRequestProxy {
	private Long userId;
    private Integer orgId;
    private Integer businessTypeId;
    private Long schemeId;
    private List<Long> selectedScheme;
    private Integer type;
    private Long branchId;
    private Long roId;
    private Long zoId;
    private Date fromDate;
    private Date toDate;
    private String noPagination;
    private String paginationFROM;
    private String paginationTO;
    private Object columnFilter;
    private Long lhoId;
    private Long userRoleId;

}
