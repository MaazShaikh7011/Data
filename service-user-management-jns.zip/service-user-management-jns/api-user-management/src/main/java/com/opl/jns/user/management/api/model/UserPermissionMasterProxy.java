package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserPermissionMasterProxy {

    private Long id;

    private String name;

    private String alias;

    private Long groupId;

    private Boolean isActive;

    private Integer loanTypeId;

    private Boolean isGlobal;

    private Date createdDate;

    private Long createdBy;

    private Date modifiedDate;

    private Long modifiedBy;

    public UserPermissionMasterProxy(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
