package com.opl.jns.user.management.api.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class UsersProxy {
	
	private Long userId;

	private String email;

	private String mobile;

	private String password;

	private String username;

	private String firstName;

	private String lastName;

	private String middleName;

	private Boolean termsAccepted;

	private Boolean otpVerified;

	private Boolean emailVerified;

	private Boolean isDeleted;

	private Boolean isLocked;

	private Integer loginCounter;

	private String campaignCode;

	private String password1;

	private String password2;

	private Date signUpDate;

	private UserTypeMasterProxy userTypeMaster;

	private Boolean isPassChanged;

	private Long modifiedBy;

	private Date modifiedDate;

	private Boolean isActive;

	private Long createdBy;

	private Date createdDate;
	
	private Long userRoleId;
	
	private Long userTypeId;
	
	private Long orgId;
	
	private Long branchId;

}
