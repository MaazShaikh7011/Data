package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MenuRoleLoanMappingProxy {

    private Long id;

    private String navigationPath;

    private Long menuId;

    private Long roleId;

    private Long businessTypeId;

    private Integer sequence;

    private boolean isActive;

    private Integer schemeId;
    
    private List<MenuMasterProxy> menuMasterProxy;

    public MenuRoleLoanMappingProxy(Long menuId) {
        this.menuId = menuId;
    }

    public MenuRoleLoanMappingProxy(Long menuId, String navigationPath) {
        this.menuId = menuId;
        this.navigationPath = navigationPath;
    }
}
