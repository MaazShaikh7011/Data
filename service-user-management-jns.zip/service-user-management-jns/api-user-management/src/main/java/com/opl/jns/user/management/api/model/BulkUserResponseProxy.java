package com.opl.jns.user.management.api.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by pooja.patel on 24-09-2020.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BulkUserResponseProxy {

    private Long id;
    private String email;
    private String mobile;
    private String firstName;
    private String middleName;
    private String lastName;
    private String role;
    private String branchCode;
    private String branchId;
    private Long orgId;
    private Integer businessTypeId;
    private Date createdDate;
    private Boolean isActive;
    private String message;
    private Long fileId;
    private String schemeName;
    private Long schemeId;
    private String roleName;
    private Long userRoleId;
    private String createdByBranchId;
    private String originalFileName;

}
