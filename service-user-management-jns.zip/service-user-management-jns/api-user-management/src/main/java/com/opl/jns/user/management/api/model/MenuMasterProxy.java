package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MenuMasterProxy {

    private Long id;

    private String keyName;

    private String displayName;

    private Long parentId;

    private String iconPath;

    private boolean isActive;

    private boolean isAdminMenu;

    private String navigationPath;

    private Integer sequence;
}
