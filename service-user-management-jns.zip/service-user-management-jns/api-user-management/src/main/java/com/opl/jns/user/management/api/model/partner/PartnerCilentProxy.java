package com.opl.jns.user.management.api.model.partner;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartnerCilentProxy {
	//Excel File Field
	private String name;
	private String email;
	private String mobile;
	private String scheme;
	private String pan;
	private Boolean isActive;
	
	//RequestResponse
	private Long partnerId ;
	private Long schemeId;
	private Long roleId;
	private Long clientId;
	private Long fileId;
	private Long userOrgId;
	private Long userId;
	private Long loggedInUserId;
	private Long fileType;
	

}
