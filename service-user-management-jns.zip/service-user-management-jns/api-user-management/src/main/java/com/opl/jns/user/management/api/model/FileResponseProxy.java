package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * Created by pooja.patel on 09-09-2020.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class FileResponseProxy {

    private Long id;
    private String originalFileName;
    private String message;
    private Integer status;
    private Integer successfulEntries;
    private Integer failedEntries;
    private Integer totalEntries;
    private Date createdDate;
    private Boolean isActive;
    private Long userType;
    private Integer checkEntry;
}
