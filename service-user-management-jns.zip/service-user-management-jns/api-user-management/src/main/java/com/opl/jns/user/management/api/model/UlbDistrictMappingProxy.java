package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.utils.common.EncryptionUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UlbDistrictMappingProxy implements Serializable{

    private static final long serialVersionUID = 1L;

    private Long id;

    private Long stateLgdCode;

    private Long districtLgdCode;

    private Long ulbLgdCode;

    private String ulbName;

    private Long userId;

    private Long modifiedBy;

    private Date modifiedDate;

    private boolean isActive;

    private Long createdBy;

    private Date createdDate;


    public UlbDistrictMappingProxy(Long id,Long ulbLgdCode, String ulbName) {
        this.id = id;
        this.ulbLgdCode = ulbLgdCode;
        this.ulbName = ulbName;
    }
}
