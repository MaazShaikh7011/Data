package com.opl.jns.user.management.api.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class BranchRequestProxy {
    private Integer orgId;
    private Long userOrgId;
    private Integer businessTypeId;
    private Long branchId;
    private Long roleId;
    private Integer cityId;
    private String code;
    private String contactPersonEmail;
    private String contactPersonName;
    private String contactPersonNumber;
    private String name;
    private int pincode;
    private Integer stateId;
    private List<Integer> stateIdLst;
    private String streetName;
    private String telephoneNo;
    private String ifscCode;
    private Integer branchType;
    private Integer regionId;
    private Long branchRoId;
    private Long branchZoId;
    private Long branchLHoId;
    private Long branchRoZoId;
    private List<Long> branchZoIdLst;
    private List<Long> branchRoIdLst;
    private Integer ruralUrbanId;

    private Long branchHoId;

    private Long schemeId;
    private List<Long> selectedScheme;
    private List<Long> schemeList;
    private List<Map<String,Object>> branchProductList;
    private Boolean isAdminPanel;


    public BranchRequestProxy(Integer orgId, String name) {
        this.orgId = orgId;
        this.name = name;
    }

    public BranchRequestProxy(Long branchId, String code) {
        this.branchId = branchId;
        this.code = code;
    }
}
