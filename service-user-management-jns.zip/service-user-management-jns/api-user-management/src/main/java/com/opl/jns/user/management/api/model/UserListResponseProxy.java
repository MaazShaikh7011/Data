package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by pooja.patel on 19-03-2021.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UserListResponseProxy implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long userId;
    private String email;
    private String mobile;
    private String firstName;
    private String middleName;
    private String lastName;
    private Date signupDate;
    private Boolean isActive;
    private String branchName;
    private String city;
    private String state;
    private String branchCode;
    private String userType;
    private Integer roleType;
    private Long userRoleId;
    private Long branchId;
    private Boolean isLocked;
    private Boolean isLockedByAdmin;
    private Long businessTypeId;
    private Long schemeId;
    private Date lastLoginDate;
    private List<Long> businessId;
    private List<Map<String,Object>> roleProductList;
    private List<Long> roleList;
    private List<Long> selectedScheme;
    private Long userOrgId;
    private Integer pageSize;
    private Integer pageIndex;
    private Date fromDate;
    private Date toDate;
    private String noPagination;
    private String paginationFROM;
    private String paginationTO;
    private Object columnFilter;
    private List<Long> schemeList;
    private Boolean roleProductStatus;
    private Long fileId;
    private Long userTypeId;
    private Long createdBy;
    private String taggedSchemes;
    private Integer ministryId;
    private Boolean isFacilitator;
    private Boolean isUlb;
    private Long ulbLgdCode;
    private Long stateLgdCode;
    private Long districtLgdCode;
    private Boolean isAdminPanel;
    private Long ulbRole;

    private Long fileType;
    
    public UserListResponseProxy(Long userId, String email, String mobile, String firstName, String userType) {
        this.userId = userId;
        this.email = email;
        this.mobile = mobile;
        this.firstName = firstName;
        this.userType = userType;
    }
    
    public UserListResponseProxy(Long userId, String email, String mobile, String firstName, String userType, Boolean isLocked) {
        this.userId = userId;
        this.email = email;
        this.mobile = mobile;
        this.firstName = firstName;
        this.userType = userType;
        this.isLocked = isLocked;
    }

    public UserListResponseProxy(Long userId, String email, String mobile, String firstName, String userType,Long stateLgdCode,Long districtLgdCode,Long ulbLgdCode) {
        this.userId = userId;
        this.email = email;
        this.mobile = mobile;
        this.firstName = firstName;
        this.userType = userType;
        this.stateLgdCode = stateLgdCode;
        this.districtLgdCode = districtLgdCode;
        this.ulbLgdCode=ulbLgdCode;
    }
}
