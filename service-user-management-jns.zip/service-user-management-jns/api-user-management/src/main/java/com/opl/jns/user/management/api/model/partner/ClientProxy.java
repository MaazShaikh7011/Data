package com.opl.jns.user.management.api.model.partner;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientProxy {
		
	private Long userId;
	private String name;
	private String email;
	private String mobileNo;	
	private Long roleId;
	private String pan;
	private Long partnerId;
	private Long userType;
	private Long loggedInUserId;
	private Long schemeId;	

}
