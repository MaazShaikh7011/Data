package com.opl.jns.user.management.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * Created by pooja.patel on 19-03-2021.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserResponseProxy  implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String message;
    private Integer status;
    private Object data;
    private Boolean flag;
    private List<Long> branchList;
    private List<?> listData = Collections.emptyList();
    private Long lastAccessBusinessTypeId;

    public UserResponseProxy(String message, int status) {
        this.message = message;
        this.status = status;
    }
    public UserResponseProxy(Long id, String message, int status) {

        this.id = id;
        this.message = message;
        this.status = status;
    }
    public UserResponseProxy(Long id, String message, int status, Long lastAccessBusinessTypeId) {

        this.id = id;
        this.message = message;
        this.status = status;
        this.lastAccessBusinessTypeId=lastAccessBusinessTypeId;
    }
    public UserResponseProxy(Long userId, Object obj, String message, int status) {

        this.id = userId;
        this.message = message;
        this.status = status;
        this.data = obj;
    }

    public UserResponseProxy(Object obj, String message, int status) {

        this.message = message;
        this.status = status;
        this.data = obj;
    }
    public UserResponseProxy(Object obj, List<Long> listData, String message, int status) {

        this.message = message;
        this.status = status;
        this.data = obj;
        this.branchList=listData;
    }
    
	public UserResponseProxy(String message, Integer status, Boolean flag) {
		this(message, status);
		this.flag = flag;
	}
	
	public UserResponseProxy(String message, Object data, Integer status, Boolean flag) {
		this(data, message, status);
		this.flag = flag;
	}

}
