package com.opl.jns.user.management.api.model.partner;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FileUploadHistoryProxy {

	private Long id;

	private Long orgId;

	private Long fileType;

	private Long schemeId;
	
	private String fileName;

	private Integer succussEntry;

	private Integer failedEntry;

	private Integer totalEntry;

	private String message;

	private Long createdBy;

	private Date createdDate;

	private Long modifiedBy;

	private Date modifiedDate;

	private Boolean isActive;
}
