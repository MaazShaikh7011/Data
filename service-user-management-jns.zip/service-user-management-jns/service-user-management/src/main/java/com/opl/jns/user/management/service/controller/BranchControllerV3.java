package com.opl.jns.user.management.service.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.user.management.api.model.BranchROZODetailsProxy;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.service.BranchServiceV3;
import com.opl.jns.utils.common.OPLUtils;

/**
 * Created by dhaval.panchal on 23-08-2020.
 */
@RestController
@RequestMapping("/v3")
public class BranchControllerV3 {

    private static final Logger logger = LoggerFactory.getLogger(BranchControllerV3.class);

    @Autowired
    private BranchServiceV3 branchService;

    @PostMapping(value = "/getBOList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBoList(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getBranchList(branchRequest), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get bo list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getBranchName/{branchId}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchName(@PathVariable Long branchId, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getBranchName(branchId), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get bo list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getSingleBo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSingleBo(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getSingleBranch(branchRequest), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getROList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getROList(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getRoBranchList(branchRequest), "Successful get ro list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get ro list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getSingleRo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSingleRo(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getSingleRoBranch(branchRequest), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getZOList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZOList(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getZoBranchList(branchRequest), "Successful get ro list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get ro list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getSingleZo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSingleZo(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getSingleZoBranch(branchRequest), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/saveBranchDetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> saveBranchDetail(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in saveBranchDetail");
        try {        	
        	//return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("The creation of new branches is currently suspended. For any updates, please contact the JanSuraksha Support.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            return new ResponseEntity<UserResponseProxy>(branchService.saveBranchDetail(branchRequest), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/editBranchDetail", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> editBranchDetail(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in editBranchDetail");
        try {
        	//return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("The creation of new branches is currently suspended. For any updates, please contact the JanSuraksha Support.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            if(OPLUtils.isObjectNullOrEmpty(branchRequest.getBranchId())){
                return new ResponseEntity<>(new UserResponseProxy("BranchId should not be null or empty.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<UserResponseProxy>(branchService.editBranchDetail(branchRequest), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllHoList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllHoList(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllHoList");
        try {
            if(OPLUtils.isObjectNullOrEmpty(branchRequest) || OPLUtils.isObjectNullOrEmpty(branchRequest.getOrgId())){
                return new ResponseEntity<>(new UserResponseProxy( "Request data should not be null or empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(branchService.getAllHoList(branchRequest), "Successful getAllHoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllHoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping(value = "/getSingleHo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSingleHo(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) throws Exception {
        logger.info("Enter in getBoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getSingleHoBranch(branchRequest), "Successful get branch data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get branch detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getOrganizationList")
    public ResponseEntity<UserResponseProxy> getOrganizationList() throws Exception {
        logger.info("Enter in getOrganizationList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getOrganizationList(), "Successful get Organization data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get getOrganization detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/isActiveBranch", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> isActiveBranch(@RequestBody BranchRequestProxy request) {
        if (!OPLUtils.isObjectNullOrEmpty(request) && !OPLUtils.isObjectNullOrEmpty(request.getBranchId()) && !OPLUtils.isObjectNullOrEmpty(request.getSchemeId())) {
            try {
            	Boolean branchIsActive = branchService.isActiveBranch(request.getBranchId(), request.getSchemeId());
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(branchIsActive, "Branch isActive successfully Done!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No Organization found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/isActiveBranchAllScheme", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> isActiveBranchAllScheme(@RequestBody BranchRequestProxy request,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        if ( !OPLUtils.isObjectNullOrEmpty(authClientResponse) && !OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserId()) && !OPLUtils.isObjectNullOrEmpty(request) && !OPLUtils.isObjectNullOrEmpty(request.getBranchId())) {
            try {
                return new ResponseEntity<UserResponseProxy>(branchService.isActiveBranchAllScheme(request.getBranchId(), authClientResponse.getUserId()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No Organization found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    
    
    @GetMapping(value = "/getRoZoDetailsByRoZoId/{roZoId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getRoZoDetails(@PathVariable Long roZoId) {
        if (!OPLUtils.isObjectNullOrEmpty(roZoId)) {
            try {
            	List<BranchROZODetailsProxy> list = branchService.getRoZoDetailsByRoZoId(roZoId);
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(list, "getRoZoDetails successfully Done!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while getRoZoDetails or get user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No RoZoDetails found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getBranchIdList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchIdList(@RequestBody BranchRequestProxy branchRequestProxy) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(branchRequestProxy)
                    && OPLUtils.isObjectNullOrEmpty(branchRequestProxy.getBranchId())
                    && OPLUtils.isObjectNullOrEmpty(branchRequestProxy.getRoleId())
                    && OPLUtils.isObjectNullOrEmpty(branchRequestProxy.getUserOrgId())) {
                return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST.getReasonPhrase(), HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(branchService.getBranchIdList(branchRequestProxy), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while updating or saving user!!");
            return new ResponseEntity<>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/getBONameListByRoId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBONameListByRoId(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getBONameList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getBONameListByRoId(branchRequest,authClientResponse), "Successful get bo list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get bo list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getZONameListByZoId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZONameListByZoId(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getZONameList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getZONameListByZoId(branchRequest,authClientResponse), "Successful get zo list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get zo list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getRONameListByZoId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getRONameListByZoId(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getRONameList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getRONameListByZoId(branchRequest,authClientResponse), "Successful get ro list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get ro list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping(value = "/getAllBranch/{userOrgId}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllBranch(@PathVariable Long userOrgId, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getRONameList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getAllBranchByOrgId(userOrgId), "Successful get ro list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get ro list ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getBranchNameAndIdBySchemeAndOrgId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchNameAndIdBySchemeAndOrgId(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getBranchNameAndIdBySchemeAndOrgId");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getBranchNameAndIdBySchemeAndOrgId(branchRequest), "Successful get bo list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get getBranchNameAndIdBySchemeAndOrgId ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getZoListBySchemeAndOrgAndStateId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZoListBySchemeAndOrgAndStateId(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getBranchNameAndIdBySchemeAndOrgId");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getZoListBySchemeAndOrgAndStateId(branchRequest), "Successful get bo list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get getBranchNameAndIdBySchemeAndOrgId ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getBranchListByOrgAndSchemeIdAndType", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchListByOrgAndSchemeIdAndType(@RequestBody String branchRequest, HttpServletRequest httpServletRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) throws Exception {
        logger.info("Enter in getBranchNameAndIdBySchemeAndOrgId");
        try {
            return new ResponseEntity<>(new UserResponseProxy(branchService.getBranchListByOrgAndSchemeIdAndType(branchRequest), "Successful get bo list data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get getBranchNameAndIdBySchemeAndOrgId ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
