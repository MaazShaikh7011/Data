package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.common.EncryptionUtilsOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bulk_rozo_creation")
public class BulkROZOCreation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_rozo_creation_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "bulk_rozo_creation_mana_seq_gen", sequenceName = "bulk_rozo_creation_mana_seq", allocationSize = 1)
	private Long id;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "branch_id")
	private Long branchId;

	@Column(name = "branch_code", columnDefinition = "varchar(50) default ''")
	private String branchCode;

	@Column(name = "branch_ro_id")
	private Long branchROId;

	@Column(name = "ro_code", columnDefinition = "varchar(20) default ''")
	private String ROCode;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "ro_email", columnDefinition = "varchar(80) default ''")
	private String ROEmail;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "ro_mobile", columnDefinition = "varchar(50) default ''")
	private String ROMobile;

	@Column(name = "ro_name", columnDefinition = "varchar(200) default ''")
	private String ROName;

	@Column(name = "ro_address", columnDefinition = "varchar(500) default ''")
	private String ROAddress;

	@Column(name = "ro_pincode", columnDefinition = "varchar(20) default ''")
	private String ROPincode;

	@Column(name = "ro_city_id")
	private Integer ROCityId;

	@Column(name = "ro_state_id")
	private Integer ROStateId;

	@Column(name = "branch_zo_id")
	private Long branchZOId;

	@Column(name = "zo_code", columnDefinition = "varchar(20) default ''")
	private String ZOCode;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "zo_email", columnDefinition = "varchar(200) default ''")
	private String ZOEmail;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "zo_mobile", columnDefinition = "varchar(50) default ''")
	private String ZOMobile;

	@Column(name = "zo_name", columnDefinition = "varchar(200) default ''")
	private String ZOName;

	@Column(name = "zo_address", columnDefinition = "varchar(500) default ''")
	private String ZOAddress;

	@Column(name = "zo_pincode", columnDefinition = "varchar(20) default ''")
	private String ZOPincode;

	@Column(name = "zo_city_id")
	private Integer ZOCityId;

	@Column(name = "zo_state_id")
	private Integer ZOStateId;

	@Column(name = "business_type_id")
	private Integer businessTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "msg", columnDefinition = "varchar(500) default ''")
	private String message;

	@Column(name = "file_id")
	private Long fileId;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Column(name = "user_role_id")
	private Long userRoleId;

	@Column(name = "created_by_branch_id", columnDefinition = "varchar(50) default ''")
	private String createdByBranchId;

	@Column(name = "original_file_name", columnDefinition = "varchar(100) default ''")
	private String originalFileName;

}
