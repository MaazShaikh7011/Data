package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "branch_master",indexes = {
		@Index(columnList = "org_id,is_active,branch_type",name = DBNameConstant.JNS_USERS + "BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE"),
		@Index(columnList = "org_id,is_active,branch_type,city_id",name = DBNameConstant.JNS_USERS + "BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE_CITY_ID_STATE_ID"),
		@Index(columnList = "org_id,is_active,branch_type,state_id",name = DBNameConstant.JNS_USERS + "BRANCH_MST_ORG_ID_IS_ACTIVE_BRANCH_TYPE_STATE_ID")
})
public class BranchMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "branch_master_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "branch_master_seq_gen", sequenceName = "branch_master_seq", allocationSize = 1)
	private Long id;

	@Column(name = "city_id")
	private Integer cityId;

//	@Lob
	@Column(name = "code",columnDefinition="varchar(100) default ''")
	private String code;

	@Column(name = "contact_person_email",columnDefinition="varchar(100) default ''")
	private String contactPersonEmail;

	@Column(name = "contact_person_name",columnDefinition="varchar(100) default ''")
	private String contactPersonName;

	@Column(name = "contact_person_number",columnDefinition="varchar(15) default ''")
	private String contactPersonNumber;

	@Column(name = "country_id")
	private Integer countryId;

	@Column(name = "created_by")
	private Integer createdBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdOn;

	@Column(name = "fax_no",columnDefinition="varchar(20) default ''")
	private String faxNo;

	@Column(name = "is_active" , nullable = false)
	private Boolean isActive;

	@Column(name = "is_ho")
	private Boolean isHo;

	@Column(name = "land_mark",columnDefinition="varchar(500) default ''")
	private String landMark;

//	@Lob
	@Column(name = "name",columnDefinition="varchar(255) default ''")
	private String name;

	@ManyToOne
	@JoinColumn(name = "org_id")
	private UserOrganisationMaster orgId;

	@Column(name = "parent_branch_id")
	private Integer parentBranchId;

	private Integer pincode;

//	@Lob
	@Column(name = "premises_no",columnDefinition="varchar(500) default ''")
	private String premisesNo;
	
//	@Lob
	@Column(name = "remarks",columnDefinition="varchar(500) default ''")
	private String remarks;

	@Column(name = "state_id")
	private Integer stateId;

//	@Lob
	@Column(name = "street_name",columnDefinition="varchar(500) default ''")
	private String streetName;

	@Column(name = "telephone_no",columnDefinition="varchar(20) default ''")
	private String telephoneNo;

	@Column(name = "ifsc_code",columnDefinition="varchar(20) default ''")
	private String ifscCode;

	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "job_id")
	private Long jobId;

	@Column(name = "is_deleted" , nullable = false)
	private Boolean isDeleted;

	@Column(name = "loan_system_id")
	private Long loanSystemId;

	@Column(name = "smec_code",columnDefinition="varchar(10) default ''")
	private String smecCode;

	@Column(name = "smec_name",columnDefinition="varchar(100) default ''")
	private String smecName;

	@Column(name = "smec_email",columnDefinition="varchar(100) default ''")
	private String smecEmail;

	@Column(name = "smec_mobile",columnDefinition="varchar(11) default ''")
	private String smecMobile;

	@Column(name = "branch_type")
	private Integer branchType;

	@Column(name = "branch_ip",columnDefinition="varchar(100) default ''")
	private String branchIp;
	
	@Column(name = "region_id")
	private Integer regionId;
	
	@Column(name = "branch_ro_id")
	private Long branchRoId;
	
	@Column(name = "branch_zo_id")
	private Long branchZoId;
	
	@Column(name = "branch_ho_id")
	private Long branchHoId;
	
	@Column(name = "lho_code",columnDefinition="varchar(10) default ''")
	private String lhoCode;

	@Column(name = "lho_name",columnDefinition="varchar(100) default ''")
	private String lhoName;

	@Column(name = "lho_email",columnDefinition="varchar(100) default ''")
	private String lhoEmail;

	@Column(name = "lho_mobile",columnDefinition="varchar(11) default ''")
	private String lhoMobile;
	
	private Boolean pl;
	private Boolean msme;
	
	@Column(name = "location_id")
	private Long locationId;

	@Column(name = "rural_urban_id")
	private Integer ruralUrbanId;

	public BranchMaster(Long id) {
		this.id = id;
	}

	public BranchMaster(Long id, String code, Integer branchType) {
		this.id = id;
		this.code = code;
		this.branchType = branchType;
	}

}
