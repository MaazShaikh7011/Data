package com.opl.jns.user.management.service.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

//import com.opl.jns.config.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="menu_role_mapping")
public class AdminMenuPermissionMapping {
	
    
    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "menu_role_mapping_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "menu_role_mapping_seq_gen", sequenceName = "menu_role_mapping_seq", allocationSize = 1)
    private Long id;
    
    @Column(name="menu_id")
    private Long menuId;
    
    @Column(name="type_id")
    private Long typeId;
    
    @Column(name="role_id")
    private Long roleId;
    
    @Column(name="is_active")
    private Boolean isActive;
    
    @Column(name="scheme_id")
    private Integer schemeId;
    

}
