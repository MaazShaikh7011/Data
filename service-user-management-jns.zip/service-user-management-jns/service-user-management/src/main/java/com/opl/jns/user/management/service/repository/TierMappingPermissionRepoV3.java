package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.TierMappingPermission;

import java.util.List;

public interface TierMappingPermissionRepoV3 extends JpaRepository<TierMappingPermission, Long> {

    @Query(value = "SELECT t FROM TierMappingPermission t WHERE t.orgId =:orgId AND t.isActive=true")
    public List<TierMappingPermission> getBranchTypeIdsByOrgId(@Param("orgId") Long orgId);

    @Query(value = "SELECT t.branchType FROM TierMappingPermission t WHERE t.orgId =:orgId")
    public List<Long> getBranchTypeIds(@Param("orgId") Long orgId);

    @Query(value = "SELECT t FROM TierMappingPermission t WHERE t.orgId =:orgId AND t.branchType =:branchType")
    public TierMappingPermission getBranchTypeData(@Param("orgId") Long orgId,@Param("branchType") Long branchType);

    @Modifying
    @Query(value = "DELETE FROM TierMappingPermission WHERE orgId =:orgId") // if want to write nativequery then mask nativeQuery  as true
    void deleteByOrgId(@Param("orgId") Long orgId);

}
