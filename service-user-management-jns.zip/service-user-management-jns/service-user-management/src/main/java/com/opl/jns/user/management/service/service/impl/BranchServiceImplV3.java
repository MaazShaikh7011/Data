package com.opl.jns.user.management.service.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.model.BranchROZODetailsProxy;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.domain.BranchMaster;
import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.user.management.service.domain.User;
import com.opl.jns.user.management.service.domain.UserOrganisationMaster;
import com.opl.jns.user.management.service.repository.BranchMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchRepositoryV3;
import com.opl.jns.user.management.service.repository.UserManagementRepositoryV3;
import com.opl.jns.user.management.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UsersRepositoryV3;
import com.opl.jns.user.management.service.service.BranchServiceV3;
import com.opl.jns.user.management.service.utils.CommonUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.ObjectConvertMaster;
import com.opl.jns.utils.enums.UserRoleMaster;

@Service
@Transactional
public class BranchServiceImplV3 implements BranchServiceV3 {
    private static final Logger logger = LoggerFactory.getLogger(BranchServiceImplV3.class);
    @Autowired
    private BranchRepositoryV3 branchRepository;

    @Autowired
    private BranchMasterRepositoryV3 branchMasterRepository;
    
    @Autowired	
    private UserManagementRepositoryV3 userManagementRepository;

    @Autowired
    private BranchProductMappingRepositoryV3 branchProductMappingRepository;

    @Autowired
    private UserOrganisationMasterRepositoryV3 userOrganisationMasterRepository;
    
    @Autowired
    private UsersRepositoryV3 usersRepository;

    @Override
    public String getBranchList(BranchRequestProxy branchRequest) {
        return branchRepository.getBranchList(branchRequest);
    }

    @Override
    public String getSingleBranch(BranchRequestProxy branchRequest) {
        return branchRepository.getSingleBranch(branchRequest);
    }

    @Override
    public String getRoBranchList(BranchRequestProxy branchRequest) {
        return branchRepository.getRoBranchList(branchRequest);
    }

    @Override
    public String getSingleRoBranch(BranchRequestProxy branchRequest) {
        return branchRepository.getSingleRoBranch(branchRequest);
    }

    @Override
    public String getZoBranchList(BranchRequestProxy branchRequest) {
        return branchRepository.getZoBranchList(branchRequest);
    }

    @Override
    public String getSingleZoBranch(BranchRequestProxy branchRequest) {
        return branchRepository.getSingleZoBranch(branchRequest);
    }

    @Override
    public UserResponseProxy saveBranchDetail(BranchRequestProxy branchRequest) {

        int count = branchMasterRepository.checkBranchExists(branchRequest.getCode(), Long.valueOf(branchRequest.getOrgId()));
        if (count > 0){
            return new UserResponseProxy(false,"Office code is already exist", HttpStatus.OK.value());
        }
        if(!OPLUtils.isObjectNullOrEmpty(branchRequest)) {
            //save branch master
            BranchMaster branchMaster = new BranchMaster();
            BeanUtils.copyProperties(branchRequest, branchMaster);
            branchMaster.setOrgId(new UserOrganisationMaster(branchRequest.getOrgId().longValue()));
            branchMaster.setCountryId(101);
            branchMaster.setIsActive(true);
            branchMaster.setCreatedOn(new Date());
            branchMaster.setModifiedDate(new Date());
            branchMasterRepository.save(branchMaster);

            //save branch product mapping
            if (!OPLUtils.isListNullOrEmpty(branchRequest.getBranchProductList())) {
                for (Map<String, Object> map : branchRequest.getBranchProductList()) {
                    Long branchRoId = ObjectConvertMaster.toLong(map.get("branchRoId"));
                    Long orgid = ObjectConvertMaster.toLong(map.get("orgId"));
                    Long schemeId = ObjectConvertMaster.toLong(map.get("schemeId"));
                    BranchProductMapping branchProductMapping = new BranchProductMapping();
                    branchProductMapping.setBranchId(branchMaster.getId());
                    branchProductMapping.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
                    branchProductMapping.setUserOrgId(ObjectConvertMaster.toLong(map.get("orgId")));

                    //New Ro Add
                    if(!OPLUtils.isObjectNullOrEmpty(branchRoId)){
                        branchProductMapping.setBranchRoId(branchRoId);
                        Map<String, Long> branchZoLHoId = branchProductMappingRepository.getLHoIdAndLHoList(branchRoId, schemeId, orgid);
                        if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchZoId"))) {
                            branchProductMapping.setBranchZoId(branchZoLHoId.get("branchZoId"));
                        }
                        if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchLHoId"))) {
                            branchProductMapping.setBranchLHoId(branchZoLHoId.get("branchLHoId"));
                        }
                    }

                    //New Zo Add
                    Long branchZoId = ObjectConvertMaster.toLong(map.get("branchZoId"));
                    if(OPLUtils.isObjectNullOrEmpty(branchProductMapping.getBranchZoId()) && !OPLUtils.isObjectNullOrEmpty(branchZoId)){
                        branchProductMapping.setBranchZoId(branchZoId);
                        Long branchLHoId = branchProductMappingRepository.getLHoId(branchZoId, schemeId, orgid);
                        if(!OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                            branchProductMapping.setBranchLHoId(branchLHoId);
                        }
                    }

                    //New LHo Add
                    Long branchLHoId = ObjectConvertMaster.toLong(map.get("branchLHoId"));
                    if(OPLUtils.isObjectNullOrEmpty(branchProductMapping.getBranchLHoId()) && !OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                        branchProductMapping.setBranchLHoId(branchLHoId);
                    }

                    branchProductMapping.setSchemeId(ObjectConvertMaster.toLong(map.get("schemeId")));
                    branchProductMapping.setIsActive(true);
                    branchProductMapping.setCreatedDate(new Date());
                    branchProductMapping.setModifiedDate(new Date());
                    branchProductMappingRepository.save(branchProductMapping);
                }
            }
            return new UserResponseProxy(branchRequest,"Saved successfully!", HttpStatus.OK.value());
        }

        else{
            return new UserResponseProxy(branchRequest,"Something went wrong!", HttpStatus.OK.value());
        }
    }

    @Override
    public String getAllHoList(BranchRequestProxy branchRequest) {
        return branchProductMappingRepository.getBranchHOName(Long.valueOf(branchRequest.getOrgId()));
    }

    @Override
    public UserResponseProxy editBranchDetail(BranchRequestProxy branchRequest) {
        try {
            BranchMaster branchMaster = branchMasterRepository.findById(branchRequest.getBranchId()).orElse(null);
            
            int count = branchMasterRepository.checkBranchExistsForEditOffice(branchRequest.getCode(), Long.valueOf(branchRequest.getOrgId()),branchMaster.getId());
            if (count > 0){
                return new UserResponseProxy(false,"Office code is already exist", HttpStatus.OK.value());
            }
            
            if (OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                return new UserResponseProxy("No data found at requested branchId!", HttpStatus.BAD_REQUEST.value());
            }
            branchMaster.setRuralUrbanId(branchRequest.getRuralUrbanId());
            branchMaster.setName(branchRequest.getName());
            branchMaster.setCode(branchRequest.getCode());
            branchMaster.setIfscCode(branchRequest.getIfscCode());
            branchMaster.setCountryId(101);
            branchMaster.setStateId(branchRequest.getStateId());
            branchMaster.setCityId(branchRequest.getCityId());
            branchMaster.setPincode(branchRequest.getPincode());
            branchMaster.setStreetName(branchRequest.getStreetName());
            branchMaster.setContactPersonName(branchRequest.getContactPersonName());
            branchMaster.setContactPersonEmail(branchRequest.getContactPersonEmail());
            branchMaster.setContactPersonNumber(branchRequest.getContactPersonNumber());
            branchMaster.setModifiedDate(new Date());
            branchMaster.setIsActive(true);
            branchMaster.setRegionId(branchRequest.getRegionId());
            branchMasterRepository.save(branchMaster);

            if (OPLUtils.isListNullOrEmpty(branchRequest.getBranchProductList())) {
                return new UserResponseProxy(null, "Atleast one Scheme must be selected!", HttpStatus.BAD_REQUEST.value());
            }

			if (Boolean.TRUE.equals(branchRequest.getIsAdminPanel())) {
				branchProductMappingRepository.deleteByBranchId(branchRequest.getBranchId());
			} else {
				branchProductMappingRepository.deleteByBranchIdAndSchemeId(branchRequest.getBranchId(), branchRequest.getSelectedScheme());
			}
            
            BranchProductMapping branchProductMapping1 = null;
            Long branchHoId = branchProductMappingRepository.getBranchHOId(Long.valueOf(branchRequest.getOrgId()));
            List<BranchProductMapping> branchProductMappingList = new ArrayList<>(branchRequest.getBranchProductList().size());
            for (Map<String, Object> map : branchRequest.getBranchProductList()) {
                branchProductMapping1 = new BranchProductMapping();
                branchProductMapping1.setBranchId(branchRequest.getBranchId());

                Long branchRoId = ObjectConvertMaster.toLong(map.get("branchRoId"));
                Long orgid = ObjectConvertMaster.toLong(map.get("orgId"));
                Long schemeId = ObjectConvertMaster.toLong(map.get("schemeId"));
                Long branchZoId = ObjectConvertMaster.toLong(map.get("branchZoId"));

                //New Ro Add
                if(!OPLUtils.isObjectNullOrEmpty(branchRoId)){
                    branchProductMapping1.setBranchRoId(branchRoId);
                    Map<String, Long> branchZoLHoId = branchProductMappingRepository.getLHoIdAndLHoList(branchRoId, schemeId, orgid);
                    if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchZoId"))) {
                        branchProductMapping1.setBranchZoId(branchZoLHoId.get("branchZoId"));
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchLHoId"))) {
                        branchProductMapping1.setBranchLHoId(branchZoLHoId.get("branchLHoId"));
                    }
                }

                //New Zo Add
                if(OPLUtils.isObjectNullOrEmpty(branchProductMapping1.getBranchZoId()) && !OPLUtils.isObjectNullOrEmpty(branchZoId)){
                    branchProductMapping1.setBranchZoId(branchZoId);
                    Long branchLHoId = branchProductMappingRepository.getLHoId(branchZoId, schemeId, orgid);
                    if(!OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                        branchProductMapping1.setBranchLHoId(branchLHoId);
                    }
                }

                //New LHo Add
                Long branchLHoId = ObjectConvertMaster.toLong(map.get("branchLHoId"));
                if(OPLUtils.isObjectNullOrEmpty(branchProductMapping1.getBranchLHoId()) && !OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                    branchProductMapping1.setBranchLHoId(branchLHoId);
                }

                branchProductMapping1.setSchemeId(schemeId);
                branchProductMapping1.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
                branchProductMapping1.setUserOrgId(orgid);
                branchProductMapping1.setCreatedDate(new Date());
                branchProductMapping1.setIsActive(true);
                branchProductMapping1.setModifiedDate(new Date());
                branchProductMappingList.add(branchProductMapping1);
            }
            branchProductMappingRepository.saveAll(branchProductMappingList);
            return new UserResponseProxy(branchRequest, "Saved successfully!", HttpStatus.OK.value());
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return new UserResponseProxy(branchRequest, "Saved successfully!", HttpStatus.OK.value());
    }

    @Override
    public String getSingleHoBranch(BranchRequestProxy branchRequest) {
        return branchRepository.getSingleHoBranch(branchRequest);
    }

    @Override
    public List<UserOrganisationMasterProxy> getOrganizationList() {
        try{
            return userOrganisationMasterRepository.findAllOrganization();
        }catch (Exception e){
//            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Boolean isActiveBranch(Long branchId, Long schemeId) {
        try {
            Optional<BranchProductMapping> branchProductMapping = branchProductMappingRepository.findByBranchIdAndSchemeId(branchId, schemeId);
            if (branchProductMapping.isPresent()) {
                if (branchProductMapping.get().getIsActive()) {
                    branchProductMapping.get().setIsActive(false);
                } else {
                    branchProductMapping.get().setIsActive(true);
                }
            }
            return Boolean.TRUE;
        } catch (Exception e) {
            logger.error("exception is getting while get isActive Branch", e);
        }
        return Boolean.FALSE;
    }
    
    @Override
    public UserResponseProxy isActiveBranchAllScheme(Long branchId, Long userId) {
        try {
        	Optional<BranchMaster> branchMaster = branchMasterRepository.findById(branchId);
            if (branchMaster.isPresent()) {
                if (branchMaster.get().getIsActive()) {
                	branchMaster.get().setIsActive(false);
                	branchMaster.get().setModifiedBy(userId);
                	branchMaster.get().setModifiedDate(new Date());
                	branchProductMappingRepository.updateByBranchId(branchId, Boolean.FALSE);
                    return new UserResponseProxy("Branch In-Active!!", HttpStatus.OK.value());
                } else {
                	branchMaster.get().setIsActive(true);
                	branchMaster.get().setModifiedBy(userId);
                	branchMaster.get().setModifiedDate(new Date());
                	branchProductMappingRepository.updateByBranchId(branchId, Boolean.TRUE);
                    return new UserResponseProxy("Branch Active !!", HttpStatus.OK.value());
                }
            }
        } catch (Exception e) {
            logger.error("exception is getting while get isActive Branch", e);
        }
        return new UserResponseProxy("exception is getting while get isActive Branch", HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

	@Override
	public List<BranchROZODetailsProxy> getRoZoDetailsByRoZoId(Long roZoId) {
		try {
			List<User> userList = usersRepository.findByBranchId(roZoId);
			if(!OPLUtils.isListNullOrEmpty(userList)) {
				List<BranchROZODetailsProxy> branchROZODetailsList = new ArrayList<BranchROZODetailsProxy>();
				BranchROZODetailsProxy branchROZOObj = null;
				for(User tempUser : userList) {
					branchROZOObj = new BranchROZODetailsProxy();
					branchROZOObj.setRoZoEmail(tempUser.getEmail());
					branchROZOObj.setRoZoMobile(tempUser.getMobile());
					branchROZOObj.setRoZoName(tempUser.getBranchId().getName());
					branchROZOObj.setRoZoCode(tempUser.getBranchId().getCode());
					branchROZOObj.setRoleName(tempUser.getUserRoleId().getDisplayName());
					branchROZODetailsList.add(branchROZOObj);
				}
				return branchROZODetailsList;
			}
			return Collections.emptyList();
		} catch (Exception e) {
			logger.error("exception is getting while get getRoZoDetails Branch", e);
			return null;
		}
	}

    @Override
    public UserResponseProxy getBranchIdList(BranchRequestProxy branchRequestProxy) {
        try {
            List<Long> branchIdList = null;
            if (!OPLUtils.isObjectNullOrEmpty(branchRequestProxy.getSchemeId())) {
                if (UserRoleMaster.RO.getId() == branchRequestProxy.getRoleId()) {
                    branchIdList = branchProductMappingRepository.getBranchIdsByRoBranchId(branchRequestProxy.getBranchId(), branchRequestProxy.getUserOrgId(), branchRequestProxy.getSchemeId());
                } else if (UserRoleMaster.ZO.getId() == branchRequestProxy.getRoleId()) {
                    branchIdList = branchProductMappingRepository.getBranchIdsByZoBranchId(branchRequestProxy.getBranchId(), branchRequestProxy.getUserOrgId(), branchRequestProxy.getSchemeId());
                } else if (UserRoleMaster.LOCAL_HEAD_OFFICE.getId() == branchRequestProxy.getRoleId()) {
                    branchIdList = branchProductMappingRepository.getBranchIdsByLhoBranchId(branchRequestProxy.getBranchId(), branchRequestProxy.getUserOrgId(), branchRequestProxy.getSchemeId());
                }
            } else {
                branchIdList = branchProductMappingRepository.getBranchIdsByBranchId(branchRequestProxy.getBranchId(), branchRequestProxy.getUserOrgId());
            }
            if (!OPLUtils.isListNullOrEmpty(branchIdList)) {
                return new UserResponseProxy(branchIdList, "successfully get branch id list", HttpStatus.OK.value());
            } else {
                return new UserResponseProxy("branch List Not Found", HttpStatus.NO_CONTENT.value());
            }

        } catch (Exception e) {
            logger.error("exception is getting while get getRoZoDetails Branch", e);
            return new UserResponseProxy(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
    }

    @Override
    public String getBranchName(Long branchId) {
        BranchMaster branch = branchMasterRepository.getOne(branchId);
        return null != branch ? branch.getName() : null;
    }

    @Override
	public List<Map<String, Object>> getBONameListByRoId(BranchRequestProxy branchRequest,AuthClientResponse authClientResponse) {
		try {			
			if(!OPLUtils.isListNullOrEmpty(branchRequest.getStateIdLst())) {
				return branchMasterRepository.getBoNameByStateId(authClientResponse.getUserOrgId(),branchRequest.getSchemeId(),branchRequest.getBranchRoIdLst(),branchRequest.getStateIdLst());
			}else {				
				return branchMasterRepository.getBoName(authClientResponse.getUserOrgId(),branchRequest.getSchemeId(),branchRequest.getBranchRoIdLst());
			}
		}catch (Exception e) {
			logger.error("exception is getting while get bo name list", e);
		}
		return null;
		}

	@Override
	public List<Map<String, Object>> getZONameListByZoId(BranchRequestProxy branchRequest,AuthClientResponse authClientResponse) {
		try {			

			List<Map<String, Object>> zoList = null;
			if(!OPLUtils.isObjectNullOrEmpty(branchRequest.getBranchZoId())) {				
				String zoListstr = userManagementRepository.getZoNameByZoId(authClientResponse.getUserOrgId(),branchRequest.getSchemeId(),branchRequest.getBranchZoIdLst());
				if(OPLUtils.isObjectNullOrEmpty(zoListstr)) {
					return null;
				}else {
					zoList = MultipleJSONObjectHelper.getListOfObjects(zoListstr, null, Map.class);
				}			}else {
				String zoListstr = userManagementRepository.getZoName(authClientResponse.getUserOrgId(),branchRequest.getSchemeId());
				if(OPLUtils.isObjectNullOrEmpty(zoListstr)) {
					return null;
				}else {
					zoList = MultipleJSONObjectHelper.getListOfObjects(zoListstr, null, Map.class);
				}
			}
			return zoList;
		}catch (Exception e) {
			logger.error("exception is getting while get zo name list", e);
		}
		return null;
		}

	@Override
	public List<Map<String, Object>> getRONameListByZoId(BranchRequestProxy branchRequest,
			AuthClientResponse authClientResponse) {
		try {			
			if(!OPLUtils.isListNullOrEmpty(branchRequest.getStateIdLst())) {
				return branchMasterRepository.getRoNameByStateId(authClientResponse.getUserOrgId(),branchRequest.getSchemeId(),branchRequest.getBranchZoIdLst(),branchRequest.getStateIdLst());
			}else {				
				return branchMasterRepository.getRoName(authClientResponse.getUserOrgId(),branchRequest.getSchemeId(),branchRequest.getBranchZoIdLst());
			}
		}catch (Exception e) {
			logger.error("exception is getting while get ro name list", e);
		}
		return null;
	}

    public List<BranchRequestProxy> getAllBranchByOrgId(Long orgId){
        List<BranchMaster> allBranchAndCode = branchMasterRepository.getAllByOrgIdUserOrgId(orgId);
        List<BranchRequestProxy> branchRequestProxiesList=new ArrayList<>(allBranchAndCode.size());
        for (BranchMaster branches : allBranchAndCode) {
            BranchRequestProxy br=new BranchRequestProxy();
            br.setCode(branches.getCode());
            br.setBranchId(branches.getId());
            br.setIfscCode(branches.getIfscCode());
            br.setBranchHoId(branches.getBranchHoId());
            br.setBranchRoId(branches.getBranchRoId());
            br.setBranchZoId(branches.getBranchZoId());
            br.setStateId(branches.getStateId());
            branchRequestProxiesList.add(br);
        }
        return branchRequestProxiesList;
    }
    
	@Override
	public List<Map<String, Object>> getBranchNameAndIdBySchemeAndOrgId(BranchRequestProxy branchRequest) {
		try {			
			if(Objects.equals(branchRequest.getBranchType(), CommonUtils.ZO)) {				
				return branchProductMappingRepository.getZoList(branchRequest.getUserOrgId(),branchRequest.getSchemeId());
			}else if(Objects.equals(branchRequest.getBranchType(), CommonUtils.RO)) {
				return branchProductMappingRepository.getRoList(branchRequest.getUserOrgId(),branchRequest.getSchemeId());
			}else if(Objects.equals(branchRequest.getBranchType(), CommonUtils.BO)) {
				return branchProductMappingRepository.getBoList(branchRequest.getUserOrgId(),branchRequest.getSchemeId());
			}
		}catch (Exception e) {
			logger.error("exception is getting while get getBranchNameAndIdBySchemeAndOrgId", e);
		}
		return null;
	}

	@Override
	public List<Map<String, Object>> getZoListBySchemeAndOrgAndStateId(BranchRequestProxy branchRequestProxy) {
		try {			
			if(!OPLUtils.isObjectNullOrEmpty(branchRequestProxy.getBranchId())) {
				return branchProductMappingRepository.getZoListByStateIdAndBranchId(branchRequestProxy.getUserOrgId(),branchRequestProxy.getStateIdLst(),branchRequestProxy.getSchemeId(),branchRequestProxy.getBranchId());
			}else {				
				return branchProductMappingRepository.getZoListByStateId(branchRequestProxy.getUserOrgId(),branchRequestProxy.getStateIdLst(),branchRequestProxy.getSchemeId());
			}
		}catch (Exception e) {
			logger.error("exception is getting while get getZoListBySchemeAndOrgAndStateId", e);
		}
		return null;
	}

    @Override
    public String getBranchListByOrgAndSchemeIdAndType(String branchRequest) {
        try {
            return userManagementRepository.getBranchListBySearch(branchRequest);
        }catch (Exception e) {
            logger.error("exception is getting while get getBranchNameAndIdBySchemeAndOrgId", e);
        }
        return null;
    }
}
