package com.opl.jns.user.management.service.service;
//package com.opl.jns.common.service.user.management.service;
//
//import java.util.Random;
//
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.web.client.HttpServerErrorException;
//import org.springframework.web.client.RestTemplate;
//
//import com.opl.jns.common.logs.api.models.RequestLogReq;
//import com.opl.jns.common.service.user.management.domain.TestDES;
//import com.opl.jns.common.service.user.management.domain.TestNormal;
//import com.opl.jns.utils.common.CommonResponse;
//
//public class dataInsertion1 {
//
//
//	private static final String url ="https://qa-jns.instantmseloans.in/user-management/v3/user/addTestUser";
//	private static final String url1="https://qa-jns.instantmseloans.in/user-management/v3/user/addTestUserNormal";
//	private static final TestDES req = new TestDES();
//	private static final TestNormal req1 = new TestNormal();
//
//
//    private static final Random rnd = new Random();
//    static RestTemplate restTemplate = new RestTemplate();
//
//    @Async
//	static
//    void bulkInsertEnrollment(TestDES req) {
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.add("req_auth","true");
//            HttpEntity<RequestLogReq> entity = new HttpEntity(req, headers);
//            restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class, new Object[0]).getBody();
//        } catch (HttpServerErrorException var5) {
//            System.out.println("Error in HttpServerErrorException Call :: {}"+ var5.getMessage());
//        } catch (Exception var6) {
//            System.out.println("Error in Call :: {}"+ var6.getMessage());
//        }
//
//    }
//
//    @Async
//	static
//    void bulkInsertEnrollmentNormal(TestNormal req) {
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.add("req_auth","true");
//            HttpEntity<RequestLogReq> entity = new HttpEntity(req, headers);
//            restTemplate.exchange(url1, HttpMethod.POST, entity, CommonResponse.class, new Object[0]).getBody();
//        } catch (HttpServerErrorException var5) {
//            System.out.println("Error in HttpServerErrorException Call :: {}"+ var5.getMessage());
//        } catch (Exception var6) {
//            System.out.println("Error in Call :: {}"+ var6.getMessage());
//        }
//
//    }
//
//    public static void main(String[] args) {
//       req.setEmail("test@mail.com");
//       req.setPersonName("test");
//       req.setPersonNumber("9889667845");
//
//       req1.setEmail("test@mail.com");
//       req1.setPersonName("test");
//       req1.setPersonNumber("9889667845");
//
//        int limit =1000000;
//        for (double i = 0; i < limit; i++) {
//            System.out.println("inserting count : "+i);
//            bulkInsertEnrollmentNormal(req1);
//            bulkInsertEnrollment(req);
//
//        }
//    }
//
//}
