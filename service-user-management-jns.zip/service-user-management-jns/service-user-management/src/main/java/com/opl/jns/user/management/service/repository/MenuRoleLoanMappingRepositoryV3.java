package com.opl.jns.user.management.service.repository;

import com.opl.jns.user.management.api.model.MenuRoleLoanMappingProxy;
import com.opl.jns.user.management.service.domain.MenuRoleLoanMapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MenuRoleLoanMappingRepositoryV3 extends JpaRepository<MenuRoleLoanMapping, Long> {

    @Query(value = "SELECT new com.opl.jns.user.management.api.model.MenuRoleLoanMappingProxy(mrm.menuId, mrm.navigationPath) FROM MenuRoleLoanMapping mrm WHERE mrm.roleId=:roleId AND mrm.isActive= TRUE AND mrm.businessTypeId=:businessTypeId AND mrm.schemeId=:schemeId ")
    List<MenuRoleLoanMappingProxy> findMenuIdByRoleIdAndBusinessTypeIdAndSchemeId(@Param("roleId") Long roleId, @Param("businessTypeId") Long businessTypeId, @Param("schemeId") Integer schemeId);

    @Query(value = "SELECT new com.opl.jns.user.management.api.model.MenuRoleLoanMappingProxy(mrm.menuId) FROM MenuRoleLoanMapping mrm WHERE mrm.roleId=:roleId AND mrm.isActive= TRUE")
    List<MenuRoleLoanMappingProxy> findMenuIdByRoleId(@Param("roleId") Long roleId);

    @Modifying
    @Query("DELETE FROM MenuRoleLoanMapping mrm WHERE mrm.roleId=:roleId  AND mrm.isActive= TRUE AND mrm.businessTypeId=:businessTypeId AND mrm.schemeId=:schemeId")
    void deleteByRoleIdAndBusinessTypeIdAndSchemeId(@Param("roleId") Long roleId, @Param("businessTypeId") Long businessTypeId, @Param("schemeId") Integer schemeId);

    @Modifying
    @Query("DELETE FROM MenuRoleLoanMapping mrm WHERE mrm.roleId=:roleId AND mrm.isActive= TRUE")
    void deleteByRoleId(@Param("roleId") Long roleId);
}
