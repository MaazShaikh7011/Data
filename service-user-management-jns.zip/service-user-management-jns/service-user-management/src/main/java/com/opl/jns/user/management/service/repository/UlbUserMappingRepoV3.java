package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.service.domain.UlbUserMapping;

@Repository
public interface UlbUserMappingRepoV3 extends JpaRepository <UlbUserMapping,Long>{

    @Query(value="SELECT u FROM UlbUserMapping u WHERE u.ulbCode=:ulbCode AND u.isActive = TRUE")
    public UlbUserMapping taggedUlb(@Param("ulbCode") Long ulbCode);

    @Query("SELECT u.ulbCode FROM UlbUserMapping u WHERE u.userId=:userId AND u.isActive=TRUE")
    public Long getUlbCode(@Param("userId") Long userId);
    
    @Query("SELECT u FROM UlbUserMapping u WHERE u.userId=:userId AND u.isActive = TRUE")
    public UlbUserMapping findByUserId(@Param("userId") Long userId);

    @Modifying
    @Query("DELETE FROM UlbUserMapping u WHERE u.userId=:userId")
    public int deleteTaggedUlb(@Param("userId") Long userId);
}
