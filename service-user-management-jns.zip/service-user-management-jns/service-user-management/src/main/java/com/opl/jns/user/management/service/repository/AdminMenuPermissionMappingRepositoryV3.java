package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.AdminMenuPermissionMapping;


public interface AdminMenuPermissionMappingRepositoryV3 extends JpaRepository<AdminMenuPermissionMapping, Long> {

    @Modifying
    @Query("DELETE FROM AdminMenuPermissionMapping amp WHERE amp.roleId=:roleId AND amp.isActive= TRUE")
    void deleteMenuIdByRoleId(@Param("roleId") Long roleId);

    @Query("SELECT amp FROM AdminMenuPermissionMapping amp WHERE amp.roleId=:roleId AND amp.isActive= TRUE")
	List<AdminMenuPermissionMapping> findByRoleId(Long roleId);
	
}
