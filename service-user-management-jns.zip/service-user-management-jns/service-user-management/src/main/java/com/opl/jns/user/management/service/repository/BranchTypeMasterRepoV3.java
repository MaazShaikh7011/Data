package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.user.management.service.domain.BranchTypeMaster;

public interface BranchTypeMasterRepoV3 extends JpaRepository<BranchTypeMaster, Long> {

    List<BranchTypeMaster> findByIsDisplay(boolean isDisplay);

}
