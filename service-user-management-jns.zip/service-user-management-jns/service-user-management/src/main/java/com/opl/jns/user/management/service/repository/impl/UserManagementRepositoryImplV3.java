package com.opl.jns.user.management.service.repository.impl;

import java.math.BigInteger;
import java.sql.Clob;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Parameter;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

//import org.hibernate.query.procedure.internal.ProcedureParameterImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.api.model.AdminRequest;
import com.opl.jns.user.management.service.repository.UserManagementRepositoryV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;



/**
 * Created by pooja.patel on 16-08-2020.
 */
@Repository
public class UserManagementRepositoryImplV3 implements UserManagementRepositoryV3 {

    private static final Logger logger = LoggerFactory.getLogger(UserManagementRepositoryImplV3.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private Environment environment;

    private static final String CW_USER_DEFAULT_PASSWORD = "cw.user.default.password";

//    public List<Object[]> getUserList(Long userId, Integer businessTypeId) {
//        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("users.spUserManagementFetchBankAdminUserList");
//        storedProcedureQuery.registerStoredProcedureParameter("userId",Long.class, ParameterMode.IN);
//        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
//        storedProcedureQuery.setParameter("userId",userId);
//        storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
//        return (List<Object[]>) storedProcedureQuery.getResultList();
//    }
    @Override
    public String spUserManagementBankBranchList(Long orgId,Long businessTypeId,int branchtype,String noPagination,Integer paginationFROM,Integer paginationTO,Long schemeId,String columnFilter) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".fetch_BANK_BRANCH_LIST");
		storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("branchtype",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("noPagination",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationFROM",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationTO",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("schemeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("columnFilter",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);

//		setStoreProcedureEnableNullParameters(storedProcedureQuery);

		storedProcedureQuery.setParameter("orgId", orgId);
		storedProcedureQuery.setParameter("branchtype", branchtype);
		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
		storedProcedureQuery.setParameter("noPagination", noPagination);
		storedProcedureQuery.setParameter("paginationFROM", paginationFROM);
		storedProcedureQuery.setParameter("paginationTO", paginationTO);
		storedProcedureQuery.setParameter("schemeId", schemeId);
		storedProcedureQuery.setParameter("columnFilter", columnFilter);
		storedProcedureQuery.execute();
//		Object object1 = storedProcedureQuery.getSingleResult();
//		System.out.println("object 1 =====>>"+object1);
//		return (String) storedProcedureQuery.getOutputParameterValue("result");
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
		
	}
    
    public String getBranchList(AdminRequest request) {
    	StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".sp_Get_Branch_List");
    	storedProcedureQuery.registerStoredProcedureParameter("filterJSON", String.class, ParameterMode.IN);
    	storedProcedureQuery.registerStoredProcedureParameter("paginationFROM", Integer.class, ParameterMode.IN);
    	storedProcedureQuery.registerStoredProcedureParameter("paginationTO", Integer.class, ParameterMode.IN);
    	storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
    	storedProcedureQuery.setParameter("filterJSON", request.getFilterJSON());
    	storedProcedureQuery.setParameter("paginationFROM", request.getPaginationFROM());
    	storedProcedureQuery.setParameter("paginationTO", request.getPaginationTO());
    	storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
    	
    }
    
    
    
    
    @Override
    public String spUserManagementFetchTierDetailRoZo(Long userId,Integer orgId,Integer businessTypeId,int type,String noPagination,Integer paginationFROM,Integer paginationTO,Long schemeId,String columnFilter) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("Fetch_Tier_Detail_RoZo");
		storedProcedureQuery.registerStoredProcedureParameter("orgId",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("userId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("noPagination",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("type1",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationFROM",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationTO",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("schemeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("columnFilter",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);

//		setStoreProcedureEnableNullParameters(storedProcedureQuery);

		storedProcedureQuery.setParameter("orgId", orgId);
		storedProcedureQuery.setParameter("userId", userId);
		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
		storedProcedureQuery.setParameter("noPagination", noPagination);
		storedProcedureQuery.setParameter("type1", type);
		storedProcedureQuery.setParameter("paginationFROM", paginationFROM);
		storedProcedureQuery.setParameter("paginationTO", paginationTO);
		storedProcedureQuery.setParameter("schemeId", schemeId);
		storedProcedureQuery.setParameter("columnFilter", columnFilter);
		storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
	}

//	public void setStoreProcedureEnableNullParameters(StoredProcedureQuery storedProcedureQuery) {
//	    if (storedProcedureQuery == null || storedProcedureQuery.getParameters() == null)
//	        return;
//
//	    for (Parameter parameter : storedProcedureQuery.getParameters()) {
//	        ((ProcedureParameterImpl) parameter).enablePassingNulls(true);
//	    }
//	}
	
	@Override
	public String spResetUserPassword(Long userid) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("SPRESETUSERPASSWORD");
		storedProcedureQuery.registerStoredProcedureParameter("userid",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", String.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("userid", userid);
		storedProcedureQuery.execute();
		return (String) storedProcedureQuery.getOutputParameterValue("result");
	}
	

	@Override
	public String spUserManagementBankUsersList(Long orgId,Long businessTypeId,int roleType,String noPagination,Integer paginationFROM,Integer paginationTO,Long schemeId,String columnFilter) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("SP_USERMANAGEMENT_BANKUSERS_LIST");
		storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("roleType",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("noPagination",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationFROM",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationTO",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("schemeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("columnFilter",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
//		setStoreProcedureEnableNullParameters(storedProcedureQuery);
		storedProcedureQuery.setParameter("orgId", orgId);
		storedProcedureQuery.setParameter("roleType", roleType);
		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
		storedProcedureQuery.setParameter("noPagination", noPagination);
		storedProcedureQuery.setParameter("paginationFROM", paginationFROM);
		storedProcedureQuery.setParameter("paginationTO", paginationTO);
		storedProcedureQuery.setParameter("schemeId", schemeId);
		storedProcedureQuery.setParameter("columnFilter", columnFilter);
		storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
	}
	
	@Override
	public String getRoZoUsersList(Long userId, Long userOrgId, Long businessTypeId, Integer roleType,
			String noPagination, String paginationFROM, String paginationTO, Long schemeId, String columnFilter) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("SPUSERMANAGEMENTFETCHROZOUSERSLIST");
		storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("roleType",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("noPagination",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationFROM",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationTO",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("schemeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("userid",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("columnFilter",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
//		setStoreProcedureEnableNullParameters(storedProcedureQuery);
		storedProcedureQuery.setParameter("orgId", userOrgId);
		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
		storedProcedureQuery.setParameter("roleType", roleType);
		storedProcedureQuery.setParameter("noPagination", noPagination);
		storedProcedureQuery.setParameter("paginationFROM", paginationFROM);
		storedProcedureQuery.setParameter("paginationTO", paginationTO);
		storedProcedureQuery.setParameter("schemeId", schemeId);
		storedProcedureQuery.setParameter("userid", userId);
		storedProcedureQuery.setParameter("columnFilter", columnFilter);
		storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
	}
	
	@Override
	public String getOfficesZoRoBoList(Long userId, Long userOrgId, Long businessTypeId, Integer roleType,
			String noPagination, String paginationFROM, String paginationTO, Long schemeId, String columnFilter) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("FETCH_ALL_OFFICES_ROZO");
		storedProcedureQuery.registerStoredProcedureParameter("userId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("roleType",Integer.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("noPagination",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationFROM",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("paginationTO",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("schemeId",Long.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("columnFilter",String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
//		setStoreProcedureEnableNullParameters(storedProcedureQuery);
		storedProcedureQuery.setParameter("userId", userId);
		storedProcedureQuery.setParameter("orgId", userOrgId);
		storedProcedureQuery.setParameter("roleType", roleType);
		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
		storedProcedureQuery.setParameter("noPagination", noPagination);
		storedProcedureQuery.setParameter("paginationFROM", paginationFROM);
		storedProcedureQuery.setParameter("paginationTO", paginationTO);
		storedProcedureQuery.setParameter("schemeId", schemeId);
		storedProcedureQuery.setParameter("columnFilter", columnFilter);
		storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
	}

    @Override
    public Boolean updateIsLocked(Long userId, Boolean isLocked) {
    	if(isLocked.equals(true)) {
    		System.out.println("locked-------");
    		 try {
    	            entityManager.createNativeQuery("UPDATE "+DBNameConstant.JNS_USERS+".users SET is_locked =:isLocked and user_locked_date=NOW() WHERE user_id =:userId")
    	                    .setParameter("userId", userId)
    	                    .setParameter("isLocked", isLocked)
    	                    .executeUpdate();
    	            return true;
    	        } catch(Exception e) {
    	            logger.error("Exception while update active status", e);
    	            return false;
    	        }
    	}else {
    		 try {
    	            entityManager.createNativeQuery("UPDATE "+DBNameConstant.JNS_USERS+".users SET is_locked =:isLocked and user_unlocked_date =:unLockedDate  WHERE user_id =:userId")
    	                    .setParameter("userId", userId)
    	                    .setParameter("isLocked", isLocked)
    	                    .setParameter("unLockedDate", new Date())
    	                    .executeUpdate();
    	            return true;
    	        } catch(Exception e) {
    	            logger.error("Exception while update active status", e);
    	            return false;
    	        }
    	}
       
    }


    public List<Object[]> getUserList(Long userId, Integer businessTypeId) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetchBankAdminUserList");
        storedProcedureQuery.registerStoredProcedureParameter("userId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("userId",userId);
        storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
        return (List<Object[]>) storedProcedureQuery.getResultList();
    }

    @Override
    public String resetPassword(String emailID) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementResetPassword");
        storedProcedureQuery.registerStoredProcedureParameter("emailID",String.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result",String.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("emailID",emailID);
        storedProcedureQuery.execute();
        return (String) storedProcedureQuery.getOutputParameterValue("result");
    }

    @Override
    public String getUserProfile(Long userId, Long businessTypeId) {
        try {
        	StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery("FETCH_USER_PROFILE");
    		storedProcedureQuery.registerStoredProcedureParameter("userid",Long.class, ParameterMode.IN);
    		storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
    		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
    		storedProcedureQuery.setParameter("userid", userId);
    		storedProcedureQuery.setParameter("businessTypeId", businessTypeId);
    		storedProcedureQuery.execute();
    		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));

        } catch(Exception e) {
            logger.error("Exception while fetching user profile details", e);
            return null;
        }
    }

    @Override
    public String getRoleTypeList(String email) {
        try {
            
	//          return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('roleType',(SELECT r.display_name FROM users.user_role_master r WHERE r.role_id = m.user_role_id),\r\n"
	//    		+ "                    'loanType',(SELECT b.display_name FROM users.business_master b WHERE b.id = m.business_id),\r\n"
	//    		+ "                    'schemeName',(SELECT b.name FROM users.scheme_master b WHERE b.id = m.scheme_id),\r\n"
	//    		+ "                    'firstName',CAST((AES_DECRYPT(UNHEX(u.first_name),'C@p!ta@W0rld#AES')) AS CHAR),\r\n"
	//    		+ "                    'middleName',CAST((AES_DECRYPT(UNHEX(u.middle_name),'C@p!ta@W0rld#AES')) AS CHAR),\r\n"
	//    		+ "                    'lastName',CAST((AES_DECRYPT(UNHEX(u.last_name),'C@p!ta@W0rld#AES')) AS CHAR),\r\n"
	//    		+ "                    'userId',u.user_id,\r\n"
	//    		+ "                    'userOrgId',u.user_org_id,\r\n"
	//    		+ "                    'email',CAST((AES_DECRYPT(UNHEX(u.email),'C@p!ta@W0rld#AES')) AS CHAR),\r\n"
	//    		+ "                    'mobile',CAST((AES_DECRYPT(UNHEX(u.mobile),'C@p!ta@W0rld#AES')) AS CHAR),\r\n"
	//    		+ "                    'ifscCode',b.ifsc_code))AS CHAR)\r\n"
	//    		+ "                    FROM "+DBNameConstant.JNS_USERS+".user_role_product_mapping m\r\n"
	//    		+ "                    LEFT JOIN "+DBNameConstant.JNS_USERS+".users u\r\n"
	//    		+ "                    ON u.user_id = m.user_id\r\n"
	//    		+ "                    LEFT JOIN "+DBNameConstant.JNS_USERS+".branch_master b\r\n"
	//    		+ "                    ON b.id = u.branch_id\r\n"
	//    		+ "                    WHERE CAST((AES_DECRYPT(UNHEX(u.email),'C@p!ta@W0rld#AES')) AS CHAR) = :email LIMIT 1")
	//            .setParameter("email",email)
	//            .getSingleResult();

			Object resObj = entityManager.createNativeQuery("SELECT JSON_OBJECT('roleType' value (SELECT r.display_name FROM "+DBNameConstant.JNS_USERS+".user_role_master r WHERE r.role_id = m.user_role_id), 'loanType' value (SELECT b.display_name FROM "+DBNameConstant.JNS_USERS+".business_master b WHERE b.id = m.business_id), 'schemeName' value (SELECT b.name FROM "+DBNameConstant.JNS_USERS+".scheme_master b WHERE b.id = m.scheme_id), 'firstName' value u.first_name, 'middleName' value u.middle_name, 'lastName' value u.last_name, 'userId' value u.user_id, 'userOrgId' value u.user_org_id, 'email' value u.email, 'mobile' value u.mobile, 'ifscCode' value b.ifsc_code) FROM "+DBNameConstant.JNS_USERS+".user_role_product_mapping m LEFT JOIN "+DBNameConstant.JNS_USERS+".users u ON u.user_id = m.user_id LEFT JOIN "+DBNameConstant.JNS_USERS+".branch_master b ON b.id = u.branch_id WHERE "+DBNameConstant.JNS_USERS+".\"decvalue\"(u.email) = :email fetch first 1 rows only")
	                .setParameter("email",email)
	                .getSingleResult();
			return MultipleJSONObjectHelper.getStringfromObject(resObj);            
            
        } catch(Exception e) {
            logger.error("Exception while update active status");
        }
        return null;
    }

    @Override
    public String getUserBusinessTypeList(Long userId) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(jobj) AS CHAR) FROM(SELECT JSON_OBJECT('businessTypeId',business_id,'roleId',user_role_id,'status', CASE WHEN is_active THEN 'Active' ELSE 'Inactive' END,'roleType',(SELECT display_name FROM "+DBNameConstant.JNS_USERS+".user_role_master WHERE role_id = user_role_id),'businessName', (SELECT display_name FROM "+DBNameConstant.JNS_USERS+".business_master WHERE id = business_id)) AS jobj FROM "+DBNameConstant.JNS_USERS+".user_role_product_mapping WHERE user_id = :userId AND is_active = TRUE GROUP BY business_id)AS jsonobj;")
//                .setParameter("userId",userId)
//                .getSingleResult();
    	try {
            return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT('businessTypeId' VALUE grptbl.businessid, 'roleId' VALUE urpm.user_role_id, 'status' VALUE 'Active', 'roleType' VALUE urm.display_name, 'businessName' VALUE bm.display_name)) \r\n"
            		+ "FROM (SELECT business_id AS businessid, MAX(USER_ID) AS userid, MAX(id) AS id  FROM "+DBNameConstant.JNS_USERS+".user_role_product_mapping WHERE user_id = :userId GROUP BY business_id) grptbl\r\n"
            		+ "INNER JOIN "+DBNameConstant.JNS_USERS+".user_role_product_mapping  urpm ON urpm.USER_ID = grptbl.userid AND urpm.id = grptbl.id\r\n"
            		+ "INNER JOIN "+DBNameConstant.JNS_USERS+".user_role_master urm ON urm.role_id = urpm.user_role_id\r\n"
            		+ "INNER JOIN "+DBNameConstant.JNS_USERS+".business_master bm ON bm.id = urpm.business_id").setParameter("userId",userId).getSingleResult();
        } catch (Exception e) {
            logger.error("Exception while get user business type  user id---> {} :- ", userId);
            e.printStackTrace();
        }
        return "";
    }


    public String getNewUsersList(Date fromDate, Date toDate, Long orgId, Long businesstypeid, Integer roleType) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetchNewUsersList");
        storedProcedureQuery.registerStoredProcedureParameter("fromDate",Date.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("toDate",Date.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("roleType",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("fromDate",fromDate);
        storedProcedureQuery.setParameter("toDate",toDate);
        storedProcedureQuery.setParameter("orgId",orgId);
        storedProcedureQuery.setParameter("businessTypeId", businesstypeid);
        storedProcedureQuery.setParameter("roleType", roleType);
        return (String) storedProcedureQuery.getSingleResult();
    }

    public String getAllRoles() {
		try {
			return (String) entityManager.createNativeQuery("SELECT JSON_OBJECT('roleId' value rm.role_id, 'roleName' value rm.display_name,'sequence' value rm.sequence) FROM " + DBNameConstant.JNS_USERS +".user_role_master rm WHERE rm.is_active=1 AND rm.is_banker = 1 ORDER BY rm.sequence ASC").getResultList().toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("error while fetching data from getAllRoles ---> {}",e);
			return null;
		}
	}


  @Override
    public BigInteger getUserId(String email, String mobile){
        return (BigInteger) entityManager.createNativeQuery("SELECT u.user_id FROM "+DBNameConstant.JNS_USERS+".users u WHERE CAST(AES_DECRYPT(UNHEX(u.email),'C@p!ta@W0rld#AES')AS CHAR) =:email AND CAST(AES_DECRYPT(UNHEX(u.mobile),'C@p!ta@W0rld#AES')AS CHAR) =:mobile")
        .setParameter("email", email)
        .setParameter("mobile", mobile)
        .getSingleResult();

    }

//    public Boolean checkEmailExits(String email) {
//        BigInteger count =(BigInteger) entityManager
//                .createNativeQuery("SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".users us WHERE CAST(AES_DECRYPT(UNHEX(us.email),'C@p!ta@W0rld#AES')AS CHAR) =:email ")
//                .setParameter("email", email).getSingleResult();
//        return count.intValue() > 0;
//    }
//
//    public Boolean checkMobileExits(String mobile) {
//        BigInteger count =(BigInteger) entityManager
//                .createNativeQuery("SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".users us WHERE us.mobile =:mobile")
//                .setParameter("mobile", mobile).getSingleResult();
//        return count.intValue() > 0;
//    }

     /*@Override
    public Boolean addFundProviderDetails(UserListResponseProxy userListResponse) {
        // TODO Auto-generated method stub
        try {
            String orgName = (String) entityManager.createNativeQuery("SELECT organisation_name FROM users.user_organisation_master WHERE user_org_id =:orgId")
                    .setParameter("orgId", userListResponse.getUserOrgId())
                    .getSingleResult();

            entityManager.createNativeQuery("INSERT INTO users.fund_provider_details \n" +
                    "(user_id,organization_name,is_active,profile_filled, is_profile_locked,first_name,middle_name,last_name) \n" +
                    "VALUES(:userId, :orgName, true, true, true, :firstName, :middleName, :lastName);")
                    .setParameter("userId", userListResponse.getUserId())
                    .setParameter("orgName", orgName)
                    .setParameter("firstName",userListResponse.getFirstName())
                    .setParameter("middleName",userListResponse.getMiddleName())
                    .setParameter("lastName",userListResponse.getLastName())
                    .executeUpdate();
            return true;
        } catch(Exception e) {
            logger.trace("Exception :-- " + e.getMessage(), e);
            return false;
        }
    }*/

    @Override
    public String getAllOfficeList(Date fromDate, Date toDate,Long orgId, Long businesstypeid, Integer branchType) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetchAllOffices");
      
        storedProcedureQuery.registerStoredProcedureParameter("orgId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("branchType",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("fromDate",Date.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("toDate",Date.class, ParameterMode.IN);
      
        storedProcedureQuery.setParameter("orgId",orgId);
        storedProcedureQuery.setParameter("businessTypeId", businesstypeid);
        storedProcedureQuery.setParameter("branchType", branchType);
        storedProcedureQuery.setParameter("fromDate",fromDate);
        storedProcedureQuery.setParameter("toDate",toDate);
        return (String) storedProcedureQuery.getSingleResult();
    }
    
    @Override
    public String getBranchUserDetails(Long branchId){
        try {

            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spGetBranchUserDetails");
            storedProcedureQuery.registerStoredProcedureParameter("branchId",Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", String.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("branchId",branchId);
            storedProcedureQuery.execute();
    		return (String) storedProcedureQuery.getOutputParameterValue("result");    	

        } catch(Exception e) {
            logger.error("Exception while fetching user profile details", e);
            return null;
        }

    }

//    @Override
//    public String getAllBoList(Long orgId,List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "'branchId',bm.id,\n" +
//                "'branchCode',bm.code,\n" +
//                "'branchName',bm.name)) AS CHAR)\n" +
//                "FROM users.branch_master bm\n" +
//                "LEFT JOIN users.branch_product_mapping bpm\n" +
//                "ON bpm.branch_id = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bpm.is_active = 1  and bpm.sch_type_id IN (:selectedScheme) AND bm.branch_type = 1\n" +
//                "ORDER BY bm.modified_date ASC")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

//    @Override
//    public String getAllBoList(Long orgId,List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'branchId',a.branchId,\n" +
//                "                'branchCode',a.branchCode,\n" +
//                "                'branchName',a.branchName)) AS CHAR)\n" +
//                "FROM (\n" +
//                "    SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
//                "    FROM users.branch_master bm\n" +
//                "INNER JOIN (\n" +
//                "SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "FROM users.branch_product_mapping bpm\n" +
//                "WHERE  bpm.is_active = 1\n" +
//                "HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 1\n" +
//                "GROUP BY bm.id\n" +
//                "ORDER BY bm.modified_date ASC) AS a\n")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

    
    
//    "SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
//    "                'branchId' value a.branchId,\n" +
//    "                'branchCode' value a.branchCode,\n" +
//    "                'branchRoId' value a.branchRoId,\n" +
//    "                'branchZoId' value a.branchZoId,\n" +
//    "                'branchName' value a.branchName) RETURNING CLOB)\n" +
//    "FROM (SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName,bpm.branch_ro_id AS branchRoId,bpm.branch_zo_id AS branchZoId\n" +
//    "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
//    "INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\n" +
//    "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 1\n" +
//    "ORDER BY bm.modified_date ASC) a"
    
    
    @Override
    public String getAllBoList(Long orgId,List<Long> selectedScheme) {
         Clob clob = (Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
                "                'branchId' value a.branchId,\n" +
                "                'branchCode' value a.branchCode,\n" +
                "                'branchRoId' value a.branchRoId,\n" +
                "                'branchZoId' value a.branchZoId,\n" +
                "                'branchName' value a.branchName) RETURNING CLOB)\n" +
                "FROM (select  grpTmp.branchId, bm.code AS branchCode,bm.name AS branchName,bpm.branch_ro_id AS branchRoId,bpm.branch_zo_id AS branchZoId\r\n"
                + "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\r\n"
                + "INNER JOIN (SELECT DISTINCT(bm.id) AS branchId \r\n"
                + "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\r\n"
                + "INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\r\n"
                + "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 1\r\n"
                + "GROUP BY bm.id) grpTmp ON grpTmp.branchId = bm.id\r\n"
                + "INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id = 1\r\n"
                + "ORDER BY bm.modified_date ASC\r\n"
                + ") a")
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
         
         return OPLUtils.readClob(clob);
    }

//    @Override
//    public String getZoList(Long orgId,List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'branchId',a.branchId,\n" +
//                "                'branchCode',a.branchCode,\n" +
//                "                'branchName',a.branchName)) AS CHAR)\n" +
//                "FROM (\n" +
//                "    SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
//                "    FROM users.branch_master bm\n" +
//                "INNER JOIN (\n" +
//                "SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "FROM users.branch_product_mapping bpm\n" +
//                "WHERE  bpm.is_active = 1\n" +
//                "HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 3\n" +
//                "GROUP BY bm.id\n" +
//                "ORDER BY bm.modified_date ASC) AS a\n")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

    @Override
    public String getZoList(Long orgId,List<Long> selectedScheme,Integer selectedSchemeSize) {
    	Clob clob = (Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
                "                'branchId' value a.branchId,\n" +
                "                'branchCode' value a.branchCode,\n" +
                "                'branchName' value a.branchName) RETURNING CLOB)\n" +
                "FROM (SELECT DISTINCT(bm.id) AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
                "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
                "INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\n" +
                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 3\n" +
                "ORDER BY bm.modified_date ASC) a")
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
    	
    	return OPLUtils.readClob(clob);
    }

    @Override
    public String getLhoList(Long orgId,List<Long> selectedScheme,Integer selectedSchemeSize) {
        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
                "                'branchId',a.branchId,\n" +
                "                'branchCode',a.branchCode,\n" +
                "                'branchName',a.branchName)) AS CHAR)\n" +
                "FROM (SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
                "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
                "INNER JOIN branch_product_mapping bpm ON bpm.branch_id = bm.id\n" +
                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 6 AND bpm.sch_type_id IN (:selectedScheme)\n" +
                "GROUP BY bm.id\n" +
                "ORDER BY bm.modified_date ASC) AS a")
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
    }

//    @Override
//    public String getRoList(Long orgId,List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'branchId',a.branchId,\n" +
//                "                'branchCode',a.branchCode,\n" +
//                "                'branchName',a.branchName)) AS CHAR)\n" +
//                "FROM (\n" +
//                "    SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
//                "    FROM users.branch_master bm\n" +
//                "INNER JOIN (\n" +
//                "SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "FROM users.branch_product_mapping bpm\n" +
//                "WHERE  bpm.is_active = 1\n" +
//                "HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 2\n" +
//                "GROUP BY bm.id\n" +
//                "ORDER BY bm.modified_date ASC) AS a\n")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

    @Override
    public String getRoList(Long orgId,List<Long> selectedScheme,Integer selectedSchemeSize) {
        Clob clob = (Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
                "                'branchId' value a.branchId,\n" +
                "                'branchCode' value a.branchCode,\n" +
                "                'branchName' value a.branchName) RETURNING CLOB)\n" +
                "FROM (SELECT DISTINCT(bm.id) AS branchId,bm.code AS branchCode,bm.name AS branchName\n" +
                "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
                "INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\n" +
                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 2\n" +
                "ORDER BY bm.modified_date ASC) a")
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
        
        return OPLUtils.readClob(clob);
    }

	@Override
	public String getAllSchemeList(Long userId) {
		 try {
//			 SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n"
//	            		+ "'schemeId',sm.id,\n"
//	            		+ "'loanMasterId',sm.loan_master_id,\n"
//	            		+ "'schemeName',sm.name,'schemeShortName',sm.short_name,'bussinessTypeId',lm.business_type,'bussinessTypeName',bm.display_name)) AS CHAR)\n"
//	            		+ "	FROM scheme_details.scheme_master sm\n"
//                     + "	LEFT JOIN users.user_role_product_mapping u ON u.scheme_id = sm.id\n"
//	            		+ "	LEFT JOIN scheme_details.loan_master lm ON lm.id=sm.loan_master_id\n"
//	            		+ "	LEFT JOIN users.business_master bm ON bm.business_type_master_id=lm.business_type\n"
//	            		+ "	WHERE u.user_id =:userId AND sm.is_active=1 AND lm.business_type IS NOT NULL

			 return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT( 'schemeId' value sm.id, 'schemeName' value sm.name, 'schemeShortName' value sm.short_name,"
	            		+ "'bussinessTypeId' value bm.id, 'bussinessTypeName' value bm.display_name)) "
	            		+ " FROM "+DBNameConstant.JNS_USERS+".scheme_master sm "
	            		+ "	INNER JOIN "+DBNameConstant.JNS_USERS+".user_role_product_mapping u ON u.scheme_id = sm.id AND u.is_active = 1 AND u.user_id = :userId "										
	            		+ " INNER JOIN "+DBNameConstant.JNS_USERS+".business_master bm ON bm.id = sm.business_id AND bm.is_active = 1 WHERE sm.is_active = 1 ")            
					 .setParameter("userId", userId)
					 .getSingleResult();
	            
	        } catch(Exception e) {
	            logger.error("Exception while fetch scheme list", e);
	            return null;
	        }
	}
	
	@Override
	public String getAllSchemeListForReport(Long userId) {
		 try {
	            return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('schemeId',sm.id,'loanMasterId',sm.loan_master_id,'schemeName',sm.name,'schemeShortName',sm.short_name,'bussinessTypeId',bm.business_type_master_id,'bussinessTypeName',bm.display_name)) AS CHAR) FROM "+DBNameConstant.JNS_USERS+".scheme_master sm INNER JOIN "+DBNameConstant.JNS_USERS+".user_role_product_mapping u ON u.scheme_id = sm.id AND u.is_active = 1 AND u.user_id = :userId INNER JOIN "+DBNameConstant.JNS_USERS+".business_master bm ON bm.business_type_master_id = sm.business_type_id AND bm.is_active = 1")
                        .setParameter("userId", userId)
	                    .getSingleResult();	            
	        } catch(Exception e) {
	            logger.error("Exception while fetch scheme list", e);
	            return null;
	        }
	}
	
	@Override
	public List<Long> getSchemeIdList(Long userId) {
		try {
			return entityManager.createNativeQuery("SELECT URMP.scheme_id FROM "+DBNameConstant.JNS_USERS+".user_role_product_mapping URMP WHERE URMP.user_id = :userId").setParameter("userId", userId).getResultList();
		} catch (Exception e) {
			logger.error("Exception while fetch scheme id list", e);
			return Collections.emptyList();
		}
	}

    @Override
    public String getAllOfficeType() {
        try {
            return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT('roleId' value rm.role_id, 'branchType' value rm.branch_type, "
            		+ " 'displayName' value rm.display_name, 'displayOfficeName' value rm.display_office_name)) AS office "
            		+ "FROM "+DBNameConstant.JNS_USERS+".user_role_master rm WHERE rm.BRANCH_TYPE IS NOT NULL AND rm.IS_ACTIVE = 1 AND rm.IS_BANKER = 1")
            		.getSingleResult();
        } catch(Exception e) {
            logger.error("Exception while fetch scheme list", e);
            return null;
        }
    }


    @Override
    public String getFacilitatorList(Long createdBy, Integer schemeId) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(""+DBNameConstant.JNS_USERS+".sp_FetchFacilitatorList_SchemeWise");
        storedProcedureQuery.registerStoredProcedureParameter("createdBy",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("schemeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("createdBy",createdBy);
        storedProcedureQuery.setParameter("schemeId",schemeId);
        return (String) storedProcedureQuery.getSingleResult();
    }

    @Override
    public String getULBList(Long createdBy,Long userId) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(""+DBNameConstant.JNS_USERS+".sp_Fetch_ULB_list");
        storedProcedureQuery.registerStoredProcedureParameter("createdBy",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("userId",Long.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("createdBy",createdBy);
        storedProcedureQuery.setParameter("userId",userId);
        return (String) storedProcedureQuery.getSingleResult();
    }


    @Override
    public String getSchemeList() {
        try {
            return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT( 'schemeId' value sm.id, 'schemeName' value sm.name, 'schemeShortName' value sm.short_name, 'bussinessTypeId' value  bm.id, 'bussinessTypeName' value bm.display_name)) "
            		+ "FROM "+ DBNameConstant.JNS_USERS +".scheme_master sm "
            		+ "INNER JOIN "+DBNameConstant.JNS_USERS+".user_role_product_mapping u ON u.scheme_id = sm.id AND u.is_active = 1 AND u.user_id = :userId "
            		+ "INNER JOIN "+DBNameConstant.JNS_USERS+".business_master bm ON bm.id = sm.business_id AND bm.is_active = 1 WHERE sm.is_active = 1;")            		
                    .getSingleResult();

        } catch(Exception e) {
            logger.error("Exception while fetch scheme list", e);
            return null;
        }
    }
    public Boolean checkEmailExits(String email) {
        BigInteger count =(BigInteger) entityManager
                .createQuery(" SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".users us WHERE us.email =:email ")
                .setParameter("email", email).getSingleResult();
        return count.intValue() > 0;
    }

    public Boolean checkMobileExits(String mobile) {
        BigInteger count =(BigInteger) entityManager
                .createQuery(" SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".users us WHERE us.mobile =:mobile ")
                .setParameter("mobile", mobile).getSingleResult();
        return count.intValue() > 0;
    }


  @Override
    public String getZoNameByZoId(Long orgId,Long schemeId,List<Long> zoIdLst){
	  return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT('id' value id ,'name' value name)) from(SELECt  DISTINCT(bm.id) as id,bm.name as name FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS + ".branch_master bm ON bm.id = bpm.branch_zo_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bpm.branch_zo_id in (:zoIdLst))").setParameter("zoIdLst", zoIdLst).setParameter("schemeId", schemeId).setParameter("orgId", orgId).getSingleResult();
  }
    
    @Override
    public String getZoName(Long orgId,Long schemeId){
    	return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT('id' value id ,'name' value name)) from ( SELECt  DISTINCT(bm.id) as id,bm.name as name FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS + ".branch_master bm ON bm.id = bpm.branch_zo_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId )").setParameter("schemeId", schemeId).setParameter("orgId", orgId).getSingleResult();

    }
    
//    @Override
//    public String getAllBoParticularList(Long userRoleId,Long orgId,List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'branchId',a.branchId,\n" +
//                "                'branchCode',a.branchCode,\n" +
//                "                'branchRoId',a.branchRoId,\n" +
//                "                'branchZoId',a.branchZoId,\n" +
//                "                'branchName',a.branchName)) AS CHAR)\n" +
//                "FROM (SELECT bm.id AS branchId,bm.code AS branchCode,bm.name AS branchName,bpm.branch_ro_id AS branchRoId,bpm.branch_zo_id AS branchZoId\n" +
//                "FROM users.branch_master bm\n" +
//                "INNER JOIN users.branch_product_mapping bpm ON bpm.branch_id = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 1 AND bpm.sch_type_id IN (:selectedScheme)\n" +
//                "GROUP BY bm.id\n" +
//                "ORDER BY bm.modified_date ASC) AS a")
//                .setParameter("orgId", orgId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();

	public String getBranchListBySearch(String request) {
		StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".SP_GET_BRANCH_LIST_BY_SEARCH");
		storedProcedureQuery.registerStoredProcedureParameter("filterJSON", String.class, ParameterMode.IN);
		storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
		storedProcedureQuery.setParameter("filterJSON", request);
		storedProcedureQuery.execute();
		return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
	}
}
