package com.opl.jns.user.management.service.repository;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import com.opl.jns.user.management.api.model.AdminRequest;

/**
 * Created by pooja.patel on 16-08-2020.
 */
public interface UserManagementRepositoryV3 {

//    public List<Object[]> getUserList(Long userId, Integer businesstypeid);

	public String resetPassword(String emailID);
	public String getBranchList(AdminRequest request);
	
	public String spResetUserPassword(Long userid); 

	public Boolean updateIsLocked(Long userId, Boolean isLocked);

	public String getUserProfile(Long userId, Long businessTypeId);

	public String getRoleTypeList(String email);

	public String getUserBusinessTypeList(Long userId);

	public String getNewUsersList(Date fromDate, Date toDate, Long orgId, Long businesstypeid, Integer roleType);
	
	public String spUserManagementFetchTierDetailRoZo(Long userId,Integer orgId,Integer businessTypeId,int type,String noPagination,Integer paginationFROM,Integer paginationTO,Long schemeId,String columnFilter) ;

	// public Boolean updateUser(UserListResponseProxy userListResponse);

	public BigInteger getUserId(String email, String mobile);

	// public Boolean addFundProviderDetails(UserListResponseProxy
	// userListResponse);

	public String getAllOfficeList(Date fromDate, Date toDate, Long orgId, Long businesstypeid, Integer branchType);

	public String getBranchUserDetails(Long branchId);

	// public String getSingleUserDetailList(Long userId);

	public Boolean checkEmailExits(String email);

	public Boolean checkMobileExits(String mobile);

	public String getAllBoList(Long orgId, List<Long> selectedScheme);

	public String getZoList(Long orgId, List<Long> selectedScheme, Integer selectedSchemeSize);

	public String getLhoList(Long orgId, List<Long> selectedScheme, Integer selectedSchemeSize);

	public String getRoList(Long orgId, List<Long> selectedScheme, Integer selectedSchemeSize);

	public String getAllSchemeList(Long userId);

	public String getAllSchemeListForReport(Long userId);

	public String getAllOfficeType();

	public String getFacilitatorList(Long createdBy, Integer schemeId);

	public String getULBList(Long createdBy, Long userId);

	public String getSchemeList();

	public List<Long> getSchemeIdList(Long userId);

	public String spUserManagementBankBranchList(Long orgId, Long businessTypeId, int branchtype, String noPagination,

			Integer paginationFROM, Integer paginationTO, Long schemeId, String columnFilter);

	public String spUserManagementBankUsersList(Long orgId, Long businessTypeId, int roleType, String noPagination,
			Integer paginationFROM, Integer paginationTO, Long schemeId, String columnFilter);

	public String getAllRoles();

	public String getZoNameByZoId(Long orgId, Long schemeId, List<Long> zoId);
	
	public String getZoName(Long orgId,Long schemeId);
	
	public String getRoZoUsersList(Long userId, Long userOrgId, Long businessTypeId, Integer roleType,
			String noPagination, String paginationFROM, String paginationTO, Long schemeId, String json);
	
	public String getOfficesZoRoBoList(Long userId, Long userOrgId, Long businessTypeId, Integer roleType,
			String noPagination, String paginationFROM, String paginationTO, Long schemeId, String json);

	public String getBranchListBySearch(String request);

}
