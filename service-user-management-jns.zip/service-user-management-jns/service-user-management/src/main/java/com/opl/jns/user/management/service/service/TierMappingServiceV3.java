package com.opl.jns.user.management.service.service;

import java.util.List;
import java.util.Map;

import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.RoleMasterProxy;
import com.opl.jns.user.management.api.model.TierMappingRequestProxy;

public interface TierMappingServiceV3 {
    public String getTierMappingList(TierMappingRequestProxy tierMappingRequest);

    public String getBranchCount(TierMappingRequestProxy tierMappingRequest);

    public String getSingleTierMapping(TierMappingRequestProxy tierMappingRequest);

    public Boolean updateBranchDetails(BranchRequestProxy branchRequest);

    public String getAllZoList(TierMappingRequestProxy tierMappingRequest);

    public String getAllLhoList(TierMappingRequestProxy tierMappingRequest);

    public String getAllRoList(TierMappingRequestProxy tierMappingRequest);

    public Boolean updateDisplayName(RoleMasterProxy roleMasterProxy,Long userId);

    public List<Long> getSchemeListByid(TierMappingRequestProxy tierMappingRequest);
    public String getZObyROId(TierMappingRequestProxy tierMappingRequest);

	public String getZObyLhoId(TierMappingRequestProxy tierMappingRequest);

	public String getBOROZObyId(TierMappingRequestProxy tierMappingRequest);
	
	public String getBObyZOId(TierMappingRequestProxy tierMappingRequest);

    public Map<String, Object> getBranchMappingIds(Long branchId, Long schemeId);
    
    public Map<String, Object> getBranchMappingIdsByIfscAndSchemeId(String ifsc, Long schemeId);
}
