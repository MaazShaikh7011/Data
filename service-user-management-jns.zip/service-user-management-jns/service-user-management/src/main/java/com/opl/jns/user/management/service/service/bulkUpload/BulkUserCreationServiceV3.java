package com.opl.jns.user.management.service.service.bulkUpload;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.model.BulkUserResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;

/**
 * Created by dhaval.panchal on 15-Oct-19.
 */
public interface BulkUserCreationServiceV3 {

    public Boolean extractExcel(MultipartFile multipartFile, Long orgId, Long fileId, Long userRoleId, Long userBranchId);
    
    public Boolean extractExcelRoZo(MultipartFile multipartFile, Long orgId, Long fileId, Long userRoleId, Long userBranchId);
    
    public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile, Long productMappingId);

    public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId);

    public List<BulkUserResponseProxy> getFileEntryList(FileResponseProxy fileResponse);

    public String getUserRoleEntries(UserListResponseProxy userListResponse);

    public String getUserEntryCount(UserListResponseProxy userListResponse);

    public List<BulkUserResponseProxy> getAllUserEntryList(UserListResponseProxy userListResponse);

    public String getUserFileEntryCount(FileResponseProxy fileResponse);

    public Boolean extractExcelForFacilitator(MultipartFile multipartFile, Long cretaedBy, Long fileId,Long schemeId,Long userType);
    
    public UserResponseProxy listUploadedExcelFacilitatorOrUlb(Long userId,Long userType);
    
    public List<BulkUserResponseProxy> getFileFacilitatorOrUlbEntryList(FileResponseProxy fileResponse);

    public Boolean extractExcelForUlb(MultipartFile multipartFile, AuthClientResponse authClientResponse, Long fileId,Long schemeId,Long userType);

}
