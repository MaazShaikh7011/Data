package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.utils.constant.DBNameConstant;

import java.util.List;
import java.util.Optional;
import java.util.Map;

/**
 * Created by dhaval.panchal on 08-May-19.
 */
public interface BranchProductMappingRepositoryV3 extends JpaRepository<BranchProductMapping,Long> {

//    @Query("SELECT b FROM BranchProductMapping b WHERE branchId=:branchId and isActive=true")
//    public List<BranchProductMapping> getBranchProductDetailsByBranchId(@Param("branchId") Long branchId);
//
//    @Query("SELECT b FROM BranchProductMapping b WHERE branchId=:branchId AND isActive=TRUE AND businessId=:businessId AND userOrgId=:userOrgId")
//    public List<BranchProductMapping> getBranchProductDetailsByBranchId(@Param("branchId") Long branchId, @Param("businessId") Long businessId, @Param("userOrgId") Long userOrgId);
//
//    public BranchProductMapping findByBranchIdAndBusinessId(@Param("branchId") Long branchId, @Param("businessId") Long businessId);

//    @Modifying
//    @Query(value = "DELETE FROM `users`.`branch_product_mapping` WHERE branch_id =:branchId",nativeQuery = true) // if want to write nativequery then mask nativeQuery  as true
//    int deleteByBranchId(@Param("branchId") Long branchId);

//    @Modifying
//    @Query(value = "DELETE FROM `users`.`branch_product_mapping` WHERE branch_id = :branchId AND sch_type_id IN(:selectedScheme)",nativeQuery = true)
//    int deleteByBranchIdAndSchemeId(@Param("branchId") Long branchId, @Param("selectedScheme") List<Long> selectedScheme);
    
    @Modifying
    @Query("DELETE from BranchProductMapping bp where bp.branchId=:branchId and bp.schemeId IN (:selectedScheme)")
    void deleteByBranchIdAndSchemeId(@Param("branchId") Long branchId, @Param("selectedScheme") List<Long> selectedScheme);
    
    @Modifying
    @Query("DELETE from BranchProductMapping bp where bp.branchId=:branchId")
    int deleteByBranchId(@Param("branchId") Long branchId);
    

    @Query(value = "SELECT branch_ho_id FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping WHERE user_org_id =:userOrgId AND branch_ho_id IS NOT NULL offset 1 row fetch next 1 row only",nativeQuery = true)
    public Long getBranchHOId(@Param("userOrgId") Long userOrgId);

//    @Query(value = "SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".`branch_product_mapping` WHERE branch_id =:branchId AND `sch_type_id`IN (:schemeTypelist)",nativeQuery = true)
//    public Integer findBySchemeId(@Param("schemeTypelist") List<Long> schemeTypelist,@Param("branchId") Long branchId);

    @Query(value = "SELECT schemeId FROM BranchProductMapping WHERE branchId =:branchId and isActive = true")
    public List<Long> getSchemeListByBranchId(@Param("branchId") Long branchId);

    @Query(value = "SELECT JSON_OBJECT('branchId' value b.id,'branchName'value b.name,'branchCode'value b.code) FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm  INNER JOIN "+DBNameConstant.JNS_USERS+".branch_master b ON bpm.branch_ho_id =b.id WHERE b.org_id =:userOrgId AND bpm.branch_ho_id IS NOT NULL OFFSET 1 ROW FETCH NEXT 1 ROW ONLY",nativeQuery = true)
    public String getBranchHOName(@Param("userOrgId") Long userOrgId);

//    @Query("SELECT b FROM BranchProductMapping b WHERE branchId=:branchId AND isActive=TRUE AND schemeId=:schemeId AND userOrgId=:userOrgId AND isActive=TRUE")
//    public BranchProductMapping getBranchProductDetailsBySchemeTypeId(@Param("branchId") Long branchId, @Param("schemeId") Long schemeId, @Param("userOrgId") Long userOrgId);

    @Query("SELECT schemeId FROM BranchProductMapping b WHERE branchId=:branchId AND isActive=true")
    public List<Long> getSchemeIds(@Param("branchId") Long branchId);

//    @Query("SELECT branchRoId FROM BranchProductMapping b WHERE branchId=:branchId AND isActive=TRUE AND schemeId=:schemeId AND userOrgId=:userOrgId AND isActive=TRUE")
//    public Long getRoId(@Param("branchId") Long branchId, @Param("schemeId") Long schemeId, @Param("userOrgId") Long userOrgId);
//
//    @Query("SELECT branchZoId FROM BranchProductMapping b WHERE branchId=:branchId AND isActive=TRUE AND schemeId=:schemeId AND userOrgId=:userOrgId AND isActive=TRUE")
//    public Long getZoId(@Param("branchId") Long branchId, @Param("schemeId") Long schemeId, @Param("userOrgId") Long userOrgId);

    Optional<BranchProductMapping> findByBranchIdAndSchemeId(Long branchId, Long schemeId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
    @Query("SELECT branchLHoId FROM BranchProductMapping b WHERE userOrgId=:userOrgId AND schemeId=:schemeId AND isActive=true AND branchId=:branchId ")
    public Long getLHoId(@Param("branchId") Long branchId, @Param("schemeId") Long schemeId, @Param("userOrgId") Long userOrgId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
    @Query("SELECT branchLHoId AS branchLHoId, branchZoId AS branchZoId FROM BranchProductMapping WHERE userOrgId=:userOrgId AND schemeId=:schemeId AND isActive=true AND branchId=:branchId")
    public Map<String, Long> getLHoIdAndLHoList(@Param("branchId") Long branchId, @Param("schemeId") Long schemeId, @Param("userOrgId") Long userOrgId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_IS_ACTIVE_BRANCH_ID_BRANCH_ZO_ID
    @Query("SELECT branchZoId FROM BranchProductMapping b WHERE userOrgId=:userOrgId AND isActive=true AND branchId=:branchRoId AND branchZoId IS NOT NULL group by branchZoId")
    public Long getZoIdByRoId(@Param("branchRoId") Long branchRoId, @Param("userOrgId") Long userOrgId);

    @Modifying
    @Query("UPDATE BranchProductMapping bpm SET bpm.isActive = :isActive, bpm.modifiedDate=current_timestamp WHERE bpm.branchId=:branchId")
	public Integer updateByBranchId(@Param("branchId") Long branchId, @Param("isActive") Boolean isActive);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_IS_ACTIVE_BRANCH_ID_BRANCH_ZO_ID
    @Query("SELECT branchLHoId FROM BranchProductMapping b WHERE userOrgId=:userOrgId AND isActive=true AND branchId=:branchZoId AND branchLHoId IS NOT NULL group by branchLHoId")

    public Long getLHoIdByZoId(@Param("branchZoId") Long branchRoId, @Param("userOrgId") Long userOrgId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_RO_ID
    @Query("SELECT DISTINCT bpm.branchId FROM BranchProductMapping bpm INNER JOIN BranchMaster bm ON bm.id = bpm.branchId AND bm.branchType = 1 AND bm.isActive = TRUE WHERE  bpm.userOrgId = :userOrgId AND bpm.schemeId = :schemeId AND bpm.isActive = TRUE AND bpm.branchRoId = :userBranchId ")
    List<Long> getBranchIdsByRoBranchId(Long userBranchId, Long userOrgId, Long schemeId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ZO_ID
    @Query("SELECT DISTINCT bpm.branchId FROM BranchProductMapping bpm INNER JOIN BranchMaster bm ON bm.id = bpm.branchId AND bm.branchType = 1 AND bm.isActive = TRUE WHERE bpm.userOrgId = :userOrgId AND bpm.schemeId = :schemeId AND bpm.isActive = TRUE AND bpm.branchZoId = :userBranchId ")
    List<Long> getBranchIdsByZoBranchId(Long userBranchId, Long userOrgId, Long schemeId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_LHO_ID
    @Query("SELECT DISTINCT bpm.branchId FROM BranchProductMapping bpm INNER JOIN BranchMaster bm ON bm.id = bpm.branchId AND bm.branchType = 1 AND bm.isActive = TRUE WHERE bpm.userOrgId = :userOrgId AND bpm.schemeId = :schemeId AND bpm.isActive = TRUE AND bpm.branchLHoId = :userBranchId ")
    List<Long> getBranchIdsByLhoBranchId(Long userBranchId, Long userOrgId, Long schemeId);

    //     ######## JNS_USERS_BR_PROD_MP_USER_ORG_ID_BRANCH_LHO_ID_IS_ACTIVE
    @Query("SELECT DISTINCT bpm.branchId FROM BranchProductMapping bpm INNER JOIN BranchMaster bm ON bm.id = bpm.branchId AND bm.branchType = 1 AND bm.isActive = TRUE WHERE bpm.userOrgId = :userOrgId AND bpm.branchLHoId = :userBranchId AND  bpm.isActive = TRUE  ")
    List<Long> getBranchIdsByBranchId(Long userBranchId, Long userOrgId);
    
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM "+ DBNameConstant.JNS_USERS  +".branch_product_mapping bpm "
			+ "INNER JOIN "+ DBNameConstant.JNS_USERS  +".branch_master bm ON bm.id=bpm.branch_ro_id AND  bm.is_active=1 and bm.branch_type=2"
			+ "WHERE bpm.user_org_id =:orgId AND bpm.sch_type_id =:schemeId", nativeQuery = true)
	public List<Map<String, Object>> getRoList(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId);
    
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM "+ DBNameConstant.JNS_USERS  +".branch_product_mapping bpm "
			+ "INNER JOIN "+ DBNameConstant.JNS_USERS  +".branch_master bm ON bm.id=bpm.branch_zo_id AND  bm.is_active=1 and bm.branch_type=3"
			+ "WHERE bpm.user_org_id =:orgId AND bpm.sch_type_id =:schemeId", nativeQuery = true)
	public List<Map<String, Object>> getZoList(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId);
	
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM "+ DBNameConstant.JNS_USERS  +".branch_product_mapping bpm "
			+ "INNER JOIN "+ DBNameConstant.JNS_USERS  +".branch_master bm ON bm.id=bpm.branch_id AND  bm.is_active=1 and bm.branch_type=1"
			+ "WHERE bpm.user_org_id =:orgId AND bpm.sch_type_id =:schemeId", nativeQuery = true)
	public List<Map<String, Object>> getBoList(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId);
	
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM "+ DBNameConstant.JNS_USERS  +".branch_product_mapping bpm "
			+ "INNER JOIN "+ DBNameConstant.JNS_USERS  +".branch_master bm ON bm.id=bpm.branch_zo_id AND  bm.is_active=1 and bm.branch_type=3 and bm.state_id IN(:stateIdLst)"
			+ "WHERE bpm.user_org_id =:orgId AND bpm.sch_type_id =:schemeId", nativeQuery = true)
	public List<Map<String, Object>> getZoListByStateId(@Param("orgId") Long orgId,@Param("stateIdLst") List<Integer> stateIdLst, @Param("schemeId") Long schemeId);
	
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM "+ DBNameConstant.JNS_USERS  +".branch_product_mapping bpm "
			+ "INNER JOIN "+ DBNameConstant.JNS_USERS  +".branch_master bm ON bm.id=bpm.branch_zo_id AND  bm.is_active=1 and bm.branch_type=3 and bm.state_id IN(:stateIdLst)"
			+ "WHERE bpm.user_org_id =:orgId AND bpm.sch_type_id =:schemeId AND bm.id=:branchId", nativeQuery = true)
	public List<Map<String, Object>> getZoListByStateIdAndBranchId(@Param("orgId") Long orgId,@Param("stateIdLst") List<Integer> stateIdLst, @Param("schemeId") Long schemeId,@Param("branchId") Long branchId);
    
}
