package com.opl.jns.user.management.service.repository;

import java.util.List;

import com.opl.jns.user.management.api.model.BranchRequestProxy;

public interface BranchRepositoryV3 {
    public String getBranchList(BranchRequestProxy branchRequest);

    public String getSingleBranch(BranchRequestProxy branchRequest);

    public String getRoBranchList(BranchRequestProxy branchRequest);

    public String getSingleRoBranch(BranchRequestProxy branchRequest);

    public String getZoBranchList(BranchRequestProxy branchRequest);

    public String getSingleZoBranch(BranchRequestProxy branchRequest);

    public String getBranchIdFromBranchCode(String branchCode, Long orgId, Integer branchType);

    
    public String getBranchCodeFromBranchId(Long branchId, Long orgId);

    public String getSingleHoBranch(BranchRequestProxy branchRequest);

    public List<Long> getBoRoIdListByZoId(Long zoId, Long roleId);

}
