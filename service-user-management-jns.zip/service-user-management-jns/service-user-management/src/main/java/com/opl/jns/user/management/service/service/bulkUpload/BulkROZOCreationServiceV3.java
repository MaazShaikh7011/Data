package com.opl.jns.user.management.service.service.bulkUpload;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.model.BulkROZOResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;

/**
 * Created by pooja.patel on 21-07-2020.
 */
public interface BulkROZOCreationServiceV3 {

    //    public Boolean extractExcel(MultipartFile multipartFile, Long orgId, Long fileId, Integer businessTypeId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId);
    public Boolean extractExcel(MultipartFile multipartFiles, Long fileId, List<Long> schemeTypelist, AuthClientResponse authClientResponse);

//    public Boolean extractExcelForZo(MultipartFile multipartFile, Long orgId, Long fileId, Integer businessTypeId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId);


    public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile, Long productMappingId);

    public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId);

    public List<BulkROZOResponseProxy> getFileEntryList(FileResponseProxy fileResponse);

    public String getROZOFileEntryCount(FileResponseProxy fileResponse);

}
