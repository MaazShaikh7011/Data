package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.opl.jns.user.management.service.domain.SchemeMaster;


public interface SchemeMasterRepositoryV3 extends JpaRepository<SchemeMaster, Long> {


    public List<SchemeMaster> findByIsActiveIsTrue();

    @Query(value="SELECT id FROM SchemeMaster u WHERE u.isActive = TRUE")
    public List<Long> getSchemeIdFromMaster();

}
