package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "tier_mapping_permission")
public class TierMappingPermission implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tier_mapping_permission_mana_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "tier_mapping_permission_mana_seq_gen", sequenceName = "tier_mapping_permission_mana_seq", allocationSize = 1)
    private Long id;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "branch_type")
    private Long branchType;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_selected")
    private Boolean isSelected;

    @Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
   	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   	private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

}
