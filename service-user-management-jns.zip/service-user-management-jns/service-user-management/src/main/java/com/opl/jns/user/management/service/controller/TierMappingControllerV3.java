package com.opl.jns.user.management.service.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.RoleMasterProxy;
import com.opl.jns.user.management.api.model.TierMappingRequestProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.service.TierMappingServiceV3;
import com.opl.jns.utils.common.CommonResponse;

/**
 * Created by dhaval.panchal on 23-08-2020.
 */
@RestController
@RequestMapping("/v3")
public class TierMappingControllerV3 {

    private static final Logger logger = LoggerFactory.getLogger(TierMappingControllerV3.class);

    @Autowired
    TierMappingServiceV3 tierMappingService;

    @PostMapping(value = "/getTierMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getTierMappingList(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
    AuthClientResponse authClientResponse) {
        logger.info("Enter in getTierMappingList");
        try {
            if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
            tierMappingRequest.setUserId(authClientResponse.getUserId());
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getTierMappingList(tierMappingRequest), "Successful getTierMappingList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getTierMappingList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getBranchCounts", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchCounts(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getBranchCounts");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getBranchCount(tierMappingRequest), "Successful getBranchCounts", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getBranchCounts ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getSingleTierMapping", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSingleTierMapping(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getTierMappingList");
        try {
            List<Long> schemeList=tierMappingService.getSchemeListByid(tierMappingRequest);
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getSingleTierMapping(tierMappingRequest), schemeList,"Successful getTierMappingList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getTierMappingList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllZoList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllZoList(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllZoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getAllZoList(tierMappingRequest), "Successful getAllZoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllLhoList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllLhoList(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllZoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getAllLhoList(tierMappingRequest), "Successful getAllZoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllRoList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllRoList(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllRoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getAllRoList(tierMappingRequest), "Successful getAllRoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllRoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/updateBranchDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> updateBranchDetails(@RequestBody BranchRequestProxy branchRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in updateBranchDetails");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.updateBranchDetails(branchRequest), "Branch Details Updated Sucessfully!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while updateBranchDetails ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/updateRoleMasterDisplayName", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<CommonResponse> updateAppOrCoAppAfterVoterSubmit(@RequestBody RoleMasterProxy commanRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authResponse) {
		try {
			Long userId = null;
			if (authResponse != null && authResponse.getUserId() != null) {
				userId = authResponse.getUserId();
			}
			if (userId == null) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("UserId can not be null or empty !!",
						HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}
			if(commanRequest.getRoleId() == null || commanRequest.getDisplayOfficeName() == null) {
				return new ResponseEntity<CommonResponse>(new CommonResponse("RoleId or name found empty !!", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
			}
			Boolean isUpdated = tierMappingService.updateDisplayName(commanRequest, userId);
			if (isUpdated) {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Data Updated successfully!", HttpStatus.OK.value(), Boolean.TRUE),
						HttpStatus.OK);
			} else {
				return new ResponseEntity<CommonResponse>(
						new CommonResponse("Something went wrong while updating data !!!", HttpStatus.OK.value(), Boolean.FALSE), HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception while updateRoleMasterDisplayName -->", e);
			return new ResponseEntity<CommonResponse>(new CommonResponse("The application has encountered some error, please try after some time", HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
    @PostMapping(value = "/getZObyROId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZObyROId(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllZoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getZObyROId(tierMappingRequest), "Successful getAllZoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PostMapping(value = "/getZObyLhoId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZObyLhoId(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getAllZoList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getZObyLhoId(tierMappingRequest), "Successful getAllZoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PostMapping(value = "/getBOROZObyId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBOROZObyId(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getBOROZObyId");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getBOROZObyId(tierMappingRequest), "Successful getAllZoList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getBObyZOId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBObyZOId(@RequestBody TierMappingRequestProxy tierMappingRequest, HttpServletRequest httpServletRequest) {
        logger.info("Enter in getBOList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getBObyZOId(tierMappingRequest), "Successful getBOList", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getAllZoList ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getBranchMappingIds/{branchId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchMappingIds(@PathVariable Long branchId, @PathVariable Long schemeId) {
        logger.info("Enter in getBranchMappingIds");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getBranchMappingIds(branchId, schemeId), "Successful getBranchMappingIds", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getBranchMappingIds ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping(value = "/getBranchMappingIdsByIfscAndSchemeId/{ifsc}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchMappingIdsByIfscAndSchemeId(@PathVariable String ifsc, @PathVariable Long schemeId) {
        logger.info("Enter in getBranchMappingIdsByIfscAndSchemeId");
        try {
            return new ResponseEntity<>(new UserResponseProxy(tierMappingService.getBranchMappingIdsByIfscAndSchemeId(ifsc, schemeId), "Successful getBranchMappingIdsByIfscAndSchemeId", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while getBranchMappingIds ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
