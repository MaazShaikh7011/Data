package com.opl.jns.user.management.service.service;

import java.util.List;
import java.util.Map;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.model.BranchROZODetailsProxy;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;

/**
 * Created by dhaval.panchal on 23-08-2020.
 */
public interface BranchServiceV3 {
    public String getBranchList(BranchRequestProxy branchRequest);

    public String getSingleBranch(BranchRequestProxy branchRequest);

    public String getRoBranchList(BranchRequestProxy branchRequest);
    
    public List<Map<String, Object>> getBONameListByRoId(BranchRequestProxy branchRequest, AuthClientResponse authClientResponse);
    
    public List<Map<String, Object>> getZONameListByZoId(BranchRequestProxy branchRequest, AuthClientResponse authClientResponse);
    
    public List<Map<String, Object>> getRONameListByZoId(BranchRequestProxy branchRequest, AuthClientResponse authClientResponse);
    
    public String getSingleRoBranch(BranchRequestProxy branchRequest);

    public String getZoBranchList(BranchRequestProxy branchRequest);

    public String getSingleZoBranch(BranchRequestProxy branchRequest);

    public UserResponseProxy saveBranchDetail(BranchRequestProxy branchRequest);

    public UserResponseProxy editBranchDetail(BranchRequestProxy branchRequest);

    public String getAllHoList(BranchRequestProxy branchRequest);

    public String getSingleHoBranch(BranchRequestProxy branchRequest);

    List<UserOrganisationMasterProxy> getOrganizationList();

	public Boolean isActiveBranch(Long branchId, Long schemeId);

	public UserResponseProxy isActiveBranchAllScheme(Long branchId, Long userId);

	public List<BranchROZODetailsProxy> getRoZoDetailsByRoZoId(Long roZoId);

    public UserResponseProxy getBranchIdList(BranchRequestProxy branchRequestProxy);

    public String getBranchName(Long branchId);

    public List<BranchRequestProxy> getAllBranchByOrgId(Long orgId);
    
    public List<Map<String, Object>> getBranchNameAndIdBySchemeAndOrgId(BranchRequestProxy branchRequestProxy);
    
    public List<Map<String, Object>> getZoListBySchemeAndOrgAndStateId(BranchRequestProxy branchRequestProxy);

    public String getBranchListByOrgAndSchemeIdAndType(String branchRequestProxy);
}
