package com.opl.jns.user.management.service.controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.api.model.BranchTypeMasterRequest;
import com.opl.jns.user.management.api.model.SchemeMasterProxy;
import com.opl.jns.user.management.api.model.UserBranchProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.api.model.UsersProxy;
import com.opl.jns.user.management.service.service.UserManagementServiceV3;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

/**
 * Created by pooja.patel on 16-08-2020.
 */
@RestController
@RequestMapping("/v3")
public class UserManagementControllerV3 {

    private static final Logger logger = LoggerFactory.getLogger(UserManagementControllerV3.class);

    @Autowired
    UserManagementServiceV3 userManagementService;

//    @RequestMapping(value = "/getUserList", method = RequestMethod.POST)
//    public ResponseEntity<UserResponseProxy> getUserList(@RequestBody UserListResponseProxy userRequest , HttpServletRequest httpServletRequest) throws Exception {
//        logger.info("Enter in getUserList");
//        Long userId = null;
//        Integer businessTypeId = Integer.valueOf(userRequest.getBusinessTypeId().toString());
//        if (!OPLUtils.isObjectNullOrEmpty(httpServletRequest.getAttribute("userId"))) {
//            userId = (Long) httpServletRequest.getAttribute("userId");
//        } else {
//            return new ResponseEntity<>(new UserResponseProxy("Invalid Request !!", HttpStatus.BAD_REQUEST.value()),
//                    HttpStatus.BAD_REQUEST);
//        }
//        try{
//            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUserList(userId,businessTypeId),"Successful get User Data", HttpStatus.OK.value()),
//                    HttpStatus.OK);
//        } catch (Exception e) {
//            logger.error("Error while check GSTIN data !!",e);
//            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
//                    HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    @PostMapping(value = "/reset_password", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> resetPassword(@RequestBody UserListResponseProxy userRequest, HttpServletRequest request) {
        logger.info("Enter in reset password");

        if (OPLUtils.isObjectNullOrEmpty(userRequest.getEmail())) {
            return new ResponseEntity<>(new UserResponseProxy("Request Parameter Null or empty", HttpStatus.BAD_REQUEST.value()),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.resetPassword(userRequest.getEmail()), "Valid Request !! ", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.warn("Error while reset password !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/updateIsLocked", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> updateIsLocked(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in update is locked user details ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            boolean result = userManagementService.updateIsLocked(userRequest);
            if (result) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("User is successfully " + (userRequest.getIsLocked() ? "Locked!" : "Unlocked!"), HttpStatus.OK.value()), HttpStatus.OK);
            } else {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Some thing went wrong.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } catch (Exception e) {
            logger.warn("Error while lock user  !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/userIsLocked", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> userIsLocked(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in update is locked user details ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            Boolean result = userManagementService.userIsLocked(userRequest.getUserId());
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("User is successfully " + (result ? "Locked!" : "Unlocked!"), HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.warn("Error while lock user  !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/userResetPassword", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> userResetPassword(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in update is locked user details ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            String result = userManagementService.userResetPassword(userRequest.getUserId());
            if (result != null) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(result, HttpStatus.OK.value()), HttpStatus.OK);
            } else {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Some thing went wrong.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } catch (Exception e) {
            logger.warn("Error while reset user Password  !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/userGenerateAndResetPassword", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> userGenerateAndResetPassword(
			@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
		try {
			logger.info("Enter in userGenerateAndResetPassword ---> ");
			if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
				return new ResponseEntity<>(
						new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()),
						HttpStatus.OK);
			}
			return new ResponseEntity<>(userManagementService.userGenerateAndResetPassword(userRequest.getUserId()),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.warn("Error while reset user Password  !!", e);
			return new ResponseEntity<>(
					new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    @PostMapping(value = "/getUserProfile", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserProfile(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in user profile details ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUserProfile(userRequest), "Successful get User Profile Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get User Profile Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @SkipInterceptor
    @PostMapping(value = "/getRoleTypeList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getRoleTypeList(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in get role type list by email address ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getEmail())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, Email Address Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getRoleTypeList(userRequest), "Successful get User Role Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get User Profile Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getNewUsersList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getNewUsersList(@RequestBody UserListResponseProxy userRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse) {
        try {
            logger.info("Enter in Get All UserList ------------------->");
            if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
//            userRequest.setUserOrgId(authClientResponse.getUserOrgId());
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getBankUsersList(userRequest), "Successful get User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @SkipInterceptor
    @PostMapping(value = "/getUserBusinessTypeList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserBusinessTypeList(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            logger.info("Enter in user business type list details ---> ");
            if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Bad Request, UserId Is Null Or Empty", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUserBusinessTypeList(userRequest), "Successful get User Business Type List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get User Business Type List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllRoleList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllRoleList(HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getAllRoleList(), "Successful get All Roles List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All Roles List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/updateUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> updateUser(@RequestBody UserListResponseProxy userRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        if (OPLUtils.isObjectNullOrEmpty(userRequest) || OPLUtils.isObjectNullOrEmpty(userRequest.getMobile())
                || OPLUtils.isObjectNullOrEmpty(userRequest.getEmail()) || OPLUtils.isObjectNullOrEmpty(userRequest.getUserRoleId())) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No email address or mobile number or User roleId found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
        try {
        	return new ResponseEntity<UserResponseProxy>(userManagementService.updateUser(userRequest, authClientResponse), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while updating or saving user!!");
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }

    }

    @PostMapping(value = "/getOfficesList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getOfficesList(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getAllOfficesList(userRequest), "Successful get User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getBranchUserDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchUserDetails(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getBranchUserDetails(userRequest), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getUserDetailsList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserDetailsList(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getSingleUserDetailList(userRequest), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getAllBOList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllBOList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getAllBOList(userListResponse), "Successful get All BO List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All BO List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getUserROList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getROList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getRoList(userListResponse), "Successful get All RO List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All RO List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getUserZOList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZOList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getZoList(userListResponse), "Successful get All ZO List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All ZO List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/getUserLHOList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getLHOList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getLHoList(userListResponse), "Successful get All ZO List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All ZO List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @SkipInterceptor
    @GetMapping(value = "/getSchemeList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSchemeList(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse ) {
        try {
            if (authClientResponse == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            } else if (authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getSchemeList(authClientResponse.getUserId()), "Successful get Scheme List", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Scheme Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping(value = "/getSchemeListForReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSchemeListForReport(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse ) {
        try {
            if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getSchemeListForReport(authClientResponse.getUserId()), "Successful get Scheme List", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Scheme Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping(value = "/getSchemeIdList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getSchemeIdList(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse ) {
        try {
            if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getSchemeIdList(authClientResponse.getUserId()), "Successful get Scheme List", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Scheme Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/checkMobile", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> checkMobile(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.checkMobile(userListResponse.getMobile()), "Successful get Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

//    @SkipInterceptor
    @PostMapping(value = "/getAllOfficeTypeList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllOfficeTypeList(HttpServletRequest httpRequest) {
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getAllOfficeTypeList(), "Successful get All Roles List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get All Roles List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/addNodalAndMinistry", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> addNodalAndMinistry(@RequestBody List<UserListResponseProxy> userRequest, HttpServletRequest httpRequest) {
        if (!OPLUtils.isListNullOrEmpty(userRequest)) {
            try {
                logger.info("Enter addNodalAndMinistry");
                CommonResponse success = userManagementService.addNodalAndMinistry(userRequest);
                return new ResponseEntity<CommonResponse>(new CommonResponse(success.getMessage(), success.getStatus()), HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while updating or saving user!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("No email address or mobile number found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getNodalAndMinistry", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getNodalAndMinistry() {
        try {
            logger.info("Enter getNodalAndMinistry");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getNodalAndMinistry(), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get getNodalAndMinistry!!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping(value = "/addFacilitatorOrUlb", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> addFacilitator(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        if (!OPLUtils.isObjectNullOrEmpty(userRequest)) {
            try {
                logger.info("Enter addFacilitat or OrUlb");
                CommonResponse success = userManagementService.addFacilitatorOrUlb(userRequest);
                return new ResponseEntity<CommonResponse>(new CommonResponse(success.getMessage(), success.getStatus()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("No email address or mobile number found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getUlbList/{createdBy}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUlbList(@PathVariable Long createdBy,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            logger.info("Enter get Ulb List");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getULBList(createdBy, authClientResponse), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getMinistryAndNAByUserId/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getMinistryAndNAByUserId(@PathVariable Long userId) {
        try {
            logger.info("Enter get Ministry And NA By UserId");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getMinistryAndNAByUserId(userId), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getMinistryBySchemeId/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getMinistryBySchemeId(@PathVariable Long schemeId) {
        try {
            logger.info("Enter get Ministry SchemeId");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getMinistryBySchemeId(schemeId), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/updateMinistryByScheme", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> updateMinistryByScheme(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest) {
        if (!OPLUtils.isObjectNullOrEmpty(userRequest)) {
            try {
                logger.info("Enter update Ministry By Scheme");
                CommonResponse success = userManagementService.updateMinistryByScheme(userRequest);
                return new ResponseEntity<CommonResponse>(new CommonResponse(success.getMessage(), success.getStatus()), HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while updating or saving user!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("No email address or mobile number found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getFacilitatorList/{createdBy}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getFacilitatorList(@PathVariable Long createdBy, @PathVariable Integer schemeId) {
        try {
            logger.info("Enter get Facilitator List");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getFacilitatorList(createdBy, schemeId), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getUlbListForNulm", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUlbList() {
        try {
            logger.info("Enter get Ulb List");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUlbListForNulm(), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping(value = "/getUlbListDistrictWise/{districtLgdCode}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUlbListDistrictWise(@PathVariable Long districtLgdCode) {
        try {
            logger.info("Enter get Ulb List");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUlbListDistrictWise(districtLgdCode), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getUlbListForEdit/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUlbListForEdit(@PathVariable Long userId) {
        try {
            logger.info("Enter get Ulb List");
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUlbListForEdit(userId), "Successful get Branch User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Branch User List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/saveUserAdmin", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> saveUserAdmin(@RequestBody UsersProxy usersProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(usersProxy)) {
            try {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(userManagementService.saveUserAdmin(usersProxy), "User is successfully Added!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No email address or mobile number found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/saveOrganization", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> saveOrganization(@RequestBody UserOrganisationMasterProxy organisationMasterProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(organisationMasterProxy)) {
            try {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(userManagementService.saveOrganization(organisationMasterProxy), "Organization is successfully Added!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No Organization found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/isActiveOrg", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> isActiveOrg(@RequestBody UserOrganisationMasterProxy organisationMasterProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(organisationMasterProxy)) {
            try {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(userManagementService.isActiveOrg(organisationMasterProxy.getUserOrgId()), "Organization is deleted successfully Added!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while updating or saving user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No Organization found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    
    @PostMapping(value = "/activeIsActiveUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> activeIsActiveUser(@RequestBody UsersProxy usersProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(usersProxy) && !OPLUtils.isObjectNullOrEmpty(usersProxy.getUserId())) {
            try {
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(userManagementService.activeIsActiveUser(usersProxy.getUserId()), "successfully Updated Flag!!", HttpStatus.OK.value()), HttpStatus.OK);
            } catch (Exception e) {
                logger.error("Error while isActive user!!");
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("No UserId found. Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getOrganisationBasicDetails/{orgId}/{branchId}/{insurerOrgId}", produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody ResponseEntity<CommonResponse> getOrganisationBasicDetails(@PathVariable Long orgId,@PathVariable Long branchId
            ,@PathVariable Long insurerOrgId, HttpServletRequest request) {

        if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
            try {
                logger.info("Enter getOrganizationName");
                BranchAndOrgDetailsProxy details = userManagementService.getOrganisationBasicDetails(orgId,branchId,insurerOrgId);
                return new ResponseEntity<CommonResponse>(new CommonResponse(details,HttpStatus.OK.getReasonPhrase(),HttpStatus.OK.value()) ,HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while getting organization!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any orgranization for this id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getOrganizationName/{orgId}", produces = {
            MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody ResponseEntity<CommonResponse> getOrganizationName(@PathVariable Long orgId,
                                                                            HttpServletRequest request) {

        if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
            try {
                logger.info("Enter getOrganizationName");
                String organizationName = userManagementService.getOrganizationName(orgId);
                return new ResponseEntity<CommonResponse>(new CommonResponse(organizationName,HttpStatus.OK.getReasonPhrase(),HttpStatus.OK.value()) ,HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while getting organization!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any orgranization for this id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }
    @GetMapping(value = "/getOrganizationCode/{orgId}", produces = {MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody ResponseEntity<CommonResponse> getOrganizationCode(@PathVariable Long orgId,HttpServletRequest request) {
        if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
            try {
                logger.info("Enter getOrganizationName");
                String organizationName = userManagementService.getOrganizationCode(orgId);
                return new ResponseEntity<CommonResponse>(new CommonResponse(organizationName,HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value()) ,HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while getting organization!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any orgranization for this id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }


    @GetMapping(value = "/getBranchType", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getBranchType() {
            try {
                logger.info("Enter getBranchType");
                return new ResponseEntity<CommonResponse>(new CommonResponse(userManagementService.getBranchType(), HttpStatus.OK.getReasonPhrase(),HttpStatus.OK.value()) ,HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while getting getBranchType!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }

    }

    @GetMapping(value = "/getBranchTypeIdsByOrgId/{orgId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getBranchTypeIdsByOrgId(@PathVariable Long orgId,
                                                        HttpServletRequest request) {
        if (!OPLUtils.isObjectNullOrEmpty(orgId)) {
            try {
                logger.info("Enter getBranchTypeIdsByOrgId");
                return new ResponseEntity<CommonResponse>(new CommonResponse(userManagementService.getBranchTypeIdsByOrgId(orgId), HttpStatus.OK.getReasonPhrase(), HttpStatus.OK.value()), HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while getting getBranchTypeIdsByOrgId!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("Not found any Branch Type for this organization id", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/saveTierConfiguration", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> saveTierConfiguration(@RequestBody List<BranchTypeMasterRequest> branchTypeMasterRequests, HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse) {
        Long orgId = authClientResponse.getUserOrgId();
        if (!OPLUtils.isListNullOrEmpty(branchTypeMasterRequests)) {
            try {
                logger.info("Enter saveTierConfiguration");
                CommonResponse success = userManagementService.saveTierConfiguration(branchTypeMasterRequests,orgId);
                return new ResponseEntity<CommonResponse>(new CommonResponse(success.getMessage(), success.getStatus()), HttpStatus.OK);

            } catch (Exception e) {
                logger.error("Error while updating or saving Tier Configuration!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<CommonResponse>(new CommonResponse("No email address or mobile number found.Invalid Request.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getAllSchemeList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllSchemeList(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse ) {
        try {

            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getAllSchemeList(), "Successful get Scheme List", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get Scheme Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping(value = "/getULBUserMapping", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getULBUserMapping(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
    	AuthClientResponse authClientResponse) {
            try{
            	logger.info("Enter getULBUserMapping");
            	if(authClientResponse == null || authClientResponse.getUserId() == null){
                    return new ResponseEntity<>(new CommonResponse("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),HttpStatus.OK);
                }
                return new ResponseEntity<CommonResponse>(new CommonResponse(
                		userManagementService.getUlbUserMappingByUserId(authClientResponse.getUserId()),
                		"Successful get ULBUserMapping Data",
                		HttpStatus.OK.value()) ,HttpStatus.OK);

            }catch(Exception e){
                logger.error("Error while fetching ULBUserMapping object!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }        
    }
    
    @GetMapping(value = "/getUserBranchDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getUserBranchDetails(HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
    	AuthClientResponse authClientResponse) {
            try{
            	logger.info("Enter getUserBranchDetails");
            	if(authClientResponse == null || authClientResponse.getUserId() == null){
                    return new ResponseEntity<>(new CommonResponse("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),HttpStatus.OK);
                }
            	if(OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserBranchId())) {
            		return new ResponseEntity<>(new CommonResponse("Branch id should not be null", HttpStatus.UNAUTHORIZED.value()),HttpStatus.OK);
            	}
            	UserBranchProxy userBranchProxy = null;
            	userBranchProxy = userManagementService.getUserBranchDetails(authClientResponse.getUserBranchId());
            	if(!OPLUtils.isObjectNullOrEmpty(userBranchProxy)) {
	                return new ResponseEntity<CommonResponse>(new CommonResponse(userBranchProxy, "Successful get User Branch Data",
	                		HttpStatus.OK.value()) ,HttpStatus.OK);            		
            	}
            	return null;
            }catch(Exception e){
                logger.error("Error while fetching User Branch object!!", e);
                return new ResponseEntity<CommonResponse>(new CommonResponse("Something Went Wrong!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }        
    }
    
    @PostMapping(value = "/getOfficesZoRoBoList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getZoRoBoOfficesList(@RequestBody UserListResponseProxy userRequest, HttpServletRequest httpRequest,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
	AuthClientResponse authClientResponse) {
        try {
        	logger.info("Enter getZoRoBoOfficesList");
        	if(authClientResponse == null || authClientResponse.getUserId() == null){
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),HttpStatus.OK);
            }
        	userRequest.setUserId(authClientResponse.getUserId());
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getOfficesZoRoBoList(userRequest), "Successful get ZoRoBo List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get ZoRoBo List Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping(value = "/getRoZoUsersList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getRoZoUsersList(@RequestBody UserListResponseProxy userRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY)
            AuthClientResponse authClientResponse) {
        try {
            logger.info("Enter in Get RoZo UserList ------------------->");
            if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()),
                        HttpStatus.OK);
            }
            userRequest.setUserId(authClientResponse.getUserId());
            userRequest.setUserOrgId(authClientResponse.getUserOrgId());
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getRoZoUsersList(userRequest), "Successful get User List Data", HttpStatus.OK.value()),
                    HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while get RoZo UserList Data !!", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/getschemeListForAdmin")
    public ResponseEntity<?> getSchemeListForAdmin(HttpServletRequest httpRequest, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse){
    	
    	try {
    		List<SchemeMasterProxy> schemeListForAdmin = userManagementService.getSchemeListForAdmin();
    		if(OPLUtils.isListNullOrEmpty(schemeListForAdmin)) {
    			logger.info("Scheme is not available ---->");
    		}
    		else {	
    			return new ResponseEntity<CommonResponse>(new CommonResponse("Successful get Scheme List", schemeListForAdmin, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
    		}
		} catch (Exception e) {
			   logger.error("Error while get Scheme Data !!", e);
			   return new ResponseEntity<>(new CommonResponse("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()),
	                    HttpStatus.INTERNAL_SERVER_ERROR);
		}
    	return null;
    }

    @SkipInterceptor
    @GetMapping(value = "/getUserTypeMasterList")
    public ResponseEntity<UserResponseProxy> getUserTypeMasterList() throws Exception {
        logger.info("Enter in Controller getUserTypeMasterList");
        try {
            return new ResponseEntity<>(new UserResponseProxy(userManagementService.getUserTypeMasterList(), "Successful get getUserTypeMasterList data", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error is getting while get getUserTypeMasterList detail ", e);
            return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    	
}
