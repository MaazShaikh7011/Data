package com.opl.jns.user.management.service.repository;

import com.opl.jns.user.management.api.model.RoleMasterProxy;
import com.opl.jns.user.management.service.domain.UserRoleMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRoleMasterRepositoryV3 extends JpaRepository<UserRoleMaster, Long> {

    UserRoleMaster findByRoleId(Long userRoleId);

    @Query(value = "select new com.opl.jns.user.management.api.model.RoleMasterProxy(urm.roleId, urm.displayName) FROM UserRoleMaster urm WHERE urm.isActive = TRUE")
    List<RoleMasterProxy> getUserRoleMasterList();

    @Query(value = "select new com.opl.jns.user.management.api.model.RoleMasterProxy(urm.roleId, urm.displayName) FROM UserRoleMaster urm WHERE  urm.isActive = TRUE AND urm.isBanker = TRUE")
	List<RoleMasterProxy> getAdminUserRoleMasterList();

   @Query(value = "select new com.opl.jns.user.management.api.model.RoleMasterProxy(urm.roleId, urm.displayName) FROM UserRoleMaster urm WHERE urm.isActive = TRUE  AND urm.roleId IN(29,30,31) ")
   List<RoleMasterProxy> getPartnerRoleMasterList();
}
