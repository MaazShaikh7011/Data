package com.opl.jns.user.management.service.repository.bulkUpload;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.BulkUserCreation;
import com.opl.jns.utils.constant.DBNameConstant;

public interface BulkUserCreationRepositoryV3 extends JpaRepository<BulkUserCreation, Long> {

    @Query(value = """
		    SELECT grptbl.totalcount, grptbl.successcount, grptbl.failcount, grptbl.fileid, bbc.created_date, bbc.original_file_name
		                  FROM (SELECT max(id) AS id, COUNT(*) AS totalcount , SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) AS successcount,  SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) AS failcount, file_id AS fileid
		                FROM jns_users.bulk_user_creation WHERE created_by_branch_id=:branchId GROUP BY file_id) grptbl
		                INNER JOIN jns_users.bulk_user_creation bbc ON bbc.file_id = grptbl.fileid AND bbc.id = grptbl.id\
		    """,nativeQuery = true)

    List<Object[]> getFileEntries(@Param("branchId") Long branchId);
    
    @Query(value = """
		    SELECT grptbl.totalcount, grptbl.successcount, grptbl.failcount, grptbl.fileid, bbc.created_date, bbc.original_file_name
		    FROM (SELECT max(id) AS id, COUNT(*) AS totalcount,
		    SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) AS successcount,
		    SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) AS failcount,
		    file_id AS fileid FROM jns_users.bulk_user_creation WHERE org_id=:orgId AND created_by_branch_id IS NULL 
		    GROUP BY file_id) grptbl 
		    INNER JOIN jns_users.bulk_user_creation bbc ON bbc.file_id = grptbl.fileid AND bbc.id = grptbl.id\
		    """,nativeQuery = true)
    List<Object[]> getFileEntriesForHO(@Param("orgId") Long orgId);

    public List<BulkUserCreation> findAllByFileId(@Param("fileId") Long fileId);
    
    public List<BulkUserCreation> findAllByFileIdAndIsActive(@Param("fileId") Long fileId, Boolean isActive);
    

    @Query(value = "SELECT JSON_ARRAYAGG(JSON_OBJECT('AdminMakerCount' value t.AdminMakerCount,'AdminCheckerCount' value t.AdminCheckerCount,\r\n"
    		+ "'HeadOfficeCount' value t.HeadOfficeCount,'ZonalOfficeCount' value t.ZonalOfficeCount,\r\n"
    		+ "'RegionOfficeCount' value t.RegionOfficeCount,\r\n"
    		+ "'BranchMakerCount' value t.BranchMakerCount,\r\n"
    		+ "'BranchCheckerCount' value t.BranchCheckerCount))\r\n"
    		+ "FROM (SELECT SUM(CASE WHEN (role = 'Admin_Maker') THEN 1 ELSE 0 END) AS AdminMakerCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Admin_Checker') THEN 1 ELSE 0 END) AS AdminCheckerCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Head_Officer') THEN 1 ELSE 0 END) AS HeadOfficeCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Zonal_Officer') THEN 1 ELSE 0 END) AS ZonalOfficeCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Regional_Officer') THEN 1 ELSE 0 END) AS RegionOfficeCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Branch_Maker') THEN 1 ELSE 0 END) AS BranchMakerCount,\r\n"
    		+ "SUM(CASE WHEN (role = 'Branch_Officer') THEN 1 ELSE 0 END) AS BranchCheckerCount \r\n"
    		+ "FROM "+DBNameConstant.JNS_USERS+".bulk_user_creation WHERE org_id =:orgId AND file_id =:fileId) t",nativeQuery = true)
    public String getUserRoleEntries(@Param("orgId") Long orgId,@Param("fileId") Long fileId);

    @Query(value = "SELECT JSON_ARRAYAGG(JSON_OBJECT('successfulCount' value t.successfulCount,\r\n"
    		+ "'failedCount' value t.failedCount,'totalCount' value t.totalCount)) \r\n"
    		+ "FROM (SELECT \r\n"
    		+ "SUM(CASE WHEN (is_active = 1) THEN 1 ELSE 0 END) AS successfulCount,\r\n"
    		+ "SUM(CASE WHEN (is_active = 0) THEN 1 ELSE 0 END) AS failedCount,\r\n"
    		+ "COUNT(*) AS totalCount\r\n"
    		+ "FROM "+DBNameConstant.JNS_USERS+".bulk_user_creation WHERE org_id =:orgId and file_id =:fileId) t",nativeQuery = true)
    public String getEntryCount(@Param("orgId") Long orgId, @Param("fileId") Long fileId);

    @Query(value = "SELECT c FROM BulkUserCreation c WHERE c.orgId=:orgId and c.fileId =:fileId")
    public List<BulkUserCreation> findAllByOrgIdAndBusinessTypeId(@Param("orgId") Long orgId, @Param("fileId") Long fileId);

    @Query(value = "SELECT bm.code FROM BranchMaster bm WHERE bm.id=:branchId")
    public String getBranchCodeFromBranchId(@Param("branchId") Long branchId);

    @Query(value = "SELECT JSON_OBJECT(\n" +
            "'successfulCount' value t.successfulCount,\n" +
            "'failedCount' value t.failedCount,\n" +
            "'totalCount' value t.totalCount)\n" +
            "FROM\n" +
            "(SELECT \n" +
            "SUM(CASE WHEN (is_active = 1) THEN 1 ELSE 0 END) AS successfulCount,\n" +
            "SUM(CASE WHEN (is_active = 0) THEN 1 ELSE 0 END) AS failedCount,\n" +
            "COUNT(*) AS totalCount\n" +
            "FROM "+ DBNameConstant.JNS_USERS+".bulk_user_creation \n" +
            "WHERE file_id =:fileId) t",nativeQuery = true)
    public String getUserFileEntryCount(@Param("fileId") Long fileId);


    @Query(value="SELECT u FROM BulkUserCreation u WHERE u.fileId =:fileId AND u.isActive = TRUE GROUP BY u.mobile")
    public List<BulkUserCreation> findIsActive(@Param("fileId") Long fileId);

}
