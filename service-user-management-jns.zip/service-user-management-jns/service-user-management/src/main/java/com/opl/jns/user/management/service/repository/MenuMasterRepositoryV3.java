package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.opl.jns.user.management.service.domain.MenuMaster;

public interface MenuMasterRepositoryV3 extends JpaRepository<MenuMaster, Long> {

	List<MenuMaster> findByIsAdminMenu(Boolean isAdminMenu);
	
	@Query("SELECT DISTINCT mm FROM MenuMaster mm INNER JOIN AdminMenuPermissionMapping rm ON rm.menuId = mm.id AND mm.isAdminMenu =TRUE AND rm.roleId IN (?1)")
	List<MenuMaster> findByRoleId(Long roleIdList);

}
