package com.opl.jns.user.management.service.repository.impl;


import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.service.repository.BranchRepositoryV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;
import com.opl.jns.utils.enums.UserRoleMaster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;


import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

import java.sql.Clob;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@Repository
public class BranchRepositoryImplV3 implements BranchRepositoryV3 {
    private static final Logger logger = LoggerFactory.getLogger(BranchRepositoryImplV3.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public String getBranchList(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spGetBranchList");
        storedProcedureQuery.registerStoredProcedureParameter("orgId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("orgId",branchRequest.getOrgId());
        storedProcedureQuery.setParameter("businessTypeId", branchRequest.getBusinessTypeId());
        return (String) storedProcedureQuery.getSingleResult();
    }


    @Override
    public String getSingleBranch(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".FETCH_SINGLE_BRANCH_DETAIL");
        storedProcedureQuery.registerStoredProcedureParameter("branchId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("branchId",branchRequest.getBranchId());
        storedProcedureQuery.setParameter("businessTypeId", branchRequest.getBusinessTypeId());
        storedProcedureQuery.execute();
        return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));    }

    @Override
    public String getRoBranchList(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spGetRoList");
        storedProcedureQuery.registerStoredProcedureParameter("orgId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("orgId",branchRequest.getOrgId());
        storedProcedureQuery.setParameter("businessTypeId", branchRequest.getBusinessTypeId());
        return (String) storedProcedureQuery.getSingleResult();
    }

    @Override
    public String getSingleRoBranch(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".FETCH_SINGLE_RO_DETAIL");
        storedProcedureQuery.registerStoredProcedureParameter("branchid",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businesstypeid",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("schemeid",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result",Clob.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("branchid",branchRequest.getBranchId());
        storedProcedureQuery.setParameter("businesstypeid", branchRequest.getBusinessTypeId());
        storedProcedureQuery.setParameter("schemeid", branchRequest.getSchemeId());
        storedProcedureQuery.execute();
        return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));    }

    @Override
    public String getZoBranchList(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spGetZoList");
        storedProcedureQuery.registerStoredProcedureParameter("branchId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("branchId",branchRequest.getBranchId());
        storedProcedureQuery.setParameter("businessTypeId", branchRequest.getBusinessTypeId());
        return (String) storedProcedureQuery.getSingleResult();
    }

    @Override
    public String getSingleZoBranch(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".FETCH_SINGLE_ZO_DETAIL");
        storedProcedureQuery.registerStoredProcedureParameter("branchid",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businesstypeid",Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result",Clob.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("branchid",branchRequest.getBranchId());
        storedProcedureQuery.setParameter("businesstypeid", branchRequest.getBusinessTypeId());
        storedProcedureQuery.execute();
        return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));    }

    @Override
    public String getBranchIdFromBranchCode(String branchCode, Long orgId, Integer branchType) {
        try {
            List<Object> branchId = entityManager.createNativeQuery("SELECT id FROM " + DBNameConstant.JNS_USERS + ".branch_master WHERE CODE =:branchCode AND org_id =:orgId AND branch_type = :branchType")
                    .setParameter("branchCode", branchCode)
                    .setParameter("orgId", orgId)
                    .setParameter("branchType", branchType)
                    .getResultList();
            Object branch = null;
            if (!OPLUtils.isListNullOrEmpty(branchId)) {
                branch = branchId.getFirst();
            }
            return !OPLUtils.isObjectNullOrEmpty(branch) ? branch.toString() : null;
        } catch (Exception e) {
            logger.error("Exception", e);

            return null;
        }
    }
    
    @Override
    public String getBranchCodeFromBranchId(Long branchId, Long orgId) {
        try {
        	logger.info("branchId--------"+branchId);
        	logger.info("orgId------"+orgId);
            List<Object> branchCode = entityManager.createNativeQuery("SELECT code FROM "+DBNameConstant.JNS_USERS+".branch_master WHERE ID =:branchId AND org_id =:orgId")
                    .setParameter("branchId", branchId)
                    .setParameter("orgId", orgId)
                    .getResultList();
            Object branch = null;
            if(!OPLUtils.isListNullOrEmpty(branchCode)){
                branch = branchCode.getFirst();
            }
            return !OPLUtils.isObjectNullOrEmpty(branch) ? branch.toString()  : null;
        }catch(Exception e){
            logger.error("Exception",e);
            return null;
        }
    }

    @Override
    public String getSingleHoBranch(BranchRequestProxy branchRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetchSingleHoDetail");
        storedProcedureQuery.registerStoredProcedureParameter("branchId",Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId",Integer.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("branchId",branchRequest.getBranchId());
        storedProcedureQuery.setParameter("businessTypeId", branchRequest.getBusinessTypeId());
        return (String) storedProcedureQuery.getSingleResult();
    }

    public List<Long> getBoRoIdListByZoId(Long zoId, Long roleId) {
        try {
            String key = UserRoleMaster.RO.getId() == roleId ? "bpm.branch_ro_id" : "bpm.branch_id";
            List<Object> idList = entityManager.createNativeQuery("SELECT DISTINCT " + key + " FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm WHERE branch_zo_id = :zoId AND " + key + " IS NOT NULL")
                    .setParameter("zoId", zoId)
                    .getResultList();
            List<Long> longIdList = new ArrayList<>(idList.size());
            for (Object id : idList) {
                longIdList.add(Long.valueOf(String.valueOf(id)));
            }
            return longIdList;
        } catch (Exception e) {
            logger.error("Exception", e);
            return Collections.emptyList();
        }
    }

}
