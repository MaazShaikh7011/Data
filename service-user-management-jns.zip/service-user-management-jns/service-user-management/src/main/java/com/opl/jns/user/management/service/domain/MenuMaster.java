package com.opl.jns.user.management.service.domain;

import java.io.Serializable;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "menu_master",indexes = {
		@Index(columnList = "is_admin_menu,is_active",name = DBNameConstant.JNS_USERS+"MNU_MST_IS_ADMIN_MENU_IS_ACTIVE")
})
public class MenuMaster implements Serializable {
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "menu_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "menu_master_mana_seq_gen", sequenceName = "menu_master_mana_seq", allocationSize = 1)
	private Long id;

	@Column(name = "key_name", columnDefinition = "varchar(200) default ''")
	private String keyName;

	@Column(name = "display_name", columnDefinition = "varchar(200) default ''")
	private String displayName;

	@Column(name = "parent_id")
	private Long parentId;
	
	private Integer sequence;

	@Column(name = "icon_path", columnDefinition = "varchar(500) default ''")
	private String iconPath;
	
	@Column(name = "type", columnDefinition = "varchar(500) default ''")
	private String type;

	@Column(name = "navigation_path", columnDefinition = "varchar(500) default ''")
	private String navigationPath;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "is_admin_menu")
	private Boolean isAdminMenu;

}
