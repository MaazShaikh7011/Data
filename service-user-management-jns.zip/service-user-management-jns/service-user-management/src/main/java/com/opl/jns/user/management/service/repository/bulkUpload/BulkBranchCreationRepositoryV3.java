package com.opl.jns.user.management.service.repository.bulkUpload;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.BulkBranchCreation;
import com.opl.jns.utils.constant.DBNameConstant;

public interface BulkBranchCreationRepositoryV3 extends JpaRepository<BulkBranchCreation, Long> {

    @Query(value = "SELECT grptbl.totalcount, grptbl.successcount, grptbl.failcount, grptbl.fileid, bbc.datetime, bbc.original_file_name\r\n"
    		+ "FROM (SELECT max(id) AS id, COUNT(*) AS totalcount,\r\n"
    		+ "SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) AS successcount,\r\n"
    		+ "SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) AS failcount,\r\n"
    		+ "file_id AS fileid FROM "+ DBNameConstant.JNS_USERS +".bulk_branch_creation WHERE created_by_branch_id= :branchId\r\n"
    		+ "GROUP BY file_id) grptbl \r\n"
    		+ "INNER JOIN "+ DBNameConstant.JNS_USERS +".bulk_branch_creation bbc ON bbc.file_id = grptbl.fileid AND bbc.id = grptbl.id\r\n"
    		+ "ORDER BY bbc.datetime DESC",nativeQuery = true)
    List<Object[]> getFileEntries(@Param("branchId") Long branchId);

    
    @Query(value = "SELECT grptbl.totalcount, grptbl.successcount, grptbl.failcount, grptbl.fileid, bbc.datetime, bbc.original_file_name\r\n"
    		+ "FROM (SELECT max(id) AS id, COUNT(*) AS totalcount,\r\n"
    		+ "SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) AS successcount,\r\n"
    		+ "SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) AS failcount,\r\n"
    		+ "file_id AS fileid FROM "+ DBNameConstant.JNS_USERS +".bulk_branch_creation WHERE org_id= :orgId AND created_by_branch_id IS NULL \r\n"
    		+ "GROUP BY file_id) grptbl \r\n"
    		+ "INNER JOIN "+ DBNameConstant.JNS_USERS +".bulk_branch_creation bbc ON bbc.file_id = grptbl.fileid AND bbc.id = grptbl.id\r\n"
    		+ "ORDER BY bbc.datetime DESC",nativeQuery = true)
    List<Object[]> getFileEntriesForHO(@Param("orgId") Long orgId);
    
    public List<BulkBranchCreation> findAllByFileId(@Param("fileId") Long fileId);
    
    public List<BulkBranchCreation> findAllByFileIdAndIsActive(@Param("fileId") Long fileId, Boolean isActive);

    @Query(value = "SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
            "'ZonalOfficeCount' value t.ZonalOfficeCount,\n" +
            "'RegionOfficeCount' value t.RegionOfficeCount,\n" +
            "'BranchCheckerCount' value t.BranchCheckerCount))\n" +
            "FROM\n" +
            "(SELECT \n" +
            "SUM(CASE WHEN (branch_type = 'Zonal Office') THEN 1 ELSE 0 END) AS ZonalOfficeCount,\n" +
            "SUM(CASE WHEN (branch_type = 'Regional Office') THEN 1 ELSE 0 END) AS RegionOfficeCount,\n" +
            "SUM(CASE WHEN (branch_type = 'Branch Office') THEN 1 ELSE 0 END) AS BranchCheckerCount \n" +
            "FROM "+DBNameConstant.JNS_USERS+".bulk_branch_creation WHERE org_id =:orgId AND business_type_id =:businessTypeId and file_id =:fileId AND is_active = 1) t",nativeQuery = true)
    public String getBranchRoleEntries(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,@Param("fileId") Long fileId);

    @Query(value = "SELECT JSON_ARRAYAGG(JSON_OBJECT(\n" +
            "'successfulCount' value t.successfulCount,\n" +
            "'failedCount' value t.failedCount,\n" +
            "'totalCount' value t.totalCount))\n" +
            "FROM\n" +
            "(SELECT \n" +
            "SUM(CASE WHEN (is_active = 1) THEN 1 ELSE 0 END) AS successfulCount,\n" +
            "SUM(CASE WHEN (is_active = 0) THEN 1 ELSE 0 END) AS failedCount,\n" +
            "COUNT(*) AS totalCount\n" +
            "FROM "+ DBNameConstant.JNS_USERS +".bulk_branch_creation \n" +
            "WHERE org_id =:orgId AND business_type_id =:businessTypeId and file_id =:fileId)  t",nativeQuery = true)
    public String getBranchEntryCount(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,@Param("fileId") Long fileId);

    @Query(value = "SELECT c FROM BulkBranchCreation c WHERE c.orgId=:orgId and c.businessTypeId=:businessTypeId and c.fileId =:fileId")
    public List<BulkBranchCreation> getAllBranchEntryList(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,@Param("fileId") Long fileId);

    @Query(value = "SELECT JSON_OBJECT(\r\n"
    		+ "'successfulCount' value t.successfulCount,\r\n"
    		+ "'failedCount' value t.failedCount,\r\n"
    		+ "'totalCount' value t.totalCount) FROM\r\n"
    		+ "(SELECT SUM(CASE WHEN (is_active = 1) THEN 1 ELSE 0 END) AS successfulCount,\r\n"
    		+ "SUM(CASE WHEN (is_active = 0) THEN 1 ELSE 0 END) AS failedCount,\r\n"
    		+ "COUNT(*) AS totalCount\r\n"
    		+ "FROM " + DBNameConstant.JNS_USERS + ".bulk_branch_creation\r\n"
    		+ "WHERE file_id =:fileId) t", nativeQuery = true)
    public String getBranchFileEntryCount(@Param("fileId") Long fileId);

}
