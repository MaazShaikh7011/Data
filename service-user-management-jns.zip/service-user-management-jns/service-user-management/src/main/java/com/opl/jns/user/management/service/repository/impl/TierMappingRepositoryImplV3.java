package com.opl.jns.user.management.service.repository.impl;

import java.math.BigInteger;
import java.sql.Clob;
import java.util.Date;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.api.model.TierMappingRequestProxy;
import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.user.management.service.repository.TierMappingRepositoryV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

@Repository
public class TierMappingRepositoryImplV3 implements TierMappingRepositoryV3 {

    private static final Logger logger = LoggerFactory.getLogger(TierMappingRepositoryImplV3.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public String getTierMappingList(TierMappingRequestProxy tierMappingRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetchTierDetail");
        storedProcedureQuery.registerStoredProcedureParameter("orgId", Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("businessTypeId", Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("type", Integer.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("fromDate", Date.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("toDate", Date.class, ParameterMode.IN);
        storedProcedureQuery.setParameter("orgId", tierMappingRequest.getOrgId());
        storedProcedureQuery.setParameter("businessTypeId", tierMappingRequest.getBusinessTypeId());
        storedProcedureQuery.setParameter("type", tierMappingRequest.getType());
        storedProcedureQuery.setParameter("fromDate", tierMappingRequest.getFromDate());
        storedProcedureQuery.setParameter("toDate", tierMappingRequest.getToDate());
        return (String) storedProcedureQuery.getSingleResult();
    }

    @Override
    public String getBranchCount(TierMappingRequestProxy tierMappingRequest) {
//        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(DBNameConstant.JNS_USERS+".spUserManagementFetch_Branch_Count_For_Tier");
//        storedProcedureQuery.registerStoredProcedureParameter("orgId", Integer.class, ParameterMode.IN);
//        storedProcedureQuery.registerStoredProcedureParameter("schemeId", Long.class, ParameterMode.IN);
//        storedProcedureQuery.setParameter("orgId", tierMappingRequest.getOrgId());
//        storedProcedureQuery.setParameter("schemeId", tierMappingRequest.getSchemeId());
//        return (String) storedProcedureQuery.getSingleResult();
        
        return (String) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(tmp.result) FROM (\n" +
				"  SELECT JSON_OBJECT('lho' VALUE SUM(CASE WHEN bm.branch_type = 6 THEN 1 ELSE 0 END),\n" +
				"  'branch' VALUE SUM(CASE WHEN bm.branch_type = 1 THEN 1 ELSE 0 END),\n" +
				"  'ro' VALUE SUM(CASE WHEN bm.branch_type = 2 THEN 1 ELSE 0 END), \n" +
				"  'zo' VALUE SUM(CASE WHEN bm.branch_type = 3 THEN 1 ELSE 0 END)) as result FROM "+ DBNameConstant.JNS_USERS +".branch_product_mapping bpm LEFT JOIN "+ DBNameConstant.JNS_USERS +".branch_master bm ON bpm.branch_id = bm.id  \n" +
				"  WHERE bm.org_id = :orgId AND bm.is_active = 1 AND bpm.sch_type_id = :schemeId\n" +
				") tmp").setParameter("orgId", tierMappingRequest.getOrgId())
		.setParameter("schemeId", tierMappingRequest.getSchemeId())
		.getSingleResult();
    }


    @Override
    public String getSingleTierMapping(TierMappingRequestProxy tierMappingRequest) {
        StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery( DBNameConstant.JNS_USERS+".Fetch_Single_Tier_Detail");
        storedProcedureQuery.registerStoredProcedureParameter("branchId", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("roId", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("zoId", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("lhoId", Long.class, ParameterMode.IN);
        storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
        storedProcedureQuery.setParameter("branchId", tierMappingRequest.getBranchId());
        if (tierMappingRequest.getRoId() == null) {
            storedProcedureQuery.setParameter("roId", -1l);
        }else{
            storedProcedureQuery.setParameter("roId", tierMappingRequest.getRoId());
        }
        if (tierMappingRequest.getZoId() == null) {
            storedProcedureQuery.setParameter("zoId", -1l);
        } else {
            storedProcedureQuery.setParameter("zoId", tierMappingRequest.getZoId());
        }
        if (tierMappingRequest.getLhoId() == null) {
            storedProcedureQuery.setParameter("lhoId", -1l);
        } else {
            storedProcedureQuery.setParameter("lhoId", tierMappingRequest.getLhoId());
        }
        logger.info("spGetSingleTierMapping("+tierMappingRequest.getBranchId()+","+tierMappingRequest.getRoId()+","+tierMappingRequest.getZoId()+","+tierMappingRequest.getLhoId()+")");
        storedProcedureQuery.execute();
        return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        }

    @Override
    public Boolean updateBranchDetails(TierMappingRequestProxy tierMappingRequest) {
        // TODO Auto-generated method stub
        try {
            entityManager.createNativeQuery("UPDATE "+DBNameConstant.JNS_USERS+".branch_product_mapping SET branch_ro_id =:branchROId, branch_zo_id =:branchZOId WHERE branch_id =:branchId AND business_type_id =:businessTypeId")
                    .setParameter("branchROId",tierMappingRequest.getRoId())
                    .setParameter("branchZOId",tierMappingRequest.getZoId())
                    .setParameter("branchId",tierMappingRequest.getBranchId())
                    .setParameter("businessTypeId",tierMappingRequest.getBusinessTypeId())
                    .executeUpdate();

            return true;
        } catch(Exception e) {
            logger.trace("Exception :-- " + e.getMessage(), e);
            return false;
        }
    }

    //    @Override
//    public String getAllZoList(Integer orgId,Integer businessTypeId) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "'zoId',a.branchId,\n" +
//                "'zoCode',a.branchCode,\n" +
//                "'zoName',a.branchName,\n" +
//                "'zoAddress',a.branchAddress,\n" +
//                "'modifiedDate',a.modifiedDate,\n" +
//                "'zoStateName',a.stateName,\n" +
//                "'zoCityName',a.cityName,\n" +
//                "'zoStateId',a.stateId,\n" +
//                "'zoCityId',a.cityId)) AS CHAR)\n" +
//                "FROM \n" +
//                "(SELECT \n" +
//                "DISTINCT(bm.id) AS branchId,\n" +
//                "bm.code AS branchCode,\n" +
//                "bm.name AS branchName,\n" +
//                "bm.street_name AS branchAddress,\n" +
//                "bm.modified_date AS modifiedDate,\n" +
//                "s.state_name AS stateName,\n" +
//                "c.city_name AS cityName,\n" +
//                "bm.state_id AS stateId,\n" +
//                "bm.city_id AS cityId\n" +
//                "FROM users.branch_product_mapping bpm \n" +
//                "LEFT JOIN users.branch_master bm ON bm.id = bpm.branch_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = TRUE  AND bm.branch_type = 3 \n" +
//                "ORDER BY bm.modified_date DESC ) AS a")
//        .setParameter("orgId", orgId)
//        .setParameter("businessTypeId", businessTypeId)
//        .getSingleResult();
//    }

//    @Override
//    public String getAllZoList(Integer orgId, List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "'zoId',a.branchId,\n" +
//                "'zoCode',a.branchCode,\n" +
//                "'zoName',a.branchName,\n" +
//                "'zoAddress',a.branchAddress,\n" +
//                "'modifiedDate',a.modifiedDate,\n" +
//                "'zoStateName',a.stateName,\n" +
//                "'zoCityName',a.cityName,\n" +
//                "'zoStateId',a.stateId,\n" +
//                "'zoCityId',a.cityId)) AS CHAR)\n" +
//                "FROM \n" +
//                "(SELECT \n" +
//                "DISTINCT(bm.id) AS branchId,\n" +
//                "bm.code AS branchCode,\n" +
//                "bm.name AS branchName,\n" +
//                "bm.street_name AS branchAddress,\n" +
//                "bm.modified_date AS modifiedDate,\n" +
//                "s.state_name AS stateName,\n" +
//                "c.city_name AS cityName,\n" +
//                "bm.state_id AS stateId,\n" +
//                "bm.city_id AS cityId\n" +
//                "    FROM users.branch_master bm\n" +
//                "INNER JOIN (\n" +
//                "SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "FROM users.branch_product_mapping bpm\n" +
////                "FROM users.branch_product_mapping bpm \n" +
////                "LEFT JOIN users.branch_master bm ON bm.id = bpm.branch_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//                "WHERE  bpm.is_active = TRUE\n" +
//                "HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 3 \n" +
//                "ORDER BY bm.modified_date DESC ) AS a")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

//    @Override
//    public String getAllZoList(Integer orgId, List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'zoId',a.branchId,\n" +
//                "                'zoCode',a.branchCode,\n" +
//                "                'zoName',a.branchName,\n" +
//                "                'zoAddress',a.branchAddress,\n" +
//                "                'modifiedDate',a.modifiedDate,\n" +
//                "                'zoStateName',a.stateName,\n" +
//                "               'zoCityName',a.cityName,\n" +
//                "                'zoStateId',a.stateId,\n" +
//                "                'zoCityId',a.cityId)) AS CHAR)\n" +
//                "                FROM \n" +
//                "                (SELECT \n" +
//                "                DISTINCT(bm.id) AS branchId,\n" +
//                "                bm.code AS branchCode,\n" +
//                "                bm.name AS branchName,\n" +
//                "                bm.street_name AS branchAddress,\n" +
//                "                bm.modified_date AS modifiedDate,\n" +
//                "                s.state_name AS stateName,\n" +
//                "                c.city_name AS cityName,\n" +
//                "                bm.state_id AS stateId,\n" +
//                "                bm.city_id AS cityId\n" +
//                "                    FROM users.branch_master bm\n" +
//                "                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//                "                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//                "                INNER JOIN (\n" +
//                "                SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "                FROM users.branch_product_mapping bpm\n" +
//                "                INNER JOIN users.branch_master bm ON bm.id = bpm.branch_id\n" +
//                "                WHERE  bpm.is_active = TRUE\n" +
//                "                HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "                WHERE  bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 3 \n" +
//                "                GROUP BY bm.id\n" +
//                "                ORDER BY bm.modified_date DESC ) AS a")
//                .setParameter("orgId", orgId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

    
//    SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//            "                                'id',a.branchId,\n" +
//            "                                'label',a.branchName,\n" +
//            "                                'zoId',a.branchId,\n" +
//            "                                'zoCode',a.branchCode,\n" +
//            "                               'zoName',a.branchName,\n" +
//            "                                'zoAddress',a.branchAddress,\n" +
//            "                                'modifiedDate',a.modifiedDate,\n" +
//            "                                'zoStateName',a.stateName,\n" +
//            "                               'zoCityName',a.cityName,\n" +
//            "                                'zoStateId',a.stateId,\n" +
//            "                                'zoCityId',a.cityId)) AS CHAR)\n" +
//            "                                FROM \n" +
//            "                                (SELECT \n" +
//            "                                DISTINCT(bm.id) AS branchId,\n" +
//            "                                bm.code AS branchCode,\n" +
//            "                                bm.name AS branchName,\n" +
//            "                                bm.street_name AS branchAddress,\n" +
//            "                                bm.modified_date AS modifiedDate,\n" +
//            "                               s.state_name AS stateName,\n" +
//            "                                c.city_name AS cityName,\n" +
//            "                                bm.state_id AS stateId,\n" +
//            "                                bm.city_id AS cityId\n" +
//            "                                FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
//            "                                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//            "                                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//            "                                INNER JOIN branch_product_mapping bpm ON bpm.branch_id = bm.id\n" +
//            "                                WHERE  bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 3 AND bpm.sch_type_id IN (:selectedScheme)\n" +
//            "                                GROUP BY bm.id\n" +
//            "                                ORDER BY bm.modified_date DESC ) AS a
    @Override
    public String getAllZoList(Integer orgId, List<Long> selectedScheme) {
		Clob clob = (Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\r\n"
						+ "'id' value a.branchId,\r\n"
						+ "'label' value a.branchName,\r\n"
						+ "'zoId' value a.branchId,\r\n"
						+ "'zoCode' value a.branchCode,\r\n"
						+ "'zoName' value a.branchName,\r\n"
						+ "'zoAddress' value a.branchAddress,\r\n"
						+ "'modifiedDate' value a.modifiedDate,\r\n"
						+ "'zoStateName' value a.stateName,\r\n"
						+ "'zoCityName' value a.cityName,\r\n"
						+ "'zoStateId' value a.stateId,\r\n"
						+ "'zoCityId' value a.cityId) RETURNING CLOB)\r\n"
						+ "FROM (SELECT \r\n"
						+ "DISTINCT(bm.id) AS branchId,\r\n"
						+ "bm.code AS branchCode,\r\n"
						+ "bm.name AS branchName,\r\n"
						+ "bm.street_name AS branchAddress,\r\n"
						+ "bm.modified_date AS modifiedDate,\r\n"
						+ "s.state_name AS stateName,\r\n"
						+ "c.city_name AS cityName,\r\n"
						+ "bm.state_id AS stateId,\r\n"
						+ "bm.city_id AS cityId\r\n"
						+ "FROM " + DBNameConstant.JNS_USERS + ".branch_master bm\r\n"
						+ "LEFT JOIN " + DBNameConstant.JNS_ONEFORM + ".city c ON c.id = bm.city_id\r\n"
						+ "LEFT JOIN " + DBNameConstant.JNS_ONEFORM + ".state s ON s.id = bm.state_id\r\n"
						+ "INNER JOIN " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\r\n"
						+ "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 3\r\n"
						+ "ORDER BY bm.MODIFIED_DATE DESC)  a")
				.setParameter("orgId", orgId)
				.setParameter("selectedScheme", selectedScheme)
				.getSingleResult();
		return OPLUtils.readClob(clob);
	}

    @Override
    public String getAllLhoList(Integer orgId, List<Long> selectedScheme) {
        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
        		" 		'id',a.branchId,\n" +
                 "                                'label',a.branchName,\n" +
                "                                'lhoId',a.branchId,\n" +
                "                                'lhoCode',a.branchCode,\n" +
                "                               'lhoName',a.branchName,\n" +
                "                                'lhoAddress',a.branchAddress,\n" +
                "                                'modifiedDate',a.modifiedDate,\n" +
                "                                'lhoStateName',a.stateName,\n" +
                "                               'lhoCityName',a.cityName,\n" +
                "                                'lhoStateId',a.stateId,\n" +
                "                                'lhoCityId',a.cityId)) AS CHAR)\n" +
                "                                FROM \n" +
                "                                (SELECT \n" +
                "                                DISTINCT(bm.id) AS branchId,\n" +
                "                                bm.code AS branchCode,\n" +
                "                                bm.name AS branchName,\n" +
                "                                bm.street_name AS branchAddress,\n" +
                "                                bm.modified_date AS modifiedDate,\n" +
                "                               s.state_name AS stateName,\n" +
                "                                c.city_name AS cityName,\n" +
                "                                bm.state_id AS stateId,\n" +
                "                                bm.city_id AS cityId\n" +
                "                                FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n" +
                "                                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
                "                                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
                "                                INNER JOIN branch_product_mapping bpm ON bpm.branch_id = bm.id\n" +
                "                                WHERE  bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 6 AND bpm.sch_type_id IN (:selectedScheme)\n" +
                "                                GROUP BY bm.id\n" +
                "                                ORDER BY bm.modified_date DESC ) AS a")
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
    }


//    @Override
//    public String getAllRoList(Integer orgId, List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "'roId',a.branchId,\n" +
//                "'roCode',a.branchCode,\n" +
//                "'roName',a.branchName,\n" +
//                "'roAddress',a.branchAddress,\n" +
//                "'modifiedDate',a.modifiedDate,\n" +
//                "'roStateName',a.stateName,\n" +
//                "'roCityName',a.cityName,\n" +
//                "'roStateId',a.stateId,\n" +
//                "'roCityId',a.cityId)) AS CHAR)\n" +
//                "FROM \n" +
//                "(SELECT \n" +
//                "DISTINCT(bm.id) AS branchId,\n" +
//                "bm.code AS branchCode,\n" +
//                "bm.name AS branchName,\n" +
//                "bm.street_name AS branchAddress,\n" +
//                "bm.modified_date AS modifiedDate,\n" +
//                "s.state_name AS stateName,\n" +
//                "c.city_name AS cityName,\n" +
//                "bm.state_id AS stateId,\n" +
//                "bm.city_id AS cityId\n" +
//                "FROM users.branch_product_mapping bpm \n" +
//                "LEFT JOIN users.branch_master bm ON bm.id = bpm.branch_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//                "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//                "WHERE  bm.org_id =:orgId AND bm.is_active = TRUE and bpm.sch_type_id IN (:selectedScheme) AND bm.branch_type = 2 \n" +
//                "ORDER BY bm.modified_date DESC ) AS a")
//                .setParameter("orgId", orgId)
////                .setParameter("businessTypeId", businessTypeId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

//    @Override
//    public String getAllRoList(Integer orgId, List<Long> selectedScheme) {
//        return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\n" +
//                "                'roId',a.branchId,\n" +
//                "                'roCode',a.branchCode,\n" +
//                "                'roName',a.branchName,\n" +
//                "                'roAddress',a.branchAddress,\n" +
//                "                'modifiedDate',a.modifiedDate,\n" +
//                "                'roStateName',a.stateName,\n" +
//                "               'roCityName',a.cityName,\n" +
//                "                'roStateId',a.stateId,\n" +
//                "                'roCityId',a.cityId)) AS CHAR)\n" +
//                "                FROM \n" +
//                "                (SELECT \n" +
//                "                DISTINCT(bm.id) AS branchId,\n" +
//                "                bm.code AS branchCode,\n" +
//                "                bm.name AS branchName,\n" +
//                "                bm.street_name AS branchAddress,\n" +
//                "                bm.modified_date AS modifiedDate,\n" +
//                "                s.state_name AS stateName,\n" +
//                "                c.city_name AS cityName,\n" +
//                "                bm.state_id AS stateId,\n" +
//                "                bm.city_id AS cityId\n" +
//                "                    FROM users.branch_master bm\n" +
//                "                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n" +
//                "                LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n" +
//                "                INNER JOIN (\n" +
//                "                SELECT bpm.branch_id AS branchId, bpm.sch_type_id AS schemeId\n" +
//                "                FROM users.branch_product_mapping bpm\n" +
//                "                INNER JOIN users.branch_master bm ON bm.id = bpm.branch_id\n" +
//                "               WHERE  bpm.is_active = TRUE\n" +
//                "                HAVING bpm.sch_type_id IN (:selectedScheme)) map ON map.branchId = bm.id\n" +
//                "                WHERE  bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 2\n" +
//                "                GROUP BY bm.id\n" +
//                "                ORDER BY bm.modified_date DESC ) AS a")
//                .setParameter("orgId", orgId)
//                .setParameter("selectedScheme", selectedScheme)
//                .getSingleResult();
//    }

    @Override
    public String getAllRoList(Integer orgId, List<Long> selectedScheme) {
		return OPLUtils.readClob((Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\r\n"
						+ "'id' value a.branchId,\r\n"
						+ "'label' value a.branchName,\r\n"
						+ "'roId' value a.branchId,\r\n"
						+ "'roCode' value a.branchCode,\r\n"
						+ "'roName' value a.branchName,\r\n"
						+ "'roAddress' value a.branchAddress,\r\n"
						+ "'modifiedDate' value a.modifiedDate,\r\n"
						+ "'roStateName' value a.stateName,\r\n"
						+ "'roCityName' value a.cityName,\r\n"
						+ "'roStateId' value a.stateId,\r\n"
						+ "'roCityId' value a.cityId)returning clob)\r\n"
						+ "FROM \r\n"
						+ "(SELECT \r\n"
						+ "distinct(bm.id) AS branchId,\r\n"
						+ "bm.code AS branchCode,\r\n"
						+ "bm.name AS branchName,\r\n"
						+ "bm.street_name AS branchAddress,\r\n"
						+ "bm.modified_date AS modifiedDate,\r\n"
						+ "s.state_name AS stateName,\r\n"
						+ "c.city_name AS cityName,\r\n"
						+ "bm.state_id AS stateId,\r\n"
						+ "bm.city_id AS cityId\r\n"
						+ "FROM " + DBNameConstant.JNS_USERS + ".branch_master bm\r\n"
						+ "LEFT JOIN " + DBNameConstant.JNS_ONEFORM + ".city c ON c.id = bm.city_id\r\n"
						+ "LEFT JOIN " + DBNameConstant.JNS_ONEFORM + ".state s ON s.id = bm.state_id\r\n"
						+ "INNER JOIN " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm ON bpm.branch_id = bm.id AND bpm.sch_type_id IN (:selectedScheme)\r\n"
						+ "WHERE  bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 2 \r\n"
						+ "ORDER BY bm.modified_date DESC ) a")
				.setParameter("orgId", orgId)
				.setParameter("selectedScheme", selectedScheme)
				.getSingleResult());
	}

    @Override
    public Boolean updateBranchProductMapping(BranchProductMapping mapping) {
        try {
            entityManager.createNativeQuery("UPDATE "+DBNameConstant.JNS_USERS+".branch_product_mapping SET branch_ro_id =:branchRoId, branch_zo_id =:branchZoId,modified_date=NOW() WHERE branch_id =:branchId AND business_id =:businessId AND sch_type_id=:schemeId AND is_active=true")
                    .setParameter("branchRoId",mapping.getBranchRoId())
                    .setParameter("branchZoId",mapping.getBranchZoId())
                    .setParameter("branchId",mapping.getBranchId())
                    .setParameter("businessId",mapping.getBusinessId())
                    .setParameter("schemeId",mapping.getSchemeId())
                    .executeUpdate();

            return true;
        } catch(Exception e) {
            logger.trace("Exception :-- " + e.getMessage(), e);
            return false;
        }
    }
    public Boolean chechBranchExist(Long branchId,Long schemeId) {
        BigInteger count =(BigInteger) entityManager
                .createNativeQuery("SELECT COUNT(*) FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping b WHERE b.branch_id=:branchId AND b.sch_type_id=:schemeId AND b.is_active=TRUE")
                .setParameter("branchId", branchId)
                .setParameter("schemeId", schemeId)
                .getSingleResult();
        return count.intValue() > 0;
    }


    public Boolean inactiveBranch(Long branchId,List<Long> schemeId,Long orgId) {
        try {
            entityManager.createNativeQuery("DELETE FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping WHERE branch_id =:branchId AND sch_type_id IN (:schemeId) AND user_org_id=:orgId")
                    .setParameter("branchId",branchId)
                    .setParameter("schemeId",schemeId)
                    .setParameter("orgId",orgId)
                    .executeUpdate();

            return true;
        } catch(Exception e) {
            logger.trace("Exception :-- " + e.getMessage(), e);
            return false;
        }
    }

    @Override
    public String getZObyROId(Long zoId, Integer orgId, List<Long> selectedScheme) {
        return (String) entityManager.createNativeQuery("""
			        SELECT JSON_ARRAYAGG(JSON_OBJECT('id' value a.branchId, 'label' value a.branchName,
			        'roId' value a.branchId,'roCode' value a.branchCode,
			        'roName' value a.branchName,'roAddress' value a.branchAddress,
			        'modifiedDate' value a.modifiedDate,
			        'roStateName' value a.stateName,'roCityName' value a.cityName,
			        'roStateId' value a.stateId,'roCityId' value a.cityId)) FROM 
			        (SELECT DISTINCT(bm2.id) AS branchId,bm2.code AS branchCode,bm2.name AS branchName,
			        bm2.street_name AS branchAddress, bm2.modified_date AS modifiedDate, s.state_name AS stateName,
			        c.city_name AS cityName, bm2.state_id AS stateId,bm2.city_id AS cityId
			        from JNS_USERS.branch_master bm2
			        LEFT JOIN JNS_ONEFORM.city c ON c.id = bm2.city_id 
			        LEFT JOIN JNS_ONEFORM.state s ON s.id = bm2.state_id 
			        where bm2.id in (select bm.id as branchId 
			        FROM JNS_USERS.branch_master bm
			        LEFT JOIN JNS_USERS.branch_product_mapping bpm ON bpm.branch_id = bm.id
			        WHERE bm.id IN (SELECT DISTINCT(branch_id) FROM JNS_USERS.branch_product_mapping wHERE branch_zo_id =:zoId)
			        AND bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 2 AND bpm.sch_type_id IN (:selectedScheme) 
			        GROUP BY bm.id
			        )ORDER BY bm2.modified_date DESC ) a\
			        """)
                .setParameter("zoId",zoId)
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
    }

	@Override
	public String getZObyLhoId(Long lhoId, Integer orgId, List<Long> selectedScheme) {
		return (String) entityManager.createNativeQuery("SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT(\r\n"
				+ "'id',a.branchId,\r\n"
				+ "'label',a.branchName,\r\n"
				+ "'zoId',a.branchId,\r\n"
				+ "'zoCode',a.branchCode,\r\n"
				+ "'zoName',a.branchName,\r\n"
				+ "'zoAddress',a.branchAddress,\r\n"
				+ "'modifiedDate',a.modifiedDate,\r\n"
				+ "'zoStateName',a.stateName,\r\n"
				+ "'zoCityName',a.cityName,\r\n"
				+ "'zoStateId',a.stateId,\r\n"
				+ "'zoCityId',a.cityId)) AS CHAR)\r\n"
				+ "FROM\r\n"
				+ "(SELECT\r\n"
				+ "DISTINCT(bm.id) AS branchId,\r\n"
				+ "bm.code AS branchCode,\r\n"
				+ "bm.name AS branchName,\r\n"
				+ "bm.street_name AS branchAddress,\r\n"
				+ "bm.modified_date AS modifiedDate,\r\n"
				+ "s.state_name AS stateName,\r\n"
				+ "c.city_name AS cityName,\r\n"
				+ "bm.state_id AS stateId,\r\n"
				+ "bm.city_id AS cityId\r\n"
				+ "FROM "+DBNameConstant.JNS_USERS+".branch_master bm\r\n"
				+ "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\r\n"
				+ "LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\r\n"
				+ "LEFT JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id\r\n"
				+ "WHERE bm.id IN (SELECT DISTINCT(branch_id) FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping WHERE branch_lho_id =:lhoId) AND bm.org_id =:orgId AND bm.is_active = TRUE AND bm.branch_type = 3 AND bpm.sch_type_id IN (:selectedScheme)\r\n"
				+ "GROUP BY bm.id\r\n"
				+ "ORDER BY bm.modified_date DESC ) AS a")
                .setParameter("lhoId",lhoId)
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult();
	}
	
	@Override
	public String getBOROZObyId(Long branchId,Long userRoleId,Integer orgId, List<Long> selectedScheme) {
		return OPLUtils.readClob((Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\n"
				+ "				'id' value a.branchId,\n"
				+ "				'label' value a.branchName,\n"
				+ "				'branchId' value a.branchId,\n"
				+ "				'branchCode' value a.branchCode,\n"
				+ "				'branchName' value a.branchName,\n"
				+ "				'zoAddress' value a.branchAddress,\n"
				+ "				'modifiedDate' value a.modifiedDate,\n"
				+ "				'zoStateName' value a.stateName,\n"
				+ "				'zoCityName' value a.cityName,\n"
				+ "				'zoStateId' value a.stateId,\n"
				+ "				'zoCityId' value a.cityId)returning clob)\n"
				+ "				FROM\n"
				+ "				(SELECT\n"
				+ "				DISTINCT(bm.id) AS branchId,\n"
				+ "				bm.code AS branchCode,\n"
				+ "				bm.name AS branchName,\n"
				+ "				bm.street_name AS branchAddress,\n"
				+ "				bm.modified_date AS modifiedDate,\n"
				+ "				s.state_name AS stateName,\n"
				+ "				c.city_name AS cityName,\n"
				+ "				bm.state_id AS stateId,\n"
				+ "				bm.city_id AS cityId\n"
				+ "				FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id\n"
				+ "				WHERE bm.id IN (SELECT DISTINCT(branch_id) FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping WHERE case when 14 =:userRoleId then branch_zo_id when 13 =:userRoleId then branch_ro_id else branch_lho_id end =:branchId)\n"
				+ "                AND bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = case when 13 =:userRoleId then 1 when 14 =:userRoleId then 2 else 3 end AND bpm.sch_type_id IN (:selectedScheme)\n"
				+ "				ORDER BY bm.modified_date DESC) a")

                .setParameter("branchId",branchId)
                .setParameter("userRoleId", userRoleId)
                .setParameter("orgId", orgId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult());
	}
	
	
	@Override
	public String getBObyZOId(Long branchId,Long userRoleId,Integer orgId,Integer businessTypeId, List<Long> selectedScheme) {
		return OPLUtils.readClob((Clob) entityManager.createNativeQuery("SELECT JSON_ARRAYAGG(JSON_OBJECT(\n"
				+ "				'id' VALUE a.branchId,\n"
				+ "				'label' VALUE a.branchName,\n"
				+ "				'branchId' VALUE a.branchId,\n"
				+ "				'branchCode' VALUE a.branchCode,\n"
				+ "				'branchName' VALUE a.branchName,\n"
				+ "				'zoAddress' VALUE a.branchAddress,\n"
				+ "				'modifiedDate' VALUE a.modifiedDate,\n"
				+ "				'zoStateName' VALUE a.stateName,\n"
				+ "				'zoCityName' VALUE a.cityName,\n"
				+ "				'zoStateId' VALUE a.stateId,\n"
				+ "				'zoCityId' VALUE a.cityId)returning clob)\n"
				+ "				FROM\n"
				+ "				(SELECT\n"
				+ "				DISTINCT(bm.id) AS branchId,\n"
				+ "				bm.code AS branchCode,\n"
				+ "				bm.name AS branchName,\n"
				+ "				bm.street_name AS branchAddress,\n"
				+ "				bm.modified_date AS modifiedDate,\n"
				+ "				s.state_name AS stateName,\n"
				+ "				c.city_name AS cityName,\n"
				+ "				bm.state_id AS stateId,\n"
				+ "				bm.city_id AS cityId\n"
				+ "				FROM "+DBNameConstant.JNS_USERS+".branch_master bm\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".city c ON c.id = bm.city_id\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_ONEFORM+".state s ON s.id = bm.state_id\n"
				+ "				LEFT JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm ON bpm.branch_id = bm.id\n"
				+ "				WHERE bm.org_id = :orgId AND bm.is_active = 1 AND bpm.business_id = :businessTypeId AND bpm.sch_type_id IN (:selectedScheme) AND bm.branch_type = 1 AND bm.id IN ( SELECT DISTINCT bpm.branchId  FROM (\n"
				+ "											SELECT DISTINCT bpmp1.branch_id AS branchId , bm.branch_type AS branchTypeId\n"
				+ "											FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping bpmp1\n"
				+ "											INNER JOIN "+DBNameConstant.JNS_USERS+".branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = 1 AND sch_type_id IN (:selectedScheme)\n"
				+ "											WHERE bpmp1.branch_zo_id = :branchId AND bpmp1.sch_type_id IN (:selectedScheme)\n"
				+ "											UNION ALL\n"
				+ "											SELECT DISTINCT bpmp.branch_id AS branchId, bm.branch_type AS branchTypeId\n"
				+ "											FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping bpmp1\n"
				+ "											INNER JOIN "+DBNameConstant.JNS_USERS+".branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id IN (:selectedScheme)\n"
				+ "											INNER JOIN "+DBNameConstant.JNS_USERS+".branch_master bm ON bm.id = bpmp.branch_id AND branch_type = 1\n"
				+ "											WHERE bpmp1.branch_zo_id = :branchId AND bpmp1.sch_type_id IN (:selectedScheme)\n"
				+ "									) bpm )\n"
				+ "				ORDER BY bm.modified_date DESC ) a")
                .setParameter("branchId",branchId)
                .setParameter("orgId", orgId)
                .setParameter("businessTypeId", businessTypeId)
                .setParameter("selectedScheme", selectedScheme)
                .getSingleResult());
	}

	@Override
	public String getBranchMappingIds(Long branchId, Long schemeId) {
		return (String) entityManager.createNativeQuery("SELECT JSON_OBJECT('branchRoId' VALUE bpm.branch_ro_id, 'branchZoId' VALUE bpm.branch_zo_id, 'branchLhoId' VALUE bpm.branch_lho_id, 'stateId' VALUE  bm.state_id,'branchCode' VALUE  bm.code, 'cityId' VALUE bm.city_id,'branchIfsc' VALUE bm.ifsc_code, 'ruralUrbanId' VALUE bm.rural_urban_id) AS res FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm INNER JOIN "+DBNameConstant.JNS_USERS+".branch_master bm ON bm.id = bpm.branch_id WHERE bpm.branch_id = :branchId AND sch_type_id = :schemeId OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY")
				.setParameter("branchId",branchId)
				.setParameter("schemeId", schemeId)
				.getSingleResult();
	}
	
	@Override
	public String getBranchMappingByIfscCodeAndSchemeId(String ifsc, Long schemeId) {
		return (String) entityManager.createNativeQuery("SELECT JSON_OBJECT('branchId' VALUE bm.id,'branchRoId' VALUE bpm.branch_ro_id, 'branchZoId' VALUE bpm.branch_zo_id, 'branchLhoId' VALUE bpm.branch_lho_id, 'stateId' VALUE  bm.state_id,'branchCode' VALUE  bm.code, 'cityId' VALUE bm.city_id, 'ruralUrbanId' VALUE bm.rural_urban_id) AS res FROM "+DBNameConstant.JNS_USERS+".branch_product_mapping bpm INNER JOIN "+DBNameConstant.JNS_USERS+".branch_master bm ON bm.id = bpm.branch_id WHERE bm.ifsc_code = :ifscCode AND sch_type_id = :schemeId OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY")
				.setParameter("ifscCode",ifsc)
				.setParameter("schemeId", schemeId)
				.getSingleResult();
	}

}
