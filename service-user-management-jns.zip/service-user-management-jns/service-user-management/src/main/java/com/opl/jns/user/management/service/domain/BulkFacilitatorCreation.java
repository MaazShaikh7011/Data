package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.common.EncryptionUtilsOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bulk_facilitator_creation")
public class BulkFacilitatorCreation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_facilitator_creation_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "bulk_facilitator_creation_mana_seq_gen", sequenceName = "bulk_facilitator_creation_mana_seq", allocationSize = 1)
	private Long id;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "email", columnDefinition = "varchar(200) default ''")
	private String email;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "mobile", columnDefinition = "varchar(20) default ''")
	private String mobile;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "first_name", columnDefinition = "varchar(200) default ''")
	private String firstName;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "middle_name", columnDefinition = "varchar(200) default ''")
	private String middleName;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "last_name", columnDefinition = "varchar(200) default ''")
	private String lastName;

	@Column(name = "role_id")
	private Long role;

	@Column(name = "branch_id", columnDefinition = "varchar(200) default ''")
	private String branchId;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "business_type_id")
	private Integer businessTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "msg", columnDefinition = "varchar(600) default ''")
	private String message;

	@Column(name = "file_id")
	private Long fileId;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Column(name = "branch_code", columnDefinition = "varchar(200) default ''")
	private String branchCode;

	@Column(name = "user_type_id", columnDefinition = "varchar(200) default ''")
	private String userTypeId;
}
