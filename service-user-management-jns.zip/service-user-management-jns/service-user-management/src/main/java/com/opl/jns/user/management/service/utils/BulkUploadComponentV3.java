package com.opl.jns.user.management.service.utils;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.opl.jns.user.management.service.domain.BranchMaster;
import com.opl.jns.user.management.service.domain.User;
import com.opl.jns.user.management.service.domain.UserOrganisationMaster;
import com.opl.jns.user.management.service.domain.UserRoleProductMapping;
import com.opl.jns.user.management.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UsersRepositoryV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BulkUploadComponentV3 {

    @Autowired
    private UsersRepositoryV3 userRepo;

    @Autowired
    UserRoleMasterRepositoryV3 userRoleMasterRepo;

    @Autowired
    UserTypeMasterRepositoryV3 userTypeRepo;

    @Autowired
    UserRoleProductMappingRepositoryV3 roleProductMapping;

    @Value("${cw.user.default.password}")
    private String defaultPwd;

    public BulkUploadUserExistProxyV3 checkEmailOrMobileExist(String email, String mobile) {
        // CHECK EMAIL OR MOBILE IS DUBLICATE OR NOT
        log.info("Email:-->"+email);
        User emailExist = null;
        if(!OPLUtils.isObjectNullOrEmpty(email)) {
            log.info("Check email exist");
            emailExist = userRepo.emailExist(email, UserTypeMaster.FUNDPROVIDER.getId());
            if(emailExist != null) {
                // CHECK CURRENT USER HAS SAME MOBILE NUMBER OR NOT
                if(!OPLUtils.isObjectNullOrEmpty(mobile) && !OPLUtils.isObjectNullOrEmpty(emailExist.getMobile()) && !emailExist.getMobile().equalsIgnoreCase(mobile)){
                    return BulkUploadUserExistProxyV3.builder().isActive(false)
                            .message("This mobile is not assign with given email address.").user(emailExist)
                            .build();
                } else if(!OPLUtils.isObjectNullOrEmpty(mobile) && OPLUtils.isObjectNullOrEmpty(emailExist.getMobile())){
                    return BulkUploadUserExistProxyV3.builder().isActive(false)
                            .message("This mobile is not assign with given email address.").user(emailExist)
                            .build();
                } else if(OPLUtils.isObjectNullOrEmpty(mobile) && !OPLUtils.isObjectNullOrEmpty(emailExist.getMobile())){
                    return BulkUploadUserExistProxyV3.builder().isActive(false)
                            .message("This email address has different mobile number").user(emailExist)
                            .build();
                }
            }
        }
        // CHECK MOBILE DUBLICATION IF REQUEST MOBILE IS NOT NULL
        if(emailExist == null && !OPLUtils.isObjectNullOrEmpty(mobile)) {
            log.info("Check mobile exist");
            emailExist = userRepo.mobileExist(mobile,UserTypeMaster.FUNDPROVIDER.getId());
            if(emailExist != null) {
                if(!OPLUtils.isObjectNullOrEmpty(email) && !OPLUtils.isObjectNullOrEmpty(emailExist.getEmail()) && !emailExist.getEmail().equalsIgnoreCase(email)){
                    return BulkUploadUserExistProxyV3.builder().isActive(false)
                            .message("This email is not assign with given mobile number.").user(emailExist)
                            .build();
                } else if(!OPLUtils.isObjectNullOrEmpty(email) && OPLUtils.isObjectNullOrEmpty(emailExist.getEmail())){
                    return BulkUploadUserExistProxyV3.builder().isActive(false)
                            .message("This email is not assign with given mobile number.").user(emailExist)
                            .build();
                } else if(OPLUtils.isObjectNullOrEmpty(email) && !OPLUtils.isObjectNullOrEmpty(emailExist.getEmail())){
                    return BulkUploadUserExistProxyV3.builder().isActive(false).user(emailExist)
                            .message("This mobile number has different email address")
                            .build();
                }
            }
        }
        if(emailExist != null) {
            return BulkUploadUserExistProxyV3.builder().isActive(true)
                    .message("User is already exists").user(emailExist)
                    .build();
        }
        return BulkUploadUserExistProxyV3.builder().isActive(true)
                .message("User not found")
                .build();
    }

    public User createUser(String email, String mobile, String firstName, String lastName,
                            String role, Long orgId, Long branchId) {
        User user = new User();
        try {
            user.setEmail(email);
            user.setMobile(mobile);
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setIsActive(Boolean.TRUE);
            user.setCreatedDate(new Date());
            user.setSignUpDate(new Date());
            // SET PASS
            user.setPassword(defaultPwd);
            user.setIsPassChanged(Boolean.FALSE);
            user.setTermsAccepted(Boolean.TRUE);
            user.setEmailVerified(Boolean.TRUE);
            user.setOtpVerified(Boolean.TRUE);

            user.setUserOrgId(new UserOrganisationMaster(orgId));
            if (role.equalsIgnoreCase("Head_Officer")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.HEAD_OFFICE.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
            }
            if (role.equalsIgnoreCase("Branch_Officer")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.BRANCH_CHECKER.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
                user.setBranchId(new BranchMaster(branchId));
            }
            if (role.equalsIgnoreCase("Regional_Officer")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.RO.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
                user.setBranchId(new BranchMaster(branchId));
            }
            if (role.equalsIgnoreCase("Zonal_Officer")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.ZO.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
                user.setBranchId(new BranchMaster(branchId));
            }
            if (role.equalsIgnoreCase("Admin_Maker")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.ADMIN_MAKER.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
            }
            if (role.equalsIgnoreCase("Admin_Checker")) {
                user.setUserRoleId( new com.opl.jns.user.management.service.domain.UserRoleMaster(UserRoleMaster.ADMIN_CHECKER.getId()));
                user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
            }
            return userRepo.saveAndFlush(user);
        } catch (Exception e){
            log.error("Exception while save scheme wise user entry ",e);
        }
        return user;
    }

   // @Async
    public void createUserAndUserSchemeMapping(String email, String mobile, String firstName, String lastName,
                                               String role, Long orgId, Long branchId, List<Long> schemeList, User user) {
        if(user == null) {
            user = createUser(email, mobile, firstName, lastName, role, orgId, branchId);
        }
        // FETCH USER ROLE PRODUCT MAPPING LIST TO CHECK DUBLICATION OF ROLE AND SCHEME MAPPING
        List<UserRoleProductMapping> userRoleProductMappings = new ArrayList<>(schemeList.size());
        UserRoleProductMapping roleMapping = null;
        for(Long schemeId : schemeList)  {
            // UPDATE ROLE PRODUCT MAPPING
            SchemeMaster scheme = SchemeMaster.getById(schemeId);
            roleMapping = new UserRoleProductMapping();
            roleMapping.setUser(new User(user.getUserId()));
            roleMapping.setUserRoleMaster(user.getUserRoleId());
            roleMapping.setBusinessId(scheme.getBussinessTypeId().longValue());
            roleMapping.setIsActive(Boolean.TRUE);
            roleMapping.setSchemeId(scheme.getId());
            roleMapping.setCreatedDate(new Date());
            roleMapping.setModifiedDate(new Date());
            userRoleProductMappings.add(roleMapping);
        }
        roleProductMapping.saveAll(userRoleProductMappings);
    }

}
