package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_file_upload_history")
public class UserFileUploadHistory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_file_upload_history_man_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "user_file_upload_history_man_seq_gen", sequenceName = "user_file_upload_history_man_seq", allocationSize = 1)
	private Long id;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "file_type")
	private Long fileType;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Column(name = "file_name",columnDefinition = "varchar(200) default ''")
	private String fileName;

	@Column(name = "succuss_entry")
	private Integer succussEntry;

	@Column(name = "failed_entry")
	private Integer failedEntry;

	@Column(name = "total_entry")
	private Integer totalEntry;
	
	@Column(name = "dms_file_id")
	private Long fileId;
	
	@Column(name = "created_by")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
   	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   	private Date createdDate;
	
	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "modified_date")
   	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   	private Date modifiedDate;
	
	@Column(name = "is_active")
	private Boolean isActive;

}
