package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_permission_master",indexes = {
		@Index(columnList = "is_global,is_active",name = DBNameConstant.JNS_USERS+"usr_perm_mst_is_global_is_active"),
		@Index(columnList = "group_id,is_active",name = DBNameConstant.JNS_USERS+"usr_perm_mst_group_id_is_active"),
		@Index(columnList = "admin_menu_id,group_id",name = DBNameConstant.JNS_USERS+"usr_perm_mst_admin_menu_id_group_id")
})
public class UserPermissionMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_permission_master_man_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_permission_master_man_seq_gen", sequenceName = "user_permission_master_man_seq", allocationSize = 1)
	private Long id;

	@Column(name = "name", columnDefinition = "varchar(200) default ''")
	private String name;

	@Column(name = "alias", columnDefinition = "varchar(100) default ''")
	private String alias;

	@Column(name = "group_id")
	private Long groupId;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "loan_type_id")
	private Integer loanTypeId;
	
	@Column(name = "admin_menu_id")
	private Integer adminMenuId;

	@Column(name = "is_global")
	private Boolean isGlobal;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "created_by")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "modified_by")
	private Long modifiedBy;

}
