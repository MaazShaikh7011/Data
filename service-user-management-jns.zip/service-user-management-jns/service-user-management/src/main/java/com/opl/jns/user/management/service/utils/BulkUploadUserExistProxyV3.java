package com.opl.jns.user.management.service.utils;

import com.opl.jns.user.management.service.domain.User;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = false)
public class BulkUploadUserExistProxyV3 {

    private Boolean isActive;
    private String message;
    private User user;

    public BulkUploadUserExistProxyV3(Boolean isActive, String message) {
        this.isActive = isActive;
        this.message = message;
    }

}
