package com.opl.jns.user.management.service.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.transaction.Transactional;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.method.CommonMethods;
import com.opl.jns.user.management.api.model.AdminRequest;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.api.model.BranchTypeMasterRequest;
import com.opl.jns.user.management.api.model.SchemeMasterProxy;
import com.opl.jns.user.management.api.model.UlbDistrictMappingProxy;
import com.opl.jns.user.management.api.model.UlbUserProxy;
import com.opl.jns.user.management.api.model.UserBranchProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.api.model.UserTypeMasterProxy;
import com.opl.jns.user.management.api.model.UsersProxy;
import com.opl.jns.user.management.service.domain.BranchMaster;
import com.opl.jns.user.management.service.domain.BranchTypeMaster;
import com.opl.jns.user.management.service.domain.BusinessMaster;
import com.opl.jns.user.management.service.domain.TierMappingPermission;
import com.opl.jns.user.management.service.domain.UlbDistrictMapping;
import com.opl.jns.user.management.service.domain.UlbUserMapping;
import com.opl.jns.user.management.service.domain.User;
import com.opl.jns.user.management.service.domain.UserOrganisationMaster;
import com.opl.jns.user.management.service.domain.UserPasswordChangeLog;
import com.opl.jns.user.management.service.domain.UserRoleProductMapping;
import com.opl.jns.user.management.service.repository.BranchMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchTypeMasterRepoV3;
import com.opl.jns.user.management.service.repository.BusinessMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.SchemeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.TierMappingPermissionRepoV3;
import com.opl.jns.user.management.service.repository.UlbDistrictMappingRepoV3;
import com.opl.jns.user.management.service.repository.UlbUserMappingRepoV3;
import com.opl.jns.user.management.service.repository.UserManagementRepositoryV3;
import com.opl.jns.user.management.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserPasswordChangeLogRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UsersRepositoryV3;
import com.opl.jns.user.management.service.service.UserManagementServiceV3;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.ObjectConvertMaster;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

/**
 * Created by pooja.patel on 16-08-2020.
 */
@Service
@Transactional
public class UserManagementServiceImplV3 implements UserManagementServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(UserManagementServiceImplV3.class);

	@Autowired
    UserManagementRepositoryV3 userManagementRepository;

	@Autowired
    UsersRepositoryV3 userRepo;

	@Autowired
    UserOrganisationMasterRepositoryV3 userOrganisationMasterRepository;

	@Autowired
    UserTypeMasterRepositoryV3 userTypeMasterRepository;

	@Autowired
    UserRoleMasterRepositoryV3 userRoleMasterRepo;

	@Autowired
	BranchMasterRepositoryV3 branchMasterRepo;

	@Autowired
	UserRoleProductMappingRepositoryV3 roleProductRepo;

	@Autowired
	SchemeMasterRepositoryV3 schemeMasterRepo;

	@Value("${cw.user.default.password}")
	private String defaultPwd;

	@Autowired
	private UlbDistrictMappingRepoV3 ulbDistrictMappingRepo;

	@Autowired
	private UlbUserMappingRepoV3 ulbUserMappingRepo;

	@Autowired
	BranchTypeMasterRepoV3 branchTypeMasterRepo;

	@Autowired
	TierMappingPermissionRepoV3 tierMappingPermissionRepo;
	
	@Autowired
	BusinessMasterRepositoryV3 businessMasterRepository;
	
	@Autowired
	private UserPasswordChangeLogRepositoryV3 passwordChangeLogRepository;

//    public List<UserListResponseProxy> getUserList(Long userId, Integer businessTypeId) {
//        List<Object[]> objList = userManagementRepository.getUserList(userId,businessTypeId);
//        if(objList.isEmpty()) {
//            return Collections.emptyList();
//        }
//        List<UserListResponseProxy> userList = new ArrayList<>(objList.size());
//        UserListResponseProxy userResp = null;
//        for(Object[] obj : objList) {
//            userResp = new UserListResponseProxy();
//            userResp.setUserId(UserCreationUtil.convertLong(obj[0]));
//            userResp.setEmail(UserCreationUtil.convertString(obj[1]));
//            userResp.setMobile(UserCreationUtil.convertString(obj[2]));
//            userResp.setSignupDate(UserCreationUtil.convertDate(obj[3]));
//            userResp.setIsActive(UserCreationUtil.convertBoolean(obj[4]));
//            userResp.setBranchName(UserCreationUtil.convertString(obj[5]));
//            userResp.setBranchCode(UserCreationUtil.convertString(obj[6]));
//            userResp.setCity(UserCreationUtil.convertString(obj[7]));
//            userResp.setState(UserCreationUtil.convertString(obj[8]));
//            userResp.setUserType(UserCreationUtil.convertString(obj[9]));
//            userResp.setIsLocked(UserCreationUtil.convertBoolean(obj[10]));
//            userResp.setLastLoginDate(UserCreationUtil.convertDate(obj[11]));
//            userList.add(userResp);
//        }
//        return userList;
//    }

	@Override
	public String resetPassword(String email) {
		try {
			return userManagementRepository.resetPassword(email);
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public boolean updateIsLocked(UserListResponseProxy userRequest) {
		try {
			User user = userRepo.findByUserId(userRequest.getUserId());
			user.setIsLocked(userRequest.getIsLocked());
			if (userRequest.getIsLocked()) {
				user.setIsActive(false);
				user.setUserLockedDate(new Date());
			} else {
				user.setLoginCounter(0);
				user.setIsActive(true);
				user.setUserUnlockedDate(new Date());
			}
			return true;
		} catch (Exception e) {
			return false;
		}

		// return userManagementRepository.updateIsLocked(userRequest.getUserId(),
		// userRequest.getIsLocked());
	}

	@Override
	public boolean userIsLocked(Long userId) {
		try {
			User user = userRepo.findByUserId(userId);
			if (user.getIsLocked()) {
				user.setIsLocked(Boolean.FALSE);
				user.setLoginCounter(0);
				user.setUserUnlockedDate(new Date());
				return Boolean.FALSE;
			} else {
				user.setIsLocked(Boolean.TRUE);
				user.setUserLockedDate(new Date());
				return Boolean.TRUE;
			}
		} catch (Exception e) {
			logger.error("Exception is getting While update Is Lock Flag");
		}
		return false;
	}

	@Override
	public String userResetPassword(Long userId) {
		try {
		
			return userManagementRepository.spResetUserPassword(userId);
		} catch (Exception e) {
			logger.error("Exception is getting While Reset User Password");
		}
		return null;
	}

	@Override
	public String getUserProfile(UserListResponseProxy userListResponse) {
		try {
			return userManagementRepository.getUserProfile(userListResponse.getUserId(),
					userListResponse.getBusinessTypeId());
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public String getRoleTypeList(UserListResponseProxy userListResponse) {
		try {
			return userManagementRepository.getRoleTypeList(userListResponse.getEmail());
		} catch (Exception e) {
			logger.error("Exception while get role type list  :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public String getUserBusinessTypeList(UserListResponseProxy userListResponse) {
		try {
			return userManagementRepository.getUserBusinessTypeList(userListResponse.getUserId());
		} catch (Exception e) {
			logger.error("Exception while get user business type list by user id  :- " + userListResponse.getUserId(),
					e);
		}
		return null;
	}

	@Override
	public String getBankUsersList(UserListResponseProxy userListResponse) {
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(userListResponse.getColumnFilter());
			logger.info("CALL users.SP_USERMANAGEMENT_BANKUSERS_LIST({}, {}, {}, {}, {}, {}, {}, '{}')",userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(),
					userListResponse.getRoleType(), userListResponse.getNoPagination(),
					userListResponse.getPaginationFROM(), userListResponse.getPaginationTO(),
					userListResponse.getSchemeId(), json);

//			return userRepo.spUserManagementBankUsersList(userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(),
//					userListResponse.getRoleType(), userListResponse.getNoPagination(),
//					userListResponse.getPaginationFROM(), userListResponse.getPaginationTO(),
//					userListResponse.getSchemeId(), json);
			
			return userManagementRepository.spUserManagementBankUsersList(userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(),
					userListResponse.getRoleType(), userListResponse.getNoPagination(),
					Integer.valueOf(userListResponse.getPaginationFROM()), Integer.valueOf(userListResponse.getPaginationTO()),
					userListResponse.getSchemeId(), json);
			
		} catch (Exception e) {
			logger.error("Exception while get user list  :- ", e);
		}
		return null;
	}

	@Override
	public String getAllRoleList() {
		try {
			return userManagementRepository.getAllRoles();
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public UserResponseProxy updateUser(UserListResponseProxy userRequest, AuthClientResponse authClientResponse) {
		try {
			// Check User duplication
			User emailObj = userRepo.findOneByEmailAndUserTypeMasterId(userRequest.getEmail(), authClientResponse.getUserType());
			
			User mobileObj = userRepo.findOneByMobileAndUserTypeMasterId(userRequest.getMobile(), authClientResponse.getUserType());
			
			User userObj = null;
			if (!OPLUtils.isObjectNullOrEmpty(emailObj) && !OPLUtils.isObjectNullOrEmpty(mobileObj)) {
				if (emailObj.getUserId() != mobileObj.getUserId()) {
					return new UserResponseProxy("email or mobile already exists!!", HttpStatus.NO_CONTENT.value());
				} else if (!OPLUtils.isObjectNullOrEmpty(emailObj)) {
					userObj = emailObj;
				} else if (!OPLUtils.isObjectNullOrEmpty(mobileObj)) {
					userObj = mobileObj;
				}
			} else if (!OPLUtils.isObjectNullOrEmpty(emailObj)) {
				userObj = emailObj;
			} else if (!OPLUtils.isObjectNullOrEmpty(mobileObj)) {
				userObj = mobileObj;
			}
			
			if (!OPLUtils.isObjectNullOrEmpty(userObj)) {
				userObj.setEmail(userRequest.getEmail());
				userObj.setMobile(userRequest.getMobile());
//				userObj.setUserRoleId(new com.opl.jns.common.service.user.management.domain.UserRoleMaster(userRequest.getUserRoleId()));
//				userObj.setUserTypeMaster(new com.opl.jns.common.service.user.management.domain.UserTypeMaster(UserTypeMaster.FUNDPROVIDER.getId()));
				if (!OPLUtils.isObjectNullOrEmpty(userRequest.getBranchId())) {
					userObj.setBranchId(new BranchMaster(userRequest.getBranchId()));
				}
				userObj.setFirstName(userRequest.getFirstName());
				userObj.setIsActive(userRequest.getIsActive());
				userObj.setLastName(userRequest.getLastName());
				userObj.setMiddleName(userRequest.getMiddleName());
				userObj.setModifiedDate(new Date());
				userObj.setUserTypeMaster(userTypeMasterRepository.getById(authClientResponse.getUserType()));

				userObj = userRepo.save(userObj);
				if (!OPLUtils.isListNullOrEmpty(userRequest.getRoleProductList())) {
					if(Boolean.TRUE.equals(userRequest.getIsAdminPanel())) {
						roleProductRepo.deleteByUserId(userObj.getUserId());
					}else {
						roleProductRepo.deleteRolesByUserId(userObj.getUserId());
//						roleProductRepo.deleteByUserIdAndSchemeIds(userObj.getUserId(),userRequest.getSelectedScheme());
					}
					UserRoleProductMapping roleMapping;
					List<UserRoleProductMapping> roleMappingList = new ArrayList<>(userRequest.getRoleProductList().size());
					for (Map<String, Object> map : userRequest.getRoleProductList()) {
						roleMapping = new UserRoleProductMapping();
						roleMapping.setUser(userObj);
						roleMapping.setUserRoleMaster(new com.opl.jns.user.management.service.domain.UserRoleMaster(ObjectConvertMaster.toLong(map.get("roleId"))));
						roleMapping.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
						roleMapping.setIsActive(ObjectConvertMaster.toBoolean(map.get("status")));
						roleMapping.setSchemeId(ObjectConvertMaster.toLong(map.get("schemeId")));
						roleMapping.setCreatedDate(new Date());
						roleMapping.setModifiedDate(new Date());
						roleMappingList.add(roleMapping);
					}
					roleProductRepo.saveAll(roleMappingList);
				}
			} else {
				User user = addUser(userRequest, authClientResponse);
				if (OPLUtils.isObjectNullOrEmpty(user)) {
					logger.info("Some thing went wrong while creating user");
					return null;
				}
				userRequest.setUserId(user.getUserId());
				logger.info("Registration in users successfully --------------> {} , userid : {}", user.getEmail(), user.getUserId());
				if (!OPLUtils.isListNullOrEmpty(userRequest.getRoleProductList())) {
					UserRoleProductMapping roleMapping;
					List<UserRoleProductMapping> roleMappingList = new ArrayList<>(userRequest.getRoleProductList().size());
					for (Map<String, Object> map : userRequest.getRoleProductList()) {
						roleMapping = new UserRoleProductMapping();
						roleMapping.setUser(new User(userRequest.getUserId()));
						roleMapping.setUserRoleMaster(new com.opl.jns.user.management.service.domain.UserRoleMaster(ObjectConvertMaster.toLong(map.get("roleId"))));
						roleMapping.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
						roleMapping.setIsActive(ObjectConvertMaster.toBoolean(map.get("status")));
						roleMapping.setSchemeId(ObjectConvertMaster.toLong(map.get("schemeId")));
						roleMapping.setCreatedDate(new Date());
						roleMappingList.add(roleMapping);
					}
					roleProductRepo.saveAll(roleMappingList);
				}
			}
			return new UserResponseProxy(userRequest, "SuccessFully Done!!", HttpStatus.OK.value());
		} catch (Exception e) {
			logger.error("Exception while update active status", e);
			return null;
		}
	}

	private User addUser(UserListResponseProxy userRequest, AuthClientResponse authClientResponse) {
		try {
			User user = new User();
			user.setEmail(userRequest.getEmail());
			user.setPassword(defaultPwd);
			if (!OPLUtils.isObjectNullOrEmpty(userRequest.getMobile())) {
				user.setMobile(userRequest.getMobile());
			}
			if(UserTypeMaster.ADMIN_PANEL.getId() == authClientResponse.getUserType()) {				
				user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(userRequest.getUserTypeId()));
			}else {
				user.setUserTypeMaster(new com.opl.jns.user.management.service.domain.UserTypeMaster(authClientResponse.getUserType()));
			}
			user.setUserOrgId(userOrganisationMasterRepository.findByUserOrgId(userRequest.getUserOrgId()));
			user.setUserRoleId(new com.opl.jns.user.management.service.domain.UserRoleMaster(userRequest.getUserRoleId()));
			if (!OPLUtils.isObjectNullOrEmpty(userRequest.getBranchId())) {
				user.setBranchId(new BranchMaster(userRequest.getBranchId()));
			}
			user.setFirstName(userRequest.getFirstName());
			user.setLastName(userRequest.getLastName());
			user.setMiddleName(userRequest.getMiddleName());
			user.setSignUpDate(new Date());
			user.setIsPassChanged(false);
			user.setOtpVerified(true);
			user.setTermsAccepted(true);
			user.setIsActive(true);
			user.setCreatedDate(new Date());
			user.setEmailVerified(true);
			return userRepo.save(user);
		} catch (Exception e) {
			logger.error("Exception while update active status", e);
			return null;
		}
	}

	private String setDate(Date date, boolean isFrom) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		if (isFrom) {
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
		} else {
			c.set(Calendar.HOUR_OF_DAY, 23);
			c.set(Calendar.MINUTE, 59);
			c.set(Calendar.SECOND, 59);
		}

		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(c.getTime());
	}

	@Override
	public String getAllOfficesList(UserListResponseProxy userListResponse) {
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(userListResponse.getColumnFilter());
			logger.info("CALL users.spUserManagementBankBranchList({},{},{},{},{},{},{},{});", userListResponse.getUserOrgId(), 
					userListResponse.getBusinessTypeId(), userListResponse.getRoleType(), userListResponse.getNoPagination(), 
					userListResponse.getPaginationFROM(), userListResponse.getPaginationTO(), userListResponse.getSchemeId(), json);
			String resList = userManagementRepository.spUserManagementBankBranchList(userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(), userListResponse.getRoleType(), userListResponse.getNoPagination(), Integer.valueOf(userListResponse.getPaginationFROM()), Integer.valueOf(userListResponse.getPaginationTO()), userListResponse.getSchemeId(), json);
				return resList;

		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public String getBranchUserDetails(UserListResponseProxy userListResponse) {
		try {
			return userManagementRepository.getBranchUserDetails(userListResponse.getBranchId());
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public UserListResponseProxy getSingleUserDetailList(UserListResponseProxy userListResponse) {
		try {
			// return
			// userManagementRepository.getSingleUserDetailList(userListResponse.getUserId());
			UserListResponseProxy user = new UserListResponseProxy();
			User userObj = userRepo.findByUserId(userListResponse.getUserId());
			BeanUtils.copyProperties(userObj, user);
			user.setUserRoleId(userObj.getUserRoleId().getRoleId());
			if (!OPLUtils.isObjectNullOrEmpty(userObj.getBranchId())) {
				user.setBranchId(userObj.getBranchId().getId());
			}
			if (!OPLUtils.isObjectNullOrEmpty(userObj.getUserOrgId())) {
				user.setUserOrgId(userObj.getUserOrgId().getUserOrgId());
			}
			List<UserRoleProductMapping> userSchemelist = roleProductRepo.findByUserUserId(userListResponse.getUserId());
			List<Long> schemeList = new ArrayList<Long>();
			for (UserRoleProductMapping userRole : userSchemelist) {
				schemeList.add(userRole.getSchemeId());
				user.setRoleProductStatus(userRole.getIsActive());
			}
			user.setSchemeList(schemeList);

			return user;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public String getAllBOList(UserListResponseProxy userListResponse) {
		try {
			return userManagementRepository.getAllBoList(userListResponse.getUserOrgId(), userListResponse.getSelectedScheme());
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public String getZoList(UserListResponseProxy userListResponse) {
		return userManagementRepository.getZoList(userListResponse.getUserOrgId(), userListResponse.getSelectedScheme(), userListResponse.getSelectedScheme().size());
	}

	@Override
	public String getLHoList(UserListResponseProxy userListResponse) {
		return userManagementRepository.getLhoList(userListResponse.getUserOrgId(), userListResponse.getSelectedScheme(), userListResponse.getSelectedScheme().size());
	}

	@Override
	public String getRoList(UserListResponseProxy userListResponse) {
		return userManagementRepository.getRoList(userListResponse.getUserOrgId(), userListResponse.getSelectedScheme(), userListResponse.getSelectedScheme().size());
	}

	@Override
	public String getSchemeList(Long userId) {
		try {
			return userManagementRepository.getAllSchemeList(userId);
		} catch (Exception e) {
			logger.error("Exception while get scheme list  :- ", e);
		}
		return "Something went wrong";
	}
	
	@Override
	public String getSchemeListForReport(Long userId) {
		try {
			return userManagementRepository.getAllSchemeListForReport(userId);
		} catch (Exception e) {
			logger.error("Exception while get scheme list  :- ", e);
		}
		return "Something went wrong";
	}
	
	@Override
	public List<Long> getSchemeIdList(Long userId) {
		try {
			return userManagementRepository.getSchemeIdList(userId);
		} catch (Exception e) {
			logger.error("Exception while get scheme list  :- ", e);
		}
		return Collections.emptyList();
	}

	@Override
	public Boolean checkMobile(String mobile) {
		// TODO Auto-generated method stub
		if (!OPLUtils.isObjectNullOrEmpty(mobile)) {
			User userObj = userRepo.findOneByMobileAndUserTypeMasterId(mobile, UserTypeMaster.FUNDPROVIDER.getId());
			if (OPLUtils.isObjectNullOrEmpty(userObj)) {
				return false;
			} else {
				return true;
			}
		}
		return null;
	}

	@Override
	public String getAllOfficeTypeList() {
		try {
			return userManagementRepository.getAllOfficeType();
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public CommonResponse addNodalAndMinistry(List<UserListResponseProxy> userRequest) {
		CommonResponse commonResponse = new CommonResponse();
		CommonMethods commonMethod = new CommonMethods();
		User userObj = new User();
		for (UserListResponseProxy userProxy : userRequest) {
			User user = userRepo.findByUserId(userProxy.getUserId());
			if (OPLUtils.isObjectNullOrEmpty(user)) {
				if (userProxy.getUserTypeId() == UserTypeMaster.NODEL_AGENCY.getId()) {
					user = userRepo.findOneByEmailAndUserTypeMasterId(userProxy.getEmail(), UserTypeMaster.NODEL_AGENCY.getId());
					if (OPLUtils.isObjectNullOrEmpty(user)) {
						user = userRepo.findOneByMobileAndUserTypeMasterId(userProxy.getMobile(), UserTypeMaster.NODEL_AGENCY.getId());
					} else {
						logger.error("Email or mobile is exist nodal");
						commonResponse.setMessage("Email or mobile is exist.");
						commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					}
				}
				if (userProxy.getUserTypeId() == UserTypeMaster.MINISTRY.getId()) {
					user = userRepo.findOneByEmailAndUserTypeMasterId(userProxy.getEmail(), UserTypeMaster.MINISTRY.getId());
					if (OPLUtils.isObjectNullOrEmpty(user)) {
						user = userRepo.findOneByMobileAndUserTypeMasterId(userProxy.getMobile(), UserTypeMaster.MINISTRY.getId());
					} else {
						logger.error("Email or mobile is exist of ministry");
						commonResponse.setMessage("Email or mobile is exist.");
						commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					}
				}
			}
			Long roleId = null;
			User userob = new User();
			if (OPLUtils.isObjectNullOrEmpty(user)) {
				user = userob;
			}
			user.setEmail(userProxy.getEmail());
			user.setPassword(defaultPwd);
			boolean isMobileValid = commonMethod.isValidContactNo(userProxy.getMobile());
			if (isMobileValid) {
				user.setMobile(userProxy.getMobile());
			} else {
				logger.error(userProxy.getMobile() + "number is not Valid");
				commonResponse.setMessage(userProxy.getMobile() + " number is not Valid.");
				commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				return commonResponse;
			}
			if (userProxy.getUserTypeId() == UserTypeMaster.NODEL_AGENCY.getId()) {
				user.setUserTypeMaster(userTypeMasterRepository.getById(UserTypeMaster.NODEL_AGENCY.getId()));
				roleId = UserRoleMaster.NODEL_AGENCY.getId();
				user.setUserRoleId(userRoleMasterRepo.findByRoleId(UserRoleMaster.NODEL_AGENCY.getId()));

			}
			if (userProxy.getUserTypeId() == UserTypeMaster.MINISTRY.getId()) {
				user.setUserTypeMaster(userTypeMasterRepository.getById(UserTypeMaster.MINISTRY.getId()));
				roleId = UserRoleMaster.MINISTRY.getId();
				user.setUserRoleId(userRoleMasterRepo.findByRoleId(UserRoleMaster.MINISTRY.getId()));
			}
			user.setUserOrgId(userOrganisationMasterRepository.findByUserOrgId(userProxy.getUserOrgId()));
			if (!OPLUtils.isObjectNullOrEmpty(userProxy.getBranchId())) {
				user.setBranchId(branchMasterRepo.getOne(userProxy.getBranchId()));
			}
			user.setFirstName(userProxy.getFirstName());
			user.setLastName(userProxy.getLastName());
			user.setMiddleName(userProxy.getMiddleName());
			user.setSignUpDate(new Date());
			user.setIsPassChanged(false);
			user.setTermsAccepted(true);
			user.setIsActive(true);
			if (!OPLUtils.isObjectNullOrEmpty(user.getUserId())) {
				user.setModifiedDate(new Date());
			} else {
				user.setCreatedDate(new Date());
			}
			user.setEmailVerified(true);
			userRepo.save(user);

//                if (OPLUtils.isObjectNullOrEmpty(user)) {
			logger.info("Registration in users successfully -------------->" + userProxy.getEmail());
			userProxy.setUserId(user.getUserId());
			if (!OPLUtils.isListNullOrEmpty(userProxy.getRoleProductList())) {
				roleProductRepo.deleteByUserId(userProxy.getUserId());
				for (Map<String, Object> map : userProxy.getRoleProductList()) {
					UserRoleProductMapping roleMapping = new UserRoleProductMapping();
					roleMapping.setUser(user);
					if (roleId != null) {
						roleMapping.setUserRoleMaster(userRoleMasterRepo.findByRoleId(roleId));
						if (userProxy.getUserTypeId() == UserTypeMaster.NODEL_AGENCY.getId()) {
							roleMapping.setUserRoleMaster(
									userRoleMasterRepo.findByRoleId(UserRoleMaster.NODEL_AGENCY.getId()));
						}
						if (userProxy.getUserTypeId() == UserTypeMaster.MINISTRY.getId()) {
							roleMapping.setUserRoleMaster(
									userRoleMasterRepo.findByRoleId(UserRoleMaster.MINISTRY.getId()));
						}
					}
					roleMapping.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
					roleMapping.setIsActive(Boolean.TRUE);
					roleMapping.setSchemeId(ObjectConvertMaster.toLong(map.get("schemeId")));
					roleMapping.setCreatedDate(new Date());
					roleMapping.setModifiedDate(new Date());
					roleProductRepo.save(roleMapping);
				}
			}
//                }
			commonResponse.setMessage("User saved successfully.");
			commonResponse.setStatus(HttpStatus.OK.value());

//            }
//            else{
//                commonResponse.setMessage("Email or mobile is exist.");
//                commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
//            }
		}
		return commonResponse;
	}

	@Override
	public List<UserListResponseProxy> getNodalAndMinistry() {
		List<UserListResponseProxy> userListResponseProxyList = userRepo.getNodalAndMinistryList();
		if (!OPLUtils.isListNullOrEmpty(userListResponseProxyList)) {
			for (UserListResponseProxy user : userListResponseProxyList) {
				List<Long> schemes = roleProductRepo.getSchemeIds(user.getUserId());
				int count = 0;
				String schemeName = "";
				for (Long schemeId : schemes) {
					schemeName = schemeName + SchemeMaster.getById(schemeId).getName()
							+ ((schemes.size() == 1 || (schemes.size() - 1) == count) ? "" : (" ,"));
					count++;
				}
				user.setTaggedSchemes(schemeName);
			}
			return userListResponseProxyList;
		}
		return Collections.emptyList();
	}

	@Override
	public CommonResponse addFacilitatorOrUlb(UserListResponseProxy userRequest) {
		CommonResponse commonResponse = new CommonResponse();
		User userObj = new User();
		Long schemeId = null;
		
		User user = new User();
		Long userId = null;
		if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
			userId = userRepo.getUserIdByEmailMobile(userRequest.getEmail(), userRequest.getMobile(), userRequest.getUserTypeId());
			user = userRepo.findByUserId(userId);
		} else {
			user = userRepo.findByUserId(userRequest.getUserId());
		}

		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			schemeId = roleProductRepo.getSchemeByUserIdAndSchemeId(user.getUserId(), userRequest.getSchemeId());
			if (OPLUtils.isObjectNullOrEmpty(userRequest.getUserId())) {
				if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
					commonResponse.setMessage("user already created");
					commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return commonResponse;
				}
			}
		}
		User addedUser = new User();
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			int email = userRepo.checkEmailExist(userRequest.getEmail(), userRequest.getUserId(), userRequest.getUserTypeId());
			int mobile = userRepo.checMobileExist(userRequest.getMobile(), userRequest.getUserId(), userRequest.getUserTypeId());
			if (email > 0 || mobile > 0) {
				commonResponse.setMessage("Email or Mobile is exist.");
				commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				return commonResponse;
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(userId)) {
					addedUser = user;
				} else {
					addedUser = addFacilitarorOrULB(user, userRequest);
				}
			}
		} else {
			if (userRequest.getUserTypeId() == UserTypeMaster.COUNCIL
					.getId()) {
				userObj = userRepo.findOneByEmailAndUserTypeMasterId(userRequest.getEmail(), UserTypeMaster.COUNCIL.getId());
				if (OPLUtils.isObjectNullOrEmpty(userObj)) {
					userObj = userRepo.findOneByMobileAndUserTypeMasterId(userRequest.getMobile(), UserTypeMaster.COUNCIL.getId());
				} else {
					logger.error("Email or mobile is exist nodal");
					commonResponse.setMessage("Email or mobile is exist.");
					commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return commonResponse;
				}
			}
			if (userRequest.getUserTypeId() == UserTypeMaster.ULB.getId()) {
				userObj = userRepo.findOneByEmailAndUserTypeMasterId(userRequest.getEmail(),
						UserTypeMaster.ULB.getId());
				if (OPLUtils.isObjectNullOrEmpty(userObj)) {
					userObj = userRepo.findOneByMobileAndUserTypeMasterId(userRequest.getMobile(), UserTypeMaster.ULB.getId());
				} else {
					logger.error("Email or mobile is exist nodal");
					commonResponse.setMessage("Email or mobile is exist.");
					commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					return commonResponse;
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(userObj)) {
				User newUser = new User();
				addedUser = addFacilitarorOrULB(newUser, userRequest);
			} else {
				logger.error("Email or mobile is exist nodal");
				commonResponse.setMessage("Email or mobile is exist.");
				commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				return commonResponse;
			}
		}

		if (!OPLUtils.isObjectNullOrEmpty(addedUser)) {
			logger.info("Registration in users successfully -------------->" + userRequest.getEmail());
			userRequest.setUserId(addedUser.getUserId());
			if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
				roleProductRepo.deleteByUserIdAndSchemeId(addedUser.getUserId(), schemeId);
			}

			if (!OPLUtils.isObjectNullOrEmpty(userRequest.getSchemeId())) {
				UserRoleProductMapping roleMapping = new UserRoleProductMapping();
				roleMapping.setUser(addedUser);
				if (userRequest.getUserTypeId() == UserTypeMaster.COUNCIL.getId()) {
					roleMapping.setUserRoleMaster(userRoleMasterRepo.findByRoleId(UserRoleMaster.FACILITATOR.getId()));
				}
				// add for mapping in userroleproductmapping
				if (userRequest.getUserTypeId() == UserTypeMaster.ULB.getId()) {
					roleMapping.setUserRoleMaster(!OPLUtils.isObjectNullOrEmpty(userRequest.getUlbRole()) ? userRoleMasterRepo.findByRoleId(userRequest.getUlbRole()) : null);
				}
				
				roleMapping.setBusinessId(Long.valueOf(SchemeMaster.getById(userRequest.getSchemeId()).getBussinessTypeId()));
				roleMapping.setIsActive(Boolean.TRUE);
				roleMapping.setSchemeId(userRequest.getSchemeId());
				roleMapping.setCreatedDate(new Date());
				roleMapping.setModifiedDate(new Date());
				roleProductRepo.save(roleMapping);

				if (userRequest.getUserTypeId() == UserTypeMaster.ULB.getId()) {
					Long taggedUlb = ulbUserMappingRepo.getUlbCode(addedUser.getUserId());
					if (!OPLUtils.isObjectNullOrEmpty(taggedUlb)) {
						ulbUserMappingRepo.deleteTaggedUlb(addedUser.getUserId());
					}
					UlbUserMapping ulb = new UlbUserMapping();
					ulb.setUserId(addedUser.getUserId());
					ulb.setUlbCode(userRequest.getUlbLgdCode());
					ulb.setStateCode(userRequest.getStateLgdCode());
					ulb.setIsActive(true);
					ulb.setCreatedBy(userRequest.getCreatedBy());
					ulb.setCreatedDate(new Date());
					ulbUserMappingRepo.save(ulb);
				}
			}
		}
		commonResponse.setMessage("User saved successfully.");
		commonResponse.setStatus(HttpStatus.OK.value());
		return commonResponse;
	}
	
	@Override
	public String getULBList(Long createdBy, AuthClientResponse authClientResponse) {
		return userManagementRepository.getULBList(createdBy, authClientResponse.getUserId());

	}

	@Override
	public UserListResponseProxy getMinistryAndNAByUserId(Long userId) {
		UserListResponseProxy userListResponseProxy = new UserListResponseProxy();
		User user = userRepo.findByUserId(userId);
		userListResponseProxy.setUserTypeId(user.getUserTypeMaster().getId());
		userListResponseProxy.setSelectedScheme(roleProductRepo.getSchemeIds(userId));
		BeanUtils.copyProperties(user, userListResponseProxy);
		return userListResponseProxy;
	}

	@Override
	public SchemeMasterProxy getMinistryBySchemeId(Long schemeId) {
//		SchemeMasterProxy schemeMasterProxy = schemeMasterRepo.getMinistryBySchemeId(schemeId);
//		schemeMasterProxy.setMinistryName(userOrganisationMasterRepository.getMinistryName(Long.valueOf(schemeMasterProxy.getMinistryId())));
		return null;
	}

	@Override
	public List<UserListResponseProxy> getUlbListForNulm() {
		List<UserListResponseProxy> userListResponseProxyList = userRepo.getUlbListForNulm();
		if (!OPLUtils.isListNullOrEmpty(userListResponseProxyList)) {
			return userListResponseProxyList;
		}
		return Collections.emptyList();
	}

	@Override
	public CommonResponse updateMinistryByScheme(UserListResponseProxy userRequest) {

		CommonResponse commonResponse = new CommonResponse();
//		com.opl.jns.common.service.user.management.domain.SchemeMaster schemeMaster = schemeMasterRepo.findById(userRequest.getSchemeId()).get();
//		schemeMaster.setMinistryId(userRequest.getMinistryId());
//		schemeMaster.setIsFacilitator(userRequest.getIsFacilitator());
//		if (userRequest.getSchemeId() == SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_URBAN_LIVELIHOODS_MISSION.getId()) {
//			schemeMaster.setIsUlb(userRequest.getIsUlb());
//		} else {
//			schemeMaster.setIsUlb(Boolean.FALSE);
//		}
//		schemeMaster.setModifiedDate(new Date());
//		schemeMasterRepo.save(schemeMaster);
//		if (!OPLUtils.isObjectNullOrEmpty(schemeMaster)) {
//			commonResponse.setStatus(HttpStatus.OK.value());
//			commonResponse.setMessage("Scheme updated successfully");
//			return commonResponse;
//		} else {
			logger.info("Scheme is not updated");
			commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			commonResponse.setMessage("Scheme is not updated");
			return commonResponse;
//		}
	}

	@Override
	public String getFacilitatorList(Long createdBy, Integer schemeId) {
		return userManagementRepository.getFacilitatorList(createdBy, schemeId);

	}

	private User addFacilitarorOrULB(User user, UserListResponseProxy userRequest) {
		try {
			user.setEmail(userRequest.getEmail());
			user.setPassword(defaultPwd);
			user.setMobile(userRequest.getMobile());
			if (userRequest.getUserTypeId() == UserTypeMaster.COUNCIL.getId()) {
				user.setUserTypeMaster(userTypeMasterRepository.getById(UserTypeMaster.COUNCIL.getId()));
				user.setUserRoleId(userRoleMasterRepo.findByRoleId(UserRoleMaster.FACILITATOR.getId()));
			}
			if (userRequest.getUserTypeId() == UserTypeMaster.ULB.getId()) {
				user.setUserTypeMaster(com.opl.jns.user.management.service.domain.UserTypeMaster.builder().id(UserTypeMaster.ULB.getId()).build());
				// userTypeRepo.findById(UserTypeMaster.ULB.getId())
				user.setUserRoleId(!OPLUtils.isObjectNullOrEmpty(userRequest.getUlbRole()) ? userRoleMasterRepo.findByRoleId(userRequest.getUlbRole()) : null);
			}
			user.setUserOrgId(userOrganisationMasterRepository.findByUserOrgId(userRequest.getUserOrgId()));
			if (!OPLUtils.isObjectNullOrEmpty(userRequest.getBranchId())) {
				user.setBranchId(branchMasterRepo.getOne(userRequest.getBranchId()));
			}
			user.setFirstName(userRequest.getFirstName());
			user.setLastName(userRequest.getLastName());
			user.setMiddleName(userRequest.getMiddleName());
			user.setSignUpDate(new Date());
			user.setIsPassChanged(false);
			user.setTermsAccepted(true);
			user.setIsActive(true);
			user.setCreatedDate(new Date());
			user.setCreatedBy(userRequest.getCreatedBy());
			user.setEmailVerified(true);
			return userRepo.save(user);
		} catch (Exception e) {
			logger.error("Exception while update active status", e);
			return null;
		}
	}

	@Override
	public List<UlbDistrictMappingProxy> getUlbListDistrictWise(Long districtLgdCode) {

		List<UlbDistrictMappingProxy> ulbDistrictMapping = ulbDistrictMappingRepo.findByDistrictLgdCode(districtLgdCode);
		if (!OPLUtils.isListNullOrEmpty(ulbDistrictMapping)) {
			return ulbDistrictMapping;
		}
		return Collections.emptyList();
	}

	@Override
	public UlbUserProxy getUlbListForEdit(Long userId) {

		UlbUserProxy userProxy = new UlbUserProxy();
		User user = userRepo.findByUserId(userId);
		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			userProxy.setUserId(userId);
			userProxy.setFirstName(user.getFirstName());
			userProxy.setEmail(user.getEmail());
			userProxy.setMobile(user.getMobile());
			userProxy.setIsActive(user.getIsActive());
			UlbUserMapping ulbUserMapping = ulbUserMappingRepo.findByUserId(userId);
			if (!OPLUtils.isObjectNullOrEmpty(ulbUserMapping)) {
				userProxy.setStateLgdCode(ulbUserMapping.getStateCode());
				userProxy.setUlbLgdCode(ulbUserMapping.getUlbCode());
				userProxy.setUlbRole(user.getUserRoleId().getRoleId());
				UlbDistrictMapping ulbDistrictMapping = ulbDistrictMappingRepo.getUlbListDistrictWise(ulbUserMapping.getUlbCode());
				if (!OPLUtils.isObjectNullOrEmpty(ulbDistrictMapping)) {
					userProxy.setDistrictLgdCode(ulbDistrictMapping.getDistrictLgdCode());
//					userProxy.setStateLgdCode(ulbDistrictMapping.getStateLgdCode());
//					userProxy.setUlbLgdCode(ulbDistrictMapping.getUlbLgdCode());
				}
			}
		}
		return userProxy;
	}

	@Override
	public Boolean saveUserAdmin(UsersProxy usersProxy) {

		try {
			User user = userRepo.findByEmailOrMobileAnduserRoleId(usersProxy.getEmail(), usersProxy.getMobile(), usersProxy.getUserRoleId());

			if (OPLUtils.isObjectNullOrEmpty(user)) {
				user = new User();
			}
			user.setFirstName(usersProxy.getFirstName());
			user.setMiddleName(usersProxy.getMiddleName());
			user.setLastName(usersProxy.getLastName());
			user.setMobile(usersProxy.getMobile());
			user.setEmail(usersProxy.getEmail());
			user.setPassword(defaultPwd);
			if (!OPLUtils.isObjectNullOrEmpty(usersProxy.getUserRoleId())) {
				user.setUserRoleId(userRoleMasterRepo.getById(usersProxy.getUserRoleId()));
			}
			user.setUserTypeMaster(userTypeMasterRepository.getById(UserTypeMaster.ADMIN_PANEL.getId()));
			user.setSignUpDate(new Date());
			user.setCreatedDate(new Date());
			user.setIsActive(Boolean.TRUE);
			user.setIsPassChanged(Boolean.FALSE);
			userRepo.save(user);
			return Boolean.TRUE;
		} catch (Exception e) {
			logger.error("exception is getting while save admin User", e);
		}
		return Boolean.TRUE;
	}

	@Override
	public Boolean saveOrganization(UserOrganisationMasterProxy organisationMasterProxy) {
		try {
			UserOrganisationMaster organisationMaster = userOrganisationMasterRepository.findByOrganisationName(organisationMasterProxy.getOrganisationName());
			if (OPLUtils.isObjectNullOrEmpty(organisationMaster)) {
				organisationMaster = new UserOrganisationMaster();
			}
			organisationMaster.setOrganisationName(organisationMasterProxy.getOrganisationName());
			organisationMaster.setDisplayOrgName(organisationMasterProxy.getOrganisationName());
			organisationMaster.setUserTypeMaster(userTypeMasterRepository.getById(UserTypeMaster.FUNDPROVIDER.getId()));
			organisationMaster.setIsActive(Boolean.TRUE);
			userOrganisationMasterRepository.save(organisationMaster);

			return Boolean.TRUE;
		} catch (Exception e) {
			logger.error("exception is getting while get save organization", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public Boolean isActiveOrg(Long userOrgId) {
		try {
			UserOrganisationMaster organisationMaster = userOrganisationMasterRepository.findByUserOrgId(userOrgId);
			if (!OPLUtils.isObjectNullOrEmpty(organisationMaster)) {
				if (organisationMaster.getIsActive()) {
					organisationMaster.setIsActive(Boolean.FALSE);
				} else {
					organisationMaster.setIsActive(Boolean.TRUE);
				}
			}
			return Boolean.TRUE;
		} catch (Exception e) {
			logger.error("exception is getting while get Delete organization", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public Boolean activeIsActiveUser(Long userId) {
		try {
			User user = userRepo.findByUserId(userId);

			if (user.getIsActive() == true) {
				user.setIsActive(false);
			} else {
				user.setIsActive(true);
			}
			return Boolean.TRUE;
		} catch (Exception e) {
			logger.error("Exception is getting While update Is Active Flag");
		}
		return Boolean.FALSE;
	}

	@Override
	public String getOrganizationName(Long orgId) {
		String orgName = userOrganisationMasterRepository.getBankName(orgId);
		if (OPLUtils.isStringEmpty(orgName).isEmpty()) {
			return orgName;
		}
		return orgName;
	}
	public String getOrganizationCode(Long orgId){
		String orgName = userOrganisationMasterRepository.getBankCode(orgId);
		if (OPLUtils.isStringEmpty(orgName).isEmpty()) {
			return orgName;
		}
		return orgName;
	}

	@Override
	public List<BranchTypeMaster> getBranchType() {
		List<BranchTypeMaster> branchTypeMasterList = branchTypeMasterRepo.findByIsDisplay(true);
		return branchTypeMasterList;
	}

	@Override
	public List<TierMappingPermission> getBranchTypeIdsByOrgId(Long orgId) {
		return tierMappingPermissionRepo.getBranchTypeIdsByOrgId(orgId);
	}

	@Override
	public CommonResponse saveTierConfiguration(List<BranchTypeMasterRequest> branchTypeMasterRequest, Long orgId) {
		CommonResponse commonResponse = new CommonResponse();
		try {
			tierMappingPermissionRepo.deleteByOrgId(orgId);
			for (BranchTypeMasterRequest branchReq : branchTypeMasterRequest) {
				TierMappingPermission tierMappingPermission = new TierMappingPermission();
				tierMappingPermission.setOrgId(orgId);
				tierMappingPermission.setBranchType(branchReq.getId());
				if (branchReq.getId() == 1) {
					tierMappingPermission.setIsSelected(Boolean.TRUE);
				} else {
					tierMappingPermission.setIsSelected(Boolean.FALSE);
				}
				tierMappingPermission.setIsActive(branchReq.getIsChecked());
				tierMappingPermission.setCreatedDate(new Date());
				tierMappingPermissionRepo.save(tierMappingPermission);
			}
			commonResponse.setMessage("Saved tier successfully");
			commonResponse.setStatus(HttpStatus.OK.value());
			return commonResponse;
		} catch (Exception e) {
			logger.error("Exception is getting While save Tier Configuation", e);
			commonResponse.setMessage("Tier Configuation not saved");
			commonResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return commonResponse;
		}
	}

	@Override
	public String getAllSchemeList() {
		try {
			return userManagementRepository.getSchemeList();
		} catch (Exception e) {
			logger.error("Exception while get scheme list  :- ", e);
		}
		return "Something went wrong";
	}

	@Override
	public UlbUserMapping getUlbUserMappingByUserId(Long userId){
		try{
			UlbUserMapping ulbUserMapping=null;
			ulbUserMapping = ulbUserMappingRepo.findByUserId(userId);
			return ulbUserMapping;
		}catch(Exception e){
			logger.error("Exception while fetching UlbUserMapping using userId :- ", e);
		}
		return null;
	}

	@Override
	public UserBranchProxy getUserBranchDetails(Long branchId) {
		try {
			BranchMaster branchMasterDetails = branchMasterRepo.getById(branchId);
			if (!OPLUtils.isObjectNullOrEmpty(branchMasterDetails)) {
				UserBranchProxy userBranchProxy = new UserBranchProxy();
				userBranchProxy.setBranchCode(branchMasterDetails.getCode());
				userBranchProxy.setBranchName(branchMasterDetails.getName());
				userBranchProxy.setBranchType(branchMasterDetails.getBranchType());
				userBranchProxy.setCityId(branchMasterDetails.getCityId());
				userBranchProxy.setStateId(branchMasterDetails.getStateId());
				userBranchProxy.setContactPersonEmail(branchMasterDetails.getContactPersonEmail());
				userBranchProxy.setContactPersonName(branchMasterDetails.getContactPersonName());
				userBranchProxy.setContactPersonNumber(branchMasterDetails.getContactPersonNumber());
				userBranchProxy.setBranchId(branchMasterDetails.getId());
//				BeanUtils.copyProperties(branchMasterDetails, userBranchProxy);
				return userBranchProxy;
			}
		} catch (Exception e) {
			logger.error("Exception while fetching USer Branch Details using userId :- ", e);
		}
		return null;
	}

	@Override
	public String getOfficesZoRoBoList(UserListResponseProxy userListResponse) {
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(userListResponse.getColumnFilter());
			String resList = userManagementRepository.getOfficesZoRoBoList(userListResponse.getUserId(),userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(), userListResponse.getRoleType(), userListResponse.getNoPagination(), userListResponse.getPaginationFROM(), userListResponse.getPaginationTO(), userListResponse.getSchemeId(), json);
//			if (!OPLUtils.isListNullOrEmpty(resList)) {
////				String s1 = MultipleJSONObjectHelper.getStringfromListOfObject(resList);
//				return MultipleJSONObjectHelper.getStringfromListOfObject(resList);
//			}
			return resList;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public String getRoZoUsersList(UserListResponseProxy userListResponse) {
		try {
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String json = ow.writeValueAsString(userListResponse.getColumnFilter());
			return userManagementRepository.getRoZoUsersList(userListResponse.getUserId(),userListResponse.getUserOrgId(), userListResponse.getBusinessTypeId(), userListResponse.getRoleType(), userListResponse.getNoPagination(), userListResponse.getPaginationFROM(), userListResponse.getPaginationTO(), userListResponse.getSchemeId(), json);
		} catch (Exception e) {
			logger.error("Exception while getting RoZo user list  :- ", e);
		}
		return null;
	}
	
	@Override
	public List<String> getBoOfficesfromZoId(UserListResponseProxy userListResponse) {
		try {
			List<String> resList = userRepo.getBoOfficesfromZoId(userListResponse.getBranchId(),userListResponse.getUserOrgId());
			if (!OPLUtils.isListNullOrEmpty(resList)) {
//				String s1 = MultipleJSONObjectHelper.getStringfromListOfObject(resList);
				return resList;
			}
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}
	
	@Override
	public List<String> getBoRoOfficesfromRoZoId(UserListResponseProxy userListResponse) {
		try {

//			List<String> resList = userRepo.getBoRoOfficesfromRoZoId(userListResponse.getBranchId(),userListResponse.getUserRoleId(),userListResponse.getUserOrgId());
			List<String> resList = Collections.emptyList();
			if(UserRoleMaster.RO.getId()==userListResponse.getUserRoleId()) {				
				resList = branchMasterRepo.getRoOfficesfromRoId(1L,userListResponse.getBranchId(),userListResponse.getUserOrgId());
			}else if(UserRoleMaster.ZO.getId()==userListResponse.getUserRoleId()) {
				resList = branchMasterRepo.getZoOfficesfromZoId(2L,userListResponse.getBranchId(),userListResponse.getUserOrgId());
			}

			if (!OPLUtils.isListNullOrEmpty(resList)) {
//				String s1 = MultipleJSONObjectHelper.getStringfromListOfObject(resList);
				return resList;
			}
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public List<SchemeMasterProxy> getSchemeListForAdmin() {

		try {
			List<com.opl.jns.user.management.service.domain.SchemeMaster> schemeMasterList = schemeMasterRepo.findAll();
			List<SchemeMasterProxy> schemeMasterProxyList = new ArrayList<>(schemeMasterList.size());
			if (!OPLUtils.isListNullOrEmpty(schemeMasterList)) {
				SchemeMasterProxy schemeMasterProxy = null;
				for (com.opl.jns.user.management.service.domain.SchemeMaster scheme : schemeMasterList) {
					schemeMasterProxy = new SchemeMasterProxy();
					schemeMasterProxy.setId(scheme.getId());
					schemeMasterProxy.setSchemeId(scheme.getId());
					BusinessMaster businessTypeName = businessMasterRepository.findById(Long.valueOf(scheme.getBusinessId())).get();
					schemeMasterProxy.setBusinessTypeName(businessTypeName.getDisplayName());
					schemeMasterProxy.setName(scheme.getName());
					schemeMasterProxy.setBusinessId(scheme.getBusinessId());
					schemeMasterProxyList.add(schemeMasterProxy);
				}
				return schemeMasterProxyList;
			}
		} catch (Exception e) {
			logger.error("Exception :- ", e.getMessage());
			throw e;
		}
		return Collections.emptyList();
	}

	@Override
	public String getBranchList(AdminRequest request) {
		try {
			return userManagementRepository.getBranchList(request);
		} catch (Exception e) {
			logger.error("Exception while getBranchList  :- ", e);
		}
		return null;
	}
	@Override
	public List<UserTypeMasterProxy> getUserTypeMasterList() {
	try {
			List<com.opl.jns.user.management.service.domain.UserTypeMaster> userTypeMasterList = userTypeMasterRepository.findByIsDisplayOnLogin(Boolean.TRUE);
			if (!OPLUtils.isListNullOrEmpty(userTypeMasterList)) {
				List<UserTypeMasterProxy> userTypeMasterProxyList = new ArrayList<>(userTypeMasterList.size());
				userTypeMasterList.forEach(x -> {
					UserTypeMasterProxy userTypeMasterProxy = new UserTypeMasterProxy();
					BeanUtils.copyProperties(x, userTypeMasterProxy);
					userTypeMasterProxyList.add(userTypeMasterProxy);
				});
				return userTypeMasterProxyList;
			}
		} catch (Exception e) {
			logger.error("Exception is getting while get userTypeMaster List",e);
		}
		return Collections.emptyList();
	}

	public BranchAndOrgDetailsProxy getOrganisationBasicDetails(Long orgId,Long branchId,Long insurerOrgId){
		UserOrganisationMasterProxy bankNameAndCode = userOrganisationMasterRepository.getNameAndCodeByOrgId(orgId);
		UserOrganisationMasterProxy insurerNameAndCode = userOrganisationMasterRepository.getNameAndCodeByOrgId(insurerOrgId);
		String branchName = branchMasterRepo.getBranchNameByBranchId(branchId);

		BranchAndOrgDetailsProxy proxy = new BranchAndOrgDetailsProxy();
		proxy.setBankName(bankNameAndCode.getOrganisationName());
		proxy.setBankCode(bankNameAndCode.getOrganisationCode());
		proxy.setInsurerName(insurerNameAndCode.getOrganisationName());
		proxy.setInsurerCode(insurerNameAndCode.getOrganisationCode());
		proxy.setBranchName(branchName);
		return proxy;
	}

	@Override
	public UserResponseProxy userGenerateAndResetPassword(Long userId) {
		try {
			User user = userRepo.findByUserId(userId);
			if (OPLUtils.isObjectNullOrEmpty(user)) {
				return new UserResponseProxy("user not found...", HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
			}

			if (!OPLUtils.isObjectNullOrEmpty(user)) {
				String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*";
				String pwd = RandomStringUtils.random(8, characters);

				user.setPassword2(user.getPassword1());
				user.setPassword1(user.getPassword());
				user.setPassword(DigestUtils.md5DigestAsHex(pwd.getBytes()));
				user.setIsPassChanged(Boolean.FALSE);
				user.setPasswordResetDate(new Date());

				/** password reset audit maintain*/
				UserPasswordChangeLog passwordLog = new UserPasswordChangeLog();
				passwordLog.setUserId(user);
				passwordLog.setPassword(user.getPassword());
				passwordLog.setCreatedOn(new Date());
				passwordChangeLogRepository.save(passwordLog);

				return new UserResponseProxy(CommonErrorMsg.Enrollment.SUCCESS, pwd, HttpStatus.OK.value(),
						Boolean.TRUE);

			}
		} catch (Exception e) {
			logger.error("Exception is getting while userGenerateAndResetPassword", e);
		}

		return new UserResponseProxy(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}


}