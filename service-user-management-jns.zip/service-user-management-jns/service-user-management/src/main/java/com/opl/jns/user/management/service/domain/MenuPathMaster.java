package com.opl.jns.user.management.service.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "menu_path_master")
public class MenuPathMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "menu_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "menu_master_mana_seq_gen", sequenceName = "menu_master_mana_seq", allocationSize = 1)
	private Long id;

	@Column(name = "navigation_path", columnDefinition = "varchar(500) default ''")
	private String navigationPath;

	@Column(name = "menu_id")
	private Long menuId;

	@Column(name = "loan_type_id")
	private Integer loanTypeId;

	@Column(name = "scheme_id")
	private Integer schemeId;

}
