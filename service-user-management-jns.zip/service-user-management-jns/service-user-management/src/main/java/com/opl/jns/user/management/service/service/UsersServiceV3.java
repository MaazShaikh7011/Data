package com.opl.jns.user.management.service.service;

import java.util.List;

import com.opl.jns.user.management.api.model.*;

public interface UsersServiceV3 {

	List<RoleMasterProxy> getUserRoleMasterList();

	List<RoleMasterProxy> getAdminUserRoleMasterList();
	
	List<UserPermissionMasterProxy> getPermissionMasterList();

	List<Long> getPermissionMappingList(Long orgId, Long userRoleId, Long schemeId);

	Boolean savePermission(Long orgId, Long userRoleId, Long schemeId, List<Long> permissionIds);

	List<MenuMasterProxy> getMenuMaser();

	List<MenuRoleLoanMappingProxy> getMenuMappingList(Long roleId, Long businessTypeId, Integer schemeId);

	Boolean saveMenuMappingList(MenuRoleLoanMappingProxy menuRoleLoanMappingProxy);

	Boolean saveMenu(MenuMasterProxy menuMasterProxy);

	Boolean deleteMenu(Long id);

	List<MenuMasterProxy> getAdminMenuMaser(Long roleId);

	List<MenuRoleLoanMappingProxy> getAdminMenuMappingList(Long roleId);

	Boolean saveAdminPermission(MenuRoleLoanMappingProxy menuRoleLoanMappingProxy);
	
	List<UserPermissionMasterProxy> getAdminPermissionMasterList(Long roleId);

	List<AdminMenuPermissionMappingProxy> getAdminMenuPermissionMappingList(Long roleId);
//
	Boolean saveAdminMenuPermission(AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy);
//
//	Boolean saveAdminBasicPermission(AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy);

	Boolean changeOrgIdAndBranchIdAndRoleId(UsersProxy usersProxy);

	Boolean changeAdminUserRole(UsersProxy usersProxy);
	
	List<RoleMasterProxy> getPartnerRoleMasterList();

}
