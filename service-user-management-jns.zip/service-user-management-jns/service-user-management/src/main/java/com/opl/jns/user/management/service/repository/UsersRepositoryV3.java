package com.opl.jns.user.management.service.repository;


import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.service.domain.User;
import com.opl.jns.utils.constant.DBNameConstant;


@Repository
public interface UsersRepositoryV3 extends JpaRepository<User, Long> {

    User findOneByEmail(String email);
    
    
//    @Query(value = "SELECT u.* FROM users.users u WHERE u.user_type_id = :userType AND UPPER(CAST((AES_DECRYPT(UNHEX(email),'C@p!ta@W0rld#AES')) AS CHAR)) = UPPER(:email)", nativeQuery = true)
//    User findOneByEmailAndUserTypeMasterId(@Param("email") String email, @Param("userType") Long userType);

//    User findOneByMobile(String mobileNumber);
    
    User findOneByMobileAndUserTypeMasterId(String mobileNumber, Long userTypeId);
    User findOneByEmailAndUserTypeMasterId(@Param("email") String email, @Param("userType") Long userType);

//    List<User> findAllByMobile(String mobileNumber);
//
//    List<User> findByIsActive(boolean isActive);

//    @Query("SELECT count(u.id) FROM User u where u.email =:email and u.userTypeMaster.id =:userTypeId and isActive = true")
//    Long checkEmailAndUserType(@Param("email") String email, @Param("userTypeId") Long userTypeId);
//
//
//    @Query("SELECT count(u.id) FROM User u where u.mobile =:mobileNumber and u.userTypeMaster.id =:userTypeId and isActive = true")
//    Long checkMobileAndUserType(@Param("mobileNumber") String mobileNumber, @Param("userTypeId") Long userTypeId);
//
//
//    @Query("SELECT count(u.id) FROM User u where u.email =:email and isLocked = true")
//    Long checkEmailAddressLock(@Param("email") String email);
//
//    @Query("SELECT count(u.id) FROM User u where u.mobile =:mobileNumber and isLocked = true")
//    Long checkMobileNumberLock(@Param("mobileNumber") String mobileNumber);

//    @Query(value = "SELECT CAST(JSON_ARRAYAGG(JSON_OBJECT('module',mm.module_name,'fieldList',(SELECT JSON_ARRAYAGG(dataa) FROM (SELECT JSON_OBJECT('moduleid',f.module_id,'label',f.field_name,'validations',JSON_ARRAYAGG(JSON_OBJECT('key',vm.value,'value',fm.validation_value,'errorMassage',fm.error_message))) AS dataa FROM validation_engine.field_validation_mapping fm LEFT JOIN validation_engine.validation_master vm ON vm.id = fm.validation_id AND vm.is_active = TRUE LEFT JOIN validation_engine.field_master f ON f.id = fm.field_id AND f.is_active = TRUE WHERE fm.is_active = TRUE GROUP BY f.id) AS objjson WHERE JSON_EXTRACT(dataa ,\"$.moduleid\") = mm.id)))AS CHAR) FROM validation_engine.module_master mm WHERE mm.is_active = TRUE AND mm.bussiness_type_id =:businessType",nativeQuery = true)
//    public String getAllValidations(@Param("businessType") Long businessTypeId);

//    @Query(value = "SELECT JSON_ARRAYAGG(JSON_OBJECT('keyName',mm.key_name,'displayName',mm.display_name,'iconPath',mm.icon_path,'navigatePath',mml.navigation_path,\n" +
//            "'childList',(SELECT JSON_ARRAYAGG(JSON_OBJECT('keyName',m.key_name,'displayName',m.display_name,'iconPath',m.icon_path,'navigatePath',ml.navigation_path)) FROM menu_master m LEFT JOIN\n" +
//            "menu_role_loan_mapping ml ON ml.menu_id = m.id\n" +
//            "WHERE ml.role_id = mml.role_id AND ml.business_type_id = mml.business_type_id AND m.parent_id = mm.id)\n" +
//            ")) FROM menu_master mm LEFT JOIN\n" +
//            "menu_role_loan_mapping mml ON mml.menu_id = mm.id\n" +
//            "WHERE mml.role_id =:roleId AND mml.business_type_id =:businessType AND mm.parent_id IS NULL",nativeQuery = true)
//    public String getMenuForBanker(@Param("businessType") Long businessTypeId,@Param("roleId") Long roleId);

//    @Query(value="SELECT pm.alias FROM  use Param("userRoleId") Long userRoleId , @Param("loanTypeId") Integer loanTypeId, @Param("orgId") Long orgId );

//	User findByEmailAndMobile(String email, String mobile);
//
//	User findByEmailAndMobileAndUserId(String email, String mobile,Long userId);
//
//	User findByEmail(String email);
//
//	User findByMobile(String mobile);

	User findByUserId(Long userId);
	
//	@Query(value = "CALL users.spUserManagementFetchAllOffices_NEW(:orgId, :businessTypeId, :branchType, :fromDate, :toDate, :noPagination, :paginationFrom, :paginationTO, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getAllOfficeList(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
//            @Param("branchType") Integer branchType,@Param("fromDate") String fromDate,
//            @Param("toDate") String toDate, @Param("noPagination") String noPagination,
//            @Param("paginationFrom") String paginationFrom,
//            @Param("paginationTO") String paginationTO, @Param("columnFilter") String columnFilter);

//    @Query(value = "CALL "+DBNameConstant.JNS_USERS+".spUserManagementBankBranchList(:orgId, :businessTypeId, :branchType, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getAllOfficeList(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
//                                               @Param("branchType") Integer branchType, @Param("noPagination") String noPagination,
//                                               @Param("paginationFrom") String paginationFrom,
//                                               @Param("paginationTO") String paginationTO,@Param("schemeId") Long schemeId, @Param("columnFilter") String columnFilter);
	
	
//	@Query(value = "CALL users.spUserManagementFetchNewUsersList_NEW(:fromDate, :toDate,:orgId, :businessTypeId, :roleType, :noPagination, :paginationFrom, :paginationTO, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getNewUsersList(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
//            @Param("roleType") Integer roleType,@Param("fromDate") String fromDate,
//            @Param("toDate") String toDate, @Param("noPagination") String noPagination,
//            @Param("paginationFrom") String paginationFrom,
//            @Param("paginationTO") String paginationTO, @Param("columnFilter") String columnFilter);

//    @Query(value = "CALL "+DBNameConstant.JNS_USERS+".spUserManagementBankUsersList(:orgId, :businessTypeId, :roleType, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> spUserManagementBankUsersList(@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
//                                              @Param("roleType") Integer roleType, @Param("noPagination") String noPagination,
//                                              @Param("paginationFrom") String paginationFrom,
//                                              @Param("paginationTO") String paginationTO, @Param("schemeId") Long schemeId, @Param("columnFilter") String columnFilter);
	
	
//	@Query(value = "CALL users.spUserManagementFetchTierDetail_NEW(:orgId, :businessTypeId, :type, :fromDate, :toDate, :noPagination, :paginationFrom, :paginationTO, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getTierMappingList(@Param("orgId") Integer orgId, @Param("businessTypeId") Integer businessTypeId,
//            @Param("type") Integer type,@Param("fromDate") String fromDate,
//            @Param("toDate") String toDate, @Param("noPagination") String noPagination,
//            @Param("paginationFrom") String paginationFrom,@Param("paginationTO") String paginationTO,@Param("columnFilter") String columnFilter);

//    @Query(value = "CALL users.spUserManagementFetchTierDetail_NEW(:orgId, :businessTypeId, :type, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getTierMappingList(@Param("orgId") Integer orgId, @Param("businessTypeId") Integer businessTypeId,
//                                                 @Param("type") Integer type, @Param("noPagination") String noPagination,
//                                                 @Param("paginationFrom") String paginationFrom,@Param("paginationTO") String paginationTO,@Param("schemeId") Long schemeId,@Param("columnFilter") String columnFilter);

//    @Query(value = "CALL "+DBNameConstant.JNS_USERS+".spUserManagementFetchTierDetailRoZo(:userId, :orgId, :businessTypeId, :type, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
//    List<Map<String, Object>> getTierMappingList(@Param("userId") Long userId, @Param("orgId") Integer orgId, @Param("businessTypeId") Integer businessTypeId,
//                                                 @Param("type") Integer type, @Param("noPagination") String noPagination,
//                                                 @Param("paginationFrom") String paginationFrom,@Param("paginationTO") String paginationTO,@Param("schemeId") Long schemeId,@Param("columnFilter") String columnFilter);


    @Query(value="SELECT new com.opl.jns.user.management.api.model.UserListResponseProxy(u.userId,u.email,u.mobile,u.firstName,u.userTypeMaster.name, u.isLocked) FROM User u WHERE u.isActive = TRUE AND u.userTypeMaster.id IN (3L,4L) ORDER BY u.createdDate DESC")
    public List<UserListResponseProxy> getNodalAndMinistryList();

//    @Query(value="SELECT u FROM User u WHERE u.isActive = TRUE AND u.userTypeMaster.id=:userType AND u.createdBy=:createdBy ORDER BY u.createdDate DESC")
//    public List<User> getFacilitatorList(@Param("createdBy") Long createdBy,@Param("userType") Long userType);


    @Query("SELECT COUNT(u.userId) FROM User u WHERE email =:email AND u.userTypeMaster.id=:userType AND u.userId <>:userId")
    int checkEmailExist(@Param("email") String mobileNumber,@Param("userId") Long userId,@Param("userType") Long userType);

    @Query("SELECT COUNT(u.userId) FROM User u WHERE u.mobile =:mobileNumber AND u.userTypeMaster.id=:userType AND u.userId not in (:userId) ")
    int checMobileExist(@Param("mobileNumber") String mobileNumber,@Param("userId") Long userId,@Param("userType") Long userType);

    @Query("SELECT u.userId FROM User u where u.email =:email AND u.mobile =:mobileNumber AND u.userTypeMaster.id=:userType")
    Long getUserIdByEmailMobile(@Param("email") String email,@Param("mobileNumber") String mobileNumber,@Param("userType") Long userType);

    @Query(value="SELECT new com.opl.jns.user.management.api.model.UserListResponseProxy(u.userId,u.email,u.mobile,u.firstName,u.userTypeMaster.name) FROM User u WHERE u.isActive = TRUE AND u.userTypeMaster.id = 8L ORDER BY u.createdDate DESC")
    public List<UserListResponseProxy> getUlbListForNulm();

//    @Query(value="SELECT new com.opl.jns.user.management.api.model.UserListResponseProxy(u.userId,u.email,u.mobile,u.firstName,u.userTypeMaster.name,ulb.stateLgdCode,ulb.districtLgdCode,ulb.ulbLgdCode) FROM User u INNER JOIN UlbDistrictMapping ulb ON ulb.userId = u.userId WHERE u.isActive = TRUE AND u.userId =:userId ORDER BY u.createdDate DESC")
//    public List<UserListResponseProxy> getUlbListForEdit(@Param("userId") Long userId);
//
//    @Query(value = "CALL spResetUserPassWord(:userId)", nativeQuery = true)
//    String userResetPassword(@Param("userId") Long userId);
//
//    @Query(value = "CALL spAdminUserList(:filterJSON, :paginationFROM, :paginationTO)", nativeQuery = true)
//    List<Map<String, Object>> spAdminUserList( @Param("filterJSON") String filterJSON, @Param("paginationFROM") String paginationFROM, @Param("paginationTO") String paginationTO);

    @Query(value = "SELECT u FROM User u WHERE u.email=:email AND u.mobile=:mobile AND u.userRoleId.roleId =:userRoleId AND u.isActive = TRUE")
    User findByEmailOrMobileAnduserRoleId(@Param("email") String email, @Param("mobile") String mobile, @Param("userRoleId") Long userRoleId);

  
    @Query(value = "SELECT u FROM User u WHERE email =:email AND u.userTypeMaster.id=:userType")
    User emailExist(@Param("email") String email,@Param("userType") Long userType);

    @Query(value = "SELECT u FROM User u WHERE mobile =:mobile AND u.userTypeMaster.id=:userType")
    User mobileExist(@Param("mobile") String mobile,@Param("userType") Long userType);

    @Modifying
    @Query(value = "UPDATE User u SET u.userOrgId.userOrgId=:orgId, u.branchId.id=:branchId, u.userRoleId.roleId=:userRoleId WHERE u.userId=:userId")
   	void changeOrgIdAndBranchIdAndRoleId(@Param("userId") Long userId, @Param("orgId") Long orgId,@Param("branchId") Long branchId, @Param("userRoleId") Long userRoleId);


//    @Query(value = "SELECT u FROM User u WHERE u.userTypeMaster.id=:userType")
//    List<User> findByUserTypeMaster(@Param("userType")Long userType);
//
//    @Query(value = "SELECT u FROM User u WHERE u.userTypeMaster.id=:userType AND u.userOrgId.userOrgId=:userOrgId")
//    List<User> getPartnersByOrg(@Param("userType")Long userType,@Param("userOrgId")Long userOrgId);
//
//    @Query("SELECT count(u.id) FROM User u where  u.userTypeMaster.id =:userTypeId AND isActive = true AND u.email =:email OR u.mobile =:mobile ")
//    Long checkEmailMobileAndUserType(@Param("email") String email,@Param("mobile") String mobile, @Param("userTypeId") Long userTypeId);

    @Query("SELECT u FROM User u WHERE u.branchId.id = :branchRoZoId ")
	List<User> findByBranchId(Long branchRoZoId);
     
    @Query(value = "CALL spUserManagementFetchAllOfficesRoZo(:userId, :orgId, :businessTypeId, :branchType, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
    List<Map<String, Object>> getOfficesZoRoBoList(@Param("userId") Long userId,@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
                                               @Param("branchType") Integer branchType, @Param("noPagination") String noPagination,
                                               @Param("paginationFrom") String paginationFrom,
                                               @Param("paginationTO") String paginationTO,@Param("schemeId") Long schemeId, @Param("columnFilter") String columnFilter);
    
    @Query(value = "CALL users.spUserManagementFetchRoZoUsersList(:userId, :orgId, :businessTypeId, :roleType, :noPagination, :paginationFrom, :paginationTO,:schemeId, :columnFilter)", nativeQuery = true)
    List<Map<String, Object>> getRoZoUsersList(@Param("userId") Long userId,@Param("orgId") Long orgId, @Param("businessTypeId") Long businessTypeId,
                                              @Param("roleType") Integer roleType, @Param("noPagination") String noPagination,
                                              @Param("paginationFrom") String paginationFrom,
                                              @Param("paginationTO") String paginationTO, @Param("schemeId") Long schemeId, @Param("columnFilter") String columnFilter);
    

    @Query(value = """
		    SELECT DISTINCT(bm.code) AS branchCode  FROM jns_users.branch_master bm
		    LEFT JOIN jns_users.branch_product_mapping bpm ON bpm.branch_id = bm.id  WHERE bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type = 1\s
		    AND bm.id IN ( SELECT DISTINCT bpm.branchId  FROM (
		    		SELECT DISTINCT bpmp1.branch_id AS branchId
		    				FROM jns_users.branch_product_mapping bpmp1
		    				INNER JOIN jns_users.branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = 1
		    				WHERE bpmp1.branch_zo_id =:zoId
		    				UNION ALL
		    				SELECT DISTINCT bpmp.branch_id AS branchId
		    				FROM jns_users.branch_product_mapping bpmp1
		    				INNER JOIN jns_users.branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id\s
		    				INNER JOIN jns_users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = 1
		    				WHERE bpmp1.branch_zo_id =:zoId\s
		    		) bpm )\
		    """, nativeQuery = true)
    List<String> getBoOfficesfromZoId(@Param("zoId") Long zoId,@Param("orgId") Long orgId);

    
    @Query(value = "CALL spUserManagementFetchBoRoOfficesfromRoZoId(:branchId, :userRoleId, :orgId)", nativeQuery = true)
    List<String> getBoRoOfficesfromRoZoId(@Param("branchId") Long userId,@Param("userRoleId") Long userRoleId,@Param("orgId") Long orgId);

}
