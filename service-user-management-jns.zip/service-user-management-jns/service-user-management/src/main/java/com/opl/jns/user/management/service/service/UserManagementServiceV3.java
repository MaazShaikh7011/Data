package com.opl.jns.user.management.service.service;

import java.util.List;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.user.management.api.model.AdminRequest;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.api.model.BranchTypeMasterRequest;
import com.opl.jns.user.management.api.model.SchemeMasterProxy;
import com.opl.jns.user.management.api.model.UlbDistrictMappingProxy;
import com.opl.jns.user.management.api.model.UlbUserProxy;
import com.opl.jns.user.management.api.model.UserBranchProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.api.model.UserTypeMasterProxy;
import com.opl.jns.user.management.api.model.UsersProxy;
import com.opl.jns.user.management.service.domain.BranchTypeMaster;
import com.opl.jns.user.management.service.domain.TierMappingPermission;
import com.opl.jns.user.management.service.domain.UlbUserMapping;
import com.opl.jns.utils.common.CommonResponse;


/**
 * Created by pooja.patel on 16-08-2020.
 */
public interface UserManagementServiceV3 {

//    public List<UserListResponseProxy> getUserList(Long userId, Integer businessTypeId);

    public String resetPassword(String email);

    public boolean updateIsLocked(UserListResponseProxy userRequest);

    public String getUserProfile(UserListResponseProxy userListResponse);

    public String getRoleTypeList(UserListResponseProxy userListResponse);

    public String getBankUsersList(UserListResponseProxy userListResponse);

    public String getUserBusinessTypeList(UserListResponseProxy userListResponse);

    public String getAllRoleList();

    public UserResponseProxy updateUser(UserListResponseProxy userRequest, AuthClientResponse authClientResponse);

    public String getAllOfficesList(UserListResponseProxy userListResponse);

    public String getBranchUserDetails(UserListResponseProxy userListResponse);

    public UserListResponseProxy getSingleUserDetailList(UserListResponseProxy userListResponse);

    public String getAllBOList(UserListResponseProxy userListResponse);

    public String getZoList(UserListResponseProxy userListResponse);

    public String getLHoList(UserListResponseProxy userListResponse);

    public String getRoList(UserListResponseProxy userListResponse);

    public String getSchemeList(Long userId);
    
    public String getSchemeListForReport(Long userId);
    
    public List<Long> getSchemeIdList(Long userId);

    public Boolean checkMobile(String mobile);

    public String getAllOfficeTypeList();

    public CommonResponse addNodalAndMinistry(List<UserListResponseProxy> userRequest);

    public List<UserListResponseProxy> getNodalAndMinistry();

    public CommonResponse addFacilitatorOrUlb(UserListResponseProxy userRequest);

    public String getULBList(Long createdBy, AuthClientResponse authClientResponse);

    public UserListResponseProxy getMinistryAndNAByUserId(Long userId);

    public SchemeMasterProxy getMinistryBySchemeId(Long schemeId);

    public List<UserListResponseProxy> getUlbListForNulm();


    public CommonResponse updateMinistryByScheme(UserListResponseProxy userRequest);

    public String getFacilitatorList(Long createdBy, Integer schemeId);

    public List<UlbDistrictMappingProxy> getUlbListDistrictWise(Long districtLgdCode);

    public UlbUserProxy getUlbListForEdit(Long userId);

    boolean userIsLocked(Long userId);

    String userResetPassword(Long userId);
    
    Boolean saveUserAdmin(UsersProxy usersProxy);

	Boolean saveOrganization(UserOrganisationMasterProxy organisationMasterProxy);

	public Boolean isActiveOrg(Long userOrgId);

	public Boolean activeIsActiveUser(Long userId);

    String getOrganizationName(Long orgId);

    String getOrganizationCode(Long orgId);

    List<BranchTypeMaster> getBranchType();

    List<TierMappingPermission> getBranchTypeIdsByOrgId(Long orgId);

    public CommonResponse saveTierConfiguration(List<BranchTypeMasterRequest> branchTypeMasterRequest,Long orgId);


    public String getAllSchemeList();

    public UlbUserMapping getUlbUserMappingByUserId(Long userId);
    
    public UserBranchProxy getUserBranchDetails(Long branchId);
    
    public String getOfficesZoRoBoList(UserListResponseProxy userListResponse);
    
    public List<String> getBoOfficesfromZoId(UserListResponseProxy userListResponse);
    
    public List<String> getBoRoOfficesfromRoZoId(UserListResponseProxy userListResponse);
    
    public String getRoZoUsersList(UserListResponseProxy userListResponse);
    
    public List<SchemeMasterProxy> getSchemeListForAdmin();

	public String getBranchList(AdminRequest request);

    List<UserTypeMasterProxy> getUserTypeMasterList();

    public BranchAndOrgDetailsProxy getOrganisationBasicDetails(Long orgId,Long branchId,Long insurerOrgId);
    
    public UserResponseProxy userGenerateAndResetPassword(Long userId);
    
}
