package com.opl.jns.user.management.service.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.user.management.api.model.*;
import com.opl.jns.user.management.service.domain.*;
import com.opl.jns.user.management.service.repository.*;
import com.opl.jns.user.management.service.service.UsersServiceV3;
import com.opl.jns.user.management.service.utils.CommonUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@Slf4j
public class UsersServiceImplV3 implements UsersServiceV3 {

	@Autowired
    UserRoleMasterRepositoryV3 userRoleMasterRepository;

	@Autowired
    UserPermissionMasterRepositoryV3 userPermissionMasterRepository;

	@Autowired
    UserPermissionMappingRepositoryV3 userPermissionMappingRepository;

	@Autowired
    MenuMasterRepositoryV3 menuMasterRepository;

	@Autowired
    MenuRoleLoanMappingRepositoryV3 menuRoleLoanMappingRepository;

	@Autowired
	UsersRepositoryV3 usersRepository;

//	@Autowired
//	MenuPathMasterRepositoryV3 menuPathMasterRepository;

	@Autowired
	AdminMenuPermissionMappingRepositoryV3 adminMenuPermissionMappingRepository;
	
	@Autowired
	UserRoleProductMappingRepositoryV3 userRoleProductMappingRepository;

	@Override
	public List<RoleMasterProxy> getUserRoleMasterList() {
		log.info("start impl getUserRoleMasterList()");
		try {
			return userRoleMasterRepository.getUserRoleMasterList();
		} catch (Exception e) {
			log.error("error getting while get getUserRoleMasterList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<RoleMasterProxy> getAdminUserRoleMasterList() {
		log.info("start impl getAdminUserRoleMasterList()");
		try {
			return userRoleMasterRepository.getAdminUserRoleMasterList();
		} catch (Exception e) {
			log.error("error getting while get getAdminUserRoleMasterList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<UserPermissionMasterProxy> getPermissionMasterList() {
		log.info("start impl getPermissionMasterList()");
		try {
			return userPermissionMasterRepository.getPermissionMasterList();
		} catch (Exception e) {
			log.error("error getting while get getPermissionMasterList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<Long> getPermissionMappingList(Long orgId, Long userRoleId, Long schemeId) {
		log.info("start impl getPermissionMappingList()");
		try {
			return userPermissionMappingRepository.findByOrgIdAndUserRoleIdAndLoanTypeid(orgId, userRoleId, schemeId);
		} catch (Exception e) {
			log.error("error getting while get getPermissionMappingList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public Boolean savePermission(Long orgId, Long userRoleId, Long schemeId, List<Long> permissionIds) {
		log.info("start impl savePermission()");
		try {
			userPermissionMappingRepository.deleteByOrgIdAndUserRoleIdAndLoanTypeid(orgId, userRoleId, schemeId);
			List<UserPermissionMapping> userPermissionMappingList = new ArrayList<>();
			UserPermissionMapping userPermissionMapping;
			for (Long id : permissionIds) {
				userPermissionMapping = new UserPermissionMapping();
				userPermissionMapping.setPermissionId(id);
				userPermissionMapping.setOrgId(orgId);
				userPermissionMapping.setUserRoleId(userRoleId);
				userPermissionMapping.setSchemeId(schemeId);
				userPermissionMappingList.add(userPermissionMapping);
			}
			userPermissionMappingRepository.saveAll(userPermissionMappingList);
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("error getting while get savePermission", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public List<MenuMasterProxy> getMenuMaser() {
		log.info("start impl getMenuMaser()");
		try {
			List<MenuMaster> menuMasterList = menuMasterRepository.findAll();
			if (!OPLUtils.isListNullOrEmpty(menuMasterList)) {
				List<MenuMasterProxy> menuMasterProxyList = new ArrayList<>(menuMasterList.size());
				MenuMasterProxy tempMenuMaster;
				for (MenuMaster menu : menuMasterList) {
					tempMenuMaster = new MenuMasterProxy();
					BeanUtils.copyProperties(menu, tempMenuMaster);
					menuMasterProxyList.add(tempMenuMaster);
				}
				return menuMasterProxyList;
			}
		} catch (Exception e) {
			log.error("Exception is getting while get all menu ", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<MenuRoleLoanMappingProxy> getMenuMappingList(Long roleId, Long businessTypeId, Integer schemeId) {
		log.info("start impl getMenuMappingList()");
		try {
			return menuRoleLoanMappingRepository.findMenuIdByRoleIdAndBusinessTypeIdAndSchemeId(roleId, businessTypeId, schemeId);
		} catch (Exception e) {
			log.error("Exception is getting while get getMenuMappingList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public Boolean saveMenuMappingList(MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) {
		log.info("start impl saveMenuMappingList()");
		try {
			menuRoleLoanMappingRepository.deleteByRoleIdAndBusinessTypeIdAndSchemeId(menuRoleLoanMappingProxy.getRoleId(), menuRoleLoanMappingProxy.getBusinessTypeId(), menuRoleLoanMappingProxy.getSchemeId());
			MenuRoleLoanMapping menuRoleLoanMapping;
			int i = 1;
			for (MenuMasterProxy menuMasterProxy : menuRoleLoanMappingProxy.getMenuMasterProxy()) {
				menuRoleLoanMapping = new MenuRoleLoanMapping();
				menuRoleLoanMapping.setMenuId(menuMasterProxy.getId());
				menuRoleLoanMapping.setRoleId(menuRoleLoanMappingProxy.getRoleId());
				menuRoleLoanMapping.setBusinessTypeId(menuRoleLoanMappingProxy.getBusinessTypeId());
				menuRoleLoanMapping.setSequence(i);
				menuRoleLoanMapping.setIsActive(Boolean.TRUE);
				menuRoleLoanMapping.setSchemeId(menuRoleLoanMappingProxy.getSchemeId());
				menuRoleLoanMappingRepository.save(menuRoleLoanMapping);
				i++;
			}
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("exception is getting while save menu Permission", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public Boolean saveMenu(MenuMasterProxy menuMasterProxy) {
		log.info("start impl saveMenu()");
		try {
			MenuMaster menuMaster = new MenuMaster();
			menuMaster.setKeyName(menuMasterProxy.getKeyName());
			menuMaster.setDisplayName(menuMasterProxy.getDisplayName());
			menuMaster.setParentId(menuMasterProxy.getParentId());
			menuMaster.setIconPath("Dashbord-inactive.svg");
			menuMaster.setIsActive(Boolean.TRUE);
			menuMasterRepository.save(menuMaster);
			log.info("Save successfully Menu");
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("exception is getting while Add Menu", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public Boolean deleteMenu(Long id) {
		log.info("start impl deleteMenu()");
		try {
			menuMasterRepository.deleteById(id);
			log.info("Delete successfully Menu");
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("exception is getting while Delete Menu", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public List<MenuMasterProxy> getAdminMenuMaser(Long roleId) {
		log.info("start impl getAdminMenuMaser()");
		try {
			List<MenuMaster> menuAdminMasterList = null;
			if (roleId == 101) {
				menuAdminMasterList = menuMasterRepository.findByIsAdminMenu(Boolean.TRUE);
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(roleId)) {
					menuAdminMasterList = menuMasterRepository.findByRoleId(roleId);
				}
			}

			if (menuAdminMasterList != null && !menuAdminMasterList.isEmpty()) {
				List<MenuMasterProxy> menuMasterProxyList = new ArrayList<>(menuAdminMasterList.size());
				MenuMasterProxy tempMenuMaster;
				for (MenuMaster menu : menuAdminMasterList) {
					tempMenuMaster = new MenuMasterProxy();
					BeanUtils.copyProperties(menu, tempMenuMaster);
					menuMasterProxyList.add(tempMenuMaster);
				}
				return menuMasterProxyList;
			}
		} catch (Exception e) {
			log.error("Exception is getting while get all menu ", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<MenuRoleLoanMappingProxy> getAdminMenuMappingList(Long roleId) {
		log.info("start impl getAdminMenuMappingList()");
		try {
			return menuRoleLoanMappingRepository.findMenuIdByRoleId(roleId);
		} catch (Exception e) {
			log.error("Exception is getting while get getAdminMenuMappingList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public Boolean saveAdminPermission(MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) {
		log.info("start impl saveAdminPermission()");
		try {
			menuRoleLoanMappingRepository.deleteByRoleId(menuRoleLoanMappingProxy.getRoleId());
			int i = 1;
			for (MenuMasterProxy masterProxy : menuRoleLoanMappingProxy.getMenuMasterProxy()) {
				MenuRoleLoanMapping menuRoleLoanMapping = new MenuRoleLoanMapping();
				menuRoleLoanMapping.setMenuId(masterProxy.getId());
				menuRoleLoanMapping.setRoleId(menuRoleLoanMappingProxy.getRoleId());
				menuRoleLoanMapping.setBusinessTypeId(0l);
				menuRoleLoanMapping.setSequence(i);
				menuRoleLoanMapping.setIsActive(Boolean.TRUE);
				menuRoleLoanMapping.setSchemeId(0);
				menuRoleLoanMappingRepository.save(menuRoleLoanMapping);
				i++;
			}
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("Exception Is Getting While Save Permission ", e);
		}
		return Boolean.FALSE;
	}

	@Override
	public List<UserPermissionMasterProxy> getAdminPermissionMasterList(Long roleId) {
		log.info("start impl getAdminPermissionMasterList()");
		try {
			if (roleId == 101) {
				return userPermissionMasterRepository.getMasterAdminPermissionMasterList();
			} else {
				if (!OPLUtils.isObjectNullOrEmpty(roleId)) {
					List<UserPermissionMaster> userPermissionMasterList = userPermissionMasterRepository.getAdminPermissionMasterList(roleId);
					if (!OPLUtils.isListNullOrEmpty(userPermissionMasterList)) {
						List<UserPermissionMasterProxy> proxiesList = new ArrayList<>(userPermissionMasterList.size());
						for (UserPermissionMaster permissionMaster : userPermissionMasterList) {
							UserPermissionMasterProxy masterProxy = MultipleJSONObjectHelper.getObjectFromObject(permissionMaster, UserPermissionMasterProxy.class);
							proxiesList.add(masterProxy);
						}
						return proxiesList;
					}
				}
			}
		} catch (Exception e) {
			log.error("error getting while get getPermissionMasterList", e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<AdminMenuPermissionMappingProxy> getAdminMenuPermissionMappingList(Long roleId) {
		log.info("start impl getAdminMenuPermissionMappingList()");
		try {
			List<AdminMenuPermissionMapping> masterList = adminMenuPermissionMappingRepository.findByRoleId(roleId);
			if (!OPLUtils.isListNullOrEmpty(masterList)) {
				List<AdminMenuPermissionMappingProxy> proxyList = new ArrayList<>(masterList.size());
				AdminMenuPermissionMappingProxy tempProxy = null;
				for (AdminMenuPermissionMapping masterObj : masterList) {
					tempProxy = new AdminMenuPermissionMappingProxy();
					BeanUtils.copyProperties(masterObj, tempProxy);
					proxyList.add(tempProxy);
				}
				return proxyList;
			}
		} catch (Exception e) {
			log.error("error getting while get getAdminMenuPermissionMappingList", e);
		}
		return Collections.emptyList();
	}
//
	@Override
	public Boolean saveAdminMenuPermission(AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy) {
		log.info("start impl saveAdminMenuPermission()");
		try {
			adminMenuPermissionMappingRepository.deleteMenuIdByRoleId(adminMenuPermissionMappingProxy.getRoleId());
			List<AdminMenuPermissionMapping> masterList = new ArrayList<>();
			AdminMenuPermissionMapping temp = null;
			for (Long id : adminMenuPermissionMappingProxy.getIdsList()) {
				temp = new AdminMenuPermissionMapping();
				temp.setMenuId(id);
				temp.setTypeId(CommonUtils.ADMIN_PANEL_TYPE_ID);
				temp.setRoleId(adminMenuPermissionMappingProxy.getRoleId());
				temp.setSchemeId(adminMenuPermissionMappingProxy.getSchemeId()!=null ?-1 :0);
				temp.setIsActive(Boolean.TRUE);
				masterList.add(temp);
			}
			adminMenuPermissionMappingRepository.saveAll(masterList);
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("error getting while get saveAdminMenuPermission", e);
		}
		return Boolean.FALSE;
	}
//
//	@Override
//	public Boolean saveAdminBasicPermission(AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy) {
//		log.info("start impl saveAdminBasicPermission()");
//		try {
//			adminMenuPermissionMappingRepository.deletePermissionIdByRoleId(adminMenuPermissionMappingProxy.getRoleId());
//			List<AdminMenuPermissionMapping> masterList = new ArrayList<>();
//			AdminMenuPermissionMapping temp = null;
//			for (Long id : adminMenuPermissionMappingProxy.getIdsList()) {
//				temp = new AdminMenuPermissionMapping();
//				temp.setPermissionId(id);
//				temp.setRoleId(adminMenuPermissionMappingProxy.getRoleId());
//				masterList.add(temp);
//			}
//			adminMenuPermissionMappingRepository.saveAll(masterList);
//			return Boolean.TRUE;
//		} catch (Exception e) {
//			log.error("error getting while get saveAdminBasicPermission", e);
//		}
//		return Boolean.FALSE;
//	}

	@Override
	public Boolean changeOrgIdAndBranchIdAndRoleId(UsersProxy usersProxy) {
		try {
			if(!OPLUtils.isObjectNullOrEmpty(usersProxy.getUserRoleId())) {
				userRoleProductMappingRepository.updateRoleIdByUserId(usersProxy.getUserId(), usersProxy.getUserRoleId());	
			}
			usersRepository.changeOrgIdAndBranchIdAndRoleId(usersProxy.getUserId(),usersProxy.getOrgId(),usersProxy.getBranchId()!= null ? usersProxy.getBranchId(): null, usersProxy.getUserRoleId()!= null ? usersProxy.getUserRoleId(): null);
			return Boolean.TRUE;	
		} catch (Exception e) {
			log.error("exception is geting while update data");
		}
		return Boolean.FALSE;	
	}

	@Override
	public Boolean changeAdminUserRole(UsersProxy usersProxy) {
		try {
			userRoleProductMappingRepository.changeAdminUserRole(usersProxy.getUserId(), usersProxy.getUserRoleId());
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error("exception is geting while change admin Role");
		}
		return Boolean.FALSE;
	}

	@Override
	public List<RoleMasterProxy> getPartnerRoleMasterList() {
		log.info("start impl getPartnerRoleMasterList()");
		try {
			return userRoleMasterRepository.getPartnerRoleMasterList();
		} catch (Exception e) {
			log.error("error getting while get getPartnerRoleMasterList", e);
		}
		return Collections.emptyList();
	}

}
