package com.opl.jns.user.management.service.domain;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "business_master")
public class BusinessMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "business_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "business_master_mana_seq_gen", sequenceName = "business_master_mana_seq", allocationSize = 1)
	private Long id;

	@Column(name = "display_name", columnDefinition = "varchar(255) default ''")
	private String displayName;

	@Column(name = "img_path", columnDefinition = "varchar(500) default ''")
	private String imgPath;
	
	
	@Column(columnDefinition = "varchar(30) default ''")
	private String path;

	private Integer sequence;
	
	
	@Column(name = "order_id")
	private Integer orderId;
}
