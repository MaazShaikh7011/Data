package com.opl.jns.user.management.service.controller.bulkUpload;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.user.management.api.model.BulkUserResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.service.bulkUpload.BulkUserCreationServiceV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class BulkUserCreationControllerV3 {

    @Autowired
    private BulkUserCreationServiceV3 bulkUserCreationService;

    private static final Logger logger = LoggerFactory.getLogger(BulkUserCreationControllerV3.class);

    /**
     * @param multipartFiles
     * @param request
     * @return
     * @author Pooja
     */
    @PostMapping(value = "/import/user", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> bulkUserCreation(@RequestPart("file") MultipartFile multipartFiles, 
    		HttpServletRequest request,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        Boolean isInOurFormat = null;
        UserResponseProxy userResponse = null;
        try {
        	
        	if(OPLUtils.isObjectNullOrEmpty(authClientResponse) || OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserOrgId())) {
        		logger.info("Organization is not Found");
                 return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("please try after some times.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        	}
            Long fileId = null;
            Long userOrgId = authClientResponse.getUserOrgId();
            logger.info("orgId====>{}",userOrgId);
            
//            List<Long> schemeTypelist = new ArrayList<Long>();
//            if (!schemeList.isEmpty()) {
//                String list = schemeList;
//                String[] list2 = list.replaceAll("\\[|\\]| ", "").split(",");
//                for (int i = 0; i < list2.length; i++) {
//                	schemeTypelist.add(Long.parseLong(list2[i]));
//                }
//            }
//            if (!businessTypeList.isEmpty()) {
//                String list = businessTypeList;
//                String[] list2 = list.replaceAll("\\[|\\]| ", "").split(",");
//                List<Integer> businesslist = new ArrayList<Integer>();
//                for (int i = 0; i < list2.length; i++) {
//                    businesslist.add(Integer.parseInt(list2[i]));
//                }
            	Long productDocMappingId = UserCreationUtil.USER_EXCEL_LIST_FOR_COMMON;
            	Long userRoleId = authClientResponse.getUserRoleId();
            	Long userBranchId = authClientResponse.getUserBranchId();
                fileId = bulkUserCreationService.uploadExcelFileToDms(userOrgId, multipartFiles, productDocMappingId);
            	Boolean user = false;
                if(OPLUtils.isObjectNullOrEmpty(fileId)){
                    return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("File is not uploaded, please try after some times.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
                }
                
                if (userRoleId == UserRoleMaster.RO.getId() || userRoleId == UserRoleMaster.ZO.getId()) {
                	user = bulkUserCreationService.extractExcelRoZo(multipartFiles, userOrgId, fileId, userRoleId, userBranchId);
                }
                if (userRoleId == UserRoleMaster.HEAD_OFFICE.getId()) {
                	 user = bulkUserCreationService.extractExcel(multipartFiles, userOrgId, fileId, userRoleId, userBranchId);
                }
                if(user == false){
                    return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("You have uploaded wrong file.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
                }
                userResponse = new UserResponseProxy();
                userResponse.setMessage("Successfully Extracted!");
                userResponse.setData(fileId);
                userResponse.setListData(null);
                userResponse.setStatus(HttpStatus.OK.value());
                return new ResponseEntity<UserResponseProxy>(userResponse, HttpStatus.OK);
//            }else {
//                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Problem while Uploading File!!", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
//            }
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/listImportedExcelUser/{orgId}/{businessTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> listUserImportedExcel(@PathVariable Long orgId,@PathVariable Integer businessTypeId, HttpServletRequest request,
    		@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        //   Long orgId = Long.valueOf(String.valueOf(request.getAttribute(CommonUtils.USER_ORG_ID)));
        UserResponseProxy userResponse = null;
        try {
            userResponse = bulkUserCreationService.listUploadedExcelFP(orgId,businessTypeId, authClientResponse.getUserBranchId(), authClientResponse.getUserRoleId());
            userResponse.setMessage(UserCreationUtil.SUCCESSFULLY_LISTED);
            userResponse.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<UserResponseProxy>(userResponse, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/user/getFileEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getFileEntries(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            List<BulkUserResponseProxy> bulkUserResponseList = bulkUserCreationService.getFileEntryList(fileResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUserRoleEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserRoleEntries(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserCreationService.getUserRoleEntries(userListResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUserEntryCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserEntryCount(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserCreationService.getUserEntryCount(userListResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getAllUserEntryList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllUserEntryList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            List<BulkUserResponseProxy> bulkUserResponseList = bulkUserCreationService.getAllUserEntryList(userListResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUserFileEntryCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getUserFileEntryCount(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserCreationService.getUserFileEntryCount(fileResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }


    @PostMapping(value = "/import/facilitatorOrUlb", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> bulkFacilitatorOrUlbCreation(@RequestPart("file") MultipartFile multipartFiles,@RequestPart("schemeId") String schemeId, HttpServletRequest request,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        Boolean isInOurFormat = null;
        UserResponseProxy userResponse = null;
        try {
        	if (authClientResponse == null || authClientResponse.getUserId() == null) {
                return new ResponseEntity<>(new UserResponseProxy("Unauthorized Request", HttpStatus.UNAUTHORIZED.value()), HttpStatus.BAD_REQUEST);
            }
            logger.info("Enter import facilitator Or Ulb");
            Long fileId = null;
            List<Long> schemeTypelist = new ArrayList<Long>();
            Long productDocMappingId = null;
                    if(OPLUtils.isObjectNullOrEmpty(fileId)) {
                        if(authClientResponse.getUserType() == UserTypeMaster.COUNCIL.getId()){
                            productDocMappingId = UserCreationUtil.FACILITATOR_EXCEL_LIST;
                        }else{
                            productDocMappingId = UserCreationUtil.ULB_EXCEL_LIST;
                        }
                        fileId = bulkUserCreationService.uploadExcelFileToDms(authClientResponse.getUserId(), multipartFiles, productDocMappingId);
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(fileId)) {
                        if(authClientResponse.getUserType() == UserTypeMaster.COUNCIL.getId()){
                            bulkUserCreationService.extractExcelForFacilitator(multipartFiles, authClientResponse.getUserId(), fileId, Long.valueOf(schemeId), authClientResponse.getUserType());
                        }else{
                            bulkUserCreationService.extractExcelForUlb(multipartFiles, authClientResponse, fileId, Long.valueOf(schemeId), authClientResponse.getUserType());
                        }
                    }

                userResponse = new UserResponseProxy();
                userResponse.setMessage("Successfully Extracted!");
                userResponse.setData(fileId);
                userResponse.setListData(null);
                userResponse.setStatus(HttpStatus.OK.value());
                return new ResponseEntity<UserResponseProxy>(userResponse, HttpStatus.OK);

        } catch (Exception e) {
            logger.error("Error while import facilitator Or Ulb", e);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/listImportedExcelFacilitatorOrUlb/{userId}/{userType}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> listImportedExcelFacilitatorOrUlb(@PathVariable Long userId, @PathVariable Long userType,HttpServletRequest request) {
        //   Long orgId = Long.valueOf(String.valueOf(request.getAttribute(CommonUtils.USER_ORG_ID)));
        try {
            logger.info("Enter list Imported Excel Facilitator Or Ulb");
            return new ResponseEntity<UserResponseProxy>(bulkUserCreationService.listUploadedExcelFacilitatorOrUlb(userId,userType), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error while list Imported Excel Facilitator Or Ulb", e);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/facilitatorOrUlb/getFileEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getFileFacilitatorEntries(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            logger.info("Enter getFileEntries Facilitator Or Ulb");
            List<BulkUserResponseProxy> bulkUserResponseList = bulkUserCreationService.getFileFacilitatorOrUlbEntryList(fileResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkUserResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error getFileEntries Facilitator Or Ulb", e);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }
}
