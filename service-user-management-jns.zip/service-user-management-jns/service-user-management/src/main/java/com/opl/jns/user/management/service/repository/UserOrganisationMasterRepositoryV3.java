package com.opl.jns.user.management.service.repository;

import java.util.List;

import com.opl.jns.user.management.api.model.UserOrganisationMasterProxy;
import com.opl.jns.user.management.service.domain.UserOrganisationMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserOrganisationMasterRepositoryV3 extends JpaRepository<UserOrganisationMaster, Long>  {

//	public List<UserOrganisationMaster> findByIsActiveAndOrgType(Boolean isActive, Integer orgType);

	//public UserOrganisationMaster findById(Integer orgId);

	public UserOrganisationMaster findByUserOrgId(Long orgId);

//	@Query(value="SELECT u.organisationName FROM UserOrganisationMaster u WHERE u.userOrgId=:userOrgId AND isActive=TRUE")
//	String getMinistryName(@Param("userOrgId") Long userOrgId);

	@Query(value="SELECT new com.opl.jns.user.management.api.model.UserOrganisationMasterProxy(u.userOrgId,u.organisationName) FROM UserOrganisationMaster u WHERE u.isActive=TRUE")
	List<UserOrganisationMasterProxy> findAllOrganization();

	public UserOrganisationMaster findByOrganisationName(String organisationName);

	@Modifying
	@Query(value="UPDATE UserOrganisationMaster u SET u.isActive = FALSE WHERE u.userOrgId=:userOrgId")
	public void deleteByUserOrgId(@Param("userOrgId") Long userOrgId);


	@Query(value="SELECT u.displayOrgName FROM UserOrganisationMaster u WHERE isActive=TRUE AND u.userOrgId=:userOrgId ")
	String getBankName(@Param("userOrgId") Long userOrgId);

	@Query(value="SELECT u.organisationCode FROM UserOrganisationMaster u WHERE isActive=TRUE AND u.userOrgId=:userOrgId ")
	String getBankCode(@Param("userOrgId") Long userOrgId);

	@Query(value="SELECT new com.opl.jns.user.management.api.model.UserOrganisationMasterProxy(u.organisationCode,u.organisationName) FROM UserOrganisationMaster u WHERE u.isActive=true AND u.userOrgId=:userOrgId ")
	UserOrganisationMasterProxy getNameAndCodeByOrgId(@Param("userOrgId") Long userOrgId);
}
