package com.opl.jns.user.management.service.service.bulkUpload.impl;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import jakarta.transaction.Transactional;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.oneform.api.exception.OneFormException;
import com.opl.jns.oneform.api.model.LgdDistrictStateResponse;
import com.opl.jns.oneform.api.model.MasterResponse;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.user.management.api.model.BulkBranchResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.domain.BranchMaster;
import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.user.management.service.domain.BulkBranchCreation;
import com.opl.jns.user.management.service.repository.BranchMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.bulkUpload.BulkBranchCreationRepositoryV3;
import com.opl.jns.user.management.service.service.bulkUpload.BulkBranchCreationServiceV3;
import com.opl.jns.user.management.service.utils.BulkUploadComponent;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;

/**
 * Created by dhaval.panchal on 15-Oct-19.
 */
@Service
@Transactional
public class BulkBranchCreationServiceImplV3 implements BulkBranchCreationServiceV3 {

    private static final Logger logger = LoggerFactory.getLogger(BulkBranchCreationServiceImplV3.class);
//    private static SimpleDateFormat FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    @Autowired
    private DMSClient dmsClient;

    @Autowired
    private BulkBranchCreationRepositoryV3 bulkBranchCreationRepository;
    
    @Autowired
    private BranchMasterRepositoryV3 branchMasterRepository;
    
    @Autowired
    private BranchProductMappingRepositoryV3 branchProductMappingRepo;

    @Autowired
    private UserOrganisationMasterRepositoryV3 userOrganisationMasterRepository;

//    @Autowired
//    private UsersRepositoryV3 userRepo;

    @Autowired
    UserTypeMasterRepositoryV3 userTypeRepo;

    @Autowired
    UserRoleMasterRepositoryV3 userRoleMasterRepo;

    @Autowired
    UserRoleProductMappingRepositoryV3 roleProductMapping;

    @Autowired
    BulkUploadComponent bulkUploadComponent;

    @Autowired
    OneFormClient oneFormClient;
    
    @Autowired
	private Environment environment;

    @Value("${cw.user.default.password}")
    private String defaultPwd;

    public boolean isRowEmpty(Row row) {
        if (row != null) {
            for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
                Cell cell = row.getCell(c);
                if (cell != null && cell.getCellTypeEnum() != CellType.BLANK)
                    return false;
            }
        }
        return true;
    }

    @Override
    public Boolean extractExcel(MultipartFile multipartFile, Long orgId, Long fileId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId) {
        Workbook workbook = null;
        try {
            workbook = WorkbookFactory.create(multipartFile.getInputStream());

        } catch (Exception e) {
            logger.error("Exception :- ", e);
        }
        Sheet worksheet = (Sheet) workbook.getSheetAt(1);
        String sheetName = worksheet.getSheetName();
        if(!sheetName.equals("Office Creation")){
            return false;
        }
        logger.info("Row Num : {}", worksheet.getLastRowNum());
        String email = null, mobile = null, branchName = null, branchCode = null, ifscCode = null, address = null, branchType = null, roCode = null, zoCode = null, originalFileName = null, ruralUrban = null;
        Integer stateId, cityId,pincode;

        originalFileName = multipartFile.getOriginalFilename();
        //NEW CODE
        List<BulkBranchCreation> bulkBranchCreationList = new ArrayList<>(503);
        List<BranchProductMapping> branchProductMappings = new ArrayList<>();
        BulkBranchCreation bulkBranchCreation = null;
        int row = 25003; // worksheet.getPhysicalNumberOfRows() < 503 ? worksheet.getPhysicalNumberOfRows() : 503;
//        int blankRowCount = 0;
        List<BranchMaster> allBranchAndCode = branchMasterRepository.getAllBranchByOnOrgId(orgId);
        List<String> codeList = new ArrayList<>();
        List<MasterResponse> stateList = new ArrayList<>();
        try {
            stateList = oneFormClient.getStateListByCountryId(101l);
        } catch (OneFormException e) {
            logger.error("Oneform client==>>",e);
        }
        for (int i = 3; i <= row; i++) {
            if(isRowEmpty(worksheet.getRow(i-1))){
                continue;
            }
            try {
                stateId = null;
                cityId = null;
                pincode = null;
                branchType = extractCellFromSheet(worksheet, "A" + i);
//                email = extractCellFromSheet(worksheet, "B" + i);
//                mobile = extractCellFromSheet(worksheet, "C" + i);
                branchName = extractCellFromSheet(worksheet, "B" + i);
                branchCode = extractCellFromSheet(worksheet, "C" + i);
                ifscCode = extractCellFromSheet(worksheet, "D" + i);
                address = extractCellFromSheet(worksheet, "E" + i);
                try {
                    pincode = extractCellFromSheet(worksheet, "F" + i) != null && extractCellFromSheet(worksheet, "F" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "F" + i)) : null;
                    stateId = extractCellFromSheet(worksheet, "G" + i) != null && extractCellFromSheet(worksheet, "G" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "G" + i)) : null;
                    cityId = extractCellFromSheet(worksheet, "H" + i) != null && extractCellFromSheet(worksheet, "H" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "H" + i)) : null;
                } catch (NumberFormatException e) {
                    logger.error("Exception :- ", e);
                }
                ruralUrban = extractCellFromSheet(worksheet, "I" + i);
                roCode = extractCellFromSheet(worksheet, "J" + i);
                zoCode = extractCellFromSheet(worksheet, "K" + i);

                //check if mandatory fields are null or not!!
                if (OPLUtils.isObjectNullOrEmpty(branchType) &&
//                        OPLUtils.isObjectNullOrEmpty(email) &&
//                        OPLUtils.isObjectNullOrEmpty(mobile) &&
                        OPLUtils.isObjectNullOrEmpty(branchName) &&
                        OPLUtils.isObjectNullOrEmpty(branchCode) &&
                        OPLUtils.isObjectNullOrEmpty(ifscCode) &&
                        OPLUtils.isObjectNullOrEmpty(address) &&
                        OPLUtils.isObjectNullOrEmpty(pincode) &&
                        OPLUtils.isObjectNullOrEmpty(stateId) &&
                        OPLUtils.isObjectNullOrEmpty(cityId)) {
                    continue;
                }
                boolean isActive = false;
//                boolean isUserExist = false;
                String msg = "";
                // CHECK BASIC VALIDATION
                if (OPLUtils.isObjectNullOrEmpty(branchType)) {
                    msg = "Branch Type can not be null";
                }
                if (!(branchType.equalsIgnoreCase("Branch Office") || branchType.equalsIgnoreCase("Regional Office") || branchType.equalsIgnoreCase("Zonal Office"))
                ) {
                    msg = "Invalid Branch type";
                }
                if (!OPLUtils.isObjectNullOrEmpty(branchType) && branchType.equalsIgnoreCase("Branch Office")) {
                    if (OPLUtils.isObjectNullOrEmpty(ifscCode)) {
                        msg = "Ifsc Code can not be null";
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(ifscCode) && ifscCode.length() != 11 && !Pattern.matches("[A-Z|a-z]{4}[0][\\d]{6}$", ifscCode)) {
                        msg = "Invalid Ifsc Code";
                    }
                }
// 				comment 23/12/2021
//                if (!OPLUtils.isObjectNullOrEmpty(branchType) && branchType.equalsIgnoreCase("Regional Office")) {
//                    if (OPLUtils.isObjectNullOrEmpty(zoCode)) {
//                        msg = "ZO Code can not be null";
//                    }
//                }
                
                
            /*
			 * if (OPLUtils.isObjectNullOrEmpty(email)) { msg = "EmailId can not be null"; }
			 * else { if (emailList.contains(email.toUpperCase())) { msg =
			 * "EmailId is already exist in given sheet"; } else { if (email.length() > 255
			 * || !Pattern.matches(
			 * "^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$",
			 * email)) { msg = "EmailId is Invalid"; } } }
			 * 
			 * if (OPLUtils.isObjectNullOrEmpty(mobile)) { msg = "Mobile can not be null";
			 * }else{ if (emailList.contains(email.toUpperCase())) { msg =
			 * "Mobile is already exist in given sheet"; } else { if (mobile.length() > 10)
			 * { msg = "MobileNo is Invalid"; mobile = ""; } } } /* if (mobile.length() >
			 * 10) { msg = "MobileNo is Invalid"; mobile = ""; }
			 */
			if (OPLUtils.isObjectNullOrEmpty(branchName)) {
				msg = "Branch Name can not be null";
			} else if (branchName.length() > 100 || !Pattern.matches("^[a-zA-Z0-9&\\,(\\)\\-.\\ ]+$", branchName)) {
				msg = "Please Enter Valid Branch Name";
			} else if (branchName.length() < 1) {
				msg = "Minimum 1 Charater branch Name required";
			} else if (branchName.length() > 100) {
				msg = "Maximum 100 Charater branch Name required";
			}
			if (OPLUtils.isObjectNullOrEmpty(branchCode)) {
				msg = "Branch Code can not be null";
			} else {
				if (codeList.contains(branchCode)) {
					msg = "Branch is already exist in given sheet";
				} else if (branchCode.length() > 50 || !Pattern.matches("^[a-zA-Z0-9]+$", branchCode)) {
					msg = "Please Enter Valid Branch Code";
				} else if (branchCode.length() < 1) {
					msg = "Minimum 2 Charater branch Code required";
				} else if (branchCode.length() > 50) {
					msg = "Maximum 30 Charater branch Code required";
				}

			}

			if (OPLUtils.isObjectNullOrEmpty(address)) {
				msg = "Address Code can not be null";
			} else if (address.length() > 200 || !Pattern.matches("^[a-zA-Z0-9&\\,(\\)\\-.\\ \\/]+$", address)) {
				msg = "Please Enter Valid Address";
			} else if (address.length() < 1) {
				msg = "Minimum 1 Charater Address required";
			} else if (address.length() > 200) {
				msg = "Maximum 200 Charater Address required";
			} 
			else {
				address = address.replace("\n", "").replace("\r", "").replaceAll("[\\p{Cf}]", "");
			}
			if (OPLUtils.isObjectNullOrEmpty(stateId)) {
				msg = "StateId can not be null";
			} else {
				Integer finalStateId = stateId;
				if (OPLUtils
						.isObjectNullOrEmpty(stateList.stream().filter(a -> a.getMappingId().equals(finalStateId)))) {
					msg = "StateId is not valid";
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(cityId)) {
				msg = "CityId can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(pincode)) {
				msg = "Pincode can not be null";
			}
            if(OPLUtils.isObjectNullOrEmpty(ruralUrban)) {
                msg = "Rural/Urban can not be null";
            }
			if (!OPLUtils.isObjectNullOrEmpty(pincode) && pincode.toString().length() > 6) {
				msg = "Invalid Pincode";
			}
			if (OPLUtils.isObjectNullOrEmpty(msg)) {
				isActive = true;
			}
                //CHECK BRANCH IS EXIST OR NOT
                BranchMaster branchMaster = null;
                List<Long> schemeIdsByBranchId = null;
                Long roId = null;
                Long zoId = null;
                // User emailExist = null;
          //      BulkUploadUserExistProxy bulkUploadUserExistProxy = null;

                if(isActive) {
                    // NOT NULL
//                    emailList.add(email.toUpperCase());
//                    mobileList.add(mobile.toLowerCase());
                    codeList.add(branchCode);
                }
                if (isActive) {
                    String bCode = branchCode;
//                    List<BranchMaster> branchMasterList = branchMasterRepository.getBranchByCodeAndOrg(bCode, orgId);
//                    if (!OPLUtils.isListNullOrEmpty(branchMasterList)) {
//                        branchMaster = branchMasterList.get(0);
//                    }
                    Optional<BranchMaster> getBranch = allBranchAndCode.stream().filter(branch -> bCode.equals(branch.getCode())).findFirst();
                    if (getBranch.isPresent()) {
                        branchMaster = getBranch.get();
                    }
                    if (branchType.equalsIgnoreCase("Branch Office")) {
                        try {
                            if (!OPLUtils.isObjectNullOrEmpty(roCode)) {
                                String rCode = roCode;
                                roId = allBranchAndCode.stream().filter(a -> rCode.equals(a.getCode())
                                        && a.getBranchType() == 2).map(b -> b.getId()).findFirst().orElse(null);
                                if (roId == null) {
                                    isActive = false;
                                    msg = "RO is not valid";
                                }
                            }
                            if (!OPLUtils.isObjectNullOrEmpty(zoCode)) {
                                String zCode = zoCode;
                                zoId = allBranchAndCode.stream().filter(a -> zCode.equals(a.getCode())
                                        && a.getBranchType() == 3).map(b -> b.getId()).findFirst().orElse(null);
                                if (zoId == null) {
                                    isActive = false;
                                    msg = "ZO is not valid";
                                } else {
                                    if (roId != null) {
                                        Long tempZo = branchProductMappingRepo.getZoIdByRoId(roId, orgId);
                                        if (OPLUtils.isObjectNullOrEmpty(tempZo) || !tempZo.equals(zoId)) {
                                            isActive = false;
                                            msg = "Given ZO is not tagged with given RO";
                                        }
                                    }
                                }
                            }
                        } catch (Exception e) {
                            logger.error("Exception while check Branch Code ", e);
                        }
                    }
                    if (branchType.equalsIgnoreCase("Regional Office")) {
                        try {
                            if (!OPLUtils.isObjectNullOrEmpty(zoCode)) {
                                String zCode = zoCode;
                                zoId = allBranchAndCode.stream()
                                        .filter(a -> zCode.equals(a.getCode())
                                                && a.getBranchType() == 3)
                                        .map(b -> b.getId())
                                        .findFirst().orElse(null);
                                if (zoId == null) {
                                    isActive = false;
                                    msg = "ZO is not valid";
                                }
                            }
                        } catch (Exception e) {
                            logger.error("Exception while check Branch Code ", e);
                        }
                    }
                  /*  if (isActive) {
                        // CHECK EMAIL OR MOBILE IS DUBLICATE OR NOT
                        bulkUploadUserExistProxy = bulkUploadComponent.checkEmailOrMobileExist(email, mobile);
                     /*   if (!bulkUploadUserExistProxy.getIsActive()) {
                            isActive = false;
                            msg = bulkUploadUserExistProxy.getMessage();
                        }*/
                        /*else {
                            if (bulkUploadUserExistProxy.getUser() != null) {
                                isActive = false;
                                msg = "Email Or Mobile Is Already Exists";
                            }
                        }
                    }*/

                    if (branchMaster != null) {
                        schemeIdsByBranchId = branchProductMappingRepo.getSchemeListByBranchId(branchMaster.getId());
                    }
                }

//            List<UserRoleProductMapping> userRoleProductMappings = null;
//            if(emailExist != null) {
//                userRoleProductMappings = roleProductMapping.findByUserUserId(emailExist.getUserId());
//            }
                List<Long> saveSchemeList = new ArrayList<>(schemeTypelist);
                BranchProductMapping branchProductMapping = null;
                schemeWiseLoop:
                for (Long schemeId : schemeTypelist) {
                    SchemeMaster scheme = SchemeMaster.getById(schemeId);
                    try {
                        bulkBranchCreation = new BulkBranchCreation();
                        bulkBranchCreation.setBranchType(OPLUtils.isObjectNullOrEmpty(branchType) ? null : branchType);
                        bulkBranchCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null : email);
                        bulkBranchCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null : mobile);
                        bulkBranchCreation.setBranchName(OPLUtils.isObjectNullOrEmpty(branchName) ? null : branchName.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(branchCode) ? null : branchCode.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setIfscCode(OPLUtils.isObjectNullOrEmpty(ifscCode) ? null : ifscCode);
                        bulkBranchCreation.setAddress(OPLUtils.isObjectNullOrEmpty(address) ? null : address.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setPincode(pincode);
                        bulkBranchCreation.setState(stateId);
                        bulkBranchCreation.setCity(cityId);
                        bulkBranchCreation.setRoCode(OPLUtils.isObjectNullOrEmpty(roCode) ? null : roCode);
                        bulkBranchCreation.setZoCode(OPLUtils.isObjectNullOrEmpty(zoCode) ? null : zoCode);
                        bulkBranchCreation.setOrgId(orgId);
                        bulkBranchCreation.setBusinessTypeId(Long.valueOf(scheme.getBussinessTypeId()));
                        bulkBranchCreation.setSchemeId(scheme.getId());
                        bulkBranchCreation.setDateTime(new Date());
                        bulkBranchCreation.setFileId(fileId);
                        bulkBranchCreation.setUserRoleId(userRoleId);
                        bulkBranchCreation.setRuralUrban(OPLUtils.isObjectNullOrEmpty(ruralUrban) ? null : ruralUrban);
//                        bulkBranchCreation.setCreatedByBranchId(String.valueOf(userBranchId));
                        bulkBranchCreation.setOriginalFileName(originalFileName);

                        // STEP CHECK NULL || CREATE
                        if (isActive && OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                            branchMaster = createBranch(bulkBranchCreation, orgId);
                            isActive = true;
                        }       
                        // CHECK schemeIdsByBranchId IS ALREADY EXITS OR NOT

                        if (schemeIdsByBranchId != null && schemeIdsByBranchId.size() > 0) {
                            if (schemeIdsByBranchId.contains(scheme.getId())) {
                                saveSchemeList.remove(schemeId);
                                bulkBranchCreation.setIsActive(false);
                                bulkBranchCreation.setMessage("Branch has already assign with same schemeId");
                                continue schemeWiseLoop;
                            }
                        }
                        bulkBranchCreation.setIsActive(isActive);
                        bulkBranchCreation.setMessage(msg);
         
                        if (isActive) {
                        	msg = "Saved Successfully";
                        	bulkBranchCreation.setMessage(msg);
                        }
                        // CHECK USER ROLE MAPPING TABLE TO AVOID DUBLICATIOn
//                    if(emailExist != null && userRoleProductMappings != null && userRoleProductMappings.size() > 0) {
//                        Long roleId = emailExist.getUserRoleId().getRoleId();
//                        UserRoleProductMapping map = userRoleProductMappings.stream()
//                                .filter(a ->
//                                        a.getUserRoleMaster().getRoleId().equals(roleId)
//                                                && a.getSchemeId().equals(scheme.getId())).findFirst().orElse(null);
//                        if(map != null) {
//                            saveSchemeList.remove(schemeId);
//                            bulkBranchCreation.setIsActive(false);
//                            bulkBranchCreation.setMessage("User has already assign with same role and schemeId");
//                            continue schemeWiseLoop;
//                        }
//                    }
                        if (!OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                            branchProductMapping = new BranchProductMapping();
                            branchProductMapping.setBranchId(branchMaster.getId());
                            branchProductMapping.setBusinessId(Long.valueOf(scheme.getBussinessTypeId()));
                            branchProductMapping.setSchemeId(scheme.getId());
                            branchProductMapping.setBranchRoId(roId != null ? roId : null);
                            branchProductMapping.setBranchZoId(zoId != null ? zoId : null);
                            branchProductMapping.setIsActive(Boolean.TRUE);
                            branchProductMapping.setCreatedDate(new Date());
                            branchProductMapping.setUserOrgId(orgId);
                            branchProductMappings.add(branchProductMapping);
                        }
                        // branchProductMappingRepo.save(branchProductMapping);
                    } catch (Exception e) {
                        logger.error("Exception while save scheme wise user entry ", e);
                    } finally {
                        if (bulkBranchCreation != null) {
                            logger.info("Saved !{}", bulkBranchCreation.getBranchCode());
                            bulkBranchCreationList.add(bulkBranchCreation);
                        }
                    }
                }
                /*  if (saveSchemeList.size() > 0 && !OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                    String roleName = "";
                    if (branchMaster.getBranchType() == 1) {
                        roleName = "Branch_Checker";
                    } else if (branchMaster.getBranchType() == 2) {
                        roleName = "Regional_Officer";
                    } else if (branchMaster.getBranchType() == 3) {
                        roleName = "Zonal_Officer";
                    }
                  if (!OPLUtils.isObjectNullOrEmpty(bulkUploadUserExistProxy) && OPLUtils.isObjectNullOrEmpty(bulkUploadUserExistProxy.getUser()) && bulkUploadUserExistProxy.getIsActive() == true) {
                        bulkUploadComponent.createUserAndUserSchemeMapping(email, mobile, null, null, roleName,
                                orgId, branchMaster.getId(), saveSchemeList, null);
                    }
                }*/
            }catch (Exception e){
                logger.error(i + " found exception==>", e);
            }
        }
        if(branchProductMappings.size() > 0) {
            branchProductMappingRepo.saveAll(branchProductMappings);
        }
        bulkBranchCreationRepository.saveAll(bulkBranchCreationList);
        return true;
    }    
    
    @Override
    public Boolean extractExcelRoZo(MultipartFile multipartFile, Long orgId, Long fileId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId) {
        Workbook workbook = null;
        try {
            workbook = WorkbookFactory.create(multipartFile.getInputStream());

        } catch (Exception e) {
            logger.error("Exception :- ", e);
        }
        Sheet worksheet = (Sheet) workbook.getSheetAt(1);
        String sheetName = worksheet.getSheetName();
        if(!sheetName.equals("Office Creation")){
            return false;
        }
        logger.info("Row Num : {}", worksheet.getLastRowNum());
        String email = null, mobile = null, branchName = null, branchCode = null, ifscCode = null, address = null, branchType = null, roCode = null, zoCode = null, originalFileName = null, ruralUrban = null;
        Integer stateId, cityId,pincode;

        originalFileName = multipartFile.getOriginalFilename();
        //NEW CODE
        List<BulkBranchCreation> bulkBranchCreationList = new ArrayList<>(503);
        List<BranchProductMapping> branchProductMappings = new ArrayList<>();
        BulkBranchCreation bulkBranchCreation = null;
        int row = worksheet.getPhysicalNumberOfRows() < 503 ? worksheet.getPhysicalNumberOfRows() : 503;
//        int blankRowCount = 0;
        List<BranchMaster> allBranchAndCode = branchMasterRepository.getAllBranchByOnOrgId(orgId);
        List<String> codeList = new ArrayList<>();
        List<MasterResponse> stateList = new ArrayList<>();
        try {
            stateList = oneFormClient.getStateListByCountryId(101l);
        } catch (OneFormException e) {
            logger.error("Oneform client==>>", e);
        }
        for (int i = 3; i <= row; i++) {
            if(isRowEmpty(worksheet.getRow(i-1))){
                continue;
            }
            try {
                stateId = null;
                cityId = null;
                pincode = null;
                branchType = extractCellFromSheet(worksheet, "A" + i);
//              email = extractCellFromSheet(worksheet, "B" + i);
//              mobile = extractCellFromSheet(worksheet, "C" + i);
                branchName = extractCellFromSheet(worksheet, "B" + i);
                branchCode = extractCellFromSheet(worksheet, "C" + i);
                ifscCode = extractCellFromSheet(worksheet, "D" + i);
                address = extractCellFromSheet(worksheet, "E" + i);
                try {
                    pincode = extractCellFromSheet(worksheet, "F" + i) != null && extractCellFromSheet(worksheet, "F" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "F" + i)) : null;
                    stateId = extractCellFromSheet(worksheet, "G" + i) != null && extractCellFromSheet(worksheet, "G" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "G" + i)) : null;
                    cityId = extractCellFromSheet(worksheet, "H" + i) != null && extractCellFromSheet(worksheet, "H" + i) != "" ? Integer.parseInt(extractCellFromSheet(worksheet, "H" + i)) : null;

                } catch (NumberFormatException e) {
                    logger.error("Exception :- ", e);
                }
                ruralUrban = extractCellFromSheet(worksheet, "I" + i);
                if (userRoleId == UserRoleMaster.ZO.getId()) {
                    roCode = extractCellFromSheet(worksheet, "J" + i);
                }

//                zoCode = extractCellFromSheet(worksheet, "J" + i);

                //check if mandatory fields are null or not!!
                if (OPLUtils.isObjectNullOrEmpty(branchType) &&
//                        OPLUtils.isObjectNullOrEmpty(email) &&
//                        OPLUtils.isObjectNullOrEmpty(mobile) &&
                        OPLUtils.isObjectNullOrEmpty(branchName) &&
                        OPLUtils.isObjectNullOrEmpty(branchCode) &&
                        OPLUtils.isObjectNullOrEmpty(ifscCode) &&
                        OPLUtils.isObjectNullOrEmpty(address) &&
                        OPLUtils.isObjectNullOrEmpty(pincode) &&
                        OPLUtils.isObjectNullOrEmpty(stateId) &&
                        OPLUtils.isObjectNullOrEmpty(cityId)) {
                    continue;
                }
                boolean isActive = false;
//                boolean isUserExist = false;
                String msg = "";
                // CHECK BASIC VALIDATION
                if (OPLUtils.isObjectNullOrEmpty(branchType)) {
                    msg = "Branch Type can not be null";
                }
                if (!(branchType.equalsIgnoreCase("Branch Office") || branchType.equalsIgnoreCase("Regional Office") || branchType.equalsIgnoreCase("Zonal Office"))
                ) {
                    msg = "Invalid Branch type";
                }
                if (!OPLUtils.isObjectNullOrEmpty(branchType) && branchType.equalsIgnoreCase("Branch Office")) {
                    if (OPLUtils.isObjectNullOrEmpty(ifscCode)) {
                        msg = "Ifsc Code can not be null";
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(ifscCode) && ifscCode.length() != 11 && !Pattern.matches("[A-Z|a-z]{4}[0][\\d]{6}$", ifscCode)) {
                        msg = "Invalid Ifsc Code";
                    }
                }
// 				comment 23/12/2021
//                if (!OPLUtils.isObjectNullOrEmpty(branchType) && branchType.equalsIgnoreCase("Regional Office")) {
//                    if (OPLUtils.isObjectNullOrEmpty(zoCode)) {
//                        msg = "ZO Code can not be null";
//                    }
//                }
                
                
            /*    if (OPLUtils.isObjectNullOrEmpty(email)) {
                    msg = "EmailId can not be null";
                } else {
                    if (emailList.contains(email.toUpperCase())) {
                        msg = "EmailId is already exist in given sheet";
                    } else {
                        if (email.length() > 255 || !Pattern.matches("^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$", email)) {
                            msg = "EmailId is Invalid";
                        }
                    }
                }

                if (OPLUtils.isObjectNullOrEmpty(mobile)) {
                    msg = "Mobile can not be null";
                }else{
                    if (emailList.contains(email.toUpperCase())) {
                        msg = "Mobile is already exist in given sheet";
                    } else {
                        if (mobile.length() > 10) {
                            msg = "MobileNo is Invalid";
                            mobile = "";
                        }
                    }
                }
              /*  if (mobile.length() > 10) {
                    msg = "MobileNo is Invalid";
                    mobile = "";
                }*/
			if (OPLUtils.isObjectNullOrEmpty(branchName)) {
				msg = "Branch Name can not be null";
			}else if (branchName.length() > 100 || !Pattern.matches("^[a-zA-Z0-9&\\,(\\)\\-.\\ ]+$", branchName)) {
				msg = "Please Enter Valid Branch Name";
			}else if (branchName.length() < 1) {
				msg = "Minimum 1 Charater branch Name required";
			} else if (branchName.length() > 100) {
				msg = "Maximum 100 Charater branch Name required";
			}
			if (OPLUtils.isObjectNullOrEmpty(branchCode)) {
				msg = "Branch Code can not be null";
			} else {
				if (codeList.contains(branchCode)) {
					msg = "Branch is already exist in given sheet";
				} else if (branchCode.length() < 1 || !Pattern.matches("^[a-zA-Z0-9]+$", branchCode)) {
					msg = "Minimum 1 Charater branch Code required";
				} else if (branchCode.length() > 50) {
					msg = "Maximum 50 Charater branch Code required";
				}

			}

			if (OPLUtils.isObjectNullOrEmpty(address)) {
				msg = "Address Code can not be null";
			} else if (address.length() < 1  || !Pattern.matches("^[a-zA-Z0-9&\\,(\\)\\-.\\ \\/]+$", address)) {
				msg = "Minimum 1 Charater Address required";
			} else if (address.length() > 200) {
				msg = "Maximum 200 Charater Address required";
			} else {
				address = address.replace("\n", "").replace("\r", "").replaceAll("[\\p{Cf}]", "");
			}
			if (OPLUtils.isObjectNullOrEmpty(stateId)) {
				msg = "StateId can not be null";
			} else {
				Integer finalStateId = stateId;
				if (OPLUtils
						.isObjectNullOrEmpty(stateList.stream().filter(a -> a.getMappingId().equals(finalStateId)))) {
					msg = "StateId is not valid";
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(cityId)) {
				msg = "CityId can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(pincode)) {
				msg = "Pincode can not be null";
			}
			if (!OPLUtils.isObjectNullOrEmpty(pincode) && pincode.toString().length() > 6) {
				msg = "Invalid Pincode";
			}
            if(OPLUtils.isObjectNullOrEmpty(ruralUrban)) {
                msg = "Rural/Urban can not be null";
            }
			if (OPLUtils.isObjectNullOrEmpty(msg)) {
				isActive = true;
			}
                //CHECK BRANCH IS EXIST OR NOT
                BranchMaster branchMaster = null;
//                List<Long> schemeIdsByBranchId = null;
                Long roId = null;
                Long zoId = null;
                Long LHoId = null;
                boolean branchAlreadyPresent = false;
                // User emailExist = null;
          //      BulkUploadUserExistProxy bulkUploadUserExistProxy = null;

                if(isActive) {
                    // NOT NULL
//                    emailList.add(email.toUpperCase());
//                    mobileList.add(mobile.toLowerCase());
                    codeList.add(branchCode);
                }
                if (isActive) {
                    String bCode = branchCode;
//                    List<BranchMaster> branchMasterList = branchMasterRepository.getBranchByCodeAndOrg(bCode, orgId);
//                    if (!OPLUtils.isListNullOrEmpty(branchMasterList)) {
//                        branchMaster = branchMasterList.get(0);
//                    }
                    Optional<BranchMaster> getBranch = allBranchAndCode.stream().filter(branch -> bCode.equals(branch.getCode())).findFirst();
                    if (getBranch.isPresent()) {
                    	branchAlreadyPresent = true;
                        branchMaster = getBranch.get();
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                    	isActive = false;
                    	msg = "Branch already exists";
                    } else {
                    	BranchMaster branchDetails= new BranchMaster();
                        if (branchType.equalsIgnoreCase("Branch Office")) {
                            try {
                            	if (userRoleId == UserRoleMaster.RO.getId()) {
                            		 roId = userBranchId;
                            		 branchDetails = branchMasterRepository.getById(roId);
                            		 roCode = branchDetails.getCode();
                            		 Long tempZo = branchProductMappingRepo.getZoIdByRoId(roId, orgId);
                            		 if (!OPLUtils.isObjectNullOrEmpty(tempZo)) {
                            			 zoId = tempZo;
                            			 branchDetails = branchMasterRepository.getById(zoId);
                            			 zoCode = branchDetails.getCode();
                            			 Long branchLHoId = branchProductMappingRepo.getLHoIdByZoId(zoId, orgId);
                                         if(!OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                                        	 LHoId = branchLHoId;
                                         }
                            		 }
                            	}
                            	if (userRoleId == UserRoleMaster.ZO.getId()) {
                            		zoId = userBranchId;
                            		branchDetails = branchMasterRepository.getById(zoId);
                            		Long branchLHoId = branchProductMappingRepo.getLHoIdByZoId(zoId, orgId);
                                    if(!OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                                   	 LHoId = branchLHoId;
                                    }
                           		 	zoCode = branchDetails.getCode();
                            		if (!OPLUtils.isObjectNullOrEmpty(roCode)) {
                            			String rCode = roCode;
                            			roId = allBranchAndCode.stream().filter(a -> rCode.equals(a.getCode())
                            					&& a.getBranchType() == 2).map(b -> b.getId()).findFirst().orElse(null);
                            			if (roId == null) {
                            				isActive = false;
                            				msg = "RO is not valid";
                            			} else {
                            				if(roId != null) {
                                                Long tempZo = branchProductMappingRepo.getZoIdByRoId(roId, orgId);
                                                if (OPLUtils.isObjectNullOrEmpty(tempZo) || !tempZo.equals(zoId)) {
                                                    isActive = false;
                                                    msg = "Given RO is not tagged with Current ZO ";
                                                }
                                            }
                            			}
                            		}                        		
                            	}
                            } catch (Exception e) {
                                logger.error("Exception while check Branch Code ", e);
                            }
                        }
                        if (branchType.equalsIgnoreCase("Regional Office")) {
                            try {
                            	zoId = userBranchId;
                        		branchDetails = branchMasterRepository.getById(zoId);
                       		 	zoCode = branchDetails.getCode();
                            } catch (Exception e) {
                                logger.error("Exception while check Branch Code ", e);
                            }
                        }
                      /*  if (isActive) {
                            // CHECK EMAIL OR MOBILE IS DUBLICATE OR NOT
                            bulkUploadUserExistProxy = bulkUploadComponent.checkEmailOrMobileExist(email, mobile);
                         /*   if (!bulkUploadUserExistProxy.getIsActive()) {
                                isActive = false;
                                msg = bulkUploadUserExistProxy.getMessage();
                            }*/
                            /*else {
                                if (bulkUploadUserExistProxy.getUser() != null) {
                                    isActive = false;
                                    msg = "Email Or Mobile Is Already Exists";
                                }
                            }
                        }*/

//                        if (branchMaster != null) {
//                            schemeIdsByBranchId = branchProductMappingRepo.getSchemeListByBranchId(branchMaster.getId());
//                        }

                    }
 }

//            List<UserRoleProductMapping> userRoleProductMappings = null;
//            if(emailExist != null) {
//                userRoleProductMappings = roleProductMapping.findByUserUserId(emailExist.getUserId());
//            }
//                List<Long> saveSchemeList = new ArrayList<>(schemeTypelist);
                BranchProductMapping branchProductMapping = null;
//                schemeWiseLoop:
                for (Long schemeId : schemeTypelist) {
                    SchemeMaster scheme = SchemeMaster.getById(schemeId);
                    try {
                        bulkBranchCreation = new BulkBranchCreation();
                        bulkBranchCreation.setBranchType(OPLUtils.isObjectNullOrEmpty(branchType) ? null : branchType);
                        bulkBranchCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null : email);
                        bulkBranchCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null : mobile);
                        bulkBranchCreation.setBranchName(OPLUtils.isObjectNullOrEmpty(branchName) ? null : branchName.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(branchCode) ? null : branchCode.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setIfscCode(OPLUtils.isObjectNullOrEmpty(ifscCode) ? null : ifscCode);
                        bulkBranchCreation.setAddress(OPLUtils.isObjectNullOrEmpty(address) ? null : address.replaceAll("\n", "").replaceAll("\r", "").replaceAll("\t", "").replaceAll("\"", " "));
                        bulkBranchCreation.setPincode(pincode);
                        bulkBranchCreation.setState(stateId);
                        bulkBranchCreation.setCity(cityId);
                        bulkBranchCreation.setRoCode(OPLUtils.isObjectNullOrEmpty(roCode) ? null : roCode);
                        bulkBranchCreation.setZoCode(OPLUtils.isObjectNullOrEmpty(zoCode) ? null : zoCode);
                        bulkBranchCreation.setOrgId(orgId);
                        bulkBranchCreation.setBusinessTypeId(Long.valueOf(scheme.getBussinessTypeId()));
                        bulkBranchCreation.setSchemeId(scheme.getId());
                        bulkBranchCreation.setDateTime(new Date());
                        bulkBranchCreation.setFileId(fileId);
                        bulkBranchCreation.setUserRoleId(userRoleId);
                        bulkBranchCreation.setCreatedByBranchId(String.valueOf(userBranchId));
                        bulkBranchCreation.setRuralUrban(OPLUtils.isObjectNullOrEmpty(ruralUrban) ? null : ruralUrban);
                        bulkBranchCreation.setOriginalFileName(originalFileName);
                        
                        // STEP CHECK NULL || CREATE
                        if (isActive && OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                            branchMaster = createBranch(bulkBranchCreation, orgId);
                            isActive = true;
                        }

                        // CHECK schemeIdsByBranchId IS ALREADY EXITS OR NOT

//                        if (schemeIdsByBranchId != null && schemeIdsByBranchId.size() > 0) {
//                            if (schemeIdsByBranchId.contains(scheme.getId())) {
//                                saveSchemeList.remove(schemeId);
//                                bulkBranchCreation.setIsActive(false);
//                                bulkBranchCreation.setMessage("Branch has already assign with same schemeId");
//                                continue schemeWiseLoop;
//                            }
//                        }
                        bulkBranchCreation.setIsActive(isActive);
                        bulkBranchCreation.setMessage(msg);
                        
                        if (isActive) {
                        	msg = "Saved Successfully";
                        	bulkBranchCreation.setMessage(msg);
                        }
                        // CHECK USER ROLE MAPPING TABLE TO AVOID DUBLICATIOn
//                    if(emailExist != null && userRoleProductMappings != null && userRoleProductMappings.size() > 0) {
//                        Long roleId = emailExist.getUserRoleId().getRoleId();
//                        UserRoleProductMapping map = userRoleProductMappings.stream()
//                                .filter(a ->
//                                        a.getUserRoleMaster().getRoleId().equals(roleId)
//                                                && a.getSchemeId().equals(scheme.getId())).findFirst().orElse(null);
//                        if(map != null) {
//                            saveSchemeList.remove(schemeId);
//                            bulkBranchCreation.setIsActive(false);
//                            bulkBranchCreation.setMessage("User has already assign with same role and schemeId");
//                            continue schemeWiseLoop;
//                        }
//                    }
                        if (!OPLUtils.isObjectNullOrEmpty(branchMaster) && !branchAlreadyPresent) {
                            branchProductMapping = new BranchProductMapping();
                            branchProductMapping.setBranchId(branchMaster.getId());
                            branchProductMapping.setBusinessId(Long.valueOf(scheme.getBussinessTypeId()));
                            branchProductMapping.setSchemeId(scheme.getId());
                            branchProductMapping.setBranchRoId(roId != null ? roId : null);
                            branchProductMapping.setBranchZoId(zoId != null ? zoId : null);
                            branchProductMapping.setBranchLHoId(LHoId != null ? LHoId : null);
                            branchProductMapping.setIsActive(Boolean.TRUE);
                            branchProductMapping.setCreatedDate(new Date());
                            branchProductMapping.setUserOrgId(orgId);
                            branchProductMappings.add(branchProductMapping);
                        }
                        // branchProductMappingRepo.save(branchProductMapping);
                    } catch (Exception e) {
                        logger.error("Exception while save scheme wise user entry ", e);
                    } finally {
                        if (bulkBranchCreation != null) {
                            logger.info("Saved !{}", bulkBranchCreation.getBranchCode());
                            bulkBranchCreationList.add(bulkBranchCreation);
                        }
                    }
                }
                /*  if (saveSchemeList.size() > 0 && !OPLUtils.isObjectNullOrEmpty(branchMaster)) {
                    String roleName = "";
                    if (branchMaster.getBranchType() == 1) {
                        roleName = "Branch_Checker";
                    } else if (branchMaster.getBranchType() == 2) {
                        roleName = "Regional_Officer";
                    } else if (branchMaster.getBranchType() == 3) {
                        roleName = "Zonal_Officer";
                    }
                  if (!OPLUtils.isObjectNullOrEmpty(bulkUploadUserExistProxy) && OPLUtils.isObjectNullOrEmpty(bulkUploadUserExistProxy.getUser()) && bulkUploadUserExistProxy.getIsActive() == true) {
                        bulkUploadComponent.createUserAndUserSchemeMapping(email, mobile, null, null, roleName,
                                orgId, branchMaster.getId(), saveSchemeList, null);
                    }
                }*/
            }catch (Exception e){
                logger.error(i + " found exception==>", e);
            }
        }
        if(branchProductMappings.size() > 0) {
            branchProductMappingRepo.saveAll(branchProductMappings);
        }
        bulkBranchCreationRepository.saveAll(bulkBranchCreationList);
        return true;
    }

//    private User createUser(BranchMaster branchMaster) {
//        User user = new User();
//
//        try {
//            user.setEmail(branchMaster.getContactPersonEmail());
//            user.setMobile(branchMaster.getContactPersonNumber());
//            user.setIsActive(Boolean.TRUE);
//            user.setCreatedDate(new Date());
//            user.setSignUpDate(new Date());
//            user.setPassword(defaultPwd);
//            user.setUserOrgId(branchMaster.getOrgId());
//            if (branchMaster.getBranchType() == 1) {
//                user.setUserRoleId(userRoleMasterRepo.findByRoleId(com.opl.jns.utils.enums.UserRoleMaster.BRANCH_CHECKER.getId()));
//                user.setUserTypeMaster(userTypeRepo.getOne(UserTypeMaster.FUNDPROVIDER.getId()));
//                user.setBranchId(branchMaster);
//            } else if (branchMaster.getBranchType() == 2) {
//                user.setUserRoleId(userRoleMasterRepo.findByRoleId(com.opl.jns.utils.enums.UserRoleMaster.RO.getId()));
//                user.setUserTypeMaster(userTypeRepo.getOne(UserTypeMaster.FUNDPROVIDER.getId()));
//                user.setBranchId(branchMaster);
//            } else if (branchMaster.getBranchType() == 3) {
//                user.setUserRoleId(userRoleMasterRepo.findByRoleId(com.opl.jns.utils.enums.UserRoleMaster.ZO.getId()));
//                user.setUserTypeMaster(userTypeRepo.getOne(UserTypeMaster.FUNDPROVIDER.getId()));
//                user.setBranchId(branchMaster);
//            }
//            return userRepo.save(user);
//        }
//        catch (Exception e){
//            logger.error("Exception while save scheme wise user entry ", e);
//        }
//        return user;
//    }

    private BranchMaster createBranch(BulkBranchCreation branchCreation, Long orgId){
        BranchMaster branchMaster = new BranchMaster();
        branchMaster.setName(branchCreation.getBranchName());
        branchMaster.setCode(branchCreation.getBranchCode());
        branchMaster.setCityId(branchCreation.getCity());
        branchMaster.setStateId(branchCreation.getState());
        branchMaster.setPincode(branchCreation.getPincode());
        if(!OPLUtils.isObjectNullOrEmpty(branchCreation.getIfscCode())){
            branchMaster.setIfscCode(branchCreation.getIfscCode());
        }
        branchMaster.setCountryId(101);
        branchMaster.setStreetName(branchCreation.getAddress());
        branchMaster.setContactPersonEmail(branchCreation.getEmail());
        branchMaster.setContactPersonNumber(branchCreation.getMobile());
        branchMaster.setCreatedOn(new Date());
        branchMaster.setIsActive(Boolean.TRUE);
        branchMaster.setRuralUrbanId("Rural".equalsIgnoreCase(branchCreation.getRuralUrban()) ? 1 : ("Urban".equalsIgnoreCase(branchCreation.getRuralUrban()) ? 2 : null));
        branchMaster.setOrgId(userOrganisationMasterRepository.findByUserOrgId(orgId));
        if(branchCreation.getBranchType().equalsIgnoreCase("Branch Office")){
            branchMaster.setBranchType(1);
        }
        if(branchCreation.getBranchType().equalsIgnoreCase("Regional Office")){
            branchMaster.setBranchType(2);
        }
        if(branchCreation.getBranchType().equalsIgnoreCase("Zonal Office")){
            branchMaster.setBranchType(3);
        }
        return branchMasterRepository.save(branchMaster);
    }

    @SuppressWarnings("unchecked")
	@Override
    public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile) {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("applicationId", orgId);
        jsonObj.put("productDocumentMappingId", UserCreationUtil.BRANCH_EXCEL_LIST_FOR_COMMON);
        jsonObj.put("userType", DocumentAlias.UERT_TYPE_APPLICANT);
        jsonObj.put("originalFileName", multipartFile.getOriginalFilename());
        try {
        	logger.info("response {}", jsonObj);
            DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
            logger.info("response {}", documentResponse.getStatus());
            StorageDetailsResponse response = null;
            Map<String, Object> list = (Map<String, Object>) documentResponse.getData();
            if (!OPLUtils.isObjectListNull(list)) {
                try {
                    response = MultipleJSONObjectHelper.getObjectFromMap(list, StorageDetailsResponse.class);
                } catch (IOException e) {
                    logger.info("Could not upload file to DMS");
                }
            }

            if (response != null) {
                logger.debug("uploadExcel() :: response is not null");
                return response.getId();
            } else {
                logger.debug("uploadExcel() :: response is null");
                return null;
            }
        } catch (DocumentException e) {
            logger.info("Could not upload file to DMS");
            return null;
        }
    }

    @SuppressWarnings("deprecation")
	public static String extractCellFromSheet(Sheet sheet, String rowNumber) {
        try {
            CellReference cellReference = new CellReference(rowNumber);
            Row row = sheet.getRow(cellReference.getRow());
            Cell cell = row.getCell(cellReference.getCol());
            if (cell != null) {
                if (cell.getCellType() == 0) {
                    cell.setCellType(Cell.CELL_TYPE_STRING);
                    return cell.toString();
                } else {
                    return cell.toString();
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
	public static Date extractNumericCellFromSheet(XSSFSheet sheet, String rowNumber) {
        try {
            CellReference cellReference = new CellReference(rowNumber);
            Row row = sheet.getRow(cellReference.getRow());
            Cell cell = row.getCell(cellReference.getCol());
            if (cell != null) {
                cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                try {
                    
                    String s = DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, cell.getDateCellValue());                    
                    return DateUtils.parse(DateFormat.DD_MM_YYYY, s);
                    
//                  String s = FORMAT.format(cell.getDateCellValue());
//                  return FORMAT.parse(s);
                } catch (Exception e) {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId) {
        UserResponseProxy userResponse = new UserResponseProxy();
        DocumentRequest documentRequest = new DocumentRequest();
        documentRequest.setApplicationId(orgId);
        documentRequest.setUserType(DocumentAlias.UERT_TYPE_APPLICANT);

        switch (businessTypeId)
        {
//            case 1:
//                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_MSME);
//                break;
//
//            case 3:
//                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_PL);
//                break;
//
//            case 5:
//                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_HL);
//                break;
//
//            case 8:   
//                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_AL);
//                break;
//
//            case 10:
//                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_ML);
//                break;

            case 1:
            case 3:
            case 5:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
                documentRequest.setProductDocumentMappingId(UserCreationUtil.BRANCH_EXCEL_LIST_FOR_COMMON);
                break;

            default:
                break;
        }

//        try {
//            DocumentResponse documentResponse = dmsClient.listProductDocumentBankUser(documentRequest);
            try {
                FileResponseProxy fileResponse = null;
                List<FileResponseProxy> fileResponseList = new ArrayList<>();
//                if(!OPLUtils.isListNullOrEmpty(documentResponse.getDataList())) {
//                    for (Object object : documentResponse.getDataList()) {
//                        StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromMap((LinkedHashMap<String, Object>) object, StorageDetailsResponse.class);
                		List<Object[]> entryList = null;
                		if (userRoleId == UserRoleMaster.HEAD_OFFICE.getId()) {
                			entryList = bulkBranchCreationRepository.getFileEntriesForHO(orgId);
                		} else {
                			entryList = bulkBranchCreationRepository.getFileEntries(userBranchId);                			
                		}
                        for (Object[] obj : entryList) {
                            fileResponse = new FileResponseProxy();
                            fileResponse.setTotalEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[0])) ? Integer.parseInt(String.valueOf(obj[0])) : 0);
                            fileResponse.setSuccessfulEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[1])) ? Integer.parseInt(String.valueOf(obj[1])) : 0);
                            fileResponse.setFailedEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[2])) ? Integer.parseInt(String.valueOf(obj[2])) : 0);
                            fileResponse.setId(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[3])) ? Long.parseLong(String.valueOf(obj[3])) : 0);
                            fileResponse.setCreatedDate((Date)(obj[4]));
                            fileResponse.setOriginalFileName(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[5])) ? String.valueOf(obj[5]) : "-");
                            fileResponseList.add(fileResponse);
                        }
//                        fileResponse.setId(storageDetailsResponse.getId());
//                        fileResponse.setOriginalFileName(storageDetailsResponse.getOriginalFileName());
//                        fileResponse.setCreatedDate(storageDetailsResponse.getCreatedDate());
//                        fileResponseList.add(fileResponse);
//                    }
                    if (fileResponseList != null) {
                        Collections.sort(fileResponseList, new Comparator<FileResponseProxy>() {
                            @Override
                            public int compare(FileResponseProxy o1, FileResponseProxy o2) {
                                return o2.getCreatedDate().compareTo(o1.getCreatedDate()); }
                        });
                    }
//                }

                userResponse.setData(fileResponseList);
                userResponse.setMessage(UserCreationUtil.SUCCESSFULLY_LISTED);
                userResponse.setStatus(HttpStatus.OK.value());
            }catch (Exception e){
                logger.error("Error while getting file", e);
                return null;
            }

            return userResponse;
//        } catch () {
//            logger.error("Error while getting file details", e);
//            return null;
//        }
    }

    @Override
    public List<BulkBranchResponseProxy> getFileEntryList(FileResponseProxy fileResponse) {
        try {
        	 logger.info("inSide getFileEntryList() fileId==>>>  {}",fileResponse.getId());
            List<BulkBranchResponseProxy> bulkBranchResponseList = new ArrayList<>();
            List<BulkBranchCreation> bulkBranchCreationList = null;
            
            if(!OPLUtils.isObjectNullOrEmpty(fileResponse.getCheckEntry())) {
            	if(fileResponse.getCheckEntry() == 2) {
            		bulkBranchCreationList = bulkBranchCreationRepository.findAllByFileId(fileResponse.getId());
                }else {
                	bulkBranchCreationList = bulkBranchCreationRepository.findAllByFileIdAndIsActive(fileResponse.getId(), fileResponse.getCheckEntry() == 0 ? true : false);
                }
            }
            BulkBranchResponseProxy bulkBranchResponse = null;
            for (BulkBranchCreation bulkBranchCreation : bulkBranchCreationList){
                bulkBranchResponse = new BulkBranchResponseProxy();
                BeanUtils.copyProperties(bulkBranchCreation,bulkBranchResponse);
                if(!OPLUtils.isObjectNullOrEmpty(bulkBranchCreation.getSchemeId())){
                    bulkBranchResponse.setSchemeName(SchemeMaster.getById(bulkBranchCreation.getSchemeId()).getName());
                }else{
                    bulkBranchResponse.setSchemeName("Not any scheme");
                }
                bulkBranchResponseList.add(bulkBranchResponse);
            }
            logger.info("SuccessFully Get Data ==>>>  ");
            return bulkBranchResponseList;

        } catch (Exception e) {
            logger.error("Exception :- ", e);
        }
        return null;
    }

    @Override
    public String getBranchRoleEntries(UserListResponseProxy userListResponse) {
        try {
            String list = bulkBranchCreationRepository.getBranchRoleEntries(userListResponse.getUserOrgId(),userListResponse.getBusinessTypeId(),userListResponse.getFileId());
            return list;
        } catch (Exception e) {
            logger.error("Exception :- ", e);
            return null;
        }

    }

    @Override
    public String getBranchEntryCount(UserListResponseProxy userListResponse) {
        try {
            String list = bulkBranchCreationRepository.getBranchEntryCount(userListResponse.getUserOrgId(),userListResponse.getBusinessTypeId(),userListResponse.getFileId());
            return list;
        } catch (Exception e) {
            logger.error("Exception :- ", e);
            return null;
        }
    }

    @Override
    public List<BulkBranchResponseProxy> getAllBranchEntryList(UserListResponseProxy userListResponse) {
        try {
            List<BulkBranchResponseProxy> bulkBranchResponseList = new ArrayList<>();
            List<BulkBranchCreation> bulkBranchCreationList = bulkBranchCreationRepository.getAllBranchEntryList(userListResponse.getUserOrgId(),userListResponse.getBusinessTypeId(),userListResponse.getFileId());
            BulkBranchResponseProxy bulkBranchResponse = null;
            for (BulkBranchCreation bulkBranchCreation : bulkBranchCreationList){
                bulkBranchResponse = new BulkBranchResponseProxy();
                BeanUtils.copyProperties(bulkBranchCreation,bulkBranchResponse);
                bulkBranchResponseList.add(bulkBranchResponse);
            }
            return bulkBranchResponseList;

        } catch (Exception e) {
            logger.error("Exception :- ", e);
        }
        return null;
    }

    @Override
    public String getBranchFileEntryCount(FileResponseProxy fileResponse) {
        try {
            return bulkBranchCreationRepository.getBranchFileEntryCount(fileResponse.getId());
        } catch (Exception e) {
            logger.error("Exception :- ", e);
            return null;
        }
    }

	@Override
	public byte[] downloadBranchCreationExcelTemplate(Long schemeId, Long userRoleId) {
		try {
			logger.info("schemeId ---------->" + schemeId);
			String files = null;
			if(userRoleId == UserRoleMaster.RO.getId()) {
//				files = schemeId == SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.getId() ? "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices_NRLM_RO.xlsx" : "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices_RO.xlsx";
				files = "com.jns.common.config.creationOfficesTemplateRO";
			}else if(userRoleId == UserRoleMaster.ZO.getId()) {
//				files = schemeId == SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.getId() ? "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices_NRLM_ZO.xlsx" : "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices_ZO.xlsx";
				files = "com.jns.common.config.creationOfficesTemplateZO";
			}else  {
//				files = schemeId == SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.getId() ? "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices_NRLM.xlsx" : "D:\\services ANS\\service-user-management-ans\\templates\\Creation_of_Offices.xlsx";
				files = "com.jns.common.config.creationOfficesTemplate";
			}
			
			Workbook wb = null;
	        logger.info("FILE PATH -------->" + files);
	        try {
	            wb = new XSSFWorkbook(OPCPackage.open(environment.getRequiredProperty(files)));
	        } catch (IOException e) {
//	            e.printStackTrace();
	        } catch (InvalidFormatException e) {
//	            e.printStackTrace();
	        }

	        Sheet sheet2 = wb.getSheetAt(2);
	        CellStyle lockStyle = wb.createCellStyle();
	        lockStyle.setLocked(true);
            List<LgdDistrictStateResponse> lgdDistrictStateMaster = oneFormClient.getLgdDistrictStateMaster();
//            List<CityStateResponse> lgdDistrictStateMaster = oneFormClient.getCityStateMaster();
	        logger.info("FILE Size  ------------------------------->" + lgdDistrictStateMaster.size());
	        for (int i = 0; i < lgdDistrictStateMaster.size(); i++) {
                LgdDistrictStateResponse cityStateResponseObj = lgdDistrictStateMaster.get(i);
	        	
	            Row row = sheet2.createRow(i + 3);
	            int cellid = 0;

//	            row.createCell(cellid).setCellValue(i + 1);
	            row.createCell(cellid + 1).setCellValue(cityStateResponseObj.getStateName());
	            row.createCell(cellid + 2).setCellValue(cityStateResponseObj.getStateId());
	            row.createCell(cellid + 3).setCellValue(cityStateResponseObj.getDistrictName());
	            row.createCell(cellid + 4).setCellValue(cityStateResponseObj.getDistrictId());

//	            row.getCell(cellid).setCellStyle(lockStyle);
	            row.getCell(cellid + 1).setCellStyle(lockStyle);
	            row.getCell(cellid + 2).setCellStyle(lockStyle);
	            row.getCell(cellid + 3).setCellStyle(lockStyle);
	            row.getCell(cellid + 4).setCellStyle(lockStyle);


	        }
	        
	        sheet2.protectSheet("opl123");
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        try {
	            wb.write(baos);
	        } catch (IOException e) {
//	            e.printStackTrace();
	        }
	        byte[] byteArray = baos.toByteArray();
//	        return new UserResponseProxy(byteArray,"SuccessFully Get Excel",HttpStatus.OK.value());
	        return byteArray;
		} catch (Exception e) {
			logger.error(" ERROR IS Getting While Get ------------------------------->", e);
		}
		return null;
	}
}
