package com.opl.jns.user.management.service.service.bulkUpload.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.BulkUserResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.domain.BulkFacilitatorCreation;
import com.opl.jns.user.management.service.domain.BulkUlbCreation;
import com.opl.jns.user.management.service.domain.BulkUserCreation;
import com.opl.jns.user.management.service.domain.UlbDistrictMapping;
import com.opl.jns.user.management.service.domain.UlbUserMapping;
import com.opl.jns.user.management.service.domain.User;
import com.opl.jns.user.management.service.domain.UserRoleProductMapping;
import com.opl.jns.user.management.service.repository.BranchMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchRepositoryV3;
import com.opl.jns.user.management.service.repository.SchemeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UlbDistrictMappingRepoV3;
import com.opl.jns.user.management.service.repository.UlbUserMappingRepoV3;
import com.opl.jns.user.management.service.repository.UserOrganisationMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserTypeMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UsersRepositoryV3;
import com.opl.jns.user.management.service.repository.bulkUpload.BulkFacilitatorCreationRepositoryV3;
import com.opl.jns.user.management.service.repository.bulkUpload.BulkUlbCreationRepoV3;
import com.opl.jns.user.management.service.repository.bulkUpload.BulkUserCreationRepositoryV3;
import com.opl.jns.user.management.service.service.UserManagementServiceV3;
import com.opl.jns.user.management.service.service.bulkUpload.BulkUserCreationServiceV3;
import com.opl.jns.user.management.service.utils.BulkUploadComponentV3;
import com.opl.jns.user.management.service.utils.BulkUploadUserExistProxyV3;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

@Service
@Transactional
public class BulkUserCreationServiceImplV3 implements BulkUserCreationServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(BulkUserCreationServiceImplV3.class);
//	private static SimpleDateFormat FORMAT = new SimpleDateFormat("dd-MM-yyyy");

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private DMSClient dmsClient;

	@Autowired
	private BulkUserCreationRepositoryV3 bulkUserCreationRepository;

	@Autowired
	private BranchRepositoryV3 branchRepository;
	
	@Autowired
	private UserManagementServiceV3 userManagementService;

	@Autowired
	private BranchProductMappingRepositoryV3 branchProductMappingRepo;

	@Autowired
	private BranchMasterRepositoryV3 branchMasterRepo;

	@Autowired
	private BulkFacilitatorCreationRepositoryV3 bulkFacilitatorCreationRepo;

	@Autowired
    UsersRepositoryV3 userRepo;

	@Autowired
    UserRoleProductMappingRepositoryV3 roleProductMapping;

	@Autowired
	UserTypeMasterRepositoryV3 userTypeRepo;

	@Autowired
	UserRoleMasterRepositoryV3 userRoleMasterRepo;

	@Value("${cw.user.default.password}")
	private String defaultPwd;

	@Autowired
	UserOrganisationMasterRepositoryV3 userOrganisationMasterRepository;

	@Autowired
	private BulkUlbCreationRepoV3 bulkUlbCreationRepo;

	@Autowired
	private UlbDistrictMappingRepoV3 ulbDistrictMappingRepo;

	@Autowired
	private UlbUserMappingRepoV3 ulbUserMappingRepo;

	@Autowired
	private BulkUploadComponentV3 bulkUploadComponent;

	@Autowired
	SchemeMasterRepositoryV3 schemeMasterRepo;

	public boolean isRowEmpty(Row row) {
		if (row != null) {
			for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
				Cell cell = row.getCell(c);
				if (cell != null && cell.getCellTypeEnum() != CellType.BLANK)
					return false;
			}
		}
		return true;
	}

	@Override
	public Boolean extractExcel(MultipartFile multipartFile, Long orgId, Long fileId, Long userRoleId, Long userBranchId) {
		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(multipartFile.getInputStream());
		} catch (Exception e) {
			logger.error("Exception :- ", e);

		}
		Sheet worksheet = (Sheet) workbook.getSheetAt(1);
		logger.info("Row Num : {}", worksheet.getLastRowNum());
		String email = null, mobile = null, firstName = null, middleName = null, lastName = null, role = null, officeCode = null, originalFileName = null;
		Integer stateId, cityId;

		 originalFileName = multipartFile.getOriginalFilename();
		// FETCH ALL BRANCH LIST BY ORG ID TO SET ID FROM CODE
		List<BranchRequestProxy> branchList = branchMasterRepo.getBranchIdAndCodeByOrgId(orgId);
		// =========================== NEW CODE START
		List<BulkUserCreation> bulkUserCreationList = new ArrayList<>(502);
		BulkUserCreation bulkUser = null;
		int row = worksheet.getPhysicalNumberOfRows() < 503 ? worksheet.getPhysicalNumberOfRows() : 503;
		int blankRowCount = 0;
		mainLoop: for (int i = 2; i <= row; i++) {
			BulkUserCreation bulkUserCreation = new BulkUserCreation();

			if (blankRowCount > 5) {
				break mainLoop;
			}

			if (isRowEmpty(worksheet.getRow(i - 1))) {
				blankRowCount++;
				continue;
			}
			List<String> emailList = new ArrayList<>();
			List<String> mobileList = new ArrayList<>();

			// FETCH ALL USER VALUE FROM SHEET
			email = extractCellFromSheet(worksheet, "A" + i);
			mobile = extractCellFromSheet(worksheet, "B" + i);
			firstName = extractCellFromSheet(worksheet, "C" + i);
			middleName = extractCellFromSheet(worksheet, "D" + i);
			lastName = extractCellFromSheet(worksheet, "E" + i);
			role = extractCellFromSheet(worksheet, "F" + i);
			officeCode = extractCellFromSheet(worksheet, "G" + i);

			if ((OPLUtils.isObjectNullOrEmpty(email) || OPLUtils.isObjectNullOrEmpty(mobile)) && OPLUtils.isObjectNullOrEmpty(firstName) && OPLUtils.isObjectNullOrEmpty(middleName) && OPLUtils.isObjectNullOrEmpty(lastName) && OPLUtils.isObjectNullOrEmpty(role)) {
				blankRowCount++;
				continue;
			}

			boolean isActive = false;
			String msg = "";
			// CHECK BASIC VALIDATION
			if (OPLUtils.isObjectNullOrEmpty(email)) {
				msg = "EmailId can not be null";
			} else {
				email = email.replaceAll("\\s", "");
				if (emailList.contains(email)) {
					msg = "Email is already exist in given sheet";
				}
			}
			if (email.length() > 255 || !Pattern.matches("^([a-zA-Z0-9])[\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}", email)) {
				msg = "EmailId is Invalid";
			}

			if (OPLUtils.isObjectNullOrEmpty(mobile)) {
				msg = "Mobile can not be null";
			} else {
				mobile = mobile.replaceAll("\\s", "");
				if (mobileList.contains(mobile)) {
					msg = "Mobile is already exist in given sheet";
				}
			}

			if (mobile.length() > 10) {
				msg = "MobileNo is Invalid";
			}
			if (OPLUtils.isObjectNullOrEmpty(firstName)) {
				msg = "First Name can not be null";
			} else if (!Pattern.matches("^[a-zA-Z]+$", firstName)) {
				msg = "please enter valid first name";
			} else if (firstName.length() < 1) {
				msg = "Minimum 1 Character required first name";
			} else if (firstName.length() > 50) {
				msg = "Maximum 50 Character required first name";
			}
			if (OPLUtils.isObjectNullOrEmpty(lastName)) {
				msg = "Last Name can not be null";
			} else if (!Pattern.matches("^[a-zA-Z]+$", lastName)) {
				msg = "please enter valid last name";
			} else if (lastName.length() < 1) {
				msg = "Minimum 1 Character required last name";
			} else if (lastName.length() > 50) {
				msg = "Maximum 50 Character required last name";
			}
			if (OPLUtils.isObjectNullOrEmpty(role)) {
				msg = "Role can not be null";
			}

			if ((role.equalsIgnoreCase("Branch_Officer") || role.equalsIgnoreCase("Branch_Maker") || role.equalsIgnoreCase("Regional_Officer") 
					|| role.equalsIgnoreCase("Zonal_Officer")) && OPLUtils.isObjectNullOrEmpty(officeCode)) {
				msg = "Branch code can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(msg)) {
				isActive = true;
			}


			// CHECK BRANCH CODE ID VALID OR NOT
			String branchId = null;
			if(!role.equals("Head_Officer") && !role.equals("Admin_Maker") && !role.equals("Admin_Checker") 
					&& (OPLUtils.isObjectNullOrEmpty(officeCode) || !isActive)) {
				bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName,
						role, branchId, orgId, officeCode, fileId, false, msg, userRoleId, userBranchId, originalFileName);
				if (bulkUserCreation != null) {
					bulkUserCreationList.add(bulkUserCreation);
				}
			}

			if (!OPLUtils.isObjectNullOrEmpty(officeCode)) {
				try {
					officeCode = officeCode.replaceAll("\\s", "");
					String branchCode = officeCode;
					Long bId = branchList.stream().filter(a -> branchCode.equalsIgnoreCase(a.getCode())).map(b -> b.getBranchId()).findFirst().orElse(null);
					if (bId != null) {
						branchId = bId.toString();
					} else {
						isActive = false;
						msg = "Invalid BranchCode";
						bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName, role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
						if (bulkUserCreation != null) {
							bulkUserCreationList.add(bulkUserCreation);
						}
					}
				} catch (Exception e) {
					logger.error("Exception while check Branch Code " + e.getMessage());
				}
			}
			// FETCH SCHEME LIST BY BRANCH ID FROM BRANCH PRODUCT MAPPING TO CHECK IF
			// ALREADY EXITS OR NOT
			List<Long> schemeList = null;
			if (isActive && !OPLUtils.isObjectNullOrEmpty(officeCode) && (role.equals("Branch_Officer") || role.equals("Branch_Maker") || role.equals("Regional_Officer") || role.equals("Zonal_Officer"))) {
				schemeList = branchProductMappingRepo.getSchemeListByBranchId(Long.parseLong(branchId));
				if (OPLUtils.isObjectNullOrEmpty(schemeList) || schemeList.size() == 0) {
					isActive = false;
					msg = "Branch is not mapped with selected schemes";

				}
			} else if (isActive && OPLUtils.isObjectNullOrEmpty(officeCode) && (role.equals("Head_Officer") || role.equals("Admin_Maker") || role.equals("Admin_Checker"))) {
				schemeList = schemeMasterRepo.getSchemeIdFromMaster();

			}
			// CHECK USER IS ALREADY EXISTS OR NOT
			User emailExist = null;
			if (isActive) {
				// CHECK EMAIL OR MOBILE IS DUBLICATE OR NOT
				BulkUploadUserExistProxyV3 bulkUploadUserExistProxy = bulkUploadComponent.checkEmailOrMobileExist(email, mobile);
				if (!bulkUploadUserExistProxy.getIsActive()) {
					isActive = false;
					emailExist = bulkUploadUserExistProxy.getUser();
					msg = bulkUploadUserExistProxy.getMessage();
				} else {
					if (bulkUploadUserExistProxy.getUser() != null) {
						emailExist = bulkUploadUserExistProxy.getUser();
						isActive = false;
						msg = "Email Or Mobile Is Already Exists";
					}
				}
			}

			// FETCH USER ROLE PRODUCT MAPPING LIST TO CHECK DUBLICATION OF ROLE AND SCHEME
			// MAPPING
			List<UserRoleProductMapping> userRoleProductMappings = null;
			if (emailExist != null) {
				userRoleProductMappings = roleProductMapping.findByUserUserId(emailExist.getUserId());
			}
			if (!OPLUtils.isListNullOrEmpty(schemeList) && schemeList.size() > 0) {
				List<Long> saveSchemeList = new ArrayList<>(schemeList);
				// SAVE SCHEME WISE BULK ENTRY
				schemeWiseLoop: for (Long schemeId : schemeList) {
					SchemeMaster scheme = SchemeMaster.getById(schemeId);
					bulkUserCreation = new BulkUserCreation();
					try {
						/*
						 * bulkUserCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null :
						 * email.trim());
						 * bulkUserCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null :
						 * mobile.trim());
						 * bulkUserCreation.setFirstName(OPLUtils.isObjectNullOrEmpty(firstName) ? null
						 * : firstName);
						 * bulkUserCreation.setMiddleName(OPLUtils.isObjectNullOrEmpty(middleName) ?
						 * null : middleName);
						 * bulkUserCreation.setLastName(OPLUtils.isObjectNullOrEmpty(lastName) ? null :
						 * lastName); bulkUserCreation.setRole(OPLUtils.isObjectNullOrEmpty(role) ? null
						 * : role); bulkUserCreation.setBranchId(OPLUtils.isObjectNullOrEmpty(branchId)
						 * ? null : branchId); bulkUserCreation.setOrgId(orgId);
						 * bulkUserCreation.setBusinessTypeId(scheme.getBussinessId());
						 * bulkUserCreation.setSchemeId(schemeId);
						 * bulkUserCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(officeCode) ?
						 * null : officeCode); bulkUserCreation.setCreatedDate(new Date());
						 * bulkUserCreation.setFileId(fileId);
						 */
						// CHECK DEFAULT VALIDATION
						bulkUserCreation = saveBulkUserCreation(scheme, email, mobile, firstName, middleName, lastName, role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
//                        if (!isActive) {
//                            saveSchemeList.remove(schemeId);
//                            bulkUserCreation.setIsActive(false);
//                            bulkUserCreation.setMessage(msg);
//                            continue schemeWiseLoop;
//                        }
						bulkUserCreation.setIsActive(true);
						bulkUserCreation.setMessage("Saved Successfully");

						// CHECK BRANCH IF VALID OR NOT
//                    if(!OPLUtils.isObjectNullOrEmpty(officeCode)) {
//                        if (schemeList != null && !schemeList.contains(schemeId)) {
//                            saveSchemeList.remove(schemeId);
//                            bulkUserCreation.setIsActive(false);
//                            bulkUserCreation.setMessage("Branch is not mapped with selected schemes");
//                            continue schemeWiseLoop;
//                        }
//                    }
						// CHECK USER ROLE MAPPING TABLE TO AVOID DUBLICATIOn
						if (emailExist != null && userRoleProductMappings != null && userRoleProductMappings.size() > 0) {
							Long roleId = emailExist.getUserRoleId().getRoleId();
							UserRoleProductMapping map = userRoleProductMappings.stream().filter(a -> a.getUserRoleMaster().getRoleId().equals(roleId) && a.getSchemeId().equals(scheme.getId())).findFirst().orElse(null);
							if (map != null) {
								saveSchemeList.remove(schemeId);
								bulkUserCreation.setIsActive(false);
								bulkUserCreation.setMessage("User has already assign with same role and schemeId");
								continue schemeWiseLoop;
							}
						}
						// HERE USER ROW IS VALID
					} catch (Exception e) {
						logger.error("Exception while save scheme wise user entry ", e);
					} finally {
						if (bulkUserCreation != null) {
							bulkUserCreationList.add(bulkUserCreation);
						}
					}
				} // END SCHEME WISE FOR LOOP
					// if (isActive) {
				if (saveSchemeList.size() > 0) {
					bulkUploadComponent.createUserAndUserSchemeMapping(email, mobile, firstName, lastName, role, orgId, branchId != null ? Long.valueOf(branchId) : null, saveSchemeList, emailExist);
				}
				// }
			}
		}
		bulkUserCreationRepository.saveAll(bulkUserCreationList);
		return true;
	}

	@Override
	public Boolean extractExcelRoZo(MultipartFile multipartFile, Long orgId, Long fileId, Long userRoleId,
			Long userBranchId) {
		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(multipartFile.getInputStream());
		} catch (Exception e) {
			logger.error("Exception :- ", e);

		}
		Sheet worksheet = (Sheet) workbook.getSheetAt(1);
		logger.info("Row Num : {}", worksheet.getLastRowNum());
		String email = null, mobile = null, firstName = null, middleName = null, lastName = null, role = null, originalFileName = null,
				officeCode = null;
		Integer stateId, cityId;

		originalFileName = multipartFile.getOriginalFilename();
		// FETCH ALL BRANCH LIST BY ORG ID TO SET ID FROM CODE
		List<BranchRequestProxy> branchList = branchMasterRepo.getBranchIdAndCodeByOrgId(orgId);
		// =========================== NEW CODE START
		List<BulkUserCreation> bulkUserCreationList = new ArrayList<>(502);
		BulkUserCreation bulkUser = null;
		int row = worksheet.getPhysicalNumberOfRows() < 503 ? worksheet.getPhysicalNumberOfRows() : 503;
		int blankRowCount = 0;
		mainLoop: for (int i = 2; i <= row; i++) {
			BulkUserCreation bulkUserCreation = new BulkUserCreation();

			if (blankRowCount > 5) {
				break mainLoop;
			}

			if (isRowEmpty(worksheet.getRow(i - 1))) {
				blankRowCount++;
				continue;
			}
			List<String> emailList = new ArrayList<>();
			List<String> mobileList = new ArrayList<>();

			// FETCH ALL USER VALUE FROM SHEET
			email = extractCellFromSheet(worksheet, "A" + i);
			mobile = extractCellFromSheet(worksheet, "B" + i);
			firstName = extractCellFromSheet(worksheet, "C" + i);
			middleName = extractCellFromSheet(worksheet, "D" + i);
			lastName = extractCellFromSheet(worksheet, "E" + i);
			role = extractCellFromSheet(worksheet, "F" + i);
			officeCode = extractCellFromSheet(worksheet, "G" + i);

			if ((OPLUtils.isObjectNullOrEmpty(email) || OPLUtils.isObjectNullOrEmpty(mobile))
					&& OPLUtils.isObjectNullOrEmpty(firstName) && OPLUtils.isObjectNullOrEmpty(middleName)
					&& OPLUtils.isObjectNullOrEmpty(lastName) && OPLUtils.isObjectNullOrEmpty(role)) {
				blankRowCount++;
				continue;
			}

			boolean isActive = false;
			String msg = "";
			// CHECK BASIC VALIDATION
			if (OPLUtils.isObjectNullOrEmpty(email)) {
				msg = "EmailId can not be null";
			} else {
				email = email.replaceAll("\\s", "");
				if (emailList.contains(email)) {
					msg = "Email is already exist in given sheet";
				}
			}
//			!Pattern.matches("^([a-zA-Z_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$"
			if (email.length() > 255 || !Pattern.matches("^([a-zA-Z0-9])[\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}", email)) {
				msg = "EmailId is Invalid";
			}

			if (OPLUtils.isObjectNullOrEmpty(mobile)) {
				msg = "Mobile can not be null";
			} else {
				mobile = mobile.replaceAll("\\s", "");
				if (!Pattern.matches("^[6-9][0-9]{9}$", mobile)) {
					msg = "MobileNo is not Valid";
				}
				if (mobileList.contains(mobile)) {
					msg = "Mobile is already exist in given sheet";
				}
			}

			
//			if (mobile.length() > 10 || mobile.length() < 10) {
//				msg = "MobileNo is Invalid";
//			}
			if (OPLUtils.isObjectNullOrEmpty(firstName)) {
				msg = "First Name can not be null";
			}
			 else if (firstName.length() < 1) {
					msg = "Minimum 1 Character required first name";
				} else if (firstName.length() > 50) {
					msg = "Maximum 50 Character required first name";
				}
			else {
				if (!Pattern.matches("^[a-zA-Z]+$", firstName)) {
					msg = "First Name is not Valid";
				}
			}
			if (OPLUtils.isObjectNullOrEmpty(middleName)) {
				middleName = "-";
			}
				
			if (OPLUtils.isObjectNullOrEmpty(lastName)) {
				msg = "Last Name can not be null";
			}
			 else if (lastName.length() < 1) {
					msg = "Minimum 1 Character required last name";
				} else if (lastName.length() > 50) {
					msg = "Maximum 50 Character required last name";
				}
			else {
				if (!Pattern.matches("^[a-zA-Z]+$", lastName)) {
					msg = "Last Name is not Valid";
				}
			}
			
			if (OPLUtils.isObjectNullOrEmpty(role)) {
				msg = "Role can not be null";
			}
			if ((role.equalsIgnoreCase("Branch_Officer") || role.equalsIgnoreCase("Branch_Maker") || role.equalsIgnoreCase("Regional_Officer") 
					|| role.equalsIgnoreCase("Zonal_Officer")) && OPLUtils.isObjectNullOrEmpty(officeCode)) {
				msg = "Branch code can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(msg)) {
				isActive = true;
			}

			// CHECK BRANCH CODE ID VALID OR NOT
			String branchId = null;
			boolean matchBranchcode = false;
			if (OPLUtils.isObjectNullOrEmpty(officeCode) || !isActive) {
				isActive = false;
				bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName,
						role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
				if (bulkUserCreation != null) {
					bulkUserCreationList.add(bulkUserCreation);
				}
			}

			if (!OPLUtils.isObjectNullOrEmpty(officeCode)) {
				try {
					officeCode = officeCode.replaceAll("\\s", "");
					String branchCode = officeCode;
					Long bId = branchList.stream().filter(a -> branchCode.equalsIgnoreCase(a.getCode())).map(b -> b.getBranchId()).findFirst().orElse(null);
					if (bId != null) {
						branchId = bId.toString();
						
						List<String> branchCodes = null;
						UserListResponseProxy userRequest = new UserListResponseProxy();
						userRequest.setBranchId(userBranchId);
						userRequest.setUserOrgId(orgId);
						
						if (userRoleId == UserRoleMaster.RO.getId()) {
							if (role.equals("Branch_Officer")) {
								userRequest.setUserRoleId(userRoleId);
								branchCodes= userManagementService.getBoRoOfficesfromRoZoId(userRequest);
								if (!OPLUtils.isListNullOrEmpty(branchCodes)) {
									matchBranchcode = branchCodes.contains(officeCode);									
								}
								if (!matchBranchcode) {
									isActive = false;
									msg = "OfficeCode is not mapped with Current RO";
								}
							}
						}
						
						if (userRoleId == UserRoleMaster.ZO.getId()) {
							if (role.equals("Branch_Officer")) {
								branchCodes= userManagementService.getBoOfficesfromZoId(userRequest);
								if (!OPLUtils.isListNullOrEmpty(branchCodes)) {
									matchBranchcode = branchCodes.contains(officeCode);									
								}
								if (!matchBranchcode) {
									isActive = false;
									msg = "OfficeCode is not mapped with Current ZO";
								}
							}
							if (role.equals("Regional_Officer")) {
								userRequest.setUserRoleId(userRoleId);
								branchCodes= userManagementService.getBoRoOfficesfromRoZoId(userRequest);
								if (!OPLUtils.isListNullOrEmpty(branchCodes)) {
									matchBranchcode = branchCodes.contains(officeCode);									
								}
								if (!matchBranchcode) {
									isActive = false;
									msg = "OfficeCode is not mapped with Current ZO";
								}
							}
						}
						
						if (!matchBranchcode) {
							bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName,
									role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
							if (bulkUserCreation != null) {
								bulkUserCreationList.add(bulkUserCreation);
							}
						}
						
					} else {
						isActive = false;
						msg = "Invalid BranchCode";
						bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName,
								role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
						if (bulkUserCreation != null) {
							bulkUserCreationList.add(bulkUserCreation);
						}
					}
				} catch (Exception e) {
					logger.error("Exception while check Branch Code " + e.getMessage());
				}
			}
			// FETCH SCHEME LIST BY BRANCH ID FROM BRANCH PRODUCT MAPPING TO CHECK IF
			// ALREADY EXITS OR NOT
			List<Long> schemeList = null;
			if (isActive && !OPLUtils.isObjectNullOrEmpty(officeCode)
					&& (role.equals("Branch_Officer") || role.equals("Branch_Maker") || role.equals("Regional_Officer")
							|| role.equals("Zonal_Officer"))) {
				schemeList = branchProductMappingRepo.getSchemeListByBranchId(Long.parseLong(branchId));
				if (OPLUtils.isObjectNullOrEmpty(schemeList) || schemeList.size() == 0) {
					isActive = false;
					msg = "Branch is not mapped with selected schemes";
					
				}
			} else if (isActive && OPLUtils.isObjectNullOrEmpty(officeCode)
					&& (role.equals("Head_Officer") || role.equals("Admin_Maker") || role.equals("Admin_Checker"))) {
				schemeList = schemeMasterRepo.getSchemeIdFromMaster();

			}
			// CHECK USER IS ALREADY EXISTS OR NOT
			User emailExist = null;
			if (isActive) {
				// CHECK EMAIL OR MOBILE IS DUBLICATE OR NOT
				BulkUploadUserExistProxyV3 bulkUploadUserExistProxy = bulkUploadComponent.checkEmailOrMobileExist(email,
						mobile);
				if (!bulkUploadUserExistProxy.getIsActive()) {
					isActive = false;
					emailExist = bulkUploadUserExistProxy.getUser();
					msg = bulkUploadUserExistProxy.getMessage();
				} else {
					if (bulkUploadUserExistProxy.getUser() != null) {
						emailExist = bulkUploadUserExistProxy.getUser();
						isActive = false;
						msg = "Email Or Mobile Is Already Exists";
					}
				}
			}

//			if (!OPLUtils.isObjectNullOrEmpty(emailExist)) {
//				isActive = false;
//				bulkUserCreation = saveBulkUserCreation(null, email, mobile, firstName, middleName, lastName,
//						role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
//				if (bulkUserCreation != null) {
//					bulkUserCreationList.add(bulkUserCreation);
//				}
//			}


			// FETCH USER ROLE PRODUCT MAPPING LIST TO CHECK DUBLICATION OF ROLE AND SCHEME
			// MAPPING
			List<UserRoleProductMapping> userRoleProductMappings = null;
//			if (OPLUtils.isObjectNullOrEmpty(emailExist)) {
//				
//			} else {
//				
//			}
			if (emailExist != null) {
				userRoleProductMappings = roleProductMapping.findByUserUserId(emailExist.getUserId());
			}
			if (!OPLUtils.isListNullOrEmpty(schemeList) && schemeList.size() > 0) {

				List<Long> saveSchemeList = new ArrayList<>(schemeList);
				// SAVE SCHEME WISE BULK ENTRY
				schemeWiseLoop: for (Long schemeId : schemeList) {
					SchemeMaster scheme = SchemeMaster.getById(schemeId);
					bulkUserCreation = new BulkUserCreation();
					try {
						/*
						 * bulkUserCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null :
						 * email.trim());
						 * bulkUserCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null :
						 * mobile.trim());
						 * bulkUserCreation.setFirstName(OPLUtils.isObjectNullOrEmpty(firstName) ? null
						 * : firstName);
						 * bulkUserCreation.setMiddleName(OPLUtils.isObjectNullOrEmpty(middleName) ?
						 * null : middleName);
						 * bulkUserCreation.setLastName(OPLUtils.isObjectNullOrEmpty(lastName) ? null :
						 * lastName); bulkUserCreation.setRole(OPLUtils.isObjectNullOrEmpty(role) ? null
						 * : role); bulkUserCreation.setBranchId(OPLUtils.isObjectNullOrEmpty(branchId)
						 * ? null : branchId); bulkUserCreation.setOrgId(orgId);
						 * bulkUserCreation.setBusinessTypeId(scheme.getBussinessId());
						 * bulkUserCreation.setSchemeId(schemeId);
						 * bulkUserCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(officeCode) ?
						 * null : officeCode); bulkUserCreation.setCreatedDate(new Date());
						 * bulkUserCreation.setFileId(fileId);
						 */
						// CHECK DEFAULT VALIDATION
						bulkUserCreation = saveBulkUserCreation(scheme, email, mobile, firstName, middleName, lastName,
								role, branchId, orgId, officeCode, fileId, isActive, msg, userRoleId, userBranchId, originalFileName);
//                        if (!isActive) {
//                            saveSchemeList.remove(schemeId);
//                            bulkUserCreation.setIsActive(false);
//                            bulkUserCreation.setMessage(msg);
//                            continue schemeWiseLoop;
//                        }
						bulkUserCreation.setMessage("Saved Successfully");
						bulkUserCreation.setIsActive(true);

						// CHECK BRANCH IF VALID OR NOT
//                    if(!OPLUtils.isObjectNullOrEmpty(officeCode)) {
//                        if (schemeList != null && !schemeList.contains(schemeId)) {
//                            saveSchemeList.remove(schemeId);
//                            bulkUserCreation.setIsActive(false);
//                            bulkUserCreation.setMessage("Branch is not mapped with selected schemes");
//                            continue schemeWiseLoop;
//                        }
//                    }
						// CHECK USER ROLE MAPPING TABLE TO AVOID DUBLICATIOn
						if (emailExist != null && userRoleProductMappings != null
								&& userRoleProductMappings.size() > 0) {
							Long roleId = emailExist.getUserRoleId().getRoleId();
							UserRoleProductMapping map = userRoleProductMappings.stream()
									.filter(a -> a.getUserRoleMaster().getRoleId().equals(roleId)
											&& a.getSchemeId().equals(scheme.getId()))
									.findFirst().orElse(null);
							if (map != null) {
								saveSchemeList.remove(schemeId);
								bulkUserCreation.setIsActive(false);
								bulkUserCreation.setMessage("User has already assign with same role and schemeId");
								continue schemeWiseLoop;
							}
						}
						// HERE USER ROW IS VALID
					} catch (Exception e) {
						logger.error("Exception while save scheme wise user entry ", e);
					} finally {
						if (bulkUserCreation != null) {
							bulkUserCreationList.add(bulkUserCreation);
						}
					}
				} // END SCHEME WISE FOR LOOP
					// if (isActive) {
				if (saveSchemeList.size() > 0) {
					bulkUploadComponent.createUserAndUserSchemeMapping(email, mobile, firstName, lastName, role, orgId,
							branchId != null ? Long.valueOf(branchId) : null, saveSchemeList, emailExist);
				}
				// }
			}
		}
		bulkUserCreationRepository.saveAll(bulkUserCreationList);
		return true;
	}

	private BulkUserCreation saveBulkUserCreation(SchemeMaster scheme, String email, String mobile, String firstName,
			String middleName, String lastName, String role, String branchId, Long orgId, String officeCode,
			Long fileId, Boolean isActive, String msg, Long userRoleId, Long userBranchId, String originalFileNme) {
		BulkUserCreation bulkUserCreation = new BulkUserCreation();
		bulkUserCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null : email.trim());
		bulkUserCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null : mobile.trim());
		bulkUserCreation.setFirstName(OPLUtils.isObjectNullOrEmpty(firstName) ? null : firstName);
		bulkUserCreation.setMiddleName(OPLUtils.isObjectNullOrEmpty(middleName) ? null : middleName);
		bulkUserCreation.setLastName(OPLUtils.isObjectNullOrEmpty(lastName) ? null : lastName);
		bulkUserCreation.setRole(OPLUtils.isObjectNullOrEmpty(role) ? null : role);
		bulkUserCreation.setBranchId(OPLUtils.isObjectNullOrEmpty(branchId) ? null : branchId);
		bulkUserCreation.setOrgId(orgId);
		bulkUserCreation.setBusinessTypeId(OPLUtils.isObjectNullOrEmpty(scheme) ? null : scheme.getBussinessTypeId());
		bulkUserCreation.setSchemeId(OPLUtils.isObjectNullOrEmpty(scheme) ? null : scheme.getId());
		bulkUserCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(officeCode) ? null : officeCode);
		bulkUserCreation.setCreatedDate(new Date());
		bulkUserCreation.setFileId(fileId);
		bulkUserCreation.setMessage(OPLUtils.isObjectNullOrEmpty(msg) ? null : msg);
		bulkUserCreation.setUserRoleId(userRoleId);
		bulkUserCreation.setCreatedByBranchId(OPLUtils.isObjectNullOrEmpty(userBranchId) ? null : String.valueOf(userBranchId));
		bulkUserCreation.setOriginalFileName(OPLUtils.isObjectNullOrEmpty(originalFileNme) ? "-" : originalFileNme);
		// CHECK DEFAULT VALIDATION
		bulkUserCreation.setIsActive(isActive);
		return bulkUserCreation;
	}

	@Override
	public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile, Long productMappingId) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("applicationId", orgId);
		jsonObj.put("productDocumentMappingId", productMappingId);
		jsonObj.put("userType", DocumentAlias.UERT_TYPE_APPLICANT);
		jsonObj.put("originalFileName", multipartFile.getOriginalFilename());
		try {
			DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
			logger.info("response {}", documentResponse.getStatus());
			StorageDetailsResponse response = null;

			Map<String, Object> list = null;
			if (!OPLUtils.isObjectNullOrEmpty(documentResponse.getData())) {
				list = (Map<String, Object>) documentResponse.getData();
//					list = MultipleJSONObjectHelper.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(documentResponse.getData()));
			}

			if (!OPLUtils.isObjectListNull(list)) {
				try {
					response = MultipleJSONObjectHelper.getObjectFromMap(list, StorageDetailsResponse.class);
				} catch (IOException e) {
					logger.info("Could not upload file to DMS");
				}
			}

			if (response != null) {
				logger.debug("uploadExcel() :: response is not null");
				return response.getId();
			} else {
				logger.debug("uploadExcel() :: response is null");
				return null;
			}
		} catch (DocumentException e) {
			logger.info("Could not upload file to DMS");
			return null;
		}
	}

	public static String extractCellFromSheet(Sheet sheet, String rowNumber) {
		try {
			CellReference cellReference = new CellReference(rowNumber);
			Row row = sheet.getRow(cellReference.getRow());
			Cell cell = row.getCell(cellReference.getCol());
			if (cell != null) {
				if (cell.getCellType() == 0) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					return cell.toString();
				} else {
					return cell.toString();
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}

	public static Date extractNumericCellFromSheet(Sheet sheet, String rowNumber) {
		try {
			CellReference cellReference = new CellReference(rowNumber);
			Row row = sheet.getRow(cellReference.getRow());
			Cell cell = row.getCell(cellReference.getCol());
			if (cell != null) {
				cell.setCellType(Cell.CELL_TYPE_NUMERIC);
				try {
				
					 String s = DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, cell.getDateCellValue());                    
	                    return DateUtils.parse(DateFormat.DD_MM_YYYY, s);
					
//					String s = FORMAT.format(cell.getDateCellValue());
//					return FORMAT.parse(s);
				} catch (Exception e) {
					return null;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId) {
		UserResponseProxy userResponse = new UserResponseProxy();
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setApplicationId(orgId);
		documentRequest.setUserType(DocumentAlias.UERT_TYPE_APPLICANT);

		switch (businessTypeId) {			
		 case 1:
         case 3:
         case 5:
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
			documentRequest.setProductDocumentMappingId(UserCreationUtil.USER_EXCEL_LIST_FOR_COMMON);
			break;

		default:
			break;
		}

//		try {
//			DocumentResponse documentResponse = dmsClient.listProductDocumentBankUser(documentRequest);
			try {
				FileResponseProxy fileResponse = null;
				List<FileResponseProxy> fileResponseList = new ArrayList<>();
//				for (Object object : documentResponse.getDataList()) {
//					StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromMap((LinkedHashMap<String, Object>) object, StorageDetailsResponse.class);
					List<Object[]> entryList = null;
					
            		if (userRoleId == UserRoleMaster.HEAD_OFFICE.getId()) {
            			entryList = bulkUserCreationRepository.getFileEntriesForHO(orgId);
            		} else {
            			entryList = bulkUserCreationRepository.getFileEntries(userBranchId);                			
            		}
            		
					for (Object[] obj : entryList) {
						fileResponse = new FileResponseProxy();
						fileResponse.setTotalEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[0])) ? Integer.parseInt(String.valueOf(obj[0])) : 0);
						fileResponse.setSuccessfulEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[1])) ? Integer.parseInt(String.valueOf(obj[1])) : 0);
						fileResponse.setFailedEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[2])) ? Integer.parseInt(String.valueOf(obj[2])) : 0);
						fileResponse.setId(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[3])) ? Long.parseLong(String.valueOf(obj[3])) : 0);
						fileResponse.setCreatedDate((Date)(obj[4]));
						fileResponse.setOriginalFileName(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[5])) ? String.valueOf(obj[5]) : "-");
						fileResponseList.add(fileResponse);
					}
//					fileResponse.setId(storageDetailsResponse.getId());
//					fileResponse.setOriginalFileName(storageDetailsResponse.getOriginalFileName());
//					fileResponse.setCreatedDate(storageDetailsResponse.getCreatedDate());
//					fileResponseList.add(fileResponse);
//				}

				if (fileResponseList != null) {
					Collections.sort(fileResponseList, new Comparator<FileResponseProxy>() {
						@Override
						public int compare(FileResponseProxy o1, FileResponseProxy o2) {
							return o2.getCreatedDate().compareTo(o1.getCreatedDate());
						}
					});
				}
				userResponse.setListData(fileResponseList);
			} catch (Exception e) {
				logger.error("Error while getting file", e);
				return null;
			}

			return userResponse;
//		} catch (DocumentException e) {
//			logger.error("Error while getting file details", e);
//			return null;
//		}
	}

	@Override
	public List<BulkUserResponseProxy> getFileEntryList(FileResponseProxy fileResponse) {
		try {
			logger.info("inSide getFileEntryList() fileId==>>>  {}", fileResponse.getId());
			List<BulkUserResponseProxy> bulkUserResponseList = new ArrayList<>();

			List<BulkUserCreation> bulkUserCreationList = bulkUserCreationRepository.findAllByFileId(fileResponse.getId());
			if (!OPLUtils.isObjectNullOrEmpty(fileResponse.getCheckEntry())) {
				if (fileResponse.getCheckEntry() == 2) {
					bulkUserCreationList = bulkUserCreationRepository.findAllByFileId(fileResponse.getId());
				} else {
					bulkUserCreationList = bulkUserCreationRepository.findAllByFileIdAndIsActive(fileResponse.getId(), fileResponse.getCheckEntry() == 0 ? true : false);
				}
			}
			if (!OPLUtils.isListNullOrEmpty(bulkUserCreationList)) {
				BulkUserResponseProxy bulkUserResponse = null;
				for (BulkUserCreation bulkUserCreation : bulkUserCreationList) {
					bulkUserResponse = new BulkUserResponseProxy();
					BeanUtils.copyProperties(bulkUserCreation, bulkUserResponse);
					if (!OPLUtils.isObjectNullOrEmpty(bulkUserCreation.getSchemeId())) {
						bulkUserResponse.setSchemeName(String.valueOf(SchemeMaster.getById(bulkUserCreation.getSchemeId()).getName()));
					} else {
						bulkUserResponse.setSchemeName("Not any scheme");
					}
//                    if (!OPLUtils.isObjectNullOrEmpty(bulkUserCreation.getBranchId())){
//                        String branchCode = bulkUserCreationRepository.getBranchCodeFromBranchId(Long.valueOf(bulkUserCreation.getBranchId()));
//                        bulkUserResponse.setBranchCode(branchCode);
//                    }
					bulkUserResponseList.add(bulkUserResponse);
				}
				logger.info("SuccessFully Get Data ==>>>  ");
				return bulkUserResponseList;
			}
		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

	@Override
	public String getUserRoleEntries(UserListResponseProxy userListResponse) {
		try {
			String list = bulkUserCreationRepository.getUserRoleEntries(userListResponse.getUserOrgId(), userListResponse.getFileId());
			return list;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
			return null;
		}

	}

	@Override
	public String getUserEntryCount(UserListResponseProxy userListResponse) {
		try {
			String list = bulkUserCreationRepository.getEntryCount(userListResponse.getUserOrgId(), userListResponse.getFileId());

			return list;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
			return null;
		}
	}

	@Override
	public List<BulkUserResponseProxy> getAllUserEntryList(UserListResponseProxy userListResponse) {
		try {
			List<BulkUserResponseProxy> bulkUserResponseList = new ArrayList<>();
			BulkUserResponseProxy bulkUserResponse = null;
			List<BulkUserCreation> list = bulkUserCreationRepository.findAllByOrgIdAndBusinessTypeId(userListResponse.getUserOrgId(), userListResponse.getFileId());
			for (BulkUserCreation bulkUserCreation : list) {
				bulkUserResponse = new BulkUserResponseProxy();
				BeanUtils.copyProperties(bulkUserCreation, bulkUserResponse);
				if (!OPLUtils.isObjectNullOrEmpty(bulkUserCreation.getBranchId())) {
					String branchCode = bulkUserCreationRepository.getBranchCodeFromBranchId(Long.valueOf(bulkUserCreation.getBranchId()));
					bulkUserResponse.setBranchCode(branchCode);
				}
				bulkUserResponseList.add(bulkUserResponse);
			}
			return bulkUserResponseList;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
			return null;
		}
	}

	@Override
	public String getUserFileEntryCount(FileResponseProxy fileResponse) {
		try {
			String list = bulkUserCreationRepository.getUserFileEntryCount(fileResponse.getId());
			return list;
		} catch (Exception e) {
			logger.error("Exception :- ", e);
			return null;
		}

	}

	@Override
	public Boolean extractExcelForFacilitator(MultipartFile multipartFile, Long cretaedBy, Long fileId, Long schemeId, Long userType) {
		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(multipartFile.getInputStream());

		} catch (Exception e) {
//			e.printStackTrace();
		}
		Sheet worksheet = (Sheet) workbook.getSheetAt(0);
		logger.info("Row Num : {}", worksheet.getLastRowNum());
		String mobile = null, firstName = null, email = null;
		// Long schemeId = null;
		/*
		 * if(userType == UserTypeMaster.FACILITATOR.getId()) { schemeIds =
		 * roleProductMapping.getSchemeIds(cretaedBy); } if(userType ==
		 * UserTypeMaster.ULB.getId()) { schemeIds.add(11l); }
		 */
		BulkFacilitatorCreation bulkFacilitatorCreation = null;
		int row = worksheet.getPhysicalNumberOfRows() + 1;
//        for(Long schemeId : schemeIds) {
		for (int i = 2; i <= row; i++) {
			firstName = extractCellFromSheet(worksheet, "B" + i);
			email = extractCellFromSheet(worksheet, "C" + i);
			mobile = extractCellFromSheet(worksheet, "D" + i);

			if (OPLUtils.isObjectNullOrEmpty(mobile) && OPLUtils.isObjectNullOrEmpty(firstName)) {

			} else {
				bulkFacilitatorCreation = new BulkFacilitatorCreation();
				try {
					bulkFacilitatorCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null : email);
					bulkFacilitatorCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null : mobile);
					if (userType == UserTypeMaster.COUNCIL.getId()) {
						bulkFacilitatorCreation.setRole(UserRoleMaster.FACILITATOR.getId());
					} else {
						bulkFacilitatorCreation.setRole(UserRoleMaster.ULB.getId());
					}
					bulkFacilitatorCreation.setFirstName(OPLUtils.isObjectNullOrEmpty(firstName) ? null : firstName);
					bulkFacilitatorCreation.setBusinessTypeId(SchemeMaster.getById(schemeId).getBussinessTypeId());
					bulkFacilitatorCreation.setSchemeId(schemeId);
					bulkFacilitatorCreation.setCreatedDate(new Date());
					bulkFacilitatorCreation.setFileId(fileId);
					User userObj = new User();
					Long existUser = userRepo.getUserIdByEmailMobile(bulkFacilitatorCreation.getEmail(), bulkFacilitatorCreation.getMobile(), userType);
					if (userType == UserTypeMaster.COUNCIL.getId()) {
						userObj = userRepo.findOneByEmailAndUserTypeMasterId(email, UserTypeMaster.COUNCIL.getId());
						if (OPLUtils.isObjectNullOrEmpty(userObj)) {
							userObj = userRepo.findOneByMobileAndUserTypeMasterId(mobile, UserTypeMaster.COUNCIL.getId());
						}
					} else {
						userObj = userRepo.findOneByEmailAndUserTypeMasterId(email, UserTypeMaster.ULB.getId());
						if (OPLUtils.isObjectNullOrEmpty(userObj)) {
							userObj = userRepo.findOneByMobileAndUserTypeMasterId(mobile, UserTypeMaster.ULB.getId());
						}
					}
					if (OPLUtils.isObjectNullOrEmpty(existUser)) {
						if (!OPLUtils.isObjectNullOrEmpty(userObj)) {
							logger.info("Email or Mobile is already exist");
							bulkFacilitatorCreation.setIsActive(Boolean.FALSE);
							bulkFacilitatorCreation.setMessage("Mobile is already exist");
						} else {

							boolean isContactValid = isValidContactNo(bulkFacilitatorCreation.getMobile());
							if (!isContactValid) {
								logger.info("Mobile number is not valid");
								bulkFacilitatorCreation.setIsActive(Boolean.FALSE);
								bulkFacilitatorCreation.setMessage("Mobile number is not valid");
							} else {
								bulkFacilitatorCreation.setIsActive(Boolean.TRUE);
							}
						}
					} else {
						bulkFacilitatorCreation.setIsActive(Boolean.TRUE);

					}

					bulkFacilitatorCreationRepo.save(bulkFacilitatorCreation);
					logger.info("Saved !{}", bulkFacilitatorCreation);
				} catch (Exception e) {
					logger.error("Exception", e);
				}
			}
		}

//        }
		boolean saveFacilitator = saveFacilitatorOrUlb(schemeId, cretaedBy, fileId, userType);
		return saveFacilitator;
	}

	public Boolean extractExcelForUlb(MultipartFile multipartFile, AuthClientResponse authClientResponse, Long fileId, Long schemeId, Long userType) {
		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(multipartFile.getInputStream());

		} catch (Exception e) {
//			e.printStackTrace();
		}
		Sheet worksheet = (Sheet) workbook.getSheetAt(1);
		logger.info("Row Num : {}", worksheet.getLastRowNum());
		String mobile = null, firstName = null, email = null, ulbRole = null;
		Long stateLgdCode, districtLgdCode, ulbLgdCode;
		BulkUlbCreation bulkUlbCreation = null;
		List<BulkUlbCreation> bulkUlbCreationList = new ArrayList<>(502);

		List<String> emailList = new ArrayList<>();
		List<String> mobileList = new ArrayList<>();

		int row = worksheet.getPhysicalNumberOfRows() < 503 ? worksheet.getPhysicalNumberOfRows() : 503;

		int blankRowCount = 0;
		mainLoop: for (int i = 4; i <= row; i++) {

			if (blankRowCount > 5) {
				break mainLoop;
			}

			if (isRowEmpty(worksheet.getRow(i - 1))) {
				blankRowCount++;
				continue;
			}

			if (UserRoleMaster.STATE_VERIFIER.getId() == authClientResponse.getUserRoleId()) {
				UlbUserMapping ulbUserMapping = ulbUserMappingRepo.findByUserId(authClientResponse.getUserId());
				ulbRole = UserRoleMaster.ULB.getValue();
				firstName = extractCellFromSheet(worksheet, "C" + i);
				email = extractCellFromSheet(worksheet, "D" + i);
				mobile = extractCellFromSheet(worksheet, "E" + i);
				ulbLgdCode = !OPLUtils.isObjectNullOrEmpty(extractCellFromSheet(worksheet, "F" + i)) ? Long.valueOf(Integer.valueOf(extractCellFromSheet(worksheet, "F" + i))) : null;
				districtLgdCode = !OPLUtils.isObjectNullOrEmpty(extractCellFromSheet(worksheet, "G" + i)) ? Long.valueOf(Integer.valueOf(extractCellFromSheet(worksheet, "G" + i))) : null;
				stateLgdCode = (!OPLUtils.isObjectNullOrEmpty(ulbUserMapping) && !OPLUtils.isObjectNullOrEmpty(ulbUserMapping.getStateCode())) ? ulbUserMapping.getStateCode() : null;
			} else {
				ulbRole = extractCellFromSheet(worksheet, "C" + i);
				firstName = extractCellFromSheet(worksheet, "D" + i);
				email = extractCellFromSheet(worksheet, "E" + i);
				mobile = extractCellFromSheet(worksheet, "F" + i);
				ulbLgdCode = !OPLUtils.isObjectNullOrEmpty(extractCellFromSheet(worksheet, "G" + i)) ? Long.valueOf(Integer.valueOf(extractCellFromSheet(worksheet, "G" + i))) : null;
				districtLgdCode = !OPLUtils.isObjectNullOrEmpty(extractCellFromSheet(worksheet, "H" + i)) ? Long.valueOf(Integer.valueOf(extractCellFromSheet(worksheet, "H" + i))) : null;
				stateLgdCode = !OPLUtils.isObjectNullOrEmpty(extractCellFromSheet(worksheet, "I" + i)) ? Long.valueOf(Integer.valueOf(extractCellFromSheet(worksheet, "I" + i))) : null;
			}

			boolean isActive = false;
			String msg = "";
			// CHECK BASIC VALIDATION
			if (OPLUtils.isObjectNullOrEmpty(email)) {
				msg = "EmailId can not be null";
			} else {
				email = email.replaceAll("\\s", "");
				if (emailList.contains(email)) {
					msg = "Email is already exist in given sheet";
				}
				emailList.add(email);
			}
			if (email.length() > 255 || !Pattern.matches("^([a-zA-Z0-9])[\\w\\-\\.\\+]+\\@[a-zA-Z0-9\\.\\-]+\\.[a-zA-z0-9]{2,5}", email)) {
				msg = "EmailId is Invalid";
			}

			if (OPLUtils.isObjectNullOrEmpty(mobile)) {
				msg = "Mobile can not be null";
			} else {
				mobile = mobile.replaceAll("\\s", "");
				if (mobileList.contains(mobile)) {
					msg = "Mobile is already exist in given sheet";
				}
				mobileList.add(mobile);
				if (mobile.length() > 10) {
					msg = "MobileNo is Invalid";
				}
			}
			
			if (OPLUtils.isObjectNullOrEmpty(firstName)) {
				msg = "First Name can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(ulbRole)) {
				msg = "ULB Role can not be null";
			} else if (!"Urban Local Body".equalsIgnoreCase(ulbRole) && !"State Verifier".equalsIgnoreCase(ulbRole)) {
				msg = "ULB Role is Invalid";
			}

			if ("Urban Local Body".equalsIgnoreCase(ulbRole) && OPLUtils.isObjectNullOrEmpty(ulbLgdCode)) {
				msg = "ULB Code can not be null";
			}

			if ("Urban Local Body".equalsIgnoreCase(ulbRole) && OPLUtils.isObjectNullOrEmpty(districtLgdCode)) {
				msg = "District Code can not be null";
			}

			if (OPLUtils.isObjectNullOrEmpty(stateLgdCode)) {
				msg = "State Code can not be null";
			}
			if (OPLUtils.isObjectNullOrEmpty(msg)) {
				isActive = true;
			}

			bulkUlbCreation = new BulkUlbCreation();
			try {
				bulkUlbCreation.setEmail(OPLUtils.isObjectNullOrEmpty(email) ? null : email.trim());
				bulkUlbCreation.setMobile(OPLUtils.isObjectNullOrEmpty(mobile) ? null : mobile.trim());
				bulkUlbCreation.setStateLgdCode(OPLUtils.isObjectNullOrEmpty(stateLgdCode) ? null : stateLgdCode);
				bulkUlbCreation.setDistrictLgdCode(OPLUtils.isObjectNullOrEmpty(districtLgdCode) ? null : districtLgdCode);
				bulkUlbCreation.setUlbLgdCode(OPLUtils.isObjectNullOrEmpty(ulbLgdCode) ? null : ulbLgdCode);
				if (ulbRole.equalsIgnoreCase("Urban Local Body")) {
					bulkUlbCreation.setRole(UserRoleMaster.ULB.getId());
				} else if (ulbRole.equalsIgnoreCase("State Verifier")) {
					bulkUlbCreation.setRole(UserRoleMaster.STATE_VERIFIER.getId());
				}
				bulkUlbCreation.setRoleName(OPLUtils.isObjectNullOrEmpty(ulbRole) ? null : ulbRole);
				bulkUlbCreation.setFirstName(OPLUtils.isObjectNullOrEmpty(firstName) ? null : firstName.trim());
				bulkUlbCreation.setBusinessTypeId(SchemeMaster.getById(schemeId).getBussinessTypeId());
				bulkUlbCreation.setSchemeId(schemeId);
				bulkUlbCreation.setCreatedDate(new Date());
				bulkUlbCreation.setFileId(fileId);

				if (isActive) {
					User userObj = new User();
					userObj = userRepo.findOneByEmailAndUserTypeMasterId(email, UserTypeMaster.ULB.getId());
					if (OPLUtils.isObjectNullOrEmpty(userObj)) {
						userObj = userRepo.findOneByMobileAndUserTypeMasterId(mobile, UserTypeMaster.ULB.getId());
					}

					Long existUser = userRepo.getUserIdByEmailMobile(bulkUlbCreation.getEmail(), bulkUlbCreation.getMobile(), userType);
					if (OPLUtils.isObjectNullOrEmpty(existUser)) {
						if (!OPLUtils.isObjectNullOrEmpty(userObj)) {
							logger.info("Email or Mobile is already exist");
							bulkUlbCreation.setIsActive(Boolean.FALSE);
							bulkUlbCreation.setMessage("Mobile is already exist");
						} else {
							boolean isContactValid = isValidContactNo(bulkUlbCreation.getMobile());
							if (!isContactValid) {
								logger.info("Mobile number is not valid");
								bulkUlbCreation.setIsActive(Boolean.FALSE);
								bulkUlbCreation.setMessage("Mobile number is not valid");
							} else {
								bulkUlbCreation.setIsActive(Boolean.TRUE);
								bulkUlbCreation.setMessage("SuccessFully Created");
							}
						}

						if ("Urban Local Body".equalsIgnoreCase(ulbRole)) {
							UlbDistrictMapping ulbDistrictMapping = ulbDistrictMappingRepo.getUlbExist(stateLgdCode, districtLgdCode, ulbLgdCode);
							if (!OPLUtils.isObjectNullOrEmpty(ulbDistrictMapping)) {
								User saveUlb = saveUlb(bulkUlbCreation, schemeId, authClientResponse.getUserId(), fileId, userType);
								if (!OPLUtils.isObjectNullOrEmpty(saveUlb)) {
									ulbUserMappingRepo.deleteTaggedUlb(saveUlb.getUserId());
									UlbUserMapping ulb = new UlbUserMapping();
									ulb.setUserId(saveUlb.getUserId());
									ulb.setUlbCode(ulbDistrictMapping.getUlbLgdCode());
									ulb.setStateCode(ulbDistrictMapping.getStateLgdCode());
									ulb.setIsActive(true);
									ulb.setCreatedBy(authClientResponse.getUserId());
									ulb.setCreatedDate(new Date());
									ulbUserMappingRepo.save(ulb);
								} else {
									logger.info("User is not created");
									bulkUlbCreation.setIsActive(Boolean.FALSE);
									bulkUlbCreation.setMessage("User is not created");
								}
							} else {
								logger.info("The ULB details provided did not match with onboarded ULBs.");
								bulkUlbCreation.setIsActive(Boolean.FALSE);
								bulkUlbCreation.setMessage("The ULB details provided did not match with onboarded ULBs.");
							}
						} else if ("State Verifier".equalsIgnoreCase(ulbRole) && !OPLUtils.isObjectNullOrEmpty(stateLgdCode)) {
							User saveUlb = saveUlb(bulkUlbCreation, schemeId, authClientResponse.getUserId(), fileId, userType);
							if (!OPLUtils.isObjectNullOrEmpty(saveUlb)) {
								ulbUserMappingRepo.deleteTaggedUlb(saveUlb.getUserId());
								UlbUserMapping ulb = new UlbUserMapping();
								ulb.setUserId(saveUlb.getUserId());
								ulb.setUlbCode(!OPLUtils.isObjectNullOrEmpty(ulbLgdCode) ? ulbLgdCode : null);
								ulb.setStateCode(!OPLUtils.isObjectNullOrEmpty(stateLgdCode) ? stateLgdCode : null);
								ulb.setIsActive(true);
								ulb.setCreatedBy(authClientResponse.getUserId());
								ulb.setCreatedDate(new Date());
								ulbUserMappingRepo.save(ulb);
							} else {
								logger.info("User is not created");
								bulkUlbCreation.setIsActive(Boolean.FALSE);
								bulkUlbCreation.setMessage("User is not created");
							}
						}else{
							logger.info("User is not created");
							bulkUlbCreation.setIsActive(Boolean.FALSE);
							bulkUlbCreation.setMessage("User is not created");
						}
					} else {
						logger.info("Email or Mobile is already exist");
						bulkUlbCreation.setMessage("Email or Mobile is already exist");
						bulkUlbCreation.setIsActive(Boolean.FALSE);
					}
				} else {
					logger.info("{} Failed email", email);
					bulkUlbCreation.setIsActive(isActive);
					bulkUlbCreation.setMessage(!OPLUtils.isObjectNullOrEmpty(msg) ? msg : null);
				}
			} catch (Exception e) {
				logger.error("Exception", e);
			} finally {
				if (bulkUlbCreation != null) {
					bulkUlbCreationList.add(bulkUlbCreation);
				}
			}
		}
		bulkUlbCreationRepo.saveAll(bulkUlbCreationList);
		return true;
	}

	private boolean isValidContactNo(String contactNo) {
		Pattern pattern = Pattern.compile("^\\d{10}$");
		Matcher matcher = pattern.matcher(contactNo);
		if (matcher.matches())
			return contactNo.startsWith("6") || contactNo.startsWith("7") || contactNo.startsWith("8") || contactNo.startsWith("9");
		else
			return false;
	}

	private boolean saveFacilitatorOrUlb(Long schemeId, Long cretaedBy, Long fileId, Long userType) {
		List<BulkFacilitatorCreation> creationList = new ArrayList<>();
		Long existScheme = null;
		creationList = bulkFacilitatorCreationRepo.findIsActive(fileId);
		for (BulkFacilitatorCreation creation : creationList) {
			User user = new User();
			Long existUser = userRepo.getUserIdByEmailMobile(creation.getEmail(), creation.getMobile(), userType);
			if (!OPLUtils.isObjectNullOrEmpty(existUser)) {
				user = userRepo.findByUserId(existUser);
			}
			user.setPassword(defaultPwd);
			user.setEmail(creation.getEmail());
			user.setMobile(creation.getMobile());
			if (userType == UserTypeMaster.COUNCIL.getId()) {
				user.setUserTypeMaster(userTypeRepo.getById(UserTypeMaster.COUNCIL.getId()));
				user.setUserRoleId(userRoleMasterRepo.findByRoleId(UserRoleMaster.FACILITATOR.getId()));
			} else {
				user.setUserTypeMaster(com.opl.jns.user.management.service.domain.UserTypeMaster.builder().id(UserTypeMaster.ULB.getId()).build());
				user.setUserRoleId(userRoleMasterRepo.findByRoleId(UserRoleMaster.ULB.getId()));
			}
			user.setFirstName(creation.getFirstName());
			user.setLastName(creation.getLastName());
			user.setMiddleName(creation.getMiddleName());
			user.setSignUpDate(new Date());
			user.setIsPassChanged(false);
			user.setTermsAccepted(true);
			user.setIsActive(true);
			user.setCreatedDate(new Date());
			user.setCreatedBy(cretaedBy);
			user.setEmailVerified(true);
			userRepo.save(user);

			if (!OPLUtils.isObjectNullOrEmpty(user)) {
				logger.info("Registration in users successfully -------------->" + creation.getEmail());
				existScheme = roleProductMapping.getSchemeByUserIdAndSchemeId(user.getUserId(), schemeId);
				if (!OPLUtils.isObjectNullOrEmpty(existScheme)) {
					roleProductMapping.deleteByUserIdAndSchemeId(user.getUserId(), existScheme);
				}

				if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
					UserRoleProductMapping roleMapping = new UserRoleProductMapping();
					roleMapping.setUser(user);
					if (userType == UserTypeMaster.COUNCIL.getId()) {
						roleMapping.setUserRoleMaster(userRoleMasterRepo.findByRoleId(UserRoleMaster.FACILITATOR.getId()));
					} else {
						roleMapping.setUserRoleMaster(userRoleMasterRepo.findByRoleId(UserRoleMaster.ULB.getId()));
					}
					roleMapping.setBusinessId(Long.valueOf(SchemeMaster.getById(schemeId).getBussinessTypeId()));
					roleMapping.setIsActive(Boolean.TRUE);
					roleMapping.setSchemeId(schemeId);
					roleMapping.setCreatedDate(new Date());
					roleMapping.setModifiedDate(new Date());
					roleProductMapping.save(roleMapping);
				}
			}
		}
		return true;
	}

	private User saveUlb(BulkUlbCreation creation, Long schemeId, Long cretaedBy, Long fileId, Long userType) {
		Long existScheme = null;
		User user = new User();
		Long existUser = userRepo.getUserIdByEmailMobile(creation.getEmail(), creation.getMobile(), UserTypeMaster.ULB.getId());
		if (!OPLUtils.isObjectNullOrEmpty(existUser)) {
			user = userRepo.findByUserId(existUser);
		}
		user.setPassword(defaultPwd);
		user.setEmail(creation.getEmail());
		user.setMobile(creation.getMobile());
		user.setUserTypeMaster(com.opl.jns.user.management.service.domain.UserTypeMaster.builder().id(UserTypeMaster.ULB.getId()).build());
		user.setUserRoleId(userRoleMasterRepo.findByRoleId(creation.getRole()));
		user.setFirstName(creation.getFirstName());
		user.setLastName(creation.getLastName());
		user.setMiddleName(creation.getMiddleName());
		user.setSignUpDate(new Date());
		user.setIsPassChanged(false);
		user.setTermsAccepted(true);
		user.setIsActive(true);
		user.setCreatedDate(new Date());
		user.setCreatedBy(cretaedBy);
		user.setEmailVerified(true);
		user.setOtpVerified(true);
		logger.info("{} successfully Created email", creation.getEmail());
		userRepo.save(user);

		if (!OPLUtils.isObjectNullOrEmpty(user)) {
			logger.info("Registration in users successfully -------------->" + creation.getEmail());
			existScheme = roleProductMapping.getSchemeByUserIdAndSchemeId(user.getUserId(), schemeId);
			if (!OPLUtils.isObjectNullOrEmpty(existScheme)) {
				roleProductMapping.deleteByUserIdAndSchemeId(user.getUserId(), existScheme);
			}

			if (!OPLUtils.isObjectNullOrEmpty(schemeId)) {
				UserRoleProductMapping roleMapping = new UserRoleProductMapping();
				roleMapping.setUser(user);
				roleMapping.setUserRoleMaster(userRoleMasterRepo.findByRoleId(creation.getRole()));
				roleMapping.setBusinessId(Long.valueOf(SchemeMaster.getById(schemeId).getBussinessTypeId()));
				roleMapping.setIsActive(Boolean.TRUE);
				roleMapping.setSchemeId(schemeId);
				roleMapping.setCreatedDate(new Date());
				roleMapping.setModifiedDate(new Date());
				roleProductMapping.save(roleMapping);
			}
		}

		return user;
	}

	@Override
	public UserResponseProxy listUploadedExcelFacilitatorOrUlb(Long userId, Long userType) {
		UserResponseProxy userResponse = new UserResponseProxy();
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setApplicationId(userId);
		documentRequest.setUserType(DocumentAlias.UERT_TYPE_APPLICANT);
		if (userType == UserTypeMaster.COUNCIL.getId()) {
			documentRequest.setProductDocumentMappingId(UserCreationUtil.FACILITATOR_EXCEL_LIST);
		} else {
			documentRequest.setProductDocumentMappingId(UserCreationUtil.ULB_EXCEL_LIST);
		}

		try {
			DocumentResponse documentResponse = dmsClient.listProductDocumentBankUser(documentRequest);
			try {
				FileResponseProxy fileResponse = null;
				List<FileResponseProxy> fileResponseList = new ArrayList<>();
				for (Object object : documentResponse.getDataList()) {
					StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromMap((LinkedHashMap<String, Object>) object, StorageDetailsResponse.class);
					List<Object[]> entryList = new ArrayList<>();
					if (userType == UserTypeMaster.COUNCIL.getId()) {
						entryList = bulkFacilitatorCreationRepo.getFileEntries(storageDetailsResponse.getId());
					} else {
						entryList = bulkUlbCreationRepo.getFileEntries(storageDetailsResponse.getId());
					}

					for (Object[] obj : entryList) {
						fileResponse = new FileResponseProxy();
						fileResponse.setTotalEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[0])) ? Integer.parseInt(String.valueOf(obj[0])) : 0);
						fileResponse.setSuccessfulEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[1])) ? Integer.parseInt(String.valueOf(obj[1])) : 0);
						fileResponse.setFailedEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[2])) ? Integer.parseInt(String.valueOf(obj[2])) : 0);
					}
					fileResponse.setId(storageDetailsResponse.getId());
					fileResponse.setOriginalFileName(storageDetailsResponse.getOriginalFileName());
					fileResponse.setCreatedDate(storageDetailsResponse.getCreatedDate());
					fileResponseList.add(fileResponse);

				}

				if (!OPLUtils.isListNullOrEmpty(fileResponseList)) {
					userResponse.setStatus(HttpStatus.OK.value());
					Collections.sort(fileResponseList, new Comparator<FileResponseProxy>() {
						@Override
						public int compare(FileResponseProxy o1, FileResponseProxy o2) {
							return o2.getCreatedDate().compareTo(o1.getCreatedDate());
						}
					});
				}
				userResponse.setListData(fileResponseList);
			} catch (Exception e) {
				logger.error("Error while getting file", e);
				return null;
			}

			return userResponse;
		} catch (DocumentException e) {
			logger.error("Error while getting file details", e);
			return null;
		}
	}

	@Override
	public List<BulkUserResponseProxy> getFileFacilitatorOrUlbEntryList(FileResponseProxy fileResponse) {
		try {
			List<BulkUserResponseProxy> bulkFacilitatorResponseList = new ArrayList<>();
			if (fileResponse.getUserType() == UserTypeMaster.COUNCIL.getId()) {
				List<BulkFacilitatorCreation> bulkFacilitatorCreation = bulkFacilitatorCreationRepo.findAllByFileId(fileResponse.getId());
				BulkUserResponseProxy bulkUserResponse = null;
				for (BulkFacilitatorCreation bulkFacilitator : bulkFacilitatorCreation) {
					bulkUserResponse = new BulkUserResponseProxy();
					BeanUtils.copyProperties(bulkFacilitator, bulkUserResponse);
					bulkUserResponse.setSchemeName(String.valueOf(SchemeMaster.getById(bulkFacilitator.getSchemeId()).getName()));
					bulkFacilitatorResponseList.add(bulkUserResponse);
				}
			} else {
				List<BulkUlbCreation> bulkUserCreationList = null;
				if (!OPLUtils.isObjectNullOrEmpty(fileResponse.getCheckEntry())) {
					if (fileResponse.getCheckEntry() == 2) {
						bulkUserCreationList = bulkUlbCreationRepo.findAllByFileId(fileResponse.getId());
					} else {
						bulkUserCreationList = bulkUlbCreationRepo.findAllByFileIdAndIsActive(fileResponse.getId(), fileResponse.getCheckEntry() == 0 ? true : false);
					}
				}
				BulkUserResponseProxy bulkUserResponse = null;
				for (BulkUlbCreation bulkUlbCreation : bulkUserCreationList) {
					bulkUserResponse = new BulkUserResponseProxy();
					BeanUtils.copyProperties(bulkUlbCreation, bulkUserResponse);
					bulkUserResponse.setSchemeName(String.valueOf(SchemeMaster.getById(bulkUlbCreation.getSchemeId()).getName()));
					bulkFacilitatorResponseList.add(bulkUserResponse);
				}
			}

			return bulkFacilitatorResponseList;

		} catch (Exception e) {
			logger.error("Exception :- ", e);
		}
		return null;
	}

}
