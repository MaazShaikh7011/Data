package com.opl.jns.user.management.service.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CommonUtils {
	public static final Long PARTNER = 1l;
	public static final Long CLIENT = 2l;
	public static final Integer SUCCESS = 1;
	public static final Integer FAILED = 2;
	public static final Long ADMIN_PANEL_TYPE_ID = 5l;

	public static final Integer BO = 1;
	public static final Integer RO = 2;
	public static final Integer ZO = 3;
	
	public static final String PRODUCT_DOCUMENT_MAPPING_ID = "productDocumentMappingId";
	public static final String USER_TYPE = "userType";
	public static final String ORIGINAL_FILE_NAME = "originalFileName";
	public static final String APPLICATION_ID = "applicationId";

	public static final String PAN_REGEX = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
	public static final String MOBILE_REGEX = "^((\\+91)?|91)?[789][0-9]{9}";
	public static final String EMAIL_REGEX ="^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{2,4})+$";

	public static final String MOBILE_ALREADY = "MobileNo is already exist,";
	public static final String MOBILE_NULL = "MobileNo can not be null,";
	public static final String MOBILE_INVALID = "MobileNo is Invalid,";
	
	public static final String EMAIL_ALREADY = "Email is already exist,";
	public static final String EMAIL_NULL = "Email can not be null,";
	public static final String EMAIL_INVALID = "Email is Invalid,";
	
	public static final String NAME_NULL = "Name can not be null,";
	
	public static final String SCHEME_NULL = "Scheme can not be null,";
	public static final String SCHEME_INVALID = "Scheme is Invalid,";
	
	public static final String PAN_NULL = "Pan can not be null,";
	public static final String PAN_INVALID = "Pan is Invalid,";
	
	public static final String USER_ORG_ID = "userOrgId";
	public static final String ORGANISATION_NAME = "organisationName";
	
	
	public static final String EMAIL_MOBILE_ALREADY = "Email Address & Mobile Number already in use";
	
	public static final String INTERNAL_SERVER_ERROR_MSG= "The application has encountered an error from Server. Please try again after sometime!!!.";
	
	public static File convertToCSV(String fileName,Long fileType){
		StringBuffer data = new StringBuffer();
		File outputFile = null;
        try {
        	 File inputFile = new File(fileName);
        	 
        	 outputFile =PARTNER.equals(fileType)? new File("partner.csv"):new File("client.csv");
             
             FileOutputStream fos = new FileOutputStream(outputFile);
             FileInputStream fis = new FileInputStream(inputFile);
             
             Workbook workbook = new XSSFWorkbook(fis);
             
             if(PARTNER.equals(fileType)) {
            	  data.append("name,email,mobile,scheme"+'\n'); 
             }else {
            	  data.append("name,email,mobile,scheme,pan"+'\n'); 
             }
          
            int numberOfSheets = workbook.getNumberOfSheets();
            Row row;
            Cell cell;
            for (int i = 0; i < numberOfSheets; i++) {
                Sheet sheet = workbook.getSheetAt(0);
                Iterator<Row> rowIterator = sheet.iterator();
                int cellIdx = 0;
                int rowNumber = 0;
                while (rowIterator.hasNext()) {
                	cellIdx = 0;
//                    row = rowIterator.next();
                    Row currentRow = rowIterator.next();
      			  // skip header
      			  if (rowNumber == 0) {
      				  rowNumber++;
      				  continue;
      			  }
                    // For each row, iterate through each columns
                    Iterator<Cell> cellIterator = currentRow.cellIterator();
                    while (cellIterator.hasNext()) {
                    	
                        cell = cellIterator.next();

                        switch (cellIdx) {
                        case 0:
                            data.append(cell.getStringCellValue() + ",");

                            break;
                        case 1:
                            data.append(cell.getStringCellValue() + ",");

                            break;
                        case 2:
                            data.append( NumberToTextConverter.toText(cell.getNumericCellValue()) + ",");
                            break;
                        case 3:
                            data.append(cell.getStringCellValue()  );
                            break;
                        case 4:
                            data.append( ","+cell.getStringCellValue());
                            break;
                        default:
//                            data.append(cell + ",");

                        }
                        cellIdx++;
                    }
//                    data.deleteCharAt(data.length()-1);
                    data.append('\n'); // appending new line after each row
                }

            }
           
            fos.write(data.toString().getBytes());
            fos.close();
            
            
        } catch (Exception ioe) {
//            ioe.printStackTrace();
        }
        return outputFile;
	}	

}
