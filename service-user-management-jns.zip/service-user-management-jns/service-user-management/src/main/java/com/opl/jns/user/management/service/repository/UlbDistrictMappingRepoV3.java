package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.api.model.UlbDistrictMappingProxy;
import com.opl.jns.user.management.service.domain.UlbDistrictMapping;

@Repository
public interface UlbDistrictMappingRepoV3 extends JpaRepository<UlbDistrictMapping, Long> {

//    List<UlbDistrictMapping> findByDistrictLgdCode(Long districtLgdCode);

    @Query(value="SELECT new com.opl.jns.user.management.api.model.UlbDistrictMappingProxy(u.id,u.ulbLgdCode,u.ulbName) FROM UlbDistrictMapping u WHERE u.isActive = TRUE AND u.districtLgdCode =:districtLgdCode ORDER BY u.createdDate DESC")
    public List<UlbDistrictMappingProxy> findByDistrictLgdCode(Long districtLgdCode);

    @Query(value="SELECT u FROM UlbDistrictMapping u WHERE u.ulbLgdCode=:ulbLgdCode AND u.isActive = TRUE")
    public UlbDistrictMapping getUlbListDistrictWise(@Param("ulbLgdCode") Long ulbLgdCode);

    @Query(value="SELECT u FROM UlbDistrictMapping u WHERE u.userId=:userId AND u.isActive = TRUE")
    public UlbDistrictMapping taggedUlb(@Param("userId") Long userId);

    @Query(value="SELECT u FROM UlbDistrictMapping u WHERE u.stateLgdCode=:stateLgdCode AND u.districtLgdCode=:districtLgdCode AND u.ulbLgdCode=:ulbLgdCode AND u.isActive = TRUE")
    public UlbDistrictMapping getUlbExist(@Param("stateLgdCode") Long stateLgdCode,@Param("districtLgdCode") Long districtLgdCode,@Param("ulbLgdCode") Long ulbLgdCode);

}
