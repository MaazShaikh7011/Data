package com.opl.jns.user.management.service.repository;

import java.util.List;

import com.opl.jns.user.management.api.model.TierMappingRequestProxy;
import com.opl.jns.user.management.service.domain.BranchProductMapping;

public interface TierMappingRepositoryV3 {
    public String getTierMappingList(TierMappingRequestProxy tierMappingRequest);

    public String getBranchCount(TierMappingRequestProxy tierMappingRequest);

    public String getSingleTierMapping(TierMappingRequestProxy tierMappingRequest);

    public Boolean updateBranchDetails(TierMappingRequestProxy tierMappingRequest);

    public String getAllZoList(Integer orgId, List<Long> selectedScheme);

    public String getAllLhoList(Integer orgId, List<Long> selectedScheme);

//    public String getAllRoList(Integer orgId);

    public String getAllRoList(Integer orgId, List<Long> selectedScheme);

    public Boolean updateBranchProductMapping(BranchProductMapping mapping);
    public Boolean chechBranchExist(Long branchId,Long schemeId);
    public Boolean inactiveBranch(Long branchId,List<Long> schemeId,Long orgId);
    public String getZObyROId(Long zoId,Integer orgId, List<Long> selectedScheme);

	public String getZObyLhoId(Long lhoId, Integer orgId, List<Long> selectedScheme);
	
	public String getBOROZObyId(Long branchId,Long userRoleId,Integer orgId, List<Long> selectedScheme);
	
	public String getBObyZOId(Long branchId,Long userRoleId,Integer orgId,Integer businessTypeId, List<Long> selectedScheme);

    public String getBranchMappingIds(Long branchId, Long schemeId);

    public String getBranchMappingByIfscCodeAndSchemeId(String ifsc, Long schemeId);
}
