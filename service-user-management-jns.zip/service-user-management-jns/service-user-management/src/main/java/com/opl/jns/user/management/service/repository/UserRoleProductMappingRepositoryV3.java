package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.service.domain.UserRoleProductMapping;



@Repository
public interface UserRoleProductMappingRepositoryV3 extends JpaRepository<UserRoleProductMapping,Long>{

    @Query("select m from UserRoleProductMapping m where m.user.id =:userId and m.isActive=true")
    List<UserRoleProductMapping> list(@Param("userId") Long userId);
    
//    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.userRoleMaster.roleId =:roleId")
//    UserRoleProductMapping checkExistingRole(@Param("userId") Long user,@Param("roleId") Long roleId);
//
//    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.businessId=:businessTypeId and m.isActive=true")
//    UserRoleProductMapping checkExistingRoleBybusinessType(@Param("userId") Long user,@Param("businessTypeId") Long businessTypeId);
    
    @Query("select m from UserRoleProductMapping m where m.user.id=:userId and m.isActive=true and m.businessId=:businessTypeId ")
    UserRoleProductMapping get(@Param("userId") Long user,@Param("businessTypeId") Long businessTypeId);

//    @Query("SELECT GROUP_CONCAT(DISTINCT um.displayName) FROM  UserRoleProductMapping urm inner join UserRoleMaster um on (um.roleId=urm.userRoleId AND um.isActive IS 1) WHERE urm.isActive IS 1 AND  urm.userId=:userId ")
//    String getUserRoleByUserId(@Param("userId") Long userId);

    void deleteByUserUserId(Long userId);

	List<UserRoleProductMapping> findByUserUserId(Long userId);

	@Modifying 
    @Query("DELETE FROM UserRoleProductMapping u WHERE u.user.userId =:userId") // if want to write nativequery then mask nativeQuery  as true
    void deleteByUserId(@Param("userId") Long userId);

    @Query("SELECT u.schemeId FROM UserRoleProductMapping u WHERE u.user.id=:userId AND u.isActive=TRUE")
    public List<Long> getSchemeIds(@Param("userId") Long userId);

    @Query("SELECT u.schemeId FROM UserRoleProductMapping u WHERE u.user.id=:userId AND u.schemeId=:schemeId AND u.isActive=TRUE")
    public Long getSchemeByUserIdAndSchemeId(@Param("userId") Long userId,@Param("schemeId") Long schemeId);

    @Modifying
    @Query("DELETE FROM UserRoleProductMapping u WHERE u.user.userId =:userId AND u.schemeId=:schemeId") // if want to write nativequery then mask nativeQuery  as true
    void deleteByUserIdAndSchemeId(@Param("userId") Long userId,@Param("schemeId") Long schemeId);

    @Modifying
    @Query("UPDATE UserRoleProductMapping urm SET urm.userRoleMaster.roleId=:userRoleId WHERE urm.user.userId =:userId")
	void updateRoleIdByUserId(@Param("userId") Long userId,@Param("userRoleId") Long userRoleId);

    @Modifying
    @Query("UPDATE User u SET u.userRoleId.roleId=:userRoleId WHERE u.userId =:userId")
	void changeAdminUserRole(@Param("userId") Long userId, @Param("userRoleId") Long userRoleId);

//    @Modifying
//    @Query("DELETE FROM UserRoleProductMapping WHERE userId =:userId AND schemeId IN(:selectedScheme)")
//	void deleteByUserIdAndSchemeIds(Long userId, List<Long> selectedScheme);
//
//	@Modifying
//	@Query("update UserRoleProductMapping set isActive = 0 WHERE userId =:userId AND schemeId IN(:schemeId) and isActive = 1")
//	void inactiveByUserIdAndSchemeId(@Param("userId") Long userId,List<Long> schemeId);
	
    @Modifying
    @Query("DELETE FROM UserRoleProductMapping WHERE user.userId =:userId")
	void deleteRolesByUserId(Long userId);
	
//	UserRoleProductMapping findByUserUserIdAndSchemeId(Long userId,Long schemeId);

}
