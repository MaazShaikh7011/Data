package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.user.management.service.domain.MenuPathMaster;

/**
 * @author ravi.thummar
 *
 */
public interface MenuPathMasterRepositoryV3 extends JpaRepository<MenuPathMaster, Long> {

//	@Query("SELECT mpm.menuId, mpm.navigationPath FROM MenuPathMaster mpm WHERE mpm.menuId =:menuId AND (mpm.loanTypeId =:loanTypeId OR mpm.loanTypeId = 0)")
//	MenuPathMaster findByMenuIdAndLoanTypeIdAndSchemeId(@Param("menuId") Long menuId, @Param("loanTypeId") Integer loanTypeId);

}
