package com.opl.jns.user.management.service.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.service.domain.BranchMaster;
import com.opl.jns.utils.constant.DBNameConstant;

public interface BranchMasterRepositoryV3 extends JpaRepository<BranchMaster, Long> {


//	@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.isActive=1  AND bm.branchType=1")
//	public List<BranchMaster> getBranchDetailsListByOrgId(@Param("userOrgId") Long userOrgId);
//
//	@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.isActive=1  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnOrgId(Long userOrgId);

	// ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query("select new com.opl.jns.user.management.service.domain.BranchMaster(bm.id, bm.code, bm.branchType) from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.isActive=true")
	public List<BranchMaster> getAllBranchByOnOrgId(Long userOrgId);

//	@Query("select bm from BranchMaster bm where bm.stateId=:stateId and bm.isActive=1  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnState(Integer stateId);
//
//	@Query("select bm from BranchMaster bm where bm.cityId=:cityId and bm.isActive=1  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnCity(Integer cityId);
//
//	@Query("select bm from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.stateId=:stateId and bm.cityId=:cityId and bm.isActive=1  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnCityOrStateOrOrgId(Long userOrgId, Integer stateId, Integer cityId);
//
//	@Query("select bm from BranchMaster bm where bm.stateId=:stateId and bm.cityId=:cityId and bm.isActive=1  AND bm.branchType=1 AND  ifscCode IS NOT NULL")
//	public List<BranchMaster> getBranchListBasedOnCityOrState(Integer stateId, Integer cityId);
//
//	@Query("select bm from BranchMaster bm where bm.code=:branchCode and bm.orgId.userOrgId=:orgId and bm.isActive=1")
//	public List<BranchMaster> getBranchByCodeAndOrg(@Param("branchCode") String branchCode, @Param("orgId") Long orgId);

	// ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query("select new com.opl.jns.user.management.api.model.BranchRequestProxy(bm.id,bm.code) from BranchMaster bm where bm.orgId.userOrgId=:orgId and bm.isActive=true")
	public List<BranchRequestProxy> getBranchIdAndCodeByOrgId(@Param("orgId") Long orgId);

	BranchMaster getOne(Long id);

	// ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query(value = "SELECT COUNT(b.id) FROM " + DBNameConstant.JNS_USERS + ".branch_master b WHERE b.org_id=:orgId AND b.is_active = 1 AND b.code =:code", nativeQuery = true)
	public int checkBranchExists(@Param("code") String code, @Param("orgId") Long orgId);
	
	@Query(value = "SELECT COUNT(b.id) FROM " + DBNameConstant.JNS_USERS + ".branch_master b WHERE b.org_id=:orgId AND b.is_active = 1 AND b.code =:code AND b.id !=:branchId", nativeQuery = true)
	public int checkBranchExistsForEditOffice(@Param("code") String code, @Param("orgId") Long orgId ,@Param("branchId") Long branchId);

	// ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	// ########### JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_IS_ACTIVE_BRANCH_ID
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
			+ ".branch_master bm ON bm.id=bpm.branch_id  WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bm.org_id=:orgId AND bm.is_active=1 AND bpm.branch_ro_id in (:branchIdLst)", nativeQuery = true)
	public List<Map<String, Object>> getBoName(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId, @Param("branchIdLst") List<Long> branchIdLst);
	
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
			+ ".branch_master bm ON bm.id=bpm.branch_id  WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bm.org_id=:orgId AND bm.is_active=1 AND bpm.branch_ro_id in (:branchIdLst) and bm.state_id IN(:stateIdLst)", nativeQuery = true)
	public List<Map<String, Object>> getBoNameByStateId(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId, @Param("branchIdLst") List<Long> branchIdLst,@Param("stateIdLst") List<Integer> stateIdLst);

//	@Query(value = "SELECT DISTINCT(bm.id) as id,bm.name as name FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
//			+ ".branch_master bm ON bm.id=bpm.branch_zo_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bpm.branch_zo_id = :zoId", nativeQuery = true)
//	public List<Map<String, Object>> getZoNameByZoId(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId, @Param("zoId") Long zoId);
//
//	@Query(value = "SELECT DISTINCT(bm.id) as id,bm.name as name FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
//			+ ".branch_master bm ON bm.id=bpm.branch_zo_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId", nativeQuery = true)
//	public List<Map<String, Object>> getZoName(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId);

	// ########### index JNS_USERS_BR_PROD_MP_USER_ORG_ID_SCH_TYPE_ID_BRANCH_ZO_ID
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
			+ ".branch_master bm ON bm.id=bpm.branch_ro_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bpm.branch_zo_id in (:zoIdLst)", nativeQuery = true)
	public List<Map<String, Object>> getRoName(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId, @Param("zoIdLst") List<Long> zoIdLst);
	
	@Query(value = "SELECT DISTINCT(bm.id) as \"id\",bm.name as \"name\" FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm INNER JOIN " + DBNameConstant.JNS_USERS
			+ ".branch_master bm ON bm.id=bpm.branch_ro_id AND  bm.is_active=1 WHERE bpm.user_org_id = :orgId AND bpm.sch_type_id = :schemeId AND bpm.branch_zo_id in (:zoIdLst) and bm.state_id IN(:stateIdLst)", nativeQuery = true)
	public List<Map<String, Object>> getRoNameByStateId(@Param("orgId") Long orgId, @Param("schemeId") Long schemeId, @Param("zoIdLst") List<Long> zoIdLst,@Param("stateIdLst") List<Integer> stateIdLst);

//	@Query("select bm.id from BranchMaster bm where bm.orgId.userOrgId=:userOrgId and bm.stateId=:stateId and bm.isActive=true")
//	public List<Long> getBranchId(Long userOrgId, Integer stateId);

	
	@Query(value = "SELECT DISTINCT(bm.code) AS branchCode FROM " + DBNameConstant.JNS_USERS + ".branch_master bm INNER JOIN " + DBNameConstant.JNS_USERS
			+ ".branch_product_mapping bpm ON bpm.branch_id=bm.id AND  bm.is_active=1 AND bm.id IN (SELECT DISTINCT(branch_id) FROM " + DBNameConstant.JNS_USERS +".branch_product_mapping WHERE branch_ro_id=:roId AND bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type =:branchType)", nativeQuery = true)
	public List<String> getRoOfficesfromRoId(@Param("branchType") Long branchType,@Param("roId") Long roId,@Param("orgId") Long orgId);
	
	@Query(value = "SELECT DISTINCT(bm.code) AS branchCode  FROM " + DBNameConstant.JNS_USERS + ".branch_master bm\n"
			+ "				LEFT JOIN " + DBNameConstant.JNS_USERS + ".branch_product_mapping bpm ON bpm.branch_id = bm.id  WHERE bm.org_id =:orgId AND bm.is_active = 1 AND bm.branch_type =:branchType \n"
			+ "				AND bm.id IN ( SELECT DISTINCT branch_id FROM " + DBNameConstant.JNS_USERS + ".branch_product_mapping WHERE branch_zo_id =:zoId)", nativeQuery = true)
	public List<String> getZoOfficesfromZoId(@Param("branchType") Long branchType,@Param("zoId") Long zoId,@Param("orgId") Long orgId);


	public List<BranchMaster> getAllByOrgIdUserOrgId(Long userOrgId);

	@Query("select name from BranchMaster bm where bm.id=:id and bm.isActive=true")
	public String getBranchNameByBranchId(@Param("id") Long orgId);


}