package com.opl.jns.user.management.service.controller.bulkUpload;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.user.management.api.model.BulkROZOResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.service.bulkUpload.BulkROZOCreationServiceV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;


/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class BulkROZOCreationControllerV3 {

    @Autowired
    private BulkROZOCreationServiceV3 bulkRozoCreationService;

    private static final Logger logger = LoggerFactory.getLogger(BulkROZOCreationControllerV3.class);

    /**
     * @param multipartFiles
     * @param request
     * @return
     * @author Dhaval
     */
    @PostMapping(value = "/import/rozo", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> proposalDetail(@RequestPart("orgId") String orgId,@RequestPart("schemeList") String schemeList, @RequestPart("businessTypeList") String businessTypeList, @RequestPart("file") MultipartFile multipartFiles, HttpServletRequest request,@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        Boolean isInOurFormat = null;
        try {
            List<Long> schemeTypelist = new ArrayList<Long>();
            if (!schemeList.isEmpty()) {
                String list = schemeList;
                String[] list2 = list.replaceAll("\\[|\\]| ", "").split(",");
                for (int i = 0; i < list2.length; i++) {
                    schemeTypelist.add(Long.parseLong(list2[i]));
                }
            }

            Long fileId = bulkRozoCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.TIER_EXCEL_LIST_FOR_COMMON);
            if(!OPLUtils.isObjectNullOrEmpty(fileId)) {
                Boolean extracted = bulkRozoCreationService.extractExcel(multipartFiles, fileId, schemeTypelist, authClientResponse);
                if(extracted)
                    return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(fileId, fileId, "Successfully Extracted!",HttpStatus.OK.value()), HttpStatus.OK);
                else
                    return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(fileId, "User is not valid",HttpStatus.UNAUTHORIZED.value()), HttpStatus.UNAUTHORIZED);

//                else if (userRoleId == UserRoleMaster.ZO.getId()) {
//                    bulkRozoCreationService.extractExcelForZo(multipartFiles, Long.valueOf(orgId), fileId, businessTypeId,schemeTypelist, userRoleId, userBranchId);
//                }
            }
        } catch (Exception e) {
            logger.error("Exception is getting while uploded RO zo tier mapping Sheet",e);
        }
        return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
    }

    @GetMapping(value = "/listImportedExcelTier/{orgId}/{businessTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> listBranchImportedExcel(@PathVariable Long orgId,@PathVariable Integer businessTypeId, HttpServletRequest request,
    		@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        //   Long orgId = Long.valueOf(String.valueOf(request.getAttribute(CommonUtils.USER_ORG_ID)));
        try {
            return new ResponseEntity<UserResponseProxy>(bulkRozoCreationService.listUploadedExcelFP(orgId,businessTypeId, authClientResponse.getUserBranchId(), authClientResponse.getUserRoleId()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/rozo/getFileEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getFileEntries(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            List<BulkROZOResponseProxy> bulkROZOResponseList = bulkRozoCreationService.getFileEntryList(fileResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkROZOResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }


    @PostMapping(value = "/getROZOFileEntryCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getROZOFileEntryCount(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
        	if(OPLUtils.isObjectNullOrEmpty(fileResponse.getId())) {
        		return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST.getReasonPhrase(), HttpStatus.BAD_REQUEST.value()), HttpStatus.BAD_REQUEST);	
        	}
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkRozoCreationService.getROZOFileEntryCount(fileResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

}
