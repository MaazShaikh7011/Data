package com.opl.jns.user.management.service.service.bulkUpload.impl;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.dms.api.exception.DocumentException;
import com.opl.jns.dms.api.model.DocumentRequest;
import com.opl.jns.dms.api.model.DocumentResponse;
import com.opl.jns.dms.api.model.StorageDetailsResponse;
import com.opl.jns.dms.api.utils.DocumentAlias;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.user.management.api.model.BulkROZOResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.user.management.service.domain.BulkROZOCreation;
import com.opl.jns.user.management.service.repository.BranchProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.BranchRepositoryV3;
import com.opl.jns.user.management.service.repository.bulkUpload.BulkROZOCreationRepositoryV3;
import com.opl.jns.user.management.service.service.bulkUpload.BulkROZOCreationServiceV3;
import com.opl.jns.utils.common.DateUtils;
import com.opl.jns.utils.common.DateUtils.DateFormat;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserRoleMaster;


/**
 * Created by pooja.patel on 21-07-2020.
 */
/**
 * @author sandip.bhetariya
 *
 */
@Service
@Transactional
public class BulkROZOCreationServiceImplV3 implements BulkROZOCreationServiceV3 {

    private static final Logger logger = LoggerFactory.getLogger(BulkROZOCreationServiceImplV3.class);
//    private static SimpleDateFormat FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    @Autowired
    private DMSClient dmsClient;

    @Autowired
    private BulkROZOCreationRepositoryV3 bulkROZOCreationRepository;

    @Autowired
    private BranchRepositoryV3 branchRepository;


    @Autowired
    private BranchProductMappingRepositoryV3 branchProductMappingRepository;


	public boolean isRowEmpty(Row row) {
		if (row != null) {
			for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
				Cell cell = row.getCell(c);
				if (cell != null && cell.getCellTypeEnum() != CellType.BLANK)
					return false;
			}
		}
		return true;
	}

    @Override
    public Boolean extractExcel(MultipartFile multipartFile, Long fileId, List<Long> schemeTypelist, AuthClientResponse authClientResponse) {
        List<BulkROZOCreation> bulkROZOCreationList = new ArrayList<>(500);
        try {
            if (UserRoleMaster.HEAD_OFFICE.getId() != authClientResponse.getUserRoleId()
                    && UserRoleMaster.ZO.getId() != authClientResponse.getUserRoleId()) {
                return false;
            }

            Workbook workbook = WorkbookFactory.create(multipartFile.getInputStream());
            Sheet worksheet = (Sheet) workbook.getSheetAt(0);
            logger.info("Last Number Of Row In Excel : {}", worksheet.getLastRowNum());
            String boCode = null, roCode = null, zoCode = null;
            String originalFileName = !OPLUtils.isObjectNullOrEmpty(multipartFile.getOriginalFilename()) ? multipartFile.getOriginalFilename() : "file";
            int blankRowCount = 0;
            List<Long> boIdList = null;
            List<Long> roIdList = null;
            if (UserRoleMaster.ZO.getId() == authClientResponse.getUserRoleId()) {
                boIdList = branchRepository.getBoRoIdListByZoId(authClientResponse.getUserBranchId(), UserRoleMaster.BRANCH_CHECKER.getId());
                roIdList = branchRepository.getBoRoIdListByZoId(authClientResponse.getUserBranchId(), UserRoleMaster.RO.getId());
            }
            List<String> branchCodeList = new ArrayList<>();
            mainLoop:
            for (int i = 3; i < 503; i++) {
                if (blankRowCount > 3) {
                    break mainLoop;
                }

                if (isRowEmpty(worksheet.getRow(i - 1))) {
                    blankRowCount++;
                    continue;
                }

                boCode = extractCellFromSheet(worksheet, "A" + i);
                roCode = extractCellFromSheet(worksheet, "B" + i);
                if (UserRoleMaster.HEAD_OFFICE.getId() == authClientResponse.getUserRoleId()) {
                    zoCode = extractCellFromSheet(worksheet, "C" + i);
                }

                boolean isActive = false;
                String msg = "", boId = null, roId = null, zoId = null;

                if (OPLUtils.isObjectNullOrEmpty(boCode)) {
                    msg = "BO Code can not be null";
                } else {
                    logger.info("Start Branch Code ->  {} !", boCode);
                    boCode = boCode.replaceAll("\\s", "");
                    if (branchCodeList.contains(boCode)) {
                        msg = "BO Code is already exist in given sheet";
                    } else {
                        branchCodeList.add(boCode);
                        boId = branchRepository.getBranchIdFromBranchCode(boCode, authClientResponse.getUserOrgId(), 1);
                        if (OPLUtils.isObjectNullOrEmpty(boId)) {
                            msg = "Branch Code Not Valid";
                        } else {
                            if (UserRoleMaster.ZO.getId() == authClientResponse.getUserRoleId() && !boIdList.contains(Long.valueOf(boId))) {
                                msg = "BO Code is not Under Login ZO";
                            }
                        }
                    }
                }

                if (OPLUtils.isObjectNullOrEmpty(roCode) && OPLUtils.isObjectNullOrEmpty(zoCode)) {
                    msg = "BO & RO Code can not be null";
                } else if (OPLUtils.isObjectNullOrEmpty(roCode) && UserRoleMaster.ZO.getId() == authClientResponse.getUserRoleId()) {
                    msg = "RO Code can not be null";
                } else {
                    if (!OPLUtils.isObjectNullOrEmpty(roCode)) {
                        roCode = roCode.replaceAll("\\s", "");
                        roId = branchRepository.getBranchIdFromBranchCode(roCode, authClientResponse.getUserOrgId(), 2);
                        if (OPLUtils.isObjectNullOrEmpty(roId)) {
                            msg = "RO Code Not Valid";
                        } else {
                            if (UserRoleMaster.ZO.getId() == authClientResponse.getUserRoleId() && !roIdList.contains(Long.valueOf(roId))) {
                                msg = "RO Code is not Under Login ZO";
                            }
                        }
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(zoCode)) {
                        zoCode = zoCode.replaceAll("\\s", "");
                        zoId = branchRepository.getBranchIdFromBranchCode(zoCode, authClientResponse.getUserOrgId(), 3);
                        if (OPLUtils.isObjectNullOrEmpty(zoId)) {
                            msg = "ZO Code Not Valid";
                        }
                    } else {
                        if (UserRoleMaster.ZO.getId() == authClientResponse.getUserRoleId()) {
                            zoId = authClientResponse.getUserBranchId().toString();
                        }
                    }
                }

                if (OPLUtils.isObjectNullOrEmpty(msg))
                    isActive = true;
                else
                    logger.info(msg);

                BulkROZOCreation bulkROZOCreation = null;
                for (Long schemeId : schemeTypelist) {
                    try {
                        bulkROZOCreation = saveBulkROZOCreation(boId, boCode, roId, roCode, zoId, zoCode, schemeId, fileId, originalFileName, authClientResponse);
                        bulkROZOCreation.setIsActive(isActive);
                        bulkROZOCreation.setMessage(OPLUtils.isObjectNullOrEmpty(msg) ? null : msg);
                    } catch (Exception e) {
                        logger.error("Error is getting while RO-ZO Mapping  --->   {}", e);
                    } finally {
                        bulkROZOCreationList.add(bulkROZOCreation);
                    }
                }
                if (isActive) {
                    saveBranchProductMapping(bulkROZOCreation, schemeTypelist);
                }
                logger.info("====================  End Read Row   =============>  {} !", (i - 2));
            }
            bulkROZOCreationRepository.saveAll(bulkROZOCreationList);

        } catch (Exception e) {
            logger.error(" Exception is getting while read multipart file -->   {}", e);
        }

        logger.info("SuccessFully File Uploaded,  Row ->  {}", (bulkROZOCreationList.size() / schemeTypelist.size()));
        return true;
    }

    private BulkROZOCreation saveBulkROZOCreation(String boId, String boCode, String roId, String roCode, String zoId,
                                                  String zoCode, Long schemeId, Long fileId,
                                                  String originalFileName, AuthClientResponse authClientResponse) {
        BulkROZOCreation bulkROZOCreation = new BulkROZOCreation();
        bulkROZOCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(roCode) ? null : boCode);
        bulkROZOCreation.setBranchId(OPLUtils.isObjectNullOrEmpty(boId) ? null : Long.valueOf(boId));
        bulkROZOCreation.setROCode(OPLUtils.isObjectNullOrEmpty(roCode) ? null : roCode);
        bulkROZOCreation.setBranchROId(OPLUtils.isObjectNullOrEmpty(roId) ? null : Long.valueOf(roId));
        bulkROZOCreation.setZOCode(OPLUtils.isObjectNullOrEmpty(zoCode) ? null : zoCode);
        bulkROZOCreation.setBranchZOId(OPLUtils.isObjectNullOrEmpty(zoId) ? null : Long.valueOf(zoId));
        bulkROZOCreation.setCreatedDate(new Date());
        bulkROZOCreation.setUserRoleId(authClientResponse.getUserRoleId());
        bulkROZOCreation.setOriginalFileName(OPLUtils.isObjectNullOrEmpty(originalFileName) ? null : originalFileName);
        bulkROZOCreation.setOrgId(authClientResponse.getUserOrgId());
        bulkROZOCreation.setBusinessTypeId(SchemeMaster.getById(schemeId).getBussinessTypeId());
        bulkROZOCreation.setSchemeId(schemeId);
        bulkROZOCreation.setFileId(fileId);
        bulkROZOCreation.setCreatedByBranchId(OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserBranchId()) ? null : authClientResponse.getUserBranchId().toString());
        return bulkROZOCreation;
    }

    private boolean saveBranchProductMapping(BulkROZOCreation bulkROZOCreation, List<Long> schemeTypelist) {
        if (bulkROZOCreation.getIsActive()) {
            branchProductMappingRepository.deleteByBranchIdAndSchemeId(bulkROZOCreation.getBranchId(), schemeTypelist);
        }

        List<BranchProductMapping> branchProductMappingList = new ArrayList<>(schemeTypelist.size());
        BranchProductMapping branchProductMapping = null;
        for (Long schemeId : schemeTypelist) {
            branchProductMapping = new BranchProductMapping();
            branchProductMapping.setBranchId(bulkROZOCreation.getBranchId());
            branchProductMapping.setBranchRoId(bulkROZOCreation.getBranchROId());
            branchProductMapping.setBranchZoId(bulkROZOCreation.getBranchZOId());
            branchProductMapping.setSchemeId(schemeId);
            branchProductMapping.setBusinessId(Long.valueOf(bulkROZOCreation.getBusinessTypeId()));
            branchProductMapping.setCreatedDate(new Date());
            branchProductMapping.setUserOrgId(bulkROZOCreation.getOrgId());
            branchProductMapping.setIsActive(true);
            branchProductMappingList.add(branchProductMapping);
        }
        branchProductMappingRepository.saveAll(branchProductMappingList);
        return true;
    }

//    public Boolean extractExcelForZo(MultipartFile multipartFile, Long orgId, Long fileId, Integer businessTypeId,List<Long> schemeTypelist,Long userRoleId, Long userBranchId) {
//        Workbook workbook = null;
//        try {
//            workbook = WorkbookFactory.create(multipartFile.getInputStream());
//        } catch (Exception e) {
////            e.printStackTrace();
//        }
//        Sheet worksheet = (Sheet) workbook.getSheetAt(0);
//        logger.info("Row Num : {}", worksheet.getLastRowNum());
//        String branchCode = null, roCode = null, zoCode = null, originalFileName = null;
////        String roEmail = null, roMobile = null, roName = null, roAddress = null,zoEmail = null, zoMobile = null, zoName = null, zoAddress = null,roPincode=null, zoPincode=null;
////        Integer roCityId ,roStateId, zoCityId ,zoStateId ;
//
//        originalFileName = multipartFile.getOriginalFilename();
//
//        zoCode = branchRepository.getBranchCodeFromBranchId(userBranchId, orgId);
//		int blankRowCount = 0;
//
//        mainLoop:for(Long schemeId : schemeTypelist) {
//            SchemeMaster scheme=SchemeMaster.getById(schemeId);
//            if(scheme.getBussinessTypeId().equals(businessTypeId)) {
//            for (int i = 3; i <= 503; i++) {
////            roCityId = null;
////            roStateId = null;
////            zoCityId = null;
////            zoStateId = null;
////        	if (blankRowCount > 5) {
////				break mainLoop;
////			}
////
////			if (isRowEmpty(worksheet.getRow(i - 1))) {
////				blankRowCount++;
////				continue;
////			}
//            branchCode = extractCellFromSheet(worksheet, "A" + i);
//            roCode = extractCellFromSheet(worksheet, "B" + i);
//
////            roEmail = extractCellFromSheet(worksheet, "C" + i);
////            roMobile = extractCellFromSheet(worksheet, "D" + i);
////            roName = extractCellFromSheet(worksheet, "E" + i);
////            roAddress = extractCellFromSheet(worksheet, "F" + i);
////            zoCode = extractCellFromSheet(worksheet, "J" + i);
////            zoEmail = extractCellFromSheet(worksheet, "K" + i);
////            zoMobile = extractCellFromSheet(worksheet, "L" + i);
////            zoName = extractCellFromSheet(worksheet, "M" + i);
////            zoAddress = extractCellFromSheet(worksheet, "N" + i);
////            roPincode = extractCellFromSheet(worksheet, "G" + i);
////            zoPincode = extractCellFromSheet(worksheet, "O" + i);
//
////                try {
////                roCityId = Integer.parseInt(extractCellFromSheet(worksheet, "H" + i));
////                roStateId = Integer.parseInt(extractCellFromSheet(worksheet, "I" + i));
////                zoCityId = Integer.parseInt(extractCellFromSheet(worksheet, "P" + i));
////                zoStateId = Integer.parseInt(extractCellFromSheet(worksheet, "Q" + i));
////            } catch (NumberFormatException e) {
////                e.printStackTrace();
////            }
//            //check if mandatory fields are null or not!!
//            if (OPLUtils.isObjectNullOrEmpty(branchCode) &&
//                    OPLUtils.isObjectNullOrEmpty(roCode)
////                    OPLUtils.isObjectNullOrEmpty(roEmail) &&
////                    OPLUtils.isObjectNullOrEmpty(roMobile) &&
////                    OPLUtils.isObjectNullOrEmpty(roName) &&
////                    OPLUtils.isObjectNullOrEmpty(roAddress) &&
////                    OPLUtils.isObjectNullOrEmpty(roPincode) &&
////                    OPLUtils.isObjectNullOrEmpty(roCityId) &&
////                    OPLUtils.isObjectNullOrEmpty(roStateId) &&
////                    OPLUtils.isObjectNullOrEmpty(zoEmail) &&
////                    OPLUtils.isObjectNullOrEmpty(zoMobile) &&
////                    OPLUtils.isObjectNullOrEmpty(zoName) &&
////                    OPLUtils.isObjectNullOrEmpty(zoAddress) &&
////                    OPLUtils.isObjectNullOrEmpty(zoPincode) &&
////                    OPLUtils.isObjectNullOrEmpty(zoCityId) &&
////                    OPLUtils.isObjectNullOrEmpty(zoStateId)
//             )
//            {
////                System.out.println("All null");
//            } else {
//
//                BulkROZOCreation bulkROZOCreation = new BulkROZOCreation();
//                bulkROZOCreation.setBranchCode(OPLUtils.isObjectNullOrEmpty(branchCode) ? null : branchCode);
//                bulkROZOCreation.setROCode(OPLUtils.isObjectNullOrEmpty(roCode) ? null : roCode);
////                bulkROZOCreation.setROEmail(OPLUtils.isObjectNullOrEmpty(roEmail) ? null : roEmail);
////                bulkROZOCreation.setROMobile(OPLUtils.isObjectNullOrEmpty(roMobile) ? null : roMobile);
////                bulkROZOCreation.setROName(OPLUtils.isObjectNullOrEmpty(roName) ? null : roName);
////                bulkROZOCreation.setROAddress(OPLUtils.isObjectNullOrEmpty(roAddress) ? null : roAddress);
////                bulkROZOCreation.setROPincode(OPLUtils.isObjectNullOrEmpty(roPincode) ? null : roPincode);
////                bulkROZOCreation.setROCityId(roCityId);
////                bulkROZOCreation.setROStateId(roStateId);
//                bulkROZOCreation.setZOCode(OPLUtils.isObjectNullOrEmpty(zoCode) ? null : zoCode);
////                bulkROZOCreation.setZOEmail(OPLUtils.isObjectNullOrEmpty(zoEmail) ? null : zoEmail);
////                bulkROZOCreation.setZOMobile(OPLUtils.isObjectNullOrEmpty(zoMobile) ? null : zoMobile);
////                bulkROZOCreation.setZOName(OPLUtils.isObjectNullOrEmpty(zoName) ? null : zoName);
////                bulkROZOCreation.setZOAddress(OPLUtils.isObjectNullOrEmpty(zoAddress) ? null : zoAddress);
////                bulkROZOCreation.setZOPincode(OPLUtils.isObjectNullOrEmpty(zoPincode) ? null : zoPincode);
////                bulkROZOCreation.setZOCityId(zoCityId);
////                bulkROZOCreation.setZOStateId(zoStateId);
//                bulkROZOCreation.setOrgId(orgId);
//                bulkROZOCreation.setCreatedDate(new Date());
//                bulkROZOCreation.setIsActive(true);
//                bulkROZOCreation.setUserRoleId(userRoleId);
//                bulkROZOCreation.setCreatedByBranchId(String.valueOf(userBranchId));
//                bulkROZOCreation.setOriginalFileName(originalFileName);
//
//                String branchMainId = branchRepository.getBranchIdFromBranchCode(branchCode, orgId, 1);
//                if(!OPLUtils.isObjectNullOrEmpty(branchMainId)) {
//                	bulkROZOCreation.setBranchId(Long.valueOf(branchMainId));
//                }
//                if(!OPLUtils.isObjectNullOrEmpty(roCode)) {
//                    String branchId = branchRepository.getBranchIdFromBranchCode(roCode, orgId, 2);
//                    if(!OPLUtils.isObjectNullOrEmpty(branchId)){
//                        bulkROZOCreation.setBranchROId(Long.valueOf(branchId));
//                        bulkROZOCreation.setIsActive(true);
//                    }
//                }
//                if(!OPLUtils.isObjectNullOrEmpty(userBranchId)) {
//                   bulkROZOCreation.setBranchZOId(userBranchId);
//                   bulkROZOCreation.setIsActive(true);
//                }
////                if(OPLUtils.isObjectNullOrEmpty(roCode) && OPLUtils.isObjectNullOrEmpty(zoCode)) {
////                    bulkROZOCreation.setIsActive(true);
////                }
//
//                bulkROZOCreation.setOrgId(orgId);
//                bulkROZOCreation.setBusinessTypeId(businessTypeId);
//                bulkROZOCreation.setSchemeId(schemeId);
//                bulkROZOCreation.setCreatedDate(new Date());
//                bulkROZOCreation.setFileId(fileId);
//                bulkROZOCreationRepository.save(bulkROZOCreation);
//                logger.info("Saved !{}", bulkROZOCreation);
//            }
//        }
//            }
//        }
//        return true;
//    }

    @Override
    public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile, Long productMappingId) {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("applicationId", orgId);
        jsonObj.put("productDocumentMappingId", productMappingId);
        jsonObj.put("userType", DocumentAlias.UERT_TYPE_APPLICANT);
        jsonObj.put("originalFileName", multipartFile.getOriginalFilename());
        try {
            DocumentResponse documentResponse = dmsClient.uploadFile(jsonObj.toString(), multipartFile);
            logger.info("response {}", documentResponse.getStatus());
            StorageDetailsResponse response = null;
            Map<String, Object> list = (Map<String, Object>) documentResponse.getData();
            if (!OPLUtils.isObjectListNull(list)) {
                try {
                    response = MultipleJSONObjectHelper.getObjectFromMap(list, StorageDetailsResponse.class);
                } catch (IOException e) {
                    logger.info("Could not upload file to DMS");
                }
            }

            if (response != null) {
                logger.debug("uploadExcel() :: response is not null");
                return response.getId();
            } else {
                logger.debug("uploadExcel() :: response is null");
                return null;
            }
        } catch (DocumentException e) {
            logger.info("Could not upload file to DMS");
            return null;
        }
    }

    public static String extractCellFromSheet(Sheet sheet, String rowNumber) {
        try {
            CellReference cellReference = new CellReference(rowNumber);
            Row row = sheet.getRow(cellReference.getRow());
            Cell cell = row.getCell(cellReference.getCol());
            if (cell != null) {
                if (cell.getCellType() == 0) {
                    cell.setCellType(Cell.CELL_TYPE_STRING);
                    return cell.toString();
                } else {
                    return cell.toString();
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Date extractNumericCellFromSheet(XSSFSheet sheet, String rowNumber) {
        try {
            CellReference cellReference = new CellReference(rowNumber);
            Row row = sheet.getRow(cellReference.getRow());
            Cell cell = row.getCell(cellReference.getCol());
            if (cell != null) {
                cell.setCellType(Cell.CELL_TYPE_NUMERIC);
                try {
                	 String s = DateUtils.setDateFormat(DateFormat.DD_MM_YYYY, cell.getDateCellValue());
                     return DateUtils.parse(DateFormat.DD_MM_YYYY, s);

//                	String s = FORMAT.format(cell.getDateCellValue());
//                    return FORMAT.parse(s);


                } catch (Exception e) {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId) {
        UserResponseProxy userResponse = new UserResponseProxy();
        DocumentRequest documentRequest = new DocumentRequest();
        documentRequest.setApplicationId(orgId);
        documentRequest.setUserType(DocumentAlias.UERT_TYPE_APPLICANT);

        documentRequest.setProductDocumentMappingId(UserCreationUtil.TIER_EXCEL_LIST_FOR_COMMON);


        try {
//            DocumentResponse documentResponse = dmsClient.listProductDocumentBankUser(documentRequest);
//            try {
            FileResponseProxy fileResponse = null;
            List<FileResponseProxy> fileResponseList = new ArrayList<>();
//                for (Object object : documentResponse.getDataList()) {
//                    StorageDetailsResponse storageDetailsResponse = MultipleJSONObjectHelper.getObjectFromMap((LinkedHashMap<String, Object>) object, StorageDetailsResponse.class);
            List<Object[]> entryList = null;

            if (userRoleId == UserRoleMaster.HEAD_OFFICE.getId()) {
                entryList = bulkROZOCreationRepository.getFileEntriesForHO(orgId);
            } else if (userRoleId == UserRoleMaster.ZO.getId()) {
                entryList = bulkROZOCreationRepository.getFileEntries(userBranchId);
            }
            for (Object[] obj : entryList) {
                fileResponse = new FileResponseProxy();
                fileResponse.setTotalEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[0])) ? Integer.parseInt(String.valueOf(obj[0])) : 0);
                fileResponse.setSuccessfulEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[1])) ? Integer.parseInt(String.valueOf(obj[1])) : 0);
                fileResponse.setFailedEntries(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[2])) ? Integer.parseInt(String.valueOf(obj[2])) : 0);
                fileResponse.setId(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[3])) ? Long.parseLong(String.valueOf(obj[3])) : 0);
                fileResponse.setCreatedDate((Date) (obj[4]));
                fileResponse.setOriginalFileName(!OPLUtils.isObjectNullOrEmpty(String.valueOf(obj[5])) ? String.valueOf(obj[5]) : "-");
                fileResponseList.add(fileResponse);
            }

//                    fileResponse.setId(storageDetailsResponse.getId());
//                    fileResponse.setOriginalFileName(storageDetailsResponse.getOriginalFileName());
//                    fileResponse.setCreatedDate(storageDetailsResponse.getCreatedDate());
//                    fileResponseList.add(fileResponse);
//                }

            userResponse.setData(fileResponseList);
            userResponse.setMessage(UserCreationUtil.SUCCESSFULLY_LISTED);
            userResponse.setStatus(HttpStatus.OK.value());
        }catch (Exception e){

                logger.error("Error while getting file", e);
                return null;
            }

            return userResponse;
//        } catch (DocumentException e) {
//            logger.error("Error while getting file details", e);
//            return null;
//        }
    }

    @Override
    public List<BulkROZOResponseProxy> getFileEntryList(FileResponseProxy fileResponse) {
        try {
            List<BulkROZOResponseProxy> bulkROZOResponseList = new ArrayList<>();
            List<BulkROZOCreation> bulkROZOCreationList = bulkROZOCreationRepository.findAllByFileId(fileResponse.getId());
            BulkROZOResponseProxy bulkROZOResponse = null;
            for (BulkROZOCreation bulkROZOCreation : bulkROZOCreationList){
                bulkROZOResponse = new BulkROZOResponseProxy();
                BeanUtils.copyProperties(bulkROZOCreation,bulkROZOResponse);
                bulkROZOResponseList.add(bulkROZOResponse);
            }
            return bulkROZOResponseList;

        } catch (Exception e) {
            logger.error("Exception :- ", e);
        }
        return null;
    }

    @Override
    public String getROZOFileEntryCount(FileResponseProxy fileResponse) {
        try {
            return bulkROZOCreationRepository.getROZOFileEntryCount(fileResponse.getId());
        } catch (Exception e) {
            logger.error("Exception :- ", e);
            return null;
        }
    }

}
