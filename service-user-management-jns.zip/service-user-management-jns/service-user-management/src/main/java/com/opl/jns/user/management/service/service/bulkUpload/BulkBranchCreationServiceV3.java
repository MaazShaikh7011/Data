package com.opl.jns.user.management.service.service.bulkUpload;

import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.user.management.api.model.BulkBranchResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;

import java.util.List;

/**
 * Created by dhaval.panchal on 15-Oct-19.
 */
public interface BulkBranchCreationServiceV3 {

    public Boolean extractExcel(MultipartFile multipartFile, Long orgId, Long fileId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId);
    
    public Boolean extractExcelRoZo(MultipartFile multipartFile, Long orgId, Long fileId,List<Long> schemeTypelist, Long userRoleId, Long userBranchId);

    public Long uploadExcelFileToDms(Long orgId, MultipartFile multipartFile);

    public UserResponseProxy listUploadedExcelFP(Long orgId, Integer businessTypeId, Long userBranchId, Long userRoleId);

    public List<BulkBranchResponseProxy> getFileEntryList(FileResponseProxy fileResponse);

    public String getBranchRoleEntries(UserListResponseProxy userListResponse);

    public String getBranchEntryCount(UserListResponseProxy userListResponse);

    public List<BulkBranchResponseProxy> getAllBranchEntryList(UserListResponseProxy userListResponse);

    public String getBranchFileEntryCount(FileResponseProxy fileResponse);

	public byte[] downloadBranchCreationExcelTemplate(Long schemeId, Long userRoleId);
}
