package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the user_role_master database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "user_role_master",indexes = {
		@Index(columnList = "is_active,is_banker", name = DBNameConstant.JNS_USERS+"_USR_ROLE_MST_IS_ACTIVE_IS_BANKER")
})
public class UserRoleMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_role_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_role_master_mana_seq_gen", sequenceName = "user_role_master_mana_seq", allocationSize = 1)
	@Column(name = "role_id")
	private Long roleId;


	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "role_name", columnDefinition = "varchar(255) default ''")
	private String roleName;

	@Column(name = "display_name", columnDefinition = "varchar(255) default ''")
	private String displayName;

	@Column(name = "is_admin_panel")
	private Boolean isAdminPanel;
	
	@Column(name = "is_banker")
	private Boolean isBanker;
	
	@Column(name = "branch_type")
	private Integer branchType;

	@Column(name = "display_office_name", columnDefinition = "varchar(255) default ''")
	private String displayOfficeName;
	
	@Column(name = "user_type_id")
	private Long userTypeId;

	@Column(name = "sequence")
	private Long sequence;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;
	
	@Column(name = "created_by")
	private Long createdBy;
	
	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
	
	@Column(name = "parent_role_id")
	private Long parentRoleId;

	public UserRoleMaster(Long roleId) {
		this.roleId = roleId;
	}
}