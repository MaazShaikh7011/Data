package com.opl.jns.user.management.service.controller;

import java.util.List;

import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.user.management.api.model.AdminMenuPermissionMappingProxy;
import com.opl.jns.user.management.api.model.AdminRequest;
import com.opl.jns.user.management.api.model.MenuMasterProxy;
import com.opl.jns.user.management.api.model.MenuRoleLoanMappingProxy;
import com.opl.jns.user.management.api.model.RoleMasterProxy;
import com.opl.jns.user.management.api.model.UserPermissionMappingProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.api.model.UsersProxy;
import com.opl.jns.user.management.service.service.UserManagementServiceV3;
import com.opl.jns.user.management.service.service.UsersServiceV3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/v3/user")
public class UserControllerV3 {

	@Autowired
	UsersServiceV3 usersService;
	
	@Autowired
	UserManagementServiceV3 managementService;
	@GetMapping(value = "/getUserRoleMasterList")
	public ResponseEntity<UserResponseProxy> getUserRoleMasterList() throws Exception {
		log.info("Enter in Controller getUserRoleMasterList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getUserRoleMasterList(), "Successful get getUserRoleMasterList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while get getUserRoleMasterList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/getAdminUserRoleMasterList")
	public ResponseEntity<UserResponseProxy> getAdminUserRoleMasterList() throws Exception {
		log.info("Enter in Controller getAdminUserRoleMasterList");
		try {
			return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(usersService.getAdminUserRoleMasterList(), "Successful get getAdminUserRoleMasterList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while get getAdminUserRoleMasterList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	  @PostMapping("/getBranchList")
		public ResponseEntity<CommonResponse> getBranchList(@RequestBody AdminRequest request) {
			try {
				String response = managementService.getBranchList(request);
				return new ResponseEntity<>(new CommonResponse("success", response, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
			} catch (Exception e) {
				log.error("Error while get getThirdPartyInfo() detail", e);
				return new ResponseEntity<>(new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

	@GetMapping(value = "/getPermissionMasterList")
	public ResponseEntity<UserResponseProxy> getPermissionMasterList() throws Exception {
		log.info("Enter in Controller getPermissionMasterList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getPermissionMasterList(), "Successful get getPermissionMasterList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while get getPermissionMasterList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getPermissionMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getPermissionMappingList(@RequestBody UserPermissionMappingProxy permissionRequest) throws Exception {
		log.info("Enter in Controller getPermissionMappingList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getPermissionMappingList(permissionRequest.getOrgId(), permissionRequest.getUserRoleId(), permissionRequest.getSchemeId()), "Successful get getPermissionMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while get getPermissionMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/setPermission", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> setPermission(@RequestBody UserPermissionMappingProxy permissionRequest) throws Exception {
		log.info("Enter in Controller setPermission");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.savePermission(permissionRequest.getOrgId(), permissionRequest.getUserRoleId(), permissionRequest.getSchemeId(), permissionRequest.getPermissionIds()), "Successful get getPermissionMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get setPermission detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/getMenuMaser")
	public ResponseEntity<UserResponseProxy> getMenuMaser() throws Exception {
		log.info("Enter in Controller getMenuMaser");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getMenuMaser(), "Successful get getMenuMaser data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while getMenuMaser detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getMenuMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getMenuMappingList(@RequestBody MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) throws Exception {
		log.info("Enter in Controller getMenuMappingList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getMenuMappingList(menuRoleLoanMappingProxy.getRoleId(), menuRoleLoanMappingProxy.getBusinessTypeId(), menuRoleLoanMappingProxy.getSchemeId()), "Successful get getMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while getMenuMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/saveMenuMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> saveMenuMappingList(@RequestBody MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) throws Exception {
		log.info("Enter in Controller saveMenuMappingList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.saveMenuMappingList(menuRoleLoanMappingProxy), "Successful saveMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while saveMenuMappingList detail", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/saveMenu", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> saveMenu(@RequestBody MenuMasterProxy menuMasterProxy) throws Exception {
		log.info("Enter in Controller saveMenu");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.saveMenu(menuMasterProxy), "Successful saveMenu data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get saveMenu detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/deleteMenu", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> deleteMenu(@RequestBody MenuMasterProxy menuMasterProxy) throws Exception {
		log.info("Enter in Controller deleteMenu");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.deleteMenu(menuMasterProxy.getId()), "Successfully Deleted Menu", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get deleteMenu detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getAdminMenuMaser", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getAdminMenuMaser(@RequestBody RoleMasterProxy roleMasterProxy) {
		log.info("Enter in Controller getAdminMenuMaser");
		try {
			if (OPLUtils.isObjectNullOrEmpty(roleMasterProxy) || OPLUtils.isObjectNullOrEmpty(roleMasterProxy.getRoleId())) {
				return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST, "Successful get getAdminMenuMaser data", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new UserResponseProxy(usersService.getAdminMenuMaser(roleMasterProxy.getRoleId()), "Successful get getAdminMenuMaser data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminMenuMaser detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getAdminMenuMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getAdminMenuMappingList(@RequestBody MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) throws Exception {
		log.info("Enter in Controller getAdminMenuMappingList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getAdminMenuMappingList(menuRoleLoanMappingProxy.getRoleId()), "Successful get getAdminMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminMenuMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/saveAdminPermission", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> saveAdminPermission(@RequestBody MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) throws Exception {
		log.info("Enter in Controller saveAdminPermission");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.saveAdminPermission(menuRoleLoanMappingProxy), "Successful get saveAdminPermission data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get saveAdminPermission detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getAdminPermissionMasterList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getAdminBasicMappingList(@RequestBody MenuRoleLoanMappingProxy menuRoleLoanMappingProxy) throws Exception {
		log.info("Enter in Controller getAdminPermissionMasterList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getAdminPermissionMasterList(menuRoleLoanMappingProxy.getRoleId()), "Successful get getAdminMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminBasicMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/getAdminMenuPermissionMappingList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> getAdminMenuPermissionMappingList(@RequestBody AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy) throws Exception {
		log.info("Enter in Controller getAdminMenuPermissionMappingList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getAdminMenuPermissionMappingList(adminMenuPermissionMappingProxy.getRoleId()), "Successful get getAdminMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminMenuPermissionMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/saveAdminMenuPermission", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> saveAdminMenuPermission(@RequestBody AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy) throws Exception {
		log.info("Enter in Controller saveAdminMenuPermission");
		try {
			if (OPLUtils.isObjectNullOrEmpty(adminMenuPermissionMappingProxy) || OPLUtils.isObjectNullOrEmpty(adminMenuPermissionMappingProxy.getRoleId())) {
				return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST, "Successful get getAdminMenuMappingList data", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new UserResponseProxy(usersService.saveAdminMenuPermission(adminMenuPermissionMappingProxy), "Successful get getAdminMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminMenuPermissionMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
//
//	@PostMapping(value = "/saveAdminBasicPermission", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<UserResponseProxy> saveAdminBasicPermission(@RequestBody AdminMenuPermissionMappingProxy adminMenuPermissionMappingProxy) throws Exception {
//		log.info("Enter in Controller saveAdminBasicPermission");
//		try {
//			if (OPLUtils.isObjectNullOrEmpty(adminMenuPermissionMappingProxy) || OPLUtils.isObjectNullOrEmpty(adminMenuPermissionMappingProxy.getRoleId())) {
//				return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST, "Successful get saveAdminBasicPermission data", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
//			}
//			return new ResponseEntity<>(new UserResponseProxy(usersService.saveAdminBasicPermission(adminMenuPermissionMappingProxy), "Successful get getAdminMenuMappingList data", HttpStatus.OK.value()), HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error while get getAdminMenuPermissionMappingList detail ", e);
//			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}

	@PostMapping(value = "/changeOrgIdAndBranchIdAndRoleId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> changeOrgIdAndBranchIdAndRoleId(@RequestBody UsersProxy usersProxy) throws Exception {
		log.info("Enter in Controller saveAdminBasicPermission");
		try {
			if (OPLUtils.isObjectNullOrEmpty(usersProxy) || OPLUtils.isObjectNullOrEmpty(usersProxy.getUserId()) || OPLUtils.isObjectNullOrEmpty(usersProxy.getOrgId())) {
				return new ResponseEntity<>(new UserResponseProxy(HttpStatus.BAD_REQUEST, "Successful get saveAdminBasicPermission data", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new UserResponseProxy(usersService.changeOrgIdAndBranchIdAndRoleId(usersProxy), "Successful Update Org and Branch", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get getAdminMenuPermissionMappingList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "/changeAdminUserRole", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserResponseProxy> changeAdminUserRole(@RequestBody UsersProxy usersProxy) throws Exception {
		log.info("Enter in Controller changeAdminUserRole");
		try {
			if (OPLUtils.isObjectNullOrEmpty(usersProxy) || OPLUtils.isObjectNullOrEmpty(usersProxy.getUserId()) || OPLUtils.isObjectNullOrEmpty(usersProxy.getUserRoleId())) {
				return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(HttpStatus.BAD_REQUEST, "userId or roleId Missing", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
			}
			return new ResponseEntity<>(new UserResponseProxy(usersService.changeAdminUserRole(usersProxy), "Successfullly Changed Role", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error while get changeAdminUserRole detail ", e);
			return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/getPartnerRoleMasterList")
	public ResponseEntity<UserResponseProxy> getPartnerRoleMasterList() throws Exception {
		log.info("Enter in Controller getPartnerRoleMasterList");
		try {
			return new ResponseEntity<>(new UserResponseProxy(usersService.getPartnerRoleMasterList(), "Successful get getPartnerRoleMasterList data", HttpStatus.OK.value()), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Error is getting while get getPartnerRoleMasterList detail ", e);
			return new ResponseEntity<>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
