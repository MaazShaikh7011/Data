package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bulk_user_creation",indexes = {
		@Index(columnList = "file_id,is_active",name = DBNameConstant.JNS_USERS + "BULK_USR_CRE_FILE_ID_IS_ACTIVE"),
		@Index(columnList = "org_id,business_type_id,is_active",name = DBNameConstant.JNS_USERS + "BULK_USR_CRE_ORG_ID_BUSINESS_TYPE_ID_IS_ACTIVE"),
})
public class BulkUserCreation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_user_creation_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "bulk_user_creation_mana_seq_gen", sequenceName = "bulk_user_creation_mana_seq", allocationSize = 1)
	private Long id;

	@Convert(converter = AESOracle.class)
	@Column(name = "email", columnDefinition = "varchar(50) default ''")
	private String email;

	@Convert(converter = AESOracle.class)
	@Column(name = "mobile", columnDefinition = "varchar(20) default ''")
	private String mobile;

	@Convert(converter = AESOracle.class)
	@Column(name = "first_name", columnDefinition = "varchar(200) default ''")
	private String firstName;

	@Convert(converter = AESOracle.class)
	@Column(name = "middle_name", columnDefinition = "varchar(200) default ''")
	private String middleName;

	@Convert(converter = AESOracle.class)
	@Column(name = "last_name", columnDefinition = "varchar(200) default ''")
	private String lastName;

	@Column(name = "role", columnDefinition = "varchar(20) default ''")
	private String role;

	@Column(name = "branch_id", columnDefinition = "varchar(20) default ''")
	private String branchId;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "business_type_id")
	private Integer businessTypeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "msg", columnDefinition = "varchar(600) default ''")
	private String message;
	
	@Column(name = "file_id")
	private Long fileId;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Column(name = "branch_code", columnDefinition = "varchar(50) default ''")
	private String branchCode;

	@Column(name = "user_role_id")
	private Long userRoleId;

	@Column(name = "created_by_branch_id", columnDefinition = "varchar(60) default ''")
	private String createdByBranchId;

	@Column(name = "original_file_name", columnDefinition = "varchar(100) default ''")
	private String originalFileName;

}
