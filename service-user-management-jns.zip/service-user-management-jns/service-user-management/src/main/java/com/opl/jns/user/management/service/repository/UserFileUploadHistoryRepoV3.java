package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.UserFileUploadHistory;

public interface UserFileUploadHistoryRepoV3  extends JpaRepository<UserFileUploadHistory, Long> {
	
	@Query("SELECT FH FROM UserFileUploadHistory FH WHERE FH.orgId=:orgId AND FH.fileType=:type")
	List<UserFileUploadHistory> getFileHistoryByOrgId(@Param("orgId")Long orgId,@Param("type") Long type);
	
	@Query("SELECT FH FROM UserFileUploadHistory FH WHERE FH.orgId=:orgId AND FH.fileType=:type AND FH.createdBy=:userId")
	List<UserFileUploadHistory> getFileHistoryByOrgIdUserId(@Param("orgId")Long orgId,@Param("userId")Long userId);
	
	
}
