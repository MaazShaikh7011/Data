package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.user.management.service.domain.BusinessMaster;

public interface BusinessMasterRepositoryV3 extends JpaRepository<BusinessMaster, Long> {

}
