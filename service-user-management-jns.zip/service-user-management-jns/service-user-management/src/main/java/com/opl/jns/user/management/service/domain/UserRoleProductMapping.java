package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_role_product_mapping",indexes = {
		@Index(columnList = "user_id,is_active,business_id",name = DBNameConstant.JNS_USERS+"_USER_ID_IS_ACTIVE_BUSINESS_ID"),
		@Index(columnList = "user_id,scheme_id,is_active",name = DBNameConstant.JNS_USERS+"_USER_ID_SCHEME_ID_IS_ACTIVE")
})
public class UserRoleProductMapping implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_role_product_mapping_man_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_role_product_mapping_man_seq_gen", sequenceName = "user_role_product_mapping_man_seq", allocationSize = 1)
	private Long id;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_role_id")
	private UserRoleMaster userRoleMaster;

	@Column(name = "business_id")
	private Long businessId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "scheme_id")
	private Long schemeId;

}
