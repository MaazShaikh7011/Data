package com.opl.jns.user.management.service.repository.bulkUpload;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.BulkROZOCreation;

/**
 * Created by pooja.patel on 22-07-2020.
 */
public interface BulkROZOCreationRepositoryV3 extends JpaRepository<BulkROZOCreation, Long> {

    @Query(value = """
		    select t.totalcount, t.successcount, t.failcount, t.fileid , brc.created_date,brc.original_file_name   from (
		    select COUNT(*) as totalcount,
		    SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) as successcount,
		    SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) as failcount,
		    max(file_id) as fileid, max(id) as id 
		    FROM jns_users.bulk_rozo_creation WHERE created_by_branch_id=:branchId GROUP BY file_id
		    ) t inner join jns_users.bulk_rozo_creation brc on brc.id = t.id ORDER BY brc.created_date ASC\
		    """,nativeQuery = true)
    List<Object[]> getFileEntries(@Param("branchId") Long branchId);

    
    @Query(value = """
		    select t.totalcount, t.successcount, t.failcount, t.fileid , brc.created_date,brc.original_file_name   from (
		    select COUNT(*) as totalcount,
		    SUM((CASE WHEN (is_active = 1)THEN 1 ELSE 0 END)) as successcount,
		    SUM((CASE WHEN (is_active = 0)THEN 1 ELSE 0 END)) as failcount,
		    max(file_id) as fileid, max(id) as id 
		    FROM jns_users.bulk_rozo_creation WHERE org_id = :orgId AND created_by_branch_id IS NULL GROUP BY file_id
		    ) t inner join jns_users.bulk_rozo_creation brc on brc.id = t.id ORDER BY brc.created_date ASC\
		    """,nativeQuery = true)
    List<Object[]> getFileEntriesForHO(@Param("orgId") Long orgId);
    
    public List<BulkROZOCreation> findAllByFileId(@Param("fileId") Long fileId);

    @Query(value = """
		    SELECT JSON_OBJECT(
		    'successfulCount' VALUE t.successfulCount,
		    'failedCount' VALUE t.failedCount,
		    'totalCount' VALUE t.totalCount)
		    FROM
		    (SELECT 
		    SUM(CASE WHEN (is_active = 1) THEN 1 ELSE 0 END) AS successfulCount,
		    SUM(CASE WHEN (is_active = 0) THEN 1 ELSE 0 END) AS failedCount,
		    COUNT(*) AS totalCount
		    FROM jns_users.bulk_rozo_creation
		    WHERE file_id =:fileId) t\
		    """,nativeQuery = true)
    public String getROZOFileEntryCount(@Param("fileId") Long fileId);

}
