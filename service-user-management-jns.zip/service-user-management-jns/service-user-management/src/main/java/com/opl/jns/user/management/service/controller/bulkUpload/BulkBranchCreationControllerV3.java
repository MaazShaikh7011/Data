package com.opl.jns.user.management.service.controller.bulkUpload;

import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.user.management.api.model.BulkBranchResponseProxy;
import com.opl.jns.user.management.api.model.FileResponseProxy;
import com.opl.jns.user.management.api.model.UserListResponseProxy;
import com.opl.jns.user.management.api.model.UserResponseProxy;
import com.opl.jns.user.management.service.service.bulkUpload.BulkBranchCreationServiceV3;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.UserCreationUtil;
import com.opl.jns.utils.enums.UserRoleMaster;

/**
 * Created by dhaval.panchal on 15-Oct-19.
 */
/**
 * @author sandip.bhetariya
 *
 */
@RestController
@RequestMapping("/v3")
public class BulkBranchCreationControllerV3 {
    @Autowired
    private BulkBranchCreationServiceV3 branchCreationService;

    private static final Logger logger = LoggerFactory.getLogger(BulkBranchCreationControllerV3.class);

    /**
     * @param multipartFiles
     * @param request
     * @return
     * @author Dhaval
     */
    @PostMapping(value = "/import/bo", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> proposalDetail(@RequestPart("schemeList") String schemeList, 
    		@RequestPart("businessTypeList") String businessTypeList, @RequestPart("file") MultipartFile multipartFiles, 
    		HttpServletRequest request, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        Boolean isInOurFormat = null;
        try {
        	//return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("The creation of new branches is currently suspended. For any updates, please contact the JanSuraksha Support.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        	if(OPLUtils.isObjectNullOrEmpty(authClientResponse) || OPLUtils.isObjectNullOrEmpty(authClientResponse.getUserOrgId())) {
        		logger.info("Organization is not Found");
                 return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("please try after some times.", HttpStatus.BAD_REQUEST.value()), HttpStatus.OK);
        	}
            Long fileId = null;
            Long userOrgId = authClientResponse.getUserOrgId();
            logger.info("orgId====>{}",userOrgId);

            List<Long> schemeTypelist = new ArrayList<Long>();
            if (!schemeList.isEmpty()) {
                String list = schemeList;
                String[] list2 = list.replaceAll("\\[|\\]| ", "").split(",");
                for (int i = 0; i < list2.length; i++) {
                	schemeTypelist.add(Long.parseLong(list2[i]));
                }
            }
            
            if (!businessTypeList.isEmpty()) {
                String list = businessTypeList;
                String[] list2 = list.replaceAll("\\[|\\]| ", "").split(",");
                List<Integer> businesslist = new ArrayList<Integer>();
                for (int i = 0; i < list2.length; i++) {
                    businesslist.add(Integer.parseInt(list2[i]));
                }
                for (Integer businessTypeId : businesslist) {
//                    if (businessTypeId == UserCreationUtil.MSME) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_MSME);
//                    } else if (businessTypeId == UserCreationUtil.PERSONAL_LOAN) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_PL);
//                    } else if (businessTypeId == UserCreationUtil.HOME_LOAN) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_HL);
//                    } else if (businessTypeId == UserCreationUtil.AUTO_LOAN) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_AL);
//                    } else if (businessTypeId == UserCreationUtil.MUDRA_LOAN) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_ML);
//                    } else if (businessTypeId == UserCreationUtil.EDUCATION_LOAN) {
//                        fileId = branchCreationService.uploadExcelFileToDms(Long.valueOf(orgId), multipartFiles, UserCreationUtil.BRANCH_EXCEL_LIST_FOR_EL);
//                    }


                }
            }
            fileId = branchCreationService.uploadExcelFileToDms(userOrgId, multipartFiles);
            Long userRoleId = authClientResponse.getUserRoleId();
            Long userBranchId = authClientResponse.getUserBranchId();
            Boolean branch = false;
            if(OPLUtils.isObjectNullOrEmpty(fileId)){
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("File is not uploaded, please try after some times.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
            if (userRoleId == UserRoleMaster.RO.getId() || userRoleId == UserRoleMaster.ZO.getId()) {
            	branch = branchCreationService.extractExcelRoZo(multipartFiles, userOrgId, fileId, schemeTypelist, userRoleId, userBranchId);
            } else if (userRoleId == UserRoleMaster.HEAD_OFFICE.getId()) {
            	branch = branchCreationService.extractExcel(multipartFiles, userOrgId, fileId, schemeTypelist, userRoleId, userBranchId);
            }
            if(branch == false){
                return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("You have uploaded wrong file.", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
            }
            UserResponseProxy userResponse = new UserResponseProxy();
            userResponse.setMessage("Successfully Extracted!");
            userResponse.setData(fileId);
            userResponse.setListData(null);
            userResponse.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<UserResponseProxy>(userResponse, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Exception while Branch Bulk Upload ", e);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/listImportedExcelBranch/{orgId}/{businessTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> listBranchImportedExcel(@PathVariable Long orgId,@PathVariable Integer businessTypeId, HttpServletRequest request,
    		@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        //   Long orgId = Long.valueOf(String.valueOf(request.getAttribute(CommonUtils.USER_ORG_ID)));
        try {
            return new ResponseEntity<UserResponseProxy>(branchCreationService.listUploadedExcelFP(orgId,businessTypeId,authClientResponse.getUserBranchId(),authClientResponse.getUserRoleId()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/branch/getFileEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getFileEntries(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            List<BulkBranchResponseProxy> bulkBranchResponseList = branchCreationService.getFileEntryList(fileResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkBranchResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getBranchRoleEntries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchRoleEntries(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(branchCreationService.getBranchRoleEntries(userListResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getBranchEntryCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchEntryCount(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(branchCreationService.getBranchEntryCount(userListResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getAllBranchEntryList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getAllBranchEntryList(@RequestBody UserListResponseProxy userListResponse, HttpServletRequest request) {
        try {
            List<BulkBranchResponseProxy> bulkBranchResponseList = branchCreationService.getAllBranchEntryList(userListResponse);
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(bulkBranchResponseList,"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getBranchFileEntryCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserResponseProxy> getBranchFileEntryCount(@RequestBody FileResponseProxy fileResponse, HttpServletRequest request) {
        try {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(branchCreationService.getBranchFileEntryCount(fileResponse),"Successfully got file entries!!", HttpStatus.OK.value()), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<UserResponseProxy>(new UserResponseProxy(UserCreationUtil.COULD_NOT_LIST, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.OK);
        }
    }
    
    @GetMapping(value = "/downloadBranchCreationExcelTemplate/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public byte[] downloadBranchCreationExcelTemplate(@PathVariable Long schemeId, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {        	
        	byte[] data = branchCreationService.downloadBranchCreationExcelTemplate(schemeId, authClientResponse.getUserRoleId());
            return data;
        } catch (Exception e) {
        	return null;
        }
    }
}

