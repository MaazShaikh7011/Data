package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.user.management.service.domain.UserTypeMaster;

public interface UserTypeMasterRepositoryV3  extends JpaRepository<UserTypeMaster, Long> {
//
//	public List<UserTypeMaster> findByIsActive(Boolean isActive);
//
	public List<UserTypeMaster> findByIsDisplayOnLogin(Boolean isDisplayOnLogin);
//
//	public List<UserTypeMaster> findByIsActiveAndIsDisplayOnLogin(Boolean isActive, Boolean isDisplayOnLogin);

}
