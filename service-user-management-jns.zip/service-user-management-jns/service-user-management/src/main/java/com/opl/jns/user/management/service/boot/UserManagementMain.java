package com.opl.jns.user.management.service.boot;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.dms.client.DMSClient;
import com.opl.jns.oneform.client.OneFormClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = { "com.opl" })
@EnableAsync
@EnableScheduling
@EnableConfigurationProperties(ApplicationProperties.class)
public class UserManagementMain implements AsyncConfigurer {

	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) {
		SpringApplication.run(UserManagementMain.class, args);
//		System.err.println(DataSourceProvider.getEnvMode());
//		System.err.println(URLConfig.fetchURL(URLMaster.AUTH));
//		System.err.println(DataSourceProvider.getDbUrlOracle());
	}

	@Bean
	public AuthClient authClient() {
		AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
//		AuthClient authClient = new AuthClient("http://localhost:8052/auth");
		applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
		return authClient;
	}

	@Bean
	public DMSClient dmsClient() {
		DMSClient dmsClient = new DMSClient(URLConfig.fetchURL(URLMaster.DMS));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(dmsClient);
		return dmsClient;
	}

//	@Bean
//	public AnsLogsClient clientLogs() {
//		AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
//		applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//		return ansLogsClient;
//	}

	@Bean
	public OneFormClient OneFormClient() {
		OneFormClient oneFormClient = new OneFormClient(URLConfig.fetchURL(URLMaster.ONE_FORM));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(oneFormClient);
		return oneFormClient;
	}

	@Override
	public Executor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setThreadNamePrefix("Async-um-");
		executor.setCorePoolSize(5);
		executor.setMaxPoolSize(10);
		executor.setQueueCapacity(1000);
		executor.initialize();
		return executor;
	}

}
