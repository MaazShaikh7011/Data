package com.opl.jns.user.management.service.domain;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author sandip.bhetariya
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "scheme_master")
public class SchemeMaster  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "scheme_master_mana_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "scheme_master_mana_seq_gen", sequenceName = "scheme_master_mana_seq", allocationSize = 1)
    private Long id;

    @Column(name = "business_id")
    private Integer businessId;
    
    @Column(name = "order_id")
    private Integer orderId;
    
    @Column(name = "loan_id")
    private Integer loanId;

    @Lob
    @Column(name = "name")
    private String name;

    @Column(name = "short_name",columnDefinition="varchar(100) default ''")
    private String shortName;

    @Column(name = "img_path",columnDefinition="varchar(200) default ''")
    private String imgPath;

    @Column(name = "path",columnDefinition="varchar(200) default ''")
    private String path;
    
    @Column(name = "is_active")
	private Boolean isActive;
    
    


}
