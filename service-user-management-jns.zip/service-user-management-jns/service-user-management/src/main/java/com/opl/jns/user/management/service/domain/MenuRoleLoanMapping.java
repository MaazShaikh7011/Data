package com.opl.jns.user.management.service.domain;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "menu_role_loan_mapping",indexes = {
        @Index(columnList = "role_id,is_active,business_type_id,scheme_id",name = DBNameConstant.JNS_USERS+"MNU_ROLE_MPG_ROLE_ID_IS_ACTIVE_BS_ID_SCHEME_ID")
})
public class MenuRoleLoanMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "menu_role_loan_mapping_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "menu_role_loan_mapping_mana_seq_gen", sequenceName = "menu_role_loan_mapping_mana_seq", allocationSize = 1)
    private Long id;

    @Column(name = "navigation_path", columnDefinition = "varchar(500) default ''")
    private String navigationPath;

    @Column(name = "menu_id")
    private Long menuId;

    @Column(name = "role_id")
    private Long roleId;

    @Column(name = "business_type_id")
    private Long businessTypeId;

    @Column(name = "sequence")
    private Integer sequence;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "scheme_id")
    private Integer schemeId;

}
