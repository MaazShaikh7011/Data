package com.opl.jns.user.management.service.repository.bulkUpload;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.BulkUlbCreation;

public interface BulkUlbCreationRepoV3 extends JpaRepository<BulkUlbCreation, Long> {

    @Query(value="SELECT * FROM users.bulk_ulb_creation u WHERE u.is_active = TRUE AND u.file_id =:fileId GROUP BY u.mobile",nativeQuery=true)
    public List<BulkUlbCreation> findIsActive(@Param("fileId") Long fileId);

    @Query(value = """
            SELECT\s
            COUNT(*),
            SUM((CASE WHEN (is_active = TRUE)THEN 1 ELSE 0 END)),
            SUM((CASE WHEN (is_active = FALSE)THEN 1 ELSE 0 END))
            FROM users.`bulk_ulb_creation` WHERE file_id =:fileId\
            """,nativeQuery = true)
    List<Object[]> getFileEntries(@Param("fileId") Long fileId);

    public List<BulkUlbCreation> findAllByFileId(@Param("fileId") Long fileId);

	public List<BulkUlbCreation> findAllByFileIdAndIsActive(Long fileId, Boolean isActive);
}
