package com.opl.jns.user.management.service.domain;

import java.io.Serializable;

import jakarta.persistence.*;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_upload_audit",indexes = {
		@Index(columnList = "file_upload_id,status",name = DBNameConstant.JNS_USERS+"_FILE_UPLOAD_ID_STATUS")
})
public class UserUploadAudit implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_upload_audit_man_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_upload_audit_man_seq_gen", sequenceName = "user_upload_audit_man_seq", allocationSize = 1)
	private Long id;

	@Column(name = "file_upload_id")
	private Long fileUploadId;

	@Column(name = "email", columnDefinition = "varchar(200) default ''")
	private String email;

	@Column(name = "mobile", columnDefinition = "varchar(20) default ''")
	private String mobile;

	@Column(name = "remarks", columnDefinition = "varchar(500) default ''")
	private String remarks;

	@Column(name = "status")
	private Integer status;

	@Column(name = "is_active")
	private Boolean isActive;
}
