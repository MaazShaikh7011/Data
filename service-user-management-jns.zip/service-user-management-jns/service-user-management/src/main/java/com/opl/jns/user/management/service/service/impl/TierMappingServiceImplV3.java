package com.opl.jns.user.management.service.service.impl;




import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.opl.jns.user.management.api.model.BranchRequestProxy;
import com.opl.jns.user.management.api.model.RoleMasterProxy;
import com.opl.jns.user.management.api.model.TierMappingRequestProxy;
import com.opl.jns.user.management.service.domain.BranchProductMapping;
import com.opl.jns.user.management.service.domain.UserRoleMaster;
import com.opl.jns.user.management.service.repository.BranchProductMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.TierMappingRepositoryV3;
import com.opl.jns.user.management.service.repository.UserManagementRepositoryV3;
import com.opl.jns.user.management.service.repository.UserRoleMasterRepositoryV3;
import com.opl.jns.user.management.service.repository.UsersRepositoryV3;
import com.opl.jns.user.management.service.service.TierMappingServiceV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.common.ObjectConvertMaster;

@Service
@Transactional
public class TierMappingServiceImplV3 implements TierMappingServiceV3 {

	private static final Logger logger = LoggerFactory.getLogger(TierMappingServiceImplV3.class); 
	
    @Autowired
    private TierMappingRepositoryV3 tierMappingRepository;

    @Autowired
    BranchProductMappingRepositoryV3 branchProductMappingRepository;
    
    @Autowired
    UserManagementRepositoryV3 managementRepository;

    @Autowired
    UsersRepositoryV3 userRepo;

    @Autowired
    UserRoleMasterRepositoryV3 roleMasterRepo;

    @Override
    public String getTierMappingList(TierMappingRequestProxy tierMappingRequest) {
    	try {
    		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
	    	String json = ow.writeValueAsString(tierMappingRequest.getColumnFilter());
//	    	List<Map<String, Object>> resList= userRepo.getTierMappingList(tierMappingRequest.getUserId(),tierMappingRequest.getOrgId(),tierMappingRequest.getBusinessTypeId(),tierMappingRequest.getType(),tierMappingRequest.getNoPagination(),tierMappingRequest.getPaginationFROM(),tierMappingRequest.getPaginationTO(),tierMappingRequest.getSchemeId(),json);
//	    	String s1 = MultipleJSONObjectHelper.getStringfromListOfObject(resList);
	    	logger.info("managementRepository.spUserManagementFetchTierDetailRoZo("+tierMappingRequest.getUserId()+","+tierMappingRequest.getOrgId()+","+tierMappingRequest.getBusinessTypeId()+","+tierMappingRequest.getType()+","+tierMappingRequest.getNoPagination()+","+Integer.valueOf(tierMappingRequest.getPaginationFROM())+","+Integer.valueOf(tierMappingRequest.getPaginationTO())+","+tierMappingRequest.getSchemeId()+","+json+")");
	    	String s1 = managementRepository.spUserManagementFetchTierDetailRoZo(tierMappingRequest.getUserId(),tierMappingRequest.getOrgId(),tierMappingRequest.getBusinessTypeId(),tierMappingRequest.getType(),tierMappingRequest.getNoPagination(),Integer.valueOf(tierMappingRequest.getPaginationFROM()),Integer.valueOf(tierMappingRequest.getPaginationTO()),tierMappingRequest.getSchemeId(),json);
	        
	    	return s1;
		} catch (Exception e) {
	        logger.error("Exception :- ", e);
	    }
		return null;
    }

    @Override
    public String getBranchCount(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getBranchCount(tierMappingRequest);
    }

    @Override
    public String getSingleTierMapping(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getSingleTierMapping(tierMappingRequest);
    }

    @Override
    public Boolean updateBranchDetails(BranchRequestProxy branchRequest) {

        Long branchId = branchRequest.getBranchId();
        Long userOrgId = Long.valueOf(branchRequest.getOrgId());

        List<Long> schemeList = branchProductMappingRepository.getSchemeIds(branchId);

        tierMappingRepository.inactiveBranch(branchId,schemeList,userOrgId);

        if(!OPLUtils.isListNullOrEmpty(branchRequest.getBranchProductList())){
            for(Map<String,Object> map: branchRequest.getBranchProductList()){
                BranchProductMapping branchProductMapping = new BranchProductMapping();
                Long schemeId = ObjectConvertMaster.toLong(map.get("schemeId"));
                
                branchProductMapping.setBranchId(ObjectConvertMaster.toLong(map.get("branchId")));
                branchProductMapping.setBusinessId(ObjectConvertMaster.toLong(map.get("businessTypeId")));
                branchProductMapping.setUserOrgId(ObjectConvertMaster.toLong(map.get("orgId")));
                
                Long branchRoId = ObjectConvertMaster.toLong(map.get("branchRoId"));
                Long branchZoId = ObjectConvertMaster.toLong(map.get("branchZoId"));
                Long branchLhoId = ObjectConvertMaster.toLong(map.get("branchLHoId"));
                
                if ((!OPLUtils.isObjectNullOrEmpty(branchRoId) && !OPLUtils.isObjectNullOrEmpty(branchZoId) && !OPLUtils.isObjectNullOrEmpty(branchLhoId))
                	|| (OPLUtils.isObjectNullOrEmpty(branchRoId) && !OPLUtils.isObjectNullOrEmpty(branchZoId) && !OPLUtils.isObjectNullOrEmpty(branchLhoId))
                	|| (OPLUtils.isObjectNullOrEmpty(branchRoId) && OPLUtils.isObjectNullOrEmpty(branchZoId) && !OPLUtils.isObjectNullOrEmpty(branchLhoId))
                	) {
                	branchProductMapping.setBranchRoId(ObjectConvertMaster.toLong(map.get("branchRoId")));
                    branchProductMapping.setBranchZoId(ObjectConvertMaster.toLong(map.get("branchZoId")));
                    branchProductMapping.setBranchLHoId(ObjectConvertMaster.toLong(map.get("branchLHoId")));
                }
                
                if(!OPLUtils.isObjectNullOrEmpty(branchRoId) && OPLUtils.isObjectNullOrEmpty(branchZoId) && OPLUtils.isObjectNullOrEmpty(branchLhoId)){
                    branchProductMapping.setBranchRoId(branchRoId);
                    Map<String, Long> branchZoLHoId = branchProductMappingRepository.getLHoIdAndLHoList(branchRoId, schemeId, ObjectConvertMaster.toLong(map.get("orgId")));
                    if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchZoId"))) {
                        branchProductMapping.setBranchZoId(branchZoLHoId.get("branchZoId"));
                    }
                    if (!OPLUtils.isObjectNullOrEmpty(branchZoLHoId.get("branchLHoId"))) {
                        branchProductMapping.setBranchLHoId(branchZoLHoId.get("branchLHoId"));
                    }
                }
                
                if(OPLUtils.isObjectNullOrEmpty(branchProductMapping.getBranchZoId()) && !OPLUtils.isObjectNullOrEmpty(branchZoId)){
                	if (!OPLUtils.isObjectNullOrEmpty(branchRoId)) {
                		branchProductMapping.setBranchRoId(branchRoId);
                	}
                    branchProductMapping.setBranchZoId(branchZoId);
                    Long branchLHoId = branchProductMappingRepository.getLHoId(branchZoId, schemeId, ObjectConvertMaster.toLong(map.get("orgId")));
                    if(!OPLUtils.isObjectNullOrEmpty(branchLHoId)){
                        branchProductMapping.setBranchLHoId(branchLHoId);
                    }
                }
//                branchProductMapping.setBranchRoId(ObjectConvertMaster.toLong(map.get("branchRoId")));
//                branchProductMapping.setBranchZoId(ObjectConvertMaster.toLong(map.get("branchZoId")));
//                branchProductMapping.setBranchLHoId(ObjectConvertMaster.toLong(map.get("branchLHoId")));
                branchProductMapping.setSchemeId(ObjectConvertMaster.toLong(map.get("schemeId")));
                branchProductMapping.setBranchHoId(branchRequest.getBranchHoId());
                branchProductMapping.setIsActive(true);
                branchProductMapping.setCreatedDate(new Date());
                branchProductMapping.setModifiedDate(new Date());
                branchProductMappingRepository.save(branchProductMapping);

            }
            return true;
        }
        return false;
    }

    @Override
    public String getAllZoList(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getAllZoList(tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
    }

    @Override
    public String getAllLhoList(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getAllLhoList(tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
    }

    @Override
    public String getAllRoList(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getAllRoList(tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
    }
    
	private String setDate(Date date, boolean isFrom) {
        Calendar c = Calendar.getInstance();
          c.setTime(date);
          if (isFrom) {
              c.set(Calendar.HOUR_OF_DAY, 0);
              c.set(Calendar.MINUTE, 0);
              c.set(Calendar.SECOND, 0);
          } else {
              c.set(Calendar.HOUR_OF_DAY, 23);
              c.set(Calendar.MINUTE, 59);
              c.set(Calendar.SECOND, 59);
          }

          DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
          return format.format(c.getTime());
      }

	@Override
	public Boolean updateDisplayName(RoleMasterProxy roleMasterProxy,Long userId) {
		try {
			UserRoleMaster roleMaster = roleMasterRepo.findByRoleId(roleMasterProxy.getRoleId());
			if(!OPLUtils.isObjectNullOrEmpty(roleMaster)) {
			    roleMaster.setDisplayName(roleMasterProxy.getDisplayOfficeName().concat(" Officer"));
//				roleMaster.setDisplayOfficeName(roleMasterProxy.getDisplayOfficeName());
//				roleMaster.setModifiedBy(userId);
//				roleMaster.setModifiedDate(new Date());
				roleMasterRepo.save(roleMaster);
				return Boolean.TRUE;
			}
			logger.info("No data found on roleId ======>",roleMasterProxy.getRoleId());
			return Boolean.FALSE;
		}catch (Exception e) {
			logger.error("Exception while updating data of role master on roleId"+roleMasterProxy.getRoleId(),e);
			return Boolean.FALSE;
		}

	}

    @Override
    public List<Long> getSchemeListByid(TierMappingRequestProxy tierMappingRequest) {
        return branchProductMappingRepository.getSchemeIds(tierMappingRequest.getBranchId());
    }

    @Override
    public String getZObyROId(TierMappingRequestProxy tierMappingRequest) {
        return tierMappingRepository.getZObyROId(tierMappingRequest.getZoId(),tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
    }

	@Override
	public String getZObyLhoId(TierMappingRequestProxy tierMappingRequest) {
		return tierMappingRepository.getZObyLhoId(tierMappingRequest.getLhoId(),tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
		
	}
	
	@Override
	public String getBOROZObyId(TierMappingRequestProxy tierMappingRequest) {
		return tierMappingRepository.getBOROZObyId(tierMappingRequest.getBranchId(),tierMappingRequest.getUserRoleId(),tierMappingRequest.getOrgId(),tierMappingRequest.getSelectedScheme());
		
	}
	
	@Override
	public String getBObyZOId(TierMappingRequestProxy tierMappingRequest) {
		return tierMappingRepository.getBObyZOId(tierMappingRequest.getBranchId(),tierMappingRequest.getUserRoleId(),tierMappingRequest.getOrgId(),tierMappingRequest.getBusinessTypeId(),tierMappingRequest.getSelectedScheme());
		
	}

    @Override
    public Map<String, Object> getBranchMappingIds(Long branchId, Long schemeId) {
        try{
            String branchMappingIds = tierMappingRepository.getBranchMappingIds(branchId, schemeId);
            if(!OPLUtils.isObjectNullOrEmpty(branchMappingIds)){
                return  MultipleJSONObjectHelper.getMapFromString(branchMappingIds);
            }
            logger.error("Branch mapping Id not found branchId ==>  {}, schemeId ==>  {}", branchId, schemeId);
        } catch (Exception e){
            logger.error("Error is gettting while get getBranchMappingIds", e);
        }
        return null;
    }
    
    @Override
    public Map<String, Object> getBranchMappingIdsByIfscAndSchemeId(String ifsc, Long schemeId) {
        try{
            String branchMappingIds = tierMappingRepository.getBranchMappingByIfscCodeAndSchemeId(ifsc, schemeId);
            if(!OPLUtils.isObjectNullOrEmpty(branchMappingIds)){
                return  MultipleJSONObjectHelper.getMapFromString(branchMappingIds);
            }
            logger.error("Branch mapping Id not found ifsc ==>  {}, schemeId ==>  {}", ifsc, schemeId);
        } catch (Exception e){
            logger.error("Error is gettting while get getBranchMappingByIfscCodeAndSchemeId", e);
        }
        return null;
    }

}
