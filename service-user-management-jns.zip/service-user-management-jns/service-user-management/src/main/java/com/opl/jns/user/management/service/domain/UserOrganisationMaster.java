package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_organisation_master",indexes = {
		@Index(columnList = "is_active",name = DBNameConstant.JNS_USERS+"usr_org_name_is_active")
})
public class UserOrganisationMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_organisation_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "user_organisation_master_mana_seq_gen", sequenceName = "user_organisation_master_mana_seq", allocationSize = 1)
	@Column(name = "user_org_id")
	private Long userOrgId;

	@Column(name = "organisation_name", columnDefinition = "varchar(150) default ''")
	private String organisationName;

	@Column(name = "display_org_name", columnDefinition = "varchar(150) default ''")
	private String displayOrgName;

	@Column(name = "organisation_code", columnDefinition = "varchar(55) default ''")
	private String organisationCode;

	@Column(name = "org_type")
	private Integer orgType;

	// bi-directional many-to-one association to UserTypeMaster
	@ManyToOne
	@JoinColumn(name = "user_type_id", referencedColumnName = "id")
	private UserTypeMaster userTypeMaster;

	@Column(name = "username", columnDefinition = "varchar(155) default ''")
	private String username;

	@Column(name = "password", columnDefinition = "varchar(155) default ''")
	private String password;

	@Column(name = "uat_url", columnDefinition = "varchar(500) default ''")
	private String uatUrl;

	@Column(name = "production_url", columnDefinition = "varchar(500) default ''")
	private String productionUrl;

	@Column(name = "is_reverse_api_activated")
	private Boolean isReverseApiActivated;

	@Column(name = "code_lang")
	private Integer codeLanguage;

	@Lob
	@Column(name = "config")
	private String config;
	
	@Lob
	@Column(name = "score_config")
	private String scoreConfig;
	
	@Lob
	@Column(name = "matches_tooltip")
	private String matchesTooltip;
	
	@Lob
	@Column(name = "large_logo_url")
	private String largeLogoUrl;
	
	@Column(name = "campaign_url_code", columnDefinition = "varchar(20) default ''")
	private String campaignUrlCode;
	
	@Column(name = "bank_type", columnDefinition = "varchar(200) default ''")
	private String bankType;
	
	@Lob
	@Column(name = "api_common_keys_value")
	private String apiCommonKeysValue;

	@Column(name = "general_fields", columnDefinition = "varchar(500) default ''")
	private String generalFields;
	
	@Column(name = "image_path", columnDefinition = "varchar(500) default ''")
	private String imagePath;

	@Column(name = "perfios_bank_name", columnDefinition = "varchar(100) default ''")
	private String perfiosBankName;

	@Column(name = "modified_by")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

	@Column(name = "is_active")
	private Boolean isActive;
	
	@Column(name = "is_campaign_running")
	private Boolean isCampaignRunning;

	@Lob
	@Column(name = "general_config")
	private String generalConfig;

	@Column(name = "control_block_msme", columnDefinition = "varchar(555) default ''")
	private String controlBlockMsme;

	@Column(name = "control_block_ntb", columnDefinition = "varchar(555) default ''")
	private String controlBlockNtb;

	@Column(name = "campaign_type")
	private Long campaignType;

	public UserOrganisationMaster(Long id) {
		this.userOrgId = id;
	}

}