package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.UserUploadAudit;

public interface UserUploadAuditRepoV3 extends JpaRepository<UserUploadAudit, Long> {

	@Query("SELECT COUNT(b) FROM UserUploadAudit b WHERE fileUploadId=:fileId AND status=:status ")
	public Integer getUploadUserCount(@Param("fileId") Long fileId, @Param("status") Integer status);

}
