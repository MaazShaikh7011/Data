package com.opl.jns.user.management.service.domain;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "branch_type_master",indexes = {
        @Index(columnList = "is_display,is_active",name = DBNameConstant.JNS_USERS + "BR_TYPE_MST_IS_DISPLAY_IS_ACTIVE"),
})
public class BranchTypeMaster implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "branch_type_master_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "branch_type_master_mana_seq_gen", sequenceName = "branch_type_master_mana_seq", allocationSize = 1)
    private Long id;

    @Column(name = "branch_type",columnDefinition = "varchar(200) default ''")
    private String branchType;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_display")
    private Boolean isDisplay;

    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdDate;

    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;

}
