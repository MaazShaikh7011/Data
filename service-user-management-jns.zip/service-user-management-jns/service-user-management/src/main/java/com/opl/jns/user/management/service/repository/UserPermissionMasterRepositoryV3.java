package com.opl.jns.user.management.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.api.model.UserPermissionMasterProxy;
import com.opl.jns.user.management.service.domain.UserPermissionMaster;

public interface UserPermissionMasterRepositoryV3 extends JpaRepository<UserPermissionMaster, Long> {

    @Query(value = "SELECT new com.opl.jns.user.management.api.model.UserPermissionMasterProxy(u.id, u.name) FROM UserPermissionMaster u WHERE u.groupId <> 13 AND u.isActive = TRUE")
    List<UserPermissionMasterProxy> getPermissionMasterList();

    @Query(value = "SELECT new com.opl.jns.user.management.api.model.UserPermissionMasterProxy(u.id, u.name) FROM UserPermissionMaster u WHERE u.groupId = 13 AND u.isActive = TRUE")
	List<UserPermissionMasterProxy> getMasterAdminPermissionMasterList();
    
    @Query("SELECT upm FROM UserPermissionMaster upm INNER JOIN MenuMaster mm ON mm.id = upm.adminMenuId INNER JOIN AdminMenuPermissionMapping rm ON rm.id = upm.id AND rm.roleId IN(:roleIdList) WHERE upm.groupId=13")
    List<UserPermissionMaster> getAdminPermissionMasterList(@Param("roleIdList") Long roleIdList);

}
