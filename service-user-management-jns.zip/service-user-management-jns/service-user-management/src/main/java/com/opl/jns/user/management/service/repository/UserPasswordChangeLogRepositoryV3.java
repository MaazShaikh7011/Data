package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.user.management.service.domain.UserPasswordChangeLog;


/**
 * @author sandip.bhetariya
 *
 */
@Repository

public interface UserPasswordChangeLogRepositoryV3 extends JpaRepository<UserPasswordChangeLog, Long> {
	
//	public  List<UserPasswordChangeLog> findOneByUserId(User user);
}
