package com.opl.jns.user.management.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.user.management.service.domain.UserPermissionMapping;

import java.util.List;

public interface UserPermissionMappingRepositoryV3 extends JpaRepository<UserPermissionMapping, Long> {

    @Query(value = "SELECT DISTINCT(u.permissionId) FROM UserPermissionMapping u WHERE u.orgId=:orgId AND u.userRoleId=:userRoleId AND u.schemeId=:schemeId")
    List<Long> findByOrgIdAndUserRoleIdAndLoanTypeid(@Param("orgId") Long orgId, @Param("userRoleId") Long userRoleId, @Param("schemeId") Long schemeId);

    @Modifying
    @Query(value = "DELETE FROM UserPermissionMapping u WHERE u.orgId=:orgId AND u.userRoleId=:userRoleId AND u.schemeId=:schemeId")
    void deleteByOrgIdAndUserRoleIdAndLoanTypeid(@Param("orgId") Long orgId, @Param("userRoleId") Long userRoleId, @Param("schemeId") Long schemeId);
}
