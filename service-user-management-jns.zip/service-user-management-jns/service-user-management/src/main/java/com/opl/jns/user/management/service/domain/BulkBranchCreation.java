package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.common.EncryptionUtilsOracle;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bulk_branch_creation")
public class BulkBranchCreation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_branch_creation_mana_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_USERS, name = "bulk_branch_creation_mana_seq_gen", sequenceName = "bulk_branch_creation_mana_seq", allocationSize = 1)
	private Long id;

	@Column(name = "branch_type", columnDefinition = "varchar(200) default ''")
	private String branchType;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "email", columnDefinition = "varchar(200) default ''")
	private String email;

	@Convert(converter = EncryptionUtilsOracle.class)
	@Column(name = "mobile", columnDefinition = "varchar(20) default ''")
	private String mobile;

	@Column(name = "branch_name", columnDefinition = "varchar(100) default ''")
	private String branchName;

	@Column(name = "branch_code", columnDefinition = "varchar(100) default ''")
	private String branchCode;

	@Column(name = "ifsc_code", columnDefinition = "varchar(50) default ''")
	private String ifscCode;

	@Column(name = "address", columnDefinition = "varchar(500) default ''")
	private String address;

	@Column(name = "pincode")
	private Integer pincode;

	@Column(name = "state")
	private Integer state;

	@Column(name = "city")
	private Integer city;

	@Column(name = "ro_code", columnDefinition = "varchar(50) default ''")
	private String roCode;

	@Column(name = "zo_code", columnDefinition = "varchar(50) default ''")
	private String zoCode;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "business_type_id")
	private Long businessTypeId;

	@Column(name = "scheme_id")
	private Long schemeId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "datetime")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date dateTime;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "msg", columnDefinition = "varchar(500) default ''")
	private String message;

	@Column(name = "file_id")
	private Long fileId;

	@Column(name = "user_role_id")
	private Long userRoleId;

	@Column(name = "created_by_branch_id", columnDefinition = "varchar(20) default ''")
	private String createdByBranchId;

	@Column(name = "original_file_name", columnDefinition = "varchar(255) default ''")
	private String originalFileName;

	@Column(name = "rural_urban", columnDefinition = "varchar(15) default ''")
	private String ruralUrban;

}
