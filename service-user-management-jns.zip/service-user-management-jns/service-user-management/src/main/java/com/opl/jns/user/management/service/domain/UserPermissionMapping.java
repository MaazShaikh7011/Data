package com.opl.jns.user.management.service.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author sandip.bhetariya
 *
 */
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_permission_mpg")
public class UserPermissionMapping {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_permission_mpg_man_seq_gen")
	@SequenceGenerator(schema =DBNameConstant.JNS_USERS,name = "user_permission_mpg_man_seq_gen", sequenceName = "user_permission_mpg_man_seq", allocationSize = 1)
    private Long id;

    @Column(name = "permission_id")
    private Long permissionId;

    @Column(name = "user_role_id")
    private Long userRoleId;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "created_by")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "created_on", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
   	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
   	private Date createdOn;

    @Column(name = "scheme_id")
    private Long schemeId;
    
	@Column(name = "is_active")
	private Boolean isActive;

}
