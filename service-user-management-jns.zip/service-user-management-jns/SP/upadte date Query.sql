
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'DD-MM-RR HH12:MI:SSXFF AM';
commit;


alter table JNS_INSURANCE.NOMINEE_DETAILS ADD column (dob_str VARCHAR2(255 CHAR) );
alter table JNS_INSURANCE.APPLICANT_INFO ADD column (dob_str VARCHAR2(255 CHAR) );
alter table JNS_INSURANCE.APPLICATION_MASTER ADD column (dob_str VARCHAR2(255 CHAR) );
commit;


update JNS_INSURANCE.NOMINEE_DETAILS set dob_str = JNS_USERS."encvalue"(to_char(dob,'yyyy-MM-dd HH:mm:ss'));
update JNS_INSURANCE.APPLICANT_INFO set dob_str = JNS_USERS."encvalue"(to_char(dob,'yyyy-MM-dd HH:mm:ss'));
update JNS_INSURANCE.APPLICATION_MASTER set dob_str = JNS_USERS."encvalue"(to_char(dob,'yyyy-MM-dd HH:mm:ss'));
commit;



alter table JNS_INSURANCE.NOMINEE_DETAILS rename column dob to dob_old;
alter table JNS_INSURANCE.APPLICANT_INFO rename column dob to dob_old;
alter table JNS_INSURANCE.APPLICATION_MASTER rename column dob to dob_old;
commit;


alter table JNS_INSURANCE.NOMINEE_DETAILS rename column dob_str to dob;;
alter table JNS_INSURANCE.APPLICANT_INFO rename column dob_str to dob;
alter table JNS_INSURANCE.APPLICATION_MASTER rename column dob_str to dob;
commit;

 

update JNS_insurance.TRANSACTION_DETAILS SET TRANS_TIME_STAMP = JNS_USERS."encvalue"(to_char(to_timestamp(TRANS_TIME_STAMP),'yyyy-MM-dd HH:mm:ss'));
commit;



ALTER TABLE JNS_INSURANCE.claim_master ADD (date_of_transaction_str VARCHAR2(255 CHAR) );
ALTER TABLE JNS_INSURANCE.claim_detail ADD (date_of_death_str VARCHAR2(255 CHAR),date_time_of_accident_str VARCHAR2(255 CHAR) );
commit;

 
update JNS_insurance.claim_master set date_of_transaction_str =jns_users."encvalue"(to_char(date_of_transaction,'yyyy-MM-dd HH:mm:ss'));
update JNS_insurance.claim_detail set date_of_death_str =jns_users."encvalue"(to_char(date_of_death,'yyyy-MM-dd HH:mm:ss')),date_time_of_accident_str =jns_users."encvalue"(to_char(date_time_of_accident,'yyyy-MM-dd HH:mm:ss'));
commit;

 
ALTER TABLE JNS_INSURANCE.claim_master RENAME COLUMN date_of_transaction to date_of_transaction_old;
ALTER TABLE JNS_INSURANCE.claim_detail RENAME COLUMN date_of_death to date_of_death_old;
ALTER TABLE JNS_INSURANCE.claim_detail RENAME COLUMN date_time_of_accident to date_time_of_accident_old;
commit;

 
ALTER TABLE JNS_INSURANCE.claim_master RENAME COLUMN date_of_transaction_str to date_of_transaction;
ALTER TABLE JNS_INSURANCE.claim_detail RENAME COLUMN date_of_death_str to date_of_death;
ALTER TABLE JNS_INSURANCE.claim_detail RENAME COLUMN date_time_of_accident_str to date_time_of_accident;
commit;

