create or replace  FUNCTION            "encvalue" ( INPUT_STRING IN VARCHAR2)
RETURN varchar2
AS
	RAW_ENCRYPTED_STRING RAW(2000);
	-- Already generated keys (not recommended to hard-code keys in function for production use - as mentioned in post)
--    RAW_KEY_BYTES_32 RAW(32) := 'C@p!ta@W0rld#AES';
	RAW_KEY_BYTES_32 RAW(16) := '434070217461405730726C6423414553';
    iv_raw raw(16):='434070217461405730726C6423414553';
	AES128 PLS_INTEGER := DBMS_CRYPTO.ENCRYPT_AES128+DBMS_CRYPTO.CHAIN_CBC+DBMS_CRYPTO.PAD_PKCS5;
BEGIN
    if INPUT_STRING is null then
        return INPUT_STRING;
    end if;

		-- For generating key of 32 Bytes in RAW format - skipped for now, as I have already declared the key
		RAW_ENCRYPTED_STRING := DBMS_CRYPTO.ENCRYPT 
		(
			SRC => UTL_I18N.STRING_TO_RAW(lower(INPUT_STRING), 'AL32UTF8'),
			TYP => AES128,
			KEY => RAW_KEY_BYTES_32
            ,iv => RAW_KEY_BYTES_32
		);

		-- BASE64 ENCODING - Makes RAW encrypted data to be suitable with VARCHAR2 storage
		RETURN UTL_RAW.CAST_TO_VARCHAR2(UTL_ENCODE.BASE64_ENCODE(RAW_ENCRYPTED_STRING));
END ;