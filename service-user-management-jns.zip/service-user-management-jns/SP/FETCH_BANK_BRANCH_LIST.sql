CREATE OR REPLACE PROCEDURE JNS_USERS.fetch_BANK_BRANCH_LIST (
    orgid           IN   NUMBER,
    businesstypeid  IN   NUMBER,
    branchtype      IN   NUMBER,
    nopagination    IN   VARCHAR2,
    paginationfrom  IN  number,
    paginationto    IN   number,
    schemeid        IN   NUMBER,
    columnfilter    IN   VARCHAR2,
    result          OUT clob
) IS
    mainQuery   CLOB;
    query             CLOB;
    selectcountquery  CLOB;
    selectdataquery   CLOB;
    tablequery        CLOB;
    whereclause       CLOB;
    totalcount        NUMBER;
    totalcountquery   CLOB;
    orderby           CLOB;
    limit             CLOB;
    searchdata        CLOB;
    fromdate          CLOB;
    todate            CLOB;
    out clob;
BEGIN
    dbms_output.enable(1000000);
    selectcountquery := ' SELECT COUNT(*) ';

    CASE
        WHEN branchtype = 5 THEN -- ALL Branches
            selectdataquery := ' bm.id as branchId, bm.code as branchCode,bm.name as branchName,bm.branch_type as branchTypeId, btm.branch_type as branchType,
                        bm.street_name as address,bm.pincode as pincode,bm.ifsc_code as ifsc,bm.contact_person_email as email,bm.telephone_no as contactNo,
                        bm.contact_person_name as contactPersonName,CASE bm.is_active WHEN 1 THEN 1 ELSE 0 END as isActive,ld.name as city,ls.name as state,
                        (SELECT COUNT(us.user_id) FROM users us WHERE us.branch_id = bm.id) as totalUsers,
                        ZO.id as zoBranchId,
                        ZO.name as zoBranchName,
                        ZO.code as zoBranchCode,
                        RO.id as roBranchId,
                        RO.name as roBranchName,
                        RO.code as roBranchCode ';
            tablequery := ' FROM
                        branch_product_mapping b
                        LEFT JOIN branch_master RO ON RO.id = b.branch_ro_id
                        LEFT JOIN branch_master ZO ON ZO.id = b.branch_zo_id
                        LEFT JOIN branch_master bm ON b.branch_id = bm.id
                        INNER JOIN JNS_USERS.BRANCH_TYPE_MASTER btm on btm.id = bm.branch_type
                        LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ld ON ld.id = bm.city_id
                        LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.id = bm.state_id ';
            whereclause := ' WHERE b.user_org_id = '
                           || orgid
                           || ' AND b.business_id = '
                           || businesstypeid
                           || ' AND b.sch_type_id = '
                           || schemeid;

        WHEN branchtype = 1 THEN  -- BO TYPE BRANCH
            selectdataquery := ' bm.id as branchId,bm.code as branchCode,bm.name as branchName,bm.branch_type as branchTypeId,''Branch Office'' as branchType,bm.street_name as address,bm.pincode as pincode,bm.ifsc_code as ifsc,
                        bm.contact_person_email as email, bm.telephone_no as contactNo, bm.contact_person_name as contactPersonName,
                        CASE bm.is_active WHEN 1 THEN 1 ELSE 0 END as isActive,ld.name as city, ls.name as state,
                        (SELECT COUNT(us.user_id) FROM users us WHERE us.user_role_id = 9 AND us.is_active = 1 AND us.branch_id = bm.id) as branchChecker,
                        (SELECT COUNT(us.user_id) FROM users us WHERE us.user_role_id = 8 AND us.is_active = 1 AND us.branch_id = bm.id) as branchMaker,
                        (SELECT COUNT(us.user_id) FROM users us WHERE us.branch_id = bm.id) as totalUsers,
                        ZO.id as zoBranchId,
                        ZO.name as zoBranchName,
                        ZO.code as zoBranchCode,
                        RO.id as roBranchId,
                        RO.name as roBranchName,
                        RO.code as roBranchCode ';
            tablequery := ' FROM branch_product_mapping b
                        LEFT JOIN branch_master RO ON RO.id = b.branch_ro_id
                        LEFT JOIN branch_master ZO ON ZO.id = b.branch_zo_id
                        LEFT JOIN branch_master bm ON b.branch_id = bm.id
                        LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ld ON ld.id = bm.city_id
                        LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.id = bm.state_id ';
            whereclause := ' WHERE b.user_org_id = '
                           || orgid
                           || ' AND bm.branch_type = '
                           || branchtype
                           || ' AND b.business_id = '
                           || businesstypeid
                           || ' AND b.sch_type_id = '
                           || schemeid;

        WHEN branchtype = 2 THEN -- RO TYPE BRANCH
            selectdataquery := ' bm.id as branchId,bm.code as branchCode,bm.name as branchName,bm.branch_type as branchTypeId,''Regional Office'' as branchType,bm.street_name as address,bm.pincode as pincode,bm.ifsc_code as ifsc,
                        bm.contact_person_email as email, bm.telephone_no as contactNo, bm.contact_person_name as contactPersonName,
                        CASE bm.is_active WHEN 1 THEN 1 ELSE 0 END as isActive,ld.name as city, ls.name as state,
                        (SELECT COUNT(us.user_id) FROM users us WHERE us.branch_id = bm.id) as totalUsers,
                        ZO.id as zoBranchId,
                         ZO.name as zoBranchName,
                         ZO.code as zoBranchCode,
                         RO.id as roBranchId,
                         RO.name as roBranchName,
                         RO.code as roBranchCode';
            tablequery := ' FROM branch_product_mapping b
                        LEFT JOIN branch_master RO ON RO.id = b.branch_ro_id
                        LEFT JOIN branch_master ZO ON ZO.id = b.branch_zo_id
                        LEFT JOIN branch_master bm ON bm.id = b.branch_id
                        LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ld ON ld.id = bm.city_id
                        LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.id = bm.state_id ';
            whereclause := ' WHERE b.user_org_id = '
                           || orgid
                           || ' AND bm.branch_type = '
                           || branchtype
                           || ' AND b.business_id = '
                           || businesstypeid
                           || ' AND b.sch_type_id = '
                           || schemeid;

        WHEN branchtype = 3 THEN -- ZO TYPE BRANCH
            selectdataquery := ' bm.id as branchId, bm.code as branchCode,bm.name as branchName,bm.branch_type as branchTypeId,''Zonal Office'' as branchType,
                    bm.street_name as address,bm.pincode as pincode,bm.ifsc_code as ifsc,bm.contact_person_email as email,bm.telephone_no as contactNo,
                    bm.contact_person_name as contactPersonName,CASE bm.is_active WHEN 1 THEN 1 ELSE 0 END as isActive,ld.name as city,ls.name as state,
                    (SELECT COUNT(us.user_id) FROM users us WHERE us.branch_id = bm.id) as totalUsers,
                    ZO.id as zoBranchId,
                     ZO.name as zoBranchName,
                     ZO.code as zoBranchCode,
                     RO.id as roBranchId,
                     RO.name as roBranchName,
                     RO.code as roBranchCode ';
            tablequery := ' FROM branch_product_mapping b
                        LEFT JOIN branch_master RO ON RO.id = b.branch_ro_id
                        LEFT JOIN branch_master ZO ON ZO.id = b.branch_zo_id
                        LEFT JOIN branch_master bm ON bm.id = b.branch_id
                        LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ld ON ld.id = bm.city_id
                        LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.id = bm.state_id ';
            whereclause := ' WHERE b.user_org_id = '
                           || orgid
                           || ' AND bm.branch_type = '
                           || branchtype
                           || ' AND b.business_id = '
                           || businesstypeid
                           || ' AND b.sch_type_id = '
                           || schemeid;

        WHEN branchtype = 6 THEN -- LHO TYPE BRANCH
             selectdataquery := ' bm.id as branchId, bm.code as branchCode,bm.name as branchName,bm.branch_type as branchTypeId,''Lead Head Office'' as branchType,
                    bm.street_name as address,bm.pincode as pincode,bm.ifsc_code as ifsc,bm.contact_person_email as email,bm.telephone_no as contactNo,
                    bm.contact_person_name as contactPersonName,CASE bm.is_active WHEN 1 THEN 1 ELSE 0 END as isActive,ld.name as city,ls.name as state,
                    (SELECT COUNT(us.user_id) FROM users us WHERE us.branch_id = bm.id) as totalUsers,
                    ZO.id as zoBranchId,
                    ZO.name as zoBranchName,
                    ZO.code as zoBranchCode,
                    RO.id as roBranchId,
                    RO.name as roBranchName,
                    RO.code as roBranchCode ';
            tablequery := ' FROM branch_product_mapping b
                        LEFT JOIN branch_master RO ON RO.id = b.branch_ro_id
                        LEFT JOIN branch_master ZO ON ZO.id = b.branch_zo_id
                        LEFT JOIN branch_master bm ON bm.id = b.branch_id
                        LEFT JOIN JNS_ONEFORM.LGD_DISTRICT ld ON ld.id = bm.city_id
                        LEFT JOIN JNS_ONEFORM.LGD_STATE ls ON ls.id = bm.state_id ';
            whereclause := ' WHERE b.user_org_id = '
                           || orgid
                           || ' AND bm.branch_type = '
                           || branchtype
                           || ' AND b.business_id = '
                           || businesstypeid
                           || ' AND b.sch_type_id = '
                           || schemeid ;




    END CASE;

	IF (JSON_VALUE(columnFilter,'$.fromDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate')  IS NOT NULL) THEN
		whereClause := whereClause || ' AND (DATE(us.created_date) BETWEEN ' || JSON_VALUE(columnFilter,'$.fromDate') || ' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||' OR DATE(us.modified_date) BETWEEN ' ||JSON_VALUE(columnFilter,'$.fromDate') ||' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||')';
	ELSIF (JSON_VALUE(columnFilter,'$.fromDate' )IS NOT NULL ) THEN
		whereClause := whereClause || ' AND DATE(us.created_date) = ' || JSON_VALUE(columnFilter,'$.fromDate');
	END IF;
--
    IF JSON_VALUE(columnFilter,'$.branchName') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ( LOWER(bm.name) LIKE ''%'
                                           || lower(JSON_VALUE(columnFilter,'$.branchName'))
                                           || '%''
                                              OR LOWER(bm.code) LIKE ''%'
                                           || LOWER(JSON_VALUE(columnFilter,'$.branchName'))
                                           || '%'')');
    END IF;

    IF
        fromdate IS NOT NULL
        AND todate IS NOT NULL
    THEN
        whereclause := concat(whereclause,(' AND (to_char(bm.created_on,''yyyy-mm-dd'') BETWEEN '''
                                           || fromdate
                                           || ''' AND '''
                                           || todate
                                           || ''' OR to_char(bm.modified_date,''yyyy-mm-dd'') BETWEEN '''
                                           || fromdate
                                           || ''' AND '''
                                           || todate
                                           || ''')'));
    ELSE
        IF fromdate IS NOT NULL THEN
            whereclause := whereclause
                           || ' AND to_char(bm.created_on,''yyyy-mm-dd'') = '''
                           || fromdate || '';
        END IF;
    END IF;

    totalcountquery := selectcountquery
                       || tablequery
                       || whereclause;
    dbms_output.put_line(totalcountquery);
    EXECUTE IMMEDIATE totalcountquery into totalcount;
    orderby := ' ORDER BY bm.id DESC';

    IF
        nopagination IS NOT NULL
--        AND nopagination != ''
    THEN
        limit := ' ';
    ELSE limit := ' OFFSET '
                   || paginationfrom
                   || ' ROWS FETCH NEXT '
                   || paginationto
                   || ' ROWS ONLY';
    END IF;

    query := 'SELECT '
             || totalcount
             || ' AS totalCount, '
             || selectdataquery
             || tablequery
             || whereclause
             || orderby
             || limit;


     CASE
        WHEN branchtype = 5 THEN

             mainQuery:=' select json_arrayagg(JSON_OBJECT( ''totalCount'' Value totalCount,''branchId''  value branchId , ''branchCode'' value branchCode ,''branchName'' value branchName ,''branchTypeId'' value branchTypeId,''branchType'' value branchType,
                         ''address'' value address,''pincode'' value pincode,''ifsc'' value ifsc ,''email'' value email ,''contactNo'' value contactNo,
                        ''contactPersonName'' value contactPersonName,''isActive'' value isActive ,''city'' value city ,''state'' value state,
                         ''totalUsers'' value totalUsers ,
                        ''zoBranchId'' value zoBranchId ,
                        ''zoBranchName'' value zoBranchName,
                        ''zoBranchCode'' value zoBranchCode,
                        ''roBranchId'' VALUE roBranchId ,
                        ''roBranchName'' value roBranchName,
                        ''roBranchCode''value roBranchCode)format json returning clob )from( '||query||') offset 0 row fetch next 1 row only ';

                WHEN branchtype = 1 THEN
                     mainQuery:=   'select JSON_ARRAYAGG(json_object( ''totalCount'' Value totalCount,''branchId'' value branchId,''branchCode'' value branchCode,''branchName'' value branchName,''branchTypeId'' value branchTypeId,''branchType'' value branchType,''address'' value address,''pincode'' value pincode,''ifsc'' value ifsc,
                        ''email'' value email, ''contactNo''value contactNo,''contactPersonName'' value contactPersonName,
                        ''isActive'' value isActive,''city'' value city, ''state'' value state,
                        ''branchChecker'' value branchChecker,
                        ''branchMaker'' value branchMaker,
                        ''totalUsers'' value totalUsers,
                        ''zoBranchId'' value zoBranchId,
                       ''zoBranchName'' value zoBranchName,
                        ''zoBranchCode'' value zoBranchCode,
                       ''roBranchId''value roBranchId,
                        ''roBranchName'' value roBranchName,
                       ''roBranchCode'' value roBranchCode )format json returning clob)from( '||query||')';

                     WHEN branchtype = 2 THEN
                     mainQuery:=  'select JSON_ARRAYAGG(json_object(''totalCount'' Value totalCount,''branchId'' value branchId,
 ''branchCode'' value branchCode,
 ''branchName'' value branchName,
 ''branchTypeId'' value branchTypeId,
 ''branchType'' value branchType,
 ''address'' value address,
 ''pincode'' value pincode,
 ''ifsc'' value ifsc, ''email'' value email,
                         ''contactNo'' value contactNo,
                         ''contactPersonName'' value contactPersonName,
                          ''isActive'' value isActive,
                        ''city'' value city,
                         ''state'' value state,
                        ''totalUsers'' value totalUsers,
                        ''zoBranchId'' value zoBranchId,
                         ''zoBranchName'' value zoBranchName,
                         ''zoBranchCode'' value zoBranchCode,
                         ''roBranchId'' value roBranchId,
                         ''roBranchName'' value roBranchName,
                         ''roBranchCode'' value roBranchCode)format json returning clob)from( '||query||')';

                          WHEN branchtype = 3 THEN
                        mainQuery:= ' select JSON_ARRAYAGG(JSON_OBJECT(''totalCount'' Value totalCount,''branchId'' value branchId,
 ''branchCode'' value branchCode,
''branchName'' value branchName,
''branchTypeId'' value branchTypeId,
''branchType'' value branchType,
''address'' value address,
''pincode'' value pincode,
''ifsc'' value ifsc,
''email'' value email,
''contactNo'' value contactNo,
''contactPersonName'' value contactPersonName,
 ''isActive'' value isActive,
''city'' value city,
''state'' value state,
''totalUsers'' value totalUsers,
''zoBranchId'' value zoBranchId,
''zoBranchName'' value zoBranchName,
''zoBranchCode'' value zoBranchCode,
''roBranchId'' value roBranchId,
''roBranchName'' value roBranchName,
'' robranchcode '' value robranchcode)format json returning clob)from( '||query||')';

                    WHEN branchtype = 6 THEN
                        mainQuery:=  ' select JSON_ARRAYAGG(JSON_OBJECT(''totalCount'' Value totalCount,''branchId''value branchId,
 ''branchCode''value branchCode,
''branchName''value branchName,
''branchTypeId''value branchTypeId,
''branchType''value branchType,
''address''value address,
''pincode''value pincode,
''ifsc''value ifsc,
''email''value email,
''contactNo''value contactNo,
''contactPersonName''value contactPersonName,
 ''isActive''value isActive,
''city''value city,
''state''value state,
''totalUsers''value totalUsers,
''zoBranchId''value zoBranchId,
''zoBranchName''value zoBranchName,
''zoBranchCode''value zoBranchCode,
''roBranchId''value roBranchId,
''roBranchName''value roBranchName,
''roBranchCode''value roBranchCode )format json returning clob)from( '||query||')';
    end case;

    dbms_output.put_line( mainQuery );
    EXECUTE IMMEDIATE mainQuery INTO out;
    result := to_clob(out);
--    dbms_output.put_line( result );
    End;