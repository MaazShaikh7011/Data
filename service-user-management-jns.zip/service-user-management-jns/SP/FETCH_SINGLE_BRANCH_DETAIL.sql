CREATE OR REPLACE PROCEDURE JNS_USERS."FETCH_SINGLE_BRANCH_DETAIL"(branchId       IN  NUMBER,
                                                                     businessTypeId IN  NUMBER,
                                                                     result         OUT CLOB)
  AS
    query CLOB;
  BEGIN
    -- dbms_output.put_line('START SPUSERMANAGEMENTFETCHSINGLEBRANCHDETAIL ');
    query := 'SELECT JSON_ARRAYAGG(JSON_OBJECT(
                    ''branchId'' value b.id ,
					''branchName'' value b.name,
					''branchCode'' value b.code ,
					''roName'' value ro.name ,
					''roCode'' value ro.code ,
					''email'' value b.contact_person_email ,
					''contactNo'' value b.contact_person_number ,
					''contactPersonName'' value b.contact_person_name ,
					''branchCreation'' value b.created_on ,
					''branchModification'' value b.modified_date ,
					''address'' value b.street_name ,
					''ifscCode'' value b.ifsc_code ,
					''pincode'' value b.pincode ,
					''boState'' value s.name ,
					''boCity'' value c.name ,
					''stateId'' value s.id ,
					''ruralUrbanId'' value b.RURAL_URBAN_ID ,
					''cityId'' value c.id ,
					''regionId'' value b.region_id ,
					''maker'' value (jns_users.fn_count_maker(b.id)) ,
					''checker'' value (jns_users.fn_count_checker(b.id)) ,
					''loanType'' value bs.display_name ,
					''businessTypeId'' value bpm.business_id ,
					''roId'' value bpm.branch_ro_id ,
					''zoId'' value bpm.branch_zo_id ,
					''zoName'' value zo.name ,
					''zoCode'' value zo.code ,
					''lhoId'' value bpm.branch_lho_id ,
					''lhoName'' value lho.name ,
					''lhoCode'' value lho.code ,
					''roName'' value (SELECT b1.name FROM jns_users.branch_master b1 WHERE b1.id=bpm.branch_ro_id ) ,
					''selectedScheme'' value (SELECT JSON_ARRAYAGG( s1.sch_type_id) FROM jns_users.branch_product_mapping s1 WHERE s1.branch_id = b.id  AND s1.user_org_id = b.org_id)
					)returning clob)
					FROM jns_users.branch_master b
					INNER JOIN jns_users.branch_product_mapping bpm ON bpm.branch_id = b.id AND business_id = '|| businessTypeId ||'
					LEFT JOIN jns_users.branch_master ro ON bpm.branch_ro_id = ro.id AND ro.branch_type = 2
					LEFT JOIN jns_users.branch_master zo ON bpm.branch_zo_id = zo.id AND zo.branch_type = 3
					LEFT JOIN jns_users.branch_master lho ON bpm.branch_lho_id = lho.id AND lho.branch_type = 6
					LEFT JOIN jns_users.business_master bs ON bs.id = bpm.business_id
					LEFT JOIN jns_oneform.lgd_state s ON b.state_id = s.id
					LEFT JOIN jns_oneform.LGD_DISTRICT c on b.city_id =c.id
					WHERE b.id = '|| branchId ;
    dbms_output.put_line(query);
    dbms_output.put_line('fetch the result  ');

    EXECUTE IMMEDIATE query
      INTO result;

  END FETCH_SINGLE_BRANCH_DETAIL;