CREATE OR REPLACE PROCEDURE JNS_USERS."FETCH_SINGLE_RO_DETAIL"(
branchid       IN  NUMBER,
businesstypeid IN  NUMBER,
schemeid       IN  NUMBER,
result         OUT CLOB)
IS
query CLOB;
BEGIN
    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    query := 'SELECT
  json_arrayagg ( json_object( ''roName'' value b.name,
                                ''roCode'' value b.code,
                                ''branchCreation'' value b.created_on,
                                ''branchModification'' value b.modified_date,
								''ruralUrbanId'' value b.RURAL_URBAN_ID ,
                                ''roState'' value s.name,
                                ''roCity'' value c.name,
                                ''stateId'' value s.id,
                                ''cityId'' value c.id,
                                ''zoName'' value zo.name,
                                ''zoCode'' value zo.code,
                                ''ifscCode'' value b.ifsc_code,
                                ''address'' value c.name || '' '' || s.name,
                                ''activeBo'' value (
                                    SELECT COUNT(DISTINCT(branch_id)) FROM jns_users.branch_product_mapping
                                    WHERE branch_ro_id = '
    || branchid
    || ' AND business_id = '
    || businesstypeid
    || '),
                                ''boDetails'' value  (SELECT
    json_arrayagg
( json_object( ''userId'' value u.user_id,
                ''userName'' value concat(concat(jns_users."decvalue"(u.first_name),'' ''),jns_users."decvalue"(u.last_name)),
                ''email'' value jns_users."decvalue"(u.email),
                ''mobile'' value jns_users."decvalue"(u.mobile),
                ''isActive'' value  u.is_active ,
''boName'' value b.name,
''boCode'' value b.code,
''ruralUrbanId'' value b.RURAL_URBAN_ID,
''boCity'' value c.name,
''boState'' value s.name,
''roleName'' value r.display_name )returning clob)
FROM
    jns_users.users               u
    LEFT JOIN jns_users.branch_master       b ON u.branch_id = b.id
    LEFT JOIN jns_oneform.LGD_STATE            s ON b.state_id = s.id
    LEFT JOIN jns_oneform.LGD_DISTRICT             c ON b.city_id = c.id
    LEFT JOIN jns_users.user_role_master    r ON u.user_role_id = r.role_id
WHERE
    u.branch_id IN (
        SELECT
           distinct branch_id
        FROM
            jns_users.branch_product_mapping
        WHERE
                branch_ro_id = ' || branchid || '
            AND business_id = ' || businesstypeid || '
    )  and b.branch_type =1 ) returning clob )returning clob )  AS branchdetails
FROM
         jns_users.branch_master b
    INNER JOIN jns_users.branch_product_mapping    bpm ON bpm.branch_id = b.id
                                                   AND bpm.business_id = ' || businesstypeid || '
                                                       AND bpm.sch_type_id = ' || schemeid || '
    LEFT JOIN jns_oneform.LGD_STATE                  s ON b.state_id = s.id
    LEFT JOIN jns_oneform.LGD_DISTRICT                   c ON b.city_id = c.id
    LEFT JOIN jns_users.branch_master             zo ON bpm.branch_zo_id = zo.id
                                        AND zo.branch_type = 3
WHERE
        b.is_active = 1
    AND b.branch_type = 2
        AND b.id = ' || branchid;

        dbms_output.put_line(query);
    EXECUTE IMMEDIATE query
      INTO result;
  END;