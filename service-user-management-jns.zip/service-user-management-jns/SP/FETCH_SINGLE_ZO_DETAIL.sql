CREATE OR REPLACE PROCEDURE JNS_USERS."FETCH_SINGLE_ZO_DETAIL"(branchid       IN  NUMBER,
                                                                 businesstypeid IN  NUMBER,
                                                                 result         OUT CLOB)
  IS
    query CLOB;
  BEGIN
    query := 'SELECT JSON_ARRAYAGG(JSON_OBJECT(
                               ''zoId'' VALUE b.id,
                               ''zoName'' VALUE b.name,
                               ''zoCode'' VALUE b.code,
							   ''ruralUrbanId'' value b.RURAL_URBAN_ID ,
                               ''zoState'' VALUE s.name,
                                 ''zoCity'' VALUE c.name,
                                 ''stateId'' VALUE s.id,
                                 ''cityId'' VALUE c.id,
                                 ''branchCreation'' VALUE b.created_on,
                                 ''branchModification'' VALUE b.modified_date,
                                 ''activeRo'' VALUE( SELECT COUNT(DISTINCT(bpm.branch_id))  FROM  jns_users.branch_product_mapping  bpm  LEFT JOIN jns_users.branch_master b ON bpm.branch_id = b.id WHERE bpm.branch_zo_id = '
                                    || branchid
                                    || 'AND bpm.business_id = '
                                    || businesstypeid
                                    ||' AND b.branch_type = 2 ),
                                 ''roDetails'' VALUE( SELECT
                                                        JSON_ARRAYAGG(JSON_OBJECT(
                                                         ''userId'' VALUE u.user_id,
                                                         ''userName'' VALUE concat(concat(jns_users."decvalue"(u.first_name),'' ''),jns_users."decvalue"(u.last_name)),
                                                         ''email'' VALUE jns_users."decvalue"(u.email),
                                                         ''mobile'' VALUE jns_users."decvalue"(u.mobile),
                                                         ''isActive'' VALUE u.is_active,
                                                         ''roName'' VALUE b.name,
                                                         ''roCode'' VALUE b.code,
														 ''ruralUrbanId'' value b.RURAL_URBAN_ID ,
                                                         ''roCity'' VALUE c.name,
                                                         ''userType'' VALUE r.display_name,
                                                         ''roState'' VALUE s.name
                                                     ) returning clob)
                                                    FROM
                                                    jns_users.users                u
                                                    LEFT JOIN jns_users.branch_master        b ON u.branch_id = b.id
                                                    LEFT JOIN jns_oneform.lgd_state    s ON b.state_id = s.id
                                                    LEFT JOIN jns_oneform.LGD_DISTRICT     c ON b.city_id = c.id
                                                    LEFT JOIN jns_users.user_role_master     r ON u.user_role_id = r.role_id
                                                    WHERE
                                                        u.branch_id IN(
                                                                    SELECT DISTINCT
                                                                    (bpm.branch_id)
                                                                     FROM
                                                                     jns_users.branch_product_mapping  bpm
                                                                     LEFT JOIN jns_users.branch_master           b ON bpm.branch_id = b.id
                                                                     WHERE
                                                                     bpm.branch_zo_id ='|| branchid||'
                                                                     AND bpm.business_id = '|| businesstypeid||'
                                                                     AND b.branch_type = 2
                                                        )
                                                ),
                                 ''activeBo'' value (SELECT COUNT(DISTINCT(bpm.branch_id))
                                                        FROM
                                                        jns_users.branch_product_mapping  bpm
                                                        LEFT JOIN jns_users.branch_master           b ON bpm.branch_id = b.id
                                                        WHERE
                                                        bpm.branch_ro_id IN(
                                                                SELECT DISTINCT(bpm.branch_id)
                                                                FROM
                                                                jns_users.branch_product_mapping bpm
                                                                INNER JOIN jns_users.branch_master b ON bpm.branch_id = b.id
                                                                WHERE
                                                                bpm.branch_zo_id = '|| branchid||'
                                                                AND bpm.business_id = '|| businesstypeid||'
                                                                AND b.branch_type = 2
                                                                AND bpm.business_id = '|| businesstypeid||'
                                                                )
                                                        ),
                                 ''status'' VALUE b.is_active,
                                 ''boDetails'' VALUE(
                                                    SELECT JSON_ARRAYAGG(JSON_OBJECT(
                                                         ''userId'' VALUE u.user_id,
                                                         ''userName'' VALUE concat(concat(jns_users."decvalue"(u.first_name),'' ''),jns_users."decvalue"(u.last_name)),
                                                         ''email'' VALUE jns_users."decvalue"(u.email),
                                                         ''mobile'' VALUE jns_users."decvalue"(u.mobile),
                                                         ''isActive'' VALUE u.is_active,
                                                         ''boName'' VALUE b.name,
                                                         ''boCode'' VALUE b.code,
														 ''ruralUrbanId'' value b.RURAL_URBAN_ID ,
                                                         ''boCity'' VALUE c.name,
                                                         ''boState'' VALUE s.name,
                                                         ''userType'' VALUE r.display_name,
                                                         ''roleName'' VALUE r.display_name
                                                     ) returning clob )
                                                    FROM jns_users.users u
                                                    LEFT JOIN jns_users.branch_master        b ON u.branch_id = b.id
                                                    LEFT JOIN jns_oneform.lgd_state    s ON b.state_id = s.id
                                                    LEFT JOIN jns_oneform.LGD_DISTRICT     c ON b.city_id = c.id
                                                    LEFT JOIN jns_users.user_role_master     r ON u.user_role_id = r.role_id
                                                    WHERE
                                                        u.branch_id IN(
                                                                SELECT
                                                                    DISTINCT(bpm.branch_id)
                                                                FROM
                                                                jns_users.branch_product_mapping  bpm
                                                                LEFT JOIN jns_users.branch_master           b ON bpm.branch_id = b.id
                                                                WHERE bpm.branch_ro_id IN(
                                                                     SELECT DISTINCT(bpm.branch_id)
                                                                     FROM
                                                                     jns_users.branch_product_mapping bpm
                                                                     INNER JOIN jns_users.branch_master b ON bpm.branch_id = b.id
                                                                     WHERE
                                                                        bpm.branch_zo_id = '|| branchid||'
                                                                        AND bpm.business_id = '|| businesstypeid||'
                                                                        AND b.branch_type = 2
                                                                        AND bpm.business_id = '|| businesstypeid||'
                                                                    )
                                                                )
                                                    )returning clob
                           ) returning clob )
    FROM
        jns_users.branch_master b
        LEFT JOIN jns_oneform.lgd_state s ON b.state_id = s.id
        LEFT JOIN jns_oneform.LGD_DISTRICT c ON b.city_id = c.id
    WHERE
        b.id = '|| branchid;
            dbms_output.put_line(query);

    EXECUTE
    IMMEDIATE
    query
      INTO result;
  END ;