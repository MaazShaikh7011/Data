CREATE OR REPLACE PROCEDURE JNS_USERS.FETCH_ALL_OFFICES_ROZO(userId in Number,orgId IN NUMBER,
  businessTypeId IN NUMBER,
  roleType IN NUMBER,
  noPagination IN VARCHAR2,
  paginationFROM IN VARCHAR2,
  paginationTO IN VARCHAR2,
  schemeId IN NUMBER,
  columnFilter IN CLOB,
   result out clob)
is
branchId number;
userRoleId number;
 selectCountQuery CLOB;
 tableQuery CLOB;
 whereClause  CLOB;
 totalCountQuery CLOB;
 orderBy CLOB;
 limitQuery CLOB;
totalcount number;
 selectDataQuery CLOB;
 finalQuery CLOB;
 mainQuery clob;

BEGIN

	SELECT branch_id,user_role_id INTO branchId, userRoleId FROM jns_users.users WHERE user_id = userId;

    selectCountQuery := ' SELECT COUNT(DISTINCT bpm.branch_id) ';

	selectDataQuery := ' bpm.branch_id AS branchId,bbm.code AS branchCode,bbm.name AS branchName,bbm.branch_type AS branchTypeId,bbm.contact_person_email AS email,bbm.telephone_no AS contactNo,
				bbm.contact_person_name AS contactPersonName,
				(SELECT COUNT(us.user_id) FROM jns_users.users us WHERE us.branch_id = bbm.id) as totalUsers,
				bbm.is_active as isActive,ct.city_name as city,
				st.state_name as state, bbm.street_name as address,bbm.pincode as pincode,bbm.ifsc_code as ifsc,
                ZO.id as zoBranchId,
				ZO.name as zoBranchName,
				ZO.code as zoBranchCode,
				RO.id as roBranchId,
				RO.name as roBranchName,
				RO.code as roBranchCode, ';

	tableQuery := ' INNER JOIN jns_users.branch_master bbm ON bbm.id = bpm.branch_id
					LEFT JOIN jns_users.branch_master RO ON RO.id = bpm.branch_ro_id
					LEFT JOIN jns_users.branch_master ZO ON ZO.id = bpm.branch_zo_id
					LEFT JOIN JNS_ONEFORM.city ct ON ct.id = bbm.city_id
					LEFT JOIN JNS_ONEFORM.state st ON st.id = bbm.state_id ';

	whereClause  := ' WHERE bbm.org_id = ' ||orgId ||' AND bpm.business_id = ' ||businessTypeId ||' AND bpm.sch_type_id = ' ||schemeId;

	IF userRoleId = 13 THEN

		IF roleType = 1 THEN
			tableQuery := ' FROM jns_users.branch_product_mapping bpm INNER JOIN jns_users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = ' ||roleType || tableQuery ;
		ELSIF roleType = 5 THEN

			tableQuery :=  ' FROM jns_users.branch_product_mapping bpm INNER JOIN jns_users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = 1 ' || tableQuery;
		END IF;

		whereClause  := whereClause ||' AND bpm.branch_ro_id = ' ||branchId;

	ELSIF userRoleId = 14 THEN
		IF roleType = 1 THEN
			tableQuery := ' FROM (
							SELECT DISTINCT bpmp1.branch_id , bm.branch_type AS branchTypeId, bpmp1.branch_ro_id, bpmp1.branch_zo_id, bm.org_id AS orgId,
							bpmp1.business_id, bpmp1.sch_type_id
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp1.branch_id AND branch_type = ' || roleType ||'
							WHERE bpmp1.branch_zo_id = ' ||branchId ||' AND bpmp1.sch_type_id = ' || schemeId ||'

							UNION ALL

							SELECT DISTINCT bpmp.branch_id, bm.branch_type AS branchTypeId, bpmp.branch_ro_id AS branchRoId, bpmp.branch_zo_id AS branchZoId, bm.org_id AS orgId,
							bpmp.business_id, bpmp.sch_type_id FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = ' || schemeId ||'
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp.branch_id AND branch_type = ' || roleType ||'
							WHERE bpmp1.branch_zo_id = ' ||branchId ||'  AND bpmp1.sch_type_id = ' || schemeId ||'
						) bpm ' || tableQuery;

		ELSIF roleType = 2 THEN

			tableQuery := ' FROM jns_users.branch_product_mapping bpm
							INNER JOIN jns_users.branch_master bm ON bm.id = bpm.branch_id AND branch_type = ' || roleType ||
							tableQuery;

			whereClause  := whereClause ||' AND bpm.branch_zo_id = ' ||branchId;

		ELSIF roleType = 5 THEN

			tableQuery := ' FROM (
							SELECT DISTINCT bpmp1.branch_id, bm.branch_type AS branchTypeId, bpmp1.branch_ro_id, bpmp1.branch_zo_id, bm.org_id AS orgId,
							bpmp1.business_id, bpmp1.sch_type_id
							FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp1.branch_id AND bm.branch_type IN(1,2)
							WHERE bpmp1.branch_zo_id = ' ||branchId ||' AND bpmp1.sch_type_id = ' || schemeId ||'

							 UNION ALL

							SELECT DISTINCT bpmp.branch_id, bm.branch_type AS roleTypeId, bpmp.branch_ro_id, bpmp.branch_zo_id, bm.org_id AS orgId,
							bpmp.business_id, bpmp.sch_type_id FROM jns_users.branch_product_mapping bpmp1
							INNER JOIN jns_users.branch_product_mapping bpmp ON bpmp.branch_ro_id = bpmp1.branch_ro_id AND bpmp.sch_type_id = ' || schemeId ||'
 							INNER JOIN jns_users.branch_master bm ON bm.id = bpmp.branch_id AND bm.branch_type IN(1,2)
							WHERE bpmp1.branch_zo_id = ' ||branchId ||'  AND bpmp1.sch_type_id = ' || schemeId ||'
						) bpm ' || tableQuery;

		END IF;

	END IF;

	IF roleType = 5 THEN -- ALL Branches
		selectDataQuery := selectDataQuery || ' CASE WHEN bbm.branch_type = 1 THEN ''Branch Office'' when bbm.branch_type = 2 then ''Regional Office'' when bbm.branch_type = 3  then ''Zonal Office'' else ''-'' end as roleType ';

	ELSIF roleType = 1 THEN  -- BO TYPE BRANCH

		selectDataQuery := selectDataQuery ||  '''Branch Office'' as roleType,
					(SELECT COUNT(us.user_id) FROM jns_users.users us WHERE us.user_role_id = 9 AND us.is_active = 1 AND us.branch_id = bbm.id) as branchChecker,
					(SELECT COUNT(us.user_id) FROM jns_users.users us WHERE us.user_role_id = 8 AND us.is_active = 1 AND us.branch_id = bbm.id) as branchMaker ';

		whereClause  := whereClause || ' AND bbm.branch_type = ' ||roleType;


	ELSIF roleType = 2 THEN -- RO TYPE BRANCH

		selectDataQuery := selectDataQuery || ' ''Regional Office'' as roleType ';

		whereClause  := whereClause || ' AND bbm.branch_type = ' ||roleType;


	ELSIF roleType = 3 THEN -- ZO TYPE BRANCH

		selectDataQuery := selectDataQuery || ' ''Zonal Office'' as roleType ';

		whereClause  := whereClause || ' AND bbm.branch_type = ' ||roleType;

	END IF;

	IF (JSON_VALUE(columnFilter,'$.fromDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate')  IS NOT NULL) THEN
		whereClause := whereClause || ' AND (DATE(us.created_date) BETWEEN ' || JSON_VALUE(columnFilter,'$.fromDate') || ' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||' OR DATE(us.modified_date) BETWEEN ' ||JSON_VALUE(columnFilter,'$.fromDate') ||' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||')';
	ELSIF (JSON_VALUE(columnFilter,'$.fromDate' )IS NOT NULL ) THEN
		whereClause := whereClause || ' AND DATE(us.created_date) = ' || JSON_VALUE(columnFilter,'$.fromDate');
	END IF;
--
    IF JSON_VALUE(columnFilter,'$.branchName') IS NOT NULL THEN
        whereclause := concat(whereclause, ' AND ( LOWER(bbm.name) LIKE ''%'
                                           || lower(JSON_VALUE(columnFilter,'$.branchName'))
                                           || '%''
                                              OR LOWER(bbm.code) LIKE ''%'
                                           || LOWER(JSON_VALUE(columnFilter,'$.branchName'))
                                           || '%'')');
    END IF;

    IF ((JSON_VALUE(columnFilter,'$.userRoleId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_role_id LIKE ''%' || JSON_VALUE(columnFilter,'$.userRoleId') ||'%'')
		';
    END IF;

     IF ((JSON_VALUE(columnFilter,'$.userTypeId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_type_id = ' || JSON_VALUE(columnFilter,'$.userTypeId') ||')
		';
    END IF;

         IF ((JSON_VALUE(columnFilter,'$.userOrgId') IS NOT NULL) AND roleType = 5) THEN
        whereClause := whereClause || ' AND (
            us.user_org_id = ' || JSON_VALUE(columnFilter,'$.userOrgId') ||')
		';
    END IF;

--    dbms_output.put_line(selectDataQuery);
		totalCountQuery :=  selectCountQuery || tableQuery || whereClause ;
   --   dbms_output.put_line(whereClause);
--      dbms_output.put_line(totalCountQuery);
-- SQLINES DEMO *** untQuery;
		EXECUTE IMMEDIATE  totalCountQuery into totalcount;
--    EXECUTE IMMEDIATE totalcountquery;

		orderBy := ' ORDER BY bbm.id DESC';

		IF (noPagination IS NOT NULL OR noPagination != '')
		THEN
		  limitQuery := ' ';
		ELSE
            limitQuery := ' OFFSET '
                   || paginationfrom
                   || ' ROWS FETCH NEXT '
                   || paginationto
                   || ' ROWS ONLY';
		END IF;

        finalQuery := 'SELECT Distinct ' || case WHEN totalCount is null then 0 else totalCount end||' AS totalCount, ' ||selectDataQuery || tableQuery || whereClause || orderBy
        || limitQuery
        ;
-- 		select @query;
--    dbms_output.put_line(finalQuery);

        mainQuery:='SELECT JSON_ARRAYAGG(JSON_OBJECT(''totalCount''VALUE totalCount,
''isActive'' VALUE isActive,
''branchName''VALUE branchName,
 ''branchCode''VALUE branchCode,
''city''VALUE city,
''state''VALUE state,
''totalUsers'' VALUE totalUsers,
''branchId'' VALUE branchId,
''branchTypeId'' VALUE branchTypeId,
                     ''zoBranchId''VALUE zoBranchId,
					 ''zoBranchName''VALUE zoBranchName,
					 ''zoBranchCode''VALUE zoBranchCode,
					 ''roBranchId''VALUE roBranchId,
					 ''roBranchName''VALUE roBranchName,
					 ''roBranchCod''VALUE roBranchCode)RETURNING CLOB) from ('||finalquery||')';
                      DBMS_OUTPUT.PUT_LINE(mainQuery);
		EXECUTE IMMEDIATE  mainQuery into result;

-- SQLINES DEMO *** rManagementFetchAllOfficesRoZo(75672,37,9,5,NULL,0,100,1,NULL)

	END;