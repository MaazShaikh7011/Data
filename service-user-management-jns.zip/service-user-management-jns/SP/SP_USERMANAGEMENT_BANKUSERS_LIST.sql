create or replace NONEDITIONABLE PROCEDURE             "SP_USERMANAGEMENT_BANKUSERS_LIST" ( orgId IN NUMBER, businessTypeId IN NUMBER, roleType IN NUMBER, noPagination IN VARCHAR2, paginationFROM IN CLOB, paginationTO IN CLOB, schemeId IN NUMBER, columnFilter IN CLOB,result out clob) IS

 selectCountQuery CLOB;
 tableQuery CLOB;
 whereClause  CLOB;
 totalCountQuery CLOB;
 orderBy CLOB;
 limitQuery CLOB;

 selectDataQuery CLOB;
 finalQuery CLOB;
BEGIN


	selectCountQuery := ' SELECT COUNT(*) INTO totalCount ';
	-- CONCAT(CAST((AES_DECRYPT(UNHEX(us.first_name),"C@p!ta@W0rld#AES")) AS CHAR)
	selectDataQuery := 'us.user_id as userId,us.first_name ," ",jns_jns_users.decValue(us.last_name)) as userName,jns_users.decValue(us.email) as email,
					jns_users.decValue(us.mobile) as mobile,us.sign_up_date as signupDate,CASE WHEN us.is_active THEN "true" ELSE "false" END as isActive,bh.id as branchId,bh.name as branchName,
					 bh.code as branchCode,ct.city_name as city,st.state_name as state,role.display_name as userType,us.user_role_id as roleTypeId,CASE WHEN us.is_locked THEN "true" ELSE "false" END as isLocked,
 					 (SELECT u.login_date FROM users.user_token_mapping u WHERE u.user_id = us.user_id ORDER BY u.id DESC LIMIT 1) as lastLogin,
					 ZO.id as zoBranchId,
					 ZO.name as zoBranchName,
					 ZO.code as zoBranchCode,
					 RO.id as roBranchId,
					 RO.name as roBranchName,
					 RO.code as roBranchCode';

	tableQuery := ' FROM users.users us
                    LEFT JOIN JNS_USERS.user_role_master role ON role.role_id = us.user_role_id
                    LEFT JOIN JNS_USERS.branch_master bh ON bh.id = us.branch_id
                    LEFT JOIN JNS_ONEFORM.city ct ON ct.id = bh.city_id
                    LEFT JOIN JNS_ONEFORM.state st ON st.id = bh.state_id
                    LEFT JOIN JNS_USERS.user_role_product_mapping m ON m.user_id = us.user_id
                    LEFT JOIN JNS_USERS.user_organisation_master um on um.user_org_id = us.user_org_id
                    LEFT JOIN JNS_USERS.branch_product_mapping BMAP ON BMAP.branch_id = us.branch_id AND BMAP.sch_type_id = 1
                    LEFT JOIN JNS_USERS.branch_master RO ON RO.id = BMAP.branch_ro_id
                    LEFT JOIN JNS_USERS.branch_master ZO ON ZO.id = BMAP.branch_zo_id  ';

	IF roleType = 1 THEN -- ALL USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		' AND m.user_role_id IN (5,8,9,12,13,14,17,10,11,15) AND us.user_type_id = 2 ';

	ELSIF roleType = 2 THEN  -- SQLINES DEMO *** R/CHECKER)
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		-- SQLINES DEMO *** e = TRUE AND m.is_active = TRUE AND m.user_role_id IN (10,11) ',
		' AND us.is_active = TRUE AND m.user_role_id IN (10,11) ';

	ELSIF roleType = 5 THEN -- HO USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		-- SQLINES DEMO *** e = TRUE AND m.is_active = TRUE AND m.user_role_id IN (5) ',
		' AND m.user_role_id IN (5) ';
	ELSIF roleType = 6 THEN -- ZO USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' and bh.branch_type = 3 AND bh.is_active AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		-- SQLINES DEMO *** e = TRUE AND m.is_active = TRUE AND m.user_role_id IN (14) ',
		' AND us.is_active = TRUE  AND m.user_role_id IN (14) ';
	ELSIF roleType = 7 THEN -- RO USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' and bh.branch_type = 2 AND bh.is_active AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		-- SQLINES DEMO *** e = TRUE AND m.is_active = TRUE AND m.user_role_id IN (13) ',
		' AND us.is_active = TRUE AND m.user_role_id IN (13) ';

	ELSIF roleType = 9 THEN -- BO USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' and bh.branch_type = 1 AND bh.is_active AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		-- SQLINES DEMO *** e = TRUE AND m.is_active = TRUE AND m.user_role_id IN (8,9) ',
		' AND m.user_role_id IN (9) ';

	ELSIF roleType = 8 THEN -- HO USERS
		whereClause  := ' WHERE us.user_org_id = ' ||orgId ||' and bh.branch_type = 6 AND bh.is_active AND m.business_id = ' ||businessTypeId ||
		' AND m.scheme_id = ' ||schemeId ||
		' AND us.is_active = TRUE  AND m.user_role_id IN (15) ';

	END IF;

--   For date RANGE
	IF (JSON_VALUE(columnFilter,'$.fromDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate') IS NOT NULL AND JSON_VALUE(columnFilter,'$.toDate')  IS NOT NULL) THEN
		whereClause := whereClause || ' AND (DATE(us.created_date) BETWEEN ' || JSON_VALUE(columnFilter,'$.fromDate') || ' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||' OR DATE(us.modified_date) BETWEEN ' ||JSON_VALUE(columnFilter,'$.fromDate') ||' AND ' || JSON_VALUE(columnFilter,'$.toDate') ||')';
	ELSIF (JSON_VALUE(columnFilter,'$.fromDate' )IS NOT NULL ) THEN
		whereClause := whereClause || ' AND DATE(us.created_date) = ' || JSON_VALUE(columnFilter,'$.fromDate');
	END IF;


	IF ((JSON_VALUE(columnFilter,'$.searchData') IS NOT NULL)) THEN
 		whereClause := whereClause || ' AND (
			jns_users.decValue(us.email) LIKE ''%' || JSON_VALUE(columnFilter,'$.searchData') ||'%''
			OR CONCAT(jns_users.decValue(us.first_name)," ",jns_users.decValue(us.last_name)) LIKE ''%' || JSON_VALUE(columnFilter,'$.searchData') ||'%''
		)';
	END IF;



		totalCountQuery :=  selectCountQuery || tableQuery || whereClause ;
        dbms_output.put_line(totalCountQuery);
-- SQLINES DEMO *** untQuery;
		EXECUTE IMMEDIATE  totalCountQuery;

		orderBy := ' ORDER BY us.user_id DESC';

		IF (noPagination IS NOT NULL AND noPagination != '')
		THEN
		  limitQuery := ' ';
		ELSE
		limitQuery := ' LIMIT ' || paginationFROM || ' , '  || paginationTO;
		END IF;

        finalQuery := 'SELECT ' ||' totalCount AS totalCount, ' ||selectDataQuery || tableQuery || whereClause || orderBy || limitQuery;
-- 		select @query;
    dbms_output.put_line(finalQuery);
		EXECUTE IMMEDIATE  finalQuery into result;
        dbms_output.put_line(result);

-- SQLINES DEMO *** rManagementBankUsersList(1, 1, 1, NULL, 0, 10, 1, '{}');
END SP_USERMANAGEMENT_BANKUSERS_LIST;