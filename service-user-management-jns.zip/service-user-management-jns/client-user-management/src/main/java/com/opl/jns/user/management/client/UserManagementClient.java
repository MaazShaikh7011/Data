package com.opl.jns.user.management.client;

import com.opl.jns.user.management.api.model.*;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

public class UserManagementClient {

    private static Logger logger = LoggerFactory.getLogger(UserManagementClient.class);
    private static final String GET_ORGANIZATION_NAME = "/v3/getOrganizationName";
    private static final String GET_ORGANIZATION_CODE = "/v3/getOrganizationCode";
    private static final String GET_BRANCH_NAME = "/v3/getBranchName";
    private static final String GET_BRANCH_ID_LIST = "/v3/getBranchIdList";
    private static final String GET_BRANCH_MAPPING_ID = "/v3/getBranchMappingIds";
    private static final String GET_BRANCH_MAPPING_ID_BY_IFSC_AND_SCHEME_ID = "/v3/getBranchMappingIdsByIfscAndSchemeId";
    private static final String GET_BRANCH_LIST_BASED_ON_ORG_ID = "/v3/getAllBranch";
    private static final String GET_ORGANISATION_DETAIL = "/v3/getOrganisationBasicDetails";
    private static final String REQ_AUTH = "req_auth";

    private String baseUrl;

    private RestTemplate restTemplate;

    public UserManagementClient(String baseUrl) {
        this.baseUrl = baseUrl;
        restTemplate = new RestTemplate();
    }

    public static void setClient(HttpHeaders headers) {
        headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.add("Accept", "application/json");
    }

    public CommonResponse getOrganizationName(Long orgId) {
        String url;
        url = baseUrl.concat(GET_ORGANIZATION_NAME) + "/" + orgId;

        logger.info("Enter in getOrganizationName()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Throw Exception While getOrganizationName ", e);
            return null;
        }
    }
    public CommonResponse getOrganizationCode(Long orgId) {
        String url;
        url = baseUrl.concat(GET_ORGANIZATION_CODE) + "/" + orgId;

        logger.info("Enter in getOrganizationName()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Throw Exception While getOrganizationName ", e);
            return null;
        }
    }
    public BranchAndOrgDetailsProxy getOrganisationDetails(Long orgId,Long branchId,Long insurerOrgId) {
        String url = baseUrl.concat(GET_ORGANISATION_DETAIL) + "/" + orgId + "/" + branchId + "/" + insurerOrgId;
        logger.info("Enter in GET_ORGANISATION_DETAIL()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            CommonResponse body = restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
            if(HttpStatus.OK.value() == body.getStatus() && !OPLUtils.isObjectNullOrEmpty(body.getData())){
                return MultipleJSONObjectHelper.getObjectFromMap((Map) body.getData(),BranchAndOrgDetailsProxy.class);
            }
        } catch (Exception e) {
            logger.error("Throw Exception While GET_ORGANISATION_DETAIL ", e);
        }
        return null;
    }
    public CommonResponse getBranchName(Long branchId) {
        String url;
        url = baseUrl.concat(GET_BRANCH_NAME) + "/" + branchId;

        logger.info("Enter in getOrganizationName()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Throw Exception While getOrganizationName ", e);
            return null;
        }
    }

    public List<Long> getBranchIdList(BranchRequestProxy branchRequestProxy) {
        String url;
        url = baseUrl.concat(GET_BRANCH_ID_LIST);

        logger.info("Enter in getBranchIdList()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            setClient(headers);
            HttpEntity<?> entity = new HttpEntity<>(branchRequestProxy, headers);
            CommonResponse commonResponse = restTemplate.exchange(url, HttpMethod.POST, entity, CommonResponse.class).getBody();
            if (!OPLUtils.isObjectNullOrEmpty(commonResponse)
                    && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())
                    && HttpStatus.OK.value() == commonResponse.getStatus()) {
                return MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), List.class);
            }
            return null;
        } catch (Exception e) {
            logger.error("Throw Exception While getOrganizationName ", e);
            return null;
        }
    }

    public Map<String, Object> getBranchMappingIds(Long branchId, Long schemeId) {
        String url = baseUrl.concat(GET_BRANCH_MAPPING_ID) + "/" + branchId + "/" + schemeId;
        logger.info("Enter in getBranchMappingIds()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            UserResponseProxy userResponseProxy = restTemplate.exchange(url, HttpMethod.GET, entity, UserResponseProxy.class).getBody();
            if (!OPLUtils.isObjectNullOrEmpty(userResponseProxy)
                    && !OPLUtils.isObjectNullOrEmpty(userResponseProxy.getData())
                    && HttpStatus.OK.value() == userResponseProxy.getStatus()) {
                return MultipleJSONObjectHelper.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(userResponseProxy.getData()));
            }
        } catch (Exception e) {
            logger.error("Throw Exception While getBranchMappingIds ", e );
        }
        return null;
    }
    
    public Map<String, Object> getBranchMappingByIfscCodeAndSchemeId(String ifsc, Long schemeId) {
        String url = baseUrl.concat(GET_BRANCH_MAPPING_ID_BY_IFSC_AND_SCHEME_ID) + "/" + ifsc + "/" + schemeId;
//    	String url = "http://localhost:8061/user-management/v3/getBranchMappingIdsByIfscAndSchemeId" + "/" + ifsc + "/" + schemeId;
        logger.info("Enter in getBranchMappingByIfscCodeAndSchemeId()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            UserResponseProxy userResponseProxy = restTemplate.exchange(url, HttpMethod.GET, entity, UserResponseProxy.class).getBody();
            if (!OPLUtils.isObjectNullOrEmpty(userResponseProxy)
                    && !OPLUtils.isObjectNullOrEmpty(userResponseProxy.getData())
                    && HttpStatus.OK.value() == userResponseProxy.getStatus()) {
                return MultipleJSONObjectHelper.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(userResponseProxy.getData()));
            }
        } catch (Exception e) {
            logger.error("Throw Exception While getBranchMappingByIfscCodeAndSchemeId ", e );
        }
        return null;
    }
    
    public List getBranchListBasedOnOrgId(Long userOrgId) {
        String url = baseUrl.concat(GET_BRANCH_LIST_BASED_ON_ORG_ID) + "/" + userOrgId;
        logger.info("Enter in getBranchListBasedOnOrgId()  ------------>" + url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(REQ_AUTH, "true");
            HttpEntity<?> entity = new HttpEntity<Object>(headers);
            UserResponseProxy userResponseProxy = restTemplate.exchange(url, HttpMethod.GET, entity, UserResponseProxy.class).getBody();
            if (!OPLUtils.isObjectNullOrEmpty(userResponseProxy)
                    && !OPLUtils.isObjectNullOrEmpty(userResponseProxy.getData())
                    && HttpStatus.OK.value() == userResponseProxy.getStatus()) {
                return MultipleJSONObjectHelper.getObjectFromString(MultipleJSONObjectHelper.getStringfromObject(userResponseProxy.getData()),List.class);
            }
        } catch (Exception e) {
            logger.error("Throw Exception While getBranchListBasedOnOrgId ", e );
        }
        return null;
    }
}
