package com.opl.jns.nabard.config.api.apiconfig.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.nabard.config.api.apiconfig.service.ClientMasterService;
import com.opl.jns.nabard.config.ere.domain.ClientAPIMap;
import com.opl.jns.nabard.config.ere.proxies.ClientAPIMapProxy;
import com.opl.jns.nabard.config.ere.repo.ClientAPIMapRepo;

@Service
@Slf4j
public class ClientMasterServiceImpl implements ClientMasterService {

	@Autowired
	private ClientAPIMapRepo apiMapRepo;

	@Override
	public List<ClientAPIMapProxy> fetchAll() {
		List<ClientAPIMap> clintAPIMapList = apiMapRepo.findByIsActiveTrue();
		List<ClientAPIMapProxy> apiMapProxies = new ArrayList<>(clintAPIMapList.size());
		clintAPIMapList.forEach(cltAPIMap -> {
			apiMapProxies.add(cltAPIMap.getProxy());
		});
		return apiMapProxies;
	}

}
