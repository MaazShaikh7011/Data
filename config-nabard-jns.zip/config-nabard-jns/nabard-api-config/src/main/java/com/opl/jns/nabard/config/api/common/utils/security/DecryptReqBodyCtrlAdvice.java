package com.opl.jns.nabard.config.api.common.utils.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.BoundedInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;

import com.opl.jns.nabard.config.ere.domain.ClientMaster;
import com.opl.jns.nabard.config.ere.enums.MetadataEnum;
import com.opl.jns.nabard.config.ere.proxies.RequestCommonProxy;
import com.opl.jns.nabard.config.ere.repo.ClientMasterRepo;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class DecryptReqBodyCtrlAdvice implements RequestBodyAdvice {

	@Autowired
	private ClientMasterRepo clientMasterRepo;

	@Override
	public boolean supports(MethodParameter methodParameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	@Override
	public HttpInputMessage beforeBodyRead(HttpInputMessage httpInputMsg, MethodParameter parameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) throws IOException {
		HttpServletRequest servletRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		/* SKIP SWAGGER URLS */
		if (servletRequest.getAttribute(SecurityUtility.REQ_ATR_IS_SWAGGER) != null) {
			return httpInputMsg;
		}

		/* SKIP ACTUATOR URLS */
		if (servletRequest.getAttribute(SecurityUtility.REQ_ATR_IS_ACTUATOR) != null) {
			return httpInputMsg;
		}

		Long apiUserId = SecurityUtility.getHeaderAttribute(servletRequest, SecurityUtility.REQ_ATR_APP_USER_ID,
				Long.class);
		log.info("apiUserId :: {} ", apiUserId);

		/* FETCH REQUETS DECRYPT BODY */
		String body = getBody(httpInputMsg);
		servletRequest.setAttribute(SecurityUtility.REQUEST_ENCRYPT_BODY, body);

		String decryptText = null;
		String auditDecryptText = null;
		if (decryptFlag(httpInputMsg)) { /* CHECK DECRYPT FLAG ON | OFF */
			decryptText = body;
			auditDecryptText = body;
		} else {
			/* FETCH API USER OBJECT BY API USER ID FOR DECRYPT */
			ClientMaster apiUser = clientMasterRepo.findById(apiUserId).get();

			/* DECRYPT REQUEST */
			decryptText = decryptReq(body, apiUser.getPublicKey(), servletRequest);
			if (OPLUtils.isObjectNullOrEmpty(decryptText)) {
				servletRequest.setAttribute(SecurityUtility.REQ_ATR_DEC_FAILED, Boolean.TRUE);
				servletRequest.setAttribute(SecurityUtility.RESPONSE_TIME, new Date().getTime());
//				throw new IOException("Exception while decrypt request body");
			} else {
				/* SET NULL VALUE IN LARGE OBJECT TO AVOID STORAGE ISSUE */
				auditDecryptText = decryptText;
			}
		}
		/* SET REQUEST PLAIN BODY IN REQUEST ATTBT */
		servletRequest.setAttribute(SecurityUtility.REQUEST_PLAIN_BODY, auditDecryptText);

		/* CAST FOR SETTING TOKEN IN CASE OF INVALID REQUEST PASSED */
		RequestCommonProxy requestForToken = MultipleJSONObjectHelper.getObjectFromString(auditDecryptText,
				RequestCommonProxy.class);
		if (!OPLUtils.isObjectNullOrEmpty(requestForToken)) {
			servletRequest.setAttribute(SecurityUtility.REQ_ATR_TOKEN, requestForToken.getToken());
		}

		ValidateHttpInputMessage validateHttpInputMessage = new ValidateHttpInputMessage(httpInputMsg);
		validateHttpInputMessage.setBody(IOUtils.toInputStream(decryptText, "UTF-8"));
		servletRequest.setAttribute(SecurityUtility.RESPONSE_TIME, new Date().getTime());
		return validateHttpInputMessage;
	}

	@Override
	public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) {
		// TODO Auto-generated method stub
		return body;
//		ObjectMapper objectMapper = new ObjectMapper();
//		try {
//			HttpServletRequest servletRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
//			
//			String data =String.valueOf(servletRequest.getAttribute(SecurityUtility.REQUEST_PLAIN_BODY));
////			converterType.getName()
//			
////			getClass().getSimpleName();
//			return objectMapper.readValue(data, converterType);
//		}catch (IOException e) {
//			e.printStackTrace();
//			log.error("Exception afterBodyRead " + e);
//			return null;
//		}
	}

	@Override
	public Object handleEmptyBody(Object body, HttpInputMessage inputMessage, MethodParameter parameter,
			Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
		// TODO Auto-generated method stub
		return body;
	}

	/**
	 * CHECK DECRYPT REQUEST FLAG ON | OFF
	 * 
	 * @param httpInputMsg
	 * @return
	 */
	private boolean decryptFlag(HttpInputMessage httpInputMsg) {
		HttpHeaders headers = httpInputMsg.getHeaders();

		if (headers.containsKey(SecurityUtility.REQ_HEADER_DECRYPTION_SKIP.toLowerCase()) && "true"
				.equals(headers.get(SecurityUtility.REQ_HEADER_DECRYPTION_SKIP.toLowerCase()).get(0).toString())) {
			return true;
		}
		if (headers.containsKey(SecurityUtility.REQ_AUTH)
				&& "true".equals(headers.get(SecurityUtility.REQ_AUTH).get(0).toString())) {
			return true;
		}
		return false;
	}

	/**
	 * FETCH REQUEST BODY
	 * 
	 * @param httpInputMessage
	 * @return
	 * @throws IOException
	 */
	private String getBody(HttpInputMessage httpInputMessage) throws IOException {
		if (httpInputMessage.getHeaders().getOrEmpty("Content-Type") != null && httpInputMessage.getHeaders()
				.getOrEmpty("Content-Type").contains(MediaType.MULTIPART_FORM_DATA_VALUE)) {
			StringBuilder requestBody = new StringBuilder();
			try (@SuppressWarnings("deprecation")
			InputStream bounded = new BoundedInputStream(httpInputMessage.getBody(), 1_048_576);
					BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bounded));) {
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					requestBody.append(line);
				}
				return String.valueOf(requestBody);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			return IOUtils.toString(httpInputMessage.getBody(), "UTF-8");
		}
		return null;
	}

	/**
	 * DECRYPT REQUEST
	 * 
	 * @param body
	 * @param publicKey
	 * @param reqLogs
	 * @return
	 */
	private String decryptReq(String body, String publicKey, HttpServletRequest servletRequest) {
		try {
			/* FETCH OPL INTERNAL USER FOR OPL PUBLIC KEY */
			ClientMaster oplUser = clientMasterRepo.findById(SecurityUtility.JNS_CLIENT_MASTER_ID).get();
			if (oplUser == null) {
				servletRequest.setAttribute(SecurityUtility.DECRYPTION_MSG, "OPL User Not Found While Decrypt Request");
				return null;
			}
			Long destOrgId=(Long) servletRequest.getAttribute(SecurityUtility.REQ_ATR_DEST_ORG);
			ClientMaster destOrg = clientMasterRepo.findByOrganizationMasterId(destOrgId);
			@SuppressWarnings("rawtypes")
			Map encDataMap = MultipleJSONObjectHelper.getObjectFromString(body, Map.class);
			if (!OPLUtils.isObjectNullOrEmpty(encDataMap) && !encDataMap.isEmpty()
					&& encDataMap.containsKey(MetadataEnum.getMetadataValueByTypeId(destOrg.getOrganizationMaster().getType()))) {
				String encryptedRequest = encDataMap.get(MetadataEnum.getMetadataValueByTypeId(destOrg.getOrganizationMaster().getType())).toString();
				return APIEncryptionUtility.decrypt(encryptedRequest, oplUser.getPrivateKey(), publicKey);
			} else {
				log.info("Request is not valid to decrypt");
				servletRequest.setAttribute(SecurityUtility.DECRYPTION_MSG, "Request is not valid to decrypt");
			}
		} catch (Exception e) {
			log.info("FAILED TO DECRYPT REQUEST:: ", e);
			servletRequest.setAttribute(SecurityUtility.DECRYPTION_MSG, e.getMessage());
		}
		return null;
	}

	class ValidateHttpInputMessage implements HttpInputMessage {
		HttpHeaders headers;
		InputStream body;

		public ValidateHttpInputMessage(HttpInputMessage httpInputMessage) {
			this.headers = httpInputMessage.getHeaders();

		}

		@Override
		public InputStream getBody() {
			return body;
		}

		@Override
		public HttpHeaders getHeaders() {
			return headers;
		}

		public void setBody(InputStream body) {
			this.body = body;
		}

		public void setHeaders(HttpHeaders headers) {
			this.headers = headers;
		}

	}

}
