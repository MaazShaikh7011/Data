package com.opl.jns.nabard.config.api.restcall.service.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.net.ssl.SSLException;

import com.opl.jns.nabard.config.ere.enums.OrganizationType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opl.jns.api.proxy.common.APIEncryptResponse;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.nabard.config.api.apiaudit.service.AuditMasterService;
import com.opl.jns.nabard.config.api.common.utils.Configuration;
import com.opl.jns.nabard.config.api.common.utils.security.APIEncryptionUtility;
import com.opl.jns.nabard.config.api.common.utils.security.SecurityUtility;
import com.opl.jns.nabard.config.api.restcall.service.RestAPIService;
import com.opl.jns.nabard.config.api.restcall.utils.ErrorUtils;
import com.opl.jns.nabard.config.ere.domain.APIStaticResponse;
import com.opl.jns.nabard.config.ere.domain.ClientMaster;
import com.opl.jns.nabard.config.ere.enums.APIType;
import com.opl.jns.nabard.config.ere.enums.MetadataEnum;
import com.opl.jns.nabard.config.ere.enums.SourceCallType;
import com.opl.jns.nabard.config.ere.proxies.APIAuditProxy;
import com.opl.jns.nabard.config.ere.proxies.ClientAPIMapProxy;
import com.opl.jns.nabard.config.ere.repo.APIStaticResponseRepo;
import com.opl.jns.nabard.config.ere.repo.ClientMasterRepo;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RestAPIServiceImpl implements RestAPIService {

	@Autowired
	private APIStaticResponseRepo apiStaticRespRepo;

	@Autowired
	private ClientMasterRepo clientMasterRepo;

	@Autowired
	private AuditMasterService auditMasterService;

	/**
	 * COMMON POST METHOD FOR CALLING JANSURAKSHA BANK AND INSURER API WITH AUDITS
	 */
	@Override
	public <T extends APIResponseV3> T post(Object plainReqObj, Long sourceOrgId, Long destOrgId, APIType apiId,
			T respClass, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory) {

		respClass.setFlag(false);

		Long orgId = destOrgId;
		
		String sourceToken = UUID.randomUUID().toString();

		/* SET ALL THE BASIC AUDIT DETAILS IN THE AUDIT REQUEST CLASS */
		APIAuditProxy apiAuditProxy = new APIAuditProxy();
		apiAuditProxy.setToken(referenceId);
		apiAuditProxy.setSourceToken(sourceToken);
		apiAuditProxy.setSourceType(SourceCallType.NABARD.getId());
		apiAuditProxy.setSourceOrgId(sourceOrgId);
		apiAuditProxy.setDestOrgId(destOrgId);
		apiAuditProxy.setCreatedDate(new Date());
		
		
		/* LOAD API CONFIGURATION BY API ID AND ORG ID */
		ClientAPIMapProxy apiConfig = Configuration.getAPIConfig(orgId, apiId);
		if (null == apiConfig) {
			apiAuditProxy.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			apiAuditProxy.setMessage(ErrorUtils.ERROR_CONFIGURATION("Bank/Insurer"));
			log.error("END BANK CONFIGURATION IS NOR FOUND FROM CONFIGURATION ----------"
					+ ErrorUtils.printLogs(orgId, apiId, referenceId));
			return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					ErrorUtils.ERROR_CONFIGURATION("Bank/Insurer"));
		}
		
		/**IF TEST MODE IS ON THEN FETCH MOCKOON RESPONSE*/
		ClientAPIMapProxy staticApiConfig = null;
		if(apiConfig.getClientMaster().isTestMode()) {
			staticApiConfig = Configuration.getAPIConfig(501l, apiId);
		}

		/* FETCH SOURCE NAME BY ORGANIZATION TYPE */
//		String source = apiConfig.getClientMaster().getOrganizationMaster().getType().toString();
		String source = OrganizationType.fromId(apiConfig.getClientMaster().getOrganizationMaster().getType()).getValue();
		Integer typeId = OrganizationType.fromId(apiConfig.getClientMaster().getOrganizationMaster().getType()).getId();

		apiAuditProxy.setClientId(apiConfig.getClientMaster().getId());
		apiAuditProxy.setClientMapId(apiConfig.getId());

		if (!OPLUtils.isObjectNullOrEmpty(apiConfig.getUrl()))
			apiAuditProxy.setContextPath(apiConfig.getUrl());
		else
			apiAuditProxy.setContextPath("URL NOT FOUND !");
		
		try {
			String url = getUrl(apiConfig.getClientMaster().isTestMode() ? staticApiConfig : apiConfig);
			apiAuditProxy.setRequestUrl(url);
			log.info("url : {}", url);
			/* CHECK IF TESTING MODE IS NOT OR NOT */
//			if (apiConfig.getClientMaster().isTestMode()) {
//				String staticRes = getStaticResponse(apiId.getId(), orgId);
//				if (!OPLUtils.isObjectNullOrEmpty(staticRes)) {
//					apiAuditProxy.setResponseStatus(HttpStatus.OK.value());
//					apiAuditProxy.setMessage("STATIC_RESPONSE");
//					apiAuditProxy.setPlainRes(staticRes);
//					apiAuditProxy.setPlainReq(MultipleJSONObjectHelper.getStringfromObject(plainReqObj));
//					apiAuditProxy.setEncypRes("STATIC_RESPONSE");
//					apiAuditProxy.setEncypReq("Static Joureny");
//					return MultipleJSONObjectHelper.getObjectFromString(staticRes, respClass.getClass());
//				}
//			}

			/* SET ALL HEADERS */
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (!OPLUtils.isObjectNullOrEmpty(apiConfig.getClientMaster().getHeaderConfig())) {
				headers.setAll(convertHeader(apiConfig.getClientMaster().getHeaderConfig()));
			}
			if (!OPLUtils.isObjectNullOrEmpty(additionalHeaders)) {
				headers.setAll(additionalHeaders);
			}

			HttpEntity<Object> entity = null;

			try {
				/* FETCH PLAIN REQUEST IN THE STRING FORMAT */
				String plainReq = MultipleJSONObjectHelper.getStringfromObject(plainReqObj);
				apiAuditProxy.setPlainReq(plainReq);
				apiAuditProxy
				.setRequestHeader(MultipleJSONObjectHelper.getStringfromObject(headers.toSingleValueMap()));
				if (apiConfig.getClientMaster().isTestMode()) {
					// CALL MOCKOON API (REQ AND RES IN THE PLAIN FORMAT)
					entity = new HttpEntity<>(plainReqObj, headers);
				} else {
					/* ENCRYPT REQUEST */
					String encryptedRequest = encryptReq(apiConfig, plainReq);
					apiAuditProxy.setEncypReq(encryptedRequest);

					/* CONVERT INTO META DATA FORM */
					Map<String, String> encryptedReq = new HashMap<>();
					encryptedReq.put(MetadataEnum.getMetadataValueByTypeId(typeId), encryptedRequest);
					entity = new HttpEntity<>(encryptedReq, headers);	
				}
			} catch (Exception e) {
				apiAuditProxy.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				apiAuditProxy.setMessage("ERROR_ENCRYPT: " + e.getMessage());
				log.error("END EXCEPTION WHILE ENCRYPT REQUEST ----------"
						+ ErrorUtils.printLogs(orgId, apiId, referenceId), e);
				apiAuditProxy.setError("Bank Error Msg - " + e.getMessage());
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.ERROR_ENCRYPT);
			}

			RestTemplate restTemplate = null;
			if (!OPLUtils.isObjectNullOrEmpty(requestFactory)) {
				restTemplate = new RestTemplate(requestFactory);
				// SET TIMEOUT FOR API CALL With CERTIFICATE
				setTimeOutWithCertificate(apiConfig, restTemplate);
			} else {
				restTemplate = new RestTemplate();
				// SET TIMEOUT FOR Normal API CALL
				setTimeOut(apiConfig, restTemplate);
			}
			ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			@SuppressWarnings("deprecation")
			String statusStg = String.valueOf(exchange.getStatusCodeValue());
			String body = exchange.getBody();
			apiAuditProxy.setEncypRes(body);
			apiAuditProxy.setModifiedDate(new Date());
			return handleResponse(apiConfig, apiAuditProxy, body, statusStg, referenceId, respClass, source);
		} catch (HttpStatusCodeException e) { // HANDLE ALL THE HTTP STATUS ERROR
			apiAuditProxy.setModifiedDate(new Date());
			@SuppressWarnings("deprecation")
			ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders())
					.body(e.getResponseBodyAsString());

			// HANDLE ERROR RESPONSE
			if (!OPLUtils.isObjectNullOrEmpty(resp.getBody())) {
				boolean contains = resp.getBody().contains(MetadataEnum.getMetadataValueByTypeId(typeId));
				if (contains) {
					return handleResponse(apiConfig, apiAuditProxy, resp.getBody(),
							e.getStatusCode() != null ? e.getStatusCode().toString() : null, referenceId, respClass,
							source);
				} else {
					if (apiConfig.getClientMaster().isTestMode()) {
						// NO NEED TO DECRYP RESPONSE
						apiAuditProxy.setPlainRes(resp.getBody());
						try {
							respClass = MultipleJSONObjectHelper.getObjectFromString(resp.getBody(),
									respClass.getClass());
							apiAuditProxy.setMessage("Mockoon Error Msg - " + e.getMessage());
							apiAuditProxy.setEncypRes(resp.getBody());
							apiAuditProxy.setError(e.getMessage());
							apiAuditProxy.setResponseStatus(e.getStatusCode().value());
							return reponse(respClass, respClass.getStatus(), respClass.getMessage());
						} catch (IOException e1) {
							log.error("END ERROR WHILE CALLING MOCKOON STATIC RESPONSE ---> " + e1.getMessage()
									+ " AND ----->" + ErrorUtils.printLogs(orgId, apiId, referenceId));
						}
					}
				}
			}
			apiAuditProxy.setMessage("Bank Error Msg - " + e.getMessage());
			apiAuditProxy.setEncypRes(resp.getBody());
			log.error("END ERROR WHILE CALLING BANK API STATUS ---> " + resp.getStatusCode().value()
					+ " AND BODY ----->" + resp.getBody() + ErrorUtils.printLogs(orgId, apiId, referenceId));
			apiAuditProxy.setError(e.getMessage());
			apiAuditProxy.setResponseStatus(e.getStatusCode().value());
			/* CHECK ALL THE STATUS ERROR */
			if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
				return reponse(respClass, e.getStatusCode().value(), ErrorUtils.ERROR_TIMEOUT(source));
			} else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
				return reponse(respClass, e.getStatusCode().value(), ErrorUtils.ERROR_FROM_SOURCE(source));
			} else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
				return reponse(respClass, e.getStatusCode().value(), ErrorUtils.ERROR_SERVICE_UNAVLBL(source));
			} else {
				return reponse(respClass, e.getStatusCode().value(), ErrorUtils.ERROR_FROM_SOURCE(source));
			}
		} catch (ResourceAccessException http) {
			log.info("http.getCause() TIMEOUT " + ErrorUtils.printLogs(orgId, apiId, referenceId), http.getCause());
			apiAuditProxy.setModifiedDate(new Date());
			apiAuditProxy.setMessage("Bank TIMEOUT Error Msg - " + http.getCause().getLocalizedMessage());
			apiAuditProxy.setError(http.getCause().getLocalizedMessage());
			if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
				apiAuditProxy.setResponseStatus(HttpStatus.GATEWAY_TIMEOUT.value());
				return reponse(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), ErrorUtils.ERROR_TIMEOUT(source));
			} else {
				apiAuditProxy.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.ERROR_500(source));
			}
		} catch (Exception e) {
			apiAuditProxy.setModifiedDate(new Date());
			apiAuditProxy.setError(e.getMessage());
			apiAuditProxy.setMessage("Bank Error Msg - " + e.getMessage());
			apiAuditProxy.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			log.error("EXCEPTION WHILE CALLING BANK API " + ErrorUtils.printLogs(orgId, apiId, referenceId), e);
			return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.ERROR_500(source));
		} finally {
			if (OPLUtils.isObjectNullOrEmpty(apiAuditProxy.getModifiedDate())) {
				apiAuditProxy.setModifiedDate(new Date());
			}
			
			auditMasterService.save(apiAuditProxy);
		}
	}

	private <T extends APIResponseV3> T handleResponse(ClientAPIMapProxy clientAPIMapProxy, APIAuditProxy auditReq,
			String body, String statusStg, String referenceId, T respClass, String source) {

		Long orgId = clientAPIMapProxy.getClientMaster().getOrganizationMaster().getId();
		APIType apiId = clientAPIMapProxy.getType();

		if (OPLUtils.isObjectNullOrEmpty(body)) {
			auditReq.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			auditReq.setMessage("Found Blank Response Body " + statusStg);
			log.error("END FOUND RESPONSE BODY NULL " + ErrorUtils.printLogs(orgId, apiId, referenceId));
			return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.INVALID_RESPONSE(source));
		}
		try {
			if (clientAPIMapProxy.getClientMaster().isTestMode()) {
				// NO NEED TO DECRYP RESPONSE
				auditReq.setPlainRes(body);
				respClass = MultipleJSONObjectHelper.getObjectFromString(body, respClass.getClass());
			} else {
				String decryptResp = "";
				APIEncryptResponse apiResp = MultipleJSONObjectHelper.getObjectFromString(body, APIEncryptResponse.class);
				if (OPLUtils.isObjectNullOrEmpty(apiResp.getMetadata())) {
					auditReq.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setMessage("Response Metadata null " + statusStg);
					log.error("END FOUND RESPONSE METADATA NULL " + ErrorUtils.printLogs(orgId, apiId, referenceId));
					return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							ErrorUtils.INVALID_RESPONSE(source));
				}
				decryptResp = decryptRes(clientAPIMapProxy, apiResp.getMetadata());
				if (OPLUtils.isObjectNullOrEmpty(decryptResp)) {
					auditReq.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setMessage("Response null after decrypt payload " + statusStg);
					log.error("END RESPONSE NULL AFTER DECRYPT PAYLOAD " + ErrorUtils.printLogs(orgId, apiId, referenceId));
					return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							ErrorUtils.INVALID_RESPONSE(source));
				}
				auditReq.setPlainRes(decryptResp);
				respClass = MultipleJSONObjectHelper.getObjectFromString(decryptResp, respClass.getClass());
			}
			
			if (!OPLUtils.isObjectNullOrEmpty(respClass.getStatus())) {
				respClass.setFlag(true);
				auditReq.setResponseStatus(respClass.getStatus());
				auditReq.setMessage(respClass.getMessage());
				if (respClass.getStatus() != HttpStatus.OK.value()) {
					respClass.setMessage(ErrorUtils.SOURCE_ERROR(source) + respClass.getMessage());
				}
				log.info("END SUCCESS RESPONSE  " + ErrorUtils.printLogs(orgId, apiId, referenceId) + " CODE ---"
						+ respClass.getStatus() + "----MESSAGE----" + respClass.getMessage());
				/** CHECK REQUEST AND RESPONSE TOKEN SAME OR NOT FOR PHASE 2 */
				T isValid = tokenAndTimeStampValidCheck(orgId, apiId, referenceId, respClass, auditReq,
						source);
				if (!OPLUtils.isObjectNullOrEmpty(isValid)) {
					auditReq.setError(isValid.getMessage());
					return isValid;
				}
				return respClass;
			} else {
				auditReq.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				auditReq.setMessage("Not Found Response Status " + statusStg);
				log.error("END FOUND RESPONSE NULL STATUS " + ErrorUtils.printLogs(orgId, apiId, referenceId));
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						ErrorUtils.INVALID_RESPONSE(source));
			}

		} catch (Exception e) {
			auditReq.setResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			auditReq.setMessage("ERROR_DECRYPT: " + e.getMessage());
			auditReq.setError("Bank ERROR_DECRYPT Msg : - " + e.getMessage());
			log.error("END EXCEPTION WHILE DECRYPT REQUEST " + ErrorUtils.printLogs(orgId, apiId, referenceId), e);
			return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.ERROR_DECRYPT);
		}
	}

	private <T extends APIResponseV3> T tokenAndTimeStampValidCheck(Long orgId, APIType apiId,
			String referenceId, T respClass, APIAuditProxy auditReq, String source) {

		try {
//			APIResponseV3 bankApiResObj = MultipleJSONObjectHelper.getObjectFromString(body, APIResponseV3.class);

			if (OPLUtils.isObjectNullOrEmpty(respClass)) {
				log.error("RESPONSE IS NULL" + ErrorUtils.printLogs(orgId, apiId, referenceId));
				auditReq.setMessage("Bank Error Msg : - RESPONSE IS NULL");
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.NULL_RESPONSE(source));
			}

			if (OPLUtils.isObjectNullOrEmpty(respClass.getTimestamp())) {
				log.error("RESPONSE TIMESTAMP IS NULL" + ErrorUtils.printLogs(orgId, apiId, referenceId));
				auditReq.setMessage("Bank Error Msg : - RESPONSE TIMESTAMP IS NULL");
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						ErrorUtils.NULL_TIMESTAMP_RESPONSE(source));
			}

			if (!OPLUtils.isObjectNullOrEmpty(respClass.getToken())) {
				if (!auditReq.getToken().equals(respClass.getToken())) {
					log.error("REQUEST AND RESPONSE TOKEN IS DIFFERENT"
							+ ErrorUtils.printLogs(orgId, apiId, referenceId));
					auditReq.setMessage("Bank Error Msg : - REQUEST AND RESPONSE TOKEN IS DIFFERENT - "
							+ auditReq.getToken() + " Not Eq " + respClass.getToken());
					return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							ErrorUtils.TOKEN_NOT_MATCH(source));
				}
			} else {
				log.error("RESPONSE TOKEN IS NULL" + ErrorUtils.printLogs(orgId, apiId, referenceId));
				auditReq.setMessage("Bank Error Msg : - RESPONSE TOKEN IS NULL");
				return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						ErrorUtils.NULL_TOKEN_RESPONSE(source));
			}
		} catch (Exception e) {
			log.error("RESPONSE TOKEN PARSE ERROR" + ErrorUtils.printLogs(orgId, apiId, referenceId));
			auditReq.setMessage("Bank TOKEN PARSE & TIMESTAMP Msg : - " + e.getMessage());
			return reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorUtils.ERROR_PARSE_TOKEN(source));
		}
		return null;
	}

	private void setTimeOutWithCertificate(ClientAPIMapProxy apiConfig, RestTemplate restTemplate) {
		Integer readTimeOut = apiConfig.getReadTimeOut();
		Integer conTimeOut = apiConfig.getConTimeOut();
		if (!OPLUtils.isObjectNullOrEmpty(conTimeOut)) {
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(conTimeOut * 1000);
		}
		if (!OPLUtils.isObjectNullOrEmpty(readTimeOut)) {
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeOut * 1000);
		}
	}

	private void setTimeOut(ClientAPIMapProxy apiConfig, RestTemplate restTemplate) {
		Integer readTimeOut = apiConfig.getReadTimeOut();
		Integer conTimeOut = apiConfig.getConTimeOut();
		if (!OPLUtils.isObjectNullOrEmpty(conTimeOut)) {
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(conTimeOut * 1000);
		}
		if (!OPLUtils.isObjectNullOrEmpty(readTimeOut)) {
			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeOut * 1000);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Map<String, String> convertHeader(String value) throws IOException {
		return value != null ? (Map) (new ObjectMapper()).readValue(value, Map.class) : null;
	}

	private String getUrl(ClientAPIMapProxy apiMapProxy) {
		if (OPLUtils.isObjectNullOrEmpty(apiMapProxy.getClientMaster().getBaseUrl())) {
			return apiMapProxy.getUrl();
		}
		return apiMapProxy.getClientMaster().getBaseUrl().concat(apiMapProxy.getUrl());
	}

	private static <T extends APIResponseV3> T reponse(T classType, Integer status, String message) {
		classType.setStatus(status);
		classType.setMessage(message);
		return classType;
	}

	private String decryptRes(ClientAPIMapProxy apiConfig, String response)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException,
			BadPaddingException, SignatureException, InvalidAlgorithmParameterException, NoSuchProviderException,
			InvalidKeySpecException, CertificateException, IOException {
		ClientMaster oplUser = clientMasterRepo.findById(SecurityUtility.JNS_CLIENT_MASTER_ID).get();
		return APIEncryptionUtility.decrypt(response, oplUser.getPrivateKey(),
				apiConfig.getClientMaster().getPublicKey());
	}

	private String encryptReq(ClientAPIMapProxy apiConfig, String request)
			throws InvalidKeyException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			SignatureException, UnsupportedEncodingException, NoSuchProviderException {
		ClientMaster oplUser = clientMasterRepo.findById(SecurityUtility.JNS_CLIENT_MASTER_ID).get();
		return APIEncryptionUtility.encrypt(request, oplUser.getPrivateKey(),
				apiConfig.getClientMaster().getPublicKey());

	}

	/**
	 * FETCH STATIC RESPONSE BY API ID AND ORG ID
	 * 
	 * @param apiId
	 * @param orgId
	 * @return
	 */
	private String getStaticResponse(Integer apiId, Long orgId) {
		APIStaticResponse apiResponse = apiStaticRespRepo
				.findByOrgIdAndApiId(!OPLUtils.isObjectNullOrEmpty(orgId) ? orgId : -1l, Long.valueOf(apiId));
		if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
			return apiResponse.getSampleJson();
		} else {
			return apiStaticRespRepo.findByOrgIdAndApiId(-1l, Long.valueOf(apiId)).getSampleJson();
		}
	}

}
