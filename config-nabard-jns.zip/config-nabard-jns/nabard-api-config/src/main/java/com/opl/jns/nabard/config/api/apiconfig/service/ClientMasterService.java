package com.opl.jns.nabard.config.api.apiconfig.service;

import java.util.List;

import com.opl.jns.nabard.config.ere.proxies.ClientAPIMapProxy;

public interface ClientMasterService {

	public List<ClientAPIMapProxy> fetchAll();

}
