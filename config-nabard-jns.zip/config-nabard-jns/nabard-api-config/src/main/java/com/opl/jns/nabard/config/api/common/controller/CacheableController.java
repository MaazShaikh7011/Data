//package com.opl.jns.nabard.config.updated.common.controller;
//
//import java.util.Date;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.CacheManager;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.opl.jns.nabard.config.updated.common.utils.security.SkipInterceptor;
//
//@RestController
//public class CacheableController {
//
//	private static final Logger logger = LoggerFactory.getLogger(CacheableController.class);
//	@Autowired
//	private CacheManager cacheManager;
//
//	@SkipInterceptor
//	@GetMapping(value = "/clearCache")
//	public String clearCache() {
//		for (String name : cacheManager.getCacheNames()) {
//			cacheManager.getCache(name).clear();
//			logger.info("{} Cache Cleared", name);
//		}
//		logger.info("All Cache Cleared On {}", new Date());
//		return "All Cache Cleared";
//	}
//
//}
