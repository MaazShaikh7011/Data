package com.opl.jns.nabard.config.api.apiaudit.service.impl;

import com.opl.jns.nabard.config.api.apiaudit.service.AuditMasterService;
import com.opl.jns.nabard.config.ere.bucketconfig.service.BucketService;
import com.opl.jns.nabard.config.ere.domain.AuditMaster;
import com.opl.jns.nabard.config.ere.proxies.APIAuditProxy;
import com.opl.jns.nabard.config.ere.proxies.ReqResBucketProxy;
import com.opl.jns.nabard.config.ere.repo.AuditMasterRepo;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 * API AUDIT FOR BANK, INSURER AND JANSURAKSHA
 * 
 * @author harshit.suhagiya
 *
 */
@Service
@Slf4j
public class AuditMasterServiceImpl implements AuditMasterService {

	@Autowired
	private AuditMasterRepo auditMasterRepo;

	@Autowired
	private BucketService bucketService;

	/**
	 * SAVE API AUDIT DATA INTO DATABASE AND S3 BUCKET
	 */
	public void save(APIAuditProxy apiAuditProxy) {
		try {
			
			AuditMaster auditMaster  = saveAuditDetailsInDB(apiAuditProxy);
			saveAuditDetailsInBucket(auditMaster,apiAuditProxy);
			
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVE AUDIT --------------->", e);
		}
	}

	/**
	 * SAVE API AUDIT DATA INTO S3 BUCKET  
	 */
	private void saveAuditDetailsInBucket(AuditMaster auditMaster, APIAuditProxy apiAuditProxy) {

		try {
			ReqResBucketProxy bucketProxy = (ReqResBucketProxy) apiAuditProxy;
			bucketProxy.setResponseTime(auditMaster.getResponseTime());
			bucketProxy.setId(auditMaster.getId());
			bucketProxy.setRequestDate(convertDate(auditMaster.getCreatedDate()));
			bucketProxy.setClientId(apiAuditProxy.getClientId());
			bucketProxy.setClientMapId(apiAuditProxy.getClientMapId());
			bucketProxy.setSourceOrgId(apiAuditProxy.getSourceOrgId());
			bucketProxy.setDestOrgId(apiAuditProxy.getDestOrgId());
			bucketService.uploadObject(bucketProxy, auditMaster.getStorageId());
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVE AUDIT DETAILS IN S3 BUCKET--------------->", e);
		}
		
	}

	/**
	 * SAVE API AUDIT DATA INTO DATABASE
	 */
	private AuditMaster saveAuditDetailsInDB( APIAuditProxy apiAuditProxy) {
		AuditMaster auditMaster = new AuditMaster();
		try {
			auditMaster.setClientId(apiAuditProxy.getClientId());
			auditMaster.setClientMapId(apiAuditProxy.getClientMapId());
			auditMaster.setSourceOrgId(apiAuditProxy.getSourceOrgId());
			auditMaster.setDestOrgId(apiAuditProxy.getDestOrgId());
			auditMaster.setCreatedDate(apiAuditProxy.getCreatedDate());
			auditMaster.setModifiedDate(apiAuditProxy.getModifiedDate());
			auditMaster.setMessage(!OPLUtils.isObjectNullOrEmpty(apiAuditProxy.getMessage())
					? apiAuditProxy.getMessage().substring(0, Math.min(apiAuditProxy.getMessage().length(), 400))
					: null);
			auditMaster.setRequestIp(apiAuditProxy.getRequestIp());
			auditMaster.setContextPath(apiAuditProxy.getContextPath());
			auditMaster.setResponseStatus(apiAuditProxy.getResponseStatus());
			auditMaster.setToken(apiAuditProxy.getToken());
			auditMaster.setSourceToken(apiAuditProxy.getSourceToken());
			auditMaster.setSourceType(apiAuditProxy.getSourceType());
			auditMaster.setResponseTime(
					apiAuditProxy.getModifiedDate().getTime() - apiAuditProxy.getCreatedDate().getTime());
			auditMaster.setStorageId(UUID.randomUUID().toString());
			auditMaster = auditMasterRepo.save(auditMaster);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVE AUDIT DETAILS IN DB--------------->", e);
		}
		return auditMaster;
	}

	private String convertDate(Date date) {
		String pattern = "dd/MM/yyyy HH:mm:ss";
		DateFormat df = new SimpleDateFormat(pattern);
		return df.format(date);
	}

}
