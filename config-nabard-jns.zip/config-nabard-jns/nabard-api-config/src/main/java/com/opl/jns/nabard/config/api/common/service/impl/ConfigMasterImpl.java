package com.opl.jns.nabard.config.api.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.nabard.config.api.common.service.ConfigMasterService;
import com.opl.jns.nabard.config.ere.proxies.ConfigMasterProxy;
import com.opl.jns.nabard.config.ere.repo.ConfigMasterRepo;

/**
 * CONFIGURE PROPERTIES AGAINS KEY IN THE COMMON TABLE
 * 
 * @author harshit.suhagiya
 *
 */
@Service
public class ConfigMasterImpl implements ConfigMasterService {

	@Autowired
	private ConfigMasterRepo configMasterRepo;

	/**
	 * LOAD ALL THE PROPERTIES FROM DATABASE
	 */
	public List<ConfigMasterProxy> fetchAll() {
		return configMasterRepo.findAllByIsActiveTrue().stream()
				.map(conf -> new ConfigMasterProxy(conf.getId(), conf.getCode(), conf.getValue(), conf.getIsActive()))
				.toList();
	}

}
