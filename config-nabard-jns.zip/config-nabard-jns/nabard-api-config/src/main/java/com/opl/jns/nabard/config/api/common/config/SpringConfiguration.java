package com.opl.jns.nabard.config.api.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.opl.jns.nabard.config.api.common.utils.security.AuthenticationInterceptor;

@Configuration
@EnableAsync
public class SpringConfiguration implements WebMvcConfigurer {

	@Bean
	AuthenticationInterceptor authenticationInterceptor() {
		return new AuthenticationInterceptor();
	}

	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(authenticationInterceptor()).addPathPatterns("/**");
	}

}
