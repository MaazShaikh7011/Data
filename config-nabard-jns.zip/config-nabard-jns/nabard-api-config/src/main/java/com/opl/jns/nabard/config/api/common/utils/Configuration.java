package com.opl.jns.nabard.config.api.common.utils;

import com.opl.jns.nabard.config.api.apiconfig.service.ClientMasterService;
import com.opl.jns.nabard.config.api.common.service.ConfigMasterService;
import com.opl.jns.nabard.config.ere.enums.APIType;
import com.opl.jns.nabard.config.ere.enums.ConfigMasterCodes;
import com.opl.jns.nabard.config.ere.proxies.ClientAPIMapProxy;
import com.opl.jns.nabard.config.ere.proxies.ConfigMasterProxy;
import com.opl.jns.nabard.config.ere.repo.ConfigMasterRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * CONFIGURE ALL THE PROPERTIES IN THE JAVA OBJECT FROM DATABASE
 * 
 * @author harshit.suhagiya
 *
 */
@Component
@Slf4j
public class Configuration {

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private ClientMasterService clientMasterService;

	@Autowired
	private ConfigMasterService configMasterService;

	@Autowired
	private ConfigMasterRepo configMasterRepo;

	private static List<ConfigMasterProxy> CONFIG_MASTER_PROXIES = new ArrayList<>();

	private static List<ClientAPIMapProxy> API_MAP_PROXIES = new ArrayList<>();

	/**
	 * LOAD ALL THE COMMON AND API CONFIGURATION FROM DATABASE
	 * 
	 * @throws Exception
	 */
	@EventListener(ApplicationReadyEvent.class)
	public void loadConfiguration() throws Exception {
		log.info("START LOADING CONFIGURATION FROM DATABASE ---------------> ");
		loadConfig();
		loadAPIConfig();
//		loadBucket();
		log.info("END LOADING CONFIGURATION FROM DATABASE ---------------> ");
	}

	public static String getConfigByCode(ConfigMasterCodes code) {
		return CONFIG_MASTER_PROXIES.stream().filter(a -> a.getCode().equalsIgnoreCase(code.name())).findFirst()
				.orElse(null).getValue();

	}

	public static ClientAPIMapProxy getAPIConfig(Long orgId, APIType apiType) {
		return API_MAP_PROXIES.stream().filter(a -> a.getClientMaster().getOrganizationMaster().getId().equals(orgId)
				&& a.getType().name().equalsIgnoreCase(apiType.name())).findFirst().orElse(null);

	}

	/**
	 * BUCKET CONFIGURATION LOAD
	 * 
	 * @return
	 * @throws Exception
	 */
//	@Bean
//	private BucketConfigProxy loadBucket() throws Exception {
//		BucketConfigProxy bucketConfig = new BucketConfigProxy();
//		try {
//			ConfigMaster config = configMasterRepo
//					.findByCodeAndIsActiveTrue(ConfigMasterCodes.BUCKET_CONFIG.toString());
//			if (OPLUtils.isObjectNullOrEmpty(config) || OPLUtils.isObjectNullOrEmpty(config.getValue())) {
//				log.error("BUCKET CONFIGURATION IS NULL OR EMPTY");
//				throw new Exception("BUCKET CONFIGURATION NOT FOUND FROM COMMON CONFIG CLASS");
//			}
//			bucketConfig = MultipleJSONObjectHelper.getObject(config.getValue(), BucketConfigProxy.class);
//			bucketConfig.setAmazonS3(AmazonS3ClientBuilder.defaultClient());
//			applicationContext.getAutowireCapableBeanFactory().autowireBean(bucketConfig);
//		} catch (Exception e) {
//			log.error("EXCEPTION WHILE LOAD BUCKET CONFIGURATION ----> " + e.getMessage());
//			throw e;
//		}
//		return bucketConfig;
//	}

	/**
	 * LOAD AND SET COMMON CONFIGURATION
	 * 
	 * @throws Exception
	 */
	private void loadConfig() throws Exception {
		log.info("1. START LOAD CONFIGURATION ------------------------>");
		CONFIG_MASTER_PROXIES = configMasterService.fetchAll();
		if (CONFIG_MASTER_PROXIES.isEmpty()) {
			throw new Exception("1. EXCEPTION WHILE LOADING CONFIGURATION");
		}
		log.info("1. END LOAD CONFIGURATION ------------------------>");
	}

	/**
	 * LOAD AND SET API CONFIGURATION
	 * 
	 * @throws Exception
	 */
	private void loadAPIConfig() throws Exception {
		log.info("2. START LOAD API CONFIGURATION ------------------------>");
		API_MAP_PROXIES = clientMasterService.fetchAll();
		if (API_MAP_PROXIES.isEmpty()) {
			throw new Exception("2. EXCEPTION WHILE LOADING API CONFIGURATION");
		}
		log.info("2. END LOAD API CONFIGURATION ------------------------>");
	}

}
