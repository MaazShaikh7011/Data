package com.opl.jns.nabard.config.api.common.utils.dbconfig;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.DataSourceProvider;
import com.opl.jns.utils.enums.ENVMode;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = { PersistenceContext.$_COM_JNS_SERVICE_REPOSITORY_PACKAGE,
		"com.opl.jns.nabard.config.updated" }, entityManagerFactoryRef = "emFR", transactionManagerRef = "tmr")
public class PersistenceContext {

	public static final String $_COM_JNS_SERVICE_REPOSITORY_PACKAGE = "${com.jns.service.repository-package}";
	public static final String MYSQL_JDBC_DRIVER = "com.mysql.jdbc.Driver";
	public static final String ORG_HIBERNATE_DIALECT_MYSQL_DIALECT = "org.hibernate.dialect.MySQL8Dialect";
	public static final String ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY = "org.hibernate.cfg.ImprovedNamingStrategy";
	public static final String HIBERNATE_HQL_BULK_ID_STRATEGY = "hibernate.hql.bulk_id_strategy";
	public static final String ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY = "org.hibernate.hql.spi.id.inline.InlineIdsOrClauseBulkIdStrategy";
	public static final String NONE = "none";
	public static final String CREATE = "create";
	public static final String UPDATE = "update";
	public static final String SELECT_1_FROM_DUAL = "SELECT 1";
	private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	private static final String PROPERTY_NAME_HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
	private static final String PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
	private static final String PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY = "hibernate.ejb.naming_strategy";
	private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_NAME_HIBERNATE_LAZY_LOAD = "hibernate.enable_lazy_load_no_trans";
	private static final String ENTITY_MANAGER_REFERENCE = "emFR";
	private static final String DATASTORE = "dsEcr";
	private static final String TRANSACTION_MANAGER_REFERENCE = "tmr";

	@Autowired
	private ApplicationProperties properties;

	@Bean(name = DATASTORE)
	@Primary
	public DataSource dataSource() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setDriverClassName(MYSQL_JDBC_DRIVER);
		System.out.println("-------------------------DB-MAIN - MYSQL------------------>"
				+ DataSourceProvider.getDatabaseURL() + properties.getDbName());
		System.out.println("-------------------------User/Pwd - MYSQL------------------>" + properties.getUserName()
				+ "/" + properties.getDbPass());
		dataSource.setJdbcUrl(DataSourceProvider.getDatabaseURL() + properties.getDbName());
		dataSource.setUsername(properties.getUserName());
		dataSource.setPassword(properties.getDbPass());
		dataSource.setConnectionTestQuery(SELECT_1_FROM_DUAL);
		dataSource.setMaximumPoolSize(Integer.parseInt(properties.getDbMaxConnections()));
		dataSource.setMaxLifetime(Long.parseLong(properties.getDbMaxLifetimeInMillis()));
		dataSource.setConnectionTimeout(Long.parseLong(properties.getDbConnectionTimeoutInMillis()));

		if (!OPLUtils.isObjectNullOrEmpty(properties.getDbMinimumIdle())) {
			dataSource.setMinimumIdle(Integer.parseInt(properties.getDbMinimumIdle()));
		}
		if (!OPLUtils.isObjectNullOrEmpty(properties.getDbMaximumpoolsize())) {
			dataSource.setMaximumPoolSize(Integer.parseInt(properties.getDbMaximumpoolsize()));
		}
		if (!OPLUtils.isObjectNullOrEmpty(properties.getDbIdelTimeout())) {
			dataSource.setIdleTimeout(Integer.parseInt(properties.getDbIdelTimeout()));
		}

		return dataSource;
	}

	@Bean(name = TRANSACTION_MANAGER_REFERENCE)
	@DependsOn(DATASTORE)
	@Primary
	public JpaTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return transactionManager;
	}

	@Bean(name = ENTITY_MANAGER_REFERENCE)
	@DependsOn(DATASTORE)
	@Primary
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

		entityManagerFactoryBean.setDataSource(dataSource());
		entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		entityManagerFactoryBean.setPackagesToScan(properties.getDomainPackageName(),
				"com.opl.jns.nabard.config.updated");

		Properties jpaProperties = new Properties();
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_DIALECT, ORG_HIBERNATE_DIALECT_MYSQL_DIALECT);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_FORMAT_SQL, properties.getHibernateFormatSql());
		ENVMode envMode = DataSourceProvider.getEnvMode();
		if (envMode.equals(ENVMode.P)) {
			// To prevent unwanted DDL Operation in database on Production.
			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO, NONE);
		} else {
			if (properties.getHibernateHbm2ddl().equals(CREATE)) {
				properties.setHibernateHbm2ddl(UPDATE);
			}
			jpaProperties.put(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO, properties.getHibernateHbm2ddl());
		}

		jpaProperties.put(PROPERTY_NAME_HIBERNATE_NAMING_STRATEGY, ORG_HIBERNATE_CFG_IMPROVED_NAMING_STRATEGY);
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL, properties.getHibernateShowSql());
		jpaProperties.put(PROPERTY_NAME_HIBERNATE_LAZY_LOAD, properties.getHibernateEnableLazyLoadNoTrans());
		jpaProperties.put(HIBERNATE_HQL_BULK_ID_STRATEGY,
				ORG_HIBERNATE_HQL_SPI_ID_INLINE_INLINE_IDS_OR_CLAUSE_BULK_ID_STRATEGY);
		entityManagerFactoryBean.setJpaProperties(jpaProperties);
		return entityManagerFactoryBean;
	}
}
