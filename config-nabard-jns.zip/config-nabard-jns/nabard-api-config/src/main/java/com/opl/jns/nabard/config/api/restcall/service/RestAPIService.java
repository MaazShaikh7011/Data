package com.opl.jns.nabard.config.api.restcall.service;

import java.util.Map;

import org.springframework.http.client.ClientHttpRequestFactory;

import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.nabard.config.ere.enums.APIType;

public interface RestAPIService {

	public <T extends APIResponseV3> T post(Object plainReqObj, Long sourceOrgId, Long destOrgId, APIType apiId,
			T respClass, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory);
}
