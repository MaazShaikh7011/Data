//package com.opl.jns.nabard.config.updated.common.utils.utility;
//
//public enum ENVMode {
//    S,
//    Q,
//    U,
//    P;
//
//    ENVMode() {
//    }
//
//    public static ENVMode fromName(String name) {
//        ENVMode[] var1 = values();
//        int var2 = var1.length;
//
//        for (int var3 = 0; var3 < var2; ++var3) {
//            ENVMode errorCode = var1[var3];
//            if (errorCode.name().equalsIgnoreCase(name)) {
//                return errorCode;
//            }
//        }
//
//        return null;
//    }
//}
