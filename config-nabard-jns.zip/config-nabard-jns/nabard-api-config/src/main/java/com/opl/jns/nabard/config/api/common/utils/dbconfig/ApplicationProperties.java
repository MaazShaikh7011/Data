package com.opl.jns.nabard.config.api.common.utils.dbconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "com.jns.common.config")
public class ApplicationProperties {

	// DB CONFIGURATION PROPERTIES
	private String userName;
	private String dbName;
	private String dbPass;
	private String dbDriver;
	private String dbMaxConnections;
	private String dbMinConnections;
	private String dbMaxPartitions;
	private String dbMaxLifetimeInMillis;
	private String dbConnectionTimeoutInMillis;
	private String dbMinimumIdle;
	private String dbMaximumpoolsize;
	private String dbIdelTimeout;

	// HIBERNATE PROPERTIES
	private String hibernateDialect;
	private String hibernateFormatSql;
	private String hibernateHbm2ddl;
	private String hibernateEJBNamingStrategy;
	private String hibernateShowSql;
	private String hibernateEnableLazyLoadNoTrans;
	private String hibernateParamNullPassing;

	// DOMAIN AND REPOSITORY PROPERTIES
	private String domainPackageName;
	private String repositoryPackageName;

}
