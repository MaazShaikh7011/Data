package com.opl.jns.nabard.config.api.common.utils.security;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.opl.jns.nabard.config.ere.domain.ClientMaster;
import com.opl.jns.nabard.config.ere.enums.MetadataEnum;
import com.opl.jns.nabard.config.ere.repo.ClientMasterRepo;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class EncryptResBodyCtrlAdvice implements ResponseBodyAdvice<Object> {

	@Autowired
	private ClientMasterRepo clientMasterRepo;

	@Override
	public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	@Override
	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
			Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest serverHttpRequest,
			ServerHttpResponse serverHttpResponse) {

		HttpServletResponse servletRes = ((ServletServerHttpResponse) serverHttpResponse).getServletResponse();
		HttpServletRequest servletReq = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		/* SKIP SWAGGER URLS */
		if (servletReq.getAttribute(SecurityUtility.REQ_ATR_IS_SWAGGER) != null) {
			return body;
		}

		/* SKIP ACTUATOR URLS */
		if (servletReq.getAttribute(SecurityUtility.REQ_ATR_IS_ACTUATOR) != null) {
			return body;
		}

		servletRes.setHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE);

		ClientMaster apiUsers = null;
		String plainBody = "";
		try {
			/*
			 * FETCH API USER ID FROM REQUEST ATTRIBUTE (SET FROM INTERCEPTOR PREHANDLE
			 * METHOD)
			 */
			Long apiUserId = SecurityUtility.getHeaderAttribute(servletReq, SecurityUtility.REQ_ATR_APP_USER_ID,
					Long.class);

			/* FETCH API USER (SET IN DECRYPTION REQUEST CLASS) */
			if (apiUserId != null) {
				apiUsers = clientMasterRepo.findById(apiUserId).get();
			}

			plainBody = MultipleJSONObjectHelper.getStringfromObject(body);

			if (servletReq.getHeader(SecurityUtility.REQ_AUTH) != null
					&& servletReq.getHeader(SecurityUtility.REQ_AUTH).equals("true")) {
				return body;
			} else {
				servletReq.setAttribute(SecurityUtility.RESPONSE_PLAIN_BODY, plainBody);

				/* IF THIS FLAG IS TRUE THEN NO NEEDS TO ENCRYPT RESPONSE */
				String skipEnc = servletReq.getHeader(SecurityUtility.REQ_HEADER_ENCRYPTION_SKIP);
				if (skipEnc != null && skipEnc.equals("true")) {
					servletReq.setAttribute(SecurityUtility.RESPONSE_ENCRYPT_BODY, plainBody);
					return body;
				} else {

					/* ENCRYPT RESPONSE */
					String encData = encryptRes(plainBody, apiUsers.getPublicKey(), servletReq);
					if (OPLUtils.isObjectNullOrEmpty(encData)) {
						throw new Exception("Exception while encrypt response");
					}

					/* SET ENCRYPT RESPONSE IN META DATA FORMS */
					Map<String, Object> response = new HashMap<>();
					Long destOrgId=(Long) servletReq.getAttribute(SecurityUtility.REQ_ATR_DEST_ORG);
					ClientMaster destOrg = clientMasterRepo.findByOrganizationMasterId(destOrgId);
					String metadata=MetadataEnum.getMetadataValueByTypeId(destOrg.getOrganizationMaster().getType());
					response.put(metadata, encData);

					/* SET REQUEST REFERENCE NUMBNER FOR SBI */
					if (apiUsers.getOrganizationMaster().getId() == SecurityUtility.SBI_ORG_ID) {
						Object attribute = servletReq.getAttribute(SecurityUtility.REQ_REF_NUMBER);
						if (!OPLUtils.isObjectNullOrEmpty(attribute)) {
							response.put(SecurityUtility.REQ_REF_NUMBER, String.valueOf(attribute));
						}
					}
					/* WRITE REPONSE IN HTTP RESPONSE CLASS */
					try (OutputStream stream = serverHttpResponse.getBody()) {
						byte[] jsonRes = MultipleJSONObjectHelper.getStringfromObject(response).getBytes("UTF-8");
						String encryptRespBody = new String(jsonRes);
						servletReq.setAttribute(SecurityUtility.RESPONSE_ENCRYPT_BODY, encryptRespBody);
						stream.write(jsonRes);
						stream.flush();
						return null;
					} catch (Exception e) {
						log.error("EXCEPTION WHILE WRITE ENCRYPT RESPONSE :-  ", e);
					}
				}
			}
		} catch (JsonProcessingException e) {
			log.error("JSON PARSE EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		} catch (IOException e) {
			log.error("IO EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE ENCRYPT RESPONSE :-  ", e);
		} finally {
			setErrorStatus(servletReq, apiUsers, plainBody);
		}
		return body;
	}

	private void setErrorStatus(HttpServletRequest servletReq, ClientMaster apiUsers, String plainBody) {
		try {
			Map<String, Object> map = null;
			if (!servletReq.getRequestURI().contains("saveAll") && !OPLUtils.isObjectNullOrEmpty(plainBody)) {
				map = MultipleJSONObjectHelper.getMapFromString(plainBody);
				if (map.get("status") != null) {
					Integer resStatus = Integer.parseInt(String.valueOf(map.get("status")));
					if (resStatus != HttpStatus.OK.value()) {
						servletReq.setAttribute(SecurityUtility.RESPONSE_STATUS, resStatus);
//						ErrorLog errorLog = new ErrorLog();
						if (apiUsers != null) {
//							errorLog.setApiUsers(apiUsers);
//							errorLog.setOrgId(apiUsers.getOrganizationMaster().getOrgId().intValue());
						}
//						errorLog.setCreatedDate(new Date());
						if (map.get(SecurityUtility.MESSAGE) == null
								|| map.get(SecurityUtility.MESSAGE).equals("null")) {
							String resMsg = (String) map.get("data");
							servletReq.setAttribute(SecurityUtility.DECRYPTION_MSG, resMsg);
//							errorLog.setErrorMsg(resMsg);
						} else {
							String resMsg = (String) map.get(SecurityUtility.MESSAGE);
							servletReq.setAttribute(SecurityUtility.DECRYPTION_MSG, resMsg);
//							errorLog.setErrorMsg(resMsg);
//							errorLog.setErrorMsg((String) map.get(AuthCredentialUtils.MESSAGE));
						}
//						errorLog.setReqUrl(servletReq.getRequestURI());
//						logService.logError(errorLog);
					}
				}
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVE ERROR LOGS IN ENCRYPT RESPONSE CLASS :- ", e);
		}
	}

	/**
	 * ENCRYPT RESPONSE
	 * 
	 * @param body
	 * @param publicKey
	 * @param reqLogs
	 * @return
	 */
	private String encryptRes(String body, String publicKey, HttpServletRequest servletReq) {
		try {
			ClientMaster oplUser = clientMasterRepo.findById(SecurityUtility.JNS_CLIENT_MASTER_ID).get();
			if (oplUser == null) {
				servletReq.setAttribute(SecurityUtility.DECRYPTION_MSG, "OPL User Not Found While Decrypt Request");
				return null;
			}
			return APIEncryptionUtility.encrypt(body, oplUser.getPrivateKey(), publicKey);
		} catch (Exception e) {
			log.info("FAILED TO DECRYPT REQUEST:: ", e);
			servletReq.setAttribute(SecurityUtility.DECRYPTION_MSG, e.getMessage());
		}
		return null;
	}

}
