package com.opl.jns.nabard.config.api.apiaudit.service;

import com.opl.jns.nabard.config.ere.proxies.APIAuditProxy;

public interface AuditMasterService {

	public void save(APIAuditProxy apiAuditProxy);

}
