package com.opl.jns.nabard.config.api.common.utils.security;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.opl.jns.nabard.config.api.apiaudit.service.AuditMasterService;
import com.opl.jns.nabard.config.ere.domain.ClientAPIMap;
import com.opl.jns.nabard.config.ere.domain.ClientMaster;
import com.opl.jns.nabard.config.ere.enums.SourceCallType;
import com.opl.jns.nabard.config.ere.proxies.APIAuditProxy;
import com.opl.jns.nabard.config.ere.proxies.HeaderProxy;
import com.opl.jns.nabard.config.ere.proxies.ResponseCommonProxy;
import com.opl.jns.nabard.config.ere.repo.ClientAPIMapRepo;
import com.opl.jns.nabard.config.ere.repo.ClientMasterRepo;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.NabardUtils;
import com.opl.jns.utils.common.OPLUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AuthenticationInterceptor implements HandlerInterceptor {

	@Autowired
	private ClientMasterRepo clientMasterRepo;

	@Autowired
	private ClientAPIMapRepo apiMapRepo;

	@Autowired
	private AuditMasterService auditMasterService;

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		log.info("REQUEST URL ---------------------------- :- " + request.getRequestURI());
		request.setAttribute(SecurityUtility.REQUEST_RECEIVED_TIME, new Date().getTime());

		/* CHECK SWAGGER URL OR NOT */
		if (SecurityUtility.checkSwaggerURL(request.getRequestURI())) {
			request.setAttribute(SecurityUtility.REQ_ATR_IS_SWAGGER, Boolean.TRUE);
			return Boolean.TRUE;
		}

		/* HANDLE /actuator METHODS */
		if (request.getRequestURI().contains("actuator")) {
			request.setAttribute(SecurityUtility.REQ_ATR_IS_ACTUATOR, Boolean.TRUE);
			return Boolean.TRUE;
		}

		HandlerMethod method = null;
		if (handler instanceof HandlerMethod) {
			method = (HandlerMethod) handler;
		}

		/* SKIP TOKEN AUTHENTICATION IF METHOD HAVE SkipInterceptor ANNOTATION */
		if (method != null && method.getMethod().isAnnotationPresent(SkipInterceptor.class)) {
			request.setAttribute(SecurityUtility.SESSION_OBJ_KEY,
					new ResponseCommonProxy(HttpStatus.OK.value(), "Success"));
			return Boolean.TRUE;
		}

		/* HANDLE /error METHODS */
		if (request.getRequestURI().contains("/error")) {
			log.error("ERROR FOR REQUEST URL ----------------- :-" + request.getRequestURI());
			return failed(response);
		}

		/* CHECK INTERNAL CLIENT CALL */
		if (SecurityUtility.isClient(request)) {
			request.setAttribute(SecurityUtility.SESSION_OBJ_KEY,
					new ResponseCommonProxy(HttpStatus.OK.value(), "Success"));
			return Boolean.TRUE;
		}

		/* FETCH API USERNAME AND API KEY */
		HeaderProxy apiRequest = SecurityUtility.httpResToAuthReq(request);
		if (apiRequest == null) {
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			log.error("BAD REQUEST, TOKEN IS NULL OR EMPTY ----------------- :-" + request.getRequestURI());
			failureLogs(request, "Username or api-key is null or empty!", null);
			return failed(response);
		}

		log.info("USER: " + apiRequest.getUserName() + " REQUEST START FOR: " + request.getRequestURI());
		ClientMaster apiUser = clientMasterRepo.findFirstByUserNameAndApiKeyAndIsActiveOrderByIdDesc(
				apiRequest.getUserName(), apiRequest.getApiKey(), true);
		if (apiUser != null) {
			/* CHECK IP IS WHITELISTED OR NOT */
			if (SecurityUtility.isClientIpMatched(request, apiUser.getIps())) {
				request.setAttribute(SecurityUtility.REQ_ATR_APP_USER_ID, apiUser.getId());
				return success(request, response, apiUser);
			} else {
				String fromIP = "";
				if (request.getAttribute(SecurityUtility.REQ_ATR_IPS_FAILED) != null) {
					fromIP = String.valueOf(request.getAttribute(SecurityUtility.REQ_ATR_IPS_FAILED));
				}
				log.error(apiUser.getId() + " IP NOT WHITELISTED ----------------- :-" + request.getRequestURI()
						+ "--------" + fromIP);
				failureLogs(request, "IP is not whitelisted", apiUser);
				return failed(response);
			}
		} else {
			log.error("USER NOT FOUND ----------------- :-" + request.getRequestURI());
			failureLogs(request, "API user not found", null);
			return failed(response);
		}
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		request.setAttribute(SecurityUtility.RESPONSE_TIME, new Date().getTime());
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable Exception ex) throws Exception {
		// SKIP SWAGGER URLS
		if (request.getAttribute(SecurityUtility.REQ_ATR_IS_SWAGGER) != null) {
			return;
		}
		if (request.getAttribute(SecurityUtility.REQ_ATR_IS_ACTUATOR) != null) {
			return;
		}
		// ONLY AUTHENTICATE REQUEST ALLOW FOR AUDIT BY API USER TABLE
		if (OPLUtils.isObjectNullOrEmpty(request.getAttribute(SecurityUtility.REQ_ATR_APP_USER_ID))) {
			return;
		}

		handleDecrypReqError(request, response);

		/* SAVE AUDIT */
		auditHandler(request, response, ex);

		/* AFTER AUDIT REMOVE VALUES FROM SERVLET */
		request.removeAttribute(SecurityUtility.REQUEST_RECEIVED_TIME);
		request.removeAttribute(SecurityUtility.REQUEST_PLAIN_BODY);
		request.removeAttribute(SecurityUtility.RESPONSE_PLAIN_BODY);
		request.removeAttribute(SecurityUtility.RESPONSE_ENCRYPT_BODY);
		request.removeAttribute(SecurityUtility.RESPONSE_STATUS);
		request.removeAttribute(SecurityUtility.RESPONSE_TIME);
		request.removeAttribute(SecurityUtility.REQ_ATR_SOURCE_ORG);
		request.removeAttribute(SecurityUtility.REQ_ATR_DEST_ORG);
		request.removeAttribute(SecurityUtility.REQ_ATR_TOKEN);
//		request.removeAttribute(SecurityUtility.REQUEST);
		request.removeAttribute(SecurityUtility.REQ_ATR_DEC_FAILED);
//		request.removeAttribute(SecurityUtility.DEC_FAILED_RES_ADDED);
		request.removeAttribute(SecurityUtility.REQ_ATR_IS_SWAGGER);
		request.removeAttribute(SecurityUtility.REQ_ATR_APP_USER_ID);
		request.removeAttribute(SecurityUtility.SESSION_OBJ_KEY);
		request.removeAttribute(SecurityUtility.REQ_ATR_LOG_ID);
		request.removeAttribute(SecurityUtility.MESSAGE);
		request.removeAttribute(SecurityUtility.REQ_ATR_IPS_FAILED);
		request.removeAttribute(SecurityUtility.DECRYPTION_MSG);
		request.removeAttribute(SecurityUtility.REQ_REF_NUMBER);

	}

	private void failureLogs(HttpServletRequest request, String message, ClientMaster apiUsers) {
		APIAuditProxy apiAuditProxy = new APIAuditProxy();

		apiAuditProxy.setContextPath(request.getContextPath());
		apiAuditProxy.setRequestUrl(request.getRequestURI());
		if (request.getAttribute(SecurityUtility.REQ_ATR_IPS_FAILED) != null) {
			apiAuditProxy.setRequestIp(String.valueOf(request.getAttribute(SecurityUtility.REQ_ATR_IPS_FAILED)));
		}

		if (apiUsers != null) {
			apiAuditProxy.setSourceOrgId(apiUsers.getOrganizationMaster().getId());
		}
		Long createdDate = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQUEST_RECEIVED_TIME,
				Long.class);
		if (createdDate != null) {
			apiAuditProxy.setCreatedDate(new Date(createdDate));
		} else {
			apiAuditProxy.setCreatedDate(new Date());
		}
		apiAuditProxy.setModifiedDate(new Date());
		apiAuditProxy
				.setResponseTime(apiAuditProxy.getModifiedDate().getTime() - apiAuditProxy.getCreatedDate().getTime());
		apiAuditProxy.setApiKey(request.getHeader(SecurityUtility.REQ_HEADER_API_KEY));
		apiAuditProxy.setUserName(request.getHeader(SecurityUtility.REQ_HEADER_USERNAME));
		apiAuditProxy.setToken(request.getHeader(SecurityUtility.REQ_ATR_TOKEN));
		apiAuditProxy.setMessage(message);
		auditMasterService.save(apiAuditProxy);
	}

	private void auditHandler(HttpServletRequest request, HttpServletResponse response, Exception ex)
			throws IOException {

		APIAuditProxy apiAuditProxy = new APIAuditProxy();

		/* PREPARE REQUEST INFORMATION IN CLASS */
//		request.getRequestURL();
//		request.getRequestURI();
//		apiAuditProxy.setContextPath(request.getContextPath());
		apiAuditProxy.setContextPath(request.getRequestURI());
		apiAuditProxy.setRequestUrl(request.getRequestURI());
		apiAuditProxy.setRequestIp(String.valueOf(request.getAttribute(SecurityUtility.REQ_ATR_IPS)));
		apiAuditProxy.setCreatedDate(new Date());
		apiAuditProxy.setRequestHeader(getHeaders(request).toString());
		apiAuditProxy.setApiKey(request.getHeader(SecurityUtility.REQ_HEADER_API_KEY));
		apiAuditProxy.setUserName(request.getHeader(SecurityUtility.REQ_HEADER_USERNAME));

		/* SET REQUESTED TIME */
		Long createdDate = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQUEST_RECEIVED_TIME,
				Long.class);
		apiAuditProxy.setCreatedDate(new Date(createdDate));

		/* SET RESPONES TIME */
		Long responseDate = SecurityUtility.getHeaderAttribute(request, SecurityUtility.RESPONSE_TIME, Long.class);
		apiAuditProxy.setModifiedDate(new Date(responseDate));

		Long orgId = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQ_ATR_SOURCE_ORG, Long.class);
		apiAuditProxy.setSourceOrgId(orgId);

		Long destOrgId = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQ_ATR_DEST_ORG, Long.class);
		apiAuditProxy.setDestOrgId(destOrgId);

		apiAuditProxy.setResponseTime(responseDate - createdDate);

		/*
		 * FETCH API USER ID FROM REQUEST ATTRIBUTE (SET FROM INTERCEPTOR PREHANDLE
		 * METHOD)
		 */
		Long apiUserId = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQ_ATR_APP_USER_ID, Long.class);
		ClientMaster apiUser = clientMasterRepo.findById(apiUserId).get();

//		ClientAPIMap apiMap = apiMapRepo.findByContexPathAndClientMasterIdAndIsActiveTrue(apiAuditProxy.getContextPath(), apiUserId);
		ClientAPIMap apiMap = apiMapRepo.findByContexPathAndClientMasterIdAndIsActiveTrue(apiAuditProxy.getRequestUrl(),
				destOrgId);

		apiAuditProxy.setClientMapId(apiMap != null ? apiMap.getId() : null);
		apiAuditProxy.setClientId(apiUser != null ? apiUser.getId() : null);

		apiAuditProxy.setRequestUrl(request.getRequestURI());
		apiAuditProxy.setRequestHeader(apiAuditProxy.getRequestHeader());
		apiAuditProxy.setEncypReq(getRequestAttribute(SecurityUtility.REQUEST_ENCRYPT_BODY, request));
		apiAuditProxy.setPlainReq(getRequestAttribute(SecurityUtility.REQUEST_PLAIN_BODY, request));
		apiAuditProxy.setEncypRes(getRequestAttribute(SecurityUtility.RESPONSE_ENCRYPT_BODY, request));
		apiAuditProxy.setPlainRes(getRequestAttribute(SecurityUtility.RESPONSE_PLAIN_BODY, request));
		apiAuditProxy.setToken(getRequestAttribute(SecurityUtility.REQ_ATR_TOKEN, request));
		
		apiAuditProxy.setSourceType(SourceCallType.JANSURAKSHA.getId());
//		String storageId = getRequestAttribute(SecurityUtility.STORAGE_ID, request);
//		if (!OPLUtils.isObjectNullOrEmpty(storageId)) {
//			apiAuditProxy.setStorageId(Long.valueOf(storageId));
//		}

		/* IN CASE OF ERROR RECEIVED */
		if (!OPLUtils.isObjectNullOrEmpty(ex)) {
			apiAuditProxy.setMessage(ExceptionUtils.getStackTrace(ex));
		}

		Integer resStatus = SecurityUtility.getHeaderAttribute(request, SecurityUtility.RESPONSE_STATUS, Integer.class);
		if (OPLUtils.isObjectNullOrEmpty(resStatus)) {
			apiAuditProxy.setResponseStatus(response.getStatus());
		} else {
			apiAuditProxy.setResponseStatus(resStatus);
		}
		/* MEANS DECRYPTION ERROR */
		String msg = getRequestAttribute(SecurityUtility.DECRYPTION_MSG, request);
		if (!OPLUtils.isObjectNullOrEmpty(msg)) {
			apiAuditProxy.setMessage(msg);
		}

		auditMasterService.save(apiAuditProxy);
	}

	public String getRequestAttribute(String attributeName, HttpServletRequest request) {
		Object attributeVal = request.getAttribute(attributeName);
		if (!OPLUtils.isObjectNullOrEmpty(attributeVal)) {
			return attributeVal.toString();
		}
		return null;
	}

	private Map<String, String> getHeaders(HttpServletRequest servletRequest) {
		Enumeration<String> headerNames = servletRequest.getHeaderNames();
		Map<String, String> requestHeader = new HashMap<>();
		if (!OPLUtils.isObjectNullOrEmpty(headerNames)) {
			while (headerNames.hasMoreElements()) { // For Set Request Header
				String key = headerNames.nextElement();
				String value = servletRequest.getHeader(key);
				requestHeader.put(key, value);
			}
		}
		return requestHeader;
	}

	/**
	 * HANDLE DECRYP REQUEST ERROR
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	private boolean handleDecrypReqError(HttpServletRequest request, HttpServletResponse response) {
		if (OPLUtils.isObjectNullOrEmpty(request.getAttribute(SecurityUtility.REQ_ATR_DEC_FAILED))) {
			return true;
		}
		ClientMaster apiUsers = null;
		try (OutputStream stream = response.getOutputStream()) {
			ResponseCommonProxy commonResponse = new ResponseCommonProxy();
			commonResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			commonResponse.setMessage("Failed to read request");
			if (request.getHeader(SecurityUtility.REQ_HEADER_ENCRYPTION_SKIP) != null
					&& request.getHeader(SecurityUtility.REQ_HEADER_ENCRYPTION_SKIP).toString().equals("true")) {
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				String resp = MultipleJSONObjectHelper.getStringfromObject(commonResponse);
				request.setAttribute(SecurityUtility.RESPONSE_PLAIN_BODY, resp);
				byte[] jsonRes = resp.getBytes("UTF-8");
				stream.write(jsonRes);
				stream.flush();
			} else {
				response.setStatus(HttpServletResponse.SC_OK);
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				Long apiUserId = SecurityUtility.getHeaderAttribute(request, SecurityUtility.REQ_ATR_APP_USER_ID,
						Long.class);
				apiUsers = clientMasterRepo.findById(apiUserId).get();
				String s = MultipleJSONObjectHelper.getStringfromObject(commonResponse);
				request.setAttribute(SecurityUtility.RESPONSE_PLAIN_BODY, s);
//				preapiAuditProxy.setPlainResponse(s);
				String encData = APIEncryptionUtility.encrypt(s, APIEncryptionUtility.OPL_PRIVATE_KEY,
						apiUsers.getPublicKey());
				Map<String, Object> responseMap = new HashMap<String, Object>();
				responseMap.put(SecurityUtility.META_DATA, encData);
				String res = MultipleJSONObjectHelper.getStringfromObject(responseMap);
				request.setAttribute(SecurityUtility.RESPONSE_ENCRYPT_BODY, res);
//				preapiAuditProxy.setResponseResult(res);
				stream.write(res.getBytes("UTF-8"));
				stream.flush();
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE ENCRYPT RESPONSE :- ", e);
		}
		return false;
	}

	private Boolean failed(HttpServletResponse response) {
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		return false;
	}

	private Boolean success(HttpServletRequest request, HttpServletResponse response, ClientMaster apiUsers)
			throws IOException {

		// FOR SBI NEED TO ADD REQUEST REFERENCE NUMNER IN HEADER
		if (!OPLUtils.isObjectNullOrEmpty(apiUsers.getOrganizationMaster())
				|| !OPLUtils.isObjectNullOrEmpty(apiUsers.getOrganizationMaster().getId())) {
			request.setAttribute(SecurityUtility.REQ_ATR_SOURCE_ORG, apiUsers.getOrganizationMaster().getId());
			/*
			 * CHECK CURRENT REQUEST COMES FROM JANSURAKSHA OR BANK/INSURER
			 */
			if (SecurityUtility.JNS_CLIENT_MASTER_ID.equals(apiUsers.getOrganizationMaster().getId())) {
				/*
				 * IF CURRENT REQUEST IS COMES FROM JANSURAKSHA, NEED TO FETCH DESTINATION ORG
				 * ID FROM HEADER
				 */
				String destOrgReq = request.getHeader(NabardUtils.REQ_JNS_DEST_ORG_KEY);
				if (OPLUtils.isObjectNullOrEmpty(destOrgReq)) {
					log.error("DESTINATION ORGANIZATION KEY IS MISSING FROM REQUEST HEADER");
					failureLogs(request, "Destination organization key is missing in the header", apiUsers);
					return false;
				}
				/*
				 * IF WE WANT TO PASS MILLISECOND FOR CHECK HEADER KEY VALIDATION OTHERWISE IT
				 * WILL TAKE 2MIN AS DEFAULT VALUE
				 */
				Long destOrgId = NabardUtils.decryptAndValidate(destOrgReq, null);
				if (OPLUtils.isObjectNullOrEmpty(destOrgId)) {
					log.error("DESTINATION ORGANIZATION KEY IS INVALID OR NOT MATCHED TIMESTAMP ---> ", destOrgReq);
					failureLogs(request, "Destination org key is invalid or timestamp is not matched", apiUsers);
					return false;
				}
				request.setAttribute(SecurityUtility.REQ_ATR_DEST_ORG, destOrgId);
				log.error("DESTINATION ORGANIZATION ID ---> "+ destOrgReq);
			} else {
				request.setAttribute(SecurityUtility.REQ_ATR_DEST_ORG, SecurityUtility.JNS_CLIENT_MASTER_ID);
				log.error("ORGANIZATION ID ---> "+ apiUsers.getOrganizationMaster().getId());
			}
			if (apiUsers.getOrganizationMaster().getId() == SecurityUtility.SBI_ORG_ID
					&& !OPLUtils.isObjectNullOrEmpty(request.getHeader(SecurityUtility.REQ_REF_NUMBER))) {
				request.setAttribute(SecurityUtility.REQ_REF_NUMBER, request.getHeader(SecurityUtility.REQ_REF_NUMBER));
			}
		}
		return true;
	}

}
