package com.opl.jns.nabard.config.api.common.service;

import java.util.List;

import com.opl.jns.nabard.config.ere.proxies.ConfigMasterProxy;

public interface ConfigMasterService {

	public List<ConfigMasterProxy> fetchAll();

}
