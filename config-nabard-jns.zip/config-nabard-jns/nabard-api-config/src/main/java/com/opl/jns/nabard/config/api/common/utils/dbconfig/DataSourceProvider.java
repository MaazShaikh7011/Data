//package com.opl.jns.nabard.config.updated.common.utils.dbconfig;
//
//import com.opl.jns.nabard.config.updated.common.utils.utility.ENVMode;
//import com.opl.jns.utils.common.OPLUtils;
//
//public class DataSourceProvider {
//
//	private static final String ORACLE_URL_KEY = "JNS_ORACLE_URL";
//	private static final String ORACLE_ENV_MODE = "JNS_ORACLE_ENV_MODE";
//	private static final String JNS_APP_SERVER_DOMAIN = "JNS_APP_SERVER_DOMAIN";
//	private static String dbUrlOracle = null;
//	private static final ENVMode envMode = null;
//	private static String ansAppServerDomain = null;
//
//	private static String decryptKey(String key) {
//		String value = System.getenv(key);
//		EncryptionUtils cryptoConverter = new EncryptionUtils();
//		return cryptoConverter.convertToEntityAttribute(value);
//	}
//
//	/* Oracle config */
//	public static String getDbUrlOracle() {
////		if (null == dbUrlOracle) {
////			dbUrlOracle = decryptKey(ORACLE_URL_KEY);
////		}
////		return dbUrlOracle;
//		return "jdbc:mysql://qa-nabard-db.czm2f3npmmw4.ap-south-1.rds.amazonaws.com:3306/";
//	}
//
//	public static ENVMode getEnvMode() {
//		if (null == envMode) {
//			String mode = decryptKey(ORACLE_ENV_MODE);
//			return OPLUtils.isObjectNullOrEmpty(mode) ? ENVMode.P : ENVMode.fromName(mode);
//		} else {
//			return envMode;
//		}
//	}
//
//	public static String getAnsAppServerDomain() {
//		if (null == ansAppServerDomain) {
//			ansAppServerDomain = decryptKey(JNS_APP_SERVER_DOMAIN);
//			return ansAppServerDomain;
//		} else {
//			return ansAppServerDomain;
//		}
//	}
//}
