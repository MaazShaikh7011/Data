package com.opl.jns.nabard.config.api.restcall.utils;

import com.opl.jns.nabard.config.ere.enums.APIType;
import com.opl.jns.utils.common.OPLUtils;

public class ErrorUtils {

	private static final String SOURCE_ERROR = "source Error - ";
	private static final String ERROR_500 = "An error has occurred during the retrieval of data from source. Please attempt the operation again after some time";
	public static final String ERROR_ENCRYPT = "A problem occurred while encrypting the request. Please try after some time";
	public static final String ERROR_DECRYPT = "A problem occurred while decrypting the request. Please try after some time";
	private static final String ERROR_TIMEOUT = "The response time from source is longer than anticipated. Please make another attempt.";
	private static final String ERROR_CONFIGURATION = "The source is not yet registered with Nabard. Please proceed with onboarding the first";
	private static final String ERROR_SERVICE_UNAVLBL = "The source API services are currently unavailable. Please try again later.";
	private static final String ERROR_FROM_SOURCE = "An error encountered in application at source level. Please try after some time";
	private static final String INVALID_RESPONSE = "Invalid response received from source. Please try after some time";
	private static final String NULL_RESPONSE = "Response is null from source. Please try after some time";
	private static final String NULL_TIMESTAMP_RESPONSE = "Response timestamp is null or response is null from source. Please try after some time";
	private static final String NULL_TOKEN_RESPONSE = "Response token is null or response is null from source. Please try after some time";
	private static final String TOKEN_NOT_MATCH = "Response token is not same as a request token from source. Please try after some time";
	private static final String ERROR_PARSE_TOKEN = "Response token parse error from source. Please try after some time";

	public static String ERROR_PARSE_TOKEN(String source) {
		return replatStg(ERROR_PARSE_TOKEN, source);
	}

	public static String NULL_TOKEN_RESPONSE(String source) {
		return replatStg(NULL_TOKEN_RESPONSE, source);
	}

	public static String TOKEN_NOT_MATCH(String source) {
		return replatStg(TOKEN_NOT_MATCH, source);
	}

	public static String NULL_TIMESTAMP_RESPONSE(String source) {
		return replatStg(NULL_TIMESTAMP_RESPONSE, source);
	}

	public static String NULL_RESPONSE(String source) {
		return replatStg(NULL_RESPONSE, source);
	}

	public static String ERROR_SERVICE_UNAVLBL(String source) {
		return replatStg(ERROR_SERVICE_UNAVLBL, source.concat("'s"));
	}

	public static String INVALID_RESPONSE(String source) {
		return replatStg(INVALID_RESPONSE, source);
	}

	public static String ERROR_FROM_SOURCE(String source) {
		return replatStg(ERROR_FROM_SOURCE, source);
	}

	private static String replatStg(String msg, String replaceWith) {
		if (!OPLUtils.isObjectNullOrEmpty(replaceWith)) {
			return msg.replace("source", replaceWith);
		}
		return msg;
	}

	public static String SOURCE_ERROR(String source) {
		return replatStg(SOURCE_ERROR, source);
	}

	public static String ERROR_500(String source) {
		return replatStg(ERROR_500, source);
	}

	public static String ERROR_CONFIGURATION(String source) {
		return replatStg(ERROR_CONFIGURATION, source);
	}

	public static String ERROR_TIMEOUT(String source) {
		return ERROR_TIMEOUT;
	}

	public static String printLogs(Long orgId, APIType apiId, String refNum) {
		return "---REFID---" + refNum + "---ORG_ID---" + orgId + "---API_ID---" + apiId.toString() + "----";
	}

}
