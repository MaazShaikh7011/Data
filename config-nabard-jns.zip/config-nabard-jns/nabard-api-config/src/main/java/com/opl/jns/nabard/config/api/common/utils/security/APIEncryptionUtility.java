package com.opl.jns.nabard.config.api.common.utils.security;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import jakarta.xml.bind.DatatypeConverter;

/**
 * ENCRYPTION AND DECRYPTION UTILITY FOR APIs
 * 
 * @author harshit.suhagiya
 *
 */
public class APIEncryptionUtility {

	private static String TRANSFORMATION = "AES/GCM/NoPadding";
	private static final int GCM_TAG_LENGTH = 16;
	public static String OPL_PRIVATE_KEY = "MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQDIM6KmlHv9s84LP4w43MVjxgqCIqnmvsrGYop8ydWDNr67f7u97EOs9JB51mooejyO7UY1GP+Za18h7u7j747k2ybza8cgM2S8rc0waTPakqaPiDVXKoC8GcYIy/uyl3fXcKddNcBK3+VnhNRdWwY8g3TlJt0+Vu5TCgWNU95QFIxLel45zlRvmDE7c/G86kyLPI7gtrAfEE21GRjny273knnkac8PRlRBaKrIuwI2C8BKckT6ECmQ8VsB1WUq97QQtb58hW6RTElwCTRs8fmUd8YIaqzVpbXeHmY5C/9ke0lp2GikM4Y63B+UkYlhWdkJTiryMD6pkFy9gDkCF5c4FPseCaD//41TvVKaNu1ffgL8qvFFE6H0675M7gBZRbOqP8H2oBb2VmPWy8xNk94sWehIeQoL5N4R68q03PzGoHxzSf+ZYCLwCUrWmnyHsGlGi0Ymgq3Xv8EoVkgMj63pDD8zrA+yu7qQGswFNqgTwp83IZIP9WuafRwsOO91TWbAlVh1um3AZDIriOdYvs0OvQDUubuzOnA7J80Lp/E1VMk+Jld5CxDIwPgbdzXQh/hl3QdcNQpdqk4YuBdy8OrAJPB7AxHs6CExyDwVBQzU6FwY0QCORq9n+EZUHFt+wGbUpYvQvuSVADKFAH6dzlj9Dc8X0mP/godl1LeNk/ekdwIDAQABAoICAQCxX44rqEJydGuI67SAbJk13LBSvANrvH5LZeLszKWuq0IxPOpJSpprEgMu7xj+483jk7UwNgW/F7Ihjl948zXW7ZOE92hkzyPhRtsUmSCn9mY7pKIdqDqGbQ9Xm+JUSH6VEeo2WvkTXWsSXE0KqSrNUmqu29AI+1wLlkV1AWll6c6i0LfK31NPy7dSxVbX2X4Xnn+3+CPyYa93U9UNCOA32D7GcDhTgCwGB4XIcmdzGtYzHyqdotQw5qWK6lXHy85tP5iVGmLruHsYGA+qtng5YiTCMEEQyNBpCuXmhQqxK8nPTTzovf2fCIeySX8+ESyJYggKq1PZR13jR0c640vFglQWN9pgjrmSLMbwpG7LZj+RRT0fRqlDUU9ftKjiUDt9gww0Tbneu/ORqYXoaa00Y0QcXZX0/Q4suVO/LwazOS3+SKSwIYxQJGirN6pSZ48bbQ2VylpDkG6DY6IZPHdctdro6zG5XAmiqteCh9KeASEpnch0Xlfd0PP5IWkzAuWHvWG20NdztqvPag/jFVmQ9EOxhMGZlfA+PZ/+p6mL/a9ARYN8+S8WM/CKMjjmLsk44zm7RgPhDVVj8nGS+zyrxj3iI6kaDqji2vWQ2oP5D1Q6S2hxY7S7Z7K2ds4bSQC70MfKFOAthV5Xtw4QzNMZIJWv/Ox9XCTdZ83gispVAQKCAQEA8Xl21jY7vz8YmRJJ8F2cc+VmXgEc915aUIrFpF6Yb+S+L6en1b6KQBlCr9N2S8aQSfHPsDY1YDrZlbIg0p08vDGp2xqUOQrgsXe8r6YLm1k23FO/XCE1A2yuSdZqO5353iCskh5hdr6qS7KUmRAJNyrImTIz4lGmVyMQKxDXxuj2Ms2mF8mmcaFmcxaNGGaOUWOxtixPdNxQn/LUljItC8mcJgPCTGoc8f58g8FMgt5VYkG2heY+0saSEzuTlJXaGIOZyyagHtJGUPS5EvHJw1UfHnNanMqsvQI3KWxf29kBS8TF3l2ytJkvKR6u0bbCUfZj/dLCmNWfl6sM+YT17wKCAQEA1D6ZiI9FTfI9Otr0cwGMWLj1uUyMQ7r9LbT4WZtxt2n8OUHHhBfAAeTv0+oWxaI8HzutDJvi2Y6mI3G0+Mg23QVW+8Fth1SB+NXIlHgN0MVFzoKmiJqKtDVZuwNjsVE3baUO8KDO2HnSh/KDB7z63iJ78MTMCArx7DDLQkXMzmhMc/7D1+iUEMKL2V0MGmM6l66/OqPszaWanXJAWONGeNj7/jGzg7HR0VgD9MgkeJVE1olpBLabWD3fom+ix0awSDP8OsMHsNEinQ12QgJoh2A9faHijmziC7p9+VVT+u8DLAzC8CRlRNhXyu8HxRlrrJ1NiB1Ka0WXD1udWLmB+QKCAQAfvg7QE+sAteOe45eSoEubtJEjVFQhdGa85bEbbU/ujYwuqYRXhaeYy3lHsa2AQobfIYliqY2Uq8fEdNj5tq+wMXsZkUHgybxFt+62zEYEUtLyXZPvIXJdk+DJVgU69wZMm9DzmEjJmkC6mKwN/tynQtmBweauHnuWQsayUpF61U7f2Ma3o8tcbpIQGOvNRFX6/vbycpqzSu7SR9KIN+pR/VuoZ6AX+W76pLBrhXJwVZe1xdufeGfTv0SegJti0dwMkugZm2c7Bfs2UyUtB1m1crAXiaRkrgPNCMiFiniDZuBTvHciRwDh2q0nY6ApczPSIGh+ikEIZDSJdHPNLRxDAoIBAEHOpwwQYAyq7xEwklqWQE3CC25IrbTSZW2mjto5uCiGVA3st0/djUsJENND4Yulob6NYjpmmw+ZiymyN8prSZd98FpevvcW3LWqk2Z1UtNIVzyQhdIVGKyHXir+AgsYg3cblmZFddzo6L3+E2Jy1dXKG2OroRddTWVOO7dwrO/SpuHQPCjVlBMePv5GO1pzKded9uzXprSchDQNGKZ20YLmxDssbdyHZebiw1dCNwysO4vJTyaG9+OES7KxqmbfJAk/FRWjIt9P+Mt5QRF2bbKLxIUPjI9ccznvuN919XP4Z6Ng0ZBjuIKAEbh6JI6YMypyG3f4nPpluVCptz+rRQECggEBAIqTYU8zyEMXE2xR6ITo0C2IwzK6kv5LCSQAcw6jCcMKQh1Q6o5mP1S49gZs3miEE+cdATR0f3/5mykYfGkGzgBVQNy8WyduFskDc3MeIp2oGvJDcYkw7cC+CyBoyGxkPRcb86MGD87qfPAVgvZob+IsKcETh2bHvOM+7fVgmexhZnXbRkTbTRygGkIm5FBAGEufYr9VGJFIMbqwt1rznXLpFWRiE4KnotNl1UPcXHvQ8AIsiSQSwIewHMfVVgbIaQ9E0XO/WsA0wOS0XQNuAG4zRrZ26HX66bQmaiURlI110Uvqk4hVHvvbNU+4ABbbziy15nbrZbc/FQidbY2knIw=";

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	public APIEncryptionUtility() {
		super();
	}

	public APIEncryptionUtility(String transformation) {
		APIEncryptionUtility.TRANSFORMATION = transformation;
	}

	/**
	 * ENCRYPT PAYLOAD USING PRIVATE AND PUBLIC KEY
	 * 
	 * @param plainText
	 * @param privateKey
	 * @param publicKey
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeySpecException
	 * @throws SignatureException
	 * @throws UnsupportedEncodingException
	 * @throws NoSuchProviderException
	 */
	public static String encrypt(String plainText, String privateKey, String publicKey)
			throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			SignatureException, UnsupportedEncodingException, NoSuchProviderException {

		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		byte[] iv = getIVFromAESKey(uuid.getBytes());
		byte[] encrypt = encryptRequestBodyAES256(plainText.getBytes(), uuid.getBytes(), iv);
		String encryptionRequestBody = Base64.getEncoder().encodeToString(encrypt);
		String digitalSignature = signSHA256RSA(encryptionRequestBody, privateKey);
		String keys = uuid;// Base64.getEncoder().encodeToString(uuid.getBytes());
		String haderKey = getEncryptHeader(keys, publicKey);
		return Base64.getEncoder()
				.encodeToString((haderKey + ":" + encryptionRequestBody + ":" + digitalSignature).getBytes());
	}

	/**
	 * DECRYPT PAYLOAD BY PRIVATE AND PUBLIC KEY
	 * 
	 * @param encText
	 * @param privatekey
	 * @param publickey
	 * @return
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws SignatureException
	 * @throws InvalidAlgorithmParameterException
	 * @throws NoSuchProviderException
	 * @throws InvalidKeySpecException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public static String decrypt(String encText, String privatekey, String publickey)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException,
			BadPaddingException, SignatureException, InvalidAlgorithmParameterException, NoSuchProviderException,
			InvalidKeySpecException, CertificateException, IOException {

		String split = new String(Base64.getDecoder().decode(encText));
		String haderKey = split.split(":")[0];
		String digitalSignature = split.split(":")[2];
		String encryptionRequestBody = split.split(":")[1];
		String decHeadr = decryptHeader(haderKey, privatekey);
		String decrypt = decSignSHA256RSA(encryptionRequestBody, digitalSignature, publickey);
		byte[] aesKey = decHeadr.getBytes();// Base64.getDecoder().decode(decHeadr);
		byte[] iv = getIVFromAESKey(aesKey);
		return decryptRequestBody(Base64.getDecoder().decode(decrypt), decHeadr.getBytes(), iv);
	}

	/**
	 * GENERATE IV FROM 0 TO 16 BYTES
	 * 
	 * @param encoded
	 * @return
	 */
	private static byte[] getIVFromAESKey(byte[] encoded) {
		return Arrays.copyOfRange(encoded, 0, 16);
	}

	/**
	 * ENCRYPT KEY USING RSA ECB OAE PADDING ALGORITHM
	 * 
	 * @param keyPlainText
	 * @param publickey
	 * @return
	 */
	private static String getEncryptHeader(String keyPlainText, String publickey) {
		try {
			byte[] keyByteArr = keyPlainText.getBytes();
			PublicKey key = getPublicKey(publickey);

			Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPADDING");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encryptedByte = cipher.doFinal(keyByteArr);
			String encodedString = Base64.getEncoder().encodeToString(encryptedByte);
			return encodedString;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * DECRYPT KEY USING PRIVATE KEY
	 * 
	 * @param data
	 * @param privatekey
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidKeySpecException
	 */
	private static String decryptHeader(String data, String privatekey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException,
			InvalidKeyException, InvalidKeySpecException {

		byte[] encryptedData = Base64.getDecoder().decode(data);
		PrivateKey privateKey = getPrivateKey(privatekey);
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPADDING");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] encryptedByte = cipher.doFinal(encryptedData);

		return new String(encryptedByte);
	}

	/**
	 * SIGN ENCRYPTED PAYLOAD BY PUBLIC KEY USING SHA256
	 * 
	 * @param input
	 * @param strPk
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws InvalidKeySpecException
	 * @throws SignatureException
	 * @throws UnsupportedEncodingException
	 */
	private static String signSHA256RSA(String input, String strPk) throws NoSuchAlgorithmException,
			InvalidKeyException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException {

		String realPK = strPk.replaceAll("-----END PRIVATE KEY-----", "").replaceAll("-----BEGIN PRIVATE KEY-----", "")
				.replaceAll("\n", "");
		byte[] b1 = DatatypeConverter.parseBase64Binary(realPK);
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
		KeyFactory kf = KeyFactory.getInstance("RSA");

		Signature privateSignature = Signature.getInstance("SHA256withRSA");
		privateSignature.initSign(kf.generatePrivate(spec));
		byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
		privateSignature.update(bytes);
		byte[] s = privateSignature.sign();
		return Base64.getEncoder().encodeToString(s);
	}

	/**
	 * DESIGN PAYLOAD BY PUBLIC KEY USING SHA256
	 * 
	 * @param encryptionRequestBody
	 * @param digitalSignature
	 * @param strPk
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeyException
	 * @throws SignatureException
	 * @throws CertificateException
	 * @throws IOException
	 */
	private static String decSignSHA256RSA(String encryptionRequestBody, String digitalSignature, String strPk)
			throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, CertificateException,
			IOException {

		String k = strPk.replaceAll("\n", "").replace("\r", "");
		Signature privateSignature = Signature.getInstance("SHA256withRSA");
		privateSignature.initVerify(getPublicKey(k));
		byte[] bytes = encryptionRequestBody.getBytes(StandardCharsets.UTF_8);
		privateSignature.update(bytes);
		privateSignature.verify(Base64.getDecoder().decode(digitalSignature));
		return encryptionRequestBody;
	}

	/**
	 * ENCRYPT PAYLOAD USING AES256 ALGORITHM WITH IV AND ENCRYPTION KEY
	 * 
	 * @param plaintext
	 * @param key
	 * @param IV
	 * @return
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws NoSuchProviderException
	 */
	private static byte[] encryptRequestBodyAES256(byte[] plaintext, byte[] key, byte[] IV)
			throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
			BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException {

		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
		cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);
		return cipher.doFinal(plaintext);
	}

	/**
	 * DECRYPT PAYLOAD BY KEY AND IV
	 * 
	 * @param cipherText
	 * @param key
	 * @param IV
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 * @throws InvalidKeyException
	 * @throws InvalidAlgorithmParameterException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws NoSuchProviderException
	 */
	private static String decryptRequestBody(byte[] cipherText, byte[] key, byte[] IV) throws NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
			BadPaddingException, NoSuchProviderException {

		Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
		cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
		byte[] decryptedText = cipher.doFinal(cipherText);

		return new String(decryptedText);
	}

	/**
	 * CONVERT PRIVATE KEY STRING TO OBJECT
	 * 
	 * @param privateKeyStr
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 */
	private static PrivateKey getPrivateKey(String privateKeyStr)
			throws NoSuchAlgorithmException, InvalidKeySpecException {

		PrivateKey privateKey = null;
		KeyFactory keyFactory = null;

		byte[] encoded = DatatypeConverter.parseBase64Binary(privateKeyStr);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
		keyFactory = KeyFactory.getInstance("RSA");
		privateKey = keyFactory.generatePrivate(keySpec);

		return privateKey;
	}

	/**
	 * CONVERT PUBLIC KEY STRING TO OBJECT
	 * 
	 * @param publicKeyStr
	 * @return
	 */
	private static PublicKey getPublicKey(String publicKeyStr) {
		PublicKey publicKey = null;
		try {
			CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
			BufferedReader br = new BufferedReader(new StringReader(publicKeyStr));
			String line = null;
			StringBuilder keyBuffer = new StringBuilder();
			while ((line = br.readLine()) != null) {
				if (!line.startsWith("-")) {
					keyBuffer.append(line);
				}
			}
			Certificate certificate = certificateFactory
					.generateCertificate(new ByteArrayInputStream(Base64.getDecoder().decode(keyBuffer.toString())));
			publicKey = certificate.getPublicKey();
		} catch (Exception var8) {
			var8.printStackTrace();
		}
		return publicKey;
	}

}
