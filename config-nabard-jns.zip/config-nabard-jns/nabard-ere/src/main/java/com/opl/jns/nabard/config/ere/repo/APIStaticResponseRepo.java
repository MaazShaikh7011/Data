package com.opl.jns.nabard.config.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.APIStaticResponse;

public interface APIStaticResponseRepo extends JpaRepository<APIStaticResponse, Long> {

	public APIStaticResponse findByOrgIdAndApiId(Long orgId, Long apiId);

}
