package com.opl.jns.nabard.config.ere.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.ConfigMaster;

public interface ConfigMasterRepo extends JpaRepository<ConfigMaster, Long> {

	List<ConfigMaster> findAllByIsActiveTrue();

	ConfigMaster findByCodeAndIsActiveTrue(String code);

	ConfigMaster findByIdAndIsActiveTrue(Long id);

}
