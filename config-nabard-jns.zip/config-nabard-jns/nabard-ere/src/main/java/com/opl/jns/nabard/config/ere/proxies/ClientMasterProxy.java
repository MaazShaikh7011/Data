package com.opl.jns.nabard.config.ere.proxies;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ClientMasterProxy extends AuditorProxy {

	private OrganizationMasterProxy organizationMaster;

	private String userName;

	private String apiKey;

	private String publicKey;

	private String privateKey;

	private String ips;

	private String loginName;

	private String password;

	private String headerConfig;

	private String baseUrl;

	private boolean testMode;
	
	private String clientName;
	

}
