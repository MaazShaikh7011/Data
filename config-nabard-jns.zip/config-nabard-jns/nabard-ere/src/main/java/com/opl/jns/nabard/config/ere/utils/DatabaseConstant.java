package com.opl.jns.nabard.config.ere.utils;

public class DatabaseConstant {

	public static final String JNS_CONFIG = "jns_config";
	public static final String JNS_BANK = "jns_bank";
	public static final String JNS_INSURER = "jns_insurer";

}
