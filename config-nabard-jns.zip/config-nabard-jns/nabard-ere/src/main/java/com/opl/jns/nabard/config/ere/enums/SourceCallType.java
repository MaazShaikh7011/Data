package com.opl.jns.nabard.config.ere.enums;

public enum SourceCallType {

	JANSURAKSHA(1,"JANSURAKSHA"), NABARD(2,"NABARD"), OTHERS(3,"OTHERS");

	private final Integer id;
	private final String value;

	SourceCallType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}
}
