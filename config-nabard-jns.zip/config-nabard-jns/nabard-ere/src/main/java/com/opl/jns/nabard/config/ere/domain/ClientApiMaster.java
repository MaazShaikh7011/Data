package com.opl.jns.nabard.config.ere.domain;

import java.io.Serializable;

import com.opl.jns.nabard.config.ere.utils.DatabaseConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "client_api_master", catalog = DatabaseConstant.JNS_CONFIG, schema = DatabaseConstant.JNS_CONFIG)
public class ClientApiMaster extends Auditor {

	/**
	 * 
	 */
	private static final long serialVersionUID = -774560592530663239L;

//	@Id
//	@Column(name = "id")
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;

	@Column(name = "published_by")
	private Integer publishedBy;

	@Column(name = "api_id")
	private Integer apiId;

	@Column(name = "api_code")
	private String apiCode;
	
	@Column(name = "api_name")
	private String apiName;
	
	@Column(name = "api_type")
	private String apiType;
	
	@Column(name = "version")
	private String version;

	@Column(name = "dflt_url")
	private String dfltUrl;

	@Column(name = "dflt_read_timeout")
	private Integer dfltReadTimeout;

	@Column(name = "dflt_con_timeout")
	private Integer dfltConTimeout;

	@Column(name = "contex_path")
	private String contexPath;

//	@Column(name = "is_active")
//	private Boolean isActive;

	@Column(name = "description")
	private String description;

}
