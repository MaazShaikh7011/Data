package com.opl.jns.nabard.config.ere.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "audit_master")
public class AuditMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = true)
	private Long id;

	@Column(name = "client_id", nullable = true)
	private Long clientId;

	@Column(name = "client_map_id", nullable = true)
	private Long clientMapId;

	@Column(name = "source_org_id", nullable = true)
	private Long sourceOrgId;

	@Column(name = "dest_org_id", nullable = true)
	private Long destOrgId;

	@Column(name = "request_ip", nullable = true)
	private String requestIp;

	@Column(name = "context_path", nullable = true)
	private String contextPath;

	@Column(name = "response_status", nullable = true)
	private Integer responseStatus;

	@Column(name = "response_time", nullable = true)
	private Long responseTime;

	@Column(name = "token", nullable = true)
	private String token;

	@Column(name = "source_token", nullable = true)
	private String sourceToken;

	@Column(name = "source_type", nullable = true)
	private Integer sourceType;

	@Column(name = "storage_id", nullable = true)
	private String storageId;

	@Column(name = "message", nullable = true)
	private String message;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

}
