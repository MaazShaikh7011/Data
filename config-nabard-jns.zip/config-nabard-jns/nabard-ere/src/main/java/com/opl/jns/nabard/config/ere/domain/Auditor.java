package com.opl.jns.nabard.config.ere.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@MappedSuperclass
@Getter
@Setter
public class Auditor implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = true)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "created_by", nullable = true)
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "modified_by", nullable = true)
	private Long modifiedBy;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	public Auditor() {
		super();
	}

	public Auditor(Long createdBy, Date createdDate, Boolean isActive) {
		super();
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.isActive = isActive;
	}

}
