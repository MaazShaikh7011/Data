package com.opl.jns.nabard.config.ere.enums;

public enum APIType {
	
	
	
	/**
	 * FORMAT SHOULD BE 
	 * B/I/J (BANK/INSURER/JANSURAKSHA)(PUBLISHED BY) +
	 * EN/CL (ENROLLMENT/CLAIM)
	 * AS/OC/DIY/CM (ASSISTED MODE / OTHER CHANNEL / DIY / COMMON)
	 * API NAME 
	 */
	
	/**
	 * BANK PUBLISHED APIs (V3)
	 */
	// ASSISTED MODE ENROLLMENT API
	B_EN_AS_TRIGGER_OTP(0,"B_EN_AS_TRIGGER_OTP"),
	B_EN_AS_VERIFY_OTP(1,"B_EN_AS_VERIFY_OTP"),
	B_EN_AS_PHYSICAL_SIGN(2,"B_EN_AS_PHYSICAL_SIGN"),
	B_EN_AS_GET_CUSTOMER_DTLS(3,"B_EN_AS_GET_CUSTOMER_DTLS"),
	B_EN_AS_PREMIUM_DEDUCT(4,"B_EN_AS_PREMIUM_DEDUCT"),
	B_EN_CM_PUSH_ENRL_DTLS(5,"B_EN_CM_PUSH_ENRL_DTLS"),
	
	// COMMON API
	B_EN_AS_GET_ACC_HLDR_DTLS(6,"B_EN_AS_GET_ACC_HLDR_DTLS"),
	B_EN_AS_GET_POLICY_DTLS(7,"B_EN_AS_GET_POLICY_DTLS"),

	// DIY OPT-OUT
	B_EN_DIY_OPT_OUT_UPDT_STS(8,"B_EN_DIY_OPT_OUT_UPDT_STS"),
	
	// DIY NOMINEE UPDATE
	B_EN_DIY_NMN_UPDT_STS(9,"B_EN_DIY_NMN_UPDT_STS"),
	
	// PUSH CLAIM DETAILS AND STATUS
	B_CL_CM_PUSH_CLM_DTLS(10,"B_CL_CM_PUSH_CLM_DTLS"),
	
	B_CL_AS_CLM_STS(11,"B_CL_AS_CLM_STS"),
	
	/**
	 * INSURER PUBLISHED APIs (V3)
	 */
	
	// PUSH ENROLLMENT AND CLAIM DETAILS
	I_EN_CM_PUSH_ENRL_DTLS(12,"I_EN_CM_PUSH_ENRL_DTLS"),
	I_CL_CM_PUSH_CLM_DTLS(13,"I_CL_CM_PUSH_CLM_DTLS"),
	
//	// CLAIM STATUS
	I_CL_CM_PUSH_CLM_STS(14,"I_CL_CM_PUSH_CLM_STS"),
	
	// OPT-OUT, NOMINNE & UPDATE STATUS
	I_EN_CM_OPT_OUT_UPDT_STS(15,"I_EN_CM_OPT_OUT_UPDT_STS"),
	I_EN_CM_NMN_UPDT(16,"I_EN_CM_NMN_UPDT"),
	I_EN_CM_GET_COI_DTLS(17,"I_EN_CM_GET_COI_DTLS"),

	
	/**
	 * JANSURAKSHA PUBLISHED APIs (V3)
	 */
	
	// OTHER CHANNEL ENROLLMENT
	J_EN_OC_ENROLLMENT(18,"J_EN_OC_ENROLLMENT"),
	J_EN_OC_UPDT_TRNSCN_DTLS(19,"J_EN_OC_UPDT_TRNSCN_DTLS"),
	J_EN_OC_UPDT_ENR_STS(20,"J_EN_OC_UPDT_ENR_STS"),
	
	// OTHER CHANNEL ENROLLMENT
	J_CL_OC_CLM_DTLS(21,"J_CL_OC_CLM_DTLS"),
	J_CL_OC_CLM_UPLD_DOCS(22,"J_CL_OC_CLM_UPLD_DOCS"),
	J_CL_OC_CLM_DEDUPE(23,"J_CL_OC_CLM_DEDUPE"),
	
	
	J_CL_OC_UPDT_CLM_STS(26,"J_CL_OC_UPDT_CLM_STS"),


	// MIS REPORT
	J_EN_CM_MIS_ENRL_DTLS(24,"J_EN_CM_MIS_ENRL_DTLS"),
	
	// UPDATE NOMINNE DETAILS
	J_EN_OC_UPDT_NMN_DTLS(25,"J_EN_OC_UPDT_NMN_DTLS");
	
	
	// QUERIED DOC UPDATE
//	I_CL_QUR_UPDT_DOCS(26,"I_CL_QUR_UPDT_DOCS");
	
	
	private final Integer id;
    private final String value;
    
    APIType(Integer id, String value){
    	 this.id = id;
         this.value = value;
    }
    
    public Integer getId() {
        return id;
    }

    public String getValue() {
        return value;
    }
    
    public static APIType fromId(Integer v) {
		for (APIType c : APIType.values()) {
			if(c.id!=null) {				
				if (c.id.equals(v)) {
					return c;
				}
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

}
