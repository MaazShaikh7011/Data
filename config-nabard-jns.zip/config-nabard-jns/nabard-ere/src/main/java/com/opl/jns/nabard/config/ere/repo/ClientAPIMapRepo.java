package com.opl.jns.nabard.config.ere.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.ClientAPIMap;
import com.opl.jns.nabard.config.ere.domain.ClientApiMaster;
import com.opl.jns.nabard.config.ere.enums.APIType;

public interface ClientAPIMapRepo extends JpaRepository<ClientAPIMap, Long> {

	public List<ClientAPIMap> findByIsActiveTrue();
	
	public ClientAPIMap findByIdAndIsActiveTrue(Long id);

	public ClientAPIMap findByContexPathAndClientMasterIdAndIsActiveTrue(String contexPath, Long clientMaster);
	
	public List<ClientAPIMap> findByClientMasterId(Long orgId);
	
}
