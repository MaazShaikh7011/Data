package com.opl.jns.nabard.config.ere.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.ClientMaster;
import com.opl.jns.nabard.config.ere.domain.OrganizationMaster;

public interface ClientMasterRepo extends JpaRepository<ClientMaster, Long> {

	public ClientMaster findByOrganizationMasterId(Long orgId);

	public ClientMaster findFirstByUserNameAndApiKeyAndIsActiveOrderByIdDesc(String userName, String apiKey,
			boolean isActive);

	public ClientMaster findByLoginNameAndPasswordAndIsActive(String userName, String password, boolean isActive);
	
	public List<ClientMaster> findByIsActiveTrue();
	
	public ClientMaster findByIdAndIsActiveTrue(Long id);
}
