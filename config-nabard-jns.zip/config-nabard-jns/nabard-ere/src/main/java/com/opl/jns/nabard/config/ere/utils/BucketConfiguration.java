package com.opl.jns.nabard.config.ere.utils;


import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.opl.jns.nabard.config.ere.bucketconfig.proxy.BucketConfigProxy;
import com.opl.jns.nabard.config.ere.domain.ConfigMaster;
import com.opl.jns.nabard.config.ere.enums.ConfigMasterCodes;
import com.opl.jns.nabard.config.ere.repo.ConfigMasterRepo;
import lombok.extern.slf4j.Slf4j;
import org.codehaus.jackson.map.DeserializationConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * CONFIGURE ALL THE PROPERTIES IN THE JAVA OBJECT FROM DATABASE
 *
 * @author harshit.suhagiya
 *
 */
@Component
@Slf4j
public class BucketConfiguration {

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private ConfigMasterRepo configMasterRepo;

    /**
     * LOAD ALL THE COMMON AND API CONFIGURATION FROM DATABASE
     *
     * @throws Exception
     */
    @EventListener(ApplicationReadyEvent.class)
    public void loadConfiguration() throws Exception {
        log.info("START LOADING CONFIGURATION FROM DATABASE ---------------> ");
        loadBucket();
        log.info("END LOADING CONFIGURATION FROM DATABASE ---------------> ");
    }

    /**
     * BUCKET CONFIGURATION LOAD
     *
     * @return
     * @throws Exception
     */
    @Bean
    private BucketConfigProxy loadBucket() throws Exception {
        BucketConfigProxy bucketConfig = new BucketConfigProxy();
        try {
            ConfigMaster config = configMasterRepo
                    .findByCodeAndIsActiveTrue(ConfigMasterCodes.BUCKET_CONFIG.toString());
            if (isObjectNullOrEmpty(config) || isObjectNullOrEmpty(config.getValue())) {
                log.error("BUCKET CONFIGURATION IS NULL OR EMPTY");
                throw new Exception("BUCKET CONFIGURATION NOT FOUND FROM COMMON CONFIG CLASS");
            }
            bucketConfig = getObject(config.getValue(), BucketConfigProxy.class);
            bucketConfig.setAmazonS3(AmazonS3ClientBuilder.defaultClient());
            applicationContext.getAutowireCapableBeanFactory().autowireBean(bucketConfig);
        } catch (Exception e) {
            log.error("EXCEPTION WHILE LOAD BUCKET CONFIGURATION ----> " + e.getMessage());
            throw e;
        }
        return bucketConfig;
    }

    public static boolean isObjectNullOrEmpty(Object value) {
        return (value == null
                || (value instanceof String s
                ? (s.isEmpty() || "".equals(s.trim()) || "null".equals(value)
                || "(null)".equals(value) || "undefined".equals(value))
                : false));
    }
    @SuppressWarnings("unchecked")
    public static <T> T getObject(String data, Class<?> clazz) throws IOException {
        org.codehaus.jackson.map.ObjectMapper mapper = new org.codehaus.jackson.map.ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return (T) mapper.readValue(data, clazz);
    }

}
