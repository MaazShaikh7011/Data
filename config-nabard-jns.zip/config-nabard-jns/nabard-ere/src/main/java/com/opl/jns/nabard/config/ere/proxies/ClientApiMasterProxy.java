package com.opl.jns.nabard.config.ere.proxies;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class ClientApiMasterProxy extends AuditorProxy {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5831389904692478248L;

	private Long id;
	private Integer publishedBy;
	private Integer apiId;
	private String apiCode;
	private String apiName;
	private String apiType;
	private String version;
	private String dfltUrl;
	private Integer dfltReadTimeout;
	private Integer dfltConTimeout;
	private String contexPath;
	private Boolean isActive;
	private String description;

}
