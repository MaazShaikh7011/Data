package com.opl.jns.nabard.config.ere.proxies;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * COMMON AUDITOR FOR ALL THE PROXY CLASS
 * 
 * @author harshit.suhagiya
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuditorProxy implements Serializable {

	private static final long serialVersionUID = -4099984998937759889L;

	private Long id;

	private Date createdDate;

	private Long createdBy;

	private Date modifiedDate;

	private Long modifiedBy;

	private Boolean isActive;

}
