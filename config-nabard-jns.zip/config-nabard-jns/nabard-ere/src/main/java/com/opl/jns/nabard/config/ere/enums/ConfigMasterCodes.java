package com.opl.jns.nabard.config.ere.enums;

public enum ConfigMasterCodes {

	BUCKET_CONFIG
}
