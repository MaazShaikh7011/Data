package com.opl.jns.nabard.config.ere.proxies;

import com.opl.jns.nabard.config.ere.enums.APIType;
import com.opl.jns.nabard.config.ere.enums.VersionMaster;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ClientAPIMapProxy extends AuditorProxy {

	private static final long serialVersionUID = -6435699485327797816L;

	private ClientMasterProxy clientMaster;

	private String url;

	private APIType type;

	private VersionMaster version;

	private Integer readTimeOut;

	private Integer conTimeOut;
	
	private String contexPath;
	
	private Long clientId;
}
