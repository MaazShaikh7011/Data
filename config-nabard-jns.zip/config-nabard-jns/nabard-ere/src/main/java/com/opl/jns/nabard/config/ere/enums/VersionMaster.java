package com.opl.jns.nabard.config.ere.enums;

public enum VersionMaster {

	V1, V2, V3

}
