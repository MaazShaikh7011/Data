package com.opl.jns.nabard.config.ere.proxies;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.opl.jns.nabard.config.ere.enums.APIType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonRequest {
    private Integer paginationFROM;
    private Integer paginationTO;
    private String filterJSON;
    private String listKey;
    private String whereClause;
    private Long publishedBy;
    private APIType apiId;
    private Long id;
    private Long roleId;
    private Long typeId;
    private List<Long> menuIdList;

}
