package com.opl.jns.nabard.config.ere.proxies;

import java.time.LocalDateTime;

import org.antlr.v4.runtime.misc.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseCommonProxy {

	private String message;

	private Integer status;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime timestamp;

	@NotNull
	@Size(min = 0, max = 100)
	private String token;

	private Boolean success;

	public ResponseCommonProxy(Integer status, String message) {
		super();
		this.message = message;
		this.status = status;
	}

}
