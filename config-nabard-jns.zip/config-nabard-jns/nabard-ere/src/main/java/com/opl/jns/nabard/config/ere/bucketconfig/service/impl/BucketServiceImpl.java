package com.opl.jns.nabard.config.ere.bucketconfig.service.impl;

import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;
import com.opl.jns.nabard.config.ere.bucketconfig.proxy.BucketConfigProxy;
import com.opl.jns.nabard.config.ere.bucketconfig.service.BucketService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;

@Service
@Slf4j
public class BucketServiceImpl implements BucketService {

	@Autowired
	private BucketConfigProxy bucketConfigProxy;

	/**
	 * UPLOAD OBJECT IN THE S3 BUCKET
	 */
	public String uploadObject(Object object, String docRefrenceId) {
		try {
			log.error("ENTRY IN BUCKET UPLOAD OBJECT------------------->");
			BucketConfigProxy s3Bucket = validate();
			if (s3Bucket == null) {
				log.error("BUCKET PROXY NOT FOUND ------------------->");
				return null;
			}
			File file = new File(docRefrenceId + ".txt");
			try {
				ObjectOutputStream objectOS = new ObjectOutputStream(new FileOutputStream(file));
				objectOS.writeObject(object);
				objectOS.close();
			} catch (Exception e) {
				log.error("EXCEPTION WHILE OBJECT SERIALIZATION -", e);
				return null;
			}
			s3Bucket.getAmazonS3().putObject(
					new PutObjectRequest(s3Bucket.getName() + "/" + s3Bucket.getPath(), file.getName(), file));
		} catch (Exception e) {
			log.error("EXCEPTION WHILE UPLOAD FILE --------------->", e);
		}
		return null;
	}

	private BucketConfigProxy validate() {
		boolean doesBucketExist = bucketConfigProxy.getAmazonS3()
				.doesBucketExist(bucketConfigProxy.getName() + "/" + bucketConfigProxy.getPath());
		if (!doesBucketExist) {
			log.warn("BUCKET PATH NOT AVAILABLE -" + bucketConfigProxy.getName() + "/" + bucketConfigProxy.getPath());
			return null;
		}
		return bucketConfigProxy;
	}

	public Object getFileObject(String bucketName, String docRefrenceId) {
		File file = null;
		try {
			log.error("ENTRY IN BUCKET UPLOAD OBJECT------------------->");
			BucketConfigProxy s3Bucket = validate();
			if (s3Bucket == null) {
				log.error("NO BUCKET FOUND FROM BUCKET NAME --->" + bucketName);
				return null;
			}
			docRefrenceId = docRefrenceId + ".txt";
			file = convertS3ByteToFile(s3Bucket, docRefrenceId);
			if (file == null) {
				log.error("NO FILE FOUND FROM BUCKET --->" + docRefrenceId);
				return null;
			}
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
				Object readObject = ois.readObject();
				return readObject;
			}
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET FILE FROM S3 BUCKET Bytes :-", e);
			return null;
		} finally {
			if (file != null) {
				file.delete();
			}
		}
	}

	private File convertS3ByteToFile(BucketConfigProxy s3Bucket, String fileName) {
		try {
			byte[] fileInByte = getFileBytesFromS3Bucket(fileName, s3Bucket);
			if (fileInByte == null) {
				return null;
			}
			File baseDir = new File("upload");
			if (!baseDir.isDirectory()) {
				baseDir.mkdir();
			}
			File file = new File(baseDir.getAbsolutePath() + "/" + fileName);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(fileInByte);
			fos.close();
			return file;
		} catch (IOException e) {
			log.error("EXCEPTION WHILE READ FILE FROM S3 BUCKET Bytes :-", e);
			return null;
		}
	}


	private byte[] getFileBytesFromS3Bucket(String fileName, BucketConfigProxy bucket) {
		try {
			log.info("Fetching from bucket: {}/{}", bucket.getName(), bucket.getPath());

			S3Object s3Object = bucket.getAmazonS3().getObject(bucket.getName() + "/" + bucket.getPath(),fileName);

			if (s3Object == null) {
				log.info("S3 object is null");
				return null;
			} else {
				log.info("S3 object retrieved successfully");
			}

			try (S3ObjectInputStream inputStream = s3Object.getObjectContent()) {
				return IOUtils.toByteArray(inputStream);
			} catch (IOException e) {
				log.error("Error while reading file content from bucket {}: {}", bucket.getName(), e.getMessage());
				return null;
			}
		} catch (Exception e) {
			log.error("Exception while getting file from bucket", e);
			return null;
		}
	}


}
