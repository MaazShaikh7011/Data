package com.opl.jns.nabard.config.ere.bucketconfig.proxy;

import com.amazonaws.services.s3.AmazonS3;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BucketConfigProxy implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;

	private String path;

	private String url;

	private AmazonS3 amazonS3;

}
