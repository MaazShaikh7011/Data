package com.opl.jns.nabard.config.ere.domain;

import com.opl.jns.nabard.config.ere.proxies.ClientMasterProxy;
import com.opl.jns.nabard.config.ere.utils.DatabaseConstant;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.BeanUtils;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@ToString
@Table(name = "client_master", catalog = DatabaseConstant.JNS_CONFIG, schema = DatabaseConstant.JNS_CONFIG)
public class ClientMaster extends Auditor {

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "org_id", referencedColumnName = "id", nullable = false)
	private OrganizationMaster organizationMaster;

	@Column(name = "user_name", nullable = true)
	private String userName;

	@Column(name = "api_key", nullable = true)
	private String apiKey;

	@Column(name = "public_key", nullable = true)
	private String publicKey;

	@Column(name = "private_key", nullable = true)
	private String privateKey;

	@Column(name = "ips", nullable = true)
	private String ips;

	@Column(name = "login_name", nullable = true)
	private String loginName;

	@Column(name = "password", nullable = true)
	private String password;

	@Column(name = "header_config")
	private String headerConfig;

	@Column(name = "base_url")
	private String baseUrl;

	@Column(name = "test_mode")
	private boolean testMode;
	
	@Column(name = "client_name")
	private String clientName;

	public ClientMasterProxy getProxy() {
		ClientMasterProxy clientMaster = new ClientMasterProxy();
		BeanUtils.copyProperties(this, clientMaster);
		clientMaster.setOrganizationMaster(this.getOrganizationMaster().getProxy());
		return clientMaster;
	}

}
