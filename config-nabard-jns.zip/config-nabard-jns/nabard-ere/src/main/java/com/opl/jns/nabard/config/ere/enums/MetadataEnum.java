package com.opl.jns.nabard.config.ere.enums;

public enum MetadataEnum {

	BANK(1,"BANK","metadata"),
	INSURER(2,"INSURER","meta-data"),
	JANSURAKSHA(3,"JANSURAKSHA","meta-data");


	private final Integer id;
	private final String value;
	private final String metadataValue;

	MetadataEnum(Integer id, String value,String metadataValue) {
		this.id = id;
		this.value = value;
		this.metadataValue = metadataValue;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static MetadataEnum fromId(Integer v) {
		for (MetadataEnum c : MetadataEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static MetadataEnum fromBankValue(String v) {
		for (MetadataEnum c : MetadataEnum.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
	
	public static String getMetadataValueByTypeId(Integer v) {
		for (MetadataEnum c : MetadataEnum.values()) {
			if (c.id.equals(v)) {
				return c.metadataValue;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static OrganizationType[] getAll() {
		return OrganizationType.values();
	}


}
