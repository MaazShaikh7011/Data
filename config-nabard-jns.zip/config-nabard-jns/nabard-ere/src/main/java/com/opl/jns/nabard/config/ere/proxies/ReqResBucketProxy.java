package com.opl.jns.nabard.config.ere.proxies;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReqResBucketProxy implements Serializable {

	private static final long serialVersionUID = 1226471916207266723L;

	private Long id;

	private String requestUrl;

	private String plainReq;

	private String plainRes;

	private String encypReq;

	private String encypRes;

	private Long responseTime;

	private String requestDate;

	private String token;

	private Long clientId;

	private Long clientMapId;

	private Long sourceOrgId;

	private Long destOrgId;

	private String message;

	private String error;

	private String requestHeader;

}
