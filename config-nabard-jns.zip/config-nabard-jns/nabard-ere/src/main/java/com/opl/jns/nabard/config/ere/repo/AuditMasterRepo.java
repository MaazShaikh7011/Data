package com.opl.jns.nabard.config.ere.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.AuditMaster;

public interface AuditMasterRepo extends JpaRepository<AuditMaster, Long> {

}
