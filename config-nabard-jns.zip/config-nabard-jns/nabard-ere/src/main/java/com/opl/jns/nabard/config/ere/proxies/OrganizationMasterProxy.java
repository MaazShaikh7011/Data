package com.opl.jns.nabard.config.ere.proxies;

import com.opl.jns.nabard.config.ere.enums.OrganizationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OrganizationMasterProxy extends AuditorProxy {

	private static final long serialVersionUID = 9194853766685256395L;

	private String code;

	private String name;

	private Integer type;

}
