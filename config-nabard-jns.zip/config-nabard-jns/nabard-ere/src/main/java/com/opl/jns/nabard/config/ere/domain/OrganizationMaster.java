package com.opl.jns.nabard.config.ere.domain;

import com.opl.jns.nabard.config.ere.enums.OrganizationType;
import com.opl.jns.nabard.config.ere.proxies.OrganizationMasterProxy;
import com.opl.jns.nabard.config.ere.utils.DatabaseConstant;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.BeanUtils;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "organization_master", catalog = DatabaseConstant.JNS_CONFIG, schema = DatabaseConstant.JNS_CONFIG)
public class OrganizationMaster extends Auditor {

	@Column(name = "code")
	private String code;

	@Column(name = "name")
	private String name;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Transient
	private OrganizationType organizationType;

	@PostLoad
	void fillTransient() {
		if (organizationType != null) {
			this.organizationType = OrganizationType.fromId(type);
		}
	}

	public OrganizationMasterProxy getProxy() {
		OrganizationMasterProxy masterProxy = new OrganizationMasterProxy();
		BeanUtils.copyProperties(this, masterProxy);
		return masterProxy;
	}

}
