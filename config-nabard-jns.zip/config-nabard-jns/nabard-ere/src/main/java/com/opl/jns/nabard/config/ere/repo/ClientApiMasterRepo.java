package com.opl.jns.nabard.config.ere.repo;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.opl.jns.nabard.config.ere.domain.ClientApiMaster;

@Repository
public interface ClientApiMasterRepo extends JpaRepository<ClientApiMaster, Long> {
	
	public ClientApiMaster findByIdAndIsActiveTrue(Long id);
	
	public ClientApiMaster findFirstByOrderByIdDesc();
	
	public List<ClientApiMaster> findByPublishedBy(Long publishedBy);
	
	@Query("select cam from ClientApiMaster cam")
	public List<ClientApiMaster> getAll(Pageable pageble);
}
