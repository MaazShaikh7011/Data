package com.opl.jns.nabard.config.ere.enums;

public enum OrganizationType {

	BANK(1,"BANK"),
	INSURER(2,"INSURER"),
	JANSURAKSHA(3,"JANSURAKSHA");


	private final Integer id;
	private final String value;

	OrganizationType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public String getValue() {
		return value;
	}

	public static OrganizationType fromId(Integer v) {
		for (OrganizationType c : OrganizationType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static OrganizationType fromBankValue(String v) {
		for (OrganizationType c : OrganizationType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static OrganizationType[] getAll() {
		return OrganizationType.values();
	}


}

