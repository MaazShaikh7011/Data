package com.opl.jns.nabard.config.ere.bucketconfig.service;

public interface BucketService {

	public String uploadObject(Object object, String docRefrenceId);

	Object getFileObject(String bucketName, String fileName);
}
