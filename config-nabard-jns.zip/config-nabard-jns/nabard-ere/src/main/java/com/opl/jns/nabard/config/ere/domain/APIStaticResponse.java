package com.opl.jns.nabard.config.ere.domain;

import com.opl.jns.nabard.config.ere.utils.DatabaseConstant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * TO STORE STATIC RESPONSE IN THE DATABASE FOR TESTING PURPOSE
 * 
 * @author harshit.suhagiya
 *
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "api_static_response", catalog = DatabaseConstant.JNS_CONFIG, schema = DatabaseConstant.JNS_CONFIG)
public class APIStaticResponse {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "api_id")
	private Long apiId;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "sample_json")
	private String sampleJson;

}
