package com.opl.jns.nabard.config.ere.domain;

import com.opl.jns.nabard.config.ere.enums.APIType;
import com.opl.jns.nabard.config.ere.enums.VersionMaster;
import com.opl.jns.nabard.config.ere.proxies.ClientAPIMapProxy;
import com.opl.jns.nabard.config.ere.utils.DatabaseConstant;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.BeanUtils;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "client_api_map", catalog = DatabaseConstant.JNS_CONFIG, schema = DatabaseConstant.JNS_CONFIG)
public class ClientAPIMap extends Auditor {

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", referencedColumnName = "id")
	private ClientMaster clientMaster;

	@Column(name = "url")
	private String url;

	@Column(name = "contex_path")
	private String contexPath;

	@Column(name = "type")
	private Integer typeId;

	@Enumerated(EnumType.STRING)
	@Column(name = "version")
	private VersionMaster version;

	@Column(name = "read_time_out")
	private Integer readTimeOut;

	@Column(name = "con_time_out")
	private Integer conTimeOut;
	
	@Transient
	private APIType type;

	@PostLoad
	void fillTransient() {
		if (typeId!=null) {
			this.type = APIType.fromId(typeId);
		}
	}

	public ClientAPIMapProxy getProxy() {
		ClientAPIMapProxy apiMapProxy = new ClientAPIMapProxy();
		BeanUtils.copyProperties(this, apiMapProxy);
		apiMapProxy.setClientMaster(this.getClientMaster().getProxy());
		return apiMapProxy;
	}

	@Override
	public String toString() {
		return "ClientAPIMap{" +
				"clientMaster=" + clientMaster +
				", url='" + url + '\'' +
				", contexPath='" + contexPath + '\'' +
				", type=" + type +
				", version=" + version +
				", readTimeOut=" + readTimeOut +
				", conTimeOut=" + conTimeOut +
				'}';
	}
}
