package com.opl.jns.nabard.config.ere.proxies;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class APIAuditProxy extends ReqResBucketProxy {

	private static final long serialVersionUID = 2034449352067901980L;

	private Date createdDate;

	private Date modifiedDate;

	private String requestIp;

	private Integer responseStatus;

	private String token;

	private String contextPath;

	private String apiKey;

	private String userName;

	private String sourceToken;

	private Integer sourceType;

}
