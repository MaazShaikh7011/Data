package com.opl.jns.nabard.config.ere.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.nabard.config.ere.domain.OrganizationMaster;

public interface OrganizationMasterRepo extends JpaRepository<OrganizationMaster, Long> {

	public OrganizationMaster findByCodeAndIsActiveTrue(String code);

	public List<OrganizationMaster> findByIsActiveTrue();
	
	public OrganizationMaster findByIdAndIsActiveTrue(Long id);

}
