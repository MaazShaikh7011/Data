package com.opl.jns.nabard.config.updated.common.proxy.notification;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

/**
 * @author Maaz Shaikh
 */
@Setter
@Getter
public class NotificationResponse extends NotificationCommonRes implements Serializable {

    private static final long serialVersionUID = 668251732769674954L;

    private String sentMessage;
    private Long count;
    private Long responseCode;
    private String responseCodeMessage;
    private Object data;
    private String success;
    private String templateName;
    private List<?> listData = Collections.emptyList();
    private Boolean flag;


    public NotificationResponse(String success, Object data, Long responseCode, String responseCodeMessage, String message) {
        super();
        this.success = success;
        this.data = data;
        this.responseCode = responseCode;
        this.setMessage(message);
        this.responseCodeMessage = responseCodeMessage;
    }

    public NotificationResponse(String success, Long responseCode, String responseCodeMessage, String message) {
        super();
        this.success = success;
        this.responseCode = responseCode;
        this.responseCodeMessage = responseCodeMessage;
        this.setMessage(message);
    }


    public NotificationResponse(Long responseCode, String responseCodeMessage, String success) {
        super();
        this.responseCode = responseCode;
        this.responseCodeMessage = responseCodeMessage;
        this.success = success;
    }


    public NotificationResponse(Integer status, Object data, String message, Boolean flag) {
        super();
        this.setStatus(status);
        this.data = data;
        this.setMessage(message);
        this.flag = flag;
    }

    public NotificationResponse(Integer status, String message, List<?> data, Boolean flag) {
        super();
        this.setStatus(status);
        this.listData = data;
        this.setMessage(message);
        this.flag = flag;
    }

    public NotificationResponse(Integer status, String message, Boolean flag) {
        super();
        this.setStatus(status);
        this.setMessage(message);
        this.flag = flag;
    }

    public NotificationResponse() {
        super();
    }


}
