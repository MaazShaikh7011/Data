package com.opl.jns.nabard.config.updated.common.service.impl;

import com.opl.jns.nabard.config.updated.bucketconfig.service.BucketService;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationLogs;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationPayloadAudit;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationProvider;
import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationAuditRequest;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationCommonRes;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationPayLoadProxy;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationLogsRepository;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationPayloadAuditRepository;
import com.opl.jns.nabard.config.updated.common.service.NotificationsHttpUtility;
import com.opl.jns.nabard.config.updated.common.utils.utility.NotificationUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLException;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.Map;

@Service
@Slf4j
public class NotificationHttpUtilityImpl implements NotificationsHttpUtility {

    private static final String ERROR_500 = "An error has occurred during API call. Please attempt the operation again after some time";
    private static final String ERROR_TIMEOUT = "The response time of API is longer than anticipated. Please make another attempt.";

    @Autowired
    private NotificationLogsRepository logsRepository;

    @Autowired
    private BucketService bucketStorageUtils;

    @Autowired
    private NotificationPayloadAuditRepository auditRepository;

    public <T extends NotificationCommonRes> T post(NotificationAuditRequest auditReq, NotificationProvider provider, Map<String, String> additionalHeaders, T respClass) {
        log.info("inside sending Email/Sms to provider [{}]",provider.getProviderName());
        try {
            // SET HEADERS
            HttpHeaders headers = new HttpHeaders();
            headers.add("Cache-Control", "no-cache");
            headers.add("Content-Type", "application/json");
            if (!OPLUtils.isObjectNullOrEmpty(additionalHeaders)) {
                headers.setAll(additionalHeaders);
            }
            auditReq.setHeaders(MultipleJSONObjectHelper.getStringfromObject(headers));

            // call api
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<Object> entity = new HttpEntity<>(auditReq.getReq(), headers);
            ResponseEntity<String> exchange = restTemplate.exchange(auditReq.getUrl(), HttpMethod.POST, entity, String.class);
            auditReq.setStatus(exchange.getStatusCode().value());
            auditReq.setRes(exchange.getBody());
            log.info("{}  TO [{}] and the response status  ====> [{}]",provider.getProviderName(),auditReq.getToStr(),exchange.getStatusCode());
            if (exchange.getStatusCode() == HttpStatus.OK) {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " Sent Successfully : " + exchange.getBody());
            } else if (exchange.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " sending failure - : " + exchange.getBody());
            } else {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " sending failure - : " + exchange.getBody());
            }
        } catch (HttpStatusCodeException e) {
            ResponseEntity<String> resp = ResponseEntity.status(e.getStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
            auditReq.setRes(resp.getBody());
            log.error("END ERROR WHILE CALLING " + provider.getProviderName() + "   API STATUS ---> " + resp.getStatusCode().value()
                    + " AND BODY ----->" + resp.getBody() + NotificationUtils.printLogs(auditReq.getToStr(),auditReq.getType()), auditReq.getType());
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(e.getStatusCode().value());
            if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(), ERROR_TIMEOUT);
            } else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "An error encountered at Provider level. Please try after some time");
            } else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "The Provider services are currently unavailable. Please try again later.");
            } else {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "An error encountered at Provider level. Please try after some time");
            }
        } catch (ResourceAccessException http) {
            log.info("http.getCause() TIMEOUT  {}" , NotificationUtils.printLogs(auditReq.getToStr(), auditReq.getType()), http.getCause());
            auditReq.setFailureReason(http.getCause().getLocalizedMessage());
            if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
                auditReq.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
                return NotificationUtils.reponse(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), ERROR_TIMEOUT);
            } else {
                auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return NotificationUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
            }
        } catch (Exception e) {
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("EXCEPTION WHILE CALLING BANK API {}" , NotificationUtils.printLogs(auditReq.getToStr(), auditReq.getType()), e);
            return NotificationUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
        } finally {
            audit(auditReq, provider);
        }
    }


    public <T extends NotificationCommonRes> T get(NotificationAuditRequest auditReq, NotificationProvider provider, Map<String, String> additionalHeaders, T respClass) {
        try {
            // SET HEADERS
            HttpEntity entity = null;
            if (!OPLUtils.isObjectNullOrEmpty(additionalHeaders)) {
                HttpHeaders headers = new HttpHeaders();
                headers.setAll(additionalHeaders);
                entity = new HttpEntity(headers);
                auditReq.setHeaders(MultipleJSONObjectHelper.getStringfromObject(headers));
            }

            // call api
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> exchange = restTemplate.exchange(auditReq.getUrl(), HttpMethod.GET, entity, String.class);
            auditReq.setStatus(exchange.getStatusCode().value());
            auditReq.setRes(exchange.getBody());
            if (exchange.getStatusCode() == HttpStatus.OK) {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " Sent Successfully : " + exchange.getBody());
            } else if (exchange.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " sending failure - : " + exchange.getBody());
            } else {
                return NotificationUtils.reponse(respClass, auditReq.getStatus(), auditReq.getType().getName() + " sending failure - : " + exchange.getBody());
            }
        } catch (HttpStatusCodeException e) {
            ResponseEntity<String> resp = ResponseEntity.status(e.getStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
            auditReq.setRes(resp.getBody());
            log.error("END ERROR WHILE CALLING {} API STATUS ---> {} AND BODY -----> {} ",provider.getProviderName(),resp.getStatusCode().value(), resp.getBody() + NotificationUtils.printLogs(auditReq.getToStr(), auditReq.getType()));
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(e.getStatusCode().value());
            if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(), ERROR_TIMEOUT);
            } else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "An error encountered at Provider level. Please try after some time");
            } else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "The Provider services are currently unavailable. Please try again later.");
            } else {
                return NotificationUtils.reponse(respClass, e.getStatusCode().value(),
                        "An error encountered at Provider level. Please try after some time");
            }
        } catch (ResourceAccessException http) {
            log.info("http.getCause() TIMEOUT {}" , NotificationUtils.printLogs(auditReq.getToStr(),auditReq.getType()), http.getCause());
            auditReq.setFailureReason(http.getCause().getLocalizedMessage());
            if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
                auditReq.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
                return NotificationUtils.reponse(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), ERROR_TIMEOUT);
            } else {
                auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return NotificationUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
            }
        } catch (Exception e) {
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("EXCEPTION WHILE CALLING BANK API {} " , NotificationUtils.printLogs(auditReq.getToStr(), auditReq.getType()), e);
            return NotificationUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
        } finally {
            audit(auditReq, provider);
        }
    }



    /* AUDITING */
    private void audit(NotificationAuditRequest auditReq, NotificationProvider provider) {
        Date curruntDate = new Date();
        NotificationLogs log = new NotificationLogs();
        log.setTo(auditReq.getToStr());
        log.setReferenceId(auditReq.getReferenceId());
        if (auditReq.getType() == NotificationType.EMAIL) {
            log.setToEmailCount(auditReq.getToLength());
            log.setCcEmailCount(auditReq.getCcLength());
            log.setBccEmailCount(auditReq.getBccLength());
        }
        if (auditReq.getType() == NotificationType.SMS && !OPLUtils.isObjectNullOrEmpty(auditReq.getBody())) {
            log.setContentLength(auditReq.getBody().length());
            double smsCount = Math.ceil((double) auditReq.getBody().length() / 160);
            log.setSmsCount((int) smsCount);
        }
        log.setNotificationTypeId(provider.getNotificationTypeId());
        log.setIsActive(Boolean.TRUE);
        log.setCreatedDate(curruntDate);
        log.setStatus(auditReq.getStatus());
        log.setTemplateId(auditReq.getTemplateId());
        log.setNotificationProvider(provider);
        log = logsRepository.save(log);
        updateBucketLogs(log.getId(), auditReq);
    }



    public String getValue() {
        return System.getenv("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");
    }

    private void updateBucketLogs(Long auditId, NotificationAuditRequest auditReq) {
        String ref = generateRef(auditReq.getReferenceId());
        NotificationPayloadAudit reqResAudit = new NotificationPayloadAudit();
        reqResAudit.setLogAudit(auditId);
        reqResAudit.setStorageId(ref);
        reqResAudit.setSuccess(false);
        reqResAudit.setNotificationTypeId(auditReq.getType().getTypeId());

        NotificationPayLoadProxy loadProxy = new NotificationPayLoadProxy();
        /* EMAIl AUDIT */
        loadProxy.setTo(auditReq.getToStr());
        loadProxy.setCc(NotificationUtils.convertTOCommaSpe(auditReq.getCc()));
        loadProxy.setBcc(NotificationUtils.convertTOCommaSpe(auditReq.getBcc()));
        loadProxy.setSubject(auditReq.getSubject());
        loadProxy.setNotificationMessage(auditReq.getBody());

        /* SMS AUDIT */
        loadProxy.setUrl(auditReq.getUrl());
        loadProxy.setHeader(auditReq.getHeaders());
        loadProxy.setRequest(auditReq.getRequestForAudit());
        loadProxy.setApiResponse(auditReq.getRes());
        loadProxy.setReferenceId(ref);
        loadProxy.setLogAuditId(auditId);
        String upload = bucketStorageUtils.uploadObject(loadProxy, ref);
        if (!OPLUtils.isObjectNullOrEmpty(upload)) {
            reqResAudit.setSuccess(true);
        }
        auditRepository.save(reqResAudit);
    }


    private String generateRef(Long referenceNumber) {
        return "Ntf_" + OPLUtils.generateUUID() + "_" + referenceNumber;
    }
//
//    public <T extends NotificationPayLoadProxy> T fetchMessageFromBucket(Long auditId, int type) {
//        NotificationPayloadAudit notificationPayloadAudit = auditRepository.findFirstByLogAuditAndNotificationTypeId(auditId, (long) type);
//        Object fileObject = bucketStorageUtils.getFileObject(getValue(), notificationPayloadAudit.getStorageId());
//        return (T) fileObject;
//    }

}
