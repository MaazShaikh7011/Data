package com.opl.jns.nabard.config.updated.common.proxy.notification;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class NotificationPayLoadProxy implements Serializable {

    private static final long serialVersionUID = -2316946665465465L;

    private String to;
    private String cc;
    private String bcc;
    private String subject;
    private String url;
    private String request;
    private String header;
    private String apiResponse;

    private String notificationMessage;
    private Long logAuditId;
    private String referenceId;
}