package com.opl.jns.nabard.config.updated.common.repo.notification;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationBasicConfiguration;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NotificationBasicConfigurationRepository extends CrudRepository<NotificationBasicConfiguration, Long> {

    @Cacheable(value = "NOTIFICATION_BASIC_CONFIG_FIND_BY_PROP_NAME_IS_ACTIVE")
    NotificationBasicConfiguration getValueByPropNameAndIsActiveIsTrue(String propName);
//
//    @Cacheable(value = "NOTIFICATION_BASIC_CONFIG_FIND_ALL_BY_IS_ACTIVE")
//    List<NotificationBasicConfiguration> findAllByIsActiveIsTrue();


    @Cacheable(value = "NOTIFICATION_BASIC_CONFIG_FIND_ALL_BY_IS_ACTIVE")
    List<NotificationBasicConfiguration> findAllByTypeAndIsActiveIsTrue(Integer type);

    @Cacheable(value = "NOTIFICATION_BASIC_CONFIG_FIND_VALUE_BY_PROP_NAME")
    @Query("select propValue from NotificationBasicConfiguration where propName=:propName")
    String findPropValueByPropNameAndIsActiveIsTrue(@Param("propName") String propName);
}
