package com.opl.jns.nabard.config.updated.common.domain.notification;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 */
@Entity
@Setter
@Getter
@Table(name = "notification_provider", schema = DBNameConstant.JNS_BANK_API, catalog = DBNameConstant.JNS_BANK_API,indexes =
        {
                @Index(name = "NOTIFICATION_PROVIDER_ACT_TYP_PRNAM_IDX",columnList = "IS_ACTIVE,NOTIFICATION_TYPE_ID,PROVIDER_NAME")
        })
@NamedQuery(name = "NotificationProvider.findAll", query = "SELECT n FROM NotificationProvider n")
@AllArgsConstructor
@NoArgsConstructor
public class NotificationProvider  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true)
    private Long id;

    @Column(name = "password")
    private String password;
    @Column(name = "request_url")
    private String requestUrl;
    @Column(name = "user_name")
    private String userName;
    @Column(name = "notification_type_id")
    private int notificationTypeId;
    @Column(name = "property")
    private String property;
    @Column(name = "provider_name")
    private String providerName;
    @Column(name = "route")
    private Integer route;
    @Column(name = "token")
    private String token;
    @Column(name = "version")
    private String version;
    @Column(name = "api_key")
    private String key;


    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "created_by", nullable = true)
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    @Column(name = "modified_by", nullable = true)
    private Long modifiedBy;

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;

}