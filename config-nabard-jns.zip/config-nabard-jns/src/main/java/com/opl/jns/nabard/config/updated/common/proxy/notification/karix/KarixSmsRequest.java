package com.opl.jns.nabard.config.updated.common.proxy.notification.karix;

import java.util.List;

public class KarixSmsRequest {

    List<Message> messages;
    private String ver;
    private String key;

    public String getVer() {
        return ver;
    }

    public void setVer(String ver) {
        this.ver = ver;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public class Message {

        List<Dest> dest;
        String text;
        String send;
        Long dlt_entity_id;
        Long dlt_template_id;
        String type;

        public List<Dest> getDest() {
            return dest;
        }

        public void setDest(List<Dest> dest) {
            this.dest = dest;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getSend() {
            return send;
        }

        public void setSend(String send) {
            this.send = send;
        }

        public Long getDlt_entity_id() {
            return dlt_entity_id;
        }

        public void setDlt_entity_id(Long dlt_entity_id) {
            this.dlt_entity_id = dlt_entity_id;
        }

        public Long getDlt_template_id() {
            return dlt_template_id;
        }

        public void setDlt_template_id(Long dlt_template_id) {
            this.dlt_template_id = dlt_template_id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

    }

    public class Dest {

        String mobileNo;

        public String getMobileNo() {
            return mobileNo;
        }

        public void setMobileNo(String mobileNo) {
            this.mobileNo = mobileNo;
        }

    }

}
