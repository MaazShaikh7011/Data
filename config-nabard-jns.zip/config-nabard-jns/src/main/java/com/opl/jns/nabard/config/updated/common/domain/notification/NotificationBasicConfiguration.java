package com.opl.jns.nabard.config.updated.common.domain.notification;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author maaz.shaikh
 */

@Setter
@Getter
@Entity
@Table(name = "notification_basic_configuration", schema = DBNameConstant.JNS_BANK_API, catalog = DBNameConstant.JNS_BANK_API,
        indexes = {@Index(columnList = "is_active", name = "BASIC_CONFIG_ACT"),
                @Index(columnList = "prop_name,is_active", name = DBNameConstant.JNS_BANK_API + "_BASIC_CONFIG_PROP_NAME_ACT")}
)
public class NotificationBasicConfiguration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "prop_name")
    private String propName;
    @Column(name = "prop_value")
    private String propValue;
    @Column(name = "type")
    private Integer type;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "is_active")
    private Boolean isActive;
}
