package com.opl.jns.nabard.config.updated.common.domain.notification;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit", schema = DBNameConstant.JNS_NOTIFICATION, catalog = DBNameConstant.JNS_NOTIFICATION,
        indexes = {
                @Index(columnList = "log_audit_id", name = DBNameConstant.JNS_NOTIFICATION + "_payload_audit_log_audit_id_idx"),
                @Index(columnList = "log_audit_id,notification_type_id", name = DBNameConstant.JNS_NOTIFICATION + "_payload_audit_log_audit_id_notification_type_id_idx"),
        })
public class NotificationPayloadAudit implements Serializable {

    @Serial
    private static final long serialVersionUID = -231645826676600012L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "log_audit_id", nullable = true)
    private Long logAudit;

    @Column(name = "storage_id", nullable = true)
    private String storageId;

    @Column(name = "success", nullable = true)
    private Boolean success;

    @Column(name = "notification_type_id", nullable = true)
    private int notificationTypeId;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    public NotificationPayloadAudit() {
        super();
        this.createdDate = new Date();
        this.success = false;
    }
}
