package com.opl.jns.nabard.config.updated.common.proxy.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import lombok.Data;

import java.util.List;

/**
 * @author - Maaz Shaikh
 * @Date - 10/6/2023
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationAuditRequest {
    private Integer status;
    private String url;
    private String subject;
    private String body;
    private String req;
    private String res;

    private Long referenceId;
    private String toStr;
    private List<String> to;
    private List<String> cc;
    private List<String> bcc;
    private Long providerId;


    private int toLength;
    private int ccLength;
    private int bccLength;
    private Long templateId;
    private NotificationType type;
    private Long auditId;
    private String failureReason;
    private String headers;
    private String requestForAudit;

    public NotificationAuditRequest() {
    }

    public NotificationAuditRequest(String url, String subject, String body, List<String> to, List<String> cc, List<String> bcc) {
        this.url = url;
        this.subject = subject;
        this.body = body;
        this.to = to;
        this.cc = cc;
        this.bcc = bcc;
    }

    public NotificationAuditRequest(String url, String content, List<String> to) {
        this.url = url;
        this.body = content;
        this.to = to;
    }


}
