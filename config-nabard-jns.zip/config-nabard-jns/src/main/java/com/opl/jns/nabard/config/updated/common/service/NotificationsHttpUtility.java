package com.opl.jns.nabard.config.updated.common.service;


import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationProvider;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationAuditRequest;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationCommonRes;

import java.util.Map;

public interface NotificationsHttpUtility {

    public <T extends NotificationCommonRes> T post(NotificationAuditRequest auditReq, NotificationProvider provider, Map<String, String> additionalHeaders, T respClass);

    public <T extends NotificationCommonRes> T get(NotificationAuditRequest auditReq, NotificationProvider provider, Map<String, String> additionalHeaders, T respClass);

}
