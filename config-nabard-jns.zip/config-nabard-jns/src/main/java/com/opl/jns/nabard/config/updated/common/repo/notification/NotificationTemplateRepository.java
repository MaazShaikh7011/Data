package com.opl.jns.nabard.config.repository.notification;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate, Long> {


    public NotificationTemplate findByIdAndIsActiveTrue(Long id);

    @Query("select o from NotificationTemplate o where type in (2,3)")
    public List<NotificationTemplate> findAllNotificationType();

}
