package com.opl.jns.nabard.config.updated.common.domain.notification;

import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 */

@Setter
@Getter
@Entity
@Table(name = "notification_template", schema = DBNameConstant.JNS_BANK_API, catalog = DBNameConstant.JNS_BANK_API,indexes = {
        @Index(name = DBNameConstant.JNS_BANK_API + "_TMPL_type_IDX",columnList = "type"),
        @Index(name = DBNameConstant.JNS_BANK_API + "_TMPL_dlt_id_IDX",columnList = "dlt_id"),
        @Index(name = DBNameConstant.JNS_BANK_API + "_TMPL_is_bcc_active_IDX",columnList = "is_bcc_active"),
        @Index(name = DBNameConstant.JNS_BANK_API + "_TMPL_is_active_IDX",columnList = "is_active")
})
@NamedQuery(name = "NotificationTemplate.findAll", query = "SELECT n FROM NotificationTemplate n")
@AllArgsConstructor
@NoArgsConstructor
public class NotificationTemplate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = true)
    private Long id;


    @Column(name = "name")
    private String name;

    @Column(name = "type")
    private int type;

    @Column(name = "subject")
    private String subject;

    @Column(name = "template")
    private String template;

    @Column(name = "dlt_id")
    private Long dltId;

    @Column(name = "is_bcc_active")
    private Boolean isBccActive;

    @Column(name = "bcc")
    private String bcc;

    @Column(name = "description")
    private String notificationDescription;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "created_by", nullable = true)
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    @Column(name = "modified_by", nullable = true)
    private Long modifiedBy;

    @Column(name = "is_active", nullable = true)
    private Boolean isActive;
}