package com.opl.jns.nabard.config.updated.common.repo.notification;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationLogs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationLogsRepository extends JpaRepository<NotificationLogs, Long> {


    NotificationLogs findFirstByNotificationTypeIdAndTemplateIdAndToOrderByIdDesc(int notificationTypeId, Long templateId, String to);

}
