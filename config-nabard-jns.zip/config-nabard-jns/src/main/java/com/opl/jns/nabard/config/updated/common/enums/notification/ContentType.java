package com.opl.jns.nabard.config.updated.common.enums.notification;

public enum ContentType {

    CONTENT, TEMPLATE

}
