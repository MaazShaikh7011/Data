package com.opl.jns.nabard.config.updated.common.utils.utility;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationBasicConfiguration;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationLogs;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationProvider;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationTemplate;
import com.opl.jns.nabard.config.updated.common.enums.notification.ContentType;
import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import com.opl.jns.nabard.config.updated.common.enums.notification.ProviderEnum;
import com.opl.jns.nabard.config.updated.common.proxy.notification.*;
import com.opl.jns.nabard.config.updated.common.proxy.notification.acl.AclRequest;
import com.opl.jns.nabard.config.updated.common.proxy.notification.karix.KarixRequest;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationBasicConfigurationRepository;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationLogsRepository;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationProviderRepository;
import com.opl.jns.nabard.config.updated.common.service.NotificationsHttpUtility;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Maaz Shaikh
 */
@Slf4j
public class NotificationUtils {

    public static final String NOTIFICATION_SERVICE_EXECUTED_SUCCESSFULLY = "Notification Service executed successfully";
    public static final String SMS_REJECTED_CAUSE_ONCE_ALREADY_SENT_TODAY = "SMS Rejected cause once already sent today";
    public static final String EMAIL_REJECTED_CAUSE_ONCE_SENT_IN_A_DAY = "Email Rejected cause once sent in a day";
    public static final String CONTENT_TYPE_REGEX = "\\.(?=[^\\.]+$)";
    private static final String EMAIL_REGEX = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
    private static final Pattern emailPattern = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
    private static final Pattern mobilePatter = Pattern.compile("^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$");
    public static final String VENDER_NAME = "vender_name";
    public static final String FROM_NAME = "fromName";
    public static final String OTP_SMS_MASTER_IDS = "otpSmsMasterIds";
    public static final String YES = "yes";
    public static final int ACL_EMAIL_PROVIDER = 9;
    public static final int KARIX_EMAIL_PROVIDER = 11;
    public static final String FROM = "from";
    public static final String NO_CACHE = "no-cache";
    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String AUTHORIZATION = "Authorization";
    public static final String REJECT_EMAIL_TEMPLATE_ONCE_SENT_IN_A_DAY = "reject_email_template_once_sent_in_a_day";
    public static final String REJECT_SMS_ONCE_SENT_IN_A_DAY = "reject_sms_once_sent_in_a_day";
    public static final String SUBJECT_MAP_PATTERN = "${";
    public static final String PROVIDED_TEMPLATE_ID_IS_INVALID = "Provided template Id is invalid";


    public static String unscapeHtmlFtlTags(String content) {
        return StringEscapeUtils.unescapeHtml(StringEscapeUtils.unescapeXml(content.replace("&nbsp;", " ")));
    }

    public static String printLogs(String to, NotificationType type) {
        return "---TO ---" + to + "---NOTIFICATION_TYPE---" + type.getName() + "----";
    }

    public static Map<String, Object> getValuesFromApplicationProperty(Map<String, Object> parameters, int type, NotificationBasicConfigurationRepository basicConfigRepo) {
        if (OPLUtils.isObjectNullOrEmpty(parameters) || (!OPLUtils.isObjectNullOrEmpty(parameters) && parameters.isEmpty())) {
            parameters = new HashMap<>();
        }
        List<NotificationBasicConfiguration> allByIsActiveIsTrue = basicConfigRepo.findAllByTypeAndIsActiveIsTrue(type);
        for (NotificationBasicConfiguration basicConf : allByIsActiveIsTrue) {
            parameters.put(basicConf.getPropName(), basicConf.getPropValue());
        }
        return parameters;
    }

    public static NotificationResponse validateNotificationRequest(NotificationResponse response, NotificationRequest request) {
        if (OPLUtils.isObjectNullOrEmpty(request.getType())) {
            response.setMessage("Notification Type can not be null");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (OPLUtils.isObjectNullOrEmpty(request.getTo())) {
            response.setMessage("To ids can not be null");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (OPLUtils.isObjectNullOrEmpty(request.getContentType())) {
            response.setMessage("Requested notification is not contain ContentType TEMPLATE OR CONTENT");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if (!request.getContentType().equals(ContentType.TEMPLATE) && !request.getContentType().equals(ContentType.CONTENT)) {
            response.setMessage("Requested notification is not contain ContentType TEMPLATE OR CONTENT");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        return null;
    }

    public static  NotificationProvider getNotificationProviderBasedOnModule(NotificationType type, Long templateId, String smsTemplateIds, NotificationProviderRepository repository) {
        NotificationProvider provider = null;
        try {
            String spRoundRobin = repository.callRoundRobin(type.getName().toUpperCase());
            Map<String, Object> callRoundRobin = MultipleJSONObjectHelper.getObjectFromString(spRoundRobin, Map.class);

            if (null != callRoundRobin && null != callRoundRobin.get(NotificationUtils.VENDER_NAME)) {
                log.info("venderData => {}", callRoundRobin.get(NotificationUtils.VENDER_NAME));
                if (callRoundRobin.get(NotificationUtils.VENDER_NAME).equals("ACL") && type == NotificationType.SMS) {
                    String aclProvider = "AclAlert";
                    if (!OPLUtils.isObjectNullOrEmpty(smsTemplateIds)) {
                        String[] split = smsTemplateIds.split(",");
                        for (String string : split) {
                            if (!OPLUtils.isObjectNullOrEmpty(string) && templateId.equals(Long.valueOf(string))) {
                                aclProvider = "AclOtp";
                            }
                        }
                    }
                    provider = repository.findByIsActiveTrueAndNotificationTypeIdAndProviderName(type.getTypeId(), aclProvider);
                } else {
                    provider = repository.findByIsActiveTrueAndNotificationTypeIdAndProviderName(type.getTypeId(), callRoundRobin.get(NotificationUtils.VENDER_NAME).toString());
                }
                log.info("provider found: {}",provider);
            }else {
                log.error("vendor details not found from roundRobin SP");
            }
        } catch (Exception e) {
            log.error("Exception while fetching Provider for type [{}]", type);
        }
        return provider;
    }

    public static List<String> getBcc(NotificationTemplate template) {
        List<String> bccList = new ArrayList<>();
        if (!OPLUtils.isObjectNullOrEmpty(template.getIsBccActive()) && Boolean.TRUE.equals(template.getIsBccActive())) {
            if (!OPLUtils.isObjectNullOrEmpty(template.getBcc())) {
                for (String bccEmail : template.getBcc().split(",")) {
                    if (Boolean.TRUE.equals(NotificationUtils.validateEmail(bccEmail))) {
                        bccList.add(bccEmail);
                    }
                }
            }
            return  bccList;
        }
        return Collections.emptyList();
    }

    public static List<String> getCc(NotificationRequest request) {
        if (!OPLUtils.isObjectNullOrEmpty(request) && !OPLUtils.isObjectNullOrEmpty(request.getCc())) {
            List<String> ccList = new ArrayList<>();
            for (String cc : request.getCc()) {
                if (Boolean.TRUE.equals(NotificationUtils.validateEmail(cc))) {
                    ccList.add(cc);
                }
            }
            return ccList;
        }
        return Collections.emptyList();
    }

    public static String mapKeysToTemplateForEmail(NotificationRequest request, String template, String templateName, Configuration fmConfiguration) {
        try {
            /* UN-SCAPE CHARACTER AND PREPARE FOR MAPPING DATA */
            if (ContentType.TEMPLATE.equals(request.getContentType())) {
                request.setParameters((Map<String, Object>) printFieldsForValue(request.getParameters()));
                return  getMappedString(unscapeHtmlFtlTags(template),templateName,request.getParameters(),fmConfiguration);
            } else if (ContentType.CONTENT.equals(request.getContentType())) {
                return request.getContent();
            }
        } catch (Exception e) {
            log.error("Exception in parsing template for sending email of Template Id [{}] for to [{}]",request.getTemplateId(),request.getToIdForLogs());
            log.error("Exception in parsing template : ", e);
        }
        return null;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static Object printFieldsForValue(Object obj) throws Exception {
        if (obj != null) {
            if (obj.getClass().isArray()) {
                // Do nothing because of X and Y.
            }
        } else {
            return obj;
        }
        switch (obj) {  // checked instance of
            case Map mapObj -> {
                for (Map.Entry<Object, Object> setEntry : ((Map<Object, Object>) mapObj).entrySet()) {
                    setEntry.setValue(printFieldsForValue(setEntry.getValue()));
                }
            }
            case String str -> {
                obj = StringEscapeUtils.escapeXml(str.replace("--", ""));
                return obj;
            }
            default -> {
                if (obj.getClass().getName().startsWith("com.opl")) {
                    Field[] fields = obj.getClass().getDeclaredFields();
                    for (Field field : fields) {
                        if ((field.getModifiers() & Modifier.STATIC) != Modifier.STATIC) {
                            field.setAccessible(true);
                            Object value = field.get(obj);
                            field.set(obj, printFieldsForValue(value));
//                        } else {
                            // Do nothing because of X and Y.
                        }
                    }
                }
            }
        }
        return obj;
    }

    /* Prepare ACL EMAIL Request  */
    public static AclRequest prepareAclRequest(NotificationRequest req) {
        AclRequest reqAcl = new AclRequest();
        AclRequest.From fromObj = reqAcl.new From();
        fromObj.setEmail(req.getFromEmail());
        fromObj.setName(!req.getParameters().isEmpty() && !OPLUtils.isObjectNullOrEmpty(req.getParameters().get(NotificationUtils.FROM_NAME)) ? req.getParameters().get(NotificationUtils.FROM_NAME).toString() : null);

        List<AclRequest.Recipient> recipient = new ArrayList<>();
        AclRequest.Recipient rec = reqAcl.new Recipient();
        ArrayList<AclRequest.To> arrayList = new ArrayList<>();
        for (String toEmail : req.getTo()) {
            AclRequest.To to = reqAcl.new To();
            to.setEmail(toEmail.trim());
            arrayList.add(to);
        }
        rec.setTo(arrayList);

        if (!OPLUtils.isObjectNullOrEmpty(req.getPreparedCC()) && !req.getPreparedCC().isEmpty()) {
            ArrayList<AclRequest.Cc> ccList = new ArrayList<>();
            for (String ccEmail : req.getPreparedCC()) {
                AclRequest.Cc cc = reqAcl.new Cc();
                cc.setEmail(ccEmail.trim());
                ccList.add(cc);
            }
            rec.setCc(ccList);
        }

        if (!OPLUtils.isObjectNullOrEmpty(req.getPreparedBcc()) && !req.getPreparedBcc().isEmpty()) {
            ArrayList<AclRequest.Bcc> bccList = new ArrayList<>();
            for (String bccEmail : req.getPreparedBcc()) {
                AclRequest.Bcc bcc = reqAcl.new Bcc();
                bcc.setEmail(bccEmail.trim());
                bccList.add(bcc);
            }
            rec.setBcc(bccList);
        }

        if(!OPLUtils.isListNullOrEmpty(req.getContentAttachments())) {
            List<AclRequest.Attachments> attList = new ArrayList<>();
            for (ContentAttachment attachments : req.getContentAttachments()) {
                AclRequest.Attachments att = reqAcl.new Attachments();
                if (!OPLUtils.isObjectNullOrEmpty(attachments.getContentInByte())) {
                    String encoded = Base64.getEncoder().encodeToString(attachments.getContentInByte());
                    att.setContent(encoded);
                    att.setName(attachments.getFileName());
                    att.setType(NotificationUtils.getContentType(attachments.getFileName().split(NotificationUtils.CONTENT_TYPE_REGEX)[1]));
                    attList.add(att);
                }
            }
            rec.setAttachement(attList);
        }

        recipient.add(rec);
        AclRequest.Content content = reqAcl.new Content();

        /* SET CONTENT */
        if (ContentType.CONTENT.equals(req.getContentType())) {
            content.setHtml(req.getContent());
        } else {
            content.setHtml(req.getPreparedTemplate());
        }

        reqAcl.setFrom(fromObj);
        reqAcl.setContent(content);
        reqAcl.setRecipients(recipient);
        reqAcl.setSubject(req.getSubject());
        return reqAcl;
    }

    /* PREPARE KARIX EMAIL REQUEST */
    public static KarixRequest prepareKarixRequest(NotificationRequest req, NotificationProvider provider, Long requestId) {
        KarixRequest reqKarix = new KarixRequest();
        reqKarix.setVersion(provider.getVersion());
        reqKarix.setUserName(provider.getUserName());
        reqKarix.setPassword(provider.getPassword());
        reqKarix.setIncludeFooter(YES);
        KarixRequest.Message message = reqKarix.new Message();
        message.setCustRef(requestId);
        message.setHtml(req.getPreparedTemplate());
        message.setSubject(req.getSubject());
        message.setFromEmail(req.getFromEmail());
        message.setFromName(req.getParameters().get(NotificationUtils.FROM_NAME).toString());
        message.setReplyTo(req.getFromEmail());

        if (ContentType.CONTENT.equals(req.getContentType())) {
            message.setHtml(req.getContent());
        } else {
            message.setHtml(req.getPreparedTemplate());
        }

        message.setRecipients(req.getTo());
        message.setCcRecipients(req.getPreparedCC());
        message.setBccRecipients(req.getPreparedBcc());

        /* SET ATTACHMENT IN REQUEST*/
        if (!OPLUtils.isListNullOrEmpty(req.getContentAttachments())) {
            List<KarixRequest.Attachment> attachmentsList = new ArrayList<>();
            for (ContentAttachment conAttachment : req.getContentAttachments()) {
                KarixRequest.Attachment attachment = reqKarix.new Attachment();
                attachment.setName(conAttachment.getFileName());

                String encoded = Base64.getEncoder().encodeToString(conAttachment.getContentInByte());
                attachment.setAttachmentData(encoded);
                attachmentsList.add(attachment);
            }
            message.setAttachments(attachmentsList);
        }

        reqKarix.setMessage(message);
        return reqKarix;
    }



    public static NotificationResponse sendEmail(NotificationsHttpUtility httpUtility, NotificationRequest request, NotificationProvider provider) {
        NotificationAuditRequest auditReq = new NotificationAuditRequest();
        auditReq.setType(NotificationType.EMAIL);
        auditReq.setTo(request.getTo());
        auditReq.setToStr(request.getToIdForLogs());
        auditReq.setCc(request.getPreparedCC());
        auditReq.setBcc(request.getPreparedBcc());
        auditReq.setBody(request.getPreparedTemplate());
        auditReq.setToLength(request.getTo().size());
        auditReq.setCcLength(request.getCcLength());
        auditReq.setBccLength(request.getBccLength());
        auditReq.setTemplateId(request.getTemplateId());
        auditReq.setProviderId(provider.getId());
        auditReq.setSubject(request.getSubject());
        auditReq.setReferenceId(NotificationUtils.getRandomNumberString());
        NotificationResponse response = new NotificationResponse();
        if (provider.getId() == ACL_EMAIL_PROVIDER) {
            /* PREPARE HEADER */
            Map<String, String> headers = new HashMap<>();
            headers.put(AUTHORIZATION, provider.getToken());
            headers.put(CACHE_CONTROL, NO_CACHE);
            headers.put(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

            /* PREPARE REQUEST */
            AclRequest prepareAclRequest = NotificationUtils.prepareAclRequest(request);
            AclRequest prepareAclRequestForAudit = prepareAclRequest.clone();
            auditReq.setRequestForAudit(getStringFromObject(prepareAclRequestForAudit,"Error in setting ACL EMAIL auditReq in Audit : "));
            auditReq.setUrl(provider.getRequestUrl());
            try {
                auditReq.setReq(MultipleJSONObjectHelper.getStringfromObject(prepareAclRequest));
            } catch (IOException e) {
                log.error("Exception while converting auditReq object to string ", e);
                response.setMessage("Exception in converting auditReq into String");
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return response;
            }

            /* CALL API */
            response = httpUtility.post(auditReq, provider, headers, response);
        } else if (provider.getId() == KARIX_EMAIL_PROVIDER) {
            /* prepare header */
            Map<String, String> headers = new HashMap<>();
            headers.put(CACHE_CONTROL, NotificationUtils.NO_CACHE);
            headers.put(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

            /* PREPARE REQUEST */
            KarixRequest prepareKarixRequest = NotificationUtils.prepareKarixRequest(request, provider, auditReq.getReferenceId());
            KarixRequest prepareKarixRequestForAuditPurpose = prepareKarixRequest.clone();
            auditReq.setRequestForAudit(getStringFromObject(prepareKarixRequestForAuditPurpose,"Error in setting KARIX  auditReq in Audit ::"));

            /* CALL API */
            auditReq.setUrl(provider.getRequestUrl());
            try {
                auditReq.setReq(MultipleJSONObjectHelper.getStringfromObject(prepareKarixRequest));
            } catch (IOException e) {
                response.setMessage("Exception in converting auditReq into String");
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return response;
            }
            response = httpUtility.post(auditReq, provider, headers, response);

            /* SET MESSAGE BASED ON STATUS */
            if (response.getStatus() == HttpStatus.OK.value()) {
                log.info("Email Sent Successfully to [{}] for Template Id [{}]", auditReq.getToStr(), auditReq.getTemplateId());
            } else if (response.getStatus() == HttpStatus.CREATED.value()) {
                response.setMessage("Invalid Username or Password");
            } else if (response.getStatus() == HttpStatus.ACCEPTED.value()) {
                response.setMessage("Invalid Source/ReplyTo/Recipient E-mail ID/Field. As per Email standard, the Email ID should not have invalid characters.");
            } else if (response.getStatus() == HttpStatus.PARTIAL_CONTENT.value()) {
                response.setMessage("Not authorized to access from your IP");
            } else if (response.getStatus() == HttpStatus.NON_AUTHORITATIVE_INFORMATION.value()) {
                response.setMessage("Account deactivated/expired");
            } else if (response.getStatus() == HttpStatus.NOT_EXTENDED.value()) {
                response.setMessage("No credits available in the account");
            } else if (response.getStatus() == HttpStatus.SERVICE_UNAVAILABLE.value()) {
                response.setMessage(HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
            }else{
                log.info("unknown response status : {}",response.getStatus());
            }
            return response;
        } else {
            log.error("Provider not found while sending email to [{}] for template [{}]", auditReq.getToStr(), auditReq.getTemplateId());
            response.setMessage("Provider not found while sending email to " + auditReq.getToStr() + " for template " + auditReq.getTemplateId());
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }

        return response;
    }

    public static String getStringFromObject(Object obj,String logError){
        try {
           return  MultipleJSONObjectHelper.getStringfromObject(obj);
        }catch (Exception e){
            log.error(logError,e);
        }
        return null;
    }

    /* Read string and mapped with keys*/
    public static String readEmailSubject(String subj, String templateName, Map<String,Object> pram,Configuration fmConfiguration) {
        if (subj.contains(SUBJECT_MAP_PATTERN)) {
            return getMappedString(subj, templateName, pram, fmConfiguration);
        } else {
            return subj;
        }
    }

    public static String getMappedString(String template, String templateName, Map<String, Object> pram, Configuration fmConfiguration) {
        try {
            Template temForSubj = new Template(templateName, new StringReader(template), fmConfiguration);
            Writer out = new StringWriter();
            temForSubj.process(pram, out);
            return out.toString();
        } catch (IOException | TemplateException e) {
            log.error("Exception while mapping the dynamic key into subject for template [{}]", templateName);
            return null;
        }
    }


    public static boolean rejectNotificationOnceSentInADay(NotificationRequest request, NotificationBasicConfigurationRepository basicConfigRepo, NotificationLogsRepository notificationLogsRepo) {
        log.info("Inside check notification already sent for type {} and To id [{}]", request.getType(),request.getToIdForLogs());
        boolean isSent = false;
        String key = switch (request.getType()) {
            case EMAIL -> REJECT_EMAIL_TEMPLATE_ONCE_SENT_IN_A_DAY;
            case SMS -> REJECT_SMS_ONCE_SENT_IN_A_DAY;
            default -> null;
        };

        NotificationBasicConfiguration basicConfig = basicConfigRepo.getValueByPropNameAndIsActiveIsTrue(key);
        if (!OPLUtils.isObjectNullOrEmpty(basicConfig)) {
            isSent = isNotificationSent(request.getType(), basicConfig.getPropValue(), request.getTo(), request.getTemplateId(),notificationLogsRepo);
        }

        return isSent;
    }

    /**
     * FIND ONCE EMAIL/SMS SEND TO THIS USER OR NOT
     */
    public static boolean isNotificationSent(NotificationType type, String templateListStr, List<String> to, Long templateId, NotificationLogsRepository notificationLogsRepo) {
        Date currentDate = new Date();
        boolean isSent = false;
        String[] templateList = templateListStr.split(",");
        for (String tem : templateList) {
            if (Long.valueOf(tem).equals(templateId)) {
                for (String stTo : to) {
                    if (!OPLUtils.isObjectNullOrEmpty(stTo)) {
                        NotificationLogs noti = notificationLogsRepo.findFirstByNotificationTypeIdAndTemplateIdAndToOrderByIdDesc(type.getTypeId(), templateId, stTo);
                        if (!OPLUtils.isObjectNullOrEmpty(noti)) {
                            long dayDiff = TimeUnit.DAYS.convert(currentDate.getTime() - noti.getCreatedDate().getTime(), TimeUnit.MILLISECONDS);
                            if (dayDiff == 0) {
                                isSent = true;
                            }
                        }
                    }
                }

            }
        }
        return isSent;
    }






    public static <T extends NotificationCommonRes> T reponse(T classType, Integer status, String message) {
        classType.setStatus(status);
        classType.setMessage(message);
        return classType;
    }

    public static Long getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        SecureRandom rand = new SecureRandom();
        int number = rand.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return (long) number;
    }

    public static String convertTOCommaSpe(List<String> name) {
        try {
            if (!OPLUtils.isObjectNullOrEmpty(name) && !name.isEmpty()) {
                StringBuilder nameBuilder = new StringBuilder();
                for (String n : name) {
                    nameBuilder.append("").append(n.replace("'", "\\'")).append(",");
                }
                nameBuilder.deleteCharAt(nameBuilder.length() - 1);
                return nameBuilder.toString();

            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    /* SMS Methods */
    public static String convertEmailToXxx(String email) {
        try {
            if (email.contains("@") && email.contains(".")) {
                String[] split = email.split("@");
                String[] split2 = split[1].split("\\.");
                String firstPart = split[0];
                String secPart = split2[0];

                String result = null;

                if (firstPart.length() > 5) {
                    result = firstPart.substring(0, 5).concat("xxx");
                } else {
                    result = firstPart;
                }

                if (secPart.length() > 5) {
                    if (split[1].substring(secPart.length()).length() > 5) {
                        int length = split2[split2.length - 1].length() - 4;
                        result = result.concat("@").concat(secPart).concat("xxx");
                        if (length > 0) {
                            result = result.concat(split2[split2.length - 1].substring(split2[split2.length - 1].length() - 4));
                        } else {
                            result = result.concat(split2[split2.length - 1]);
                        }
                    } else {
                        result = result.concat("@").concat(secPart.substring(0, 5)).concat("xxx").concat(split[1].substring(secPart.length()));
                    }
                } else {
                    // make condition of split2.lenght
                    if (split[1].substring(secPart.length()).length() > 5) {
                        int length = split2[split2.length - 1].length() - 4;
                        result = result.concat("@").concat(secPart).concat("xxx");
                        if (length > 0) {
                            result = result.concat(split2[split2.length - 1].substring(split2[split2.length - 1].length() - 4));
                        } else {
                            result = result.concat(split2[split2.length - 1]);
                        }
                    } else {
                        result = result.concat("@").concat(secPart).concat(split[1].substring(secPart.length()));
                    }
                }
                return result;
            }
            return email;
        } catch (Exception e) {
            log.error("Exception in masking email {} And error  is : ", email, e);
            return email;
        }
    }


    public static NotificationResponse sendSMS(NotificationsHttpUtility httpUtility, NotificationRequest request, NotificationProvider provider) {
        String recipient = request.getToIdForLogs();
        NotificationResponse response = new NotificationResponse();
        if (OPLUtils.isObjectNullOrEmpty(recipient)) {
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.setMessage("Phone number can not be null");
            return response;
        }

        request.setUserName(String.valueOf(request.getParameters().get("smsProviderUserName")));
        String requestUrl = null;

        try {
            if (ProviderEnum.ACL_ALERT.equals(provider.getProviderName())) {
                requestUrl = provider.getRequestUrl() + "&from=" + URLEncoder.encode(provider.getUserName(), StandardCharsets.UTF_8) +
                        "&to=" + URLEncoder.encode(recipient, StandardCharsets.UTF_8) +
                        "&text=" +request.getPreparedTemplate()+"&alert=1&selfid=true&dlrreq=false&intflag=false";
            } else if (ProviderEnum.ACL_OTP.equals(provider.getProviderName())) {
                requestUrl = provider.getRequestUrl() + "&msisdn=" + URLEncoder.encode(recipient, StandardCharsets.UTF_8) +
                        "&sender=" + URLEncoder.encode(provider.getUserName(), StandardCharsets.UTF_8) + "&msgtext=" + request.getPreparedTemplate();
            } else if (ProviderEnum.KARIX_SMS.equals(provider.getProviderName())) {
                requestUrl = provider.getRequestUrl() + "ver=" + provider.getVersion() +
                        "&key=" + provider.getKey() + "&encrpt=0&dest=" + URLEncoder.encode(recipient, StandardCharsets.UTF_8) +
                        "&send=" + URLEncoder.encode(provider.getUserName(), StandardCharsets.UTF_8) +
                        "&dlt_entity_id=1201159219814300421&dlt_template_id=" + request.getDltId() + "&text=" + request.getPreparedTemplate();
            }
        } catch (Exception e) {
            log.error("Error in URL encoding to the SMS request for mobile number [{}] and templateId [{}] and exception is ", recipient, request.getTemplateId(), e);
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setMessage("Error in URL encoding to the SMS request for mobile number " + recipient + " and templateId " + request.getTemplateId() + " and exception is " + e.getMessage());
            return response;
        }

        NotificationAuditRequest auditReq = new NotificationAuditRequest();
        auditReq.setUrl(requestUrl);
        auditReq.setType(NotificationType.SMS);
        auditReq.setToStr(recipient);
        auditReq.setTo(request.getTo());
        auditReq.setTemplateId(request.getTemplateId());
        auditReq.setBody(request.getPreparedTemplate());
        auditReq.setProviderId(provider.getId());
        auditReq.setReferenceId(NotificationUtils.getRandomNumberString());

        response = httpUtility.get(auditReq, provider, null, response);
        if (response.getStatus() == HttpStatus.OK.value()) {
            log.info("SMS sent successfully on mobile : [{}]", recipient);
            response.setSentMessage(response.getMessage());
        }
        return response;
    }

    /**
     * @param email
     * @throws
     * @author: maaz.shaikh
     * @Details If email matched or this method return false that means email id is
     * incorrect.
     * @time : 5:11:33 PM - 24-Sep-2019
     */
    public static Boolean validateEmail(String email) {
        if (!OPLUtils.isObjectNullOrEmpty(email) ) {
            Matcher matcher = emailPattern.matcher(email.replaceAll("\\s+", ""));
            return matcher.matches();
        } else {
            return false;
        }
    }


    public static Boolean validateMobile(String mobile) {
        Matcher m = mobilePatter.matcher(mobile);
        return (m.find() && m.group().equals(mobile));
    }


    public static String getContentType(String type) {
        return  switch (type) {
            case "aac" -> "audio/aac";
            case "abw" -> "application/x-abiword";
            case "arc" -> "application/x-freearc";
            case "avi" -> "video/x-msvideo";
            case "azw" -> "application/vnd.amazon.ebook";
            case "bmp" -> "image/bmp";
            case "bz" -> "application/x-bzip";
            case "bz2" -> "application/x-bzip2";
            case "csh" -> "application/x-csh";
            case "csv" -> "text/csv";
            case "doc" -> "application/msword";
            case "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "eot" -> "application/vnd.ms-fontobject";
            case "epub" -> "application/epub+zip";
            case "gz" -> "application/gzip";
            case "gif" -> "image/gif";
            case "htm", "html" -> "text/html";
            case "jar" -> "application/java-archive";
            case "jpeg", "jpg" -> "image/jpeg";
            case "json" -> "application/json";
            case "jsonld" -> "application/ld+json";
            case "mid", "midi" -> "audio/midi audio/x-midi";
            case "mp3" -> "audio/mpeg";
            case "mp4" -> "video/mp4";
            case "mpeg" -> "video/mpeg";
            case "mpkg" -> "application/vnd.apple.installer+xml";
            case "odp" -> "application/vnd.oasis.opendocument.presentation";
            case "ods" -> "application/vnd.oasis.opendocument.spreadsheet";
            case "odt" -> "application/vnd.oasis.opendocument.text";
            case "oga" -> "audio/ogg";
            case "ogv" -> "video/ogg";
            case "ogx" -> "application/ogg";
            case "png" -> "image/png";
            case "pdf" -> "application/pdf";
            case "ppt" -> "application/vnd.ms-powerpoint";
            case "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "rar" -> "application/vnd.rar";
            case "rtf" -> "application/rtf";
            case "svg" -> "image/svg+xml";
            case "tar" -> "application/x-tar";
            case "tif", "tiff" -> "image/tiff";
            case "ts" -> "video/mp2t";
            case "txt" -> "text/plain";
            case "xls" -> "application/vnd.ms-excel";
            case "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "xml" -> "application/xml";
            case "3gp" -> "video/3gpp";
            case "3g2" -> "video/3gpp2";
            case "7z" -> "application/x-7z-compressed";
            default -> "application/octet-stream";
        };
    }
}
