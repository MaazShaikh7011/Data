package com.opl.jns.nabard.config.updated.common.repo.notification;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationProvider;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface NotificationProviderRepository extends JpaRepository<NotificationProvider, Long> {

    @Query(value = "CALL spRoundRobin(:provider)", nativeQuery = true)
    public String callRoundRobin(@Param("provider") String name);

    @Cacheable(value = "NOTIFICATION_PROVIDER_FIND_BY_TYPE_PROVIDER_NAME")
    NotificationProvider findByIsActiveTrueAndNotificationTypeIdAndProviderName(int typeId, String providerName);

}
