package com.opl.jns.nabard.config.updated.common.proxy.notification;

import com.opl.jns.nabard.config.updated.common.enums.notification.ContentType;
import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class NotificationRequest implements Serializable {

    private static final long serialVersionUID = 1571195060508109481L;

    /* REQUEST FIELDS */
    private NotificationType type;
    private List<String> to;
    private List<String> cc;
    private ContentType contentType;
    private String content;
    private String subject;
    private Long templateId;
    private Map<String, Object> parameters = new HashMap<String, Object>();
    private String fileName;
    private List<ContentAttachment> contentAttachments = new ArrayList<ContentAttachment>();


    /* LOGS PURPOSE FIELDS */
    private String toIdForLogs;
    private String fromEmail;
    private List<String> preparedBcc;
    private List<String> preparedCC;
    private String preparedTemplate;
    private int bccLength;
    private int ccLength;
    private int toCount;
    private int messageLength;
    private Long dltId;
    private String userName;

}
