package com.opl.jns.nabard.config.updated.common.repo.notification;

import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationPayloadAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface NotificationPayloadAuditRepository extends JpaRepository<NotificationPayloadAudit, Long> {

    NotificationPayloadAudit findFirstByLogAuditAndNotificationTypeId(Long logAudit, Long type);

}
