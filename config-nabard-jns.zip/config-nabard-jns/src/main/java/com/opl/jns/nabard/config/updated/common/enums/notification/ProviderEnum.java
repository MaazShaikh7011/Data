package com.opl.jns.nabard.config.updated.common.enums.notification;

public class ProviderEnum {

    public static final String ACL_ALERT = "AclAlert";
    public static final String ACL_OTP = "AclOtp";
    public static final String KARIX_SMS = "KARIX_SMS";


    private ProviderEnum() {
        // Do nothing
    }

}
