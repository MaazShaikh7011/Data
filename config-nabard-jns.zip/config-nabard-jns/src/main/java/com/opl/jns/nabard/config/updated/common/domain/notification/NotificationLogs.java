package com.opl.jns.nabard.config.updated.common.domain.notification;

import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import com.opl.jns.utils.constant.DBNameConstant;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 */
@Setter
@Getter
@Entity
@Table(name = "notification_logs", schema = DBNameConstant.JNS_BANK_API, catalog = DBNameConstant.JNS_BANK_API,
        indexes = {
                @Index(columnList = "notification_type_id,is_active,status_code", name = DBNameConstant.JNS_BANK_API + "_type_act_sts"),
                @Index(columnList = "notification_type_id,template_id,to_id", name = DBNameConstant.JNS_BANK_API + "_type_tmplt_to")
        })
@NamedQuery(name = "NotificationLogs.findAll", query = "SELECT n FROM NotificationLogs n")
public class NotificationLogs implements Serializable {
    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "to_id", nullable = false)
    private String to;
    @Column(name = "reference_id")
    private Long referenceId;
    @Column(name = "notification_type_id")
    private int notificationTypeId;
    @Transient
    private NotificationType type;
    @Column(name = "status_code", nullable = false)
    private Integer status;
    @Column(name = "template_id", nullable = false)
    private Long templateId;
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinColumn(name = "provider_id", nullable = false)
    private NotificationProvider notificationProvider;
    @Column(name = "cc_email_count")
    private Integer ccEmailCount;
    @Column(name = "bcc_email_count")
    private Integer BccEmailCount;
    @Column(name = "to_email_count")
    private Integer toEmailCount;
    @Column(name = "sms_count")
    private Integer smsCount;
    @Column(name = "content_length")
    private Integer contentLength;
    @Column(name = "created_date", nullable = false)
    private Date createdDate;
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @PostLoad
    void fillTransient() {
        if (notificationTypeId != 0) {
            this.type = NotificationType.fromId(notificationTypeId);
        }
    }


}