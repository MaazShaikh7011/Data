//package com.opl.jns.nabard.config.boot;
//
//import com.opl.jns.nabard.config.proxy.ApplicationProperties;
//import com.opl.jns.nabard.config.service.commonConfig.impl.ConfigProperties;
//import com.opl.jns.nabard.config.service.commonConfig.ConfigService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//
//@SpringBootApplication
//@ComponentScan(basePackages = {"com.opl"})
//@EnableCaching
//@EnableAutoConfiguration
//@EnableConfigurationProperties(ApplicationProperties.class)
//public class ServiceBankJnsApplication {
//
//    private static final Logger log = LoggerFactory.getLogger(ServiceBankJnsApplication.class);
//
//    @Autowired
//    private ApplicationContext applicationContext;
//
//    @Autowired
//    private ConfigService configService;
//
//    @Autowired
//    private ConfigProperties properties;
//
//    public static void main(String[] args) {
//        SpringApplication.run(ServiceBankJnsApplication.class, args);
//    }
//
//    @Bean
//    CommandLineRunner run() {
//        return args -> {
//            configService.setApiMasters();
//            properties.setAllValue();
//        };
//    }
//
//}
