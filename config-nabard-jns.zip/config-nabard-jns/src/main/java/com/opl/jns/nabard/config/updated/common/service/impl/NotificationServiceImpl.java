package com.opl.jns.nabard.config.updated.common.service.impl;


import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationProvider;
import com.opl.jns.nabard.config.updated.common.domain.notification.NotificationTemplate;
import com.opl.jns.nabard.config.updated.common.enums.notification.ContentType;
import com.opl.jns.nabard.config.updated.common.enums.notification.NotificationType;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationRequest;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationResponse;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationBasicConfigurationRepository;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationLogsRepository;
import com.opl.jns.nabard.config.updated.common.repo.notification.NotificationProviderRepository;
import com.opl.jns.nabard.config.updated.common.service.NotificationService;
import com.opl.jns.nabard.config.updated.common.service.NotificationsHttpUtility;
import com.opl.jns.nabard.config.updated.common.utils.utility.NotificationUtils;
import com.opl.jns.utils.common.OPLUtils;
import freemarker.template.Configuration;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationProviderRepository repository;

    @Autowired
    private com.opl.jns.nabard.config.repository.notification.NotificationTemplateRepository notificationTemplateRepository;

    @Autowired
    private NotificationBasicConfigurationRepository basicConfigRepo;

    @Autowired
    private NotificationLogsRepository notificationLogsRepo;

    @Autowired
    private Configuration fmConfiguration;

    @Autowired
    private NotificationsHttpUtility httpUtility;

    @Autowired
    private com.opl.jns.nabard.config.repository.notification.NotificationTemplateRepository templateRepository;


    @Override
    public NotificationResponse sendNotification(NotificationRequest request) {
        NotificationResponse response = null;

        /* VALIDATING REQUEST */
        response = NotificationUtils.validateNotificationRequest(response, request);
        if (!OPLUtils.isObjectNullOrEmpty(response)){
            return response;
        }

       response = new NotificationResponse();
       switch (request.getType()) {
            case EMAIL:

                /* VALIDATE TO EMAIL */
                List<String> validateTo = new ArrayList<>();
                for (String to : request.getTo()) {
                    if (NotificationUtils.validateEmail(to)) {
                        validateTo.add(to);
                    }
                }

                if (validateTo.isEmpty()) {
                    response.setMessage("Valid to email ids are not found");
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    return response;
                }

                request.setToIdForLogs(NotificationUtils.convertTOCommaSpe(validateTo));
                log.info("email ids are {}", request.getToIdForLogs());
                request.setTo(validateTo);
                /* GETTING VALUES FROM APPLICATION PROPERTY */
                request.setParameters(NotificationUtils.getValuesFromApplicationProperty(request.getParameters(), NotificationType.EMAIL.getTypeId(),basicConfigRepo));
                response = sendEmail(request);
                break;

            case SMS:

                /* VALIDATE MOBILE NUMBER */
                if (OPLUtils.isObjectNullOrEmpty(request.getTo())) {
                    response.setMessage("valid phone number not found");
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    return response;
                }
                List<String> phoneNumberList = new ArrayList<>();
                for (String phone : request.getTo()) {
                    if (NotificationUtils.validateMobile(phone)) {
                        phoneNumberList.add(phone);
                    }
                }

                if (!phoneNumberList.isEmpty()) {
                    request.setTo(phoneNumberList);
                    request.setToCount(phoneNumberList.size());
                } else {
                    response.setMessage("valid phone number not found");
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    return response;
                }

                /* GET COMMON VALUES*/
                request.setParameters(NotificationUtils.getValuesFromApplicationProperty(request.getParameters(),NotificationType.SMS.getTypeId(),basicConfigRepo));

                /* CHECK DYNAMIC PARAMETERS LENGTH */
                if(!OPLUtils.isObjectNullOrEmpty(request.getParameters())) {
                    for (String Parameter : request.getParameters().keySet()) {
                        if (!OPLUtils.isObjectNullOrEmpty(request.getParameters().get(Parameter)) && request.getParameters().get(Parameter).toString().length() > 30) {
                            log.info("Parameter Length Exceed 30 Characters param name {} and value : {}", Parameter, request.getParameters().get(Parameter).toString());
                            response.setMessage(Parameter + " Parameter Length Exceed 30 Characters");
                            response.setStatus(HttpStatus.BAD_REQUEST.value());
                            return response;
                        }
                    }
                }

                response =  sendSMS(request);
                log.info(NotificationUtils.NOTIFICATION_SERVICE_EXECUTED_SUCCESSFULLY);
                break;
            default:
                break;
        }
        return response;
    }


    /* TO SEND EMAIL */
    private NotificationResponse sendEmail(NotificationRequest request) {
        NotificationResponse response = new NotificationResponse();

        /* SET FROM EMAIL */
        request.setFromEmail(basicConfigRepo.findPropValueByPropNameAndIsActiveIsTrue(NotificationUtils.FROM));

        /* FETCH PROVIDER FROM ROUND ROBIN */
        NotificationProvider provider =  NotificationUtils.getNotificationProviderBasedOnModule(NotificationType.EMAIL, request.getTemplateId(), null,repository);
        if (OPLUtils.isObjectNullOrEmpty(provider)) {
            response.setMessage("Email sending failure cause : Provider not found for :" + request.getToIdForLogs());
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        log.info("Provider Found : {}", provider.getProviderName());

        /* GETTING TEMPLATE BY LOAN AND USER ORG ID*/
        NotificationTemplate template = templateRepository.findByIdAndIsActiveTrue(request.getTemplateId());
        if(OPLUtils.isObjectNullOrEmpty(template)){
            response.setMessage(NotificationUtils.PROVIDED_TEMPLATE_ID_IS_INVALID);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if(template.getType() != NotificationType.EMAIL.getTypeId()){
            response.setMessage(NotificationUtils.PROVIDED_TEMPLATE_ID_IS_INVALID);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* IN CASE OF TEMPLATE READING SUBJECT WITH DYNAMIC KEYS */
        if (!OPLUtils.isObjectNullOrEmpty(template) && ! OPLUtils.isObjectNullOrEmpty(template.getTemplate())) {
            if(request.getContentType() == ContentType.TEMPLATE) {
                String mappedSubject = NotificationUtils.readEmailSubject(template.getSubject(), template.getName(), request.getParameters(),fmConfiguration);
                if (OPLUtils.isObjectNullOrEmpty(mappedSubject)) {
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    response.setMessage("Error while mapping the values against key in subject");
                    return response;
                }
                request.setSubject(mappedSubject);
            }
        } else {
            log.error("Email is not active or Subject not found for Template ID [{}] While sending email to [{}]", request.getTemplateId(), request.getToIdForLogs());
            response.setMessage("Email Subject not found or template is not active");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* CHECK HERE IF ANY TEMPLATE HAVE ONCE SENT CONDITION OR NOT */
        boolean isSentOnce = NotificationUtils.rejectNotificationOnceSentInADay(request,basicConfigRepo,notificationLogsRepo);
        if (isSentOnce) {
            response.setMessage(NotificationUtils.EMAIL_REJECTED_CAUSE_ONCE_SENT_IN_A_DAY);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* SET BCC EMAIL IN EMAIL */
        request.setPreparedBcc(NotificationUtils.getBcc(template));
        request.setBccLength(!OPLUtils.isObjectNullOrEmpty(request.getPreparedBcc()) ?request.getPreparedBcc().size() : 0);

        /* SET CC EMAIL IN EMAIL */
        request.setPreparedCC(NotificationUtils.getCc(request));
        request.setCcLength(!OPLUtils.isObjectNullOrEmpty(request.getPreparedCC()) ?request.getPreparedCC().size() : 0);

        /* PREPARE AND MAPPED THE KEYS AND VALUES INTO TEMPLATE */
        if (ContentType.TEMPLATE.equals(request.getContentType())) {
            request.setPreparedTemplate(NotificationUtils.mapKeysToTemplateForEmail(request, template.getTemplate(), template.getName(), fmConfiguration));
        } else if (ContentType.CONTENT.equals(request.getContentType())) {
            request.setPreparedTemplate(request.getContent());
        }

        /* RETURN IN CASE OF CONTENT TYPE IS OTHER THE TEMPLATE AND CONTENT */
        if (!OPLUtils.isObjectNullOrEmpty(request.getPreparedTemplate())) {
            response.setMessage("Exception while mapping the values in templates");
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* SEND EMAIL */
        response = NotificationUtils.sendEmail(httpUtility, request, provider);
        if (!OPLUtils.isObjectNullOrEmpty(response)) {
            log.info("Notification sent for email Id : [{}] and response is [{}]", request.getToIdForLogs(), response.getMessage());
            response.setSentMessage(response.getMessage());
            response.setMessage("Notification Sent and saved");
            response.setStatus(HttpStatus.OK.value());
        } else {
            log.info("Exception in sending Email for email Id : [{}]", request.getToIdForLogs());
            response.setMessage("Exception in sending Email to" + request.getToIdForLogs());
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }
        return response;
    }

    /* TO SEND SMS NOTIFICATION */
    public NotificationResponse sendSMS(NotificationRequest request) {
        NotificationResponse response = new NotificationResponse();
        request.setToIdForLogs(NotificationUtils.convertTOCommaSpe(request.getTo()));

        /* FETCH PROVIDER FROM ROUND ROBIN */
        String otpSms = null;
        if (!OPLUtils.isObjectNullOrEmpty(request.getParameters()) && request.getParameters().containsKey(NotificationUtils.OTP_SMS_MASTER_IDS)) {
            otpSms = request.getParameters().get(NotificationUtils.OTP_SMS_MASTER_IDS).toString();
        }
        NotificationProvider provider = NotificationUtils.getNotificationProviderBasedOnModule(NotificationType.SMS, request.getTemplateId(), otpSms,repository);
        if (OPLUtils.isObjectNullOrEmpty(provider)) {
            response.setMessage("Email sending failure cause : Provider not found for :" + request.getToIdForLogs());
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }
        log.info("Provider Found : {}", provider.getProviderName());


        /* CONVERT EMAIL INTO XXX FORMAT */
        for (Map.Entry<String, Object> map : request.getParameters().entrySet()) {
            if (map.getValue() != null) {
                map.setValue(NotificationUtils.convertEmailToXxx(map.getValue().toString()));
            }
        }

        /* GETTING TEMPLATE BY LOAN AND USER ORG ID*/
        NotificationTemplate template = templateRepository.findByIdAndIsActiveTrue(request.getTemplateId());
        if(OPLUtils.isObjectNullOrEmpty(template)){
            response.setMessage(NotificationUtils.PROVIDED_TEMPLATE_ID_IS_INVALID);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        if(template.getType() != NotificationType.SMS.getTypeId()){
            response.setMessage(NotificationUtils.PROVIDED_TEMPLATE_ID_IS_INVALID);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* MAPPED THE VALUES OF KEYS IN TEMPLATE  */
        request.setDltId(template.getDltId());
        String mappedTemplate = NotificationUtils.getMappedString(template.getTemplate(), template.getName(), request.getParameters(), fmConfiguration);
        request.setPreparedTemplate(mappedTemplate);
        if (OPLUtils.isObjectNullOrEmpty(mappedTemplate)) {
            response.setMessage("Exception while mapping the values in templates");
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            return response;
        }


        /* CHECK HERE IF ANY TEMPLATE HAVE ONCE SENT CONDITION OR NOT */
        boolean isSentOnce = NotificationUtils.rejectNotificationOnceSentInADay(request, basicConfigRepo,notificationLogsRepo);
        if (isSentOnce) {
            response.setMessage(NotificationUtils.SMS_REJECTED_CAUSE_ONCE_ALREADY_SENT_TODAY);
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            return response;
        }

        /* SEND SMS */
        response = NotificationUtils.sendSMS(httpUtility, request,provider);
        log.info("Notification SMS Process Completed for : {}", request.getToIdForLogs());
        return response;
    }

}