package com.opl.jns.nabard.config.updated.common.enums.notification;

import lombok.Getter;

@Getter
public enum NotificationType {

    /**
     * To Set notification Type to Email
     */
    EMAIL(1, "EMAIL"),

    /**
     * To Set notification Type to SMS
     */
    SMS(2, "SMS"),

    /**
     * To Set notification Type to System Notification
     */
    SYSTEM(3, "SYSTEM");

    int typeId;
    String name;

    NotificationType(int typeId, String name) {
        this.typeId = typeId;
        this.name = name;
    }

    public static NotificationType fromId(int v) {
        for (NotificationType c : NotificationType.values()) {
            if (c.typeId == v) {
                return c;
            }
        }
        throw new IllegalArgumentException(String.valueOf(v));
    }


}
