package com.opl.jns.nabard.config.updated.common.proxy.notification.karix;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.jns.utils.common.OPLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class KarixRequest implements Cloneable{


    private static final Logger log = LoggerFactory.getLogger(KarixRequest.class);
    String version;
    String userName;
    String password;
    @JsonProperty("includeFooter")
    String includeFooter;
    Message message;

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @JsonProperty("userName")
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @JsonProperty("password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIncludeFooter() {
        return includeFooter;
    }

    public void setIncludeFooter(String includeFooter) {
        this.includeFooter = includeFooter;
    }

    @JsonProperty("message")
    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    @Override
    public KarixRequest clone() {
        try {
            KarixRequest clone = (KarixRequest) super.clone();
            if(!OPLUtils.isObjectNullOrEmpty(clone.getMessage())) {
                clone.setMessage(clone.getMessage().clone());
                clone.getMessage().setHtml(null);
            }
            return clone;
        }catch (CloneNotSupportedException e){
            log.error("Error while cloning Karix request for Audit purpose : ",e);
        }
        return null;
    }

    public class Message implements Cloneable {

        Long custRef;
        String html;
        String text;
        String subject;
        String fromEmail;
        String fromName;
        String replyTo;
        //		String recipient;
        @JsonProperty("recipients")
        List<String> recipients;
        @JsonProperty("ccRecipients")

//		List<Cc> ccRecipients;
        List<String> ccRecipients;
        @JsonProperty("bccRecipients")
//		List<Bcc> bccRecipients;

        List<String> bccRecipients;
        Template template;
        List<Attachment> attachments;

        @JsonProperty("custRef")
        public Long getCustRef() {
            return custRef;
        }

        public void setCustRef(Long custRef) {
            this.custRef = custRef;
        }

        @JsonProperty("html")
        public String getHtml() {
            return html;
        }

        public void setHtml(String html) {
            this.html = html;
        }

        @JsonProperty("text")
        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        @JsonProperty("subject")
        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        @JsonProperty("fromEmail")
        public String getFromEmail() {
            return fromEmail;
        }


//		public String getRecipient() {
//			return recipient;
//		}
//
//		public void setRecipient(String recipient) {
//			this.recipient = recipient;
//		}

        public void setFromEmail(String fromEmail) {
            this.fromEmail = fromEmail;
        }

        @JsonProperty("fromName")
        public String getFromName() {
            return fromName;
        }

        public void setFromName(String fromName) {
            this.fromName = fromName;
        }

        @JsonProperty("replyTo")
        public String getReplyTo() {
            return replyTo;
        }

        public void setReplyTo(String replyTo) {
            this.replyTo = replyTo;
        }

        public List<String> getRecipients() {
            return recipients;
        }

        public void setRecipients(List<String> recipients) {
            this.recipients = recipients;
        }

        public List<String> getCcRecipients() {
            return ccRecipients;
        }

        public void setCcRecipients(List<String> ccRecipients) {
            this.ccRecipients = ccRecipients;
        }

        public List<String> getBccRecipients() {
            return bccRecipients;
        }

        public void setBccRecipients(List<String> bccRecipients) {
            this.bccRecipients = bccRecipients;
        }

        @JsonProperty("template")
        public Template getTemplate() {
            return template;
        }

        public void setTemplate(Template template) {
            this.template = template;
        }

        @JsonProperty("attachments")
        public List<Attachment> getAttachments() {
            return attachments;
        }

        public void setAttachments(List<Attachment> attachments) {
            this.attachments = attachments;
        }

        @Override
        public Message clone() {
            try {
                return (Message) super.clone();
            } catch (CloneNotSupportedException e) {
                log.error("Error while cloning Message class in Karix request : ",e);
            }
            return null;
        }
    }

    public class Template {

        Long templateId;
        String templateValues;

        @JsonProperty("templateId")
        public Long getTemplateId() {
            return templateId;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        @JsonProperty("templateValues")
        public String getTemplateValues() {
            return templateValues;
        }

        public void setTemplateValues(String templateValues) {
            this.templateValues = templateValues;
        }
    }

    public class Attachment {

        String name;
        String attachmentData;

        @JsonProperty("name")
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty("attachmentData")
        public String getAttachmentData() {
            return attachmentData;
        }

        public void setAttachmentData(String attachmentData) {
            this.attachmentData = attachmentData;
        }
    }


    //	public class Cc {
//
//		@JsonProperty("email")
//		public String getEmail() {
//			return email;
//		}
//
//		public void setEmail(String email) {
//			this.email = email;
//		}
//
//		String email;
//	}
    public class Recipients {

        String email;

        @JsonProperty("email")
        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

//	public class Bcc {
//
//		@JsonProperty("email")
//		public String getEmail() {
//			return email;
//		}
//
//		public void setEmail(String email) {
//			this.email = email;
//		}
//
//		String email;
//	}

}
