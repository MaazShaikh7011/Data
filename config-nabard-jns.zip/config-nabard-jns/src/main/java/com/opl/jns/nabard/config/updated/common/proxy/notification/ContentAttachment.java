package com.opl.jns.nabard.config.updated.common.proxy.notification;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ContentAttachment {

    private String fileName;

    private byte[] contentInByte;

    public ContentAttachment() {
        super();
    }

    public ContentAttachment(String fileName, byte[] contentInByte) {
        super();
        this.fileName = fileName;
        this.contentInByte = contentInByte;
    }

}
