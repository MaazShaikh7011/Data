package com.opl.jns.nabard.config.updated.common.service;

import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationRequest;
import com.opl.jns.nabard.config.updated.common.proxy.notification.NotificationResponse;

public interface NotificationService {

    public NotificationResponse sendNotification(NotificationRequest notificationRequest);

}
