import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UIModule } from './ui/ui.module';
import { CommonSelectComponent } from 'src/app/CommoUtils/Common-Component/common-select/common-select.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { crNumFormatPipe } from 'src/app/CommoUtils/common-services/pipe/cr-num-format.pipe';
import { InputRestrictionDirective } from 'src/app/CommoUtils/common-services/directives/input-restriction.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgOtpInputModule } from 'ng-otp-input';
import { HttpClientModule } from '@angular/common/http';

// import { NgxMaskModule } from 'ngx-mask';
import { UiSwitchModule } from 'ngx-ui-switch';

import { ValidateElementDirective } from 'src/app/CommoUtils/common-services/directives/validate-element.directive';
import { MaterialModule } from './merterial.module';
import { ValidateElementNewDirective } from 'src/app/CommoUtils/common-services/directives/validate-element-new.directive';
import { NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { HighchartsChartModule } from 'highcharts-angular';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgxSelectFilterDirective } from 'src/app/CommoUtils/common-services/directives/ngx-select-filter.directive';
import { NoDataFoundComponent } from 'src/app/CommoUtils/Common-Component/no-data-found/no-data-found.component';
@NgModule({
  declarations: [
    CommonSelectComponent,
    crNumFormatPipe,
    InputRestrictionDirective,    
    ValidateElementDirective,
    ValidateElementNewDirective,
    NgxSelectFilterDirective,
    NoDataFoundComponent
  ],
  imports: [
    CommonModule,
    UIModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
   
    NgOtpInputModule,
    UiSwitchModule,
    HttpClientModule,
    // NgxMaskModule.forRoot(),
    MaterialModule,
    NgOtpInputModule,
    NgbModule,

    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule, 
    NgxMatMomentModule,
    HighchartsChartModule,
    NgxMatSelectSearchModule,
  ],
  exports: [
    CommonSelectComponent,
    ValidateElementDirective,
    ValidateElementNewDirective,
    crNumFormatPipe,
    InputRestrictionDirective,
    UIModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    NgOtpInputModule,
    UiSwitchModule,
    HttpClientModule,
    // NgxMaskModule,
    MaterialModule,

    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule, 
    NgxMatMomentModule,
    NgxMatSelectSearchModule,

    HighchartsChartModule,
    NgxSelectFilterDirective,
    NoDataFoundComponent
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class SharedModule { }
