import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard } from 'src/app/CommoUtils/auth.guard';
import { ChangePasswordComponent } from 'src/app/Component/pages/change-password/change-password.component';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent implements OnInit {

  notificationItems: Array<{}>;
  languages: Array<{
    id: number,
    flag?: string,
    name: string
  }>;
  selectedLanguage: {
    id: number,
    flag?: string,
    name: string
  };
  isLoginUrl: boolean = false;
  isChangePasswordRouterUrl:boolean = false;
  openMobileMenu: boolean;
  userDetails: any = {};
  userId: any;
  @Output() settingsButtonClicked = new EventEmitter();
  @Output() mobileMenuButtonClicked = new EventEmitter();

  constructor(private router: Router, private authGuard: AuthGuard,
    private commonService: CommonService, private userService: UserProfileService) {
    this.userId = Number(CommonService.getStorage(Constants.httpAndCookies.USER_ID, true));
  }

  ngOnInit() {
    // get the notifications
    this.isLoginUrl = (this.router.url === ('/login'));
    this.isChangePasswordRouterUrl = this.router.url.includes('/Change-PassWord');
    this._fetchNotifications();
    this.openMobileMenu = false;
    if (this.userId != 0) {
      this.getUserDetails();
    }
  }


  /**
   * Change the language
   * @param language language
   */
  changeLanguage(language) {
    this.selectedLanguage = language;
  }

  /**
   * Toggles the right sidebar
   */
  toggleRightSidebar() {
    this.settingsButtonClicked.emit();
  }

  /**
   * Toggle the menu bar when having mobile screen
   */
  toggleMobileMenu(event: any) {
    event.preventDefault();
    this.mobileMenuButtonClicked.emit();
  }

  /**
   * Logout the user
   */
  logout() {
    this.authGuard.logoutUser();
  }

  getUserDetails() {
    this.userService.getUserDetails().subscribe(success => {
      if (success.status === 200 && !this.commonService.isObjectNullOrEmpty(success.data)) {
        this.userDetails = success.data
      }

    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }
  /**
   * Fetches the notification
   * Note: For now returns the hard coded notifications
   */
  _fetchNotifications() {
    this.notificationItems = [{
      text: 'Caleb Flakelar commented on Admin',
      subText: '1 min ago',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'primary',
      redirectTo: '/notification/1'
    },
    {
      text: 'New user registered.',
      subText: '5 min ago',
      icon: 'mdi mdi-account-plus',
      bgColor: 'info',
      redirectTo: '/notification/2'
    },
    {
      text: 'Cristina Pride',
      subText: 'Hi, How are you? What about our next meeting',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'success',
      redirectTo: '/notification/3'
    },
    {
      text: 'Caleb Flakelar commented on Admin',
      subText: '2 days ago',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'danger',
      redirectTo: '/notification/4'
    },
    {
      text: 'Caleb Flakelar commented on Admin',
      subText: '1 min ago',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'primary',
      redirectTo: '/notification/5'
    },
    {
      text: 'New user registered.',
      subText: '5 min ago',
      icon: 'mdi mdi-account-plus',
      bgColor: 'info',
      redirectTo: '/notification/6'
    },
    {
      text: 'Cristina Pride',
      subText: 'Hi, How are you? What about our next meeting',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'success',
      redirectTo: '/notification/7'
    },
    {
      text: 'Caleb Flakelar commented on Admin',
      subText: '2 days ago',
      icon: 'mdi mdi-comment-account-outline',
      bgColor: 'danger',
      redirectTo: '/notification/8'
    }];
  }

  changePassword() {
    const config = {
      windowClass: 'popup-600',
      centered: true
    };
    this.commonService.openPopUp(null, ChangePasswordComponent, false, config).result.then(result => { }, (reason) => { });
  }
}
