import { Component, OnInit, AfterViewInit, ElementRef, ViewChild, Input, OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import MetisMenu from 'metismenujs';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

declare var jQuery: any;
declare var $: any;
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, AfterViewInit, OnChanges {
  @Input() isCondensed = false;

  menu: any;

  collapse: boolean = false;
  Dashbordcollapse: boolean = false;
  ProductScoringcollapse: boolean = false;
  UserManagementcollapse: boolean = false;
  Reportscollapse: boolean = false;
  BankProfilecollapse: boolean = false;
  Monitoringcollapse: boolean = false;
  roleId: any
  menuData: any = [
  ];
  roleName: any;
  routeMainPath: any;
  businessTypeId: any;
  schemeId: any;

  @ViewChild('sideMenu', { static: false }) sideMenu: ElementRef;

  constructor(private userService: UserProfileService, private commonService: CommonService, private router: Router) {

  }

  ngOnInit() {
    // this java script Add Nikul Do not-Remove 1-1-2020 Start point
    (function ($) {
      $(document).ready(function () {
        ResizeView();
        //console.log("Working this")
      })

      $(window).resize(function () {
        ResizeView();
      });

    })(jQuery);

    // this java script Add Nikul Do not-Remove 1-1-2020 End Point
    function ResizeView() {
      const width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      if (width < 1450) {
        document.body.classList.add('enlarged');
        document.body.classList.remove('sidebar-enable');
        return true;
      } else {
        document.body.classList.add('sidebar-enable');
        document.body.classList.remove('enlarged');
        return false;
      }
    }

    this.getAllMenuForBanker();
  }

  routeUrl(item) {

    if (this.commonService.isObjectNullOrEmpty(item.navigatePath)) {
      item.isCollapse = !item.isCollapse;
    } else {
      this.router.navigate([item.navigatePath]);
    }


  }
  getAllMenuForBanker() {
    this.userService.getAllMenuForBanker().subscribe(success => {
      if (success.status === 200) {
        this.menuData = JSON.parse(success.data);
        this.menuData = _.orderBy(this.menuData, ['seq'], ['asc']);
        if (!this.commonService.isObjectNullOrEmpty(this.menuData)) {
          this.menuData.forEach(element => {
            if (this.router.url.includes(element.navigatePath)) {
              element.isActive = true;
            }
            if (element.childList && !_.isEmpty(element.childList)) {
              element.childList = _.orderBy(element.childList, ['seq'], ['asc']);
              const isParent = _.find(element.childList, (x: any) => this.router.url.includes(x.navigatePath));
              element.isCollapse = isParent ? true : false;
              element.isActive = isParent ? true : false;
            } else {
              element.childList = []
              element.isCollapse = false;
            }
          });
        }
      } else {
        this.commonService.errorSnackBar("Error While get menu details")
      }
    });
  }

  ngAfterViewInit() {
    this.menu = new MetisMenu(this.sideMenu.nativeElement);

    this._activateMenuDropdown();
  }

  ngOnChanges() {
    if (!this.isCondensed && this.sideMenu || this.isCondensed) {
      setTimeout(() => {
        this.menu = new MetisMenu(this.sideMenu.nativeElement);
      });
    } else if (this.menu) {
      this.menu.dispose();
    }
  }
  /**
   * small sidebar
   */

  smallSidebar() {
    document.body.classList.add('left-side-menu-sm');
    document.body.classList.remove('left-side-menu-dark');
    document.body.classList.remove('topbar-light');
    document.body.classList.remove('boxed-layout');
    document.body.classList.remove('enlarged');
  }

  /**
   * Dark sidebar
   */
  darkSidebar() {
    document.body.classList.remove('left-side-menu-sm');
    document.body.classList.add('left-side-menu-dark');
    document.body.classList.remove('topbar-light');
    document.body.classList.remove('boxed-layout');
  }

  /**
   * Light Topbar
   */
  lightTopbar() {
    document.body.classList.add('topbar-light');
    document.body.classList.remove('left-side-menu-dark');
    document.body.classList.remove('left-side-menu-sm');
    document.body.classList.remove('boxed-layout');

  }

  /**
   * Sidebar collapsed
   */
  sidebarCollapsed() {
    document.body.classList.remove('left-side-menu-dark');
    document.body.classList.remove('left-side-menu-sm');
    document.body.classList.toggle('enlarged');
    document.body.classList.remove('boxed-layout');
    document.body.classList.remove('topbar-light');
  }

  /**
   * Boxed Layout
   */
  boxedLayout() {
    document.body.classList.add('boxed-layout');
    document.body.classList.remove('left-side-menu-dark');
    document.body.classList.add('enlarged');
    document.body.classList.remove('left-side-menu-sm');
  }

  /**
   * Activates the menu dropdown
   */
  _activateMenuDropdown() {

    const links = document.getElementsByClassName('side-nav-link-ref');
    let menuItemEl = null;
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < links.length; i++) {
      // tslint:disable-next-line: no-string-literal
      if (window.location.pathname === links[i]['pathname']) {
        menuItemEl = links[i];
        break;
      }
    }

    if (menuItemEl) {
      menuItemEl.classList.add('active');

      const parentEl = menuItemEl.parentElement;
      if (parentEl) {
        parentEl.classList.add('active');

        const parent2El = parentEl.parentElement;
        if (parent2El) {
          parent2El.classList.add('in');
        }

        const parent3El = parent2El.parentElement;
        if (parent3El) {
          parent3El.classList.add('active');
          parent3El.firstChild.classList.add('active');
        }
      }
    }
  }

}
