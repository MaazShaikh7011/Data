import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-create-branch',
  templateUrl: './create-branch.component.html',
  styleUrls: ['./create-branch.component.scss']
})
export class CreateBranchComponent implements OnInit {
  @ViewChild('createBranch') createBranch: NgForm;
  selectedScheme = [];
  businessTypeId;
  hoList: any = [];
  zoList: any = [];
  roList: any = [];
  branchObj: any = {};
  submitted = false;
  orgList: any = [];
  // schemeMasterList = Constants.schemeMasterList;
  schemeMasterList = [];

  SelectSchemeChipList: any = []
  isView:boolean=false;

  branchType: any = [];
  stateList: any = [];
  cityList: any = [];
  regionList: any = [];
  boReportOffice: any = [];
  boReportOfficeZO: any = [];
  boReportOfficeRO: any = [];
  boReportOfficeHO: any = [];
  countryId = 101;
  branchProductList: any = [];
  branchId: any;
  branchTypeId: any;
  orgId: any;
  isEditBranch: any;

  constructor(private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private activatedRoute: ActivatedRoute,private router:Router) {
    this.activatedRoute.queryParams.subscribe(params => {
      if (!commonService.isObjectNullOrEmpty(params)
        && !commonService.isObjectNullOrEmpty(params.branchId)
        && !commonService.isObjectNullOrEmpty(params.branchTypeId)) {
        this.branchId = Number(CommonService.decryptFuntion(params['branchId']));
        this.branchTypeId = Number(CommonService.decryptFuntion(params['branchTypeId']));
        this.orgId = Number(CommonService.decryptFuntion(params['orgId']));
      }
    });

    this.branchType = [{ branchType: 1, displayOfficeName: 'Branch Office' }];
    this.regionList = [{ regionId: 1, value: 'WEST' }, { regionId: 2, value: 'EAST' }, { regionId: 3, value: 'NORTH' }, { regionId: 4, value: 'SOUTH' }, { regionId: 5, value: 'CENTRAL' }];
    this.boReportOffice = [{ officeId: 1, value: 'Regional Office' }, { officeId: 2, value: 'Zonal Office' }];
    this.boReportOfficeZO = [{ officeId: 2, value: 'Zonal Office' }];
    this.boReportOfficeRO = [{ officeId: 1, value: 'Regional Office' }];
    this.boReportOfficeHO = [{ officeId: 3, value: 'Head Office' }];
  }

  ngOnInit(): void {
    // this.getOfficeList();
    
    this.getSchmeList();
    this.getStateListbyCountryId();
    // this.branchObj.branchType = 1;
    if (this.branchId) {
      this.isEditBranch = true;
      this.getSingleBODetails(this.branchId, this.branchTypeId);
    } else {
      this.isEditBranch = false;
      this.getOrganizationList();
    }
  }

  getSingleBODetails(branchId, businessTypeId) {
    const data = {
      branchId: branchId,
      businessTypeId: businessTypeId,
    }
    this.adminService.getSingleBODetails(data).subscribe(success => {
      if (success.status === 200 && success.data) {
        this.branchObj = JSON.parse(success.data)[0];
        this.selectedScheme = this.branchObj.selectedScheme;
        this.branchObj.code = this.branchObj.branchCode;
        this.branchObj.streetName = this.branchObj.address;
        this.branchObj.contactPersonEmail = this.branchObj.email;
        this.branchObj.contactPersonNumber = this.branchObj.contactNo;
        this.branchObj.name = this.branchObj.branchName;
        this.branchObj.branchType = Number(this.branchTypeId);
        // console.log(this.branchObj);
        this.getOrganizationList();
        this.getCityListByStateId(this.branchObj.stateId);
      }
    }, (error: any) => {
      this.commonService.errorSnackBar(error);
    });
  }

  getOrganizationList() {
    this.adminService.getOrganizationList().subscribe(res => {
      if (res && res.data) {
        this.orgList = res.data;
        if(this.orgId){
          this.branchObj.orgId = Number(this.orgId);
        }
        if (!this.commonService.isObjectNullOrEmpty(this.branchObj.roId)) {
          this.getROList();
          this.branchObj.officeId = 1;
        }
        if (!this.commonService.isObjectNullOrEmpty(this.branchObj.zoId)) {
          this.getZOList();
          this.branchObj.officeId = 2;
        }
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  checkSelectAll() {
    if (this.selectedScheme.length == this.schemeMasterList.length) {
      return true;
    } else {
      return false;
    }
  }

  selectAllSchemes(event) {
    this.selectedScheme = [];
    if (event.target.checked) {
      this.schemeMasterList.forEach(element => {
        this.selectedScheme.push(element.id);
      });
    } else {
      this.selectedScheme = [];
    }
  }

  getOfficeList(): void {
    this.adminService.getOfficeList().subscribe(success => {
      if (success.status === 200 && success.data) {
        this.branchType = JSON.parse(success.data);
      }
    }, error => {
      this.commonService.errorSnackBar(error); 
    });
  }

  // getStateListbyCountryId() {
  //   this.adminService.getStatesByCountryId(this.countryId).subscribe(success => {
  //     if (success.status === 200 && success.listData) {
  //       this.stateList = success.listData;
  //     }
  //   }, error => {
  //     this.commonService.errorSnackBar(error);
  //   });
  // }
  getStateListbyCountryId() {
    this.adminService.getLgdStateList().subscribe(success => {
      if (success?.status === 200 && success?.data) {
        success.data.forEach(element => {
          element.id = element.stateId;
          element.value = element.stateName;
          element.name = element.stateName;
        });
          this.stateList = success.data;
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  // getCityListByStateId(selectedState) {
  //   this.adminService.getCitiesByStateId(selectedState).subscribe(success => {
  //     if (success.status === 200 && success.listData) {
  //       this.cityList = success.listData;
  //     }
  //   }, error => {
  //     this.commonService.errorSnackBar(error);
  //   });
  // }
  getCityListByStateId(stateId) {
      this.adminService.getLgdCityListByLgdStateId(stateId).subscribe(success => {
        if (success?.status === 200 && success?.data) {
          success.data.forEach(element => {
            element.id = element.districtId;
            element.value = element.districtName;
            element.name = element.districtName;
          });
          this.cityList = success.data;
        }
      }, error => {
        this.commonService.errorSnackBar(error);
      });
    }

  getRoZoHoList(branchType) {
    if (this.branchObj.orgId && !_.isEmpty(this.selectedScheme)) {
      if (this.branchObj.officeId && this.branchObj.officeId == 1)
        this.getROList();
      if (this.branchObj.officeId && this.branchObj.officeId == 2)
        this.getZOList();
    }
  }

  getROList() {
    let obj = { orgId: this.branchObj.orgId, selectedScheme: this.selectedScheme };
    this.roList = [];
    this.adminService.getROList(obj).subscribe(success => {
      if (success.status === 200 && success.data) {
        this.roList = JSON.parse(success.data);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getZOList() {
    let obj = {
      orgId: this.branchObj.orgId,
      selectedScheme: this.selectedScheme
    };
    this.zoList = [];
    this.adminService.getZOList(obj).subscribe(success => {
      if (success.status === 200 && success.data) {
        this.zoList = JSON.parse(success.data);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getHOList() {
    let obj = { orgId: this.branchObj.orgId, branchId: this.branchObj.officeId };
    this.adminService.getHOList(obj).subscribe(success => {
      if (success.status === 200 && success.data) {
        this.hoList = JSON.parse(success.data);
        this.branchObj.hoName = this.hoList.branchName;
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getSchmeList() {
    this.adminService.getSchmeListForAdmin().subscribe(res => {
      if (res && res.status == 200 && res.flag == true) {
        this.schemeMasterList = res.data;
        this.schemeMasterList = this.schemeMasterList.filter(a => a.id != -1);
        // console.log(this.schemeMasterList);
        this.isView = true;
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }


  saveBranch() {
    this.submitted = false;
    setTimeout(() => {
      this.submitted = true;
    }, 0);

    this.branchProductList = [];
    this.selectedScheme.forEach(element => {
      const data = this.schemeMasterList.find(a => a.id == element);
      const temp: any = {};
      temp.orgId = this.branchObj.orgId;
      temp.businessTypeId = data.businessId;
      temp.branchRoId = this.branchObj.roId;
      temp.branchZoId = this.branchObj.zoId;
      temp.schemeId = data.id;
      this.branchProductList.push(temp);
    });

    this.branchObj.branchProductList = this.branchProductList;
    this.branchObj.selectedScheme = _.map(this.branchProductList, (x: any) => x.schemeId);
    this.branchObj.isAdminPanel = true;
    // console.log(this.branchObj)
    if (this.createBranch.valid) {
      if (this.isEditBranch) {
        this.adminService.editBranchBranch(this.branchObj).subscribe(success => {
          if (success.status === 200 && success.data) {
            this.commonService.successSnackBar("SuccessFully Updeted");
            this.router.navigate(['/Admin/branch-list'])
          } else if (success.status === 200 && success.data == false) {
            this.commonService.warningSnackBar("Office Code already Exist");
          }
        }, error => {
          this.commonService.errorSnackBar(error);
        });
      } else {
        this.adminService.saveNewBranch(this.branchObj).subscribe(success => {
          if (success.status === 200 && success.data) {
            this.commonService.successSnackBar("SuccessFully Created");
            this.router.navigate(['/Admin/branch-list'])
          } else if (success.status === 200 && success.data == false) {
            this.commonService.warningSnackBar("Branch already Exist");
          }
        }, error => {
          this.commonService.errorSnackBar(error);
        });
      }
    }else{
      this.createBranch.control.markAllAsTouched();
      this.commonService.warningSnackBar("Please fill required fields");
    }
  }

  SelectSchemeChips(selectSchemeChip) {
    this.SelectSchemeChipList = [];
    selectSchemeChip.forEach(element => {
      const tmpScheme = _.find(this.schemeMasterList, (x: any) => x.id == element);
      tmpScheme && this.SelectSchemeChipList.push(tmpScheme.name);
    });
  }
  onToppingRemoved(scheme: string): void {
    const toppings = this.selectedScheme as any;
    // this.singleBranchDetail.selectedScheme = [];
    this.schemeMasterList.forEach(element => {
     if(element.name==scheme){
      this.removeFirst(toppings, element.id);
     }
     
    });
    
    //this.selectSchemeChips(toppings)
  //  this.selectedScheme=toppings; // To trigger change detection
  
  }

  private removeFirst<T>(array: T[], toRemove: T): void {
    this.isView = false
    // console.log('array: ', array);
    // console.log('toRemove: ', toRemove);
    const index = array.indexOf(toRemove);
    if (index !== -1) {
      array.splice(index, 1);
      this.SelectSchemeChipList.splice(index,1);
    }

    const ind = this.selectedScheme.indexOf(toRemove);
    if(ind != -1){
      this.selectedScheme.splice(ind, 1);
    }
    setTimeout(() => {
      this.isView = true
    }, 0);
    
    
  }

}
