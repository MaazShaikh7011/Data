import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-encrypt-decrypt-bank-and-insurer-data',
  templateUrl: './encrypt-decrypt-bank-and-insurer-data.component.html',
  styleUrls: ['./encrypt-decrypt-bank-and-insurer-data.component.scss']
})
export class EncryptDecryptBankAndInsurerDataComponent implements OnInit {
  LODASH = _;
  @ViewChild('encDecData') encDecData: NgForm;
  orgList;
  orgMasterList;
  id;
  encDecType;
  requestData;
  secretKey;
  convertedResponse: any;
  orgRes:any;

  constructor(private adminService: AdminPanelServiceService, private commonService : CommonService, private commonMethod : CommonMethods) { }

  ngOnInit(): void {
    this.getOrgMasterListByApimasterId();
  }

  getOrgMasterListByApimasterId() {
    this.adminService.getAllOrgList().subscribe(res => {
      if (res && res.status == 200) {
        this.orgList = res.data;
        this.orgMasterList = res.data;
      }
    })
  }

  convertData(requestData) {
    if(!this.encDecData.valid){
      this.commonService.warningSnackBar('Please fill required fields');
      return;
    }
    const obj = {
      id: this.id ? this.id : undefined,
      encryptDecryptType: this.encDecType ? this.encDecType : undefined,
      encryptDecryptRequest: requestData ? requestData : undefined,
      secretKey: this.secretKey ? this.secretKey : undefined,
    }
    this.adminService.getEcrDecRes(obj).subscribe(res => {
      if (res && res.data) {
        this.convertedResponse =  res.data;
        this.commonService.successSnackBar(res.message);
      }else{
        this.commonService.errorSnackBar(res.message);
      }
    })
  }

  copyToClipBoard(data, isJson) {
    this.commonMethod.copyToClipBoard(data, isJson);
  }
  
  setOrgRes(res){
    this.orgRes = res;
  }

}
