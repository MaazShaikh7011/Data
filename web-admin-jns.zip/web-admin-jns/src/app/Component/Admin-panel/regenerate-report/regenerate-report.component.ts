import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-regenerate-report',
  templateUrl: './regenerate-report.component.html',
  styleUrl: './regenerate-report.component.scss',
  providers: [DatePipe]
})
export class RegenerateReportComponent implements OnInit {
  LODASH = _;

  orgIds: any = [];
  schemeIds: any = [];
  isListCollapsed: boolean = true;
  dataList: any = [];
  fromDate;
  toDate;
  responseCode;
  orgId: any;
  schemeMasterList;
  tableFilterToggle: Boolean = false;
  filterToggle: Boolean = false;
  bankList:any =[];
  bankMasterList:any =[];
  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  dateFormate = Constants.dateFormat.DDMMYYYYHHMMSS;

  constructor(private datePipe: DatePipe,private adminPanelService: AdminPanelServiceService,private commonService:CommonService) {
    // this.schemeId = commonService.getStorage(Constants.httpAndCookies.SCHEME_ID, true);
    // this.orgId = commonService.getStorage(Constants.httpAndCookies.ORGID, true);
  }

  ngOnInit(): void {
    this.getCommonList(2);
    this.fetchData();
  }


  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.fetchData();
  }

  fetchData() {
    if(this.orgId){
        if(!this.fromDate || !this.toDate){
          this.commonService.warningSnackBar("If orgName selected then date range is mandatory.");
          return;
        }
    }
    const filterJSON = {
      orgId: this.orgId ? this.orgId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
    }
    this.adminPanelService.getDownloadFailedAppLst(filterJSON).subscribe(res => {
      if (res && res.data) {
          this.dataList = res.data;
      } else {
          this.dataList = [];
        }
    });

  }

  toggleFilterBtn() {
    this.filterToggle = false;
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  getCommonList(id) {
    this.adminPanelService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }

  regenerateReport(schemeId,orgId,completionDate) {
    this.orgIds = [];
    this.schemeIds = [];
    this.orgIds.push(orgId);
    this.schemeIds.push(schemeId);
    const filterJSON = {
      orgIds: this.orgIds ? this.orgIds : undefined,
      schemeIds: this.schemeIds ? this.schemeIds : undefined,
      fromDate: completionDate ? this.changeDateFormat(completionDate) : undefined,
      toDate: completionDate ? this.changeDateFormat(completionDate) : undefined,
    }
    this.adminPanelService.regenerateDownloadReport(filterJSON).subscribe(res => {
      if (res && res.flag) {
        this.commonService.successSnackBar("regenerated successfully");
      }else{
        this.commonService.errorSnackBar(res?.message);
      }
    });

  }

}
