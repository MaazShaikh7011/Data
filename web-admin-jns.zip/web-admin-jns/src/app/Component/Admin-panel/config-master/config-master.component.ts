import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-config-master',
  templateUrl: './config-master.component.html',
  styleUrls: ['./config-master.component.scss']
})
export class ConfigMasterComponent implements OnInit {

  apiConfigMasterList;
  configMasterList;

  constructor(private adminService: AdminPanelServiceService, private router: Router) { }

  ngOnInit(): void {
    this.getApiConfigMaster();
    this.getConfigMaster();
  }

  getApiConfigMaster() {
    this.adminService.getApiConfigMaster().subscribe(res => {
      if (res && res.data) {
        this.apiConfigMasterList = JSON.parse(res.data);
      }
    })
  }

  getConfigMaster() {
    this.adminService.getConfigMaster().subscribe(res => {
      if (res && res.data) {
        this.configMasterList = JSON.parse(res.data);
      }
    })
  }
  createConfigMaster() {
    this.router.navigate(['/Admin/add-config']);
  }
  editConfig(id) {
    console.log(id)
    this.router.navigate(['/Admin/add-config'], { queryParams: { id: CommonService.encryptFuntion(id) } });
  }
}
