import { Component, HostListener, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { findIndex } from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
declare var $: any;

@Component({
  selector: 'app-admin-management',
  templateUrl: './admin-management.component.html',
  styleUrls: ['./admin-management.component.scss']
})
export class AdminManagementComponent implements OnInit {

  constructor(private commonService: CommonService,
    private adminService: AdminPanelServiceService) {
  }

  tab!: number;
  adminMenuMaserList;
  adminBasicPermissionMaserList;
  setMenuIdList: any = [];
  setPermissionIdList: any = [];
  isShow: boolean = false;
  isCheckBoxLoad: boolean = false;
  adminRoleId;
  adminPermissionList=[];
  currentAdminRole = CommonService.getStorage(Constants.httpAndCookies.ROLEID, true);


  ngOnInit(): void {
    this.tab = 1;
    // this.getAdminMenuMaserList(this.currentAdminRole);
    this.fetchData();
    this.getAdminPermisssionMaserList(this.currentAdminRole);
  }

  onChangeAdminRole() {
    if (this.adminRoleId) {
      this.isShow = true;
      this.getAdminMenuPermissionMappingList(this.adminRoleId);
    }
  }

  activeClick(tabId: number) {
    this.tab = tabId;
  }

  adjustWidth() {
    var parentwidth = $(".parent").width();
    $(".fix-to-top-3").width(parentwidth);
    // console.log(parentwidth);
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e: any) {
    if (window.pageYOffset > 360) {
      let element: any = document.getElementById('stick-headerN');
      element.classList.add('fix-to-top-3');
      this.adjustWidth();
    } else {
      let element: any = document.getElementById('stick-headerN');
      element.classList.remove('fix-to-top-3');
      //this.adjustWidthRemove();]
      // Fix After Remove Css
      let stickN: any = document.getElementById("stick-headerN");
      stickN.style.width = "100%"
    }
  }

  // getAdminMenuMaserList(adminRoleId) {
  //   const data = {
  //     listKey: 'admin_menu_permission_list',
  //     roleId: adminRoleId
  //   }

  //   this.adminService.getFilterList(data).subscribe(res => {
  //     if (res && res.data) {
  //       this.adminMenuMaserList = JSON.parse(res.data);
  //     }
  //   });
  // }

  getAdminPermisssionMaserList(adminRoleId) {
    const data = {
      roleId: adminRoleId
    }
    this.adminService.getAdminPermisssionMaserList(data).subscribe(res => {
      if (res && res.data) {
        this.adminBasicPermissionMaserList = res.data;
      }
    });
  }
  fetchData(): void {
    const data = {
      listKey:'admin_menu_permission' ,
      whereClause:CommonService.getStorage(Constants.httpAndCookies.ROLEID, true),
      };
      this.adminService.getFilterList(data).subscribe((res: any) => {
        this.adminPermissionList = JSON.parse(res?.data);
      });
    }
    clearFilter(){
      this.adminRoleId=null;
      this.isShow=false;
    }

  getAdminMenuPermissionMappingList(adminRoleId) {
    // const data1 = {
    //   roleId: adminRoleId
    // }
    // this.adminService.getAdminMenuPermissionMappingList(data1).subscribe(res => {
    //   if (res && res.data) {
    //     this.setMenuIdList = _.filter(_.map(res.data, 'menuId'), o => o);
    //     this.setPermissionIdList = _.map(_.filter(res.data, o => o.permissionId), 'permissionId');

    //     this.setMenuIdList.forEach(element => {
    //       const index = _.findIndex(this.adminMenuMaserList, (o: any) => o.id == element);
    //       if (index != -1) {
    //         this.adminMenuMaserList[index].isChecked = true;
    //       }
    //     });

    //     this.setPermissionIdList.forEach(element => {
    //       const index = _.findIndex(this.adminBasicPermissionMaserList, (o: any) => o.id == element);
    //       if (index != -1) {
    //         this.adminBasicPermissionMaserList[index].isChecked = true;
    //       }
    //     });
    //     this.isCheckBoxLoad = true;
    //   }
    // });


    const data = {
        listKey: 'admin_menu_permission_list',
        whereClause: adminRoleId,
      };
      this.adminService.getFilterList(data).subscribe((res: any) => {
        this.adminMenuMaserList = JSON.parse(res.data);
        
        // this.setMenuIdList = _.filter(_.map(res.data, 'menuId'), o => o);
        this.setMenuIdList = _.map(JSON.parse(res.data), 'menuId');
        // this.setPermissionIdList = _.map(_.filter(res.data, o => o.permissionId), 'permissionId');

          this.setMenuIdList.forEach(element => {
          const index = _.findIndex(this.adminMenuMaserList, (o: any) => o.id == element);
          
          if (index != -1) {
            this.adminMenuMaserList[index].isChecked =true ;
            this.adminMenuMaserList[index].isActive =this.adminMenuMaserList[index].IsActive==1 ?true :false ;
          }
        });
        // console.log("masterlist",this.adminMenuMaserList);

        this.setPermissionIdList.forEach(element => {
          const index = _.findIndex(this.adminBasicPermissionMaserList, (o: any) => o.id == element);
          if (index != -1) {
            this.adminBasicPermissionMaserList[index].isChecked = true;
          }
        });

        this.isCheckBoxLoad = true;
    });
  }

  adminRoleChange() {
    this.isCheckBoxLoad = false;
  }

  setMenuPermission() {
    const data = {
      roleId: this.adminRoleId,
      idsList: _.map(_.filter(this.adminMenuMaserList, x => x.isActive), 'id'),
    }
    this.adminService.saveAdminMenuPermission(data).subscribe(res => {
      if (res && res.data) {
        this.commonService.successSnackBar("Successfully Set Permission");
      }
    });
    this.getAdminMenuPermissionMappingList(data.roleId);
  }

  setBasicPermission() {
    const data = {
      roleId: this.adminRoleId,
      idsList: _.map(_.filter(this.adminBasicPermissionMaserList, x => x.isChecked), 'id'),
    }
    this.adminService.saveAdminBasicPermission(data).subscribe(res => {
      if (res && res.data) {
        this.commonService.successSnackBar("Successfully Set Basic Permission");
      }
    });
  }
}
