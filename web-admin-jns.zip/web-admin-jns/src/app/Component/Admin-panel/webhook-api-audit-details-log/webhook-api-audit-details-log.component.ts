import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-webhook-api-audit-details-log',
  templateUrl: './webhook-api-audit-details-log.component.html',
  styleUrls: ['./webhook-api-audit-details-log.component.scss']
})
export class WebhookApiAuditDetailsLogComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  auditLogStartIndex = 0;
  // page number
  page = 1;
  auditLogPage = 1;
  // default page size
  pageSize = 10;
  auditLogPageSize = 10;
  endIndex = 10;
  auditLogEndIndex = 10;

  isListCollapsed: boolean = true;
  dataList: any = [];
  fromDate;
  toDate;
  responseMessage;
  responseCode;
  orgId: any;
  schemeId;
  // SchemeMasterList = Constants.schemeList;
  schemeMasterList;
  tableFilterToggle: Boolean = false;
  filterToggle: Boolean = false;
  totalCount = 0;
  auditLogTotalCount = 0;
  debounceEventForFilter = _.debounce(() => this.fetchData(), 500, {});
  searchAccountNoAndUrn;
  schemeName;
  PageSelectNumber = [5, 10, 20, 50, 100];
  bankList:any =[];
  bankMasterList:any =[];
  searchType;
  searchTypeId;
  apiRespose: any = {};

  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  auditLogList: any =[];
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminPanelService: AdminPanelServiceService,private commonService:CommonService) { 
    // this.schemeId = commonService.getStorage(Constants.httpAndCookies.SCHEME_ID, true);
    // this.orgId = commonService.getStorage(Constants.httpAndCookies.ORGID, true);
  }

  ngOnInit(): void {
    this.getOrgMasterListByApimasterId();
    this.searchType = [
      { id: 1, value: 'Application Id' },
      { id: 2, value: 'Account Number ' },
      { id: 3, value: 'URN'},
      { id: 4, value: 'Token' },
    ];
    this.getAllScheme();
    // this.fetchData(undefined,true);
    // this.fetchData(undefined,false);
  }

  onPageChange(page: any, isFromBucket?): void {
    if(isFromBucket){
      this.auditLogStartIndex = (page - 1) * this.auditLogPageSize;
      this.auditLogEndIndex = (page - 1) * this.auditLogPageSize + this.auditLogPageSize;
      this.fetchData(true, true);
    }else{
      this.startIndex = (page - 1) * this.pageSize;
      this.endIndex = (page - 1) * this.pageSize + this.pageSize;
      this.fetchData(true);
    }
    
  }


  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.schemeId = undefined;
    this.searchTypeId = undefined;
    this.searchAccountNoAndUrn = undefined; 
    this.fetchData();
  }

  fetchData(onPageChangeFlag?, isFromBucket?) {
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }

    // if(this.orgId || onPageChangeFlag==false){
    const filterJSON = {
      orgId: this.orgId ? this.orgId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      // responseCode: this.responseCode ? this.responseCode : undefined,
      // responseMessage: this.responseMessage ? this.responseMessage : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      searchTypeId: this.searchTypeId ? this.searchTypeId : undefined,
      searchAccountNoAndUrn: this.searchAccountNoAndUrn ? this.searchAccountNoAndUrn : undefined,
      paginationFROM: isFromBucket ? (this.auditLogStartIndex ? this.auditLogStartIndex : 0) : (this.startIndex ? this.startIndex : 0),
      paginationTO: isFromBucket ? (this.auditLogPageSize ? this.auditLogPageSize : 10) : (this.pageSize ? this.pageSize : 10),
      isFromBucket: isFromBucket ? true : false
    }
    this.adminPanelService.spGetApplicationWebhookAuditList(filterJSON).subscribe(res => {
      if (res && !_.isEmpty(res.data)) {
        if (isFromBucket) {
          this.auditLogList = JSON.parse(res.data);
          this.auditLogTotalCount = this.auditLogList[0].totalCount || 0;
        } else {
          this.dataList = JSON.parse(res.data);
          this.dataList.forEach(element => {
            element.plainRequest = JSON.parse(element?.plainRequest);
          });
          this.totalCount = this.dataList[0].totalCount || 0;
        }
      } else {
        if (isFromBucket) {
          this.auditLogTotalCount = 0;
          this.auditLogList = [];
        } else {
          this.totalCount = 0;
          this.dataList = [];
        }

      }
    });
    // }else{
    //   this.commonService.warningSnackBar('Please select Bank');
    // }

  }

  toggleFilterBtn() {
    this.filterToggle = false;
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  
  changeDateFormat(date) {
      // const dateParts = date.split('-');
      // const dateObj = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
      return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
  }
  // getCommonList(id) {
  //   this.adminPanelService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
  //     if (res && res.data) {
  //       this.bankList = JSON.parse(res.data);
  //       this.bankMasterList = JSON.parse(res.data);
  //     }
  //   });
  // }
  getAllScheme() {
    this.adminPanelService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }

  getResResBucket(obj, isListCollapsed) {
    if (!isListCollapsed) {
      return;
    }
    if (!obj.storageId) {
      this.commonService.warningSnackBar('File Not Found');
      return;
    }
    this.apiRespose = {};
    this.auditLogList.forEach(element => {
      element.isListCollapsed = false
    });
    this.adminPanelService.getWbResResBucket(obj.storageId).subscribe(res => {
      if (res) {
        const data = res;
        const index = _.findIndex(this.auditLogList, (x: any) => x.id == obj.id);
        if (index != -1) {
          this.auditLogList[index].isListCollapsed = true;
        }
        console.log(data,"data")
        this.apiRespose = data
        // this.apiRespose.requestUrl = data.requestUrl;
        // this.apiRespose.requestHeader = data.requestHeader;
        // this.apiRespose.referenceId = data.referenceId;
        // this.apiRespose.logAuditId = data.logAuditId;
        // this.apiRespose.plainRequest = data.requestPlain;
        // this.apiRespose.plainResponse = data.responsePlain;
        // this.apiRespose.request = data.requestEncrypt;
        // this.apiRespose.encryptResponse = data.responseEncrypt;
      } else {
        this.commonService.infoSnackBar('Data Not Found');
      }
    });
  }
  search(){
    this.fetchData(false,true);
  }

  getOrgMasterListByApimasterId() {
    this.adminPanelService.getAllOrgList().subscribe(res => {
      if (res && res.status == 200) {
        this.bankList = res.data;
        this.bankMasterList = res.data;
      }
    })
  }

  downloadFile(apiName,urn) {
    var sJson = JSON.stringify(this.apiRespose, undefined, 2).replace(/\\/g,'');
    var element = document.createElement('a');
    element.setAttribute('href', "data:text/json;charset=UTF-8," + encodeURIComponent(sJson));
    element.setAttribute('download', apiName+"_"+urn + ".txt");
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }

}
