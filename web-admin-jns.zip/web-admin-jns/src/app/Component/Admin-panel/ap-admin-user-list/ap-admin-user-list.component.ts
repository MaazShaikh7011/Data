import { Component, OnInit } from '@angular/core';
import { InPrincipleApplications } from 'src/app/CommoUtils/common-services/Product-Scoring-Data/customers.model';
import { InPrincipleApplication } from 'src/app/CommoUtils/common-services/Product-Scoring-Data/dataCustomer';
import { Observable } from 'rxjs';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { DatePipe } from '@angular/common';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';

@Component({
  selector: 'app-ap-admin-user-list',
  templateUrl: './ap-admin-user-list.component.html',
  styleUrls: ['./ap-admin-user-list.component.scss'],
  providers: [DatePipe]
})
export class APAdminUserListComponent implements OnInit {

  // bread crumb items
  breadCrumbItems: Array<{}>;

  selectValue: string[];
  InPrincipleApplication: InPrincipleApplications[];

  // page number
  page = 1;
  // default page size
  pageSize = 10;

  // start and end index
  startIndex = 1;
  endIndex = 10;
  totalSize = 0;

  PageSelectNumber: string[];

  total$: Observable<number>;
  debounceEventForFilter = _.debounce(() => this.getUserAdminList(), 500, {});
  userAdminList: any;
  totalCount;
  fromDate;
  toDate;
  applicantName;
  canCreate:Boolean=false;
  adminPermissionList: any = [];
  currentAdminRole = CommonService.getStorage(Constants.httpAndCookies.ROLEID, true);
  childUserId: any;
  todayDate: Date = new Date();
  constructor(private adminService: AdminPanelServiceService,
    private router: Router,
    private commonService: CommonService,
    private commonMethods: CommonMethods,
    private datePipe: DatePipe,) { }

  ngOnInit(): void {
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
    this.selectValue = ['Working Capital Term Loan', 'Working Capital Term Loan', 'Term Loan'];

    this.InPrincipleApplication = InPrincipleApplication;
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
 
    this.fetchData();
    this.getUserAdminList();
    this.creteUserPermission();
    
  }
  clearFilter(){
    this.childUserId=null;
    this.toDate=null;
    this.fromDate=null;
    this.applicantName=null;
    this.getUserAdminList();
  }
  fetchData(): void {
    const data = {
      listKey:'admin_menu_permission' ,
      whereClause:CommonService.getStorage(Constants.httpAndCookies.ROLEID, true),
      };
      this.adminService.getFilterList(data).subscribe((res: any) => {
        this.adminPermissionList = JSON.parse(res?.data);
      });
    }
  
  getFormatedDate(date): any {
    // const dateParts = date.split('-');
    // const dateObj = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    // return this.datePipe.transform(dateObj, 'y/MM/dd');
    return this.datePipe.transform(date, 'dd-MM-y');
  }
  creteUserPermission(){
    // console.log( this.commonService.getStorage("usr_role_id",true));
    let val =this.commonService.getStorage("usr_role_id",true);
    if(val==101 || val==102 || val==106){
      this.canCreate= true;
    }
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.getUserAdminList(true);
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }

  omit_special_char(event) {
    var k;
    k = event.charCode;  //         k = event.keyCode;  (Both can be used)
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }

  getUserAdminList(onPageChangeFlag?) {
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    const data = {
      filterJSON: {
        fromDate: this.fromDate ? this.getFormatedDate(this.fromDate) : undefined,
        toDate: this.toDate ? this.getFormatedDate(this.toDate) : undefined,
        applicantName: this.applicantName || undefined,
        adminRoleId: CommonService.getStorage(Constants.httpAndCookies.ROLEID, true) || undefined,
        childUserId: this.childUserId || undefined
      },
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getUserAdminList(data).subscribe(res => {
      this.userAdminList = [];
      if (res && res.data) {
        this.userAdminList = JSON.parse(res.data);
        this.totalCount = this.userAdminList[0].totalCount;
      }
    });
  }

  goToPermissionPage(data) {
    this.router.navigate(['/Admin/AP-Permission'], { queryParams: { roleId: CommonService.encryptFuntion(data.roleId), role: CommonService.encryptFuntion(data.role), userId: CommonService.encryptFuntion(data.userId) } });
  }

  activeIsActiveUser(userId, isActive) {
    const data = {
      userId: userId,
      isActive: isActive,
    };
    this.adminService.activeIsActiveUser(data).subscribe(res => {
      if (res) {
        this.getUserAdminList(true);
      }
    });
  }

  userResetPassword(userId) {
    const data = {
      userId: userId,
    };
    this.adminService.userResetPassword(data).subscribe(res => {
      if (res) {
        this.getUserAdminList();
        this.commonService.successSnackBar(res.message);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }

  lockUnlockUser(userId) {
    const data = {
      userId: userId,
    };
    this.adminService.lockUnlockUser(data).subscribe(res => {
      if (res) {
        this.getUserAdminList();
        this.commonService.infoSnackBar(res.message);
      }
    });
  }

  copyToClipBoard(data) {
    this.commonMethods.copyToClipBoard(data);
  }

  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }
}
