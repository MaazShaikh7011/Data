import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';

@Component({
  selector: 'app-application-status-master',
  templateUrl: './application-status-master.component.html',
  styleUrls: ['./application-status-master.component.scss']
})
export class ApplicationStatusMasterComponent implements OnInit {

  applicationStatus;
  applicationStage;

  constructor(private adminService: AdminPanelServiceService) { }

  ngOnInit(): void {
    this.getMasterList();
  }

  getMasterList() {
    const masterObj = ['APPLICATION_STATUS','ENROLLSTAGEMASTER'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.applicationStatus = res.data.APPLICATION_STATUS;
        this.applicationStage = res.data.ENROLLSTAGEMASTER;
      }
    })
  }

}
