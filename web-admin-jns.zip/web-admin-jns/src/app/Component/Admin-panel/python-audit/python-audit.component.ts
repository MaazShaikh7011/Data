import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-python-audit',
  templateUrl: './python-audit.component.html',
  styleUrls: ['./python-audit.component.scss']
})
export class PythonAuditComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount ;
  isListCollapsed: boolean = true;
  searchData;
  bankList :any =[];
  bankMasterList : any =[];
  orgId;
  userorgName;
  registryDataList :any =[];
  searchType;
  searchTypeId;
  listRegistryReqUrl;
  registryurl;
  fromDate: any;
  toDate: any;

  apiRespose: any= {};

  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private userService: UserProfileService) { 
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  ngOnInit(): void {
    this.getMasterList();
    this.getCommonList(2);
    this.searchType = [
      { id: 1, value: 'ReqLogId' },
      { id: 2, value: 'Request Url' },
      { id: 3, value: 'Application Id' },
      { id: 4, value: 'Account No' },
      { id: 5, value: 'Cif' },
    ];
    // this.fetchRegistryDataList();
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }
  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchRegistryDataList(true);
  }
  
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:mm:ss aaa');
}

  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.searchTypeId = undefined;
    this.registryurl= undefined;
    this.searchData = undefined;
    this.fetchRegistryDataList();
  }

  fetchRegistryDataList(onPageChangeFlag?){
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
      const data = {     
        type : 2 ,
        searchData: this.searchData ? this.searchData : undefined,
        toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        orgId: this.orgId ? this.orgId : undefined,
        searchTypeId : this.searchTypeId ? this.searchTypeId :undefined,
        requrl : this.registryurl ? ( this.registryurl) : undefined,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: onPageChangeFlag==false ? 0 : this.pageSize
      }
      this.adminService.fetchDDRegistryAuditDetails(data).subscribe(res => {
          if (res && res.data) {
          this.registryDataList = JSON.parse(res.data);
          this.totalCount = this.registryDataList[0].totalCount || 0;
        }
         else {
          this.totalCount = 0;
          this.registryDataList = [];
        }
      });

  }

  getApiData(auditId, isListCollapsed){
    console.log('isListCollapsed: ', isListCollapsed);
    console.log('auditId: ', auditId);
    // console.log('fileName: ', auditId);
    if(!isListCollapsed){
      return;
    } 
    if(!auditId){
      this.commonService.warningSnackBar('File Not Found');
      return;
    }
    this.apiRespose = undefined;
    this.registryDataList.forEach(element => {
      element.isListCollapsed = false
    });
    this.adminService.getDDRegistryReqRes(auditId).subscribe(res => {
      if (res.data) {
        const data = res.data;
        const index = _.findIndex(this.registryDataList, (x: any) => x.id == auditId);
        if (index != -1) {
          this.registryDataList[index].isListCollapsed = true;
        }
        this.apiRespose = {
          reqLogAuditId: data.reqLogAuditId,
          referenceId: data.referenceId,
          plainRequest: data.plainRequest,
          plainResponse: data.plainResponse,
        }
      } else {
        this.commonService.infoSnackBar('Data Not Found');
      }
    });
  }

  getMasterList() {
    this.userService.apiList().subscribe(res => {
      
      if (res && res.status == 200 && res.data) {
        this.listRegistryReqUrl = res.data;
      }
    })
  }
  clearSearchType(){
    this.fromDate=undefined;
    this.toDate=undefined;
    this.registryurl = undefined;
    this.searchData = undefined;
  }
}
