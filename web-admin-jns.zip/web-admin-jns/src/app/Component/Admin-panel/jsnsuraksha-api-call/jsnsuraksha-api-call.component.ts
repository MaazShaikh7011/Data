import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-jsnsuraksha-api-call',
  templateUrl: './jsnsuraksha-api-call.component.html',
  styleUrls: ['./jsnsuraksha-api-call.component.scss']
})
export class JsnsurakshaApiCallComponent implements OnInit {
  LODASH = _;
  @ViewChild('jansurakshaApi') jansurakshaApi: NgForm;
  orgList;
  orgMasterList;
  orgId;
  requestData;
  convertedResponse: any;
  apiId:any;
  apiName: any;
  apiList: any = [];
  headerList : any=[];
  apiNameUserNameList;
  encDecTypeList = [
    { id: 1, value: 'Skip Encrypt Decrypt' },
    { id: 2, value: 'Skip Encrypt' },
    { id: 3, value: 'Skip Decrypt'},
    { id: 4, value: 'None of the above' },
  ];
  encDecTypeId = 1;
 
  constructor(private adminService: AdminPanelServiceService,
     private commonService : CommonService,
     private commonMethod : CommonMethods) {
      }

  ngOnInit(): void {
    this.getOrgMasterListByApimasterId();
    this.getApiList();
  }

  getOrgMasterListByApimasterId() {
    this.adminService.getAllOrgList().subscribe(res => {
      if (res && res.status == 200) {
        this.orgList = res.data;
        this.orgMasterList = res.data;
      }
    })
  }
  copyToClipBoard(data, isJson) {
    this.commonMethod.copyToClipBoard(data, isJson);
  }
  getApiList() {
    const masterObj = ['JANSURAKSHA_API_LIST'];
    this.adminService.getMasterListByKey(masterObj).subscribe((res) => {
      if (res && res.status == 200 && res.data) {
        this.apiList = res.data.JANSURAKSHA_API_LIST;
        // console.log(this.apiList)
      }
    });
  }
  isSingleChecked(){

  }
  getApiUserListByOrgId() {
    this.apiId = undefined;
    this.requestData = undefined;
    this.convertedResponse = undefined;
    console.log(this.orgId)
    this.adminService.getApiUserListByOrgId(this.orgId).subscribe(res => {
      if (res && res.status == 200) {
        this.apiNameUserNameList = res.data;
      }
    });
  }

  fetchRequest(apiId){
    this.requestData = null;
    this.convertedResponse = null;
    const req={
      userTypeId : 0,
      apiId : apiId ? apiId : undefined,
    }
    this.adminService.fetchBankWebhookRequest(req).subscribe((res) => {
      if (res && res.data) {
        this.requestData =  JSON.stringify(JSON.parse(res.data), undefined, 2);
      }
    });
  }
  convertData(){
    if(this.orgId == null ){
      this.commonService.warningSnackBar('Please Select Organisation');
      return;
    }
    if(this.apiId == null ){
      this.commonService.warningSnackBar('Please Select Any Api');
      return;
    }
    if (!this.jansurakshaApi.valid) {
      this.commonService.warningSnackBar('Please fill required fields');
      return;
    }

    const request = {
      orgId: this.orgId ? this.orgId : undefined,
      apiId: this.apiId ? this.apiId : undefined,
      apiName :_.find(this.apiList,(x:any)=>x.id == this.apiId).value,
      encDecTypeId : this.encDecTypeId ? this.encDecTypeId : undefined,
      userName : this.apiNameUserNameList.userName ? this.apiNameUserNameList.userName : undefined,
      apiKey : this.apiNameUserNameList.apiKey ? this.apiNameUserNameList.apiKey : undefined,
      request: this.requestData ? JSON.stringify(JSON.parse(this.requestData)) : undefined
    }
    console.log("requestData : ",request)
    this.adminService.fetchJanApiRequest(request).subscribe((res) => {
      if (res && res.data) {
        this.convertedResponse = JSON.stringify(res.data);
        // this.commonService.successSnackBar(res.message);
      } else {
        this.convertedResponse = undefined;
        this.commonService.errorSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }
  jsonFormatData(){
    this.requestData =  JSON.stringify(JSON.parse(this.requestData), undefined, 2);
   }
}
