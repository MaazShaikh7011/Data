import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import alasql from 'alasql';

@Component({
  selector: 'app-claim-report',
  // standalone: true,
  // imports: [],
  templateUrl: './claim-report.component.html',
  styleUrl: './claim-report.component.scss'
})
export class ClaimReportComponent implements OnInit {
  LODASH = _;
  claimReportList: any = [];
  orgId: any;
  schemeId;
  fromDate: any;
  toDate: any;
  bankList: any = [];
  bankMasterList: any = [];
  schemeMasterList: any = [];
  todayDate: Date = new Date();
  constructor(private adminService: AdminPanelServiceService, private commonService: CommonService, private datePipe: DatePipe) {
    // const tempDate = new Date();
    // this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear());
    // this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+(tempDate.getDate()+1)+"/"+tempDate.getFullYear());
  }
  ngOnInit(): void {
    //  this.fetchClaimReports();
    this.getCommonList(2);
    this.getAllScheme();
  }

  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.schemeId = undefined;
    // this.fetchClaimReports();
  }
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }
  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }

  fetchClaimReports(isDownload?) {
    const data = {
      orgId: this.orgId,
      schemeId: this.schemeId,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined
    }
    this.adminService.fetchClaimReports(data).subscribe(res => {
      if (res && !_.isEmpty(res.data)) {
        this.claimReportList = JSON.parse(res.data);
      } else {
        this.claimReportList = [];
        this.commonService.warningSnackBar(res.message)
      }
      if (isDownload == true) {
        this.downloadDataInExcel(this.claimReportList);
      }
    });
  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    const fileName = 'Claim Ageing ' + this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa') + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
      allApplications = [{
        Sr_no: index,
        'ID': element.id,
        'BANK NAME': element.orgName ? element.orgName : "-",
        'SCHEME NAME': element.schemeName ? element.schemeName : "-",
        'REGISTRATION_DATE': element.claimDate ? element.claimDate : "-",
        'CLAIM STATUS': element.statusName ? element.statusName : "-",
        'AGEING': element.aging ? element.aging : "-",
        'STATUS_CHANGE_DATE': element.status_change_date ?  this.changeDateFormat(element.status_change_date) : "-"
      }];

      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }

}
