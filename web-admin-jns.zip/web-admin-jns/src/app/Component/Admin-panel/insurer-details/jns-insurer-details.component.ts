import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog as MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { ObjectModel } from 'src/app/CommoUtils/model/object-model';


@Component({
  selector: 'app-jns-insurer-details',
  templateUrl: './jns-insurer-details.component.html',
  styleUrls: ['./jns-insurer-details.component.scss'],
  providers: [DatePipe]
})
export class JNSInsurerDetailsComponent implements OnInit {
  
addInsurer() {
throw new Error('Method not implemented.');
}

  applicationId:any
  schemeId:any
  orgId:any
  abc:any;
  policyStartYear:any;
  policyEndYear:any;
  filterToggle: Boolean = false;
  tableFilterToggle: Boolean = false;
  mode:any;
  currentYear= new Date().getFullYear();
  dataList: any = [];
  yearList: any = [];
  bankUserTypeList: any = [];
  roleMaserList: any = [];
  insurerList: any = [];
  lastEndDate:any;
  lastStartDate:any;
  lastInsurerRecord:any;
  totalCount = 0;
  orgList: any;
  orgMasterList : any;
  schTypeId: number;
  years: any;
  isBanker:any;
  isInsurer:any;
  // page number
  page = 1;
  PageSelectNumber:any;
  // default page size
  pageSize = 10;
  // start and end index
  startIndex = 0;
  endIndex = 5;
  bankUserList = [];
  searchData;
  fromDate;
  toDate;
  createUserObj: any = {};

  isMatchPswEightCharLength: any;
  todayDate:Date = new Date();
  isMatchPswOneNumber: RegExpMatchArray;
  isMatchPswOneSpecialChar: RegExpMatchArray;
  isMatchPswOneAlpha: RegExpMatchArray;
  isMatchPswOneCapAlpha: RegExpMatchArray;
  error: string='Please fill required fields'
  validation: ObjectModel[] = [{ key: 'required', value: true }, { key: 'pattern', value: "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@!%*#?&_=`~{}:;,.'$-])[A-Za-z\\d$@!%*#?&_=`~{}:;,.'$-]{8,20}$" }];
  insureData:any
  emailValidation: ObjectModel[] = [{ key: 'required', value: true }]
  debounceEventForFilter = _.debounce(() => this.fetchData(), 500, {});
  response;
  routingData: any;
  constructor(public dialog: MatDialog,private commonService: CommonService,private adminService: AdminPanelServiceService,
    private datePipe: DatePipe,private router: Router) {
    }
   _keyPress(event: any) {
    const pattern = /[0-9]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();

    }
  }

  ngOnInit(): void {
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.applicationId = Number(this.commonService.getStorage(Constants.httpAndCookies.APPLICATION_ID, true));
    this.schemeId = parseInt(this.commonService.getStorage(Constants.httpAndCookies.SCHEME_ID, true));
    this.orgId = parseInt(this.commonService.getStorage(Constants.httpAndCookies.ORGID, true));

    this.fetchData();
    this.getYearsList();
    this.getAllUserType();
    //this.openDialog();
  }
  
  getYearsList() {
    this.adminService.getYearsList().subscribe(res => {
      
      if (res && res.data) {
        this.yearList  =JSON.parse(res.data);
        // this.orgId = 13;
        // this.schTypeId = 1;
      }
    });
  }
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
    
  }
  getBankUserList(onSearchFlag?) {
    if (!onSearchFlag) {
      this.resetStartIndex();
    }

     if(this.bankUserTypeList?.id==2 ){
          this.isBanker=true;
          this.getCommonList(2)
          // this.roleMaserList();
        }else if(this.bankUserTypeList?.id==6){
          this.isInsurer=true;
          this.getCommonList(6)
          // this.roleMaserList();
        }
    
    
  }

  getCommonList(id) {
     
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
       this.orgList = JSON.parse(res.data);
       this.orgMasterList = JSON.parse(res.data);
     }
    });
  }
 

  getAllUserType() {
    this.adminService.getAllUserType().subscribe(res => {
      if (res && res.data) {
        this.bankUserTypeList =res.data
        // console.log(this.bankUserTypeList);
        
        // res.data.forEach(element => {
        //   let res1 ={key:element[0],value:element[1]};
          
        //   this.bankUserTypeList.push(res1);
        //   console.log("bankUserTypeList",this.bankUserTypeList)
          
        // });
     
        //
      }
     // this.getBankUserList();
    });
  }
  getBranchList() {
    throw new Error('Method not implemented.');
  }

  fetchData(idDownload?) {
    const data = {
      searchData: this.searchData ? this.searchData : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      orgId: this.orgId ? this.orgId : undefined,
      years:this.years?this.years: undefined,
      from: this.startIndex ? this.startIndex : 0,
      to: idDownload ? this.totalCount : this.pageSize
      //to: this.pageSize
    }
    this.adminService.spGetInsurerDetailList(data).subscribe(res => {
      // console.log(data);
      
      if (res?.data && res.status === 200) {
        if (idDownload) {
          this.downloadDataInExcel(res.data);
        }else{
          this.dataList = JSON.parse(res.data);
        }
        // console.log("dataList",this.dataList);
        
          this.dataList.forEach((element, index, array) => {
            if (index === (array.length -1)) {
                // This is the last one.
                this.lastInsurerRecord = element;
                this.lastEndDate = element.policyEndDateFormat;
                this.lastStartDate = element.policyStartDate;
            }
            this.policyStartYear = new Date(this.changeDateFormat(element.policyStartDate)).getFullYear();
            element.policyStartYear = this.policyStartYear;
        });
          this.totalCount = this.dataList[0]?.totalcount || 0;
      } else {
        if (idDownload) {
          this.commonService.warningSnackBar('data not found');
        } else{
          this.dataList = [];
          this.totalCount = 0;
        }
        }
    });

  }

  downloadDataInExcel(data) {
    let downloadData = [];
    const fileName = 'Insurer Count '+this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa')+'.xlsx';
    data.forEach((element, i) => {
      const index = i + 1;
      let allApplications = [{
        'Sr no': index,       
        'Insured Name': element.insurerName ? element.insurerName : '',
        'Insured Code': element.insurerCode ? element.insurerCode : '',
        'Insured Address': element.insurerAddress ? element.insurerAddress : '',
        'Pincode': element.pincode ? element.pincode : '',
        'Contact Person': element.contactPerson ? element.contactPerson : '',
        'Monile Number': element.mobileNumber ? element.mobileNumber : '',
        'Email': element.email ? element.email : '',
        'Master Policy number': element.masterPolicyNo ? element.masterPolicyNo.toUpperCase() : '',
        'Scheme': element.schemeName ? element.schemeName : '',
        'Year': element.years ? element.years : '', 
        'Policy Start Date': element.policyStartDate ? element.policyStartDate : '',
        'Policy End Date': element.policyEndDate ? element.policyEndDate : '',
        'Head Name': element.headName ? element.headName : '',
        'Head Email': element.headEmail ? element.headEmail : '',
        'Head Contact Number': element.headContactNo ? element.headContactNo : '',
        'Head Mobile Number': element.headMobileNo ? element.headMobileNo : '',
        'Associated Account Holder Name': element.associatedAccHolderName ? element.associatedAccHolderName : '',
        'Associated Account Number': element.associatedAccNo ? element.associatedAccNo : '',
        'Associated Ifsc Code': element.associatedIfscCode ? element.associatedIfscCode : '',
        'Status': element.status ? element.status : '',
        
      }];
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  onPageChange(page) {
    this.startIndex = (this.page - 1) * this.pageSize;
    this.endIndex = (this.page - 1) * this.pageSize + this.pageSize;
    this.fetchData();
  }

  // addInsurer(){
  //   this.mode=1;
  //   this.router.navigate([Constants.ROUTE_URL.ADD_NEW_INSURED_DETAILS], { queryParams: { schemeId: this.commonService.setURLData(this.lastInsurerRecord?.schemeId),
  //   orgId: this.commonService.setURLData(this.lastInsurerRecord?.orgId),mode: this.commonService.setURLData(this.mode)} });
  // }

  // editInsurer(schemeId,orgId,id){
  //   this.mode=2;
  //   this.router.navigate([Constants.ROUTE_URL.ADD_NEW_INSURED_DETAILS], { queryParams: { schemeId: this.commonService.setURLData(schemeId),
  //      orgId: this.commonService.setURLData(orgId),id: this.commonService.setURLData(id),mode: this.commonService.setURLData(this.mode)} });
  // }

  // viewInsurer(schemeId,orgId,id){
  //   this.mode=3;
  //   this.router.navigate([Constants.ROUTE_URL.ADD_NEW_INSURED_DETAILS], { queryParams: { schemeId: this.commonService.setURLData(schemeId), 
  //     orgId: this.commonService.setURLData(orgId),id: this.commonService.setURLData(id),mode: this.commonService.setURLData(this.mode)} });
  // }

  clearFilter(){
    this.bankUserTypeList.id=null;
    this.toDate = null;
    this.fromDate = null;
    this.years=null;
    this.orgId=null;
    this.fetchData();
  }

}
