import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-claim-api-audit-log',
  templateUrl: './claim-api-audit-log.component.html',
  styleUrls: ['./claim-api-audit-log.component.scss']
})
export class ClaimApiAuditLogComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount ;
  isListCollapsed: boolean = true;
  searchData;
  bankList :any =[];
  bankMasterList :any=[];
  bankId;
  userorgName;
  claimDataList :any =[];
  schemeList;
  claimStageList;
  schemeId;
  listRegistryReqUrl;
  registryurl;
  fromDate: any;
  toDate: any;
  searchTypeId:any;
  searchTypeList:any = [];
  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  claimStage;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private userService: UserProfileService,
    private adminPanelService: AdminPanelServiceService) { 
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  ngOnInit(): void {
    this.getCommonList(2);
    this.schemeList = [
      { id: 1, value: 'PMSBY' },
      { id: 2, value: 'PMJJBY' }
    ];
    this.searchTypeList = [
      { id: 1, value: 'Account Number' },
      { id: 2, value: 'URN' },
      { id: 3, value: 'Application Id' },
    ];
    this.claimStageList = [
      { id: 1, value: 'Sent to Insurer' ,claimStatus:6},
      { id: 2, value: 'Claim Insurer In Progress' ,claimStatus:11},
      { id: 3, value: 'Approved' ,claimStatus:10},
      { id: 4, value: 'Rejected' ,claimStatus:8},
      { id: 5, value: 'Sent back by Insurer' ,claimStatus:7},
      { id: 6, value: 'Sent to Insurer' ,claimStatus:6},
      { id: 7, value: 'Rejected' ,claimStatus:8},
      { id: 9, value: 'Claim Insurer In Progress' ,claimStatus:11}
    ];
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.getClaimDataList(true);
  }
  
  clearFilter() {
    this.bankId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.schemeId = undefined;
    this.claimStage = undefined;
    this.searchTypeId = undefined;
    this.searchData = undefined;

    this.getClaimDataList(false);
  }

  getClaimDataList(onPageChangeFlag?) {  
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    if(this.bankId){
      const data = {
        tabId:this.claimStage,
        fromDate:this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        toDate:this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        schemeId: this.schemeId ? this.schemeId: undefined,
        bankId: this.bankId ? +this.bankId : undefined,
        searchData: this.searchData ? this.searchData : undefined,
        searchTypeId : this.searchTypeId ? this.searchTypeId :undefined,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: !onPageChangeFlag ? 0 : this.pageSize
      }
      this.userService.fetchClaimDashboardList(data).subscribe(res => {
        if (res?.data && res.status === 200) {
          this.claimDataList = JSON.parse(res.data);
          this.claimDataList.forEach(element => {
            element.claimStageName = _.find(this.claimStageList , o => o.claimStatus == element.claimStatus)?.value;            
          });
          this.totalCount = this.claimDataList[0]?.totalCount || 0;
        } else {
          this.claimDataList = [];
          this.totalCount = 0;
        }
      });
    }else{
      this.commonService.warningSnackBar('Please select Bank');
      this.claimDataList = [];
    }
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  
  clearSearchType(){
    this.fromDate=undefined;
    this.toDate=undefined;
    this.registryurl = undefined;
    this.searchData = undefined;
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }



  downloadZipFile(applicationId,claimId,urn) {
    this.adminPanelService.getDocumentZip({ applicationId,claimId }).subscribe(res => {
    if(res){
        const blob = new Blob([res], { type: 'application/octet-stream' });
        const a: any = document.createElement("a");
        document.body.appendChild(a);
        a.style = "display:none";
        var url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = urn + '-Documents.zip';
        a.click();
        a.remove();
    }else{
        this.commonService.warningSnackBar('Claim Document not uploaded');
    }
  },error => {
    this.commonService.warningSnackBar('Claim Document not uploaded');
  });
}

}
