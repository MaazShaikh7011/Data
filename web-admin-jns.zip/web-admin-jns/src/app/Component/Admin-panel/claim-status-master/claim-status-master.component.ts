import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';

@Component({
  selector: 'app-claim-status-master',
  templateUrl: './claim-status-master.component.html',
  styleUrls: ['./claim-status-master.component.scss']
})
export class ClaimStatusMasterComponent implements OnInit {

  CliamStatus;
  CliamStage;
  constructor(private adminService: AdminPanelServiceService) { }

  ngOnInit(): void {
    this.getMasterList();
  }

  getMasterList() {
    const masterObj = ['CLIAM_STATUS','CLIAM_STAGE_MASTER'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.CliamStatus = res.data.CLIAM_STATUS;
        this.CliamStage = res.data.CLIAM_STAGE_MASTER;
      }
    })
  }
}
