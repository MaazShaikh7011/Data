import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-publish-api-audit-details-log',
  templateUrl: './publish-api-audit-details-log.component.html',
  styleUrls: ['./publish-api-audit-details-log.component.scss']
})
export class PublishApiAuditDetailsLogComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount ;
  isListCollapsed: boolean = true;
  searchData;
  publishdataList: any = [];

  insureList :any =[];
  insureMasterList : any =[];
  orgId;
  userorgName;
  searchType;
  searchTypeId;
  listPublishReqUrl;
  publishurl;
  apiRespose: any= {};

  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;

  debounceEventForFilter = _.debounce(() => this.fetchPublishDataList(), 500, {});
  fromDate: any;
  toDate: any;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe, private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private userService: UserProfileService) { 
      this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    }

  ngOnInit(): void {
    this.getCommonList(6);
    this.searchType = [
      { id: 1, value: 'Id' },
      { id: 2, value: 'Request Url' },
      { id: 3, value: 'Token' },
      { id: 7, value: 'Ref no.' },
    ];
    this.getMasterList();
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchPublishDataList(true);
  }
  changeDateFormat(date) {
    // const dateParts = date;
    // const dateObj = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
}
  
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.searchTypeId = undefined;
    this.publishurl= undefined;
    this.fetchPublishDataList(false);
  }
  fetchPublishDataList(onPageChangeFlag?){
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    if(this.orgId || onPageChangeFlag==false){
      const data = {
        type : 1 ,
        searchData: this.searchData ? this.searchData : undefined,
        fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        orgId: this.orgId ? this.orgId : undefined,
        searchTypeId : this.searchTypeId ? this.searchTypeId :undefined,
        requrl : this.publishurl ? ( "/api/jns"+this.publishurl) : undefined ,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: onPageChangeFlag==false ? 0 : this.pageSize
      }

      this.userService.fetchPublishApiAuditDetailList(data).subscribe(res => {
        // if (res && !_.isEmpty(res.data)) {
          if (res && res.data) {
          this.publishdataList = JSON.parse(res.data);
          this.publishdataList.forEach(element => {
            element.userorgName =_.find(this.insureList,(x:any)=>x.userOrgId == this.orgId).organisationName
           });
          // this.publishdataList.forEach(element => {
          //   element.plainRequest=JSON.parse(element?.plainRequest);
          // });
          this.totalCount = this.publishdataList[0].totalCount || 0;
        }
         else {
          this.totalCount = 0;
          this.publishdataList = [];
        }
      });
    }else{
      this.commonService.warningSnackBar('Please select Bank');
    }

  }
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.insureList = JSON.parse(res.data);
        this.insureMasterList= JSON.parse(res.data);
        // console.log("this",this.insureList)
      }
    });
  }
   getMasterList() {
    const masterObj = ['PUBLLISH_REQ_LIST'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.listPublishReqUrl = res.data.PUBLLISH_REQ_LIST;
      }
    })
  }
  clearSearchType(){
    this.publishurl = undefined;
    this.searchData = undefined;
  }

  getApiData(auditId, isListCollapsed){
    // console.log('fileName: ', auditId);
    if(!isListCollapsed){
      return;
    } 
    if(!auditId){
      this.commonService.warningSnackBar('File Not Found');
      return;
    }
    this.apiRespose = undefined;
    this.publishdataList.forEach(element => {
      element.isListCollapsed = false
    });
    this.adminService.getPublishReqRes(auditId).subscribe(res => {
      if (res.data) {
        const data = res.data;
        const index = _.findIndex(this.publishdataList, (x: any) => x.id == auditId);
        if (index != -1) {
          this.publishdataList[index].isListCollapsed = true;
        }
        this.apiRespose = data;
        // this.apiRespose = {
        //   reqLogAuditId: data.reqLogAuditId,
        //   referenceId: data.referenceId,
        //   header: data.header,
        //   plainRequest: data.plainRequest,
        //   plainResponse: data.plainResponse,
        //   encryptRequest: data.encryptRequest,
        //   encryptResponse: data.encryptResponse,
        // }
      } else {
        this.commonService.infoSnackBar('Data Not Found');
      }
    });
  }
}
