import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-organization-list',
  templateUrl: './organization-list.component.html',
  styleUrls: ['./organization-list.component.scss'],
  providers: [DatePipe]
})
export class OrganizationListComponent implements OnInit {
  breadCrumbItems: Array<{}>;

  selectValue: string[];

  userTypeId;
  otherUserList:any=[];
  // page number
  page = 1;
  isInsurer:Boolean
  isBanker:Boolean
  insurerList:any
  // default page size
  pageSize = 10;

  bankUserTypeList: any = [];

  // start and end index
  startIndex = 1;
  endIndex = 10;
  totalSize = 0;

  PageSelectNumber!: string[];

  debounceEventForFilter = _.debounce(() => this.getUserOrganizationList(false,this.otherUserList.userTypeId), 500, {});
  userOrgList: any;
  totalCount;
  fromDate;
  toDate;
  searchValue;
  adminPermissionList: any = [];


  constructor(private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private commonMethod: CommonMethods,
    private datePipe: DatePipe,) { 
      
    }

  ngOnInit(): void {
    this.getAllUserType();
    this.getUserOrganizationList();
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
    
    this.getOtherUserList();
  }
  clearFilter(){
    this.otherUserList.userTypeId=null;
    this.searchValue=null;
    this.getUserOrganizationList();
  }


  getFormatedDate(date): any {
    const dateParts = date.split('-');
    const dateObj = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    return this.datePipe.transform(dateObj, 'y-MM-dd');
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.getUserOrganizationList(true,this.otherUserList.userTypeId);
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }

  omit_special_char(event) {
    var k;
    k = event.charCode;  //         k = event.keyCode;  (Both can be used)
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
  }

  getUserOrganizationList(onPageChangeFlag?,userTypeId?) {
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    
    const filterJSON = {
      userTypeId: userTypeId ? userTypeId : this.userTypeId || undefined,
      searchValue: this.searchValue || undefined,
      
    }
    
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getUserOrganizationList(data).subscribe(res => {
      this.userOrgList = [];
      if (res && !_.isEmpty(res.data)) {
        this.userOrgList = JSON.parse(res.data);
        this.totalCount = this.userOrgList[0].totalCount;
      } else {
        this.totalCount = 0;
        this.userOrgList = [];
      }
    });
  }
  getCommonList(id) {
     
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
       this.insurerList = res.data;
     }
    });
  }


  setOrgPermission(orgId, isActive) {
    if (isActive) {
      const data = {
        userOrgId: orgId
      }
      this.adminService.setOrgPermission(data).subscribe(res => {
        if (res && res.data) {
          this.commonService.successSnackBar("Successfully set Permission");
        }
      });
    } else {
      this.commonService.warningSnackBar("Branch is in-Active");
    }
  }

  isActiveOrg(orgId) {
    const data = {
      userOrgId: orgId
    }
    this.adminService.isActiveOrg(data).subscribe(res => {
      if (res && res.data) {
        this.getUserOrganizationList();
        this.commonService.successSnackBar("Successfully Done");
      }
    });
  }

  downloadAll() {
    const filterJSON = {
      searchValue: this.searchValue || undefined,
      userTypeId : this.userTypeId || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: 0,
      paginationTO: this.totalCount,
    }
    this.adminService.getUserOrganizationList(data).subscribe(res => {
      if (res && res.data) {
        console.log("ddddd",res);
        
        this.downloadExcel(JSON.parse(res.data));
      }
    });
  }
  getAllUserType() {
    this.adminService.getAllUserType().subscribe(res => {
      if (res && res.data) {
        this.bankUserTypeList = res.data
        // res.data.forEach(element => {
        //   let res1 ={key:element[0],value:element[1]};
          
        //   this.bankUserTypeList.push(res1);
          
        // });
        
        //g
      }
      
    });
  }
  getOtherUserList(onSearchFlag?) {
    if (!onSearchFlag) {
      this.resetStartIndex();
    }
    const filterJSON = {
      // userOrgId: this.userOrgId || undefined,
      userTypeId: this.userTypeId || undefined,
      searchValue: this.searchValue || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getOtherUserList(data).subscribe(res => {
      this.otherUserList = [];
      if (res && res.data) {
        // this.otherUserList = res.data;
         this.otherUserList = JSON.parse(res.data);
       
      
      }
    });
  }
  

  downloadExcel(excelData) {
    let downloadData = [];
    const fileName = 'Organizations.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      const allApplications = [{
        "SR No": index,
        "Bank Id": element.orgId || '',
        "Bank Name": element.orgFullName || '',
        "Bank Code": element.orgCode || '',
        "Bank Type": element.bankType || '',
        "Is Active": element.isActive ? 'YES' : 'NO',
      }];
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }

  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }

  copyToClipBoard(data) {
    if(CommonService.isObjectNullOrEmpty(data)) {
      return;
    }
    this.commonMethod.copyToClipBoard(data);
  }
}
