import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';

@Component({
  selector: 'app-dms-master',
  templateUrl: './dms-master.component.html',
  styleUrls: ['./dms-master.component.scss']
})
export class DmsMasterComponent implements OnInit {

  typeMasterList;
  documentMasterList;

  constructor(private adminService : AdminPanelServiceService) { }

  ngOnInit(): void {
    this.getTypeMasterForDms();
    this.getDocumentMasterForDms();
  }

  getTypeMasterForDms(){
    this.adminService.getTypeMasterForDms().subscribe(res=>{
      if(res && res.data){
        this.typeMasterList=JSON.parse(res.data);
      }
    })
  }
  getDocumentMasterForDms(){
    this.adminService.getDocumentMasterForDms().subscribe(res=>{
      if(res && res.data){
        this.documentMasterList=JSON.parse(res.data);
      }
    })
  }


}
