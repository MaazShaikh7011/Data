import { Component, OnInit } from '@angular/core';
import { MatDialog as MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { UserProfileService } from 'src/app/CommoUtils/user.service';
import { ConfirmationPopupComponent } from 'src/app/Popup/confirmation-popup/confirmation-popup.component';
import { LockUserPopupComponent } from 'src/app/Popup/lock-user-popup/lock-user-popup.component';
import { ResetPasswordPopupComponent } from 'src/app/Popup/reset-password-popup/reset-password-popup.component';
import { UpdatedMobileEmailPopupComponent } from 'src/app/Popup/updated-mobile-email-popup/updated-mobile-email-popup.component';

@Component({
  selector: 'app-jns-support-dashboard',
  templateUrl: './jns-support-dashboard.component.html',
  styleUrls: ['./jns-support-dashboard.component.scss']
})
export class JNSSupportDashboardComponent implements OnInit {

  // bread crumb items
  breadCrumbItems: Array<{}>;

  startIndex = 0;
  auditLogStartIndex = 0;
  // page number
  page = 1;
  // default page size
  pageSize = 10;
  endIndex = 10;
  enrollmentStartIndex = 0;
  enrollmentPage = 1;
  enrollmentPageSize = 10;
  enrollmentEndIndex = 10;
  enrollmentInprocessStartIndex = 0;
  enrollmentInprocessPage = 1;
  enrollmentInprocessPageSize = 10;
  enrollmentInprocessEndIndex = 10;
  enrollmentFailedStartIndex = 0;
  enrollmentFailedPage = 1;
  enrollmentFailedPageSize = 10;
  enrollmentFailedEndIndex = 10;
  loginStartIndex = 0;
  loginPage = 1;
  loginPageSize = 10;
  loginEndIndex = 10;
  notificationStartIndex = 0;
  notificationPage = 1;
  notificationPageSize = 10;
  notificationEndIndex = 10;
  totalSize = 0;
  totalCount;
  apiUserList;
  PageSelectNumber: string[];
  serviceapikey;
  orgId;
  bankUserTypeList: any = [];
  isInsurer: Boolean = false;
  isBanker: Boolean = false;
  insurerList: any = [];
  insurerMasterList: any = [];
  fetchedData: any = [];
  fetchedInprocessData: any = [];
  fetchedFailedData: any = [];
  userTypeId: any;
  searchData: any;
  customerDetails: any;
  inprocessCustomerDetails: any;
  failedCustomerDetails: any;
  submitted: Boolean = false;
  searchType = Constants.searchUserType;
  dateFormate = Constants.dateFormat.DDMMYYYYHHMMSS;

  CommonWiseDataCollaps: boolean = false;
  InprocessDataCollaps: boolean = false;
  FailedDataCollaps: boolean = false;
  LoginDataCollaps: boolean = false;
  WrgAtpDataCollaps: boolean = false;
  NtfDataCollaps: boolean = false;
  URNWiseDataCollaps: boolean = false;
  dataList: any;
  getApiRes: any;
  apiRespose: any;
  tokenData: any;
  notificationDtl: any;
  loginTotalCount: any;
  notificationTotalCount: any;
  enrollmentTotalCount: any;
  enrollmentInprocessTotalCount: any;
  enrollmentFailedTotalCount: any;
  allUrn: any;
  failedAllUrn: any;
  inprocessAllUrn: any;
  userId:any;
  resetedPassword: any;
  notificationType;

  constructor(private adminService: AdminPanelServiceService, private userService: UserProfileService,
    private commonService: CommonService, private commonMethod: CommonMethods, public dialog: MatDialog) { 
      this.userId = parseInt(this.commonService.getStorage(Constants.httpAndCookies.USER_ID, true));
    }

  ngOnInit(): void {
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  openPopUpMat(obj: any, popUpName: any, objClass?: any, disableClose?: boolean) {
    return this.dialog.open(popUpName, { panelClass: objClass, autoFocus: false, data: obj, disableClose: disableClose });
  }

  clearFilter() {
    this.userTypeId = null;
    this.searchData = null;
  }

  onPageChange(page: any, isEnrollmentDtls?, isLoginDtls?, isNotificationDtls?,displayTypeId?): void {
    if (isEnrollmentDtls) {
      if(displayTypeId==1){
        this.enrollmentStartIndex = (page - 1) * this.enrollmentPageSize;
        this.enrollmentEndIndex = (page - 1) * this.enrollmentPageSize + this.enrollmentPageSize;
        this.fetchAllUrn(true, page,displayTypeId);
      }else if(displayTypeId==2){
        this.enrollmentInprocessStartIndex = (page - 1) * this.enrollmentInprocessPageSize;
        this.enrollmentInprocessEndIndex = (page - 1) * this.enrollmentInprocessPageSize + this.enrollmentInprocessPageSize;
        this.fetchInprocessAllUrn(true, page,displayTypeId);
      }else if(displayTypeId==3){
        this.enrollmentFailedStartIndex = (page - 1) * this.enrollmentFailedPageSize;
        this.enrollmentFailedEndIndex = (page - 1) * this.enrollmentFailedPageSize + this.enrollmentFailedPageSize;
        this.fetchFailedAllUrn(true, page,displayTypeId);
      }
    } else if (isLoginDtls) {
      this.loginStartIndex = (page - 1) * this.loginPageSize;
      this.loginEndIndex = (page - 1) * this.loginPageSize + this.loginPageSize;
      this.fetchTokenData(true);
    } else if (isNotificationDtls) {
      this.notificationStartIndex = (page - 1) * this.notificationPageSize;
      this.notificationEndIndex = (page - 1) * this.notificationPageSize + this.notificationPageSize;
      // this.fetchNotificationDtl(true);
    }
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }


  fetchData() {
    this.CommonWiseDataCollaps = false;
    this.InprocessDataCollaps = false;
    this.FailedDataCollaps = false;
    this.LoginDataCollaps = false;
    this.WrgAtpDataCollaps = false;
    this.NtfDataCollaps = false;
    this.URNWiseDataCollaps = false;
    this.notificationType = null;
    this.customerDetails = null;
    this.notificationDtl = null;
    this.enrollmentStartIndex = 0;
    this.enrollmentPage = 1;
    this.enrollmentPageSize = 10;
    this.enrollmentEndIndex = 10;
    this.enrollmentInprocessStartIndex = 0;
    this.enrollmentInprocessPage = 1;
    this.enrollmentInprocessPageSize = 10;
    this.enrollmentInprocessEndIndex = 10;
    this.enrollmentInprocessStartIndex = 0;
    this.enrollmentFailedPage = 1;
    this.enrollmentFailedPageSize = 10;
    this.enrollmentFailedEndIndex = 10;
    this.loginStartIndex = 0;
    this.loginPage = 1;
    this.loginPageSize = 10;
    this.loginEndIndex = 10;

    this.dataList = null;
    if (!this.searchData || !this.userTypeId) {
      this.commonService.warningSnackBar('Please fill required details');
      return;
    }
    const data = {
      type: this.userTypeId,
      searchData: this.searchData
    }
    this.adminService.getUsersDetails(data).subscribe(res => {
      // if (res?.data && res.status === 200) {
      if (res && !_.isEmpty(res?.data) && res.status === 200) {
        //  this.dataList = res.data;
        this.dataList = JSON.parse(res.data);
        // this.commonService.successSnackBar(res.message);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });

  }

  fetchAllUrn(CommonWiseDataCollaps, page?,displayTypeId?) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.allUrn = null;
    if (!CommonWiseDataCollaps) {
      return;
    }
    // if(displayTypeId==1){
    //   this.FailedDataCollaps = false;
    //   this.InprocessDataCollaps = false;
    // } else if(displayTypeId==2){
    //   this.CommonWiseDataCollaps = false;
    //   this.FailedDataCollaps = false;
    // } else if(displayTypeId==3){
    //   this.CommonWiseDataCollaps = false;
    //   this.InprocessDataCollaps = false;
    // }
    const data = {
      userId: this.dataList?.userId,
      type: this.userTypeId,
      searchData: this.searchData,
      paginationFROM: page ? (page - 1) : 0,
      displayTypeId:displayTypeId,
      paginationTO: this.enrollmentPageSize ? +this.enrollmentPageSize : (this.pageSize ? this.pageSize : 10),
    }
    this.adminService.fetchAllUrn(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        if(displayTypeId==1){
          this.allUrn = res.data;
          this.enrollmentTotalCount = this.allUrn[0].totalCount || 0;
        }
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

  fetchInprocessAllUrn(CommonWiseDataCollaps, page?,displayTypeId?) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.inprocessAllUrn = null;
    if (!CommonWiseDataCollaps) {
      return;
    }
    const data = {
      userId: this.dataList?.userId,
      type: this.userTypeId,
      searchData: this.searchData,
      paginationFROM: page ? (page - 1) : 0,
      displayTypeId:displayTypeId,
      paginationTO: this.enrollmentInprocessPageSize ? +this.enrollmentInprocessPageSize : (this.pageSize ? this.pageSize : 10),
    }
    this.adminService.fetchAllUrn(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
          this.inprocessAllUrn = res.data;
          this.enrollmentInprocessTotalCount = this.inprocessAllUrn[0].totalCount || 0;
      } 
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

  fetchFailedAllUrn(CommonWiseDataCollaps, page?,displayTypeId?) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.failedAllUrn = null;
    if (!CommonWiseDataCollaps) {
      return;
    }
    const data = {
      userId: this.dataList?.userId,
      type: this.userTypeId,
      searchData: this.searchData,
      paginationFROM: page ? (page - 1) : 0,
      displayTypeId:displayTypeId,
      paginationTO: this.enrollmentFailedPageSize ? +this.enrollmentFailedPageSize : (this.pageSize ? this.pageSize : 10),
    }
    this.adminService.fetchAllUrn(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
          this.failedAllUrn = res.data;
          this.enrollmentFailedTotalCount = this.failedAllUrn[0].totalCount || 0;
      } 
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

  getSingleDropDwn(urn, URNWiseDataCollaps) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.apiRespose = null;
    if (!URNWiseDataCollaps) {
      return;
    }
    this.allUrn.forEach(element => {
      if(element.urn!=urn){
        element.URNWiseDataCollaps = false
      }
    });
    if(!this.commonService.isObjectIsEmpty(this.fetchedData)){
      for(let element of this.fetchedData){
        if (element[0].urn==urn) {
          this.customerDetails = element;
          return;
        }
      }
    }
    const data = {
      urn: urn
    }
    this.adminService.fetchEnrollmentDetails(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerDetails = res.data;
        this.fetchedData.push(this.customerDetails);
        const index = _.findIndex(this.allUrn, (x: any) => x.urn == urn);
        if (index != -1) {
          this.allUrn[index].URNWiseDataCollaps = true;
        }
        // this.commonService.successSnackBar(res.message);
      } else {
        this.customerDetails = null;
        this.commonService.warningSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getInprocessSingleDropDwn(urn, URNWiseInprocessDataCollaps) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.apiRespose = null;
    if (!URNWiseInprocessDataCollaps) {
      return;
    }
    this.inprocessAllUrn.forEach(element => {
      if(element.urn!=urn){
        element.URNWiseInprocessDataCollaps = false
      }
    });
    if(!this.commonService.isObjectIsEmpty(this.fetchedInprocessData)){
      for(let element of this.fetchedInprocessData){
        if (element[0].urn==urn) {
          this.inprocessCustomerDetails = element;
          return;
        }
      }
    }
    const data = {
      urn: urn
    }
    this.adminService.fetchEnrollmentDetails(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.inprocessCustomerDetails = res.data;
        this.fetchedInprocessData.push(this.inprocessCustomerDetails);
        const index = _.findIndex(this.inprocessAllUrn, (x: any) => x.urn == urn);
        if (index != -1) {
          this.inprocessAllUrn[index].URNWiseInprocessDataCollaps = true;
        }
      } else {
        this.inprocessCustomerDetails = null;
        this.commonService.warningSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }


  getFailedSingleDropDwn(urn, URNWiseFailedDataCollaps) {
    this.LoginDataCollaps = false;
    this.NtfDataCollaps = false;
    this.apiRespose = null;
    if (!URNWiseFailedDataCollaps) {
      return;
    }
    this.failedAllUrn.forEach(element => {
      if(element.urn!=urn){
        element.URNWiseFailedDataCollaps = false
      }
    });
    if(!this.commonService.isObjectIsEmpty(this.fetchedFailedData)){
      for(let element of this.fetchedFailedData){
        if (element[0].urn==urn) {
          this.failedCustomerDetails = element;
          return;
        }
      }
    }
    const data = {
      urn: urn
    }
    this.adminService.fetchEnrollmentDetails(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.failedCustomerDetails = res.data;
        this.fetchedFailedData.push(this.failedCustomerDetails);
        const index = _.findIndex(this.failedAllUrn, (x: any) => x.urn == urn);
        if (index != -1) {
          this.failedAllUrn[index].URNWiseFailedDataCollaps = true;
        }
      } else {
        this.failedCustomerDetails = null;
        this.commonService.warningSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }


  ConfirmationPopup(type) {
    const config = {
      windowClass: 'popup-650',
      userType: this.dataList?.userTypeId,
      userId: this.dataList?.userId,
      type: type
    };
    this.openPopUpMat(config, ConfirmationPopupComponent, ['popup-650' ,'p-0-popup'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        this.updateEmailMobilePopup(type);
      }
    });
  }

  updateEmailMobilePopup(type) {
    const config = {
      windowClass: 'popup-650',
      userType: this.dataList?.userTypeId,
      userId: this.dataList?.userId,
      type: type
    };
    this.openPopUpMat(config, UpdatedMobileEmailPopupComponent, ['popup-650'], true).afterClosed().subscribe(result => {
      if (result != 'cancel') {
        this.saveSupportAudit(type == 1 ? Constants.suportAuditAction.EMAIL_EDIT : Constants.suportAuditAction.MOBILE_NO_EDIT, result);
      }
    });
  }

  onLockPopup() {
    const config = {
      windowClass: 'popup-650',
      userId: this.dataList?.userId,
      isLocked: this.dataList?.locked,
      email: this.dataList?.email,
    };
    this.openPopUpMat(config, LockUserPopupComponent, ['popup-650'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        this.lockUser();
      }
    });
  }


  lockUser(): void {
    const data = {
      userId: this.dataList?.userId,
      isLocked: this.dataList?.locked === 'Yes' ? false : true,
      isLockedByAdmin: this.dataList?.locked === 'Yes' ? false : true
    };
    this.userService.lockUnlockUser(data).subscribe(success => {
      if (success.status === 200) {
        // this.commonService.successSnackBar(success.message);
        this.saveSupportAudit(Constants.suportAuditAction.USER_LOCK_UNLOCK, this.dataList?.locked === 'Yes' ? 'Unlocked' : 'Locked');
      } else {
        this.commonService.warningSnackBar(success.message);
      }
    }, (error: any) => {

    });
  }

  resetPaswordPopup(userId) {
    const config = {
      windowClass: 'popup-650',
      userId: userId
    };
    this.openPopUpMat(config, ResetPasswordPopupComponent, ['popup-650'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        this.userResetPassword();
      }
    });
  }

  userResetPassword() {
    const data = {
      userId: this.dataList?.userId,
    };
    this.adminService.userResetPassword(data).subscribe(res => {
      if (res && res?.status == 200 && res?.data) {
        this.resetedPassword = res?.data;
        this.openResetPassword(this.resetedPassword);
        // this.commonService.successSnackBar(res.message);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }

  openResetPassword(password) {
    const config = {
      windowClass: 'popup-650',
      type: 3,
      password:password
    };
    this.openPopUpMat(config, ConfirmationPopupComponent, ['popup-650','p-0-popup'], true).afterClosed().subscribe(result => {
      if (result == 'cancle') {
        this.saveSupportAudit(Constants.suportAuditAction.PASSWORD_RESET, null);
      }
    });
  }

  getResResBucket(obj) {
    this.apiRespose = null;
    if (!obj) {
      this.commonService.warningSnackBar('File Not Found');
      return;
    }
    this.adminService.getResResBucket(obj).subscribe(res => {
      if (res) {
        this.apiRespose = res;
      } else {
        this.commonService.infoSnackBar('Data Not Found');
      }
    });
  }

  saveSupportAudit(actionType, newData) {
    const data = {
      supportUserId: this.userId,
      userId: this.dataList?.userId,
      action: actionType,
      newData: newData,
      oldData: actionType == 1 ? this.dataList?.email : actionType == 2 ? this.dataList?.mobile : actionType == 3 ? (this.dataList?.locked == 'Yes' ? 'Locked' : 'Unlocked') : actionType == 4 ? null : null
    }
    this.adminService.saveSupportAudit(data).subscribe(res => {
      if (res && res?.status === 200) {
        this.fetchData();
      }
    });

  }

  fetchTokenData(LoginDataCollaps) {
    this.CommonWiseDataCollaps = false;
    this.InprocessDataCollaps = false;
    this.FailedDataCollaps = false;
    this.NtfDataCollaps = false;
    this.URNWiseDataCollaps = false;
    this.tokenData = null;
    if (!LoginDataCollaps) {
      return;
    }
    const data = {
      userId: this.dataList?.userId,
      paginationFROM: this.loginStartIndex ? this.loginStartIndex : (this.startIndex ? this.startIndex : 0),
      paginationTO: this.loginPageSize ? this.loginPageSize : (this.pageSize ? this.pageSize : 10)
    }
    this.adminService.fetchTokenData(data).subscribe(res => {
      if (res && res?.status === 200) {
        this.tokenData = JSON.parse(res.data);
        this.loginTotalCount = this.tokenData[0].totalCount || 0;
      }
    });

  }

  fetchNotificationDtl(NtfDataCollaps,notificationType) {
    this.notificationDtl = null;
    this.CommonWiseDataCollaps = false;
    this.InprocessDataCollaps = false;
    this.FailedDataCollaps = false;
    this.LoginDataCollaps = false;
    this.URNWiseDataCollaps = false;
    if (!NtfDataCollaps) {
      return;
    }
    // if (this.dataList?.roleId != 9) {
    //   return this.commonService.warningSnackBar("This is just for the branch officer.");
    // }
    const data = {
      mobile: this.dataList?.mobile,
      email: this.dataList?.email,
      paginationFROM: this.notificationStartIndex ? this.notificationStartIndex : (this.startIndex ? this.startIndex : 0),
      paginationTO: this.notificationPageSize ? this.notificationPageSize : (this.pageSize ? this.pageSize : 10),
      notificationTypeId : notificationType
    }
    this.adminService.getNotificationDtl(data).subscribe(res => {
      if (res && res?.status === 200) {
        this.notificationDtl = JSON.parse(res.data);
        // this.notificationTotalCount = this.notificationDtl[0].totalCount || 0;
        // this.commonService.successSnackBar(res.message);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });

  }

  copyToClipBoard(data, isJson) {
    this.commonMethod.copyToClipBoard(JSON.parse(data), isJson);
  }

}
