import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss']
})
export class NotificationListComponent implements OnInit {

  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount;
  bankList :any =[];
  orgId;
  fromDate: any;
  toDate: any;
  isSkipCount = 0;
  searchType:any;
  notificationType:any;
  notificationTypeId:any;
  searchTypeId:any;
  searchData:any;
  notificationList:any = [];

  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    public commonMethods: CommonMethods) { 
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    const tempDate = new Date();
    this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 00:00:00");
    this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 11:59:59 PM");
  }

  ngOnInit(): void {
    this.searchType = [
      { id: 1, value: 'To' },
      { id: 2, value: 'Reference Id' },
    ];
    this.notificationType =[
      { id: 1, value: 'EMAIL' },
      { id: 2, value: 'SMS' },
    ] 
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchNotificationList(true);
  }
  
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
 
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:mm:ss aaa');
  }

  clearFilter() {
    this.fromDate = undefined;
    this.toDate = undefined;
    this.searchTypeId = undefined;
    this.searchData = undefined;
    this.notificationTypeId = undefined;
    this.fetchNotificationList(true);
  }

  fetchNotificationList(onPageChangeFlag?){
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    if(this.searchTypeId != null && this.commonService.isObjectNullOrEmpty(this.searchData)){
        this.commonService.warningSnackBar('Please pass data for search');    
    }else if((this.fromDate != null && this.commonService.isObjectNullOrEmpty(this.toDate)) || (this.toDate != null && this.commonService.isObjectNullOrEmpty(this.fromDate))){
      this.commonService.warningSnackBar('Please pass valid date filter for search');    
    }
    else{
      const data = {     
        searchData: this.searchData ? this.searchData : undefined,
        typeId : this.searchTypeId ? this.searchTypeId :undefined,
        toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        notificationType: this.notificationTypeId ? this.notificationTypeId : undefined,
        fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: onPageChangeFlag==false ? 0 : this.pageSize
      }
      this.adminService.fetchNotificationList(data).subscribe(res => {
       console.log('data: ',res);
          if (res && res?.data && res.status == 200) {
            this.notificationList = JSON.parse(res.data);
            this.totalCount = this.notificationList[0]?.totalCount || 0;
          } else {
            this.totalCount = 0;
            this.notificationList = [];
            this.commonService.warningSnackBar('data not found');
          }
    });
  }

 }

  // downloadCertificate(applicationData) {
  //   const data = {
  //     applicationId: applicationData.id,
  //     schemeId: +this.schemeId,
  //     orgId: +this.orgId,
  //     isDownload: true
  //   }
  //   this.adminService.getCertiInsData(data).subscribe(res => {
  //     if (res && res.data) {
  //       const fileName = "Certificate-of-Insurance-" + applicationData.urn;
  //       this.commonMethods.downloadPdfFromBase64toFile(res.data, fileName);
  //     }
  //   }, error => {
  //     this.commonService.errorSnackBar(error);

  //   })
  // }

  clearSearchType(){
    // this.fromDate=undefined;
    // this.toDate=undefined;
    this.searchData = undefined;
    this.notificationTypeId = undefined;
  }

}
