import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';

@Component({
  selector: 'app-premium-master',
  templateUrl: './premium-master.component.html',
  styleUrls: ['./premium-master.component.scss']
})
export class PremiumMasterComponent implements OnInit {

  premiumList;
  constructor(private adminService: AdminPanelServiceService) { }

  ngOnInit(): void {
    this.getPreMimumMaster();
  }

  getPreMimumMaster(){
    this.adminService.getPreMimumMaster().subscribe(res=>{
      if(res && res.data){
        this.premiumList=JSON.parse(res.data);
      }
    })
  }

}
