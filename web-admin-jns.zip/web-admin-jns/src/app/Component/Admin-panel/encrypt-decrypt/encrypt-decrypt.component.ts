import { Component, OnInit } from '@angular/core';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { AesGcmEncryptionService } from 'src/app/service/encryption/aes-gcm-encryption.service';

@Component({
  selector: 'app-encrypt-decrypt',
  templateUrl: './encrypt-decrypt.component.html',
  styleUrls: ['./encrypt-decrypt.component.scss']
})
export class EncryptDecryptComponent implements OnInit {
  breadCrumbItems: Array<{}>;
  requestData: any;
  responseData: any;
  urlRequestData: any;
  urlResponseData: any;
  tab = 1;
  request: any;
  response: any;
  constructor(private commonMethod: CommonMethods) { }

  ngOnInit(): void {
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
  }

  // tab
  activeClick(tabId: number) {
    this.tab = tabId;
  }

  convertData(request) {
    // this.requestData = CommonService.decryptText(request);
    this.requestData = AesGcmEncryptionService.getDecPayload(request);
    try {
      this.requestData = JSON.parse(this.requestData.toString());
    } catch (ex) {
      this.requestData = this.requestData;
    }
  }
  convertUrlData(request) {
    // this.urlRequestData = CommonService.decryptFuntion(request);
    this.urlRequestData = AesGcmEncryptionService.getDecPayload(request);
    try {
      this.urlRequestData = this.urlRequestData.toString();
    } catch (ex) {
      this.urlRequestData = this.urlRequestData;
    }
  }
  decryptUrlData(request) {
    // this.urlResponseData = CommonService.encryptFuntion(request);
    this.urlResponseData = AesGcmEncryptionService.getEncPayload(request)
    try {
      this.urlResponseData = this.urlResponseData.toString();
    } catch (ex) {
      this.urlResponseData = this.urlResponseData;
    }
  }

  convertDecData(response) {
    // this.responseData = CommonService.encryptText(response);
    this.responseData = AesGcmEncryptionService.getEncPayload(response)
  }

  copyToClipBoard(data, isJson) {
    this.commonMethod.copyToClipBoard(data, isJson);
  }

}
