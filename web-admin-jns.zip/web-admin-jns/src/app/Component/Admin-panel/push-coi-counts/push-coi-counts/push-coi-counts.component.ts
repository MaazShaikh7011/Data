import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';

@Component({
  selector: 'app-push-coi-counts',
  templateUrl: './push-coi-counts.component.html',
  styleUrls: ['./push-coi-counts.component.scss']
})
export class PushCoiCountsComponent implements OnInit {
  LODASH = _;
  fromDate;
  toDate;
  countObj: any = {};
  orgId;
  bankList :any =[];
  bankMasterList :any =[];
  schemeMasterList;
  schemeId;
  typeId: any;
  searchType: any;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService :AdminPanelServiceService,private commonMethod: CommonMethods) { 
    const tempDate = new Date();
    this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear());
    this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+(tempDate.getDate()+1)+"/"+tempDate.getFullYear());
}

  ngOnInit(): void {
    this.getCommonList(2);
    this.getAllScheme();
    // this.fetchData();
  }
  
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data)
      }
    });
  }
  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }
  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.schemeId = undefined;
    this.fetchData();
  }
fetchData(){
  const filterJSON = {
    orgId:this.orgId,
    schemeId:this.schemeId,
    fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
    toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined  
  }
  this.adminService.fetchCoiPushAllCounts(filterJSON).subscribe(res => {
    if (res?.data) {
      this.countObj = JSON.parse(res.data);
    }else{
      this.countObj = {};
      this.commonMethod.warningSnackBar('Data not found.');
    }
  });

}
changeDateFormat(date) {
  return this.datePipe.transform(date, 'yyyy-MM-dd');
}

}
