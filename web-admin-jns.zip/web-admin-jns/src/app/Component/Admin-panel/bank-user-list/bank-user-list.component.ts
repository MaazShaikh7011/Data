import { DatePipe } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { MatDialog as MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import alasql from 'alasql';
import * as _ from 'lodash';
import { constant } from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';
import { ConfirmationPopupComponent } from 'src/app/Popup/confirmation-popup/confirmation-popup.component';
declare var $: any;

@Component({
  selector: 'app-bank-user-list',
  templateUrl: './bank-user-list.component.html',
  styleUrls: ['./bank-user-list.component.scss'],
  providers: [DatePipe]
})
export class BankUserListComponent implements OnInit {

  tab!: number;
  breadCrumbItems: Array<{}>;
  totalCount;
  totalOtherCount;
  fromDate;
  toDate;
  key;
  searchValue;
  debounceEventForFilter = _.debounce(() => this.tab == 1 ? this.getBankUserList(false) : this.getOtherUserList(false), 700, {});
  bankUserList;
  otherUserList;
  isInsurer:Boolean=false;
  canCreate:Boolean=false;
  isShow = false;
  isBanker:Boolean=false;
  insurerList: any = [];
  insurerMasterList : any =[];
  PageSelectNumber: string[];
  userOrgId;
  userRoleId;
  userTypeId;
  bankUserTypeList: any = [];
  bankUserMasterList: any = [];
  userDetails: any = {};
  userId;
  createUserObj: any = {};
  // page number
  page = 1;
  // default page size
  pageSize = 10;

  // start and end index
  startIndex = 0;
  endIndex = 10;
  totalSize = 0;
  orgList: any = [];
  roleMaserList: any = [];
  roleList : any =[];
  adminPermissionList: any = [];
  resetedPassword:any;
  LODASH=_;
  constructor(private adminService: AdminPanelServiceService,private route: ActivatedRoute,
    private router: Router,
    private commonMethod: CommonMethods,
    private commonService: CommonService,
    private userService: UserProfileService,
    public dialog: MatDialog,
    private datePipe: DatePipe,) { this.router.routeReuseStrategy.shouldReuseRoute = () => false;}

  ngOnInit(): void {
    
    this.tab = 1;
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
    this.getAllUserType();
    this.getOtherUserList();
    this.getRoleMaserList();
    
    //this.getUserDetails();
    
     this.getBankUserList();
     this.creteUserPermission();
    
  }
  clearFilter(){
    this.otherUserList.userTypeId=null;
    this.userRoleId=null;
    this.userOrgId=null;
    this.searchValue=null;
    this.getBankUserList();
  }
  creteUserPermission(){
    // console.log( this.commonService.getStorage("usr_role_id",true));
    let val =this.commonService.getStorage("usr_role_id",true);
    if(val==101 || val==102 || val==106){
      this.canCreate= true;
    }
   
  }
  refreshPage() {
   this.ngOnInit();
  }
  // ________________________________  C O M M A N  -  S T A R T  ________________________________
  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e: any) {
    if (window.pageYOffset > 360) {
      let element: any = document.getElementById('stick-headerN');
      element.classList.add('fix-to-top-3');
      this.adjustWidth();
    } else {
      let element: any = document.getElementById('stick-headerN');
      element.classList.remove('fix-to-top-3');
      let stickN: any = document.getElementById("stick-headerN");
      stickN.style.width = "100%"
    }
  }
  adjustWidth() {
    var parentwidth = $(".parent").width();
    $(".fix-to-top-3").width(parentwidth);
  }
  activeClick(tabId: number) {
    this.tab = tabId;
    this.resetStartIndex();
  }
  getFormatedDate(date): any {
    const dateParts = date.split('-');
    const dateObj = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    return this.datePipe.transform(dateObj, 'y-MM-dd');
  }
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
    
  }
  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    if (this.tab === 1 ) {
      
      this.getBankUserList(true);
    } else if (this.tab === 2) {
      
      this.getOtherUserList(true);
    }
  }
  copyToClipBoard(data) {
    this.commonMethod.copyToClipBoard(data);
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    const fileName = 'User List' + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
      if (this.tab == 1) {
        allApplications = [{
          Sr_no: index,
          'Email-Id': element.email,
          'Mobile': element.mobile,
          'Role Name': element.roleName,
          'Full Name': element.fullName,
          'Created Date': this.dateFormateForExcel(element.createdOn),
          'Organization Name': element.orgName,
          'Branch Name': element.branchName,
          'Is Active': element.isActive ? 'True' : 'False',
          'Is Locked': element.isLocked ? 'True' : 'False',
        }];
      } else if (this.tab == 2) {
        allApplications = [{
          Sr_no: index,
          'Email-Id': element.email,
          'Mobile': element.mobile,
          'User Type': element.typeName,
          'Full Name': element.fullName,
          'Created Date': this.dateFormateForExcel(element.createdOn),
          'Is Active': element.isActive ? 'True' : 'False',
          'Is Locked': element.isLocked ? 'True' : 'False',
        }];
      }
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }
  dateFormateForExcel(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }
  // ________________________________  C O M M A N  -  E N D  ________________________________


  // ________________________________  B A N K E R  -  U S E R  -  S T A R T  ________________________________
  getBankUserList(onSearchFlag?,userType?) {
    if (!onSearchFlag) {
      this.resetStartIndex();
    }
    const filterJSON = {
      userOrgId: this.userOrgId || undefined,
      userRoleId: this.userRoleId || undefined,
      userName: this.searchValue || undefined,
      userTypeId: userType ? userType : this.userTypeId || undefined,
    }
    // this.userOrgId=null;
    // this.userRoleId=null;
    const data = {
      columnFilter: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
      roleType: 5,
      schemeId: '',
      businessTypeId: 1,
      noPagination: '',
      userOrgId: '',
    }
    
    this.adminService.getBankUserList(data).subscribe(res => {
      this.bankUserList = [];
      if (res && res.data) {
        this.bankUserList = JSON.parse(res.data);
        // this.otherUserList = JSON.parse(res.data);
        this.totalCount = this.bankUserList[0]?.totalCount;
        this.isBanker=false;
        this.isInsurer=false;
        
        if(this.otherUserList?.userTypeId==2 ){
          this.isBanker=true;
          this.getCommonList(2)
          this.roleMaserList();
        }else if(this.otherUserList?.userTypeId==6){
          this.isInsurer=true;
          this.getCommonList(6)
          this.roleMaserList();
        }
        else if(this.otherUserList?.userTypeId==4){
         // this.isInsurer=true;
          //this.getBankUserList();
          this.getCommonList(4)
        }
          
      }
      
    });
    
    
  }
  getOrganizationList() {
    this.adminService.getOrganizationList().subscribe(res => {
      if (res && res.data) {
        this.orgList = res.data;
        
        //        this.userOrgId = 13;
        //this.getBankUserList();
      }
    });
   // this.getRoleMaserList();
  }
  getAllUserType() {
    this.adminService.getAllUserType().subscribe(res => {
      if (res && res.data) {
        this.bankUserTypeList =res.data
        this.bankUserMasterList = res.data
        // res.data.forEach(element => {
        //   let res1 ={key:element[0],value:element[1]};
          
        //   this.bankUserTypeList.push(res1);
        //   console.log("bankUserTypeList",this.bankUserTypeList)
          
        // });
     
        //
      }
     // this.getBankUserList();
    });
  }
  // getUserDetails() {
  //   const data = {
  //     userId: this.userId
  //   }
  //   this.adminService.getUserDetailsList(data).subscribe(res => {
  //     if (res && res.data) {
  //       this.userDetails = res.data;
  //       this.createUserObj.email = this.userDetails.email;
  //       this.createUserObj.mobile = this.userDetails.mobile;
  //       this.createUserObj.firstName = this.userDetails.firstName;
  //       this.createUserObj.middleName = this.userDetails.middleName;
  //       this.createUserObj.lastName = this.userDetails.lastName;
  //       this.createUserObj.userOrgId = this.userDetails.userOrgId;
  //      // this.selectedScheme = this.userDetails.schemeList;
  //       this.createUserObj.userRoleId = this.userDetails.userRoleId;
  //       //this.isBranchShow(this.userRoleId);
  //     }
  //     this.getBankUserList();
  //   });

  // }
  getRoleMaserList() {
    this.adminService.getAdminRoleMaserList().subscribe(res => {
      if (res && res.data) {
        this.roleMaserList = res.data;
        this.roleList = res.data;
        this.createUserObj.userTypeId = this.bankUserTypeList.key;
        
        
        
      }
    });
  //  this.getAllUserType();
  }
  lockUnlockUser(userId,isLocked) {
    const data = {
      userId: userId,
      isLocked: isLocked === 1 ? false : true,
      isLockedByAdmin: isLocked === 1 ? false : true
    };
    this.userService.lockUnlockUser(data).subscribe(res => {
      if (res) {
        if (this.tab === 1) {
          this.getBankUserList();
        } else if (this.tab === 2) {
          this.getOtherUserList();
        }
      }
      this.commonService.infoSnackBar(res.message);
    });
  }
  activeIsActiveUser(userId, isActive) {
    const data = {
      userId: userId,
      isActive: isActive,
    };
    this.adminService.activeIsActiveUser(data).subscribe(res => {
      if (res) {
        this.getBankUserList();
      }
    });
  }
  // userResetPassword(userId) {
  //   const data = {
  //     userId: userId,
  //   };
  //   this.adminService.userResetPassword(data).subscribe(res => {
  //     if (res) {
  //       this.getBankUserList();
  //       this.commonService.successSnackBar(res.message);
  //     } else {
  //       this.commonService.warningSnackBar(res.message);
  //     }
  //   });
  // }

  userResetPassword(userId) {
    const data = {
      userId: userId,
    };
    this.adminService.userResetPassword(data).subscribe(res => {
      if (res && res?.status == 200 && res?.data) {
        this.resetedPassword = res?.data;
        this.openResetPassword(this.resetedPassword);
        // this.commonService.successSnackBar(res.message);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }

  openResetPassword(password) {
    const config = {
      windowClass: 'popup-650',
      type: 3,
      password:password
    };
    this.openPopUpMat(config, ConfirmationPopupComponent, ['popup-650','p-0-popup'], true).afterClosed().subscribe(result => {
      this.getBankUserList();
    });
  }

  openPopUpMat(obj: any, popUpName: any, objClass?: any, disableClose?: boolean) {
    return this.dialog.open(popUpName, { panelClass: objClass, autoFocus: false, data: obj, disableClose: disableClose });
  }

  goToCreateUserPage(userId, userOrgId, branchId, userRoleId) {
    this.router.navigate(['/Admin/Create-New-User'], { queryParams: { userId: CommonService.encryptFuntion(userId), userOrgId: CommonService.encryptFuntion(userOrgId), branchId: branchId ? CommonService.encryptFuntion(branchId) : undefined, userRoleId: CommonService.encryptFuntion(userRoleId) } });
  }
  downloadAll() {
    const filterJSON = {
      userOrgId: this.userOrgId || undefined,
      userRoleId: this.userRoleId || undefined,
      searchValue: this.searchValue || undefined,
      userTypeId: this.userTypeId || undefined
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: 0,
      paginationTO: this.totalCount,
    }
    this.adminService.getBankUserList(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.downloadDataInExcel(res.data);
      } else {
        this.commonService.warningSnackBar("No records available.")
      }
    });
  }
  // ________________________________  B A N K E R  -  U S E R  -  E N D  ________________________________


  // ________________________________  O T H E R  -  U S E R  -  S T A R T  ________________________________
  getOtherUserList(onSearchFlag?) {
    if (!onSearchFlag) {
      this.resetStartIndex();
    }
    const filterJSON = {
      // userOrgId: this.userOrgId || undefined,
      userTypeId: this.userTypeId || undefined,
      searchValue: this.searchValue || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getOtherUserList(data).subscribe(res => {
      this.otherUserList = [];
      if (res && res.data) {
         this.otherUserList = JSON.parse(res.data);
        // this.otherUserList = res.data;
        
      //  setTimeout(() => {
      //   this.getBankUserList();
      //  }, 1000);
        
        
        this.totalOtherCount = res.data[0].totalCount;
        this.setHideBranch(this.otherUserList.userTypeId)
      }
    });
    
    this.getOrganizationList()
  }
  
  setHideBranch(userTypeId) {
    this.isBanker=false;
    this.isInsurer=false;
    if(userTypeId==2){
      this.isBanker=true;
      this.getBankUserList();
      this.getCommonList(2)
    }else if(userTypeId==6){
      this.isInsurer=true;
      this.getBankUserList();
      this.getCommonList(6)
    }
    this.isShow = false;
    //this.checkValueIsNull();
    this.getOrganizationList();
  }
  
   getCommonList(id) {
     
     this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
       if (res && res.data) {
        this.insurerList = JSON.parse(res.data);
        this.insurerMasterList = JSON.parse(res.data);
      }
     });
   }

  downloadOtherUser() {
    const filterJSON = {
      userTypeId: this.userTypeId || undefined,
      searchValue: this.searchValue || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getOtherUserList(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.downloadDataInExcel(res.data);
      } else {
        this.commonService.warningSnackBar("No records available.")
      }
    });
  }

  // ________________________________  O T H E R  -  U S E R  -  E N D  ________________________________
}
