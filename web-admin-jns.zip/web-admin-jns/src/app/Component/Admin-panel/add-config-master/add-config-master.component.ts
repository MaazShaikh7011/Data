import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-add-config-master',
  templateUrl: './add-config-master.component.html',
  styleUrls: ['./add-config-master.component.scss']
})
export class AddConfigMasterComponent implements OnInit {

  id;
  code;
  value;
  isActive;
  response;
  constructor(private adminService: AdminPanelServiceService, private commonService: CommonService,private router: Router) { 
    this.id = this.commonService.getURLData('id');
  }

  ngOnInit(): void {
    if (this.id != null) {
      this.getConfigListById(this.id);
    }
  }

  saveConfigMaster() {
    const obj = {
      id: this.id ? this.id : undefined,
      code: this.code ? this.code : undefined,
      value: this.value ? this.value : undefined,
    }
    this.adminService.saveConfigMaster(obj).subscribe(res => {
      if (res && res.data) {
        this.commonService.successSnackBar(res.message);
        this.router.navigate(['/Admin/config-status'])
      }
    })
  }

  activeIsConfigMaster(id) {
    this.adminService.activeIsConfigMaster(this.id).subscribe(res => {
      if (res) {
        this.commonService.successSnackBar(res.message);
      }
    });
  }

  getConfigListById(id) {
    this.adminService.getConfigListById(id).subscribe(res => {
      if (res && res.status == 200) {
        this.response = res.data;
        this.code = this.response.code;
        this.value = this.response.value;
      }
    });

  }
}
