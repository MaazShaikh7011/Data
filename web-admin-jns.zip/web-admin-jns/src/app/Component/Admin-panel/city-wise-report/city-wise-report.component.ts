import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';

@Component({
  selector: 'app-city-wise-report',
  templateUrl: './city-wise-report.component.html',
  styleUrls: ['./city-wise-report.component.scss']
})
export class CityWiseReportComponent implements OnInit {
  LODASH = _;
  fromDate;
  toDate;
  orgId;
  bankList: any = [];
  bankMasterList: any = [];
  cityWiseDataList: any = {};
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,private commonMethod: CommonMethods) {
    const tempDate = new Date();
    // this.fromDate = new Date("" + (tempDate.getMonth() + 1) + "/" + tempDate.getDate() + "/" + tempDate.getFullYear());
    // this.toDate = new Date("" + (tempDate.getMonth() + 1) + "/" + (tempDate.getDate() + 1) + "/" + tempDate.getFullYear());
  }

  ngOnInit(): void {
    this.getCommonList(2);
    this.fetchCityWiseData();
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data)
      }
    });
  }
  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.fetchCityWiseData();
  }
  fetchCityWiseData() {
    const filterJSON = {
      orgId: this.orgId,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined
    }
    this.adminService.fetchCityWiseData(filterJSON).subscribe(res => {
      if (res?.data) {
        this.cityWiseDataList = JSON.parse(res.data);
      } else {
        this.cityWiseDataList = {};
        this.commonMethod.warningSnackBar('Data not found.');
      }
    });
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
  }

}
