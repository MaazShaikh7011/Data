import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-bank-wiseclaim-count',
  templateUrl: './bank-wiseclaim-count.component.html',
  styleUrls: ['./bank-wiseclaim-count.component.scss']
})
export class BankWiseclaimCountComponent implements OnInit {
  LODASH = _;
  bankWiseCliamList : any =[];
  orgId;
  bankList :any =[];
  bankMasterList :any =[];
  schemeMasterList;
  schemeId;
  isListCollapsed: boolean = true;
  orgIdwiseCountList;
  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  fromDate;
  toDate;
  countFlag: boolean = false;
  inProgressCnt : any =0;
  totalCnt: any =0;
  acceptedCnt : any =0;
  onHoldCnt : any =0;
  rejectedCnt : any =0;
  sendBankToBankCnt : any =0;
  sendToInsurerCnt : any =0;
  todayDate: Date = new Date();
  constructor(private adminService: AdminPanelServiceService,private commonService: CommonService,private datePipe: DatePipe) {
     const tempDate = new Date();
     this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 00:00:00");
     this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 11:59:59 PM");
   }

  ngOnInit(): void {
    this.getCommonList(2);
    this.getAllScheme();
    this.fetchClaimBankWiseCount();
  }
  clearFilter() {
    this.orgId = undefined;
    this.schemeId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.fetchClaimBankWiseCount();
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }

  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }

  fetchClaimBankWiseCount(isDwnld?){
    const data ={
      orgId: this.orgId ? this.orgId : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
    }
    this.totalCnt= 0;
    this.inProgressCnt = 0;
    this.acceptedCnt = 0;
    this.onHoldCnt = 0;
    this.rejectedCnt = 0;
    this.sendBankToBankCnt = 0;
    this.sendToInsurerCnt = 0;
    this.adminService.fetchClaimBankWiseCount(data).subscribe(res=>{
      if(res && res.data){
        this.bankWiseCliamList = JSON.parse(res.data);
        if(this.orgId){
          this.bankWiseCliamList = _.filter(this.bankWiseCliamList, (x:any)=> x.orgId == this.orgId);
        }
        if(this.orgId != null || this.schemeId !=null){
          this.bankWiseCliamList=  _.filter(this.bankWiseCliamList, (x) => x.orgId > 0)
          this.countFlag = false;
        }else{
          this.countFlag = true;
          for (let i = 0; i < this.bankWiseCliamList.length; i++) {
            this.inProgressCnt += Number(this.bankWiseCliamList[i].InProgressCount ?  this.bankWiseCliamList[i].InProgressCount : 0 )
            this.sendToInsurerCnt += Number(this.bankWiseCliamList[i].SendToInsurerCount ?  this.bankWiseCliamList[i].SendToInsurerCount : 0 )
            this.sendBankToBankCnt += Number(this.bankWiseCliamList[i].SendBackToBnakCount ?  this.bankWiseCliamList[i].SendBackToBnakCount : 0 )
            this.rejectedCnt += Number(this.bankWiseCliamList[i].RejectedCount ?  this.bankWiseCliamList[i].RejectedCount : 0 )
            this.onHoldCnt += Number(this.bankWiseCliamList[i].OnHoldCount ?  this.bankWiseCliamList[i].OnHoldCount : 0 )
            this.acceptedCnt += Number(this.bankWiseCliamList[i].AccpetedCount ?  this.bankWiseCliamList[i].AccpetedCount : 0 )
            this.totalCnt += Number(this.bankWiseCliamList[i].totalCount ?  this.bankWiseCliamList[i].totalCount : 0 )
          }
        }
      }
      if(isDwnld==true){
        this.downloadDataInExcel(this.bankWiseCliamList);
        }
    })
  }
  
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    const fileName = 'Bank-Wise Claim Count'+this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa') + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
        allApplications = [{
          Sr_no: index,
          'org Name': element.orgName || 0,
          'Total Count': element.totalCount || 0,
          'Completed Count': element.AccpetedCount || 0,
          'OnHold Count': element.OnHoldCount || 0,
          'Rejected Count': element.RejectedCount || 0,
          'SendBackToBnak Count': element.SendBackToBnakCount || 0,
          'SendToInsurer Count': element.SendToInsurerCount || 0,
        }];
      
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }
  dateFormateForExcel(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  fetchclaimOrgIdwiseCount(orgId){
    this.orgIdwiseCountList = [];
    this.bankWiseCliamList.forEach(element => {
      if (element.orgId == orgId) {
        element.isListCollapsed == false;
      } else {
        element.isListCollapsed = false;
      }
    });
    const data ={
      orgId : orgId ? orgId :undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
    }
    this.adminService.fetchclaimOrgIdwiseCount(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.orgIdwiseCountList = JSON.parse(res.data);
        this.orgIdwiseCountList.forEach(element => {
          element.schemeName = _.find(this.schemeMasterList, (x: any) => x.id == element.schemeId).name;
        });
        // console.log(this.orgIdwiseCountList)
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

}
