import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-enrollment-api-audit-details-log',
  templateUrl: './enrollment-api-audit-details-log.component.html',
  styleUrls: ['./enrollment-api-audit-details-log.component.scss']
})
export class EnrollmentApiAuditDetailsLogComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount;
  bankList :any =[];
  bankMasterList : any =[];
  orgId;
  fromDate: any;
  toDate: any;
  schemeId=1;
  schemeList:any;
  enrollmentDataList:any = [];
  isSkipCount = 0;
  searchType:any;
  searchTypeId:any;
  searchData:any;
  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private userService: UserProfileService,
    public commonMethods: CommonMethods) { 
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  ngOnInit(): void {
    this.getCommonList(2);
    this.schemeList = _.filter(Constants.schemeList, (x) => x.id > 0); 
    this.searchType = [
      { id: 1, value: 'Account Number' },
      { id: 2, value: 'URN' },
      { id: 3, value: 'CIF' },
      { id: 4, value: 'Application Id' },
    ];
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }
  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchEnrollmentList(true);
  }
  
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
 
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.searchTypeId = undefined;
    this.searchData = undefined;
    this.fetchEnrollmentList(false);
  }

  fetchEnrollmentList(onPageChangeFlag?){
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    if(this.orgId){
      const data = {     
        searchData: this.searchData ? this.searchData : undefined,
        searchTypeId : this.searchTypeId ? this.searchTypeId :undefined,
        toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        bankId: this.orgId ? this.orgId : undefined,
        schemeId: this.schemeId ? this.schemeId : undefined,
        isSkipCount: this.isSkipCount,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: onPageChangeFlag==false ? 0 : this.pageSize
      }
      this.adminService.fetchEnrollmentList(data).subscribe(res => {
          if (res && res?.data && res.status == 200) {
            this.enrollmentDataList = JSON.parse(res.data);
            this.enrollmentDataList.forEach(element => {
              element.userorgName =_.find(this.bankList,(x:any)=>x.userOrgId == this.orgId).organisationName
             });
            this.enrollmentDataList = _.orderBy(this.enrollmentDataList , [x => x.stageId ==6 ? x.enrollDate : x.modifiedDate ] ,['desc'] )
            this.totalCount = this.enrollmentDataList[0]?.totalcount || 0;
          } else {
            this.totalCount = 0;
            this.enrollmentDataList = [];
            this.commonService.warningSnackBar('data not found');
          }
    });
  } else{
    this.enrollmentDataList = [];
    this.totalCount = 0;
    this.commonService.warningSnackBar('please select any organisation.');
  }
  }

  downloadCertificate(applicationData) {
    const data = {
      applicationId: applicationData.id,
      schemeId: +this.schemeId,
      orgId: +this.orgId,
      isDownload: true
    }
    this.adminService.getCertiInsData(data).subscribe(res => {
      if (res && res.data) {
        const fileName = "Certificate-of-Insurance-" + applicationData.urn;
        this.commonMethods.downloadPdfFromBase64toFile(res.data, fileName);
      }
    }, error => {
      this.commonService.errorSnackBar(error);

    })
  }

  clearSearchType(){
    this.fromDate=undefined;
    this.toDate=undefined;
    this.searchData = undefined;
  }
   
}
