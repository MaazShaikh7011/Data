export class AdminDashboard {

    static GRAPH_TYPE = {
        LINE_COLUM_BAR_CHART: 1,
        APPLICATION_DETAILS_PIE_CHART: 2,
        SCHEME_WISE_APPLICATION_PIECHARTSC: 3,
        LOAN_WISE_APPLICATION_PIECHARTSC: 4,
        BANK_WISE_APPLICATION_PIECHARTSC: 5,
        DAY_WISE_COLUMN_BAR_CHART: 6,
        DAY_WISE_BAR_CHART: 9,
        STATE_WISE_APPLICATION_PIE_CHART: 7,
        CITY_WISE_APPLICATION_PIE_CHART: 8,
        BANK_LIVE_DATA: 10,
    };

    static PROPOSAL_STATUS_LIST = [
        { id: 1, name: 'On Going' },
        { id: 2, name: 'Approved' },
        { id: 3, name: 'Referred' },
        { id: 4, name: 'On Hold' },
        { id: 5, name: 'Rejected' },
        { id: 6, name: 'Sanctioned' },
        { id: 7, name: 'Disbursed' }
    ];

    static SOURSE_TYPE_LIST = [
        { id: 1, name: 'All' },
        { id: 2, name: 'Bank Specific' },
        { id: 3, name: 'Market Place' }
    ];

    static DAY_MONTH_YEAR_LIST = [
        { id: 1, name: 'Day' },
        { id: 2, name: 'Month' },
        { id: 3, name: 'Year' }
    ];

    static RADIO_BUTTON_LIST = [
        { id: 1, name: 'Count' }, // , isActive: true 
        { id: 2, name: 'Amount' } // , isActive: false
    ];

    static SCHEME_ID_LIST = [1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 15];

}