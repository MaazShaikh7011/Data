import { Component, OnInit, HostListener } from '@angular/core';
import { ChartType } from 'src/app/CommoUtils/common-services/apex.model';
import { lineColumAreaChart, APPLICATION_DETAILS_PIE_CHART, SCHEME_WISE_APPLICATION_PIECHARTSC, LOAN_WISE_APPLICATION_PIECHARTSC, BANK_WISE_APPLICATION_PIECHARTSC, CITY_WISE_APPLICATION_PIE_CHART, STATE_WISE_APPLICATION_PIE_CHART, DAY_WISE_COLUMN_BAR_CHART, DAY_WISE_BAR_CHART, BANK_LIVE_DATA } from 'src/app/CommoUtils/common-services/data';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import * as _ from 'lodash';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { DatePipe } from '@angular/common';
import alasql from 'alasql';
import { IndNumFormatPipe } from 'src/app/CommoUtils/common-services/pipe/ind-num-format.pipe';
import { AdminDashboard } from './admin-dashboard.model';

import * as Highcharts from 'highcharts';

declare var $: any;

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss'],
  providers: [DatePipe, IndNumFormatPipe]
})
export class AdminDashboardComponent implements OnInit {
  // bread crumb items
  breadCrumbItems: Array<{}>;
  applicationDetailsCollaps: boolean = false;
  loanTypWiseCollaps: boolean = false;
  cityStateCollaps: boolean = false;
  orgWiseDataCollaps: boolean = false;
  insurerWiseDataCollaps: boolean = false;
  bankWiseLiveDataCollaps:boolean=false;
  
  schemeList: any = [];
  data: any = [];
  categories: any = [];
  schemeWisCategories: any = [];
  disbursedCount = 0;
  generateCount = 0;
  inProgressCount = 0;
  onholdCount = 0;
  referredCount = 0;
  rejectedCount = 0;
  sanctionedByOtherBankCount = 0;
  sanctionedCount = 0;
  totalUser = 0;
  
  searchItem: any;
  
  sourseTypeList = AdminDashboard.SOURSE_TYPE_LIST;
  dayMonthYearList = AdminDashboard.DAY_MONTH_YEAR_LIST;
  radioButtonList = AdminDashboard.RADIO_BUTTON_LIST;
  proposalStatusMasterList = AdminDashboard.PROPOSAL_STATUS_LIST;
  approvedReferredproposalStatusMasterList = _.filter(AdminDashboard.PROPOSAL_STATUS_LIST, (x: any) => x.id == 2 || x.id == 3);
  cityStateProposalStatusMasterList = _.filter(AdminDashboard.PROPOSAL_STATUS_LIST, (x: any) => x.id != 1);
  
  stateType = 1;
  cityType = 2;
  barChartSourceId = 1;
  applicationDetailsSourceId = 1;
  schemeWiseSourceId = 1;
  loanWiseSourceId = 1;
  bankWiseSourceId = 1;
  dayMonthbarChartSourceId = 1;
  dayMonthbarChartSourceIdForApprRef = 1;
  statePieChartSourceId = 1;
  cityPieChartSourceId = 1;
  
  dayMonthbarChartTypeId;
  dayMonthbarChartTypeApproRefId = 1;
  
  barChartCampaignId;
  applicationDetailsCampaignId;
  schemeWiseCampaignId;
  loanWiseCampaignId;
  dayMonthWiseCampaignId;
  dayMonthWiseAppRefCampainId;
  stateWiseCampaignId;
  cityWiseCampaignId;
  
  stateWiseUserOrgId;
  cityWiseUserOrgId;
  
  proposalType: number;
  
  campaignList: any = [];
  organizationList: any = [];
  barChartApplicationDetailsList = [];
  applicationDetailsList: any = [];
  schemeWiseList: any = [];
  loanWiseList: any = [];
  bankWiseList: any = [];
  stateWiseList: any = [];
  cityWiseList: any = [];
  orgWisePolicyList: any = [];
  insureWisePolicyList: any = [];
  bankLivePolicyList: any = [];
  
  selectedScheme: any = [];
  selectedSchemeApproRef: any = [];
  dayMonthSelectedScheme: any = [];
  dayMonthSelectedApproRefScheme: any = [];
  stateSelectedScheme: any = [];
  citySelectedScheme: any = [];
  selectedProposalStatus: any = [];
  selectedProposalAppRefStatus: any = [];
  
  totalCountApplicationDetailsPieChart = 0;
  totalCountSchemeWisePieChart = 0;
  totalCountLoanWisePieChart = 0;
  totalCountBankWisePieChart = 0;
  totalCountStateWisePieChart = 0;
  totalCountCityWisePieChart = 0;
  
  lineColumAreaChart:any;

  APPLICATION_DETAILS_PIE_CHART:any;
  SCHEME_WISE_APPLICATION_PIECHARTSC: any;
  LOAN_WISE_APPLICATION_PIECHARTSC: any;
  BANK_WISE_APPLICATION_PIECHARTSC: any;
  DAY_WISE_COLUMN_BAR_CHART: any;
  DAY_WISE_BAR_CHART: any;
  BANK_LIVE_DATA: any;
  STATE_WISE_APPLICATION_PIE_CHART: any;
  CITY_WISE_APPLICATION_PIE_CHART: any;
  
  loadBarChartCount = false;
  loadApplicationDetailsPieChart = false;
  loadSchemeWisePieChart = false;
  loadLoanWisePieChart = false;
  loadBankWisePieChart = false;
  loadStateWisePieChart = false;
  loadCityWisePieChart = false;
  loadOrgWiseBarChart = true;
  loadInsurerWiseBarChart = true;
  loadBankLiveData = true;
  
  businessMasterList = _.filter(Constants.businessMaster, x => x.id != -1)
  schemeMasterList;
  
  fromDate: any;
  toDate: any;
  maxDate: any;
  adminPermissionList: any = [];
  
  tab!: number;
  tab1!: number;
  tab2!: number;
  tab3!: number;
  tab4!: number;
  tab5!: number;
  tab6!: number;
  tab7!: number;
  tab8!: number;
  tab9!: number;

  schemeWiseProposalStatusId;
  loanWiseProposalStatusId;
  bankWiseProposalStatusId;
  stateWiseProposalStatusId;
  cityWiseProposalStatusId;
  
  applicationSummaryBarChartLoding: boolean = true;
  applicationDetailsPieChartLoding: boolean = true;
  schemeWisePieChartLoding: boolean = true;
  loanWisePieChartLoding: boolean = true;
  bankWisePieChartLoding: boolean = true;
  stateWisePieChartLoding: boolean = true;
  cityWisePieChartLoding: boolean = true;
  orgWiseBarCharLoading: boolean = true;
  insurerWiseBarChartLoading: boolean = true;
  bankLiveDataLoading: boolean = true;

  applicationDetailsPieChartRadioButton = 1;
  schemeWisePieChartRadioButton = 1;
  loanWisePieChartRadioButton = 1;
  bankWisePieChartRadioButton = 1;
  stateWisePieChartRadioButton = 1;
  cityWisePieChartRadioButton = 1;
  
  Highcharts: typeof Highcharts = Highcharts;
  chart;
  updateFlag = false;
  chartConstructor = "chart";
  chartCallback;
  orgList=[];
  orgId;
  todayDate: Date = new Date();
  isOrgViewEmpty:boolean = true;
  isInsViewEmpty:boolean = true;
  isLiveViewEmpty:boolean = true;
  constructor(
    private commonService: CommonService,
    private adminService: AdminPanelServiceService,
    private datePipe: DatePipe
    ) {
      this.defaultSelectedData();
      this.fillChart();
    }
    
  //   adjustWidth() {
  //     var parentwidth = $(".parent").width();
  //     $(".fix-to-top-3").width(parentwidth);
  // }

  // @HostListener('window:scroll', ['$event'])
  // onWindowScroll(e: any) {
  //   if (window.pageYOffset > 100) {
  //     let element: any = document.getElementById('stick-headerN');
  //     element.classList.add('fix-to-top-3');
  //     this.adjustWidth();
  //   } else {
  //     let element: any = document.getElementById('stick-headerN');
  //     element.classList.remove('fix-to-top-3');
  //     //this.adjustWidthRemove();]
  //     // Fix After Remove Css
  //     let stickN: any = document.getElementById("stick-headerN");
  //     stickN.style.width = "100%"
  //   }
  // }

  ngOnInit(): void {
    this.adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
    this.fetchOrganizationList(2);
  }

  fetchOrganizationList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.orgList = JSON.parse(res.data);
      }
    });
  }

  defaultSelectedData() {
    this.tab = this.tab1 = this.tab2 = this.tab3 = this.tab4 = this.tab5 = this.tab6 = this.tab7 = this.tab8 = 1;
    this.tab9= 3;

    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
    const date1 = new Date(new Date);
    this.maxDate = { year: date1.getFullYear(), month: date1.getMonth() + 1, day: date1.getDate() };
    const date = { year: date1.getFullYear(), month: date1.getMonth() + 1, day: date1.getDate() };
    // this.fromDate = ((date.day == 1 ? 1 : date.day - 1) + '-' + date.month + '-' + date.year);
    this.fromDate = (date.year + '-' + date.month + '-' + 1);
    this.fromDate = this.getFormatedDate(this.fromDate);
    this.toDate = (date.year + "-" + date.month + "-" + date.day);
    this.toDate = this.getFormatedDate(this.toDate);
    this.selectedScheme = this.dayMonthSelectedScheme = AdminDashboard.SCHEME_ID_LIST;
    this.selectedSchemeApproRef = this.dayMonthSelectedApproRefScheme = AdminDashboard.SCHEME_ID_LIST;
    // this.applicationDetailsPieChartRadioButton = this.schemeWisePieChartRadioButton = this.loanWisePieChartRadioButton = this.bankWisePieChartRadioButton = this.stateWisePieChartRadioButton = this.cityWisePieChartRadioButton = 1;
    this.selectedProposalStatus = [2, 3];
    this.selectedProposalAppRefStatus = [2,3];
    this.dayMonthbarChartTypeId = 1;
  }

  private fillChart() {
    this.lineColumAreaChart = lineColumAreaChart;
    this.APPLICATION_DETAILS_PIE_CHART = APPLICATION_DETAILS_PIE_CHART;
    this.SCHEME_WISE_APPLICATION_PIECHARTSC = SCHEME_WISE_APPLICATION_PIECHARTSC;
    this.LOAN_WISE_APPLICATION_PIECHARTSC = LOAN_WISE_APPLICATION_PIECHARTSC;
    this.BANK_WISE_APPLICATION_PIECHARTSC = BANK_WISE_APPLICATION_PIECHARTSC;
    this.DAY_WISE_COLUMN_BAR_CHART = DAY_WISE_COLUMN_BAR_CHART;
    this.DAY_WISE_BAR_CHART = DAY_WISE_BAR_CHART;
    this.BANK_LIVE_DATA = BANK_LIVE_DATA;

    this.STATE_WISE_APPLICATION_PIE_CHART = STATE_WISE_APPLICATION_PIE_CHART;
    this.CITY_WISE_APPLICATION_PIE_CHART = CITY_WISE_APPLICATION_PIE_CHART;
  }


  getDashBoardData(type?, isCollaps?) {
    if (isCollaps) {
      if (type === 4) {
        this.getPolicyBarChartOrgWise(true);
      } else if (type === 5) {
        this.getPolicyBarChartInsurerWise(true);
      }  else if (type === 6) {
        this.tab9=3;
        // this.getPolicyBarChartBankLiveData(true);
      }
    }
  }

  commonRequsetJSON(requestFrom?) {
    const filterJSON: any = {
      fromDate: this.fromDate ? this.getFormatedDate(this.fromDate) : undefined,
      toDate: this.toDate ? this.getFormatedDate(this.toDate) : undefined,
    }
    switch (requestFrom) {
      case AdminDashboard.GRAPH_TYPE.DAY_WISE_COLUMN_BAR_CHART:
        break;
      case AdminDashboard.GRAPH_TYPE.DAY_WISE_BAR_CHART:
        break;
      case AdminDashboard.GRAPH_TYPE.BANK_LIVE_DATA:
        filterJSON.orgId = this.orgId ? this.orgId : undefined;
        break;
      default:
        break;
    }
    return filterJSON;
  }

  getPolicyBarChartOrgWise(isClear?) {
    this.orgWiseBarCharLoading = true;
    if (isClear) {
      this.tab5 = 1;
      // this.loadOrgWiseBarChart = false;
    }
    this.isOrgViewEmpty = true;
    this.adminService.getPolicyBarChartOrgWise({ filterJSON: JSON.stringify(this.commonRequsetJSON(AdminDashboard.GRAPH_TYPE.DAY_WISE_COLUMN_BAR_CHART)) }).subscribe(success => {
      this.orgWisePolicyList = [];      
      if (success && success.status == 200 && success.flag) {        
        this.orgWisePolicyList = JSON.parse(success.data);
        console.log(JSON.parse(success.data));
        
        this.orgWisePolicyList.forEach(element => {
          element.pmsbyCount = element.pmsbyCount ? element.pmsbyCount : 0;
          element.pmjjbyCount = element.pmjjbyCount ? element.pmjjbyCount : 0;
          element.total = element.pmsbyCount + element.pmjjbyCount;
          if(element.total > 0 && this.isOrgViewEmpty){
            this.isOrgViewEmpty = false;
          }
        });
        this.orgWisePolicyList = _.orderBy(this.orgWisePolicyList, (x: any) => x.total, 'desc');
        this.setPolicyBarChartOrgWise(this.orgWisePolicyList);
      } else {
        this.orgWisePolicyList = [];
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  setPolicyBarChartOrgWise(responce) {
    if (!_.isEmpty(responce)) {
      const data = [];
      const pmsbyCountList = [];
      const pmjjbyCountList = [];
      const categories = [];
     
      responce.forEach(element => {
        categories.push(element.orgName);
        if (element.pmsbyCount || element.pmjjbyCount) {
          pmsbyCountList.push(element.pmsbyCount ? element.pmsbyCount : 0);
          pmjjbyCountList.push(element.pmjjbyCount ? element.pmjjbyCount: 0);
        }
      });

      if (!_.isEmpty(pmsbyCountList)) {
        data.push({ name: 'PMSBY Count', data: pmsbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
              [0, '#468CC2'],[1, '#23699E']]},     
             });
      }
      if (!_.isEmpty(pmjjbyCountList)) {
        data.push({ name: 'PMJJBY Count', data: pmjjbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
          [0, '#F7BC38'],[1, '#FBDD9A']]}, 
        });
      }

      this.DAY_WISE_COLUMN_BAR_CHART.xAxis.categories = categories;
      this.DAY_WISE_COLUMN_BAR_CHART.series = data;
      this.loadOrgWiseBarChart = false;

      setTimeout(() => {
        this.orgWiseBarCharLoading = false;
        this.loadOrgWiseBarChart = true;
      }, 500);
    } else {
      this.DAY_WISE_COLUMN_BAR_CHART.labels = ['No Data'];
      this.DAY_WISE_COLUMN_BAR_CHART.series = [0];
      this.loadOrgWiseBarChart = true;
      setTimeout(() => {
        this.orgWiseBarCharLoading = false;
      }, 500);
    }
  }

  getPolicyBarChartInsurerWise(isClear?) {
    this.insurerWiseBarChartLoading = true;
    if (isClear) {
      this.tab8 = 1;
      // this.loadInsurerWiseBarChart = false;
    }
    this.isInsViewEmpty = true;
    this.adminService.getPolicyBarChartInsurerWise({ filterJSON: JSON.stringify(this.commonRequsetJSON(AdminDashboard.GRAPH_TYPE.DAY_WISE_BAR_CHART)) }).subscribe(success => {
      this.insureWisePolicyList = [];
      if (success && success.data) {
        this.insureWisePolicyList = JSON.parse(success.data);
        this.insureWisePolicyList.forEach(element => {
          element.pmsbyCount = element.pmsbyCount ? element.pmsbyCount : 0;
          element.pmjjbyCount = element.pmjjbyCount ? element.pmjjbyCount : 0;
          element.total = element.pmsbyCount + element.pmjjbyCount;
          if(element.total > 0 && this.isInsViewEmpty){
            this.isInsViewEmpty = false;
          }
        });
        this.insureWisePolicyList = _.orderBy(this.insureWisePolicyList, (x: any) => x.total, 'desc');
        this.setPolicyBarChartInsurerWise(this.insureWisePolicyList);
      } else {
        this.insureWisePolicyList = [];
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  setPolicyBarChartInsurerWise(responce) {
    if (!_.isEmpty(responce)) {
      const data = [];
      const pmsbyCountList = [];
      const pmjjbyCountList = [];
      const categories = [];
      responce.forEach(element => {
        categories.push(element.orgName);
        if (element.pmsbyCount || element.pmjjbyCount) {
          pmsbyCountList.push(element.pmsbyCount ? element.pmsbyCount : 0);
          pmjjbyCountList.push(element.pmjjbyCount ? element.pmjjbyCount: 0);
        }
      });

      if (!_.isEmpty(pmsbyCountList)) {
        data.push({ name: 'PMSBY Count', data: pmsbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
              [0, '#468CC2'],[1, '#23699E']]},     
             });
      }
      if (!_.isEmpty(pmjjbyCountList)) {
        data.push({ name: 'PMJJBY Count', data: pmjjbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
          [0, '#F7BC38'],[1, '#FBDD9A']]}, 
        });
      }
      
      this.DAY_WISE_BAR_CHART.xAxis.categories = categories;
      this.DAY_WISE_BAR_CHART.series = data;
      this.loadInsurerWiseBarChart = false;
      setTimeout(() => {
        this.insurerWiseBarChartLoading = false;
        this.loadInsurerWiseBarChart = true;
      }, 500);
    } else {
      this.DAY_WISE_BAR_CHART.labels = ['No Data'];
      this.DAY_WISE_BAR_CHART.series = [0];
      this.loadInsurerWiseBarChart = true;
      setTimeout(() => {
        this.insurerWiseBarChartLoading = false;
      }, 500);
    }
  }

  getPolicyBarChartBankLiveData(isClear?) {
    if (!this.orgId){
      this.tab9= 3;
      this.commonService.warningSnackBar("Please select Organisation");
      return;
    }
    this.bankLiveDataLoading = true;
    if (isClear) {
      this.tab9 = 1;
      // this.loadBankLiveData = false;
    }
    this.isLiveViewEmpty = true;
    this.adminService.getPolicyBarChartBankLiveData({ filterJSON: JSON.stringify(this.commonRequsetJSON(AdminDashboard.GRAPH_TYPE.BANK_LIVE_DATA)) }).subscribe(success => {
      this.bankLivePolicyList = [];
      if (success && success.data) {
        this.bankLivePolicyList = JSON.parse(success.data);
        this.bankLivePolicyList.forEach(element => {
          element.pmsbyCount = element.pmsbyCount ? element.pmsbyCount : 0;
          element.pmjjbyCount = element.pmjjbyCount ? element.pmjjbyCount : 0;
          element.total = element.pmsbyCount + element.pmjjbyCount;
          if(element.total > 0 && this.isLiveViewEmpty){
            this.isLiveViewEmpty = false;
          }
        });
        this.bankLivePolicyList = _.orderBy(this.bankLivePolicyList, (x: any) => x.total, 'desc');
        this.setPolicyBarChartBankLiveData(this.bankLivePolicyList);
      } else {
        this.bankLivePolicyList = [];
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  setPolicyBarChartBankLiveData(responce) {
    if (!_.isEmpty(responce)) {
      const data = [];
      const pmsbyCountList = [];
      const pmjjbyCountList = [];
      const categories = [];      
      responce.forEach(element => {
        categories.push(element.channel);
        if (element.pmsbyCount || element.pmjjbyCount) {
          pmsbyCountList.push(element.pmsbyCount ? element.pmsbyCount : 0);
          pmjjbyCountList.push(element.pmjjbyCount ? element.pmjjbyCount: 0);
        }
      });

      if (!_.isEmpty(pmsbyCountList)) {
        data.push({ name: 'PMSBY Count', data: pmsbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
          [0, '#468CC2']]}, // ,[1, '#23699E']
        });
      }
      if (!_.isEmpty(pmjjbyCountList)) {
        data.push({ name: 'PMJJBY Count', data: pmjjbyCountList,color: {linearGradient: {x1: 0,x2: 0,y1: 0,y2: 1},stops: [
          [0, '#F7BC38']]}, // ,[1, '#FBDD9A']
        });
      }

      this.BANK_LIVE_DATA.xAxis.categories = categories;
      this.BANK_LIVE_DATA.series = data;
      this.loadBankLiveData = false;
      setTimeout(() => {
        this.bankLiveDataLoading = false;
        this.loadBankLiveData = true;
      }, 500);
    } else {
      this.BANK_LIVE_DATA.labels = ['No Data'];
      this.BANK_LIVE_DATA.series = [0];
      this.loadBankLiveData = true;
      setTimeout(() => {
        this.bankLiveDataLoading = false;
      }, 500);
    }
  }

  getDataBySubmit(): void {
    // if (this.applicationDetailsCollaps) {
    //   this.getApplicationDetailsPieChart(true);
    //   this.getSchemeWisePieChart(true);
    // }
    // if (this.loanTypWiseCollaps) {
    //   this.getLoanWisePieChart(true);
    //   this.getBankWisePieChart(true);
    // }
    // if (this.cityStateCollaps) {
    //   this.getCityWisePieChart(true);
    //   this.getStateWisePieChart(true);
    // }
    if (this.orgWiseDataCollaps) {
      this.getPolicyBarChartOrgWise(true);
    }
    if (this.insurerWiseDataCollaps) {
      this.getPolicyBarChartInsurerWise(true);
    }
    if (this.bankWiseLiveDataCollaps) {
      this.getPolicyBarChartBankLiveData(true);
    }
  }

  activeClick(tabId: number) {
    this.tab = tabId;
  }
  activeClick1(tabId: number) {
    this.tab1 = tabId;
  }
  activeClick2(tabId: number) {
    this.tab2 = tabId;
  }
  activeClick3(tabId: number) {
    this.tab3 = tabId;
  }
  activeClick4(tabId: number) {
    this.tab4 = tabId;
  }
  activeClick5(tabId: number) {
    this.tab5 = tabId;
  }
  activeClick6(tabId: number) {
    this.tab6 = tabId;
  }
  activeClick7(tabId: number) {
    this.tab7 = tabId;
  }
  activeClick8(tabId: number) {
    this.tab8 = tabId;
  }
  activeClick9(tabId: number) {
    this.tab9 = tabId;
  }

  getFormatedDate(date): any {
    if (typeof(date) != "object") {
      const dateParts = date.split('-');
      const dateObj = new Date(+dateParts[0], dateParts[1] - 1, +dateParts[2]);
      return this.datePipe.transform(dateObj, 'y-MM-dd');
    } else {
      return this.datePipe.transform(date, 'y-MM-dd');
    }
  }

  downloadReportOrgWise(excelName, excelData): void {
    if (_.isEmpty(excelData)) {
      this.commonService.warningSnackBar('Data not Found');
      return;
    }
    let downloadData = [];
    excelData.forEach((element, i) => {
      let excelValue: any;
      if (excelName == 'Org Wise Data') {
        excelValue = [{
          Sr_no: (i + 1),
          'Org Name': element.orgName || '',
          'PMSBY Count': element.pmsbyCount || 0,
          'PMJJBY Count': element.pmjjbyCount || 0,
          'Total Count': element.total || 0,
        }];
      } else {
        excelValue = [{
          Sr_no: (i + 1),
          Label: element.labelName,
          Count: element.proposalCount
        }];
      }
      downloadData = downloadData.concat(excelValue);
    });
    alasql('SELECT * INTO XLSX("' + excelName + '",{headers:true}) FROM ?', [downloadData]);
  }

  downloadReportInsurerWise(excelName, excelData): void {
    if (_.isEmpty(excelData)) {
      this.commonService.warningSnackBar('Data not Found');
      return;
    }
    let downloadData = [];
    excelData.forEach((element, i) => {
      let excelValue: any;
      if (excelName == 'Insurer Wise Data') {
        excelValue = [{
          Sr_no: (i + 1),
          'Insurer Name': element.orgName || '',
          'PMSBY Count': element.pmsbyCount || 0,
          'PMJJBY Count': element.pmjjbyCount || 0,
          'Total Count': element.total || 0,
        }];
      } else {
        excelValue = [{
          Sr_no: (i + 1),
          Label: element.labelName,
          Count: element.proposalCount
        }];
      }
      downloadData = downloadData.concat(excelValue);
    });
    alasql('SELECT * INTO XLSX("' + excelName + '",{headers:true}) FROM ?', [downloadData]);
  }

  downloadReportBankLiveData(excelName, excelData): void {
    if (_.isEmpty(excelData)) {
      this.commonService.warningSnackBar('Data not Found');
      return;
    }
    let downloadData = [];
    excelData.forEach((element, i) => {
      let excelValue: any;
      if (excelName == 'Bank Wise Data') {
        excelValue = [{
          Sr_no: (i + 1),
          'Channel Name': element.channel || '',
          'PMSBY Count': element.pmsbyCount || 0,
          'PMJJBY Count': element.pmjjbyCount || 0,
          'Total Count': element.total || 0,
        }];
      } else {
        excelValue = [{
          Sr_no: (i + 1),
          Label: element.labelName,
          Count: element.proposalCount
        }];
      }
      downloadData = downloadData.concat(excelValue);
    });
    alasql('SELECT * INTO XLSX("' + excelName + '",{headers:true}) FROM ?', [downloadData]);
  }

  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }

  selectAllScheme(event) {
    this.selectedScheme = [];
    if (event.target.checked) {
      this.schemeMasterList.forEach(element => {
        this.selectedScheme.push(element.id);
      });
    } else {
      this.selectedScheme = [];
    }
  }

  selectAllDayMonthScheme(event) {
    this.dayMonthSelectedScheme = [];
    this.dayMonthSelectedApproRefScheme = [];
    if (event.target.checked) {
      this.schemeMasterList.forEach(element => {
        this.dayMonthSelectedScheme.push(element.id);
        this.dayMonthSelectedApproRefScheme.push(element.id);
      });
    } else {
      this.dayMonthSelectedScheme = [];
      this.dayMonthSelectedApproRefScheme = [];
    }
  }

  selectAllStateScheme(event) {
    this.stateSelectedScheme = [];
    if (event.target.checked) {
      this.schemeMasterList.forEach(element => {
        this.stateSelectedScheme.push(element.id);
      });
    } else {
      this.stateSelectedScheme = [];
    }
  }

  selectAllCityScheme(event) {
    this.citySelectedScheme = [];
    if (event.target.checked) {
      this.schemeMasterList.forEach(element => {
        this.citySelectedScheme.push(element.id);
      });
    } else {
      this.citySelectedScheme = [];
    }
  }

  // selectAllProposalStatus(event, isApprovedReferrd) {
  //   this.selectedProposalStatus = [];
  //   this.selectedProposalAppRefStatus = [];
  //   if (event.target.checked) {
  //     if (isApprovedReferrd) {
  //       this.approvedReferredproposalStatusMasterList.forEach(element => {
  //         this.selectedProposalAppRefStatus.push(element.id);
  //       });
  //     } else {
  //       this.proposalStatusMasterList.forEach(element => {
  //         this.selectedProposalStatus.push(element.id);
  //       });
  //     }
  //   } else {
  //     this.selectedProposalStatus = [];
  //     this.selectedProposalAppRefStatus = [];
  //   }
  // }

  selectAllProposalStatus(event) {
    this.selectedProposalStatus = [];
    if (event.target.checked) {
      this.proposalStatusMasterList.forEach(element => {
        this.selectedProposalStatus.push(element.id);
      });
    } else {
      this.selectedProposalStatus = [];
    }
  }

  selectAllProposalStatusA(event) {
    this.selectedProposalAppRefStatus = [];
    if (event.target.checked) {
      this.approvedReferredproposalStatusMasterList.forEach(element => {
        this.selectedProposalAppRefStatus.push(element.id);
      });
    } else {
      this.selectedProposalAppRefStatus = [];
    }
  }
}
