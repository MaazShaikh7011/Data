import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-application-claim-audit',
  templateUrl: './application-claim-audit.component.html',
  styleUrls: ['./application-claim-audit.component.scss']
})
export class ApplicationClaimAuditComponent implements OnInit {

  constructor(private adminService:AdminPanelServiceService,private commonService:CommonService) { }
  searchTerm;
    searchType;
    typeId;
    searchData;
    errorLogslist=[];
    data=[];
    logsStartIndex = 0;
    isListCollapsed=true;
    orgList: any;
    orgId:any;
  
    apiCounts;
    totalCount;
    logsTotalCount;
    // page number
    page = 1;
    endIndex = 10;
    logsPage = 1;
    logsEndIndex = 10;
    schemeId;
    // SchemeMasterList = Constants.schemeList;
    schemeMasterList;
  
    // default page size
    pageSize = 10;
    logsPageSize = 10;
  
    PageSelectNumber = [10, 20, 50];
    LogsPageSelectNumber = [10, 20, 50];
    ngOnInit(): void {
      this.searchType = this.searchType = [
        { id: 1, value: 'Account Number' },
        { id: 2, value: 'Application Id' },
        { id: 3, value: 'URN' },
        // { id: 4, value: 'Application Code' },
        // { id: 5, value: 'Scheme' },
        // { id: 6, value: 'Bank' },
        // { id: 7, value: 'Request Url' },
        // { id: 8, value: 'Api User Id' },
        // { id: 8, value: 'Message' }
      ];
      this.getCommonList(2);
      this.getAllScheme();
      // this.getErrorLogs();
    }

    clearFilter(){
      this.orgId = undefined;
      this.schemeId= undefined;
      this.typeId = undefined;
      this.searchData = undefined;
      this.getErrorLogs();
    }
    getAllScheme() {
      this.adminService.getAllScheme().subscribe(res => {
        if (res && res.data) {
          this.schemeMasterList = JSON.parse(res.data);
          this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
        }
      });
    }
    getCommonList(id) {
     
      this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
        if (res && res.data) {
         this.orgList = JSON.parse(res.data);
       }
      });
    }
    islistShow(flag){
      this.errorLogslist[flag].isListCollapsed =!this.errorLogslist[flag].isListCollapsed;
    }
  
    getErrorLogs(){
      const filterObj= {
        schemeId:this.schemeId ? this.schemeId : undefined,
        orgId:this.orgId ? this.orgId :undefined,
        typeId:this.typeId ? this.typeId : undefined,
        searchData:this.searchData ? this.searchData : undefined,
        from: ((this.logsPageSize*(this.logsPage-1))+1),
        to: (this.pageSize),
      }
      this.logsStartIndex=filterObj.from-1;
      this.adminService.getApiDashboardErrorLog(filterObj).subscribe(res =>{
        this.errorLogslist = JSON.parse(res.data);
        // this.data = this.errorLogslist.map(a => a.isListCollapsed);
          this.logsTotalCount = this.errorLogslist[0].totalCount || 0;
      });
    }
  
}
