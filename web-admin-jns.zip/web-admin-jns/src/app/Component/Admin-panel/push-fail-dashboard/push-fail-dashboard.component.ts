import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-push-fail-dashboard',
  templateUrl: './push-fail-dashboard.component.html',
  styleUrl: './push-fail-dashboard.component.scss'
})
export class PushFailDashboardComponent implements OnInit {

  fetchDashboardList: any = [];
  fetchDashboardInsIdeList: any = [];
  tmpObj: any = {};

  // pagination Start
  startIndex = 1;
  page = 1;
  pageSize = 5;
  totalCount: any;
  endIndex = 5;
  PageSelectNumber: number[] = [5, 10, 15, 20];
  // pagination End

  // isListLoad: boolean = false;

  LODASH = _;

  bankMasterList: any = [];
  bankList: any = [];
  orgId;

  schemeMasterList: any = [];
  schemeId;

  typeMasterList: any = [{ id: 2, value: 'Bank' }, { id: 6, value: 'Insurer' },];
  userType;

  fromDate;
  toDate;
  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe, private adminService: AdminPanelServiceService, private commonService: CommonService) {
  }

  ngOnInit(): void {
    this.userType = 2;
    // this.clearFilter();
    this.getAllScheme();
    this.getCommonList(2);
    // this.fetchDashboard();
  }

  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = _.filter(JSON.parse(res.data), (x) => x.id > 0);
        this.clearFilter();
        // console.log('this.schemeMasterList: ', this.schemeMasterList);
      }
    });
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }

  clearFilter() {
    this.orgId = undefined;
    this.schemeId = undefined;
    const tempDate = new Date();
    this.fromDate = new Date("" + (tempDate.getMonth() + 1) + "/" + tempDate.getDate() + "/" + tempDate.getFullYear() + " 00:00:00 AM");
    this.toDate = new Date("" + (tempDate.getMonth() + 1) + "/" + tempDate.getDate() + "/" + tempDate.getFullYear() + " 11:59:59 PM");
    this.fetchDashboard();
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }

  empgtyFailPuseList() {
    this.fetchDashboardList = [];
  }

  fetchDashboard(onPageChangeFlag?, obj?, isInside?) {
    const isListCollapsed = obj?.isListCollapsed ? true : false;
    if (isInside) {
      if (!this.schemeId) {
        this.commonService.warningSnackBar('please select schemeId');
        return;
      }
      if (!isListCollapsed) {
        return;
      }
    }

    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }

    this.fetchDashboardInsIdeList = [];
    this.fetchDashboardList.forEach(element => {
      element.isListCollapsed = element.orgId == obj?.orgId ? true : false;
    });
    this.tmpObj = obj;
    const data = {
      userType: this.userType ? this.userType : undefined,
      isInside: isListCollapsed,
      orgId: this.orgId ? this.orgId : (obj?.orgId ? obj.orgId : undefined),
      schemeId: this.schemeId ? this.schemeId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize ? this.pageSize : 5
    };
    // console.log('fetchPushFailList: ', data);
    this.adminService.fetchPushFailList(data).subscribe(res => {
      if (res && res.data) {
        if (isListCollapsed) {
          this.fetchDashboardInsIdeList = _.orderBy(JSON.parse(res.data), (x: any) => x.date, 'desc');
          this.totalCount = this.fetchDashboardInsIdeList[0]?.totalCount ? this.fetchDashboardInsIdeList[0].totalCount : 0;
        } else {
          this.fetchDashboardList = JSON.parse(res.data);
        }
      }
    });
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
  }

  changeDateFormatToApi(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd hh:MM:ss');
  }
  onPageChange(page: any, obj?): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    obj.isListCollapsed = true;
    this.fetchDashboard(true, obj, true);
  }

  pushBankAndInsurer(type, obj, count) {
    if (!count) {
      this.commonService.infoSnackBar('Already Data Pushed');
      return;
    }

    const startDate = this.changeDateFormate(new Date(this.fromDate));
    const endDate = this.changeDateFormate(new Date(this.toDate));
    const data = {
      schemeId: this.schemeId ? this.schemeId : undefined,
      orgId: obj.orgId ? obj.orgId : undefined,
      userType: this.userType ? this.userType : undefined,
      fromDate: startDate ? startDate : undefined,
      toDate: endDate ? endDate : undefined,
      type: type ? type : undefined,
      isSchedular: false
    };
    // console.log('data: ', data);
    this.adminService.pushBankAndInsurer(data).subscribe(res => {
      if (res) {
        this.commonService.successSnackBar(res.message);
      }
    });
  }

  changeDateFormate(tempDate: Date) {
    return "" + (tempDate.getFullYear()) + "-" + ('0' + (tempDate.getMonth() + 1)).slice(-2) + "-" + ('0' + tempDate.getDate()).slice(-2) + " " + ('0' + tempDate.getHours()).slice(-2) + ":" + ('0' + tempDate.getMinutes()).slice(-2) + ":" + ('0' + tempDate.getSeconds()).slice(-2);
  }

  // convertDate(tempDate: Date, isStart) {
  //   console.log('tempDate: ', tempDate);
  //   if (isStart) {
  //     return "" + (tempDate.getFullYear()) + "-" + ('0' + (tempDate.getMonth() + 1)).slice(-2) + "-" + ('0' + tempDate.getDate()).slice(-2) + " 00:00:00";
  //   } else {
  //     return "" + (tempDate.getFullYear()) + "-" + ('0' + (tempDate.getMonth() + 1)).slice(-2) + "-" + ('0' + tempDate.getDate()).slice(-2) + " 23:59:59";
  //   }
  // }

}
