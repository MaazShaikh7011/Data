import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { AdminPanelRoutingModule } from './admin-panel-routing.module';

import { EncryptDecryptComponent } from './encrypt-decrypt/encrypt-decrypt.component';
import { BranchListComponent } from './branch-list/branch-list.component';
import { CreateBranchComponent } from './create-branch/create-branch.component';
import { BankUserListComponent } from './bank-user-list/bank-user-list.component';
import { CreateNewUserComponent } from './create-new-user/create-new-user.component';
import { OrganizationListComponent } from './organization-list/organization-list.component';
import { BankApiUserComponent } from './bank-api-user/bank-api-user.component';
import { CreateNewBankApiUserComponent } from './create-new-bank-api-user/create-new-bank-api-user.component';
import { CustomerRecoredListComponent } from './customer-recored-list/customer-recored-list.component';
import { BankApiAuditDetailsLogComponent } from './bank-api-audit-details-log/bank-api-audit-details-log.component';
import { PublishApiAuditDetailsLogComponent } from './publish-api-audit-details-log/publish-api-audit-details-log.component';
import { OtherChannelApiAuditDetailsLogComponent } from './other-channel-api-audit-details-log/other-channel-api-audit-details-log.component';
import { AdminManagementComponent } from './admin-management/admin-management.component';
import { AddAdminUserComponent } from './add-admin-user/add-admin-user.component';
import { APAdminUserListComponent } from './ap-admin-user-list/ap-admin-user-list.component';
import { JNSInsurerDetailsComponent } from './insurer-details/jns-insurer-details.component';
import { ApplicationClaimAuditComponent } from './application-claim-audit/application-claim-audit.component';
import { AddConfigMasterComponent } from './add-config-master/add-config-master.component';
import { ApplicationStatusMasterComponent } from './application-status-master/application-status-master.component';
import { ClaimStatusMasterComponent } from './claim-status-master/claim-status-master.component';
import { ConfigMasterComponent } from './config-master/config-master.component';
import { DmsMasterComponent } from './dms-master/dms-master.component';
import { NotificationCountComponent } from './notification-count/notification-count.component';
import { PremiumMasterComponent } from './premium-master/premium-master.component';
import { BankwiseApplicationCountComponent } from './bankwise-application-count/bankwise-application-count.component';
import { BankWiseclaimCountComponent } from './bank-wiseclaim-count/bank-wiseclaim-count.component';
import { InsurerCountComponent } from './insurer-count/insurer-count.component';
import { ClaimApiAuditLogComponent } from './claim-api-audit-log/claim-api-audit-log.component';
import { PythonAuditComponent } from './python-audit/python-audit.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { EnrollmentApiAuditDetailsLogComponent } from './enrollment-api-audit-details-log/enrollment-api-audit-details-log.component';
import { SubLoderComponent } from 'src/app/CommoUtils/Common-Component/sub-loder/sub-loder.component';
import { PushCoiCountsComponent } from './push-coi-counts/push-coi-counts/push-coi-counts.component';
import { EncryptDecryptBankAndInsurerDataComponent } from './encrypt-decrypt-bank-and-insurer-data/encrypt-decrypt-bank-and-insurer-data.component';
import { BucketAuditDetailsComponent } from './bucket-audit-details/bucket-audit-details.component';
import { NotificationListComponent } from './notification-list/notification-list.component';
import { BankInsurerCountComponent } from './bank-insurer-count/bank-insurer-count.component';
import { JNSSupportDashboardComponent } from './jns-support-dashboard/jns-support-dashboard.component';
import { CityWiseReportComponent } from './city-wise-report/city-wise-report.component';
import { CityWisePolicyReportComponent } from './city-wise-policy-report/city-wise-policy-report.component';
import { WebhookApiAuditDetailsLogComponent } from './webhook-api-audit-details-log/webhook-api-audit-details-log.component';
import { PostmanClientCallComponent } from './postman-client-call/postman-client-call.component';
import { JsnsurakshaApiCallComponent } from './jsnsuraksha-api-call/jsnsuraksha-api-call.component';
import { ClaimReportComponent } from './claim-report/claim-report.component';
import { PushFailDashboardComponent } from './push-fail-dashboard/push-fail-dashboard.component';
import { RegenerateReportComponent } from './regenerate-report/regenerate-report.component';



@NgModule({
  declarations: [

    AdminDashboardComponent,

    EncryptDecryptComponent,
    BranchListComponent,
    CreateBranchComponent,
    BankUserListComponent,
    CreateNewUserComponent,
    OrganizationListComponent,
    BankApiUserComponent,
    CreateNewBankApiUserComponent,
    CustomerRecoredListComponent,

    BankApiAuditDetailsLogComponent,
    PublishApiAuditDetailsLogComponent,
    OtherChannelApiAuditDetailsLogComponent,
    APAdminUserListComponent,
    PythonAuditComponent,
    AddAdminUserComponent,
    AdminManagementComponent,
    JNSInsurerDetailsComponent,

    ApplicationClaimAuditComponent,
    ApplicationStatusMasterComponent,
    ClaimStatusMasterComponent,
    ConfigMasterComponent,
    DmsMasterComponent,
    PremiumMasterComponent,
    AddConfigMasterComponent,
    NotificationCountComponent,

    BankwiseApplicationCountComponent,
    BankWiseclaimCountComponent,
    InsurerCountComponent,
    ClaimApiAuditLogComponent,
    EnrollmentApiAuditDetailsLogComponent,
    SubLoderComponent,
    PushCoiCountsComponent,
    EncryptDecryptBankAndInsurerDataComponent,
    BucketAuditDetailsComponent,
    NotificationListComponent,
    BankInsurerCountComponent,
    JNSSupportDashboardComponent,
    CityWiseReportComponent,
    CityWisePolicyReportComponent,
    // WebhookApiAuditDetailsLogComponent,
    PostmanClientCallComponent,
    JsnsurakshaApiCallComponent,
    ClaimReportComponent,
    JsnsurakshaApiCallComponent,
    PushFailDashboardComponent,
    RegenerateReportComponent


  ],
  imports: [
    CommonModule,
    AdminPanelRoutingModule,
    SharedModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AdminPanelModule { }
