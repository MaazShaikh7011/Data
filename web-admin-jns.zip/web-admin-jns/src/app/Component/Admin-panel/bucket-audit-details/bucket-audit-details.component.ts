import { KeyValue } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
@Component({
  selector: 'app-bucket-audit-details',
  templateUrl: './bucket-audit-details.component.html',
  styleUrls: ['./bucket-audit-details.component.scss']
})
export class BucketAuditDetailsComponent implements OnInit {

  contextPath;
  bucketList: any;
  reqUrlList;
  referenceId;
  originalOrder: any;

  constructor(private adminService: AdminPanelServiceService, private commonService: CommonService) {
    this.reqUrlList = Constants.ReqUrlList;
  }

  ngOnInit(): void {
    this.originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
      return 0;
    }
  }

  clearFilter() {
    this.contextPath = undefined;
    this.referenceId = undefined;
    this.bucketList = undefined;
  }
  
  getBucketLogDetails() {
    this.bucketList = undefined;
    if (this.commonService.isObjectNullOrEmpty(this.contextPath)) {
      this.commonService.warningSnackBar("Please select any One");
      return;
    }
    if (this.commonService.isObjectNullOrEmpty(this.referenceId)) {
      this.commonService.warningSnackBar("Please Enter ReferenceId");
      return;
    }
    this.adminService.getBucketLogDetails(this.contextPath, this.referenceId).subscribe(res => {
      if (res) {
        this.bucketList = res;
      } else {
        this.commonService.warningSnackBar("Not Found")
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

}
