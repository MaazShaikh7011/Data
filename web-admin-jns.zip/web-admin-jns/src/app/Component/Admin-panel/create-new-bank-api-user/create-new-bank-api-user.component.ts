import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-create-new-bank-api-user',
  templateUrl: './create-new-bank-api-user.component.html',
  styleUrls: ['./create-new-bank-api-user.component.scss']
})
export class CreateNewBankApiUserComponent implements OnInit {
  @ViewChild('createApiUser') createApiUser: NgForm;

  apiKey;
  userName;
  ips;
  publicKey;
  privateKey;
  headerConfig;
  urlConfig;
  timeOutConfig;
  // serviceapikey;
  configType;
  listApiUsers;
  orgList;
  orgId;
  orgName;
  id;
  submitted = false;
  response;
  type;
  constructor(private adminService: AdminPanelServiceService, private commonService: CommonService, private router: Router) { 
    this.id = this.commonService.getURLData('id');
    this.type=this.commonService.getURLData('type')
  }

  ngOnInit(): void {
    if (this.id != null) {
      this.getApiUserList(this.id);
    }

    this.getMasterList();
    this.getOrgMasterListByApimasterId();
  }

  getApiUserList(id) {
    this.adminService.getApiUserList(id).subscribe(res => {
      if (res && res.status == 200) {
        this.response = res.data;
        this.configType = this.response.configType;
        // this.serviceapikey = this.response.serviceapikey;
        this.orgId = this.response.orgId;
        this.orgName = this.response.orgName;
        this.apiKey = this.response.apiKey;
        this.userName = this.response.userName;
        this.ips = this.response.ips;
        this.publicKey = this.response.publicKey;
        this.privateKey = this.response.privateKey;
        this.headerConfig = this.response.headerConfig;
        this.urlConfig = this.response.urlConfig;
        this.timeOutConfig = this.response.timeOutConfig;
      }
    });

  }
  saveApiUser() {
    const obj = {
      id: this.id ? this.id : undefined,
      configType: this.configType ? this.configType : undefined,
      orgName: _.find(this.orgList, (x: any) => x.orgId == this.orgId).displayOrgName,
      orgId: this.orgId ? this.orgId : undefined,
      apiKey: this.apiKey ? this.apiKey : undefined,
      userName: this.userName ? this.userName : undefined,
      ips: this.ips ? this.ips : undefined,
      publicKey: this.publicKey ? this.publicKey : undefined,
      privateKey: this.privateKey ? this.privateKey : undefined,
      headerConfig: this.headerConfig ? this.headerConfig : undefined,
      urlConfig: this.urlConfig ? this.urlConfig : undefined,
      timeOutConfig : this.timeOutConfig ? this.timeOutConfig : undefined
    }
    this.adminService.saveApiUser(obj).subscribe(res => {
      if (res && res.data) {
        this.commonService.successSnackBar(res.message);
        this.router.navigate(['/Admin/bank-api-user'])
      }
    })
  }

  getMasterList() {
    const masterObj = ['API_MASTER'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.listApiUsers = res.data.API_MASTER;
        // console.log("listApiUsers", this.listApiUsers)
      }
    })
  }
  getOrgMasterListByApimasterId() {
    this.adminService.getOrgMasterListByApimasterId().subscribe(res => {
      if (res && res.status == 200) {
        this.orgList = res.data;
      }
    })
  }

}
