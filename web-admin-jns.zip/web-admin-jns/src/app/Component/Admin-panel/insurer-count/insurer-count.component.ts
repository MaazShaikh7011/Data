import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import alasql from 'alasql';
import { objectEach } from 'highcharts';
import * as _ from 'lodash';
import { element } from 'protractor';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-insurer-count',
  templateUrl: './insurer-count.component.html',
  styleUrls: ['./insurer-count.component.scss']
})
export class InsurerCountComponent implements OnInit {

  fromDate;
  toDate;
  dataList: any = [];
  orgId;
  bankList :any =[];
  bankMasterList :any =[];
  schemeMasterList;
  schemeId;
  typeId: any;
  searchType: any;
  sourceList;
  source;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService :AdminPanelServiceService,private commonMethod: CommonMethods) { 
// this.schemeId = commonService.getStorage(Constants.httpAndCookies.SCHEME_ID, true);
// this.orgId = commonService.getStorage(Constants.httpAndCookies.ORGID, true);
      const tempDate = new Date();
      this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear());
      this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+(tempDate.getDate()+1)+"/"+tempDate.getFullYear());
}

  ngOnInit(): void {
    this.searchType = [
      { id: 1, value: 'Enrollment' },
      { id: 2, value: 'Claim' },
    ];
    this.getCommonList(6);
    this.getAllScheme();
    this.getMasterList();
    // this.fetchData();
  }
  
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }
  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }
  
  getMasterList() {
    const masterObj = ['SOURCE'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.sourceList = res.data.SOURCE;
      }
    })
  }
  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.schemeId = undefined;
    this.source =undefined;
    this.fetchData();
  }
fetchData(isDwnld?){
  const filterJSON = {
    typeId:this.typeId,
    orgId:this.orgId,
    schemeId:this.schemeId,
    fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
    toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined ,
    // toDate: this.toDate ? this.changeDateFormat1(this.toDate) : undefined  
    source : this.source? this.source : undefined
  }
  if (this.typeId!=null || this.typeId != undefined) {
     this.adminService.getAllInsurerCount(filterJSON).subscribe(res => {
    
    if (res && !_.isEmpty(res.data)) {

      if(this.typeId ==1 ){
        this.dataList = res.data;
      }else{
        this.dataList = JSON.parse(res.data);
      }
      this.dataList = _.orderBy(this.dataList, [x => x.totalCount ? x.totalCount : 0], ['desc']);
      // if (this.orgId!=null ) {
      //     this.dataList = JSON.parse(res.data);
      // }
      // if (this.orgId==null ) {
      //       this.dataList = res.data;
      //       if(filterJSON.typeId==1){
      //         this.dataList = this.dataList.filter(obj => obj.sendBackToBankCount==null);
      //       }
      //       if(filterJSON.typeId==2){
      //         this.dataList =  this.dataList.filter(obj => obj.sendBackToBankCount!=null);
      //       }
            
      // }
    } else {
      this.dataList = [];
    }
    if(isDwnld==true){
      this.dataList = _.filter(this.dataList, (x:any)=> x.totalCount != 0)
      this.downloadDataInExcel(this.dataList);
      }

  });
  }else{
    this.commonMethod.warningSnackBar('please select atleast one type');
  }
}
changeDateFormat(date) {
  // let startDate=new Date(date);
  // startDate.setHours(0);
  // startDate.setMinutes(0);
  // startDate.setSeconds(0);
  // return this.datePipe.transform(startDate, 'dd-MM-yyyy HH:mm:ss');
  return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
}
changeDateFormat1(date) {
  let startDate=new Date(date);
  startDate.setHours(23);
  startDate.setMinutes(59);
  startDate.setSeconds(59);
  return this.datePipe.transform(startDate, 'dd-MM-yyyy HH:mm:ss');
}

downloadDataInExcel(excelData) {
  let downloadData = [];
  const fileName = 'InsurerCount List' + '.xlsx';
  excelData.forEach((element, i) => {
    const index = i + 1;
    var allApplications = null;
    
    if(this.typeId==1){
             allApplications = [{
               Sr_no: index,
              //  'organisation Id': element.orgId,
              //  'Scheme': element.scheme,
               'organisation Name': element.name,
              //  'channelId': element.channelId,
               'totalCount': element.totalCount,
               'CompletedCount': element.completedCount,
               'RejectedCount': element.rejectedCount,
               'ExpiredCount': element.expiredCount,
              }];
            }   
           else if(this.typeId==2){
             allApplications = [{
               Sr_no: index,
              //  'organisation Id': element.orgId,
              //  'Scheme': element.scheme,
               'organisation Name': element.name,
              //  'channelId': element.channelId,
               'totalCount': element.totalCount,
               'AccpetedCount': element.accpetedCount,
               'OnHoldCount': element.onHoldCount,
               'RejectedCount': element.rejectedCount,
               'SendBackToBankCount': element.sendBackToBankCount,
              }];
            }  
    downloadData = downloadData.concat(allApplications);
  });
  alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
}
dateFormateForExcel(date) {
  return this.datePipe.transform(date, 'yyyy-MM-dd');
}


}
