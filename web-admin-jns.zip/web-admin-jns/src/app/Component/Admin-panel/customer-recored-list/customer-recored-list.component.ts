import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { Constitutioncharttables, StateDatas } from 'src/app/CommoUtils/common-services/Product-Scoring-Data/customers.model';
import { Constitutioncharttable, StateData } from 'src/app/CommoUtils/common-services/Product-Scoring-Data/dataCustomer';
import { ChartType } from 'src/app/CommoUtils/common-services/apex.model';
import { lineColumAreaChart, NA_AR_NP_PieChartFIC, NA_AR_NP_PieChartSC } from 'src/app/CommoUtils/common-services/data';
import { Observable } from 'rxjs';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { DatePipe, KeyValue } from '@angular/common';
import alasql from 'alasql';
import * as _ from 'lodash';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { element } from 'protractor';
import { ClaimDownloadDocumentsComponent } from 'src/app/Popup/claim-download-documents/claim-download-documents.component';
import { MatDialog as MatDialog } from '@angular/material/dialog';


@Component({
  selector: 'app-customer-recored-list',
  templateUrl: './customer-recored-list.component.html',
  styleUrls: ['./customer-recored-list.component.scss']
})
export class CustomerRecoredListComponent implements OnInit {
  LODASH = _;
  preKycId3: boolean = false
  accountNumber: any;
  applicationCode: any
  dateFormate = Constants.dateFormat.DDMMYYYY;
  dataList: any = [];
  stateValue: any
  isMenuOpened: boolean = false;
  schemeId;
  orgId;
  claimId: any;
  totalCount = 0;
  counter = 0;
  tab: any;
  isActive = false;
  // bread crumb items
  breadCrumbItems: Array<{}>;

  selectValue: string[];
  fetchedClaimViewData: any;
  acceptBtnFlag: Boolean = false;
  rejectBtnFlag: Boolean = false;
  sendBackBtnFlag: Boolean = false;

  // Collapse declare
  isCollapsed: boolean = false;
  isCollapsed1: boolean = true;
  isListCollapsed: boolean = true;
  isMstListCollapsed: boolean = true;
  // page number
  page = 1;
  pageEligible = 1;
  // default page size
  pageSize = 10;
  pageEligibleSize = 5;

  // start and end index
  startIndex = 0;
  startEligibleIndex = 1;
  endIndex = 10;
  endEligibleIndex = 5;
  totalSize = 0;
  claimMaster = Constants.ClaimMaster;
  totalRecords: any;
  PageSelectNumber!: string[];
  PageEligibleSelectNumber!: string[];
  total$!: Observable<number>;
  // date Picker For to
  // Component DatePicker colorpicker
  componentcolor: string;

  // hoveredDate: NgbDate;
  // fromNGDate: NgbDate;
  // toNGDate: NgbDate;
  bankList: any = [];
  bankMasterList: any = [];
  schemeMasterList: any = [];
  hidden: boolean;
  selected: any;
  color: string;
  @Input() fromDate: Date;
  @Input() toDate: Date;
  @Output() dateRangeSelected: EventEmitter<{}> = new EventEmitter();
  @ViewChild('dp', { static: true }) datePicker: any;

  Constitutioncharttable: Constitutioncharttables[];
  StateData: StateDatas[];
  lineColumAreaChart: ChartType;
  NA_AR_NP_PieChartSC: ChartType;
  NA_AR_NP_PieChartFIC: ChartType;

  submitted: boolean;

  popUpObj: any = [];
  dataList1: any
  proposalId: any;
  schemeTypeId: any;
  applicationId: any;
  customerRecordList: any;
  customerDetails: any;
  customerDetails1: any;
  customerDetMaster: any;
  customerpublishedDetils: any;
  customerpublishedDetils1: any;
  searchType: any;
  zoResponse: any = {};
  lhoResponse: any = {};
  searchData;
  data;
  pageNumber: any
  documentList
  // typeId = 1;
  typeId;
  id: any;
  eligibleAndInEligibleDetailsList: any;
  pageViewEligibleAndInEligibleDetailsList: any;
  eligibilityCalculationsDetails: any;
  rowDataPagination: any = [];
  rowDataEligiblePagination: any = [];
  totalData: any;
  originalOrder: any;
  totalEligibleData: any;
  userPersonalDetails;
  dataPublishList1: any = [];
  dataPublishList: any = [];
  documentListApp : any =[];
  documentListCliamRef:any =[];
  reqData: any = {
    toDate: new Date(), fromDate: new Date(), businessTypeId: null,
    noPagination: null, paginationFROM: null, paginationTO: null
  };
  adminPermissionList: any = [];

  constructor(private commonService: CommonService,
    private commonMethod: CommonMethods,
    private commonMethods: CommonMethods,
    public dialog: MatDialog,
    private adminService: AdminPanelServiceService) {
    this.claimId = +commonService.getURLData('claimId');
    this.schemeId = commonService.getStorage(Constants.httpAndCookies.SCHEME_ID, true);
  }

  proposalData: any = [];
  searchMachesApplication;
  searchList: any = [];
  isSearch: boolean = false;
  onFirstDataRendered(params) {
    params.api.forEachNode(function (node) {
      node.setExpanded(node.id === '1');
    });
  }

  ngOnInit(): void {
    // this.getUsernameAndApiKey();
    this.originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
      return 0;
    }
    this.applicationId = +this.commonService.getURLData('applicationId');
    // this.fetchData();
    // this.getCustomerDetailsList(this.id);
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'Reports', path: '/', active: true }];
    this.selectValue = ['Working Capital Term Loan', 'Working Capital Term Loan', 'Term Loan'];
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.PageEligibleSelectNumber = ['5', '10', '25', '50', '100'];
    // date
    this.hidden = true;
    //this._fetchData();
    this.searchType = [
      { id: 1, value: 'URN' },
      // { id: 2, value: 'Account Number' },
      { id: 3, value: 'Application Id' },
    ];
    this.adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
    // this.getCustomerClaimDetailsList(null);
    this.getCommonList(2);
    this.getAllScheme();
}


  openPopUpMat(obj: any, popUpName: any, objClass?: any, disableClose?: boolean) {
    return this.dialog.open(popUpName, { panelClass: objClass, autoFocus: false, data: obj, disableClose: disableClose });
  }
  openDownloadPopUp() {
    this.openPopUpMat(this.applicationId, ClaimDownloadDocumentsComponent, ['w-900px'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        //this.downloadZipFile(data);
      }
    });
  }

  changeDateFormat(date) {
    //return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  clearFilter() {
    this.orgId = undefined;
    this.schemeId = undefined;
    this.typeId = undefined;
    this.searchData = undefined;
    this.fetchData();
    this.dataList = undefined;
    this.dataList1 = undefined;
    this.dataPublishList = undefined;
    this.dataPublishList1 = undefined;
  }


  fetchData(idDownload?) {
    if (this.commonService.isObjectNullOrEmpty(this.orgId)
      || this.commonService.isObjectNullOrEmpty(this.schemeId)
      || this.commonService.isObjectNullOrEmpty(this.typeId)) {
      this.commonService.warningSnackBar("Please select Bank ,scheme ,Type ");
      return;
    }
    if (this.commonService.isObjectNullOrEmpty(this.searchData)) {
      this.commonService.warningSnackBar("Please Search Data ");
      return;
    }
    const data = {
      //  typeId: this.typeId,
      //  searchData: this.searchData ? this.searchData : undefined,
      //  fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      //  toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      //  applicationCode: this.applicationCode ? this.applicationCode : undefined,
      //  accountNumber: this.accountNumber ? this.accountNumber : undefined,
      // pageType:1,//this.routingData.type,
      // schemeId: this.schemeId ? this.schemeId : undefined,
      // from: 0,//this.startIndex ? this.startIndex : 0,
      // to:10// idDownload ? this.totalCount : this.pageSize

      typeId: this.typeId,
      searchData: this.searchData ? this.searchData : undefined,
      orgId: this.orgId ? this.orgId : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      // paginationFROM: this.pageNumber ? this.pageNumber : this.startIndex,
      // paginationTO: idDownload ? this.totalCount : this.pageSize
    }
    this.adminService.spGetApplicationList(data).subscribe(res => {
        if (res && !_.isEmpty(res?.data) && res.status === 200) {
        this.dataList = JSON.parse(res.data);
        if(this.dataList.length > 1){
          this.dataList = [_.find(this.dataList, (x:any)=> x.customerAccountNumber)];
        }
        this.totalCount = this.dataList[0].totalCount || 0;

        this.dataList.forEach(element => {
          data.searchData=element.applicationId;
          this.adminService.fetchPublishedAppList(data).subscribe(res => {
            if (res?.data && res.status === 200) {
              this.dataPublishList = JSON.parse(res.data);
              this.totalCount = this.dataPublishList[0].totalCount || 0;
            }
          });
          this.adminService.spGetApplicationClaimList(data).subscribe(res => {
            if (res?.data && res.status === 200) {
              this.dataList1 = JSON.parse(res.data);
              this.totalCount = this.dataList1[0].totalCount || 0;
                this.adminService.fetchPublishedClaimList(data).subscribe(res => {
                  if (res?.data && res.status === 200) {
                    this.dataPublishList1 = JSON.parse(res.data);
                    this.totalCount = this.dataPublishList1[0].totalCount || 0;
                  }
                });
            }
          });
        });

      }else{
        this.commonService.warningSnackBar("No data Found");
        this.dataList = undefined;
        this.dataList1 = undefined;
        this.dataPublishList = undefined;
        this.dataPublishList1 = undefined;
      }
    });

  }


  // getCommonList(): void {
  //   const data = {
  //     applicationId: this.data
  //   }
  //   this.adminService.getCommonList('getUplodedDocumentList', JSON.stringify(data)).subscribe(res => {
  //     if (res?.data) {
  //       this.documentList = res?.data
  //     } else {
  //       this.commonService.warningSnackBar(res.message);
  //     }
  //   });
  // }
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }
  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }


  getPaginationData(): void {
    this.customerRecordList = this.rowDataPagination.slice(((this.page - 1) * this.pageSize), (this.page * this.pageSize));
    this.startIndex = ((this.page - 1) * this.pageSize) + 1;
    this.endIndex = (this.page * this.pageSize);
    if (this.totalData < this.endIndex) {
      this.endIndex = this.totalData;
    }
  }

  getEligiblityPaginationData(isCheck?): void {
    if (isCheck) {
      this.eligibleAndInEligibleDetailsList = this.searchList.slice(((this.pageEligible - 1) * this.pageEligibleSize), (this.pageEligible * this.pageEligibleSize));
    } else {
      this.eligibleAndInEligibleDetailsList = this.rowDataEligiblePagination.slice(((this.pageEligible - 1) * this.pageEligibleSize), (this.pageEligible * this.pageEligibleSize));
    }
    this.startEligibleIndex = ((this.pageEligible - 1) * this.pageEligibleSize) + 1;
    this.endEligibleIndex = (this.pageEligible * this.pageEligibleSize);
    if (this.totalEligibleData < this.endEligibleIndex) {
      this.endEligibleIndex = this.totalEligibleData;
    }
  }



  getCustomerDetailsList(data) {

    this.dataList.forEach(element => {
      if (element.id == data.id) {
        element.isListCollapsed == false;
      } else {
        element.isListCollapsed = false;
      }
    });
    this.adminService.getCustomerDetailsList(data.id).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerDetails = res.data;
        //this.getUserPersonalDetails(this.customerDetails.userId);
      }else{
        this.customerDetails = null;
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }

  getCustomerMasterDetailsList(data) {

    this.dataList.forEach(element => {
      if (element.id == data.id) {
        element.isMstListCollapsed == false;
      } else {
        element.isMstListCollapsed = false;
      }
    });

    this.adminService.getCustomerMasterDetailsList(data.id,this.schemeId).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerDetMaster = res.data;
        console.log(this.customerDetMaster)
        //this.getUserPersonalDetails(this.customerDetails.userId);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }


  getCustomerClaimDetailsList(data) {


    // const data = {
    //   claimId: this.claimId,
    // }
    this.dataList1.forEach(element => {
      if (element.id == data.id) {
        element.isListCollapsed == false;
      } else {
        element.isListCollapsed = false;
      }
    });
    this.adminService.getCustomerClaimDetailsList(data.applicationId, data.id).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerDetails1 = res.data;

        if (this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_ACCEPTED.id && this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_SEND_BACK_BY_INSURER.id) {
          this.acceptBtnFlag = true;
        }
        if (this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_ACCEPTED.id &&
          this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_REJECTED.id && this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_SEND_BACK_BY_INSURER.id) {
          this.rejectBtnFlag = true;
        }
        if (this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_ACCEPTED.id && this.customerDetails1?.claimStatus != this.claimMaster.CLAIM_SEND_BACK_BY_INSURER.id) {
          this.sendBackBtnFlag = true;
        }
          this.getDocumentListByAppId(data.applicationId, data.id);
        // this.getUserPersonalDetails(this.customerDetails.userId);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getPublishedAppFormDetails(data) {
    this.dataPublishList.forEach(element => {
      if (element.applicationReferenceId == data.applicationReferenceId) {
        element.isListCollapsed == false;
      } else {
        element.isListCollapsed = false;
      }
    });
    this.adminService.getPublishedAppFormDetails(data.applicationReferenceId).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerpublishedDetils = res.data;
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getPublishedclaimFormDetails(data) {
    this.dataPublishList1.forEach(element => {
      if (element.claimReferenceId == data.claimReferenceId) {
        element.isListCollapsed == false;
      } else {
        element.isListCollapsed = false;
      }
    });
    this.adminService.getPublishedclaimFormDetails(data.claimReferenceId).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.customerpublishedDetils1 = res.data;
        // console.log("customerpublishedDetils1", this.customerpublishedDetils1)
        this.getDocumentListByCliamRefId(data.claimReferenceId);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }



  getUserPersonalDetails(userId) {
    const data = {
      userId: userId,
    };
    this.adminService.getUserPersonalDetails(data).subscribe(res => {
      if (res && res.data != null) {
        this.userPersonalDetails = JSON.parse(res.data);

      }
    });
  }
  downloadCertificate(applicationData) {
    const data = {
      applicationId: applicationData.id,
      schemeId: applicationData.schemeId,
      orgId: +this.orgId,
      isDownload: true
    }
    this.adminService.getCertiInsData(data).subscribe(res => {
      if (res && res.data) {
        const fileName = "Certificate-of-insurance-" + applicationData.urn;
        this.commonMethods.downloadPdfFromBase64toFile(res.data, fileName);
      }
    }, error => {
      this.commonService.errorSnackBar(error);

    })
  }
  getDocumentListByAppId(applicationId,claimId){
    const data={
      applicationId: applicationId ? applicationId : undefined,
      claimId : claimId ? claimId : undefined
    }
    console.log(data)
    this.adminService.getDocumentListByAppId(data).subscribe(res=>{
      if (res && res.data) {
        this.documentListApp= JSON.parse(res.data);
        // console.log(this.documentListApp)
      }
    })
  }
  getDocumentListByCliamRefId(claimRefId){
    const data={
      claimRefId: claimRefId ? claimRefId : undefined,
    }
    this.adminService.getDocumentListByCliamRefId(data).subscribe(res=>{
      if (res && res.data) {
        this.documentListCliamRef= JSON.parse(res.data);
        // console.log(this.data.claimReferenceId)
      }
    })
  }
  //   downloadZipFile(data) {
  //     this.downloadZip(data.applicationId);
  //   }
  //   downloadZip(applicationId) {
  //     this.adminService.getDocumentZip({ applicationId }).subscribe(res => {
  //       const blob = new Blob([res], { type: 'application/octet-stream' });
  //       const a: any = document.createElement("a");
  //       document.body.appendChild(a);
  //       a.style = "display:none";
  //       var url = window.URL.createObjectURL(blob);
  //       a.href = url;
  //       a.download = applicationId + '_documents.zip';
  //       a.click();
  //       a.remove();
  //     });
  // }
  downloadZipFilePublish(data) {
  this.download(data.applicationId, data.claimReferenceId, data.urn);
  }

  download(applicationId, claimReferenceId, urn){
    const data ={
      claimReferenceId : claimReferenceId
    }
    this.adminService.downloadZipFilePublish(data).subscribe(res=>{
      const blob = new Blob([res], { type: 'application/octet-stream' });
      const a: any = document.createElement("a");
      document.body.appendChild(a);
      a.style = "display:none";
      var url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = urn + '_documents.zip';
      a.click();
      a.remove();
    })
  }
  downloadZipFile(data) {
    this.downloadZip(data.applicationId, data.id, data.urn);
  }
  downloadZip(applicationId, claimId, urn) {
    this.adminService.getDocumentZip({ applicationId, claimId, urn }).subscribe(res => {
      const blob = new Blob([res], { type: 'application/octet-stream' });
      const a: any = document.createElement("a");
      document.body.appendChild(a);
      a.style = "display:none";
      var url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = urn + '_documents.zip';
      a.click();
      a.remove();
    });
  }
  downloadFile(data){
    // if(!_.isEmpty(this.customerpublishedDetils.coi)){
    const fileName = "Certificate-of-insurance-" + data.urn;
    this.commonMethods.downloadPdfFromBase64toFile(this.customerpublishedDetils.coi.document, fileName);
  //  }else{
  //   }
}

}

