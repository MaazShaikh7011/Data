import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import alasql from 'alasql';
import * as _ from 'lodash';
import { result } from 'lodash';
import { parse } from 'path';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { ViewApplicationPopupComponent } from 'src/app/Popup/view-application-popup/view-application-popup.component';
import { ViewRozoDetailsPopupComponent } from 'src/app/Popup/view-rozo-details-popup/view-rozo-details-popup.component';

@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.scss'],
  providers: [DatePipe]
})
export class BranchListComponent implements OnInit {
  LODASH = _;
  breadCrumbItems: Array<{}>;
  page = 1;
  pageSize = 10;
  startIndex = 1;
  endIndex = 10;
  PageSelectNumber!: string[];
  searchValue;
  branchList;
  totalCount;
  debounceEventForFilter = _.debounce(() => this.getBranchList(false), 500, {});
  branchId;
  orgList: any = [];
  orgMasterList :any =[];
  schTypeId;
  orgId;
  branchTypeId;
  schemeList;
  branchTypeList: any = Constants.branchType;
  adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
  canCreate: boolean;
  searchType;
  searchTypeId;

  constructor(private adminService: AdminPanelServiceService,
    private commonMethods: CommonMethods,
    private commonService: CommonService,
    private datePipe: DatePipe,
    private router: Router,) { }

  ngOnInit(): void {
    this.breadCrumbItems = [{ label: 'Dashboard', path: '/' }, { label: 'User & Branch Management', path: '/', active: true }];
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.searchType = [
      { id: 1, value: 'Name' },
      { id: 3, value: 'Id' },
      { id: 2, value: 'Code' },
    ];
    this.getOrganizationList();
    this.getSchmeList();
    this.getBranchList();
    this.creteUserPermission();
  }
  creteUserPermission(){
    // console.log( this.commonService.getStorage("usr_role_id",true));
    let val =this.commonService.getStorage("usr_role_id",true);
    if(val==101 || val==102 || val==106){
      this.canCreate= true;
    }
  }
  
  clearSearchType(){
    this.searchValue = undefined;
  }
  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.getBranchList(true);
  }

  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }

  getBranchList(onPageChangeFlag?) {
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    const filterJSON = {
      searchTypeId: this.searchTypeId || undefined,
      searchValue: this.searchValue || undefined,
      orgId: this.orgId || undefined,
      schTypeId: this.schTypeId || undefined,
      branchTypeId: this.branchTypeId || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.getBranchList(data).subscribe(res => {
      this.branchList = [];
      if  (res && res.data) {
        this.branchList= JSON.parse(res.data);
        this.totalCount = res.data && res.data[0] && this.branchList[0].totalCount ? this.branchList[0].totalCount : 0;
      }
    });
  }

  getOrganizationList() {
    this.adminService.getOrganizationList().subscribe(res => {
      if (res && res.data) {
        this.orgList = res.data;
        this.orgMasterList = res.data;
        this.orgId = 13;
        this.schTypeId = 1;
        this.getBranchList();
      }
    });
  }

  isActiveBranch(branch) {
    if (!branch.totalProposalCount) {
      const data = {
        branchId: branch.branchId,
        schemeId: this.schTypeId
      }
      this.adminService.isActiveBranch(data).subscribe(res => {
        if (res && res.data) {
          this.getBranchList();
          this.commonService.successSnackBar("Successfully Done");
        }
      });
    } else {
      this.getBranchList(true);
      this.commonService.warningSnackBar("Please transfer All proposal Before in-active");
    }
  }

  copyToClipBoard(data) {
    this.commonMethods.copyToClipBoard(data);
  }

  redirectForEdit(branchId, branchTypeId, orgId) {
    this.router.navigate(['/Admin/create-branch'], { queryParams: { branchId: CommonService.encryptFuntion(branchId), branchTypeId: CommonService.encryptFuntion(branchTypeId), orgId: CommonService.encryptFuntion(orgId) } });
  }
  clearFilter(){
    this.searchTypeId =null;
    this.orgId = null;
    this.schTypeId = null;
    this.branchTypeId=null;
    this.searchValue=null;
    this.getBranchList(false);
  }

  viewApplication(branch) {
    if (branch.totalProposalCount > 0) {
      const config = {
        //windowClass: 'popup_NP_100',
        size: 'xl'
      };
      const data = {
        proposalDetails: JSON.parse(branch.proposalDetails),
        currentBranch: branch.currentBranch,
        orgId: branch.orgId,
        schTypeId: this.schTypeId,
        branchId: branch.branchId,
        businessTypeId: _.find(this.schemeList, (x: any) => x.id == this.schTypeId).businessId,
      }
      this.commonService.openPopUp(data, ViewApplicationPopupComponent, false, config).result.then(result => { }, (reason) => {

        if (reason !== 'cancel' && reason !== 1 && reason !== 0) {
          this.updateBranchId(reason)
        }
      });
    } else {
      this.commonService.warningSnackBar("No Proposal Found");
    }
  }

  viewROZODetails(branch, type) {
    if (!branch.branchRoId && type == 1) {
      this.commonService.warningSnackBar('Ro Details not Found');
      return;
    } else if (!branch.branchZoId && type == 2) {
      this.commonService.warningSnackBar('Zo Details not Found');
      return;
    }
    const config = {
      //windowClass: 'popup_NP_100',
      size: 'xl'
    };
    const data = {
      branchRoZoId: type == 1 ? branch.branchRoId : branch.branchZoId,
    }
    this.commonService.openPopUp(data, ViewRozoDetailsPopupComponent, false, config).result.then(result => { }, (reason) => { });
  }

  updateBranchId(data) {
    if (_.isEmpty(data.proposalIdsList)) {
      return;
    }
    // console.log("data  ==>  "+data)
    this.adminService.updateBranchIdForMultipleApplication(data).subscribe(success => {
      if (success?.status === 200) {
        this.commonService.infoSnackBar('Successfully Transfer Branch');
        this.getBranchList(false);
      } else {
        this.commonService.warningSnackBar(success.message);
      }
    });
  }


  downloadAll() {
    const filterJSON = {
      searchValue: this.searchValue || undefined,
      orgId: this.orgId || undefined,
      schTypeId: this.schTypeId || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: 0,
      paginationTO: this.totalCount,
    }
    this.adminService.getBranchList(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.downloadDataInExcel(res.data);
      } else {
        this.commonService.warningSnackBar("No records available.")
      }
    });
  }


  dateFormateForExcel(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  downloadDataInExcel(excelData) {
    let downloadData = [];
    const fileName = 'Branch List' + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = [{
        Sr_no: index,
        'Branch Name': element.branchName || '',
        'Branch Code': element.branchCode || '',
        'Organization Name': element.orgName || '',
        'Scheme Name': element.schemeName || '',
        'Created Date': element.createdOn ? this.dateFormateForExcel(element.createdOn) : '',
        'RO Name (Code)': element.roName || '',
        'ZO Name (Code)': element.zoName || '',
        'Total Proposal': element.totalProposalCount || '',
        'Is Active': element.isActive ? 'True' : 'False',
      }];
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }


  getSchmeList() {
    this.adminService.getSchmeListForAdmin().subscribe(res => {
      if (res && res.status == 200 && res.flag == true) {
        this.schemeList = _.filter(res.data , (x: any) => x.id != -1);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }


  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }
}
