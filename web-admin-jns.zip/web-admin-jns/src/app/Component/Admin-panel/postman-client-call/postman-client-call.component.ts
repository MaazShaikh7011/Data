import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
@Component({
  selector: 'app-postman-client-call',
  templateUrl: './postman-client-call.component.html',
  styleUrls: ['./postman-client-call.component.scss'],
})
export class PostmanClientCallComponent implements OnInit {
  @ViewChild('reqData') reqData: NgForm;
  orgList;
  orgMasterList;
  id;
  apiType;
  requestData;
  secretKey;
  convertedResponse: any;
  orgRes: any;
  insurerList;
  bankAPIList: any = [];
  insurerAPIList: any = [];
  bankInsurerRequest : any;
  bankUserTypeList;
  userTypeId;
  apiName;
  orgId;
  apiId;
  contextPath;
  bucketList: any;
  referenceId;
  reqUrlList;

  constructor(
    private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private commonMethod: CommonMethods
  ) {
    this.reqUrlList = Constants.ReqUrlList;
  }

  ngOnInit(): void {
    // this.getOrgMasterListByApimasterId();
    this.getAllUserType();
  }

  getOrgMasterListByApimasterId() {
    this.adminService.getAllOrgList().subscribe((res) => {
      if (res && res.status == 200) {
        this.orgList = res.data;
        this.orgMasterList = res.data;
      }
    });
  }

  copyToClipBoard(data, isJson) {
    this.commonMethod.copyToClipBoard(data, isJson);
  }

  getCommonList(id) {
    // this.orgId = null;
    this.apiId = null;
    this.requestData = null;
    this.convertedResponse = null;
    this.bucketList = null;
    this.adminService
      .getCommonList('getOrgListByTypeId', id)
      .subscribe((res) => {
        if (res && res.data) {
          this.orgList = JSON.parse(res.data);
          this.orgMasterList = JSON.parse(res.data);
        }
      });
  }

  clearFilter() {
    this.orgList = [];
    this.orgMasterList = [];
    this.bankAPIList = [];
    this.insurerAPIList = [];
    this.bucketList =[];
  }

  getBankUserList() {
    this.orgId = null;
    this.apiId = null;
    this.requestData = null;
    this.convertedResponse = null;
    this.bucketList = null;
    if (this.userTypeId == 2) {
      this.getCommonList(2);
      this.getBankApiList();
    } else if (this.userTypeId == 6) {
      this.getCommonList(6);
      this.getInsurerApiList();
    }
  }

  getAllUserType() {
    this.adminService.getAllUserType().subscribe((res) => {
      if (res && res.data) {
        this.bankUserTypeList = res.data;
      }
    });
  }

  getBankApiList() {
    const masterObj = ['BANKS_API_LIST'];
    this.adminService.getMasterListByKey(masterObj).subscribe((res) => {
      if (res && res.status == 200 && res.data) {
        this.bankAPIList = res.data.BANKS_API_LIST;
        // console.log(this.bankAPIList)
      }
    });
  }

  getInsurerApiList() {
    const masterObj = ['INSURER_API_LIST'];
    this.adminService.getMasterListByKey(masterObj).subscribe((res) => {
      if (res && res.status == 200 && res.data) {
        this.insurerAPIList = res.data.INSURER_API_LIST;
        // console.log(this.insurerAPIList)
      }
    });
  }
  fetchBankWebhookRequest(apiId){
    this.requestData = null;
    this.convertedResponse = null;
    this.bucketList = null;
    const req={
      apiId : apiId ? apiId : undefined,
      orgId: this.orgId ? this.orgId : undefined,
      userTypeId : this.userTypeId ? this.userTypeId : undefined
    }
    this.adminService.fetchBankWebhookRequest(req).subscribe((res) => {
      if (res && res.data) {
        this.requestData =  JSON.stringify(res.data, undefined, 2);
        // console.log(this.requestData)
      }
    });
  }
  convertData() {
    if(this.userTypeId == null ){
      this.commonService.warningSnackBar('Please Select User Type');
      return;
    }

    if(this.orgId == null ){
      this.commonService.warningSnackBar('Please Select Organisation');
      return;
    }

    if(this.apiId == null ){
      this.commonService.warningSnackBar('Please Select Any Api');
      return;
    }

    if (!this.reqData.valid) {
      this.commonService.warningSnackBar('Please fill required fields');
      return;
    }

    const obj = {
      userTypeId: this.userTypeId? this.userTypeId : undefined,
      orgId: this.orgId?this.orgId : undefined,
      apiId: this.apiId ? this.apiId : undefined,
      request: this.requestData ? JSON.stringify(JSON.parse(this.requestData)) : undefined,
    }
    // console.log("requestData : ",obj)
    this.adminService.fetchPostmanResponse(obj).subscribe((res) => {
      if (res && res.data) {
        this.convertedResponse = JSON.stringify(res.data);
        // if(res.data.token){
            this.referenceId = res.data.token;
        // }
        // this.commonService.successSnackBar(res.message);
      } else {
        this.convertedResponse = undefined;
        this.commonService.errorSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  getBucketLogDetails() {
    // console.log(this.reqUrlList)
    if (!this.convertedResponse) {
      this.commonService.warningSnackBar('Please fill required fields');
      return;
    }
    if(this.userTypeId == 2 && [1,2,3,4,5,7,8].includes(this.apiId)){
      this.contextPath ='bankapi';
    }else{
      this.contextPath = 'api/registry';
    }
    this.adminService.getBucketLogDetails(this.contextPath, this.referenceId).subscribe(res => {
      if (res) {
        this.bucketList = res;
      } else {
        this.commonService.warningSnackBar("Not Found")
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }
 jsonFormatData(){
  this.requestData =  JSON.stringify(JSON.parse(this.requestData), undefined, 2);
 }
}
