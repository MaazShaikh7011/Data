import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import alasql from 'alasql';
@Component({
  selector: 'app-bank-insurer-count',
  templateUrl: './bank-insurer-count.component.html',
  styleUrls: ['./bank-insurer-count.component.scss']
})
export class BankInsurerCountComponent implements OnInit {

  typeList;
  typeId;
  insrureDataList;
  fromDate;
  toDate;
  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private adminService: AdminPanelServiceService,
    private datePipe: DatePipe,
    private commonService: CommonService,) { 
      const tempDate = new Date();
      this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 00:00:00");
      this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 11:59:59 PM");
    }

  ngOnInit(): void {
    this.typeList = [
      { id: 1, value: 'Insurance' },
      { id: 2, value: 'Publish' },
    ];
  }
  clearFilter() {
    this.typeId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.insrureDataList = undefined;

  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
  }
  fetchOrgAndInsuranceWiseCount(isDwnld?) {
    if (this.commonService.isObjectNullOrEmpty(this.typeId)) {
      this.commonService.warningSnackBar("Please select any One ");
      return;
    }
    const data = {
      typeId: this.typeId ? this.typeId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
    }
    this.adminService.fetchOrgAndInsuranceWiseCount(data).subscribe(res => {
      if (res && res.data) {
        this.insrureDataList = res.data;
        if(isDwnld==true){
          this.downloadDataInExcel(this.insrureDataList);
          }
      }
      else {
        this.insrureDataList = [];
        this.commonService.warningSnackBar("No Data Found");
      }
    });
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    const fileName = 'Bank-Wise Insurance Count'+this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa') + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
        allApplications = [{
          Sr_no: index,
          'DB Name': element.dbName,
          'org Name': element.orgName,
          'Scheme Name ': element.schemeName,
          'Insurer Name ': element.insName,
          'Total Count': element.totalCount,
        }];
      
      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }


}


