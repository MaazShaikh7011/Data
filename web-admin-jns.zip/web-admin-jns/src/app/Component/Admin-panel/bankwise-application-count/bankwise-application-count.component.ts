import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-bankwise-application-count',
  templateUrl: './bankwise-application-count.component.html',
  styleUrls: ['./bankwise-application-count.component.scss']
})
export class BankwiseApplicationCountComponent implements OnInit {
  LODASH = _;
  bankWiseAppList : any =[];
  orgId;
  bankList :any =[];
  bankMasterList :any =[];
  schemeMasterList;
  schemeId;
  isListCollapsed: boolean = true;
  orgIdwiseCountList
  countFlag: boolean = false;
  completedCnt: any =0;
  transactionFailedCnt : any =0;
  applicationFormCnt : any =0;
  rejectedCnt : any =0;
  expiredCnt : any =0;
  totalCnt: any =0;
  sourceList;

  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  fromDate;
  toDate;
  source;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService, private commonService: CommonService) { 
    const tempDate = new Date();
    this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 00:00:00 AM");
    this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 11:59:59 PM");
  }

  ngOnInit(): void {
    // const date = { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() };
    // this.fromDate = (date.year + '-' + (date.month.toString().length == 1 ? '0' : '') + date.month + '-' + (date.day.toString().length == 1 ? '0' : '') + date.day);
    // this.toDate = new Date();
    this.getCommonList(2);
    this.getAllScheme();
    this.getMasterList();
    this.fetchAppBankWiseCount();
  }

  clearFilter() {
    this.orgId = undefined;
    this.schemeId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.source = undefined;
    this.fetchAppBankWiseCount();
  }

  changeDateFormat(date) {
    return this.datePipe.transform(date,'dd-MMM-yyyy hh:mm:ss a');
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data);
      }
    });
  }

  getMasterList() {
    const masterObj = ['SOURCE'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.sourceList = res.data.SOURCE;
      }
    })
  }
  fetchAppBankWiseCount(isDwnld?) {
    const data = {
      orgId: this.orgId ? this.orgId : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      source : this.source? this.source : undefined
    }
    this.completedCnt=0;
    this.transactionFailedCnt = 0;
    this.applicationFormCnt = 0;
    this.rejectedCnt = 0;
    this.expiredCnt = 0;
    this.totalCnt= 0;
    this.adminService.fetchAppBankWiseCount(data).subscribe(res=>{
      if(res && res.data){
        this.bankWiseAppList = res.data;
        this.bankWiseAppList = _.orderBy(this.bankWiseAppList, [x => x.totalCount ? x.totalCount : 0], ['desc']);
        this.bankWiseAppList = _.filter(this.bankWiseAppList, (x:any)=> x.orgId != 0);
        if(this.orgId){
          this.bankWiseAppList = _.filter(this.bankWiseAppList, (x:any)=> x.orgId == this.orgId);
        }
        if(this.orgId != null || this.schemeId !=null){
          this.bankWiseAppList=  _.filter(this.bankWiseAppList, (x) => x.orgId > 0)
          this.countFlag = false;
        }else{
          this.countFlag = true;
          for (let i = 0; i < this.bankWiseAppList.length; i++) {
            this.completedCnt += Number(this.bankWiseAppList[i].completedCount ?  this.bankWiseAppList[i].completedCount : 0 )
            this.transactionFailedCnt += Number(this.bankWiseAppList[i].transactionFailedCount ?  this.bankWiseAppList[i].transactionFailedCount : 0 )
            this.applicationFormCnt += Number(this.bankWiseAppList[i].applicationForm ?  this.bankWiseAppList[i].applicationForm : 0 )
            this.rejectedCnt += Number(this.bankWiseAppList[i].rejectedCount ?  this.bankWiseAppList[i].rejectedCount : 0 )
            this.expiredCnt += Number(this.bankWiseAppList[i].expiredCount ?  this.bankWiseAppList[i].expiredCount : 0 )
            this.totalCnt += Number(this.bankWiseAppList[i].totalCount ?  this.bankWiseAppList[i].totalCount : 0 )
          }
        }
        }
 
      if(isDwnld==true){
        this.downloadDataInExcel(this.bankWiseAppList);
        }
    })
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    // const fileName = 'Bank-Wise Enrollment Count ' + this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa') + '.xlsx';
    const fileName = 'Bank-Wise Enrollment Count ' + this.getTodayDate() + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
      allApplications = [{
        Sr_no: index,
        'org Name': element.orgName ?  element.orgName : '-' ,
        'Total Count': element.totalCount ? element.totalCount : 0,
        'Completed Count': element.completedCount ? element.completedCount : 0,
        'Rejected Count': element.rejectedCount ? element.rejectedCount :0,
        'Expired Count': element.expiredCount ? element.expiredCount :0,
        'Trasaction Failed Count': element.transactionFailedCount ? element.transactionFailedCount :0,
      }];

      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }
  dateFormateForExcel(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  getTodayDate(){
    let day = new Date().getDate();
    let month = new Date().getMonth()+1;
    let date = (day<10 ? (0+day.toString()) : day) + '-' + (month<10 ? (0+month.toString()) : month) + '-' + new Date().getFullYear();
    return date;
  }

  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
      }
    });
  }

  fetchAppOrgIdwiseCount(orgId, isListCollapsed) {
    if (!isListCollapsed) {
      return;
    }
    this.orgIdwiseCountList = [];
    this.bankWiseAppList.forEach(element => {
      element.isListCollapsed = element.orgId == orgId ? true : false;
    });
    const data = {
      orgId: orgId ? orgId : undefined,
      schemeId: this.schemeId ? this.schemeId : undefined,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
      source : this.source? this.source : undefined
    }
    this.adminService.fetchAppOrgIdwiseCount(data).subscribe(res => {
      if (res && res.data && res.status == 200) {
        this.orgIdwiseCountList = res.data;
        // this.orgIdwiseCountList.forEach(element => {
        //   element.schemeName = _.find(this.schemeMasterList, (x: any) => x.id == element.schemeId).name;
        // });
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });

  }
}
