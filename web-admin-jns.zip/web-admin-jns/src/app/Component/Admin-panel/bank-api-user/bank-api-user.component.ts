import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-bank-api-user',
  templateUrl: './bank-api-user.component.html',
  styleUrls: ['./bank-api-user.component.scss']
})
export class BankApiUserComponent implements OnInit {
  LODASH = _;
  page = 1;
  pageSize = 10;
  startIndex = 1;
  endIndex = 10;
  totalSize = 0;
  totalCount;
  apiUserList;
  PageSelectNumber: string[];
  serviceapikey;
  orgId;
  bankUserTypeList: any = [];
  isInsurer:Boolean=false;
  isBanker:Boolean=false;
  insurerList: any = [];
  insurerMasterList: any = [];
  userTypeId: any;
  submitted:Boolean=false;
  
  constructor(private adminService: AdminPanelServiceService, private router: Router,private  commonService: CommonService) { }

  ngOnInit(): void {
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
    this.fetchApiUser();
    this.getAllUserType();
  }
  clearFilter(){
    this.userTypeId=null;
    this.orgId=null;
    this.fetchApiUser();
  }

  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchApiUser(true);

  }
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  
  fetchApiUser(onPageChangeFlag?,orgId?) {
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    const filterJSON = {
      orgId: orgId ? orgId : this.orgId || undefined,
      // searchValue: this.searchValue || undefined,
    }
    const data = {
      filterJSON: JSON.stringify(filterJSON),
      paginationFROM: this.startIndex,
      paginationTO: this.pageSize,
    }
    this.adminService.fetchApiUser(data).subscribe(res => {
      this.apiUserList = [];
      if (res && res.data) {
        this.apiUserList = JSON.parse(res.data);
        this.totalCount =  this.apiUserList[0].totalCount ?  this.apiUserList[0].totalCount : 0;
        this.apiUserList.forEach(element => {
          element.apiName = _.find(Constants.ApiMaster, (x: any) => x.id == element.configType).name;
        });       
      }
    });
  }
  // getMasterList() {
  //   const masterObj = ['API_MASTER'];
  //   this.adminService.getMasterListByKey(masterObj).subscribe(res => {
  //     if (res && res.status == 200 && res.data) {
  //       this.listApiUsers = res.data.API_MASTER;
  //     }
  //   })
  // }

  createApiUser(type) {
    this.router.navigate(['/Admin/create-new-bank-api-user'], { queryParams: { type: CommonService.encryptFuntion(type) } });
  }
  editApiUser(id,type) {
    this.router.navigate(['/Admin/create-new-bank-api-user'], { queryParams: { id: CommonService.encryptFuntion(id), type: CommonService.encryptFuntion(type) } });
  }
  viewApiUser(id,type){
    this.router.navigate(['/Admin/create-new-bank-api-user'], { queryParams: { id: CommonService.encryptFuntion(id) ,type: CommonService.encryptFuntion(type)} });
  }
  activeIsApiUser(id) {
    this.adminService.activeIsApiUser(id).subscribe(res => {
      if (res) {
        this.commonService.successSnackBar(res.message);
        this.fetchApiUser();
      }
    });
  }
  getAllUserType() {
    this.adminService.getAllUserType().subscribe(res => {
      if (res && res.data) {
        this.bankUserTypeList =res.data
      }
    });
  }

 
  getCommonList(id) {  
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
       this.insurerList = JSON.parse(res.data);
       this.insurerMasterList = JSON.parse(res.data);
     }
    });
  }

  fetchBankDetails(userTypeId){
    if(userTypeId==2 ){
      this.isBanker=true;
      this.isInsurer=false;
      this.getCommonList(2)

    }else if(userTypeId==6){
      this.isInsurer=true;
      this.isBanker=false;
      this.getCommonList(6)

    }
  }

}
