import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import alasql from 'alasql';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-notification-count',
  templateUrl: './notification-count.component.html',
  styleUrls: ['./notification-count.component.scss']
})
export class NotificationCountComponent implements OnInit {

  fromDate;
  toDate;
  dataList: any = [];
  downloadList: any = [];
  public showSpinners = true;
  public showSeconds = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe,private commonService: CommonService,
    private adminService :AdminPanelServiceService) { 
      const tempDate = new Date();
      this.fromDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 00:00:00");
      this.toDate = new Date(""+(tempDate.getMonth()+1)+"/"+tempDate.getDate()+"/"+tempDate.getFullYear()+" 11:59:59 PM");
}

  ngOnInit(): void {
    // this.fetchData();
  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:mm:ss aaa');
    // return this.datePipe.transform(date, 'dd-MMM-yyyy hh:MM:ss aaa');
}
  changeDateFormat1(date) {
    let startDate=new Date(date);
    startDate.setHours(23);
    startDate.setMinutes(59);
    startDate.setSeconds(59);
    return this.datePipe.transform(startDate, 'dd-MM-yyyy HH:mm:ss');
}
fetchData(isDwnld?){
  if(this.commonService.isObjectNullOrEmpty(this.fromDate) || this.commonService.isObjectNullOrEmpty(this.toDate)){
    this.commonService.warningSnackBar("Please Select Date Fiter")
  }
  else{
  let filterJSON : any= {
    fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
    toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined  
    // toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined 
  }
  this.adminService.getNotificationCount(filterJSON).subscribe(res => {
    if (res && !_.isEmpty(res.data)) {
      this.dataList = JSON.parse(res.data);
    } else {
      this.dataList = [];
      this.commonService.warningSnackBar(res.message)
    }
    if(isDwnld==true){
    this.downloadDataInExcel(this.dataList);
    }
  });
}
}

downloadNotificationList(){
  if(this.commonService.isObjectNullOrEmpty(this.fromDate) || this.commonService.isObjectNullOrEmpty(this.toDate)){
    this.commonService.warningSnackBar("Please Select Date Fiter")
  }
  else{
  let filterJSON : any= {
    fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
    toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined  
    // toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined 
  }
  this.adminService.downloadNotificatioList(filterJSON).subscribe(res => {
    if (res && !_.isEmpty(res.data)) {
      this.downloadList = JSON.parse(res.data);
      this.downloadDataInExcel(this.downloadList);
    } else {
      this.downloadList = [];
      this.commonService.warningSnackBar(res.message)
    }
  });
}
}
downloadDataInExcel(excelData) {
  let downloadData = [];
  const fileName = 'Notification List ' +this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa')+ '.xlsx';
  excelData.forEach((element, i) => {
    const index = i + 1;
    var allApplications = null;
      allApplications = [{
        Sr_no: index,
        'ID':element.id,
        'TO_ID':element.toId?element.toId:"-",
        'TO_EMAIL_COUNT':element.toEmailCount?element.toEmailCount:"-",
        'CC_EMAIL_COUNT':element.ccEmailCount?element.ccEmailCount:"-", 
        'BCC_EMAIL_COUNT':element.bccEmailCount?element.bccEmailCount:"-",
        'SMS_COUNT':element.smsCount?element.smsCount:"-", 
        'CONTENT_LENGTH':element.contLength?element.contLength:"-",
        'MASTER_ID':element.masterId?element.masterId:"-",
        'SUBJECT_ID':element.subjectId?element.subjectId:"-",
        'TEMPLATE_ID':element.templateId?element.templateId:"-",
        'NOTIFICATION_TYPE_ID':element.notiTypeId?element.notiTypeId:"-",
        'REFERENCE_ID':element.referenceId?element.referenceId:"-",
        'STATUS_CODE':element.statusCode?element.statusCode:"-", 
        'PROVIDE_ID':element.providerId?element.providerId:"-",
        'CREATED_DATE':element.createdDate?element.createdDate:"-"
      }];
    
    downloadData = downloadData.concat(allApplications);
  });
  alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
}
dateFormateForExcel(date) {
  return this.datePipe.transform(date, 'yyyy-MM-dd');
}

}
