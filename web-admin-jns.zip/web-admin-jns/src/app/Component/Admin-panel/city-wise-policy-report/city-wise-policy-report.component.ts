import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import alasql from 'alasql';
import * as _ from 'lodash';

@Component({
  selector: 'app-city-wise-policy-report',
  templateUrl: './city-wise-policy-report.component.html',
  styleUrls: ['./city-wise-policy-report.component.scss']
})
export class CityWisePolicyReportComponent implements OnInit {
  LODASH = _;
  cityWiseList: any;
  orgId;
  fromDate;
  toDate;
  bankList: any = [];
  bankMasterList: any = [];
  todayDate: Date = new Date();
  constructor(private datePipe: DatePipe, private adminService: AdminPanelServiceService,
    private commonService: CommonService, private commonMethod: CommonMethods) {
    const tempDate = new Date();
    // this.fromDate = new Date("" + (tempDate.getMonth() + 1) + "/" + tempDate.getDate() + "/" + tempDate.getFullYear());
    // this.toDate = new Date("" + (tempDate.getMonth() + 1) + "/" + (tempDate.getDate() + 1) + "/" + tempDate.getFullYear());
  }

  ngOnInit(): void {
    this.getCommonList(2);
    // this.fetchCityWiseForPolicy();
  }
  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.bankList = JSON.parse(res.data);
        this.bankMasterList = JSON.parse(res.data)
      }
    });
  }
  clearFilter() {
    this.orgId = undefined;
    // this.fetchCityWiseForPolicy();
    this.cityWiseList = undefined;
  }
  fetchCityWiseForPolicy(isDwnld?) {
    // if (this.commonService.isObjectNullOrEmpty(this.orgId)) {
    //   this.commonService.warningSnackBar("Please Search Bank ");
    //   return;
    // }
    //    if (this.commonService.isObjectNullOrEmpty(this.orgId)) {
    //   this.commonService.warningSnackBar("Please Search Bank ");
    //   return;
    // }
    const filterJSON = {
      orgId: this.orgId,
      fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
      toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined
    }
    this.adminService.fetchCityWiseForPolicy(filterJSON).subscribe(res => {
      if (res?.data) {
        this.cityWiseList = JSON.parse(res.data);
        if (isDwnld == true) {
          this.downloadDataInExcel(this.cityWiseList);
        }
      } else {
        this.cityWiseList = {};
        this.commonMethod.warningSnackBar('Data not found.');
      }
    });
  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }
  downloadDataInExcel(excelData) {
    let downloadData = [];
    // const fileName = 'Bank-Wise Enrollment Count ' + this.datePipe.transform(new Date(), 'dd MMM yyyy hh:MM:ss aaa') + '.xlsx';
    const fileName = 'City wise Count ' + this.getTodayDate() + '.xlsx';
    excelData.forEach((element, i) => {
      const index = i + 1;
      var allApplications = null;
      allApplications = [{
        Sr_no: index,
        'City Name': element.cityName ? element.cityName : '-',
        'State Name': element.stateName ? element.stateName : '-',
        'Total Count': element.totalCount ? element.totalCount : 0,
        'Premium Amount': element.amount ? element.amount : 0,
      }];

      downloadData = downloadData.concat(allApplications);
    });
    alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?', [downloadData]);
  }
  getTodayDate() {
    let day = new Date().getDate();
    let month = new Date().getMonth() + 1;
    let date = (day < 10 ? (0 + day.toString()) : day) + '-' + (month < 10 ? (0 + month.toString()) : month) + '-' + new Date().getFullYear();
    return date;
  }
}
