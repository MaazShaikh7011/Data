import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.scss']
})
export class CreateNewUserComponent implements OnInit {
  @ViewChild('createAdmin') createAdmin: NgForm;

  createUserObj: any = {};
  submitted = false;
  isView:boolean=false;
  adminRoleMaster = Constants.adminRoleMaster;
  organizationList: any = [];
  insurerList: any = [];
  documentList: any
  roleMaserList: any = [];
  roleMaserList1: any = [];
  schemeMasterList: any = [];
  selectedScheme = [];
  selectedAllScheme = [];
  isBranchView = false;
  branchList: any = [];
  bankUserTypeList: any = [];
  SelectSchemeChipList: any = []
  // temp: any = { businessTypeId: null, roleId: null, status: null };
  roleProductList: any = [];
  userId;
  userTypeId: any
  userOrgId;
  key: any
  userRoleId;
  branchId;
  userDetails: any = {};
  devUserOrgId; // for developer user olny
  devBranchId: number; // for developer user olny
  devRoleId: number; // for developer user olny
  adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
  isEditUser = false;
  isEmailAvailbleFlag = false;
  isuserFoundFlag = false;
  isInsurer: Boolean = false;
  listname: any
  isBanker: Boolean = false;
  isRoleView: Boolean = false;
  isSchemeDisabled:boolean = false;

  constructor(private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private activatedRoute: ActivatedRoute,
    private router: Router,) {
    this.activatedRoute.queryParams.subscribe(params => {
      if (!commonService.isObjectNullOrEmpty(params) && !commonService.isObjectNullOrEmpty(params.userId)) {
        this.userId = CommonService.decryptFuntion(params['userId']);
        this.userOrgId = CommonService.decryptFuntion(params['userOrgId']);
        this.userRoleId = CommonService.decryptFuntion(params['userRoleId']);
        if (!commonService.isObjectNullOrEmpty(params.branchId)) {
          this.branchId = CommonService.decryptFuntion(params['branchId']);
        }
      }
    });
  }

  ngOnInit(): void {
    this.getAllScheme();
    // this.getOrganizationList();
    // this.getRoleMaserList(this.key);
    this.getAllUserType();

    // this.schemeMasterList = _.filter(Constants.schemeMasterList);
    if (!this.commonService.isObjectNullOrEmpty(this.userId)) {
      this.isEditUser = true;
      this.getUserDetails();
    }
  }

  getRoleTypeList(): void {
    if (this.isEmailAvailbleFlag) {
      return;
    }
    this.submitted = false;
    setTimeout(() => {
      this.submitted = true;
    }, 0);
    if (this.createAdmin.valid) {
      this.adminService.getRoleTypeList({ email: this.createUserObj.email }).subscribe(success => {
        if (success.status === 200 && success.data) {
          this.isuserFoundFlag = true;
          this.commonService.warningSnackBar("Email Already Exists");
        } else {
          this.isuserFoundFlag = false;
          this.isEmailAvailbleFlag = true;
        }
      }, error => {
        this.commonService.errorSnackBar(error);
      });
    }
  }

  getUserDetails() {
    const data = {
      userId: this.userId
    }
    this.adminService.getUserDetailsList(data).subscribe(res => {
      if (res && res.data) {
        this.userDetails = res.data;
        this.createUserObj.email = this.userDetails.email;
        this.createUserObj.mobile = this.userDetails.mobile;
        this.createUserObj.firstName = this.userDetails.firstName;
        this.createUserObj.middleName = this.userDetails.middleName;
        this.createUserObj.lastName = this.userDetails.lastName;
        this.createUserObj.userOrgId = this.userDetails.userOrgId;
        this.selectedScheme = this.userDetails.schemeList;
        this.createUserObj.userRoleId = this.userDetails.userRoleId;
        this.isBranchShow(this.userRoleId);
      }
    });

  }

  // isBankDisabled() {
  //   if (!this.commonService.isObjectNullOrEmpty(this.userOrgId)) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  // getOrganizationList() {
  //   this.adminService.getOrganizationList().subscribe(res => {
  //     if (res && res.data) {
  //       this.organizationList = res.data;
  //     }
  //   });
  // }

  getAllUserType() {
    this.adminService.getAllUserType().subscribe(res => {
      if (res && res.data) {
        this.bankUserTypeList = res.data;
      }
    });
  }

  getAllScheme() {
    this.adminService.getAllScheme().subscribe(res => {
      if (res && res.data) {
        this.isView = true
        this.schemeMasterList = JSON.parse(res.data);
        this.schemeMasterList = _.filter(this.schemeMasterList, (x) => x.id > 0);
        // res.data.forEach(element => {
        //   let res1 = { id: element[0], name: element[1], businessId: element[2] };
        //   this.schemeMasterList.push(res1);
        // });
      }
    });

  }

  getRoleMaserList(userTypeId) {
    if (!userTypeId) {
      return;
    }
    this.adminService.getAdminRoleMaserList().subscribe(res => {
      if (res && res.data) {
        if (2 == userTypeId) {
          this.roleMaserList = _.filter(res.data, (x: any) => x.roleId == 5 || x.roleId == 9 || x.roleId == 13 || x.roleId == 14);
        } else if (4 == userTypeId) {
          this.roleMaserList = _.filter(res.data, (x: any) => x.roleId == 21);
        } else if (6 == userTypeId) {
          this.roleMaserList = _.filter(res.data, (x: any) => x.roleId == 5);
        } else if (7 == userTypeId) {
          this.roleMaserList = _.filter(res.data, (x: any) => x.roleId == 22 || x.roleId == 23 || x.roleId == 24);
        }
        this.isRoleView = [2, 4, 6, 7].includes(userTypeId) ? true : false;
      }
    });
  }

  checkSelectAll() {
    if (this.selectedScheme.length == this.schemeMasterList.length) {
      return true;
    } else {
      return false;
    }
  }

  selectAllSchemes(event) {
    //selectedScheme
    this.selectedScheme = [];
    this.selectedAllScheme = [];
    if (event.target.checked) {
      for (var i = 0; i < this.schemeMasterList.length; i++) {
        this.selectedAllScheme.push(this.schemeMasterList[i].id);
        this.selectedScheme = this.selectedAllScheme;
      }
    } else {
      this.selectedScheme = [];
    }
  }

  getAllBOList(data) {
    this.adminService.getAllBOList(data).subscribe(res => {
      if (res && res.data) {
        this.branchList = JSON.parse(res.data);
        this.createUserObj.branchId = this.userDetails.branchId;
      }
    });
  }

  getAllRoList(data) {
    this.adminService.getAllRoList(data).subscribe(res => {
      if (res && res.data) {
        this.branchList = JSON.parse(res.data);
        this.createUserObj.branchId = this.userDetails.branchId;
      }
    });
  }

  getAllZoList(data) {
    this.adminService.getAllZoList(data).subscribe(res => {
      if (res && res.data) {
        this.branchList = JSON.parse(res.data);
        this.createUserObj.branchId = this.userDetails.branchId;
      }
    });
  }

  setDefaultValue() {
    this.isBanker = false;
    this.isRoleView = false;
    this.isInsurer = false;
    this.isBranchView = false;
    this.isSchemeDisabled = false;
  }

  

  isRoleChanged(roleId) {
    if (!roleId || ![22, 23, 24].includes(roleId)) {
      this.isBranchShow(roleId);
      return;
    } else {
      this.selectedScheme = [];
      this.SelectSchemeChipList = [];
      if (roleId == 22) {
        this.selectedScheme = [1, 2];
      } else if (roleId == 23) {
        this.selectedScheme = [1];
      } else if (roleId == 24) {
        this.selectedScheme = [2];
      }
      this.selectedScheme.forEach(element => {
        this.SelectSchemeChipList.push(_.find(this.schemeMasterList, (x: any) => element == x.id).name);
      });
      this.isSchemeDisabled = true;
    }
  }

  getCommonList(id) {
    this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
      if (res && res.data) {
        this.insurerList = JSON.parse(res.data);
      }
    });
  }


  checkValueIsNull() {
    if (((this.commonService.isObjectNullOrEmpty(this.createUserObj.userOrgId)) || (this.selectedScheme.length == 0)) || (!this.commonService.isObjectNullOrEmpty(this.userRoleId))) {
      return true;
    } else {
      return false;
    }
  }

  setHideBranch(userTypeId?) {
    if (!userTypeId) {
      this.commonService.warningSnackBar('please select branch type');
      return;
    }
    this.createUserObj.userRoleId = undefined;
    this.createUserObj.userOrgId = undefined;
    this.createUserObj.branchId = undefined;
    this.isBranchView = false;
    this.setDefaultValue();
    if (userTypeId == 2) {
      this.isBanker = true;
      this.getRoleMaserList(userTypeId);
      this.getCommonList(userTypeId);
    } else if (userTypeId == 4) {
      this.getRoleMaserList(userTypeId);
    } else if (userTypeId == 6) {
      this.isInsurer = true;
      this.getRoleMaserList(userTypeId);
      this.getCommonList(userTypeId);
    } else if (userTypeId == 7) {
      this.getRoleMaserList(userTypeId);
    }
  }

  isBranchShow(userRoleId) {
    if (!userRoleId) {
      return;
    }
    if (![9, 13, 14].includes(userRoleId)) {
      this.createUserObj.branchId = undefined;
      this.isBranchView = false;
      return;
    }
    if (this.commonService.isObjectNullOrEmpty(this.createUserObj.userOrgId)) {
      this.commonService.warningSnackBar("Please Select Bank");
      return;
    }
    if (this.selectedScheme?.length == 0) {
      this.commonService.warningSnackBar("Please Select Scheme");
      return;
    }

    const data = {
      userOrgId: this.createUserObj.userOrgId,
      selectedScheme: this.selectedScheme
    }
    this.branchList = [];
    if (userRoleId == 9) {
      this.isBranchView = true;
      this.getAllBOList(data);
    } else if (userRoleId == 13) {
      this.isBranchView = true;
      this.getAllRoList(data);
    } else if (userRoleId == 14) {
      this.isBranchView = true;
      this.getAllZoList(data);
    }
    //  else {
    //   this.createUserObj.branchId = undefined;
    //   this.isBranchView = false;
    // }
  }


  checkUserMobile(userData, isUpdateUser): void {
    if (isUpdateUser) {
      this.adminService.checkUserMobile({ mobile: userData.mobile }).subscribe(success => {
        if (success.status === 200 && success.data) {
          this.commonService.warningSnackBar("Mobile Exists.!");
        } else {
          this.saveUserData(userData);
        }
      });
    } else {
      this.saveUserData(userData);
    }
  }

  saveUserData(createUserObj) {
    this.submitted = false;
    setTimeout(() => {
      this.submitted = true;
    }, 0);

    if (this.createAdmin.valid) {
      this.roleProductList = [];
      this.selectedScheme.forEach(element => {
        const temp: any = {};
        const data = this.schemeMasterList.find(a => a.id == element);
        temp.roleId = createUserObj.userRoleId;
        temp.status = true;
        // temp.businessTypeId = data.businessId;
        temp.businessTypeId = 1;
        temp.schemeId = data.id;
        this.roleProductList.push(temp);
      });
      createUserObj.roleProductList = this.roleProductList;
      createUserObj.userId = this.userId;
      createUserObj.isActive = true;
      createUserObj.selectedScheme = _.map(this.roleProductList, (x: any) => x.schemeId);
      createUserObj.isAdminPanel = true;
      this.adminService.createNewUser(createUserObj).subscribe(res => {
        if (res && res.data) {
          this.commonService.successSnackBar(res.message);
          this.router.navigate(['/Admin/Bank-User-List']);
        }
      });
    }else{
      this.createAdmin.control.markAllAsTouched();
      this.commonService.warningSnackBar("Please fill required fields");
    }
  }

  changeRoleOrgBranch(userId, orgId, branchId, userRoleId) {
    if (!userRoleId && !orgId) {
      this.commonService.warningSnackBar("Please Select Organization & Role")
      return;
    }
    const data = {
      userId: userId,
      orgId: orgId,
      branchId: branchId ? branchId : undefined,
      userRoleId: userRoleId ? userRoleId : undefined,
    };
    this.adminService.changeOrgIdAndBranchId(data).subscribe(res => {
      if (res && res.data) {
        this.commonService.successSnackBar(res.message);
        this.router.navigate(['/Admin/Bank-User-List']);
      }
    });
  }

  checkAdminPermission(button: any): boolean {
    const index: number = this.adminPermissionList.indexOf(button);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }

  SelectSchemeChips(selectSchemeChip) {
    this.SelectSchemeChipList = [];
    selectSchemeChip.forEach(element => {
      const tmpScheme = _.find(this.schemeMasterList, (x: any) => x.id == element);
      tmpScheme && this.SelectSchemeChipList.push(tmpScheme.name);
    });
  }
  onToppingRemoved(scheme: string): void {
    if(this.isSchemeDisabled){
      return;
    }
    const toppings = this.selectedScheme as any;
    // this.singleBranchDetail.selectedScheme = [];
    this.schemeMasterList.forEach(element => {
     if(element.name==scheme){
      this.removeFirst(toppings, element.id);
     }
    });
    
    //this.selectSchemeChips(toppings)
  //  this.selectedScheme=toppings; // To trigger change detection
  
  }

  private removeFirst<T>(array: T[], toRemove: T): void {
    this.isView = false;
    const index = array.indexOf(toRemove);
    if (index !== -1) {
      array.splice(index, 1);
      this.SelectSchemeChipList.splice(index,1);
    }

    const ind = this.selectedScheme.indexOf(toRemove);
    if(ind != -1){
      this.selectedScheme.splice(ind, 1);
    }
    setTimeout(() => {
      this.isView = true
    }, 0);
    
    
  }
}
