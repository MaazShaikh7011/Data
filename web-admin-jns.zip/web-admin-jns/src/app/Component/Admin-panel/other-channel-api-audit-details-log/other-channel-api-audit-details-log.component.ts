import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-other-channel-api-audit-details-log',
  templateUrl: './other-channel-api-audit-details-log.component.html',
  styleUrls: ['./other-channel-api-audit-details-log.component.scss']
})
export class OtherChannelApiAuditDetailsLogComponent implements OnInit {
  LODASH = _;
  startIndex = 0;
  PageSelectNumber: string[];
  page = 1;

  pageSize = 10;
  endIndex = 10;
  totalCount ;
  isListCollapsed: boolean = true;
  searchData;
  bankList :any =[];
  bankMasterList :any =[];
  orgId;
  userorgName;
  registryDataList :any =[];
  searchType;
  searchTypeId;
  listRegistryReqUrl;
  registryurl;
  fromDate: any;
  toDate: any;
  apiRespose: any= {};
  todayDate: Date = new Date();  
  public disabled = false;
  public showSpinners = true;
  public showSeconds = true;
  public enableMeridian = true;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;

  constructor(private datePipe: DatePipe,private adminService: AdminPanelServiceService,
    private commonService: CommonService,
    private userService: UserProfileService) { 
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  ngOnInit(): void {
    // this.getCommonList(2);
    this.getOrganizationList()
    this.searchType = [
      { id: 1, value: 'Id' },
      { id: 2, value: 'Request Url' },
      { id: 3, value: 'Token' },
      { id: 4, value: 'Account No.' },
      { id: 5, value: 'CIF' },
      { id: 6, value: 'URN' },
      { id: 7, value: 'Ref no.' },
    ];
    this.getMasterList();
  }

  // getCommonList(id) {
  //   this.adminService.getCommonList('getOrgListByTypeId', id).subscribe(res => {
  //     if (res && res.data) {
  //       this.bankList = JSON.parse(res.data);
  //       this.bankMasterList  = JSON.parse(res.data);
  //     }
  //   });
  // }
  getOrganizationList() {
    this.adminService.getOrganizationList().subscribe(res => {
      if (res && res.data) {
        this.bankList= res.data
        this.bankMasterList = res.data;
      }
    });
  }
  onPageChange(page: any): void {
    this.startIndex = (page - 1) * this.pageSize;
    this.endIndex = (page - 1) * this.pageSize + this.pageSize;
    this.fetchRegistryDataList(true);
  }
  
  resetStartIndex(): void {
    this.startIndex = 0;
    this.page = 1;
  }
  changeDateFormat(date) {
    return this.datePipe.transform(date, 'dd-MMM-yyyy hh:mm:ss aaa');
}

  clearFilter() {
    this.orgId = undefined;
    this.fromDate = undefined;
    this.toDate = undefined;
    this.searchTypeId = undefined;
    this.registryurl= undefined;
    this.searchData = undefined;
    this.fetchRegistryDataList(false);
  }
  fetchRegistryDataList(onPageChangeFlag?){
    if (!onPageChangeFlag) {
      this.resetStartIndex();
    }
    if(this.orgId || onPageChangeFlag==false){
      const data = {     
        type : 2 ,
        searchData: this.searchData ? this.searchData : undefined,
        toDate: this.toDate ? this.changeDateFormat(this.toDate) : undefined,
        fromDate: this.fromDate ? this.changeDateFormat(this.fromDate) : undefined,
        orgId: this.orgId ? this.orgId : undefined,
        searchTypeId : this.searchTypeId ? this.searchTypeId :undefined,
        requrl : this.registryurl ? ("/api/registry" + this.registryurl) : undefined,
        paginationFROM: this.startIndex ? this.startIndex : 0,
        paginationTO: onPageChangeFlag==false ? 0 : this.pageSize
      }
      this.userService.fetchRegistryApiAuditDetailList(data).subscribe(res => {
        // if (res && !_.isEmpty(res.data)) {
          if (res && res.data) {
          this.registryDataList = JSON.parse(res.data);
           this.registryDataList.forEach(element => {
            element.userorgName =_.find(this.bankList,(x:any)=>x.userOrgId == this.orgId).organisationName
           });
          // console.log(this.registryDataList)
          // this.publishdataList.forEach(element => {
          //   element.plainRequest=JSON.parse(element?.plainRequest);
          // });
          this.totalCount = this.registryDataList[0].totalCount || 0;
        }
         else {
          this.totalCount = 0;
          this.registryDataList = [];
        }
      });
    }else{
      this.commonService.warningSnackBar('Please select Bank');
    }

  }
  getMasterList() {
    const masterObj = ['REGISTRY_REQ_LIST'];
    this.adminService.getMasterListByKey(masterObj).subscribe(res => {
      if (res && res.status == 200 && res.data) {
        this.listRegistryReqUrl = res.data.REGISTRY_REQ_LIST;
      }
    })
  }
  clearSearchType(){
    this.fromDate=undefined;
    this.toDate=undefined;
    this.registryurl = undefined;
    this.searchData = undefined;
  }

  getApiData(auditId, isListCollapsed){
    // console.log('fileName: ', auditId);
    if(!isListCollapsed){
      return;
    } 
    if(!auditId){
      this.commonService.warningSnackBar('File Not Found');
      return;
    }
    this.apiRespose = undefined;
    this.registryDataList.forEach(element => {
      element.isListCollapsed = false
    });
    this.adminService.getRegistryReqRes(auditId).subscribe(res => {
      if (res.data) {
        const data = res.data;
        const index = _.findIndex(this.registryDataList, (x: any) => x.id == auditId);
        if (index != -1) {
          this.registryDataList[index].isListCollapsed = true;
        }
        this.apiRespose = data
        // this.apiRespose = {
        //   reqLogAuditId: data.reqLogAuditId,
        //   referenceId: data.referenceId,
        //   header: data.header,
        //   plainRequest: data.plainRequest,
        //   plainResponse: data.plainResponse,
        //   encryptRequest: data.encryptRequest,
        //   encryptResponse: data.encryptResponse,
        // }
      } else {
        this.commonService.infoSnackBar('Data Not Found');
      }
    });
  }

  downloadFile(urn) {
    var sJson = JSON.stringify(this.apiRespose, undefined, 2).replace(/\\/g,'');
    var element = document.createElement('a');
    element.setAttribute('href', "data:text/json;charset=UTF-8," + encodeURIComponent(sJson));
    element.setAttribute('download', urn + ".txt");
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }

}
