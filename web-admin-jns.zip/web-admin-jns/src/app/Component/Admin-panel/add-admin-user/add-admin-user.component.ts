import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Component({
  selector: 'app-add-admin-user',
  templateUrl: './add-admin-user.component.html',
  styleUrls: ['./add-admin-user.component.scss']
})
export class AddAdminUserComponent implements OnInit {
  @ViewChild('addAdminData') addAdminData: NgForm;
  adminObj: any = {};
  submitted = false;
  currentAdminRole = CommonService.getStorage(Constants.httpAndCookies.ROLEID, true);

  constructor(private adminService: AdminPanelServiceService,
    private commonService: CommonService,private router:Router) { }
  ngOnInit(): void { }

  addAdminUser(adminObj) {
    this.submitted = false;
    setTimeout(() => {
      this.submitted = true;
    }, 0);
    if (this.addAdminData.valid) {
      this.adminService.saveUserAdmin(adminObj).subscribe(res => {
        if (res && res.data) {
          this.commonService.successSnackBar(res.message);
          this.router.navigate(["/Admin/Admin-User-List"])
        }
      });
    }else{
      this.addAdminData.control.markAllAsTouched();
      this.commonService.warningSnackBar("Please fill required fields");
      return;
    }
  }

}
