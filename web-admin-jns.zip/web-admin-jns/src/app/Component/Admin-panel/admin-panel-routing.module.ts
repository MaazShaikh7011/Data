import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EncryptDecryptComponent } from './encrypt-decrypt/encrypt-decrypt.component';
import { BranchListComponent } from './branch-list/branch-list.component';
import { CreateBranchComponent } from './create-branch/create-branch.component';
import { BankUserListComponent } from './bank-user-list/bank-user-list.component';
import { CreateNewUserComponent } from './create-new-user/create-new-user.component';
import { OrganizationListComponent } from './organization-list/organization-list.component';
import { BankApiUserComponent } from './bank-api-user/bank-api-user.component';
import { CreateNewBankApiUserComponent } from './create-new-bank-api-user/create-new-bank-api-user.component';
import { CustomerRecoredListComponent } from './customer-recored-list/customer-recored-list.component';
import { BankApiAuditDetailsLogComponent } from './bank-api-audit-details-log/bank-api-audit-details-log.component';
import { PublishApiAuditDetailsLogComponent } from './publish-api-audit-details-log/publish-api-audit-details-log.component';
import { OtherChannelApiAuditDetailsLogComponent } from './other-channel-api-audit-details-log/other-channel-api-audit-details-log.component';
import { APAdminUserListComponent } from './ap-admin-user-list/ap-admin-user-list.component';
import { AddAdminUserComponent } from './add-admin-user/add-admin-user.component';
import { AdminManagementComponent } from './admin-management/admin-management.component';
import { JNSInsurerDetailsComponent } from './insurer-details/jns-insurer-details.component';
import { ApplicationClaimAuditComponent } from './application-claim-audit/application-claim-audit.component';

import { ApplicationStatusMasterComponent } from './application-status-master/application-status-master.component';
import { ClaimStatusMasterComponent } from './claim-status-master/claim-status-master.component';
import { ConfigMasterComponent } from './config-master/config-master.component';
import { DmsMasterComponent } from './dms-master/dms-master.component';
import { PremiumMasterComponent } from './premium-master/premium-master.component';
import { AddConfigMasterComponent } from './add-config-master/add-config-master.component';
import { NotificationCountComponent } from './notification-count/notification-count.component';
import { BankwiseApplicationCountComponent } from './bankwise-application-count/bankwise-application-count.component';
import { BankWiseclaimCountComponent } from './bank-wiseclaim-count/bank-wiseclaim-count.component';
import { InsurerCountComponent } from './insurer-count/insurer-count.component';
import { ClaimApiAuditLogComponent } from './claim-api-audit-log/claim-api-audit-log.component';
import { PythonAuditComponent } from './python-audit/python-audit.component';

import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { EnrollmentApiAuditDetailsLogComponent } from './enrollment-api-audit-details-log/enrollment-api-audit-details-log.component';
import { PushCoiCountsComponent } from './push-coi-counts/push-coi-counts/push-coi-counts.component';
import { EncryptDecryptBankAndInsurerDataComponent } from './encrypt-decrypt-bank-and-insurer-data/encrypt-decrypt-bank-and-insurer-data.component';
import { BucketAuditDetailsComponent } from './bucket-audit-details/bucket-audit-details.component';
import { NotificationListComponent } from './notification-list/notification-list.component';
import { BankInsurerCountComponent } from './bank-insurer-count/bank-insurer-count.component';
import { JNSSupportDashboardComponent } from './jns-support-dashboard/jns-support-dashboard.component';
import { CityWiseReportComponent } from './city-wise-report/city-wise-report.component';
import { CityWisePolicyReportComponent } from './city-wise-policy-report/city-wise-policy-report.component';
import { WebhookApiAuditDetailsLogComponent } from './webhook-api-audit-details-log/webhook-api-audit-details-log.component';
import { PostmanClientCallComponent } from './postman-client-call/postman-client-call.component';
import { JsnsurakshaApiCallComponent } from './jsnsuraksha-api-call/jsnsuraksha-api-call.component';
import { ClaimReportComponent } from './claim-report/claim-report.component';
import { PushFailDashboardComponent } from './push-fail-dashboard/push-fail-dashboard.component';
import { RegenerateReportComponent } from './regenerate-report/regenerate-report.component';

const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },

  { path: 'Admin-Dashboard', component: AdminDashboardComponent, data: { title: 'Request Encrypt Decrypt' } },

  { path: 'requestView', component: EncryptDecryptComponent, data: { title: 'Request Encrypt Decrypt' } },
  { path: 'branch-list', component: BranchListComponent, data: { title: 'Branch List' } },
  { path: 'create-branch', component: CreateBranchComponent, data: { title: 'Create Branch' } },
  { path: 'Bank-User-List', component: BankUserListComponent, data: { title: 'Bank User List' } },
  { path: 'Create-New-User', component: CreateNewUserComponent, data: { title: 'Create New User' } },
  { path: 'Organization-List', component: OrganizationListComponent, data: { title: 'Set Permission' } },

  { path: 'bank-api-user', component: BankApiUserComponent, data: { title: 'Branch List' } },
  { path: 'create-new-bank-api-user', component: CreateNewBankApiUserComponent, data: { title: 'Create New Bank Api User' } },
  { path: 'encrypt-decrypt-data', component: EncryptDecryptBankAndInsurerDataComponent, data: { title: 'Encrypt Decrypt Bank And Insurer Data' } },

  { path: 'Admin-Customer-List', component: CustomerRecoredListComponent, data: { title: 'Admin Customer List' } },


  { path: 'Bank-Api-Audit', component: BankApiAuditDetailsLogComponent, data: { title: 'Bank Api Audit Details' } },
  { path: 'Webhook-Api-Audit', component: WebhookApiAuditDetailsLogComponent, data: { title: 'Webhhok Api Audit Details' } },
  { path: 'Publish-Api-Audit', component: PublishApiAuditDetailsLogComponent, data: { title: 'Publish Api Audit Details' } },
  { path: 'Other-Channel-Api-Audit', component: OtherChannelApiAuditDetailsLogComponent, data: { title: 'Publish Api Audit Details' } },
  { path: 'claim-api-audit', component: ClaimApiAuditLogComponent, data: { title: 'claim Api Audit Details' } },
  { path: 'Enrollment-Api-Audit', component: EnrollmentApiAuditDetailsLogComponent, data: { title: 'Enrollment Api Audit Details' } },
  { path: 'Python-Api-Audit', component: PythonAuditComponent, data: { title: 'Python Api Audit Details' } },
  { path: 'Bucket-Audit', component: BucketAuditDetailsComponent, data: { title: 'Publish Api Audit Details' } },
  { path: 'Admin-User-List', component: APAdminUserListComponent, data: { title: 'Admin User List' } },
  { path: 'Add-Admin', component: AddAdminUserComponent, data: { title: 'Set Permission' } },
  { path: 'admin-management', component: AdminManagementComponent, data: { title: 'Admin Management' } },

  { path: 'Insurer-Detail', component: JNSInsurerDetailsComponent, data: { title: 'Insurer Detail List' } },

  { path: 'Admin-Error-List', component: ApplicationClaimAuditComponent, data: { title: 'Application Claim Audit' } },

  { path: 'application-status', component: ApplicationStatusMasterComponent, data: { title: 'Application Status Details' } },
  { path: 'claim-status', component: ClaimStatusMasterComponent, data: { title: 'Claim Status Details' } },
  { path: 'config-status', component: ConfigMasterComponent, data: { title: 'Config  Details' } },
  { path: 'dms-status', component: DmsMasterComponent, data: { title: 'DMS Master Details' } },
  { path: 'premium-master', component: PremiumMasterComponent, data: { title: 'Premium Master  Details' } },
  { path: 'add-config', component: AddConfigMasterComponent, data: { title: 'Add Config Master' } },
  { path: 'Notification-count', component: NotificationCountComponent, data: { title: 'Notification Count' } },
  { path: 'notification-list', component: NotificationListComponent, data: { title: 'Notification List' } },

  { path: 'bank-wise-Enrollment-count', component: BankwiseApplicationCountComponent, data: { title: 'DMS Master Details' } },
  { path: 'bank-wise-Claim-count', component: BankWiseclaimCountComponent, data: { title: 'Premium Master  Details' } },
  { path: 'Insurer-wise-Enrollment-count', component: InsurerCountComponent, data: { title: 'DMS Master Details' } },
  { path: 'push-coi-count', component: PushCoiCountsComponent, data: { title: 'Push COI counts' } },
  { path: 'bank-Insurer-count', component: BankInsurerCountComponent, data: { title: 'Premium Master  Details' } },

  { path: 'supportDashboard', component: JNSSupportDashboardComponent, data: { title: 'Support Dashboard Details' } },
  { path: 'cityWiseReport', component: CityWiseReportComponent, data: { title: 'Notification List' } },
  { path: 'cityWisePolicyReport', component: CityWisePolicyReportComponent, data: { title: 'Notification List' } },
  { path: 'postman-client-call', component: PostmanClientCallComponent, data: { title: 'Postman Client call' } },
  { path: 'jansuraksha-api', component: JsnsurakshaApiCallComponent, data: { title: 'Postman Client call' } },
  { path: 'claimAgeingReport', component: ClaimReportComponent, data: { title: 'Postman Client call' } },
  { path: 'pushFailDashboard', component: PushFailDashboardComponent, data: { title: 'Push Fail Data' } },
  { path: 'regenerateReport', component: RegenerateReportComponent, data: { title: 'Regenerate Report' } },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminPanelRoutingModule { }
