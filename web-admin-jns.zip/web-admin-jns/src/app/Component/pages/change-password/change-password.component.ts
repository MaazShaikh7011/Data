import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminPanelServiceService } from '../../../CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from '../../../CommoUtils/common-services/common-methods';
import { CommonService } from '../../../CommoUtils/common-services/common.service';
import { Constants } from '../../../CommoUtils/common-services/constants';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  @ViewChild('changePasswordForm') changePasswordForm: NgForm;
  hide = true;
  hide1 = true;
  hide2 = true;

  isDisabled: boolean = false;

  isMatchPswEightCharLength: any;

  isMatchPswOneNumber: RegExpMatchArray;
  isMatchPswOneSpecialChar: RegExpMatchArray;
  isMatchPswOneAlpha: RegExpMatchArray;
  isMatchPswOneCapAlpha: RegExpMatchArray;

  currentPassword: any;
  newPassword: any;
  reEnterPassword: any;

  firstPwdChange: any;
  constructor(
    private adminPanelServiceService: AdminPanelServiceService,
    public activeModal: NgbActiveModal,
    private commonService: CommonService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private commonMethod: CommonMethods) { }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      if (!this.commonService.isObjectNullOrEmpty(params)
        && !this.commonService.isObjectNullOrEmpty(params.firstPwdChange)) {
        this.firstPwdChange = CommonService.decryptFuntion(params['firstPwdChange']);
      }
    });
  }

  submit() {
    const data = {
      oldPassword: this.currentPassword,
      password: this.newPassword,
      confirmPassword: this.reEnterPassword,
      isPasswordSet: true,
    }

    if (!this.currentPassword && !this.newPassword && !this.reEnterPassword) {
      this.commonService.warningSnackBar('Please fill all the details correctly.')
      return;
    }

    this.adminPanelServiceService.changePassword(data).subscribe(res => {
      if (res && res.status === 200) {
        this.commonService.successSnackBar("New password successfully updated!");
        this.activeModal.close('cancel')
        setTimeout(() => {
          this.router.navigate([Constants.ROUTE_URL.LOGIN]);
        }, 1500);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }

  checkPasswordMatch(): any {
    if (this.newPassword !== this.reEnterPassword) {
      this.commonService.warningSnackBar('Password and Confirm password should be same');
      return false;
    } else if ((this.isMatchPswEightCharLength <= 8 && this.isMatchPswEightCharLength >= 20) ||
      (this.isMatchPswOneNumber == null) || (this.isMatchPswOneCapAlpha == null) ||
      (this.isMatchPswOneAlpha == null) || (this.isMatchPswOneSpecialChar == null)) {
      this.commonService.warningSnackBar('Enter valid password');
      return;
    }
    else {
      this.submit();
    }
  }
  chkPatternMatch(event: any) {
    this.isDisabled = true;
    let x: String;
    x = event.target.value;
    this.isMatchPswEightCharLength = x.length;
    this.isMatchPswOneNumber = x.match(".*\\d+.*");
    this.isMatchPswOneSpecialChar = x.match("(?=.*[$@!%*#?&_=`~{}:;,.'$-])");
    this.isMatchPswOneAlpha = x.match("(?=.*[a-z]){1,}");
    this.isMatchPswOneCapAlpha = x.match("(?=.*[A-Z]){1,}");
  }

  cancel() {
    if (this.firstPwdChange) {
      this.router.navigate([Constants.ROUTE_URL.LOGIN]);
    }
  }
}
