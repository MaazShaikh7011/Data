import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChangePasswordComponent } from 'src/app/Component/pages/change-password/change-password.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, data: { title: 'Jansuraksha - Login' } },
  { path: 'Change-PassWord', component: ChangePasswordComponent, data: { title: 'Change Pass-Word User' } },
  // { path: 'TeaserView', loadChildren: () => import('./TeaserView/teaser-view.module').then(m => m.TeaserViewModule) },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
