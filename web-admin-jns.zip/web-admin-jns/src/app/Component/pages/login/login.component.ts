import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { BankerService } from 'src/app/service/banker.service';
import { ValidationsService } from 'src/app/CommoUtils/common-services/validations.service';
import { Router } from '@angular/router';
import { UserProfileService } from 'src/app/CommoUtils/user.service';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: UntypedFormGroup;
  submitted = false;
  returnUrl: string;
  error = '';
  hide = true;
  loading = false;
  userResponse: any = {};
  //For Captcha
  captchaData: any;
  currentCaptcha: string;
  apiKey :any;
  pubApiKey :any
  pubUsername : any ;
  constructor(private formBuilder: UntypedFormBuilder, private commonMethods: CommonMethods,
    private bankerService: BankerService,
    private commonService: CommonService,
    private userService: UserProfileService,
    private validationsService: ValidationsService,
    private router: Router,private adminService: AdminPanelServiceService) {
    commonMethods.getValidationByModule(Constants.validationModule.LOGIN);

  }

  ngOnInit() {
    CommonService.clearStorage();
    // this.loginForm = this.formBuilder.group({
    //   username: ['', [Validators.required, Validators.email]],
    //   password: ['', Validators.required],
    // });
    this.getCaptcha();
    this.loginForm = this.formBuilder.group({
      userType: this.validationsService.validationConfig(Constants.UserType.ADMIN_MASTER, this.commonMethods.getValidations('userType')),
      username: this.validationsService.validationConfig('', this.commonMethods.getValidations('username')),
      password: this.validationsService.validationConfig('', this.commonMethods.getValidations('password')),
      captcha: [''],
    });
  }

  get f() { return this.loginForm.controls; }

  login(): void {
    const data: any = {};
    if (CommonService.isObjectNullOrEmpty(this.loginForm.value.captcha)) {
      this.commonMethods.warningSnackBar('Please Enter Captcha !!');
      return;
    }
    if (this.loginForm.value.captcha.length != 6) {
      this.commonMethods.warningSnackBar('Please Enter Valid Captcha !!');
      this.loginForm.controls.captcha.patchValue('');
      this.getCaptcha();
      return;
    }

    if (this.loginForm.value.captcha != this.currentCaptcha) {
      this.commonMethods.warningSnackBar('Please Enter Valid Captcha!!');
      this.loginForm.controls.captcha.patchValue('');
      this.getCaptcha();
      return;
    }
    if (CommonService.isObjectNullOrEmpty(this.loginForm.controls.username.value)) {
      this.commonMethods.warningSnackBar('Please enter email Id or Mobile no.');
      return;
    }
    if (!isNaN(this.loginForm.controls.username.value) && this.loginForm.controls.username.value.length > 10) {
      this.commonMethods.warningSnackBar('Please enter valid Email Address or Mobile Number.');
      return;
    }

    if (!this.loginForm.controls.username.valid) {
      this.commonMethods.warningSnackBar('Please enter valid Email Address or Mobile Number.');
      return;
    }
    this.submitted = false;
    setTimeout(() => {
      this.submitted = true;
    }, 0);
    if (!this.loginForm.valid) {
      this.commonMethods.warningSnackBar('Please enter valid Email Address or Password');
      return;
    }
    data.email = this.loginForm.controls.username.value;
    data.password = this.loginForm.controls.password.value;
    data.userType = Constants.UserType.ADMIN_MASTER;
    const validation = CommonService.getStorage('validations', true);

    CommonService.clearStorage();
    CommonService.setStorage(Constants.httpAndCookies.VALIDATIONS, validation);
    data.captchaEnter = this.loginForm.value.captcha;
    data.captchaOriginal = this.currentCaptcha;

    this.bankerService.login(data).subscribe(res => {
      if (res.status === 200) {
        this.manageLocalStorage(res);

        if (!res.isPasswordChanged) {
          this.router.navigate([Constants.ROUTE_URL.CHANGE_PASSWORD], { queryParams: { firstPwdChange: CommonService.encryptFuntion(true) } });
          return;
        }
        // this.router.navigate([Constants.ROUTE_URL.BANK_WISE_ENROLLMENT_COUNT]);
        this.router.navigate([Constants.ROUTE_URL.ADMIN_DASHBOARD]);

        // CommonService.redirectToAdminPanel();
        return;
      } else {
        this.commonMethods.errorSnackBar(res.message);
      }
    }, error => {
      this.commonMethods.errorSnackBar(error);
    });
  }

  getCaptcha() {
    this.bankerService.getCaptcha().subscribe((res: any) => {
      if (res && res.status == 200) {
        this.captchaData = "data:image/png;base64," + JSON.parse(JSON.stringify(res)).data.bytes;
        this.currentCaptcha = atob(JSON.parse(JSON.stringify(res)).data.captchaString);
        // this.loginForm.controls.captcha.patchValue(this.currentCaptcha);
        // this.loginForm.controls.captcha.patchValue(this.currentCaptcha);
      } else {
        this.commonMethods.warningSnackBar(res.message);
      }
    }, error => {
      this.commonMethods.errorSnackBar(error);
    })
  }

  manageLocalStorage(res): boolean {
    CommonService.removeStorage(Constants.httpAndCookies.USERTYPE);
    CommonService.removeStorage(Constants.httpAndCookies.COOKIES_OBJ);
    this.userResponse = res;
    CommonService.setStorage(Constants.httpAndCookies.USERTYPE, this.userResponse.userType);
    CommonService.setStorage(Constants.httpAndCookies.USER_ID, this.userResponse.userId);
    if (!CommonService.isObjectNullOrEmpty(this.userResponse.userRoleId) && !CommonService.isObjectNullOrEmpty(this.userResponse.userOrgId)) {
      CommonService.setStorage(Constants.httpAndCookies.ROLEID, this.userResponse.userRoleId);
      CommonService.setStorage(Constants.httpAndCookies.ORGID, this.userResponse.userOrgId);
    }
    if (!CommonService.isObjectNullOrEmpty(this.userResponse.userRoleId)) {
      CommonService.setStorage(Constants.httpAndCookies.ROLEID, this.userResponse.userRoleId);
    }
    // save data in Localstorage
    const isSaved: boolean = CommonService.setSessionAndHttpAttr(btoa(this.userResponse.userName), this.userResponse, this.userResponse.loginToken);
    this.getAdminPermission();
    this.getUsernameAndApiKey();
    return isSaved;
  }

  getAdminPermission() {
    let roleId = CommonService.getStorage(Constants.httpAndCookies.ROLEID, true);
    let request = { userRoleIdString: roleId };
    this.userService.getAdminPermission(request).subscribe(success => {
      if (this.commonService.isObjectNullOrEmpty(success.data)) {
        // this.commonService.errorSnackBar("Something went wrong!!!")
        return;
      }
      CommonService.setStorage('AdminPermission', success.data);
    }, error => {
      this.commonService.errorSnackBar(error);
    });
  }
  getUsernameAndApiKey(){
    this.adminService.getUsernameAndApiKey().subscribe(res => {
      if (res && res.data) {
        this.apiKey = JSON.parse(res.data);
        const pub_obj: any = {};
        pub_obj[Constants.httpAndCookies.PUB_APIKEY] = this.apiKey.api_key;
        pub_obj[Constants.httpAndCookies.PUB_USERNAME] = this.apiKey.user_name;
        CommonService.setStorage(Constants.httpAndCookies.PUB_OBJ, JSON.stringify(pub_obj));
      }
    });
  }
}
