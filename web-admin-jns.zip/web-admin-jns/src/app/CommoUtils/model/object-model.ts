export class ObjectModel {
    key!: string;
    value!: string | boolean | number;
}
