import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { RestUrl } from 'src/app/CommoUtils/resturl';
import { HttpService } from 'src/app/CommoUtils/common-services/http.service';
import { CommonService } from './common-services/common.service';

@Injectable({ providedIn: 'root' })
export class UserProfileService {
    constructor(private http: HttpService) { }

    // getAll() {
    //     return this.http.get<User[]>(`/api/login`);
    // }

    getAdminPermission(request): Observable<any> {
        return this.http.post(RestUrl.GET_ADMIN_PERMISSION, request);
    }

    getAllMenuForBanker(): Observable<any> {
        return this.http.get(RestUrl.GET_ALL_MENU_FOR_BANKER, false, false);
    }

    getUserDetails(): Observable<any> {
        return this.http.get(RestUrl.GET_USER_DETAILS, false);
    }
    getRoleProductMapping(): Observable<any> {
        return this.http.get(RestUrl.GET_ROLE_PRODUCT_MAPPING, false);
    }
    getScemeProductMapping(businessType): Observable<any> {
        return this.http.get(RestUrl.GET_SCHEME_PRODUCT_MAPPING + CommonService.encryptFuntion(businessType), false);
    }
    fetchPublishApiAuditDetailList(data: any): Observable<any> {
        return this.http.post(RestUrl.SP_GET_PUBLISH_AUDIT_APP_LIST, data);
    }
    fetchRegistryApiAuditDetailList(data: any): Observable<any> {
        return this.http.post(RestUrl.SP_GET_REGISTRY_AUDIT_APP_LIST, data);
    }
    fetchClaimDashboardList(data: any): Observable<any> {
        return this.http.post(RestUrl.FETCH_CLAIM_DASHBOARD_LIST, data);
    }
    apiList(): Observable<any> {
        return this.http.get(RestUrl.FETCH_PYTHON_API_LIST,false);
    }

    updateEmail(request): Observable<any> {
        return this.http.post(RestUrl.UPDATE_EMAIL, request);
    }
    updateMobile(request): Observable<any> {
        return this.http.post(RestUrl.UPDATE_MOBILE, request);
    }
    lockUnlockUser(data): Observable<any> {
        return this.http.post(RestUrl.LOCK_USER, data, true);
      }

}