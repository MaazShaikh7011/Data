import { Constants } from "./common-services/constants";

const baseUrl = Constants.IS_GATEWAY && Constants.GatewayAppendUrl.includes(Constants.LOCATION_URL) ?
    Constants.LOCATION_URL + '/gateway' : Constants.LOCATION_URL;

// const dmsbaseUrl = Constants.LOCATION_URL;
// const adminPanelUrlTemp = 'http://localhost:8064/admin-panel';
// const bankApiUrlTemp = 'http://localhost:8053/bankapi';
// const userCreationTemp = 'http://localhost:8061/user-management/v3';
// const userMgmt = 'http://localhost:8061';
// const insuranceUrl = 'http://localhost:8060/insurance';
// const dms = 'http://localhost:8052';
// const ddregistry = 'http://localhost:8070';
//  const localSystem = 'http://192.168.0.162:8060';
// const publishURL = 'http://localhost:8050';
//  const registryUrlTemp = 'http://localhost:8065/api/registry';
// const ddregistryUrlTemp= 'http://localhost:8070' + '/dd/registry/jns';
//  const users = 'http://localhost:8059';
//const insuranceUrl = 'http://192.168.1.117:8060/insurance';


const reportUrl = baseUrl + '/report';
const insuranceUrl = baseUrl + '/insurance';
const userUrl = baseUrl + '/users/v3';
const userCreation = baseUrl + '/user-management/v3';
const schemeUrl = baseUrl + '/scheme';
const adminPanelUrl = baseUrl + '/admin-panel';
const proposalViewUrl = baseUrl + '/proposal';
const scoringUrl = baseUrl + '/scoring';
const productUrl = baseUrl + '/product';
const bankerReportUrl = baseUrl + '/banker-report';
const oneFormMasterUrl = baseUrl + '/oneform/master';
const oneFormMasterUrls = baseUrl + '/oneform/v3/master';
const dmsUrl = baseUrl + '/dms';
const loanretailsUrl = baseUrl + '/loans/retail';
const loanAgriUrl = baseUrl + '/loans/agri';
const loanMsmeUrl = baseUrl + '/loans/msme';
const loanLivelihoodUrl = baseUrl + '/loans/lhd';
const loansUrl = baseUrl + '/loans';
const downloadUrl = baseUrl + '/dn/jns';

const publishUrl = baseUrl + '/api/jns';
const registryUrl = baseUrl + '/api/registry';
const ddregistryUrl = baseUrl + '/dd/registry/jns';
const cibilMsmeUrl = baseUrl + '/cibil/msme';
const cibilAgriUrl = baseUrl + '/cibil/agri';
const cibilRetailUrl = baseUrl + '/cibil/retail';
const cibilLivelihoodUrl = baseUrl + '/cibil/lhd';
const bankApiUrl = baseUrl + '/bankapi';

export const RestUrl = {
    LOGIN: userUrl + '/login',
    ACCESS_TOKEN: userUrl + '/accessToken',
    LOGOUT_USER: userUrl + '/logoutUser',
    GET_CAPTCHA: userUrl + '/signup/captcha/gen',

    DOWNLOAD_DOCUMENT_BY_DOCUMENT_MAPPING_ID: dmsUrl + "/v3/downloadDocumentByDocumentMappingId",
    GET_DOCUMENT_ZIP: dmsUrl + '/v3/getDocumentZip',
    // SP_GET_APPLICATION_LIST: insuranceUrl + '/v1/reports/fetchIssuedAndSavedEnrollmentAppList',
    SP_GET_APPLICATION_LIST: adminPanelUrl + '/v3/fetchApplicationList',

    GET_USERS_DETAILS: adminPanelUrl + '/v3/getUserDetails',

    GET_NOTIFICATION_AUDIT: adminPanelUrl + '/v3/getNotificationAudit',

    SAVE_SUPPORT_AUDIT: adminPanelUrl + '/v3/insertSupportAudit',
    FETCH_TOKEN_DATA: adminPanelUrl + '/v3/getUserTknMappingLst/',

    // SP_GET_APPLICATION_CLAIM_LIST: reportUrl + '/fetchSavedClaimAppList',
    SP_GET_APPLICATION_CLAIM_LIST: adminPanelUrl + '/v3/fetchClaimAppList',

    SP_GET_PUBLISHED_APP_LIST: adminPanelUrl + '/v3/fetchEnrollmentList',
    SP_GET_PUBLISHED_CLAIM_LIST: adminPanelUrl + '/v3/fetchClaimList',

    GET_PUBLISHED_FORM_APP_LIST: publishUrl + '/publish/getEnrollmentDetail',
    GET_PUBLISHED_FORM_CLAIM_LIST: publishUrl + '/publish/getClaimDetail',
    GET_PUBLISHED_DOCUMENT_ZIP: publishUrl + '/publish/getUploadedDocuments',

    SP_GET_SCHEME_LIST: adminPanelUrl + '/v3/fetchMasterData',
    // GET_CUSTOMER_DETAILS_LIST: insuranceUrl + '/v1/enrollment/getApplicationFormDetails/',
    GET_CUSTOMER_DETAILS_LIST: adminPanelUrl + '/v3/getApplicationAllDetails/',
    GET_CUSTOMER_DETAILS_Master_LIST: adminPanelUrl + '/v3/getCustomerMasterDetailsList/',
    FETCH_ENROLLMENT_DATA: insuranceUrl + '/v3/enrollment/fetchEnrollmentDetails/',
    FETCH_ALL_URN: insuranceUrl + '/v3/enrollment/fetchAllUrnByUrnAndStageId',
    // GET_CUSTOMER_CLAIM_DETAILS_LIST: insuranceUrl + '/v1/claim/fetchViewClaimDetailsByApplicationId/',
    GET_CUSTOMER_CLAIM_DETAILS_LIST: insuranceUrl + '/v3/claim/getAllClaimDetail/',
    GET_DOCUMENTLIST_BY_APPID: adminPanelUrl + '/v3/getDocumentListByAppId',
    GET_DOCUMENTLIST_BY_CLAIMREF_ID: adminPanelUrl + '/v3/getDocumentListByCliamRefId',
    // GET_USER_ORGANIZATION_LIST: admin + '/spUserOrganizationList',
    GET_USER_ORGANIZATION_LIST: adminPanelUrl + '/v3/spUserOrganizationList',
    SP_GET_INSURER_DETAIL_LIST: adminPanelUrl + '/v3/fetchInsurerMstDetailList',
    GET_YEARS_LIST: adminPanelUrl + '/v3/getYearsList',
    // GET_BRANCH_LIST: userCreation + '/user/getBranchList',
    GET_BRANCH_LIST: adminPanelUrl + '/v3/getBranchList',

    GET_ORGANIZATION_LIST: userCreation + '/getOrganizationList',
    // GET_BANKER_USER_LIST: userCreation + '/getNewUsersList',
    GET_BANKER_USER_LIST: adminPanelUrl + '/v3/fetchBankUserList',

    GET_DOWNLOAD_FAILED_APPLICATION_LIST: downloadUrl + '/getFailedDownloadApplicationList',
    REGENERATE_DOWNLOAD_REPORT: downloadUrl + '/generateEnrollmentCsvFromScheduler',
    SP_GET_AUDIT_APPLICATION_LIST: adminPanelUrl + '/v3/fetchBankApiAuditDetailList',
    SP_GET_AUDIT_WEBHOOK_APPLICATION_LIST: adminPanelUrl + '/v3/fetchWebhookApiAuditDetailList',
    GET_RES_RES_BUCKET: bankApiUrl + '/opl/bucket/deseriablize/',
    GET_RES_WB_RES_BUCKET: registryUrl + '/opl/bucket/deseriablize/',
    GET_NOTIFICATION_COUNT: adminPanelUrl + '/v3/fetchNotificationCount',
    DOWNLOAD_NOTIFICATION_LIST: adminPanelUrl + '/v3/downloadNotificationList',
    GET_ALL_INSURER_COUNT: adminPanelUrl + '/v3/fetchAllInsurerCount',
    SP_GET_PUBLISH_AUDIT_APP_LIST: adminPanelUrl + '/v3/fetchPublishApiAuditDetailList',

    GET_PUBLISH_REQ_RES: adminPanelUrl + '/v3/getPublishReqRes/',
    GET_REGISTRY_REQ_RES: adminPanelUrl + '/v3/getRegistryReqRes/',

    SP_GET_REGISTRY_AUDIT_APP_LIST: adminPanelUrl + '/v3/fetchRegistryApiAuditDetailList',
    GET_DD_REGISTRY_REQ_RES: ddregistryUrl + '/audit/getDDRegistryReqRes/',
    GET_ADMIN_USER_LIST: adminPanelUrl + '/v3/spAdminUserList',
    GET_ERROR_STAGE_LIST: adminPanelUrl + '/spStageUserList',
    FETCH_DDREGISTRY_AUDIT_DETAILS: adminPanelUrl + '/v3/fetchAuditDetails',
    FETCH_PYTHON_API_LIST: ddregistryUrl + '/audit/apiList',
    GET_CERTI_DATA: insuranceUrl + '/v3/enrollment/generateCOI',
    GET_ALL_ORG_LIST: adminPanelUrl + '/v3/api/getAllApiUserList',
    ENC_DEC_DATA: adminPanelUrl + '/v3/api/encryptDecryptData',
    // For validations
    // GET_VALIDATIONS: userUrl + '/getAllValidations/',
    GET_ADMIN_PERMISSION: userUrl + '/getAdminPermissions',
    GET_USER_DETAILS: userUrl + '/getUserDetailsById',
    GET_ALL_MENU_FOR_BANKER: userUrl + '/getAllMenuForBanker',
    BANK_LIST: userUrl + '/org/getAllByOrgType',
    UPDATE_EMAIL: userUrl + '/updateEmailByUserId',
    UPDATE_MOBILE: userUrl + '/updateMobileByUserId',
    LOCK_USER: userCreation + '/updateIsLocked',

    GET_ROLE_PRODUCT_MAPPING: userUrl + '/roleProductMap/getByUserId',
    GET_SCHEME_PRODUCT_MAPPING: userUrl + '/roleProductMap/getByBusinessType/',
    UPDATE_ROLE_BUSINESS_TYPE: userUrl + '/updateRoleAndBusinessTypeId',
    UPDATE_GRIEVANCES_REMARK: userUrl + '/grievances/updateRemark',

    GET_USER_BUSINESS_TYPE_LIST: userCreation + '/getUserBusinessTypeList',

    GETLOANMASTERLIST: schemeUrl + '/application/getLoanMasterList',
    GETSCHEMELIST: schemeUrl + '/application/getSchemeListByLoanType',

    GET_LOAN_APPLCIATION_DETAIL: adminPanelUrl + '/dashboard/getLoanApplicationDetail',
    GET_APPLICATION_STAGES_DETAIL: adminPanelUrl + '/dashboard/getApplicationStagesDetail',

    GET_DASHBORAD_WIDGET_COUNT: proposalViewUrl + '/hl/getDashboradWidgetCount',

    // Customer-Record
    GET_CUSTOMER_RECORD_LIST: adminPanelUrl + '/dashboard/spCustomerRecord',
    GET_CUSTOMER_DETAILS: adminPanelUrl + '/dashboard/spCustomerDetails',
    GET_ELIGIBLE_AND_IN_ELIGIBLE_RESPONSE: adminPanelUrl + '/dashboard/spEligibleAndInEligibleResponse',
    GET_SCORING_CALCULATIONS_DETAILS: adminPanelUrl + '/dashboard/spScoringCalculations',
    GET_ELIGIBILITY_CALCULATIONS_DETAILS: adminPanelUrl + '/dashboard/spEligibilityCalculations',
    GET_USER_PERSONAL_DETAILS: adminPanelUrl + '/spUserDetails',
    GET_UPDATE_IS_LOCK: userCreation + '/userIsLocked',
    USER_RESET_PASSWORD: userCreation + '/userGenerateAndResetPassword',
    GET_APP_PROD_MATCHES_DATA: adminPanelUrl + '/dashboard/spAppProdMatchesData',
    GET_PROPOSAL_DETAILS: adminPanelUrl + '/dashboard/getProposalDetails',
    GET_BANKER_USER_LOGS_DETAILS: adminPanelUrl + '/dashboard/spBankerUserLogsList',
    GET_BANKER_USER_REQ_RES_LOGS_DETAILS: adminPanelUrl + '/dashboard/spBankerUserReqResLogsList',
    GET_REQ_RES_LOGS_DATA: adminPanelUrl + '/dashboard/getReqResData',
    GET_SCHEME_WISE_API_CALLS_DATA: adminPanelUrl + '/dashboard/getSchemeWiseApiCallsData',
    GET_BILLING_COUNTS: adminPanelUrl + '/dashboard/getBillingCounts',
    GET_THIRD_PARTY_INFO: adminPanelUrl + '/dashboard/getThirdPartyInfo',
    GET_THIRD_PARTY_COUNT: adminPanelUrl + '/dashboard/spGetThirdPartyCount',
    // GET_THIRD_PARTY_COUNT: 'http://localhost:8990/admin-panel' + '/dashboard/spGetThirdPartyCount',

    //branch transfer
    UPDATE_BRANCHID: baseUrl + "/loans/proposal/updateBranchId",
    UPDATE_BRANCHID_MULTIPLE_APPLICATION: baseUrl + "/loans/proposal/updateBranchIdForMultipleApplication",
    SEARCH_BRANCH_LIST_BASED_ON_CODE_OR_NAME: userUrl + '/get/searchBranchListFromCodeOrName',

    // api-dashboard
    GET_API_DASHBOARD_COUNT: adminPanelUrl + '/dashboard/spAPIDashboardCount',

    // system OTP
    GET_SYSTEM_OTP: adminPanelUrl + '/dashboard/getSystemOtp',

    // set Permission
    //GET_ORGANIZATION_LIST: userCreation + '/getOrganizationList',
    GET_ROLE_MASTER_LIST: userCreation + '/user/getUserRoleMasterList',
    GET_PARTNER_MASTER_LIST: userCreation + '/user/getPartnerRoleMasterList',
    GET_ADMIN_ROLE_MASTER_LIST: userCreation + '/user/getAdminUserRoleMasterList', // today
    GET_PERMISSION_MASTER_LIST: userCreation + '/user/getPermissionMasterList',
    GET_PERMISSION_MAPPING_LIST: userCreation + '/user/getPermissionMappingList',
    SAVE_PERMISSION: userCreation + '/user/setPermission',
    GET_MENU_MASTER: userCreation + '/user/getMenuMaser',
    GET_MENU_MAPPING_LIST: userCreation + '/user/getMenuMappingList',
    SAVE_MENU_MAPPING_LIST: userCreation + '/user/saveMenuMappingList',
    SAVE_MENU: userCreation + '/user/saveMenu',
    DELETE_MENU: userCreation + '/user/deleteMenu',
    GET_ADMIN_PERMISSION_MASTER_LIST: userCreation + '/user/getAdminPermissionMasterList', // masterlist

    // user admin
    //GET_ADMIN_USER_LIST: adminPanelUrl + '/dashboard/spAdminUserList',
    GET_ADMIN_MENU_MASTER: userCreation + '/user/getAdminMenuMaser',
    GET_ADMIN_MENU_MAPPING_LIST: userCreation + '/user/getAdminMenuMappingList',
    SAVE_ADMIN_PERMISSION: userCreation + '/user/saveAdminPermission',
    SAVE_USER_ADMIN: userCreation + '/saveUserAdmin',

    FETCH_PAN_AADHAR_DE_DUPLICATION: loansUrl + '/loans/fetchPanAadharDeDuplication',

    // save Organization
    // GET_USER_ORGANIZATION_LIST: adminPanelUrl + '/dashboard/spUserOrganizationList',
    SAVE_ORGANIZATION: userCreation + '/saveOrganization',

    SET_ORG_PERMISSION: adminPanelUrl + '/dashboard/spSetBasicPermissionToOrg',
    IS_ACTIVE_ORGANIZATION: userCreation + '/isActiveOrg',

    // banker user list
    //GET_BANKER_USER_LIST: adminPanelUrl + '/dashboard/spBankerUserList',
    // GET_OTHER_USER_LIST: adminPanelUrl + '/spOtherUserList',
    GET_OTHER_USER_LIST: adminPanelUrl + '/v3/spOtherUserList',

    // Partner user list
    GET_PARTNER_USER_LIST: adminPanelUrl + '/dashboard/spPartnerUserList',
    GET_PARTNER_APPLICATIONS: adminPanelUrl + '/dashboard/spPartnerApplicationsList',
    //GET_OTHER_USER_LIST: adminPanelUrl + '/dashboard/spOtherUserList',

    //Stp Gateway List
    GET_STP_GATEWAY_LIST: adminPanelUrl + '/dashboard/spStpGatewayDetails',
    GET_STP_API_AUDITS: adminPanelUrl + '/dashboard/spStpApiAudits',

    //Bureau Config Active Inactive List
    GET_BUREAU_CONFIG_ACTIVE_INACTIVE_LIST: adminPanelUrl + '/dashboard/spBureauConfigActiveInactiveList',

    // cibil logs list
    GET_CIBIL_LOGS_LIST: adminPanelUrl + '/dashboard/spGetCibiLogs',

    // create new Users
    GET_USER_BO_LIST: userCreation + '/getAllBOList',
    GET_USER_RO_LIST: userCreation + '/getUserROList',
    GET_USER_ZO_LIST: userCreation + '/getUserZOList',
    CHECK_USER_MOBILE: userCreation + '/checkMobile',
    CREATE_USER: userCreation + '/updateUser',
    GET_USER_DETAILS_LIST: userCreation + '/getUserDetailsList',
    ACTIVE_IS_ACTIVE_USER: userCreation + '/activeIsActiveUser',
    USER_ROLE_TYPE: userCreation + '/getRoleTypeList',

    // product
    GET_PRODUCT_LIST: adminPanelUrl + '/dashboard/spFetchProductList',
    GET_PRODUCT_BY_ID: productUrl + "/get/",
    GET_PRODUCT_MASTER_VIEW_DATA: productUrl + "/getProdViewData/",
    GET_SCALING_MATRIX_MASTER_BY_PRODUCT_ID: productUrl + "/scaling/getScalingMatrixMasterByProductId",
    GET_CURRENT_BASE_RATE: productUrl + "/baseRate/getCurrentEffectiveBaseRate",
    GET_ELIGIBILITY_MODEL_MASTER_BY_ID: productUrl + '/eligibility/getEligibilityModelMasterById/',
    PRODUCT_BY_SCORE_ID: productUrl + '/getProductByScoringId/',

    //scoring
    GET_SCORING_LIST: adminPanelUrl + '/dashboard/spFetchScoringList',
    GET_SCORING_MODEL: scoringUrl + '/getScoringModel/',

    GET_GRIEVANCES_LIST: adminPanelUrl + '/dashboard/spFetchGrievances',

    // common select filter list
    GET_FILTER_LIST: adminPanelUrl + '/v3/fetchMasterData',
    SEND_MAIL_WITH_REPORT: bankerReportUrl + '/sendMailWithReport',
    UPLOAD_TRANSACTION_REPORT_FILE_UPLOAD: bankerReportUrl + '/uploadTransactionReportFile',

    // admin Management
    GET_ADMIN_MENU_PERMISSION_MAPPING_LIST: userCreation + '/user/getAdminMenuPermissionMappingList',
    SAVE_ADMIN_MENU_PERMISSION: userCreation + '/user/saveAdminMenuPermission',
    SAVE_ADMIN_BASIC_PERMISSION: userCreation + '/user/saveAdminBasicPermission',

    // Branch List
    //GET_BRANCH_LIST: adminPanelUrl + '/dashboard/getBranchList',
    IS_ACTIVE_BRANCH: userCreation + '/isActiveBranch',
    GET_BRANCH_AUDIT_LIST: baseUrl + "/loans/proposal/getBranchAuditList",

    //create Branch
    GET_ALL_OFFICE_LIST: userCreation + '/getAllOfficeTypeList',
    GET_ZO_LIST: userCreation + '/getAllZoList',
    GET_HO_LIST: userCreation + '/getAllHoList',
    GET_RO_LIST: userCreation + '/getAllRoList',
    GET_STATE_LIST: oneFormMasterUrls + '/getStateListByCountryId/',
    GET_CITY_LIST: oneFormMasterUrls + '/getCityListByStateId/',
    GET_LGD_STATE_LIST: oneFormMasterUrls + '/getLgdStateList',
    GET_LGD_DISTRICT_LIST: oneFormMasterUrls + '/getLgdCityListByLgdStateId/',
    SAVE_NEW_BRANCH: userCreation + '/saveBranchDetail',
    EDIT_BRANCH_DETAILS: userCreation + '/editBranchDetail',
    GET_SINGLE_BO_DETAIL: userCreation + '/getSingleBo',

    // download file
    DOWNLOAD_ALL_ZIP_FILE: dmsUrl + "/v3/downloadAll",

    // All CAM Report
    DOWNLOAD_EDU_CAM_REPORT: loanretailsUrl + '/getEduCamReport/',
    DOWNLOAD_HOME_CAM_REPORT: loanretailsUrl + '/getHomeLoanCamReport/',
    DOWNLOAD_AGRI_ACABC_CAM_REPORT: loanAgriUrl + '/getAgriCamReport/',
    DOWNLOAD_AGRI_AMI_CAM_REPORT: loanAgriUrl + '/getAmiCamReport/',
    DOWNLOAD_SWMS_CAM_REPORT: loanMsmeUrl + "/getSWMSCamReport/",
    DOWNLOAD_MUDRA_CAM_REPORT: loanMsmeUrl + "/getMudraCamReport/",
    DOWNLOAD_LIVELIHOOD_CAM_REPORT: loanLivelihoodUrl + '/getLivelihoodCamReport/',
    DOWNLOAD_SRMS_CAM_REPORT: loanMsmeUrl + '/getSrmsCamReport/',
    DOWNLOAD_SUIC_CAM_REPORT: loanMsmeUrl + "/getStandUpCamReport/",
    DOWNLOAD_AGRI_AIF_CAM_REPORT: loanAgriUrl + '/getAifCamReport/',
    DOWNLOAD_NRLM_CAM_REPORT: loanLivelihoodUrl + '/getNrlmCamReport/',
    DOWNLOAD_KCC_CAM_REPORT: loanAgriUrl + '/kccAgriCamReport/',

    // All Application Form
    DOWNLOAD_EDU_APPLICATION_FORM: loanretailsUrl + '/getEduApplicationForm/',
    DOWNLOAD_HOME_APPLICATION_FORM: loanretailsUrl + '/getApplicationForm/',
    DOWNLOAD_ACABC_APPLICATION_FORM: loanAgriUrl + '/getAcabcApplicationForm/',
    DOWNLOAD_AMI_APPLICATION_FORM: loanAgriUrl + '/getAmiApplicationForm/',
    DOWNLOAD_SWMS_APPLICATION_FORM: loanMsmeUrl + '/getSwmsApplicationForm/',
    DOWNLOAD_MUDRA_APPLICATION_FORM: loanMsmeUrl + '/getMudraApplicationForm/',
    DOWNLOAD_LIVELIHOOD_APPLICATION_FORM: loanLivelihoodUrl + '/getLivelihoodApplicationForm/',
    DOWNLOAD_SRMS_APPLICATION_FORM: loanMsmeUrl + '/getSrmsApplicationForm/',
    DOWNLOAD_SUIC_APPLICATION_FORM: loanMsmeUrl + '/getStandUpApplicationForm/',
    DOWNLOAD_AIF_APPLICATION_FORM: loanAgriUrl + '/getAifApplicationForm/',
    DOWNLOAD_NRLM_APPLICATION_FORM: loanLivelihoodUrl + '/getNrlmApplicationForm/',
    DOWNLOAD_KCC_APPLICATION_FORM: loanAgriUrl + '/getKccApplicationForm/',

    DOWNLOAD_CMA_EXCEL_FILE: loanAgriUrl + '/common/downloadExcelFile',
    DOWNLOAD_BUSINESS_CMA_EXCEL_FILE: baseUrl + '/itr/msme/cma/downloadCMAAndCoCMAExcelFile',

    //change Org And Branch
    CHANGE_ORG_AND_BRANCH: userCreation + '/user/changeOrgIdAndBranchIdAndRoleId',

    // Create Borrower
    CREATE_BORROWER: adminPanelUrl + '/dashboard/createBorrower',

    // SAVE AND GET BUREAU DEAILS
    SAVE_CIBIL_PERMISSION_MSME: cibilMsmeUrl + '/msme/saveBuereauPermission',
    SAVE_CIBIL_PERMISSION_RETAIL: cibilRetailUrl + '/msme/saveBuereauPermission',
    SAVE_CIBIL_PERMISSION_AGRI: cibilAgriUrl + '/msme/saveBuereauPermission',
    SAVE_CIBIL_PERMISSION_LHD: cibilLivelihoodUrl + '/msme/saveBuereauPermission',

    // GET BUREAU DETAILS
    GET_BUREAU_MASTER_LIST_MSME: cibilMsmeUrl + '/msme/getBureauPermissionMasterList',
    GET_BUREAU_MASTER_LIST_RETAIL: cibilRetailUrl + '/msme/getBureauPermissionMasterList',
    GET_BUREAU_MASTER_LIST_AGRI: cibilAgriUrl + '/msme/getBureauPermissionMasterList',
    GET_BUREAU_MASTER_LIST_LHD: cibilLivelihoodUrl + '/msme/getBureauPermissionMasterList',

    // change password after login
    RESET_PASSWORD_AFTER_LOGIN: userUrl + '/set/passwordAfterLogin',

    // get Count Bank and Schemewise
    GET_COUNT_SCHEME_AND_BANKWISE: adminPanelUrl + '/dashboard/spGetCountSchemeAndBankWise',

    //push pull engine calls
    CREATE_BANKWISE_USER: adminPanelUrl + '/dashboard/createBankWiseUser',
    UPDATE_BANKWISE_USER: adminPanelUrl + '/dashboard/updateBankWiseUser',

    GET_BUREAU_MASTER_LIST: cibilMsmeUrl + '/msme/getBureauPermissionMasterListForParticularOrgId',
    SAVE_CIBIL_PERMISSION: cibilMsmeUrl + '/msme/saveBureauPermissionForParticularOrgId',

    // push-pull-api
    GET_ERROR_LOG_DASHBOARD: adminPanelUrl + '/v3/fetchApplicationHistory',
    GET_FAILED_APPLICATION_DETAIL: adminPanelUrl + '/dashboard/getFailedApplicationDetails',
    DO_RETRY_COUNT: adminPanelUrl + '/dashboard/doRetrySave',

    // change admin User Role
    CHANGE_ADMIN_USER_ROLE: userCreation + '/user/changeAdminUserRole',
    GET_STAGE_AUDIT_LIST: adminPanelUrl + '/dashboard/spGetStageAudit',
    GET_SCHEME_LIST: adminPanelUrl + '/dashboard/getSchemeList',
    GET_API_LIST: adminPanelUrl + '/dashboard/getApiListBySchemeId',
    SAVE_API_DATA: adminPanelUrl + '/dashboard/saveApiData',
    GET_ANS_PROPERTIES: adminPanelUrl + '/dashboard/getAnsConfig',
    SAVE_ANS_PROPERTIES: adminPanelUrl + '/dashboard/saveAnsConfig',
    GET_NAME_MATCH: adminPanelUrl + '/dashboard/getNameMatchPecAndSchemeList',
    SAVE_NAME_MATCH: adminPanelUrl + '/dashboard/saveNameMatchPec',
    GET_PMAY_STATUS_LIST: adminPanelUrl + '/dashboard/spGetPMAYStatusList',
    GET_BANK_SPECIFIC_LIST: adminPanelUrl + '/dashboard/getAllProposalList',
    // GET_COMMON_PROPOSAL_LIST: adminPanelUrl + '/dashboard/spGetCommonProposalList',
    GET_ALL_PROPOSAL_DATA: loansUrl + '/proposal/spGetCommonProposalList',

    // ------------------------CAMPAIGN CONFIGURATION------------------------------------------
    GET_CAMPAIGN_LIST: adminPanelUrl + '/dashboard/getCampaignList',
    UPDATE_CAMPAIGN_CODE: adminPanelUrl + '/dashboard/updateCampaignCode',
    GET_CAMPAIGN_BY_ID: adminPanelUrl + '/dashboard/getCampaignById',
    GET_IN_ELIGIBLE_LIST: adminPanelUrl + '/dashboard/spGetInEligibleReason',

    COPY_PRODUCT_TO_OTHER_ORG: productUrl + '/temp/coyProductToOtherOrg',
    GET_ANS_SERVICES: adminPanelUrl + '/dashboard/getAnsServices',
    PING_ANS_SERVICES: adminPanelUrl + '/dashboard/pingAnsServices',

    SP_GET_NEW_DASHBOARD_USER_AND_APPLICATION_BAR_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardUserAndApplicationBarChart',
    SP_GET_NEW_DASHBOARD_APPLICATION_DETAILS_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardApplicationDetailsPieChart',
    SP_GET_NEW_DASHBOARD_SCHEMEWISE_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardSchemeWisePieChart',
    SP_GET_NEW_DASHBOARD_LOANWISE_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardLoanWisePieChart',
    SP_GET_NEW_DASHBOARD_BANKWISE_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardBankWisePieChart',
    SP_GET_NEW_DASHBOARD_DAY_MONTH_WISE_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardDayMonthWiseBarChart',
    SP_GET_NEW_DASHBOARD_APPROVE_REFERRED_BAR_CHART: adminPanelUrl + '/dashboard/spGetApproveReferredFilterBarChart',
    SP_GET_NEW_DASHBOARD_CITY_STATE_WISE_PIE_CHART: adminPanelUrl + '/dashboard/spGetNewDashBoardCityStateWisePieChart',

    GET_RO_ZO_DETAILS_BY_RO_ZO_ID: userCreation + '/getRoZoDetailsByRoZoId',

    GET_PROPOSAL_BUTTONS: baseUrl + "/loans/proposal/getProposalButtons",
    GET_PROPOSAL_DISBURSE_DETAILS: loansUrl + "/proposal/disburseDetails",
    UPDATE_PROPOSAL_STATUS: loansUrl + "/proposal/updateProposalStatus",

    GET_SCHEME_LIST_FOR_ADMIN: userCreation + '/getschemeListForAdmin',

    //common

    // GET_ALL_USER_TYPE: adminPanelUrl + '/v3/getAllUserType',
    GET_ALL_USER_TYPE: userCreation + '/getUserTypeMasterList',
    // GET_ALL_SCHEME: adminPanelUrl + '/getAllScheme',
    GET_ALL_SCHEME: adminPanelUrl + '/v3/getAllScheme',
    GET_ALL_INSURER: adminPanelUrl + '/getAllInsurer',

    GET_API_CONFIG_MASTER: adminPanelUrl + '/v3/getApiConfigMaster',
    GET_CONFIG_MASTER: adminPanelUrl + '/v3/getConfigMaster',
    GET_TYPE_MASTER: adminPanelUrl + '/v3/getTypeMasterForDms',
    GET_DOCUMENT_MASTER: adminPanelUrl + '/v3/getDocumentMasterForDms',
    GET_PREMIMUM_MASTER: adminPanelUrl + '/v3/getPreMimumMaster',
    SAVE_CONFIG_MASTER: adminPanelUrl + '/v3/saveConfigMaster',
    ACTIVE_IS_CONFIG_USER: adminPanelUrl + '/v3/activeIsConfigMaster',
    GET_CONFIG_LIST_BY_ID: adminPanelUrl + '/v3/getConfigListById',

    //master
    GET_MASTER_LIST_BY_KEY: oneFormMasterUrls + '/getMasterListByKey',
    SAVE_API_USRR: adminPanelUrl + '/v3/api/saveApiUser',
    GET_ORG_LIST_BY_APIMASTERID: adminPanelUrl + '/v3/api/getOrgMasterListByApimasterId',
    FETCH_API_USER_LIST: adminPanelUrl + '/v3/api/fetchApiUser',
    GET_API_USER: adminPanelUrl + '/v3/api/getApiUserList',
    ACTIVE_IS_API_USER: adminPanelUrl + '/v3/api/activeIsApiUser',

    //Report
    FETCH_BANK_WISE_APP_LIST: adminPanelUrl + '/v3/fetchAppBankWiseCount',
    FETCH_ORGID_APP_LIST: adminPanelUrl + '/v3/fetchAppOrgIdwiseCount',
    FETCH_BANK_WISE_CLIAM_LIST: adminPanelUrl + '/v3/fetchClaimBankWiseCount',
    FETCH_ORGID_CLIAM_LIST: adminPanelUrl + '/v3/fetchclaimOrgIdwiseCount',
    GET_USERNAME_APIKEY: adminPanelUrl + '/v3/getUsernameAndApiKey',
    FETCH_CLAIM_DASHBOARD_LIST: reportUrl + '/fetchClaimList',
    FETCH_ENROLLMENT_LIST: adminPanelUrl + '/v3/spFetchAdminEnrollmentList',
    GET_POLICY_BAR_CHART_ORG_WISE: adminPanelUrl + '/v3/getGetPolicyBarChartOrgWise',
    GET_POLICY_BAR_CHART_INSURER_WISE: adminPanelUrl + '/v3/getGetPolicyBarChartInsurerWise',
    GET_POLICY_BAR_CHART_BANK_LIVE_DATA: adminPanelUrl + '/v3/spFetchEnrollmentCount',
    // API_DESERIABLIZE: publishUrl + '/opl/bucket/deseriablize/',
    // REGISTRY_DESERIABLIZE: registryUrl + '/opl/bucket/deseriablize/'

    FETCH_COI_PUSH_ALL_COUNTS: adminPanelUrl + '/v3/fetchCoiPushAllCounts',
    GET_BUCKET_LOG_DETAILS: baseUrl,
    FETCH_NOTIFICATION_LIST: adminPanelUrl + '/v3/fetchNotificationList',
    FETCH_ORG_INSURANCE_WISE_LIST: adminPanelUrl + '/v3/fetchOrgAndInsuranceWiseCount',
    FETCH_CITY_WISE_LIST: adminPanelUrl + '/v3/fetchCityWiseData',
    FETCH_CITY_WISE_POLICY_LIST: adminPanelUrl + '/v3/fetchCityWiseForPolicy',
    FETCH_POSTMAN_RESPONSE: adminPanelUrl + '/v3/fetchPostmanResponse',
    FETCH_BANK_WEBHOOK_REQ: adminPanelUrl + '/v3/fetchBankWebhookRequest',
    FETCH_JAN_API_REQ: adminPanelUrl + '/v3/fetchJanApiRequest',
    GET_API_USER_BY_ORGID: adminPanelUrl + '/v3/api/getApiUserListByOrgId',
    GET_FETCH_CLAIM_REPORTS: adminPanelUrl + '/v3/fetchClaimReports',
    FETCH_PUSH_FAIL_LIST: adminPanelUrl + '/v3/fetchPushFailList',
    PUSH_BANK_AND_INSURER: publishUrl + '/push/v3/pushBankAndInsurer',

};
