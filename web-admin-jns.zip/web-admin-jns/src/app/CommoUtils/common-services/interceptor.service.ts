import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { finalize, catchError, map } from 'rxjs/operators';
import { AesGcmEncryptionService } from 'src/app/service/encryption/aes-gcm-encryption.service';
import { CommonMethods } from './common-methods';
import { CommonService } from './common.service';
import { Constants } from './constants';
import { LoaderService } from './LoaderService';

/**
 *  Note intercepter for filter web service Like header add skip URl from Headers etc.
 */
@Injectable()
export class InterceptorService implements HttpInterceptor {
  private requests: HttpRequest<any>[] = [];
  constructor(private loaderService: LoaderService, private commonMethod: CommonMethods) { }

  // Handle request for loader spin
  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    if (i >= 0) {
      this.requests.splice(i, 1);
    }
    this.loaderService.isLoading.next(this.requests.length > 0);
  }

  // call interceptor and add token parameter into request
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any> | any> {
    const headers = req.headers;
    //console.log('url=====>',req.url);
    if (!this.isHeaderSkipUrls(req.url)) {// for skip URL
      const cookiesObj = JSON.parse(CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true));
      if (cookiesObj != null && cookiesObj !== undefined) {
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.USNM, cookiesObj[Constants.httpAndCookies.USNM]) });
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.ACTK, cookiesObj[Constants.httpAndCookies.ACTK]) });
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.LGTK, cookiesObj[Constants.httpAndCookies.LGTK].toString()) });
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.RFTK, cookiesObj[Constants.httpAndCookies.RFTK]) });
        if (this.isSkipEncryption(req.url)) {
          req = req.clone({ headers: req.headers.set('is_decrypt', 'true') });
        }
        // req = req.clone({ headers: req.headers.set('req_auth', 'true') });
      } else {
        this.hideLoader();
        console.log('You are not authorised person');
      }
    }
    // if(this.isSkipEncryption(req.url)){
    //   req = req.clone({ headers: req.headers.set('isDecrypt', 'true') });
    // }
    if (this.isSetUserName(req.url)) {
      //   req = req.clone({ headers: req.headers.set('user-name', 'Z2JTcjBtT0g5QTdyRlJLc1D1wXV8qiXlNdKRgPtdk2I=') });
      //  req = req.clone({ headers: req.headers.set('api-key', '89aff97e-3423-4050-a0f8-fb378dcf71b0') });
      const pubObj = JSON.parse(CommonService.getStorage(Constants.httpAndCookies.PUB_OBJ, true));
      if (pubObj != null) {
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.PUB_USERNAME, pubObj[Constants.httpAndCookies.PUB_USERNAME]) });
        req = req.clone({ headers: req.headers.set(Constants.httpAndCookies.PUB_APIKEY, pubObj[Constants.httpAndCookies.PUB_APIKEY]) });
      }
      req = req.clone({ headers: req.headers.set('skipEnc', 'true') });
      req = req.clone({ headers: req.headers.set('isDecrypt', 'true') });
      //  req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
      // req = req.clone({ headers: req.headers.set('req_auth', 'true') });
    }
    if (this.isSetBucketByPass(req.url)) {
      req = req.clone({ headers: req.headers.set('ZHAyOWhWNXhGK2o4MEg4NiS5WwUVUKNXy82ZixoEYXo', 'true') }); // for publish API
      req = req.clone({ headers: req.headers.set('req_auth', 'true') }); // for internal api
    }
    const startTime = Date.now();
    let status: string;
    if (Constants.IS_ENCRYPTION && !this.isSkipEncryption(req.url)) {
      if (req.body != null && !(req.body instanceof FormData) && !(req.body instanceof Array)) {
        // req = req.clone({ body: { data: CommonService.encryptText(req.body) } })
        req = req.clone({ body: { data: AesGcmEncryptionService.getEncPayload(JSON.stringify(req.body)) } })
      }
    }

    // Hide loader
    if (headers.has('ignoreLoader') && (headers.get('ignoreLoader') === 'false')) {
      req = req.clone({ headers: req.headers.delete('ignoreLoader', 'false') });
      this.hideLoader();
    } else {
      this.requests.push(req);
    }
    return next.handle(req).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          status = 'succeeded';
          this.removeRequest(req);
          if (Constants.IS_ENCRYPTION && !this.isSkipEncryption(req.url)) {
            if (event.body != null && event.body.encData != undefined && event.body.encData != null) {
              // let data = CommonService.decryptText(event.body.encData);
              let data = AesGcmEncryptionService.getDecPayload(event.body.encData);
              event = event.clone({ body: JSON.parse(data.toString()) })
            }
          }
          // console.log('event--->>>', event);
          return event;
        } else {
          const elapsedTime = Date.now() - startTime;
          const message = req.method + ' ' + req.urlWithParams + ' ' + status + ' in ' + elapsedTime + 'ms';
          this.logDetails(message);
          // this.removeRequest(req);
          return null;
        }
      }, catchError(error => {
        status = 'Error';
        this.removeRequest(req);
        return this.handleError(error);
      })), finalize(() => {
        const elapsedTime = Date.now() - startTime;
        const message = req.method + ' ' + req.urlWithParams + ' ' + status + ' in ' + elapsedTime + 'ms';
        this.logDetails(message);
        this.removeRequest(req);
        // this.hideLoader();
      }));
  }

  // For Skip URLS
  isHeaderSkipUrls(url: string): boolean {
    if (url.endsWith('.json') || url.endsWith('/maintenance') ||
      url.endsWith('/login')
      || url.endsWith('/forgotpassword')
      || url.includes('/forgotpasswordEncrypt')
      || url.endsWith('.json')
      || url.endsWith('/otp')
      || url.endsWith('/resend')
      || url.endsWith('/checkOtpVarification')
      || url.endsWith('/linkVerification')
      || url.endsWith('/password')
      || url.endsWith('/register')
      || url.endsWith('/getLoanMasters')
      || url.endsWith('/saveCustomForm')
      || url.includes('/scheme/application/getLoan')
      || url.includes('/getAllValidations/')
      || url.endsWith('/getLoanFilledData')
      || url.endsWith('/saveEligibility')
      || url.endsWith('/maintenance')
      || url.includes('/getStateList/satateByCountry')
      || url.includes('/getCityList/cityByState')
      || url.includes('/updateEligibilityUser')
      || url.includes('/captcha/gen')
      || url.includes('/new')
      || url.includes('/setPass')
      || url.includes('/verifyOTP')
      || url.includes('/sendEmailOTP')
      || url.includes('/resendMobileOTP')
      || url.includes('/skipEmailVerification')
      // || url.endsWith('/publish/fetchEnrollmentList')
      // || url.endsWith('/publish/fetchClaimList')
      || url.includes('/getEnrollmentDetail')
      || url.includes('/getClaimDetail')
      // || url.endsWith('/fetchPublishApiAuditDetailList')
      // || url.endsWith('/fetchRegistryApiAuditDetailList')
      || url.endsWith('/getUploadedDocuments')
      // || url.includes('/getPublishReqRes')
      // || url.includes('/getRegistryReqRes')
    ) {
      return true;
    } else {
      return false;
    }
  }

  // For Skip Encryption URLS
  isSkipEncryption(url: string): boolean {
    if (url.endsWith('/spGetCommonProposalList')
      || url.endsWith('/spGetStageAudit')
      || url.endsWith('spStpGatewayDetails')
      // || url.endsWith('/publish/fetchEnrollmentList')
      // || url.endsWith('/publish/fetchClaimList')
      // || url.endsWith('/fetchPublishApiAuditDetailList')
      // || url.endsWith('/fetchRegistryApiAuditDetailList')
      || url.endsWith('/getUploadedDocuments')
      || url.includes('/getPublishReqRes')
      || url.includes('/getRegistryReqRes')
      || url.includes('/push/v3/pushBankAndInsurer')
    )
      return true;
    else
      return false;
  }

  isSetUserName(url: string): boolean {
    if (
      // url.endsWith('/publish/fetchEnrollmentList')
      // || url.endsWith('/publish/fetchClaimList')
      url.includes('/getEnrollmentDetail')
      || url.includes('/getClaimDetail')
      // || url.endsWith('/fetchPublishApiAuditDetailList')
      // || url.endsWith('/fetchRegistryApiAuditDetailList')
      || url.endsWith('/getUploadedDocuments')
      // || url.includes('/getPublishReqRes')
      // || url.includes('/getRegistryReqRes')
    )
      return true;
    else
      return false;
  }

  isSetBucketByPass(url: string): boolean {
    if (url.includes('/opl/bucket/deseriablize')
      || url.includes('/push/v3/pushBankAndInsurer'))
      return true;
    else
      return false;
  }

  handleError(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      console.log(error.status);
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    this.commonMethod.errorHandle(error);
    // window.alert(errorMessage);
    console.log(errorMessage);
    return throwError(errorMessage);
  }

  private logDetails(msg: string) {
    //console.log(msg);
  }

  private hideLoader(): void {
    this.loaderService.hide();
  }
}
