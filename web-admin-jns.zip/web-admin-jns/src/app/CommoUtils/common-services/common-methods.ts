import { Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { throwError } from 'rxjs';
import { Constants } from './constants';
import { SnackbarService } from './SnackbarService';
import { CommonService } from './common.service';
import { ObjectModel } from '../model/object-model';
import * as _ from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class CommonMethods {
    validations: any;
    validationsobj: any;
    constructor(private snackbar: SnackbarService, private modalService: NgbModal) { }

    detectIEEdge() {
        var ua = window.navigator.userAgent;

        var msie = ua.indexOf('MSIE ');
        if (msie > 0) {
            // IE 10 or older => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
        }

        var trident = ua.indexOf('Trident/');
        if (trident > 0) {
            // IE 11 => return version number
            var rv = ua.indexOf('rv:');
            return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
        }

        var edge = ua.indexOf('Edge/');
        if (edge > 0) {
            // Edge => return version number
            return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        }

        // other browser
        return false;
    }

    /**
  * For handle error and display error msg
  */
    errorHandle(error: any) {
        let errMsg = '';
        console.error('errMsg ->', errMsg);
        if (errMsg == null) {
            console.error('Error Logs Not Found ', errMsg);
            return errMsg;
        }
        if (error.status === 401) {
            window.location.href = Constants.LOCATION_URL + '/admin-web' + '/login'
            // window.location.href = 'http://localhost:2500/login';
            localStorage.clear();
            errMsg = 'You are not authorised';
        } else if (error.status === 404) {
            if (error.message !== undefined && error.message != null) {
                errMsg = error.message;
            } else {
                errMsg = 'Method Not found';
            }
        } else if (error.status === 400) {
            if (error.message !== undefined && error.message != null) {
                errMsg = error.message;
            } else {
                errMsg = 'Bad Request';
            }
        } else if (error.status === 0) {
            errMsg = 'Internal Server error';
        } else if (error.status === 500) {
            if (error.message !== undefined && error.message != null) {
                errMsg = error.message;
            } else {
                errMsg = 'Internal Server error';
            }
        } else if (error.status === 502) {
            errMsg = 'Server is not responding';
        } else {
            if (error.error !== undefined && error.error != null) {
                errMsg = error.error.message;
            } else {
                errMsg = 'Something went wrong';
            }
            if (errMsg === '') {
                errMsg = 'Something went wrong';
            }
        }
        this.errorSnackBar({ message: errMsg });
        return throwError(errMsg);
    }

    /**
      * For display Toaster msg in right side
      */
    successSnackBar(message: any, action?: any): any {
        this.snackbar.openSnackBar(message, action, 'success');
    }
    errorSnackBar(message: any, action?: any): any {
        this.snackbar.openSnackBar(message, action, 'error');
    }
    warningSnackBar(message: any, action?: any): any {
        this.snackbar.openSnackBar(message, action, 'warning');
    }
    infoSnackBar(message: any, action?: any): any {
        this.snackbar.openSnackBar(message, action, 'info');
    }
    defaultSnackBar(message: any, action?: any): any {
        this.snackbar.openSnackBar(message, action, '');
    }

    /**
      * Open PopUp
      */
    openPopUp(obj: any, popUpName: any, isYesNo: any, objClass?: any) {
        // and use the reference from the component itself

        const modalRef = this.modalService.open(popUpName, objClass);
        modalRef.componentInstance.popUpObj = obj;
        modalRef.componentInstance.isYesNo = isYesNo; // if isYesNo true than display both buttons
        return modalRef;
    }

    // Get Validations By Module name
    getValidationByModule(moduleName): any {
        const listdata = CommonService.parseData(CommonService.getStorage('validations', true)) as any;
        CommonService.setStorage('module_val', null);
        if (!CommonService.isObjectNullOrEmpty(listdata)) {
            this.validations = listdata.filter(option => option.module.startsWith(moduleName));
            if (this.validations[0].fieldList != null) {
                CommonService.setStorage('module_val', JSON.stringify(this.validations[0].fieldList));
            }
        }
    }


    // Dynamic Validations
    getValidations(labelOrKeyName: string): Array<ObjectModel> {
        const listdata = CommonService.parseData(CommonService.getStorage('module_val', true)) as any;
        if (!CommonService.isObjectNullOrEmpty(listdata)) {
            const fieldValidations = listdata.filter(option => option.label.startsWith(labelOrKeyName));
            if (fieldValidations != null || fieldValidations !== undefined) {
                if (fieldValidations[0] != null || fieldValidations[0] !== undefined) {
                    return fieldValidations[0].validations;
                }
            }
        }
        return [];
    }

    // Given Error Msg customised
    getErrorMessage(labelOrKeyName: string, propertyName): string {
        const listdata = JSON.parse(CommonService.getStorage('module_val', true)) as any;
        if (!CommonService.isObjectNullOrEmpty(listdata)) {
            const fieldValidations = listdata.filter(option => option.label.startsWith(labelOrKeyName));
            if (fieldValidations != null || fieldValidations !== undefined) {
                if (fieldValidations[0] != null || fieldValidations[0] !== undefined) {
                    const errormsgObj = fieldValidations[0].validations.filter(msg => msg.key === propertyName)[0];
                    return errormsgObj !== undefined ? errormsgObj.errorMassage : null;
                }
            }
        }
        return null;
    }

    public copyToClipBoard(data, isJson?) {
        if (data) {
            const adminPermissionList = _.split(CommonService.getStorage('AdminPermission', true), ',');
            const index: number = adminPermissionList.indexOf('IS_COPY');
            document.addEventListener('copy', (e: ClipboardEvent) => {
                e.clipboardData.setData('text/plain', isJson ? JSON.stringify(data) : (index != -1) ? data : '');
                e.preventDefault();
                document.removeEventListener('copy', null);
            });
            document.execCommand('copy');
            isJson ? this.successSnackBar("String Copied") : (index != -1) ? this.successSnackBar("Copied") : undefined;
        }
        else {
            this.warningSnackBar("data not Found")
        }
    }

    public getYearMonthDateFormate(date) {
        const tempDate = date.split('-');
        return { year: +tempDate[2], month: +tempDate[1], day: +tempDate[0] };
    }

    downloadPdfFromBase64toFile(base64, fileName?) {
        const byteString = window.atob(base64);
        const int8Array = new Uint8Array(new ArrayBuffer(byteString.length));
        for (let i = 0; i < byteString.length; i++) {
            int8Array[i] = byteString.charCodeAt(i);
        }
        const anchor = document.createElement('a');
        anchor.download = (fileName ? fileName : 'document') + ".pdf";
        anchor.href = window.URL.createObjectURL(new Blob([int8Array], { type: 'application/pdf' }));
        anchor.click();
    }
    downloadPdf(res, fileName?) {
        const blob = new Blob([res], { type: 'application/pdf' });
        const downloadUrl = window.URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.download = fileName ? fileName : 'document.pdf';
        anchor.href = downloadUrl;
        anchor.click();
    }

    
}
