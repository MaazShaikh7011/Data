const mainPath = '/';
export const Constants = {
    LOCATION_URL: window.location.protocol + '//' + window.location.hostname,
    // LOCATION_URL: 'https://qa-jns.instantmseloans.in',
    // LOCATION_URL: 'https://uat-jns.instantmseloans.in',
    // LOCATION_URL: 'https://jansuraksha.in',
    IS_GATEWAY: false,
    IS_ENCRYPTION: true,
    cwjs: '26f1ac75f77c22ebc66e2359c13ea9955ebd5e2bd7fbe50e5b3ac2977a772302',

    GatewayAppendUrl: [
    ],


    httpAndCookies: {
        ACTK: 'tk_ac',
        RFTK: 'tk_rc',
        USNM: 'ur_cu',
        LGTK: 'tk_lg',
        COOKIES_OBJ: 'ck_obj',
        USERTYPE: 'usr_type',
        USER_ID: 'userId',
        ORGID: 'usr_orgId',
        FS_USER_ID: 'fsUserId',
        ROLEID: 'usr_role_id',
        PROFILE_ID: 'profileId',
        TMP_PROFILE_ID: 'tmpProfileId',
        CAMPIGN_CODE: 'campaignCode',
        CAMPIGN_TYPE: 'type',
        App_Count: 'applicationCount',
        VALIDATIONS: 'validations',
        FACILITATOR_ID: 'facilitatorId',
        BUSINESS_TYPE_ID: 'business_type_id',
        SCHEME_ID: 'scheme_id',
        LOAN_TYPE_ID: 'loan_type_id',
        USER_PERMISSION: 'up_data',
        USER_NAME: 'user_name',
        APPLICATION_ID: 'application_id',
        PUB_OBJ: 'pub_obj',
        PUB_APIKEY: 'api-key',
        PUB_USERNAME: 'user-name',
    },

    BussinessType: {
        EXISTING_BUSINESS: 1,
        NEW_TO_BUSINESS: 2,
        RETAIL_PERSONAL_LOAN: 3,
        ONE_PAGER: 4,
        RETAIL_HOME_LOAN: 5,
        MFI: 6,
        AGRICULTURE: 11,
        LIVELIHOOD_LOAN: 12,
        RETAIL_EDUCATION_LOAN: 9,
        MUDRA_LOAN: 10,
    },

    ROUTE_URL: {
        LOGIN: mainPath + 'login',
        MAIN_DASHBOARD: mainPath + 'Admin/mainDashboard',
        REQUEST_VIEW: mainPath + 'Admin/requestView',
        AP_LOANAPPLICATION: mainPath + 'Admin/AP-LoanApplication',
        ADMIN_DASHBOARD: mainPath + 'Admin/Admin-Dashboard',
        CHANGE_PASSWORD: mainPath + 'Change-PassWord',
        BANK_API_AUDIT: mainPath + 'Bank-Api-Audit',
        BANK_WISE_ENROLLMENT_COUNT: mainPath + 'Admin/adminDashboard',
    },

    LoanType: {
        HOME_LOAN: 3,
        EDUCATION_LOAN: 8,
        WORKING_CAPITAL: 1,
        TERM_LOAN: 2,
        BUSINESS_ACTIVITY: 4,
        AGRICULTURE_INFRASTRUCTURE: 6,
        LIVELIHOODS_LOAN: 5
    },

    GstTypeId: {
        REGULAR: 1,
        COMPOSITE: 2,
        GST_NOT_APPLICABLE: 3
    },
    GstTypes: {
        REGULAR: 'Regular',
        COMPOSITE: 'Composition'
    },
    SUCCESS_MESSAGE: 'Saved Successfully',
    PRODUCT_ID: 'productId',

    UserType: {
        BORROWER: 1,
        BANKER: 2,
        NODEL_AGENCY: 3,
        MINISTRY: 4,
        MASTER_ADMIN: 6,
        FACILITATOR: 7,
        ADMIN_MASTER: 5,

    },

    UserTypeList: [
        { id: 1, name: 'Borrower' },
        { id: 2, name: 'Banker' },
        { id: 3, name: 'Nodal Agency' },
        { id: 4, name: 'Ministry' },
        { id: 6, name: 'Master Admin' },
        { id: 7, name: 'Facilitator' },
    ],

    UserTypeVal: {
        FS: { id: 1, name: 'Borrower' },
        PN: { id: 7, name: 'Partner' },
    },

    CurrentStages: {
        GST: 0,
        ITR: 1,
        ONE_FORM: 2,
        MATCHES: 3,
        CIBIL: 4,
        IN_PRENCIPAL: 5,
        COMPLETED: 6,
        // NTB stages
        NTB_ITR: 101,
        NTB_ONE_FORM: 102,
        NTB_MATCHES: 103,
        NTB_CIBIL: 104,
        NTB_IN_PRENCIPAL: 105,
        NTB_COMPLETED: 106,
    },

    STAGE: {
        MSME: {
            GST: 0,
            ITR: 1,
            BANK_STATEMENT: 2,
            DIRECTOR: 3,
            ONE_FORM: 4,
            MATCHES: 5,
            PAYMENT: 6,
            COMPLETED: 7,
            MCQ: 8,
            IN_PRENCIPLE: 9,
            NBFC_MATCHES: 10,
            BRANCH_SELECTION: 11,
            IN_ELIGIBILE: 12,
        }
    },

    JOURNEY_COMPLETED_STAGE: {
        EDU: 15,
        HOME: 14,
        MSME: 13,
        AGRI: 13,
        LIVELIHOOD: 11,
    },

    ScreenMaster: {
        LARGE_DESKTOP: 1,
        MIDUME_DESKTOP: 2,
        MOBILE: 3
    },

    validationModule: {
        REGISTER: "registered",
        LOGIN: "login",
    },

    MaintenaceType: {
        Marquee: 1,
        Page: 2,
    },

    CurrentJourneyStages: {
        MCQ: 1,
        IDENTITY_VERIFICATION: 2,
        PERSONAL_DETAILS: 3,
        CONSENT: 4,
        BUREAU_DETAILS: 5,
        ITR: 6,
        BANK_STATEMENT: 7,
        LOAN_DETAILS: 8,
        CREDIT_DETAILS: 9,
        UPLOAD_DOCUMENTS: 10,
        CO_APPLICANT_CREATION: 11,
        STAGE_LIST: 12,
        MATCHES: 13,
        BRANCH_SELECTION: 14,
        COMPLETED: 15
    },

    CoApplicantStages: {
        IDENTITY_VERIFICATION: 1,
        PERSONAL_DETAILS: 2,
        CONSENT: 3,
        BUREAU_DETAILS: 4,
        ITR: 5,
        BANK_STATEMENT: 6,
        CREDIT_DETAILS: 7,
        UPLOAD_DOCUMENTS: 8,
        COMPLETED: 9
    },

    SCHEME: {
        CSIS: 1,
        PADHO: 2,
        DR_AMBEDKAR: 3,
        HOME: 4,
        PMEGP: 5,
        ACABC: 6,
        AMI: 7,
        SWMS: 8,
        MUDRA: 9,
        PM_SVANIDHI: 10,
        NULM: 11,
        SRMS: 12,
        STAND_UP: 13,
        NRLM: 14,
        AIF: 15,
        KCC: 16
    },

    SchemeMaster: {
        CENTRAL_SECTOR_INTEREST_SUBSIDY: { id: 1, loanMasterId: 8, name: "Central Sector Interest Subsidy", code: "CSIS", businessTypeId: 9 },
        PADHO_PRADESH: { id: 2, loanMasterId: 8, name: "Padho Pardesh", code: "Padho Pardesh", businessTypeId: 9 },
        DR_AMBEDKAR_CENTRAL_SECTOR_SCHEME: { id: 3, loanMasterId: 8, name: "Dr. Ambedkar Central Sector Scheme", code: "DACSS", businessTypeId: 9 },
        PRADHAN_MANTRI_AWAS_YOJANA: { id: 4, loanMasterId: 3, name: "Pradhan Mantri Awas Yojana", code: "PMAY", businessTypeId: 5 },
        PRIME_MINISTER_EMPLOYMENT_GENERATION_PROGRAMME: { id: 5, loanMasterId: 6, name: "Prime Minister's Employment Generation Programme", code: "PMEGP", businessTypeId: 11 },
        AGRICLINICS_AGRIBUSINESS_CENTERS_SCHEME: { id: 6, loanMasterId: 6, name: "Agri Clinics And Agri Business Centers Scheme", code: "ACABC", businessTypeId: 11 },
        AGRICULTURAL_MARKETING_INFRASTRUCTURE: { id: 7, loanMasterId: 6, name: "Agricultural Marketing Infrastructure", code: "AMI", businessTypeId: 11 },
        WEAVER_CREDIT_CARD: { id: 8, loanMasterId: 4, name: "Weaver Mudra Scheme", code: "WMS", businessTypeId: 1 },
        PRADHAN_MANTRI_MUDRA_YOJNA: { id: 9, loanMasterId: 4, name: "Pradhan Mantri MUDRA Yojna", code: "PMMY", businessTypeId: 1 },
        PM_SVANIDHI: { id: 10, loanMasterId: 4, name: 'Pradhan Mantri Street Vendor Aatmanirbhar Svanidhi Scheme', code: 'PM SVANidhi', businessTypeId: 1 },
        NULM: { id: 11, loanMasterId: 12, name: 'Deendayal Antyodaya Yojana-NATIONAL Urban Livelihoods Mission', code: 'DAY-NULM', businessTypeId: 12 },
        SRMS: { id: 12, loanMasterId: 4, name: 'Self Employment Scheme for Rehabilitation of Manual Scavengers', code: 'SRMS', businessTypeId: 1 },
        STAND_UP_INDIA_SCHEME: { id: 13, loanMasterId: 4, name: "Stand Up India Scheme", code: "SUIS", businessTypeId: 1 },
        DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION: { id: 14, loanMasterId: 12, name: 'Deendayal Antyodaya Yojana - National Rural Livelihoods Mission', code: 'DAY-NRLM', businessTypeId: 12 },
        AGRICULTURE_INFRASTRUCTURE_FUND: { id: 15, loanMasterId: 6, name: 'Agriculture Infrastructure Fund', code: 'AIF', businessTypeId: 11 },
        KISAN_CREDIT_CARD: { id: 16, loanMasterId: 6, name: 'Kisan Credit Card', code: 'KCC', businessTypeId: 11 },
    },

    businessMaster: [
        { id: -1, name: 'All Loans' },
        { id: 9, name: 'Education Loan' },
        { id: 5, name: 'Home Loan' },
        { id: 1, name: 'Business Loan' },
        { id: 11, name: 'Agriculture Loan' },
        { id: 12, name: 'Livelihood Loan' },
    ],

    searchUserType: [
        { id: 1, name: 'Email Id' },
        { id: 2, name: 'Mobile Number' },
        { id: 3, name: 'URN' },
        { id: 4, name: 'ApplicationId' },
        { id: 6, name: 'Username' }
    ],

    suportAuditAction: {
        EMAIL_EDIT: 1,
        MOBILE_NO_EDIT: 2,
        USER_LOCK_UNLOCK: 3,
        PASSWORD_RESET: 4
    },

    schemeMasterList: [
        { id: -1, name: 'All Scheme', businessId: -1 },
        { id: 1, name: 'Central Sector Interest Subsidy', businessId: 9 },
        { id: 2, name: 'Padho Pardesh', businessId: 9 },
        { id: 3, name: 'Dr. Ambedkar Central Sector Scheme', businessId: 9 },
        { id: 4, name: 'Pradhan Mantri Awas Yojana', businessId: 5 },
        { id: 5, name: 'Prime Minister\'s Employment Generation Program', businessId: 1 },
        { id: 6, name: 'Agriclinics And Agribusiness Centers Scheme', businessId: 11 },
        { id: 7, name: 'Agricultural Marketing Infrastructure', businessId: 11 },
        { id: 8, name: 'Weaver Mudra Scheme', businessId: 1 },
        { id: 9, name: 'Pradhan Mantri MUDRA Yojna', businessId: 1 },
        { id: 10, name: 'Pradhan Mantri Street Vendor Aatmanirbhar Svanidhi Scheme', businessId: 1 },
        { id: 11, name: 'Deendayal Antyodaya Yojana - National Urban Livelihoods Mission', businessId: 12 },
        { id: 12, name: 'Self Employment Scheme for Rehabilitation of Manual Scavengers', businessId: 1 },
        { id: 13, name: 'Stand Up India Scheme', businessId: 1 },
        { id: 14, name: 'Deendayal Antyodaya Yojana - National Rural Livelihoods Mission', businessId: 12 },
        { id: 15, name: 'Agriculture Infrastructure Fund', businessId: 11 },
        { id: 16, name: 'Kisan Credit Card', businessId: 11 },
    ],

    menuPathMaster: [
        { menuId: 1, path: '/Admin/AP-LoanApplication' },
        { menuId: 36, path: '/Admin/Customer-Record' },
        { menuId: 37, path: '/Admin/requestView' },
        { menuId: 39, path: '/Admin/Api-DashBoard' },
        { menuId: 40, path: '/Admin/Set-Permission' },
        { menuId: 41, path: '/Admin/Admin-User-List' },
    ],

    adminRoleMaster: [
        { id: 101, roleName: 'Admin Master' },
        { id: 102, roleName: 'Admin Developers' },
        { id: 103, roleName: 'Admin Product Team' },
        { id: 104, roleName: 'Admin Qa Team' },
        { id: 105, roleName: 'Admin Team Lead' },
    ],

    businessType: {
        All_LOANS: -1,
        EDUCATION_LOAN: 9,
        HOME_LOAN: 5,
        BUSINESS_LOAN: 1,
        PERSONAL_LOAN: 3,
        MUDRA_LOAN: 10,
        AGRI_LOAN: 11,
        LIVELYHOOD_LOAN: 12
    },

    responceType: [
        { id: 1, name: 'Success' },
        { id: 2, name: 'User Failure' },
        { id: 3, name: 'Error' },
    ],

    countType: [
        { id: 1, name: 'Online' },
        { id: 2, name: 'Offline' },
        { id: 3, name: 'Total' },
    ],

    campaignType: [
        { id: 1, name: 'Market Place' },
        { id: 2, name: 'Bank Specific' },
    ],

    branchType: [
        { id: 1, name: 'Branch Office' },
        { id: 2, name: 'Regional Office' },
        { id: 3, name: 'Zonal Office' },
        { id: 6, name: 'Local Head Office' },
    ],

    stageOptionsList: [
        { id: 1, name: 'In Progress' },
        { id: 2, name: 'Completed' },
        { id: 3, name: 'Cancalled' }
    ],

    proposalDetailsList: [
        { id: 1, name: 'Bank Details' },
        { id: 2, name: 'Branch Details' },
        { id: 3, name: 'RO Details' },
        { id: 4, name: 'ZO Details' },
        { id: 5, name: 'Sanctioned Details' },
        { id: 6, name: 'Disbusment Details' },
        { id: 7, name: 'User Details' },
        { id: 8, name: 'Document Upload Details' },
    ],

    proposalStatusMaster: [
        { id: 1, name: 'Completed' },
        { id: 2, name: 'Sanctioned' },
        { id: 3, name: 'Disbursed' },
        { id: 4, name: 'Reject' },
        { id: 5, name: 'Hold' },
        { id: 6, name: 'Hold After Sanction' },
        { id: 7, name: 'Reject After Sanction' },
        { id: 8, name: 'Partial Disburse' },
        { id: 9, name: 'Sanctioned By Other Bank' },
        { id: 10, name: 'Reject Offline Configuration' },
    ],

    proposalDoneThrough: [
        { id: 1, name: 'Regular Borrower Journey' },
        { id: 2, name: 'Assisted Journey' }
    ],

    dateTypeList: [
        { id: 1, name: 'Journey Completion Date' },
        { id: 2, name: 'Last Change Date' },
        { id: 3, name: 'First Disbursement Entry Date' },
    ],
    dateFormat: {
        DDMMYYYY: "dd/MM/yyyy",
        DDMMYYYYHHMMSS: "dd/MM/yyyy HH:mm:ss",
    },

    HoldRejectReason: [
        'Customer not reachable',
        'Customer is not ready to provide collateral security',
        'Customer wants higher loan amount than his or her eligibility',
        'Customer provided wrong information or data on the portal',
        'Delinquency observed in customers credit bureau report',
        'Customer is located outside branch jurisdiction or service area',
        'Customer is maintaining account with another bank',
        'Customer has availed other facilities from other bank',
        'Customer not interested in availing loan',
        'Customer not able to provide required documents',
        'Customer not eligible under the scheme',
        'Loan purpose does not eligible under the scheme',
        'Customer income is not as per scheme criteria'
    ],

    REGEX_TYPE: [
        { id: 1, value: /[^0-9]/g, desc: 'Number Only' },
        { id: 2, value: /[^A-Za-z]/g, desc: 'Alphabetic Only' },
        { id: 3, value: /[^A-Za-z0-9]/g, desc: 'Alphanumeric Only' },
        { id: 4, value: /[^a-zA-Z\s]/g, desc: 'Alphabetic With Space Only' },
        { id: 5, value: /[^A-Za-z0-9\s]/g, desc: 'Alphanumeric With Space Only' },
        { id: 6, value: /[\s]/g, desc: 'No-Space Only' },
        { id: 7, value: /[^0-9\s]/g, desc: 'Numeric and Space Only' },
        { id: 8, value: /[^0-9.]/g, desc: 'Number with Decimal Only' },
    ],

    ReportMaster: {
        PROPOSAL_LIST: { id: 1, reportName: "Proposal List", spName: "spGetCommonProposalDetails" }
    },

    ClaimMaster: {
        CLAIM_IN_PROGRESS: { id: 5, value: "Claim In Progress" },
        CLAIM_SEND_TO_INSURER: { id: 6, value: "Claim Send to Insurer" },
        CLAIM_SEND_BACK_BY_INSURER: { id: 7, value: "Claim Send back by insurer" },
        CLAIM_REJECTED: { id: 8, value: "Claim Rejected" },
        CLAIM_HOLD: { id: 9, value: "Claim Hold" },
        CLAIM_ACCEPTED: { id: 10, value: "Claim Accpeted" },
        TOTAL_CLAIM_AMOUNT: { id: 11, value: 200000 },
        PMSBY_DISABLITY_CLAIM_AMOUNT: { id: 12, value: 100000 }
    },

    schemeList: [
        { id: -1, loanMasterId: -1, name: "All scheme", code: "All scheme", businessTypeId: -1 },
        { id: 1, loanMasterId: 1, name: "Pradhan Mantri Suraksha Bima Yojana", code: "PMSBY", businessTypeId: 1 },
        { id: 2, loanMasterId: 1, name: "Pradhan Mantri Jeevan Jyoti Bima Yojana", code: "PMJJBY", businessTypeId: 1 },
    ],
    ApiMaster: [
        { id: 1, name: 'Bank API' },
        { id: 2, name: 'Publish API' },
        { id: 3, name: 'Other Channel API' },
    ],
    stageMaster: {
        CREATED: { id: 1, value: "Created" },
        OTP_PHYSICAL_VERIFICATION: { id: 2, value: "Otp / Physical Verification" },
        ACCOUNT_HOLDER_SELECTION: { id: 3, value: "account Holder Selection" },
        APPLICATION_FORM: { id: 4, value: "Application Form" },
        PREMIUM_DEDUCTION: { id: 5, value: "Premium Deduction" },
        COMPLETED: { id: 6, value: "Completed" },
        EXPIRED: { id: 7, value: "Expired" },
        REJECTED: { id: 8, value: "Rejected" },
        CLAIM_REGISTRATION: { id: 10, value: "Claim Registration" },
        CLAIM_FORM: { id: 11, value: "Claim Form" },
        CLAIM_UPLOAD_DOCUMENT: { id: 12, value: "Claim Upload Document" },
        SEND_TO_INSURER: { id: 13, value: "Send To Insurer" },
        CLAIM_COMPLETED: { id: 14, value: "Claim Completed" },
        PREMIUM_DEDUCTION_FAILED: { id: 15, value: "Transaction Failed" },
    },
    statusMaster: {
        ENROLL_IN_PROGRESS: { id: 1, value: "Created (Enrollment in Progress)" },
        ENROLL_COMPLETED: { id: 2, value: "Enrolled (Enrollment Completed)" },
        ENROLL_EXPIRED: { id: 3, value: "Expired (Enrollment Expired)" },
        PARTIALLY_CLAIMED: { id: 4, value: "Partially Claimed (In case of disability)" },
        CLAIMED: { id: 5, value: "Claimed" },
        OPT_OUT: { id: 6, value: "Opt-Out" },
        ACCOUNT_INACTIVE: { id: 7, value: "Account Inactive" },
        INSUFFICIENT_BALANCE: { id: 8, value: "Insufficient Balance" },
        ACCOUNT_HOLDER_DECEASED: { id: 9, value: "Account Holder Deceased" },
        RENEWED: { id: 10, value: "Renewed" },
        DE_DUPE_FAILED: { id: 11, value: "De-dupe Failed" },
        ENROLL_REJECTED: { id: 12, value: "Rejected" },
        OPT_OUT_IN_PROCESS: { id: 13, value: "In Process Opt-Out" },
    },
    claimStatusMaster: {
        CLAIM_IN_PROGRESS: { id: 5, value: "Claim In Progress" },
        CLAIM_SEND_TO_INSURER: { id: 6, value: "Claim Send to Insurer" },
        CLAIM_SEND_BACK_BY_INSURER: { id: 7, value: "Claim Send back by insurer" },
        CLAIM_REJECTED: { id: 8, value: "Claim Rejected" },
        CLAIM_HOLD: { id: 9, value: "Claim Hold" },
        CLAIM_ACCEPTED: { id: 10, value: "Claim Accpeted" },
        CLAIM_INSURER_IN_PROGRESS: { id: 11, value: "Claim Insurer In Progress" },
        CLAIM_EXPIRE: { id: 12, value: "Expire" },
    },

    ReqUrlList: [
        { id: 1, value: 'bankapi', key: 'Bank Api' },
        { id: 2, value: 'api/registry', key: 'Other Channel Api' },
        { id: 3, value: 'api/jns', key: 'Publish Api' },
        { id: 4, value: 'dd/registry/jns', key: 'DD Registry' },
        { id: 5, value: 'notification', key: 'Notification' },
    ],
};
