import { Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as CryptoJS from 'crypto-js';
import { AesGcmEncryptionService } from 'src/app/service/encryption/aes-gcm-encryption.service';
import { Constants } from './constants';
import { SnackbarService } from './SnackbarService';
import { ActivatedRoute } from '@angular/router';

/**
 * Common services common methods for multiple time use
 */
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private modalService: NgbModal, private snackbar: SnackbarService,private activatedRoute: ActivatedRoute,) { }

  /**
   * For check null,empty and undefined
   */
  static isObjectNullOrEmpty(data: any) {
    return (data == null || data === undefined || data === '' || data === 'null' || data === 'undefined' ||
      data === '');
  }

  static isObjectIsEmpty(data: any) {
    return data && Object.keys(data).length <= 0;
  }

  encryptFunction(request) {
    if (Constants.IS_ENCRYPTION && !this.isObjectNullOrEmpty(request)) {
      // return CommonService.toBTOA(CommonService.encryptText(request));      
      return AesGcmEncryptionService.getEncPayload(request.toString());
    }
    // else {
    return request;
    // }
  }
  /**
   * for convert value(encrypt)
   */
  static toBTOA(value: string) {
    try {
      return btoa(value);
    } catch (err) {
      console.log('error while btoa convert');
      return null;
    }
  }
  getURLData(data: string) {
    return this.decryptFunction(this.activatedRoute.snapshot.queryParamMap.get(data));
  }

  decryptFunction(request) {
    if (Constants.IS_ENCRYPTION && !this.isObjectNullOrEmpty(request)) {
      // return CommonService.decryptText(CommonService.toATOB(request));
      return AesGcmEncryptionService.getDecPayload(request);
    }
    return request;
  }
  /**
   * Decrypt value
   */
  static toATOB(value: any) {
    try {
      return atob(value);
    } catch (err) {
      console.log('error while atob convert');
      return null;
    }
  }
  getStorage(key: string, decrypt: boolean) {
    const data: any = localStorage.getItem(key);
    if (this.isObjectNullOrEmpty(data)) {
      return data;
    }
    if (decrypt) {
      const decryptdata = this.decryptText(data);
      return this.isObjectIsEmpty(decryptdata) ? null : decryptdata;
    }
    return data;
  }

  decryptText(request: string): string {
    try {
      if (!this.isObjectNullOrEmpty(request)) {
        return AesGcmEncryptionService.getDecPayload(request);
      }
      return request;
    } catch (ex) {

      return JSON.parse(request);
    }
  }
  /**
   * Get value from storage
   */
  static getStorage(key: string, decrypt: boolean) {
    const data: any = localStorage.getItem(key);
    if (CommonService.isObjectNullOrEmpty(data)) {
      return data;
    }
    // console.log('Get Storege-------Key-------->' + key + '-----------Value-----> ' + data);
    if (decrypt) {
      const decryptdata = this.decryptText(data);
      // console.log('Get Storege-------Key-------->' + key + '-----------Descrypt Value-----> ' + decryptdata);
      return CommonService.isObjectIsEmpty(decryptdata) ? null : decryptdata;
    }
    return data;
  }

  /**
   * set value in storage
   */
   static setStorage(key: any, value: any): void {
    if (!CommonService.isObjectNullOrEmpty(value)) {
      value = value.toString();
      const newLocal: any = this.encryptText(value);
      localStorage.setItem(key, newLocal);
    } else {
      CommonService.removeStorage(key);
    }
  }

  /**
   * Remove value from storage
   */
  static removeStorage(key: any) {
    localStorage.removeItem(key);
  }

  static clearStorage(): void {
    localStorage.clear();
  }

  /**
   * for set Header for cookies
   */
  static setSessionAndHttpAttr(email: any, response: { access_token: any; refresh_token: any; }, loginToken: any): boolean {
    CommonService.removeStorage(Constants.httpAndCookies.COOKIES_OBJ);
    // set cookies object
    const cookies: any = {};
    const config = { secure: true };
    cookies[Constants.httpAndCookies.USNM] = email;
    cookies[Constants.httpAndCookies.ACTK] = response.access_token;
    cookies[Constants.httpAndCookies.RFTK] = response.refresh_token;
    cookies[Constants.httpAndCookies.LGTK] = loginToken;
    CommonService.setStorage(Constants.httpAndCookies.COOKIES_OBJ, JSON.stringify(cookies));
    return true;
  }

  // static redirectToAdminPanel() {
  //   let cookiesObje: any = CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true);
  //   cookiesObje = this.parseData(cookiesObje);
  //   cookiesObje.token = cookiesObje.tk_lg;
  //   cookiesObje.userType = CommonService.getStorage(Constants.httpAndCookies.USERTYPE, true);
  //   cookiesObje.roleId = CommonService.getStorage(Constants.httpAndCookies.ROLEID, true);
  //   cookiesObje.orgId = CommonService.getStorage(Constants.httpAndCookies.ORGID, true);
  //   cookiesObje.userId = CommonService.getStorage(Constants.httpAndCookies.USER_ID, true);
  //   const encObj = CommonService.toBTOA(JSON.stringify(cookiesObje));
    // const encObj=Constants.IS_ENCRYPTION ? this.encryptFuntion(JSON.stringify(cookiesObje)) : CommonService.toBTOA(JSON.stringify(cookiesObje));
  //   let redirectModule;
  //   redirectModule = '/Admin/AP-LoanApplication';
  //   window.location.href = Constants.LOCATION_URL + redirectModule;
  //   // window.location.href = 'http://localhost:4500' + redirectModule;
  // }


  openPopUp(obj: any, popUpName: any, isYesNo: any, objClass?: any) {
    // and use the reference from the component itself

    const modalRef = this.modalService.open(popUpName, objClass);
    modalRef.componentInstance.popUpObj = obj;
    modalRef.componentInstance.isYesNo = isYesNo; // if isYesNo true than display both buttons
    return modalRef;
  }

  static loadScript(url: string) {
    const body = document.body as HTMLDivElement;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }

  static downloadFile(bytes: BlobPart, fileName: any) {
    const blob = new Blob([bytes], {
      type: 'application/octet-stream'
    });
    const a: any = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display:none';
    const url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  }

  static encryptText(request: object): string {
    if(!CommonService.isObjectNullOrEmpty(request)){
      return AesGcmEncryptionService.getEncPayload(request.toString());
    }
    return null;
  }

  static decryptText(request: string): string {
    try{
      if(!CommonService.isObjectNullOrEmpty(request)){
        return AesGcmEncryptionService.getDecPayload(request);
      }
      return request;
    } catch(ex){
      console.log("Error on parse data", ex);
      return JSON.parse(request);
    }  
  }

  static getCampaignCode() {
    return CommonService.getStorage('campaignCode', true);
  }

  static setAppCount(countTOUpdate: number) {
    this.setStorage(Constants.httpAndCookies.App_Count, countTOUpdate + ""); // to preventing multiple tab issue
  }

  static getConstants() {
    return Constants;
  }

  static parseData(data) {
    try {
      return JSON.parse(data);
    } catch (ex) {
      console.log("Error on parse data", ex);
      return JSON.parse(JSON.stringify(data));
    }
  }

  static encryptFuntion(request) {
    if (Constants.IS_ENCRYPTION && !CommonService.isObjectNullOrEmpty(request)) {
      return AesGcmEncryptionService.getEncPayload(request.toString());  
    }
    return request;
  }

  static decryptFuntion(request) {
    if (Constants.IS_ENCRYPTION && !CommonService.isObjectNullOrEmpty(request)) {
     return AesGcmEncryptionService.getDecPayload(request);
    }
    return request;
  }

  /**
   * For check null,empty and undefined
   */
  isObjectNullOrEmpty(data: any) {
    return (data == null || data === undefined || data === '' || data === 'null' || data === 'undefined' ||
      data === '');
  }

  isObjectIsEmpty(data: any) {
    return data && Object.keys(data).length <= 0;
  }

  errorSnackBar(message: string, action?: undefined) {
    this.snackbar.openSnackBar(message, action, 'error');
  }

  /**
   * For display Toaster msg in right side
   */
  successSnackBar(message: any, action?: any) {
    this.snackbar.openSnackBar(message, action, 'success');
  }

  warningSnackBar(message: any, action?: any) {
    this.snackbar.openSnackBar(message, action, 'warning');
  }

  infoSnackBar(message: any, action?: any) {
    this.snackbar.openSnackBar(message, action, 'info');
  }

  static getBusinessTypeIdBySchemeId(schemeId: number): number {
    if (Constants.SchemeMaster.AGRICLINICS_AGRIBUSINESS_CENTERS_SCHEME.id == schemeId) {
      return Constants.SchemeMaster.AGRICLINICS_AGRIBUSINESS_CENTERS_SCHEME.businessTypeId;
    } else if (Constants.SchemeMaster.AGRICULTURAL_MARKETING_INFRASTRUCTURE.id == schemeId) {
      return Constants.SchemeMaster.AGRICULTURAL_MARKETING_INFRASTRUCTURE.businessTypeId;
    } else if (Constants.SchemeMaster.CENTRAL_SECTOR_INTEREST_SUBSIDY.id == schemeId) {
      return Constants.SchemeMaster.CENTRAL_SECTOR_INTEREST_SUBSIDY.businessTypeId;
    } else if (Constants.SchemeMaster.DR_AMBEDKAR_CENTRAL_SECTOR_SCHEME.id == schemeId) {
      return Constants.SchemeMaster.DR_AMBEDKAR_CENTRAL_SECTOR_SCHEME.businessTypeId;
    } else if (Constants.SchemeMaster.PADHO_PRADESH.id == schemeId) {
      return Constants.SchemeMaster.PADHO_PRADESH.businessTypeId;
    } else if (Constants.SchemeMaster.PRADHAN_MANTRI_AWAS_YOJANA.id == schemeId) {
      return Constants.SchemeMaster.PRADHAN_MANTRI_AWAS_YOJANA.businessTypeId;
    } else if (Constants.SchemeMaster.PRADHAN_MANTRI_MUDRA_YOJNA.id == schemeId) {
      return Constants.SchemeMaster.PRADHAN_MANTRI_MUDRA_YOJNA.businessTypeId;
    } else if (Constants.SchemeMaster.PRIME_MINISTER_EMPLOYMENT_GENERATION_PROGRAMME.id == schemeId) {
      return Constants.SchemeMaster.PRIME_MINISTER_EMPLOYMENT_GENERATION_PROGRAMME.businessTypeId;
    } else if (Constants.SchemeMaster.WEAVER_CREDIT_CARD.id == schemeId) {
      return Constants.SchemeMaster.WEAVER_CREDIT_CARD.businessTypeId;
    } else if (Constants.SchemeMaster.PM_SVANIDHI.id == schemeId) {
      return Constants.SchemeMaster.PM_SVANIDHI.businessTypeId;
    } else if (Constants.SchemeMaster.NULM.id == schemeId) {
      return Constants.SchemeMaster.NULM.businessTypeId;
    } else if (Constants.SchemeMaster.SRMS.id == schemeId) {
      return Constants.SchemeMaster.SRMS.businessTypeId;
    } else if (Constants.SchemeMaster.STAND_UP_INDIA_SCHEME.id == schemeId) {
      return Constants.SchemeMaster.STAND_UP_INDIA_SCHEME.businessTypeId;
    } else if (Constants.SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.id == schemeId) {
      return Constants.SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.businessTypeId;
    } else if (Constants.SchemeMaster.AGRICULTURE_INFRASTRUCTURE_FUND.id == schemeId) {
      return Constants.SchemeMaster.AGRICULTURE_INFRASTRUCTURE_FUND.businessTypeId;
    }
    return null;
  }
  getStageNameByStageId(stageId: number): String {
    if (Constants.stageMaster.CREATED.id == stageId) {
      return Constants.stageMaster.CREATED.value;
    } else if (Constants.stageMaster.OTP_PHYSICAL_VERIFICATION.id == stageId) {
      return Constants.stageMaster.OTP_PHYSICAL_VERIFICATION.value;
    } else if (Constants.stageMaster.ACCOUNT_HOLDER_SELECTION.id == stageId) {
      return Constants.stageMaster.ACCOUNT_HOLDER_SELECTION.value;
    } else if (Constants.stageMaster.APPLICATION_FORM.id == stageId) {
      return Constants.stageMaster.APPLICATION_FORM.value;
    } else if (Constants.stageMaster.PREMIUM_DEDUCTION.id == stageId) {
      return Constants.stageMaster.PREMIUM_DEDUCTION.value;
    } else if (Constants.stageMaster.COMPLETED.id == stageId) {
      return Constants.stageMaster.COMPLETED.value;
    } else if (Constants.stageMaster.EXPIRED.id == stageId) {
      return Constants.stageMaster.EXPIRED.value;
    } else if (Constants.stageMaster.REJECTED.id == stageId) {
      return Constants.stageMaster.REJECTED.value;
    } else if (Constants.stageMaster.CLAIM_REGISTRATION.id == stageId) {
      return Constants.stageMaster.CLAIM_REGISTRATION.value;
    } else if (Constants.stageMaster.CLAIM_FORM.id == stageId) {
      return Constants.stageMaster.CLAIM_FORM.value;
    } else if (Constants.stageMaster.CLAIM_UPLOAD_DOCUMENT.id == stageId) {
      return Constants.stageMaster.CLAIM_UPLOAD_DOCUMENT.value;
    } else if (Constants.stageMaster.SEND_TO_INSURER.id == stageId) {
      return Constants.stageMaster.SEND_TO_INSURER.value;
    } else if (Constants.stageMaster.CLAIM_COMPLETED.id == stageId) {
      return Constants.stageMaster.CLAIM_COMPLETED.value;
    } else if (Constants.stageMaster.PREMIUM_DEDUCTION_FAILED.id == stageId) {
      return Constants.stageMaster.PREMIUM_DEDUCTION_FAILED.value;
    }
    return null;
  }

  getStatusByStatusId(statusId: number): String {
    if (Constants.statusMaster.ENROLL_IN_PROGRESS.id == statusId) {
      return Constants.statusMaster.ENROLL_IN_PROGRESS.value;
    } else if (Constants.statusMaster.ENROLL_COMPLETED.id == statusId) {
      return Constants.statusMaster.ENROLL_COMPLETED.value;
    } else if (Constants.statusMaster.ENROLL_EXPIRED.id == statusId) {
      return Constants.statusMaster.ENROLL_EXPIRED.value;
    } else if (Constants.statusMaster.ENROLL_EXPIRED.id == statusId) {
      return Constants.statusMaster.ENROLL_EXPIRED.value;
    } else if (Constants.statusMaster.CLAIMED.id == statusId) {
      return Constants.statusMaster.CLAIMED.value;
    } else if (Constants.statusMaster.OPT_OUT.id == statusId) {
      return Constants.statusMaster.OPT_OUT.value;
    } else if (Constants.statusMaster.ACCOUNT_INACTIVE.id == statusId) {
      return Constants.statusMaster.ACCOUNT_INACTIVE.value;
    } else if (Constants.statusMaster.INSUFFICIENT_BALANCE.id == statusId) {
      return Constants.statusMaster.INSUFFICIENT_BALANCE.value;
    } else if (Constants.statusMaster.ACCOUNT_HOLDER_DECEASED.id == statusId) {
      return Constants.statusMaster.ACCOUNT_HOLDER_DECEASED.value;
    } else if (Constants.statusMaster.RENEWED.id == statusId) {
      return Constants.statusMaster.RENEWED.value;
    } else if (Constants.statusMaster.DE_DUPE_FAILED.id == statusId) {
      return Constants.statusMaster.DE_DUPE_FAILED.value;
    } else if (Constants.statusMaster.ENROLL_REJECTED.id == statusId) {
      return Constants.statusMaster.ENROLL_REJECTED.value;
    } else if (Constants.statusMaster.OPT_OUT_IN_PROCESS.id == statusId) {
      return Constants.statusMaster.OPT_OUT_IN_PROCESS.value;
    }
    return null;
  }
  getClaimStatusByClaimStatusId(claimStatusId: number): String {
    if (Constants.claimStatusMaster.CLAIM_IN_PROGRESS.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_IN_PROGRESS.value;
    } else if (Constants.claimStatusMaster.CLAIM_SEND_TO_INSURER.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_SEND_TO_INSURER.value;
    } else if (Constants.claimStatusMaster.CLAIM_SEND_BACK_BY_INSURER.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_SEND_BACK_BY_INSURER.value;
    } else if (Constants.claimStatusMaster.CLAIM_REJECTED.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_REJECTED.value;
    } else if (Constants.claimStatusMaster.CLAIM_HOLD.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_HOLD.value;
    } else if (Constants.claimStatusMaster.CLAIM_ACCEPTED.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_ACCEPTED.value;
    } else if (Constants.claimStatusMaster.CLAIM_INSURER_IN_PROGRESS.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_INSURER_IN_PROGRESS.value;
    } else if (Constants.claimStatusMaster.CLAIM_EXPIRE.id == claimStatusId) {
      return Constants.claimStatusMaster.CLAIM_EXPIRE.value;
    }
    return null;
  }
}
