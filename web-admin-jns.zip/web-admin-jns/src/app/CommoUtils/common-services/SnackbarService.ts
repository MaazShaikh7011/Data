import { Injectable, TemplateRef } from '@angular/core';
import { SnackbarComponent } from '../Common-Component/snackbar/snackbar.component';
import { MatSnackBar } from '@angular/material/snack-bar';
// import { MatSnackBar } from '@angular/material/snack-bar';




@Injectable({
  providedIn: 'root'
})
export class SnackbarService {
  toasts = [];
  constructor(
     private snackBar: MatSnackBar
  ) { }

  /**
   * Open snackbar
   */
  public openSnackBar(message: string, action: string, snackType: any) {
    // console.log(snackType + "---------" + message);
    const sType = snackType !== undefined ? snackType : '';
    // console.log(sType);
    this.snackBar.openFromComponent(SnackbarComponent, {
      duration: 3000,
      horizontalPosition: 'right',
      verticalPosition: 'top',
      panelClass: [sType + '-snackbar'],
      data: { message, snackType: sType },
    });

  }

  /**
   * Close snackbar
   */
  public dismiss() {
    // this.snackBar.dismiss();
  }

  // code related to ngb-toast
  /**
   * Show NG Bootstrap toast
   */
  showNGBToast(textOrTpl: string | TemplateRef<any>, options: any = {}): void {
    this.toasts.push({ textOrTpl, ...options });
  }

  /**
   * Show NG Bootstrap toast
   */
  removeNGBToast(toast): void {
    this.toasts = this.toasts.filter(t => t !== toast);
  }
}
