import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { RestUrl } from '../resturl';
import { CommonService } from './common.service';
import { HttpService } from './http.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';

@Injectable({
  providedIn: 'root'
})
export class AdminPanelServiceService {
  saveSubject = new Subject();
  public saveSubjectSubscriber$ = this.saveSubject.asObservable();

  constructor(private http: HttpService, private commonService: CommonService,) { }

  spGetInsurerDetailList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_INSURER_DETAIL_LIST, data);
  }
  spGetApplicationAuditList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_AUDIT_APPLICATION_LIST, data);
  }
  getDownloadFailedAppLst(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_DOWNLOAD_FAILED_APPLICATION_LIST, data);
  }
  regenerateDownloadReport(data: any): Observable<any> {
    return this.http.post(RestUrl.REGENERATE_DOWNLOAD_REPORT, data);
  }
  spGetApplicationWebhookAuditList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_AUDIT_WEBHOOK_APPLICATION_LIST, data);
  }
  spGetApplicationList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_APPLICATION_LIST, data);
  }
  getDocumentZip(data: any): Observable<any> {
    return this.http.downloadReport(RestUrl.GET_DOCUMENT_ZIP, data);
  }
  downloadDocumentByDocumentMappingId(data): Observable<any> {
    return this.http.downloadReport(RestUrl.DOWNLOAD_DOCUMENT_BY_DOCUMENT_MAPPING_ID, data);
  }

  spGetApplicationClaimList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_APPLICATION_CLAIM_LIST, data);
  }
  getCommonList(listKey, whereClause): Observable<any> {
    return this.http.post(RestUrl.SP_GET_SCHEME_LIST, { listKey, whereClause });
  }
  getCustomerDetailsList(applicationId: any): Observable<any> {
    return this.http.get(RestUrl.GET_CUSTOMER_DETAILS_LIST + this.commonService.encryptFunction(applicationId), false, false);
  }

  getCertiInsData(data): Observable<any> {
    return this.http.post(RestUrl.GET_CERTI_DATA, data);
  }

  getErrorStageList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ERROR_STAGE_LIST, data);
  }

  getCustomerClaimDetailsList(applicationId, claimId): Observable<any> {
    return this.http.get(RestUrl.GET_CUSTOMER_CLAIM_DETAILS_LIST + this.commonService.encryptFunction(applicationId) + "/" + this.commonService.encryptFunction(claimId), false, false);
  }

  getLoanApplicationDetail(data): Observable<any> {
    return this.http.post(RestUrl.GET_LOAN_APPLCIATION_DETAIL, data, true);
  }
  getStagesDetail(data): Observable<any> {
    return this.http.post(RestUrl.GET_APPLICATION_STAGES_DETAIL, data, true);
  }
  getCustomerRecordList(data): Observable<any> {
    return this.http.post(RestUrl.GET_CUSTOMER_RECORD_LIST, data);
  }
  getCustomerDetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_CUSTOMER_DETAILS, data);
  }
  getEligibleAndInEligibleResponse(data): Observable<any> {
    return this.http.post(RestUrl.GET_ELIGIBLE_AND_IN_ELIGIBLE_RESPONSE, data);
  }
  getScoringCalculationsDetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_SCORING_CALCULATIONS_DETAILS, data);
  }

  getEligibilityCalculationsDetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_ELIGIBILITY_CALCULATIONS_DETAILS, data);
  }
  getUserPersonalDetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_PERSONAL_DETAILS, data);
  }
  getAppProdMatchesData(data): Observable<any> {
    return this.http.post(RestUrl.GET_APP_PROD_MATCHES_DATA, data);
  }
  lockUnlockUser(data): Observable<any> {
    return this.http.post(RestUrl.GET_UPDATE_IS_LOCK, data);
  }
  activeIsActiveUser(data): Observable<any> {
    return this.http.post(RestUrl.ACTIVE_IS_ACTIVE_USER, data);
  }
  userResetPassword(data): Observable<any> {
    return this.http.post(RestUrl.USER_RESET_PASSWORD, data);
  }
  getSystemOtp(data): Observable<any> {
    return this.http.post(RestUrl.GET_SYSTEM_OTP, data, true);
  }
  getApiDashboardCount(): Observable<any> {
    return this.http.get(RestUrl.GET_API_DASHBOARD_COUNT, false, true);
  }

  // set-Permmition
  getYearsList(): Observable<any> {
    return this.http.get(RestUrl.GET_YEARS_LIST, false, true);
  }
  getNotificationCount(data): Observable<any> {
    return this.http.post(RestUrl.GET_NOTIFICATION_COUNT, data);
  }
  downloadNotificatioList(data): Observable<any> {
    return this.http.post(RestUrl.DOWNLOAD_NOTIFICATION_LIST, data);
  }
  getAllInsurerCount(data): Observable<any> {
    return this.http.post(RestUrl.GET_ALL_INSURER_COUNT, data);
  }
  getOrganizationList(): Observable<any> {
    return this.http.get(RestUrl.GET_ORGANIZATION_LIST, false, true);
  }
  getInsurerList(): Observable<any> {
    return this.http.get(RestUrl.GET_ALL_INSURER, false, true);
  }
  getRoleMaserList(): Observable<any> {
    return this.http.get(RestUrl.GET_ROLE_MASTER_LIST, false, true);
  }


  getAdminRoleMaserList(): Observable<any> {
    return this.http.get(RestUrl.GET_ADMIN_ROLE_MASTER_LIST, false, true);
  }

  getPermissionMaserList(): Observable<any> {
    return this.http.get(RestUrl.GET_PERMISSION_MASTER_LIST, false, true);
  }




  getUserPermissionMapping(data): Observable<any> {
    return this.http.post(RestUrl.GET_PERMISSION_MAPPING_LIST, data);
  }
  savePermission(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_PERMISSION, data);
  }
  getMenuMaserList(): Observable<any> {
    return this.http.get(RestUrl.GET_MENU_MASTER, false, true);
  }
  getAdminMenuMaserList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ADMIN_MENU_MASTER, data);
  }
  getAdminPermisssionMaserList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ADMIN_PERMISSION_MASTER_LIST, data);
  }
  viewMenuPermissionMapping(data): Observable<any> {
    return this.http.post(RestUrl.GET_MENU_MAPPING_LIST, data);
  }
  saveMenuMappingPermission(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_MENU_MAPPING_LIST, data);
  }
  saveMenu(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_MENU, data);
  }
  deleteMenu(data): Observable<any> {
    return this.http.post(RestUrl.DELETE_MENU, data);
  }

  // User Admin List
  getUserAdminList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ADMIN_USER_LIST, data);
  }
  getAdminMenuMappingrList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ADMIN_MENU_MAPPING_LIST, data);
  }
  saveAdminPermission(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_ADMIN_PERMISSION, data);
  }
  saveUserAdmin(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_USER_ADMIN, data);
  }
  saveOrganization(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_ORGANIZATION, data);
  }
  getUserOrganizationList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_ORGANIZATION_LIST, data);
  }
  setOrgPermission(data): Observable<any> {
    return this.http.post(RestUrl.SET_ORG_PERMISSION, data);
  }
  isActiveOrg(data): Observable<any> {
    return this.http.post(RestUrl.IS_ACTIVE_ORGANIZATION, data);
  }
  getAllBOList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_BO_LIST, data);
  }
  getAllRoList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_RO_LIST, data);
  }
  getAllZoList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_ZO_LIST, data);
  }
  createNewUser(data): Observable<any> {
    return this.http.post(RestUrl.CREATE_USER, data);
  }
  checkUserMobile(data): Observable<any> {
    return this.http.post(RestUrl.CHECK_USER_MOBILE, data, true);
  }
  getBankUserList(data): Observable<any> {
    return this.http.post(RestUrl.GET_BANKER_USER_LIST, data);
  }

  getPartnerUserList(data): Observable<any> {
    return this.http.post(RestUrl.GET_PARTNER_USER_LIST, data);
  }

  getApplicationsList(data): Observable<any> {
    return this.http.post(RestUrl.GET_PARTNER_APPLICATIONS, data);
  }

  getStpGatewayList(data): Observable<any> {
    return this.http.post(RestUrl.GET_STP_GATEWAY_LIST, data);
  }

  getStpApiAudits(data): Observable<any> {
    return this.http.post(RestUrl.GET_STP_API_AUDITS, data);
  }

  getBureauConfigActiveInactiveList(data): Observable<any> {
    return this.http.post(RestUrl.GET_BUREAU_CONFIG_ACTIVE_INACTIVE_LIST, data);
  }

  getPartnerRoleMaserList(): Observable<any> {
    return this.http.get(RestUrl.GET_PARTNER_MASTER_LIST, false, true);
  }

  getOtherUserList(data): Observable<any> {
    return this.http.post(RestUrl.GET_OTHER_USER_LIST, data);
  }
  getUserDetailsList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_DETAILS_LIST, data);
  }
  getCibilLogsList(data): Observable<any> {
    return this.http.post(RestUrl.GET_CIBIL_LOGS_LIST, data);
  }
  getProductList(data): Observable<any> {
    return this.http.post(RestUrl.GET_PRODUCT_LIST, data);
  }
  getScoringList(data): Observable<any> {
    return this.http.post(RestUrl.GET_SCORING_LIST, data);
  }
  getScoringModel(scoringModelId: any, type: any, tabType: any): Observable<any> {
    return this.http.get(RestUrl.GET_SCORING_MODEL + CommonService.encryptFuntion(scoringModelId) + "/" + CommonService.encryptFuntion(type) + "/" + CommonService.encryptFuntion(tabType), false);
  }
  fetchPanAadharDeDuplicationList(data): Observable<any> {
    return this.http.post(RestUrl.FETCH_PAN_AADHAR_DE_DUPLICATION, data);
  }
  getGrievancesList(data): Observable<any> {
    return this.http.post(RestUrl.GET_GRIEVANCES_LIST, data);
  }
  updateGrievancesRemark(data): Observable<any> {
    return this.http.post(RestUrl.UPDATE_GRIEVANCES_REMARK, data);
  }
  getProductByIdFromMaster(id: number, type: number): Observable<any> {
    return this.http.get(RestUrl.GET_PRODUCT_BY_ID + CommonService.encryptFuntion(id) + '/' + CommonService.encryptFuntion(type), false);
  }
  getMasterViewData(id: number): Observable<any> {
    return this.http.get(RestUrl.GET_PRODUCT_MASTER_VIEW_DATA + CommonService.encryptFuntion(id), false);
  }
  getScalingMatrixMaster(request: any): Observable<any> {
    return this.http.post(RestUrl.GET_SCALING_MATRIX_MASTER_BY_PRODUCT_ID, request, false);
  }
  getBaseRate(request): Observable<any> {
    return this.http.post(RestUrl.GET_CURRENT_BASE_RATE, request, false);
  }
  getEligibilityModelMasterById(fpProductId: any): Observable<any> {
    return this.http.get(RestUrl.GET_ELIGIBILITY_MODEL_MASTER_BY_ID + CommonService.encryptFuntion(fpProductId), false);
  }
  getProductSByscoringId(scoringId: any): Observable<any> {
    return this.http.get(RestUrl.PRODUCT_BY_SCORE_ID + CommonService.encryptFuntion(scoringId), false);
  }
  getProposalDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_PROPOSAL_DETAILS, data);
  }
  getBankerUserLogsDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_BANKER_USER_LOGS_DETAILS, data);
  }
  getBankerUserReqResLogsDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_BANKER_USER_REQ_RES_LOGS_DETAILS, data);
  }
  getReqResLogsDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_REQ_RES_LOGS_DATA, data);
  }
  getSchemeWiseApiCallsData(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_SCHEME_WISE_API_CALLS_DATA, data);
  }
  getBillingCounts(data: any, resultType): Observable<any> {
    return this.http.post(RestUrl.GET_BILLING_COUNTS + '/' + CommonService.encryptFuntion(resultType), data);
  }
  getFilterList(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_FILTER_LIST, data);
  }
  sendMailWithReport(data: any): Observable<any> {
    return this.http.post(RestUrl.SEND_MAIL_WITH_REPORT, data, false);
  }
  uploadTransactionReportFile(data: FormData): Observable<any> {
    return this.http.post(RestUrl.UPLOAD_TRANSACTION_REPORT_FILE_UPLOAD, data, true);
  }
  // ravi added
  updateBranchId(data): Observable<any> {
    return this.http.post(RestUrl.UPDATE_BRANCHID, data);
  }
  updateBranchIdForMultipleApplication(data): Observable<any> { // for multiple application branch transfer
    return this.http.post(RestUrl.UPDATE_BRANCHID_MULTIPLE_APPLICATION, data);
  }
  searchBranchListBasedOnCodeOrName(data): Observable<any> {
    return this.http.post(RestUrl.SEARCH_BRANCH_LIST_BASED_ON_CODE_OR_NAME, data);
  }

  // admin Management
  getAdminMenuPermissionMappingList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ADMIN_MENU_PERMISSION_MAPPING_LIST, data);
  }
  saveAdminMenuPermission(data: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_ADMIN_MENU_PERMISSION, data);
  }
  saveAdminBasicPermission(data: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_ADMIN_BASIC_PERMISSION, data);
  }

  getThirdPartyInfo(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_THIRD_PARTY_INFO, data);
  }

  getThirdPartyCount(data): Observable<any> {
    return this.http.post(RestUrl.GET_THIRD_PARTY_COUNT, data, false);
  }

  // get Branch List
  getBranchList(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_BRANCH_LIST, data);
  }
  isActiveBranch(data): Observable<any> {
    return this.http.post(RestUrl.IS_ACTIVE_BRANCH, data);
  }
  getBranchAuditList(data): Observable<any> {
    return this.http.post(RestUrl.GET_BRANCH_AUDIT_LIST, data);
  }

  // create Branch
  getOfficeList(): Observable<any> {
    return this.http.post(RestUrl.GET_ALL_OFFICE_LIST, true);
  }
  getZOList(data): Observable<any> {
    return this.http.post(RestUrl.GET_ZO_LIST, data, true);
  }
  getHOList(data): Observable<any> {
    return this.http.post(RestUrl.GET_HO_LIST, data, true);
  }
  getROList(data): Observable<any> {
    return this.http.post(RestUrl.GET_RO_LIST, data, true);
  }
  getStatesByCountryId(countryId): Observable<any> {
    return this.http.get(RestUrl.GET_STATE_LIST + CommonService.encryptFuntion(countryId), false);
  }
  getCitiesByStateId(stateId): Observable<any> {
    return this.http.get(RestUrl.GET_CITY_LIST + CommonService.encryptFuntion(stateId), false);
  }

  getLgdStateList(): Observable<any> {
    return this.http.get(RestUrl.GET_LGD_STATE_LIST, false);
  }
  getLgdCityListByLgdStateId(stateId): Observable<any> {
    return this.http.get(RestUrl.GET_LGD_DISTRICT_LIST + this.commonService.encryptFunction(stateId), false);
  }
  saveNewBranch(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_NEW_BRANCH, data, true);
  }
  editBranchBranch(data): Observable<any> {
    return this.http.post(RestUrl.EDIT_BRANCH_DETAILS, data, true);
  }
  getSingleBODetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_SINGLE_BO_DETAIL, data, true);
  }

  createBankWiseUser(data): Observable<any> {
    return this.http.post(RestUrl.CREATE_BANKWISE_USER, data);
  }

  updateBankWiseUser(data): Observable<any> {
    return this.http.post(RestUrl.UPDATE_BANKWISE_USER, data);
  }

  downloadZipFile(data): Observable<any> {
    return this.http.downloadReport(RestUrl.DOWNLOAD_ALL_ZIP_FILE, data);
  }

  // All CAM Report
  downloadEduCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_EDU_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadHomeCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_HOME_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAcabcCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_AGRI_ACABC_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAmiCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_AGRI_AMI_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSWMSCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SWMS_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadMLCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_MUDRA_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadLivelihoodCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_LIVELIHOOD_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSrmsCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SRMS_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSUICCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SUIC_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAifCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_AGRI_AIF_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadNrlmCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_NRLM_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadKCCCamReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_KCC_CAM_REPORT + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }

  // All Application Form
  downloadEduApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_EDU_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadHLApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_HOME_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAcabcApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_ACABC_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAmiApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_AMI_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSwmsApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SWMS_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadMudraApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_MUDRA_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadLivelihoodApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_LIVELIHOOD_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSrmsApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SRMS_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadSUICApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_SUIC_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadAifApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_AIF_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadNrlmApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_NRLM_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }
  downloadKccApplicationFormReport(applicationId, proposalId): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_KCC_APPLICATION_FORM + CommonService.encryptFuntion(applicationId) + '/' + CommonService.encryptFuntion(proposalId), false, true);
  }

  // CMA FILE DOWNLOAD
  downloadExcelFile(typeId: any): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_CMA_EXCEL_FILE + '/' + CommonService.encryptFuntion(typeId), true);
  }
  downloadBusinessCMAExcelFile(profileId: any): Observable<any> {
    return this.http.get(RestUrl.DOWNLOAD_BUSINESS_CMA_EXCEL_FILE + '/' + CommonService.encryptFuntion(profileId) + '/' + CommonService.encryptFuntion(7), true);
  }

  changeOrgIdAndBranchId(data): Observable<any> {
    return this.http.post(RestUrl.CHANGE_ORG_AND_BRANCH, data);
  }

  createBorrower(data): Observable<any> {
    return this.http.post(RestUrl.CREATE_BORROWER, data);
  }

  changePassword(data: any): Observable<any> {
    return this.http.post(RestUrl.RESET_PASSWORD_AFTER_LOGIN, data);
  }

  savePermissionCibilForParticularOrg(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_CIBIL_PERMISSION, data);
  }
  // savePermissionCibil(data): Observable<any> {
  //   console.log("schemeId  ::: {}", data);
  //   // for MSME
  //   if (data.schemeId == Constants.SchemeMaster.PRADHAN_MANTRI_MUDRA_YOJNA.id ||
  //     data.schemeId == Constants.SchemeMaster.STAND_UP_INDIA_SCHEME.id ||
  //     data.schemeId == Constants.SchemeMaster.SRMS.id ||
  //     data.schemeId == Constants.SchemeMaster.WEAVER_CREDIT_CARD.id) {
  //     return this.http.post(RestUrl.SAVE_CIBIL_PERMISSION_MSME, data);

  //     // FOR RETAIL
  //   } else if (data.schemeId == Constants.SchemeMaster.CENTRAL_SECTOR_INTEREST_SUBSIDY.id ||
  //     data.schemeId == Constants.SchemeMaster.PADHO_PRADESH.id ||
  //     data.schemeId == Constants.SchemeMaster.DR_AMBEDKAR_CENTRAL_SECTOR_SCHEME.id) {
  //     return this.http.post(RestUrl.SAVE_CIBIL_PERMISSION_RETAIL, data);

  //     // FOR AGRI SCHEME
  //   } else if (data.schemeId == Constants.SchemeMaster.AGRICLINICS_AGRIBUSINESS_CENTERS_SCHEME.id
  //     || data.schemeId == Constants.SchemeMaster.AGRICULTURAL_MARKETING_INFRASTRUCTURE.id
  //     || data.schemeId == Constants.SchemeMaster.AGRICULTURE_INFRASTRUCTURE_FUND.id) {
  //     return this.http.post(RestUrl.SAVE_CIBIL_PERMISSION_AGRI, data);


  //   } else if (data.schemeId == Constants.SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.id
  //     || data.schemeId == Constants.SchemeMaster.NULM.id) {
  //     return this.http.post(RestUrl.SAVE_CIBIL_PERMISSION_LHD, data);
  //   }
  //   return null;
  // }

  // getBureauPermissionMaserList(schTypeId): Observable<any> {
  //   // for MSME
  //   if (schTypeId == Constants.SchemeMaster.PRADHAN_MANTRI_MUDRA_YOJNA.id ||
  //     schTypeId == Constants.SchemeMaster.STAND_UP_INDIA_SCHEME.id ||
  //     schTypeId == Constants.SchemeMaster.SRMS.id ||
  //     schTypeId == Constants.SchemeMaster.WEAVER_CREDIT_CARD.id) {
  //     return this.http.get(RestUrl.GET_BUREAU_MASTER_LIST_MSME, false, true);
  //     // FOR RETAIL
  //   } else if (schTypeId == Constants.SchemeMaster.CENTRAL_SECTOR_INTEREST_SUBSIDY.id ||
  //     schTypeId == Constants.SchemeMaster.PADHO_PRADESH.id ||
  //     schTypeId == Constants.SchemeMaster.DR_AMBEDKAR_CENTRAL_SECTOR_SCHEME.id) {
  //     return this.http.get(RestUrl.GET_BUREAU_MASTER_LIST_RETAIL, false, true);
  //     // FOR AGRI SCHEME
  //   } else if (schTypeId == Constants.SchemeMaster.AGRICLINICS_AGRIBUSINESS_CENTERS_SCHEME.id
  //     || schTypeId == Constants.SchemeMaster.AGRICULTURAL_MARKETING_INFRASTRUCTURE.id
  //     || schTypeId == Constants.SchemeMaster.AGRICULTURE_INFRASTRUCTURE_FUND.id) {
  //     return this.http.get(RestUrl.GET_BUREAU_MASTER_LIST_AGRI, false, true);
  //   } else if (schTypeId == Constants.SchemeMaster.DEENDAYAL_ANTYODAYA_YOJANA_NATIONAL_RURAL_LIVELIHOODS_MISSION.id ||
  //     schTypeId == Constants.SchemeMaster.NULM.id) {
  //     return this.http.get(RestUrl.GET_BUREAU_MASTER_LIST_LHD, false, true);
  //   }
  //   return null;
  // }

  getBureauPermissionMaserList(orgId): Observable<any> {
    return this.http.get(RestUrl.GET_BUREAU_MASTER_LIST + '/' + CommonService.encryptFuntion(orgId), false, true);
  }

  spGetCountSchemeAndBankWise(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_COUNT_SCHEME_AND_BANKWISE, data);
  }

  getApiDashboardErrorLog(req: any): Observable<any> {
    return this.http.post(RestUrl.GET_ERROR_LOG_DASHBOARD, req, true);
  }

  getFailedApplicationDetails(req: any): Observable<any> {
    return this.http.post(RestUrl.GET_FAILED_APPLICATION_DETAIL, req, true);
  }

  updateRetryCount(req: any): Observable<any> {
    return this.http.post(RestUrl.DO_RETRY_COUNT, req, true);
  }
  changeAdminUserRole(data): Observable<any> {
    return this.http.post(RestUrl.CHANGE_ADMIN_USER_ROLE, data);
  }

  getStageAuditList(data): Observable<any> {
    return this.http.post(RestUrl.GET_STAGE_AUDIT_LIST, data);
  }

  getSchemeList(): Observable<any> {
    return this.http.get(RestUrl.GET_SCHEME_LIST, false, true);
  }

  getApiListBySchemeId(id): Observable<any> {
    return this.http.post(RestUrl.GET_API_LIST, id);
  }

  saveApiData(request: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_API_DATA, request);
  }

  getAnsProperties(): Observable<any> {
    return this.http.get(RestUrl.GET_ANS_PROPERTIES, false, true);
  }

  saveAnsProperties(data): Observable<any> {
    return this.http.post(RestUrl.SAVE_ANS_PROPERTIES, data);
  }
  // ------------------------CAMPAIGN CONFIGURATION------------------------------------------
  getCampaignList(): Observable<any> {
    return this.http.get(RestUrl.GET_CAMPAIGN_LIST, false, true);
  }
  saveOrUpdateCampaignCode(request: any): Observable<any> {
    return this.http.post(RestUrl.UPDATE_CAMPAIGN_CODE, request);
  }
  getCampaignById(request: any): Observable<any> {
    return this.http.post(RestUrl.GET_CAMPAIGN_BY_ID, request);
  }
  getRoleTypeList(data): Observable<any> {
    return this.http.post(RestUrl.USER_ROLE_TYPE, data, true);
  }

  getNameMatchData(): Observable<any> {
    return this.http.get(RestUrl.GET_NAME_MATCH, false, true);
  }

  saveNameMatchData(request: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_NAME_MATCH, request);
  }

  getPMAYStatusList(request: any): Observable<any> {
    return this.http.post(RestUrl.GET_PMAY_STATUS_LIST, request);
  }

  getBankSpecificList(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_BANK_SPECIFIC_LIST, data);
  }

  getCommonProposalList(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_ALL_PROPOSAL_DATA, data, true);
  }
  getInEligibleList(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_IN_ELIGIBLE_LIST, data);
  }
  coyProductToOtherOrg(data: any): Observable<any> {
    return this.http.post(RestUrl.COPY_PRODUCT_TO_OTHER_ORG, data);
  }
  getAnsServiceList(): Observable<any> {
    return this.http.get(RestUrl.GET_ANS_SERVICES, false);
  }

  pingAnsServices(): Observable<any> {
    return this.http.get(RestUrl.PING_ANS_SERVICES, false);
  }

  getNewDashBoardUserAndApplicationBarChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_USER_AND_APPLICATION_BAR_CHART, data, false);
  }
  getNewDashBoardApplicationDetailsPieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_APPLICATION_DETAILS_PIE_CHART, data, false);
  }
  getNewDashBoardSchemeWisePieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_SCHEMEWISE_PIE_CHART, data, false);
  }
  getNewDashBoardLoanWisePieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_LOANWISE_PIE_CHART, data, false);
  }
  getNewDashBoardBankWisePieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_BANKWISE_PIE_CHART, data, false);
  }
  getNewDashBoardDayMonthWisePieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_DAY_MONTH_WISE_PIE_CHART, data, false);
  }
  getNewDashBoardApprovedReferredFilterBarChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_APPROVE_REFERRED_BAR_CHART, data, false);
  }
  spGetNewDashBoardCityStateWisePieChart(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_NEW_DASHBOARD_CITY_STATE_WISE_PIE_CHART, data, false);
  }
  getRoZoDetailsByRoZoId(roZoId: any): Observable<any> {
    return this.http.get(RestUrl.GET_RO_ZO_DETAILS_BY_RO_ZO_ID + '/' + CommonService.encryptFuntion(roZoId), false);
  }
  getProposalButton(data): Observable<any> {
    return this.http.post(RestUrl.GET_PROPOSAL_BUTTONS, data);
  }
  getProposalDisburseDetails(data): Observable<any> {
    return this.http.post(RestUrl.GET_PROPOSAL_DISBURSE_DETAILS, data);
  }
  updateProposalStatus(data): Observable<any> {
    return this.http.post(RestUrl.UPDATE_PROPOSAL_STATUS, data);
  }

  getSchmeListForAdmin(): Observable<any> {
    return this.http.get(RestUrl.GET_SCHEME_LIST_FOR_ADMIN, false);
  }


  //common

  getAllUserType(): Observable<any> {
    return this.http.get(RestUrl.GET_ALL_USER_TYPE, false, true);
  }

  getAllScheme(): Observable<any> {
    return this.http.get(RestUrl.GET_ALL_SCHEME, false, true);
  }

  getMasterListByKey(data): Observable<any> {
    return this.http.post(RestUrl.GET_MASTER_LIST_BY_KEY, data);
  }

  saveApiUser(data: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_API_USRR, data, false);
  }
  getOrgMasterListByApimasterId(): Observable<any> {
    return this.http.get(RestUrl.GET_ORG_LIST_BY_APIMASTERID, false, true);
  }

  fetchApiUser(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_API_USER_LIST, data);
  }

  getApiUserList(id: any): Observable<any> {
    return this.http.get(RestUrl.GET_API_USER + "/" + CommonService.encryptFuntion(id), false);
  }
  activeIsApiUser(id: any): Observable<any> {
    return this.http.get(RestUrl.ACTIVE_IS_API_USER + "/" + CommonService.encryptFuntion(id), false);
  }
  fetchPublishedAppList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_PUBLISHED_APP_LIST, data, true);
  }
  fetchPublishedClaimList(data: any): Observable<any> {
    return this.http.post(RestUrl.SP_GET_PUBLISHED_CLAIM_LIST, data, false);
  }
  // getPublishedAppFormDetails(applicationReferenceId: any): Observable<any> {
  //   return this.http.get(RestUrl.GET_PUBLISHED_FORM_APP_LIST + this.commonService.encryptFunction(applicationReferenceId),false , false);
  // }

  getPublishedAppFormDetails(applicationReferenceId: any): Observable<any> {
    return this.http.get(RestUrl.GET_PUBLISHED_FORM_APP_LIST + "/" + applicationReferenceId, false);
  }
  // getPublishedclaimFormDetails(claimReferenceId: any): Observable<any> {
  //   return this.http.get(RestUrl.GET_PUBLISHED_FORM_CLAIM_LIST + this.commonService.encryptFunction(claimReferenceId),false , false);
  // }
  getPublishedclaimFormDetails(claimReferenceId: any): Observable<any> {
    return this.http.get(RestUrl.GET_PUBLISHED_FORM_CLAIM_LIST + "/" + claimReferenceId, false);
  }

  downloadZipFilePublish(data: any): Observable<any> {
    return this.http.downloadReport(RestUrl.GET_PUBLISHED_DOCUMENT_ZIP, data);
  }

  getApiConfigMaster(): Observable<any> {
    return this.http.get(RestUrl.GET_API_CONFIG_MASTER, false, true);
  }
  getConfigMaster(): Observable<any> {
    return this.http.get(RestUrl.GET_CONFIG_MASTER, false, true);
  }
  getTypeMasterForDms(): Observable<any> {
    return this.http.get(RestUrl.GET_TYPE_MASTER, false, true);
  }
  getDocumentMasterForDms(): Observable<any> {
    return this.http.get(RestUrl.GET_DOCUMENT_MASTER, false, true);
  }

  getPreMimumMaster(): Observable<any> {
    return this.http.get(RestUrl.GET_PREMIMUM_MASTER, false, true);
  }

  saveConfigMaster(data: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_CONFIG_MASTER, data, false);
  }

  activeIsConfigMaster(id: any): Observable<any> {
    return this.http.get(RestUrl.ACTIVE_IS_CONFIG_USER + "/" + CommonService.encryptFuntion(id), false);
  }
  getConfigListById(id: any): Observable<any> {
    return this.http.get(RestUrl.GET_CONFIG_LIST_BY_ID + "/" + CommonService.encryptFuntion(id), false);
  }
  fetchAppBankWiseCount(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_BANK_WISE_APP_LIST, data, true);
  }
  fetchAppOrgIdwiseCount(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ORGID_APP_LIST, data, true);
  }
  fetchClaimBankWiseCount(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_BANK_WISE_CLIAM_LIST, data, true);
  }
  fetchclaimOrgIdwiseCount(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ORGID_CLIAM_LIST, data, true);
  }
  getDocumentListByAppId(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_DOCUMENTLIST_BY_APPID, data, false);
  }
  getDocumentListByCliamRefId(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_DOCUMENTLIST_BY_CLAIMREF_ID, data, false);
  }
  getUsernameAndApiKey(): Observable<any> {
    return this.http.get(RestUrl.GET_USERNAME_APIKEY, false, true);
  }
  fetchEnrollmentList(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ENROLLMENT_LIST, data, true);
  }

  getPolicyBarChartOrgWise(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_POLICY_BAR_CHART_ORG_WISE, data, false);
  }

  getPolicyBarChartInsurerWise(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_POLICY_BAR_CHART_INSURER_WISE, data, false);
  }

  // apiDeSeriablize(fileName: any): Observable<any> {
  //   return this.http.get(RestUrl.API_DESERIABLIZE + fileName, false, true);
  // }

  // registryDeSeriablize(fileName: any): Observable<any> {
  //   return this.http.get(RestUrl.REGISTRY_DESERIABLIZE + fileName, false, true);
  // }

  getPublishReqRes(fileName: any): Observable<any> {
    return this.http.get(RestUrl.GET_PUBLISH_REQ_RES + fileName, false, true);
  }
  getRegistryReqRes(auditId: any): Observable<any> {
    return this.http.get(RestUrl.GET_REGISTRY_REQ_RES + auditId, false, true);
  }
  fetchDDRegistryAuditDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_DDREGISTRY_AUDIT_DETAILS, data);
  }
  getDDRegistryReqRes(auditId: any): Observable<any> {
    return this.http.get(RestUrl.GET_DD_REGISTRY_REQ_RES + CommonService.encryptFuntion(auditId), false, true);
  }

  getPolicyBarChartBankLiveData(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_POLICY_BAR_CHART_BANK_LIVE_DATA, data, false);
  }
  getResResBucket(fileName): Observable<any> {
    return this.http.get(RestUrl.GET_RES_RES_BUCKET + fileName, false);
  }
  getWbResResBucket(fileName): Observable<any> {
    return this.http.get(RestUrl.GET_RES_WB_RES_BUCKET + fileName, false);
  }
  fetchCoiPushAllCounts(data): Observable<any> {
    return this.http.post(RestUrl.FETCH_COI_PUSH_ALL_COUNTS, data, true);

  } getEcrDecRes(data: any): Observable<any> {
    return this.http.post(RestUrl.ENC_DEC_DATA, data, true);
  }

  getAllOrgList(): Observable<any> {
    return this.http.get(RestUrl.GET_ALL_ORG_LIST, false, true);
  }
  getBucketLogDetails(contextPath: any, filename: any): Observable<any> {
    return this.http.get(RestUrl.GET_BUCKET_LOG_DETAILS + '/' + contextPath + '/opl/bucket/deseriablize/' + filename, false, true);
  }
  fetchNotificationList(data): Observable<any> {
    return this.http.post(RestUrl.FETCH_NOTIFICATION_LIST, data, true);
  }
  fetchOrgAndInsuranceWiseCount(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ORG_INSURANCE_WISE_LIST, data, true);
  }
  getUsersDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_USERS_DETAILS, data, true);
  }
  fetchEnrollmentDetails(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ENROLLMENT_DATA, data, true);
  }
  fetchAllUrn(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_ALL_URN, data, true);
  }
  saveSupportAudit(data: any): Observable<any> {
    return this.http.post(RestUrl.SAVE_SUPPORT_AUDIT, data, true);
  }
  fetchTokenData(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_TOKEN_DATA, data, true);
  }
  getNotificationDtl(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_NOTIFICATION_AUDIT, data, true);
  }
  fetchCityWiseData(data): Observable<any> {
    return this.http.post(RestUrl.FETCH_CITY_WISE_LIST, data, true);
  }
  fetchCityWiseForPolicy(data): Observable<any> {
    return this.http.post(RestUrl.FETCH_CITY_WISE_POLICY_LIST, data, true);
  }
  getCustomerMasterDetailsList(applicationId: any, schemeId: any): Observable<any> {
    return this.http.get(RestUrl.GET_CUSTOMER_DETAILS_Master_LIST + this.commonService.encryptFunction(applicationId) + "/" + this.commonService.encryptFunction(schemeId), false, false);
  }
  fetchPostmanResponse(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_POSTMAN_RESPONSE, data, true);
  }
  fetchBankWebhookRequest(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_BANK_WEBHOOK_REQ, data, true);
  }
  fetchJanApiRequest(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_JAN_API_REQ, data, true);
  }
  getApiUserListByOrgId(orgId: any): Observable<any> {
    return this.http.get(RestUrl.GET_API_USER_BY_ORGID + "/" + CommonService.encryptFuntion(orgId), false);
  }
  fetchClaimReports(data): Observable<any> {
    return this.http.post(RestUrl.GET_FETCH_CLAIM_REPORTS, data);
  }
  fetchPushFailList(data: any): Observable<any> {
    return this.http.post(RestUrl.FETCH_PUSH_FAIL_LIST, data, true);
  }
  pushBankAndInsurer(data: any): Observable<any> {
    return this.http.post(RestUrl.PUSH_BANK_AND_INSURER, data, true);
  }
}
