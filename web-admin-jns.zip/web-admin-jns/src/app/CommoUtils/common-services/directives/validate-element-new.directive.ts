import { Directive, DoCheck, ElementRef, Input } from '@angular/core';
import { AbstractControl, FormControl } from '@angular/forms';
import { CommonMethods } from '../common-methods';
import { ValidationsService } from '../validations.service';

@Directive({
  selector: '[appValidateElementNew]'
})
export class ValidateElementNewDirective implements DoCheck {

  // validate on save click
  @Input() set appValidateElement(value) {
    this.errorMessage(value);
  }

  @Input() validationMessage;
  @Input() control: AbstractControl = new FormControl();
  // @Input() validationControlName: string;
  @Input() minlength = 10;
  @Input() maxlength = 100;

  validationMessageJSON = {
    required: '',
    minlength: '',
    maxlength: '',
    pattern: '',
    matDatepickerParse: '',
    matDatetimePickerMin: '',
    matDatetimePickerMax: '',
  };

  constructor(
    private elementRef: ElementRef,
    private validationService: ValidationsService
  ) {
    elementRef.nativeElement.insertAdjacentHTML('beforeend', '<div class="text-danger errorClass"></div>');
  }

  ngDoCheck(): void {
    if (this.control?.errors && (this.control.dirty || this.control.touched)) {
      this.errorMessage();
    } else {
      const errorElement = this.elementRef?.nativeElement?.childNodes[0];
      if (errorElement) {
        errorElement.innerHTML = '';
      }
    }
  }

  errorMessage(submitted?): void {
    let errorMsg = '';
    this.setValidationMessage();
    const errorElement = this.elementRef?.nativeElement?.childNodes[0];
    for (const propertyName in this.control?.errors) {
      if (this.control.errors.hasOwnProperty(propertyName) && (this.control.dirty || this.control.touched)
        || (submitted && this.control.invalid)) {
        // errorMsg = this.validatorErrorMessage(this.control, propertyName);
        errorMsg += this.validationMessageJSON[propertyName] + ' ';
        if (errorMsg === 'undefined ') {
          errorMsg = null;
        }
        if (errorMsg == null) {
          errorMsg = this.validationService.getValidatorErrorMessage(propertyName, this.control.errors[propertyName]);
        }
        if (errorElement && errorElement.classList.contains('errorClass')) {
          if (errorMsg) {
            errorElement.innerHTML = errorMsg;
          } else {
            errorElement.innerHTML = '';
          }
        }
      }
    }
  }

  // validatorErrorMessage(c: AbstractControl, propertyName): string | null {
  //   const formGroup = c.parent.controls;
  //   let controlName = Object.keys(formGroup).find(name => c === formGroup[name]);
  //   if (this.validationControlName != null || this.validationControlName !== undefined) {
  //     controlName = this.validationControlName;
  //   }
  //   if (controlName != null || controlName !== undefined) {
  //     return this.commonMethod.getErrorMessage(controlName, propertyName) || null;
  //   }
  //   return null;
  // }

  setValidationMessage() {
    this.validationMessageJSON = {
      required: this.validationMessage && this.validationMessage.required || 'Required',
      minlength: this.validationMessage && this.validationMessage.minlength || `Minimum ${this.minlength} characters required`,
      maxlength: this.validationMessage && this.validationMessage.maxlength || `Maximum ${this.maxlength} characters allowed`,
      pattern: this.validationMessage && this.validationMessage.pattern || 'Invalid pattern',
      matDatepickerParse: this.validationMessage && this.validationMessage.matDatepickerParse || 'Required',
      matDatetimePickerMin: this.validationMessage && this.validationMessage.matDatetimePickerMin || 'Invalid Date Selection',
      matDatetimePickerMax: this.validationMessage && this.validationMessage.matDatetimePickerMax || 'Invalid Date Selection',
    };
  }

}
