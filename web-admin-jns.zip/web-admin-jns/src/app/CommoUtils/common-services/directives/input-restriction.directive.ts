import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { AbstractControl, UntypedFormControl, NgControl } from '@angular/forms';
import * as _ from 'lodash';
import { Constants } from '../constants';

@Directive({
  selector: '[appInputRestriction]'
})
export class InputRestrictionDirective {
  private el: HTMLInputElement;
  private regex = null;

  // FORM CONTROL
  @Input() control: AbstractControl = new UntypedFormControl();

  // REGEX FOR RISTRICTION
  @Input() set regexType(regexType: number) {
    this.regex = _.find(Constants.REGEX_TYPE, { id: regexType })?.value;
  }

  // NG MODEL OR FORM CONTROL
  @Input() isNgModel = false;

  // Example
  // appInputRestriction [regexType]="8" [control]="personalDetailsForm.controls.firstName" --> formControl
  // appInputRestriction [regexType]="8" [isNgModel]="true" --> ngModel 

  constructor(private elementRef: ElementRef) {
    this.el = this.elementRef.nativeElement;
  }

  ngOnInit() {
  }

  @HostListener('input', ['$event'])
  onInput(event) {
    if (this.regex) {
      const data = event.target.value.replace(this.regex, '');
      if (this.isNgModel) {
        this.el.value = data;
      } else {
        this.control.setValue(data);
      }
    }
  }
}
