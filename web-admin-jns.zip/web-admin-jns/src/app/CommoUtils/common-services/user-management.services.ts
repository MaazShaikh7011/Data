import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { RestUrl } from '../resturl';
import { HttpService } from './http.service';


@Injectable({
  providedIn: 'root'
})
export class UserManagementServices {

  saveSubject = new Subject();
  public saveSubjectSubscriber$ = this.saveSubject.asObservable();


  constructor(private http: HttpService) { }


  getUserBusinessTypeList(data): Observable<any> {
    return this.http.post(RestUrl.GET_USER_BUSINESS_TYPE_LIST, data, true);
  }

 
  
}
