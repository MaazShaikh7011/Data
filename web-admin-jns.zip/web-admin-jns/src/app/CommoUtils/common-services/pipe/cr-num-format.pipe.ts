import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'crNumFormat'
})
export class crNumFormatPipe implements PipeTransform {

  transform(numbers: any): any {
    if (typeof (numbers) !== 'undefined' && numbers !== null && !isNaN(parseFloat(numbers))) {
      const text = Math.abs(parseFloat(numbers));
      const crVal= (text / 10000000).toFixed(2) + ' Cr';
      return crVal;
    }
    return null;
  }
}
