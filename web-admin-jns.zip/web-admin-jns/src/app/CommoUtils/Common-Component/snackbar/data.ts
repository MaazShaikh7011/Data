const alertData = [
    {
        color: 'success',
        icon: ' mdi mdi-check-circle'
    },
    {
        color: 'danger',
        icon: 'mdi mdi-block-helper'
    },
    {
        color: 'warning',
        icon: 'mdi mdi-alert-outline'
    },
    {
        color: 'info',
        icon: ' mdi mdi-alert-circle'
    },
];

export { alertData };
