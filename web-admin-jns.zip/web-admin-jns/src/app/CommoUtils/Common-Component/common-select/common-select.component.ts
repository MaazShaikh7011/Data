import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as _ from 'lodash';
import { AdminPanelServiceService } from '../../common-services/admin-panel-service.service';

@Component({
  selector: 'app-common-select',
  templateUrl: './common-select.component.html',
  styleUrls: ['./common-select.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CommonSelectComponent),
    multi: true
  }]
})
export class CommonSelectComponent implements OnInit, ControlValueAccessor {

  @Input() placeholder;
  @Input() searchParam;
  @Input() clearable = true;
  selectedVal;
  @Input()
  set selectedValue(value) {
    this.selectedVal = value ? Number(value) : null;
  }

  whereClauseForAPI;
  @Input() set whereClause(value) {
    this.whereClauseForAPI = value;
    this.fetchData();
  }

  @Output() selectedEvent = new EventEmitter();
  @Output() fetchListEvent = new EventEmitter();

  @Input() isDynamicList = true;
  @Input() options = [];


  private _value: string;
  // Whatever name for this (myValue) you choose here, use it in the .html file.
  public get myValue(): string { return this._value }
  public set myValue(v: string) {
    this._value = this._value || undefined;
    v = v || undefined;
    if (v !== this._value) {
      this._value = v;
      this.onChange(v);
    }
  }

  constructor(
    private adminPanelService: AdminPanelServiceService,
  ) { }

  onChange = (_) => { };
  onTouched = () => { };

  writeValue(obj: any): void {
    this.myValue = obj;
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  // setDisabledState?(isDisabled: boolean): void {
  //   throw new Error("Method not implemented.");
  // }

  ngOnInit(): void {
    // if (this.isDynamicList) {
    //   this.fetchData();
    // }
  }

  fetchData(): void {
    if (this.whereClauseForAPI) {
      const data = {
        listKey: this.searchParam,
        whereClause: this.whereClauseForAPI,
      };
      this.adminPanelService.getFilterList(data).subscribe((res: any) => {
        this.options = JSON.parse(res?.data);
        this.fetchListEvent.emit(this.options);
      });
    }
  }

  selectionChange(): void {
    const data = {
      selectedValue: this._value,
      selectedObj: _.find(this.options, o => o.id === this._value)
    };
    this.selectedEvent.emit(data);
  }
}
