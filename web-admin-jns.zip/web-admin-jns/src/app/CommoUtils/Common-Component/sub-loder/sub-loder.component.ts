import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-loder',
  templateUrl: './sub-loder.component.html',
  styleUrls: ['./sub-loder.component.scss']
})
export class SubLoderComponent implements OnInit {

  @Input() isLoading: boolean;
  isVisible: boolean;

  constructor() { }

  ngOnInit(): void {
    this.isVisible = true;
  }
}
