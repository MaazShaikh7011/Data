import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { interval } from 'rxjs';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { Constants } from 'src/app/CommoUtils/common-services/constants';
import { LoaderService } from 'src/app/CommoUtils/common-services/LoaderService';
import { BankerService } from '../service/banker.service';
import { CommonMethods } from './common-services/common-methods';

@Injectable({ providedIn: 'root' })
export class AuthGuard  {
    constructor(private router: Router, private commonMethod: CommonMethods, private loaderService: LoaderService, private bankerService: BankerService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true) != null) {
            // logged in so return true
            this.startIntervalForGetNewAccessKey(1800000);
            return true;
        } else {
            // not logged in so redirect to login page with the return url
            this.loaderService.hide();
            this.commonMethod.warningSnackBar('You are not Authorized');
            // this.logoutUser();
            return false;
        }
    }

    logoutUser() {
        if (CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true) != null) {
            this.bankerService.logoutUser().subscribe(res => {
                if (res.status === 200) {
                    this.commonMethod.successSnackBar(res.message);
                } else {
                    this.commonMethod.errorSnackBar(res.message);
                }
            }, error => {
                this.commonMethod.errorSnackBar(error);
            });
        }

        CommonService.removeStorage(Constants.httpAndCookies.USERTYPE);
        CommonService.removeStorage(Constants.httpAndCookies.COOKIES_OBJ);
        CommonService.removeStorage(Constants.httpAndCookies.ORGID);
        CommonService.removeStorage(Constants.httpAndCookies.ROLEID);
        CommonService.removeStorage(Constants.httpAndCookies.USER_ID);
        window.sessionStorage.removeItem('applicationId');
        window.sessionStorage.removeItem('profileId');

        window.location.href = Constants.LOCATION_URL + '/admin-web' + '/login';
        // window.location.href = 'http://localhost:2500' + '/login';
    }


    startIntervalForGetNewAccessKey(seconds: any) {
        // this is for get access token every 28 min
        interval(seconds).subscribe(x => {
            if (CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true) !== undefined
                && CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true) != null) {
                this.bankerService.getAccessToken().subscribe((res: any) => {
                    if (res.status === 200) {
                        let cookiesObje = CommonService.getStorage(Constants.httpAndCookies.COOKIES_OBJ, true);
                        cookiesObje = JSON.parse(cookiesObje);
                        const email = cookiesObje[Constants.httpAndCookies.USNM];
                        const lgTk = cookiesObje[Constants.httpAndCookies.LGTK];
                        CommonService.setSessionAndHttpAttr(email, res, lgTk);
                        // clearInterval(1);
                    }
                }, (error: any) => {
                    this.commonMethod.errorSnackBar({ message: error });
                    CommonService.removeStorage(Constants.httpAndCookies.COOKIES_OBJ);
                    // this.router.navigate(["/login"]);
                    window.location.href = Constants.LOCATION_URL + '/admin-web' + '/login';
                    // window.location.href = 'http://localhost:2500/login';
                });
            }
        });
    }
}