import { Component, Inject } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { CommonService } from './CommoUtils/common-services/common.service';
import { BankerService } from './service/banker.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  validationsobj: any;
  title = 'Jansuraksha - admin-panel';
  constructor(private titleService: Title,private bankerService: BankerService, @Inject(DOCUMENT) private document: Document) {
    this.document.body.classList.add('JNS_Admin');
  }

  ngOnInit(): void {
    // this.getAllValidations();
    this.titleService.setTitle(this.title);
  }
  ngOnDestroy(){
    this.document.body.classList.remove('JNS_Admin');
  }

   // Get All valication by Business type
  //  getAllValidations() {
  //   this.bankerService.getValidations(0).subscribe(res => {
  //     if (res.status === 200) {
  //       this.validationsobj = CommonService.parseData(res.data);
  //       CommonService.setStorage('validations', JSON.stringify(this.validationsobj));
  //     }
  //   }, error => {
  //     console.log(error);
  //   });
  // }
}
