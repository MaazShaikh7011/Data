
import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LayoutsModule } from './Component/layout/layouts.module';
import { SnackbarComponent } from './CommoUtils/Common-Component/snackbar/snackbar.component';
import { DatePipe, DecimalPipe } from '@angular/common';
import { LoaderComponent } from './CommoUtils/Common-Component/loader/loader.component'
import { DragDropDirective } from './CommoUtils/common-services/directives/drag-drop.directive';
import { InterceptorService } from './CommoUtils/common-services/interceptor.service';
import { CustomAdapter, CustomDateParserFormatter } from './CommoUtils/common-services/datepicker-adapter';

import { NgbDateParserFormatter, NgbDateAdapter, NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PopupModule } from './Popup/popup.module';

import { SharedModule } from './Component/shared/shared.module';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_FORMATS, MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import { SubLoderComponent } from './CommoUtils/Common-Component/sub-loder/sub-loder.component';
import { WebhookApiAuditDetailsLogComponent } from './Component/Admin-panel/webhook-api-audit-details-log/webhook-api-audit-details-log.component';
import { MAT_SELECTSEARCH_DEFAULT_OPTIONS, MatSelectSearchOptions } from 'ngx-mat-select-search';
import { LoaderService } from './CommoUtils/common-services/LoaderService';


@NgModule({
    declarations: [
        AppComponent,
        SnackbarComponent,
        LoaderComponent,
        DragDropDirective,
        WebhookApiAuditDetailsLogComponent,
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        LayoutsModule,
        AppRoutingModule,
        SharedModule,
        PopupModule,
    ],
    providers: [NgbActiveModal, { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
        { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
        { provide: NgbDateAdapter, useClass: CustomAdapter }, 
         /* Date Picker Formated Stared Nikul*/
         { provide: MAT_DATE_LOCALE, useValue: 'en-IN' },
         { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS] },
         { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
         {
            provide: MAT_SELECTSEARCH_DEFAULT_OPTIONS,
            useValue: <MatSelectSearchOptions>{
                noEntriesFoundLabel: 'No options found',
                disableInitialFocus: true,
                alwaysRestoreSelectedOptionsMulti: false,
                clearSearchInput: true,
                placeholderLabel: 'Search ....',
                searching: true,
                enableClearOnEscapePressed: true,
            }
        },
         /* Date Picker Formated Endd Nikul*/
        LoaderService, Title, DecimalPipe, DatePipe],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    bootstrap: [AppComponent]
})
export class AppModule { }
