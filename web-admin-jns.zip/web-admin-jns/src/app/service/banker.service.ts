import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonService } from '../CommoUtils/common-services/common.service';
import { HttpService } from '../CommoUtils/common-services/http.service';
import { RestUrl } from '../CommoUtils/resturl';

@Injectable({
  providedIn: 'root'
})
export class BankerService {

  constructor(private http: HttpService) { }

  login(data: any): Observable<any> {
    return this.http.post(RestUrl.LOGIN, data);
  }
  getAccessToken(): Observable<any> {
    return this.http.get(RestUrl.ACCESS_TOKEN, false, false);
  }
  logoutUser(): Observable<any> {//  For Logout User
    return this.http.get(RestUrl.LOGOUT_USER, false);
  }
  getCaptcha(){
    return this.http.get(RestUrl.GET_CAPTCHA, false);
  }

  // getValidations(loanType): Observable<any> {
  //   return this.http.get(RestUrl.GET_VALIDATIONS + CommonService.encryptFuntion(loanType) , false);
  // }
  getLoanMasterList(): Observable<any> {
    return this.http.get(RestUrl.GETLOANMASTERLIST, false);
  }
  
  getSchemeListByLoanType(loanTypeId): Observable<any> {
    return this.http.get(RestUrl.GETSCHEMELIST + '/' + CommonService.encryptFuntion(loanTypeId), false);
  }

  getBankList(orgType): Observable<any> {
    return this.http.get(RestUrl.BANK_LIST + '/' + CommonService.encryptFuntion(orgType), false);
  }
  getDashboradWidgetCount(data: any): Observable<any> {
    return this.http.post(RestUrl.GET_DASHBORAD_WIDGET_COUNT, data);
  }
  
}
