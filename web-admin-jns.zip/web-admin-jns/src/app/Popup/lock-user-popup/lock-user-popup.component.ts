import { Component, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA as MAT_DIALOG_DATA, MatDialogRef as MatDialogRef } from '@angular/material/dialog';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-lock-user-popup',
  templateUrl: './lock-user-popup.component.html',
  styleUrls: ['./lock-user-popup.component.scss']
})
export class LockUserPopupComponent implements OnInit {
  @Input() public popUpObj: any;
  isLock = false;

  constructor(public activeModal: NgbActiveModal,public dialogRef: MatDialogRef<LockUserPopupComponent>,public userService :UserProfileService,
    @Inject(MAT_DIALOG_DATA) public userData: any,public commonService : CommonService) { }

  ngOnInit(): void {
  }

  closePopup(closeType?): void {
    this.dialogRef.close(closeType);
  }

}
