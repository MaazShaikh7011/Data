import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';

@Component({
  selector: 'app-view-rozo-details-popup',
  templateUrl: './view-rozo-details-popup.component.html',
  styleUrls: ['./view-rozo-details-popup.component.scss']
})
export class ViewRozoDetailsPopupComponent implements OnInit {

  @Input() popUpObj;
  userList: any = [];
  constructor(public activeModal: NgbActiveModal,
    private commonMethods: CommonMethods,
    private adminService: AdminPanelServiceService) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.getRoZoDetailsByRoZoId(this.popUpObj.branchRoZoId);
    }, 0);
  }

  getRoZoDetailsByRoZoId(branchRoZoId) {
    this.adminService.getRoZoDetailsByRoZoId(branchRoZoId).subscribe(res => {
      if (res && res.data) {
        this.userList = res.data;
      }
    });
  }

  copyToClipBoard(data) {
    this.commonMethods.copyToClipBoard(data);
  }
}
