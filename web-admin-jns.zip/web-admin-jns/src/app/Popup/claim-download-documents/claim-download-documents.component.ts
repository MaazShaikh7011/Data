import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA as MAT_DIALOG_DATA, MatDialog as MatDialog, MatDialogRef as MatDialogRef } from '@angular/material/dialog';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-claim-download-documents',
  templateUrl: './claim-download-documents.component.html',
  styleUrls: ['./claim-download-documents.component.scss']
})
export class ClaimDownloadDocumentsComponent implements OnInit {
  documentList: any;

  constructor(public dialogRef: MatDialogRef<ClaimDownloadDocumentsComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any, private adminService: AdminPanelServiceService, private commonService: CommonService, private commonMethods: CommonMethods) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.getCommonList();
    }, 0);
  }

  closePopup(closeType?): void {
    this.dialogRef.close(closeType);
  }

  getCommonList(): void {
    const data = {
      applicationId: this.data
    }
    this.adminService.getCommonList('getUplodedDocumentList', JSON.stringify(data)).subscribe(res => {
      if (res?.data) {
        this.documentList = res?.data
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }

  DownloadDocument(documentData) {
    const data = {
      applicationId: documentData.applicationId,
      productDocumentMappingId: documentData.productDocumentMappingId
    }
    this.adminService.downloadDocumentByDocumentMappingId(data).subscribe(res => {
      this.commonMethods.downloadPdf(res, documentData.originalFileName);
    });
  }
}
