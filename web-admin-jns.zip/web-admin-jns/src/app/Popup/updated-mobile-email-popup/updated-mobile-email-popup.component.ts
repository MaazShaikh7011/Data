import { Component, Inject, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA as MAT_DIALOG_DATA, MatDialog as MatDialog, MatDialogRef as MatDialogRef } from '@angular/material/dialog';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';
import { ValidationsService } from 'src/app/CommoUtils/common-services/validations.service';
import { ObjectModel } from 'src/app/CommoUtils/model/object-model';
import { UserProfileService } from 'src/app/CommoUtils/user.service';

@Component({
  selector: 'app-updated-mobile-email-popup',
  templateUrl: './updated-mobile-email-popup.component.html',
  styleUrls: ['./updated-mobile-email-popup.component.scss']
})
export class UpdatedMobileEmailPopupComponent implements OnInit {

  profileForm: UntypedFormGroup;
  emailId:any;
  emailValidation: ObjectModel[] = [{ key: 'required', value: true }, { key: 'pattern', value: '^(([^<>()\\[\\]\\.,;:\\s@"]+(\.[^<>()\\[\\]\\.,;:\\s@"]+)*)|(".+"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))|[6-9][0-9]\\d{8}$' }];
  mobileValidation: ObjectModel[] = [{ key: 'required', value: true }, { key: 'pattern', value: '^((\\+91-?)|0)?[0-9]{10}$' }];

  constructor(public dialogRef: MatDialogRef<UpdatedMobileEmailPopupComponent>, public dialog: MatDialog,private validationsService: ValidationsService,
    @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: UntypedFormBuilder, private userService: UserProfileService, private commonService: CommonService, private commonMethods: CommonMethods) { }

  ngOnInit(): void {
    this.createForm();
  }

  closePopup(closeType?): void {
    this.dialogRef.close(closeType);
  }

  createForm() {
    this.profileForm = this.formBuilder.group({
      emailId: this.validationsService.validationConfig('', this.data?.type==1 ? this.emailValidation : this.mobileValidation),
    })
  }

  updateEmail(): void {
    if (!this.profileForm.valid) {
      this.commonService.warningSnackBar('Please enter valid email address');
      return;
    }
    const data = {
      userId: this.data?.userId,
      userType: this.data?.userType,
      email: this.profileForm.value.emailId
    }
    this.userService.updateEmail(data).subscribe(res => {
      if (res && res?.status == 200) {
        this.commonService.successSnackBar(res.message);
        this.dialogRef.close(this.profileForm.value.emailId);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }

  updateMobile(): void {
    if (!this.profileForm.valid) {
      this.commonService.warningSnackBar('Please enter valid mobile number');
      return;
    }
    const data = {
      userId: this.data?.userId,
      userType: this.data?.userType,
      mobile: this.profileForm.value.emailId
    }
    this.userService.updateMobile(data).subscribe(res => {
      if (res && res?.status == 200) {
        this.commonService.successSnackBar(res.message);
        this.dialogRef.close(this.profileForm.value.emailId);
      } else {
        this.commonService.warningSnackBar(res.message);
      }
    });
  }


}
