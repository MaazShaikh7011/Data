import { Component, Inject, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UpdatedMobileEmailPopupComponent } from '../updated-mobile-email-popup/updated-mobile-email-popup.component';
import { ResetPasswordPopupComponent } from '../reset-password-popup/reset-password-popup.component';
import { LockUserPopupComponent } from '../lock-user-popup/lock-user-popup.component';
import { MAT_DIALOG_DATA as MAT_DIALOG_DATA, MatDialog as MatDialog, MatDialogRef as MatDialogRef } from '@angular/material/dialog';
import { CommonMethods } from 'src/app/CommoUtils/common-services/common-methods';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-confirmation-popup',
  templateUrl: './confirmation-popup.component.html',
  styleUrls: ['./confirmation-popup.component.scss']
})
export class ConfirmationPopupComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ConfirmationPopupComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any, public activeModal: NgbActiveModal,private commonService: CommonService) { }

  ngOnInit(): void {
  }

  closePopup(closeType?): void {
    this.dialogRef.close(closeType);
  }
  openPopUpMat(obj: any, popUpName: any, objClass?: any, disableClose?: boolean) {
    return this.dialog.open(popUpName, { panelClass: objClass, autoFocus: false, data: obj, disableClose: disableClose });
  }

  onLockPopup(){
    const config = {
      windowClass: 'popup-650',
    };
    this.openPopUpMat(config, LockUserPopupComponent, ['popup-650'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        this.dialogRef.close('ok');
      }
    });
  }
  resetPaswordPopup() {
    const config = {
      windowClass: 'popup-650',
    };
    this.openPopUpMat(config, ResetPasswordPopupComponent, ['popup-650'], true).afterClosed().subscribe(result => {
      if (result == 'ok') {
        this.dialogRef.close('ok');
      }
    });
  }

  copyMessage(val: string){
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.commonService.successSnackBar("Password Copied")
  }
}
