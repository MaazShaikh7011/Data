import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../Component/shared/shared.module';
import { ViewRozoDetailsPopupComponent } from './view-rozo-details-popup/view-rozo-details-popup.component';
import { ViewApplicationPopupComponent } from './view-application-popup/view-application-popup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClaimDownloadDocumentsComponent } from './claim-download-documents/claim-download-documents.component';
import { ConfirmationPopupComponent } from './confirmation-popup/confirmation-popup.component';
import { ResetPasswordPopupComponent } from './reset-password-popup/reset-password-popup.component';
import { UpdatedMobileEmailPopupComponent } from './updated-mobile-email-popup/updated-mobile-email-popup.component';
import { LockUserPopupComponent } from './lock-user-popup/lock-user-popup.component';


@NgModule({
  declarations: [
   ViewRozoDetailsPopupComponent,
   ViewApplicationPopupComponent,
   ClaimDownloadDocumentsComponent,
   ConfirmationPopupComponent,
   ResetPasswordPopupComponent,
   UpdatedMobileEmailPopupComponent,
   LockUserPopupComponent
  ],
  imports: [
    CommonModule,    
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PopupModule { }
