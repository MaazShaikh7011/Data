import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA as MAT_DIALOG_DATA, MatDialog as MatDialog, MatDialogRef as MatDialogRef } from '@angular/material/dialog';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-reset-password-popup',
  templateUrl: './reset-password-popup.component.html',
  styleUrls: ['./reset-password-popup.component.scss']
})
export class ResetPasswordPopupComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal,public dialogRef: MatDialogRef<ResetPasswordPopupComponent>, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any,public adminSevice : AdminPanelServiceService,public commonService : CommonService) { }

  ngOnInit(): void {
  }

  closePopup(closeType?): void {
    this.dialogRef.close(closeType);
  }
  
}
