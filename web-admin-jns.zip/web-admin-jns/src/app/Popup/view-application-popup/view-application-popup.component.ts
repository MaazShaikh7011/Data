import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import { AdminPanelServiceService } from 'src/app/CommoUtils/common-services/admin-panel-service.service';
import { CommonService } from 'src/app/CommoUtils/common-services/common.service';

@Component({
  selector: 'app-view-application-popup',
  templateUrl: './view-application-popup.component.html',
  styleUrls: ['./view-application-popup.component.scss']
})
export class ViewApplicationPopupComponent implements OnInit {

  @ViewChild('transferBulkBranch') transferBulkBranch: NgForm;
  @Input() popUpObj;
  submitted = false;
  remark: any;
  searchData;
  page = 1;
  pageSize = 5;
  startIndex = 1;
  endIndex = 10;
  totalCount;
  isSearch: boolean = false;
  pageData: any = [];
  proposalDetailsList: any = [];
  selectedProposalId: any = [];
  branchList: any = [];
  searchList: any = [];
  branchSearch;
  newBranchId;
  PageSelectNumber!: string[];
  constructor(public activeModal: NgbActiveModal,
    private adminPanelServiceService: AdminPanelServiceService,
    private commonService: CommonService) { }

  ngOnInit(): void {
    this.onPageData();
    this.popUpObj;
    this.PageSelectNumber = ['5', '10', '25', '50', '100'];
  }

  onPageData(isCheck?) {
    this.proposalDetailsList = this.popUpObj.proposalDetails;
    if (isCheck) {
      this.pageData = this.searchList.slice(((this.page - 1) * this.pageSize), (this.page * this.pageSize));
    } else {
      this.pageData = this.proposalDetailsList.slice(((this.page - 1) * this.pageSize), (this.page * this.pageSize));
      this.totalCount = this.popUpObj.proposalDetails.length;
    }
    this.startIndex = ((this.page - 1) * this.pageSize) + 1;
    this.endIndex = (this.page * this.pageSize);
    if (this.totalCount < this.endIndex) {
      this.endIndex = this.totalCount;
    }
  }

  isAllChecked(isChecked) {
    if (isChecked) {
      this.selectedProposalId = _.map(this.proposalDetailsList, (x: any) => x.proposaId);
    } else {
      this.selectedProposalId = [];
    }
  }

  isSingleChecked(proposalId) {
    const index = _.indexOf(this.selectedProposalId, proposalId);
    if (index == -1) {
      this.selectedProposalId.push(proposalId);
    } else {
      this.selectedProposalId.splice(index, 1);
    }
    // console.log(this.selectedProposalId)
  }

  updateIsChecked(proposalId) {
    const index = _.indexOf(this.selectedProposalId, proposalId);
    if (index != -1) {
      return true;
    } else {
      return false;
    }
  }

  getBranchDetails(searchName: string) {
    if (searchName.length <= 2) {
      this.branchList = [];
      return;
    }
    const data = {
      name: searchName,
      orgId: this.popUpObj.orgId,
      schTypeId: this.popUpObj.schTypeId,
      branchId: this.popUpObj.branchId,
    }
    this.adminPanelServiceService.searchBranchListBasedOnCodeOrName(data).subscribe(success => {
      if (success.status === 200) {
        this.branchList = _.filter(success.listData, (o: any) => o.id != this.popUpObj.branchId);
      } else {
        this.branchList = [];
      }
    }, error => {

    });
  }

  selectedBranch(branchId) {
    this.newBranchId = branchId;
  }

  resetPageSize() {
    this.page = 1;
    this.pageSize = 5;
  }

  searchApplication() {
    this.pageData = [];
    if (!this.commonService.isObjectNullOrEmpty(this.searchData)) {
      // Search from applicationCode
      this.searchList = this.proposalDetailsList.filter(res => JSON.stringify(res.applicationCode).toLowerCase().includes(this.searchData.toLowerCase()));
      this.totalCount = this.searchList.length;
      this.isSearch = true;
      this.resetPageSize();
      this.onPageData(true);
    } else {
      this.pageData = this.proposalDetailsList;
      this.totalCount = this.proposalDetailsList.length;
      this.isSearch = false;
      this.onPageData();
    }
  }

  updateBranchDetails() {
    if (this.transferBulkBranch.invalid) {
      this.submitted = false
      setTimeout(() => {
        this.submitted = true;
      }, 0);
      return;
    }
    if (!this.newBranchId) {
      this.commonService.warningSnackBar("please Select Bank");
      return;
    }
    if (this.selectedProposalId.length == 0) {
      this.commonService.warningSnackBar("please Select proposal");
      return;
    }

    const data = {
      newBranchId: this.newBranchId,
      oldBranchId: this.popUpObj.branchId,
      businessTypeId: this.popUpObj.businessTypeId,
      proposalIdsList: this.selectedProposalId,
      // profileId: this.popUpObj.profileId,
      remark: this.remark
    }
    this.activeModal.dismiss(data);
  }

}
