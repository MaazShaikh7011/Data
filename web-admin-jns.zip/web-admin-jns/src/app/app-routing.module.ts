import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './Component/layout/layout.component';

const routes: Routes = [
  // , canActivate: [AuthGuard]
  { path: '', component: LayoutComponent, loadChildren: () => import('./Component/pages/pages.module').then(m => m.PagesModule) },
  { path: 'Admin', component: LayoutComponent, loadChildren: () => import('./Component/Admin-panel/admin-panel.module').then(m => m.AdminPanelModule) },
  { path: '**', redirectTo: 'login' },
];
@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
