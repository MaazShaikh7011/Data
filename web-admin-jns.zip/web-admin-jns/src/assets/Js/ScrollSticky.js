$(function ($) {
  var left = document.getElementById("stick-header");
  var stop = (left.offsetTop - 120);
  window.onscroll = function (e) {
    /* debugger; */
    var scrollTop = (window.pageYOffset !== undefined) ? window.pageYOffset :
      (document.documentElement || document.body.parentNode || document.body).scrollTop;
    // console.log(scrollTop, left.offsetTop);
    left.offsetTop;

    if (scrollTop >= stop) {
      left.className = 'card-box btn-tabs fix-to-top';
      // console.log(scrollTop, left.offsetTop);
    } else {
      left.className = 'card-box btn-tabs';
    }

  }
})
