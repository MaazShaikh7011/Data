package com.opl.bucket.storage.model;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Component
public class BucketListProxy {

	private List<BucketProxy> bucketProxies;

//	public BucketProxy filter(String bucketName) {
//		Optional<BucketProxy> srBucketPrx = bucketProxies.stream().filter(a -> Objects.equals(a.getBucketName(), bucketName) || Objects.equals(a.getBucketCode(), bucketName)).findFirst();
//		return srBucketPrx.orElse(null);
//	}



	public BucketProxy filter(String bucketName) {
		Optional<BucketProxy> srBucketPrx = bucketProxies.stream().filter(a -> a.getBucketName().equals(bucketName))
				.findFirst();
		return srBucketPrx.isPresent() ? srBucketPrx.get() : null;
	}

}
