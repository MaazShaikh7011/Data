package com.opl.bucket.storage.config;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.bucket.storage.model.BucketListProxy;
import com.opl.bucket.storage.model.BucketEnrlmntProp;
import com.opl.bucket.storage.model.BucketProxy;
import com.opl.bucket.storage.utils.EncryptionUtils;
import com.opl.bucket.storage.utils.OPLBkUtils;
import com.opl.bucket.storage.utils.OPLJSONObjectHelper;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BucketLoad {

	@Autowired
	private ApplicationContext applicationContext;

	/**
	 * CREATE MULTIPLE BEAN FROM ENROLLMENT PROPERTIES CONFIGURATION
	 *
     */
	@Bean
	public BucketListProxy getS3BucketList() {
		BucketListProxy bucketListProxy = null;
		try {

//			String decrypt = "[{\"bucketName\":\"prod-jansuraksha-data\",\"bucketPath\":\"request\",\"accessKey\":\"AKIAV6JCA72NOCAUP7BF\",\"secretKey\":\"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\",\"url\":\"https://prod-jansuraksha-data.s3.ap-south-1.amazonaws.com\",\"access\":\"private\",\"bucketType\":\"S3\"}]";

			/* LOAD CONFIGURATION FROM SYSTEM ENROLLMENT PROPERTIES */
			String configuration = System.getenv(OPLBkUtils.ENROLLMENT_PROP_NAME);
			log.info("configuration   === >{}",configuration);
			if (!OPLBkUtils.isObjectNullOrEmpty(configuration)) {

				/* DECRYPT CONFIGURATION PROPERTIES USING ENCRYPTION UTILS */
				String decrypt = EncryptionUtils.decrypt(configuration);
				log.info("Decrypted configuration   === >{}",decrypt);
				@SuppressWarnings("unchecked")
				List<BucketEnrlmntProp> bkList = OPLJSONObjectHelper.getListOfObjects(decrypt, null,
						BucketEnrlmntProp.class);
				if (!bkList.isEmpty()) {
					List<BucketProxy> bucketProxies = new ArrayList<>(bkList.size());
					BucketProxy bucketProxy = null;
					for (BucketEnrlmntProp properties : bkList) {
						log.info("In forloop for Prop ==={}",properties);
						if(!"LOCAL".equalsIgnoreCase(properties.getBucketType())) {
							log.info("Uploading in S3");
							bucketProxy = new BucketProxy(properties.getBucketName(), properties.getBucketCode(), properties.getBucketPath(),
									properties.getUrl(), amazons3(properties));
							bucketProxies.add(bucketProxy);
						} else {
							log.info("Uploading in Local");
							bucketProxy = new BucketProxy(properties.getBucketName(), properties.getBucketCode(), properties.getBucketPath(), properties.getUrl(), null);
							bucketProxies.add(bucketProxy);
						}
						//bucketProxies.add(bucketProxy);
					}
					bucketListProxy = new BucketListProxy(bucketProxies);
					applicationContext.getAutowireCapableBeanFactory().autowireBean(bucketListProxy);
				}
			}
		} catch (Exception e) {
			log.error("Exception while load Bucket Beans - ", e);
			((ConfigurableApplicationContext) applicationContext).close();
		}
		return bucketListProxy;
	}

	/**
	 * PREPARE AmazonS3 OBJECT
	 *
     */
	public AmazonS3 amazons3(BucketEnrlmntProp bucket) {
//		if ("S3DEFAULTCLIENT".equalsIgnoreCase(bucket.getBucketType())) {
//			return AmazonS3ClientBuilder.defaultClient();
//		}
//		log.error("{bucketType:S3DEFAULTCLIENT} is not set in server Environment");
//		return null;
		return AmazonS3ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials(bucket)))
				.withRegion(Regions.AP_SOUTH_1).build();
	}

	/*
	 * CONFIGURE CREDENTIALS FOR AWS S3 ACCESS
	 * 
	 * @param bucket
	 * @return
	 */
	public AWSCredentials basicAWSCredentials(BucketEnrlmntProp bucket) {
		AWSCredentials credentials = new BasicAWSCredentials(bucket.getAccessKey(), bucket.getSecretKey());
		applicationContext.getAutowireCapableBeanFactory().autowireBean(credentials);
		return credentials;
	}

}
