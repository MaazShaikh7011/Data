package com.opl.bucket.storage.utils;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptionUtils {
	private static final String ALGORITHM = "AES";
	private static final String KEY = "C@p!tta@W0rld#AES";
	public static final String MD5 = "MD5";

	private static final Logger logger = (Logger) LoggerFactory.getLogger(EncryptionUtils.class);

	/**
	 * ENCRYPT PLAIN TEXT
	 * 
	 * @param plainText
	 * @return
	 */
	public static String encrypt(String plainText) {
		try {
			if (!OPLBkUtils.isObjectNullOrEmpty(plainText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);

				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.ENCRYPT_MODE, key);

				byte[] cleartext = plainText.getBytes(StandardCharsets.UTF_8);
				byte[] ciphertextBytes = cipher.doFinal(cleartext);

				return new String(Hex.encodeHex(ciphertextBytes));
			}
		} catch (Exception e) {
			logger.error("Error while encrypting data : " + plainText, e);
		}
		return null;
	}

	/**
	 * DECRYPT TEXT
	 * 
	 * @param encryptedText
	 * @return
	 */
	public static String decrypt(String encryptedText) {
		try {
			if (!OPLBkUtils.isObjectNullOrEmpty(encryptedText)) {
				byte[] keyBytes = Arrays.copyOf(KEY.getBytes("ASCII"), 16);
				SecretKey key = new SecretKeySpec(keyBytes, ALGORITHM);
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.DECRYPT_MODE, key);
				return new String(cipher.doFinal(Hex.decodeHex(encryptedText.toCharArray())));
			}
		} catch (Exception e) {
			logger.error("Error while decrypting data : " + encryptedText, e);
		}
		return null;
	}

	public static void main(String[] args) {
		String buc = "9a5fde1d9ff6a9a6d6eec72b606578ee39def9c4421443388e54a570cb20924223d8aea9885e94e4b315c521e27503ed1324cce39784aaa39dfeb6cffecea68330f39a3a194b32b4ca76527ee1e6136b36bc43c92b9013a16d3789c5cf5cfe181e90f878954d03cc8e042197d82d3cd7ce06318aefbc083268d5dce0ff9b293bd1040c22db667ea312ff822caf4152b95dca3f037e8a2788efbc3c497a7a460371f7a8a157c0cb5dcaf63b5b16ca0d8e8365918cadc567bd697f885447a8d8e96b9304cb090ddf0e24f06549d80dc38e4d1c037197696e5afd1703896c134ace67401db24b889a72ca2eb3992918c947";
//		String buc = "9a5fde1d9ff6a9a6d6eec72b606578ee39def9c4421443388e54a570cb20924223d8aea9885e94e4b315c521e27503ed1324cce39784aaa39dfeb6cffecea68330f39a3a194b32b4ca76527ee1e6136b36bc43c92b9013a16d3789c5cf5cfe181e90f878954d03cc8e042197d82d3cd7ce06318aefbc083268d5dce0ff9b293bd1040c22db667ea312ff822caf4152b95dca3f037e8a2788efbc3c497a7a460371f7a8a157c0cb5dcaf63b5b16ca0d8e8365918cadc567bd697f885447a8d8e96b9304cb090ddf0e24f06549d80dc38e4d1c037197696e5afd1703896c134ace67401db24b889a72ca2eb3992918c947";
		System.out.println(decrypt(buc));
		String enc = "[\n" +
				"    {\n" +
				"        \"bucketName\": \"development-hsbc-data-dev\",\n" +
				"        \"bucketCode\": \"NA\",\n" +
				"        \"bucketPath\": \"dev-hsbc\",\n" +
				"        \"url\": \"https: //development-hsbc-data-dev.s3.ap-south-1.amazonaws.com\",\n" +
				"        \"access\": \"Private\",\n" +
				"        \"bucketType\": \"S3DEFAULTCLIENT\",\n" +
				"        \"accessKey\": \"NA\",\n" +
				"        \"secretKey\": \"NA\"\n" +
				"    }\n" +
				"]";
		System.out.println(encrypt((enc)));
	}

}
