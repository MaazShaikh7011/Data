package com.opl.bucket.storage.controller;

import java.util.List;
import java.util.UUID;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.bucket.storage.utils.OPLBkUtils;
import com.opl.bucket.storage.utils.TestObject;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author ravi.thummar Date : 13-09-2023
 */
@RestController
@Hidden
@Slf4j
public class BucketController {

	@Autowired
	private BucketStorageUtils bucketStorageUtils;

	/**
	 * ONLY FOR TESTING PURPOSE
	 * 
	 * @param bucketName
	 * @return
	 */
	@GetMapping(value = "/opl/bucket/seriablize/{bucketName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> uploadedReqResFile(@PathVariable("bucketName") String bucketName) {
		TestObject test = new TestObject().toBuilder().id(1).message("Success").status(200).build();
		String randomName = UUID.randomUUID().toString();
		bucketStorageUtils.upload(bucketName, test, randomName);
		return ResponseEntity.status(HttpStatus.OK).body("Success");
	}

	@GetMapping(value = "/opl/bucket/deseriablize/{fileName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUploadedReqResFile(@PathVariable("fileName") String fileName) {
		String bucketName =  System.getenv(OPLBkUtils.ENROLLMENT_BUCKET_NAME);
		if(OPLBkUtils.isObjectNullOrEmpty(bucketName)){
			return ResponseEntity.status(HttpStatus.OK).body("Environment Bucket is Empty");
		}
		Object deserializeUploadedFile = bucketStorageUtils.getFileObject(bucketName, fileName);
		return ResponseEntity.status(HttpStatus.OK).body(deserializeUploadedFile);
	}

	@GetMapping(value = "/opl/bucket/deseriablize/{bucketName}/{fileName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUploadedReqResFile(@PathVariable("bucketName") String bucketName, @PathVariable("fileName") String fileName) {
		Object deserializeUploadedFile = bucketStorageUtils.getFileObject(bucketName, fileName);
		return ResponseEntity.status(HttpStatus.OK).body(deserializeUploadedFile);
	}

	/**
	 * Read text content from file and return it
	 */
	@GetMapping(value = "/opl/bucket/getTextData/{fileName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUploadedReqResTextFile(@PathVariable("fileName") String fileName) {
		try {
			String bucketName =  System.getenv(OPLBkUtils.ENROLLMENT_BUCKET_NAME);
			if(OPLBkUtils.isObjectNullOrEmpty(bucketName)){
				return ResponseEntity.status(HttpStatus.OK).body("Environment Bucket is Empty");
			}
			Object deserializeUploadedFile = bucketStorageUtils.getTextFileData(bucketName, fileName);
			return ResponseEntity.status(HttpStatus.OK).body(deserializeUploadedFile);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	/**
	 * For get all uploaded files on Bucket path
	 * @author ketan.goswami
	 * @date 03-Jun-2024
	 */
	@GetMapping(value = "/opl/bucket/listFiles/{path}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> listFilesInBucket(@PathVariable("path") String path) {
		try {
			String bucketName = System.getenv(OPLBkUtils.ENROLLMENT_BUCKET_NAME);

			if (OPLBkUtils.isObjectNullOrEmpty(bucketName)) {
				log.error("Environment bucket name is empty or null.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Environment Bucket is Empty");
			}

			List<String> fileList = bucketStorageUtils.listFiles(bucketName, path);

			if (fileList.isEmpty()) {
				log.info("No files found in path: {}", path);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No files found");
			}

			return ResponseEntity.ok().body(fileList);
		} catch (Exception e) {
			log.error("Exception occurred while listing files in path: {}", path, e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error listing files");
		}
	}

	/**
	 * FOR GET FILE BYTES FROM FILENAME AND EXTENSION
	 *
	 * @param fileName
	 * @param extension
	 * @return File Bytes
	 * @author ketan.goswami
	 * @date 03-Jun-2024
	 */
	@GetMapping(value = "/opl/bucket/deseriablizeFile/{fileName}/{extension}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getUploadedFileByteArr(@PathVariable("fileName") String fileName,@PathVariable("extension") String extension) {
		try{
			String bucketName =  System.getenv(OPLBkUtils.ENROLLMENT_BUCKET_NAME);
			if(OPLBkUtils.isObjectNullOrEmpty(bucketName)){
				System.out.println("Environment bucket name is empty or null.");
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Environment Bucket is Empty");
			}
			byte[] byteArr = bucketStorageUtils.getFileByReferenceId(bucketName, fileName, extension);

			if (byteArr == null) {
				System.out.println("File not found: " + fileName +"." +  extension);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found");
			}
			return ResponseEntity.ok().body(byteArr);
		} catch (Exception e) {
			System.out.println("Exception occurred while retrieving file:"+ fileName +"." +  extension +" - " + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving file");
		}
	}

}
