package com.opl.bucket.storage.repository;

import com.opl.bucket.storage.domain.DOCStorage;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author ravi.thummar
 * Date : 13-09-2023
 */
public interface DOCStorageRepository extends JpaRepository<DOCStorage, Long> {

    public
    DOCStorage findByReferenceId(String referenceId);
}
