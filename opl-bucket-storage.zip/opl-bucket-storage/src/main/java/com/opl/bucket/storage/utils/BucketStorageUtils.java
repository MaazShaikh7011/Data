package com.opl.bucket.storage.utils;

import com.amazonaws.services.s3.model.*;
import com.amazonaws.util.IOUtils;
import com.opl.bucket.storage.domain.DOCStorage;
import com.opl.bucket.storage.model.BucketListProxy;
import com.opl.bucket.storage.model.BucketProxy;
import com.opl.bucket.storage.repository.DOCStorageRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
public class BucketStorageUtils {

    @Autowired
    private BucketListProxy bucketListProxy;

    @Autowired
    private DOCStorageRepository docStorageRepository;

    /**
     * UPLOAD CLASS OBJECT FILE IN BUCKET
     *
     * @param bucketName
     * @param object
     * @param docRefrenceId (Optional)
     * @return
     */
    public String upload(String bucketName, Object object, String docRefrenceId) {
        DOCStorage docStorage = new DOCStorage(docRefrenceId, false);
        try {
            if (OPLBkUtils.isObjectNullOrEmpty(docRefrenceId)) {
                docRefrenceId = OPLBkUtils.generateUUID();
                docStorage.setReferenceId(docRefrenceId);
            }
            BucketProxy s3Bucket = validate(bucketName, docStorage);
            if (s3Bucket == null) {
                return null;
            }
            File file;
            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                file = new File(s3Bucket.getBucketPath() + docRefrenceId + ".txt");
            } else {
                file = new File(docRefrenceId + ".txt");
            }
            try {
                ObjectOutputStream objectOS = new ObjectOutputStream(new FileOutputStream(file));
                log.info("File details ==>{}",file);
                objectOS.writeObject(object);
                objectOS.close();
            } catch (Exception e) {
                log.error("EXCEPTION WHILE OBJECT SERIALIZATION -", e);
                docStorage.setMessage("EXCEPTION WHILE FILE WRITE: " + e.getMessage());
                return null;
            }
            docStorage.setFileSize(file.getTotalSpace());
            docStorage.setFileType(FilenameUtils.getExtension(file.getName()));
            docStorage.setOriginalName(file.getName());
            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                docStorage.setIsActive(true);
                return docRefrenceId;
            }
            boolean uploadFile = uploadFile(file, docRefrenceId, s3Bucket, docStorage, file.getName());
            if (uploadFile) {
                return docRefrenceId;
            }
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPLOAD OBJECT IN BUCKET ---->", e);
            docStorage.setMessage(e.getMessage());
        } finally {
            if (!docStorage.getIsActive()) {
                docStorage.setModifiedDate(new Date());
                docStorageRepository.save(docStorage);
            }
        }
        return null;
    }

    /**
     * UPLOAD FILE IN BUCKET
     *
     * @param bucketName    (Configure in Enrollment Variables)
     * @param file
     * @param docRefrenceId (Optional)
     * @return
     */
    @SuppressWarnings("ResultOfMethodCallIgnored")
    public String upload(String bucketName, File file, String docRefrenceId) {
        DOCStorage docStorage = new DOCStorage(docRefrenceId, FilenameUtils.getExtension(file.getName()), file.getName(),
                null, file.getTotalSpace(), null, false);
        try {
            if (OPLBkUtils.isObjectNullOrEmpty(docRefrenceId)) {
                docRefrenceId = OPLBkUtils.generateUUID();
                docStorage.setReferenceId(docRefrenceId);
            }

            BucketProxy s3Bucket = validate(bucketName, docStorage);
            if (s3Bucket == null) {
                return null;
            }
            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                String path = bucketListProxy.filter(bucketName).getBucketPath();
                log.info("Path ====>{}",path);
                String fileName = System.currentTimeMillis() + "_" + file.toPath().getFileName();
                File newFile = new File(path + fileName);
                byte[] bytes = Files.readAllBytes(file.toPath());
                Files.write(newFile.toPath(), bytes);
                log.info("Old File ==>{}",file);
                log.info("new File ==>{}",newFile);
                if (file.exists()) {
                    file.delete();
                }
                docStorage.setIsActive(true);
                return fileName;
            }

            String fileName = docRefrenceId + "." + FilenameUtils.getExtension(file.getName());
            boolean uploadFile = uploadFile(file, docRefrenceId, s3Bucket, docStorage, fileName);
            if (uploadFile) {
                return docRefrenceId;
            }
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPLOAD FILE IN BUCKET ---->", e);
            docStorage.setMessage(e.getMessage());
        } finally {
            if (!docStorage.getIsActive()) {
                docStorage.setModifiedDate(new Date());
                docStorageRepository.save(docStorage);
            }
        }
        return null;
    }

    /**
     * FETCH SERIALIZATION OBJECT FROM S3 BUCKET
     * @param bucketName
     * @param docRefrenceId
     * @return
     */
    @SuppressWarnings("ResultOfMethodCallIgnored")
    public Object getFileObject(String bucketName, String docRefrenceId) {
        File file = null;
        try {
            BucketProxy s3Bucket = bucketListProxy.filter(bucketName);
            if (s3Bucket == null) {
                log.error("NO BUCKET FOUND FROM BUCKET NAME --->" + bucketName);
                return null;
            }
            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                log.info("s3Bucket.getAmazonS3() is null so it's consider as local Getting mechanism =====================>  ");
                String path = s3Bucket.getBucketPath();
                Path filePath = Path.of(path + docRefrenceId);
                return Files.readAllBytes(filePath);
            }
            docRefrenceId = docRefrenceId + ".txt";
            file = convertS3ByteToFile(s3Bucket, docRefrenceId);
            if (file == null) {
                log.error("NO FILE FOUND FROM BUCKET --->" + docRefrenceId);
                return null;
            }
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                return ois.readObject();
            }
        } catch (Exception e) {
            log.error("EXCEPTION WHILE GET FILE FROM S3 BUCKET Bytes :-", e);
            return null;
        } finally {
            if (file != null) {
                file.delete();
            }
        }
    }

    /**
     * FILTER BUCKET AND VALIDATE
     *
     * @param bucketName
     * @return
     */
    private BucketProxy validate(String bucketName, DOCStorage docStorage) {
        BucketProxy s3Bucket = bucketListProxy.filter(bucketName);
        log.info("S3 OBJECT ==>{}",s3Bucket);
        if (s3Bucket == null) {
            log.error("NO BUCKET FOUND FROM BUCKET NAME ---> " + bucketName);
            docStorage.setMessage("NO BUCKET FOUND FROM BUCKET NAME --->" + bucketName);
            return null;
        }
        if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
            log.info("s3Bucket.getAmazonS3() is null so it's consider as local Saving mechanism =====================> ");
            return s3Bucket;
        }
        boolean doesBucketExist = s3Bucket.getAmazonS3().doesBucketExist(s3Bucket.getBucketName() + "/" + s3Bucket.getBucketPath());
        if (doesBucketExist) {
            return s3Bucket;
        }
        log.warn("FOLDER PATH NOT EXIST CHECK WITH BUCKET NAME ONLY -" + s3Bucket.getBucketName() + "/" + s3Bucket.getBucketPath());
        doesBucketExist = s3Bucket.getAmazonS3().doesBucketExist(s3Bucket.getBucketName());
        if (doesBucketExist) {
            return s3Bucket;
        }
        log.warn("BUCKET PATH AND FOLDER BOTH NOT AVAILABLE -" + s3Bucket.getBucketName() + "/" + s3Bucket.getBucketPath());
        docStorage.setMessage("BUCKET PATH NOT AVAILABLE -" + s3Bucket.getBucketName() + "/" + s3Bucket.getBucketPath());
        return null;
    }

    private boolean uploadFile(File file, String referenceId, BucketProxy bucket, DOCStorage docStorage, String uploadFileName) {
        try {
            // SET FILE DETAILS IN AUDIT TABLE
            docStorage.setFileType(FilenameUtils.getExtension(file.getName()));
            docStorage.setOriginalName(file.getName());
            docStorage.setFileSize(file.getTotalSpace());
            //log.info("docStorage ---> {}", docStorage);
            // UPLOAD FILE IN S3 BUCKET
            bucket.getAmazonS3().putObject(
                    new PutObjectRequest(bucket.getBucketName(), bucket.getBucketPath() + "/" + uploadFileName, file));
            // SET BUCKET URL
            String url = bucket.getUrl().concat(bucket.getBucketPath()).concat("/").concat(uploadFileName);
            //log.info("url ---> {}", url);
            //https://development-hsbc-data.s3.ap-south-1.amazonaws.comdev-hsbc/UPLOAD-61b3c9bf-2a41-4f56-8d42-5b1f0ba4a35d.txt

            docStorage.setDocUrl(url);
            docStorage.setMessage("SUCCESS");
            docStorage.setIsActive(true);
            return true;
        } catch (Exception e) {
            log.error("EXCEPTION WHILE UPLOADING FILE ---> ", e);
            docStorage.setMessage("EXCEPTION WHILE UPLOAD FILE: " + e.getMessage());
//			e.printStackTrace();
        } finally {
            if (file.exists()) {
                file.delete();
            }
        }
        return false;
    }


    private File convertS3ByteToFile(BucketProxy s3Bucket, String fileName) {
        try {
            byte[] fileInByte = getFileBytesFromS3Bucket(fileName, s3Bucket);
            if (fileInByte == null) {
                return null;
            }
            File baseDir = new File("upload");
            if (!baseDir.isDirectory()) {
                baseDir.mkdir();
            }
            File file = new File(baseDir.getAbsolutePath() + "/" + fileName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(fileInByte);
            fos.close();
            return file;
        } catch (IOException e) {
            log.error("EXCEPTION WHILE READ FILE FROM S3 BUCKET Bytes :-", e);
            return null;
        }
    }

    private byte[] getFileBytesFromS3Bucket(String fileName, BucketProxy bucket) {
        try {
            log.info("Fetching from bucket: {}/{}", bucket.getBucketName(), bucket.getBucketPath());

            S3Object s3Object = bucket.getAmazonS3().getObject(bucket.getBucketName() + "/" + bucket.getBucketPath(), fileName);

            if (s3Object == null) {
                log.info("S3 object is null");
                return null;
            } else {
                log.info("S3 object retrieved successfully");
            }

            try (S3ObjectInputStream inputStream = s3Object.getObjectContent()) {
                return IOUtils.toByteArray(inputStream);
            } catch (IOException e) {
                log.error("Error while reading file content from bucket {}: {}", bucket.getBucketName(), e.getMessage());
                return null;
            }
        } catch (Exception e) {
            log.error("Exception while getting file from bucket", e);
            return null;
        }
    }

    /**
     * This will upload text content of object
     */
    public String uploadTextFile(String bucketName, String data, String docRefrenceId) {
        File file = null;
        try {
            file = new File(docRefrenceId + ".txt");
            Files.write(file.toPath(), data.getBytes());
            return upload(bucketName, file, docRefrenceId);
        } catch (Exception e) {
            return null;
        } finally {
            if (!OPLBkUtils.isObjectNullOrEmpty(file)) {
                boolean delete = file.delete();
                if (delete) {
                    log.info("File deleted.");
                }
            }
        }
    }


    /**
     * Read text content from file and return it
     */
    public Object getTextFileData(String bucketName, String docRefrenceId) {
        try {
            BucketProxy s3Bucket = bucketListProxy.filter(bucketName);
            if (s3Bucket == null) {
                log.error("NO BUCKET FOUND FROM BUCKET NAME --->" + bucketName);
                return null;
            }

            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                log.info("s3Bucket.getAmazonS3() is null so it's consider as local Getting mechanism =====================> ");
                Path filePath = Path.of(s3Bucket.getBucketPath() + docRefrenceId);
                return new String(Files.readAllBytes(filePath));
            }

            docRefrenceId = docRefrenceId + ".txt";
            byte[] fileBytes = getFileBytesFromS3Bucket(docRefrenceId, s3Bucket);
            return new String(fileBytes);
        } catch (Exception e) {
            log.error("EXCEPTION WHILE GET FILE FROM S3 BUCKET Bytes :-", e);
            return null;
        }
    }

    /**
     * FETCH ORIGINAL FILE FROM REFERENCE ID
     * @param bucketName
     * @param docRefrenceId
     * @return
     */
    public byte[] getFileByReferenceId(String bucketName, String docReferenceId, String extension) {
        try {
            log.info("Fetching file from bucket. Bucket: {}, Doc Reference ID: {}, Extension: {}", bucketName, docReferenceId, extension);

            // Check for null or empty bucket name
            if (bucketName == null || bucketName.isEmpty()) {
                log.error("Bucket name is null or empty.");
                return null;
            }

            BucketProxy s3Bucket = bucketListProxy.filter(bucketName);
            if (s3Bucket == null) {
                log.error("No bucket found with name: {}", bucketName);
                return null;
            }
            if (OPLBkUtils.isObjectNullOrEmpty(s3Bucket.getAmazonS3())) {
                log.info("s3Bucket.getAmazonS3() is null so it's consider as local Getting mechanism =====================> ");
                Path filePath = Path.of(s3Bucket.getBucketPath() + docReferenceId);
                return Files.readAllBytes(filePath);
            }

            log.info("Bucket found: {}", s3Bucket.getBucketName());

            String fileName = docReferenceId + "." + extension;
            log.info("Fetching file: {}", fileName);

            return getFileBytesFromS3Bucket(fileName, s3Bucket);
        } catch (Exception e) {
            log.error("Exception while fetching file from bucket", e);
            return null;
        }
    }

    // Add this method to your BucketProxy class
    public List<String> listFiles(String bucketName, String path) {
        List<String> fileList = new ArrayList<>();

        BucketProxy s3Bucket = bucketListProxy.filter(bucketName);
        if (s3Bucket == null) {
            log.error("NO BUCKET FOUND FROM BUCKET NAME --->" + bucketName);
            return null;
        }
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
                .withBucketName(bucketName)
                .withPrefix(path);

        ObjectListing objectListing;
        do {
            objectListing = s3Bucket.getAmazonS3().listObjects(listObjectsRequest);
            for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
                fileList.add(objectSummary.getKey());
            }
            listObjectsRequest.setMarker(objectListing.getNextMarker());
        } while (objectListing.isTruncated());

        return fileList;
    }

}
