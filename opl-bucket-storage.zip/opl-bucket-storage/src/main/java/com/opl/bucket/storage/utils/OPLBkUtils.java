package com.opl.bucket.storage.utils;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

public class OPLBkUtils {
	
	public static String ENROLLMENT_PROP_NAME = "OPL_BUCKET_STRG";
	public static String ENROLLMENT_BUCKET_NAME = "REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME";

	public static boolean isListNullOrEmpty(Collection<?> data) {
		return (data == null || data.isEmpty());
	}

	public static String isStringEmpty(String value) {
		value = value.trim();
		if (value.isEmpty() || value == null || "undefined".equals(value) || "null".equals(value) || "".equals(value)) {
			return "";
		}
		return value;
	}

	public static boolean isObjectNullOrEmpty(Object value) {
		return (value == null
				|| (value instanceof String
						? (((String) value).isEmpty() || "".equals(((String) value).trim()) || "null".equals(value)
								|| "(null)".equals(value) || "undefined".equals(value))
						: false));
	}

	public static boolean isObjectNullOrEmptyOrNAOrDash(Object value) {
		return (value == null
				|| (value instanceof String
						? (((String) value).isEmpty() || "".equals(((String) value).trim()) || "null".equals(value)
								|| "(null)".equals(value) || "undefined".equals(value)
								|| "NA".equalsIgnoreCase((String) value) || "-".equals(value))
						: false));
	}

	public static Object replaceIfNull(Object value, Object replaceValue) {
		return isObjectNullOrEmpty(value) ? replaceValue : value;
	}

	public static String replaceStringIfNull(Object value, String replaceValue) {
		return isObjectNullOrEmpty(value) ? replaceValue : value.toString();
	}

	public static boolean isObjectNullOrEmptyOrDash(Object value) {
		return (value == null
				|| (value instanceof String
						? (((String) value).isEmpty() || "".equals(((String) value).trim()) || "null".equals(value)
								|| "(null)".equals(value) || "-".equals(value) || "undefined".equals(value))
						: false));
	}

	@SuppressWarnings("rawtypes")
	public static boolean isObjectListNull(Object... args) {
		for (Object object : args) {
			boolean flag = false;
			if (object instanceof List) {
				flag = isListNullOrEmpty((List) object);
				if (flag)
					return true;
				else
					continue;
			}
			flag = isObjectNullOrEmpty(object);
			if (flag)
				return true;
		}
		return false;
	}

	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}

}
