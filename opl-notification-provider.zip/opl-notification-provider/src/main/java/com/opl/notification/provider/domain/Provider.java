package com.opl.notification.provider.domain;

import com.opl.notification.provider.enums.NotificationType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Entity
@Setter
@Getter
@Table(name = "notification_provider", indexes =
        {
                @Index(name = "NOTIFICATION_PROVIDER_ACT_IDX",columnList = "IS_ACTIVE")
        })
@NamedQuery(name = "Provider.findAll", query = "SELECT n FROM Provider n")
@NoArgsConstructor
public class Provider implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_provider_seq_gen")
    @SequenceGenerator(name = "notification_provider_seq_gen", sequenceName = "notification_provider_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @Column(name = "IS_ACTIVE")
    private String isActive;

    @Column(name = "MODIFIED_BY")
    private Long modifiedBy;

    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;

    private String password;

    @Column(name = "REQUEST_URL")
    private String requestUrl;

    private String username;

    @Column(name = "NOTIFICATION_TYPE_ID")
    private Long notificationType;

    @Column(name = "PROVIDER_NAME")
    private String providerName;

    @Column(name = "TOKEN")
    private String token;

    @Column(name = "VERSION")
    private String version;

    @Column(name = "API_KEY")
    private String key;

    /* SET ENUM BASES ON TYPE */
    @Transient
    private NotificationType type;

    @PostLoad
    void fillTransient() {
        if (type != null) {
            this.type = NotificationType.fromId(notificationType);
        }
    }

}