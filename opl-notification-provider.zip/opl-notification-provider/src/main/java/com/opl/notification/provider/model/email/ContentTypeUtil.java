package com.opl.notification.provider.model.email;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public class ContentTypeUtil {

    public static Integer UPLOAD_IN_FOLDER = 1; // for KMS algorithm Applied

    private ContentTypeUtil() {
        // Do nothing because of X and Y.
    }

    public static String getContentType(String type) {
        String result = null;
        switch (type) {
            case "aac":
                result = "audio/aac";
                break;
            case "abw":
                result = "application/x-abiword";
                break;
            case "arc":
                result = "application/x-freearc";
                break;
            case "avi":
                result = "video/x-msvideo";
                break;
            case "azw":
                result = "application/vnd.amazon.ebook";
                break;
            case "bin":
                result = "application/octet-stream";
                break;
            case "bmp":
                result = "image/bmp";
                break;
            case "bz":
                result = "application/x-bzip";
                break;
            case "bz2":
                result = "application/x-bzip2";
                break;
            case "csh":
                result = "application/x-csh";
                break;
            case "csv":
                result = "text/csv";
                break;
            case "doc":
                result = "application/msword";
                break;
            case "docx":
                result = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                break;
            case "eot":
                result = "application/vnd.ms-fontobject";
                break;
            case "epub":
                result = "application/epub+zip";
                break;
            case "gz":
                result = "application/gzip";
                break;
            case "gif":
                result = "image/gif";
                break;
            case "htm":
            case "html":
                result = "text/html";
                break;
            case "jar":
                result = "application/java-archive";
                break;
            case "jpeg":
            case "jpg":
                result = "image/jpeg";
                break;
            case "json":
                result = "application/json";
                break;
            case "jsonld":
                result = "application/ld+json";
                break;
            case "mid":
            case "midi":
                result = "audio/midi audio/x-midi";
                break;
            case "mp3":
                result = "audio/mpeg";
                break;
            case "mp4":
                result = "video/mp4";
                break;
            case "mpeg":
                result = "video/mpeg";
                break;
            case "mpkg":
                result = "application/vnd.apple.installer+xml";
                break;
            case "odp":
                result = "application/vnd.oasis.opendocument.presentation";
                break;
            case "ods":
                result = "application/vnd.oasis.opendocument.spreadsheet";
                break;
            case "odt":
                result = "application/vnd.oasis.opendocument.text";
                break;
            case "oga":
                result = "audio/ogg";
                break;
            case "ogv":
                result = "video/ogg";
                break;
            case "ogx":
                result = "application/ogg";
                break;
            case "png":
                result = "image/png";
                break;
            case "pdf":
                result = "application/pdf";
                break;
            case "ppt":
                result = "application/vnd.ms-powerpoint";
                break;
            case "pptx":
                result = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                break;
            case "rar":
                result = "application/vnd.rar";
                break;
            case "rtf":
                result = "application/rtf";
                break;
            case "svg":
                result = "image/svg+xml";
                break;
            case "tar":
                result = "application/x-tar";
                break;
            case "tif":
            case "tiff":
                result = "image/tiff";
                break;
            case "ts":
                result = "video/mp2t";
                break;
            case "txt":
                result = "text/plain";
                break;
            case "xls":
                result = "application/vnd.ms-excel";
                break;
            case "xlsx":
                result = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                break;
            case "xml":
                result = "application/xml";
                break;
            case "3gp":
                result = "video/3gpp";
                break;
            case "3g2":
                result = "video/3gpp2";
                break;
            case "7z":
                result = "application/x-7z-compressed";
                break;
            default:
                result = "application/octet-stream";
                break;
        }
        return result;
    }
}

