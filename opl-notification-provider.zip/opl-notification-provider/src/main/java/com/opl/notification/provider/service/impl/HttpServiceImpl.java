package com.opl.notification.provider.service.impl;

import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.NotificationCommonRes;
import com.opl.notification.provider.service.HttpService;
import com.opl.notification.provider.service.NotificationAuditService;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLException;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

@Service
@Slf4j
public class HttpServiceImpl implements HttpService {

    @Autowired
    private NotificationAuditService auditDetailService;

    /**
     * USED FOR CALL POST METHOD API AND AUDITING.<br>
     * IN CASE OF TESTING MODE FLAG isTestingModeOn IS TRUE IN BASIC CONFIG TABLE THEN WE SKIP THE AUDITING
     *
     * @param additionalHeaders USE FOR CUSTOMISE HEADER
     * @param auditReq API REQUEST
     * @param respClass RESPONSE CLASS IT SHOULD INHERIT BY NotificationCommonRes
     * */
    public <T extends NotificationCommonRes> T post(NotificationAuditRequest auditReq, Map<String, String> additionalHeaders, T respClass) {
        String isTestingModeOn = NotificationUtils.getBasicConfigByKey("isTestingModeOn");
        try {
            /* SET HEADERS */
            HttpHeaders headers = new HttpHeaders();
            headers.add("Cache-Control", "no-cache");
            headers.add("Content-Type", "application/json");
            if (!NotificationUtils.isObjectNullOrEmpty(additionalHeaders)) {
                headers.setAll(additionalHeaders);
            }
            auditReq.setHeaders(NotificationUtils.getStringfromObject(headers));

            /* CALL API */
            ResponseEntity<String> exchange = null;
            if (isTestingModeOn.equalsIgnoreCase("true")) {
                exchange = new ResponseEntity<>("Message sent successfully with testing mode flag on", HttpStatus.OK);
            } else {
                RestTemplate restTemplate = new RestTemplate();
                HttpEntity<Object> entity = new HttpEntity<>(auditReq.getReq(), headers);
                exchange = restTemplate.exchange(auditReq.getUrl(), HttpMethod.POST, entity, String.class);
                auditReq.setStatus(exchange.getStatusCodeValue());
                auditReq.setRes(exchange.getBody());
            }
            if (exchange.getStatusCode() == HttpStatus.OK) {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + " Sent Successfully : " + exchange.getBody());
            } else if (exchange.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + NotificationUtils.SENDING_FAILURE + exchange.getBody());
            } else {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + NotificationUtils.SENDING_FAILURE + exchange.getBody());
            }
        } catch (HttpStatusCodeException e) {
            ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
            auditReq.setRes(resp.getBody());
            log.error("END ERROR WHILE CALLING " + auditReq.getProviderName() + "   API STATUS ---> " + resp.getStatusCode().value()
                    + " AND BODY ----->" + resp.getBody() + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()));
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(e.getStatusCode().value());
            if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(), NotificationUtils.ERROR_TIMEOUT);
            } else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        NotificationUtils.AN_ERROR_ENCOUNTERED_AT_PROVIDER_LEVEL_PLEASE_TRY_AFTER_SOME_TIME);
            } else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        "The Provider services are currently unavailable. Please try again later.");
            } else {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        NotificationUtils.AN_ERROR_ENCOUNTERED_AT_PROVIDER_LEVEL_PLEASE_TRY_AFTER_SOME_TIME);
            }
        } catch (ResourceAccessException http) {
            log.info("http.getCause() TIMEOUT " + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()), http.getCause());
            auditReq.setFailureReason(http.getCause().getLocalizedMessage());
            if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
                auditReq.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
                return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), NotificationUtils.ERROR_TIMEOUT);
            } else {
                auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), NotificationUtils.ERROR_500);
            }
        } catch (Exception e) {
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("EXCEPTION WHILE CALLING BANK API " + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()), e);
            return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), NotificationUtils.ERROR_500);
        } finally {
            if (!isTestingModeOn.equalsIgnoreCase("true")) {
                auditDetailService.audit(auditReq, auditReq.getProviderId());
            }
            log.info("message sent successfully :{} ", new Date());
        }
    }

    /**
     * USED FOR CALL GET METHOD API AND AUDITING. <br>
     * IN CASE OF TESTING MODE FLAG isTestingModeOn IS TRUE IN BASIC CONFIG TABLE THEN WE SKIP THE AUDITING
     *
     * @param additionalHeaders USE FOR CUSTOMISE HEADER
     * @param auditReq API REQUEST
     * @param respClass RESPONSE CLASS IT SHOULD INHERIT BY NotificationCommonRes
     * */
    public <T extends NotificationCommonRes> T get(NotificationAuditRequest auditReq, Map<String, String> additionalHeaders, T respClass) {
        String isTestingModeOn = NotificationUtils.getBasicConfigByKey("isTestingModeOn");
        try {
            /* SET HEADERS */
            HttpEntity entity = null;
            if (!NotificationUtils.isObjectNullOrEmpty(additionalHeaders)) {
                HttpHeaders headers = new HttpHeaders();
                headers.setAll(additionalHeaders);
                entity = new HttpEntity(headers);
                auditReq.setHeaders(NotificationUtils.getStringfromObject(headers));
            }

            log.info("URL : {}", auditReq.getUrl());
            /* CALL API */
            ResponseEntity<String> exchange = null;
            if (isTestingModeOn.equalsIgnoreCase("true")) {
                exchange = new ResponseEntity<>("Message sent successfully with testing mode flag on", HttpStatus.OK);
            } else {
                RestTemplate restTemplate = new RestTemplate();
                exchange = restTemplate.exchange(auditReq.getUrl(), HttpMethod.GET, entity, String.class);
                auditReq.setStatus(exchange.getStatusCodeValue());
                auditReq.setRes(exchange.getBody());
            }

            if (exchange.getStatusCode() == HttpStatus.OK) {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + " Sent Successfully : " + exchange.getBody());
            } else if (exchange.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + NotificationUtils.SENDING_FAILURE + exchange.getBody());
            } else {
                return NotificationUtils.setCommonResponseFields(respClass, exchange.getStatusCodeValue(), auditReq.getType().getName() + NotificationUtils.SENDING_FAILURE + exchange.getBody());
            }
        } catch (HttpStatusCodeException e) {
            ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
            auditReq.setRes(resp.getBody());
            log.error("END ERROR WHILE CALLING " + auditReq.getProviderName() + "   API STATUS ---> " + resp.getStatusCode().value()
                    + " AND BODY ----->" + resp.getBody() + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()));
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(e.getStatusCode().value());
            if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(), NotificationUtils.ERROR_TIMEOUT);
            } else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        NotificationUtils.AN_ERROR_ENCOUNTERED_AT_PROVIDER_LEVEL_PLEASE_TRY_AFTER_SOME_TIME);
            } else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        "The Provider services are currently unavailable. Please try again later.");
            } else {
                return NotificationUtils.setCommonResponseFields(respClass, e.getStatusCode().value(),
                        NotificationUtils.AN_ERROR_ENCOUNTERED_AT_PROVIDER_LEVEL_PLEASE_TRY_AFTER_SOME_TIME);
            }
        } catch (ResourceAccessException http) {
            log.info("http.getCause() TIMEOUT " + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()), http.getCause());
            auditReq.setFailureReason(http.getCause().getLocalizedMessage());
            if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
                auditReq.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
                return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), NotificationUtils.ERROR_TIMEOUT);
            } else {
                auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
                return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), NotificationUtils.ERROR_500);
            }
        } catch (Exception e) {
            auditReq.setFailureReason(e.getMessage());
            auditReq.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("EXCEPTION WHILE CALLING BANK API " + NotificationUtils.printLogs(Arrays.toString(auditReq.getTo()), auditReq.getType()), e);
            return NotificationUtils.setCommonResponseFields(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), NotificationUtils.ERROR_500);
        } finally {
            if (!isTestingModeOn.equalsIgnoreCase("true")) {
                auditDetailService.audit(auditReq, auditReq.getProviderId());
            }
        }
    }

}
