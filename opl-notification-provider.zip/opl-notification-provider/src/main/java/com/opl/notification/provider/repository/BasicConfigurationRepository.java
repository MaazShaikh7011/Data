package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.BasicConfiguration;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface BasicConfigurationRepository extends CrudRepository<BasicConfiguration, Long> {

    List<BasicConfiguration> findAllByIsActiveTrue();

}
