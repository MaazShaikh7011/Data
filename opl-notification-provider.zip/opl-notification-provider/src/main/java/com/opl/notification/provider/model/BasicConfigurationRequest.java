package com.opl.notification.provider.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BasicConfigurationRequest {

    private Long id;
    private String propName;
    private Object propValue;
    private Date createdDate;
    private Boolean isActive;
}
