package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.PayloadAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Repository
public interface PayloadAuditRepository extends JpaRepository<PayloadAudit, Long> {

    PayloadAudit findFirstByLogAuditAndNotificationTypeId(Long logAudit, Long type);

}
