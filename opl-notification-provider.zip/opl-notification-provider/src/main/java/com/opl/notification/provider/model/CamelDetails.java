package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 25-09-2024
 */
@Setter
@Getter
public class CamelDetails {
    List<String> componentName=new ArrayList<>();
    List<Integer> weightage;
}
