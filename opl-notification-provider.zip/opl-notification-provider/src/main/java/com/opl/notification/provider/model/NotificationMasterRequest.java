package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class NotificationMasterRequest {

    private Long masterId;
    private String notificationName;
    private String notificationDesc;
    private Boolean isEditable;
    private String defaultConfigKey;
    private Boolean isActive;
    private Date createdDate;
    private Date modifiedDate;
    private Long modifiedBy;
    private Long createdBy;

}
