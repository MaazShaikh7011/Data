package com.opl.notification.provider.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_basic_configuration",
        indexes = {@Index(columnList = "is_active", name = "BASIC_CONFIG_ACT"),
                @Index(columnList = "prop_name,is_active", name =  "JNS_NOTIFICATION_BASIC_CONFIG_PROP_NAME_ACT")}
)
public class BasicConfiguration {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_basic_configuration_seq_gen")
    @SequenceGenerator(name = "notification_basic_configuration_seq_gen", sequenceName = "notification_basic_configuration_seq_gen", allocationSize = 1)
    private Long id;
    @Column(name = "prop_name")
    private String propName;
    @Column(name = "prop_value")
    private String propValue;
    @Column(name = "type")
    private Integer type;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "is_active")
    private Boolean isActive;
}
