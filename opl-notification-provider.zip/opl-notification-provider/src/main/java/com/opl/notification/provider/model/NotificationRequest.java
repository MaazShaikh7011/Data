package com.opl.notification.provider.model;

import com.opl.notification.provider.enums.ContentType;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class NotificationRequest {
    private Long templateId;
    private Map<String, Object> parameters;
    private ContentType template;
    private String content;
    private String templateName;
    private Long userId;
    private Long masterId;
    private Integer loanTypeId;
    private Long userOrgId;
    private Integer sourceId;
    private String referenceId;
    private Long sourceType;
    private String defaultConfigKey;
}
