package com.opl.notification.provider.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.opl.notification.provider.enums.NotificationType;
import lombok.Data;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationAuditRequest {
    private Integer status;
    private String url;
    private String subject;
    private String body;
    private String req;
    private String res;

    private Long referenceId;
    private String[] to;
    private String[] cc;
    private String[] bcc;
    private String toStr;
    private String ccStr;
    private String bccStr;

    private Long providerId;
    private String providerName;

    private Long subjectId;
    private Long templateId;
    private Long masterId;
    private NotificationType type;
    private Long auditId;
    private String failureReason;
    private String headers;
    private String requestForAudit;
    private Long orgId;
    private Long sourceType;

    public NotificationAuditRequest() {
    }

    public NotificationAuditRequest(String url, String subject, String body, String[] to, String[] cc, String[] bcc) {
        this.url = url;
        this.subject = subject;
        this.body = body;
        this.to = to;
        this.cc = cc;
        this.bcc = bcc;
    }

    public NotificationAuditRequest(String url, String content, String[] to) {
        this.url = url;
        this.body = content;
        this.to = to;
    }


}
