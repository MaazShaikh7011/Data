package com.opl.notification.provider.model.sms;

import com.opl.notification.provider.model.NotificationCommonRes;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class SMSResponse extends NotificationCommonRes {


    private String smsMessage;

}
