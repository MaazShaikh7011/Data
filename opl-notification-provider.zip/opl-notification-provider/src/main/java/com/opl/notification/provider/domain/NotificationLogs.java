package com.opl.notification.provider.domain;

import com.opl.notification.provider.enums.NotificationType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@Entity
@Table(name = "notification_logs",
        indexes = {
                @Index(columnList = "notification_type_id,is_active,status_code", name = "JNS_NOTIFICATION_type_act_sts"),
                @Index(columnList = "notification_type_id,template_id,to_id", name = "JNS_NOTIFICATION_type_tmplt_to")
        })
@NamedQuery(name = "NotificationLogs.findAll", query = "SELECT n FROM NotificationLogs n")
public class NotificationLogs implements Serializable {
    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notification_log_seq_gen")
    @SequenceGenerator(name = "notification_log_seq_gen", sequenceName = "notification_log_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "to_id", nullable = false)
    private String to;

    @Column(name = "reference_id")
    private Long referenceId;

    @Column(name = "notification_type_id")
    private Long notificationTypeId;

    @Transient
    private NotificationType type;

    @Column(name = "status_code", nullable = false)
    private Integer status;
    @Column(name = "subject_id")
    private Long subjectId;
    @Column(name = "template_id", nullable = false)
    private Long templateId;
    @Column(name = "master_id", nullable = false)
    private Long masterId;
    @Column(name="provider_id")
    private Long providerId;
    @Column(name = "cc_email_count")
    private Integer ccEmailCount;
    @Column(name = "bcc_email_count")
    private Integer bccEmailCount;
    @Column(name = "to_email_count")
    private Integer toEmailCount;
    @Column(name = "sms_count")
    private Integer smsCount;
    @Column(name = "content_length")
    private Integer contentLength;
    @Column(name = "created_date", nullable = false)
    private Date createdDate;
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
    @Column(name = "org_id")
    private Long orgId;
    @Column(name = "source_type")
    private Long sourceType;

    @PostLoad
    void fillTransient() {
        if (notificationTypeId != null) {
            this.type = NotificationType.fromId(notificationTypeId);
        }
    }


}