package com.opl.notification.provider.service;

import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
import org.springframework.stereotype.Service;

/**
 * @author Maaz Shaikh
 * @implNote Parent class of all providers
 * @since 09-09-2024
 */
@Service
public interface ProviderService {

    /** IMPLEMENTATION OF EMAIL NOTIFICATION PROVIDER WISE  */
    public EmailResponse processEmail(EmailRequest emailRequest);

    /** IMPLEMENTATION OF sms NOTIFICATION PROVIDER WISE  */
    public SMSResponse processSms(SMSRequest smsRequest);

}
