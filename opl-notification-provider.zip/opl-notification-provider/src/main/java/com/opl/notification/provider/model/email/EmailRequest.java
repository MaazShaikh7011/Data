package com.opl.notification.provider.model.email;

import com.opl.notification.provider.model.NotificationRequest;
import com.opl.notification.provider.model.NotificationTemplateRequest;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class EmailRequest extends NotificationRequest {

    private String[] toEmail;
    private String[] bcc;
    private String[] cc;
    private String fromEmail;
    private List<ContentAttachment> contentAttachments = new ArrayList<ContentAttachment>();
    private String subject;
    private byte[] contentInBytes;
    private String fileName;
    private Long fileSize;
    private String maxAllowedFileSize;
    private Long subjectId;
    private String emailContent;
    private NotificationTemplateRequest templateRequest;
    private String toEmailStr;
    private String bccStr;
    private String ccStr;


    public EmailRequest() {
        super();
    }

    public EmailRequest(Map<String, Object> param) {
        super();
        super.setParameters(param);
    }

}
