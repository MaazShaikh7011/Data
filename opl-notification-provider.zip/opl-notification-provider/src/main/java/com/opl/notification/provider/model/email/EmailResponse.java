package com.opl.notification.provider.model.email;

import com.opl.notification.provider.model.NotificationCommonRes;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class EmailResponse extends NotificationCommonRes {
    // response fields fo acl
    public String requestId;
    private String emailMessage;
    private String requestStatus;
    private String statusDesc;
    private Long messageId;
    private Long custRef;

    //For get different third Party Email API Information
    private String url;
    private String request;
    private String response;
    private Long apiStatus;

}
