package com.opl.notification.provider.service.impl;

import com.opl.notification.provider.enums.ContentType;
import com.opl.notification.provider.enums.ProviderEnum;
import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.email.ContentAttachment;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
import com.opl.notification.provider.model.email.karix.KarixRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
import com.opl.notification.provider.model.vendor.ProviderRequest;
import com.opl.notification.provider.service.HttpService;
import com.opl.notification.provider.service.ProviderAbstractLayer;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * @author Maaz Shaikh
 * @implNote KARIX PROVIDER IMPLEMENTATION CLASS
 * @since 09-09-2024
 */
@Service("Karix")
@Slf4j
public class KarixServiceImpl extends ProviderAbstractLayer {


    @Autowired
    HttpService httpService;

    /** IMPLEMENTATION OF EMAIL NOTIFICATION PROVIDER WISE  */
    public EmailResponse processEmail(EmailRequest emailRequest) {
        log.info("Sending EMAIL through KARIX Service Provider for email id {}", emailRequest.getToEmailStr());
        EmailResponse response = new EmailResponse();

        /* GET PROVIDER OBJ - notification Provider for KARIX EMAIL */
        ProviderRequest provider = NotificationUtils.getProviderByName(ProviderEnum.KARIX_EMAIL.getName());

        /* PREPARE AUDIT FIELDS */
        NotificationAuditRequest request = this.prepareEmailAuditRequest(emailRequest, provider.getProviderName(), provider.getId(), provider.getRequestUrl());

        /* PREPARE HEADER */
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-cache");
        headers.put("Content-Type", "application/json");

        /* PREPARE REQUEST */
        KarixRequest prepareKarixRequest = prepareKarixRequest(emailRequest, provider, request.getReferenceId());
        try {
            request.setReq(NotificationUtils.getStringfromObject(prepareKarixRequest));
            request.setRequestForAudit(NotificationUtils.getStringfromObject(prepareKarixRequest.clone()));
        } catch (Exception e) {
            log.error("Error in setting KARIX  request in Audit : ", e);
        }

        /* CALL API */
        response = httpService.post(request, headers, response);
        if (response.getStatus() == HttpStatus.OK.value()) {
            log.info("EMAIL sent on email ids [{}] for masterId  [{}] and Response id [{}]", request.getToStr(), request.getMasterId(),response.getMessage());
        } else if (response.getStatus() == HttpStatus.CREATED.value()) {
            response.setMessage("Invalid Username or Password");
        } else if (response.getStatus() == HttpStatus.ACCEPTED.value()) {
            response.setMessage("Invalid Source/ReplyTo/Recipient E-mail ID/Field. As per Email standard, the Email ID should not have invalid characters.");
        } else if (response.getStatus() == HttpStatus.PARTIAL_CONTENT.value()) {
            response.setMessage("Not authorized to access from your IP");
        } else if (response.getStatus() == HttpStatus.NON_AUTHORITATIVE_INFORMATION.value()) {
            response.setMessage("Account deactivated/expired");
        } else if (response.getStatus() == HttpStatus.NOT_EXTENDED.value()) {
            response.setMessage("No credits available in the account");
        } else if (response.getStatus() == HttpStatus.SERVICE_UNAVAILABLE.value()) {
            response.setMessage(HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
        } else {
            try {
                log.info("unknown response status : {}", NotificationUtils.getStringfromObject(response));
            }catch (Exception e){
                log.error("Exception in converting karix response in string for logging : ",e);
            }
        }

        return response;
    }

    /** PREPARE REQUEST FOR KARIX EMAIl API */
    private KarixRequest prepareKarixRequest(EmailRequest req, ProviderRequest provider, Long requestId) {
        KarixRequest reqKarix = new KarixRequest();
        reqKarix.setVersion(provider.getVersion());
        reqKarix.setUserName(provider.getUsername());
        reqKarix.setPassword(provider.getPassword());
        reqKarix.setIncludeFooter(NotificationUtils.YES);
        KarixRequest.Message message = reqKarix.new Message();
        message.setCustRef(requestId);
        message.setHtml(req.getEmailContent());
        message.setSubject(req.getSubject());
        message.setFromEmail(req.getFromEmail());
        message.setFromName(req.getParameters().get(NotificationUtils.FROM_NAME).toString());
        message.setReplyTo(req.getFromEmail());

        if (ContentType.CONTENT.equals(req.getTemplate())) {
            message.setHtml(req.getContent());
        } else {
            message.setHtml(req.getEmailContent());
        }

        if (!NotificationUtils.isObjectNullOrEmpty(req.getToEmail())) {
            List<String> recipientsList = new ArrayList<>();
            for (String recEmail : req.getToEmail()) {
                recipientsList.add(recEmail.trim());
            }
            message.setRecipients(recipientsList);
            List<String> ccList = new ArrayList<>();
            if (!NotificationUtils.isObjectNullOrEmpty(req.getCc())) {
                for (String ccEmail : req.getCc()) {
                    if (!NotificationUtils.isObjectNullOrEmpty(ccEmail)) {
                        ccList.add(ccEmail.trim());
                    }
                }
                message.setCcRecipients(ccList);
            }
        } else {
            log.error("ToEmail not found while sending email from KARIX for master id {}",req.getMasterId());
        }

        if (!NotificationUtils.isListNullOrEmpty(req.getContentAttachments())) {
            List<KarixRequest.Attachment> attachmentsList = new ArrayList<>();
            for (ContentAttachment conAttachment : req.getContentAttachments()) {
                KarixRequest.Attachment attachment = reqKarix.new Attachment();
                attachment.setName(conAttachment.getFileName());
                attachment.setAttachmentData(Base64.getEncoder().encodeToString(conAttachment.getContentInByte()));
                attachmentsList.add(attachment);
            }
            message.setAttachments(attachmentsList);
        }

        if (!NotificationUtils.isObjectNullOrEmpty(req.getBcc())) {
            List<String> bccList = new ArrayList<>();
            for (String bccEmail : req.getBcc()) {
                if (!NotificationUtils.isObjectNullOrEmpty(bccEmail)) {
                    bccList.add(bccEmail.trim());
                }
            }
            message.setBccRecipients(bccList);
        }

        reqKarix.setMessage(message);
        return reqKarix;
    }

    /** IMPLEMENTATION OF sms NOTIFICATION PROVIDER WISE  */
    public SMSResponse processSms(SMSRequest smsRequest) {
        log.info("Sending SMS through KARIX Service Provider for mobile number {}",smsRequest.getPhoneNumberStr());

        String fromName = NotificationUtils.getBasicConfigByKey(NotificationUtils.SMS_PROVIDER_SENDER_NAME_KEY);
        String requestUrl = null;

        /* GET PROVIDER Object  */
        ProviderRequest provider = NotificationUtils.getProviderByName(ProviderEnum.KARIX_SMS.getName());
        smsRequest.setProviderId(provider.getId());
        smsRequest.setProviderName(provider.getProviderName());

        /* PREPARE URL */
        requestUrl = provider.getRequestUrl() + "ver=" + provider.getVersion() +
                "&key=" + provider.getKey() + "&encrpt=0&dest=" + URLEncoder.encode(smsRequest.getPhoneNumberStr(), StandardCharsets.UTF_8) +
                "&send=" + URLEncoder.encode(fromName, StandardCharsets.UTF_8) +
                "&dlt_entity_id=1201159219814300421&dlt_template_id=" + smsRequest.getDltId() + "&text=" + smsRequest.getMappedMessage();


        /* SET AUDIT REQUEST */
        NotificationAuditRequest auditRequest = prepareSmsAuditRequest(smsRequest, requestUrl);

        /* CALL API */
        SMSResponse smsResponse = new SMSResponse();
        smsResponse = httpService.get(auditRequest, null, smsResponse);
        if (smsResponse.getStatus() == HttpStatus.OK.value()) {
            log.info("SMS sent successfully on mobile : [{}] and response is :[{}]", smsRequest.getPhoneNumberStr(),smsResponse.getMessage());
        }

        return smsResponse;
    }

}
