	package com.opl.notification.provider.model;

    import lombok.Getter;
    import lombok.Setter;

    import java.io.Serializable;

    /**
     * @author Maaz Shaikh
     * @since 09-09-2024
     */
    @Setter
    @Getter
    public class PayLoadProxy extends CommonPayLoadProxy implements Serializable {

        private static final long serialVersionUID = -2316946665465465L;

        private String to;
        private String cc;
        private String bcc;
        private String subject;
        private String url;
        private String request;
        private String header;
        private String apiResponse;

    }