package com.opl.notification.provider.service.impl;

import com.opl.notification.provider.enums.ProviderEnum;
import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.email.ContentAttachment;
import com.opl.notification.provider.model.email.ContentTypeUtil;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.email.EmailResponse;
import com.opl.notification.provider.model.email.acl.AclRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.sms.SMSResponse;
import com.opl.notification.provider.model.vendor.ProviderRequest;
import com.opl.notification.provider.service.HttpService;
import com.opl.notification.provider.service.ProviderAbstractLayer;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * @author Maaz Shaikh
 * @implNote ACL PROVIDER IMPLEMENTATION CLASS
 * @since 09-09-2024
 */
@Service("Acl")
@Slf4j
public class AclServiceImpl extends ProviderAbstractLayer {

    @Autowired
    HttpService httpService;


    /** IMPLEMENTATION OF EMAIL NOTIFICATION - ACL PROVIDER  */
    public EmailResponse processEmail(EmailRequest emailRequest){
        log.info("Sending EMAIL through ACL Service Provider for email id {}", emailRequest.getToEmailStr());
        EmailResponse response = new EmailResponse();

        /* GET PROVIDER OBJ - notification Provider for ACL_EMAIL */
        ProviderRequest providerReq = NotificationUtils.getProviderByName(ProviderEnum.ACL_EMAIL.getName());

        /* PREPARE AUDIT FIELDS */
        NotificationAuditRequest request = this.prepareEmailAuditRequest(emailRequest,providerReq.getProviderName(),providerReq.getId(),providerReq.getRequestUrl());

        /* PREPARE HEADER */
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", providerReq.getToken());
        headers.put("Cache-Control", "no-cache");
        headers.put("Content-Type", "application/json");

        /* PREPARE REQUEST */
        AclRequest prepareAclRequest = prepareAclRequest(emailRequest);
        try {
            request.setReq(NotificationUtils.getStringfromObject(prepareAclRequest));
            request.setRequestForAudit(NotificationUtils.getStringfromObject(prepareAclRequest.clone()));
        }catch (Exception e){
            log.error("Error in setting KARIX  request in Audit : ",e);
        }

        /* CALL API */
        EmailResponse post = httpService.post(request, headers, response);
        if (post.getStatus() == HttpStatus.OK.value()) {
            log.info("EMAIL sent on email ids [{}] for masterId  [{}] and Response id [{}]", request.getToStr(), request.getMasterId(),response.getMessage());
        }
        return post;
    }

    /** PREPARE REQUEST FOR ACL EMAIl API */
    private AclRequest prepareAclRequest(EmailRequest req) {
        AclRequest reqAcl = new AclRequest();
        AclRequest.From fromObj = reqAcl.new From();
        fromObj.setEmail(req.getFromEmail());
        fromObj.setName(!req.getParameters().isEmpty() && !NotificationUtils.isObjectNullOrEmpty(req.getParameters().get(NotificationUtils.FROM_NAME)) ? req.getParameters().get(NotificationUtils.FROM_NAME).toString() : null);

        List<AclRequest.Recipient> recipient = new ArrayList<>();
        AclRequest.Recipient rec = reqAcl.new Recipient();
        ArrayList<AclRequest.To> arrayList = new ArrayList<>();
        for (String toEmail : req.getToEmail()) {
            AclRequest.To to = reqAcl.new To();
            to.setEmail(toEmail.trim());
            arrayList.add(to);
        }
        rec.setTo(arrayList);
        if (req.getCc() != null) {
            ArrayList<AclRequest.Cc> ccList = new ArrayList<>();
            for (String ccEmail : req.getCc()) {
                AclRequest.Cc cc = reqAcl.new Cc();
                cc.setEmail(ccEmail.trim());
                ccList.add(cc);
            }
            rec.setCc(ccList);
        }
        if (req.getBcc() != null) {
            ArrayList<AclRequest.Bcc> bccList = new ArrayList<>();
            for (String bccEmail : req.getBcc()) {
                AclRequest.Bcc bcc = reqAcl.new Bcc();
                bcc.setEmail(bccEmail.trim());
                bccList.add(bcc);
            }
            rec.setBcc(bccList);
        }
        if(!NotificationUtils.isListNullOrEmpty(req.getContentAttachments())) {
            List<AclRequest.Attachments> attList = new ArrayList<>();
            for (ContentAttachment attachments : req.getContentAttachments()) {
                AclRequest.Attachments att = reqAcl.new Attachments();
                if (!NotificationUtils.isObjectNullOrEmpty(attachments.getContentInByte())) {
                    String encoded = Base64.getEncoder().encodeToString(attachments.getContentInByte());
                    att.setContent(encoded);
                    att.setName(attachments.getFileName());
                    att.setType(ContentTypeUtil.getContentType(attachments.getFileName().split(NotificationUtils.CONTENT_TYPE_REGEX)[1]));
                    attList.add(att);
                }
            }
            rec.setAttachement(attList);
        }
        recipient.add(rec);
        AclRequest.Content content = reqAcl.new Content();
        content.setHtml(req.getEmailContent());
        reqAcl.setFrom(fromObj);
        reqAcl.setContent(content);
        reqAcl.setRecipients(recipient);
        reqAcl.setSubject(req.getSubject());
        return reqAcl;
    }




    /** IMPLEMENTATION OF sms NOTIFICATION ACL SMS PROVIDER  */
    public SMSResponse processSms(SMSRequest smsRequest){
        log.info("Sending SMS through ACL Service Provider for mobile number {}",smsRequest.getPhoneNumberStr());
        String fromName = NotificationUtils.getBasicConfigByKey(NotificationUtils.SMS_PROVIDER_SENDER_NAME_KEY);
        String requestUrl=null;

        /* GET PROVIDER FOR OTP  */
        ProviderRequest aclSmsProvider = getAclSmsProvider(smsRequest.getMasterId());
        smsRequest.setProviderId(aclSmsProvider.getId());
        smsRequest.setProviderName(aclSmsProvider.getProviderName());

        /* PREPARE URL */
        if (ProviderEnum.ACL_ALERT.getName().equals(aclSmsProvider.getProviderName())) {
            requestUrl = aclSmsProvider.getRequestUrl() + "&from=" + URLEncoder.encode(fromName, StandardCharsets.UTF_8) +
                    "&to=" + URLEncoder.encode(smsRequest.getPhoneNumberStr(), StandardCharsets.UTF_8) +
                    "&text=" + smsRequest.getMappedMessage() + "&alert=1&selfid=true&dlrreq=false&intflag=false";
        } else if (ProviderEnum.ACL_OTP.getName().equals(aclSmsProvider.getProviderName())) {
            requestUrl = aclSmsProvider.getRequestUrl() + "&msisdn=" + URLEncoder.encode(smsRequest.getPhoneNumberStr(), StandardCharsets.UTF_8) +
                    "&sender=" + URLEncoder.encode(fromName, StandardCharsets.UTF_8) + "&msgtext=" + smsRequest.getMappedMessage();
        }else{
            // return in case of provider not found
            return null;
        }

        /* SET AUDIT REQUEST */
        NotificationAuditRequest auditRequest = prepareSmsAuditRequest(smsRequest, requestUrl);

        /* CALL API */
        SMSResponse smsResponse = new SMSResponse();
        smsResponse = httpService.get(auditRequest,null, smsResponse);
        if (smsResponse.getStatus() == HttpStatus.OK.value()) {
            log.info("SMS sent successfully on mobile : [{}] and response is :[{}]", smsRequest.getPhoneNumberStr(),smsResponse.getMessage());
        }

        return smsResponse;

    }

    /** THIS METHOD IS USE FOR IDENTIFIED OTP SMS PROVIDER BASED ON MASTER ID.
     * <p>ACL SMS HAS 2 API <br>
     * 1. ACL ALERT - USE FOR OTHER THEN OTP <br>
     * 2. ACL OTP - USE FOR OTP SMS ONLY AND IT IS FASTER THEN ALERT SMS.
     * </p>
     * @param masterId  - TEMPLATE MASTER ID
     * */
    private ProviderRequest getAclSmsProvider(Long masterId){
        boolean isForOtp = false;
        String smsMasterId = NotificationUtils.getBasicConfigByKey(NotificationUtils.OTP_SMS_MASTER_ID_LIST_KEY);
        String[] split = smsMasterId.split(",");
        for (String string : split) {
            if (!NotificationUtils.isObjectNullOrEmpty(string) && masterId.equals(Long.valueOf(string))) {
                isForOtp = true;
            }
        }

        if (isForOtp) {
            return NotificationUtils.getProviderByName(ProviderEnum.ACL_OTP.getName());
        } else {
            return NotificationUtils.getProviderByName(ProviderEnum.ACL_ALERT.getName());
        }

    }

}
