package com.opl.notification.provider.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.opl.notification.provider.enums.NotificationType;
import com.opl.notification.provider.enums.ProviderEnum;
import com.opl.notification.provider.model.BasicConfigurationRequest;
import com.opl.notification.provider.model.CamelDetails;
import com.opl.notification.provider.model.NotificationCommonRes;
import com.opl.notification.provider.model.vendor.BankVendorConfigModel;
import com.opl.notification.provider.model.vendor.ProviderRequest;
import com.opl.notification.provider.model.vendor.VendorConfigModel;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author Maaz Shaikh
 * @implNote Use for common methods and shared objects
 * @since 09-09-2024
 */
@Slf4j
public class NotificationUtils {

    public static final String FROM_NAME = "fromName";
    public static final String CONTENT_TYPE_REGEX = "\\.(?=[^\\.]+$)";
    public static final String ERROR_500 = "An error has occurred during API call. Please attempt the operation again after some time";
    public static final String ERROR_TIMEOUT = "The response time of API is longer than anticipated. Please make another attempt.";
    public static final String Y = "Y";
    public static final String OTP_SMS_MASTER_ID_LIST_KEY="otpSmsMasterIds";
    public static final String SMS_PROVIDER_SENDER_NAME_KEY="smsProviderUserName";
    public static final String SENDING_FAILURE = " sending failure - : ";
    public static final String AN_ERROR_ENCOUNTERED_AT_PROVIDER_LEVEL_PLEASE_TRY_AFTER_SOME_TIME = "An error encountered at Provider level. Please try after some time";
    public static final String NOTIFICATION_TYPE_ID = "notificationTypeId";

    /** CONFIG FILED */
    private static final List<ProviderRequest> PROVIDER_LIST = new ArrayList<>();
    private static final List<VendorConfigModel> VENDOR_CONFIG_LIST = new ArrayList<>();
    private static final List<BasicConfigurationRequest> BASIC_CONFIG_LIST = new ArrayList<>();
    private static final List<BankVendorConfigModel> BANK_VENDOR_CONFIG_LIST = new ArrayList<>();

    /** COMPONENT LIST */
    private static final List<Integer> PROVIDER_WEIGHT = new ArrayList<>();
    private static final List<String> PROVIDER_COMPONENTS = new ArrayList<>();
    public static final String YES = "yes";

    /** SET AND GET PROVIDERS - SET FROM ROUTER */
    public static void setProviderList(ProviderRequest element){
        PROVIDER_LIST.add(element);
    }
    /** FILTER PROVIDER LIST BY NAME */
    public static ProviderRequest getProviderByName(String name){
        return PROVIDER_LIST.stream().filter(x -> x.getProviderName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    /** SET AND GET BASIC CONFIG LIST - SET FROM ROUTER  */
    public static void setBasicConfig(BasicConfigurationRequest element){
        BASIC_CONFIG_LIST.add(element);
    }
    /** GET BASIC CONFIG BY KEY */
    public static String getBasicConfigByKey(String key){
         return (String) BASIC_CONFIG_LIST.stream().filter(x -> x.getPropName().equalsIgnoreCase(key)).findFirst().map(BasicConfigurationRequest::getPropValue).orElse("");
    }
    /** GETTING ALL CONFIG - USED IN LOAN */
    public static List<BasicConfigurationRequest> getAllBasicConfig(){
        return BASIC_CONFIG_LIST;
    }

    /** SET AND GET VENDOR DETAILS FROM ROUTER*/
    public static void setVendorConfig(VendorConfigModel element){
        VENDOR_CONFIG_LIST.add(element);
    }
    /** FILTER VENDOR CONFIG BY KEY */
    public static List<VendorConfigModel> getVendorConfigDetailsByKey(String key){
        return VENDOR_CONFIG_LIST.stream().filter(x -> x.getKey().equalsIgnoreCase(key)).toList();
    }

    /** SET AND GET BANK VENDOR CONFIG DETAILS FORM ROUTER*/
    public static void setBankVendorConfig(BankVendorConfigModel element){
        BANK_VENDOR_CONFIG_LIST.add(element);
    }
    /** GET ALL VENDOR CONFIG */
    public static List<BankVendorConfigModel> getAllBankVendorConfig(){
        return BANK_VENDOR_CONFIG_LIST;
    }

    /** METHOD TO CHECK OBJECT IS NULL OR EMPTY */
    public static boolean isObjectNullOrEmpty(Object value) {
        return (value == null
                || (value instanceof String s
                ? (s.isEmpty() || "".equals(s.trim()) || "null".equals(value)
                || "(null)".equals(value) || "undefined".equals(value))
                : false));
    }

    /** METHOD TO CHECK OBJECT IS NULL OR EMPTY */
    public static boolean isListNullOrEmpty(Collection<?> data) {
        return data == null || data.isEmpty();
    }

    /** METHOD FOR CONVERTING STRING FROM OBJECT */
    public static String getStringfromObject(Object object) throws IOException {
        if (object != null) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
            return mapper.writeValueAsString(object);
        } else {
            return "{}";
        }
    }
    /** SET COMMON FIELDS */
    public static <T extends NotificationCommonRes> T setCommonResponseFields(T classType, Integer status, String message) {
        classType.setStatus(status);
        classType.setMessage(message);
        return classType;
    }

    /** PRINT LOGS */
    public static String printLogs(String to, NotificationType type) {
        return "---TO ---" + to + "---NOTIFICATION_TYPE---" + type.getName() + "----";
    }

    /** CONVERT ARRAY TO COMMA STRING  */
    public static String convertTOCommaSpe(String[] name) {
        try {
            if (name != null) {
                if (name.length > 0) {
                    StringBuilder nameBuilder = new StringBuilder();

                    for (String n : name) {
                        nameBuilder.append("").append(n.replace("'", "\\'")).append(",");
                    }
                    nameBuilder.deleteCharAt(nameBuilder.length() - 1);
                    return nameBuilder.toString();
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** GENERATE UUID */
    public static String generateUUID() {
        return UUID.randomUUID().toString();
    }

    /** GET RANDOM NUMBER STRING */
    public static Long getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        SecureRandom rand = new SecureRandom();
        int number = rand.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return Long.valueOf(number);
    }

    /** EVALUATE DETAILS FOR CAMEL CONFIGURATION VENDOR WISE */
    public static CamelDetails getVendorWiseConfiguration(Integer sourceId, Long orgId, Long masterId) {
        List<BankVendorConfigModel> bankConfig = NotificationUtils.getAllBankVendorConfig();
        NotificationUtils.PROVIDER_WEIGHT.clear();
        NotificationUtils.PROVIDER_COMPONENTS.clear();

        /* SEARCH WITH MASTER ID AND ORG ID */
        if (!NotificationUtils.isObjectNullOrEmpty(orgId)) {
            bankConfig = bankConfig.stream().filter(x -> x.getOrgId() == orgId && x.getMasterId() == masterId).toList();
        }else{
            /* IN CASE OF REQUEST ORG IS NULL SO RUN THROUGH DEFAULT CONFIG */
            /* IN CASE RETURN NULL WE SELECT DEFAULT CONFIG FROM TEMPLATE */
            return null;
        }

        if(NotificationUtils.isListNullOrEmpty(bankConfig)){
            log.info("Configuration not found for given ORG ID [{}] AND Master Id [{}]",orgId,masterId);
            return null;
        }


        /* SEARCH WITH MASTER ID AND SOURCE ID */
        if (!NotificationUtils.isObjectNullOrEmpty(sourceId)) {
            AtomicReference<CamelDetails> dtls = new AtomicReference<>();
            bankConfig.stream().filter(x -> x.getSourceId() == sourceId && x.getMasterId() == masterId).findFirst().ifPresent(bnk -> {
                dtls.set(selectVendorConfigBasedOnKey(bnk.getVendorKey()));
            });
            return dtls.get();
        }else{
            /* IN CASE OF REQUEST SOURCE IS NULL SO RUN THROUGH BANK CONFIG */
            return selectVendorConfigBasedOnKey(bankConfig.getLast().getVendorKey());
        }
    }

    /** SELECT VENDOR FROM VENDOR CONFIG BASED ON KEY AND CHECK ROUND-ROBIN AND SINGLE PROVIDER CONFIG*/
    public static CamelDetails selectVendorConfigBasedOnKey(String key) {
        CamelDetails cdt = new CamelDetails();
        /* SEARCH IN VENDOR CONFIG */
        List<VendorConfigModel> vendorConfigDetailsByKey = NotificationUtils.getVendorConfigDetailsByKey(key);
        if (!vendorConfigDetailsByKey.isEmpty()) {
            /*  CHECK FIRST IS ROUND-ROBIN IS TRUE OR FALSE*/
            if(vendorConfigDetailsByKey.stream().filter(VendorConfigModel::isRoundRobin).toList().isEmpty()){
                /*  ROUND-ROBIN IS FALSE */
                VendorConfigModel vendorConfigModel = vendorConfigDetailsByKey.getLast();
                NotificationUtils.PROVIDER_COMPONENTS.add(ProviderEnum.getServiceByProviderId(vendorConfigModel.getProviderId()));
                NotificationUtils.PROVIDER_WEIGHT.add(vendorConfigModel.getCallRatio());
            }else{
                /*  ROUND-ROBIN IS TRUE */
                vendorConfigDetailsByKey.forEach(x -> {
                    NotificationUtils.PROVIDER_COMPONENTS.add(ProviderEnum.getServiceByProviderId(x.getProviderId()));
                    NotificationUtils.PROVIDER_WEIGHT.add(x.getCallRatio());
                });
            }
            cdt.setWeightage(NotificationUtils.PROVIDER_WEIGHT);
            cdt.setComponentName(NotificationUtils.PROVIDER_COMPONENTS);
            return cdt;
        } else {
            log.info("vendor config details not found for vendor KEY [{}]", key);
            return null ;
        }
    }
}
