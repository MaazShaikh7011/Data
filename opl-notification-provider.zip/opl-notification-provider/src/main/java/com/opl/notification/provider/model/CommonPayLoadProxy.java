package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class CommonPayLoadProxy implements Serializable {

    private static final long serialVersionUID = -2316946665455555L;

    private String notificationMessage;
    private Long logAuditId;
    private String referenceId;
}
