package com.opl.notification.provider.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit",
        indexes = {
                @Index(columnList = "log_audit_id", name =  "JNS_NOTIFICATION_payload_audit_log_audit_id_idx"),
                @Index(columnList = "log_audit_id,notification_type_id", name ="JNS_NOTIFICATION_payload_audit_log_audit_id_notification_type_id_idx"),
        })
public class PayloadAudit {

    private static final long serialVersionUID = -231645826676600012L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payload_audit_seq_gen")
    @SequenceGenerator( name = "payload_audit_seq_gen", sequenceName = "payload_audit_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "log_audit_id", nullable = true)
    private Long logAudit;

    @Column(name = "storage_id", nullable = true)
    private String storageId;

    @Column(name = "success", nullable = true)
    private Boolean success;

    @Column(name = "notification_type_id", nullable = true)
    private Long notificationTypeId;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    public PayloadAudit() {
        super();
        this.createdDate = new Date();
        this.success = false;
    }
}
