package com.opl.notification.provider.enums;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public enum ContentType {
    CONTENT, TEMPLATE
}
