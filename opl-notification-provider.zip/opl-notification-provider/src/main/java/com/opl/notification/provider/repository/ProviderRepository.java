package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.Provider;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface ProviderRepository extends JpaRepository<Provider, Long> {

    List<Provider> findAllByIsActive(String isActive);

}
