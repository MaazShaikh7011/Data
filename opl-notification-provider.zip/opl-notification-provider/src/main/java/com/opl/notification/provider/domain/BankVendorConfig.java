package com.opl.notification.provider.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Maaz Shaikh
 * @since 25-09-2024
 */
@Entity
@Setter
@Getter
@Table(name = "bank_vendor_config", indexes =
        {
                @Index(columnList = "master_id,org_id,source_id,is_active", name = "bank_vendor_config_mst_org_source_ACT"),
        })

@NamedQuery(name = "BankVendorConfig.findAll", query = "SELECT n FROM BankVendorConfig n")
@NoArgsConstructor
public class BankVendorConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bank_vendor_config_seq_gen")
    @SequenceGenerator(name = "bank_vendor_config_seq_gen", sequenceName = "bank_vendor_config_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "source_id")
    private Integer sourceId;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "master_id")
    private Long masterId;

    @Column(name = "vendor_key")
    private String vendorKey;

    @Column(name = "is_active")
    private boolean isActive;

}