package com.opl.notification.provider.service;

import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.NotificationCommonRes;

import java.util.Map;

public interface HttpService {

    /**
     * USED FOR CALL POST METHOD API AND AUDITING.<br>
     * IN CASE OF TESTING MODE FLAG isTestingModeOn IS TRUE IN BASIC CONFIG TABLE THEN WE SKIP THE AUDITING
     *
     * @param additionalHeaders USE FOR CUSTOMISE HEADER
     * @param auditReq API REQUEST
     * @param respClass RESPONSE CLASS IT SHOULD INHERIT BY NotificationCommonRes
     * */
    public <T extends NotificationCommonRes> T post(NotificationAuditRequest auditReq, Map<String, String> additionalHeaders, T respClass);

    /**
     * USED FOR CALL GET METHOD API AND AUDITING. <br>
     * IN CASE OF TESTING MODE FLAG isTestingModeOn IS TRUE IN BASIC CONFIG TABLE THEN WE SKIP THE AUDITING
     *
     * @param additionalHeaders USE FOR CUSTOMISE HEADER
     * @param auditReq API REQUEST
     * @param respClass RESPONSE CLASS IT SHOULD INHERIT BY NotificationCommonRes
     * */
    public <T extends NotificationCommonRes> T get(NotificationAuditRequest auditReq, Map<String, String> additionalHeaders, T respClass);

}
