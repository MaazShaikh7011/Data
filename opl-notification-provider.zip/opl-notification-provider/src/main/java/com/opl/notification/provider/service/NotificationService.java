package com.opl.notification.provider.service;

import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.sms.SMSRequest;

/**
 * @author Maaz Shaikh
 * @implNote Use for common methods and shared objects
 * @since 09-09-2024
 */
public interface NotificationService {

    /** SET PROVIDER LIST AND BASIC CONFIG  */
    public void initServiceConfiguration();

    /** RUN APACHE CAMEL ROUTER FOR EMAIL */
    public String processEmail(EmailRequest emailRequest);

    /** RUN APACHE CAMEL ROUTER FOR SMS */
    public String processSms(SMSRequest smsRequest);

}
