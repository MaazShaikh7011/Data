package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.NotificationLogs;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
public interface NotificationLogsRepository extends JpaRepository<NotificationLogs, Long> {

    NotificationLogs findFirstByNotificationTypeIdAndMasterIdAndToOrderByIdDesc(Long notificationTypeId, Long masterId, String to);

}
