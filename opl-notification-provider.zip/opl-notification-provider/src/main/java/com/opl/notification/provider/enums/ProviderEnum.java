package com.opl.notification.provider.enums;

import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@NoArgsConstructor
@Getter
public enum ProviderEnum {
    ACL_ALERT("AclAlert","Acl",7L),
    ACL_OTP("AclOtp","Acl",8L),
    ACL_EMAIL("ACL_EMAIL","Acl",9L),
    KARIX_SMS("KARIX_SMS","Karix",10L),
    KARIX_EMAIL("KARIX_EMAIL","Karix",11L);

    String name;
    String service;
    Long providerId;



    ProviderEnum(String name,String service,Long providerId){
        this.name=name;
        this.service =service;
        this.providerId = providerId;
    }


    public static String getServiceByProviderId(Long providerId){
        for (ProviderEnum c : ProviderEnum.values()) {
            if (Objects.equals(c.providerId, providerId)) {
                return c.getService();
            }
        }
        return null;
    }

}
