package com.opl.notification.provider.model.email.acl;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Slf4j
public class AclRequest implements Cloneable {

    String subject;
    From from;
    ReplyTo reply_to;
    List<Recipient> recipients;
    Content content;

    @JsonProperty("subject")
    public String getSubject() {
        return this.subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @JsonProperty("from")
    public From getFrom() {
        return this.from;
    }

    public void setFrom(From from) {
        this.from = from;
    }

    @JsonProperty("reply_to")
    public ReplyTo getReply_to() {
        return this.reply_to;
    }

    public void setReply_to(ReplyTo reply_to) {
        this.reply_to = reply_to;
    }

    @JsonProperty("recipients")
    public List<Recipient> getRecipients() {
        return this.recipients;
    }

    public void setRecipients(List<Recipient> recipients) {
        this.recipients = recipients;
    }

    @JsonProperty("content")
    public Content getContent() {
        return this.content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    public class From {
        String email;
        String name;

        @JsonProperty("email")
        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @JsonProperty("name")
        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

    }

    public class ReplyTo {
        Object email;
        Object name;

        @JsonProperty("email")
        public Object getEmail() {
            return this.email;
        }

        public void setEmail(Object email) {
            this.email = email;
        }

        @JsonProperty("name")
        public Object getName() {
            return this.name;
        }

        public void setName(Object name) {
            this.name = name;
        }
    }

    public class To {
        String email;
        String name;

        @JsonProperty("email")
        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @JsonProperty("name")
        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

    }

    public class Cc {
        String email;
        String name;

        @JsonProperty("email")
        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @JsonProperty("name")
        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

    }

    public class Bcc {
        String email;
        String name;

        @JsonProperty("email")
        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        @JsonProperty("name")
        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public class Attributes {
        String name;
        String city;
        String greeting;

        @JsonProperty(":name")
        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty(":city")
        public String getCity() {
            return this.city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        @JsonProperty(":greeting")
        public String getGreeting() {
            return this.greeting;
        }

        public void setGreeting(String greeting) {
            this.greeting = greeting;
        }

    }

    public class UniqueArguments {
        String xApiheader;

        @JsonProperty("x-apiheader")
        public String getXApiheader() {
            return this.xApiheader;
        }

        public void setXApiheader(String xApiheader) {
            this.xApiheader = xApiheader;
        }


    }

    public class Recipient {
        List<Cc> cc;
        List<Bcc> bcc;
        List<To> to;
        Attributes attributes;
        UniqueArguments unique_arguments;
        @JsonProperty("attachments")

        List<Attachments> attachement;

        @JsonProperty("cc")

        public List<Cc> getCc() {
            return cc;
        }

        public void setCc(List<Cc> cc) {
            this.cc = cc;
        }

        @JsonProperty("bcc")
        public List<Bcc> getBcc() {
            return bcc;
        }

        public void setBcc(List<Bcc> bcc) {
            this.bcc = bcc;
        }

        @JsonProperty("to")
        public List<To> getTo() {
            return this.to;
        }

        public void setTo(List<To> to) {
            this.to = to;
        }

        @JsonProperty("attributes")
        public Attributes getAttributes() {
            return this.attributes;
        }

        public void setAttributes(Attributes attributes) {
            this.attributes = attributes;
        }

        @JsonProperty("unique_arguments")
        public UniqueArguments getUnique_arguments() {
            return this.unique_arguments;
        }

        public void setUnique_arguments(UniqueArguments unique_arguments) {
            this.unique_arguments = unique_arguments;
        }

        public List<Attachments> getAttachement() {
            return attachement;
        }

        public void setAttachement(List<Attachments> attachement) {
            this.attachement = attachement;
        }

    }

    public class Content  implements Cloneable{
        String text;
        String html;

        @JsonProperty("text")
        public String getText() {
            return this.text;
        }

        public void setText(String text) {
            this.text = text;
        }

        @JsonProperty("html")
        public String getHtml() {
            return this.html;
        }

        public void setHtml(String html) {
            this.html = html;
        }

        @Override
        public Content clone() {
            try {
                return (Content) super.clone();
            } catch (CloneNotSupportedException e) {
                log.error("Exception in cloning Content class in ACL Email Request : ",e);
            }
            return null;
        }
    }

    public class Attachments {

        @JsonProperty("name")
        String name;
        String path;
        String content;
        String type = "application/octet-stream";
        String disposition = "attachment";
        String content_id;


        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @JsonProperty("path")
        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        @JsonProperty("content")
        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        @JsonProperty("type")
        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        @JsonProperty("disposition")
        public String getDisposition() {
            return disposition;
        }

        public void setDisposition(String disposition) {
            this.disposition = disposition;
        }

        @JsonProperty("content_id")
        public String getContent_id() {
            return content_id;
        }

        public void setContent_id(String content_id) {
            this.content_id = content_id;
        }


    }

    @Override
    public AclRequest clone() {
        try {
            AclRequest clone = (AclRequest) super.clone();
            if(!NotificationUtils.isObjectNullOrEmpty(clone.getContent())) {
                clone.setContent(clone.getContent().clone());
                clone.getContent().setHtml(null);
            }
            return clone;
        }catch (CloneNotSupportedException e){
            log.error("Error while cloning ACL Email request for Audit purpose : ",e);
        }
        return null;
    }
}
