package com.opl.notification.provider.domain;

import com.opl.notification.provider.enums.NotificationType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 25-09-2024
 */
@Entity
@Setter
@Getter
@Table(name = "vendor_config", indexes =
        {
                @Index(columnList = "key,is_active", name = "vendor_config_key_ACT"),
        })
@NamedQuery(name = "VendorConfig.findAll", query = "SELECT n FROM VendorConfig n")
@NoArgsConstructor
public class VendorConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vendor_config_seq_gen")
    @SequenceGenerator(name = "vendor_config_seq_gen", sequenceName = "vendor_config_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "key")
    private String key;

    @Column(name = "is_round_robin")
    private boolean isRoundRobin = false;

    @Column(name = "call_ratio")
    private Integer callRatio;

    @Column(name = "provider_id")
    private Long providerId;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "is_active")
    private boolean isActive;

}