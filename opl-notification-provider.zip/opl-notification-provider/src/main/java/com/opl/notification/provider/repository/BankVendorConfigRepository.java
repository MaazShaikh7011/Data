package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.BankVendorConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 25-09-2024
 */
public interface BankVendorConfigRepository extends JpaRepository<BankVendorConfig, Long> {

    List<BankVendorConfig> findAllByIsActiveTrue();
}
