package com.opl.notification.provider.config;

import com.opl.notification.provider.enums.NotificationType;
import com.opl.notification.provider.model.CamelDetails;
import com.opl.notification.provider.model.NotificationRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.AsyncCallback;
import org.apache.camel.Exchange;
import org.apache.camel.processor.loadbalancer.LoadBalancerSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Slf4j
public class CustomWeightedRoundRobinLoadBalancer extends LoadBalancerSupport {

    private static final AtomicInteger counter = new AtomicInteger(0);

    /** CUSTOM LOAD BALANCER USED FOR SWITCHING THE ROUND-ROBIN AND INTO SINGLE PROVIDER AND VISE VERSA */
    @Override
    public boolean process(Exchange exchange, AsyncCallback callback) {
        Long notificationType = exchange.getIn().getHeader(NotificationUtils.NOTIFICATION_TYPE_ID, Long.class);
        NotificationRequest request  = exchange.getIn().getBody(NotificationRequest.class);
        CamelDetails vendorWiseConfiguration = NotificationUtils.getVendorWiseConfiguration(request.getSourceId(), request.getUserOrgId(), request.getMasterId());
        if(NotificationUtils.isObjectNullOrEmpty(vendorWiseConfiguration)){

            /* GET DEFAULT ROUND-ROBIN CONFIG BASED ON KEY */
            vendorWiseConfiguration = NotificationUtils.selectVendorConfigBasedOnKey(request.getDefaultConfigKey());
            if(NotificationUtils.isObjectNullOrEmpty(vendorWiseConfiguration)){
                log.info("Any configuration not found for masterId [{}]",request.getMasterId());
                callback.done(false);
                return false;
            }
        }

        /* SELECT BEAN AND METHOD TYPE BASED ON NOTIFICATION REQUEST */
        try {
            StringBuilder builder = getBeanUrlBuilder(vendorWiseConfiguration, notificationType);
            exchange.getContext().createProducerTemplate().asyncSend(builder.toString(), exchange);
            callback.done(true);
            return true;
        }catch (Exception e){
            log.error("Exception while processing notification on custom load balancer :",e);
            callback.done(false);
        }
        return false;
    }

    /** USED FOR BUILDING BEAN STRING FOR CALLING APACHE CAMEL BASED ON VENDOR AND ITS WEIGHTAGE */
    private static StringBuilder getBeanUrlBuilder(CamelDetails vendorWiseConfiguration, Long notificationType) {
        int index = counter.getAndIncrement() % vendorWiseConfiguration.getComponentName().size(); //NOSONAR
        String selectedComponent = vendorWiseConfiguration.getComponentName().get(index);

        StringBuilder builder = new StringBuilder( "bean:" + selectedComponent );
        if(notificationType == NotificationType.EMAIL.getTypeId()){
            builder.append("?method=processEmail");
        } else if (notificationType == NotificationType.SMS.getTypeId()) {
            builder.append("?method=processSms");
        }
        return builder;
    }
}
