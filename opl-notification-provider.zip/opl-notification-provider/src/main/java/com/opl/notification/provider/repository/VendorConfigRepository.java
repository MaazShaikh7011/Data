package com.opl.notification.provider.repository;

import com.opl.notification.provider.domain.VendorConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @since 25-09-2024
 */
public interface VendorConfigRepository extends JpaRepository<VendorConfig, Long> {

    List<VendorConfig> findAllByIsActiveTrue();
}
