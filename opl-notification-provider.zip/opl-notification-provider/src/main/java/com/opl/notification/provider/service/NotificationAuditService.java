package com.opl.notification.provider.service;

import com.opl.notification.provider.model.CommonPayLoadProxy;
import com.opl.notification.provider.model.NotificationAuditRequest;

/**
 * @author Maaz Shaikh
 * @implNote NOTIFICATION AUDIT SERVICE
 * @since 09-09-2024
 */
public interface NotificationAuditService {

    /** USED FOR SAVING AUDIT OF EMAIL AND SMS API CALLS
     *
     * @param auditReq AUDIT OBJECT FOR SAVING AND UPLOADING ON BUCKET.
     * @param providerId FOR SETTING FOR EMAIL AND SMS AGAINST API CALL
     * */
    public void audit(NotificationAuditRequest auditReq,Long providerId);

    /***
     * USED FOR SAVING LOGS AND UPLOADING LOGS ON BUCKET FOR SYSTEM NOTIFICATION
     * @param auditId FOR SAVING LOGS
     * @param message SYSTEM NOTIFICATION MESSAGE
     */
    public void updateBucketLogsForSystemNotification(Long auditId, String message);

    /** USED FOR FETCHING UPLOADED LOGS FROM BUCKET BEY AUDIT IT
     *
     * @param auditId - AUDIT ID
     * @param type - NOTIFICATION TYPE ID
     * */
    public <T extends CommonPayLoadProxy> T fetchMessageFromBucket(Long auditId, int type);
}
