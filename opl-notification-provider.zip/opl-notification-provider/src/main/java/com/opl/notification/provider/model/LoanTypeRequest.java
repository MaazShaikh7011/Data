package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class LoanTypeRequest implements Serializable {

    private Long id;
    private String loanTypeName;
    private Integer loanTypeId;
    private Integer buisnessTypeId;
    private Long createdBy;
    private Date createdDate;
    private Long modifiedBy;
    private Date modifiedDate;
    private Boolean isActive;


}
