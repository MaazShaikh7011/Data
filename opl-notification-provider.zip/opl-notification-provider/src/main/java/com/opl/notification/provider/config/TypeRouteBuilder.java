package com.opl.notification.provider.config;

import com.opl.notification.provider.enums.NotificationType;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.service.NotificationService;
import com.opl.notification.provider.utils.NotificationUtils;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Component
public class TypeRouteBuilder extends RouteBuilder {

    @Autowired
    NotificationService notificationService;

    /** ROUTER CONFIG METHOD ITS EXECUTE WHEN SERVICE START */
    @Override
    public void configure() throws Exception {

        /* GET BASIC CONFIG AND PROVIDER DETAIL AND SET */
        notificationService.initServiceConfiguration();

        /* SETTING UP THE CUSTOM LOAD BALANCER */
        CustomWeightedRoundRobinLoadBalancer emailLoadBalancer = new CustomWeightedRoundRobinLoadBalancer();
        CustomWeightedRoundRobinLoadBalancer smsLoadBalancer = new CustomWeightedRoundRobinLoadBalancer();


        /* ROUND ROBIN FOR EMAIL */
        from("direct:emailRoundRobin")
                .setHeader(NotificationUtils.NOTIFICATION_TYPE_ID, constant(NotificationType.EMAIL.getTypeId()))
                .convertBodyTo(EmailRequest.class)
                .process(exchange -> {
                    /* GET INPUT FROM THE EXCHANGE */
                    exchange.getIn().getBody(EmailRequest.class);
                })
                .loadBalance(emailLoadBalancer)
                .end();

        /* ROUND ROBIN FOR SMS */
        from("direct:smsRoundRobin")
                .setHeader(NotificationUtils.NOTIFICATION_TYPE_ID, constant(NotificationType.SMS.getTypeId()))
                .convertBodyTo(SMSRequest.class)
                .process(exchange -> {
                    /* GET INPUT FROM THE EXCHANGE */
                    exchange.getIn().getBody(SMSRequest.class);
                })
                .loadBalance(smsLoadBalancer).end();
    }


}
