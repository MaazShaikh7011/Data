package com.opl.notification.provider.service.impl;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.notification.provider.domain.NotificationLogs;
import com.opl.notification.provider.domain.PayloadAudit;
import com.opl.notification.provider.enums.NotificationType;
import com.opl.notification.provider.model.CommonPayLoadProxy;
import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.PayLoadProxy;
import com.opl.notification.provider.repository.NotificationLogsRepository;
import com.opl.notification.provider.repository.PayloadAuditRepository;
import com.opl.notification.provider.service.NotificationAuditService;
import com.opl.notification.provider.utils.NotificationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author Maaz Shaikh
 * @implNote NOTIFICATION AUDIT SERVICE IMPLEMENTATION
 * @since 09-09-2024
 */
@Service
public class NotificationAuditServiceImpl implements NotificationAuditService {

    @Autowired
    private NotificationLogsRepository logsRepository;

    @Autowired
    private BucketStorageUtils bucketStorageUtils;

    @Autowired
    private PayloadAuditRepository auditRepository;

    /** USED FOR SAVING AUDIT OF EMAIL AND SMS API CALLS
     *
     * @param auditReq AUDIT OBJECT FOR SAVING AND UPLOADING ON BUCKET.
     * @param providerId FOR SETTING FOR EMAIL AND SMS AGAINST API CALL
     * */
    @Override
    public void audit(NotificationAuditRequest auditReq,Long providerId) {
        Date curruntDate = new Date();
        NotificationLogs log = new NotificationLogs();
        log.setOrgId(auditReq.getOrgId());
        log.setSourceType(auditReq.getSourceType());
        log.setTo(auditReq.getToStr().replace("[","").replace("]",""));
        log.setReferenceId(auditReq.getReferenceId());
        if (auditReq.getType() == NotificationType.EMAIL) {
            log.setToEmailCount(!NotificationUtils.isObjectNullOrEmpty(auditReq.getTo()) ? auditReq.getTo().length : null);
            log.setCcEmailCount(!NotificationUtils.isObjectNullOrEmpty(auditReq.getCc()) ? auditReq.getCc().length : null);
            log.setBccEmailCount(!NotificationUtils.isObjectNullOrEmpty(auditReq.getBcc()) ? auditReq.getBcc().length : null);
        }
        if (auditReq.getType() == NotificationType.SMS && !NotificationUtils.isObjectNullOrEmpty(auditReq.getBody())) {
            log.setContentLength(auditReq.getBody().length());
            double smsCount = Math.ceil((double) auditReq.getBody().length() / 160);
            log.setSmsCount((int) smsCount);
        }
        log.setNotificationTypeId(auditReq.getType().getTypeId());
        log.setIsActive(Boolean.TRUE);
        log.setCreatedDate(curruntDate);
        log.setMasterId(auditReq.getMasterId());
        log.setSubjectId(auditReq.getSubjectId());
        log.setStatus(auditReq.getStatus());
        log.setTemplateId(auditReq.getTemplateId());
        log.setProviderId(providerId);
        log = logsRepository.save(log);
        updateBucketLogs(log.getId(), auditReq);
    }


    public String getValue() {
        return System.getenv("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");
    }

    /** USED FOR UPLOAD LOGS ON AWS BUCKET  AGAINST AUDIT ID*/
    public void updateBucketLogs(Long auditId, NotificationAuditRequest auditReq) {
        String ref = generateRef(auditReq.getReferenceId());
        PayloadAudit reqResAudit = new PayloadAudit();
        reqResAudit.setLogAudit(auditId);
        reqResAudit.setStorageId(ref);
        reqResAudit.setSuccess(false);
        reqResAudit.setNotificationTypeId(auditReq.getType().getTypeId());

        PayLoadProxy loadProxy = new PayLoadProxy();
        loadProxy.setTo(auditReq.getToStr().replace("[","").replace("]",""));
        loadProxy.setCc(auditReq.getCcStr());
        loadProxy.setBcc(auditReq.getBccStr());
        loadProxy.setSubject(auditReq.getSubject());
        loadProxy.setNotificationMessage(auditReq.getBody());
        loadProxy.setUrl(auditReq.getUrl());
        loadProxy.setHeader(auditReq.getHeaders());
        loadProxy.setRequest(auditReq.getRequestForAudit());
        loadProxy.setApiResponse(auditReq.getRes());
        loadProxy.setReferenceId(ref);
        loadProxy.setLogAuditId(auditId);
        String upload = bucketStorageUtils.upload(getValue(), loadProxy, ref);
        if (!NotificationUtils.isObjectNullOrEmpty(upload)) {
            reqResAudit.setSuccess(true);
        }
        auditRepository.save(reqResAudit);
    }

    /***
     * USED FOR SAVING LOGS AND UPLOADING LOGS ON BUCKET FOR SYSTEM NOTIFICATION
     * @param auditId FOR SAVING LOGS
     * @param message SYSTEM NOTIFICATION MESSAGE
     */
    public void updateBucketLogsForSystemNotification(Long auditId, String message) {
        String ref = "Sys_Ntf_" + NotificationUtils.generateUUID();
        PayloadAudit reqResAudit = new PayloadAudit();
        reqResAudit.setLogAudit(auditId);
        reqResAudit.setStorageId(ref);
        reqResAudit.setSuccess(false);
        reqResAudit.setNotificationTypeId(NotificationType.SYSTEM.getTypeId());

        CommonPayLoadProxy loadProxy = new CommonPayLoadProxy();
        loadProxy.setNotificationMessage(message);
        loadProxy.setReferenceId(ref);
        loadProxy.setLogAuditId(auditId);
        String upload = bucketStorageUtils.upload(getValue(), loadProxy, ref);
        if (!NotificationUtils.isObjectNullOrEmpty(upload)) {
            reqResAudit.setSuccess(true);
        }
        auditRepository.save(reqResAudit);
    }

    /** GENERATE REF ID FOR SAVING LOGS AGAINST THE ID */
    private String generateRef(Long referenceNumber) {
        return "Ntf_" + NotificationUtils.generateUUID() + "_" + referenceNumber;
    }

    /** USED FOR FETCHING UPLOADED LOGS FROM BUCKET BEY AUDIT IT
     *
     * @param auditId - AUDIT ID
     * @param type - NOTIFICATION TYPE ID
     * */
    public <T extends CommonPayLoadProxy> T fetchMessageFromBucket(Long auditId, int type) {
        PayloadAudit payloadAudit = auditRepository.findFirstByLogAuditAndNotificationTypeId(auditId, (long) type);
        Object fileObject = bucketStorageUtils.getFileObject(getValue(), payloadAudit.getStorageId());
        return (T) fileObject;
    }

}
