package com.opl.notification.provider.model.sms;

import com.opl.notification.provider.model.NotificationRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class SMSRequest extends NotificationRequest {
    private String[] phoneNumber;
    private String phoneNumberStr;
    private String smsTemplateInString;
    private Long dltId;
    private String mappedMessage;
    private Long providerId;
    private String providerName;
}
