package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class UserOrganisationMasterRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long userOrgId;
    private String organisationName;
    private boolean isActive;


}