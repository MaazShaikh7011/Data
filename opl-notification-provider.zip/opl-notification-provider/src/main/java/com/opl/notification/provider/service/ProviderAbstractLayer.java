package com.opl.notification.provider.service;

import com.opl.notification.provider.domain.Provider;
import com.opl.notification.provider.enums.NotificationType;
import com.opl.notification.provider.model.NotificationAuditRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.repository.ProviderRepository;
import com.opl.notification.provider.utils.NotificationUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author Maaz Shaikh
 * @implNote Abstract implementation of provider Parent class
 * @since 09-09-2024
 */
public abstract class ProviderAbstractLayer implements ProviderService{

    /** METHOD FOR PREPARE AUDIT FIELDS FOR EMAIL */
    public NotificationAuditRequest prepareEmailAuditRequest(EmailRequest emailRequest, String providerName,Long providerId, String url) {
        NotificationAuditRequest request = new NotificationAuditRequest();
        request.setType(NotificationType.EMAIL);
        request.setTo(emailRequest.getToEmail());
        request.setToStr(emailRequest.getToEmailStr());
        request.setCc(emailRequest.getCc());
        request.setBcc(emailRequest.getBcc());
        request.setBody(emailRequest.getEmailContent());
        request.setSubjectId(emailRequest.getSubjectId());
        request.setOrgId(emailRequest.getUserOrgId());
        request.setSourceType(emailRequest.getSourceType());
        request.setTemplateId(!NotificationUtils.isObjectNullOrEmpty(emailRequest.getTemplateId()) ? emailRequest.getTemplateId() : 0L);
        request.setMasterId(!NotificationUtils.isObjectNullOrEmpty(emailRequest.getMasterId()) ? emailRequest.getMasterId() : 0L);
        request.setProviderId(providerId);
        request.setProviderName(providerName);
        request.setSubject(emailRequest.getSubject());
        request.setReferenceId(NotificationUtils.getRandomNumberString());
        request.setUrl(url);
        return request;
    }

    /** METHOD FOR PREPARE AUDIT FIELDS FOR EMAIL */
    public NotificationAuditRequest prepareSmsAuditRequest(SMSRequest smsRequest,String requestUrl){
        NotificationAuditRequest auditReq = new NotificationAuditRequest();
        auditReq.setUrl(requestUrl);
        auditReq.setType(NotificationType.SMS);
        auditReq.setToStr(smsRequest.getPhoneNumberStr());
        auditReq.setTo(smsRequest.getPhoneNumber());
        auditReq.setTemplateId(!NotificationUtils.isObjectNullOrEmpty(smsRequest.getTemplateId()) ? smsRequest.getTemplateId() : 0L);
        auditReq.setMasterId(!NotificationUtils.isObjectNullOrEmpty(smsRequest.getMasterId()) ? smsRequest.getMasterId() : 0L);
        auditReq.setBody(smsRequest.getMappedMessage());
        auditReq.setProviderId(smsRequest.getProviderId());
        auditReq.setProviderName(smsRequest.getProviderName());
        auditReq.setReferenceId(NotificationUtils.getRandomNumberString());
        auditReq.setOrgId(smsRequest.getUserOrgId());
        auditReq.setSourceType(smsRequest.getSourceType());
        return auditReq;
    }

}
