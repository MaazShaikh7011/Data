package com.opl.notification.provider.model.email;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class ContentAttachment {

    private String fileName;
    private byte[] contentInByte;

}
