package com.opl.notification.provider.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;


/**
 * @author Maaz Shaikh
 * @since 09-09-2024
 */
@Setter
@Getter
public class NotificationTemplateRequest {

    private Long id;
    private Long createdBy;
    private Date createdDate;
    private Boolean isWorking;
    private String isActive;
    private Long modifiedBy;
    private Date modifiedDate;
    private String templateName;
    private String notificationTemplate;
    private Long notificationTypeId;
    private Long organizationId;
    private String alias;
    private Boolean isBccActive;
    private String bccEmail;
    private Boolean isSinglePageTemplate;
    private Boolean isWorkWithOldFlow;
    private UserOrganisationMasterRequest userOrg;
    private LoanTypeRequest loanTypeId;
    private NotificationMasterRequest masterReq;
    private String notificationDescription;
    private Long dltId;
}
