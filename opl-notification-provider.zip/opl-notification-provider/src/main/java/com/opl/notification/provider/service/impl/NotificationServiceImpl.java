package com.opl.notification.provider.service.impl;

import com.opl.notification.provider.domain.BankVendorConfig;
import com.opl.notification.provider.domain.BasicConfiguration;
import com.opl.notification.provider.domain.Provider;
import com.opl.notification.provider.domain.VendorConfig;
import com.opl.notification.provider.model.BasicConfigurationRequest;
import com.opl.notification.provider.model.email.EmailRequest;
import com.opl.notification.provider.model.sms.SMSRequest;
import com.opl.notification.provider.model.vendor.BankVendorConfigModel;
import com.opl.notification.provider.model.vendor.ProviderRequest;
import com.opl.notification.provider.model.vendor.VendorConfigModel;
import com.opl.notification.provider.repository.BankVendorConfigRepository;
import com.opl.notification.provider.repository.BasicConfigurationRepository;
import com.opl.notification.provider.repository.ProviderRepository;
import com.opl.notification.provider.repository.VendorConfigRepository;
import com.opl.notification.provider.service.NotificationService;
import com.opl.notification.provider.utils.NotificationUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Maaz Shaikh
 * @implNote Use for common methods and shared objects
 * @since 09-09-2024
 */
@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    ProviderRepository providerRepository;

    @Autowired
    BankVendorConfigRepository bankVendorConfigRepo;

    @Autowired
    VendorConfigRepository vendorConfigRepo;

    @Autowired
    BasicConfigurationRepository configRepo;

    /** CAMEL CONFIG */
    private final CamelContext camelContext;
    private final ProducerTemplate template;
    public NotificationServiceImpl(CamelContext camelContext) {
        this.camelContext = camelContext;
        this.template = camelContext.createProducerTemplate();
    }

    /** RUN APACHE CAMEL ROUTER FOR SMS */
    public String processSms(SMSRequest smsRequest) {
        return template.requestBody("direct:smsRoundRobin", smsRequest, String.class);
    }

    /** RUN APACHE CAMEL ROUTER FOR EMAIL */
    public String processEmail(EmailRequest emailRequest) {
        return template.requestBody("direct:emailRoundRobin", emailRequest, String.class);
    }

    /** SET PROVIDER LIST AND BASIC CONFIG  */
    public void initServiceConfiguration() {

        /* SET VENDOR CONFIG */
        List<VendorConfig> allVendorConfig = vendorConfigRepo.findAllByIsActiveTrue();
        allVendorConfig.forEach(x -> {
            VendorConfigModel model = new VendorConfigModel();
            BeanUtils.copyProperties(x,model);
            NotificationUtils.setVendorConfig(model);
        });

        /* SET BANK VENDOR CONFIG */
        List<BankVendorConfig> allBankVendorConfig = bankVendorConfigRepo.findAllByIsActiveTrue();
        allBankVendorConfig.forEach(x -> {
            BankVendorConfigModel model = new BankVendorConfigModel();
            BeanUtils.copyProperties(x,model);
            NotificationUtils.setBankVendorConfig(model);
        });

        /* SET PROVIDER CONFIG */
        List<Provider> allProvider = providerRepository.findAllByIsActive(NotificationUtils.Y);
        allProvider.forEach(x -> {
            ProviderRequest req = new ProviderRequest();
            BeanUtils.copyProperties(x, req);
            NotificationUtils.setProviderList(req);
        });

        /* SET BASIC CONFIGURATIONS */
        List<BasicConfiguration> allConfig = configRepo.findAllByIsActiveTrue();
        allConfig.forEach(x -> {
            BasicConfigurationRequest req = new BasicConfigurationRequest();
            BeanUtils.copyProperties(x,req);
            NotificationUtils.setBasicConfig(req);
        });

        log.info("All configuration has been loaded  initially ======================> ");
    }

}
