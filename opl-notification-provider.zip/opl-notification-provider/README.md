    **Required Table**
    
        BasicConfiguration -- for notification and required Basic Config
        NotificationLogs  -- For Audit Logs
        PayloadAudit - For Bucket Logs
        Provider - For Notification provider master table with master data. https://rsource.instantmseloans.in/commoncodebase/opl-notification-provider/-/blob/master/Sql/notification_provider_orcl%20master%20data%20.sql
    
    **Technology used**
        Spring boot 3.3.3
        Apapche camel 4.7
    
    **Steps of change Provider**
        in notification_provider modified the value of the call ratio.
        0 indicates not working in round robin
        1 indicates running once in round robin.

    **Run Single Provider**
        If you only want to run one provider, pick notification type in notification_provider, 
        save 0 in the callRatio column of all records, and 1 in the callRatio column of the provider you want to run.

    **Integration steps**
        Steps for Adding a New Provider
            1. Add a call ratio and call order column to the notification_provider table.
            2. Create a service implementation with a qualified name for that provider; see the example below.
                @Service("AclServiceImpl")
            3. Enter the Qualifier's name in the Provider Enum.
            4. Before installing the whole service, ensure that the apache camel settings are working properly.

        Steps of Test service
            1.Add the Maven dependency for opl-notification-provider.
            2.Create an API and invoke the NotificationService method implemented in opl-notification-provider.
            3.Run the API.