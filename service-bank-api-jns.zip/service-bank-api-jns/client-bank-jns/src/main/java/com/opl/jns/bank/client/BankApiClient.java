package com.opl.jns.bank.client;

import java.io.IOException;
import java.time.ZoneId;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequestV3;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationRequestV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponseV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequestV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponseV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequestV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponseV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequestV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.api.model.BankAllApisResProxy;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;

public class BankApiClient {

    public static final String STATUS_CODE_RECEIVED_IN_EXCEPTION = "status code received in exception [{}] ===> ";
    public static final String RESP_GET_STATUS_CODE_VALUE = "resp.getStatusCode().value() ==>  [{}] ===> ";
    private static Logger logger = LoggerFactory.getLogger(BankApiClient.class);
    public static final String RESPONSE = "response";
    public static final String STATUS = "status";
    public static final int INT_2 = 2;

    private String baseUrlStr;
    private RestTemplate restTemplate;


    private static final String TRIGGER_OTP = "/v1/triggerOTP";
    private static final String VERIFY_OTP = "/v1/verifyOtp";
    private static final String GET_CUSTOMER_DETAILS = "/v1/getCustomerDetails";
    private static final String GET_PREMIUM_DEDUCTION = "/v1/getPremiumDeduction";
    private static final String PHYSICAL_VERIFICATION = "/v1/verifyPhysicalSignature";
    private static final String TRIGGER_OTP_V3 = "/v3/triggerVerificationCode";
    private static final String VERIFY_OTP_V3 = "/v3/verifyVerificationCode";
    private static final String GET_CUSTOMER_DETAILS_V3 = "/v3/getCustomerDetails";
    private static final String GET_PREMIUM_DEDUCTION_V3 = "/v3/premiumDeduction";
    private static final String PHYSICAL_VERIFICATION_V3 = "/v3/physicalSignatureVerification";
    private static final String GET_ACC_HOLDER_LST = "/v3/getAccHolderList";
    private static final String GET_POLICY_DTL = "/v3/getPolicyDetails";
    private static final String OPT_OUT_UPDATE_STATUS = "/v3/optOutUpdateStatus";
    private static final String NOMINEE_UPDATE_STATUS = "/v3/nomineeUpdateStatus";
    private static final String PUSH_CLAIM_STATUS_YO_BANK = "/v3/pushClaimStatustoBank";
    private static final String CHECK_DEDUPE = "/insurer/checkDedupe";
    private static final String FETCH_VERIFY_OTP_RESPONSE = "/audit/fetchVerifyOtpResponse";
    private static final String FETCH_ALL_API_RESPONSE = "/audit/fetchAllApisResByAppId/";

    public BankApiClient() {
    }

    public BankApiClient(String baseUrlStr) {
        super();
        this.baseUrlStr = baseUrlStr;
        this.restTemplate = new RestTemplate();
    }


    public TriggerOtpResponseV3 triggerOTP(TriggerOtpRequestV3 triggerOtpRequest,AuthClientResponse authClientResponse) throws IOException {
//      String url = baseUrlStr.concat(TRIGGER_OTP);
		String url = null;
		Boolean isPhase2 = PhaseMode.checkPhase2(triggerOtpRequest.getOrgId());
		triggerOtpRequest.setToken(triggerOtpRequest.getUrn());
		if (Boolean.TRUE.equals(isPhase2)) {
			url = baseUrlStr.concat(TRIGGER_OTP_V3);
		} else {
			url = baseUrlStr.concat(TRIGGER_OTP);
		}
        logger.info("Enter in calling  Trigget OTP Api -------------------->{}", url);
        try {
            HttpHeaders headers = setHeaders(authClientResponse);
            HttpEntity<TriggerOtpRequestV3> entity = new HttpEntity<>(triggerOtpRequest,headers);
            TriggerOtpResponseV3 triggerOtpResponse = restTemplate.exchange(url, HttpMethod.POST, entity, TriggerOtpResponseV3.class).getBody();
            if (Boolean.TRUE.equals(isPhase2)) {
            	triggerOtpResponse.setFlag(triggerOtpResponse.getSuccess());
            }else {
            	triggerOtpResponse.setToken(triggerOtpRequest.getUrn());
            	triggerOtpResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
            	triggerOtpResponse.setSuccess(triggerOtpResponse.getFlag());
            }
            return triggerOtpResponse;
        } catch(HttpStatusCodeException e) {
			return setResponseData(TriggerOtpResponseV3.class ,e);
		} catch (Exception e) {
            logger.error("Exception While calling  Trigget OTP Api :: ", e);
            return null;
        }
    }


    public VerifyOtpApiResponseV3 verifyOtp(OTPRequestV3 otpRequest,AuthClientResponse authClientResponse) throws IOException {
//      String url = baseUrlStr.concat(VERIFY_OTP);
		String url = null;
		Boolean isPhase2 = PhaseMode.checkPhase2(otpRequest.getOrgId());
		otpRequest.setToken(otpRequest.getUrn());
		if (Boolean.TRUE.equals(isPhase2)) {
			url = baseUrlStr.concat(VERIFY_OTP_V3);
		} else {
			url = baseUrlStr.concat(VERIFY_OTP);
		}
        logger.info("Enter in calling  VERIFY OTP Api -------------------->{}", url);
		logger.info("MultipleJSONObjectHelper.getStringfromObject(otpRequest)==>> {}",MultipleJSONObjectHelper.getStringfromObject(otpRequest));
        try {
            HttpHeaders headers = setHeaders(authClientResponse);
            HttpEntity<OTPRequestV3> entity = new HttpEntity<>(otpRequest,headers);
            VerifyOtpApiResponseV3 verifyOtpApiResponse = restTemplate.exchange(url, HttpMethod.POST, entity, VerifyOtpApiResponseV3.class).getBody();
			logger.info("verifyOtpApiResponse.getFlag() ===>>   {}",verifyOtpApiResponse.getFlag());
            if (Boolean.TRUE.equals(isPhase2)) {
            	verifyOtpApiResponse.setFlag(verifyOtpApiResponse.getSuccess());
            }else {
            	verifyOtpApiResponse.setToken(otpRequest.getUrn());
            	verifyOtpApiResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
            	verifyOtpApiResponse.setSuccess(verifyOtpApiResponse.getFlag());
            }
            return verifyOtpApiResponse;
        } catch(HttpStatusCodeException e) {
			return setResponseData(VerifyOtpApiResponseV3.class ,e);
		} catch (Exception e) {
            logger.error("Exception While calling  VERIFY OTP Api :: ", e);
            return null;
        }
    }


    public CustomerDetailsDataV3 getCustomerDetails(CustomerDetailsRequest customerDetailsRequest,AuthClientResponse authClientResponse) throws IOException {
    	String url = null;
    	Boolean isPhase2 = PhaseMode.checkPhase2(customerDetailsRequest.getOrgId());
    	customerDetailsRequest.setToken(customerDetailsRequest.getUrn());
		if (Boolean.TRUE.equals(isPhase2)) {
			url = baseUrlStr.concat(GET_CUSTOMER_DETAILS_V3);
		} else {
			url = baseUrlStr.concat(GET_CUSTOMER_DETAILS);
		}
        logger.info("Enter in calling  GET CUSTOMER DETAILS Api -------------------->{}", url);
        try {
            HttpHeaders headers = setHeaders(authClientResponse);
            HttpEntity<CustomerDetailsRequest> entity = new HttpEntity<>(customerDetailsRequest,headers);
            CustomerDetailsDataV3 customerDetailsDataV3 =restTemplate.exchange(url, HttpMethod.POST, entity, CustomerDetailsDataV3.class).getBody();
            if (Boolean.TRUE.equals(isPhase2)) {
            	customerDetailsDataV3.setFlag(customerDetailsDataV3.getSuccess());
            }else {
            	customerDetailsDataV3.setToken(customerDetailsRequest.getUrn());
            	customerDetailsDataV3.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
            	customerDetailsDataV3.setSuccess(customerDetailsDataV3.getFlag());
            }
            return customerDetailsDataV3;
        } catch(HttpStatusCodeException e) {
			return setResponseData(VerifyOtpApiResponseV3.class ,e);
		} catch (Exception e) {
            logger.error("Exception While calling  GET CUSTOMER DETAILS Api :: ", e);
            return null;
        }
    }


    public PremiumDeductionResponseV3 getPremiumDeduction(PremiumDeductionRequestV3 premiumDeductionRequest,AuthClientResponse authClientResponse) throws IOException {
//      String url = baseUrlStr.concat(GET_PREMIUM_DEDUCTION);
		String url = null;
		Boolean isPhase2 = PhaseMode.checkPhase2(premiumDeductionRequest.getOrgId());
		premiumDeductionRequest.setToken(premiumDeductionRequest.getUrn());
		if (Boolean.TRUE.equals(isPhase2)) {
			url = baseUrlStr.concat(GET_PREMIUM_DEDUCTION_V3);
		} else {
			url = baseUrlStr.concat(GET_PREMIUM_DEDUCTION);
		}
        logger.info("Enter in calling  GET PREMIUM DEDUCTION Api -------------------->{}", url);
        try {
            HttpHeaders headers = setHeaders(authClientResponse);
            HttpEntity<PremiumDeductionRequestV3> entity = new HttpEntity<>(premiumDeductionRequest,headers);
            PremiumDeductionResponseV3 premiumDeductionResponse = restTemplate.exchange(url, HttpMethod.POST, entity, PremiumDeductionResponseV3.class).getBody();
            if (Boolean.TRUE.equals(isPhase2)) {
            	premiumDeductionResponse.setFlag(premiumDeductionResponse.getSuccess());
            }else {
            	premiumDeductionResponse.setDebitStatus("1");
            	premiumDeductionResponse.setToken(premiumDeductionRequest.getUrn());
            	premiumDeductionResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
            	premiumDeductionResponse.setSuccess(premiumDeductionResponse.getFlag());
            }
            return premiumDeductionResponse;
        } catch(HttpStatusCodeException e) {
			return setResponseData(PremiumDeductionResponseV3.class ,e);
		} catch (Exception e) {
            logger.error("Exception While calling  GET PREMIUM DEDUCTION Api :: ", e);
            return null;
        }
    }
    
    public PhysicalVerificationResponseV3 verifyPhysicalSignature(PhysicalVerificationRequestV3 physicalVerificationRequest,AuthClientResponse authClientResponse) throws IOException {
//      String url = baseUrlStr.concat(PHYSICAL_VERIFICATION);
		String url = null;
		Boolean isPhase2 = PhaseMode.checkPhase2(physicalVerificationRequest.getOrgId());
		physicalVerificationRequest.setToken(physicalVerificationRequest.getUrn());
		if (Boolean.TRUE.equals(isPhase2)) {
			url = baseUrlStr.concat(PHYSICAL_VERIFICATION_V3);
		} else {
			url = baseUrlStr.concat(PHYSICAL_VERIFICATION);
		}
        logger.info("Enter in calling  GET PHYSICAL VERIFICATION Api -------------------->{}", url);
        try {
            HttpHeaders headers = setHeaders(authClientResponse);
            HttpEntity<PhysicalVerificationRequestV3> entity = new HttpEntity<>(physicalVerificationRequest,headers);
            PhysicalVerificationResponseV3 physicalVerificationResponse = restTemplate.exchange(url, HttpMethod.POST, entity, PhysicalVerificationResponseV3.class).getBody();
            if (Boolean.TRUE.equals(isPhase2)) {
            	physicalVerificationResponse.setFlag(physicalVerificationResponse.getSuccess());
            }else {
            	physicalVerificationResponse.setToken(physicalVerificationRequest.getUrn());
            	physicalVerificationResponse.setTimestamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
            	physicalVerificationResponse.setSuccess(physicalVerificationResponse.getFlag());
            }
            return physicalVerificationResponse;
        } catch(HttpStatusCodeException e) {
			return setResponseData(PhysicalVerificationResponseV3.class ,e);
		} catch (Exception e) {
            logger.error("Exception While calling  GET PHYSICAL VERIFICATION Api :: ", e);
            return null;
        }
    }
//    
//    public TriggerOtpResponse triggerOTPV3(TriggerOtpRequest triggerOtpRequest,AuthClientResponse authClientResponse) throws IOException {
//        String url = baseUrlStr.concat(TRIGGER_OTP_V3);
//        logger.info("Enter in calling  Trigget OTP Api -------------------->{}", url);
//        try {
//            HttpHeaders headers = setHeaders(authClientResponse);
//            HttpEntity<TriggerOtpRequest> entity = new HttpEntity<>(triggerOtpRequest,headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, TriggerOtpResponse.class).getBody();
//        } catch(HttpStatusCodeException e) {
//			return setResponseData(TriggerOtpResponse.class ,e);
//		} catch (Exception e) {
//            logger.error("Exception While calling  Trigget OTP Api :: ", e);
//            return null;
//        }
//    }
//
//
//    public VerifyOtpApiResponse verifyOtpV3(OTPRequest otpRequest,AuthClientResponse authClientResponse) throws IOException {
//        String url = baseUrlStr.concat(VERIFY_OTP_V3);
//        logger.info("Enter in calling  VERIFY OTP Api -------------------->{}", url);
//        try {
//            HttpHeaders headers = setHeaders(authClientResponse);
//            HttpEntity<OTPRequest> entity = new HttpEntity<>(otpRequest,headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, VerifyOtpApiResponse.class).getBody();
//        } catch(HttpStatusCodeException e) {
//			return setResponseData(VerifyOtpApiResponse.class ,e);
//		} catch (Exception e) {
//            logger.error("Exception While calling  VERIFY OTP Api :: ", e);
//            return null;
//        }
//    }


//    public CustomerDetailsDataV3 getCustomerDetailsV3(CustomerDetailsRequest customerDetailsRequest,AuthClientResponse authClientResponse) throws IOException {
//        String url = baseUrlStr.concat(GET_CUSTOMER_DETAILS_V3);
//        logger.info("Enter in calling  GET CUSTOMER DETAILS Api -------------------->{}", url);
//        try {
//            HttpHeaders headers = setHeaders(authClientResponse);
//            HttpEntity<CustomerDetailsRequest> entity = new HttpEntity<>(customerDetailsRequest,headers);
//            return restTemplate.exchange(url, HttpMethod.POST, entity, CustomerDetailsDataV3.class).getBody();
//        } catch(HttpStatusCodeException e) {
//			return setResponseData(CustomerDetailsDataV3.class ,e);
//		} catch (Exception e) {
//            logger.error("Exception While calling  GET CUSTOMER DETAILS Api :: ", e);
//            return null;
//        }
//    }


	public VerifyOtpApiResponseV3 fetchVerifyOtpResponse(AccountHolderSelectionDetailsRequest accountHolderSelRequest) {
		String url = baseUrlStr.concat(FETCH_VERIFY_OTP_RESPONSE);
//		String url = "http://localhost:8053/bankapi/v1/fetchVerifyOtpResponse";
		logger.info("Enter in calling  FETCH VERIFY OTP RESPONSE Api -------------------->{}", url);
		try {
			HttpHeaders headers = setHeaders(null);
			HttpEntity<AccountHolderSelectionDetailsRequest> entity = new HttpEntity<>(accountHolderSelRequest,
					headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, VerifyOtpApiResponseV3.class).getBody();
		} catch (Exception e) {
			logger.error("Exception While calling  FETCH VERIFY OTP RESPONSE Api :: ", e);
			return null;
		}
	}
	
	public AccHolderListResponseV3 getAccHolderList(AccHolderListRequestV3 accHolderListRequest,AuthClientResponse authClientResponse) {
		String url = baseUrlStr.concat(GET_ACC_HOLDER_LST);
		accHolderListRequest.setToken(!OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getUrn()) ? accHolderListRequest.getUrn() : accHolderListRequest.getAccountNumber());
		logger.info("Enter in calling  FETCH ACCOUNT HOLDER LIST RESPONSE Api -------------------->{}", url);
		try {
			HttpHeaders headers = setHeaders(authClientResponse);
			HttpEntity<AccHolderListRequestV3> entity = new HttpEntity<>(accHolderListRequest,
					headers);
			return restTemplate.exchange(url, HttpMethod.POST, entity, AccHolderListResponseV3.class).getBody();
		} catch (Exception e) {
			logger.error("Exception While calling FETCH ACCOUNT HOLDER LIST RESPONSE Api :: ", e);
			return null;
		}
	}
	
	public PolicyDetailsResponseV3 getPolicyDetails(PolicyDetailsRequestV3 policyDetailsRequest,AuthClientResponse authClientResponse) {
		String url = baseUrlStr.concat(GET_POLICY_DTL);
		logger.info("Enter in calling  FETCH POLICY DETAILS RESPONSE Api -------------------->{}", url);
		policyDetailsRequest.setToken(!OPLUtils.isObjectNullOrEmpty(policyDetailsRequest.getUrn()) ? policyDetailsRequest.getUrn() : policyDetailsRequest.getAccountNumber());
		try {
			HttpHeaders headers = setHeaders(authClientResponse);
			HttpEntity<PolicyDetailsRequestV3> entity = new HttpEntity<>(policyDetailsRequest,
					headers);
			PolicyDetailsResponseV3 detailsResponse= restTemplate.exchange(url, HttpMethod.POST, entity, PolicyDetailsResponseV3.class).getBody();
			logger.info("Policy Response ----Client----------------->{}",MultipleJSONObjectHelper.getStringfromObject(detailsResponse));
			return detailsResponse;
		} catch (Exception e) {
			logger.error("Exception While calling FETCH POLICY DETAILS RESPONSE Api :: ", e);
			return null;
		}
	}
	
	public BankAllApisResProxy fetchAllApisResponse(String urn) {
		String url = baseUrlStr.concat(FETCH_ALL_API_RESPONSE + urn);
//		String url = "http://localhost:8053/bankapi/audit/fetchAllApisResByAppId/" + urn;
		logger.info("Enter in calling  FETCH ALL APIS RESPONSE -------------------->{}", url);
		try {
			HttpHeaders headers = setHeaders(null);
			HttpEntity<String> entity = new HttpEntity<>(urn,
					headers);
			return restTemplate.exchange(url, HttpMethod.GET, entity, BankAllApisResProxy.class).getBody();
		} catch (Exception e) {
			logger.error("Exception While calling  FETCH ALL APIS RESPONSE :: ", e);
			return null;
		}
	}

    private static HttpHeaders setHeaders(AuthClientResponse authClientResponse) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("req_auth", "true");
        headers.setContentType(MediaType.APPLICATION_JSON);
        if(!OPLUtils.isObjectNullOrEmpty(authClientResponse)) {
            headers.set("email", authClientResponse.getEmail());
            headers.set("userId", String.valueOf(authClientResponse.getUserId()));
        }
        return headers;
    }

    public static <T> T setResponseData(Class<?> classType,HttpStatusCodeException e) throws IOException {
    	if(classType.equals(TriggerOtpResponseV3.class)) {
    		TriggerOtpResponseV3 response = new TriggerOtpResponseV3();
    		logger.info(STATUS_CODE_RECEIVED_IN_EXCEPTION,e.getStatusCode().value());
    		ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());		
    		response.setStatus(resp.getStatusCode().value());
    		CommonResponse commonResponse = MultipleJSONObjectHelper.getObjectFromString(resp.getBody(), CommonResponse.class);
    		response.setMessage(commonResponse.getMessage());
    		response.setFlag(commonResponse.getFlag());
    		if(e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
    				|| e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE){
    			response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
    		}
    		logger.info(RESP_GET_STATUS_CODE_VALUE,resp.getStatusCode().value());
    		return MultipleJSONObjectHelper.getObjectFromObject(response, TriggerOtpResponseV3.class);
    	}else if(classType.equals(VerifyOtpApiResponseV3.class)) {
    		VerifyOtpApiResponseV3 response = new VerifyOtpApiResponseV3();
    		logger.info(STATUS_CODE_RECEIVED_IN_EXCEPTION,e.getStatusCode().value());
    		ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());		
    		response.setStatus(resp.getStatusCode().value());
    		CommonResponse commonResponse = MultipleJSONObjectHelper.getObjectFromString(resp.getBody(), CommonResponse.class);
    		response.setMessage(commonResponse.getMessage());
    		if(e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
    				|| e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE){
    			response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
    		}
    		logger.info(RESP_GET_STATUS_CODE_VALUE,resp.getStatusCode().value());
    		return MultipleJSONObjectHelper.getObjectFromObject(response, VerifyOtpApiResponseV3.class);
    	}else if(classType.equals(PremiumDeductionResponseV3.class)) {
    		PremiumDeductionResponseV3 response = new PremiumDeductionResponseV3();
    		logger.info(STATUS_CODE_RECEIVED_IN_EXCEPTION,e.getStatusCode().value());
    		ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());		
    		response.setStatus(resp.getStatusCode().value());
    		CommonResponse commonResponse = MultipleJSONObjectHelper.getObjectFromString(resp.getBody(), CommonResponse.class);
    		response.setMessage(commonResponse.getMessage());
    		if(e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
    				|| e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE){
    			response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
    		}
    		logger.info(RESP_GET_STATUS_CODE_VALUE,resp.getStatusCode().value());
    		return MultipleJSONObjectHelper.getObjectFromObject(response, PremiumDeductionResponseV3.class);
    	}else if(classType.equals(PhysicalVerificationResponseV3.class)) {
    		PhysicalVerificationResponseV3 response = new PhysicalVerificationResponseV3();
    		logger.info(STATUS_CODE_RECEIVED_IN_EXCEPTION,e.getStatusCode().value());
    		ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());		
    		response.setStatus(resp.getStatusCode().value());
    		CommonResponse commonResponse = MultipleJSONObjectHelper.getObjectFromString(resp.getBody(), CommonResponse.class);
    		response.setMessage(commonResponse.getMessage());
    		if(e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT || e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
    				|| e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE){
    			response.setStatus(HttpStatus.GATEWAY_TIMEOUT.value());
    		}
    		logger.info(RESP_GET_STATUS_CODE_VALUE,resp.getStatusCode().value());
    		return MultipleJSONObjectHelper.getObjectFromObject(response, PhysicalVerificationResponseV3.class);
    	}
		return null;
    }
}
