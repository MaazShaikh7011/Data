package com.opl.jns.bank.api.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse implements Serializable {


	private String metadata;

}
