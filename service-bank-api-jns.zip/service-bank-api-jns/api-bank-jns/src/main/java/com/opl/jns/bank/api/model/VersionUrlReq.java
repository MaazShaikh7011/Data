package com.opl.jns.bank.api.model;


import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VersionUrlReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private ApiUrlsRequest v2;
	private ApiUrlsRequest v3;
}
