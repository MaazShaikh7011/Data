package com.opl.jns.bank.api.model.common;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AccountHolderSelectionDetailsRequest {
	
	private Long applicationId;
	private String urn;
	private String referenceId;
	private Long userId;

}
