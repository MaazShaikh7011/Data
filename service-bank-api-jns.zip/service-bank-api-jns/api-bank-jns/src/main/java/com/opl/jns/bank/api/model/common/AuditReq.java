package com.opl.jns.bank.api.model.common;

import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AuditReq {

	private Long applicationId;

	private Long orgId;

	private String failureReason;

	private Integer apiId;

	private Integer responseCode;

	private Date createdDate;

	private String referenceId;

	private String reqPlain;

	private String resEncrypt;

	private String reqEncrypt;

	private String resPlain;

	private Map<String, String> reqHeader;

	private String reqUrl;

	private String urn;

	private String accountNumber;
	
	private String requestRefNumber;
	
	private String reqToken;
	
	private String secretKey;
	
	private String errorMsg;


	public AuditReq(Long applicationId, Long orgId, Integer apiId, Date createdDate, String referenceId, String urn,
			String accountNumber, String reqToken) {
		super();
		this.applicationId = applicationId;
		this.orgId = orgId;
		this.apiId = apiId;
		this.createdDate = createdDate;
		this.referenceId = referenceId;
		this.urn = urn;
		this.accountNumber = accountNumber;
		this.reqToken = reqToken;
	}

}
