package com.opl.jns.bank.api.model.sbi;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SBIEncryptedResponse implements Serializable {

	private static final long serialVersionUID = -7894008183348211426L;

	@JsonProperty("REQUEST_REFERENCE_NUMBER")
	private String requestRefNumber;

	@JsonProperty("RESPONSE")
	private String response;

	@JsonProperty("DIGI_SIGN")
	private String digiSign;

	private String accessToken;
	private String secretKey;
}
