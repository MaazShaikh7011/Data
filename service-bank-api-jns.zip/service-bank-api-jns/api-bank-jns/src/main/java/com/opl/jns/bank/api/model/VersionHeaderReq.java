package com.opl.jns.bank.api.model;


import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.*;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VersionHeaderReq implements Serializable {

	private static final long serialVersionUID = 1L;
	private Map<String,String> v2;
	private Map<String,String> v3;
}
