package com.opl.jns.bank.api.model;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

import java.io.*;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiMasterRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private Long orgId;
	private VersionUrlReq urlConfig;
	private VersionHeaderReq headerConfig;
	private Boolean isActive;
	private String oplPrivateKey;
	private String publicKey;
	private Boolean isLatest;
	private VersionTimeOutReq timeOutConfig;

}
