package com.opl.jns.bank.api.model;


import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiUrlsRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String baseUrl;
	private String triggerOtp;
	private String verifyOtp;
	private String customerDetails;
	private String premiumDeduction;
	private String physicalVerification;
	private String checkDedupe;
	private String getAccHolderList;
	private String getPolicyDetails;

}
