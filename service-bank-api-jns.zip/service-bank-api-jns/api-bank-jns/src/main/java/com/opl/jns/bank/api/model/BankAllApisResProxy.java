package com.opl.jns.bank.api.model;

import java.io.Serializable;

import com.opl.jns.api.proxy.common.APIResponseV3;

public class BankAllApisResProxy extends APIResponseV3 implements Serializable {

	private static final long serialVersionUID = -2316942665468465L;
	private String triggerOtpRes;
	private String verifyOtpRes;
	private String physicalVerificationRes;
	private String customerDetailsRes;
	private String premiumDeductionRes;

	public String getTriggerOtpRes() {
		return triggerOtpRes;
	}

	public String getVerifyOtpRes() {
		return verifyOtpRes;
	}

	public String getPhysicalVerificationRes() {
		return physicalVerificationRes;
	}

	public String getCustomerDetailsRes() {
		return customerDetailsRes;
	}

	public String getPremiumDeductionRes() {
		return premiumDeductionRes;
	}

	public void setTriggerOtpRes(String triggerOtpRes) {
		this.triggerOtpRes = triggerOtpRes;
	}

	public void setVerifyOtpRes(String verifyOtpRes) {
		this.verifyOtpRes = verifyOtpRes;
	}

	public void setPhysicalVerificationRes(String physicalVerificationRes) {
		this.physicalVerificationRes = physicalVerificationRes;
	}

	public void setCustomerDetailsRes(String customerDetailsRes) {
		this.customerDetailsRes = customerDetailsRes;
	}

	public void setPremiumDeductionRes(String premiumDeductionRes) {
		this.premiumDeductionRes = premiumDeductionRes;
	}

	public BankAllApisResProxy(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

	public BankAllApisResProxy() {
		super();
		// TODO Auto-generated constructor stub
	}

}