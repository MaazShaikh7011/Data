package com.opl.jns.bank.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@Entity
@Table(name = "payload_audit", indexes = {@Index(columnList = "log_audit_id", name = DBNameConstant.JNS_BANK_API
        + "_payload_audit_log_audit_id_idx"),})
public class PayloadAudit {

    private static final long serialVersionUID = -231645826676600012L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payload_audit_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_BANK_API, name = "payload_audit_seq_gen", sequenceName = "payload_audit_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "log_audit_id", nullable = true)
    private Long logAudit;

    @Column(name = "storage_id", nullable = true)
    private String storageId;

    @Column(name = "success", nullable = true)
    private Boolean success;

//	@Column(name = "type_id", nullable = true)
//	private Integer typeId;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    public PayloadAudit() {
        super();
        this.createdDate = new Date();
        this.success = false;
    }
}
