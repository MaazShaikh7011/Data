package com.opl.jns.bank.service.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.jns.bank.api.model.common.AuditReq;
import com.opl.jns.bank.service.domain.AuditLogv3;
import com.opl.jns.bank.service.domain.PayloadAudit;
import com.opl.jns.bank.service.model.PayLoadProxy;
import com.opl.jns.bank.service.repository.ApiAuditRepositoryV3;
import com.opl.jns.bank.service.repository.PayloadAuditRepository;
import com.opl.jns.bank.service.service.AuditDetailServiceV3;
import com.opl.jns.bank.service.utils.Utils;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AuditDetailServiceImpl implements AuditDetailServiceV3 {

	public static final String BANK_API = "BANK_API_";

	@Autowired
	private ApiAuditRepositoryV3 auditRepo;

	@Autowired
	private BucketStorageUtils bucketStorageUtils;

	@Autowired
	private PayloadAuditRepository auditRepository;

	@Async
	@Override
	public void audit(AuditReq auditReq) {
		try {
			Date date = new Date();
//			String generateUUID = BANK_API + OPLUtils.generateUUID();
			AuditLogv3 audits = new AuditLogv3();
			audits.setApplicationId(auditReq.getApplicationId());
			audits.setCreatedDate(auditReq.getCreatedDate());
			audits.setFailureReason(auditReq.getFailureReason());
			audits.setIsActive(true);
			audits.setModifiedDate(date);
			audits.setResponseTime(date.getTime() - auditReq.getCreatedDate().getTime());
			audits.setOrgId(auditReq.getOrgId());
			audits.setReferenceId(auditReq.getReferenceId());
			audits.setResponseCode(auditReq.getResponseCode());
			audits.setApiId(auditReq.getApiId());
			audits.setUrn(auditReq.getUrn());
			audits.setAccountNumber(auditReq.getAccountNumber());
			audits.setRequestRefNumber(auditReq.getRequestRefNumber());
			audits.setRequestToken(auditReq.getReqToken());
			audits = auditRepo.save(audits);
			updateBucketLogs(audits.getId(), auditReq);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE SAVING AUDIT ---------->", e);
		}

	}

	public String getValue() {
		return System.getenv("REGISTRY_REQ_RES_STORE_S3_BUCKET_NAME");
	}

	public void updateBucketLogs(Long auditId, AuditReq auditReq) {
		PayloadAudit reqResAudit = new PayloadAudit();
		reqResAudit.setLogAudit(auditId);
		reqResAudit.setStorageId(auditReq.getReferenceId());
		reqResAudit.setSuccess(false);

		PayLoadProxy loadProxy = new PayLoadProxy();
		loadProxy.setRequestPlain(auditReq.getReqPlain());
		loadProxy.setResponsePlain(auditReq.getResPlain());
		loadProxy.setRequestEncrypt(auditReq.getReqEncrypt());
		loadProxy.setResponseEncrypt(auditReq.getResEncrypt());
		loadProxy.setReferenceId(auditReq.getReferenceId());
		loadProxy.setLogAuditId(auditId);
		loadProxy.setRequestHeader(auditReq.getReqHeader() != null ? auditReq.getReqHeader().toString() : "");
		loadProxy.setRequestUrl(auditReq.getReqUrl());
		loadProxy.setRequestRefNumber(auditReq.getRequestRefNumber());		
		loadProxy.setSecretKey(auditReq.getSecretKey());
		loadProxy.setErrorMsg(auditReq.getErrorMsg());
		
		String upload = bucketStorageUtils.upload(getValue(), loadProxy, auditReq.getReferenceId());
		if (!OPLUtils.isObjectNullOrEmpty(upload)) {
			reqResAudit.setSuccess(true);
		}
		auditRepository.save(reqResAudit);
	}

}
