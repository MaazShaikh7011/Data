package com.opl.jns.bank.service.service;

import com.opl.jns.bank.api.model.common.AuditReq;

public interface AuditDetailServiceV3 {

	public void audit(AuditReq auditReq);

}
