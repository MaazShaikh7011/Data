package com.opl.jns.bank.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequestV3;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationRequestV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponseV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequestV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponseV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpRequestV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponseV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequestV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.bank.service.service.FactoryService;
import com.opl.jns.bank.service.utils.CommonUtils;
import com.opl.jns.bank.service.utils.Utils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.VersionMaster;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v3")
@Slf4j
public class BankApiControllerV3 {

	private static VersionMaster VERSION = VersionMaster.V3;

	@Autowired
	private FactoryService factoryService;

	@GetMapping("/pingService")
	@SkipInterceptor
	public String ping() {
		return " working ";
	}

	private String generateRef() {
		return "BANK_API_" + OPLUtils.generateUUID();
	}

	@PostMapping(value = "/triggerVerificationCode", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TriggerOtpResponseV3> triggerOTP(@Valid @RequestBody TriggerOtpRequestV3 triggerOtpRequest,
			HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START TRIGGER OTP ----------------> " + generateRef);
		try {
			
			if (OPLUtils.isObjectNullOrEmpty(triggerOtpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new TriggerOtpResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			triggerOtpRequest.setToken(Utils.generateToken(triggerOtpRequest.getOrgId()));
			TriggerOtpResponseV3 triggerOtpResponse = factoryService.triggerOtp(triggerOtpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, triggerOtpRequest.getUrn(),
					triggerOtpRequest.getAccountNumber());

			log.info("END TRIGGER OTP ----------------> " + generateRef);
			triggerOtpResponse.setToken(generateRef);
			return new ResponseEntity<>(triggerOtpResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE TRIGGER OTP ---" + generateRef + "---", e);
			return new ResponseEntity<>(
					new TriggerOtpResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping(value = "/verifyVerificationCode", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<VerifyOtpApiResponseV3> verifyOtp(@Valid @RequestBody OTPRequestV3 otpRequest,
			HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START VERIFY OTP ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new VerifyOtpApiResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}

			otpRequest.setToken(Utils.generateToken(otpRequest.getOrgId()));
			VerifyOtpApiResponseV3 verifyOtpApiResponse = factoryService.varifyOtp(otpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, otpRequest.getUrn(),
					otpRequest.getAccountNumber());
			log.info("END VERIFY OTP ----------------> " + generateRef);
			verifyOtpApiResponse.setToken(generateRef);
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE VERIFY OTP ---" + generateRef + "---", e);
			return new ResponseEntity<>(new VerifyOtpApiResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getCustomerDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerDetailsDataV3> getCustomerDetails(
			@Valid @RequestBody CustomerDetailsRequest custDtlsReq, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START GET CUSTOMER DETAILS ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(custDtlsReq.getOrgId())) {
				return new ResponseEntity<>(
						new CustomerDetailsDataV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			custDtlsReq.setToken(Utils.generateToken(custDtlsReq.getOrgId()));
			CustomerDetailsDataV3 customerDetailsResponse = factoryService.getCustomerDetailsV3(custDtlsReq,
					authClientResponse.getUserId(), generateRef, VERSION, custDtlsReq.getUrn(),
					custDtlsReq.getAccountNumber());
			log.info("END GET CUSTOMER DETAILS ----------------> " + generateRef);
			customerDetailsResponse.setToken(generateRef);
			return new ResponseEntity<>(customerDetailsResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET CUSTOMER DETAILS --- " + generateRef + "---", e);
			return new ResponseEntity<>(
					new CustomerDetailsDataV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}

	}

	@PostMapping(value = "/premiumDeduction", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PremiumDeductionResponseV3> getPremiumDeduction(
			@Valid @RequestBody PremiumDeductionRequestV3 premDeducReq, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START PREMIUM DEDUCTION REQUEST ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(premDeducReq.getOrgId())) {
				return new ResponseEntity<>(
						new PremiumDeductionResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			premDeducReq.setToken(Utils.generateToken(premDeducReq.getOrgId()));
			PremiumDeductionResponseV3 premiumDeductionResponse = factoryService.getPremiumDeduction(premDeducReq,
					authClientResponse.getUserId(), generateRef, VERSION, premDeducReq.getUrn(),
					premDeducReq.getCustomerAccountNumber());
			log.info("END PREMIUM DEDUCTION REQUEST ----------------> " + generateRef);
			premiumDeductionResponse.setToken(generateRef);
			return new ResponseEntity<>(premiumDeductionResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PREMIUM DEDUCTION REQUEST ---" + generateRef + "---", e);
			return new ResponseEntity<>(new PremiumDeductionResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/physicalSignatureVerification", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PhysicalVerificationResponseV3> getPhysicalVerification(
			@Valid @RequestBody PhysicalVerificationRequestV3 otpRequest, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START VERIFY PHYSICAL SIGNATURE ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new PhysicalVerificationResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}

			otpRequest.setToken(Utils.generateToken(otpRequest.getOrgId()));
			PhysicalVerificationResponseV3 verifyOtpApiResponse = factoryService.getPhysicalVerification(otpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, otpRequest.getUrn(),
					otpRequest.getAccountNumber());
			log.info("END VERIFY PHYSICAL SIGNATURE----------------> " + generateRef);
			verifyOtpApiResponse.setToken(generateRef);
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE VERIFY PHYSICAL SIGNATURE REQUEST  ---" + generateRef + "---", e);
			return new ResponseEntity<>(new PhysicalVerificationResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getAccHolderList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AccHolderListResponseV3> getAccHolderList(
			@Valid @RequestBody AccHolderListRequestV3 accHolderListRequest, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START GET ACCOUNT HOLDER LIST ----------------> " + generateRef);
//		BankAPICommonResV3 getTokenAndTimeStemp = CommonUtils.setTokenAndTimeStemp(new BankAPICommonResV3(), httpServletRequest);
		try {
			if (OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getOrgId())) {
				return new ResponseEntity<>(
						new AccHolderListResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}
			if (!OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getAccountNumber())
					&& OPLUtils.isObjectNullOrEmpty(accHolderListRequest.getDob())) {
				return new ResponseEntity<>(
						new AccHolderListResponseV3(HttpStatus.BAD_REQUEST.value(), "dob can not be null", false),
						HttpStatus.OK);
			}

			accHolderListRequest.setToken(Utils.generateToken(accHolderListRequest.getOrgId()));
			AccHolderListResponseV3 getAccHolderLstRes = factoryService.getAccHolderList(accHolderListRequest,
					authClientResponse.getUserId(), generateRef, VERSION, accHolderListRequest.getUrn(),
					accHolderListRequest.getAccountNumber());
			log.info("END GET ACCOUNT HOLDER LIST ----------------> " + generateRef);
			getAccHolderLstRes.setToken(generateRef);
			return new ResponseEntity<>(getAccHolderLstRes, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET ACCOUNT HOLDER LIST REQUEST  ---" + generateRef + "---", e);
			return new ResponseEntity<>(new AccHolderListResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getPolicyDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PolicyDetailsResponseV3> getPolicyDetails(
			@Valid @RequestBody PolicyDetailsRequestV3 policyDtlsReq, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START GET POLICY DETAILS ----------------> " + generateRef);
//		BankAPICommonResV3 getTokenAndTimeStemp = CommonUtils.setTokenAndTimeStemp(new BankAPICommonResV3(), httpServletRequest);
		try {
			if (OPLUtils.isObjectNullOrEmpty(policyDtlsReq.getOrgId())) {
				return new ResponseEntity<>(
						new PolicyDetailsResponseV3(HttpStatus.BAD_REQUEST.value(), CommonUtils.ORG_MSG, false),
						HttpStatus.OK);
			}

			policyDtlsReq.setToken(Utils.generateToken(policyDtlsReq.getOrgId()));
			PolicyDetailsResponseV3 policyDetailsResponse = factoryService.getPolicyDetails(policyDtlsReq,
					authClientResponse.getUserId(), generateRef, VERSION, policyDtlsReq.getUrn(),
					policyDtlsReq.getAccountNumber());
			log.info("END GET POLICY DETAILS ----------------> " + generateRef);
			policyDetailsResponse.setToken(generateRef);
			return new ResponseEntity<>(policyDetailsResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET POLICY DETAILS REQUEST  ---" + generateRef + "---", e);
			return new ResponseEntity<>(new PolicyDetailsResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

}
