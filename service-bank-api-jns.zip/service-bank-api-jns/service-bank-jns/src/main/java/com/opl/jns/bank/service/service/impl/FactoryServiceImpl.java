package com.opl.jns.bank.service.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.service.service.FactoryService;
import com.opl.jns.bank.service.service.ManageRequestBankWise;
import com.opl.jns.utils.enums.VersionMaster;

@Service
@Transactional
public class FactoryServiceImpl implements FactoryService {

	public static final int INDIAN_BANK = 13;
	public static final int CENTRAL_BANK = 25;
	public static final int UNION_BANK = 1;
	public static final int BANK_OF_BARODA = 17;
	public static final int ICICI_BANK = 4;
	public static final int BANK_OF_INDIA = 14;
	public static final int BANK_OF_MAHARASHTRA = 27;
	public static final int CANARA_BANK = 12;
	public static final int INDIAN_OVERSEAS_BANK = 28;
	public static final int PUNJAB_SIND_BANK = 20;
	public static final int PUNJAB_NATIONAL_BANK = 18;
	public static final int UCO_BANK = 19;
	public static final int HDFC_BANK_LTD = 32;
	public static final int SBI_BANK = 16;
	public static final int PUNJAB_NATIONAL_BANK1 = 501;

	@Autowired
	private IndianBankApiServiceImpl IndianBankApiServiceImpl;

	@Autowired
	private IciciBankApiServiceImpl iciciBankApiServiceImpl;

	@Autowired
	private CommonBankAPIServiceImpl commonBankAPIServiceImpl;

	@Autowired
	private HdfcBankApiServiceImpl hdfcBankApiServiceImpl;

	@Autowired
	private SbiBankApiServiceImpl sbiBankApiServiceImpl;

	@Override
	public <T extends MainResponse, U extends CommonRequest> T varifyOtp(U otpRequest, Long userId, String referenceId,
			VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(otpRequest.getOrgId()).verifyOtpRequest(otpRequest, userId, referenceId, null, version, urn,
				accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T triggerOtp(U triggerOtpRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(triggerOtpRequest.getOrgId()).triggerOtpRequest(triggerOtpRequest, userId, referenceId, null,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getCustomerDetails(U custDetailsReq, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(custDetailsReq.getOrgId()).customerDetailsRequest(custDetailsReq, userId, referenceId, null,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getCustomerDetailsV3(U custDetailsReq, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(custDetailsReq.getOrgId()).customerDetailsRequestV3(custDetailsReq, userId, referenceId,
				null, version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPremiumDeduction(U premDeductionReq, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(premDeductionReq.getOrgId()).premiumDeductionRequest(premDeductionReq, userId, referenceId,
				null, version, urn, accNo);

	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U otpRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(otpRequest.getOrgId()).getPhysicalVerification(otpRequest, userId, referenceId, null,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(holderListRequest.getOrgId()).getAccHolderList(holderListRequest, userId, referenceId, null,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException {
		return getInstance(policyDetailsRequest.getOrgId()).getPolicyDetails(policyDetailsRequest, userId, referenceId,
				null, version, urn, accNo);
	}

	public ManageRequestBankWise getInstance(Long orgId) throws CommonException {
		ManageRequestBankWise instance = null;
		switch (orgId.intValue()) {
		case INDIAN_BANK:
			instance = IndianBankApiServiceImpl;
			break;
		case ICICI_BANK:
			instance = iciciBankApiServiceImpl;
			break;
		case HDFC_BANK_LTD:
			instance = hdfcBankApiServiceImpl;
			break;
		case SBI_BANK:
			instance = sbiBankApiServiceImpl;
			break;
		case CENTRAL_BANK:
		case UNION_BANK:
		case BANK_OF_BARODA:
		case BANK_OF_MAHARASHTRA:
		case CANARA_BANK:
		case INDIAN_OVERSEAS_BANK:
		case PUNJAB_SIND_BANK:
		case PUNJAB_NATIONAL_BANK:
		case UCO_BANK:
		case BANK_OF_INDIA:
		case PUNJAB_NATIONAL_BANK1:
			instance = commonBankAPIServiceImpl;
			break;
		default:
			throw new CommonException("ORG IS NULL OR BANK IMPLEMENTATION NOT FOUND ");
		}
		return instance;

	}

}
