package com.opl.jns.bank.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.bank.service.domain.AuditLogv3;

public interface ApiAuditRepositoryV3 extends JpaRepository<AuditLogv3,Long> {
	AuditLogv3 findFirstByIdOrderByIdDesc(Long id);
	
	AuditLogv3 findFirstByApiIdAndUrnOrderByIdDesc(Integer apiId, String urn);
		
	@Query("select new com.opl.jns.bank.service.domain.AuditLogv3(max(ad.apiId),max(ad.referenceId)) from AuditLogv3 ad WHERE urn =:urn and isActive = true group by ad.apiId")
	List<AuditLogv3> findByUrn(@Param("urn") String urn);
}
