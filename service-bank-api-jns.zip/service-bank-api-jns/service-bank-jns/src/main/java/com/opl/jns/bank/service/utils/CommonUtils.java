package com.opl.jns.bank.service.utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.api.model.ApiMasterRequest;
import com.opl.jns.bank.api.model.ApiResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 3/11/2023
 */
@Slf4j
public class CommonUtils {
	public static final List<ApiMasterRequest> apiMastersList = new ArrayList<>();

	public static final RestTemplate restTemplate = new RestTemplate();
	public static final ApiMasterRequest emptyObject = new ApiMasterRequest();
	public static final int INT_0 = 0;
	public static final int INT_1 = 1;
	public static final int INT_2 = 2;
	public static final Integer INT_500 = 500;
	public static final Integer INT_1000 = 1000;
	public static final Integer INT_200 = 200;
	public static final int OTP_API_ID = 1;
	public static final int VERIFY_API_ID = 2;
	public static final int CUSTOMER_DETAIL_API_ID = 3;
	public static final int PREMIUM_DEDUCT_API_ID = 4;
	public static final int PHYSICAL_VERIFICATION_API_ID = 5;
	public static final int CHECK_DEDUPE_API_ID = 6;
	public static final int GET_ACCOUNT_HOLDER_LIST_ID = 7;
	public static final int GET_POLICY_DETAILS_ID = 8;
	public static final int OPT_OUT_UPDATE_STATUS_ID = 9;
	public static final int NOMINEE_UPDATE_STATUS_ID = 10;
	public static final int PUSH_CLAIM_STATUS_TO_BANK_ID = 11;
	public static final String X_API_INTERACTION_ID = "X-API-Interaction-ID";
	public static final String TRANS_UNIQUE_ID = "transUniqueID";
	public static final String V_SUSERID = "v_sUserId";
	public static final String V_SPASSWORD = "v_sPassword";
	public static final String RESPONSE = "response";
	public static final String AUDIT_ID = "AuditId";
	public static final String SAVE_DETAILS_TESTING_MODE = "SAVE_DETAILS_TESTING_MODE";
	public static final String BANK_URL_NOT_FOUND = "Bank Url not found";
	public static final String TOKEN_MSG = "token is null or empty";
	public static final String ORG_MSG = "ORG ID is null or empty";
	public static final String PHASE_2_MSG = "Kindly use phase 2 api your phase 2 api enabled";
	public static final String STATUS = "status";
	public static final String MESSAGE = "message";
	public static final DateFormat sdf_dd_MM_yyyy = new SimpleDateFormat("dd/MM/yyyy");
	public static final DateFormat YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");
	public static final DateFormat sdf_ddMMyyyy = new SimpleDateFormat("ddMMyyyy");
	public static final String METADATA = "metadata";
	public static final String UNABLE_TO_PROCEED_DUE_TO_ERROR_FROM_BANK = "Unable to proceed due to error from bank";
	public static final String NO_RESPONSE_FROM_BANK = "No Response data from Bank";
	public static final String PLAIN_RESP = "plainResp";
	public static final String INVALID_DOB = "Invalid dob";
	public final static String REQ_ATR_TOKEN = "REQ_ATR_TOKEN";

	public static <T> T getObjectFromString(String data, Class<?> clazz) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		return (T) mapper.readValue(data, clazz);
	}

	public static String printLogs(Long orgId, int apiId, String refNum) {
		return "---REFID---" + refNum + "---ORG_ID---" + orgId + "---API_ID---" + apiId + "----";
	}

	public static ApiMasterRequest getApiUserByOrgId(Long orgId) {
		return apiMastersList.stream().filter(x -> x.getOrgId().equals(orgId)).findFirst()
				.orElse(CommonUtils.emptyObject);
	}

	public static ApiMasterRequest getApiUserByOrgIdForBankApi(Long orgId) {
		return apiMastersList.stream().filter(x -> x.getOrgId().equals(orgId) && x.getUrlConfig() != null).findFirst()
				.orElse(CommonUtils.emptyObject);
	}

	public static String replaceString(String plaintext) {
		plaintext = StringEscapeUtils.unescapeJava(plaintext);
		return plaintext;
	}

	public static <T> T checkStringAndCast(String value, Class<T> type, Long orgId) throws ParseException {
		if (!OPLUtils.isObjectNullOrEmpty(value) && !value.equalsIgnoreCase("na") && !value.equals("-")
				&& !value.equals("|") && !value.equals("0")) {
			if (type.equals(Boolean.class)) {
				return (T) Boolean.valueOf(value);
			} else if (type.equals(Integer.class)) {
				return (T) Integer.valueOf(value);
			} else if (type.equals(Double.class)) {
				return (T) Double.valueOf(value);
			} else if (type.equals(Long.class)) {
				return (T) Long.valueOf(value);
			} else if (type.equals(Date.class)) {
				return (T) sdf_dd_MM_yyyy.parse(value);
			} else if (type.equals(LocalDate.class)) {
				if (PhaseMode.checkPhase2(orgId)) {
					return (T) LocalDate.parse(value);
				} else {
					String reformattedStr = YYYY_MM_DD.format(sdf_dd_MM_yyyy.parse(value));
					return (T) LocalDate.parse(reformattedStr);
				}
			}
		}
		return null;
	}

	public static <T> T convertMapToResponseObject(Map<String, Object> response, Long orgId, Class<?> classType,
			Long userId) throws IOException, CommonException {
		if (response.containsKey(CommonUtils.RESPONSE) && response.containsKey(CommonUtils.STATUS)) {
			int status = null != response.get(CommonUtils.STATUS)
					? Integer.valueOf(response.get(CommonUtils.STATUS).toString())
					: HttpStatus.INTERNAL_SERVER_ERROR.value();
			if (status == HttpStatus.INTERNAL_SERVER_ERROR.value() || status == HttpStatus.GATEWAY_TIMEOUT.value()) {
				return null;
			} else {
				ApiResponse apiResp = MultipleJSONObjectHelper
						.getObjectFromString(response.get(CommonUtils.RESPONSE).toString(), ApiResponse.class);
				if (!OPLUtils.isObjectNullOrEmpty(apiResp.getMetadata())) {
					String plainResponse = Utils.decryptResponseFromEncryptedResponse(apiResp.getMetadata(), orgId,
							userId);
					response.put(PLAIN_RESP, plainResponse);
					return MultipleJSONObjectHelper.getObjectFromString(plainResponse, classType);
				}
			}
		}
		return null;
	}

	public static <T extends MainResponse> T reponse(T classType, Integer status, String message) {
		classType.setStatus(status);
		classType.setMessage(message);
		return classType;
	}

	public static CustomerDetailsDataV3 setAccountHolderDtl(AccountHolderDetailsV3 accDtl,
			AccountHolderDetailsResponseV3 res, CustomerDetailsDataV3 detailResp, Long orgId) throws ParseException {
		res.setNomineePincode(CommonUtils.checkStringAndCast(accDtl.getNomineePincode(), Integer.class, orgId));
		res.setNomineeCityLGDCode(CommonUtils.checkStringAndCast(accDtl.getNomineeCityLGDCode(), Long.class, orgId));
		res.setNomineeDistrictLGDCode(
				CommonUtils.checkStringAndCast(accDtl.getNomineeDistrictLGDCode(), Long.class, orgId));
		res.setNomineeStateLGDCode(CommonUtils.checkStringAndCast(accDtl.getNomineeStateLGDCode(), Long.class, orgId));
		res.setCityLGDCode(CommonUtils.checkStringAndCast(accDtl.getCityLGDCode(), Long.class, orgId));
		res.setDistrictLGDCode(CommonUtils.checkStringAndCast(accDtl.getDistrictLGDCode(), Long.class, orgId));
		res.setStateLGDCode(CommonUtils.checkStringAndCast(accDtl.getStateLGDCode(), Long.class, orgId));
		res.setPincode(CommonUtils.checkStringAndCast(accDtl.getPincode(), Long.class, orgId));
		try {
			res.setDob(CommonUtils.checkStringAndCast(accDtl.getDob(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Applicant's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Applicant's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		try {
			res.setNomineeDateOfBirth(
					CommonUtils.checkStringAndCast(accDtl.getNomineeDateOfBirth(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Nominee's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Nominee's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		detailResp.setAccountHolderDetails(res);
		return detailResp;
	}

	public static CustomerDetailsDataV3 setAccountHolderDtlV3(AccountHolderDetailsV3 accDtl,
			AccountHolderDetailsResponseV3 res, CustomerDetailsDataV3 detailResp, Long orgId) throws ParseException {
		res.setPincode(CommonUtils.checkStringAndCast(accDtl.getPincode(), Long.class, orgId));
		try {
			res.setDob(CommonUtils.checkStringAndCast(accDtl.getDob(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Applicant's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Applicant's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		try {
			res.setNomineeDateOfBirth(
					CommonUtils.checkStringAndCast(accDtl.getNomineeDateOfBirth(), LocalDate.class, orgId));
		} catch (Exception e) {
			log.error("Nominee's date of birth format is invalid : {} ", e);
			detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			detailResp.setMessage("Nominee's date of birth format is invalid");
			detailResp.setFlag(Boolean.FALSE);
		}
		detailResp.setAccountHolderDetails(res);
		return detailResp;
	}

	public static Integer getReadTimeOut(ApiMasterRequest req, Integer apiId, Long orgId) {
		if (!OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig())) {
			if (PhaseMode.checkPhase2(orgId)) {
				if (apiId == CommonUtils.OTP_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getTriggerOtp())) {
					return req.getTimeOutConfig().getV3().getTriggerOtp().getReadTimeOut();
				} else if (apiId == CommonUtils.VERIFY_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getVerifyOtp())) {
					return req.getTimeOutConfig().getV3().getVerifyOtp().getReadTimeOut();
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getCustomerDetails())) {
					return req.getTimeOutConfig().getV3().getCustomerDetails().getReadTimeOut();
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getPremiumDeduction())) {
					return req.getTimeOutConfig().getV3().getPremiumDeduction().getReadTimeOut();
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getPhysicalVerification())) {
					return req.getTimeOutConfig().getV3().getPhysicalVerification().getReadTimeOut();
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getCheckDedupe())) {
					return req.getTimeOutConfig().getV3().getCheckDedupe().getReadTimeOut();
				} else if (apiId == CommonUtils.GET_ACCOUNT_HOLDER_LIST_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getGetAccHolderList())) {
					return req.getTimeOutConfig().getV3().getGetAccHolderList().getReadTimeOut();
				} else if (apiId == CommonUtils.GET_POLICY_DETAILS_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getGetPolicyDetails())) {
					return req.getTimeOutConfig().getV3().getGetPolicyDetails().getReadTimeOut();
				}
			} else {
				if (apiId == CommonUtils.OTP_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getTriggerOtp())) {
					return req.getTimeOutConfig().getV2().getTriggerOtp().getReadTimeOut();
				} else if (apiId == CommonUtils.VERIFY_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getVerifyOtp())) {
					return req.getTimeOutConfig().getV2().getVerifyOtp().getReadTimeOut();
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getCustomerDetails())) {
					return req.getTimeOutConfig().getV2().getCustomerDetails().getReadTimeOut();
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getPremiumDeduction())) {
					return req.getTimeOutConfig().getV2().getPremiumDeduction().getReadTimeOut();
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getPhysicalVerification())) {
					return req.getTimeOutConfig().getV2().getPhysicalVerification().getReadTimeOut();
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getCheckDedupe())) {
					return req.getTimeOutConfig().getV2().getCheckDedupe().getReadTimeOut();
				}
			}
		}
		return null;
	}

	public static Integer getConnectionTimeOut(ApiMasterRequest req, Integer apiId, Long orgId) {
		if (!OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig())) {
			if (PhaseMode.checkPhase2(orgId)) {
				if (apiId == CommonUtils.OTP_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getTriggerOtp())) {
					return req.getTimeOutConfig().getV3().getTriggerOtp().getConTimeOut();
				} else if (apiId == CommonUtils.VERIFY_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getVerifyOtp())) {
					return req.getTimeOutConfig().getV3().getVerifyOtp().getConTimeOut();
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getCustomerDetails())) {
					return req.getTimeOutConfig().getV3().getCustomerDetails().getConTimeOut();
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getPremiumDeduction())) {
					return req.getTimeOutConfig().getV3().getPremiumDeduction().getConTimeOut();
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getPhysicalVerification())) {
					return req.getTimeOutConfig().getV3().getPhysicalVerification().getConTimeOut();
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getCheckDedupe())) {
					return req.getTimeOutConfig().getV3().getCheckDedupe().getConTimeOut();
				} else if (apiId == CommonUtils.GET_ACCOUNT_HOLDER_LIST_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getGetAccHolderList())) {
					return req.getTimeOutConfig().getV3().getGetAccHolderList().getConTimeOut();
				} else if (apiId == CommonUtils.GET_POLICY_DETAILS_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV3().getGetPolicyDetails())) {
					return req.getTimeOutConfig().getV3().getGetPolicyDetails().getConTimeOut();
				}
			} else {

				if (apiId == CommonUtils.OTP_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getTriggerOtp())) {
					return req.getTimeOutConfig().getV2().getTriggerOtp().getConTimeOut();
				} else if (apiId == CommonUtils.VERIFY_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getVerifyOtp())) {
					return req.getTimeOutConfig().getV2().getVerifyOtp().getConTimeOut();
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getCustomerDetails())) {
					return req.getTimeOutConfig().getV2().getCustomerDetails().getConTimeOut();
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getPremiumDeduction())) {
					return req.getTimeOutConfig().getV2().getPremiumDeduction().getConTimeOut();
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getPhysicalVerification())) {
					return req.getTimeOutConfig().getV2().getPhysicalVerification().getConTimeOut();
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID
						&& !OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig().getV2().getCheckDedupe())) {
					return req.getTimeOutConfig().getV2().getCheckDedupe().getConTimeOut();
				}

			}

		}
		return null;
	}

	public static String getUrl(ApiMasterRequest req, Integer apiId, Long orgId) {
		if (!OPLUtils.isObjectNullOrEmpty(req.getTimeOutConfig())) {
			if (PhaseMode.checkPhase2(orgId)) {
				if (apiId == CommonUtils.OTP_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl().concat(req.getUrlConfig().getV3().getTriggerOtp());
				} else if (apiId == CommonUtils.VERIFY_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl().concat(req.getUrlConfig().getV3().getVerifyOtp());
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl()
							.concat(req.getUrlConfig().getV3().getCustomerDetails());
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl()
							.concat(req.getUrlConfig().getV3().getPremiumDeduction());
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl()
							.concat(req.getUrlConfig().getV3().getPhysicalVerification());
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID) {
					return req.getUrlConfig().getV3().getBaseUrl().concat(req.getUrlConfig().getV3().getCheckDedupe());
				} else if (apiId == CommonUtils.GET_ACCOUNT_HOLDER_LIST_ID) {
					return req.getUrlConfig().getV3().getBaseUrl()
							.concat(req.getUrlConfig().getV3().getGetAccHolderList());
				} else if (apiId == CommonUtils.GET_POLICY_DETAILS_ID) {
					return req.getUrlConfig().getV3().getBaseUrl()
							.concat(req.getUrlConfig().getV3().getGetPolicyDetails());
				}
			} else {
				if (apiId == CommonUtils.OTP_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl().concat(req.getUrlConfig().getV2().getTriggerOtp());
				} else if (apiId == CommonUtils.VERIFY_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl().concat(req.getUrlConfig().getV2().getVerifyOtp());
				} else if (apiId == CommonUtils.CUSTOMER_DETAIL_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl()
							.concat(req.getUrlConfig().getV2().getCustomerDetails());
				} else if (apiId == CommonUtils.PREMIUM_DEDUCT_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl()
							.concat(req.getUrlConfig().getV2().getPremiumDeduction());
				} else if (apiId == CommonUtils.PHYSICAL_VERIFICATION_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl()
							.concat(req.getUrlConfig().getV2().getPhysicalVerification());
				} else if (apiId == CommonUtils.CHECK_DEDUPE_API_ID) {
					return req.getUrlConfig().getV2().getBaseUrl().concat(req.getUrlConfig().getV2().getCheckDedupe());
				}

			}
		}
		return null;
	}

	private CommonUtils() {
		super();
	}

//	public static APIResponse setTokenAndTimeStemp(APIResponse commonResponse, HttpServletRequest request) {
//		HttpServletRequest servletWebRequest = request;
//		if (null != servletWebRequest.getAttribute(REQ_ATR_TOKEN)) {
//			commonResponse.setToken(servletWebRequest.getAttribute(REQ_ATR_TOKEN).toString());
//		}
//		commonResponse.setTimeStamp(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
//		return commonResponse;
//	}

}
