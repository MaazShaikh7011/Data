package com.opl.jns.bank.service.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.service.service.HttpUtility;
import com.opl.jns.bank.service.utils.APIAbsractLayer;
import com.opl.jns.utils.enums.VersionMaster;

@Service
@Transactional
public class CommonBankAPIServiceImpl extends APIAbsractLayer {

	@Autowired
	private HttpUtility httpUtility;

	@Override
	public <T extends MainResponse, U extends CommonRequest> T triggerOtpRequest(U triggerOtpReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.triggerOtpRequest(httpUtility, triggerOtpReq, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T verifyOtpRequest(U otpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.verifyOtpRequest(httpUtility, otpRequest, userId, referenceId, null, requestFactory, version, urn,
				accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequest(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.customerDetailsRequest(httpUtility, custDetailsReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequestV3(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.customerDetailsRequestV3(httpUtility, custDetailsReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T premiumDeductionRequest(U premDeducReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.premiumDeductionRequest(httpUtility, premDeducReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U phyVrfReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getPhysicalVerification(httpUtility, phyVrfReq, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getAccHolderList(httpUtility, holderListRequest, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getPolicyDetails(httpUtility, policyDetailsRequest, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

}
