package com.opl.jns.bank.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.opl.jns.bank.service.domain.PayloadAudit;


@Repository
public interface PayloadAuditRepository extends JpaRepository<PayloadAudit, Long> {

}
