package com.opl.jns.bank.service.controller;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.bank.service.service.ConfigServiceV3;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 3/6/2023
 */
@RestController
@Slf4j
public class ConfigController {


    @Autowired
    private ConfigServiceV3 configService;

    @GetMapping(value="/v1/getProperties", produces=MediaType.APPLICATION_JSON_VALUE)
    @SkipInterceptor
    public ResponseEntity<CommonResponse> getProperties(HttpServletRequest httpServletRequest) {
        try {
            CommonResponse res= new CommonResponse();
            res.setData(configService.getApiMasters());
            res.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getApplicationList() ", e);
            return null;
        }

    }
    @GetMapping(value="/v1/setProperties", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
    @SkipInterceptor
    public ResponseEntity<CommonResponse> setProperties(HttpServletRequest httpServletRequest) {
        try {
            CommonResponse res= new CommonResponse();
            configService.setApiMasters();
            res.setStatus(HttpStatus.OK.value());
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getApplicationList() ", e);
            return null;
        }

    }
			
}
