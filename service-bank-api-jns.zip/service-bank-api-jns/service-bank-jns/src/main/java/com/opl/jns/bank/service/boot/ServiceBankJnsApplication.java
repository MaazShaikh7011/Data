package com.opl.jns.bank.service.boot;

import java.net.Socket;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.bank.service.service.ConfigServiceV3;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@SpringBootApplication
@ComponentScan(basePackages = { "com.opl" })
@EnableConfigurationProperties(ApplicationProperties.class)
public class ServiceBankJnsApplication {

	private static final Logger log = LoggerFactory.getLogger(ServiceBankJnsApplication.class);

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private ConfigServiceV3 configService;

	@Autowired
	private ConfigProperties properties;

	@Bean
	CommandLineRunner run() {
		return args -> {
			configService.setApiMasters();
			properties.setAllValue();
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(ServiceBankJnsApplication.class, args);
		ignoreCertificates();
        trustAllHosts();
	}

	@Bean
	public AuthClient authClient() {
		AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
		return authClient;
	}

//	@Bean
//	public AnsLogsClient clientLogs() {
//		AnsLogsClient ansLogsClient = new AnsLogsClient(URLConfig.fetchURL(URLMaster.LOGS));
//		applicationContext.getAutowireCapableBeanFactory().autowireBean(ansLogsClient);
//		return ansLogsClient;
//	}

	private static void ignoreCertificates() {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}

			@Override
			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };
		try {
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			log.error("Exception is ignoreCertificates ", e);
		}
	}
	public  static void trustAllHosts()
    {
        try
        {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager()
                    {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers()
                        {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
                        {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
                        {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException
                        {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException
                        {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException
                        {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException
                        {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new  HostnameVerifier()
            {
                @Override
                public boolean verify(String hostname, SSLSession session)
                {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        }
        catch (Exception e)
        {
            log.error("Error occurred",e);
        }
    }
}
