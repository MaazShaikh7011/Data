package com.opl.jns.bank.service.service;

import java.io.IOException;

import org.springframework.http.client.ClientHttpRequestFactory;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.utils.enums.VersionMaster;

public interface ManageRequestBankWise {

	public <T extends MainResponse, U extends CommonRequest> T triggerOtpRequest(U triggerOtpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T verifyOtpRequest(U otpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequest(U customerDetailsRequest,
			Long userId, String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequestV3(U customerDetailsRequest,
			Long userId, String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T premiumDeductionRequest(U premiumDeductionRequest,
			Long userId, String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U otpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException;

}
