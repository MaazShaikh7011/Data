package com.opl.jns.bank.service.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.opl.bucket.storage.utils.BucketStorageUtils;
import com.opl.bucket.storage.utils.OPLBkUtils;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.bank.api.model.BankAllApisResProxy;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.bank.service.domain.AuditLogv3;
import com.opl.jns.bank.service.model.PayLoadProxy;
import com.opl.jns.bank.service.repository.ApiAuditRepositoryV3;
import com.opl.jns.bank.service.service.BankApiAuditDetailsService;
import com.opl.jns.bank.service.utils.CommonUtils;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

@Service
public class BankApiAuditDetailsServiceImpl implements BankApiAuditDetailsService {

	@Autowired
	private ApiAuditRepositoryV3 apiAuditRepositoryV3;
	
	@Autowired
	private BucketStorageUtils bucketStorageUtils;
	
	@Override
	public VerifyOtpApiResponseV3 fetchVerifyOtpResponse(AccountHolderSelectionDetailsRequest accountHolderSelRequest)
			throws IOException {
		AuditLogv3 auditLogv3 = apiAuditRepositoryV3.findFirstByApiIdAndUrnOrderByIdDesc(CommonUtils.VERIFY_API_ID,
				accountHolderSelRequest.getUrn());
		if (!OPLUtils.isObjectNullOrEmpty(auditLogv3)) {			
			String bucketName = System.getenv(OPLBkUtils.ENROLLMENT_BUCKET_NAME);
			PayLoadProxy deserializeUploadedFile = (PayLoadProxy) bucketStorageUtils.getFileObject(bucketName,auditLogv3.getReferenceId());			
			if (!OPLUtils.isObjectNullOrEmpty(deserializeUploadedFile)) {
				return MultipleJSONObjectHelper.getObjectFromString(deserializeUploadedFile.getResponsePlain(),VerifyOtpApiResponseV3.class);
			}
			/** call bucket client and get verify otp response */
			//return getBankApiReqRes(auditLogv3.getReferenceId());
		}
		return null;
	}

	public VerifyOtpApiResponseV3 getBankApiReqRes(String referenceId) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("req_auth", "true");
		headers.add("Accept", "application/json");
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Map<String, Object>> entity = new HttpEntity<>(headers);
		String url = URLConfig.fetchURL(URLMaster.BANK_API) + "/opl/bucket/deseriablize/" + referenceId;
		System.err.println(url);
		Map<String, Object> body = new RestTemplate().exchange(url, HttpMethod.GET, entity, Map.class).getBody();
		VerifyOtpApiResponseV3 verifyOtpApiResponse = null;
		if (!OPLUtils.isObjectNullOrEmpty(body)) {
				verifyOtpApiResponse = MultipleJSONObjectHelper.getObjectFromString(body.get("responsePlain").toString(), VerifyOtpApiResponseV3.class);
			}
		return verifyOtpApiResponse;
}

	@Override
	public BankAllApisResProxy fetchAllApisRes(String urn) throws IOException {
		List<AuditLogv3> auditLogv3 = apiAuditRepositoryV3.findByUrn(urn);
		if (!OPLUtils.isListNullOrEmpty(auditLogv3)) {
			if (!OPLUtils.isListNullOrEmpty(auditLogv3)) {
				BankAllApisResProxy bankAllApisResProxy = new BankAllApisResProxy();
				auditLogv3.forEach(x -> {
					if (!OPLUtils.isObjectNullOrEmpty(x.getApiId())) {
						if (x.getApiId() == CommonUtils.OTP_API_ID) {
							bankAllApisResProxy.setTriggerOtpRes(x.getReferenceId());
						}
						if (x.getApiId() == CommonUtils.VERIFY_API_ID) {
							bankAllApisResProxy.setVerifyOtpRes(x.getReferenceId());
						}
						if (x.getApiId() == CommonUtils.PHYSICAL_VERIFICATION_API_ID) {
							bankAllApisResProxy.setPhysicalVerificationRes(x.getReferenceId());
						}
						if (x.getApiId() == CommonUtils.CUSTOMER_DETAIL_API_ID) {
							bankAllApisResProxy.setCustomerDetailsRes(x.getReferenceId());
						}
						if (x.getApiId() == CommonUtils.PREMIUM_DEDUCT_API_ID) {
							bankAllApisResProxy.setPremiumDeductionRes(x.getReferenceId());
						}
					}
				});
				return bankAllApisResProxy;
			}
		}
		return null;
	}
	
}
