package com.opl.jns.bank.service.model;

import java.io.Serializable;

public class PayLoadProxy implements Serializable {

	private static final long serialVersionUID = -2316946665465465L;
	private String requestPlain;
	private String responsePlain;
	private String requestEncrypt;
	private String responseEncrypt;
	private Long logAuditId;
	private String referenceId;
	private String requestHeader;
	private String requestUrl;
	
	private String requestRefNumber;	
	private String secretKey;
	private String errorMsg;

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public Long getLogAuditId() {
		return logAuditId;
	}

	public void setLogAuditId(Long logAuditId) {
		this.logAuditId = logAuditId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getRequestPlain() {
		return requestPlain;
	}

	public void setRequestPlain(String requestPlain) {
		this.requestPlain = requestPlain;
	}

	public String getResponsePlain() {
		return responsePlain;
	}

	public void setResponsePlain(String responsePlain) {
		this.responsePlain = responsePlain;
	}

	public String getRequestEncrypt() {
		return requestEncrypt;
	}

	public void setRequestEncrypt(String requestEncrypt) {
		this.requestEncrypt = requestEncrypt;
	}

	public String getResponseEncrypt() {
		return responseEncrypt;
	}

	public void setResponseEncrypt(String responseEncrypt) {
		this.responseEncrypt = responseEncrypt;
	}

	public String getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(String requestHeader) {
		this.requestHeader = requestHeader;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public String getRequestRefNumber() {
		return requestRefNumber;
	}

	public void setRequestRefNumber(String requestRefNumber) {
		this.requestRefNumber = requestRefNumber;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}


}