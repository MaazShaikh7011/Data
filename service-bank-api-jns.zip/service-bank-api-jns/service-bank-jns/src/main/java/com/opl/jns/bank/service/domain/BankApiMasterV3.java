package com.opl.jns.bank.service.domain;

import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.io.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "bank_api_master")
public class BankApiMasterV3 implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bank_api_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_BANK_API, name = "bank_api_master_seq_gen", sequenceName = "bank_api_master_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "name")
	private String name;

	@Column(name = "is_active")
	private Boolean isActive;
}
