package com.opl.jns.bank.service.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bank_api_response")
public class BankApiResponse {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bank_api_response_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_BANK_API, name = "bank_api_response_seq_gen", sequenceName = "bank_api_response_seq_gen", allocationSize = 1)
	private Long id;
	
	@Column(name = "api_id")
	private Long apiId;

	@Column(name = "org_id")
	private Long orgId;

	@Column(name = "sample_json")
	private String sampleJson;
	
}
