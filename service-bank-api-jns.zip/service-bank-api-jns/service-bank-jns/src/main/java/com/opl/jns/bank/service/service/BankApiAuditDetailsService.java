package com.opl.jns.bank.service.service;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.bank.api.model.BankAllApisResProxy;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;

@Service
public interface BankApiAuditDetailsService {

	VerifyOtpApiResponseV3 fetchVerifyOtpResponse(AccountHolderSelectionDetailsRequest accountHolderSelRequest) throws IOException;

	BankAllApisResProxy fetchAllApisRes(String urn) throws IOException;

}
