package com.opl.jns.bank.service.service.impl;

import javax.net.ssl.*;
import java.security.cert.*;

public class TrustAllX509TrustManager implements X509TrustManager {
    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0];
    }

    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {// Do nothing
        // because of X
        // and Y.
    }

    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {// Do nothing
        // because of X
        // and Y.
    }

}