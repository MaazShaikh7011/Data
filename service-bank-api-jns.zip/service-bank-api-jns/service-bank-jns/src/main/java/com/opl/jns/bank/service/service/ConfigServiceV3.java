package com.opl.jns.bank.service.service;

import java.util.List;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.bank.api.model.ApiMasterRequest;

public interface ConfigServiceV3 {

    public void setApiMasters() throws CommonException;

    public List<ApiMasterRequest> getApiMasters() throws CommonException;

    ApiMasterRequest getApiMasterByOrgId(Long orgId) throws CommonException;

}
