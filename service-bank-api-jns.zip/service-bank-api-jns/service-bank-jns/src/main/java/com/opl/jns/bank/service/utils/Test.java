package com.opl.jns.bank.service.utils;

import java.io.IOException;
import java.time.LocalDateTime;

import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;

public class Test {

	public static <T extends MainResponse> T handleRes(T respClass, String version) {
		if ("V2".equals(version)) {
			APIResponseV2 apiResponse2 = (APIResponseV2) respClass;
			apiResponse2.setFlag(true);
			apiResponse2.setMessage("Test");
			apiResponse2.setStatus(200);
			apiResponse2.setTimestamp(LocalDateTime.now());
			apiResponse2.setToken("XYZ");
			return (T) apiResponse2;
		}
		APIResponseV3 apiResponse3 = (APIResponseV3) respClass;
		apiResponse3.setSuccess(true);
		apiResponse3.setMessage("Test");
		apiResponse3.setStatus(200);
		apiResponse3.setTimestamp(LocalDateTime.now());
		apiResponse3.setToken("XYZ");
		return (T) apiResponse3;
	}

	public static void main(String[] args) throws IOException {
		APIResponseV2 apiResponseV2 = new APIResponseV2();
		APIResponseV2 handleRes = handleRes(apiResponseV2, "V2");
		System.out.println(MultipleJSONObjectHelper.getStringfromObject(handleRes));

		APIResponseV3 apiResponseV3 = new APIResponseV3();
		APIResponseV3 handleRes3 = handleRes(apiResponseV3, "V3");
		System.out.println(MultipleJSONObjectHelper.getStringfromObject(handleRes3));
	}

}
