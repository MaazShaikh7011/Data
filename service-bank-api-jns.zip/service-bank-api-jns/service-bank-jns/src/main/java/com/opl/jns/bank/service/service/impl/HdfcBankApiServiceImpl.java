package com.opl.jns.bank.service.service.impl;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.service.service.HttpUtility;
import com.opl.jns.bank.service.utils.APIAbsractLayer;
import com.opl.jns.utils.enums.VersionMaster;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class HdfcBankApiServiceImpl extends APIAbsractLayer {
	String dirPath = "/apps/test/";
	String keyStore = "hdfc_comunication_certificate.p12";
	String keyStoreType = "pkcs12";

	@Value("${certification_path}")
	String certPath;

	@Value("${certification_name}")
	String certName;

	@Value("${certification_type}")
	String certType;

	@Value("${certification_pass}")
	String certPass;

	@Autowired
	private HttpUtility httpUtility;

	@Override
	public <T extends MainResponse, U extends CommonRequest> T triggerOtpRequest(U triggerOtpReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.triggerOtpRequest(httpUtility, triggerOtpReq, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T verifyOtpRequest(U otpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.verifyOtpRequest(httpUtility, otpRequest, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequest(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.customerDetailsRequest(httpUtility, custDetailsReq, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequestV3(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.customerDetailsRequestV3(httpUtility, custDetailsReq, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T premiumDeductionRequest(U premDeducReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.premiumDeductionRequest(httpUtility, premDeducReq, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U phyVrfReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getPhysicalVerification(httpUtility, phyVrfReq, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getAccHolderList(httpUtility, holderListRequest, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		return this.getPolicyDetails(httpUtility, policyDetailsRequest, userId, referenceId, generateHeader(),
				this.getSslCertificate(certPath,certName,certPass,certType), version, urn, accNo);
	}

	public Map<String, String> generateHeader() {
		Map<String, String> header = new HashMap<>();
		header.put("api-key", "B5vp1aM61OK5kcgxiS1IkUVx3OxNX0mGBxUpk25ArGyzmFCY");
		header.put("user-name", "Read");
		header.put("accept", "application/json");
		return header;
	}


	/* LOAD SSL CERTIFICATE */
	
	public static ClientHttpRequestFactory getSslCertificate(String certPath, String certName, String certPass, String certType) {
		try {
			// SET CERTIFICATE FILE PATH
			String keyStoreFilePath = certPath + certName;
			log.info("keyStoreFilePath ===> {} ", keyStoreFilePath);

			// Load KeyStore
			KeyStore clientStore = KeyStore.getInstance(certType);
			try (FileInputStream fis = new FileInputStream(keyStoreFilePath)) {
				clientStore.load(fis, certPass.toCharArray());
			}

			// Initialize KeyManagerFactory
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(clientStore, certPass.toCharArray());
			KeyManager[] kms = kmf.getKeyManagers();

			// Initialize SSLContext
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(kms, new TrustManager[]{new TrustAllX509TrustManager()}, new SecureRandom());
			org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory sslConFactory = new org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory(sslContext);

			// SET SSL Socket Factory
			HttpClientConnectionManager connectionManager = PoolingHttpClientConnectionManagerBuilder.create().setSSLSocketFactory(sslConFactory).build();
			org.apache.hc.client5.http.impl.classic.CloseableHttpClient httpClient = org.apache.hc.client5.http.impl.classic.HttpClients.custom().setConnectionManager(connectionManager).build();
//            return (HttpClient) httpClient;
			ClientHttpRequestFactory httpClient1 = new HttpComponentsClientHttpRequestFactory(httpClient);
//            HttpComponentsClientHttpRequestFactory httpClient1 = (HttpComponentsClientHttpRequestFactory) ((HttpClient) httpClient);
			return httpClient1;
		} catch (Exception e) {
			log.info("Exception while loading SSL certificate for HDFC bank APIs",e);
		}
		return null;
	}


}
