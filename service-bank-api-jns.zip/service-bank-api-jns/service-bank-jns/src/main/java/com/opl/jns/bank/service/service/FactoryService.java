package com.opl.jns.bank.service.service;

import java.io.IOException;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.utils.enums.VersionMaster;

public interface FactoryService {

	public <T extends MainResponse, U extends CommonRequest> T varifyOtp(U otpRequest, Long userId, String referenceId,
			VersionMaster version, String urn, String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T triggerOtp(U triggerOtpRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getCustomerDetails(U customerDetailsRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getCustomerDetailsV3(U customerDetailsRequest,
			Long userId, String referenceId, VersionMaster version, String urn, String accNo)
			throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getPremiumDeduction(U premiumDeductionRequest,
			Long userId, String referenceId, VersionMaster version, String urn, String accNo)
			throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U otpRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, VersionMaster version, String urn, String accNo) throws CommonException, IOException;

	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String generateRef, VersionMaster version, String urn, String accNo) throws CommonException, IOException;

}
