package com.opl.jns.bank.service.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.stereotype.Service;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.service.service.HttpUtility;
import com.opl.jns.bank.service.utils.APIAbsractLayer;
import com.opl.jns.bank.service.utils.Utils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.VersionMaster;

@Service
public class SbiBankApiServiceImpl extends APIAbsractLayer {

	private final static String SOURCE_ID = "JK";

	@Autowired
	private HttpUtility httpUtility;

	@Override
	public <T extends MainResponse, U extends CommonRequest> T triggerOtpRequest(U triggerOtpReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		triggerOtpReq.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(triggerOtpReq.getOrgId())) {
			triggerOtpReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			triggerOtpReq.setToken(null);
		}		
		return this.triggerOtpRequest(httpUtility, triggerOtpReq, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T verifyOtpRequest(U otpRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		otpRequest.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(otpRequest.getOrgId())) {
			otpRequest.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			otpRequest.setToken(null);
		}	
		return this.verifyOtpRequest(httpUtility, otpRequest, userId, referenceId, null, requestFactory, version, urn,
				accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequest(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		custDetailsReq.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(custDetailsReq.getOrgId())) {
			custDetailsReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			custDetailsReq.setToken(null);
		}	
		return this.customerDetailsRequest(httpUtility, custDetailsReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequestV3(U custDetailsReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		custDetailsReq.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(custDetailsReq.getOrgId())) {
			custDetailsReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			custDetailsReq.setToken(null);
		}
		return this.customerDetailsRequestV3(httpUtility, custDetailsReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T premiumDeductionRequest(U premDeducReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		if(PhaseMode.checkPhase2(premDeducReq.getOrgId())) {
			premDeducReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			premDeducReq.setToken(null);
		}
		premDeducReq.setSourceId(SOURCE_ID);
		
		return this.premiumDeductionRequest(httpUtility, premDeducReq, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(U phyVrfReq, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		phyVrfReq.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(phyVrfReq.getOrgId())) {
			phyVrfReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			phyVrfReq.setToken(null);
		}
		phyVrfReq.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		return this.getPhysicalVerification(httpUtility, phyVrfReq, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(U holderListRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		if(PhaseMode.checkPhase2(holderListRequest.getOrgId())) {
			holderListRequest.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			holderListRequest.setToken(null);
		}
		holderListRequest.setSourceId(SOURCE_ID);
		
		return this.getAccHolderList(httpUtility, holderListRequest, userId, referenceId, null, requestFactory, version,
				urn, accNo);
	}

	@Override
	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(U policyDetailsRequest, Long userId,
			String referenceId, ClientHttpRequestFactory requestFactory, VersionMaster version, String urn,
			String accNo) throws CommonException, IOException {
		policyDetailsRequest.setSourceId(SOURCE_ID);
		if(PhaseMode.checkPhase2(policyDetailsRequest.getOrgId())) {
			policyDetailsRequest.setToken(gnerateReferenceNumber(Utils.SBI_BANK_CODE));
		}else {
			policyDetailsRequest.setToken(null);
		}
	
		return this.getPolicyDetails(httpUtility, policyDetailsRequest, userId, referenceId, null, requestFactory,
				version, urn, accNo);
	}

	/**
	 * GENERATE REFERENCE NUMBER & TOKEN
	 * 
	 * @param orgCode
	 * @return
	 */
	private String gnerateReferenceNumber(String orgCode) {
		Date date = new Date();
		return orgCode + "JK" + getTimestampFormat(date, "YYDDD") + getTimestampFormat(date, "hhMMsss")
				+ UUID.randomUUID().toString().replace("-", "").substring(0, 8);
	}

	private String getTimestampFormat(Date date, String format) {
		return new SimpleDateFormat(format).format(date);
	}
}
