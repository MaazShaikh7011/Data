package com.opl.jns.bank.service.service.impl;

import java.net.SocketTimeoutException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.net.ssl.SSLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.api.proxy.common.APIResponseV2;
import com.opl.jns.api.proxy.common.APIResponseV3;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.api.model.ApiMasterRequest;
import com.opl.jns.bank.api.model.ApiResponse;
import com.opl.jns.bank.api.model.common.AuditReq;
import com.opl.jns.bank.api.model.sbi.SBIEncryptedRequest;
import com.opl.jns.bank.api.model.sbi.SBIEncryptedResponse;
import com.opl.jns.bank.service.domain.BankApiResponse;
import com.opl.jns.bank.service.repository.BankApiResponseRepository;
import com.opl.jns.bank.service.service.AuditDetailServiceV3;
import com.opl.jns.bank.service.service.HttpUtility;
import com.opl.jns.bank.service.utils.CommonUtils;
import com.opl.jns.bank.service.utils.Utils;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.VersionMaster;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HttpUtilityImpl implements HttpUtility {

	@Autowired
	private AuditDetailServiceV3 auditDetailService;

	@Autowired
	private BankApiResponseRepository bankApiResponseRepository;

	private static final String BANK_ERROR = "Bank Error - ";
	private static final String ERROR_500 = "An error has occurred during the retrieval of customer data from CBS. Please attempt the operation again after some time";
	private static final String ERROR_ENCRYPT = "A problem occurred while encrypting the request. Please try after some time";
	private static final String ERROR_DECRYPT = "A problem occurred while decrypting the request. Please try after some time";
	private static final String ERROR_TIMEOUT = "The response time from CBS is longer than anticipated. Please make another attempt.";
	private static final String ERROR_CONFIGURATION = "The bank is not yet registered with JanSuraksha. Please proceed with onboarding the bank first";

	public <T extends MainResponse> T post(Object plainReqObj, Long orgId, Long appId, int apiId, Long userId,
			T respClass, String referenceId, String urn, String accountNumber, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, String reqToken, VersionMaster version) {

		respClass.setFlag(false);
		String secretKey = null;
		AuditReq auditReq = new AuditReq(appId, orgId, apiId, new Date(), referenceId, urn, accountNumber, reqToken);
		try {
			ApiMasterRequest apiConfig = CommonUtils.getApiUserByOrgIdForBankApi(orgId);
			if (null == apiConfig.getUrlConfig()) {
				auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				auditReq.setFailureReason(ERROR_CONFIGURATION);
				log.error("END BANK CONFIGURATION IS NOR FOUND FROM CONFIGURATION ----------"
						+ CommonUtils.printLogs(orgId, apiId, referenceId));
				return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_CONFIGURATION);
			}
			String url = CommonUtils.getUrl(apiConfig, apiId, orgId);
			auditReq.setReqUrl(url);

			// CHECK IF TESTING MODE IS NOT OR NOT
			if (isTestingMode(userId)) {
				String staticRes = getStaticResponse(apiId, orgId);
				if (!OPLUtils.isObjectNullOrEmpty(staticRes)) {
					auditReq.setResponseCode(HttpStatus.OK.value());
					auditReq.setFailureReason("STATIC_RESPONSE");
					auditReq.setResPlain(staticRes);
					auditReq.setReqPlain(MultipleJSONObjectHelper.getStringfromObject(plainReqObj));
					auditReq.setResEncrypt("STATIC_RESPONSE");
					auditReq.setReqEncrypt("Static Joureny");
					return MultipleJSONObjectHelper.getObjectFromString(staticRes, respClass.getClass());
				}
			}

			// SET HEADERS
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			if (!OPLUtils.isObjectNullOrEmpty(apiConfig.getHeaderConfig())) {
				headers.setAll(PhaseMode.checkPhase2(orgId) ? apiConfig.getHeaderConfig().getV3()
						: apiConfig.getHeaderConfig().getV2());
			}
			if (!OPLUtils.isObjectNullOrEmpty(additionalHeaders)) {
				headers.setAll(additionalHeaders);
			}

			HttpEntity<Object> entity = null;

			// ENCRYPT PLAIN REQUEST
			if (Utils.SBI_BANK_ID.equals(orgId)) { // SBI BANK SPECIFIC
				try {
					SBIEncryptedRequest encryptedRequest = Utils.encryptedRequestSBI(plainReqObj, orgId, userId);
					if(PhaseMode.checkPhase2(orgId)) {
						encryptedRequest.setRequestRefNumber(reqToken);
					}else {
						encryptedRequest.setRequestRefNumber(encryptedRequest.getRequestRefNumber());
					}					

					// Set Audit
					String plainReq = MultipleJSONObjectHelper.getStringfromObject(plainReqObj);
					auditReq.setReqPlain(plainReq);

					// Set Audit
					auditReq.setReqEncrypt(MultipleJSONObjectHelper.getStringfromObject(encryptedRequest));
					auditReq.setRequestRefNumber(encryptedRequest.getRequestRefNumber());

					// SET SBI SPECIFIC HEADER
					headers.set(Utils.ACCESS_TOKEN, encryptedRequest.getAccessToken());
					secretKey = encryptedRequest.getSecretKey();
					auditReq.setSecretKey(secretKey);
					auditReq.setReqHeader(headers.toSingleValueMap());

					encryptedRequest.setAccessToken(null);
					encryptedRequest.setSecretKey(null);
					String encryptedRequestStr = MultipleJSONObjectHelper.getStringfromObject(encryptedRequest);
					entity = new HttpEntity<>(encryptedRequestStr, headers);
				} catch (Exception e) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason("ERROR_ENCRYPT: " + e.getMessage());
					log.error("END EXCEPTION WHILE ENCRYPT REQUEST ----------"
							+ CommonUtils.printLogs(orgId, apiId, referenceId), e);
					auditReq.setErrorMsg("Bank Error Msg - " + e.getMessage());
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_ENCRYPT);
				}
			} else {
				try {
					String plainReq = MultipleJSONObjectHelper.getStringfromObject(plainReqObj);
					auditReq.setReqPlain(plainReq);
					String encryptedRequest = Utils.encryptedRequestFromString(plainReq, orgId, userId);
					auditReq.setReqEncrypt(encryptedRequest);
					auditReq.setReqHeader(headers.toSingleValueMap());
					
					// CONVERT INTO META DATA FORM
					Map<String, String> encryptedReq = new HashMap<>();
					if(OPLUtils.isConvertMetaDataString(orgId)) {						
						entity = new HttpEntity<>("{\"metadata\":\""+encryptedRequest+"\"}", headers);
					}else {
						encryptedReq.put(CommonUtils.METADATA, encryptedRequest);
						entity = new HttpEntity<>(encryptedReq, headers);
					}

				} catch (Exception e) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason("ERROR_ENCRYPT: " + e.getMessage());
					log.error("END EXCEPTION WHILE ENCRYPT REQUEST ----------"
							+ CommonUtils.printLogs(orgId, apiId, referenceId), e);
					auditReq.setErrorMsg("Bank Error Msg - " + e.getMessage());
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_ENCRYPT);
				}
			}

			RestTemplate restTemplate = null;
			if (!OPLUtils.isObjectNullOrEmpty(requestFactory)) {
				// SET TIMEOUT FOR API CALL With CERTIFICATE
				restTemplate = setTimeOutWithCertificate(apiConfig, apiId, orgId);
				restTemplate.setRequestFactory(requestFactory);
//				restTemplate = new RestTemplate(requestFactory);

			} else {
//				restTemplate = new RestTemplate();

				// SET TIMEOUT FOR Normal API CALL
				restTemplate = setTimeOut(apiConfig, apiId, orgId);
			}
			log.info("url : {}", url);
			ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			String statusStg = String.valueOf(exchange.getStatusCodeValue());
			String body = exchange.getBody();
			auditReq.setResEncrypt(body);
			return handleResponse(auditReq, body, statusStg, orgId, apiId, referenceId, respClass, userId, secretKey,
					version);
		} catch (HttpStatusCodeException e) {
			ResponseEntity<String> resp = ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders())
					.body(e.getResponseBodyAsString());

			// HANDLE ERROR RESPONSE
			if (!OPLUtils.isObjectNullOrEmpty(resp.getBody())) {
				boolean contains = resp.getBody().contains("metadata");
				if (contains) {
					return handleResponse(auditReq, resp.getBody(),
							e.getStatusCode() != null ? e.getStatusCode().toString() : null, orgId, apiId, referenceId,
							respClass, userId, secretKey, version);
				}
			}
			auditReq.setErrorMsg("Bank Error Msg - " + e.getMessage());
			auditReq.setResEncrypt(resp.getBody());
			log.error("END ERROR WHILE CALLING BANK API STATUS ---> " + resp.getStatusCode().value()
					+ " AND BODY ----->" + resp.getBody() + CommonUtils.printLogs(orgId, apiId, referenceId));
			auditReq.setFailureReason(e.getMessage());
			auditReq.setResponseCode(e.getStatusCode().value());
			if (e.getStatusCode() == HttpStatus.GATEWAY_TIMEOUT) {
				return CommonUtils.reponse(respClass, e.getStatusCode().value(), ERROR_TIMEOUT);
			} else if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
				return CommonUtils.reponse(respClass, e.getStatusCode().value(),
						"An error encountered in application at CBS level. Please try after some time");
			} else if (e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
				return CommonUtils.reponse(respClass, e.getStatusCode().value(),
						"The bank's API services are currently unavailable. Please try again later.");
			} else {
				return CommonUtils.reponse(respClass, e.getStatusCode().value(),
						"An error encountered in application at CBS level. Please try after some time");
			}
		} catch (ResourceAccessException http) {
			log.info("http.getCause() TIMEOUT " + CommonUtils.printLogs(orgId, apiId, referenceId), http.getCause());
			auditReq.setErrorMsg("Bank TIMEOUT Error Msg - " + http.getCause().getLocalizedMessage());
			auditReq.setFailureReason(http.getCause().getLocalizedMessage());
			if (http.getCause() instanceof SocketTimeoutException || http.getCause() instanceof SSLException) {
				auditReq.setResponseCode(HttpStatus.GATEWAY_TIMEOUT.value());
				return CommonUtils.reponse(respClass, HttpStatus.GATEWAY_TIMEOUT.value(), ERROR_TIMEOUT);
			} else {
				auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
			}
		} catch (Exception e) {
			auditReq.setFailureReason(e.getMessage());
			auditReq.setErrorMsg("Bank Error Msg - " + e.getMessage());
			auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			log.error("EXCEPTION WHILE CALLING BANK API " + CommonUtils.printLogs(orgId, apiId, referenceId), e);
			return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_500);
		} finally {
			auditDetailService.audit(auditReq);
		}
	}

	private <T extends MainResponse> T handleResponse(AuditReq auditReq, String body, String statusStg, Long orgId,
			int apiId, String referenceId, T respClass, Long userId, String secretKey, VersionMaster version) {
		if (OPLUtils.isObjectNullOrEmpty(body)) {
			auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			auditReq.setFailureReason("Found Blank Response Body " + statusStg);
			log.error("END FOUND RESPONSE BODY NULL " + CommonUtils.printLogs(orgId, apiId, referenceId));
			return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					"Invalid response received from CBS. Please try after some time");
		}
		try {
			String decryptResp = "";
			if (Utils.SBI_BANK_ID.equals(orgId)) {

				// respClass.getClass() MEANS RESPONSE CLASS OF SBI
				SBIEncryptedResponse enResponse = MultipleJSONObjectHelper.getObjectFromString(body,
						SBIEncryptedResponse.class);
				enResponse.setSecretKey(secretKey);

				// response.toString() MEANS FETCH RESPONSE FROM ABOVE OBJECT
				CommonResponse decryptResponse = Utils.decryptResponseSBI(enResponse, orgId);
				auditReq.setResPlain(String.valueOf(decryptResponse.getData()));
				if (!OPLUtils.isObjectNullOrEmpty(decryptResponse.getStatus())
						&& decryptResponse.getStatus() == HttpStatus.INTERNAL_SERVER_ERROR.value()
						&& !decryptResponse.getFlag()) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason(decryptResponse.getMessage());
					log.error("Invalid response received from CBS. Please try after some time - "
							+ decryptResponse.getMessage() + CommonUtils.printLogs(orgId, apiId, referenceId));
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Invalid response received from CBS. Please try after some time");
				}

				decryptResp = String.valueOf(decryptResponse.getData());
				if (OPLUtils.isObjectNullOrEmpty(decryptResp)) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason("Response null after decrypt payload " + statusStg);
					log.error("END RESPONSE NULL AFTER DECRYPT PAYLOAD "
							+ CommonUtils.printLogs(orgId, apiId, referenceId));
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Invalid response received from CBS. Please try after some time");
				}
			} else {
				ApiResponse apiResp = MultipleJSONObjectHelper.getObjectFromString(body, ApiResponse.class);
				if (OPLUtils.isObjectNullOrEmpty(apiResp.getMetadata())) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason("Response Metadata null " + statusStg);
					log.error("END FOUND RESPONSE METADATA NULL " + CommonUtils.printLogs(orgId, apiId, referenceId));
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Invalid response received from CBS. Please try after some time");
				}
				decryptResp = Utils.decryptResponseFromEncryptedResponse(apiResp.getMetadata(), orgId, userId);
				if (OPLUtils.isObjectNullOrEmpty(decryptResp)) {
					auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					auditReq.setFailureReason("Response null after decrypt payload " + statusStg);
					log.error("END RESPONSE NULL AFTER DECRYPT PAYLOAD "
							+ CommonUtils.printLogs(orgId, apiId, referenceId));
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Invalid response received from CBS. Please try after some time");
				}
			}
			auditReq.setResPlain(decryptResp);
			respClass = MultipleJSONObjectHelper.getObjectFromString(decryptResp, respClass.getClass());
			if (!OPLUtils.isObjectNullOrEmpty(respClass.getStatus())) {
				respClass.setFlag(true);
				auditReq.setResponseCode(respClass.getStatus());
				auditReq.setFailureReason(respClass.getMessage());
				if (respClass.getStatus() != HttpStatus.OK.value()) {
					respClass.setMessage(BANK_ERROR + respClass.getMessage());
				}
				log.info("END SUCCESS RESPONSE  " + CommonUtils.printLogs(orgId, apiId, referenceId) + " CODE ---"
						+ respClass.getStatus() + "----MESSAGE----" + respClass.getMessage());
				/** CHECK REQUEST AND RESPONSE TOKEN SAME OR NOT FOR PHASE 2 */
				if (PhaseMode.checkPhase2(orgId)) {
					T isValid = tokenAndTimeStampValidCheck(decryptResp, orgId, apiId, referenceId, respClass, auditReq,
							version);
					if (!OPLUtils.isObjectNullOrEmpty(isValid)) {
						return isValid;
					}
				}
				return respClass;
			} else {
				auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				auditReq.setFailureReason("Not Found Response Status " + statusStg);
				log.error("END FOUND RESPONSE NULL STATUS " + CommonUtils.printLogs(orgId, apiId, referenceId));
				return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						"Invalid response received from CBS. Please try after some time");
			}

		} catch (Exception e) {
			auditReq.setResponseCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			auditReq.setFailureReason("ERROR_DECRYPT: " + e.getMessage());
			auditReq.setErrorMsg("Bank ERROR_DECRYPT Msg : - " + e.getMessage());
			log.error("END EXCEPTION WHILE DECRYPT REQUEST " + CommonUtils.printLogs(orgId, apiId, referenceId), e);
			return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(), ERROR_DECRYPT);
		}
	}

	private boolean isTestingMode(Long userId) {
		String isTesting = ConfigProperties.getBankApiTestingModeFlags();
		List<String> isSkipUserIdIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
		List<Long> isSkipUserIdsLst = isSkipUserIdIds.stream().map(Long::parseLong).collect(Collectors.toList());
		if ((!OPLUtils.isObjectNullOrEmpty(isTesting) && "TRUE".equals(isTesting))
				|| isSkipUserIdsLst.contains(userId)) {
			return true;
		}
		return false;
	}

	private RestTemplate setTimeOutWithCertificate(ApiMasterRequest apiConfig, int apiId,
			Long orgId) {
		Integer readTimeOut = CommonUtils.getReadTimeOut(apiConfig, apiId, orgId);
		Integer conTimeOut = CommonUtils.getConnectionTimeOut(apiConfig, apiId, orgId);

		return new RestTemplateBuilder().requestFactory(HttpComponentsClientHttpRequestFactory.class)
				.setConnectTimeout(Duration.ofSeconds(!OPLUtils.isObjectNullOrEmpty(conTimeOut) ? conTimeOut : 30))
				.setReadTimeout(Duration.ofSeconds(!OPLUtils.isObjectNullOrEmpty(readTimeOut) ? readTimeOut : 90))
				.build();

//		if (!OPLUtils.isObjectNullOrEmpty(conTimeOut)) {
//			((HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(conTimeOut * 1000);
//		}
//
//		if (!OPLUtils.isObjectNullOrEmpty(readTimeOut)) {
//			((HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeOut * 1000);
//		}
	}


	private RestTemplate setTimeOut(ApiMasterRequest apiConfig, int apiId, Long orgId) {
		Integer readTimeOut = CommonUtils.getReadTimeOut(apiConfig, apiId, orgId);
		Integer conTimeOut = CommonUtils.getConnectionTimeOut(apiConfig, apiId, orgId);

		return new RestTemplateBuilder().requestFactory(HttpComponentsClientHttpRequestFactory.class)
				.setConnectTimeout(Duration.ofSeconds(!OPLUtils.isObjectNullOrEmpty(conTimeOut) ? conTimeOut : 30))
				.setReadTimeout(Duration.ofSeconds(!OPLUtils.isObjectNullOrEmpty(readTimeOut) ? readTimeOut : 90))
				.build();
//		if (!OPLUtils.isObjectNullOrEmpty(conTimeOut)) {
//			((HttpComponentsClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(conTimeOut * 1000);
//		}
//		if (!OPLUtils.isObjectNullOrEmpty(readTimeOut)) {
//			((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(readTimeOut * 1000);
//		}
	}

	private String getStaticResponse(Integer apiId, Long orgId) {

		BankApiResponse apiResponse = bankApiResponseRepository.findByApiIdAndOrgId(Long.valueOf(apiId),
				!OPLUtils.isObjectNullOrEmpty(orgId) ? orgId : -1L);

		if (!OPLUtils.isObjectNullOrEmpty(apiResponse)) {
			return apiResponse.getSampleJson();
		} else {
			return bankApiResponseRepository.findByApiIdAndOrgId(Long.valueOf(apiId), -1L).getSampleJson();
		}
	}

	private <T extends MainResponse> T tokenAndTimeStampValidCheck(String body, Long orgId, int apiId,
			String referenceId, T respClass, AuditReq auditReq, VersionMaster version) {

		try {
			LocalDateTime timeStamp = null;
			String token = null;
			if (VersionMaster.V2 == version) {
				APIResponseV2 bankApiResObj = MultipleJSONObjectHelper.getObjectFromString(body, APIResponseV2.class);
				if (OPLUtils.isObjectNullOrEmpty(bankApiResObj)) {
					log.error("RESPONSE IS NULL" + CommonUtils.printLogs(orgId, apiId, referenceId));
					auditReq.setErrorMsg("Bank Error Msg : - RESPONSE IS NULL");
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Response is null from CBS. Please try after some time");
				}
				timeStamp = bankApiResObj.getTimestamp();
				token = bankApiResObj.getToken();
			} else {
				APIResponseV3 bankApiResObj = MultipleJSONObjectHelper.getObjectFromString(body, APIResponseV3.class);
				if (OPLUtils.isObjectNullOrEmpty(bankApiResObj)) {
					log.error("RESPONSE IS NULL" + CommonUtils.printLogs(orgId, apiId, referenceId));
					auditReq.setErrorMsg("Bank Error Msg : - RESPONSE IS NULL");
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Response is null from CBS. Please try after some time");
				}
				timeStamp = bankApiResObj.getTimestamp();
				token = bankApiResObj.getToken();
			}

			if (OPLUtils.isObjectNullOrEmpty(timeStamp)) {
				log.error("RESPONSE TIMESTAMP IS NULL" + CommonUtils.printLogs(orgId, apiId, referenceId));
				auditReq.setErrorMsg("Bank Error Msg : - RESPONSE TIMESTAMP IS NULL");
				return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						"Response timeStamp is null or response is null from CBS. Please try after some time");
			}

			if (!OPLUtils.isObjectNullOrEmpty(token)) {
				if (!auditReq.getReqToken().equals(token)) {
					log.error("REQUEST AND RESPONSE TOKEN IS DIFFERENT"
							+ CommonUtils.printLogs(orgId, apiId, referenceId));
					auditReq.setErrorMsg("Bank Error Msg : - REQUEST AND RESPONSE TOKEN IS DIFFERENT - "
							+ auditReq.getReqToken() + " Not Eq " + token);
					return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
							"Response token is not same as a request token from CBS. Please try after some time");
				}
			} else {
				log.error("RESPONSE TOKEN IS NULL" + CommonUtils.printLogs(orgId, apiId, referenceId));
				auditReq.setErrorMsg("Bank Error Msg : - RESPONSE TOKEN IS NULL");
				return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
						"Response token is null or response is null from CBS. Please try after some time");
			}
		} catch (Exception e) {
			log.error("RESPONSE TOKEN PARSE ERROR" + CommonUtils.printLogs(orgId, apiId, referenceId));
			auditReq.setErrorMsg("Bank TOKEN PARSE & TIMESTAMP Msg : - " + e.getMessage());
			return CommonUtils.reponse(respClass, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					"Response token parse error");
		}
		return null;

	}
}
