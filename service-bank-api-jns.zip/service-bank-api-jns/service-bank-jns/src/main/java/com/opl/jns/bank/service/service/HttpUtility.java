package com.opl.jns.bank.service.service;

import java.util.Map;

import org.springframework.http.client.ClientHttpRequestFactory;

import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.utils.enums.VersionMaster;

public interface HttpUtility {

	public <T extends MainResponse> T post(Object plainReqObj, Long orgId, Long appId, int apiId, Long userId,
			T respClass, String referenceId, String urn, String accountNumber, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, String reqToken, VersionMaster version);

}
