package com.opl.jns.bank.service.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.bank.api.model.ApiMasterRequest;
import com.opl.jns.bank.api.model.sbi.SBIEncryptedRequest;
import com.opl.jns.bank.api.model.sbi.SBIEncryptedResponse;
import com.opl.jns.bank.api.utils.SBIEncryptionUtils;
import com.opl.jns.bank.api.utils.SymAsymEncryption;
import com.opl.jns.config.utils.ConfigProperties;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Utils {

    public static final String ERROR = "Error  ";
    public static final Long SBI_BANK_ID = 16l;
    public static final String SBI_BANK_CODE = "SBI";
    public static final String ACCESS_TOKEN="AccessToken";

    public static String encryptedRequestFromString(String request, Long orgId, Long userId) throws CommonException {
        String  isTesting = ConfigProperties.getBankApiTestingModeFlags();
        List<String> isSkipUserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
        List<Long> isSkipUserIdsLst = isSkipUserIds.stream().map(Long::parseLong).collect(Collectors.toList());
        if((!OPLUtils.isObjectNullOrEmpty(isTesting) && isTesting.equals("TRUE")) || isSkipUserIdsLst.contains(userId)) {
            return request;
        }
        ApiMasterRequest apiUserByOrgId = CommonUtils.getApiUserByOrgId(orgId);
        try {
            if (apiUserByOrgId == null) {
                throw new CommonException("Organisation Configuration not found");
            }
            if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getOplPrivateKey())) {
            	log.info("Jansuraksha Private Key Not found");
                throw new CommonException("Jansuraksha Private Key Not found");
            }
            if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getPublicKey())) {
            	log.info(apiUserByOrgId.getOrgId()+" = Bank Public Key Not found");
                throw new CommonException("Bank Public Key Not found");
            }
            SymAsymEncryption asymEncryption = new SymAsymEncryption();
            return asymEncryption.encrypt(request, apiUserByOrgId.getOplPrivateKey(), apiUserByOrgId.getPublicKey());
        } catch (Exception e) {
            throw new CommonException(e);
        }
    }


    public static String decryptResponseFromEncryptedResponse(String request, Long orgId,Long userId) throws CommonException {
//    	log.info("request ===> ",request);
        String  isTesting = ConfigProperties.getBankApiTestingModeFlags();
        List<String> isSkipuserIds = ConfigProperties.getSkipAllTestingAndDeDupeMode();
        if((!OPLUtils.isObjectNullOrEmpty(isTesting) && isTesting.equals("TRUE"))  || isSkipuserIds.contains(userId)) {
            return request;
        }
        ApiMasterRequest apiUserByOrgId = CommonUtils.getApiUserByOrgId(orgId);
        try {
            if (apiUserByOrgId == null) {
                throw new CommonException("Organisation Configuration not found");
            }
            SymAsymEncryption asymEncryption = new SymAsymEncryption();
            return asymEncryption.decrypt(request, apiUserByOrgId.getOplPrivateKey(), apiUserByOrgId.getPublicKey());
        } catch (Exception e) {
            throw new CommonException(e);
        }
    }
    
    /**
     * SBI REQUEST ENCRYPTION
     * @param request
     * @param orgId
     * @param userId
     * @return
     * @throws CommonException
     */
    public static SBIEncryptedRequest encryptedRequestSBI(Object request, Long orgId, Long userId) throws CommonException {
    	ApiMasterRequest apiUserByOrgId = CommonUtils.getApiUserByOrgId(orgId);
		try {
			if (apiUserByOrgId == null) {
				throw new CommonException("Organisation Configuration not found");
			}
			if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getOplPrivateKey())) {
				log.info("Jansuraksha Private Key Not found");
				throw new CommonException("Jansuraksha Private Key Not found");
			}
			if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getPublicKey())) {
				log.info(apiUserByOrgId.getOrgId() + " = Bank Public Key Not found");
				throw new CommonException("Bank Public Key Not found");
			}
			SBIEncryptionUtils sbiEncryptionUtils=new SBIEncryptionUtils();
			return sbiEncryptionUtils.prepareRequest(request, apiUserByOrgId.getOplPrivateKey(), apiUserByOrgId.getPublicKey(), SBI_BANK_CODE,orgId);
		} catch (Exception e) {
			throw new CommonException(e);
		}
    }
    
    /**
     * SBI RESPONSE DECRYPT
     * @param request
     * @param orgId
     * @param userId
     * @return
     * @throws CommonException
     */
    public static CommonResponse decryptResponseSBI(SBIEncryptedResponse enResponse, Long orgId) throws CommonException {
    	
    	String plainResponse=null;
    	ApiMasterRequest apiUserByOrgId = CommonUtils.getApiUserByOrgId(orgId);
		try {
			if (apiUserByOrgId == null) {
				throw new CommonException("Organisation Configuration not found");
			}
			if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getOplPrivateKey())) {
				log.info("Jansuraksha Private Key Not found");
				throw new CommonException("Jansuraksha Private Key Not found");
			}
			if (OPLUtils.isObjectNullOrEmpty(apiUserByOrgId.getPublicKey())) {
				log.info(apiUserByOrgId.getOrgId() + " = Bank Public Key Not found");
				throw new CommonException("Bank Public Key Not found");
			}
			SBIEncryptionUtils sbiEncryptionUtils=new SBIEncryptionUtils();
						
			//String secretKey=sbiEncryptionUtils.RSADecrypt(enResponse.getAccessToken(),apiUserByOrgId.getOplPrivateKey());
			 if (OPLUtils.isObjectNullOrEmpty(enResponse.getSecretKey())) {
				 log.info("Access Toekn Decrypt failed for Secret Key :"+apiUserByOrgId.getOrgId());
				 return new CommonResponse("Access Token is Null.", HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
			 }		
			plainResponse=sbiEncryptionUtils.decrypt(enResponse.getResponse(),enResponse.getSecretKey());
			boolean isVerified= SBIEncryptionUtils.digiSignVerify(plainResponse,enResponse.getDigiSign(),apiUserByOrgId.getPublicKey());
			if (!isVerified) {
				log.warn("DigiSignVerify - Signature failed :"+apiUserByOrgId.getOrgId());			
				return new CommonResponse("Digi Sign Verify failed.",plainResponse, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
			}		
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new CommonException(e);
		}
		return new CommonResponse("Successfully",plainResponse ,HttpStatus.OK.value(), true);
	}
    
    /**GENERATE TOKEN*/
    public static String generateToken(Long orgId) {
		Date date = new Date();
		return "JNS" + "%03d".formatted(orgId) +getTimestampFormat(date, "YYMMdd") + getTimestampFormat(date, "hhMMsss")
				+ UUID.randomUUID().toString().replace("-", "").substring(0, 8);
	}
	
	public static String getTimestampFormat(Date date, String format) {
		return new SimpleDateFormat(format).format(date);
	}
	
}
