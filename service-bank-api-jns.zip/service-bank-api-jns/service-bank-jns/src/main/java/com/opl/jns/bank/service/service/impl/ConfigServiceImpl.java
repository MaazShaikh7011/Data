package com.opl.jns.bank.service.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.bank.api.model.ApiMasterRequest;
import com.opl.jns.bank.api.model.ApiRequest;
import com.opl.jns.bank.api.model.ApiUrlsRequest;
import com.opl.jns.bank.api.model.VersionHeaderReq;
import com.opl.jns.bank.api.model.VersionTimeOutReq;
import com.opl.jns.bank.api.model.VersionUrlReq;
import com.opl.jns.bank.service.service.ConfigServiceV3;
import com.opl.jns.bank.service.utils.CommonUtils;
import com.opl.jns.config.domain.ApiUsersV3;
import com.opl.jns.config.repository.ApiUsersRepositoryV3;
import com.opl.jns.config.utils.ConfigType;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 3/11/2023
 */
@Service
@Slf4j
public class ConfigServiceImpl implements ConfigServiceV3 {

    @Autowired
    ApiUsersRepositoryV3 apiUsersRepo;

    public void setApiMasters() throws CommonException,RuntimeException{
        List<ApiUsersV3> apiListEntities = apiUsersRepo.findAllByIsActiveTrue();
        //log.info("apiListEntities ---->"+apiListEntities);
        ApiUsersV3 internalOrg = apiListEntities.stream().filter(x -> x.getOrgId() == CommonUtils.INT_0).findFirst().orElse(null);
        apiListEntities.forEach(apiUser -> {
            if(apiUser.getConfigType() == ConfigType.BANK_CONFIG.getConfigType()) {
                ApiMasterRequest req = new ApiMasterRequest();
                req.setOrgId(apiUser.getOrgId());
                req.setId(apiUser.getId());
                VersionHeaderReq versionHeaderReq = null;
                VersionUrlReq versionUrlReq = null;
                VersionTimeOutReq timeOutReq = null;
                try {
                	versionHeaderReq = null != apiUser.getHeaderConfig() ? MultipleJSONObjectHelper.getObjectFromString(apiUser.getHeaderConfig(), VersionHeaderReq.class) : null;
                	if((OPLUtils.isObjectNullOrEmpty(versionHeaderReq) || (!OPLUtils.isObjectNullOrEmpty(versionHeaderReq) && OPLUtils.isObjectNullOrEmpty(versionHeaderReq.getV2()))) && !OPLUtils.isObjectNullOrEmpty(apiUser.getHeaderConfig())) {
                		log.info("V3 DETAILS NOT ONBOARD : orgId {}, apiUserId {} ",apiUser.getOrgId(),apiUser.getId());
                		versionHeaderReq = new VersionHeaderReq();
                		versionHeaderReq.setV2(MultipleJSONObjectHelper.getObjectFromString(apiUser.getHeaderConfig(), Map.class));
                	}
                    req.setHeaderConfig(versionHeaderReq);
                    
                    versionUrlReq = null != apiUser.getUrlConfig() ? MultipleJSONObjectHelper.getObjectFromString(apiUser.getUrlConfig(), VersionUrlReq.class) : null;
                    if(!OPLUtils.isObjectNullOrEmpty(versionUrlReq) && OPLUtils.isObjectNullOrEmpty(versionUrlReq.getV2()) && !OPLUtils.isObjectNullOrEmpty(apiUser.getUrlConfig())) {
                    	log.info("V3 DETAILS NOT ONBOARD : orgId {}, apiUserId {} ",apiUser.getOrgId(),apiUser.getId());
                    	versionUrlReq = new VersionUrlReq();
                    	versionUrlReq.setV2(MultipleJSONObjectHelper.getObjectFromString(apiUser.getUrlConfig(), ApiUrlsRequest.class));
                    }
                    req.setUrlConfig(versionUrlReq);
                    
                    timeOutReq = null != apiUser.getTimeOutConfig() ? MultipleJSONObjectHelper.getObjectFromString(apiUser.getTimeOutConfig(), VersionTimeOutReq.class):null;
                    if(!OPLUtils.isObjectNullOrEmpty(timeOutReq) && OPLUtils.isObjectNullOrEmpty(timeOutReq.getV2())  && !OPLUtils.isObjectNullOrEmpty(apiUser.getTimeOutConfig())) {
                    	log.info("V3 DETAILS NOT ONBOARD : orgId {}, apiUserId {} ",apiUser.getOrgId(),apiUser.getId());
                    	timeOutReq = new VersionTimeOutReq();
                    	timeOutReq.setV2(MultipleJSONObjectHelper.getObjectFromString(apiUser.getTimeOutConfig(), ApiRequest.class));
                    }
                    req.setTimeOutConfig(timeOutReq);
                    if (null != internalOrg) {
                        req.setOplPrivateKey(internalOrg.getPrivateKey());
                    }
                    req.setPublicKey(apiUser.getPublicKey());
                } catch (RuntimeException | IOException e) {
                	log.error("EXCEPTION WHILE DETAILS : orgId {}, apiUserId {}" ,apiUser.getOrgId(),apiUser.getId());
                    throw new RuntimeException(e);
                }
                CommonUtils.apiMastersList.add(req);
            }
        });
    }

    public List<ApiMasterRequest> getApiMasters() throws CommonException{
        return CommonUtils.apiMastersList;
    }

    public ApiMasterRequest getApiMasterByOrgId(Long orgId) throws CommonException{
        return CommonUtils.apiMastersList.stream().filter(x ->x.getOrgId().equals(orgId)).findFirst().orElse(CommonUtils.emptyObject);
    }
}

