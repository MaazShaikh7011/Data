package com.opl.jns.bank.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.bank.service.domain.ApiAuditsReqResDetailV3;

public interface ApiAuditsReqResDetailRepositoryV3 extends JpaRepository<ApiAuditsReqResDetailV3,Long> {
	ApiAuditsReqResDetailV3 findFirstByLogIdOrderByIdDesc(Long id);
}
