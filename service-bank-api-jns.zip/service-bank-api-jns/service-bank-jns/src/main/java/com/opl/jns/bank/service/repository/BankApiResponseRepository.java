package com.opl.jns.bank.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.bank.service.domain.BankApiResponse;

public interface BankApiResponseRepository extends JpaRepository<BankApiResponse,Long>{

	BankApiResponse findByApiIdAndOrgId(Long apiId, Long orgId);

}
