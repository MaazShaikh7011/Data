package com.opl.jns.bank.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.bank.api.model.BankAllApisResProxy;
import com.opl.jns.bank.api.model.common.AccountHolderSelectionDetailsRequest;
import com.opl.jns.bank.service.service.BankApiAuditDetailsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/audit")
@Slf4j
public class BankApiAuditDetailsController {

	@Autowired
	private BankApiAuditDetailsService bankApiAuditDetailsService;

	
	/** 
	 * fetch verify otp response in bucket
	 * 
	 * @param AccountHolderSelectionDetailsRequest
	 * @return
	 */
	@PostMapping(value = "/fetchVerifyOtpResponse", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<VerifyOtpApiResponseV3> fetchVerifyOtpResponse(
			@RequestBody AccountHolderSelectionDetailsRequest accountHolderSelRequest) {
		try {
			VerifyOtpApiResponseV3 verifyOtpApiResponse = bankApiAuditDetailsService.fetchVerifyOtpResponse(accountHolderSelRequest);
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE FETCH VERIFY OTP RESPONSE ---" + accountHolderSelRequest.getUrn() + "---", e);
			return new ResponseEntity<>(
					new VerifyOtpApiResponseV3(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}
	
	/** 
	 * fetch all apis response by urn
	 * 
	 * @param urn
	 * @return
	 */
	@GetMapping(value = "/fetchAllApisResByAppId/{urn}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BankAllApisResProxy> fetchAllApisResByAppId(@PathVariable String urn) {
		try {
			BankAllApisResProxy allApisResProxy = bankApiAuditDetailsService.fetchAllApisRes(urn);
			return new ResponseEntity<>(allApisResProxy, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE FETCH FETCH ALL APIS RESPONSE ---" + urn + "---", e);
			return new ResponseEntity<>(
					new BankAllApisResProxy(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

}
