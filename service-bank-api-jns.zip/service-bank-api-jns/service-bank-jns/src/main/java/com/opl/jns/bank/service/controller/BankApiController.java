package com.opl.jns.bank.service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsRequest;
import com.opl.jns.api.proxy.banks.v2.getCustomerDetails.CustomerDetailsDataV2;
import com.opl.jns.api.proxy.banks.v2.physicalVerification.PhysicalVerificationRequestV2;
import com.opl.jns.api.proxy.banks.v2.physicalVerification.PhysicalVerificationResponseV2;
import com.opl.jns.api.proxy.banks.v2.premiumDeduction.PremiumDeductionResponseV2;
import com.opl.jns.api.proxy.banks.v2.triggerOtp.TriggerOtpRequestV2;
import com.opl.jns.api.proxy.banks.v2.triggerOtp.TriggerOtpResponseV2;
import com.opl.jns.api.proxy.banks.v2.verifyOtp.OTPRequestV2;
import com.opl.jns.api.proxy.banks.v2.verifyOtp.VerifyOtpApiResponseV2;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionRequestV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.OTPRequestV3;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.bank.service.service.FactoryService;
import com.opl.jns.bank.service.utils.CommonUtils;
import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.config.PhaseMode;
import com.opl.jns.utils.enums.VersionMaster;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1")
@Slf4j
public class BankApiController {

	private static VersionMaster VERSION = VersionMaster.V2;

	@Autowired
	private FactoryService factoryService;

	@GetMapping("/pingService")
	@SkipInterceptor
	public String ping() {
		return " working ";
	}

	private String generateRef() {
		return "BANK_API_" + OPLUtils.generateUUID();
	}

	@PostMapping(value = "/triggerOTP", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> triggerOTP(@Valid @RequestBody TriggerOtpRequestV2 triggerOtpRequest,
			HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START TRIGGER OTP ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(triggerOtpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new TriggerOtpResponseV2(HttpStatus.BAD_REQUEST.value(), "ORG ID is null or empty", false),
						HttpStatus.OK);
			}
			if (PhaseMode.checkPhase2(triggerOtpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new TriggerOtpResponseV2(HttpStatus.BAD_REQUEST.value(), CommonUtils.PHASE_2_MSG, false),
						HttpStatus.OK);
			}
			triggerOtpRequest.setToken(null);
			Object triggerOtpResponse = factoryService.triggerOtp(triggerOtpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, triggerOtpRequest.getUrn(),
					triggerOtpRequest.getAccountNumber());

			log.info("END TRIGGER OTP ----------------> " + generateRef);
			return new ResponseEntity<>(triggerOtpResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE TRIGGER OTP ---" + generateRef + "---", e);
			return new ResponseEntity<>(
					new TriggerOtpResponseV2(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}
	}

	@PostMapping(value = "/verifyOtp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> verifyOtp(@Valid @RequestBody OTPRequestV2 otpRequest,
			HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START VERIFY OTP ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new VerifyOtpApiResponseV2(HttpStatus.BAD_REQUEST.value(), "ORG ID is null or empty", false),
						HttpStatus.OK);
			}
			if (PhaseMode.checkPhase2(otpRequest.getOrgId())) {
				return new ResponseEntity<>(
						new VerifyOtpApiResponseV2(HttpStatus.BAD_REQUEST.value(), CommonUtils.PHASE_2_MSG, false),
						HttpStatus.OK);
			}
			otpRequest.setToken(null);
			Object verifyOtpApiResponse = factoryService.varifyOtp(otpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, otpRequest.getUrn(),
					otpRequest.getAccountNumber());
			log.info("END VERIFY OTP ----------------> " + generateRef);
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE VERIFY OTP ---" + generateRef + "---", e);
			return new ResponseEntity<>(new VerifyOtpApiResponseV2(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/getCustomerDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getCustomerDetails(
			@Valid @RequestBody CustomerDetailsRequest custDtlsReq, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START GET CUSTOMER DETAILS ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(custDtlsReq.getOrgId())) {
				return new ResponseEntity<>(
						new CustomerDetailsDataV2(HttpStatus.BAD_REQUEST.value(), "ORG ID is null or empty", false),
						HttpStatus.OK);
			}
			if (PhaseMode.checkPhase2(custDtlsReq.getOrgId())) {
				return new ResponseEntity<>(
						new CustomerDetailsDataV2(HttpStatus.BAD_REQUEST.value(), CommonUtils.PHASE_2_MSG, false),
						HttpStatus.OK);
			}
			custDtlsReq.setToken(null);
			Object customerDetailsResponse = factoryService.getCustomerDetails(custDtlsReq,
					authClientResponse.getUserId(), generateRef, VERSION, custDtlsReq.getUrn(),
					custDtlsReq.getAccountNumber());
			log.info("END GET CUSTOMER DETAILS ----------------> " + generateRef);
			return new ResponseEntity<>(customerDetailsResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET CUSTOMER DETAILS --- " + generateRef + "---", e);
			return new ResponseEntity<>(
					new CustomerDetailsDataV2(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage(), false),
					HttpStatus.OK);
		}

	}

	@PostMapping(value = "/getPremiumDeduction", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getPremiumDeduction(
			@Valid @RequestBody PremiumDeductionRequestV3 premDeducReq, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START PREMIUM DEDUCTION REQUEST ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(premDeducReq.getOrgId())) {
				return new ResponseEntity<>(new PremiumDeductionResponseV2(HttpStatus.BAD_REQUEST.value(),
						"ORG ID is null or empty", false), HttpStatus.OK);
			}
			if (PhaseMode.checkPhase2(premDeducReq.getOrgId())) {
				return new ResponseEntity<>(
						new PremiumDeductionResponseV2(HttpStatus.BAD_REQUEST.value(), CommonUtils.PHASE_2_MSG, false),
						HttpStatus.OK);
			}
			premDeducReq.setToken(null);
			Object premiumDeductionResponse = factoryService.getPremiumDeduction(premDeducReq,
					authClientResponse.getUserId(), generateRef, VERSION, premDeducReq.getUrn(),
					premDeducReq.getCustomerAccountNumber());
			log.info("END PREMIUM DEDUCTION REQUEST ----------------> " + generateRef);
			return new ResponseEntity<>(premiumDeductionResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE PREMIUM DEDUCTION REQUEST ---" + generateRef + "---", e);
			return new ResponseEntity<>(new PremiumDeductionResponseV2(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/verifyPhysicalSignature", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getPhysicalVerification(
			@Valid @RequestBody PhysicalVerificationRequestV2 otpRequest, HttpServletRequest httpServletRequest,
			@RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
		String generateRef = generateRef();
		log.info("START VERIFY PHYSICAL SIGNATURE ----------------> " + generateRef);
		try {
			if (OPLUtils.isObjectNullOrEmpty(otpRequest.getOrgId())) {
				return new ResponseEntity<>(new PhysicalVerificationResponseV2(HttpStatus.BAD_REQUEST.value(),
						"ORG ID is null or empty", false), HttpStatus.OK);
			}
			if (PhaseMode.checkPhase2(otpRequest.getOrgId())) {
				return new ResponseEntity<>(new PhysicalVerificationResponseV2(HttpStatus.BAD_REQUEST.value(),
						CommonUtils.PHASE_2_MSG, false), HttpStatus.OK);
			}
			otpRequest.setToken(null);
			Object verifyOtpApiResponse = factoryService.getPhysicalVerification(otpRequest,
					authClientResponse.getUserId(), generateRef, VERSION, otpRequest.getUrn(),
					otpRequest.getAccountNumber());
			log.info("END VERIFY PHYSICAL SIGNATURE----------------> " + generateRef);
			return new ResponseEntity<>(verifyOtpApiResponse, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EXCEPTION WHILE VERIFY PHYSICAL SIGNATURE REQUEST  ---" + generateRef + "---", e);
			return new ResponseEntity<>(new PhysicalVerificationResponseV2(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					e.getLocalizedMessage(), false), HttpStatus.OK);
		}
	}
}
