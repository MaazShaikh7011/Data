package com.opl.jns.bank.service.utils;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequestFactory;

import com.opl.jns.api.proxy.banks.v1.getCustomerDetails.CustomerDetailsBankRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.AccountHolderDetailsV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsDataV3;
import com.opl.jns.api.proxy.banks.v3.getCustomerDetails.CustomerDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.getPolicyDetails.PolicyDetailsResponseV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationRequestV3;
import com.opl.jns.api.proxy.banks.v3.physicalVerification.PhysicalVerificationResponseV3;
import com.opl.jns.api.proxy.banks.v3.premiumDeduction.PremiumDeductionResponseV3;
import com.opl.jns.api.proxy.banks.v3.tiggerOtp.TriggerOtpResponseV3;
import com.opl.jns.api.proxy.banks.v3.verifyOtp.VerifyOtpApiResponseV3;
import com.opl.jns.api.proxy.common.CommonException;
import com.opl.jns.api.proxy.common.CommonRequest;
import com.opl.jns.api.proxy.common.MainResponse;
import com.opl.jns.bank.service.service.HttpUtility;
import com.opl.jns.bank.service.service.ManageRequestBankWise;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.VersionMaster;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class APIAbsractLayer implements ManageRequestBankWise {

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T triggerOtpRequest(HttpUtility httpUtility,
			U triggerOtpReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {
		log.info("START TRIGGER OTP REQUEST "
				+ CommonUtils.printLogs(triggerOtpReq.getOrgId(), CommonUtils.OTP_API_ID, referenceId));
		TriggerOtpResponseV3 triggerOtpRes = new TriggerOtpResponseV3();
		Long orgId = triggerOtpReq.getOrgId();
		Long applicationId = triggerOtpReq.getApplicationId();
		triggerOtpReq.setOrgId(null);
		triggerOtpReq.setApplicationId(null);
		return (T) httpUtility.post(triggerOtpReq, orgId, applicationId, CommonUtils.OTP_API_ID, userId, triggerOtpRes,
				referenceId, urn, accNo, additionalHeaders, requestFactory, triggerOtpReq.getToken(), master);
	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T verifyOtpRequest(HttpUtility httpUtility, U otpRequest,
			Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {
		log.info("START VERIFY OTP REQUEST "
				+ CommonUtils.printLogs(otpRequest.getOrgId(), CommonUtils.VERIFY_API_ID, referenceId));
		VerifyOtpApiResponseV3 verifyOtpApiRes = new VerifyOtpApiResponseV3();
		Long orgId = otpRequest.getOrgId();
		Long applicationId = otpRequest.getApplicationId();
		otpRequest.setOrgId(null);
		otpRequest.setApplicationId(null);
		return (T) httpUtility.post(otpRequest, orgId, applicationId, CommonUtils.VERIFY_API_ID, userId,
				verifyOtpApiRes, referenceId, urn, accNo, additionalHeaders, requestFactory, otpRequest.getToken(),
				master);
	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequest(HttpUtility httpUtility,
			U custDetailsReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {
		log.info("START GET CUSTOMER DETAILS REQUEST "
				+ CommonUtils.printLogs(custDetailsReq.getOrgId(), CommonUtils.CUSTOMER_DETAIL_API_ID, referenceId));
		Long orgId = custDetailsReq.getOrgId();
		Long applicationId = custDetailsReq.getApplicationId();
		custDetailsReq.setOrgId(null);
		custDetailsReq.setApplicationId(null);
		CustomerDetailsResponseV3 custDetailsRes = new CustomerDetailsResponseV3();
		custDetailsRes = httpUtility.post(custDetailsReq, orgId, applicationId, CommonUtils.CUSTOMER_DETAIL_API_ID,
				userId, custDetailsRes, referenceId, urn, accNo, additionalHeaders, requestFactory,
				custDetailsReq.getToken(), master);

		CustomerDetailsDataV3 detailResp = new CustomerDetailsDataV3();
		BeanUtils.copyProperties(custDetailsRes, detailResp);

		if (Boolean.TRUE
				.equals(!OPLUtils.isObjectNullOrEmpty(custDetailsRes.getFlag()) && custDetailsRes.getFlag()
						&& !OPLUtils.isObjectNullOrEmpty(custDetailsRes.getStatus()))
				&& custDetailsRes.getStatus() == HttpStatus.OK.value()) {
			AccountHolderDetailsV3 accDtl = custDetailsRes.getAccountHolderDetails();
			if (!OPLUtils.isObjectNullOrEmpty(accDtl)) {
				AccountHolderDetailsResponseV3 res = new AccountHolderDetailsResponseV3();
				BeanUtils.copyProperties(accDtl, res);
				try {
					detailResp = CommonUtils.setAccountHolderDtl(accDtl, res, detailResp, orgId);
				} catch (Exception e) {
					detailResp.setMessage(
							"It seems the application encounter error while getting account holder details from bank API response, please try after some time");
					detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					log.error("Exception while converting account holder details -->", e);
				}
			} else {
				detailResp.setMessage(
						"Its seems we have not found customer details from CBS, Please attempt the operation again after some time");
				detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}
		return (T) detailResp;
	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T customerDetailsRequestV3(HttpUtility httpUtility,
			U custDetailsReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {

		log.info("START GET CUSTOMER DETAILS REQUEST "
				+ CommonUtils.printLogs(custDetailsReq.getOrgId(), CommonUtils.CUSTOMER_DETAIL_API_ID, referenceId));

		CustomerDetailsBankRequest custDetailsBankReq = new CustomerDetailsBankRequest();
		BeanUtils.copyProperties(custDetailsReq, custDetailsBankReq);

		CustomerDetailsResponseV3 custDetailsRes = new CustomerDetailsResponseV3();
		Long orgId = custDetailsReq.getOrgId();
		Long applicationId = custDetailsReq.getApplicationId();
		custDetailsReq.setOrgId(null);
		custDetailsReq.setApplicationId(null);
		custDetailsRes = httpUtility.post(custDetailsBankReq, orgId, applicationId, CommonUtils.CUSTOMER_DETAIL_API_ID,
				userId, custDetailsRes, referenceId, urn, accNo, additionalHeaders, requestFactory,
				custDetailsReq.getToken(), master);

		CustomerDetailsDataV3 detailResp = new CustomerDetailsDataV3();
		BeanUtils.copyProperties(custDetailsRes, detailResp);

		if (Boolean.TRUE
				.equals(!OPLUtils.isObjectNullOrEmpty(custDetailsRes.getSuccess()) && custDetailsRes.getSuccess()
						&& !OPLUtils.isObjectNullOrEmpty(custDetailsRes.getStatus()))
				&& custDetailsRes.getStatus() == HttpStatus.OK.value()) {
			AccountHolderDetailsV3 accDtl = custDetailsRes.getAccountHolderDetails();
			if (!OPLUtils.isObjectNullOrEmpty(accDtl)) {
				AccountHolderDetailsResponseV3 res = new AccountHolderDetailsResponseV3();
				BeanUtils.copyProperties(accDtl, res);
				try {
					detailResp = CommonUtils.setAccountHolderDtlV3(accDtl, res, detailResp, orgId);
				} catch (Exception e) {
					detailResp.setMessage(
							"It seems the application encounter error while getting account holder details from bank API response, please try after some time");
					detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					log.error("Exception while converting account holder details -->", e);
				}
			} else {
				detailResp.setMessage(
						"Its seems we have not found customer details from CBS, Please attempt the operation again after some time");
				detailResp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}
		return (T) detailResp;
	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T premiumDeductionRequest(HttpUtility httpUtility,
			U premDeducReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {
		log.info("START PREMIUM DEDUCT REQUEST "
				+ CommonUtils.printLogs(premDeducReq.getOrgId(), CommonUtils.PREMIUM_DEDUCT_API_ID, referenceId));
		PremiumDeductionResponseV3 premDeductRes = new PremiumDeductionResponseV3();
		Long orgId = premDeducReq.getOrgId();
		Long applicationId = premDeducReq.getApplicationId();
		premDeducReq.setOrgId(null);
		premDeducReq.setApplicationId(null);
		return (T) httpUtility.post(premDeducReq, orgId, applicationId, CommonUtils.PREMIUM_DEDUCT_API_ID, userId,
				premDeductRes, referenceId, urn, accNo, additionalHeaders, requestFactory, premDeducReq.getToken(),
				master);
	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T getPhysicalVerification(HttpUtility httpUtility,
			U phyVrfReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {
		log.info("START PHYSICAL VERIFICATION REQUEST "
				+ CommonUtils.printLogs(phyVrfReq.getOrgId(), CommonUtils.PHYSICAL_VERIFICATION_API_ID, referenceId));
		PhysicalVerificationResponseV3 physclVrfyRes = new PhysicalVerificationResponseV3();
		PhysicalVerificationRequestV3 bankReq = new PhysicalVerificationRequestV3();
		BeanUtils.copyProperties(phyVrfReq, bankReq);
		Long orgId = phyVrfReq.getOrgId();
		Long applicationId = phyVrfReq.getApplicationId();
		bankReq.setOrgId(null);
		bankReq.setApplicationId(null);
		return (T) httpUtility.post(bankReq, orgId, applicationId, CommonUtils.PHYSICAL_VERIFICATION_API_ID, userId,
				physclVrfyRes, referenceId, urn, accNo, additionalHeaders, requestFactory, phyVrfReq.getToken(),
				master);

	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T getAccHolderList(HttpUtility httpUtility,
			U accHolderListReq, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {

		log.info("START GET ACCOUNT HOLDER LIST REQUEST " + CommonUtils.printLogs(accHolderListReq.getOrgId(),
				CommonUtils.GET_ACCOUNT_HOLDER_LIST_ID, referenceId));

		AccHolderListResponseV3 accHolderListResponse = new AccHolderListResponseV3();

		Long orgId = accHolderListReq.getOrgId();
		Long applicationId = accHolderListReq.getApplicationId();
		accHolderListReq.setOrgId(null);
		accHolderListReq.setApplicationId(null);
		return (T) httpUtility.post(accHolderListReq, orgId, applicationId, CommonUtils.GET_ACCOUNT_HOLDER_LIST_ID,
				userId, accHolderListResponse, referenceId, urn, accNo, additionalHeaders, requestFactory,
				accHolderListReq.getToken(), master);

	}

	@SuppressWarnings("unchecked")
	public <T extends MainResponse, U extends CommonRequest> T getPolicyDetails(HttpUtility httpUtility,
			U policyDetailsRequest, Long userId, String referenceId, Map<String, String> additionalHeaders,
			ClientHttpRequestFactory requestFactory, VersionMaster master, String urn, String accNo)
			throws CommonException, IOException {

		log.info("START GET POLICY DETAILS REQUEST " + CommonUtils.printLogs(policyDetailsRequest.getOrgId(),
				CommonUtils.GET_POLICY_DETAILS_ID, referenceId));

		PolicyDetailsResponseV3 policyDetailsResponse = new PolicyDetailsResponseV3();
		Long orgId = policyDetailsRequest.getOrgId();
		Long applicationId = policyDetailsRequest.getApplicationId();
		policyDetailsRequest.setOrgId(null);
		policyDetailsRequest.setApplicationId(null);

		PolicyDetailsResponseV3 detailsResponse = httpUtility.post(policyDetailsRequest, orgId, applicationId,
				CommonUtils.GET_POLICY_DETAILS_ID, userId, policyDetailsResponse, referenceId, urn, accNo,
				additionalHeaders, requestFactory, policyDetailsRequest.getToken(), master);
		log.info("START GET POLICY DETAILS RESPONSE ----------------> " + detailsResponse);
		return (T) detailsResponse;

	}

}
