package com.opl.jns.publishinsurance.client;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.internal.PullPushRequest;
import com.opl.jns.publishinsurance.api.internal.PushPullResponse;



public class PublishedClient {

    private static Logger logger = LoggerFactory.getLogger(PublishedClient.class);

    private String baseUrlStr;
    private static final String IS_DECRYPT = "isDecrypt";
    private static final String PUSHPULL = "/jns/internal/pushData";
    private static final String PUSH_STORAGE_ID = "/push/v3/pushStorageId/";

    private static final String PUSH_APPLICATION = "/push/v3/enrollment/";
    
    private RestTemplate restTemplate;

    public PublishedClient(String baseUrl) {
        this.baseUrlStr = baseUrl;
        restTemplate = new RestTemplate();
    }

    public static void setClient(HttpHeaders headers) {
        headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.set(IS_DECRYPT, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("req_auth", "true");
        headers.setContentType(MediaType.APPLICATION_JSON);
    }

    public PushPullResponse pushApiClient(PullPushRequest pullPushRequest) {
        String url = baseUrlStr.concat(PUSHPULL);
        logger.info("Enter in calling  Trigget OTP Api -------------------->{}", url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("req_auth", "true");
            headers.set(IS_DECRYPT, "true");
            setClient(headers);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<PullPushRequest> entity = new HttpEntity<>(pullPushRequest,headers);
            return restTemplate.exchange(url, HttpMethod.POST, entity, PushPullResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Exception While calling  Trigget OTP Api :: ", e);
            return null;
        }
    }
    public CommonResponse pushStorageId(Long applicationId, Long storageId) {
        String url = baseUrlStr.concat(PUSH_STORAGE_ID) + applicationId + "/" +  storageId;
        logger.info("Enter in calling  pushStorageId Api -------------------->{}", url);
        try {
            HttpHeaders headers = new HttpHeaders();
            setClient(headers);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<PullPushRequest> entity = new HttpEntity<>(null,headers);
            return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Exception While calling  Trigget OTP Api :: ", e);
            return null;
        }
    }

    public CommonResponse pushApplication(Long applicationId) {
        String url = baseUrlStr.concat(PUSH_APPLICATION) + applicationId ;
        logger.info("Enter in calling  Push Application Api -------------------->{}", url);
        try {
            HttpHeaders headers = new HttpHeaders();
            setClient(headers);
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<PullPushRequest> entity = new HttpEntity<>(null,headers);
            return restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
        } catch (Exception e) {
            logger.error("Exception While calling  Trigget OTP Api :: ", e);
            return null;
        }
    }
}
