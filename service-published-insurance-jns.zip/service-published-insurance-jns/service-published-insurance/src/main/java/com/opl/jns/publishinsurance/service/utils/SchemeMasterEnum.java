package com.opl.jns.publishinsurance.service.utils;

public enum SchemeMasterEnum {
	ALL_SCHEME(-1L, -1L, "All Scheme", "All", -1),
	PMSBY(1L, 1L, "Pradhan Mantri Suraksha Bima Yojana", "PMSBY", 1),
	PMJJBY(2L, 1L, "Pradhan Mantri Jeevan Jyoti Bima Yojana", "PMJJBY", 1);

	private final Long id;
	private final Long loanMasterId;
	private final String name;
	private final String shortName;
	private final Integer bussinessTypeId;

	private SchemeMasterEnum(Long id, Long loanMasterId, String name, String shortName, Integer bussinessTypeId) {
		this.id = id;
		this.loanMasterId = loanMasterId;
		this.name = name;
		this.shortName = shortName;
		this.bussinessTypeId = bussinessTypeId;
	}

	public Long getId() {
		return id;
	}


	public String getName() {
		return name;
	}

	public String getShortName() {
		return shortName;
	}


	public static SchemeMasterEnum getById(Long v) {
		for (SchemeMasterEnum c : SchemeMasterEnum.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}
	public static SchemeMasterEnum getByCode(String v) {
		for (SchemeMasterEnum c : SchemeMasterEnum.values()) {
			if (c.shortName.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

	public static SchemeMasterEnum[] getAll() {
		return SchemeMasterEnum.values();
	}

	public Long getLoanMasterId() {
		return loanMasterId;
	}

	public Integer getBussinessTypeId() {
		return bussinessTypeId;
	}


}
