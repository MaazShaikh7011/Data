package com.opl.jns.publishinsurance.service.utils;

import com.amazonaws.util.IOUtils;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequestV3;
import com.opl.jns.api.proxy.common.pushClaim.Document;
import com.opl.jns.api.proxy.common.pushEnrollment.CoiDocumentDetailsProxy;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.enums.EnrollPushType;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDocs;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.webhook.client.WebHookClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * PUSH ENROLLMENT AND CLAIM DATA IN TO WEBHOOK
 * 
 * @author maulik.panchal
 * @date 29-Feb-2024
 */
@Slf4j
@Component
public class BankAndInsurerPushDataUtils {

	@Autowired
	private DMSService dmsService;

	@Autowired
	private WebHookClient webHookClient;

	@Autowired
	private UsersClient usersClient;
	
	@Autowired
	private UserManagementClient userManagementClient;
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;
//
//	@Autowired
//	private OrgWiseSQSProducer producer;
//
	@Autowired
	private EreCommonService ereCommonService;
	
	/**
	 * PUSH ENROLLMENT DATA BANK AND INSURER
	 * 
	 * @param appMaster
	 * @return
	 */

	public boolean pushEnrollmentDataBankAndInsurer(ApplicationMasterV3 appMaster,ApplicationPushStatus applicationPushStatus, boolean  isManual) {
		try {

			PushEnrollmentDetailsRequestV3 pushDataReq = new PushEnrollmentDetailsRequestV3();

			/** SET APPLICATION MASTER DETAILS */
			pushDataReq = GetSetUtils.setAppMstDtl(pushDataReq, appMaster);

			/** SET APPLICANT INFO DETAILS */
			pushDataReq = GetSetUtils.setApplicantInfoDtl(pushDataReq, appMaster.getApplicantInfo());

			/** SET APPLICATION MASTER OTHER DETAILS */
			pushDataReq = GetSetUtils.setOtherDtl(pushDataReq, appMaster.getApplicationMasterOtherDetails());

			/** SET TRANSACTION DETAILS */
			pushDataReq = GetSetUtils.setTransactionDtl(pushDataReq, appMaster.getLastTransactionDetails());

			/** SET NOMINEE DETAILS */
			pushDataReq = GetSetUtils.setNomineeDtl(pushDataReq, appMaster.getNomineeDetails());

			/** SET GUARDIAN DETAILS */
			pushDataReq = GetSetUtils.setGuardianDtl(pushDataReq, appMaster.getNomineeDetails());

			/** SET COI */
			if(PublishApiUtils.isSqsFlagEnabled()) {
				if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails())
						&& !OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoiStorageId())) {
					pushDataReq.setStorageId(appMaster.getLastTransactionDetails().getCoiStorageId());
				}
			}else{
				pushDataReq.setCOI(setCOI(appMaster));
			}

			/** CALL WEBHOOK FOR PUSH DATA BANK AND INSURER */
			callEnrollmentWebhook(appMaster, pushDataReq,applicationPushStatus,isManual);

			return true;
		} catch (Exception e) {

			// ------------------------------- HANDLE EXCEPTION ---------------------------
			log.info("Exception while enrollment webhook call and set data : ", e);
			return false;
		}
	}

	private CoiDocumentDetailsProxy setCOI(ApplicationMasterV3 applicationMst) {
		if (!OPLUtils.isObjectNullOrEmpty(applicationMst.getLastTransactionDetails())
				&& !OPLUtils.isObjectNullOrEmpty(applicationMst.getLastTransactionDetails().getCoiStorageId())) {
			InputStreamResource inputStreamResource = dmsService
					.downloadDocumentByProductDocumentId(applicationMst.getLastTransactionDetails().getCoiStorageId());
			if (inputStreamResource != null) {
				try {
					InputStream inputStream = inputStreamResource.getInputStream();
					byte[] bytes = IOUtils.toByteArray(inputStream);
					CoiDocumentDetailsProxy coiDocumentDetailsProxy = new CoiDocumentDetailsProxy();
					coiDocumentDetailsProxy.setDocumentType("coi");
					coiDocumentDetailsProxy.setContentType("pdf");
					coiDocumentDetailsProxy.setDocument(bytes);
					return coiDocumentDetailsProxy;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	private void callEnrollmentWebhook(ApplicationMasterV3 masterV3,
			PushEnrollmentDetailsRequestV3 pushDataReq,ApplicationPushStatus applicationPushStatus,boolean isManual) throws IOException {

		/* CALL WEBHOOK FOR PUSH ENROLLMENT DATA BANK */
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getBankPush()) || Boolean.FALSE.equals(applicationPushStatus.getBankPush())) {
			log.info("isPushEnrollmentCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isPushEnrollmentCall(pushDataReq.getOrgId(), masterV3.getApplicationMasterOtherDetails().getSource()),masterV3.getId());
			log.info("isBankCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isBankCall(pushDataReq.getOrgId(), masterV3.getApplicationMasterOtherDetails().getSource()),masterV3.getId());
			log.info("isSkipToUpdatePushEnrollBank ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isSkipToUpdatePushEnrollBank(pushDataReq.getOrgId()),masterV3.getId());
			
			if(OPLUtils.isPushEnrollmentCall(pushDataReq.getOrgId(), masterV3.getApplicationMasterOtherDetails().getSource()) && OPLUtils.isBankCall(pushDataReq.getOrgId(), masterV3.getApplicationMasterOtherDetails().getSource())) {
 				pushDataReq.setFailureCount(0);
				boolean isEnabled =  PublishApiUtils.isSqsFlagEnabled();
				log.info("isEnabled ===> {}",isEnabled);
//				if(PublishApiUtils.isSqsFlagEnabled() && !isManual){  // sqs call
//					String token= CommonUtils.generateToken(pushDataReq.getOrgId());
//					String generateRef = "WH_API_"+token;
//					pushDataReq.setToken(token);
//					pushDataReq.setReferenceId(generateRef);
//					String request = MultipleJSONObjectHelper.getStringfromObject(pushDataReq);
//					producer.produceByOrg(request,pushDataReq.getOrgId());
//				 }else{
					 webHookClient.pushEnrollmentWithURL(pushDataReq, PublishApiUtils.getWebHookURL(true,masterV3.getOrgId(),masterV3.getInsurerOrgId()));  //client call
//				 }
			}else if(OPLUtils.isSkipToUpdatePushEnrollBank(pushDataReq.getOrgId())) {
				ereCommonService.updateEnrollPushStatus(EnrollPushType.BANK_PUSH, masterV3.getId(), true, new Date());
			}
		}

		/* CALL WEBHOOK FOR PUSH ENROLLMENT DATA INSURER */
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getInsurerPush()) || Boolean.FALSE.equals(applicationPushStatus.getInsurerPush())) {
			log.info("isPushEnrollmentCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isPushEnrollmentCall(masterV3.getInsurerOrgId(), masterV3.getApplicationMasterOtherDetails().getSource()),masterV3.getId());
			log.info("isSkipToUpdatePushEnrollBank ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isSkipToUpdatePushEnrollBank(masterV3.getInsurerOrgId()),masterV3.getId());
			if(OPLUtils.isPushEnrollmentCall(masterV3.getInsurerOrgId(), masterV3.getApplicationMasterOtherDetails().getSource())) {
				String token= CommonUtils.generateToken(masterV3.getInsurerOrgId());
				String generateRef = "WH_API_"+token;
				pushDataReq.setToken(token);
				pushDataReq.setReferenceId(generateRef);
				pushDataReq.setOrgId(masterV3.getInsurerOrgId());
				pushDataReq.setIsInsurer(true);
				pushDataReq.setFailureCount(0);
//				if(PublishApiUtils.isSqsFlagEnabled() && !isManual){
//					String request = MultipleJSONObjectHelper.getStringfromObject(pushDataReq);
//					producer.produceByOrg(request,masterV3.getInsurerOrgId());
//				}else{
					webHookClient.pushEnrollmentWithURL(pushDataReq, PublishApiUtils.getWebHookURL(false,masterV3.getOrgId(),masterV3.getInsurerOrgId())); //client call
//				}
			}else if(OPLUtils.isSkipToUpdatePushEnrollBank(masterV3.getInsurerOrgId())) {
				ereCommonService.updateEnrollPushStatus(EnrollPushType.INSURER_PUSH, masterV3.getId(), true, new Date());
			}
		}
	}


	/**
	 * PUSH CLAIM DATA BANK AND INSURER
	 * 
	 * @return
	 */

	public Boolean pushClaimDataBankAndInsurer(ClmMaster clmMaster, String masterPolicyNo,PUBClaimMaster pubClaimMst) {
		try {

			PushClaimDetailsRequestV3 pushDataReq = new PushClaimDetailsRequestV3();

			/**SET ENROLLMENT DETAILS*/
			String organizationName = usersClient.getOrganizationName(clmMaster.getOrgId());
			BranchAndOrgDetailsProxy orgDetls = userManagementClient.getOrganisationDetails(clmMaster.getOrgId(), clmMaster.getBranchId(), clmMaster.getInsurerOrgId());
			pushDataReq = GetSetUtils.setEnrollmentDetails(pushDataReq, clmMaster, masterPolicyNo, organizationName,orgDetls);

			/**SET NOMINEE DETAILS*/
			pushDataReq = GetSetUtils.setNomineeDetails(pushDataReq, clmMaster);

			/**SET GUARDIAN DETAILS*/
			pushDataReq = GetSetUtils.setGuardianDetails(pushDataReq, clmMaster);

			/**SET CLAIMANT DETAILS*/
			pushDataReq = GetSetUtils.setClaimantDetails(pushDataReq, clmMaster);

			/**SET CLAIM DETAILS*/
			pushDataReq = GetSetUtils.setClaimDetails(pushDataReq, clmMaster);
			
			/**SET CLAIM UPLOADED DOCUMENTS*/
			List<Document> claimUploadedDocuments = getClaimUploadedDocuments(clmMaster.getId(), pubClaimMst.getClaimDocs(), clmMaster.getOrgId());
			pushDataReq.setDocuments(claimUploadedDocuments);
			
			/** CALL CLAIM WEBHOOK FOR PUSH DATA BANK AND INSURER */
			callClaimWebhook(clmMaster, pushDataReq);

			return true;
		} catch (Exception e) {

			// ------------------------------- HANDLE EXCEPTION ---------------------------
			log.info("Exception while claim webhook call and set data : ", e);
		}
		return false;
	}

	private List<Document> getClaimUploadedDocuments(Long claimRefId, List<PUBClaimDocs> docLst,Long orgId) {
		List<Document> documentLst = new ArrayList<>();
		log.info("....Entry in getUploadedDocumentDetails()....");
		if (!OPLUtils.isListNullOrEmpty(docLst)) {
			docLst.stream().filter(x->x.getIsActive()).forEach(documents -> {
				Document document = new Document();
				BeanUtils.copyProperties(documents, document);
				document.setDocumentType(documents.getDocumentType());
				document.setDocumentId(documents.getMasterId());
				document.setContentType("pdf");					
					InputStreamResource inputStreamResource = dmsService
							.downloadDocumentByProductDocumentId(documents.getDmsId());
					if (inputStreamResource != null) {
						try {
							InputStream inputStream = inputStreamResource.getInputStream();
							byte[] bytes = IOUtils.toByteArray(inputStream);
							document.setDocument(bytes);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				documentLst.add(document);
			});
		}
		log.info("....Exit from getUploadedDocumentDetails()....");
		return documentLst;
	}
	
	private void callClaimWebhook(ClmMaster clmMaster,PushClaimDetailsRequestV3 pushDataReq) throws IOException {
		
		/** CALL WEBHOOK FOR PUSH CLAIM DATA INSURER */
		if (OPLUtils.isObjectNullOrEmpty(clmMaster.getIsInsurerClaimPush()) || Boolean.FALSE.equals(clmMaster.getIsInsurerClaimPush())) {			
			pushDataReq.setOrgId(clmMaster.getInsurerOrgId());
			pushDataReq.setIsInsurer(true);
			webHookClient.claimPush(pushDataReq);
		}
		
		/** CALL WEBHOOK FOR PUSH CLAIM DATA BANK */
		if (OPLUtils.isObjectNullOrEmpty(clmMaster.getIsBankClaimPush()) || Boolean.FALSE.equals(clmMaster.getIsBankClaimPush())) {			
			pushDataReq.setOrgId(clmMaster.getOrgId());
			log.info("isPushClaimCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isPushClaimCall(pushDataReq.getOrgId(),clmMaster.getSource()),clmMaster.getApplicationId());
			log.info("isBankCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isBankCall(pushDataReq.getOrgId(),clmMaster.getSource()),clmMaster.getApplicationId());
			if(OPLUtils.isPushClaimCall(pushDataReq.getOrgId(),clmMaster.getSource()) && OPLUtils.isBankCall(pushDataReq.getOrgId(),clmMaster.getSource())) {
				if(!OPLUtils.isSetClaimDocumentByte(pushDataReq.getOrgId())) {	
					pushDataReq.getDocuments().stream().forEach(x->x.setDocument(null));
				}
				pushDataReq.setIsInsurer(null);
				webHookClient.claimPush(pushDataReq);
			}else {
				clmMasterRepository.updateClaimBankFlagAndModified(new Date(), clmMaster.getId(), true);
			}
		}
	}

//	public void testSqs(String test,Long orgId){
//		producer.produceByOrg(test,orgId);
//	}



//	public void sqsLoadTesting(int count){
//		log.info("START of push sqs load testing : {}",count);
//		for (int i = 0; i <= count; i++) {
//			System.out.println("calling time of "+i);
//			Long appId = Long.valueOf(i) + 1L ;
//			sqsLoadTestingPreparation(appId);
//		}
//		log.info("END of push sqs load testing");
//	}
//
//	@Async
//	public void sqsLoadTestingPreparation(Long applicationId){
//		List<Long> bankOrgList = new ArrayList<>();
//		bankOrgList.add(1L);
//		bankOrgList.add(4L);
//		bankOrgList.add(12L);
//		bankOrgList.add(13L);
//		bankOrgList.add(14L);
//		bankOrgList.add(16L);
//		bankOrgList.add(17L);
//		bankOrgList.add(18L);
//		bankOrgList.add(19L);
//		bankOrgList.add(20L);
//		bankOrgList.add(25L);
//		bankOrgList.add(27L);
//		bankOrgList.add(28L);
//		bankOrgList.add(32L);
//
//		List<Long> insurerOrgList = new ArrayList<>();
//		insurerOrgList.add(188L);
//		insurerOrgList.add(189L);
//		insurerOrgList.add(196L);
//		insurerOrgList.add(199L);
//		insurerOrgList.add(200L);
//		insurerOrgList.add(201L);
//		insurerOrgList.add(208L);
//		insurerOrgList.add(210L);
//		insurerOrgList.add(217L);
//		insurerOrgList.add(219L);
//		insurerOrgList.add(220L);
//		insurerOrgList.add(226L);
//		insurerOrgList.add(236L);
//		insurerOrgList.add(237L);
//		insurerOrgList.add(238L);
//
//
//		PushEnrollmentDetailsRequestV3 pushDataReq = new PushEnrollmentDetailsRequestV3();
//
//		for(Long bankOrg:bankOrgList) {
//			log.info("calling sqs for applicationId [{}]",applicationId);
//			pushDataReq.setCommonUserId(3403l);
//			pushDataReq.setStorageId(16360l);
//			pushDataReq.setApplicationId(applicationId);
//			pushDataReq.setFailureCount(0);
//			pushDataReq.setOrgId(bankOrg);
//			String token= CommonUtils.generateToken(bankOrg);
//			String generateRef = "WH_API_"+token;
//			pushDataReq.setToken(token);
//			pushDataReq.setReferenceId(generateRef);
//			pushDataReq.setOrgId(bankOrg);
//			pushDataReq.setIsInsurer(false);
//			pushDataReq.setFailureCount(0);
//			try {
//				String request = MultipleJSONObjectHelper.getStringfromObject(pushDataReq);
//				producer.produceByOrg(request, bankOrg);
//			}catch (Exception e){
//				e.printStackTrace();
//			}
//			applicationId = applicationId + 1;
//		}
//
//		System.out.println("============================================================");
//		System.out.println(applicationId);
//		System.out.println("============================================================");
//
//
//
//		pushDataReq = new PushEnrollmentDetailsRequestV3();
//		for(Long insurer:insurerOrgList) {
//			log.info("calling sqs for applicationId [{}]",applicationId);
//			pushDataReq.setCommonUserId(3403l);
//			pushDataReq.setStorageId(16360l);
//			pushDataReq.setApplicationId(applicationId);
//			pushDataReq.setOrgId(insurer);
//			pushDataReq.setIsInsurer(true);
//			pushDataReq.setFailureCount(0);
//			String token= CommonUtils.generateToken(insurer);
//			String generateRef = "WH_API_"+token;
//			pushDataReq.setToken(token);
//			pushDataReq.setReferenceId(generateRef);
//			pushDataReq.setOrgId(insurer);
//			pushDataReq.setFailureCount(0);
//			try {
//				String request = MultipleJSONObjectHelper.getStringfromObject(pushDataReq);
//				producer.produceByOrg(request, insurer);
//			}catch (Exception e){
//				e.printStackTrace();
//			}
//			applicationId = applicationId + 1;
//		}
//	}

}


