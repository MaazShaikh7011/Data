package com.opl.jns.publishinsurance.service.repository.internal.impl;

import com.opl.jns.publishinsurance.service.repository.internal.*;
import com.opl.jns.utils.common.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import jakarta.persistence.*;
import java.sql.*;

@Repository
@Slf4j
public class pushDataRepositoryImpl implements pushDataRepository {

	 @Qualifier("emFR")
	 @Autowired
	 EntityManager entityManager;
	
	 
	   @Override
	    public String fetchPublishedAppList(String query) {
	        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
	    }
	    
	    @Override
	    public String fetchAppCount(String query) {
	        return (String) entityManager.createNativeQuery(query).getSingleResult();
	    }
	    
	@Override
    public String fetchPublishedClaimList(String query) {
        return OPLUtils.readClob((Clob) entityManager.createNativeQuery(query).getSingleResult());
    }
    
    @Override
    public String fetchClaimCount(String query) {
        return (String) entityManager.createNativeQuery(query).getSingleResult();
    }
    
 
}
