package com.opl.jns.publishinsurance.service.service.internal.impl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.insurance.published.v1.BankInsurerPushProxy;
import com.opl.jns.publishinsurance.service.service.internal.PushBankInsurerService;
import com.opl.jns.utils.enums.ClaimStageMaster;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.enums.UserTypeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * @author MaulikPanchal
 *
 */

@Transactional
@Service
@Slf4j
public class PushBankInsurerServiceImpl extends BankAndInsurerPushAbstract implements PushBankInsurerService {

	@Autowired
	private ClmMasterRepository clmMasterRepository;

	@Autowired
	private ApplicationPushStatusRepo applicationPushStatusRepo;

	/**
	 * ENROLLMENT DATA PUSH
	 */
	@Override
	public void pushBankInsurerEnrolmentData(BankInsurerPushProxy proxy,boolean isManualPush) throws Exception {
		log.info("ENTER IN PUSH ENROLLMENT DATA --->");
		
		/** CHECK ENROLLMENT DATA BANK INSURER PUSH OR NOT */
		List<Long> isBankInsurerPushPendingApp = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingApp = applicationPushStatusRepo
					.findAllByBankInsurerPushNull(proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.INSURER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {				
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByPMSBYInsurerPushNullAndOrgId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByPMJJBYInsurerPushNullAndOrgId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}else if(proxy.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {				
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByPMSBYBankPushNullAndOrgId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByPMJJBYBankPushNullAndOrgId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}
			
		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingApp)) {
			log.info("TOTAL PUSH ENROLLMENT APPLICATION ID LIST ---> {} -------> LIST LENGTH ----> {}",isBankInsurerPushPendingApp,isBankInsurerPushPendingApp.size());
			this.pushEnrollmentBankInsurer(isBankInsurerPushPendingApp,false);
		}else {
			log.info("NO PENDING RECORD FOUND FOR PUSH ENROLLMENT --->");
		}
		log.info("EXIT IN PUSH ENROLLMENT DATA --->");
	}

	/**
	 * ENROLLMENT OPT OUT PUSH
	 */
	@Override
	public void pushBankInsurerOptOutData(BankInsurerPushProxy proxy) throws Exception {
		log.info("ENTER IN PUSH OPT OUT DATA --->");
		
		/** CHECK OPT OUT DATA BANK INSURER PUSH OR NOT */
		List<Long> isBankInsurerPushPendingApp = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingApp = applicationPushStatusRepo
					.findAllByBankInsurerOptOutPushNull(MiscellaneousType.OPT_OUT.getId(),proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.INSURER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByInsurerPMSBYOptOutPushNullAndOrgId(MiscellaneousType.OPT_OUT.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByInsurerPMJJBYOptOutPushNullAndOrgId(MiscellaneousType.OPT_OUT.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}else if(proxy.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByBankPMSBYOptOutPushNullAndOrgId(MiscellaneousType.OPT_OUT.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByBankPMJJBYOptOutPushNullAndOrgId(MiscellaneousType.OPT_OUT.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}
		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingApp)) {
			log.info("TOTAL OPT OUT APPLICATION ID LIST ---> {} LIST LENGTH ----> {}",isBankInsurerPushPendingApp,isBankInsurerPushPendingApp.size());
			this.pushOptOutBankInsurer(isBankInsurerPushPendingApp);
		}else {
			log.info("NO PENDING RECORD FOUND FOR OPT OUT --->");
		}
		log.info("EXIT IN PUSH OPT OUT DATA --->");
	}

	/**
	 * ENROLLMENT NOMINEE UPDATE PUSH
	 */
	@Override
	public void pushBankInsurerNomineeUpdateData(BankInsurerPushProxy proxy) throws Exception {
		log.info("ENTER IN PUSH NOMINEE UPDATE DATA --->");
		/** CHECK OPT OUT DATA BANK INSURER PUSH OR NOT */

		List<Long> isBankInsurerPushPendingApp = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingApp = applicationPushStatusRepo
					.findAllByBankInsurerNomineeUpdatePushNull(MiscellaneousType.NOMINEE_UPDATE.getId(),proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.INSURER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByInsurerPMSBYNomineeUpdatePushNullAndOrgId(MiscellaneousType.NOMINEE_UPDATE.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByInsurerPMJJBYNomineeUpdatePushNullAndOrgId(MiscellaneousType.NOMINEE_UPDATE.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}else if(proxy.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
			if(proxy.getSchemeId()==SchemeMaster.PMSBY.getId().intValue()) {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByBankPMSBYNomineeUpdatePushNullAndOrgId(MiscellaneousType.NOMINEE_UPDATE.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}else {
				isBankInsurerPushPendingApp = applicationPushStatusRepo
						.findAllByBankPMJJBYNomineeUpdatePushNullAndOrgId(MiscellaneousType.NOMINEE_UPDATE.getId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId());
			}
		}
		
		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingApp)) {
			log.info("TOTAL NOMINEE UPDATE APPLICATION ID LIST ---> {} LIST LENGTH ----> {}",isBankInsurerPushPendingApp,isBankInsurerPushPendingApp.size());
			this.pushNomineeUpdateBankInsurer(isBankInsurerPushPendingApp);
		}else {
			log.info("NO PENDING RECORD FOUND FOR NOMINEE UPDATE --->");
		}
		log.info("EXIT IN PUSH NOMINEE UPDATE DATA --->");
	}

	/**
	 * CLAIM DATA PUSH
	 */
	@Override
	public void pushBankInsurerClaimData(BankInsurerPushProxy proxy) throws Exception {
		log.info("ENTER IN CLAIM PUSH DATA --->");
		
		/** CHECK CLAIM BANK INSURER PUSH OR NOT */
		List<Long> isBankInsurerPushPendingClmId = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingClmId = clmMasterRepository.findAllByIsBankInsurerPushFlagNull(ClaimStageMaster.CLAIM_COMPLETED.getStageId(),proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.INSURER.getId()) {
			isBankInsurerPushPendingClmId = clmMasterRepository.findAllByIsInsurerPushFlagNullAndOrgIdAndSchemeId(ClaimStageMaster.CLAIM_COMPLETED.getStageId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId(),proxy.getSchemeId());
		}else if(proxy.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
			isBankInsurerPushPendingClmId = clmMasterRepository.findAllByIsBankPushFlagNullAndOrgIdAndSchemeId(ClaimStageMaster.CLAIM_COMPLETED.getStageId(),proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId(),proxy.getSchemeId());
		}

		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingClmId)) {
			log.info("TOTAL CLAIM PUSH CLAIM ID LIST ---> {} LIST LENGTH ----> {}",isBankInsurerPushPendingClmId,isBankInsurerPushPendingClmId.size());
			this.pushClaimBankInsurer(isBankInsurerPushPendingClmId);
		}else {
			log.info("NO PENDING RECORD FOUND FOR CLAIM PUSH --->");
		}
		log.info("EXIT IN CLAIM PUSH DATA --->");
	}

	/**
	 * INSURER CLAIM STATUS PUSH
	 */
	@Override
	public void pushInsurerClaimStatusData(BankInsurerPushProxy proxy) throws Exception {
		log.info("ENTER IN INSURER CLAIM STATUS PUSH DATA --->");
		/** CHECK CLAIM STATUS BANK INSURER PUSH OR NOT */
		List<Long> isBankInsurerPushPendingclmId = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingclmId = clmMasterRepository.findAllByIsInsurerStatusFlagNull(proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.INSURER.getId()) {
			isBankInsurerPushPendingclmId = clmMasterRepository.findAllByIsInsurerStatusFlagNullAndOrgIdAndSchemeId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId(),proxy.getSchemeId());
		}
		
		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingclmId)) {
			log.info("TOTAL INSURER CLAIM STATUS PUSH CLAIM ID LIST ---> {} LIST LENGTH ----> {}",isBankInsurerPushPendingclmId,isBankInsurerPushPendingclmId.size());
			this.pushClaimStatusInsurer(isBankInsurerPushPendingclmId);
		}else {
			log.info("NO PENDING RECORD FOUND FOR INSURER CLAIM STATUS PUSH --->");
		}
		log.info("EXIT IN INSURER CLAIM STATUS PUSH DATA --->");
	}
	
	/**
	 * BANK CLAIM STATUS PUSH
	 */
	@Override
	public void pushBankClaimStatusData(BankInsurerPushProxy proxy) throws Exception {
		log.info("ENTER IN BANK CLAIM STATUS PUSH DATA --->");
		/** CHECK CLAIM STATUS BANK INSURER PUSH OR NOT */
		List<Long> isBankInsurerPushPendingclmId = Collections.emptyList();
		if(proxy.getIsSchedular()) {			
			isBankInsurerPushPendingclmId = clmMasterRepository.findAllByIsBankStatusFlagNull(proxy.getFromDate(),proxy.getToDate());
		}else if(proxy.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
			isBankInsurerPushPendingclmId = clmMasterRepository.findAllByIsBankStatusAndOrgIdFlagNullAndOrgIdAndSchemeId(proxy.getFromDate(),proxy.getToDate(),proxy.getOrgId(),proxy.getSchemeId());
		}
		if (!OPLUtils.isListNullOrEmpty(isBankInsurerPushPendingclmId)) {
			log.info("TOTAL BANK CLAIM STATUS PUSH CLAIM ID LIST ---> {} LIST LENGTH ----> {}",isBankInsurerPushPendingclmId,isBankInsurerPushPendingclmId.size());
			this.pushClaimStatusBank(isBankInsurerPushPendingclmId);
		}else {
			log.info("NO PENDING RECORD FOUND FOR BANK CLAIM STATUS PUSH --->");
		}
		log.info("EXIT IN BANK CLAIM STATUS PUSH DATA --->");
	}
}
