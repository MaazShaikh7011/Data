package com.opl.jns.publishinsurance.service.service.publish.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.published.lib.domain.UserOrganizationMaster;
import com.opl.jns.published.lib.repository.UserOrganizationMasterRepository;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.repository.publish.PUBApplicationMasterRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimMasterRepo;
import com.opl.jns.publishinsurance.service.service.publish.ValidationService;
import com.opl.jns.publishinsurance.service.utils.CommonUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ValidationServiceImpl implements ValidationService {

    @Autowired
    PUBApplicationMasterRepo applicationMasterRepository;

    @Autowired
    PUBClaimMasterRepo claimMasterPublishedRepo;

    @Autowired
    UserOrganizationMasterRepository organizationMasterRepo;

    @Override
    public Map<String, Object> isValidUser(HttpServletRequest request, Long applicationRefId,Long claimRefId) {
        // check skip
        Map<String, Object> map = checkForSkipHeader(request);

        if(request.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID) != null && request.getAttribute(APIAuthUtils.REQ_ATR_APP_USER_ID) != null) {
            Long appOrgId = null ;
            Long userOrgId = Long.valueOf(request.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID).toString());
            UserOrganizationMaster orgMst = organizationMasterRepo.findByOrgIdAndIsActiveIsTrue(userOrgId);
            if(!OPLUtils.isObjectNullOrEmpty(orgMst)){
                PUBApplicationMaster master = null;
                if(OPLUtils.isObjectNullOrEmpty(claimRefId)) {
                    master = getPubApplicationMasterForEnrollment(applicationRefId, userOrgId, orgMst, master);
                }else {
                    master = getPubApplicationMasterForClaim(claimRefId, userOrgId, orgMst, master);
                }
                if (orgMst.getOrgType().equals(CommonUtils.ORG_TYPE_INSURER)) {
                    appOrgId = getInsurerOrgIdEnrollment(master);
                } else if (orgMst.getOrgType().equals(CommonUtils.ORG_TYPE_BANK)) {
                    appOrgId = getBankOrgIdEnrollment(master);
                }


                if(!OPLUtils.isObjectNullOrEmpty(master)){
                    map.put("applicationId", master.getApplicationId());
                }
                map.put("claimRefId", claimRefId);
            }

            if (OPLUtils.isObjectNullOrEmpty(appOrgId)) {
                log.error("Org id not found for " + userOrgId + " in proposal details");
                map.put(Constants.STATUS, Boolean.FALSE);
                return map;
            }
            if (!userOrgId.equals(appOrgId)) {
                log.error("Invalid org id userOrgId=" + userOrgId + " requestApplicationOrgId=" + appOrgId);
                map.put(Constants.STATUS, Boolean.FALSE);
                return map;
            }

            map.put("applicationRefId", applicationRefId);
            map.put(Constants.STATUS, Boolean.TRUE);
            return map;
        }
        log.error("Org id not found for application reference Id: [{}]",applicationRefId);
        map.put(Constants.STATUS, Boolean.FALSE);
        return map;
    }

    private static Map<String, Object> checkForSkipHeader(HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();
        String skipEnc = request.getHeader(APIAuthUtils.REQ_HEADER_ENCRYPTION_SKIP);
        if (skipEnc != null && skipEnc.equals("true")) {
            map.put(Constants.STATUS, Boolean.TRUE);
        }
        return map;
    }

    private PUBApplicationMaster getPubApplicationMasterForClaim(Long claimRefId, Long userOrgId, UserOrganizationMaster orgMst, PUBApplicationMaster master) {
        PUBClaimMaster clmMaster = null;
        if (Objects.equals(orgMst.getOrgType(), CommonUtils.ORG_TYPE_BANK)) { // 1 - bank
            clmMaster = claimMasterPublishedRepo.findByIdAndApplicationMasterOrgIdAndIsActiveTrue(claimRefId, userOrgId);
        } else if (Objects.equals(orgMst.getOrgType(), CommonUtils.ORG_TYPE_INSURER)) { // 3 - insurer
            clmMaster = claimMasterPublishedRepo.findByIdAndIsActiveTrueAndApplicationMasterInsurerOrgId(claimRefId, userOrgId);
        }

        if(!OPLUtils.isObjectNullOrEmpty(clmMaster)){
            master = clmMaster.getApplicationMaster();
        }
        return master;
    }

    private PUBApplicationMaster getPubApplicationMasterForEnrollment(Long applicationRefId, Long userOrgId, UserOrganizationMaster orgMst, PUBApplicationMaster master) {
        if (orgMst.getOrgType() == Constants.LONG_1) { // 1 - bank
            master = applicationMasterRepository.findByIdAndOrgIdAndIsActiveTrue(applicationRefId, userOrgId);
        } else if (orgMst.getOrgType() == Constants.LONG_3) { // 3 - insurer
            master = applicationMasterRepository.findByIdAndInsurerOrgIdAndIsActiveTrue(applicationRefId, userOrgId);
        }
        return master;
    }

    private Long getBankOrgIdEnrollment(PUBApplicationMaster master){
        if(!OPLUtils.isObjectNullOrEmpty(master)){
            return  master.getOrgId();
        }
        return null;
    }


    private Long getInsurerOrgIdEnrollment(PUBApplicationMaster master){
        if(!OPLUtils.isObjectNullOrEmpty(master)){
            return  master.getInsurerOrgId();
        }
        return null;
    }

}
