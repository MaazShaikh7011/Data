package com.opl.jns.publishinsurance.service.service.internal.impl;

import com.amazonaws.*;
import com.amazonaws.services.s3.*;
import com.amazonaws.services.s3.model.*;
import com.opl.jns.publishinsurance.service.domain.internal.*;
import com.opl.jns.publishinsurance.service.repository.internal.*;
import com.opl.jns.publishinsurance.service.service.internal.*;

import org.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.core.env.*;
import org.springframework.core.io.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class DMSServiceImpl implements DMSService {

    private static final Logger logger = LoggerFactory.getLogger(DMSServiceImpl.class);

    @Autowired
    private AmazonS3 amzonS3;

    @Autowired
    private ProductStorageRepository productStorageRepository;

    @Autowired
    private Environment environment;

    protected static final String PROPERTY_NAME_BUCKET_NAME = "cw.aws.config.bucketName";
    protected static final String PROPERTY_NAME_S3_FOLDER_NAME = "cw.aws.config.folderName";


    public InputStreamResource downloadDocumentByProductDocumentMappingId(Long applicationId, Long productDocumentMappingId, List<Long> coApplicantIds) {
        String encryptedFileName = productStorageRepository.getEncryptedFileNameFromApplicationId(applicationId, productDocumentMappingId, coApplicantIds);
        logger.info("encryptedFileName ::: {}" ,encryptedFileName);
        return getByEncryptedFileName(encryptedFileName);
    }

    public InputStreamResource getByEncryptedFileName(String encryptedFileName){
        S3Object s3object = null;
        try {
        	logger.info(":::::::::::::::::::::::::::::::::   Start getByEncryptedFileName:::::::::::::::::::::::::::::::::");
            logger.info("encryptedFileName :::{}",encryptedFileName);
            s3object = amzonS3.getObject(new GetObjectRequest(environment.getProperty(PROPERTY_NAME_BUCKET_NAME), environment.getProperty(PROPERTY_NAME_S3_FOLDER_NAME) + encryptedFileName));
            logger.info(":::::::::::::::::::::::::::::::::   end getByEncryptedFileName:::::::::::::::::::::::::::::::::");
            return new InputStreamResource(s3object.getObjectContent());
        } catch (AmazonServiceException ase) {
            logger.error("Caught an AmazonServiceException from GET requests, rejected reasons:");
            logger.error("Error Message: {}" ,ase.getMessage());
            logger.error("HTTP Status Code: {}" ,ase.getStatusCode());
            logger.error("AWS Error Code: {}" ,ase.getErrorCode());
            logger.error("Error Type: {}" ,ase.getErrorType());
            logger.error("Request ID: {}" ,ase.getRequestId());
            return null;
        } catch (AmazonClientException ace) {
            logger.error("Caught an AmazonClientException: ");
            logger.error("Error Message: {}" ,ace.getMessage());
            return null;
        }

    }

    public InputStreamResource downloadDocumentByProductDocumentId(Long id) {
        String encryptedFileName = productStorageRepository.getEncryptedFileNameFromId(id);
        logger.info("encryptedFileName :: : {}" , encryptedFileName);
        return getByEncryptedFileName(encryptedFileName);
    }

    public List<ProductStorageDetailsV3> getDocumentList(Long applicationId) {
        return productStorageRepository.getListByApplicationIdAndIsActive(applicationId, true);
    }

    public List<ProductStorageDetailsV3> getDocumentList(Long applicationId, Long profileId, List<Long> moduleMasterIds) {
    	
    if(Boolean.FALSE.equals(productStorageRepository.existsByApplicationIdAndProductDocumentMappingId(applicationId, 740l))){
  		  logger.info("Application Form not Available:::{}", applicationId );
  		  return Collections.emptyList();
    	}

  	if(Boolean.FALSE.equals(productStorageRepository.existsByApplicationIdAndProductDocumentMappingId(applicationId, 678l))){
		  logger.info("Cam report not Available:::{}", applicationId );
		  return Collections.emptyList();
		}
    	
        List<ProductStorageDetailsV3> productStorageDetailsList = getDocumentList(applicationId);
        List<ProductStorageDetailsV3> productStorageDetailsAll = new ArrayList<>();
//        if (moduleMasterIds != null && !moduleMasterIds.isEmpty()) {
//            List<ProductStorageDetailsV3> productStorageDetails = productStorageRepository.getListByProfileIdAndModuleMasterIdAndIsActive(profileId, moduleMasterIds, true);
//            if(productStorageDetails!=null){
//                productStorageDetailsAll.addAll(productStorageDetails);
//            }
//        }
        if(productStorageDetailsList!=null){
            productStorageDetailsAll.addAll(productStorageDetailsList);
        }
        return productStorageDetailsAll;
    }

}
