package com.opl.jns.publishinsurance.service.service.publish.impl;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ClaimDetailsProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList.ClaimProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.DocumentDetailsProxy1_1;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.UploadedDocumentsDetailsProxy1_1;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;

import com.amazonaws.util.IOUtils;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.published.lib.domain.UserOrganizationMaster;
import com.opl.jns.published.lib.repository.UserOrganizationMasterRepository;
import com.opl.jns.published.lib.service.PublishedLibService;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.domain.publish.PUBAddressMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicantInfo;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDetail;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDocs;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBNomineeDetails;
import com.opl.jns.publishinsurance.service.domain.publish.PUBTransactionDetails;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimDocsRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimMasterRepo;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.publishinsurance.service.service.internal.PushService;
import com.opl.jns.publishinsurance.service.service.publish.ClaimService;
import com.opl.jns.publishinsurance.service.service.publish.CommonService;
import com.opl.jns.publishinsurance.service.utils.CommonUtils;
import com.opl.jns.publishinsurance.service.utils.PublishApiUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 5/6/2023
 */
@Service
@Slf4j
public class ClaimServiceImpl implements ClaimService {


	@Autowired
	PUBClaimMasterRepo pubClaimMasterRepo;
	
    @Autowired
	PUBClaimDocsRepo pubClaimDocsRepo;

    @Autowired
	UserOrganizationMasterRepository userOrganizationMasterRepository;
    @Autowired
	PushService pushService;
    @Autowired
	DMSService dmsService;
    @Autowired
    CommonService commonService;

	@Autowired
	PublishedLibService publishedLibService;

    @Override
    public List<ClaimProxy> getClaimApplicationListForPush(LocalDateTime fromDateStr, LocalDateTime toDateStr, Long userOrgId) throws Exception {

        Date fromDate = Date.from(fromDateStr.atZone(ZoneId.systemDefault()).toInstant());
        Date toDate = Date.from(toDateStr.atZone(ZoneId.systemDefault()).toInstant());

        List<PUBClaimMaster> masterList = Collections.emptyList();
        if (!com.opl.jns.published.utils.common.OPLUtils.isObjectNullOrEmpty(userOrgId)) {
            /** check here first if logged in org is for insurer */
            UserOrganizationMaster orgMaster = userOrganizationMasterRepository.findByOrgIdAndIsActiveIsTrue(userOrgId);
            if(!OPLUtils.isObjectNullOrEmpty(orgMaster)) {
                if (orgMaster.getOrgType().equals(CommonUtils.ORG_TYPE_INSURER)) {     /** if insurer then use below query */
                    masterList = pubClaimMasterRepo.findAllByApplicationMasterInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(userOrgId, fromDate, toDate);
                } else if (orgMaster.getOrgType().equals(CommonUtils.ORG_TYPE_BANK)) {  /** if bank then use below query */
                    masterList = pubClaimMasterRepo.findAllByApplicationMasterOrgIdAndIsActiveTrueAndPushReadyDateBetween(userOrgId, fromDate, toDate);
                } else {
                    return Collections.emptyList();
                }
            }
        } else {
            return Collections.emptyList();
        }
        List<ClaimProxy> responses = new ArrayList<>();
        masterList.forEach(master -> {
            ClaimProxy resp = new ClaimProxy();
            resp.setClaimReferenceId(master.getId());
            if (!OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster())) {
            	if (null != master.getApplicationMaster().getSchemeId()) {
            		resp.setSchemeId(master.getApplicationMaster().getSchemeId());
            		resp.setSchemeName(com.opl.jns.published.utils.enums.SchemeMaster.getById(master.getApplicationMaster().getSchemeId().longValue()).getName());
            	}
            	resp.setUrn(master.getApplicationMaster().getUrn());	
            }
            responses.add(resp);
        });

        return responses;
    }

    @Override
    public ClaimDetailsProxy getClaimApplicationDetails(Long applicationReferenceId) throws Exception {
        ClaimDetailsProxy response = new ClaimDetailsProxy();
        PUBClaimMaster master = pubClaimMasterRepo.findByIdAndIsActiveTrue(applicationReferenceId);
        if (!OPLUtils.isObjectNullOrEmpty(master)) {
            BeanUtils.copyProperties(master, response);
            response.setClaimReferenceId(applicationReferenceId);
            
            setClaimApplicantMasterData(master,response);
            
            setClaimApplicantInfoData(master, response);
            
            setClaimOtherDetails(master, response);
            
            setClaimNomineeDetails(master.getApplicationMaster(), response);
            
            setClaimTransactionData(master, response);
        }
		return response;
    }

    private void setClaimApplicantMasterData(PUBClaimMaster master, ClaimDetailsProxy response) {
    	try {
			if (!OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster())) {
				PUBApplicationMaster applicationMaster = master.getApplicationMaster();
				BeanUtils.copyProperties(applicationMaster, response);
				
				response.setSchemeId(applicationMaster.getSchemeId().longValue());
				response.setSchemeName(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
				response.setCustomerAccountNumber(applicationMaster.getAccountNumber());
				response.setDateOfEnrollment(applicationMaster.getEnrollmentDate());
				
			    String branchNameResponse = PublishApiUtils.getBranchName(applicationMaster.getBranchId());
		        if(null != branchNameResponse) {
		        	response.setBranchName(branchNameResponse);
		        }
			    response.setBankCode(PublishApiUtils.getOrganizationCode(applicationMaster.getOrgId()));
				response.setCustomerBankname(PublishApiUtils.getOrganizationName(applicationMaster.getOrgId()));
				response.setClaimantBank(PublishApiUtils.getOrganizationName(applicationMaster.getOrgId()));

			}
		} catch (Exception e) {
			log.error(Constants.ERROR_WHILE_SET_CLAIM_APPLICANT_MASTER_DATA,e);
		}
    }
    
    private void setClaimApplicantInfoData(PUBClaimMaster master, ClaimDetailsProxy response) {
		if (!OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster()) && !OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster().getApplicantInfo())) {
			PUBApplicantInfo applicantInfo = master.getApplicationMaster().getApplicantInfo();
			BeanUtils.copyProperties(applicantInfo, response);

			response.setCustomerIFSC(applicantInfo.getIfsc());
			response.setAccountHolderName(applicantInfo.getName());
			if (!OPLUtils.isObjectNullOrEmpty(applicantInfo.getGenderId())) {
				response.setGender(Gender.fromId(applicantInfo.getGenderId()).getBankValue());
			}
			response.setEmailID(applicantInfo.getEmail());
			response.setKycID1(applicantInfo.getKycId1());
			response.setKycID2(applicantInfo.getKycId2());
			response.setKycID1number(applicantInfo.getKycIdNumber1().toUpperCase());
			response.setKycID2number(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getKycIdNumber2()) ? applicantInfo.getKycIdNumber2().toUpperCase() : null);
			response.setAadhaar(OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar())?Boolean.FALSE:Boolean.TRUE);
			response.setPan(OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan())?Boolean.FALSE:Boolean.TRUE);
			response.setPanNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan()) ? applicantInfo.getPan().toUpperCase() : null);
			response.setAadhaarNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar()) ? applicantInfo.getAadhaar().toUpperCase() : null);

			//set claimant kyc details
			setKycDetailForClaimant(master, response, applicantInfo);

			//set claimant address info
			setClaimApplicantAddressDetails(applicantInfo, response);

		}
    }

	private static void setKycDetailForClaimant(PUBClaimMaster master, ClaimDetailsProxy response, PUBApplicantInfo applicantInfo) {
		boolean isCkycYes = OPLUtils.isObjectNullOrEmpty(applicantInfo.getCkyc()) ? Boolean.FALSE : (applicantInfo.getCkyc().equalsIgnoreCase("Yes") || applicantInfo.getCkyc().equalsIgnoreCase("Y"));
		response.setCkyc(isCkycYes);
		response.setCkycNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getCkycNumber()) ? applicantInfo.getCkycNumber().toUpperCase() : null);
		String[] strArray = null;
		if(!OPLUtils.isObjectNullOrEmpty(master.getClaimDetail().getKycDocId())) {
			 log.info("KYC ID----->"+master.getClaimDetail().getKycDocId());
			strArray = master.getClaimDetail().getKycDocId().split(",");
			response.setClaimantKYC1(KycDocument.fromId(Integer.valueOf(strArray[0].trim())).getValue());
			response.setClaimantKYCNumber1(!OPLUtils.isObjectNullOrEmpty(PublishApiUtils.getKycDocument(Integer.valueOf(strArray[0].trim()), master.getClaimDetail())) ? PublishApiUtils.getKycDocument(Integer.valueOf(strArray[0]), master.getClaimDetail()).toUpperCase() : null);


			if(strArray.length>1 && !OPLUtils.isObjectNullOrEmpty(strArray[1]) && !OPLUtils.isObjectNullOrEmpty(strArray[1].trim())) {

				response.setClaimantKYC2(!OPLUtils.isObjectNullOrEmpty(strArray[1]) ? KycDocument.fromId(Integer.valueOf(strArray[1].trim())).getValue() : null);
				response.setClaimantKycNumber2(!OPLUtils.isObjectNullOrEmpty(PublishApiUtils.getKycDocument(Integer.valueOf(strArray[1].trim()), master.getClaimDetail())) ? PublishApiUtils.getKycDocument(Integer.valueOf(strArray[1]), master.getClaimDetail()).toUpperCase() : null);
			}
		}
	}

	private void setClaimApplicantAddressDetails(PUBApplicantInfo applicantInfo, ClaimDetailsProxy response) {
        if(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
        	PUBAddressMaster addressDetails = applicantInfo.getAddress();
        	BeanUtils.copyProperties(addressDetails, response);
        
        	response.setAddressline1(addressDetails.getAddressLine1());
        	response.setAddressline2(addressDetails.getAddressLine2());
        	response.setCity(addressDetails.getCityName());
        	response.setState(addressDetails.getStateName());
        	response.setCityLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getCityLGDCode()) ? addressDetails.getCityLGDCode().toString() : null);
        	response.setStateLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getStateLGDCode()) ? addressDetails.getStateLGDCode().toString() : null);
        	response.setDistrictLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getDistrictLGDCode()) ? addressDetails.getDistrictLGDCode().toString() : null);
        }
    }
    
    private void setClaimNomineeDetails(PUBApplicationMaster applicationMst, ClaimDetailsProxy response) {
        List<PUBNomineeDetails> nomineeDetailsList = applicationMst.getNomineeDetails();
        
	    if(!OPLUtils.isListNullOrEmpty(nomineeDetailsList)) {
	     	List<PUBNomineeDetails> guardianDetailsList = nomineeDetailsList.stream().filter(a -> a.getType().equals(NomineeType.GUARDIAN.getId())).collect(Collectors.toList());
	     	List<PUBNomineeDetails> nomineeDetails= nomineeDetailsList.stream().filter(a -> a.getType().equals(NomineeType.NOMINEE.getId())).collect(Collectors.toList());
	     	List<PUBNomineeDetails> claimantDetails= nomineeDetailsList.stream().filter(a -> a.getType().equals(NomineeType.CLAIMANT.getId())).collect(Collectors.toList());

	     	// GUARDIAN DETAILS
			setGuardianDetailsForClaim(response, guardianDetailsList);

			//NOMINEE DETAILS
	     	if (!OPLUtils.isListNullOrEmpty(nomineeDetails)) {
	     		PUBNomineeDetails nominee = nomineeDetails.getFirst();
	     		response.setNomineeFirstName(!OPLUtils.isObjectNullOrEmpty(nominee.getFirstName()) ? nominee.getFirstName() : nominee.getName());
	     		response.setNomineeMiddleName(nominee.getMiddleName());
	     		response.setNomineeLastName(nominee.getLastName());
	     		response.setNomineeDateOfBirth(commonService.parseAndFormatDateUsing_sdf(nominee.getDob()));
	     		response.setNomineeMobileNumber(nominee.getMobileNumber());
	     		response.setNomineeEmailId(nominee.getEmail());
	     		response.setCorrectNomineeFirstName(nominee.getCorrectNomineeFirstName());
	     		response.setCorrectnomineeMiddleName(nominee.getCorrectNomineeMiddleName());
	     		response.setCorrectnomineeLastName(nominee.getCorrectNomineeLastName());
	     		if (nominee.getRelationId() != null) {
	     			response.setRelationOfNominee(RelationShip.fromId(nominee.getRelationId()).getValue());             			
	     		}
	     		if (!OPLUtils.isObjectNullOrEmpty(nominee.getAddress())) {
	     			PUBAddressMaster nomineeAddress = nominee.getAddress();
		     		response.setNomineeAddressline1(nominee.getAddress().getAddressLine1());
		     		response.setNomineeAddressline2(nominee.getAddress().getAddressLine2());
		     		response.setNomineePincode(!OPLUtils.isObjectNullOrEmpty(nomineeAddress.getPincode()) ? nomineeAddress.getPincode().toString() : null);
		     		response.setNomineeCity(nomineeAddress.getCityName());
		     		response.setNomineeCityLGDCode(nomineeAddress.getCityLGDCode() != null ? nomineeAddress.getCityLGDCode().toString() : null);
		     		response.setNomineeDistrict(nomineeAddress.getDistrict());
		     		response.setNomineeDistrictLGDCode(nomineeAddress.getDistrictLGDCode() != null ? nomineeAddress.getDistrictLGDCode().toString() : null);
		     		response.setNomineeState(nomineeAddress.getStateName());
		     		response.setNomineeStateLGDCode(nomineeAddress.getStateLGDCode() != null ? nomineeAddress.getStateLGDCode().toString() : null);
	     		}
	     	}
	     	
	     	// CLAIMANT DETAILS
	     	if (!OPLUtils.isListNullOrEmpty(claimantDetails)) {
	     		PUBNomineeDetails claimant = claimantDetails.getFirst();
	     		response.setClaimantFirstName(claimant.getFirstName());
	     		response.setClaimantMiddleName(claimant.getMiddleName());
	     		response.setClaimantLastName(claimant.getLastName());
	     		response.setClaimantDateOfBirth(commonService.parseAndFormatDateUsing_sdf(claimant.getDob()));
	     		response.setClaimantMobileNumber(claimant.getMobileNumber());
	     		if (claimant.getRelationId() != null) {
	     			response.setRelationOfClaimant(RelationShip.fromId(claimant.getRelationId()).getValue());        			
	     		}
	     	}
	     }   
    }

	private static void setGuardianDetailsForClaim(ClaimDetailsProxy response, List<PUBNomineeDetails> guardianDetailsList) {
		if (!OPLUtils.isListNullOrEmpty(guardianDetailsList)) {
			PUBNomineeDetails guardian = guardianDetailsList.getFirst();
			response.setNameofGuardian((guardian.getName()));
			response.setGuardianMobileNumber(guardian.getMobileNumber());
			response.setGuardianEmailId(guardian.getEmail());

			if (guardian.getRelationId() != null) {
				response.setRelationShipOfGuardian(RelationShip.fromId(guardian.getRelationId()).getValue());
			}
			if (!OPLUtils.isObjectNullOrEmpty(guardian.getAddress())) {
				response.setAddressOfGuardian(guardian.getAddress().getAddressLine1());
		   }
		}
	}

	private void setClaimOtherDetails(PUBClaimMaster master, ClaimDetailsProxy response) {
    	try {
			if (!OPLUtils.isObjectNullOrEmpty(master.getClaimDetail())) {
				PUBClaimDetail claimDetails = master.getClaimDetail();
				BeanUtils.copyProperties(claimDetails, response,"pan","aadhar");
				
				if (response.getSchemeId() != null) {
					if (response.getSchemeId().equals(com.opl.jns.published.utils.enums.SchemeMaster.PMSBY.getId())) {
						response.setCauseOfDeathDisability(claimDetails.getCauseOfDeathDisabilityName());
						response.setCauseOfDeath(null);
					} else if (response.getSchemeId().equals(com.opl.jns.published.utils.enums.SchemeMaster.PMJJBY.getId())) {
						response.setCauseOfDeath(claimDetails.getCauseOfDeathDisabilityName());
						response.setCauseOfDeathDisability(null);
					}					
				}
				response.setTypeOfDisability(claimDetails.getTypeOfDisablityName());
				response.setClaimantBankAccount(claimDetails.getClaimantBankAccountNumber());
				
				if (claimDetails.getDateTimeOfAccident() != null) {
					response.setDateOfAccident(CommonUtils.sdf.format(CommonUtils.sdf.parse(claimDetails.getDateTimeOfAccident())));
					response.setTimeOfAccident(CommonUtils.HH_mm_ss.format(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.parse(claimDetails.getDateTimeOfAccident())));
					response.setDayOfAccident(CommonUtils.day.format(CommonUtils.sdf.parse(claimDetails.getDateTimeOfAccident())));					
				}
	    		response.setPlaceOfAccident(claimDetails.getLocationOfLoss());
	    		response.setNatureOfAccident(claimDetails.getNatureOfLossName());
	    		response.setClaimantIFSC(claimDetails.getCustIfscCode());
			}
		} catch (Exception e) {
			log.error(Constants.ERROR_WHILE_SET_CLAIM_APPLICANT_MASTER_DATA,e);
		}
    }
    
    private void setClaimTransactionData(PUBClaimMaster master, ClaimDetailsProxy response) {
    	try {
			if (!OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster()) && !OPLUtils.isObjectNullOrEmpty(master.getApplicationMaster().getLastTransactionDetails())) {
				PUBTransactionDetails lastTransactionDetails = master.getApplicationMaster().getLastTransactionDetails();
				BeanUtils.copyProperties(lastTransactionDetails, response);
				
				response.setMasterPolicyNumber(lastTransactionDetails.getMasterPolicyNo());
				if(!OPLUtils.isObjectNullOrEmpty(lastTransactionDetails.getTransTimeStamp())) {					
					response.setPremDebitDate(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(lastTransactionDetails.getTransTimeStamp()));
					response.setPremRemitDate(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(lastTransactionDetails.getTransTimeStamp()));
				}
			}
		} catch (Exception e) {
			log.error(Constants.ERROR_WHILE_SET_CLAIM_APPLICANT_MASTER_DATA,e);
		}
    }

	@Override
    public UploadedDocumentsDetailsProxy1_1 getUploadedDocumentDetails(GetClaimDocumentRequest documentRequest, StringBuilder message) {
        log.info("....Entry in kcc getUploadedDocumentDetails()....");
        UploadedDocumentsDetailsProxy1_1 uploadedDocumentsDetailsProxy = new UploadedDocumentsDetailsProxy1_1();
		List<PUBClaimDocs> claimDocument = null;
		if (!OPLUtils.isObjectNullOrEmpty(documentRequest.getDocumentId()) && !documentRequest.getDocumentId().isEmpty()){
			claimDocument = pubClaimDocsRepo.findByClaimMasterIdAndIsActiveIsTrueAndMasterIdIn(documentRequest.getClaimReferenceId(),documentRequest.getDocumentId());
		}else {
			claimDocument = pubClaimDocsRepo.findByClaimMasterIdAndIsActiveIsTrue(documentRequest.getClaimReferenceId());
		}

        uploadedDocumentsDetailsProxy.setClaimReferenceId(documentRequest.getClaimReferenceId());
        List<DocumentDetailsProxy1_1> documentList = new ArrayList<>();

		if (!claimDocument.isEmpty() && !OPLUtils.isObjectNullOrEmpty(claimDocument.getFirst().getClaimMaster())
				&& (!OPLUtils.isObjectNullOrEmpty(claimDocument.getFirst().getClaimMaster().getApplicationMaster()))) {
        		uploadedDocumentsDetailsProxy.setUrn(claimDocument.getFirst().getClaimMaster().getApplicationMaster().getUrn());
        }
        
        if (!OPLUtils.isObjectNullOrEmpty(claimDocument) && !claimDocument.isEmpty()) {
        	claimDocument.forEach(documents -> {
                DocumentDetailsProxy1_1 documentDetailsProxy = new DocumentDetailsProxy1_1();
                BeanUtils.copyProperties(documents, documentDetailsProxy);
                documentDetailsProxy.setDocumentType(documents.getDocumentType());
                documentDetailsProxy.setDocumentId(documents.getMasterId());
                InputStreamResource inputStreamResource = dmsService.downloadDocumentByProductDocumentId(documents.getDmsId());
                if (inputStreamResource != null) {
                    try {
                        InputStream inputStream = inputStreamResource.getInputStream();
                        byte[] bytes = IOUtils.toByteArray(inputStream);
                        documentDetailsProxy.setDocument(bytes);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                documentDetailsProxy.setSuccess(Boolean.TRUE);
                documentDetailsProxy.setMessage("Document Available.");
                documentList.add(documentDetailsProxy);
            });
        } else {
            message.append("Document not found.Kindly try after sometime.");
        }
        uploadedDocumentsDetailsProxy.setDocumentList(documentList);
        log.info("....Exit from kcc getUploadedDocumentDetails()....");
        return uploadedDocumentsDetailsProxy;
    }

}
