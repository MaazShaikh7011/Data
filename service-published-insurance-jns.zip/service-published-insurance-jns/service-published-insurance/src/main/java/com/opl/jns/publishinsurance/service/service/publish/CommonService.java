package com.opl.jns.publishinsurance.service.service.publish;

import java.text.*;
import java.util.*;

public interface CommonService {
    public String parseAndFormatDateUsing_sdf(String dob);
}
