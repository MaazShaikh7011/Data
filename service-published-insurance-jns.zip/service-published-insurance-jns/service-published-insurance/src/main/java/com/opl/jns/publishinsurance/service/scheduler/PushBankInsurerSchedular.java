package com.opl.jns.publishinsurance.service.scheduler;

import java.util.Calendar;
import java.util.Date;

import com.opl.jns.published.lib.utils.EnvironmentUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.opl.jns.ere.domain.ExpSchedulerAudit;
import com.opl.jns.ere.enums.ExpSchedulerApiEnum;
import com.opl.jns.ere.repo.ExpSchedulerAuditRepo;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.publishinsurance.api.insurance.published.v1.BankInsurerPushProxy;
import com.opl.jns.publishinsurance.service.service.internal.PushBankInsurerService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PushBankInsurerSchedular {

	@Autowired
	PushBankInsurerService bankInsurerService;
	
	@Autowired
	ExpSchedulerAuditRepo expSchedulerAuditRepo;

	/**
	 * every night 10 PM
	 * 
	 * @throws Exception
	 */
	// 0 0 22 * * *
	@Scheduled(cron = "${bank.insurer.webhook.data.push.schedular}")
	public void pushBankInsurer() throws Exception {
		String value = EnvironmentUtils.PUSH_READY_SCHEDULER_ENABLE.getValue();
		 if ("ON".equalsIgnoreCase(value)) {
		log.info("BANK AND INSURER PUSH SCHEDULAR FOR PUSHING THE DATA =====> START AT :[{}]", new Date());
		
		String toDate = getToDate();
		String fromDate = getFromDate();
		log.info("FROMDATE =====> :[{}]", fromDate);
		log.info("TODATE =====> :[{}]", toDate);
		
		BankInsurerPushProxy proxy = new BankInsurerPushProxy();
		proxy.setFromDate(fromDate);
		proxy.setToDate(toDate);
		proxy.setIsSchedular(true);
		
		/**MAINTAIN AUDIT FOR PUSH FAIL APPLICATIONS*/
		Date currentDate = new Date();
		ExpSchedulerAudit audit = new ExpSchedulerAudit();
		audit.setStartDate(currentDate);
		audit.setStatus("Pending");
		audit.setApi(ExpSchedulerApiEnum.PUSH_FAIL_SCHEDULAR.getId());
		audit = expSchedulerAuditRepo.save(audit);

		/**
		 * ENROLLMENT DATA PUSH
		 */
		bankInsurerService.pushBankInsurerEnrolmentData(proxy,false);

		/**
		 * ENROLLMENT OPT OUT PUSH
		 */
		bankInsurerService.pushBankInsurerOptOutData(proxy);

		/**
		 * ENROLLMENT NOMINEE UPDATE PUSH
		 */
		bankInsurerService.pushBankInsurerNomineeUpdateData(proxy);

		/**
		 * CLAIM DATA PUSH
		 */
		bankInsurerService.pushBankInsurerClaimData(proxy);

		/**
		 * INSURER CLAIM STATUS PUSH
		 */
		bankInsurerService.pushInsurerClaimStatusData(proxy);

		/**
		 * BANK CLAIM STATUS PUSH
		 */
		bankInsurerService.pushBankClaimStatusData(proxy);
		
		/**UPDATE SCHEDULAR AUDIT*/
		audit.setCompleteDate(new Date());
		audit.setStatus("Completed");
		expSchedulerAuditRepo.save(audit).getId();
		log.info("BANK AND INSURER PUSH SCHEDULAR FOR PUSHING THE DATA =====> END AT :[{}]", new Date());
	}else {
			 log.info("BANK AND INSURER PUSH SCHEDULAR FOR PUSHING THE DATA ==="+value);
		 }

	}

	public String getFromDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_YEAR, -1);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 59);
		Date datedays = cal.getTime();
		return CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(datedays);
	}

	public String getToDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 59);
		Date datedays = cal.getTime();
		return CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(datedays);
	}
}
