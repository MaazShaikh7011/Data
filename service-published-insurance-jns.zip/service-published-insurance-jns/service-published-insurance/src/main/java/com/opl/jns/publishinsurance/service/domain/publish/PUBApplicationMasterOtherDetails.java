package com.opl.jns.publishinsurance.service.domain.publish;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "application_master_other_details")
public class PUBApplicationMasterOtherDetails {

	@Id
	@Column(name = "application_master_id")
	private Long id;
	@OneToOne(fetch = FetchType.LAZY)
	@MapsId
	@JoinColumn(name = "application_master_id")
	private PUBApplicationMaster applicationMaster;

	@Column(name = "source", nullable = true)
	private Integer source;

	@Column(name = "type_of_verification", nullable = true)
	private Integer typeOfVerification;

	@Column(name = "branch_ro_id", nullable = true)
	private Long branchRoId;

	@Column(name = "branch_zo_id", nullable = true)
	private Long branchZoId;

	@Column(name = "branch_lho_id", nullable = true)
	private Long branchLhoId;

	@Column(name = "branch_state_id", nullable = true)
	private Long branchStateId;

	@Column(name = "branch_city_id", nullable = true)
	private Long branchCityId;

	@Column(name = "consent_for_auto_debit", nullable = true)
	private String consentForAutoDebit;

	@Column(name = "rural_urban_semi", nullable = true)
	private String ruralUrbanSemi;
	
    @Column(name = "channel_id", nullable = true)
    private String channelId;

	@Column(name = "user_id_1",nullable = true)
	private String userId1;
	@Column(name = "user_id_2",nullable = true)
	private String userId2;
}
