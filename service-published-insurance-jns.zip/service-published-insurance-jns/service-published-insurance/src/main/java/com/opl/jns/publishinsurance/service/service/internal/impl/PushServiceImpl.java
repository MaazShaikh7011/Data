package com.opl.jns.publishinsurance.service.service.internal.impl;

import java.io.IOException;
import java.io.InputStream;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.IOUtils;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReqV3;
import com.opl.jns.api.proxy.insurer.UpdateDocQuery.ClaimStatusWebhook;
import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.UpdateAppClaimRequest;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmNomineeDetails;
import com.opl.jns.ere.domain.ClmNomineePIDetails;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.CauseOfDeathDisability;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.EnrollAndClaimPushType;
import com.opl.jns.ere.enums.EnrollPushType;
import com.opl.jns.ere.enums.EnrollTypeEnum;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.OrgType;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.utils.JnsNotificationMasterUtil;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.api.utils.SourceType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.config.PhaseMode;
import com.opl.jns.publishinsurance.api.PushPullException;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.domain.internal.ProductStorageDetailsV3;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDetail;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDocs;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBNomineeDetails;
import com.opl.jns.publishinsurance.service.domain.publish.PUBTransactionDetails;
import com.opl.jns.publishinsurance.service.repository.internal.ProductStorageRepository;
import com.opl.jns.publishinsurance.service.repository.publish.PUBApplicationMasterRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimMasterRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBNomineeDetailsRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBTransactionDetailsRepo;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.publishinsurance.service.service.internal.PushService;
import com.opl.jns.publishinsurance.service.utils.BankAndInsurerPushDataUtils;
import com.opl.jns.publishinsurance.service.utils.CommonUtils;
import com.opl.jns.publishinsurance.service.utils.GetSetUtils;
import com.opl.jns.publishinsurance.service.utils.MasterPushDataUtils;
import com.opl.jns.publishinsurance.service.utils.PublishApiUtils;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.SchemeMaster;
import com.opl.jns.utils.model.COIRequest;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

@Transactional
@Service
@Slf4j
public class PushServiceImpl implements PushService {


    /**
     * Platform Repositories
     */

    @Autowired
    private ApplicationMasterRepositoryV3 appMasterRepo;

    @Autowired
    private ClmMasterRepository clmMasterRepository;

    /**
     * PUBLISH API Repositories
     */
    @Autowired
    private ProductStorageRepository productStorageRepository;

    @Autowired
    private PUBApplicationMasterRepo pubAppMasterRepo;

    @Autowired
    private PUBNomineeDetailsRepo pubNomineeDtlRepo;
    @Autowired
    private PUBClaimMasterRepo pubClaimMasterRepo;

    @Autowired
    private NotificationClient notificationClient;

    @Autowired
    private DMSService dmsService;

    @Autowired
    private WebHookClient webHookClient;

    @Autowired
    private PUBTransactionDetailsRepo pubTransactionDetailsRepo;

    @Autowired
    private UserManagementClient userManagementClient;

    @Autowired
    private EreCommonService ereCommonService;

    @Autowired
    private PDFGenerateClient pdfGenerateClient;


    @Autowired
    private MasterPushDataUtils masterPushDataUtils;

    @Autowired
    private BankAndInsurerPushDataUtils bankAndInsurerPushDataUtils;

    @Autowired
    private ApplicationPushStatusRepo applicationPushStatusRepo;

    @Autowired
    private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;

    @Autowired
    private NomineePIDetailsRepository nomineePIDetailsRepository;

    @Autowired
    private AddressMasterRepositoryV2 addressMasterRepositoryV2;

    @Autowired
    private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

    @Async
    @Override
    public void pushEnrolmentData(long applicationId) throws Exception {
        Boolean isSuccess=Boolean.TRUE;
        try {
            log.info("ENTER IN PUSH ENROLLMENT DATA FOR APPLICATION_ID --->" + applicationId);

            ApplicationMasterV3 appMaster = appMasterRepo.findByIdAndIsActiveTrue(applicationId);
            if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
                isSuccess=Boolean.FALSE;
                log.info("EXIT IN PUSH ENROLLMENT DATA (NOT DATA FOUND BY APPLICATION ID) --->" + applicationId);
                // return new PushPullResponse(ENROLL.APP_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
            }
            // CHECK CURRENT ENROLLMENT JOURNEY IS COMPLAED OR NOT
            if (OPLUtils.isObjectNullOrEmpty(appMaster.getStageId()) || appMaster.getStageId() < 6) {
                log.info("EXIT IN PUSH ENROLLMENT DATA (JOURNEY IS NOT COMPLETED YET) --->" + applicationId);
                isSuccess=Boolean.FALSE;
                //return new PushPullResponse(ENROLL.APP_NOT_COMPLETED, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
            }
            // FETCH CUSTOMER/APPLICANT INFORMATION
            ApplicantInfo applicantInfo = appMaster.getApplicantInfo();// applicantInfoRepo.findByApplicationMasterId(applicationId);
            if (OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
                isSuccess=Boolean.FALSE;
                log.info("EXIT IN PUSH ENROLLMENT DATA (APPLICANT INFO IS NULL) --->" + applicationId);
                //return new PushPullResponse(ENROLL.APP_NOT_COMPLETED, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
            }
            if(isSuccess) {
            	//Off for Phase 2
               // Date curruntDate = publishData(applicationId, appMaster, applicantInfo);

                /**UPDATE INSURANCE IS PUSHED FLAG*/
                // ereCommonService.updateEnrollPushStatus(EnrollPushType.BANK_PUSH, appMaster.getId(), true, curruntDate);
//            appMasterRepo.updatePublishFlagAndModified(curruntDate, appMaster.getId());

                // push here to new table structure
                boolean isSavedToNewStructure = false;
                ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(appMaster.getId())
                        .orElse(null);
                if (!OPLUtils.isObjectNullOrEmpty(applicationPushStatus)) {
                    if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getMasterPush()) || Boolean.FALSE.equals(applicationPushStatus.getMasterPush())) {
                        isSavedToNewStructure = masterPushDataUtils.pushData(appMaster);
                    }
                }

                /**PUSH ENROLLMENT DATA BANK AND INSURER USING WEBHOOK*/
                if(PhaseMode.checkPhase2Enroll(appMaster.getOrgId())) {
                    if (!OPLUtils.isObjectNullOrEmpty(applicationPushStatus)) {
                        if ((OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getBankPush())
                                || Boolean.FALSE.equals(applicationPushStatus.getBankPush()))
                                || (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getInsurerPush())
                                || Boolean.FALSE.equals(applicationPushStatus.getInsurerPush()))) {
                            bankAndInsurerPushDataUtils.pushEnrollmentDataBankAndInsurer(appMaster,applicationPushStatus,true);
                        }
                    }
                }

                if(isSavedToNewStructure) {
                    // update flag
                    try {
                        ereCommonService.updateEnrollPushStatus(EnrollPushType.MASTER_PUSH, appMaster.getId(), true, new Date());
                        
                        /**INSERT INTO JNS_MASTER.APPLICATION_PUSH_STATUS*/
                        ereCommonService.insertEnrollAndClaimPushStatusInMaster(appMaster.getId(), true, EnrollAndClaimPushType.MASTER_PUSH.getId(), OrgType.BANK.getId(),  new Date());
                    }catch (Exception e) {
                        log.error("EXCEPTION WHILE MASTER PUSH FLAG UPDATE ---->", e);
                    }
                    log.info("Successfully Publish Data with App Master Is Pushed Flag Updated --->" + applicationId);
                }
            }else {
                log.error("Invalid Push Details, Kindly verfiy stage and data then try again.");
            }

            //return new PushPullResponse(ENROLL.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("EXCEPTION WHILE PUSH ENROLLMENT DETAILS ---->", e);
            //return new PushPullResponse(ENROLL.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }
    /**
     * This ids for publish data for remove V2
     * @param applicationId
     * @param appMaster
     * @param applicantInfo
     * @return
     */
    @Deprecated
    private Date publishData(long applicationId, ApplicationMasterV3 appMaster, ApplicantInfo applicantInfo) {
		// --------- START SAVING ENROLLMENT DATA IN API DATABASE -----------
		PUBApplicationMaster pubAppMaster = pubAppMasterRepo.findByApplicationIdAndIsActiveTrue(applicationId);
		pubAppMaster = GetSetUtils.setEnrollAppMaster(pubAppMaster, appMaster);

		BranchAndOrgDetailsProxy orgDetls = userManagementClient.getOrganisationDetails(appMaster.getOrgId(), appMaster.getBranchId(), appMaster.getInsurerOrgId());
		if (!OPLUtils.isObjectNullOrEmpty(orgDetls)) {
		    pubAppMaster.setOrgName(orgDetls.getBankName());
		    pubAppMaster.setInsurerOrgName(orgDetls.getInsurerName());
		    pubAppMaster.setBranchName(orgDetls.getBranchName());
		    pubAppMaster.setOrgCode(orgDetls.getBankCode());
		    pubAppMaster.setInsurerOrgCode(orgDetls.getInsurerCode());
		}

		// -------------------------- SET APPLICANT INFO ----------------------------
		pubAppMaster = GetSetUtils.setEnrollApplicant(pubAppMaster, applicantInfo);

		// -------------------------- SET TRANSACTION DETAILS -------------------
		pubAppMaster = GetSetUtils.setEnrollTransDetails(pubAppMaster, appMaster);
		PUBTransactionDetails pubLastTransDtls = pubAppMaster.getLastTransactionDetails();

		/* RE-GENERATE COI IN CASE NOT GENERATED */
		if (!OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails()) && OPLUtils.isObjectNullOrEmpty(appMaster.getLastTransactionDetails().getCoiStorageId())) {

		    /* FETCH COI REQUEST FROM APPLICATION MASTER */
		    COIRequest coiReq = ereCommonService.generateCOIRequest(appMaster);

		    /* GENERATE PDF FILE FROM PDF CLIENT */
		    com.opl.jns.utils.common.CommonResponse generateCOI = pdfGenerateClient.generateCOI(coiReq);
		    if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getStatus()) && generateCOI.getStatus() == 200 && !OPLUtils.isObjectNullOrEmpty(generateCOI.getData())) {
		        /* SAVE COI IN INSURANCE */
		        ereCommonService.saveStorageIdInLastTransactionDetails(generateCOI.getId(), appMaster.getLastTransactionDetails().getId());

		        /* SAVE COI IN PUBLISH  */
		        pubLastTransDtls.setCoiStorageId(generateCOI.getId());
//                    log.info("--------------- COI Storage Id is : [{}]", pubLastTransDtls.getCoiStorageId());
		    } else if (!OPLUtils.isObjectNullOrEmpty(generateCOI) && !OPLUtils.isObjectNullOrEmpty(generateCOI.getMessage())) {
		        log.error("Error while generate PDF COI --> {}", generateCOI.getMessage());
		    } else {
		        log.error("Error while generate PDF COI {}", HttpStatus.SERVICE_UNAVAILABLE.value());
		    }
		}


		// IS ACTIVE FALSE BY APPLICATION_ID
		pubNomineeDtlRepo.isActiveFalseByApplicationId(applicationId, Arrays.asList(NomineeType.NOMINEE.getId(), NomineeType.GUARDIAN.getId()));

		// -------------------------- SET NOMINEE DETAILS -------------------
		List<PUBNomineeDetails> pubNomineeList = new ArrayList<>();
		PUBNomineeDetails pubNomineeDetails = GetSetUtils.setNomineeDetails(pubAppMaster, appMaster, NomineeType.NOMINEE);
		if (!OPLUtils.isObjectNullOrEmpty(pubNomineeDetails)) {
		    pubNomineeList.add(pubNomineeDetails);
		}
		PUBNomineeDetails pubGuardian = GetSetUtils.setNomineeDetails(pubAppMaster, appMaster, NomineeType.GUARDIAN);
		if (!OPLUtils.isObjectNullOrEmpty(pubGuardian)) {
		    pubNomineeList.add(pubGuardian);
		}
		if (!pubNomineeList.isEmpty()) {
		    pubAppMaster.setNomineeDetails(pubNomineeList);
		}
		Date curruntDate = new Date();

		if (OPLUtils.isObjectNullOrEmpty(pubAppMaster.getPushReadyDate())
		        || (!OPLUtils.isObjectNullOrEmpty(appMaster.getEnrollType())
		        && Objects.equals(appMaster.getEnrollType(),
		        EnrollTypeEnum.ENDORSEMENT.getId()))) {
		    pubAppMaster.setPushReadyDate(curruntDate);
		}
		pubAppMasterRepo.save(pubAppMaster);
		return curruntDate;
	}

    public boolean pushStorageId(long applicationId, long storageId) throws Exception {
        PUBApplicationMaster pubAppMaster = pubAppMasterRepo.findByApplicationIdAndIsActiveTrue(applicationId);
        if (!OPLUtils.isObjectNullOrEmpty(pubAppMaster) && !OPLUtils.isObjectNullOrEmpty(pubAppMaster.getLastTransactionDetails())) {
            pubTransactionDetailsRepo.updateStorageIdInTransaction(storageId, pubAppMaster.getLastTransactionDetails().getId());
            return true;
        }
        return false;
    }

    @Async
    @Override
    public void pushNomineeUpdate(long applicationId,long schemeId) throws Exception {
        Boolean isSuccess=Boolean.TRUE;
        try {
            log.info("ENTER IN NOMINEE DETAILS PUSH ENROLLMENT DATA FOR APPLICATION_ID --->" + applicationId);

            ApplicationMasterBothSchemeProxy appMaster = ereCommonService.getJnsMasterDataApplicationMaster(schemeId, applicationId);
            if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
                isSuccess=Boolean.FALSE;
                log.info("EXIT IN NOMINEE DETAILS PUSH ENROLLMENT DATA (NOT DATA FOUND BY APPLICATION ID) --->" + applicationId);
                //return new PushPullResponse(ENROLL.APP_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
            }
            if(isSuccess) {
                PUBApplicationMaster pubAppMaster = pubAppMasterRepo
                        .findByApplicationIdAndIsActiveTrue(applicationId);

                // IS ACTIVE FALSE BY APPLICATION_ID
                List<PUBNomineeDetails> nmDtl = pubAppMaster.getNomineeDetails().stream().filter(x->x.getIsActive() && (Objects.equals(x.getType(), NomineeType.NOMINEE.getId()) || Objects.equals(x.getType(), NomineeType.GUARDIAN.getId()))).collect(Collectors.toList());
                nmDtl.forEach(x->{
                    x.setIsActive(false);
                    x.setModifiedDate(new Date());
                });
                pubAppMaster.setNomineeDetails(nmDtl);
                // -------------------------- SET NOMINEE DETAILS -------------------

                NomineeDetailsV2 nomineeDetailsV2 = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appMaster.getId());
                NomineePIDetails nomineePIDetails = nomineePIDetailsRepository.findById(nomineeDetailsV2.getId()).orElse(null);
                AddressMasterV2 nomineeAddMstV2 = addressMasterRepositoryV2.findById(nomineeDetailsV2.getAddressId()).orElse(null);
                List<PUBNomineeDetails> pubNomineeList = new ArrayList<>();
                PUBNomineeDetails pubNomineeDetails = GetSetUtils.setNomineeDetailsUsingNewDb(pubAppMaster, appMaster,nomineeDetailsV2,nomineePIDetails,nomineeAddMstV2);
                if (!OPLUtils.isObjectNullOrEmpty(pubNomineeDetails)) {
                    pubNomineeList.add(pubNomineeDetails);
                }
                PUBNomineeDetails pubGuardian = GetSetUtils.setGuardianDetailsUsingNewDb(pubAppMaster, appMaster,nomineeDetailsV2,nomineePIDetails,nomineeAddMstV2);
                if (!OPLUtils.isObjectNullOrEmpty(pubGuardian)) {
                    pubNomineeList.add(pubGuardian);
                }
                if (!pubNomineeList.isEmpty()) {
                    pubAppMaster.setNomineeDetails(pubNomineeList);
                }
                Date curruntDate = new Date();
                pubAppMaster.setPushReadyDate(curruntDate);
                pubAppMaster.setEnrollType(EnrollTypeEnum.ENDORSEMENT.getId());
                pubAppMasterRepo.save(pubAppMaster);
            }else {
                log.error("Invalid push Nominee Update Details, Kindly verfiy stage and data then try again.");
            }

            //return new PushPullResponse(ENROLL.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("EXCEPTION WHILE NOMINEE DETAILS PUSH ENROLLMENT DETAILS ---->", e);
            // return new PushPullResponse(ENROLL.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }

    @Async
    @Override
    public void pushClaimDetails(Long claimId) {
        Boolean isSuccess=Boolean.TRUE;
        try {
            log.info("ENTER IN PUSH ENROLLMENT DATA FOR APPLICATION_ID --->" + claimId);

            ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);
            if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
                isSuccess=Boolean.FALSE;
                log.info("EXIT IN PUSH CLAIM DATA (NO CLAIM MASTER FOUND BY CLAIM ID) --->" + claimId);
                //return new PushPullResponse(CLAIM.CLAIM_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
            }
            if(isSuccess) {
                PUBClaimMaster pubClaimMst = publishClaim(claimId, claimMaster);

                /**PUSH CLAIM DATA BANK AND INSURER USING WEBHOOK*/
                if(PhaseMode.checkPhase2Claim(claimMaster.getOrgId())) {
                    ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService
                            .getJnsMasterDataApplicationMaster(claimMaster.getSchemeId().longValue(),claimMaster.getApplicationId());
                    if (OPLUtils.isObjectNullOrEmpty(applicationMaster)
                            || OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails())) {
                        isSuccess=Boolean.FALSE;
                        log.info("EXIT IN PUSH CLAIM DATA (NO CLAIM APPLICATION AND CLAIM DETAILS FOUND BY CLAIM ID) --->"
                                + claimId);
                        //return new PushPullResponse(CLAIM.CLAIM_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
                    }

                    TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepositoryV2.findFirstByApplicationIdOrderByIdDesc(applicationMaster.getId());
                    if (OPLUtils.isObjectNullOrEmpty(transactionDetailsV2)) {
                        isSuccess=Boolean.FALSE;
                        log.info("EXIT IN PUSH CLAIM DATA (NO TRANSACTION DETAILS FOUND BY ID) --->" + applicationMaster.getLastTransactionId());
                        //return new PushPullResponse(CLAIM.CLAIM_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
                    }
                    if(isSuccess) {
                        bankAndInsurerPushDataUtils.pushClaimDataBankAndInsurer(claimMaster,transactionDetailsV2.getMasterPolicyNo(),pubClaimMst);
                    }
                }

                /**UPDATE IS PUSHED FLAG IN CLAIM MASTER INSURANCE*/
                clmMasterRepository.updatePushFlagAndModified(new Date(),pubClaimMst.getClaimId());
            }else {
                log.error("Invalid Claim Push Details, Kindly verfiy stage and data then try again.");
            }
            // new PushPullResponse(CLAIM.SUCCESS, HttpStatus.OK.value(), Boolean.TRUE);
        } catch (Exception e) {
            log.error("EXCEPTION WHILE PUSH CLAIM DETAILS ---->", e);
            // new PushPullResponse(CLAIM.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
        }
    }
	private PUBClaimMaster publishClaim(Long claimId, ClmMaster claimMaster) throws PushPullException {
		boolean checkPhase2 = PhaseMode.checkPhase2Claim(claimMaster.getOrgId());
/*ApplicationMasterV3 applicationMaster = appMasterRepo
			.findByIdAndIsActiveTrue(claimMaster.getApplicationId());
if (OPLUtils.isObjectNullOrEmpty(applicationMaster)
			|| OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails())) {
		log.info("EXIT IN PUSH CLAIM DATA (NO CLAIM APPLICATION AND CLAIM DETAILS FOUND BY CLAIM ID) --->"
				+ claimId);
		return new PushPullResponse(CLAIM.CLAIM_DATA_NOT_FOUND, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
}*/

		// ------------------ SAVE CLAIM MASTER ----------------------------
		PUBApplicationMaster pubApplicationMaster = pubAppMasterRepo
		        .findByApplicationIdAndIsActiveTrue(claimMaster.getApplicationId());
		PUBClaimMaster pubClaimMst = pubClaimMasterRepo.findByClaimIdAndIsActiveTrue(claimId);
		if (pubClaimMst != null) {
		    BeanUtils.copyProperties(claimMaster, pubClaimMst, "id", "applicationMaster", "claimDetail",
		            "createdDate", "isActive");
		    pubClaimMst.setModifiedDate(new Date());
		} else {
		    pubClaimMst = new PUBClaimMaster(new Date(), true);
		    BeanUtils.copyProperties(claimMaster, pubClaimMst, "id", "applicationMaster", "claimDetail",
		            "createdDate", "isActive");
		}

		pubClaimMst.setClaimStatus(claimMaster.getStatus());
		pubClaimMst.setClaimBranchName(PublishApiUtils.getBranchName(claimMaster.getBranchId()));
		pubClaimMst.setClaimId(claimId);
		pubClaimMst.setClaimDateStr(GetSetUtils.CONVERT_API_DATE_FRMT(claimMaster.getClaimDate()));
		pubClaimMst.setIsClaimantSame(claimMaster.getClmDetails().getIsClaimantSame());
		pubClaimMst.setClaimBranchId(claimMaster.getBranchId());
		pubClaimMst.setStatusReason(null);
		pubClaimMst.setApplicationMaster(pubApplicationMaster);
		pubClaimMst = pubClaimMasterRepo.save(pubClaimMst);

		// ---------------- SAVE CLAIM DETAILS -----------------------
		ClmDetails claimDetail = claimMaster.getClmDetails();
		PUBClaimDetail pubClaimDtl = pubClaimMst.getClaimDetail();
		if (pubClaimDtl != null) {
		    BeanUtils.copyProperties(claimDetail, pubClaimDtl, "id", "claimMaster", "createdDate", "isActive");
		    pubClaimDtl.setModifiedDate(new Date());
		} else {
		    pubClaimDtl = new PUBClaimDetail(new Date(), true);
		    BeanUtils.copyProperties(claimDetail, pubClaimDtl, "id", "claimMaster", "createdDate", "isActive");
		}
		// set cause of death disablity value
		if(checkPhase2) {
		    pubClaimDtl.setCauseOfDeathDisabilityName(
		            CauseOfDeathDisabilityV2.fromId(claimDetail.getCauseOfDeathDisabilityId()).getValue());
		}else {
		    pubClaimDtl.setCauseOfDeathDisabilityName(
		            CauseOfDeathDisability.fromId(claimDetail.getCauseOfDeathDisabilityId()).getValue());
		}
		pubClaimMst.setApplicationId(claimMaster.getApplicationId());

		// Master Details
		pubClaimDtl.setNameOfBank(claimDetail.getClmPIDetails().getClmBankName());
		pubClaimDtl.setClaimantBankAccountNumber(claimDetail.getClmPIDetails().getClmAccountNumber());
		pubClaimDtl.setLocationOfLoss(claimDetail.getPlaceOfOccurrence());
		pubClaimDtl.setCustIfscCode(claimMaster.getClmDetails().getApCustomerIfsc());
		pubClaimDtl.setNatureOfLossName(!OPLUtils.isObjectNullOrEmpty(claimDetail.getNatureOfLossId())
		        ? NatureOfLoss.fromId(claimDetail.getNatureOfLossId()).getValue()
		        : null);
		if(checkPhase2) {
		    pubClaimDtl.setCauseOfDeathDisabilityName(
		            !OPLUtils.isObjectNullOrEmpty(claimDetail.getCauseOfDeathDisabilityId())
		                    ? CauseOfDeathDisabilityV2.fromId(claimDetail.getCauseOfDeathDisabilityId()).getValue()
		                    : null);
		}else {
		    pubClaimDtl.setCauseOfDeathDisabilityName(
		            !OPLUtils.isObjectNullOrEmpty(claimDetail.getCauseOfDeathDisabilityId())
		                    ? CauseOfDeathDisability.fromId(claimDetail.getCauseOfDeathDisabilityId()).getValue()
		                    : null);
		}
		pubClaimDtl.setTypeOfDisablityName(!OPLUtils.isObjectNullOrEmpty(claimDetail.getTypeOfDisabilityId())
		        ? TypeOfDisability.fromId(claimDetail.getTypeOfDisabilityId()).getValue()
		        : null);
		pubClaimDtl.setTypeOfDisablityId(claimDetail.getTypeOfDisabilityId());
		pubClaimDtl.setDateOfDeath(GetSetUtils.CONVERT_API_DATE_FRMT(claimDetail.getDateOfDeath()));
		pubClaimDtl.setDateTimeOfAccident(GetSetUtils.CONVERT_API_DATE_FRMT(claimDetail.getDateTimeOfAccident()));
		pubClaimDtl.setDayOfAccident(claimDetail.getDayOfAccident());

//			kyc details
		Integer[] kycId = new Integer[2];
		KycDocument kycDocument1 = KycDocument.fromId(claimDetail.getClmPIDetails().getClmKycId1());
		kycId[0] = kycDocument1.getId();
		setKycDocument(kycDocument1.getId(), pubClaimDtl, claimDetail.getClmPIDetails().getClmKycIdNumber1());

		if (!OPLUtils.isObjectNullOrEmpty(claimDetail.getClmPIDetails().getClmKycId2())) {
		    KycDocument kycDocument2 = KycDocument.fromId(claimDetail.getClmPIDetails().getClmKycId2());
		    kycId[1] = kycDocument2.getId();
		    setKycDocument(kycDocument2.getId(), pubClaimDtl, claimDetail.getClmPIDetails().getClmKycIdNumber2());
		}

		pubClaimDtl.setKycDocId(Arrays.toString(kycId).replace("[", "").replace("]", ""));

//			1. claiment details
		PUBNomineeDetails claimant = GetSetUtils.pushNomineeDetailAndClaimantDetails(pubClaimMst, claimMaster,checkPhase2);
		if (null != claimant) {
		    pubNomineeDtlRepo.save(claimant);
		}

//			Nominee details
		List<PUBNomineeDetails> pubNomineeList = pubApplicationMaster.getNomineeDetails();
		if (pubNomineeList.size() > 0) {

		    ClmNomineeDetails clmNomineeDetails = claimMaster.getClmNomineeDetails();
		    ClmNomineePIDetails clmNomineePIDetails = claimMaster.getClmNomineeDetails().getClmNomineePIDetails();

		    /* Nominee Update */
		    if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails)
		            && !OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails)) {
		        pubNomineeList.stream().filter(x -> x.getType().equals(NomineeType.NOMINEE.getId())).findAny()
		                .ifPresent(pubNominee -> {
		                    boolean isUpdateNominee = false;
		                    if ((!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getMobileNumber())
		                            && OPLUtils.isObjectNullOrEmpty(pubNominee.getMobileNumber()))
		                            || (!OPLUtils.isObjectNullOrEmpty(pubNominee.getMobileNumber()) && !pubNominee
		                            .getMobileNumber().equals(clmNomineeDetails.getMobileNumber()))) {
		                        pubNominee.setMobileNumber(clmNomineeDetails.getMobileNumber());
		                        isUpdateNominee = true;
		                    }

		                    if ((!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getEmail())
		                            && OPLUtils.isObjectNullOrEmpty(pubNominee.getEmail()))
		                            || (!OPLUtils.isObjectNullOrEmpty(pubNominee.getEmail())
		                            && !pubNominee.getEmail().equals(clmNomineeDetails.getEmail()))) {
		                        pubNominee.setEmail(clmNomineeDetails.getEmail());
		                        isUpdateNominee = true;
		                    }
		                    if(checkPhase2) {
		                        pubNominee.setCorrectNomineeFirstName(clmNomineePIDetails.getCorrectNomineeName());
		                    }else {
		                        pubNominee.setCorrectNomineeFirstName(clmNomineePIDetails.getCorrectNomineeFirstName());
		                        pubNominee.setCorrectNomineeMiddleName(clmNomineePIDetails.getCorrectNomineeMiddleName());
		                        pubNominee.setCorrectNomineeLastName(clmNomineePIDetails.getCorrectNomineeLastName());
		                    }

		                    if (isUpdateNominee) {
		                        pubNominee.setModifiedDate(new Date());
		                        pubNomineeDtlRepo.save(pubNominee);
		                    }
		                });
		    }

		    /* Guardian details */
		    pubNomineeList.stream().filter(x -> x.getType().equals(NomineeType.GUARDIAN.getId())).findAny()
		            .ifPresent(pubGuardian -> {
		                if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails)
		                        && !OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails)
		                        && !OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getGdName())) {
		                    boolean isUpdateGuardian = false;
		                    if (!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails)) {
		                        if ((!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdMobile())
		                                && OPLUtils.isObjectNullOrEmpty(pubGuardian.getMobileNumber()))
		                                || (!OPLUtils.isObjectNullOrEmpty(pubGuardian.getMobileNumber())
		                                && !pubGuardian.getMobileNumber()
		                                .equals(clmNomineeDetails.getGdMobile()))) {
		                            pubGuardian.setMobileNumber(clmNomineeDetails.getGdMobile());
		                            isUpdateGuardian = true;
		                        }

		                        if ((!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdEmail())
		                                && OPLUtils.isObjectNullOrEmpty(pubGuardian.getEmail()))
		                                || (!OPLUtils.isObjectNullOrEmpty(pubGuardian.getEmail()) && !pubGuardian
		                                .getEmail().equals(clmNomineeDetails.getGdEmail()))) {
		                            pubGuardian.setEmail(clmNomineeDetails.getGdEmail());
		                            isUpdateGuardian = true;
		                        }

		                        if (isUpdateGuardian) {
		                            pubGuardian.setModifiedDate(new Date());
		                            pubNomineeDtlRepo.save(pubGuardian);
		                        }

		                    }
		                }
		            });

		}

		pubClaimDtl.setClaimMaster(pubClaimMst);
		pubClaimMst.setClaimDetail(pubClaimDtl);

		// ---------------- SAVE UPLOADED DOCUMENTS
		updateDocs(pubClaimMst);

		pubClaimMst.setPushReadyDate(new Date());
		pubClaimMasterRepo.save(pubClaimMst);

		/**PUSH CLAIM DATA PYTHON API USING DD-REGISTRY*/
		try {
		    //deDupeRegistryAPIClient.callPushClaimRequestV3(claimMaster,applicationMaster.getLastTransactionDetails().getMasterPolicyNo());
		} catch (Exception e) {
		    log.error("Error while push claim python API",
		            claimMaster.getApplicationId(), e.getMessage());
		}
		return pubClaimMst;
	}

    private void updateDocs(PUBClaimMaster pubClaimMst) {

        List<ProductStorageDetailsV3> proStorageDocsList = productStorageRepository
                .getListByApplicationIdAndClaimIdAndIsActive(pubClaimMst.getApplicationMaster().getApplicationId(),
                        pubClaimMst.getClaimId(), Boolean.TRUE);
        if (proStorageDocsList.size() > 0) {

            List<PUBClaimDocs> pubClaimDocs = null;
            if (pubClaimMst.getClaimDocs() != null && pubClaimMst.getClaimDocs().size() > 0) {
                pubClaimDocs = pubClaimMst.getClaimDocs();
                // ----- SET IS ACTIVE FALSE FOR ALL EXISTING OBJECTS
                pubClaimDocs.forEach(a -> a.setIsActive(false));
            } else {
                pubClaimDocs = new ArrayList<>();
            }

            PUBClaimDocs pubClaimDoc = null;
            for (ProductStorageDetailsV3 psd : proStorageDocsList) {

                // CHECK EXISTING OBJECT IS AVAILABLE OR NOT
                Optional<PUBClaimDocs> pubCDOpt = pubClaimDocs.stream()
                        .filter(a -> a.getDmsId().equals(psd.getId()) && a.getMasterId().equals(psd.getDocumentId())
                                && a.getProductDocMapId().equals(psd.getProductDocumentMappingId()))
                        .findFirst();
                pubClaimDoc = pubCDOpt.orElse(null);

                if (pubClaimDoc != null) {
                    pubClaimDoc.setContentType(psd.getOriginalFileName()
                            .substring(psd.getOriginalFileName().lastIndexOf(".") + Constants.ENROLLMENT_TYPE_ID_1));
                    pubClaimDoc.setDocumentType(psd.getDocName());
                    pubClaimDoc.setIsActive(true);
                    pubClaimDoc.setModifiedDate(new Date());
                } else {
                    pubClaimDoc = new PUBClaimDocs(new Date(), true);
                    pubClaimDoc.setDmsId(psd.getId());
                    pubClaimDoc.setClaimMaster(pubClaimMst);
                    pubClaimDoc.setProductDocMapId(psd.getProductDocumentMappingId());
                    pubClaimDoc.setMasterId(psd.getDocumentId());
                    pubClaimDoc.setContentType(psd.getOriginalFileName()
                            .substring(psd.getOriginalFileName().lastIndexOf(".") + Constants.ENROLLMENT_TYPE_ID_1));
                    pubClaimDoc.setDocumentType(psd.getDocName());
                    pubClaimDocs.add(pubClaimDoc);
                }
            }
            pubClaimMst.setClaimDocs(pubClaimDocs);
        }

    }

    public boolean updateDocsInCaseOfQuery(Long claimId) throws IOException {
        PUBClaimMaster pubClaimMst = pubClaimMasterRepo.findByClaimIdAndIsActiveTrue(claimId);
        ClmMaster claimMaster = clmMasterRepository.findByIdAndIsActiveTrue(claimId);

        List<ProductStorageDetailsV3> proStorageDocsList = productStorageRepository
                .getListByApplicationIdAndClaimIdAndIsActive(pubClaimMst.getApplicationMaster().getApplicationId(), pubClaimMst.getClaimId(), Boolean.TRUE);
        if (!proStorageDocsList.isEmpty()) {
            List<PUBClaimDocs> pubClaimDocs = null;
            List<Long> storageList = new ArrayList<>();
            if (pubClaimMst.getClaimDocs() != null && !pubClaimMst.getClaimDocs().isEmpty()) {
                pubClaimDocs = pubClaimMst.getClaimDocs();
                // ----- SET IS ACTIVE FALSE FOR ALL EXISTING OBJECTS
                String[] strings = !OPLUtils.isObjectNullOrEmpty(claimMaster.getQueriedStorageId()) ? claimMaster.getQueriedStorageId().split(",") : null;
                if (null != strings) {
                    for (String s : strings) {
                        storageList.add(Long.valueOf(s.trim()));
                    }
//					List<Long> prdMpgIdList = productStorageRepository.getProductDocumentMappingIdFromStorageId(storageList);
//					if(!prdMpgIdList.isEmpty()) {
//						pubClaimDocs.stream().filter(x ->prdMpgIdList.contains(x.getProductDocMapId())).findFirst().ifPresent(x -> {
//							x.setIsActive(Boolean.FALSE);
//						});
////						pubClaimDocs.stream().filter(x -> x.getProductDocMapId().equals(prdMpgId)).forEach(a -> a.setIsActive(false));
//					}
                }

            } else {
                pubClaimDocs = new ArrayList<>();
            }

            PUBClaimDocs pubClaimDoc = null;
            for (ProductStorageDetailsV3 psd : proStorageDocsList) {

                // CHECK EXISTING OBJECT IS AVAILABLE OR NOT
                pubClaimDoc = pubClaimDocs.stream()
                        .filter(a -> a.getMasterId().equals(psd.getDocumentId()) && a.getProductDocMapId().equals(psd.getProductDocumentMappingId()))
                        .findFirst().orElse(null);
                if (pubClaimDoc != null) {
                    pubClaimDoc.setDmsId(psd.getId());
                    pubClaimDoc.setContentType(psd.getOriginalFileName().substring(psd.getOriginalFileName().lastIndexOf(".") + Constants.ENROLLMENT_TYPE_ID_1));
                    pubClaimDoc.setDocumentType(psd.getDocName());
                    pubClaimDoc.setIsActive(Boolean.TRUE);
                    pubClaimDoc.setModifiedDate(new Date());
                } else {
                    pubClaimDoc = new PUBClaimDocs(new Date(), Boolean.TRUE);
                    pubClaimDoc.setDmsId(psd.getId());
                    pubClaimDoc.setClaimMaster(pubClaimMst);
                    pubClaimDoc.setProductDocMapId(psd.getProductDocumentMappingId());
                    pubClaimDoc.setMasterId(psd.getDocumentId());
                    pubClaimDoc.setContentType(psd.getOriginalFileName().substring(psd.getOriginalFileName().lastIndexOf(".") + Constants.ENROLLMENT_TYPE_ID_1));
                    pubClaimDoc.setDocumentType(psd.getDocName());
                    pubClaimDocs.add(pubClaimDoc);
                }
            }
            pubClaimMst.setClaimDocs(pubClaimDocs);
            pubClaimMst.setModifiedDate(new Date());
            pubClaimMasterRepo.save(pubClaimMst);

            /**FIRST INSURER CLAIM STATUS PUSH FLAG SET FALSE*/
            ereCommonService.setInsurerClaimStatusPushFlagFalse(claimMaster.getId());

            /**FIRST BANK CLAIM STATUS PUSH FLAG SET FALSE*/
            ereCommonService.setBankClaimStatusPushFlagFalse(claimMaster.getId());

            /** call here bank webhook in case */
            ClaimStatusWebhook wbRequest = new ClaimStatusWebhook(claimMaster.getInsurerClaimId(),claimMaster.getId(),claimMaster.getUrn(), ClaimStatus.CLAIM_INSURER_IN_PROGRESS.getId());
            List<com.opl.jns.api.proxy.insurer.UpdateDocQuery.Document> docList = new ArrayList<>();

            if (!OPLUtils.isObjectNullOrEmpty(storageList) && storageList.size() > 0) {
                pubClaimDocs.stream().filter(docs -> storageList.contains(docs.getDmsId())).forEach(documents -> {
                    InputStreamResource inputStreamResource = dmsService.downloadDocumentByProductDocumentId(documents.getDmsId());
                    if (inputStreamResource != null) {
                        try {
                            com.opl.jns.api.proxy.insurer.UpdateDocQuery.Document doc = new com.opl.jns.api.proxy.insurer.UpdateDocQuery.Document();
                            BeanUtils.copyProperties(documents, doc);
                            doc.setDocumentType(documents.getDocumentType());
                            doc.setDocumentId(documents.getMasterId());
                            InputStream inputStream = inputStreamResource.getInputStream();
                            byte[] bytes = IOUtils.toByteArray(inputStream);
                            doc.setDocument(bytes);
                            docList.add(doc);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            wbRequest.setDocuments(docList);
            // call here
            wbRequest.setOrgId(claimMaster.getInsurerOrgId());
            wbRequest.setIsInsurer(true);
            wbRequest.setCommonUserId(claimMaster.getCreatedBy());
            wbRequest.setApplicationId(claimMaster.getApplicationId());
            wbRequest.setClaimRefId(claimMaster.getId());
            wbRequest.setRemarks(claimMaster.getRemarks());
            wbRequest.setMessage("Uploaded documents submitted successfully.");
            webHookClient.updateDocToInsurerForQuery(wbRequest);

            /**PUSH CLAIM STATUS TO BANK*/
            PushClaimStatustoBankReqV3 bankReq = prepareRequestPushClaimStatusToBank(claimMaster);
            webHookClient.pushClaimStatusToBank(bankReq);

            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    public PushClaimStatustoBankReqV3 prepareRequestPushClaimStatusToBank(ClmMaster claimMaster) {
        PushClaimStatustoBankReqV3 bankReq=new PushClaimStatustoBankReqV3();
        bankReq.setClaimId(claimMaster.getInsurerClaimId());
        bankReq.setClaimReferenceId(claimMaster.getId());
        bankReq.setClaimStatus(ClaimStatus.CLAIM_INSURER_IN_PROGRESS.getId());
        bankReq.setInsurerStatus(claimMaster.getInsurerStatus());
        bankReq.setReason(claimMaster.getStatusReasonId());
        bankReq.setUrn(claimMaster.getUrn());
        bankReq.setCommonUserId(claimMaster.getCreatedBy());
        bankReq.setOrgId(claimMaster.getOrgId());
        bankReq.setApplicationId(claimMaster.getApplicationId());
        bankReq = WebHookClient.pushClmStausBnkManageRequest(bankReq);
        return bankReq;
    }

    @Override
    public ClmMaster updateStatusFromPublish(UpdateAppClaimRequest updateAppClaimRequest, PUBClaimMaster pubClaimMaster) {
        try {
            log.info("Enter into updateStatusFromPublish() :::");

            PUBClaimMaster claimMaster = pubClaimMasterRepo.findByIdAndIsActiveTrue(updateAppClaimRequest.getClaimReferenceId());
            if (!OPLUtils.isObjectNullOrEmpty(claimMaster)) {
                ClmMaster claimInsurance = clmMasterRepository.findByIdAndIsActiveTrue(claimMaster.getClaimId());
                if (!OPLUtils.isObjectNullOrEmpty(claimInsurance)) {
                    claimInsurance.setStatus(updateAppClaimRequest.getClaimStatus());
                    claimInsurance.setTransactionUTR(updateAppClaimRequest.getTransactionUTR());
                    claimInsurance.setTransactionAmount(updateAppClaimRequest.getAmountOfTransaction());
                    if (!OPLUtils.isObjectNullOrEmpty(updateAppClaimRequest.getDateOfTransaction())) {
                        Date dateOfTransaction = Date.from(updateAppClaimRequest.getDateOfTransaction().atZone(ZoneId.systemDefault()).toInstant());
                        claimInsurance.setTransactionTimeStamp(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.parse(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(dateOfTransaction)));
                    }
                    claimInsurance.setModifiedDate(new Date());
                    claimInsurance.setInsurerClaimId(updateAppClaimRequest.getClaimId());
                    claimInsurance.setInsurerStatus(updateAppClaimRequest.getInsurerStatus());
                    claimInsurance.setStatusReasonId(updateAppClaimRequest.getReason());
                    clmMasterRepository.save(claimInsurance);

                    sendNotificationInCaseOfStatusUpdate(
                            setEmailParameters(
                                    OPLUtils.isObjectNullOrEmpty(claimInsurance.getUrn()) ? null : claimInsurance.getUrn(),
                                    OPLUtils.isObjectNullOrEmpty(claimInsurance.getClmDetails().getClmPIDetails().getApFirstName()) ? null : claimInsurance.getClmDetails().getClmPIDetails().getApFirstName(),
                                    OPLUtils.isObjectNullOrEmpty(claimInsurance.getSchemeId()) ? null : SchemeMaster.getById(Long.valueOf(claimInsurance.getSchemeId())).getShortName(),
                                    OPLUtils.isObjectNullOrEmpty(claimInsurance.getStatus()) ? null : Constants.ClaimStatus.getById(claimInsurance.getStatus()).getDescription(),pubClaimMaster.getApplicationMaster().getApplicationMasterOtherDetails().getSource(),
                                    OPLUtils.isObjectNullOrEmpty(pubClaimMaster.getApplicationMaster().getOrgId()) ? null : pubClaimMaster.getApplicationMaster().getOrgId()),
                            OPLUtils.isObjectNullOrEmpty(claimInsurance.getClmDetails().getApEmail()) ? null : claimInsurance.getClmDetails().getApEmail(),
                            OPLUtils.isObjectNullOrEmpty(claimInsurance.getClmDetails().getApMobileNumber()) ? null : claimInsurance.getClmDetails().getApMobileNumber(),
                            OPLUtils.isObjectNullOrEmpty(claimInsurance.getOrgId()) ? null : claimInsurance.getOrgId(), SourceType.JANSURAKSHA.getId());
                }
                return claimInsurance;
            }

        } catch (Exception e) {
            log.error("Error while updateStatusFromPublish()", e);
        }
        return null;
    }


    public void sendNotificationInCaseOfStatusUpdate(Map<String, Object> emailParameters, String toEmail, String toSms, Long orgId, Long sourceType) {
        log.info("entry in sendNotification()");

        String[] toEmailAry = {toEmail};
        String[] toSmsAry = {91 + toSms};

        NotificationRequest notificationRequest = new NotificationRequest();
        if (!OPLUtils.isObjectNullOrEmpty(toEmail)) {
            Notification emailNoti = NotificationClient.prepareRequestForSmsOrEmail(toEmailAry, emailParameters, JnsNotificationMasterUtil.EMAIL_CUST_CLAIM_SETTLEMENT_SUCESS, null, NotificationType.EMAIL, orgId, sourceType);
            notificationRequest.addNotification(emailNoti);
        }
        if (!OPLUtils.isObjectNullOrEmpty(toSms)) {
            Long smstempId = null;
            if (emailParameters.get("nameOfScheme").equals("PMSBY")) {
                smstempId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMSBY;
            } else {
                smstempId = JnsNotificationMasterUtil.SMS_CUST_CLAIM_SETTLEMENT_SUCESS_PMJJBY;
            }
            Notification smsNoti = NotificationClient.prepareRequestForSmsOrEmail(toSmsAry, emailParameters, smstempId, null, NotificationType.SMS, orgId, sourceType);
            notificationRequest.addNotification(smsNoti);
        }

        if (!OPLUtils.isListNullOrEmpty(notificationRequest.getNotifications()) && !notificationRequest.getNotifications().isEmpty()) {
            notificationClient.send(notificationRequest);
            log.info("Notification sent successfully");
        }

    }

    public Map<String, Object> setEmailParameters(String urn, String claimaintName, String schemeName, String status,Integer source,Long orgId) {
        log.info("entry in emailParameters()");
        Map<String, Object> emailParameters = new HashMap<>();
        emailParameters.put("claimaintName", claimaintName);
        emailParameters.put("statusUpdate", status);
        emailParameters.put("nameOfScheme", schemeName);
        emailParameters.put("urn", urn.substring(4));
        emailParameters.put("source", source);
        emailParameters.put("orgId", orgId);
        return emailParameters;
    }


//	public ClaimStatusWebhookAudit webhookAudit(ClaimMasterV3 claimMaster,ClaimStatusWebhookAudit webhookAuditDmn,Integer status){
//		if(null == webhookAuditDmn){
//			webhookAuditDmn = new ClaimStatusWebhookAudit();
//			webhookAuditDmn.setCreatedDate(new Date());
//			webhookAuditDmn.setClaimId(claimMaster.getId());

//			webhookAuditDmn.setClaimStatus(claimMaster.getClaimStatus());
//			webhookAuditDmn.setIsActive(Boolean.TRUE);
//			webhookAuditDmn.setWebhookMasterId(WebhookMasterEnum.UPDATE_CLAIM_STATUS_TO_INSURER_BY_JS.getId());
//		}else{
//			webhookAuditDmn.setIsActive(Boolean.FALSE);
//			webhookAuditDmn.setModifiedDate(new Date());
//			webhookAuditDmn.setWebhookStatus(status);
//		}
//		return webhookAuditRepository.save(webhookAuditDmn);
//	}


    @Override
    public void pushApplicationHasError(int page, int count) {
        Page<Long> appList = applicationPushStatusRepo.findAllByIsPushedNull(PageRequest.of(page, count));
        if (!appList.isEmpty()) {
            log.info("found the application which has not push [{}]", appList.getContent().size());
            for (Long applicationId : appList) {
                try {
                    pushEnrolmentData(applicationId);
                } catch (Exception e) {
                    log.error("Exception while pushing the application : {} and error is : ",applicationId,e);
                }
            }
        } else {
            log.info("No application pending for pushing");
        }
    }


    private void setKycDocument(Integer kycId, PUBClaimDetail claimDetailV3, String value) {
        if (Objects.equals(KycDocument.PAN.getId(), kycId)) {
            claimDetailV3.setPan(value);
        } else if (Objects.equals(KycDocument.PASSPORT.getId(), kycId)) {
            claimDetailV3.setPassport(value);
        } else if (Objects.equals(KycDocument.DRIVING_LICENCE.getId(), kycId)) {
            claimDetailV3.setDrivingLicense(value);
        } else if (Objects.equals(KycDocument.MGNREGA_CARD.getId(), kycId)) {
            claimDetailV3.setMgnerega(value);
        } else if (Objects.equals(KycDocument.VOTERS_ID_CARD.getId(), kycId)) {
            claimDetailV3.setVottingCardId(value);
        }
    }
}

