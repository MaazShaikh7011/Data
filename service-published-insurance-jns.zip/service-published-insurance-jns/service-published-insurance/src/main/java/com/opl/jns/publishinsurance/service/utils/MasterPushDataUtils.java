package com.opl.jns.publishinsurance.service.utils;

import java.util.*;

import com.opl.jns.ere.enums.EnrollTypeEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.PMJJBY;
import com.opl.jns.ere.domain.v2.PMSBY;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.repo.v2.AddressMasterRepositoryV2;
import com.opl.jns.ere.repo.v2.ApplicantInfoRepoV2;
import com.opl.jns.ere.repo.v2.ApplicantPIDetailsRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.PmjjbyRepository;
import com.opl.jns.ere.repo.v2.PmsbyRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;

/**
 * PUSH ENROLLMENT DATA IN TO MASTER REPOSITORY
 * 
 * @author harshit.suhagiya
 * @date 29-Jan-2024
 */
@Slf4j
@Component
public class MasterPushDataUtils {

	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepositoryV2;

	@Autowired
	private NomineePIDetailsRepository nomineePIDetailsRepository;

	@Autowired
	private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;

	@Autowired
	private ApplicantPIDetailsRepository applicantPIDetailsRepository;

	@Autowired
	private ApplicantInfoRepoV2 applicantInfoRepoV2;

	@Autowired
	private AddressMasterRepositoryV2 addressMasterRepositoryV2;

	@Autowired
	private PmjjbyRepository pmjjbyRepository;

	@Autowired
	private PmsbyRepository pmsbyRepository;
	
	/**
	 * SET ALL THE TABLER SEQUENCE
	 * MODIFY SETTER METHOD
	 * MODIFY INSERT DATA LOGIC
	 * AUDIT
	 * @param appMaster
	 * @return
	 */

	public boolean pushData(ApplicationMasterV3 appMaster) {
		try {
			if (EnrollTypeEnum.ENDORSEMENT.getId() == appMaster.getEnrollType()) {
				// IS_ACTIVE FALSE BY APPLICATION ID
//				nomineeDetailsRepositoryV2.isActiveFalseByApplicationId(appMaster.getId());

				/* SET NOMINEE AND GUARDIAN DETAILS */
				NomineeDetailsV2 nominee = null;
				List<NomineeDetails> nomineeDetails = appMaster.getNomineeDetails();
				Optional<NomineeDetails> nomineeOptional = nomineeDetails.stream().filter(
								a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.NOMINEE.getId().equals(a.getType()))
						.findFirst();
				if (nomineeOptional.isPresent()) {
					/* SET NOMINEE DETAILS */
					NomineeDetails ndtls = nomineeOptional.get();
					nominee = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appMaster.getId());
					nominee = GetSetUtils.setNomineeDetails(appMaster.getId(), ndtls,nominee);

					NomineePIDetails piDetails = new NomineePIDetails();
					piDetails.setEnrollmentDate(appMaster.getEnrollmentDate());

					/* SET GUARDIAN DETAILS */
					Optional<NomineeDetails> guardianOptional = nomineeDetails.stream().filter(
									a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.GUARDIAN.getId().equals(a.getType()))
							.findFirst();
					if (guardianOptional.isPresent()) {
						NomineeDetails guardian = guardianOptional.get();
						nominee.setGdEmail(guardian.getEmail());
						nominee.setGdMobile(guardian.getMobileNumber());
						nominee.setGdRelationId(guardian.getRelationId());

						/* SET GUARDIAN PI DETAILS */
						AddressMasterV3 gdAdd = guardian.getAddress();
						piDetails.setGdAddress(!OPLUtils.isObjectNullOrEmpty(gdAdd) ? gdAdd.getAddressLine1() : null);
						piDetails.setGdName(guardian.getName());
					}

					/* SET NOMINEE ADDRESS */
					AddressMasterV3 address = ndtls.getAddress();
					AddressMasterV2 nAdd = addressMasterRepositoryV2.findById(address.getId()).orElse(null);
					nAdd = GetSetUtils.setNomineeAddress(address,nAdd);
					nAdd = addressMasterRepositoryV2.save(nAdd);
					nominee.setAddressId(nAdd.getId());

					/* SAVE NOMINEE */
					nominee = nomineeDetailsRepositoryV2.save(nominee);

//					/* SET NOMINEE PI DETAILS */
					piDetails = GetSetUtils.setNomineePiDetails(piDetails, nominee.getId(), ndtls, address, appMaster.getEnrollmentDate());
					piDetails.setId(nominee.getId());
					nomineePIDetailsRepository.save(piDetails);
				}

				if (appMaster.getSchemeId().equals(SchemeMaster.PMSBY.getId().intValue())) {
					PMSBY pmsby = pmsbyRepository.findById(appMaster.getId()).orElse(null);
					if (!OPLUtils.isObjectNullOrEmpty(pmsby)) {
						pmsby.setEnrollType(EnrollTypeEnum.ENDORSEMENT.getId());
						pmsbyRepository.save(pmsby);
						updateCoiStorageId(appMaster, pmsby.getLastTransactionId());
					}
				} else if (appMaster.getSchemeId().equals(SchemeMaster.PMJJBY.getId().intValue())) {
					PMJJBY pmjjby = pmjjbyRepository.findById(appMaster.getId()).orElse(null);
					if (!OPLUtils.isObjectNullOrEmpty(pmjjby)) {
						pmjjby.setEnrollType(EnrollTypeEnum.ENDORSEMENT.getId());
						pmjjbyRepository.save(pmjjby);
						updateCoiStorageId(appMaster, pmjjby.getLastTransactionId());
					}
				} else {
					log.info("Scheme id not found for applicationId [{}]", appMaster.getId());
					throw new Exception("Scheme id not found for applicationId " + appMaster.getId());
				}
			} else {
				ApplicationMasterOtherDetailsV3 otherDtls = appMaster.getApplicationMasterOtherDetails();
				ApplicantInfo applicantInfo = appMaster.getApplicantInfo();
				AddressMasterV3 addressInfo = applicantInfo.getAddress();

				/* SAVE APPLICANT INFO */
				ApplicantInfoV2 appInfo = applicantInfoRepoV2.findById(appMaster.getId()).orElse(null);
				appInfo = GetSetUtils.setApplicantInfo(appMaster, applicantInfo, otherDtls,appInfo);

				/* SAVE ADDRESS */
				if (!OPLUtils.isObjectNullOrEmpty(addressInfo)) {
					AddressMasterV2 address = addressMasterRepositoryV2.findById(addressInfo.getId()).orElse(null);
					address = GetSetUtils.setApplicantAddress(addressInfo,address);
					address = addressMasterRepositoryV2.save(address);
					appInfo.setAddressId(address.getId());
				}
				applicantInfoRepoV2.save(appInfo);

				/* SET APPLICANT PI DETAILS */
				ApplicantPIDetails appPiDtls = applicantPIDetailsRepository.findById(appMaster.getId()).orElse(null);
				appPiDtls = GetSetUtils.setApplicantPiDetails(appMaster, applicantInfo, addressInfo,appPiDtls);
				applicantPIDetailsRepository.save(appPiDtls);

				/* SET NOMINEE AND GUARDIAN DETAILS */
				NomineeDetailsV2 nominee = null;
				List<NomineeDetails> nomineeDetails = appMaster.getNomineeDetails();
				Optional<NomineeDetails> nomineeOptional = nomineeDetails.stream().filter(
								a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.NOMINEE.getId().equals(a.getType()))
						.findFirst();
				if (nomineeOptional.isPresent()) {
					/* SET NOMINEE DETAILS */
					NomineeDetails ndtls = nomineeOptional.get();
					nominee = nomineeDetailsRepositoryV2.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appMaster.getId());
					nominee = GetSetUtils.setNomineeDetails(appMaster.getId(), ndtls,nominee);

					/* SET GUARDIAN DETAILS */
					Optional<NomineeDetails> guardianOptional = nomineeDetails.stream().filter(
									a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.GUARDIAN.getId().equals(a.getType()))
							.findFirst();
					String gdAddress = null;
					String gdName = null;
					if (guardianOptional.isPresent()) {
						NomineeDetails guardian = guardianOptional.get();
						nominee.setGdEmail(guardian.getEmail());
						nominee.setGdMobile(guardian.getMobileNumber());
						nominee.setGdRelationId(guardian.getRelationId());

						/* SET GUARDIAN PI DETAILS */
						AddressMasterV3 gdAdd = guardian.getAddress();
						gdAddress = !OPLUtils.isObjectNullOrEmpty(gdAdd) ? gdAdd.getAddressLine1() : null;
						gdName = guardian.getName();
					}

					/* SET NOMINEE ADDRESS */
					AddressMasterV3 address = ndtls.getAddress();
					AddressMasterV2 nAdd = addressMasterRepositoryV2.findById(address.getId()).orElse(null);
					nAdd = GetSetUtils.setNomineeAddress(address,nAdd);
					nAdd = addressMasterRepositoryV2.save(nAdd);
					nominee.setAddressId(nAdd.getId());

					/* SAVE NOMINEE */
					nominee = nomineeDetailsRepositoryV2.save(nominee);

					/* SET NOMINEE PI DETAILS */
					/* Find Nominee */
					NomineePIDetails piDetails = nomineePIDetailsRepository.findById(nominee.getId()).orElse(null);
					piDetails = GetSetUtils.setNomineePiDetails(piDetails, nominee.getId(), ndtls, address, appMaster.getEnrollmentDate());
					piDetails.setGdAddress(gdAddress);
					piDetails.setGdName(gdName);
					nomineePIDetailsRepository.save(piDetails);
				}

				/* SAVE TRANSACTION DETAILS */
				TransactionDetailsV3 lastTransactionDetails = appMaster.getLastTransactionDetails();
				Long lastTransactionId = null;
				if (!OPLUtils.isObjectNullOrEmpty(lastTransactionDetails)) {
					TransactionDetailsV2 trxn = transactionDetailsRepositoryV2.findFirstByApplicationIdOrderByIdDesc(appMaster.getId());
					if(OPLUtils.isObjectNullOrEmpty(trxn)) {
						trxn = new TransactionDetailsV2();
						trxn.setId(lastTransactionDetails.getId());
					}
					BeanUtils.copyProperties(lastTransactionDetails, trxn,"id");
					trxn.setApplicationId(appMaster.getId());
					trxn.setInsurerMasterId(lastTransactionDetails.getInsurerMaster().getId());
					trxn.setInsurerCode(lastTransactionDetails.getInsurerCode());
					trxn.setCreatedBy(lastTransactionDetails.getCreatedBy());
					trxn.setCreatedDate(lastTransactionDetails.getCreatedDate());
					trxn.setModifiedBy(lastTransactionDetails.getModifiedBy());
					trxn.setModifiedDate(lastTransactionDetails.getModifiedDate());
					trxn = transactionDetailsRepositoryV2.save(trxn);
					lastTransactionId = trxn.getId();
				}

				/* SAVE MASTER DETAILS */
				if (appMaster.getSchemeId().equals(SchemeMaster.PMSBY.getId().intValue())) {
					PMSBY pmsby = pmsbyRepository.findById(appMaster.getId()).orElse(null);
					if(OPLUtils.isObjectNullOrEmpty(pmsby)) {
						pmsby = new PMSBY();
						pmsby.setEnrollmentDate(appMaster.getEnrollmentDate());
						pmsby.setOrgId(appMaster.getOrgId());
					}
					GetSetUtils.setAppMasterV2(appMaster, otherDtls, applicantInfo, lastTransactionId, pmsby);
					pmsbyRepository.save(pmsby);
				} else if (appMaster.getSchemeId().equals(SchemeMaster.PMJJBY.getId().intValue())) {
					PMJJBY pmjjby = pmjjbyRepository.findById(appMaster.getId()).orElse(null);
					if(OPLUtils.isObjectNullOrEmpty(pmjjby)) {
						pmjjby = new PMJJBY();
						pmjjby.setEnrollmentDate(appMaster.getEnrollmentDate());
						pmjjby.setOrgId(appMaster.getOrgId());
					}
					GetSetUtils.setAppMasterV2(appMaster, otherDtls, applicantInfo, lastTransactionId, pmjjby);
					pmjjbyRepository.save(pmjjby);
				} else {
					log.info("Scheme id not found for applicationId [{}]", appMaster.getId());
					throw new Exception("Scheme id not found for applicationId " + appMaster.getId());
				}
			}
			return true;
		} catch (Exception e) {

			// ------------------------------- HANDLE EXCEPTION ---------------------------
			log.info("Exception while saving details to new structure : ", e);
			return false;
		}
	}

	public void updateCoiStorageId(ApplicationMasterV3 appMaster, Long lastTransactionId) {
		transactionDetailsRepositoryV2.updateStorageIdInTransaction(
				appMaster.getLastTransactionDetails().getCoiStorageId(), lastTransactionId);
	}

}
