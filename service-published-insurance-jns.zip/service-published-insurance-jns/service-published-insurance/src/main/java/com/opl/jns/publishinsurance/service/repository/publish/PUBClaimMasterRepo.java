package com.opl.jns.publishinsurance.service.repository.publish;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;

public interface PUBClaimMasterRepo extends JpaRepository<PUBClaimMaster, Long> {

	PUBClaimMaster findByClaimIdAndIsActiveTrue(final long applicationId);

	
	public List<PUBClaimMaster> findAllByApplicationMasterInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long insOrgId, Date claimFromDate, Date claimToDate);
	
	public List<PUBClaimMaster> findAllByApplicationMasterOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long orgId, Date claimFromDate, Date claimToDate);
	
	PUBClaimMaster findByIdAndIsActiveTrue(final long applicationId);
	
	PUBClaimMaster findByIdAndClaimStatusAndIsActiveTrue(final long applicationId,Integer claimStatus);

	PUBClaimMaster findByIdAndApplicationMasterOrgIdAndIsActiveTrue(Long claimId, Long orgId);

	PUBClaimMaster findByIdAndIsActiveTrueAndApplicationMasterInsurerOrgId(Long claimId, Long insOrgId);

	public Long countByApplicationMasterIdAndIsActiveTrueAndClaimStatusIn(Long applicationId, List<Integer> status);
	
	public List<PUBClaimMaster> findByApplicationMasterIdAndIsActiveTrue(Long applicationId);

	PUBClaimMaster findByIdAndApplicationMasterUrnAndIsActiveTrue(Long claimReferenceId,String urn);


}
