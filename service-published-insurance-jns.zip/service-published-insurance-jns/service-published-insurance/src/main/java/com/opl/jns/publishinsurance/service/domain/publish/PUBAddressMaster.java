package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.published.lib.utils.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * 
 * @author harshit.suhagiya
 * @date 17-Jun-2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "address_master")
public class PUBAddressMaster extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_add_mst_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_add_mst_seq_gen", sequenceName = "pub_add_mst_seq_gen", allocationSize = 1)
	private Long id;

    @Convert(converter = AESEncryption.class)
	@Column(name = "address_line_1", length = 500, nullable = true)
	private String addressLine1;

    @Convert(converter = AESEncryption.class)
	@Column(name = "address_line_2", length = 500, nullable = true)
	private String addressLine2;

	@Column(name = "district", length = 500, nullable = true)
	private String district;

	@Column(name = "city_name", length = 500, nullable = true)
	private String cityName;

	@Column(name = "state_name", length = 500, nullable = true)
	private String stateName;

	@Column(name = "pincode")
	private Integer pincode;

	@Column(name = "city_lgd_code", length = 20, nullable = true)
	private Long cityLGDCode;

	@Column(name = "state_lgd_code", length = 20, nullable = true)
	private Long stateLGDCode;

	@Column(name = "city_id", length = 200, nullable = true)
	private Long cityId;

	@Column(name = "state_id", length = 200, nullable = true)
	private Long stateId;

	@Column(name = "district_lgd_code", length = 20, nullable = true)
	private Long districtLGDCode;

	@OneToOne(mappedBy = "address",cascade = CascadeType.ALL)
	private PUBApplicantInfo applicantInfo;

	public PUBAddressMaster(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
