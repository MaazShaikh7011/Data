package com.opl.jns.publishinsurance.service.controller.publish.v1;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationDetails.ApplicationDetailResponse;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationDetails.ApplicationDetailsRequest;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationProxy;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationRequest;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationResponse;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response400;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response401;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.publish.EnrollmentService;
import com.opl.jns.publishinsurance.service.service.publish.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/***
 * 
 * @author Maaz Shaikh
 * @date : 04/03/2023
 */

@RestController
@RequestMapping(Constants.REQUEST_MAPPING_V1)
@Slf4j
@Tag(name = "1. Insurance V1", description = "List of Insurance Scheme APIs for version 1")
public class EnrolmentController {

    @Autowired
    ValidationService validationService;

    @Autowired
    EnrollmentService enrollmentService;

    @PostMapping(value = "/getApplicationList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(
            operationId = Constants.STR_1,
            summary = Constants.COMMON_BASIC_INSURANCE_APPLICANT_MESSAGE,
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
                content = @Content(examples = {
                        @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_APPLICATION_LIST_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
                        @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
            })),
    		responses = {
    				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
    						 content = {
                                     @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationResponse.class),
                                             examples = {
                                                     @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.GET_APPLICATION_PLAIN_RESPONSE_SUCCESS),
                                                     @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                                             })
                             }),
    				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
    						 content = {
                                     @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
                                             examples = {
                                                     @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
                                                     @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                                             }

                                     )
                             }),
    				 @ApiResponse(responseCode =Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
    						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//    						 content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class)
//                             examples = {
//                                     @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//                                     @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//                             }
                     )})

			})
    public ResponseEntity<CommonResponse> getApplicationList(@Valid  @RequestBody ApplicationRequest applicationRequest, HttpServletRequest httpServletRequest, BindingResult result) {
        try {
            Long userOrgId=Long.valueOf(String.valueOf(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID)));
            log.info(Constants.USER_ORG_ID,userOrgId);
            List<ApplicationProxy> data = enrollmentService.getApplicationListForPush(applicationRequest.getFromDate(), applicationRequest.getToDate(), userOrgId);
            return new ResponseEntity<>(new CommonResponse(Constants.SUCCESS, data, HttpStatus.OK.value(), !OPLUtils.isListNullOrEmpty(data) ? Boolean.TRUE : Boolean.FALSE),HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getApplicationList() ", e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, Boolean.FALSE,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }

    }
	@PostMapping(value = "/getApplicationDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(
            operationId = Constants.STR_2,
            summary = Constants.COMMON_BASIC_INSURANCE_APPLICANT_DETAIL_MESSAGE,
    		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
            content = @Content(examples = {
                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
            })),
            responses = {
                     @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
                     content = {
                         @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationDetailResponse.class),
                         examples = {
                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.ENROLLMENT_PLAIN_REQUEST_SUCCESS),
                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                         })
                     }),
                     @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
                         content = {
                             @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
                                 examples = {
                                         @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
                                         @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                                 }
                             )
                         }),
                     @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
                    		 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//                             examples = {
//                                     @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//                                     @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//                             }
                     )})

            })
    public ResponseEntity<CommonResponse> getApplicationDetails(@Valid @RequestBody ApplicationDetailsRequest detailsRequest, HttpServletRequest httpServletRequest) {
        Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, detailsRequest.getApplicationReferenceId(), null);
        if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
            CommonResponse matchResponse = new CommonResponse(Constants.INVALID_APPLICATION_REF_ID, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(matchResponse, HttpStatus.OK);
        }
        try {
            CommonResponse data =  enrollmentService.getApplicationDetails(detailsRequest.getApplicationReferenceId());
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getApplicationDetails() ", e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }

    }
}
