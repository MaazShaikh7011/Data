package com.opl.jns.publishinsurance.service.boot;

//import io.awspring.cloud.autoconfigure.cache.*;
//import io.awspring.cloud.autoconfigure.context.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.pdfgenerate.client.PDFGenerateClient;
import com.opl.jns.published.lib.utils.ApplicationProperties;
import com.opl.jns.published.utils.config.URLConfig;
import com.opl.jns.published.utils.config.URLMaster;
import com.opl.jns.user.management.client.UserManagementClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.webhook.client.WebHookClient;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableScheduling
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
//@EnableAutoConfiguration(exclude= {DataSourceAutoConfiguration.class, MongoAutoConfiguration.class, MongoDataAutoConfiguration.class,})
//ContextStackAutoConfiguration.class, ElastiCacheAutoConfiguration.class
public class PublishedMain {
	
	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) {
		SpringApplication.run(PublishedMain.class, args);
	}
	
	@Bean
	public AmazonS3 amazonS3() {
		AmazonS3 amazonS3 = AmazonS3ClientBuilder.defaultClient();
		applicationContext.getAutowireCapableBeanFactory().autowireBean(amazonS3);
		return amazonS3;
	}

    @Bean
    public NotificationClient notificationClient() {
    	NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
        return notificationClient;
    }
	
    @Bean
    public WebHookClient webHookClient() {
    	WebHookClient webHookClient = new WebHookClient(URLConfig.fetchURL(URLMaster.WEBHOOK));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(webHookClient);
        return webHookClient;
    }

	@Bean
	public UserManagementClient userManagementClient() {
		UserManagementClient userManagementClient = new UserManagementClient(URLConfig.fetchURL(URLMaster.USER_MANAGEMENT));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(userManagementClient);
		return userManagementClient;
	}

	@Bean
	public PDFGenerateClient pdfGenerateClient() {
		PDFGenerateClient pdfGenerateClient = new PDFGenerateClient(URLConfig.fetchURL(URLMaster.PDF_GENARATE));
		applicationContext.getAutowireCapableBeanFactory().autowireBean(pdfGenerateClient);
		return pdfGenerateClient;
	}
	
	@Bean
    public DedupeRegistryClient dedupeRegistryClient() {
    	DedupeRegistryClient dedupeRegistryClient = new DedupeRegistryClient(URLConfig.fetchURL(URLMaster.DD_REGISTRY));
    	applicationContext.getAutowireCapableBeanFactory().autowireBean(dedupeRegistryClient);
    	return dedupeRegistryClient;
    }
	
    @Bean
    public UsersClient usersClient() {
        UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
        return usersClient;
    }
}

