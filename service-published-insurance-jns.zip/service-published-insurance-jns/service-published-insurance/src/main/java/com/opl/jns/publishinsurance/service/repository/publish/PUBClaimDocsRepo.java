package com.opl.jns.publishinsurance.service.repository.publish;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.publishinsurance.service.domain.publish.*;

import java.util.*;

public interface PUBClaimDocsRepo extends JpaRepository<PUBClaimDocs, Long> {
	public List<PUBClaimDocs> findByClaimMasterIdAndIsActiveIsTrue(Long claimReferenceId);

	public List<PUBClaimDocs> findByClaimMasterIdAndIsActiveIsTrueAndMasterIdIn(Long claimReferenceId, List<Long> masterIds);

	public List<PUBClaimDocs> findByClaimMasterClaimIdAndIsActiveIsTrue(Long claimReferenceId);
	
	public List<PUBClaimDocs> findByDmsIdInAndIsActiveIsTrue(List<Long> dmsId);
	
//	public List<PUBClaimDocs> findByProductDocMapIdAndIsActiveIsTrue(Long claimReferenceId);
}
