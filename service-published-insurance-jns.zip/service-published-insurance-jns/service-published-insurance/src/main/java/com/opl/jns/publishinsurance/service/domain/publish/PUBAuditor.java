package com.opl.jns.publishinsurance.service.domain.publish;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author - Maaz Shaikh
 * @Date - 3/8/2023
 */
@Getter
@Setter
@MappedSuperclass
@EqualsAndHashCode
public class PUBAuditor {

	@Column(name = "created_date", nullable = true)
	private Date createdDate;

	@Column(name = "modified_date", nullable = true)
	private Date modifiedDate;

	@Column(name = "is_active", nullable = true)
	private Boolean isActive;

	public PUBAuditor() {
		super();
	}

	public PUBAuditor(Date createdDate, Boolean isActive) {
		super();
		this.createdDate = createdDate;
		this.isActive = isActive;
	}

}
