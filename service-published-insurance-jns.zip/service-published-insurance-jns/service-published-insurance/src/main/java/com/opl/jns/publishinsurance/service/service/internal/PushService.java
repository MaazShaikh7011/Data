package com.opl.jns.publishinsurance.service.service.internal;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.UpdateAppClaimRequest;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;

import java.io.IOException;



public interface PushService {

	/**
	 * ENROLLMENT DATA PUSH
	 * 
	 * @param applicationId (APPLICATION MASTER PRIMARY ID)(INSURANCE DATABASE)
	 * @return PushPullResponse with message and status
	 * @throws Exception
	 */
	public void pushEnrolmentData(long applicationId) throws Exception;

	/**
	 *  PUSH STORAGE ID ONLY IN SPECIFIC CASES
	 * @param storageId
	 * @param applicationId
	 * @return PUSHED STATUS
	 * @throws Exception
	 */

	public boolean pushStorageId(long applicationId,long storageId) throws Exception;

	/**
	 * CLAIM DATA PUSH
	 * 
	 * @param claimId (CLAIM MASTER PRIMARY ID)(INSURANCE DATABASE)
	 * @return PushPullResponse with message and status
	 */
	public void pushClaimDetails(Long claimId);

	/**
	 * CLAIM DOCS PUSH API IN CASE OF QUERY FROM INSURER AND DOCS UPDATED BY BANKER
	 *
	 * @param claimId
	 * @throws IOException 
	 */
	public boolean updateDocsInCaseOfQuery(Long claimId) throws IOException;

	public ClmMaster updateStatusFromPublish(UpdateAppClaimRequest updateAppClaimRequest, PUBClaimMaster claimMaster);

	/**
	 * FOR PUSHING APPLICATION IN CASE OF NOT PUBLISHED
	 *
	 * @param page
	 * @param count
	 */
	public void pushApplicationHasError(int page, int count);

	/**
	 * NOMINEE UPDATE DATA PUSH
	 * 
	 * @param applicationId (APPLICATION MASTER PRIMARY ID)(INSURANCE DATABASE)
	 * @throws Exception
	 */
	public void pushNomineeUpdate(long applicationId,long schemeId) throws Exception;
}
