package com.opl.jns.publishinsurance.service.utils;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.opl.jns.ddregistry.api.model.pushClaim.PushClaimProxy;
import com.opl.jns.ddregistry.client.DedupeRegistryClient;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.repo.ClmDetailsRepository;
import com.opl.jns.ere.utils.CommonUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.ClaimStatus;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DeDupeRegistryAPIClient {


	@Autowired
	private DedupeRegistryClient dedupeRegistryClient;
	
	@Autowired
	private ClmDetailsRepository clmDetailsRepository;

	
	/**
	 * PUSH CLAIM DETAILS INTO DE-DUPE REGISTRY
	 * 
	 * @param claimMaster
	 * @return
	 */
	public CommonResponse callPushClaimRequestV3(ClmMaster claimMaster,String masterPolicyNo) {
		try {
			CommonResponse commonResponse = dedupeRegistryClient
					.callPushClaimRequest(getcallClaimPushRequestDataV3(claimMaster,masterPolicyNo));
			
			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData())
					&& !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);
			}
			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		} catch (Exception e) {
			log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
			return new CommonResponse(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					false);
		}
	}


	private PushClaimProxy getcallClaimPushRequestDataV3(ClmMaster claimMaster,String masterPolicyNo) {
		ClmDetails clmDetails = clmDetailsRepository.findById(claimMaster.getId()).orElse(null);
		
		PushClaimProxy pushClaimProxy = new PushClaimProxy();
		pushClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
		pushClaimProxy.setUrn(claimMaster.getUrn());
		pushClaimProxy.setScheme(SchemeMaster.getById(claimMaster.getSchemeId().longValue()).getShortName());
		pushClaimProxy.setGender(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClmDetails().getApGenderId())
				? Gender.fromId(claimMaster.getClmDetails().getApGenderId()).getBankValue()
				: null);
		pushClaimProxy.setApplicantAccNo(claimMaster.getClmDetails().getClmPIDetails().getApAccountNumber());
		pushClaimProxy.setOrgId(claimMaster.getOrgId());
		pushClaimProxy
				.setApplicantDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(claimMaster.getClmDetails().getClmPIDetails().getApDob()));
		pushClaimProxy.setInsurerOrgId(claimMaster.getInsurerOrgId());
		
		
		pushClaimProxy.setMasterPolicyNumber(masterPolicyNo);
		pushClaimProxy.setApplicantfirstName(claimMaster.getClmDetails().getClmPIDetails().getAcHolderName());
		pushClaimProxy.setApplicantmiddleName(claimMaster.getClmDetails().getClmPIDetails().getApMiddleName());
		pushClaimProxy.setApplicantlastName(claimMaster.getClmDetails().getClmPIDetails().getApLastName());
		pushClaimProxy.setDateofDeath(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateOfDeath()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(clmDetails.getDateOfDeath()) : null);
		pushClaimProxy
				.setDateofAccident(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateTimeOfAccident()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(clmDetails.getDateTimeOfAccident()) : null);
		pushClaimProxy.setClaimStatusId(ClaimStatus.CLAIM_SEND_TO_INSURER.getId());
		pushClaimProxy.setEnrollmentDate(CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getFirstEnrollmentDate()));
		if(claimMaster.getSchemeId()==SchemeMaster.PMSBY.getId().longValue()) {
			String typeOfDisability = null;
			if(!OPLUtils.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId())) {
				typeOfDisability = TypeOfDisability.fromId(clmDetails.getTypeOfDisabilityId()).getValue();
			}
			String typeOfLoss = !OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId()) && Objects.equals(clmDetails.getNatureOfLossId(), NatureOfLoss.DISABILITY.getId()) ? typeOfDisability : "-";
			pushClaimProxy.setClaimType(!OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId()) && Objects.equals(clmDetails.getNatureOfLossId(), NatureOfLoss.DEATH.getId()) ? NatureOfLoss.DEATH.getValue() : typeOfLoss );
		}else if(claimMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().longValue() && (!OPLUtils.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId()))) {		
				String typeOfLoss=Objects.equals(clmDetails.getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.ACCIDENTAL_30_DAYS.getId()) ? "Accidental Death" : "-";
				pushClaimProxy.setClaimType(Objects.equals(clmDetails.getCauseOfDeathDisabilityId(), CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getId()) ? CauseOfDeathDisabilityV2.NATURAL_DEATH_NON_ACCIDENTAL.getValue() :typeOfLoss );
			
		}
		pushClaimProxy.setClaimDate(!OPLUtils.isObjectNullOrEmpty(claimMaster.getClaimDate()) ? CommonUtils.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(claimMaster.getClaimDate()) : null);
		return pushClaimProxy;
	}
}
