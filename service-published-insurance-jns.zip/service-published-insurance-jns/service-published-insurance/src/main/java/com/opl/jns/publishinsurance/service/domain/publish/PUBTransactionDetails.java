package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.published.lib.utils.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author ravi.thummar Date : 15-06-2023
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "transaction_details", indexes = {@Index(columnList = "application_id,type", name = "PUB_TRANS_APP_TYPE")})
public class PUBTransactionDetails extends PUBAuditor {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_transaction_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_transaction_details_seq_gen", sequenceName = "pub_transaction_details_seq_gen", allocationSize = 1)
	private Long id;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private PUBApplicationMaster applicationMaster;

	@Column(name = "cover_start_date", nullable = true)
	private String coverStartDate;

	@Column(name = "cover_end_date", nullable = true)
	private String coverEndDate;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;
	
    @Column(name = "insurer_code")
    private String insurerCode;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Column(name = "year", nullable = true)
	private Integer year;

    @Convert(converter = AESEncryption.class)
	@Column(name = "trans_utr", nullable = true)
	private String transUtr;

    @Convert(converter = DateEncrypterAes.class)
	@Column(name = "trans_time_stamp", nullable = true)
	private Date transTimeStamp;

	@Column(name = "trans_amount", nullable = true)
	private Double transAmount;

	@Column(name = "trans_comment", nullable = true)
	private String transComment;

	@Column(name = "coi_storage_id", nullable = true)
	private Long coiStorageId;

    @Convert(converter = AESEncryption.class)
	@Column(name = "master_policy_no", nullable = true)
	private String masterPolicyNo;

	@OneToOne(mappedBy = "lastTransactionDetails", cascade = CascadeType.ALL)
	private PUBApplicationMaster applicationMasterV3;

	public PUBTransactionDetails(Date createdDate, boolean isActive) {
		super(createdDate, isActive);
	}

}
