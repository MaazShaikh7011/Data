package com.opl.jns.publishinsurance.service.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class CertificateInsDtlRequest {
	
	@NotNull
	private Long applicationId;
	
	@NotNull
	private Integer schemeId;
	
	@NotNull
	private Long orgId;

	private Boolean isDownload;
	
	private Boolean isCoiUpload;

}
