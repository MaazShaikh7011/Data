package com.opl.jns.publishinsurance.service.repository.publish;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.publishinsurance.service.domain.publish.PUBNomineeDetails;

import jakarta.transaction.Transactional;
import java.util.List;

public interface PUBNomineeDetailsRepo extends JpaRepository<PUBNomineeDetails, Long> {

	public List<PUBNomineeDetails> findByApplicationMasterIdAndIsActiveTrue(final long applicationId);
	
	PUBNomineeDetails findByTypeAndApplicationMasterIdAndIsActiveTrue(Integer type, Long applicationId);
	
	List<PUBNomineeDetails> findByTypeInAndApplicationMasterIdAndIsActiveTrue(List<Integer> type, Long applicationId);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("UPDATE PUBNomineeDetails SET isActive = FALSE WHERE applicationMaster.id = :applicationId AND type IN(:type)")
	void isActiveFalseByApplicationId(@Param("applicationId") Long applicationId, @Param("type") List<Integer> type);
	
}
