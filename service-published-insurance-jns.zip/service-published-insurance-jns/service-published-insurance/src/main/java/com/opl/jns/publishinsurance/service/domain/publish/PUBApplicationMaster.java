package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.published.lib.utils.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.*;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.*;
import java.util.*;

/**
 * @author ravi.thummar Date : 15-06-2023
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "application_master",indexes = {
		@Index(columnList = "application_id,is_active",name = "PUB_APP_MST_APP_ID_ACT"),
		@Index(columnList = "id,is_active",name = "PUB_APP_MST_ID_ACT"),
		@Index(columnList = "id,org_id,is_active",name = "PUB_APP_MST_ID_ORG_ACT"),
		@Index(columnList = "id,insurer_org_id,is_active",name = "PUB_APP_MST_ID_INS_ORG_ACT"),
		@Index(columnList = "org_id,is_active,push_ready_date",name = "PUB_APP_MST_ORG_ACT_PUSH_READY_DATE"),
		@Index(columnList = "insurer_org_id,is_active,push_ready_date",name = "PUB_APP_MST_INS_ORG_ACT_PUSH_READY_DATE")
})
public class PUBApplicationMaster extends PUBAuditor {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_application_master_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_application_master_seq_gen", sequenceName = "pub_application_master_seq_gen", allocationSize = 1)
	private Long id;

	@Column(name = "application_id", nullable = true)
	private Long applicationId;

	@Column(name = "urn", nullable = true)
	private String urn;

	@Column(name = "scheme_id", nullable = true)
	private Integer schemeId;

	@Column(name = "scheme_name", nullable = true)
	private String schemeName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "account_number", nullable = true)
	private String accountNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "cif", nullable = true)
	private String cif;

	@Column(name = "org_id", nullable = true)
	private Long orgId;

	@Column(name = "org_name", nullable = true)
	private String orgName;
	@Column(name = "org_code", nullable = true)
	private String orgCode;

	@Column(name = "user_id", nullable = true)
	private Long userId;

	@Column(name = "branch_id", nullable = true)
	private Long branchId;

	@Column(name = "branch_name", nullable = true)
	private String branchName;

	@Column(name = "enrollment_date", nullable = true)
	private String enrollmentDate;
	
	@Column(name = "completion_date", nullable = true)
	private Date completionDate;

	@Column(name = "premium_amount", nullable = true)
	private Double premiumAmount;

	@Column(name = "application_status", nullable = true)
	private Integer applicationStatus;

	@Column(name = "message", nullable = true)
	private String message;

	@Column(name = "insurer_org_id", nullable = true)
	private Long insurerOrgId;

	@Column(name = "insurer_org_name", nullable = true)
	private String insurerOrgName;

	@Column(name = "insurer_org_code", nullable = true)
	private String insurerOrgCode;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "applicationMaster")
	@PrimaryKeyJoinColumn
	private PUBApplicationMasterOtherDetails applicationMasterOtherDetails;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "applicationMaster")
	private PUBApplicantInfo applicantInfo;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY,mappedBy = "applicationMaster")
	private List<PUBNomineeDetails> nomineeDetails;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "last_transaction_id")
	private PUBTransactionDetails lastTransactionDetails;

	@Column(name = "amount", nullable = true)
	private Double amount;

	@Column(name = "push_ready_date", nullable = true)
	private Date pushReadyDate;
	
	@Column(name = "enroll_type", nullable = true)
	private Integer enrollType;

	public PUBApplicationMaster(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
