package com.opl.jns.publishinsurance.service.service.internal.impl;

import java.io.IOException;
import java.io.InputStream;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.IOUtils;
import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.PushClaimStatustoBankReqV3;
import com.opl.jns.api.proxy.banks.v3.pushClaimStatusToBank.UpdateTransactionRequestV3;
import com.opl.jns.api.proxy.insurer.UpdateDocQuery.ClaimStatusWebhook;
import com.opl.jns.api.proxy.insurer.UpdateDocQuery.Document;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ApplicationPushStatus;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.MiscellaneousAudit;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.domain.v2.TransactionDetailsV2;
import com.opl.jns.ere.enums.EnrollPushType;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ApplicationPushStatusRepo;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.repo.MiscellaneousAuditRepository;
import com.opl.jns.ere.repo.v2.NomineeDetailsRepositoryV2;
import com.opl.jns.ere.repo.v2.NomineePIDetailsRepository;
import com.opl.jns.ere.repo.v2.TransactionDetailsRepositoryV2;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDocs;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimDocsRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimMasterRepo;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.publishinsurance.service.utils.BankAndInsurerPushDataUtils;
import com.opl.jns.publishinsurance.service.utils.GetSetUtils;
import com.opl.jns.utils.enums.ClaimStatus;
import com.opl.jns.utils.enums.MiscellaneousType;
import com.opl.jns.webhook.client.WebHookClient;

import lombok.extern.slf4j.Slf4j;

@Component
@Transactional
@Slf4j
public abstract class BankAndInsurerPushAbstract {

	@Autowired
	private ApplicationPushStatusRepo applicationPushStatusRepo;

	@Autowired
	private ApplicationMasterRepositoryV3 appMasterRepo;

	@Autowired
	private ClmMasterRepository clmMasterRepository;

	@Autowired
	private PUBClaimMasterRepo pubClaimMasterRepo;

	@Autowired
	private TransactionDetailsRepositoryV2 transactionDetailsRepository;

	@Autowired
	private MiscellaneousAuditRepository miscellaneousAuditRepository;

	@Autowired
	private NomineeDetailsRepositoryV2 nomineeDetailsRepositoryV2;

	@Autowired
	private NomineePIDetailsRepository nomineePIDetailsRepository;

	@Autowired
	private PUBClaimDocsRepo pubClaimDocsRepo;
	
	@Autowired
	private BankAndInsurerPushDataUtils bankAndInsurerPushDataUtils;
	
	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private DMSService dmsService;
	
	@Autowired
	private WebHookClient webHookClient;

	public void pushEnrollmentBankInsurer(List<Long> isBankInsurerPushPendingApp,boolean isManual) {
		for (Long appId : isBankInsurerPushPendingApp) {
			ApplicationMasterV3 appMaster = appMasterRepo.findByIdAndIsActiveTrue(appId);
			if (OPLUtils.isObjectNullOrEmpty(appMaster)) {
				log.info("EXIT IN PUSH ENROLLMENT DATA (APPLICATION MASTER NOT DATA FOUND BY APPLICATION ID) --->"
						+ appId);
				continue;
			}
			ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(appId).orElse(null);

			/** PREPARE REQUEST AND CALL WEBHOOK FOR PUSH ENROLLMENT BANK AND INSURER */
			bankAndInsurerPushDataUtils.pushEnrollmentDataBankAndInsurer(appMaster, applicationPushStatus,isManual);
		}
	}

	public void pushOptOutBankInsurer(List<Long> isBankInsurerPushPendingApp) throws IOException {
		for (Long appId : isBankInsurerPushPendingApp) {

			ApplicationMasterBothSchemeProxy applicationMaster = null;
			applicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMSBY.getId(), appId);
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				applicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMJJBY.getId(),
						appId);
			}
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				log.info(
						"EXIT IN PUSH OPT OUT DATA (JNS_MASTER APPLICATION MASTER NOT DATA FOUND BY APPLICATION ID) --->"
								+ appId);
				continue;
			}

			MiscellaneousAudit msAdt = miscellaneousAuditRepository.findFirstByApplicationIdAndTypeAndIsActiveTrue(
					applicationMaster.getId(), MiscellaneousType.OPT_OUT.getId());
			if (OPLUtils.isObjectNullOrEmpty(msAdt)) {
				log.info("EXIT IN PUSH OPT OUT DATA (MISCELLANEOUS AUDIT NOT DATA FOUND BY APPLICATION ID) --->"
						+ appId);
				continue;
			}

			ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(appId).orElse(null);

			/**CALL WEBHOOK FOR OPT OUT UPDATE STATUS*/
			callWebhookForPushOptOutUpdateStatusBankAndInsurer(msAdt.getAccountNumber(), msAdt.getUrn(), msAdt.getCif(),
					applicationMaster, msAdt.getDateOfEffective(), applicationPushStatus);
		}
	}

	public void callWebhookForPushOptOutUpdateStatusBankAndInsurer(String accNo, String urn, String cif,
			ApplicationMasterBothSchemeProxy applicationMaster, Date coverEndDate,
			ApplicationPushStatus applicationPushStatus) throws IOException {

		/** PREPARE OPT OUT UPDATE STATUS REQUEST */
		OptOutUpdateStatusRequestV3 updateStatusReq = GetSetUtils.prepareOptOutUpdateStatusRequestV3(accNo, urn, cif,
				applicationMaster, coverEndDate);

		/** BANK WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getBankOptOutPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getBankOptOutPush())) {
			log.info("isBankCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource()),applicationMaster.getId());
			log.info("isOptOutCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isOptOutCall(applicationMaster.getOrgId()),applicationMaster.getId());
			if(OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource()) && OPLUtils.isOptOutCall(applicationMaster.getOrgId())) {
				optOutUpdateStatus(updateStatusReq, applicationMaster.getCreatedBy());
			}else {
				ereCommonService.updateEnrollPushStatus(EnrollPushType.BANK_OPT_OUT_PUSH, applicationMaster.getId(), true, new Date());
			}
		}

		/** INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		log.info("isOptOutCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isOptOutCall(applicationMaster.getInsurerOrgId()),applicationMaster.getId());
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getInsurerOptOutPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getInsurerOptOutPush())) {
			if(OPLUtils.isOptOutCall(applicationMaster.getInsurerOrgId())) {				
				updateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
				updateStatusReq.setIsInsurer(true);
				optOutUpdateStatus(updateStatusReq, applicationMaster.getCreatedBy());
			}else {
				ereCommonService.updateEnrollPushStatus(EnrollPushType.INSURER_OPT_OUT_PUSH, applicationMaster.getId(), true, new Date());
			}
		}
	}

	/** CALL WEBHOOK FOR OPT OUT UPDATE STATUS */
	public void optOutUpdateStatus(OptOutUpdateStatusRequestV3 outUpdateStatusReq, Long userId) throws IOException {
		outUpdateStatusReq.setCommonUserId(userId);
		webHookClient.optOutUpdateStatus(outUpdateStatusReq);
	}

	public void pushNomineeUpdateBankInsurer(List<Long> isBankInsurerPushPendingApp) throws IOException {
		for (Long appId : isBankInsurerPushPendingApp) {

			ApplicationMasterBothSchemeProxy applicationMaster = null;
			applicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMSBY.getId(), appId);
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				applicationMaster = ereCommonService.getJnsMasterDataApplicationMaster(SchemeMaster.PMJJBY.getId(),
						appId);
			}
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				log.info(
						"EXIT IN PUSH NOMINEE UPDATE DATA (JNS_MASTER APPLICATION MASTER NOT DATA FOUND BY APPLICATION ID) --->"
								+ appId);
				continue;
			}

			NomineeDetailsV2 nomineeMaster = nomineeDetailsRepositoryV2
					.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(appId);
			if (OPLUtils.isObjectNullOrEmpty(nomineeMaster)) {
				log.info(
						"EXIT IN PUSH NOMINEE UPDATE DATA (JNS_MASTER NOMINEE DETAILS NOT DATA FOUND BY APPLICATION ID) --->"
								+ appId);
				continue;
			}

			NomineePIDetails nomineePIDtl = nomineePIDetailsRepository.findById(nomineeMaster.getId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(nomineePIDtl)) {
				log.info(
						"EXIT IN PUSH NOMINEE UPDATE DATA (JNS_MASTER NOMINEE PI DETAILS NOT DATA FOUND BY APPLICATION ID) --->"
								+ appId);
				continue;
			}

			ApplicationPushStatus applicationPushStatus = applicationPushStatusRepo.findById(appId).orElse(null);

			/**CALL WEBHOOK FOR NOMINEE UPDATE STATUS*/
			callWebhookForPushNomineeUpdateStatusBankAndInsurer(applicationMaster, nomineeMaster, nomineePIDtl,
					applicationPushStatus);
		}
	}

	public void callWebhookForPushNomineeUpdateStatusBankAndInsurer(ApplicationMasterBothSchemeProxy applicationMaster,
			NomineeDetailsV2 nomineeDetailsV2, NomineePIDetails nomineePIDetails,
			ApplicationPushStatus applicationPushStatus) throws IOException {

		/** PREPARE NOMINEE UPDATE STATUS REQUEST */
		NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq = GetSetUtils
				.prepareNomineeUpdateStatusRequestV3(applicationMaster, nomineeDetailsV2, nomineePIDetails);

		/** BANK WEBHOOK CALL FOR NOMINEE UPDATE STATUS */
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getBankNmnDtlsPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getBankNmnDtlsPush())) {
			log.info("isBankCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource()),applicationMaster.getId());
			log.info("isNomineeUpdateCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isNomineeUpdateCall(applicationMaster.getOrgId()),applicationMaster.getId());
			if(OPLUtils.isBankCall(applicationMaster.getOrgId(), applicationMaster.getSource()) && OPLUtils.isNomineeUpdateCall(applicationMaster.getOrgId())) {				
				nomineeUpdateStatus(nomineeUpdateStatusReq, applicationMaster.getCreatedBy());
			}else {
				ereCommonService.updateEnrollPushStatus(EnrollPushType.BANK_NMN_DTLS_PUSH, applicationMaster.getId(), true, new Date());
			}
		}

		/** INSURER WEBHOOK CALL FOR OPT OUT UPDATE STATUS */
		log.info("isNomineeUpdateCall ---> {} -------> APPLICATION ID ----> "+ OPLUtils.isNomineeUpdateCall(applicationMaster.getInsurerOrgId()),applicationMaster.getId());
		if (OPLUtils.isObjectNullOrEmpty(applicationPushStatus.getInsurerNmnDtlsPush())
				|| Boolean.FALSE.equals(applicationPushStatus.getInsurerNmnDtlsPush())) {
		if(OPLUtils.isNomineeUpdateCall(applicationMaster.getInsurerOrgId())) {
			nomineeUpdateStatusReq.setOrgId(applicationMaster.getInsurerOrgId());
			nomineeUpdateStatusReq.setIsInsurer(true);
			nomineeUpdateStatus(nomineeUpdateStatusReq, applicationMaster.getCreatedBy());
		}else {
			ereCommonService.updateEnrollPushStatus(EnrollPushType.INSURER_NMN_DTLS_PUSH, applicationMaster.getId(), true, new Date());
		}
	}
}

	/** CALL WEBHOOK FOR NOMINEE UPDATE STATUS */
	public void nomineeUpdateStatus(NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq, Long userId) throws IOException {
		nomineeUpdateStatusReq.setCommonUserId(userId);
		webHookClient.nomineeUpdateStatus(nomineeUpdateStatusReq);
	}

	public void pushClaimBankInsurer(List<Long> isBankInsurerPushPendingclmId) throws IOException {
		for (Long clmId : isBankInsurerPushPendingclmId) {
			ClmMaster claimMaster = clmMasterRepository.findById(clmId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				log.info("EXIT IN PUSH CLAIM DATA (NO CLAIM MASTER FOUND BY CLAIM ID) --->" + clmId);
				continue;
			}

			PUBClaimMaster pubClaimMst = pubClaimMasterRepo.findByClaimIdAndIsActiveTrue(clmId);
			if (OPLUtils.isObjectNullOrEmpty(pubClaimMst)) {
				log.info("EXIT IN PUSH CLAIM DATA (NO PUB CLAIM MASTER FOUND BY CLAIM ID) --->" + clmId);
				continue;
			}

			ApplicationMasterBothSchemeProxy master = ereCommonService.getJnsMasterDataApplicationMaster(
					claimMaster.getSchemeId().longValue(), claimMaster.getApplicationId());
			if (OPLUtils.isObjectNullOrEmpty(master)) {
				log.info("EXIT IN PUSH CLAIM DATA (NO JNS MASTER DB FOUND BY APPLICATION ID) --->"
						+ claimMaster.getApplicationId());
				continue;
			}

			TransactionDetailsV2 transactionDetailsV2 = transactionDetailsRepository
					.findById(master.getLastTransactionId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(master)) {
				log.info("EXIT IN PUSH CLAIM DATA (NO JNS MASTER--TRANSACTION DETAILS FOUND BY TRANSACTION ID) --->"
						+ master.getLastTransactionId());
				continue;
			}

			/** PREPARE REQUEST AND CALL WEBHOOK FOR PUSH CLAIM BANK AND INSURER */
			bankAndInsurerPushDataUtils.pushClaimDataBankAndInsurer(claimMaster,
					transactionDetailsV2.getMasterPolicyNo(), pubClaimMst);
		}
	}

	public void pushClaimStatusInsurer(List<Long> isBankInsurerPushPendingclmId) throws IOException {
		for (Long clmId : isBankInsurerPushPendingclmId) {
			ClmMaster claimMaster = clmMasterRepository.findById(clmId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				log.info("EXIT IN PUSH CLAIM STATUS DATA (NO CLAIM MASTER FOUND BY CLAIM ID) --->" + clmId);
				continue;
			}

			PUBClaimMaster pubClaimMaster = pubClaimMasterRepo.findByClaimIdAndIsActiveTrue(clmId);
			if (OPLUtils.isObjectNullOrEmpty(pubClaimMaster)) {
				log.info("EXIT IN PUSH CLAIM STATUS DATA (NO PUB CLAIM MASTER FOUND BY CLAIM ID) --->" + clmId);
				continue;
			}

			/**PREPARE STORAGE ID LIST*/
			List<Long> storageList = new ArrayList<>();
			String[] strings = !OPLUtils.isObjectNullOrEmpty(claimMaster.getQueriedStorageId()) ? claimMaster.getQueriedStorageId().split(",") : null;
            if (null != strings) {
                for (String s : strings) {
                    storageList.add(Long.valueOf(s.trim()));
                }
            if(!OPLUtils.isListNullOrEmpty(storageList)) {            	
            	List<PUBClaimDocs> clmDocs = pubClaimDocsRepo
            			.findByDmsIdInAndIsActiveIsTrue(storageList);
            	if (OPLUtils.isListNullOrEmpty(clmDocs)) {
            		log.info("EXIT IN PUSH CLAIM STATUS DATA (NO PUB CLAIM DOCS FOUND BY CLAIM ID) --->" + clmId);
            		continue;
            	}
            	/**PREPARE REQUEST FOR PUSH CLAIM STATUS INSURER*/
    			ClaimStatusWebhook claimStatusPushRequest = prepareClaimStatusPushRequest(claimMaster, clmDocs);
    			
    			/**CALL WEBHOOK FOR PUSH CLAIM STATUS INSURER*/
    			claimStatusPush(claimStatusPushRequest);
            }else {
            	log.info("EXIT IN PUSH CLAIM STATUS DATA (CLAIM MASTER QUERIED STORAGE ID NOT FOUND) --->" + clmId);
        		continue;
            }
            }
		}
	}

	public ClaimStatusWebhook prepareClaimStatusPushRequest(ClmMaster claimMaster, List<PUBClaimDocs> pubClaimDocs) {
		ClaimStatusWebhook wbRequest = new ClaimStatusWebhook(claimMaster.getInsurerClaimId(), claimMaster.getId(),
				claimMaster.getUrn(), claimMaster.getStatus() == ClaimStatus.CLAIM_SEND_TO_INSURER.getId()
						? ClaimStatus.CLAIM_INSURER_IN_PROGRESS.getId(): claimMaster.getStatus());
		List<Document> docList = new ArrayList<>();

		pubClaimDocs.stream().forEach(documents -> {
			InputStreamResource inputStreamResource = dmsService
					.downloadDocumentByProductDocumentId(documents.getDmsId());
			if (inputStreamResource != null) {
				try {
					Document doc = new Document();
					BeanUtils.copyProperties(documents, doc);
					doc.setDocumentType(documents.getDocumentType());
					doc.setDocumentId(documents.getMasterId());
					InputStream inputStream = inputStreamResource.getInputStream();
					byte[] bytes = IOUtils.toByteArray(inputStream);
					doc.setDocument(bytes);
					docList.add(doc);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		wbRequest.setDocuments(docList);
		wbRequest.setOrgId(claimMaster.getInsurerOrgId());
		wbRequest.setIsInsurer(true);
		wbRequest.setCommonUserId(claimMaster.getCreatedBy());
		wbRequest.setApplicationId(claimMaster.getApplicationId());
		wbRequest.setClaimRefId(claimMaster.getId());
		wbRequest.setRemarks(claimMaster.getRemarks());
	    wbRequest.setMessage("Uploaded documents submitted successfully.");
		return wbRequest;
	}

	/** CALL WEBHOOK FOR CLAIM STATUS PUSH */
	public void claimStatusPush(ClaimStatusWebhook wbRequest) throws IOException {
		webHookClient.updateDocToInsurerForQuery(wbRequest);
	}
	
	public void pushClaimStatusBank(List<Long> isBankInsurerPushPendingclmId) throws IOException {
		for (Long clmId : isBankInsurerPushPendingclmId) {
			ClmMaster claimMaster = clmMasterRepository.findById(clmId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(claimMaster)) {
				log.info("EXIT IN PUSH CLAIM STATUS DATA (NO CLAIM MASTER FOUND BY CLAIM ID) --->" + clmId);
				continue;
			}

			/**PUSH CLAIM STATUS TO BANK*/
			PushClaimStatustoBankReqV3 bankReq = prepareRequestPushClaimStatusToBank(claimMaster);
			claimStatusPushBank(bankReq,claimMaster.getId());
		}
	}
	
	/** CALL WEBHOOK FOR CLAIM STATUS PUSH BANK */
	public void claimStatusPushBank(PushClaimStatustoBankReqV3 bankReq,Long claimId) throws IOException {
		webHookClient.pushClaimStatusToBank(bankReq);
	}
	
	public PushClaimStatustoBankReqV3 prepareRequestPushClaimStatusToBank(ClmMaster claimMaster) {
		PushClaimStatustoBankReqV3 bankReq=new PushClaimStatustoBankReqV3();
		bankReq.setOrgId(claimMaster.getOrgId());
		bankReq.setClaimId(claimMaster.getInsurerClaimId());
		bankReq.setClaimReferenceId(claimMaster.getId());
		bankReq.setClaimStatus(claimMaster.getStatus() == ClaimStatus.CLAIM_SEND_TO_INSURER.getId()
				? ClaimStatus.CLAIM_INSURER_IN_PROGRESS.getId(): claimMaster.getStatus());	
		bankReq.setInsurerStatus(claimMaster.getInsurerStatus());
		bankReq.setReason(claimMaster.getStatusReasonId());
		bankReq.setUrn(claimMaster.getUrn());
		bankReq.setCommonUserId(claimMaster.getCreatedBy());
		bankReq.setApplicationId(claimMaster.getApplicationId());
		UpdateTransactionRequestV3 transactionRequest=new UpdateTransactionRequestV3();
		transactionRequest.setTransactionAmount(claimMaster.getTransactionAmount());
		transactionRequest.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionTimeStamp()) ? claimMaster.getTransactionTimeStamp().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null);
		transactionRequest.setTransactionUTR(claimMaster.getTransactionUTR());
		bankReq.setTransactionDetails(transactionRequest);
		bankReq = WebHookClient.pushClmStausBnkManageRequest(bankReq);
		return bankReq;
    }
	
}
