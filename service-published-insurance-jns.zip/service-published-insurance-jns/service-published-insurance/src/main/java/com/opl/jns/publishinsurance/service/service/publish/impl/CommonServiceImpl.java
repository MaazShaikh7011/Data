package com.opl.jns.publishinsurance.service.service.publish.impl;

import java.text.ParseException;

import org.springframework.stereotype.Service;

import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.publish.CommonService;
import com.opl.jns.publishinsurance.service.utils.CommonUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 4/24/2023
 */
@Service
@Slf4j
public class CommonServiceImpl implements CommonService {

    
    public String parseAndFormatDateUsing_sdf(String dob) {
    	if(OPLUtils.isObjectNullOrEmpty(dob)) {
    		return null;
    	}
        if (!OPLUtils.isObjectNullOrEmpty(dob)) {
        	if(dob.equals("string")) {
        		return null;
        	}
            try {
                return Constants.sdf.format(Constants.sdf.parse(dob));
            } catch (Exception e) {
                log.error("Exception in parsing date : ", e);
                try {                	
                	return CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.parse(dob));
                }catch (Exception e1) {
                	log.error("Exception in parsing date : ", e1);
                	try {
						return CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(CommonUtils.sdf_dd_MM_yyyy_T_HH_mm_ss_SS.parse(dob));
					} catch (ParseException e2) {
						e2.printStackTrace();
					}
				}
            }
        }

        return null;
    }

}
