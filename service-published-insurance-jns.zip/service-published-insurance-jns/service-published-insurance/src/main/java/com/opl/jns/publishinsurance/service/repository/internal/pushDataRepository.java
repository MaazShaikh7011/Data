package com.opl.jns.publishinsurance.service.repository.internal;

import org.springframework.stereotype.Repository;

@Repository
public interface pushDataRepository {

	String fetchPublishedAppList(String query);

	String fetchAppCount(String query);

	String fetchPublishedClaimList(String query);

	String fetchClaimCount(String query);
}
