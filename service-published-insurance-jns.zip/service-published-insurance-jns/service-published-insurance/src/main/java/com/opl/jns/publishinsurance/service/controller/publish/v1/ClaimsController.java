package com.opl.jns.publishinsurance.service.controller.publish.v1;

import com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup.ClaimDeDupRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.ClaimDeDup.ClaimDedupResponse;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ApplicationClaimRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ClaimDetailsProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ClaimDetailsResponse;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList.ClaimProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList.ClaimRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList.ClaimResponse;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.ClaimUploadedDocumentDetailsResponse1_1;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.UploadedDocumentsDetailsProxy1_1;
import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.UpdateAppClaimRequest;
import com.opl.jns.published.lib.utils.APIAuthUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response400;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response401;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.publish.ClaimService;
import com.opl.jns.publishinsurance.service.service.publish.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/***
 * 
 * @author Maaz Shaikh
 * @date : 04/03/2023
 */

@RestController
@RequestMapping(Constants.REQUEST_MAPPING_V1)
@Slf4j
@Tag(name = "2. Claim V1", description = "List of Claim APIs for version 1")
public class ClaimsController {

    @Autowired
	ValidationService validationService;

    @Autowired
	ClaimService claimService;


	@PostMapping(value = "/getClaimList", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(
			operationId = Constants.STR_3,
			summary = Constants.COMMON_BASIC_INSURANCE_APP_CLAIM_MESSAGE,
    		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
            content = @Content(examples = {
                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.ENROLLMENT_APPLICATION_LIST_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
            })),
			responses = {
				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
						 content = {
								 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimResponse.class),
										 examples = {
												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_LIST_EXAMPLE),
												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
										 })
						 }),
				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
						 content = {
								 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
										 examples = {
												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
										 }

								 )
						 }),
				 @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//						 examples = {
//								 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//								 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//						 }
				 )})
    						 
		})
    public ResponseEntity<CommonResponse> getClaimList(@Valid @RequestBody ClaimRequest applicationRequest, HttpServletRequest httpServletRequest) {
        try {
            Long userOrgId=Long.valueOf(String.valueOf(httpServletRequest.getAttribute(APIAuthUtils.REQ_ATR_ORG_ID)));
            log.info(Constants.USER_ORG_ID,userOrgId);
            List<ClaimProxy> response = claimService.getClaimApplicationListForPush(applicationRequest.getFromDate(), applicationRequest.getToDate(), userOrgId);
            return new ResponseEntity<>(new CommonResponse(Constants.SUCCESS, response, HttpStatus.OK.value(), !OPLUtils.isListNullOrEmpty(response) ? Boolean.TRUE : Boolean.FALSE),HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getApplicationList() ", e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }

    }
	@PostMapping(value = "/getClaimApplicationDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(
		operationId = Constants.STR_4,
		summary = Constants.COMMON_BASIC_INSURANCE_APP_CLAIM_DETAIL_MESSAGE,
		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
		content = @Content(examples = {
				@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_APPLICATION_LIST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
				@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
		})),
		responses = {
				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
						 content = {
								 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimDetailsResponse.class),
										 examples = {
												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_APPLICATION_RESPONSE_EXAMPLE),
												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
										 })
						 }),
				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//										 examples = {
//												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
//												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//										 }

								 )
						 }),
				 @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
						 content = {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response401.class),
						 examples = {
								 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
								 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
						 }
				 )})

		})
    public ResponseEntity<CommonResponse> getApplicationDetails(@Valid @RequestBody ApplicationClaimRequest detailsRequest, HttpServletRequest httpServletRequest) {
        try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, detailsRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				CommonResponse matchResponse = new CommonResponse(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}

            ClaimDetailsProxy data = claimService.getClaimApplicationDetails(detailsRequest.getClaimReferenceId());
            return new ResponseEntity<>(new CommonResponse(Constants.SUCCESS, data, HttpStatus.OK.value(), !OPLUtils.isObjectNullOrEmptyOrDash(data) ? Boolean.TRUE : Boolean.FALSE),HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in getApplicationDetails() ", e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,
                    HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getUploadedDocuments", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(
			operationId = Constants.STR_5,
			summary = Constants.COMMON_DOCUMENT_MESSAGE,
    		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
            content = @Content(examples = {
                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_UPLOAD_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
            })),
			responses = {
				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
						 content = {
								 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimUploadedDocumentDetailsResponse1_1.class),
										 examples = {
												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_UPLOAD_RESPONSE_EXAMPLE),
												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
										 })
						 }),
				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
						 content = {
								 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
										 examples = {
												 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
												 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
										 }

								 )
						 }),
				 @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//						 examples = {
//								 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//								 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//						 }
				 )})

		})
	public ResponseEntity<CommonResponse> getUploadedDocuments(@Valid @RequestBody GetClaimDocumentRequest claimRequest, HttpServletRequest httpServletRequest) {
        try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, claimRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				CommonResponse matchResponse = new CommonResponse(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}

            StringBuilder message = new StringBuilder();
            UploadedDocumentsDetailsProxy1_1 data = claimService.getUploadedDocumentDetails(claimRequest,  message);
            if (!OPLUtils.isObjectNullOrEmpty(data) && !OPLUtils.isObjectNullOrEmpty(data.getClaimReferenceId())) {
                return new ResponseEntity<>(new CommonResponse(Constants.MSG.SUCCESS, data, HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new CommonResponse(!OPLUtils.isObjectNullOrEmpty(message) ? message.toString() : null, !OPLUtils.isObjectNullOrEmpty(message) ? message.toString() : null, HttpStatus.BAD_REQUEST.value(), Boolean.FALSE), HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getUploadedDocuments() {}", e.getMessage());
            return new ResponseEntity<>(new CommonResponse("SOMETHING_WENT_WRONG", false, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }

    }
 /*   @PostMapping(value = "/updateClaimStatus", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(
			operationId = Constants.STR_6,
			summary = Constants.UPDATE_INSURANCE_STATUS_MESSAGE,
    		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
            content = @Content(examples = {
                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION_FOR_UPDATE_STATUS),
                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
            })),
    		responses = {
   				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
						 content = {
                                 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommonResponse.class),
                                         examples = {
                                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_RESPONSE_EXAMPLE),
                                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                                         })
                         }),
				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
						 content = {
                                 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
                                         examples = {
                                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
                                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
                                         }

                                 )
                         }),
				 @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//                         examples = {
//                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WIHTOUT_FLAG_PLAIN_RESPONSE_401),
//                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//                         }
                 )})

		})
    public ResponseEntity<CommonResponse> updateApplicationStatus(@Valid @RequestBody UpdateAppClaimRequest updateAppClaimRequest, HttpServletRequest httpServletRequest) {
        try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, updateAppClaimRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				CommonResponse matchResponse = new CommonResponse(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}
//			Long apiUserId=null;
//			if(null != httpServletRequest.getAttribute(AuthCredentialUtils.APP_USER_ID)){
//				apiUserId = Long.valueOf(httpServletRequest.getAttribute(AuthCredentialUtils.APP_USER_ID).toString());
//			}
            StringBuilder message = new StringBuilder();
//            CommonResponse commonResponse=claimService.updateClaimStatus(updateAppClaimRequest,  message,httpServletRequest);
//            return new ResponseEntity<>(commonResponse,HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error in getApplicationDetails() {} ", e.getMessage());
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
		return null;

    }
*/
/*
	@PostMapping(value = "/claimDeDup", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(
			operationId = Constants.STR_7,
			summary = Constants.CLAIM_DEDUPE_API_MESSAGE,
			requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
					content = @Content(examples = {
							@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.CLAIM_PLAIN_DE_DUPE_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
							@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
					})),
			responses = {
					@ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
							content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimDedupResponse.class),
											examples = {
													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_PLAIN_DE_DUPE_SUCCESS_RESPONSE_EXAMPLE),
													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
											})
							}),
					@ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
							content = {
									@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
											examples = {
													@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.DEDUPE_FAILED_PLAIN_RESPONSE_400),
													@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
											}

									)
							}),
					@ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
							 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//									examples = {
//											@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_401),
//											@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//									}
							)})

			})
	public ResponseEntity<CommonResponse> claimDeDup(@Valid @RequestBody ClaimDeDupRequest dedupeRequest, HttpServletRequest httpServletRequest) {
		try {
			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, dedupeRequest.getClaimReferenceId());
			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
				CommonResponse matchResponse = new CommonResponse(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
			}
//			CommonResponse commonResponse = claimService.getClaimDedupeData(dedupeRequest);
//			return new ResponseEntity<>(commonResponse, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getApplicationDetails() {} ", e.getMessage());
			return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
		return null;

	}
*/








}
