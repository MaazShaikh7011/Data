package com.opl.jns.publishinsurance.service.utils;

public enum ResponseStatus {

    APPLICATION_IN_PROGRESS(100),    
    AGE_IN_VALID_ERROR(101),
    APPLICATION_ALREADY_TAKEN_INSURANCE_FOR_SELECTED_HOLDER(102),
    KYC_NOT_UPDATED(103),
    AMOUNT_INVALID_ERROR(104),
    CUSTOMER_DETAIL_NOT_VALID_ERROR(105),
    ENROLLEMENT_IN_PROGRESS(106),
    SUCCESS(200),
    NO_CONTENT(204),
    BAD_REQUEST(400),
    EXCEPTION_IN_PROCESSING(500);
    int statusId;

    ResponseStatus(int statusId){
        this.statusId=statusId;
    }
   public int getStatusId(){
        return this.statusId;
    }

}
