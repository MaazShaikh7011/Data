package com.opl.jns.publishinsurance.service.repository.publish;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.*;
import org.springframework.transaction.annotation.*;

import com.opl.jns.publishinsurance.service.domain.publish.*;

public interface PUBTransactionDetailsRepo extends JpaRepository<PUBTransactionDetails, Long> {

	public PUBTransactionDetails findByApplicationMasterIdAndIsActiveTrue(final long applicationId);


	@Transactional
	@Modifying
	@Query("update PUBTransactionDetails set coiStorageId=:storageId where id=:id")
	void updateStorageIdInTransaction(@Param("storageId") Long var1, @Param("id") Long var2);

}
