package com.opl.jns.publishinsurance.service.repository.publish;

import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationProxy;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface PUBApplicationMasterRepo extends JpaRepository<PUBApplicationMaster, Long> {

	PUBApplicationMaster findByApplicationIdAndIsActiveTrue(long applicationId);
	PUBApplicationMaster findByApplicationId(long applicationId);
	PUBApplicationMaster findFirstByApplicationIdAndIsActiveTrue(long applicationId);

	List<PUBApplicationMaster> findAllByInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long insOrgId, Date fromCreatedDate, Date toCreatedDate);



	@Query("select new com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationProxy(id,schemeId,urn) from PUBApplicationMaster where insurerOrgId =:insOrgId and isActive = true and pushReadyDate between :fromCreatedDate and :toCreatedDate")
	List<ApplicationProxy> getByInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(@Param("insOrgId") Long insOrgId, @Param("fromCreatedDate") Date fromCreatedDate, @Param("toCreatedDate") Date toCreatedDate);

	List<PUBApplicationMaster> findAllByOrgIdAndIsActiveTrueAndPushReadyDateBetween(Long orgId, Date fromCreatedDate, Date toCreatedDate);

	PUBApplicationMaster findByIdAndIsActiveTrue(Long id);

	PUBApplicationMaster findByIdAndOrgIdAndIsActiveTrue(Long refId, Long bankOrgId);
	PUBApplicationMaster findByIdAndInsurerOrgIdAndIsActiveTrue(Long refId, Long insOrgId);

}
