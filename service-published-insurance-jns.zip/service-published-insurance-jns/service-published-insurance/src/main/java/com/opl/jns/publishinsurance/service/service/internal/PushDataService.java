package com.opl.jns.publishinsurance.service.service.internal;


import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;

public interface PushDataService {

//	PushPullResponse fetchPublishedAppList(String request);
	
//	PushPullResponse fetchPublishedClaimList(String request);

//	PushPullResponse getUploadedDocuments(String request,StringBuilder message);
	public byte[] getUploadedDocuments(GetClaimDocumentRequest documentRequest, StringBuilder message);
	
//	PushPullResponse fetchPublishApiAuditDetailList(String request);

}
