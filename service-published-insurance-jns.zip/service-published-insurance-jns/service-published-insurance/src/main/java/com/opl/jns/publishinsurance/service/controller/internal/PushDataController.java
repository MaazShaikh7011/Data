package com.opl.jns.publishinsurance.service.controller.internal;


import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ClaimDetailsProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import com.opl.jns.published.lib.utils.SkipInterceptor;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.internal.PushDataService;
import com.opl.jns.publishinsurance.service.service.publish.ClaimService;
import com.opl.jns.publishinsurance.service.service.publish.EnrollmentService;
import com.opl.jns.publishinsurance.service.utils.BankAndInsurerPushDataUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/publish")
@Slf4j
public class PushDataController {

   @Autowired
   PushDataService pushDataService;
   
   @Autowired
   EnrollmentService enrollmentService;
   
   @Autowired
   ClaimService claimService;
    
//   @Autowired
//   ApiAuditDetailService apiAuditDetailService;

    @Autowired
    BankAndInsurerPushDataUtils pushDataUtils;

   // fetchPublishedAppList = fetchEnrollmentList
//   @SkipInterceptor
//   @PostMapping(value = "/fetchEnrollmentList", produces = MediaType.APPLICATION_JSON_VALUE)
//   public ResponseEntity<PushPullResponse> fetchPublishedAppList(@RequestBody String request) {
//       try {
//       	return new ResponseEntity<>(pushDataService.fetchPublishedAppList(request), HttpStatus.OK);
//       } catch (Exception e) {
//       	log.error("Exception while fetchPublishedAppList ------>", e);
//       	 return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//       }
//		
//   }

   // fetchPublishedClaimList =  fetchClaimList
//    @SkipInterceptor
//    @PostMapping(value = "/fetchClaimList", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<PushPullResponse> fetchPublishedClaimList(@RequestBody String request) {
//        try {
//        	return new ResponseEntity<>(pushDataService.fetchPublishedClaimList(request), HttpStatus.OK);
//        } catch (Exception e) {
//        	log.error("Exception while fetchPublishedClaimList ------>", e);
//        	 return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//        }
//		
//    }
     // getPublishedAppFormDetails = getEnrollmentDetail
	
    @SkipInterceptor
    @GetMapping(value = "/getEnrollmentDetail/{applicationReferenceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getPublishedAppFormDetails(@PathVariable Long applicationReferenceId) {
        try {
        	 CommonResponse data = enrollmentService.getApplicationDetails(applicationReferenceId);
        	if(data == null) {
        		return new ResponseEntity<>(new CommonResponse("Its seems we have not found details by given information, kindly refresh page and try again",HttpStatus.BAD_REQUEST.value(), Boolean.TRUE), HttpStatus.OK);
        	}
        	return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    // getPublishedclaimFormDetails = getClaimDetail
    @SkipInterceptor
    @GetMapping(value ="/getClaimDetail/{claimReferenceId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getClaimDetail(@PathVariable Long claimReferenceId) {
        try {
        	ClaimDetailsProxy data = claimService.getClaimApplicationDetails(claimReferenceId);
        	if(data == null) {
        		return new ResponseEntity<>(new CommonResponse("Its seems we have not found details by given information, kindly refresh page and try again",HttpStatus.BAD_REQUEST.value(), Boolean.TRUE), HttpStatus.OK);
        	}
        	 return new ResponseEntity<>(new CommonResponse(Constants.SUCCESS, data, HttpStatus.OK.value(), !OPLUtils.isObjectNullOrEmptyOrDash(data) ? Boolean.TRUE : Boolean.FALSE),HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

  	  
//    @SkipInterceptor
//    @GetMapping(value = "/getPublishReqRes/{auditId}", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<?> getPublishReqRes(@PathVariable("auditId") Long auditId) {
//		try {			
//			log.info("Enter In getPublishReqRes() auditId -> ({})", auditId);
//			 return new ResponseEntity<>(apiAuditDetailService.getPublishReqRes(auditId, false), HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Exception while fetch Publish Req Res --->", e);
//			  return new ResponseEntity<>(new CommonResponse(Constants.ErrorMsg.SMTG_WNT_WRG, false,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//		}
//	}

    
    @SkipInterceptor
    @PostMapping(value = "/getUploadedDocuments", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> getUploadedDocuments(@RequestBody GetClaimDocumentRequest claimRequest) {
		try {			
			log.info("Enter In getUploadedDocuments()" + claimRequest);
			   StringBuilder message = new StringBuilder();
			 byte[] zipByte=pushDataService.getUploadedDocuments(claimRequest,message);
			 return new ResponseEntity<>(zipByte, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getUploadedDocuments  --->", e);
			 return new ResponseEntity<>(null, HttpStatus.OK);
		}
	}

//    @SkipInterceptor
//    @GetMapping(value = "/sqsLoadTesting/{count}")
//    public ResponseEntity<?> callSqs(@PathVariable("count") int count){
//        pushDataUtils.sqsLoadTesting(count);
//        return new ResponseEntity<>(new CommonResponse(Constants.SUCCESS, "Done", HttpStatus.OK.value(), Boolean.TRUE),HttpStatus.OK);
//    }

}
