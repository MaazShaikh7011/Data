package com.opl.jns.publishinsurance.service.repository.publish;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.publishinsurance.service.domain.publish.*;

public interface PUBApplicantInfoRepo extends JpaRepository<PUBApplicantInfo, Long> {

	public PUBApplicantInfoRepo findByApplicationMasterIdAndIsActiveTrue(final long applicationId);
}
