package com.opl.jns.publishinsurance.service.scheduler;

import com.opl.jns.published.lib.utils.*;
import com.opl.jns.publishinsurance.service.service.internal.*;

import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;

/**
 * @author - Maaz Shaikh
 * @Date - 12/14/2023
 */

@Component
@Slf4j
public class PublishSchedular {

    @Autowired
    PushService pushService;

    /**
     * In case of any error, this scheduler re-try it max 3 times This scheduler run
     * at every minute
     */
    @Scheduled(fixedDelay = 300000)
    public void pushApplicationsInCaseOfNotPushed() {
        String value = EnvironmentUtils.PUSH_READY_SCHEDULER_ENABLE.getValue();
        if ("ON".equalsIgnoreCase(value)) {
            log.info("application and claim scheduler for pushing the data =====> Start at :[{}]", new Date());

            // Enrollment And COI
            pushService.pushApplicationHasError(0,1000);

            // Push Claim
//            pushService.pushRemainingClaim();
        } else {
            log.info("PUSH READY APPLICATION SCHEDULE OFF FROM ENVIRONMENT PROPERTY");
        }

    }




}
