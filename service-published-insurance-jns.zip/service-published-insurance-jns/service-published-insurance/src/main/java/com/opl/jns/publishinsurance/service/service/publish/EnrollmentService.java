package com.opl.jns.publishinsurance.service.service.publish;

import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationProxy;

import java.time.LocalDateTime;
import java.util.List;

public interface EnrollmentService {
    public List<ApplicationProxy> getApplicationListForPush(LocalDateTime fromDateStr, LocalDateTime endDateStr, Long userOrgId) throws Exception;

    CommonResponse getApplicationDetails(Long applicationReferenceId) throws  Exception;


}
