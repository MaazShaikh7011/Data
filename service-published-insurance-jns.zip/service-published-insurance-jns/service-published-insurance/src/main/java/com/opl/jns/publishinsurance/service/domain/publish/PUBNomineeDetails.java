package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.ere.enums.*;
import com.opl.jns.published.lib.utils.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nominee_details",indexes = {
		@Index(columnList = "type,application_id,is_active",name="PUB_NOMINEE_TYPE_APP_ACT")
})
public class PUBNomineeDetails extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_nominee_details_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_nominee_details_seq_gen", sequenceName = "pub_nominee_details_seq_gen", allocationSize = 1)
	private Long id;

    @Convert(converter = AESEncryption.class)
	@Column(name = "first_name", nullable = true)
	private String firstName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "middle_name", nullable = true)
	private String middleName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "last_name", nullable = true)
	private String lastName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "mobile_number", nullable = true)
	private String mobileNumber;
	
	@Column(name = "correct_nominee_first_name", nullable = true)
	private String correctNomineeFirstName;

	@Column(name = "correct_nominee_middle_name", nullable = true)
	private String correctNomineeMiddleName;

	@Column(name = "correct_nominee_last_name", nullable = true)
	private String correctNomineeLastName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "email", nullable = true)
	private String email;

    @Convert(converter = AESEncryption.class)
	@Column(name = "dob", nullable = true)
	private String dob;

    @Convert(converter = AESEncryption.class)
	@Column(name = "name", nullable = true)
	private String name;

	@Column(name = "type", nullable = true)
	private Integer type;

	@Transient
	private NomineeType nomineeType;

	@Transient
	private RelationShip relationShip;

	@PostLoad
	void fillTransient() {
		if (type != null) {
			this.nomineeType = NomineeType.fromId(type);
		}
		if (null != relationId) {
			this.relationShip = RelationShip.fromId(relationId);
		}
	}

	@Column(name = "is_Other_Claimant", nullable = true)
	private Boolean isOtherClaimant;

    @Convert(converter = AESEncryption.class)
	@Column(name = "aadhar_number", nullable = true)
	private String aadhaarNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "pan_number", nullable = true)
	private String panNumber;

	@Column(name = "relation_id", nullable = true)
	private Integer relationId;

	@Column(name = "relation", nullable = true)
	private String relation;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private PUBApplicationMaster applicationMaster;

	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private PUBAddressMaster address;

	public PUBNomineeDetails(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
