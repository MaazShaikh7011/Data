package com.opl.jns.publishinsurance.service.config;

import com.opl.jns.published.utils.common.*;
import com.opl.jns.published.utils.config.*;
import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.*;
import io.swagger.v3.oas.models.parameters.*;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.*;
import io.swagger.v3.oas.models.servers.*;
import org.apache.commons.io.*;
import org.springdoc.core.customizers.*;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.*;
import org.springframework.core.io.*;
import org.springframework.http.*;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.resource.*;

import jakarta.servlet.http.*;
import java.io.*;
import java.nio.charset.*;
import java.util.*;
import java.util.stream.*;

@Configuration
public class Swagger2UiConfiguration implements WebMvcConfigurer {

    private static final String TOKEN_IS_NULL = "Token is null";

    private static final String REQUEST_DECRYPTION_KEY_IS_NULL = "Request decryption Key is null";

    private static final String TOKEN_EXPIRED = "Token is Expired";

    private static final String APPLICATION_EMPTY_MSG = "ApplicationId is null or empty ";

    private static final String API_TYPE_ID_IS_EMPTY = "Api Type is null or empty ";

    private static final String UNAUTHORIZED = "Invalid bank username and password";

    private static final String ILLEGAL_REQUEST = "Illegal Request (it contain zunk character)";

    private static final String INVALID_API_TYPE_MSG = "Invalid apiTypId";

    private static final String REQUEST_DATA_IS_EMPTY = "Request data is empty";

    private static final String DECRYTIPON_DATA_IS_EMPTY = "Decrytion data is empty";

    private static final String API_AUTH_REQ_IS_NULL = "Api Auth is null";

    private static final String APPLICATION_JSON = "application/json";

    private static final String[] BAD_REQUEST = new String[]{TOKEN_IS_NULL, REQUEST_DECRYPTION_KEY_IS_NULL, DECRYTIPON_DATA_IS_EMPTY,
            API_TYPE_ID_IS_EMPTY, APPLICATION_EMPTY_MSG, INVALID_API_TYPE_MSG, ILLEGAL_REQUEST, API_AUTH_REQ_IS_NULL};

    private static final String[] UNAUTHORIZEDs = new String[]{UNAUTHORIZED, TOKEN_EXPIRED,};

    private static final String[] NO_CONTENT = new String[]{REQUEST_DATA_IS_EMPTY};

    private static final  String DOMAIN = DataSourceProvider.getAnsAppServerDomain();
    static final Map<String,Integer> applicationOrderList = new HashMap<>();
    static{
        applicationOrderList.put("/v1/getApplicationList",1);
        applicationOrderList.put("/v1/getApplicationDetails",2);
        applicationOrderList.put("/v1/getClaimList",3);
        applicationOrderList.put("/v1/getClaimApplicatioapplicationOrderListnDetails",4);
        applicationOrderList.put("/v1/getUploadedDocuments",5);
        applicationOrderList.put("/v1/updateClaimStatus",6);
    }
    @Bean
    public GroupedOpenApi publicApiV1() {
        return GroupedOpenApi.builder()
                .addOpenApiCustomizer(sort())
                .group("Jansuraksha-Insurer-API V1(beta)")
                .packagesToScan("com.opl.jns.publishinsurance.service.controller.publish.v1")
                .addOperationCustomizer(customizeHeader())
                .build();
    }

    @Bean
    public GroupedOpenApi publicApiV2() {
        return GroupedOpenApi.builder()
                .addOpenApiCustomizer(sort())
                .group("Jansuraksha-Insurer-API V2(beta)")
                .packagesToScan("com.opl.jns.publishinsurance.service.controller.publish.v2")
                .addOperationCustomizer(customizeHeader())
                .build();
    }

    @Bean
    public OpenApiCustomizer sort() {
        return openApi -> openApi.setPaths(
            (Paths) openApi.getPaths().entrySet()
            .stream()
            .sorted(Comparator.comparingInt(pathItem -> {
                Operation op = null;
                if(!OPLUtils.isObjectNullOrEmpty(pathItem.getValue().getPost())){
                    op = pathItem.getValue().getPost();
                }else if(!OPLUtils.isObjectNullOrEmpty(pathItem.getValue().getGet())){
                    op = pathItem.getValue().getGet();
                }
                if (!OPLUtils.isObjectNullOrEmpty(op) && !OPLUtils.isObjectNullOrEmpty(op.getOperationId())) {
                    return Integer.parseInt(op.getOperationId());
                }
                return 0;
            }))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (x, y) -> y, Paths::new))
        );
    }

    @Value("${server.servlet.context-path}")
    String contextPath;

    @Bean
    public OpenAPI customOpenAPI() {
        Contact contact = new Contact();
        contact.setEmail("");
        //return new OpenAPI().addServersItem(new Server().url("http://localhost:8050" + contextPath))        
        return new OpenAPI().addServersItem(new Server().url(DOMAIN + contextPath.substring(1)))
                .info(new Info()
                        .title("JanSurksha Insurer Api")
                        .contact(contact)
                        .description("""
                                JanSurksha Insurer API document includes two schemes:\
                                <b><br>1.PMSBY (Pradhan Mantri Suraksha Bima Yojana)\
                                <br>2.PMJJBY (Pradhan Mantri Jeevan Jyoti Bima Yojana)\
                                <br><br>For all these schemes APIs are available in one versions v1, check the same by selecting definition in header of the page.\
                                <br><br>Broadly, APIs are <b>Get</b> APIs to fetch data entered by Applicant for the Insurer on portal.\
                                <br><br>This is only for ready reference of Request and Response of respective API. Note:Do not use try out feature.\
                                """)
                        .termsOfService(""));
    }

    /**
     * Error.INVALID - If any exception is occur then always INVALID(10001) response return as custom HTTPS status code
     */
    @Bean
    public OperationCustomizer customerGlobalHeaderOpenApiCustomiser() {

        return (operation, handlerMethod) -> {
            ApiResponses apiResponses = new ApiResponses();
            apiResponses
                    .addApiResponse(HttpStatus.UNAUTHORIZED.value() + "", new ApiResponse().description(Arrays.toString(UNAUTHORIZEDs))
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
                    .addApiResponse(HttpStatus.NO_CONTENT.value() + "", new ApiResponse().description(Arrays.toString(NO_CONTENT))
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
                    .addApiResponse(HttpStatus.BAD_REQUEST.value() + "", new ApiResponse().description(Arrays.toString(BAD_REQUEST))
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))

                    .addApiResponse("", new ApiResponse().description("")
                            .content(new Content().addMediaType("/*", new MediaType())))
                    .addApiResponse(HttpStatus.UNAUTHORIZED.value() + "", new ApiResponse().description("true or some custome message")
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
                    .addApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value() + "", new ApiResponse().description("any exception is occur")
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())))
                    .addApiResponse(HttpStatus.OK.value() + "", new ApiResponse().description("true and api info")
                            .content(new Content().addMediaType(APPLICATION_JSON, new MediaType())));
            operation.responses(apiResponses);
            return operation;
        };
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.
                addResourceHandler("/swagger-ui/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/swagger-ui/")
                .resourceChain(true);

    }


    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/swagger-ui/").setViewName("forward:" + "/swagger-ui/index.html");
    }


    @Bean
    public OperationCustomizer customizeHeader() {

        return (operation, handlerMethod) ->
        {
            Schema<?> type = new Schema<>().type("string");
            return operation.
                    addParametersItem(new Parameter()
                            .name("user-name")
                            .in("header")
                            .required(true)
                            .description("required to be shared ")
                            .schema(type))
                    .addParametersItem(new Parameter()
                            .name("api-key")
                            .in("header")
                            .required(true)
                            .description("required to be shared")
                            .schema(type));
        };
    }

    public static class IndexPageTransformer implements ResourceTransformer {

        private String overwriteDefaultUrl(String html) {
            return html.replace("https://petstore.swagger.io/v2/swagger.json", "/v3/api-docs");
        }

        @Override
        public Resource transform(HttpServletRequest httpServletRequest, Resource resource,
                                  ResourceTransformerChain resourceTransformerChain) throws IOException {
            if (resource.getURL().toString().endsWith("/index.html")) {
                String html = IOUtils.toString(resource.getInputStream(), StandardCharsets.UTF_8);
                html = overwriteDefaultUrl(html);
                return new TransformedResource(resource, html.getBytes());
            } else {
                return resource;
            }
        }
    }
}
