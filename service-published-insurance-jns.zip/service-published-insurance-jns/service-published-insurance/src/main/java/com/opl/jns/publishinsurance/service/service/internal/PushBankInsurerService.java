package com.opl.jns.publishinsurance.service.service.internal;

import com.opl.jns.publishinsurance.api.insurance.published.v1.BankInsurerPushProxy;

public interface PushBankInsurerService {
	
	/**
	 * ENROLLMENT DATA PUSH
	 */
	public void pushBankInsurerEnrolmentData(BankInsurerPushProxy bankInsurerPushProxy,boolean isManualPush) throws Exception;

	/**
	 * ENROLLMENT OPT OUT PUSH
	 */
	public void pushBankInsurerOptOutData(BankInsurerPushProxy bankInsurerPushProxy) throws Exception;

	/**
	 * ENROLLMENT NOMINEE UPString PUSH
	 */
	public void pushBankInsurerNomineeUpdateData(BankInsurerPushProxy bankInsurerPushProxy) throws Exception;

	/**
	 * CLAIM DATA PUSH
	 */
	public void pushBankInsurerClaimData(BankInsurerPushProxy bankInsurerPushProxy) throws Exception;

	/**
	 * INSURER CLAIM STATUS PUSH
	 */
	public void pushInsurerClaimStatusData(BankInsurerPushProxy bankInsurerPushProxy) throws Exception;
	
	/**
	 * BANK CLAIM STATUS PUSH
	 */
	public void pushBankClaimStatusData(BankInsurerPushProxy bankInsurerPushProxy) throws Exception;

}
