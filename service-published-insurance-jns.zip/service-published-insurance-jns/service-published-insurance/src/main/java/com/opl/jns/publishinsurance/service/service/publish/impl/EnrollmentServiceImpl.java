package com.opl.jns.publishinsurance.service.service.publish.impl;

import com.amazonaws.util.IOUtils;
import com.opl.jns.api.proxy.common.pushEnrollment.CoiDocumentDetailsProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.UpdateClaimStatus.CommonResponse;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationDetails.ApplicationDetailProxy;
import com.opl.jns.api.proxy.insurer.v1.Enrollment.GetApplicationList.ApplicationProxy;
import com.opl.jns.ere.enums.*;
import com.opl.jns.published.lib.repository.UserOrganizationMasterRepository;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.domain.publish.*;
import com.opl.jns.publishinsurance.service.repository.internal.ProductStorageRepository;
import com.opl.jns.publishinsurance.service.repository.publish.PUBApplicationMasterRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBNomineeDetailsRepo;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.publishinsurance.service.service.publish.CommonService;
import com.opl.jns.publishinsurance.service.service.publish.EnrollmentService;
import com.opl.jns.publishinsurance.service.utils.PublishApiUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author - Maaz Shaikh
 * @Date - 01/05/2023
 */
@Service
@Slf4j
@Transactional
public class EnrollmentServiceImpl implements EnrollmentService {

    @Autowired
    private UserOrganizationMasterRepository userOrganizationMasterRepository;
    
    @Autowired
    private CommonService commonService;
    
    @Autowired
    private ProductStorageRepository productStorageRepository;
    
    @Autowired
    DMSService dmsService;

    @Autowired
    private PUBApplicationMasterRepo masterPublishedRepo;

    @Autowired
    private PUBNomineeDetailsRepo nomineeDetailsRepoV3;
    
    @Autowired
    private PublishApiUtils publishApiUtils;
    
    @Override
    public List<ApplicationProxy> getApplicationListForPush(LocalDateTime fromDateStr, LocalDateTime toDateStr, Long userOrgId) throws Exception {
        Date fromDate = Date.from(fromDateStr.atZone(ZoneId.systemDefault()).toInstant());
        Date toDate = Date.from(toDateStr.atZone(ZoneId.systemDefault()).toInstant());

        List<ApplicationProxy> responses = masterPublishedRepo.getByInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(userOrgId, fromDate, toDate);
        for(ApplicationProxy master : responses) {
            master.setSchemeName(SchemeMaster.getById(master.getSchemeId().longValue()).getShortName());
        }

//        log.info("ENTER IN GET APPLICATION LIST ------------------->" + userOrgId);
//        List<PUBApplicationMaster> masterList = Collections.emptyList();
//        if (!com.opl.jns.published.utils.common.OPLUtils.isObjectNullOrEmpty(userOrgId)) {
//            /** check here first if logged in org is for insurer */
//            UserOrganizationMaster orgMaster = userOrganizationMasterRepository.findByOrgIdAndIsActiveIsTrue(userOrgId);
//            if(!OPLUtils.isObjectNullOrEmpty(orgMaster)) {
//                if (orgMaster.getOrgType().equals(CommonUtils.ORG_TYPE_INSURER)) {     /** if insurer then use below query */
//                    masterList = masterPublishedRepo.findAllByInsurerOrgIdAndIsActiveTrueAndPushReadyDateBetween(userOrgId, fromDate, toDate);
//                } else if (orgMaster.getOrgType().equals(CommonUtils.ORG_TYPE_BANK)) {  /** if bank then use below query */
//                    masterList = masterPublishedRepo.findAllByOrgIdAndIsActiveTrueAndPushReadyDateBetween(userOrgId, fromDate, toDate);
//                }
//            }
//        }
//        log.info("FETCHED APPLICATION LIST ------------------->" + userOrgId);
//
//        if (OPLUtils.isListNullOrEmpty(masterList)) {
//            return Collections.emptyList();
//        }
//
//        log.info("START CONVERT INTO APPLICATION LIST ------------------->" + userOrgId);
//        List<ApplicationProxy> responses = new ArrayList<>(masterList.size());
//        ApplicationProxy resp = null;
//        for(PUBApplicationMaster master : masterList) {
//            resp = new ApplicationProxy();
//            resp.setSchemeName(SchemeMaster.getById(master.getSchemeId().longValue()).getShortName());
//            resp.setSchemeId(master.getSchemeId());
//            resp.setUrn(master.getUrn());
//            resp.setApplicationReferenceId(master.getId());
//            responses.add(resp);
//        }
////        masterList.forEach(master -> {
////            ApplicationProxy resp = new ApplicationProxy();
////            resp.setSchemeName(SchemeMaster.getById(master.getSchemeId().longValue()).getShortName());
////            resp.setSchemeId(master.getSchemeId());
////            resp.setUrn(master.getUrn());
////            resp.setApplicationReferenceId(master.getId());
////            responses.add(resp);
////        });
//        log.info("END CONVERT INTO APPLICATION LIST ------------------->" + userOrgId);
        return responses;
    }

    public CommonResponse getApplicationDetails(Long applicationReferenceId) throws Exception {
        CommonResponse commonResp=new CommonResponse();
        log.info("....Enter in get Enrollment Data for Application Id [{}]....", applicationReferenceId);
        
        PUBApplicationMaster master = masterPublishedRepo.findByIdAndIsActiveTrue(applicationReferenceId);
        if(OPLUtils.isObjectNullOrEmpty(master)){
            commonResp.setStatus(HttpStatus.BAD_REQUEST.value());
            commonResp.setMessage("Invalid Application Reference Id");
            commonResp.setSuccess(Boolean.FALSE);
            return commonResp;
        }
        
        ApplicationDetailProxy response = new ApplicationDetailProxy();
        
        /* set enrollment Applicant Master Data*/
        setEnrollmentApplicationMasterData(master, response);
        
        /* set enrollment Applicant info address*/
        PUBApplicantInfo applicantInfo = master.getApplicantInfo();
        if (!OPLUtils.isObjectNullOrEmpty(applicantInfo)) {
        	setEnrollmentApplicantInfoDetails(applicantInfo, response);
        }
        
        /* set applicantOtherDetails address*/
        PUBApplicationMasterOtherDetails applicantOtherDetails = master.getApplicationMasterOtherDetails();
        if (!OPLUtils.isObjectNullOrEmpty(applicantOtherDetails)) {
        	setEnrollmentApplicantOtherDetails(applicantOtherDetails, response);
        }
        
        /* set nominee values */
        setEnrollmentNomineeDetails(master, response);

        /* set transaction details */
        setEnrollmentTransactionDetails(master, response);
        
        /* setCoi */
        setCOI(master, response);

        commonResp.setData(response);
        commonResp.setSuccess(!OPLUtils.isObjectNullOrEmptyOrDash(response) ? Boolean.TRUE : Boolean.FALSE);
        commonResp.setStatus(HttpStatus.OK.value());
        commonResp.setMessage(Constants.SUCCESS);
        log.info("....Exit from Get application Data for Application Id [{}] found....", applicationReferenceId);
        return commonResp;
    }

    private static String setSource(PUBApplicationMasterOtherDetails otherDetails){
        String source =Source.JANSURAKSHA.getValue();
        if(!OPLUtils.isObjectNullOrEmpty(otherDetails)){
            source = Source.fromId(otherDetails.getSource()).getValue();
        }
        return source;
    }
    
    private void setEnrollmentApplicationMasterData(PUBApplicationMaster applicationMst, ApplicationDetailProxy applicationDetailsProxy) {
        applicationDetailsProxy.setUrn(applicationMst.getUrn());
        applicationDetailsProxy.setCif(applicationMst.getCif());
        applicationDetailsProxy.setCustomerAccountNumber(applicationMst.getAccountNumber());
        applicationDetailsProxy.setSchemeId(applicationMst.getSchemeId().longValue());
        applicationDetailsProxy.setSchemeName(SchemeMaster.getById(applicationMst.getSchemeId().longValue()).getShortName());
        applicationDetailsProxy.setDateOfEnrollment(applicationMst.getEnrollmentDate());

        applicationDetailsProxy.setBranchName(applicationMst.getBranchName());
        applicationDetailsProxy.setNameofInsurer(applicationMst.getInsurerOrgName());
        applicationDetailsProxy.setBankName(applicationMst.getOrgName());
        applicationDetailsProxy.setBankCode(applicationMst.getOrgCode());
        applicationDetailsProxy.setInsurerCode(applicationMst.getInsurerOrgCode());

    }
    
  
    private static void setEnrollmentApplicantInfoDetails(PUBApplicantInfo applicantInfo, ApplicationDetailProxy applicationDetailsProxy) {
        applicationDetailsProxy.setFirstName(applicantInfo.getFirstName());
        applicationDetailsProxy.setMiddleName(applicantInfo.getMiddleName());
        applicationDetailsProxy.setLastName(applicantInfo.getLastName());
        applicationDetailsProxy.setDob(applicantInfo.getDob());
    	applicationDetailsProxy.setAccountHolderName(applicantInfo.getName());
//    	applicationDetailsProxy.setDisabilityStatus(applicantInfo.getDisabilityStatus());
    	applicationDetailsProxy.setCustomerIFSC(applicantInfo.getIfsc());
    	applicationDetailsProxy.setGender(null != applicantInfo.getGenderId() ? Gender.fromId(applicantInfo.getGenderId()).getBankValue() : null);
    	applicationDetailsProxy.setEmailId(applicantInfo.getEmail());
        applicationDetailsProxy.setMobileNumber(applicantInfo.getMobileNumber());
    	applicationDetailsProxy.setKycID1(applicantInfo.getKycId1());
    	applicationDetailsProxy.setKycID2(applicantInfo.getKycId2());
    	applicationDetailsProxy.setKycID1Number(applicantInfo.getKycIdNumber1().toUpperCase());
    	applicationDetailsProxy.setKycID2Number(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getKycIdNumber2()) ? applicantInfo.getKycIdNumber2().toUpperCase() : null);
    	applicationDetailsProxy.setAadhaar(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar()) ? Boolean.TRUE :Boolean.FALSE);
    	applicationDetailsProxy.setPan(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan()) ? Boolean.TRUE :Boolean.FALSE);
    	applicationDetailsProxy.setPanNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan()) ? applicantInfo.getPan().toUpperCase() : null);
    	applicationDetailsProxy.setAadhaarNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar()) ? applicantInfo.getAadhaar().toUpperCase() : null);
        boolean isCkycYes = OPLUtils.isObjectNullOrEmpty(applicantInfo.getCkyc()) ? Boolean.FALSE : applicantInfo.getCkyc().equalsIgnoreCase("Yes") || applicantInfo.getCkyc().equalsIgnoreCase("Y");
        applicationDetailsProxy.setCkyc(isCkycYes);
    	applicationDetailsProxy.setCkycNumber(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getCkycNumber()) ? applicantInfo.getCkycNumber().toUpperCase() : null);
    	applicationDetailsProxy.setFatherHusbandName(applicantInfo.getFatherHusbandName());
//        applicationDetailsProxy.setDisabilityStatus(applicantInfo.getDisabilityStatus());
    	applicationDetailsProxy.setDisabilityStatus(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getDisabilityStatus()) ? DisabilityStatus.fromStatus(applicantInfo.getDisabilityStatus()).getStatus() : null);
        applicationDetailsProxy.setDisabilityDetails(applicantInfo.getDisabilityDetails());
        if(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
        	setEnrollmentAddressDetails(applicantInfo, applicationDetailsProxy);
        }

    }
    
    private static void setEnrollmentApplicantOtherDetails(PUBApplicationMasterOtherDetails applicantOtherDetails, ApplicationDetailProxy applicationDetailsProxy) {
    	applicationDetailsProxy.setConsentforautodebit(applicantOtherDetails.getConsentForAutoDebit());
    	applicationDetailsProxy.setRuralUrban(applicantOtherDetails.getRuralUrbanSemi());
    	applicationDetailsProxy.setChannelId(applicantOtherDetails.getChannelId() != null ? applicantOtherDetails.getChannelId() : null);
        applicationDetailsProxy.setSource(setSource(applicantOtherDetails));
        applicationDetailsProxy.setUserId1(applicantOtherDetails.getUserId1());
        applicationDetailsProxy.setUserId2(applicantOtherDetails.getUserId2());
    }
    
    private static void setEnrollmentAddressDetails(PUBApplicantInfo applicantInfo, ApplicationDetailProxy applicationDetailsProxy) {
        if(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
        	PUBAddressMaster addressDetails = applicantInfo.getAddress();
        	applicationDetailsProxy.setAddressline1(addressDetails.getAddressLine1());
        	applicationDetailsProxy.setAddressline2(addressDetails.getAddressLine2());
            applicationDetailsProxy.setDistrict(addressDetails.getDistrict());
            applicationDetailsProxy.setDistrictLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getDistrictLGDCode()) ? addressDetails.getDistrictLGDCode().toString() : null);
        	applicationDetailsProxy.setCity(addressDetails.getCityName());
            applicationDetailsProxy.setCityLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getCityLGDCode()) ? addressDetails.getCityLGDCode().toString() : null);
        	applicationDetailsProxy.setState(addressDetails.getStateName());
            applicationDetailsProxy.setStateLGDCode(!OPLUtils.isObjectNullOrEmpty(addressDetails.getStateLGDCode()) ? addressDetails.getStateLGDCode().toString() : null);
            applicationDetailsProxy.setPincode(addressDetails.getPincode());
        }
    }
    
    private void setEnrollmentNomineeDetails(PUBApplicationMaster applicationMst, ApplicationDetailProxy applicationDetailsProxy) {
        List<PUBNomineeDetails> nomineeDetailsList =applicationMst.getNomineeDetails();
        
	    if(!OPLUtils.isListNullOrEmpty(nomineeDetailsList)) {
	     	List<PUBNomineeDetails> guardianDetailsList = nomineeDetailsList.stream().filter(a -> Objects.equals(a.getType(), NomineeType.GUARDIAN.getId())).collect(Collectors.toList());
	     	List<PUBNomineeDetails> nomineeDetails= nomineeDetailsList.stream().filter(a -> Objects.equals(a.getType(), NomineeType.NOMINEE.getId())).collect(Collectors.toList());
	
	     	// GUARDIAN DETAILS
            setGuardianDetailsForNomineeEnrollment(applicationDetailsProxy, guardianDetailsList);

            //NOMINEE DETAILS
	     	if (!OPLUtils.isListNullOrEmpty(nomineeDetails)) {
	     		PUBNomineeDetails nominee = nomineeDetails.getFirst();
	     		applicationDetailsProxy.setNomineeFirstName(OPLUtils.isObjectNullOrEmpty(nominee.getFirstName()) ? nominee.getName() : nominee.getFirstName());
	     		applicationDetailsProxy.setNomineeMiddleName(nominee.getMiddleName());
	     		applicationDetailsProxy.setNomineeLastName(nominee.getLastName());
	     		applicationDetailsProxy.setNomineeDateOfBirth(commonService.parseAndFormatDateUsing_sdf(nominee.getDob()));
	     		applicationDetailsProxy.setNomineeMobileNumber(nominee.getMobileNumber());
	     		applicationDetailsProxy.setNomineeEmailId(nominee.getEmail());
	     		
	     		if (nominee.getRelationId() != null) {
	     			applicationDetailsProxy.setRelationOfNominee(RelationShip.fromId(nominee.getRelationId()).getValue());             			
	     		}
                setNomineeAddressForEnrollment(applicationDetailsProxy, nominee);
            }
	     }   
    }

    private static void setGuardianDetailsForNomineeEnrollment(ApplicationDetailProxy applicationDetailsProxy, List<PUBNomineeDetails> guardianDetailsList) {
        if (!OPLUtils.isListNullOrEmpty(guardianDetailsList)) {
            PUBNomineeDetails guardian = guardianDetailsList.getFirst();
            applicationDetailsProxy.setNameofGuardian((guardian.getName()));
            applicationDetailsProxy.setGuardianMobileNumber(guardian.getMobileNumber());
            applicationDetailsProxy.setGuardianEmailId(guardian.getEmail());

            if (guardian.getRelationId() != null) {
                applicationDetailsProxy.setRelationshipofGuardian(RelationShip.fromId(guardian.getRelationId()).getValue());
            }
            if (!OPLUtils.isObjectNullOrEmpty(guardian.getAddress())) {
                applicationDetailsProxy.setAddressofGuardian(guardian.getAddress().getAddressLine1());
           }
        }
    }

    private static void setNomineeAddressForEnrollment(ApplicationDetailProxy applicationDetailsProxy, PUBNomineeDetails nominee) {
        if (!OPLUtils.isObjectNullOrEmpty(nominee.getAddress())) {
            PUBAddressMaster nomineeAddress = nominee.getAddress();
            applicationDetailsProxy.setNomineeAddressline1(nominee.getAddress().getAddressLine1());
            applicationDetailsProxy.setNomineeAddressline2(nominee.getAddress().getAddressLine2());
            applicationDetailsProxy.setNomineePincode(!OPLUtils.isObjectNullOrEmpty(nomineeAddress.getPincode()) ? nomineeAddress.getPincode().toString() : null);
            applicationDetailsProxy.setNomineeCity(nomineeAddress.getCityName());
            applicationDetailsProxy.setNomineeCityLGDCode(nomineeAddress.getCityLGDCode() != null ? nomineeAddress.getCityLGDCode().toString() : null);
            applicationDetailsProxy.setNomineeDistrict(nomineeAddress.getDistrict());
            applicationDetailsProxy.setNomineeDistrictLGDCode(nomineeAddress.getDistrictLGDCode() != null ? nomineeAddress.getDistrictLGDCode().toString() : null);
            applicationDetailsProxy.setNomineeState(nomineeAddress.getStateName());
            applicationDetailsProxy.setNomineeStateLGDCode(nomineeAddress.getStateLGDCode() != null ? nomineeAddress.getStateLGDCode().toString() : null);
        }
    }

    private static void setEnrollmentTransactionDetails(PUBApplicationMaster applicationMst, ApplicationDetailProxy applicationDetailsProxy) {
        if(!OPLUtils.isObjectNullOrEmpty(applicationMst.getLastTransactionDetails())) {
        	PUBTransactionDetails transactionDetails = applicationMst.getLastTransactionDetails();
        	applicationDetailsProxy.setTransactionUTR(transactionDetails.getTransUtr());
        	applicationDetailsProxy.setTransactionAmount(transactionDetails.getTransAmount());
        	applicationDetailsProxy.setComment(transactionDetails.getTransComment());
        	applicationDetailsProxy.setTransactionTimeStamp(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS,transactionDetails.getTransTimeStamp()));
        	applicationDetailsProxy.setMasterPolicyNumber(transactionDetails.getMasterPolicyNo());
        	applicationDetailsProxy.setTransactionType(applicationMst.getEnrollType() != null ? EnrollTypeEnum.fromId(applicationMst.getEnrollType()).getKey():null);
        }
    }
    
    private void setCOI(PUBApplicationMaster applicationMst, ApplicationDetailProxy applicationDetailsProxy) {
    	if (!OPLUtils.isObjectNullOrEmpty(applicationMst.getLastTransactionDetails()) && !OPLUtils.isObjectNullOrEmpty(applicationMst.getLastTransactionDetails().getCoiStorageId())) {
    		InputStreamResource inputStreamResource = dmsService.downloadDocumentByProductDocumentId(applicationMst.getLastTransactionDetails().getCoiStorageId());

    		if (inputStreamResource != null) {
    			try {
    				InputStream inputStream = inputStreamResource.getInputStream();
    				byte[] bytes = IOUtils.toByteArray(inputStream);
    				CoiDocumentDetailsProxy coiDocumentDetailsProxy = new CoiDocumentDetailsProxy();
                    productStorageRepository.findById(applicationMst.getLastTransactionDetails().getCoiStorageId())
                            .ifPresent( productStorage -> {
                                coiDocumentDetailsProxy.setDocumentType(!OPLUtils.isObjectNullOrEmpty(productStorage.getDocName()) ?productStorage.getDocName() : "coi" );
                                coiDocumentDetailsProxy.setContentType(productStorage.getOriginalFileName().substring(productStorage.getOriginalFileName().lastIndexOf(".") + Constants.ENROLLMENT_TYPE_ID_1));
                            });
    				coiDocumentDetailsProxy.setDocument(bytes);
    				applicationDetailsProxy.setCOI(coiDocumentDetailsProxy);
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}    		
    	}
    }
}

