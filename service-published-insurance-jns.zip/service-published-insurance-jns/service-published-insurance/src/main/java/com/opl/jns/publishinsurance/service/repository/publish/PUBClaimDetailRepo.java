package com.opl.jns.publishinsurance.service.repository.publish;

import org.springframework.data.jpa.repository.*;

import com.opl.jns.publishinsurance.service.domain.publish.*;

public interface PUBClaimDetailRepo extends JpaRepository<PUBClaimDetail, Long> {

}
