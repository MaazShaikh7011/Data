package com.opl.jns.publishinsurance.service.service.internal;

import org.springframework.core.io.*;
import org.springframework.stereotype.Service;

import com.opl.jns.publishinsurance.service.domain.internal.*;

import java.util.*;

@Service
public interface DMSService {

     InputStreamResource downloadDocumentByProductDocumentMappingId(Long applicationId, Long productDocumentMappingId, List<Long> coApplicantIds);

     InputStreamResource downloadDocumentByProductDocumentId(Long id);

     public List<ProductStorageDetailsV3> getDocumentList(Long applicationId, Long profileId, List<Long> moduleMasterIds) ;

}
