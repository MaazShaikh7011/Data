//package com.opl.jns.publishinsurance.service.controller.publish.v1;
//
//import com.opl.jns.api.proxy.insurer.v1.Webhook.UpdateClaimStatus.ClaimStatusResponse;
//import com.opl.jns.api.proxy.insurer.v1.Webhook.UpdateClaimStatus.ClaimStatusWebhook;
//import com.opl.jns.published.utils.common.OPLUtils;
//import com.opl.jns.publishinsurance.api.publish.api_responses.Response400;
//import com.opl.jns.publishinsurance.api.publish.api_responses.Response401;
//import com.opl.jns.publishinsurance.api.utils.Constants;
//import com.opl.jns.publishinsurance.service.service.publish.ValidationService;
//import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.ExampleObject;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//import io.swagger.v3.oas.annotations.tags.Tag;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.validation.Valid;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.Map;
//
///***
// *
// * @author Maaz Shaikh
// * @date : 04/03/2023
// */
//
//@RestController
//@Slf4j
//@Tag(name = "3. Insurer Published API", description = "(APIs published by insurer)")
//public class WebhookController {
//
//    @Autowired
//    ValidationService validationService;
//
//
//
//	@PostMapping(value = "/updateClaimStatus", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    @Operation(
//			operationId = Constants.STR_8,
//			summary = Constants.WB_UPDATE_CLAIM_STATUS,
//    		requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody( description = Constants.REQUEST_EXAMPLES_DESC,
//            content = @Content(examples = {
//                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.WB_UPDATE_CLAIM_STATUS_PLAIN_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
//                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),
//            })),
//    		responses = {
//   				 @ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE,
//						 content = {
//                                 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClaimStatusResponse.class),
//                                         examples = {
//                                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.CLAIM_RESPONSE_EXAMPLE),
//                                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//                                         })
//                         }),
//				 @ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE,
//						 content = {
//                                 @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class),
//                                         examples = {
//                                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_400),
//                                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//                                         }
//
//                                 )
//                         }),
//				 @ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
//						 content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
////                         examples = {
////                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_401),
////                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
////                         }
//                 )})
//
//		})
//    public ResponseEntity<ClaimStatusResponse> updateClaimDocument(@Valid @RequestBody ClaimStatusWebhook claimStatus, HttpServletRequest httpServletRequest) {
//        try {
//			Map<String, Object> isValidUser = validationService.isValidUser(httpServletRequest, null, claimStatus.getClaimReferenceId());
//			if (!OPLUtils.isObjectNullOrEmpty(isValidUser) && !OPLUtils.isObjectNullOrEmpty(isValidUser.get(Constants.STATUS)) && isValidUser.get(Constants.STATUS).equals(Boolean.FALSE)) {
//                ClaimStatusResponse matchResponse = new ClaimStatusResponse(Constants.INVALID_CLAIM_REF_ID, HttpStatus.BAD_REQUEST.value());
//				return new ResponseEntity<>(matchResponse, HttpStatus.OK);
//			}
//
//            StringBuilder message = new StringBuilder();
//            Boolean status=Boolean.TRUE;//claimService.updateClaimStatus(updateAppClaimRequest,  message);
//            return new ResponseEntity<>(new ClaimStatusResponse(message.toString(),HttpStatus.OK.value(), !OPLUtils.isObjectNullOrEmptyOrDash(status) ? Boolean.TRUE : Boolean.FALSE),HttpStatus.OK);
//        } catch (Exception e) {
//            e.printStackTrace();
//            log.error("Error in getApplicationDetails() {} ", e.getMessage());
//            return new ResponseEntity<>(new ClaimStatusResponse(Constants.ErrorMsg.SMTG_WNT_WRG, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//        }
//
//    }
//
//
//
//
//
//}
