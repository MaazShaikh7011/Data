package com.opl.jns.publishinsurance.service.utils;

import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;

import com.opl.jns.api.proxy.banks.v3.nomineeUpdateStatus.NomineeUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.optOutUpdateStatus.OptOutUpdateStatusRequestV3;
import com.opl.jns.api.proxy.banks.v3.pushClaim.PushClaimDetailsRequestV3;
import com.opl.jns.api.proxy.banks.v3.pushEnrollment.PushEnrollmentDetailsRequestV3;
import com.opl.jns.ere.domain.AddressMasterV3;
import com.opl.jns.ere.domain.ApplicantInfo;
import com.opl.jns.ere.domain.ApplicationMasterOtherDetailsV3;
import com.opl.jns.ere.domain.ApplicationMasterV3;
import com.opl.jns.ere.domain.ClmAddressMaster;
import com.opl.jns.ere.domain.ClmDetails;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.domain.ClmNomineeDetails;
import com.opl.jns.ere.domain.ClmNomineePIDetails;
import com.opl.jns.ere.domain.ClmPIDetails;
import com.opl.jns.ere.domain.NomineeDetails;
import com.opl.jns.ere.domain.TransactionDetailsV3;
import com.opl.jns.ere.domain.v2.AddressMasterV2;
import com.opl.jns.ere.domain.v2.AppMasterV2;
import com.opl.jns.ere.domain.v2.ApplicantInfoV2;
import com.opl.jns.ere.domain.v2.ApplicantPIDetails;
import com.opl.jns.ere.domain.v2.NomineeDetailsV2;
import com.opl.jns.ere.domain.v2.NomineePIDetails;
import com.opl.jns.ere.enums.CauseOfDeathDisabilityV2;
import com.opl.jns.ere.enums.ChannelIdEnum;
import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.ere.enums.NatureOfLoss;
import com.opl.jns.ere.enums.NomineeType;
import com.opl.jns.ere.enums.RelationShip;
import com.opl.jns.ere.enums.RuralUrbanEnum;
import com.opl.jns.ere.enums.Source;
import com.opl.jns.ere.enums.TransactionType;
import com.opl.jns.ere.enums.TypeOfDisability;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.published.utils.common.DateUtils;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.enums.SchemeMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBAddressMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicantInfo;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBApplicationMasterOtherDetails;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.domain.publish.PUBNomineeDetails;
import com.opl.jns.publishinsurance.service.domain.publish.PUBTransactionDetails;
import com.opl.jns.user.management.api.model.BranchAndOrgDetailsProxy;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GetSetUtils {
	
	/**
	 * SET EXISTING APPLICATION MASTER INTO API APPLICATION MASTER TABLE SET
	 * EXISTING APPLICATION OTHER DETAILS INTO API APPLICATION OTHER DETAILS TABLE
	 * 
	 * @param pubAppMaster
	 * @param appMaster
	 */
	public static PUBApplicationMaster setEnrollAppMaster(PUBApplicationMaster pubAppMaster, ApplicationMasterV3 appMaster) {
		if (OPLUtils.isObjectNullOrEmpty(pubAppMaster)) {
			pubAppMaster = new PUBApplicationMaster(new Date(), true);
			BeanUtils.copyProperties(appMaster, pubAppMaster, "id", "enrollmentDate", "createdDate", "isActive");
			pubAppMaster.setApplicationId(appMaster.getId());
			pubAppMaster.setEnrollType(appMaster.getEnrollType());	
		} else {
			BeanUtils.copyProperties(appMaster, pubAppMaster, "id", "enrollmentDate", "applicationId", "createdDate");
			pubAppMaster.setModifiedDate(new Date());
		}
		pubAppMaster.setEnrollmentDate(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS, appMaster.getEnrollmentDate()));
		pubAppMaster.setSchemeName(SchemeMaster.getById(appMaster.getSchemeId().longValue()).getShortName());

		// ----------------- APPLICATION MASTER OTHER DETAILS ------------------
		PUBApplicationMasterOtherDetails pubAppMstOtrDetails = pubAppMaster.getApplicationMasterOtherDetails();
		if (pubAppMstOtrDetails != null) {
			BeanUtils.copyProperties(appMaster.getApplicationMasterOtherDetails(), pubAppMstOtrDetails, "id","applicationMaster");
		} else {
			pubAppMstOtrDetails = new PUBApplicationMasterOtherDetails();
			BeanUtils.copyProperties(appMaster.getApplicationMasterOtherDetails(), pubAppMstOtrDetails,"applicationMaster");
			try {
				pubAppMstOtrDetails.setChannelId(ChannelIdEnum.fromId(appMaster.getApplicationMasterOtherDetails().getChannel()).getShortName());
			}catch (Exception e) {
				log.info("CHANNEL ENUM CHANNEL ID NOT FOUND --->" + appMaster.getApplicationMasterOtherDetails().getChannel());
			}
			pubAppMstOtrDetails.setApplicationMaster(pubAppMaster);
		}
		pubAppMaster.setApplicationMasterOtherDetails(pubAppMstOtrDetails);

		return  pubAppMaster;
	}

	/**
	 * SET EXISTING APPLICANT DETAILS INTO API APPLICANT DETAILS TABLE
	 * 
	 * @param pubAppMaster
	 * @param applicantInfo
	 */
	public static PUBApplicationMaster setEnrollApplicant(PUBApplicationMaster pubAppMaster, ApplicantInfo applicantInfo) {
		PUBApplicantInfo pubApplicantInfo = pubAppMaster.getApplicantInfo();
		if (pubApplicantInfo != null) {
			BeanUtils.copyProperties(applicantInfo, pubApplicantInfo, "id", "createdDate", "applicationMaster", "dob");
			pubApplicantInfo.setModifiedDate(new Date());
			// ADDRESS
			PUBAddressMaster pubAddress = pubApplicantInfo.getAddress();
			if (pubAddress != null) {
				if(null != applicantInfo.getAddress()) {
					BeanUtils.copyProperties(applicantInfo.getAddress(), pubAddress, "id", "applicantInfo");
					pubApplicantInfo.setAddress(pubAddress);
				}
			} else {
				pubAddress = new PUBAddressMaster(new Date(), true);
				if(null != applicantInfo.getAddress()) {
					BeanUtils.copyProperties(applicantInfo.getAddress(), pubAddress, "id", "applicantInfo", "createdDate","isActive");
					pubApplicantInfo.setAddress(pubAddress);
				}
			}
		} else {
			// ADDRESS
			pubApplicantInfo = new PUBApplicantInfo(new Date(), true);
			BeanUtils.copyProperties(applicantInfo, pubApplicantInfo, "id", "dob", "createdDate", "isActive");
			pubApplicantInfo.setApplicationMaster(pubAppMaster);

			PUBAddressMaster pubAddress = new PUBAddressMaster(new Date(), true);
			if(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
				BeanUtils.copyProperties(applicantInfo.getAddress(), pubAddress, "id", "applicantInfo", "createdDate","isActive");
			}
			pubApplicantInfo.setAddress(pubAddress);
		}
		pubApplicantInfo.setDisabilityStatus(applicantInfo.getDisabilityStatus());
		pubApplicantInfo.setGender(OPLUtils.isObjectNullOrEmpty(applicantInfo.getGender()) ? null :  applicantInfo.getGender().getBankValue());
		pubApplicantInfo.setDob(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD, applicantInfo.getDob()));
		pubAppMaster.setApplicantInfo(pubApplicantInfo);

		return pubAppMaster;
	}

	/**
	 * SET EXISTING TRANSACTION DETAILS INTO API TRANSACTION DETAILS TABLE
	 * 
	 * @param pubAppMaster
	 * @param appMaster
	 */
	public static PUBApplicationMaster setEnrollTransDetails(PUBApplicationMaster pubAppMaster, ApplicationMasterV3 appMaster) {
		TransactionDetailsV3 lastTransDtls = appMaster.getLastTransactionDetails();
		if(null == lastTransDtls) {
			return pubAppMaster;
		}

		PUBTransactionDetails pubLastTransDtls = pubAppMaster.getLastTransactionDetails();
		if (pubLastTransDtls != null) {
			BeanUtils.copyProperties(lastTransDtls, pubLastTransDtls, "id", "applicationMaster", "coverStartDate", "coverEndDate");
			pubLastTransDtls.setModifiedDate(new Date());
		} else {
			pubLastTransDtls = new PUBTransactionDetails(new Date(), true);
			BeanUtils.copyProperties(lastTransDtls, pubLastTransDtls, "id", "applicationMaster", "coverStartDate", "coverEndDate");
			pubLastTransDtls.setApplicationMaster(pubAppMaster);
		}

		pubLastTransDtls.setCoiStorageId(lastTransDtls.getCoiStorageId());
		pubLastTransDtls.setCoverStartDate(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS,lastTransDtls.getCoverStartDate()));
		pubLastTransDtls.setCoverEndDate(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS, lastTransDtls.getCoverEndDate()));
		pubLastTransDtls.setTransTimeStamp(lastTransDtls.getTransTimeStamp());
		pubAppMaster.setLastTransactionDetails(pubLastTransDtls);
		return pubAppMaster;
	}

	public static PUBNomineeDetails setNomineeDetails(PUBApplicationMaster pubAppMaster, ApplicationMasterV3 appMaster, NomineeType nomineeType) {

		Optional<NomineeDetails> nomineeOptional = appMaster.getNomineeDetails().stream()
				.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && nomineeType.getId().equals(a.getType()))
				.findFirst();
		NomineeDetails nomineeDetails = null;
		if(nomineeOptional.isPresent()) {
			nomineeDetails = nomineeOptional.get();
		}else{
			return null;
		}

		PUBNomineeDetails pubNominee = null;
		if (pubAppMaster.getNomineeDetails() != null && pubAppMaster.getNomineeDetails().size() > 0) {
			Optional<PUBNomineeDetails> optNominee = pubAppMaster.getNomineeDetails().stream()
					.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && nomineeType.getId().equals(a.getType()))
					.findFirst();
			pubNominee = optNominee.isPresent() ? optNominee.get() : null;
		}

		if (pubNominee != null) {
			BeanUtils.copyProperties(nomineeDetails, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			pubNominee.setModifiedDate(new Date());
			pubNominee.setAddress(createOrUpdatePUBAddress(pubNominee.getAddress(), nomineeDetails.getAddress()));
		} else {
			pubNominee = new PUBNomineeDetails(new Date(), true);
			BeanUtils.copyProperties(nomineeDetails, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			pubNominee.setApplicationMaster(pubAppMaster);
			pubNominee.setAddress(createOrUpdatePUBAddress(null, nomineeDetails.getAddress()));
		}
		if(!OPLUtils.isObjectNullOrEmpty(nomineeDetails.getDob())) {
			pubNominee.setDob(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD, nomineeDetails.getDob()));		
		}
		return pubNominee;
	}
	
	
	public static PUBNomineeDetails setNomineeDetailsUsingNewDb(PUBApplicationMaster pubAppMaster, ApplicationMasterBothSchemeProxy appMaster, NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomineeAddMstV2) {

		PUBNomineeDetails pubNominee = null;
		if (pubAppMaster.getNomineeDetails() != null && pubAppMaster.getNomineeDetails().size() > 0) {
			Optional<PUBNomineeDetails> optNominee = pubAppMaster.getNomineeDetails().stream()
					.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.NOMINEE.getId().equals(a.getType()))
					.findFirst();
			pubNominee = optNominee.isPresent() ? optNominee.get() : null;
		}

		if (pubNominee != null) {
			BeanUtils.copyProperties(nomineeDetailsV2, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			BeanUtils.copyProperties(nomineePIDetails, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			pubNominee.setModifiedDate(new Date());
			pubNominee.setAddress(createOrUpdatePUBAddressUsingNewDb(pubNominee.getAddress(),nomineeAddMstV2,nomineePIDetails));
		} else {
			pubNominee = new PUBNomineeDetails(new Date(), true);
			BeanUtils.copyProperties(nomineeDetailsV2, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			BeanUtils.copyProperties(nomineePIDetails, pubNominee, "id", "createdDate", "isActive", "dob","applicationMaster", "address");
			pubNominee.setType(NomineeType.NOMINEE.getId());
			pubNominee.setApplicationMaster(pubAppMaster);
			pubNominee.setAddress(createOrUpdatePUBAddressUsingNewDb(null, nomineeAddMstV2,nomineePIDetails));
		}
		if(!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getDob())) {
			pubNominee.setDob(DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD, nomineePIDetails.getDob()));		
		}
		return pubNominee;
	}

	public static PUBNomineeDetails setGuardianDetailsUsingNewDb(PUBApplicationMaster pubAppMaster, ApplicationMasterBothSchemeProxy appMaster, NomineeDetailsV2 nomineeDetailsV2,NomineePIDetails nomineePIDetails,AddressMasterV2 nomineeAddMstV2) {

		PUBNomineeDetails pubNominee = null;
		if (pubAppMaster.getNomineeDetails() != null && pubAppMaster.getNomineeDetails().size() > 0) {
			Optional<PUBNomineeDetails> optNominee = pubAppMaster.getNomineeDetails().stream()
					.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.GUARDIAN.getId().equals(a.getType()))
					.findFirst();
			pubNominee = optNominee.isPresent() ? optNominee.get() : null;
		}

		if(OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getGdName())) {
			return null;
		}
		
		if (pubNominee != null) {
			pubNominee.setModifiedDate(new Date());
			PUBAddressMaster address = pubNominee.getAddress();
			address.setAddressLine1(nomineePIDetails.getGdAddress());
			address.setModifiedDate(new Date());
			pubNominee.setAddress(address);
		} else {
			pubNominee = new PUBNomineeDetails(new Date(), true);
			pubNominee.setApplicationMaster(pubAppMaster);
			pubNominee.setType(NomineeType.GUARDIAN.getId());
			PUBAddressMaster address = new PUBAddressMaster();
			address.setAddressLine1(nomineePIDetails.getGdAddress());
			address.setCreatedDate(new Date());
			address.setIsActive(true);
			pubNominee.setAddress(address);
		}
		pubNominee.setName(nomineePIDetails.getGdName());
		pubNominee.setRelationId(nomineeDetailsV2.getGdRelationId());
		pubNominee.setMobileNumber(nomineeDetailsV2.getGdMobile());
		pubNominee.setEmail(nomineeDetailsV2.getGdEmail());
		return pubNominee;
	}


	/** PUSH NOMINEE AND CLAIMANT DETAIL TO PUBLISH APIS*/
	public static PUBNomineeDetails pushNomineeDetailAndClaimantDetails(PUBClaimMaster claimMsrPub, ClmMaster insuranceApplicationMaster,boolean checkPhase2){
		PUBNomineeDetails pubNomineeDtls = null;
		if(!OPLUtils.isObjectNullOrEmpty(insuranceApplicationMaster.getClmDetails())) {			
			ClmDetails internalNominee =  insuranceApplicationMaster.getClmDetails();
			ClmPIDetails internalNomineePIDtl =  insuranceApplicationMaster.getClmDetails().getClmPIDetails();
			if(null != internalNominee ) {
				pubNomineeDtls = new PUBNomineeDetails();
				pubNomineeDtls.setType(NomineeType.CLAIMANT.getId());
				if(checkPhase2) {					
					pubNomineeDtls.setFirstName(internalNomineePIDtl.getClmName());
				}else {
					pubNomineeDtls.setFirstName(internalNomineePIDtl.getClmFirstName());
					pubNomineeDtls.setMiddleName(internalNomineePIDtl.getClmMiddleName());
					pubNomineeDtls.setLastName(internalNomineePIDtl.getClmLastName());
				}
				pubNomineeDtls.setIsActive(true);
				pubNomineeDtls.setDob(GetSetUtils.CONVERT_API_DATE_FRMT(internalNomineePIDtl.getClmDob()));
				pubNomineeDtls.setRelationId(internalNominee.getClmRelationId());
				pubNomineeDtls.setMobileNumber(internalNominee.getClmMobile());
				pubNomineeDtls.setEmail(internalNominee.getClmEmail());
				pubNomineeDtls.setApplicationMaster(claimMsrPub.getApplicationMaster());
			}
		}
		return pubNomineeDtls;
	}


	private static PUBAddressMaster createOrUpdatePUBAddress(PUBAddressMaster pubAddress, AddressMasterV3 addressMaster) {
		if(null != addressMaster) {
			if (pubAddress != null) {
				BeanUtils.copyProperties(addressMaster, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
				pubAddress.setModifiedDate(new Date());
			} else {
				pubAddress = new PUBAddressMaster(new Date(), true);
				BeanUtils.copyProperties(addressMaster, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
			}
		}
		return pubAddress;
	}
	
	private static PUBAddressMaster createOrUpdatePUBAddressUsingNewDb(PUBAddressMaster pubAddress, AddressMasterV2 addressMaster,NomineePIDetails nomineePIDetails) {
		if(null != addressMaster) {
			if (pubAddress != null) {
				BeanUtils.copyProperties(addressMaster, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
				BeanUtils.copyProperties(nomineePIDetails, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
				pubAddress.setModifiedDate(new Date());
			} else {
				pubAddress = new PUBAddressMaster(new Date(), true);
				BeanUtils.copyProperties(addressMaster, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
				BeanUtils.copyProperties(nomineePIDetails, pubAddress, "id", "applicantInfo", "createdDate", "isActive");
			}
		}
		return pubAddress;
	}

	public static String CONVERT_API_DATE_FRMT(Date date) {
		if (date != null) {
			return DateUtils.setDateFormat(DateUtils.DateFormat.YYYY_MM_DD_HH_MM_SS, date);
		}
		return null;
	}
	
	public static <T extends AppMasterV2> T setAppMasterV2(ApplicationMasterV3 appMaster, ApplicationMasterOtherDetailsV3 otherDtls, 
			ApplicantInfo applicantInfo, Long lastTransactionId, T pmjjby) {
		pmjjby.setId(appMaster.getId());
		pmjjby.setUrn(appMaster.getUrn());
		pmjjby.setInsurerOrgId(appMaster.getInsurerOrgId());
		pmjjby.setBranchId(appMaster.getBranchId());
		pmjjby.setStatus(appMaster.getApplicationStatus());
		pmjjby.setCompletionDate(appMaster.getCompletionDate());
		pmjjby.setStatusChangeDate(appMaster.getStatusChangeDate());
		pmjjby.setCreatedBy(!OPLUtils.isObjectNullOrEmpty(appMaster.getCreatedBy()) ? appMaster.getCreatedBy() : appMaster.getUserId());
		pmjjby.setCreatedDate(appMaster.getCreatedDate());
		pmjjby.setModifiedBy(!OPLUtils.isObjectNullOrEmpty(appMaster.getModifiedBy()) ? appMaster.getModifiedBy() : appMaster.getUserId());
		pmjjby.setModifiedDate(appMaster.getModifiedDate());
		pmjjby.setMessage(appMaster.getMessage());
		pmjjby.setIsActive(appMaster.getIsActive());
		pmjjby.setPremiumAmount(appMaster.getPremiumAmount());
		pmjjby.setEnrollType(appMaster.getEnrollType());
		if(!OPLUtils.isObjectNullOrEmpty(otherDtls)) {
			pmjjby.setSource(otherDtls.getSource());
			pmjjby.setChannelId(otherDtls.getChannel());
			pmjjby.setGenderId(!OPLUtils.isObjectNullOrEmpty(applicantInfo) ? applicantInfo.getGenderId() : null);
			pmjjby.setBranchStateId(otherDtls.getBranchStateId());
			pmjjby.setBranchCityId(otherDtls.getBranchCityId());
			pmjjby.setBranchLhoId(otherDtls.getBranchLhoId());
			pmjjby.setBranchRoId(otherDtls.getBranchRoId());
			pmjjby.setBranchZoId(otherDtls.getBranchZoId());
			pmjjby.setRuralUrban(otherDtls.getRuralUrbanId());
		}

		pmjjby.setPolicyYear(fetchPolicyYear(pmjjby.getCompletionDate()));
		pmjjby.setFinancialYear(fetchFinancialYear(pmjjby.getCompletionDate()));
		pmjjby.setPolicyMonth(fetchMonth(pmjjby.getCompletionDate()));
		pmjjby.setFinancialMonth(fetchMonth(pmjjby.getCompletionDate()));
		pmjjby.setFinancialDay(fetchDay(pmjjby.getCompletionDate()));
		pmjjby.setPolicyDay(fetchDay(pmjjby.getCompletionDate()));
		pmjjby.setLastTransactionId(lastTransactionId);
		return pmjjby;
	}


	public static NomineePIDetails setNomineePiDetails(NomineePIDetails piDetails, Long nomineeId, NomineeDetails ndtls, AddressMasterV3 address,Date enrollmentDate) {
		if(OPLUtils.isObjectNullOrEmpty(piDetails)) {
			piDetails =new NomineePIDetails();
			piDetails.setId(nomineeId);
			piDetails.setEnrollmentDate(enrollmentDate);
		}
		piDetails.setFirstName(ndtls.getFirstName());
		piDetails.setMiddleName(ndtls.getMiddleName());
		piDetails.setLastName(ndtls.getLastName());
		piDetails.setName(ndtls.getName());
		piDetails.setDob(ndtls.getDob());
		if(!OPLUtils.isObjectNullOrEmpty(address)) {
			piDetails.setAddressLine1(address.getAddressLine1());
			piDetails.setAddressLine2(address.getAddressLine2());
		}
		return piDetails;
	}

	public static NomineeDetailsV2 setNomineeDetails(Long applicationId,NomineeDetails ndtls,NomineeDetailsV2 nominee) {
		if(OPLUtils.isObjectNullOrEmpty(nominee)){
			nominee = new NomineeDetailsV2();
			nominee.setId(ndtls.getId());
		}
		nominee.setApplicationId(applicationId);
		nominee.setRelationId(ndtls.getRelationId());
		nominee.setMobileNumber(ndtls.getMobileNumber());
		nominee.setEmail(ndtls.getEmail());
		nominee.setIsOtherClaimant(ndtls.getIsOtherClaimant());
		nominee.setModifiedBy(ndtls.getModifiedBy());
		nominee.setModifiedDate(ndtls.getModifiedDate());
		nominee.setIsActive(ndtls.getIsActive());
		return nominee;
	}

	public static AddressMasterV2 setNomineeAddress(AddressMasterV3 address,AddressMasterV2 nAdd) {
		if(OPLUtils.isObjectNullOrEmpty(nAdd)) {
			nAdd = new AddressMasterV2();
			nAdd.setId(address.getId());
		}
		nAdd.setCityName(address.getCityName());
		nAdd.setStateName(address.getStateName());
		nAdd.setPincode(address.getPincode());
		nAdd.setDistrict(address.getDistrict());
		nAdd.setCityLGDCode(address.getCityLGDCode());
		nAdd.setStateLGDCode(address.getStateLGDCode());
		nAdd.setStateId(address.getStateId());
		nAdd.setCityId(address.getCityId());
		return nAdd;
	}

	public static ApplicantInfoV2 setApplicantInfo(ApplicationMasterV3 appMaster, ApplicantInfo applicantInfo, ApplicationMasterOtherDetailsV3 otherDtls,ApplicantInfoV2 appInfo) {
		if(OPLUtils.isObjectNullOrEmpty(appInfo)) {
			appInfo = new ApplicantInfoV2();
			appInfo.setId(appMaster.getId());
		}
		appInfo.setEmail(applicantInfo.getEmail());
		appInfo.setMobileNumber(applicantInfo.getMobileNumber());
		appInfo.setIfsc(applicantInfo.getIfsc());
//		appInfo.setFatherHusbandName(applicantInfo.getFatherHusbandName());
		appInfo.setIsNomineeDetailsSameEnroll(applicantInfo.getIsNomineeDetailsSameEnroll());
		appInfo.setDisabilityStatus(applicantInfo.getDisabilityStatus());
		appInfo.setDisabilityDetails(applicantInfo.getDisabilityDetails());
		appInfo.setIsKYCUpdate(applicantInfo.getIsKYCUpdate());
		appInfo.setIsPMJJBYExists(applicantInfo.getIsPMJJBYExists());
		appInfo.setIsPMSBYExists(applicantInfo.getIsPMSBYExists());
		appInfo.setIsSameAppAddress(applicantInfo.getIsSameAppAddress());
		appInfo.setModifiedBy(applicantInfo.getModifiedBy());
		appInfo.setModifiedDate(applicantInfo.getModifiedDate());
		appInfo.setUserId1(otherDtls.getUserId1());
		appInfo.setUserId2(otherDtls.getUserId2());
		if(otherDtls.getSource().equals(Source.JANSURAKSHA_DIY.getId())) {
			appInfo.setIsDiyPremiumConsent(Boolean.TRUE);
		}
		appInfo.setIsNomineeDetailsSameEnroll(applicantInfo.getIsNomineeDetailsSameEnroll());
		appInfo.setTypeOfVerification(otherDtls.getTypeOfVerification());
		appInfo.setConsentForAutoDebit(otherDtls.getConsentForAutoDebit());

		return appInfo;
	}


	public static AddressMasterV2 setApplicantAddress(AddressMasterV3 addressInfo,AddressMasterV2 address) {
		if(OPLUtils.isObjectNullOrEmpty(address)) {
			address = new AddressMasterV2();
			address.setId(addressInfo.getId());
		}
		address.setCityId(addressInfo.getCityId());
		address.setStateId(addressInfo.getStateId());
		address.setDistrict(addressInfo.getDistrict());
		address.setPincode(addressInfo.getPincode());
		address.setStateName(addressInfo.getStateName());
		address.setCityName(addressInfo.getCityName());
		address.setDistrictLGDCode(addressInfo.getDistrictLGDCode());
		address.setStateLGDCode(addressInfo.getStateLGDCode());
		address.setCityLGDCode(addressInfo.getCityLGDCode());
		return address;
	}

	public static ApplicantPIDetails setApplicantPiDetails(ApplicationMasterV3 appMaster, ApplicantInfo applicantInfo,AddressMasterV3 addressInfo,ApplicantPIDetails appPiDtls) {
		if(OPLUtils.isObjectNullOrEmpty(appPiDtls)){
			appPiDtls = new ApplicantPIDetails();
			appPiDtls.setId(appMaster.getId());
			appPiDtls.setEnrollmentDate(appMaster.getEnrollmentDate());
		}
		appPiDtls.setFatherHusbandName(applicantInfo.getFatherHusbandName());
		appPiDtls.setAccountNumber(appMaster.getAccountNumber());
		appPiDtls.setCif(appMaster.getCif());
		appPiDtls.setAcHolderName(applicantInfo.getName());
		appPiDtls.setFirstName(applicantInfo.getFirstName());
		appPiDtls.setMiddleName(applicantInfo.getMiddleName());
		appPiDtls.setLastName(applicantInfo.getLastName());
		appPiDtls.setPan(applicantInfo.getPan());
		appPiDtls.setAadhaar(applicantInfo.getAadhaar());
		appPiDtls.setCkycNumber(applicantInfo.getCkycNumber());
		appPiDtls.setKycId1(applicantInfo.getKycId1());
		appPiDtls.setKycIdNumber1(applicantInfo.getKycIdNumber1());
		appPiDtls.setKycId2(applicantInfo.getKycId2());
		appPiDtls.setKycIdNumber2(applicantInfo.getKycIdNumber2());
		appPiDtls.setDob(applicantInfo.getDob());
		if(!OPLUtils.isObjectNullOrEmpty(addressInfo)) {
			appPiDtls.setAddressLine1(addressInfo.getAddressLine1());
			appPiDtls.setAddressLine2(addressInfo.getAddressLine2());
		}
		return  appPiDtls;
	}
	
	public static PushEnrollmentDetailsRequestV3 setNomineeDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			List<NomineeDetails> nomineeLst) {
		Optional<NomineeDetails> nomineeOptional = nomineeLst.stream()
				.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.NOMINEE.getId().equals(a.getType()))
				.findFirst();
		if (nomineeOptional.isPresent()) {
			NomineeDetails nomineeDtl = nomineeOptional.get();
			pushDataReq.setNomineeName(nomineeDtl.getName());
			pushDataReq.setNomineeDateOfBirth(!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getDob())
					? CommonUtils.sdf.format(nomineeDtl.getDob())
							: null);
			pushDataReq.setNomineeMobileNumber(nomineeDtl.getMobileNumber());
			pushDataReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getRelationId())
					? RelationShip.fromId(nomineeDtl.getRelationId()).getValue()
					: null);
			pushDataReq.setNomineeEmailId(nomineeDtl.getEmail());
			pushDataReq.setAddressofNominee(
					!OPLUtils.isObjectNullOrEmpty(nomineeDtl.getAddress()) ? nomineeDtl.getAddress().getAddressLine1()
							: null);
		}
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setGuardianDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			List<NomineeDetails> guardianLst) {
		Optional<NomineeDetails> guardianOptional = guardianLst.stream()
				.filter(a -> Boolean.TRUE.equals(a.getIsActive()) && NomineeType.GUARDIAN.getId().equals(a.getType()))
				.findFirst();
		if (guardianOptional.isPresent()) {
			NomineeDetails guardianDtl = guardianOptional.get();
			pushDataReq.setNameofGuardian(guardianDtl.getName());
			pushDataReq.setAddressOfGuardian(
					!OPLUtils.isObjectNullOrEmpty(guardianDtl.getAddress()) ? guardianDtl.getAddress().getAddressLine1()
							: null);
			pushDataReq.setRelationShipOfGuardian(!OPLUtils.isObjectNullOrEmpty(guardianDtl.getRelationId())
					? RelationShip.fromId(guardianDtl.getRelationId()).getValue()
					: null);
			pushDataReq.setGuardianMobileNumber(guardianDtl.getMobileNumber());
			pushDataReq.setGuardianEmailId(guardianDtl.getEmail());
		}
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setTransactionDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			TransactionDetailsV3 transactionDetails) {
		pushDataReq.setInsurerCode(transactionDetails.getInsurerCode());
		pushDataReq.setTransactionUTR(transactionDetails.getTransUtr());
		pushDataReq.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(transactionDetails.getTransTimeStamp())
				? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(transactionDetails.getTransTimeStamp())
						: null);
		pushDataReq.setTransactionAmount(transactionDetails.getTransAmount());
		pushDataReq.setTransactionType(TransactionType.NEW_ENROLLMENT.getKey());
		pushDataReq.setMasterPolicyNumber(transactionDetails.getMasterPolicyNo());
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setOtherDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
		ApplicationMasterOtherDetailsV3 appOtherDtl) {		
		
		if(!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getSource()) && appOtherDtl.getSource().equals(Source.OTHER_CHANNEL.getId())){			
			pushDataReq.setSource(Source.OTHER_CHANNEL.getMode());
			pushDataReq.setMode(null);
		}else {
			pushDataReq.setSource(Source.JANSURAKSHA.getMode());
			pushDataReq.setMode(Source.fromId(appOtherDtl.getSource()).getMode());			
		}
		pushDataReq.setBranchCode(appOtherDtl.getBranchCode());
		pushDataReq.setBankCode(appOtherDtl.getBankCode());
		pushDataReq.setConsentForAutoDebit("Yes");
		pushDataReq.setUserId1(appOtherDtl.getUserId1());
		pushDataReq.setUserId2(appOtherDtl.getUserId2());
		pushDataReq.setChannelId(!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getChannel()) ? ChannelIdEnum.fromId(appOtherDtl.getChannel()).getShortName() : null);
		pushDataReq.setRuralUrban(!OPLUtils.isObjectNullOrEmpty(appOtherDtl.getRuralUrbanId()) ? RuralUrbanEnum.fromId(appOtherDtl.getRuralUrbanId()).getValue() : null);
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setApplicantInfoDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			ApplicantInfo applicantInfo) {
		pushDataReq.setCustomerIFSC(applicantInfo.getIfsc());
		pushDataReq.setAccountHolderName(applicantInfo.getName());
		pushDataReq.setGender(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getGenderId())
				? Gender.fromId(applicantInfo.getGenderId()).getBankValue()
				: null);
		pushDataReq.setFatherHusbandName(applicantInfo.getFatherHusbandName());
		pushDataReq.setDob(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getDob())
				? CommonUtils.sdf.format(applicantInfo.getDob())
						: null);
		pushDataReq.setMobileNumber(applicantInfo.getMobileNumber());
		pushDataReq.setEmailId(applicantInfo.getEmail());
		if (!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAddress())) {
			pushDataReq.setAddressLine1(applicantInfo.getAddress().getAddressLine1());
			pushDataReq.setAddressLine2(applicantInfo.getAddress().getAddressLine2());
			pushDataReq.setPincode(validatePincode(applicantInfo.getAddress().getPincode()));
			pushDataReq.setCity(applicantInfo.getAddress().getCityName());
			pushDataReq.setDistrict(applicantInfo.getAddress().getDistrict());
			pushDataReq.setState(applicantInfo.getAddress().getStateName());
		}
		pushDataReq.setKycID1(applicantInfo.getKycId1());
		pushDataReq.setKycID1Number(applicantInfo.getKycIdNumber1());
		pushDataReq.setPan(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getPan()) ? YesNo.YES.getValue()
				: YesNo.NO.getValue());
		pushDataReq.setPanNumber(applicantInfo.getPan());
		pushDataReq.setAadhaar(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getAadhaar()) ? YesNo.YES.getValue()
				: YesNo.NO.getValue());
		pushDataReq.setAadhaarNumber(applicantInfo.getAadhaar());
		pushDataReq.setDisabilityStatus(!OPLUtils.isObjectNullOrEmpty(applicantInfo.getDisabilityStatus()) ? YesNo.fromShortName(applicantInfo.getDisabilityStatus()).getValue()
			: YesNo.NO.getValue());
		pushDataReq.setDisabilityDetails(applicantInfo.getDisabilityDetails());
		pushDataReq.setApplicantOccupation(applicantInfo.getOccupation());
		return pushDataReq;
	}

	public static PushEnrollmentDetailsRequestV3 setAppMstDtl(PushEnrollmentDetailsRequestV3 pushDataReq,
			ApplicationMasterV3 appMaster) {
		pushDataReq.setApplicationId(appMaster.getId());
		pushDataReq.setCommonUserId(appMaster.getUserId());
		pushDataReq.setOrgId(appMaster.getOrgId());
		pushDataReq.setUrn(appMaster.getUrn());
		pushDataReq.setPolicyYear(!OPLUtils.isObjectNullOrEmpty(appMaster.getCompletionDate())
				? String.valueOf(fetchPolicyYear(appMaster.getCompletionDate()))
				: null);
		pushDataReq.setFirstEnrollmentDate(!OPLUtils.isObjectNullOrEmpty(appMaster.getCompletionDate())
				? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(appMaster.getCompletionDate())
						: null);
		pushDataReq.setSchemeName(SchemeMaster.getById(appMaster.getSchemeId().longValue()).getShortName());
		pushDataReq.setAccountNumber(appMaster.getAccountNumber());
		pushDataReq.setCif(appMaster.getCif());
		return pushDataReq;
	}
	
	public static PushClaimDetailsRequestV3 setEnrollmentDetails(PushClaimDetailsRequestV3 pushDataReq, ClmMaster clmMaster,
			String masterPolicyNo, String bankName,BranchAndOrgDetailsProxy orgDetls) {
		ClmDetails clmDetails = clmMaster.getClmDetails();
		ClmPIDetails clmPIDetails = clmDetails.getClmPIDetails();
		pushDataReq.setUserId(clmMaster.getCreatedBy());
		pushDataReq.setApplicationId(clmMaster.getApplicationId());
		pushDataReq.setOrgId(clmMaster.getOrgId());
		pushDataReq.setClaimReferenceId(clmMaster.getId());
		pushDataReq.setMasterPolicyNumber(masterPolicyNo);
		pushDataReq.setUrn(clmMaster.getUrn());
		pushDataReq.setSchemeName(SchemeMaster.getById(clmMaster.getSchemeId().longValue()).getShortName());
		pushDataReq.setCustomerAccountNumber(clmPIDetails.getApAccountNumber());
		pushDataReq.setCustomerBankname(bankName);
		pushDataReq.setCustomerIFSC(clmDetails.getApCustomerIfsc());
		pushDataReq.setAccountHolderName(clmPIDetails.getAcHolderName());
		pushDataReq.setDob(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApDob())
				? clmPIDetails.getApDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		pushDataReq.setGender(!OPLUtils.isObjectNullOrEmpty(clmDetails.getApGenderId())
				? Gender.fromId(clmDetails.getApGenderId()).getBankValue()
				: null);
		if(!OPLUtils.isObjectNullOrEmpty(orgDetls)) {			
			pushDataReq.setInsurerCode(orgDetls.getInsurerCode());
			pushDataReq.setBankCode(orgDetls.getBankCode());
		}
		pushDataReq.setBranchCode(clmDetails.getBranchCode());
		pushDataReq.setBankBranchEmailId(clmDetails.getBranchEmailId());
		pushDataReq.setMobileNumber(clmDetails.getApMobileNumber());
		pushDataReq.setEmailID(clmDetails.getApEmail());
		pushDataReq.setAddressline1(clmPIDetails.getApAddressLine1());
		pushDataReq.setAddressline2(clmPIDetails.getApAddressLine2());

		ClmAddressMaster apAddressMaster = clmDetails.getApAddressMaster();
		pushDataReq.setPincode(validatePincode(apAddressMaster.getPincode()));
		pushDataReq.setCity(apAddressMaster.getCityName());
		pushDataReq.setDistrict(apAddressMaster.getDistrict());
		pushDataReq.setState(apAddressMaster.getStateName());

		pushDataReq.setKycID1(clmPIDetails.getApKycId1());
		pushDataReq.setKycID1number(clmPIDetails.getApKycIdNumber1());
		pushDataReq.setPanNumber(clmPIDetails.getApPan());
		pushDataReq.setPan(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApPan()) ? YesNo.YES.getValue()
				: YesNo.NO.getValue());
		pushDataReq.setAadhaarNumber(clmPIDetails.getApAadhaar());
		pushDataReq.setAadhaar(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApAadhaar()) ? YesNo.YES.getValue()
				: YesNo.NO.getValue());
		pushDataReq.setCkycNumber(clmPIDetails.getApCkycNumber());
		pushDataReq.setCkyc(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getApCkycNumber()) ? YesNo.YES.getValue()
				: YesNo.NO.getValue());
		return pushDataReq;
	}

	public static PushClaimDetailsRequestV3 setNomineeDetails(PushClaimDetailsRequestV3 pushDataReq, ClmMaster clmMaster) {
		ClmNomineeDetails clmNomineeDetails = clmMaster.getClmNomineeDetails();
		ClmNomineePIDetails clmNomineePIDetails = clmNomineeDetails.getClmNomineePIDetails();

		pushDataReq.setNomineeName(clmNomineePIDetails.getName());
		pushDataReq.setNomineeDateOfBirth(!OPLUtils.isObjectNullOrEmpty(clmNomineePIDetails.getDob())
				? clmNomineePIDetails.getDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		pushDataReq.setNomineeGender(!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getNomineeGenderId()) ? Gender.fromId(clmNomineeDetails.getNomineeGenderId()).getBankValue() :null);
		pushDataReq.setNomineeMobileNumber(clmNomineeDetails.getMobileNumber());
		pushDataReq.setNomineeEmailId(clmNomineeDetails.getEmail());
		pushDataReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getRelationId())
				? RelationShip.fromId(clmNomineeDetails.getRelationId()).getValue()
				: null);
		pushDataReq.setAddressofNominee(clmNomineePIDetails.getAddressLine1());
		pushDataReq.setCorrectNomineeName(clmNomineePIDetails.getCorrectNomineeName());
		return pushDataReq;
	}

	public static PushClaimDetailsRequestV3 setGuardianDetails(PushClaimDetailsRequestV3 pushDataReq, ClmMaster clmMaster) {
		ClmNomineeDetails clmNomineeDetails = clmMaster.getClmNomineeDetails();
		ClmNomineePIDetails clmNomineePIDetails = clmNomineeDetails.getClmNomineePIDetails();
		pushDataReq.setNameofGuardian(clmNomineePIDetails.getGdName());
		pushDataReq.setRelationShipOfGuardian(!OPLUtils.isObjectNullOrEmpty(clmNomineeDetails.getGdRelationId())
				? RelationShip.fromId(clmNomineeDetails.getGdRelationId()).getValue()
				: null);
		pushDataReq.setGuardianMobileNumber(clmNomineeDetails.getGdMobile());
		pushDataReq.setGuardianEmailId(clmNomineeDetails.getGdEmail());
		pushDataReq.setAddressOfGuardian(clmNomineePIDetails.getGdAddress());
		return pushDataReq;
	}

	public static PushClaimDetailsRequestV3 setClaimantDetails(PushClaimDetailsRequestV3 pushDataReq, ClmMaster clmMaster) {
		ClmDetails clmDetails = clmMaster.getClmDetails();
		ClmPIDetails clmPIDetails = clmDetails.getClmPIDetails();
		pushDataReq.setClaimantName(clmPIDetails.getClmName());
		pushDataReq.setClaimantAddress(clmPIDetails.getClmAddress());
		pushDataReq.setClaimantDateOfBirth(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getClmDob())
				? clmPIDetails.getClmDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		pushDataReq.setClaimantMobileNumber(clmDetails.getClmMobile());
		pushDataReq.setClaimantEmailId(clmDetails.getClmEmail());
		pushDataReq.setClaimantKYC1(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getClmKycId1())
				? KycDocument.fromId(clmPIDetails.getClmKycId1()).getKey()
				: null);
		pushDataReq.setClaimantKYCNumber1(clmPIDetails.getClmKycIdNumber1());
		pushDataReq.setClaimantKYC2(!OPLUtils.isObjectNullOrEmpty(clmPIDetails.getClmKycId2())
				? KycDocument.fromId(clmPIDetails.getClmKycId2()).getKey()
				: null);
		pushDataReq.setClaimantKycNumber2(clmPIDetails.getClmKycIdNumber2());
		pushDataReq.setClaimantGender(!OPLUtils.isObjectNullOrEmpty(clmDetails.getClmGenderId())
				? Gender.fromId(clmDetails.getClmGenderId()).getBankValue()
				: null);
		return pushDataReq;
	}

	public static PushClaimDetailsRequestV3 setClaimDetails(PushClaimDetailsRequestV3 pushDataReq, ClmMaster clmMaster) {
		ClmDetails clmDetails = clmMaster.getClmDetails();
		ClmPIDetails clmPIDetails = clmDetails.getClmPIDetails();
		pushDataReq.setDateOfAccident(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateTimeOfAccident())
				? clmDetails.getDateTimeOfAccident().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		pushDataReq.setTimeOfAccident(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateTimeOfAccident()) ? CommonUtils.HH_mm_ss.format(clmDetails.getDateTimeOfAccident()) : null);
		pushDataReq.setDayOfAccident(clmDetails.getDayOfAccident());
		pushDataReq.setPlaceOfOccurence(clmDetails.getPlaceOfOccurrence());
		pushDataReq.setNatureOfAccident(!OPLUtils.isObjectNullOrEmpty(clmDetails.getNatureOfLossId())
				? NatureOfLoss.fromId(clmDetails.getNatureOfLossId()).getValue()
				: null);
		pushDataReq.setDateOfDeath(!OPLUtils.isObjectNullOrEmpty(clmDetails.getDateOfDeath())
				? clmDetails.getDateOfDeath().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
				: null);
		if(clmMaster.getSchemeId()==SchemeMaster.PMJJBY.getId().intValue()) {			
			pushDataReq.setCauseOfDeath(!OPLUtils.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId())
					? CauseOfDeathDisabilityV2.fromId(clmDetails.getCauseOfDeathDisabilityId()).getValue()
							: null);
		}else {			
			pushDataReq.setCauseOfDeathDisability(!OPLUtils.isObjectNullOrEmpty(clmDetails.getCauseOfDeathDisabilityId())
					? CauseOfDeathDisabilityV2.fromId(clmDetails.getCauseOfDeathDisabilityId()).getValue()
							: null);
		}
		pushDataReq.setTypeOfDisability(!OPLUtils.isObjectNullOrEmpty(clmDetails.getTypeOfDisabilityId())
				? TypeOfDisability.fromId(clmDetails.getTypeOfDisabilityId()).getValue()
				: null);
		pushDataReq.setClaimantBankAccountNumber(clmPIDetails.getClmAccountNumber());
		pushDataReq.setClaimantBankName(clmPIDetails.getClmBankName());
		pushDataReq.setClaimantBranchIFSC(clmPIDetails.getClmBranchIfsc());
		/*if(!OPLUtils.isObjectNullOrEmpty(clmMaster.getClmDetails().getApTransactionTimestamp())) {			
			pushDataReq.setPremDebitDate(clmMaster.getClmDetails().getApTransactionTimestamp().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
			pushDataReq.setPremRemitDate(clmMaster.getClmDetails().getApTransactionTimestamp().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		}else {*/
			pushDataReq.setPremDebitDate(clmMaster.getClmDetails().getPremDebitDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
			pushDataReq.setPremRemitDate(clmMaster.getClmDetails().getPremRemitDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		//}
		pushDataReq.setDateOfLodgingClaim(
				!OPLUtils.isObjectNullOrEmpty(!OPLUtils.isObjectNullOrEmpty(clmMaster.getTransactionTimeStamp()))
						? clmMaster.getClaimDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(): null);
		return pushDataReq;
	}
	
	public static OptOutUpdateStatusRequestV3 prepareOptOutUpdateStatusRequestV3(String accNo, String urn, String cif,
			ApplicationMasterBothSchemeProxy applicationMaster, Date coverEndDate) {
		OptOutUpdateStatusRequestV3 updateStatusReq = new OptOutUpdateStatusRequestV3();
		updateStatusReq.setAccountNumber(accNo);
		updateStatusReq.setCif(cif);
		updateStatusReq.setEffectiveDate(!OPLUtils.isObjectNullOrEmpty(coverEndDate)
				? coverEndDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()
				: null);
		updateStatusReq.setUrn(urn);
		updateStatusReq.setApplicationId(applicationMaster.getId());
		updateStatusReq.setOrgId(applicationMaster.getOrgId());
		updateStatusReq.setRequestDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
		return updateStatusReq;
	}
	
	public static NomineeUpdateStatusRequestV3 prepareNomineeUpdateStatusRequestV3(
			ApplicationMasterBothSchemeProxy applicationMaster, NomineeDetailsV2 nomineeDetailsV2,
			NomineePIDetails nomineePIDetails) {
		NomineeUpdateStatusRequestV3 nomineeUpdateStatusReq = new NomineeUpdateStatusRequestV3();
		nomineeUpdateStatusReq.setApplicationId(applicationMaster.getId());
		nomineeUpdateStatusReq.setOrgId(applicationMaster.getOrgId());
		nomineeUpdateStatusReq.setUrn(applicationMaster.getUrn());
		nomineeUpdateStatusReq.setNomineeUpdateFlag("YES");
		nomineeUpdateStatusReq.setNomineeName(nomineePIDetails.getName());
		nomineeUpdateStatusReq.setNomineeDateOfBirth(!OPLUtils.isObjectNullOrEmpty(nomineePIDetails.getDob())
				? nomineePIDetails.getDob().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				: null);
		nomineeUpdateStatusReq.setNomineeMobileNumber(nomineeDetailsV2.getMobileNumber());
		nomineeUpdateStatusReq.setNomineeEmailId(nomineeDetailsV2.getEmail());
		nomineeUpdateStatusReq.setRelationshipOfNominee(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getRelationId())
				? RelationShip.fromId(nomineeDetailsV2.getRelationId()).getValue()
				: null);
		nomineeUpdateStatusReq.setAddressOfNominee(nomineePIDetails.getAddressLine1());
		nomineeUpdateStatusReq.setNameOfGuardian(nomineePIDetails.getGdName());
		nomineeUpdateStatusReq.setAddressOfGuardian(nomineePIDetails.getGdAddress());
		nomineeUpdateStatusReq.setRelationshipOfGuardian(!OPLUtils.isObjectNullOrEmpty(nomineeDetailsV2.getGdRelationId())
				? RelationShip.fromId(nomineeDetailsV2.getGdRelationId()).getValue()
				: null);
		nomineeUpdateStatusReq.setGuardianMobileNumber(nomineeDetailsV2.getGdMobile());
		nomineeUpdateStatusReq.setGuardianEmailId(nomineeDetailsV2.getGdEmail());
		return nomineeUpdateStatusReq;
	}
	
	static int fetchPolicyYear(Date date){
		int currentMonth = date.getMonth();
		int currentYear = date.getYear()+CommonUtils.INT_1900;
		if(currentMonth > Calendar.MAY){
			currentYear = currentYear + 1;
		}

		return currentYear;
	}

	static int fetchFinancialYear(Date date){
		int currentMonth = date.getMonth();
		int currentYear = date.getYear()+CommonUtils.INT_1900;
		if(currentMonth > Calendar.MARCH){
			currentYear = currentYear + 1;
		}

		return currentYear;
	}

	static int fetchMonth(Date date){
		return date.getMonth() + 1;
	}

	static int fetchDay(Date date){
		return date.getDate();
	}
	
	public static Integer validatePincode(Integer pincode) {
		if (!OPLUtils.isObjectNullOrEmpty(pincode) && pincode == 0) {
			return 000000;
		} else if (!OPLUtils.isObjectNullOrEmpty(pincode)) {
			return pincode;
		}
		return null;
	}
}
