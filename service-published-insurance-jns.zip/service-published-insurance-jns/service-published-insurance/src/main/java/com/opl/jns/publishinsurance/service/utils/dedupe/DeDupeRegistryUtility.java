package com.opl.jns.publishinsurance.service.utils.dedupe;
//package com.opl.jns.insurance.service.published.utils.dedupe;
//
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.util.Date;
//import java.util.Objects;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//import com.opl.api.dd.jns.model.claimDedupe.ClaimDedupApiProxy;
//import com.opl.api.dd.jns.model.dedupe.ClaimDedupApiResponse;
//import com.opl.api.dd.jns.model.updateClaimStatus.TransactionDetailsProxy;
//import com.opl.api.dd.jns.model.updateClaimStatus.UpdateClaimStatusProxy;
//import com.opl.client.dd.DedupeRegistryClient;
//import com.opl.jns.ere.domain.ApplicationMasterV3;
//import com.opl.jns.ere.domain.ClaimMasterV3;
//import com.opl.jns.ere.domain.ClmMaster;
//import com.opl.jns.ere.enums.CauseOfDeathDisability;
//import com.opl.jns.ere.enums.Gender;
//import com.opl.jns.ere.enums.NatureOfLoss;
//import com.opl.jns.ere.enums.TypeOfDisability;
//import com.opl.jns.ere.utils.CommonUtils;
//import com.opl.jns.insurance.api.published.CommonResponse;
//import com.opl.jns.insurance.api.published.publish.claim_dedupe_req_res.ClaimDeDupRequest;
//import com.opl.jns.utils.common.CommonErrorMsg;
//import com.opl.jns.utils.common.MultipleJSONObjectHelper;
//import com.opl.jns.utils.common.OPLUtils;
//import com.opl.jns.utils.enums.SchemeMaster;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * @author sandip.bhetariya
// *
// */
//@Slf4j
//@Service
//public class DeDupeRegistryUtility {
//
//	@Autowired
//	private DedupeRegistryClient dedupeRegistryClient;
//
//	
//	public ClaimDedupApiResponse callClaimDedupeRequest(ClaimMasterV3 claimMaster,ClaimDeDupRequest dedupeRequest) {
//			try {
//				com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callClaimDedupeRequest(getcallClaimDedupeRequestData(claimMaster,dedupeRequest));
//				
//				if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())) {
//					ClaimDedupApiResponse claimDedupApiResponse = MultipleJSONObjectHelper.getObjectFromObject(commonResponse.getData(), ClaimDedupApiResponse.class);
//					if(claimDedupApiResponse.getIsDup().equals(Boolean.TRUE)) {						
//						log.info("De Dupe details found for account number [{}] and response is : [{}]",claimMaster.getApplicationMaster().getAccountNumber(),MultipleJSONObjectHelper.getStringfromObject(claimDedupApiResponse));
//					}
//					return claimDedupApiResponse;
//				} else {
//					log.error(!OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//					return new ClaimDedupApiResponse(false, !OPLUtils.isObjectNullOrEmpty(commonResponse.getMessage()) ? CommonUtils.CLAIM_DUPE_EXCEPTION_MSG : commonResponse.getMessage());
//				}
//			} catch (Exception e) {
//				log.error(CommonUtils.CLAIM_DUPE_EXCEPTION_MSG + "------>", e);
//				return new ClaimDedupApiResponse(false, CommonUtils.CLAIM_DUPE_EXCEPTION_MSG);
//			}
//	}
//
//	private ClaimDedupApiProxy getcallClaimDedupeRequestData(ClaimMasterV3 claimMaster,ClaimDeDupRequest dedupeRequest) {
//		ApplicationMasterV3 applicationMaster = claimMaster.getApplicationMaster();
//			ClaimDedupApiProxy dedupRequest = new ClaimDedupApiProxy();
//			dedupRequest.setKycId1(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId1()) ?  applicationMaster.getApplicantInfo().getKycId1().toUpperCase() : applicationMaster.getApplicantInfo().getKycId1());
//			dedupRequest.setKycIdValue1(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycIdNumber1()) ? applicationMaster.getApplicantInfo().getKycIdNumber1().toUpperCase() : applicationMaster.getApplicantInfo().getKycIdNumber1());
//			dedupRequest.setKycId2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycId2()) ? applicationMaster.getApplicantInfo().getKycId2().toUpperCase() : applicationMaster.getApplicantInfo().getKycId2());
//			dedupRequest.setKycIdValue2(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getKycIdNumber2()) ? applicationMaster.getApplicantInfo().getKycIdNumber2().toUpperCase() : applicationMaster.getApplicantInfo().getKycIdNumber2());
//			dedupRequest.setCkycNumber(applicationMaster.getApplicantInfo().getCkycNumber());
//			dedupRequest.setGender(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getGenderId()) ? Gender.fromId(applicationMaster.getApplicantInfo().getGenderId()).getBankValue()  : null);
//			dedupRequest.setFirstName(applicationMaster.getApplicantInfo().getFirstName());
//			dedupRequest.setMiddleName(applicationMaster.getApplicantInfo().getMiddleName());
//			dedupRequest.setLastName(applicationMaster.getApplicantInfo().getLastName());
//			dedupRequest.setFatherHusbandName(applicationMaster.getApplicantInfo().getFatherHusbandName());
//			dedupRequest.setMob(applicationMaster.getApplicantInfo().getMobileNumber());
//			dedupRequest.setPincode(!OPLUtils.isObjectNullOrEmpty(applicationMaster.getApplicantInfo().getAddress()) ? applicationMaster.getApplicantInfo().getAddress().getPincode() : null);
//			dedupRequest.setDob(CommonUtils.formatDate_sdf_dd_mm_yyyy(applicationMaster.getApplicantInfo().getDob()));
//			dedupRequest.setBankCode(applicationMaster.getApplicationMasterOtherDetails().getBankCode());
//			dedupRequest.setAccNo(applicationMaster.getAccountNumber());
//			dedupRequest.setScheme(SchemeMaster.getById(applicationMaster.getSchemeId().longValue()).getShortName());
//			dedupRequest.setAccountStatus("A");
//			dedupRequest.setType("N");
//			dedupRequest.setOrgId(applicationMaster.getOrgId());
//			dedupRequest.setInsurerOrgId(applicationMaster.getInsurerOrgId());
//			dedupRequest.setCif(applicationMaster.getCif());
//			dedupRequest.setUrn(applicationMaster.getUrn());
//			dedupRequest.setEnrollmentDate(CommonUtils.formatDate_sdf(applicationMaster.getEnrollmentDate()));
//			dedupRequest.setDateOfDeath(CommonUtils.formatDate_sdf(claimMaster.getClaimDetail().getDateOfDeath()));
//			dedupRequest.setDateOfAccident(CommonUtils.formatDate_sdf(claimMaster.getClaimDetail().getDateTimeOfAccident()));
//			dedupRequest.setIsNameMatch("true");
//			dedupRequest.setClaimTypeId(getClaimTypeId(claimMaster));
//			dedupRequest.setClaimReferenceId(claimMaster.getId().toString());
//			dedupRequest.setFirNo(dedupeRequest.getFirNo());
//			dedupRequest.setFirDate(localDateToStr(dedupeRequest.getFirDate()));
//			dedupRequest.setPanchnamaNo(dedupeRequest.getPanchnamaNo());
//			dedupRequest.setPanchnamaDate(localDateToStr(dedupeRequest.getPanchnamaDate()));
//			dedupRequest.setPostMortemReportNo(dedupeRequest.getPostMortemReportNo());
//			dedupRequest.setPostMortemReportDate(localDateToStr(dedupeRequest.getPostMortemReportDate()));
//			dedupRequest.setDeathOrdisabilityCertificateReportNo(dedupeRequest.getDeathCertificateReportNo());
//			dedupRequest.setDeathOrdisabilityCertificateReportDate(localDateToStr(dedupeRequest.getDeathCertificateReportDate()));			
//			return dedupRequest;
//	}
//	
//	private String localDateToStr(LocalDateTime lct) {
//		if (!OPLUtils.isObjectNullOrEmpty(lct)) {
//			return CommonUtils
//					.formatDate_sdf_yyyy_MM_dd_HH_mm_ss(Date.from(lct.atZone(ZoneId.systemDefault()).toInstant()));
//		}
//		return null;
//	}
//	
//	private Integer getClaimTypeId(ClaimMasterV3 claimMaster) {
//		if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMSBY.getId().longValue()) {
//			if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DEATH.getId())) {
//				return 4;
//			} else if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
//					&& Objects.equals(claimMaster.getClaimDetail().getTypeOfDisablityId(), TypeOfDisability.PARTIAL_DISABILITY
//							.getId())) {
//				return 2;
//			} else if (Objects.equals(claimMaster.getClaimDetail().getNatureOfLossId(), NatureOfLoss.DISABILITY.getId())
//					&& Objects.equals(claimMaster.getClaimDetail().getTypeOfDisablityId(), TypeOfDisability.TOTAL_DISABILITY
//							.getId())) {
//				return 3;
//			}
//
//		} else if (claimMaster.getApplicationMaster().getSchemeId() == SchemeMaster.PMJJBY.getId().longValue()) {
//			if (Objects.equals(claimMaster.getClaimDetail().getCauseOfDeathDisabilityId(), CauseOfDeathDisability.NATURAL_DEATH_NON_ACCIDENTAL.getId())) {
//				return 1;
//			} else if (Objects.equals(claimMaster.getClaimDetail()
//					.getCauseOfDeathDisabilityId(), CauseOfDeathDisability.ACCIDENTAL_30_DAYS.getId())) {
//				return 5;
//			}
//		}
//		return null;
//	}
//	
//	public CommonResponse callUpdateClaimStatusRequest(ClmMaster claimMaster) {
//		try {
//			com.opl.jns.insurance.api.published.CommonResponse commonResponse = dedupeRegistryClient.callUpdateClaimStatusRequest(getcallUpdateClaimRequestData(claimMaster));
//
//			if (!OPLUtils.isObjectNullOrEmpty(commonResponse) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getData()) && !OPLUtils.isObjectNullOrEmpty(commonResponse.getStatus())
//					&& (commonResponse.getStatus() == HttpStatus.OK.value())) {
//				return new CommonResponse(CommonErrorMsg.Common.SUCCESS, HttpStatus.OK.value(), true);	
//			}
//			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		} catch (Exception e) {
//			log.error(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG + "------>", e);
//			return new CommonResponse(CommonUtils.UPDATE_CLAIM_EXCEPTION_MSG, HttpStatus.INTERNAL_SERVER_ERROR.value(), false);
//		}
//}
//	
//	private UpdateClaimStatusProxy getcallUpdateClaimRequestData(ClmMaster claimMaster) {
//		UpdateClaimStatusProxy updateClaimProxy = new UpdateClaimStatusProxy();
//	
//		updateClaimProxy.setClaimReferenceId(claimMaster.getId().toString());
//		updateClaimProxy.setUrn(claimMaster.getUrn());
//		updateClaimProxy.setClaimStatus(claimMaster.getStatus());
//		updateClaimProxy.setReason(claimMaster.getStatusReasonId());
//	
//		TransactionDetailsProxy transactionDetailsProxy = new TransactionDetailsProxy();
//		transactionDetailsProxy.setTransactionAmount(!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionAmount())
//				? claimMaster.getTransactionAmount().longValue()
//				: null);
//		transactionDetailsProxy.setTransactionTimeStamp(!OPLUtils.isObjectNullOrEmpty(claimMaster.getTransactionTimeStamp()) ? CommonUtils.sdf_yyyy_MM_dd_HH_mm_ss.format(claimMaster.getTransactionTimeStamp()) : null);
//		transactionDetailsProxy.setTransactionUTR(claimMaster.getTransactionUTR());
//	
//		updateClaimProxy.setTransactionDetails(transactionDetailsProxy);
//		return updateClaimProxy;
//	}
//	
//}
