package com.opl.jns.publishinsurance.service.repository.internal;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.*;

import com.opl.jns.publishinsurance.service.domain.internal.*;

import java.util.*;

/**
 * Created by dhaval on 15-Apr-17.
 */
public interface ProductStorageRepository extends JpaRepository<ProductStorageDetailsV3, Long> {

    @Query("select app.encryptedFileName from ProductStorageDetailsV3 app where (app.applicationId=:applicationId and app.productDocumentMappingId=:productDocumentMappingId and isActive=true and isFileUploadedAws=true) or (app.coApplicantId in (:coApplicantId) and app.productDocumentMappingId=:productDocumentMappingId and isActive=true and isFileUploadedAws=true)")
    public String getEncryptedFileNameFromApplicationId(@Param("applicationId") Long applicationId, @Param("productDocumentMappingId") Long productDocumentMappingId, @Param("coApplicantId") List<Long> coApplicantId);

    @Query("select app.encryptedFileName from ProductStorageDetailsV3 app where (app.id=:id and isActive=true)")
    public String getEncryptedFileNameFromId(@Param("id") Long id);


    @Query(value = "FROM ProductStorageDetailsV3 WHERE id IN (SELECT MAX(p.id) FROM ProductStorageDetailsV3 p WHERE p.applicationId=:applicationId and p.isActive=:isActive GROUP BY p.productDocumentMappingId)")
    List<ProductStorageDetailsV3> getListByApplicationIdAndIsActive(@Param("applicationId") Long applicationId,@Param("isActive") Boolean isActive);

    @Query(value = "FROM ProductStorageDetailsV3 WHERE id IN (SELECT MAX(p.id) FROM ProductStorageDetailsV3 p WHERE p.applicationId=:applicationId and p.claimId=:claimId and p.isActive=:isActive GROUP BY p.productDocumentMappingId)")
    List<ProductStorageDetailsV3> getListByApplicationIdAndClaimIdAndIsActive(@Param("applicationId") Long applicationId,@Param("claimId") Long claimId,@Param("isActive") Boolean isActive);

    @Query(value = "FROM ProductStorageDetailsV3 WHERE productDocumentMappingId IN (:mappingIds) and id IN (:maxIds)")
    List<ProductStorageDetailsV3> getListByApplicationIdAndIsActiveAndMappingIds(@Param("mappingIds") List<Long> mappingIds,@Param("maxIds") List<Long> maxIds);

    @Query(value = "SELECT MAX(id) FROM ProductStorageDetailsV3 WHERE applicationId=:applicationId and isActive=:isActive GROUP BY productDocumentMappingId", nativeQuery = true)
    List<Long> getListOfMaxIds(@Param("applicationId") Long applicationId, @Param("isActive") Boolean isActive);
    
    Boolean existsByApplicationIdAndProductDocumentMappingId(Long applicationId, Long productDocumentMappingId);

    @Query(value = "SELECT productDocumentMappingId FROM ProductStorageDetailsV3 WHERE id in (:storageId) and isActive = TRUE ")
    List<Long> getProductDocumentMappingIdFromStorageId(@Param("storageId") List<Long> storageId);
}

