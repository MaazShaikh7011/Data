package com.opl.jns.publishinsurance.service.utils;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.opl.jns.ere.enums.KycDocument;
import com.opl.jns.published.lib.domain.ApiConfigMaster;
import com.opl.jns.published.utils.common.CommonResponse;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.published.utils.config.DataSourceProvider;
import com.opl.jns.publishinsurance.api.PushPullException;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDetail;
import com.opl.jns.publishinsurance.service.model.CertificateInsData;
import com.opl.jns.publishinsurance.service.model.CertificateInsDtlRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PublishApiUtils {

	public static final String REQ_AUTH = "req_auth";

	public static String isSqsEnabled;

	@Value("${isSqsEnabled}")
	public void setStaticName(String name) {
		isSqsEnabled = name;
	}

	public static String getStaticName() {
		return isSqsEnabled;
	}
	
	public static String getWebHookURL(boolean isBank,long bankOrgId,long insurerOrgId) {
		try {
//			long x = new Date().getTime();
			if (isBank) {
				return "http://localhost:8068/wb/jns";
			} else {
				if(insurerOrgId == 226L){ //NIC
					return "http://localhost:8870/wb/jns";
				}else if(insurerOrgId == 208L){ // SBI LIFE
					return "http://localhost:8869/wb/jns";
				}else if(insurerOrgId == 189L || insurerOrgId == 188L || insurerOrgId == 237L){ // LIC UIIC AND ORCL
					return "http://localhost:8871/wb/jns";
				}else{
					return "http://localhost:8868/wb/jns";
				}
			}	
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GET WEBHOOK URL --->" + e.getMessage());
		}
		return "http://localhost:8068/wb/jns";
	}


	/**
	 * FETCH ORG NAME BY ORG ID
	 */
	public static String getOrganizationName(Long orgId) throws PushPullException {
		if(null == orgId){
			return null;
		}
		String url = DataSourceProvider.getAnsAppServerDomain().concat("user-management/v3/getOrganizationName/") + orgId;
//		String url = "https://qa-jns.instantmseloans.in/user-management/v3/getOrganizationName/" + orgId;
		log.info("Enter in getOrganizationName()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("req_auth", "true");
			HttpEntity<?> entity = new HttpEntity(headers);
			CommonResponse resp = (CommonResponse) CommonUtils.restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class, new Object[0]).getBody();
			return !OPLUtils.isObjectNullOrEmpty(resp.getData()) ? resp.getData().toString() : null;
		} catch (Exception var5) {
			log.error("Throw Exception While getOrganizationName ", var5);
			throw  new PushPullException(var5);
		}
	}

	/**
	 * FETCH ORG CODE BY ORG ID
	 * 
	 * @param orgId
	 * @return
	 */
	public static String getOrganizationCode(Long orgId) throws PushPullException  {
		if(null == orgId){
			return null;
		}
		String url = DataSourceProvider.getAnsAppServerDomain().concat("user-management/v3/getOrganizationCode/") + orgId;
//		String url = "https://qa-jns.instantmseloans.in/user-management/v3/getOrganizationCode/" + orgId;
		log.info("Enter in getOrganizationName()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<>(headers);
			CommonResponse resp =(CommonResponse) CommonUtils.restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class, new Object[0]).getBody();
			return !OPLUtils.isObjectNullOrEmpty(resp.getData()) ? resp.getData().toString() : null;
		} catch (Exception var5) {
			log.error("Throw Exception While getOrganizationName ", var5);
			throw  new PushPullException(var5);
		}
	}

	/**
	 *  Get Branch details by branchId
	 */

	public static String getBranchName(Long branchId)  throws PushPullException {
		if(null == branchId){
			return null;
		}
		String url = DataSourceProvider.getAnsAppServerDomain().concat("user-management/v3/getBranchName/") + branchId;
//		String url = "https://qa-jns.instantmseloans.in/user-management/v3/getBranchName/"+ branchId;

		log.info("Enter in getOrganizationName()  ------------>" + url);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set(REQ_AUTH, "true");
			HttpEntity<?> entity = new HttpEntity<Object>(headers);
			CommonResponse resp = (CommonResponse) CommonUtils.restTemplate.exchange(url, HttpMethod.GET, entity, CommonResponse.class).getBody();
			return !OPLUtils.isObjectNullOrEmpty(resp.getData()) ? resp.getData().toString() : null;
		} catch (Exception e) {
			log.error("Throw Exception While getOrganizationName ", e);
			throw  new PushPullException(e);
		}
	}


	/**
	 * UPLOAD / GENERATE COI
	 * @param applicationId
	 * @param orgId
	 * @return COI DMS STORAGE ID
	 */
	public static Long generateCOI(long applicationId, long orgId,ApiConfigMaster apiConfigMaster) {
		try {
			if (OPLUtils.isObjectNullOrEmpty(apiConfigMaster)
					|| OPLUtils.isObjectNullOrEmpty(apiConfigMaster.getValue())) {
				log.info("COI URL NOT FOUND FROM API CONFIGURATION WHILE GENERATE COI");
				return null;
			}
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(OPLUtils.REQUEST_HEADER_AUTHENTICATE, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
			headers.set(REQ_AUTH, OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
			headers.add("Accept", "application/json");

			// PREPARE REQUEST
			CertificateInsDtlRequest certificateInsDtlRequest = new CertificateInsDtlRequest();
			certificateInsDtlRequest.setIsCoiUpload(Boolean.TRUE);
			certificateInsDtlRequest.setApplicationId(applicationId);
			certificateInsDtlRequest.setOrgId(orgId);

			HttpEntity<Object> entity = new HttpEntity<>(certificateInsDtlRequest, headers);
			log.info("URL is :[{}]", apiConfigMaster.getValue());
			RestTemplate restTemplate = new RestTemplate();
			CommonResponse comRes = restTemplate.exchange(apiConfigMaster.getValue(), HttpMethod.POST, entity, CommonResponse.class).getBody();
			if (OPLUtils.isObjectNullOrEmpty(comRes) || OPLUtils.isObjectNullOrEmpty(comRes.getStatus())) {
				log.info("COMMON RESPONSE IS NULL WHILE GENERATE COI");
				return null;
			}
			if (comRes.getStatus() != 200) {
				log.info("FOUND ERROR WHILE GENERATE COI");
				return null;
			}
			if (OPLUtils.isObjectNullOrEmpty(comRes.getData())) {
				log.info("RESPONSE DATA IS NULL OR EMPTY WHILE GENERATE COI");
				return null;
			}
			@SuppressWarnings("unchecked")
			CertificateInsData crtRes = MultipleJSONObjectHelper
					.getObjectFromMap((Map<String, Object>) comRes.getData(), CertificateInsData.class);
			if (crtRes != null && crtRes.getCoiStorageId() != null) {
				return crtRes.getCoiStorageId();
			}
			log.info("COI GENERATE RESPONSE OR COI STORAGE ID IS NULL OR EMPTY");
		} catch (Exception e) {
			log.error("EXCEPTION WHILE GENERATE COI ---->", e);
		}
		return null;
	}

	public static String getKycDocument(Integer kycId, PUBClaimDetail claimDetailV3) {
		if (KycDocument.PAN.getId() == kycId) {
			return claimDetailV3.getPan();
		} else if (KycDocument.PASSPORT.getId() == kycId) {
			return claimDetailV3.getPassport();
		} else if (KycDocument.DRIVING_LICENCE.getId() == kycId) {
			return claimDetailV3.getDrivingLicense();
		} else if (KycDocument.MGNREGA_CARD.getId() == kycId) {
			return claimDetailV3.getMgnerega();
		} else if (KycDocument.VOTERS_ID_CARD.getId() == kycId) {
			return claimDetailV3.getVottingCardId();
		}
		return null;
	}


	public static boolean isSqsFlagEnabled(){
		return !com.opl.jns.utils.common.OPLUtils.isObjectNullOrEmpty(getStaticName()) && getStaticName().equalsIgnoreCase("true");
	}

}
