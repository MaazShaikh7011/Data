package com.opl.jns.publishinsurance.service.service.internal.impl;

import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.UploadedDocumentsDetailsProxy1_1;
import com.opl.jns.published.lib.domain.ApiConfigMaster;
import com.opl.jns.published.lib.repository.ApiConfigMasterRepo;
import com.opl.jns.publishinsurance.api.ZipRequest;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimDocs;
import com.opl.jns.publishinsurance.service.domain.publish.PUBClaimMaster;
import com.opl.jns.publishinsurance.service.repository.internal.pushDataRepository;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimDocsRepo;
import com.opl.jns.publishinsurance.service.repository.publish.PUBClaimMasterRepo;
import com.opl.jns.publishinsurance.service.service.internal.DMSService;
import com.opl.jns.publishinsurance.service.service.internal.PushDataService;
import com.opl.jns.utils.common.OPLUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Transactional
@Service
@Slf4j
public class PushDataServiceImpl implements PushDataService {

	@Autowired
	pushDataRepository pusDataRepository;
	
    @Autowired
	PUBClaimDocsRepo pubClaimDocsRepo;
    
    @Autowired
	PUBClaimMasterRepo pubClaimMasterRepo;
    
    @Autowired
	DMSService dmsService;
    
	@Autowired
	private ApiConfigMasterRepo configRepo;
	
//	@Override
//	public PushPullResponse fetchPublishedAppList(String request) {
//		try {
//
//			JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
////			String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
////			String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
//			Long typeId = filterJSON.has("typeId") ? filterJSON.get("typeId").asLong() : null;
//			String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
//			Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
//			Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
//
//			String searchQuery = "";
//			
//            String whereClause = " WHERE am.is_active = 1 " ;
//			
//			if(!OPLUtils.isObjectNullOrEmpty(orgId)) {
//            	whereClause += " AND am.org_id =" + orgId;            	
//            }
//			
//			if(!OPLUtils.isObjectNullOrEmpty(schemeId)) {
//            	whereClause += " AND am.scheme_id =" + schemeId;            	
//            }
//			
//			if (searchData != null) {
//				if (typeId == 1) {
//					searchQuery = " AND  am.urn =  '" +  searchData  +"'  ";
//
//				} else if(typeId == 2) {
////					searchQuery = " AND " + DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) = '"  + searchData + "' ";
//					searchQuery = " AND am.account_number = " + DBNameConstant.JNS_PUBLISH_API + ".\"PUBLISH_ENCVALUE\"('" + searchData + "') ";
//				}else {
//					searchQuery = " AND  am.application_id =  '" +  searchData  +"'  ";
//				}
//			}
//
//			 whereClause = whereClause + searchQuery;
//
//			String totalCountSelectQuery = "select (json_object('totalCount' value count(am.id))) ";
//
//			String tablesQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".application_master am ";
//
//			String orderByQuery = "order by am.created_date desc";
////			String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY";
//
//			String str = pusDataRepository.fetchAppCount(totalCountSelectQuery + tablesQuery + whereClause);
//			JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
//			Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;
//
//			String tableQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".application_master am INNER JOIN "
//					+ DBNameConstant.JNS_PUBLISH_API + ".applicant_info ai ON ai.application_id = am.id LEFT JOIN "
//					+ DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1";
//			
//				String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
//					+ " ,'schemeName' value schemeName,'applicationReferenceId' value applicationReferenceId,"
//					+ "'applicationId' value applicationId,"
//					+ "'urn' value urn, 'customerAccountNumber' value customerAccountNumber,"
//					+ "'application_status' value application_status, 'createdDate' value createdDate,"
//					+ "'enrollDate' value enrollDate,'message' value message, 'modifiedDate' value modifiedDate,"
//					+ "'orgId' value orgId,"
//					+ "'mobileNumber' value mobileNumber, 'name' value name )returning clob) FROM( SELECT am.id as applicationReferenceId,"
//					+ " am.application_id as applicationId,"
//					+ "sm.short_name as schemeName,am.urn as urn,"+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) as customerAccountNumber,"
//							+ "am.application_status as application_status,"
//					+ "am.created_date as createdDate,am.enrollment_date as enrollDate,am.message as message,am.modified_date as modifiedDate,am.org_id as orgId,"
//					+ ""+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(ai.mobile_number) as mobileNumber,"
//							+ ""+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(ai.name) as name ";
////			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery + " )";
//			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + " )";
//			System.err.println(mainQuery);
//			return new PushPullResponse("successfully get Data", pusDataRepository.fetchPublishedAppList(mainQuery),
//					HttpStatus.OK.value(), Boolean.TRUE);
//		}
//
//		catch (Exception e) {
//			log.error("Exception is getting while get fetchPublishedAppList", e);
//		}
//		return new PushPullResponse(ENROLL.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//	}

//	@Override
//	public PushPullResponse fetchPublishedClaimList(String request) {
//		try {
//
//			JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
////			String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
////			String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
//			Long typeId = filterJSON.has("typeId") ? filterJSON.get("typeId").asLong() : null;
//			String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
//			Long schemeId = filterJSON.has("schemeId") ? filterJSON.get("schemeId").asLong() : null;
//			Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
//
//			String searchQuery = "";
//			 String whereClause = " WHERE ca.is_active = 1 " ;
//				
//				if(!OPLUtils.isObjectNullOrEmpty(orgId)) {
//	            	whereClause += " AND am.org_id =" + orgId;            	
//	            }
//				
//				if(!OPLUtils.isObjectNullOrEmpty(schemeId)) {
//	            	whereClause += " AND am.scheme_id =" + schemeId;            	
//	            }
//				
//			if (searchData != null) {
//				if (typeId == 1) {
//					searchQuery = " AND  am.urn =  '" +  searchData  +"'  ";
//
//				} else if(typeId == 2) {
////					searchQuery = " AND " + DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) = '"  + searchData + "' ";
//					searchQuery = " AND am.account_number = " + DBNameConstant.JNS_PUBLISH_API + ".\"PUBLISH_ENCVALUE\"('" + searchData + "') ";
//				}else {
//					searchQuery = " AND  ca.application_id =  '" +  searchData  +"'  ";
//				}
//			}
//           
//			 whereClause = whereClause + searchQuery;
//
//			String totalCountSelectQuery = "select (json_object('totalCount' value count(ca.id))) ";
//			
//			String tablesQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".claim_master ca INNER JOIN "
//					+ DBNameConstant.JNS_PUBLISH_API + ".application_master am ON am.id = ca.application_ref_id " ;
//
//			String orderByQuery = "order by ca.created_date desc";
////			String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY";
//
//			String str = pusDataRepository.fetchClaimCount(totalCountSelectQuery + tablesQuery + whereClause);
//			JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
//			Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;
//
//			String tableQuery = " FROM " + DBNameConstant.JNS_PUBLISH_API + ".claim_master ca INNER JOIN "
//					+ DBNameConstant.JNS_PUBLISH_API + ".claim_detail cd ON cd.claim_id = ca.id INNER JOIN "
//					+ DBNameConstant.JNS_PUBLISH_API + ".application_master am ON am.id = ca.application_ref_id LEFT JOIN "
//					+ DBNameConstant.JNS_PUBLISH_API + ".applicant_info ai ON ai.application_id = am.id LEFT JOIN "
//					+ DBNameConstant.JNS_USERS + ".scheme_master sm ON sm.id=am.scheme_id AND sm.is_active=1";
//			
//			String selectQuery = "SELECT JSON_ARRAYAGG(JSON_OBJECT('totalCount' value " + totalCount
//					+ " ,'claimReferenceId' value lst.claimReferenceId,"
//					+ "'applicationId' value lst.applicationId,"
//					+ "'accountHolderName' value lst.accountHolderName,"
//					+ " 'amount_of_transaction' value lst.amount_of_transaction, "
//					+ " 'customerAccountNumber' value lst.customerAccountNumber, 'urn' value lst.urn,  "
//					+ "'mobileNumber' value lst.mobileNumber,'schemeName' value lst.schemeName,'claimDate' value lst.claimDate,  'modifiedDate' value lst.modifiedDate,"
//					+ "'createdDate' value lst.createdDate )returning clob) FROM( SELECT ca.id as claimReferenceId, ca.application_id as applicationId,"
//					+ " "+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(ai.name) as accountHolderName, ca.amount_of_transaction as amount_of_transaction,"
//					+ ""+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) as customerAccountNumber, am.urn as urn,"
//				    + ""+DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(ai.mobile_number) as mobileNumber, sm.short_name as schemeName, "
//					+ "ca.claim_date as claimDate, ca.modified_date as modifiedDate,ca.created_date as createdDate";
//			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + ") lst";
////			String mainQuery = selectQuery + tableQuery + whereClause + orderByQuery + limitQuery + ") lst";
//			System.err.println(mainQuery);
//			return new PushPullResponse("successfully get Data", pusDataRepository.fetchPublishedClaimList(mainQuery),
//					HttpStatus.OK.value(), Boolean.TRUE);
//		}
//
//		catch (Exception e) {
//			log.error("Exception is getting while get fetchPublishedClaimList", e);
//		}
//		return new PushPullResponse(ENROLL.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//	}

	@Override
	public byte[] getUploadedDocuments(GetClaimDocumentRequest documentRequest,
									   StringBuilder message) {
		try {
			UploadedDocumentsDetailsProxy1_1 uploadedDocumentsDetailsProxy = new UploadedDocumentsDetailsProxy1_1();
			List<PUBClaimDocs> claimDocument = null;
			 PUBClaimMaster pubClaimMaster =null;
			 
				if (!OPLUtils.isObjectNullOrEmpty(documentRequest.getClaimReferenceId())) {
					pubClaimMaster = pubClaimMasterRepo.findById(documentRequest.getClaimReferenceId()).get();
					
					claimDocument = pubClaimDocsRepo
							.findByClaimMasterIdAndIsActiveIsTrue(pubClaimMaster.getId());
				}
		     if(!OPLUtils.isObjectNullOrEmpty(pubClaimMaster.getApplicationId()))  {
		    	 return downloadZip(pubClaimMaster,claimDocument);	    			 
		     }
			
		} catch (Exception e) {
			log.error("Error While get Documents ",e);
		}
	        return null;
	}
	
	public byte[] downloadZip(PUBClaimMaster pubclaimMaster,List<PUBClaimDocs> claimDocument) {		
		
//		String url = "http://localhost:8052/dms/v3/getDocumentZip";
		ApiConfigMaster pushPullApi = configRepo.findByCodeAndIsActiveTrue("GET_DOWNLOAD_ZIP");
//		String url =  pushPullApi.getValue() + "" + pubclaimMaster.getId(); 
		String url =  pushPullApi.getValue();
 	  	try {
 	  		ZipRequest req = new ZipRequest();
 	  		req.setApplicationId(pubclaimMaster.getApplicationId());
 	  		req.setClaimId(pubclaimMaster.getClaimId());
 	  		req.setProductDocumentMappingIds(claimDocument.stream().map(x->x.getProductDocMapId()).collect(Collectors.toList()));
	          HttpHeaders headers = new HttpHeaders();
	          headers.set("req_auth", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		      headers.set("isDecrypt", OPLUtils.REQUEST_HEADER_AUTHENTICATE_VALUE);
		      headers.add("Accept", "application/json");
	          headers.setContentType(MediaType.APPLICATION_JSON);
	          HttpEntity<ZipRequest> entity = new HttpEntity<>(req, headers);
	          RestTemplate restTemplate = new RestTemplate();
	          log.info("getDocumentZip For -->" + pubclaimMaster.getClaimId() + "==========API URL ----------->" + url);
//	         String response = restTemplate.exchange(url, HttpMethod.POST,entity,String.class).getBody();
	         return restTemplate.exchange(url, HttpMethod.POST,entity, byte[].class).getBody();
	         
     } catch (Exception e) {
         log.error("Exception While calling getDocumentZip details api :: ", e);
     }
 	   return null;
	}



//	@Override
//	public PushPullResponse fetchPublishApiAuditDetailList(String request) {
//		try {
//			JsonNode filterJSON = MultipleJSONObjectHelper.convertJSONToObject(request, JsonNode.class);
//		      String paginationFROM = filterJSON.has("paginationFROM") ? filterJSON.get("paginationFROM").asText() : "0";
//	          String paginationTO = filterJSON.has("paginationTO") ? filterJSON.get("paginationTO").asText() : "10";
////	          String searchData = filterJSON.has("searchData") ? filterJSON.get("searchData").asText() : null;
//	          Long orgId = filterJSON.has("orgId") ? filterJSON.get("orgId").asLong() : null;
//	          Long type = filterJSON.has("type") ? filterJSON.get("type").asLong() : null;
//	          
////	          String searchQuery = "";
////				if (searchData != null) {
////					searchQuery = " AND ( " + DBNameConstant.JNS_PUBLISH_API+".PUBLISH_DECVALUE(am.account_number) LIKE " + "'%" + searchData + "%'" +
////								   " OR am.urn LIKE " + "'%"+ searchData + "%')";
////				}
//	          String dbname =null;
//	          if(type == 1 ) {
//	        	  dbname = DBNameConstant.JNS_PUBLISH_API ;
//	          }
//	          else {
//	        	  dbname = DBNameConstant.JNS_REGISTRY_API;
//	          }
//				
//				 String whereClause = "where 1=1 " ;
//				 
//				if(!OPLUtils.isObjectNullOrEmpty(orgId)) {
//	            	whereClause += " AND api.org_id = " + orgId;            	
//	            }
//				
////				 whereClause = whereClause + searchQuery;
//
//					String totalCountSelectQuery = "select (json_object('totalCount' value count(rl.id))) ";
//					
//					String tableQuery = " FROM " + dbname + ".request_log_audit rl INNER JOIN "
//						+ dbname + ".api_users api ON api.id = rl.api_user_id LEFT JOIN "
//						+ dbname + ".request_response_audit rr ON rr.log_audit_id = rl.id " ;
////						+ dbname + ".application_master am ON am.id  = rl.application_reference_id ";
//
//					String orderByQuery = " order by rl.created_date desc";
//					String limitQuery = " OFFSET " + paginationFROM + " ROWS FETCH NEXT " + paginationTO + " ROWS ONLY )" ;
//
//					  System.err.println(totalCountSelectQuery + tableQuery + whereClause);
//					String str = pusDataRepository.fetchClaimCount(totalCountSelectQuery + tableQuery + whereClause);
//					JsonNode json = MultipleJSONObjectHelper.convertJSONToObject(str, JsonNode.class);
//					Integer totalCount = json.has("totalCount") ? json.get("totalCount").asInt() : 0;
//					
//					String selectQuery="SELECT \n"
//		            		+ "                           rl.id as id,\n"
//		            		+ "                           rl.application_reference_id as applicationReferenceId ,\n"
//		            		+ "                           rl.request_url  as requestUrl,\n"
//		            		+ "                           rl.request_ip as requestIp,\n"
//		            		+ "                           api.org_id as orgId,\n"
//		            		+ "                           rr.request_header as requestHeader \n" ;
//					
//		           String selectsQuery ="SELECT json_arrayagg(json_object( \n"
//		            		+ "                           'totalCount'  value "+totalCount+" ,"
//		            		+ "                           'id' value id,\n"
//		            		+ "                           'applicationReferenceId' value applicationReferenceId,\n"
//		            		+ "                           'requestUrl' value requestUrl,\n"
//		            		+ "                           'requestIp' value requestIp,\n"
//		            		+ "                           'orgId' value orgId , \n"
//		            		+ "	                          'requestHeader' value requestHeader  \n ) RETURNING CLOB ) from (";
//		            
//		           String mainQuery = selectsQuery +selectQuery + tableQuery + whereClause + orderByQuery + limitQuery  ;
//		            System.err.println(mainQuery);
//		            return new PushPullResponse("successfully get Data", pusDataRepository.fetchPublishedClaimList(mainQuery),
//							HttpStatus.OK.value(), Boolean.TRUE);
//			
//			
//		}
//		catch(Exception e) {
//			log.error("Exception is getting while get fetchPublishApiAuditDetailList", e);
//		}
//		return new PushPullResponse(ENROLL.ERROR, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
//	}


	
}
