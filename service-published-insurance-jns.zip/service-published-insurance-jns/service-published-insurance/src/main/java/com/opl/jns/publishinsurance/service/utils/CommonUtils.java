package com.opl.jns.publishinsurance.service.utils;

import org.springframework.dao.*;
import org.springframework.web.client.*;

import java.sql.*;
import java.text.*;
import java.util.Date;
import java.util.UUID;


public class CommonUtils {
    public static final DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    public static final DateFormat E_MMM_dd_HH_mm_ss_z_yyyy=new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
    public static final DateFormat yyyy_MM_dd_T_HH_mm_ssXXX = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
    public static final DateFormat HH_MM = new SimpleDateFormat("HH:mm");
    public static final DateFormat HH_mm_ss = new SimpleDateFormat("HH:mm:ss");
    public static final DateFormat sdf_yyyy_MM_dd_HH_mm=new SimpleDateFormat("yyyy-MM-dd HH:mm");
    public static final DateFormat sdf_yyyy_MM_dd_HH_mm_ss=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final DateFormat sdf_dd_MM_yyyy_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	public static final DateFormat sdf_yyyy_MM_dd_T_HH_mm_ss_SS = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SS");
	public static final DateFormat sdf_dd_MM_yyyy_T_HH_mm_ss_SS = new SimpleDateFormat("dd/MM/yyyy'T'HH:mm:ss");
	public static final DateFormat day = new SimpleDateFormat("EEEE");  
	public static final String CLAIM_INITIATED_MSG = "Claim has already been initiated for the selected Account Holder";
	public static final String CLAIM_ALREADY_COMPLETE_MSG = "Claim has already complete for the selected holder !!";
	public static final String CLAIM_ALREADY_PAID_MSG = "Claim has already been paid for the selected A/C holder !!";
	public static final String CLAIM_ALREADY_REJECTED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_ALREADY_REJETED_DEATH_MSG = "Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_ALREADY_REJETED_ACCIDENTIAL_MSG = "Accidental Death Claim has been repudiated. Kindly reopen to proceed";
	public static final String CLAIM_SUM_INSURED_EXHUSTED_MSG = "Sum Insured has been exhausted for the selected A/C holder.";
	public static final String CLAIM_SUBMISSION_IN_PROGRESS_MSG = "Kindly complete the claim application that is pending for submission and then proceed here.";
	public static final String CLAIM_DEATH_MSG = "Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_DEATH_PAID_MSG = "Death Claim has already been paid for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_MSG = "Accidental Death Claim has already been initiated for the selected A/C holder";
	public static final String CLAIM_ACCIDENTIAL_PAID_MSG = "Accidental Death Claim has already been paid for the selected A/C holder";
	public static final String CUSTOMER_ALREADY_ENROLLED_ERROR="Customer is already enrolled with Scheme";
	public static final String DEATH = "Death";
	public static final String TOTAL_DISABILITY = "Total Disability";
	public static final Double PARTIALLY_DISABILITY_AMOUNT =100000.0;
	public static final Double OTHER_THAN_PARTIALLY_DISABILITY_AMOUNT =200000.0;
	public static final int INT_1900 = 1900;
	public static final String PROCEED = "Proceed";
	public static final Long SBI_BANK_ID = 16l;

	public static final Long LONG_2 = 2L;
	public static final RestTemplate restTemplate = new RestTemplate();
    public static boolean isDBConnectionError(Object e){
        return (e instanceof SQLNonTransientConnectionException || e instanceof DataAccessResourceFailureException);
    }

    public static final Long ORG_TYPE_INSURER = 3L;
    public static final Long ORG_TYPE_BANK = 1L;

	public static String getTimestampFormat(Date date, String format) {
		return new SimpleDateFormat(format).format(date);
	}

	/**GENERATE TOKEN*/
	public static String generateToken(Long orgId) {
		java.util.Date date = new Date();
		return "JNS" + String.format("%03d", orgId) +getTimestampFormat(date, "YYMMdd") + getTimestampFormat(date, "hhMMsss")
				+ UUID.randomUUID().toString().replace("-", "").substring(0, 8);
	}

}
