package com.opl.jns.publishinsurance.service.controller.publish.v2;

import com.opl.jns.api.proxy.insurer.GetCoiDetails.GetCoiRequest;
import com.opl.jns.api.proxy.insurer.GetCoiDetails.GetCoiResponse;
import com.opl.jns.api.proxy.insurer.NomineeUpdateStatus.NomineeUpdateStatusRequest;
import com.opl.jns.api.proxy.insurer.NomineeUpdateStatus.NomineeUpdateStatusResponse;
import com.opl.jns.api.proxy.insurer.OptOutUpdateStatus.DiyOptOutUpdateStatusResponse;
import com.opl.jns.api.proxy.insurer.OptOutUpdateStatus.OptOutUpdateStatusRequest;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response400;
import com.opl.jns.publishinsurance.api.publish.api_responses.Response401;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.publish.ValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(Constants.REQUEST_MAPPING_V2)
@Slf4j
@Tag(name = "3. Opt-out,Nominee UpdateStatus ", description = "List of APIs for Opt out status, Nominee Update status and COI regeneration")
public class OptoutControllerV2 {

	@Autowired
	ValidationService validationService;

	@PostMapping(value = "/optOutUpdateStatus")
	@Operation(operationId = Constants.STR_12, summary = Constants.OPT_OUT_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.OPT_OUT_STATUS_EXAMPLE,description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = DiyOptOutUpdateStatusResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.OPT_OUT_STATUS_SUCCESS,description = Constants.DATE_FORMAT_DESCRIPTION),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//		                         examples = {
//		                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_401),
//		                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//		                         }
							) }) })
	public ResponseEntity<DiyOptOutUpdateStatusResponse> optOutStatus(
			@RequestBody OptOutUpdateStatusRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/nomineeUpdateStatus")
	@Operation(operationId = Constants.STR_13, summary = Constants.NOMINEE_UPDATE_STATUS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.NOMINEE_UPDATE_STATUS_EXAMPLE,description = Constants.DOB_DATE_FORMAT_DESCRIPTION_NOMINEE),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = NomineeUpdateStatusResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.NOMINEE_UPDATE_SUCCESS,description = Constants.DATE_FORMAT_DESCRIPTION),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//		                         examples = {
//		                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_401),
//		                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//		                         }
							) }) })
	public ResponseEntity<NomineeUpdateStatusResponse> optOutStatus(
			@RequestBody NomineeUpdateStatusRequest applicationRequest, HttpServletRequest httpServletRequest) {
		return null;

	}

	@PostMapping(value = "/getCOIDetails")
	@Operation(operationId = Constants.STR_14, summary = Constants.GET_COI_DETAILS, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
			@ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.GET_COI_EXAMPLE,description = Constants.DOB_DATE_FORMAT_DESCRIPTION),
			@ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE), })), responses = {
					@ApiResponse(responseCode = Constants.STR_200, description = Constants.COMMON_DATA_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCoiResponse.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.GET_COI_SUCCESS,description = Constants.DATE_FORMAT_DESCRIPTION_COI),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }) }),
					@ApiResponse(responseCode = Constants.STR_400, description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
							@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
									@ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_400),
									@ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE) }

							) }),
					@ApiResponse(responseCode = Constants.STR_401, description = Constants.COMMON_UNAUTHORIZED_MESSAGE, content = {
							@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
//		                         examples = {
//		                                 @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.WB_PLAIN_RESPONSE_401),
//		                                 @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)
//		                         }
							) }) })
	public ResponseEntity<GetCoiResponse> optOutStatus(@RequestBody GetCoiRequest applicationRequest,
													   HttpServletRequest httpServletRequest) {
		return null;

	}
}
