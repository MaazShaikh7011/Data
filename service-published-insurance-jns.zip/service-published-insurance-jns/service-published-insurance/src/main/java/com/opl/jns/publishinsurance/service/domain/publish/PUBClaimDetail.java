package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.published.lib.utils.*;
import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "claim_detail", indexes = {
//        @Index(columnList = "is_active", name = "is_active_clm_detl_idx"),
})
public class PUBClaimDetail extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_claim_detail_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_claim_detail_seq_gen", sequenceName = "pub_claim_detail_seq_gen", allocationSize = 1)
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "claim_id", referencedColumnName = "id")
	private PUBClaimMaster claimMaster;

	@Column(name = "claimant_bank_account_number", nullable = true)
	private String claimantBankAccountNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "pan", nullable = true)
	private String pan;

    @Convert(converter = AESEncryption.class)
	@Column(name = "aadhar", nullable = true)
	private String aadhar;

    @Convert(converter = AESEncryption.class)
	@Column(name = "passport", nullable = true)
	private String passport;

    @Convert(converter = AESEncryption.class)
	@Column(name = "mgnerega", nullable = true)
	private String mgnerega;

    @Convert(converter = AESEncryption.class)
	@Column(name = "driving_license", nullable = true)
	private String drivingLicense;

    @Convert(converter = AESEncryption.class)
	@Column(name = "votting_card_id", nullable = true)
	private String vottingCardId;

	@Column(name = "location_of_loss", nullable = true)
	private String locationOfLoss;

	@Column(name = "loss_location_pincode", nullable = true)
	private Long lossLocationPincode;

	@Column(name = "nature_of_loss_id", nullable = true)
	private Integer natureOfLossId;

	@Column(name = "cause_of_death_disability_id", nullable = true)
	private Integer causeOfDeathDisabilityId;

	@Column(name = "type_of_disability_id", nullable = true)
	private Integer typeOfDisablityId;

	@Column(name = "fir_no", nullable = true)
	private Long firNo;


	@Column(name = "name_of_bank", nullable = true)
	private String nameOfBank;

//	@Column(name = "branch_ifsc_code", nullable = true)
//	private String branchIfscCode;
	@Column(name = "cust_ifsc_code", nullable = true)
	private String custIfscCode;

	@Column(name = "kyc_doc_id", nullable = true)
	private String kycDocId;

	// ------------- NEW ADDED
	@Column(name = "nature_of_loss_name", nullable = true)
	private String natureOfLossName;

	@Column(name = "cause_of_death_disability_name", nullable = true)
	private String causeOfDeathDisabilityName;

	@Column(name = "type_of_disability_name", nullable = true)
	private String typeOfDisablityName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "date_of_death", nullable = true)
	private String dateOfDeath;

    @Convert(converter = AESEncryption.class)
	@Column(name = "date_time_of_accident", nullable = true)
	private String dateTimeOfAccident;
	
	@Column(name = "day_of_accident", nullable = true)
	private String dayOfAccident;

	public PUBClaimDetail(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
