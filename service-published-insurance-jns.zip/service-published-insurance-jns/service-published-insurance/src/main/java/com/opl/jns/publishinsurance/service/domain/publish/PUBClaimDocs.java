package com.opl.jns.publishinsurance.service.domain.publish;

import com.opl.jns.utils.constant.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "claim_docs", indexes = {
//        @Index(columnList = "is_active", name = "is_active_clm_detl_idx"),
})
public class PUBClaimDocs extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_claim_docs_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_claim_docs_seq_gen", sequenceName = "pub_claim_docs_seq_gen", allocationSize = 1)
	private Long id;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "claim_id", referencedColumnName = "id")
	private PUBClaimMaster claimMaster;

	@Column(name = "product_doc_map_id", nullable = true)
	private Long productDocMapId;

	@Column(name = "dms_id", nullable = true)
	private Long dmsId;

	@Column(name = "document_type", nullable = true)
	private String documentType;

	@Column(name = "content_type", nullable = true)
	private String contentType;

	@Column(name = "master_id", nullable = true)
	private Long masterId; // documentMasterId

	public PUBClaimDocs(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
