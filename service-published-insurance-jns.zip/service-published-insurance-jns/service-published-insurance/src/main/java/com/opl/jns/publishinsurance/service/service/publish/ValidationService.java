package com.opl.jns.publishinsurance.service.service.publish;

import jakarta.servlet.http.*;
import java.util.*;

public interface ValidationService {

    public Map<String, Object> isValidUser(HttpServletRequest request, Long applicationRefId,Long claimRefId) ;
}
