package com.opl.jns.publishinsurance.service.domain.publish;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PostLoad;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import com.opl.jns.ere.enums.Gender;
import com.opl.jns.ere.enums.YesNo;
import com.opl.jns.published.lib.utils.AESEncryption;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.utils.constant.DBNameConstant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author ravi.thummar Date : 15-06-2023
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "applicant_info")
public class PUBApplicantInfo extends PUBAuditor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pub_applicant_info_seq_gen")
	@SequenceGenerator(schema = DBNameConstant.JNS_PUBLISH_API, name = "pub_applicant_info_seq_gen", sequenceName = "pub_applicant_info_seq_gen", allocationSize = 1)
	private Long id;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private PUBApplicationMaster applicationMaster;

    @Convert(converter = AESEncryption.class)
	@Column(name = "name", nullable = true)
	private String name;

    @Convert(converter = AESEncryption.class)
	@Column(name = "first_name", nullable = true)
	private String firstName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "middle_name", nullable = true)
	private String middleName;

    @Convert(converter = AESEncryption.class)
	@Column(name = "last_name", nullable = true)
	private String lastName;

	@Column(name = "ifsc", nullable = true)
	private String ifsc;

	@Column(name = "is_kyc_update", nullable = true)
	private Boolean isKYCUpdate;

	@Column(name = "is_pmjjby_exists", nullable = true)
	private Boolean isPMJJBYExists;

	@Column(name = "is_pmsby_exists", nullable = true)
	private Boolean isPMSBYExists;

	@Column(name = "gender_id", nullable = true)
	private Integer genderId;

	@Column(name = "gender", nullable = true)
	private String gender;

	@Transient
	private Gender genderEnm;

	@PostLoad
	void fillTransient() {
		if (!OPLUtils.isObjectNullOrEmpty(genderId)) {
			this.genderEnm = Gender.fromId(genderId);
		}
//		if (disablityStatusEnum != null) {
//			this.disablityStatusEnum = YesNo.fromId(disabilityStatusId);
//		}
	}

    @Convert(converter = AESEncryption.class)
	@Column(name = "mobile_number", nullable = true)
	private String mobileNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "email", nullable = true)
	private String email;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_1", nullable = true)
	private String kycId1;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_2", nullable = true)
	private String kycId2;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_3", nullable = true)
	private String kycId3;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_number_1", nullable = true)
	private String kycIdNumber1;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_number_2", nullable = true)
	private String kycIdNumber2;

    @Convert(converter = AESEncryption.class)
	@Column(name = "kyc_id_number_3", nullable = true)
	private String kycIdNumber3;

    @Convert(converter = AESEncryption.class)
	@Column(name = "pan", nullable = true)
	private String pan;

    @Convert(converter = AESEncryption.class)
	@Column(name = "aadhaar", nullable = true)
	private String aadhaar;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "address_id", referencedColumnName = "id")
	private PUBAddressMaster address;

	@Column(name = "is_same_app_address", nullable = true)
	private Boolean isSameAppAddress;

    @Convert(converter = AESEncryption.class)
	@Column(name = "dob", nullable = true)
	private String dob;

	@Column(name = "ckyc", nullable = true)
	private String ckyc; // type change
	
    @Column(name = "ckyc_number",nullable = true)
    private String ckycNumber;

    @Convert(converter = AESEncryption.class)
	@Column(name = "father_husband_name", nullable = true)
    private String fatherHusbandName;
    
	@Column(name = "disability_status", nullable = true)
	private String disabilityStatus;

	@Transient
	private YesNo disablityStatusEnum;
	
	@Convert(converter = AESEncryption.class)
    @Column(name = "occupation",nullable = true)
    private String occupation;

    @Column(name = "disability_details",nullable = true)
    private String disabilityDetails;
	
	public PUBApplicantInfo(Date createdDate, Boolean isActive) {
		super(createdDate, isActive);
	}

}
