package com.opl.jns.publishinsurance.service.controller.internal;


import com.opl.jns.ere.enums.PushBankAndInsurerTypeEnum;
import com.opl.jns.published.lib.utils.SkipInterceptor;
import com.opl.jns.published.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.published.utils.common.OPLUtils;
import com.opl.jns.publishinsurance.api.insurance.published.v1.BankInsurerPushProxy;
import com.opl.jns.publishinsurance.api.internal.PushPullResponse;
import com.opl.jns.publishinsurance.api.utils.Constants;
import com.opl.jns.publishinsurance.service.service.internal.PushBankInsurerService;
import com.opl.jns.publishinsurance.service.service.internal.PushService;
import com.opl.jns.publishinsurance.service.utils.BankAndInsurerPushDataUtils;
import com.opl.jns.utils.enums.UserTypeMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author - Maaz Shaikh
 * @Date - 5/1/2023
 */
@RestController
@RequestMapping("/push/v3")
@Slf4j
public class PushController {

    @Autowired
    PushService service;
    
    @Autowired
    PushBankInsurerService bankInsurerService;

    @Autowired
    BankAndInsurerPushDataUtils detailUtils;

    @SkipInterceptor
    @GetMapping("/enrollment/{applicationId}")
    public ResponseEntity<PushPullResponse> pushEnrolmentData(@PathVariable Long applicationId) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(applicationId)) {
                return new ResponseEntity<>(new PushPullResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value(), Boolean.TRUE), HttpStatus.OK);
            }
            service.pushEnrolmentData(applicationId);
            return new ResponseEntity<>(new PushPullResponse("Details pushed successfully.", HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    /**
     * FETCH CURRENT APPLICATION MASTER DETAILS
     *
     * @return
     */
    @SkipInterceptor
    @GetMapping("/claim/{claimId}")
    public ResponseEntity<PushPullResponse> saveAll(@PathVariable Long claimId) {
        try {
            service.pushClaimDetails(claimId);
            return new ResponseEntity<>(new PushPullResponse("Details pushed successfully.", HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    /**
     * FETCH CURRENT APPLICATION MASTER DETAILS
     *
     * @return
     */
    @SkipInterceptor
    @GetMapping("/claim/docs/{claimId}")
    public ResponseEntity<PushPullResponse> updateDocsInCaseOfQuery(@PathVariable Long claimId) {
        try {
            PushPullResponse psResp = new PushPullResponse();
            boolean status = service.updateDocsInCaseOfQuery(claimId);
            psResp.setFlag(status);
            psResp.setStatus(status ? HttpStatus.OK.value() : HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(psResp, HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null, HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }
    @SkipInterceptor
    @GetMapping("/pushStorageId/{applicationId}/{storageId}")
    public ResponseEntity<PushPullResponse> pushStorageId(@PathVariable Long applicationId,@PathVariable Long storageId) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(applicationId) || OPLUtils.isObjectNullOrEmpty(storageId) ) {
                return new ResponseEntity<>(new PushPullResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value(), Boolean.TRUE), HttpStatus.OK);
            }
            boolean status = service.pushStorageId(applicationId, storageId);
            return new ResponseEntity<>(new PushPullResponse("Storage id updated",status,HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/pushEnrollment/{page}/{count}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<com.opl.jns.utils.common.CommonResponse> pushApp(@PathVariable Integer page, @PathVariable Integer count) {
        try {
            log.info("Enter in push app -->");
            service.pushApplicationHasError(page, count);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while get stage details ------>", e);
            return new ResponseEntity<com.opl.jns.utils.common.CommonResponse>(com.opl.jns.utils.common.CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
    
    @SkipInterceptor
    @GetMapping("/pushNomineeUpdate/{applicationId}/{schemeId}")
    public ResponseEntity<PushPullResponse> pushNomineeUpdate(@PathVariable Long applicationId,@PathVariable Long schemeId) {
        try {
            if (OPLUtils.isObjectNullOrEmpty(applicationId) || OPLUtils.isObjectNullOrEmpty(schemeId)) {
                return new ResponseEntity<>(new PushPullResponse(Constants.MSG_INVALID_BAD_REQUEST_FOR_PARAM_EMPTY,HttpStatus.BAD_REQUEST.value(), Boolean.TRUE), HttpStatus.OK);
            }
            service.pushNomineeUpdate(applicationId,schemeId);
            return new ResponseEntity<>(new PushPullResponse("Nominee details pushed successfully.", HttpStatus.OK.value(), true), HttpStatus.OK);
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
        }
    }
    
    @SkipInterceptor
    @PostMapping(value = "/pushBankAndInsurer", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PushPullResponse> pushBankAndInsurer(@RequestBody BankInsurerPushProxy req) {
		try {
			log.info("Enter in pushBankAndInsurer -----> " + MultipleJSONObjectHelper.getStringfromObject(req));
			req.setIsSchedular(false);
			if(req.getType()==PushBankAndInsurerTypeEnum.ENROLLMENT_PUSH.getId()) {		
				bankInsurerService.pushBankInsurerEnrolmentData(req,true);
			}else if(req.getType()==PushBankAndInsurerTypeEnum.OPT_OUT_PUSH.getId()) {
				bankInsurerService.pushBankInsurerOptOutData(req);
			}else if(req.getType()==PushBankAndInsurerTypeEnum.NOMINEE_UPDATE_PUSH.getId()) {
				bankInsurerService.pushBankInsurerNomineeUpdateData(req);
			}else if(req.getType()==PushBankAndInsurerTypeEnum.CLAIM_PUSH.getId()) {
				bankInsurerService.pushBankInsurerClaimData(req);
			}else if(req.getType()==PushBankAndInsurerTypeEnum.CLAIM_STATUS_PUSH_BANK_INSURER.getId() && req.getUserType()==UserTypeMaster.INSURER.getId()) {
				bankInsurerService.pushInsurerClaimStatusData(req);
			}else if(req.getType()==PushBankAndInsurerTypeEnum.CLAIM_STATUS_PUSH_BANK_INSURER.getId() && req.getUserType()==UserTypeMaster.FUNDPROVIDER.getId()) {
				bankInsurerService.pushBankClaimStatusData(req);
			}
			log.info("End in pushBankAndInsurer -----> ");
			return new ResponseEntity<>(new PushPullResponse(Constants.SUCCESS,HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			log.error(Constants.EXCEPTION_WHILE_SAVING, e);
            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
		}
	}

//    @SkipInterceptor
//    @GetMapping("/testSqs/{orgId}")
//    public ResponseEntity<PushPullResponse> pushNomineeUpdate(@RequestBody String request,@PathVariable("orgId") Long orgId) {
//        try {
//            log.info("orgId + {}",orgId);
//            log.info("request + {}",request);
//            detailUtils.testSqs(request,orgId);
//            return new ResponseEntity<>(new PushPullResponse("Nominee details pushed successfully.", HttpStatus.OK.value(), true), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
//            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//        }
//    }

//    @SkipInterceptor
//    @PostMapping(value = "/encryptSqsConfiguration", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<PushPullResponse> encryptSqsConfiguration(@RequestBody List<SqsConfiguration> req) {
//        try {
//            return new ResponseEntity<>(new PushPullResponse(Constants.SUCCESS,SQSEncryptionUtils.encryptSqsConfiguration(req),HttpStatus.OK.value(), Boolean.TRUE), HttpStatus.OK);
//        } catch (Exception e) {
//            log.error(Constants.EXCEPTION_WHILE_SAVING, e);
//            return new ResponseEntity<>(new PushPullResponse(Constants.ErrorMsg.SMTG_WNT_WRG, null,HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE), HttpStatus.OK);
//        }
//    }
}
