package com.opl.jns.publishinsurance.service.service.publish;

import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimApplicationDetails.ClaimDetailsProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetClaimList.ClaimProxy;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.GetClaimDocumentRequest;
import com.opl.jns.api.proxy.insurer.v1.Claim.GetUploadedDocuments.UploadedDocumentsDetailsProxy1_1;

import java.time.LocalDateTime;
import java.util.List;

public interface ClaimService {

    List<ClaimProxy> getClaimApplicationListForPush(LocalDateTime fromDateStr, LocalDateTime toDateStr, Long userOrgId) throws  Exception;

    ClaimDetailsProxy getClaimApplicationDetails(Long applicationReferenceId) throws  Exception;

    public UploadedDocumentsDetailsProxy1_1 getUploadedDocumentDetails(GetClaimDocumentRequest documentRequest, StringBuilder message);
    
}
