
  CREATE OR REPLACE  FUNCTION "JNS_PUBLISH_API"."PUBLISH_DECVALUE" ( encryptedvalue IN varchar2)

RETURN VARCHAR2
AS 
    RAW_DECRYPTED_STRING RAW(2000);
--    RAW_KEY_BYTES_32 RAW(32) := 'opl@pub#jns!#AES';
	RAW_KEY_BYTES_32 RAW(16) := '6F706C40707562236A6E732123414553';
    
    AES256 PLS_INTEGER := DBMS_CRYPTO.ENCRYPT_AES128+DBMS_CRYPTO.CHAIN_CBC+DBMS_CRYPTO.PAD_PKCS5;
BEGIN
    if encryptedvalue is null then
        return encryptedvalue;
    end if;
        RAW_DECRYPTED_STRING := DBMS_CRYPTO.DECRYPT 
        (
            SRC =>  UTL_ENCODE.base64_decode(UTL_RAW.CAST_TO_RAW(encryptedvalue)),
            TYP => AES256,
            KEY => RAW_KEY_BYTES_32
            ,iv => RAW_KEY_BYTES_32
        );
        RETURN UTL_I18N.RAW_TO_CHAR(RAW_DECRYPTED_STRING, 'AL32UTF8');
END ;


