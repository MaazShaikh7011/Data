package com.opl.jns.publishinsurance.api.utils;

public class MsgUtils {

	public interface INTENAL {
		public interface ENROLL {
			public static String APP_DATA_NOT_FOUND = "No data found by application Id";
			public static String APP_NOT_COMPLETED = "Application is not completed yet";
			public static String COI_GENERATE_ISSUE = "Error while generate COI";
			public static String SUCCESS = "Successfull created";
			public static String ERROR = "Application has encountered some error";
		}

		public interface CLAIM {
			public static String CLAIM_DATA_NOT_FOUND = "No data found by claim Id";
			public static String SUCCESS = "Successfull created";
			public static String ERROR = "Application has encountered some error";
		}
	}

}
