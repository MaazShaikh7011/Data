package com.opl.jns.publishinsurance.api;

public class PushPullException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PushPullException() {
		super();
	}

	public PushPullException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public PushPullException(String message, Throwable cause) {
		super(message, cause);
	}

	public PushPullException(String message) {
		super(message);
	}

	public PushPullException(Throwable cause) {
		super(cause);
	}

	
	
}
