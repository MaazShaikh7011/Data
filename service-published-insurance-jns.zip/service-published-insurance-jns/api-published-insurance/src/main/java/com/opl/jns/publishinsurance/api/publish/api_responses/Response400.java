package com.opl.jns.publishinsurance.api.publish.api_responses;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opl.jns.publishinsurance.api.utils.Constants;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class Response400 {

    @Schema(example = "It seems that request is not properly formed.")
    private String message;

    private Object data;

    @Schema(example = "400")
    private Integer status;

    @Schema(example = "false")
    private Boolean success;

    @NotNull
    @Schema(example = "token")
    private String token;

    @NotNull
    @JsonFormat(pattern = Constants.YYYY_MM_DD_HH_MM_SS)
    @ApiModelProperty(notes = "timeStamp", example = Constants.YYYY_MM_DD_HH_MM_SS, required = true)
    private LocalDateTime timeStamp;


}
