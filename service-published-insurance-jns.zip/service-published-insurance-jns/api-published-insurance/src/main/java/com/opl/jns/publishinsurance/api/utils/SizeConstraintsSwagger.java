package com.opl.jns.publishinsurance.api.utils;

public final class SizeConstraintsSwagger {
	SizeConstraintsSwagger(){
	}

	public static final String INTEGER_MAX_VALUE = Integer.MAX_VALUE + "";

	public static final String LONG_MAX_VALUE = Long.MAX_VALUE + "";

	public static final String DOUBLE_MAX_VALUE = Double.MAX_EXPONENT + "";

	public static final String STRING_MAX_VALUE = "255";

}