package com.opl.jns.publishinsurance.api.msme.publish.v1;

import com.fasterxml.jackson.databind.annotation.*;
import com.opl.jns.published.utils.common.*;
import io.swagger.v3.oas.annotations.media.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.*;
import java.time.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationMasterProxy implements Serializable {

	private static final long serialVersionUID = 1L;

	@Schema(description = """
			application reference\s
			id will be uniquie id\s
			for each\s
			proposal,which will\s
			be used to get all data\s
			and update data api\
			""")
	private Long applicationReferenceId;

	@Schema(description = "Refer schemeName for enum")
	private Integer schemeId;

	@Schema(maxLength = 100 ,description = """
			application code will\s
			be generated unique\s
			for each proposal
			Sample : ANS-EL-
			1354-689\
			""")
	private String applicationCode;

	@Schema(maxLength = 500 ,description = """
			1 - Central Sector Interest Subsidy,
			2 - Padho Pardesh,
			3 - Dr. Ambedkar Central Sector Scheme,
			4 - Pradhan Mantri Awas Yojana,
			5 - Prime Minister's Employment Generation Programme,
			6 - Agri Clinics And Agri Business Centers Scheme,
			7 - Agricultural Marketing Infrastructure,
			8 - Star Weaver Mudra Scheme,
			9 - Pradhan Mantri MUDRA Yojna,
			10 - Pradhan Mantri Street Vendor Aatmanirbhar Nidhi Scheme,
			11 - Deendayal Antyodaya Yojana - National Urban Livelihoods Mission,
			12 - Self Employment Scheme for Rehabilitation of Manual Scavengers,
			13 - Stand Up India Scheme,
			14 - Deendayal Antyodaya Yojana - National Rural Livelihoods Mission,
			15 - Agriculture Infrastructure Fund\
			""")
	private String schemeName;
	
	@Schema(description = "Refer applicationType for enum")
	private Integer applicationTypeId;
	
	@Schema(maxLength = 255 ,description = """
			1 - Approved,
			2 - Referred\
			""")
	private String applicationType;

	@Schema(maxLength = 255 ,description = "ifscCode")
	private String ifscCode;

	@Schema(name = "applicationDate",pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDateTime applicationDate;
}
