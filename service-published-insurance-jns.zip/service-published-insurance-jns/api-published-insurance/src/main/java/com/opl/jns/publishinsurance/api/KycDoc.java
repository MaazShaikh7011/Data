package com.opl.jns.publishinsurance.api;

public enum KycDoc {

    PAN(1l,"pan"),
    AADHAR(2l,"Aadhar"),
    PASSPORT(3l,"Passport"),
    DRIVING_LICENCE(3l,"Driving Licence"),
    MGNREGA_CARD(3l,"Mgnerega card"),
    VOTER_ID(3l,"Voter Id card") ;

    private final Long id;
    private final String name;

    private KycDoc(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }


    public String getName() {
        return name;
    }




    public static String getNameById(Long v) {
        for (KycDoc c : KycDoc.values()) {
            if (c.id.equals(v)) {
                return c.getName();
            }
        }
        return null;
    }

    public static KycDoc getById(Long v) {
        for (KycDoc c : KycDoc.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }
    public static KycDoc getByName(String v) {
        for (KycDoc c : KycDoc.values()) {
            if (c.name.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static KycDoc[] getAll() {
        return KycDoc.values();
    }

}
