package com.opl.jns.publishinsurance.api;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import java.io.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ClaimDtlRequest implements Serializable {

    private static final long serialVersionUID = 1111111L;
    @Schema(hidden = true)
    private Long applicationId;

    @Schema(required = true)
    private Long claimReferenceId;

    @Schema(hidden = true)
    private Integer schemeId;

}