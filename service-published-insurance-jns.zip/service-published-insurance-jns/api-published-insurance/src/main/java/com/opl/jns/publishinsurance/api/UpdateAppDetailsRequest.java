package com.opl.jns.publishinsurance.api;

import lombok.*;

/***
 * 
 * @author paresh.radadiya
 * @Date : 04/03/2023
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UpdateAppDetailsRequest {
	
	private static final long serialVersionUID = 1111111L;

	private Long applicationReferenceId;
	
	private Integer proposalStatusId;
}
