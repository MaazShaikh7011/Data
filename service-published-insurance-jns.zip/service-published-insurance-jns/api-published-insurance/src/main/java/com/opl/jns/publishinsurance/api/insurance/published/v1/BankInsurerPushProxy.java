package com.opl.jns.publishinsurance.api.insurance.published.v1;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class BankInsurerPushProxy implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer schemeId;
	private Long orgId;
	private Long userType;
	private String fromDate;
	private String toDate;
	private Integer type;
	private Boolean isSchedular;
}
