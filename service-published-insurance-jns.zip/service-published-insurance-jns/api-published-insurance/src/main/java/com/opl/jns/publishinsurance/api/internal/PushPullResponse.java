package com.opl.jns.publishinsurance.api.internal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PushPullResponse {

    private static final long serialVersionUID = 1L;

    private String message;

    private Object data;

    private Integer status;

    private Boolean flag;

    private Integer responseType;

    private String sysMessage;

    private Integer msgCode;

    private String success;

    public PushPullResponse(String message, Integer status) {
        super();
        this.message = message;
        this.status = status;
    }

    public PushPullResponse(String message, Object data, Integer status) {
        super();
        this.message = message;
        this.data = data;
        this.status = status;
    }

    public PushPullResponse(String message, Object data, Integer status, Boolean flag) {
        super();
        this.message = message;
        this.data = data;
        this.status = status;
        this.flag = flag;
    }

    public PushPullResponse(String message, Integer status, Boolean flag) {
        super();
        this.message = message;
        this.status = status;
        this.flag = flag;
    }
}
