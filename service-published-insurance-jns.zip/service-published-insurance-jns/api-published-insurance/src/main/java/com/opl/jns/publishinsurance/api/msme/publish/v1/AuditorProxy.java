package com.opl.jns.publishinsurance.api.msme.publish.v1;

import jakarta.persistence.MappedSuperclass;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.*;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
public class AuditorProxy implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3142509682235191538L;

	private Long createdBy;

	private Date createdDate;

	private Boolean isActive = true;

	private Date modifiedDate;

	public AuditorProxy(Long createdBy, Date createdDate, Boolean isActive) {
		super();
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.isActive = isActive;
	}
}
