package com.opl.jns.publishinsurance.api;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

import java.io.*;
import java.util.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(hidden = true)
    private Long applicationId;

    @Schema(required = true)
    private Long applicationReferenceId;

    @Schema(hidden = true)
    private Long coAppId;

    @Schema(hidden = true)
    private Long proposalId;
    
    @Schema(hidden = true)
    private String urnCode;

    @Schema(hidden = true)
    private Long schemeId;
    
    @Schema(hidden = true)
    private Long bankOrgId;
    
    @Schema(hidden = true)
    private Long insOrgId;
    
    @Schema(hidden = true)
    private Long branchId;
    
    @Schema(hidden = true)
    private Date completionDate;
    

}
