package com.opl.jns.publishinsurance.api.internal;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class PullPushRequest {

    private Long applicationId;
    
    private Long applicationReferenceId;

    private Long proposalId;

    private String applicationCode;
    
    private String urnCode;

    private String platformType;

    private Date createdDate;

    private Date modifiedDate;

    private Boolean isActive;

    private Long bankOrgId;

    private String pullStatus;

    private String pushStatus;

    private Long schemeId;

    private Boolean isOffline;

    private Long fpProductId;
    
    private Boolean isBankSpecific;
    
    private Long userId;
    
    private Integer stageId;
    


    public PullPushRequest(Long applicationId,Long proposalId,Long bankOrgId,String applicationCode,Boolean isOffline,Long fpProductId,Boolean isBankSpecific){
        this.applicationId = applicationId;
        this.proposalId = proposalId;
        this.bankOrgId = bankOrgId;
        this.applicationCode = applicationCode;
        this.isOffline = isOffline;
        this.fpProductId = fpProductId;
        this.isBankSpecific= isBankSpecific;
    }
}
