package com.opl.jns.publishinsurance.api.publish.api_responses;

import io.swagger.v3.oas.annotations.media.*;
import lombok.*;

@Data
@ToString
@NoArgsConstructor
public class Response401 {

//	@Schema(example = "Unauthorized Request")
//    private String message;
//
//    @Schema(example = "401")
//    private Integer status;
//
//    @Schema(example = "false")
//    private Boolean success;
//
//    @Schema(example = "false")
//    private Boolean flag;
}
