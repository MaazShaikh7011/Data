package com.opl.jns.publishinsurance.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author - Maaz Shaikh
 * @Date - 5/11/2023
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class EncRequest {
    String apiUserName;
    String apiKey;
    Long apiUserId;
    Object request;

    String metadata;

}
