package com.opl.jns.publishinsurance.api.msme.publish.v1;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.*;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class UploadedDocumentsDetailsProxy implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long applicationReferenceId;

	private List<DocumentDetailsProxy> documentList;

}
