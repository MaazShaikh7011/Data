package com.opl.jns.publishinsurance.api.msme.publish.v1;

import io.swagger.v3.oas.annotations.media.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode

public class DocumentDetailsProxy implements Serializable {

	private static final long serialVersionUID = 1L;

	@Schema(maxLength = 100)
    private String documentType;
	
	@Schema(maxLength = 30, description = "Applicant ,Co-Applicant")
    private String type;
	
    private byte[] document;
    
    @Schema(maxLength = 50, description = "pdf ,jpg ,jpeg ,png ,xlsx ,html ,doc")
    private String contentType;

}
