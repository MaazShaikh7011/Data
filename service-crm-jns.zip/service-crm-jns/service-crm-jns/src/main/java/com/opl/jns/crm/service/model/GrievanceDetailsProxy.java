package com.opl.jns.crm.service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GrievanceDetailsProxy {
    private Long id;
    private String urn;
    private Long orgId;
    private Long insurerId;
    private Integer schemeId;
    private Integer complType;
    private Integer complPredefined;
    private String complNo;
    private Date createdDate;
    private Long modifiedBy;
    private Date modifiedDate;
    private Integer status;
    private String branchId;
    private Long docStorageId;
    private Integer actionOwner;
    private String name;
    private String mobileNumber;
    private String accNo;
    private Date dob;
    private String cif;
    private Long claimNo;
    private String policyNo;
    private String complName;
    private String complEmail;
    private Integer complRelation;
    private Boolean isClaimReOpened;
    private Integer claimStatus;
    private Double approvedAmount;
    private String complDescription;
    private String resolvedRemarks;
    private String statusName;
    private String schemeName;
    private String bankName;
    private String branchName;
    private String insName;
}
