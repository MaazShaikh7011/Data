package com.opl.jns.crm.service.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opl.jns.crm.api.model.crm.email.req.ContentAttachment;
import com.opl.jns.crm.api.model.crm.email.req.EmailRequest;
import com.opl.jns.crm.api.model.crm.sms.req.SmsRequest;
import com.opl.jns.crm.service.service.CrmService;
import com.opl.jns.crm.service.utils.Validator;
import com.opl.jns.notification.api.model.Notification;
import com.opl.jns.notification.api.model.NotificationRequest;
import com.opl.jns.notification.api.model.NotificationResponse;
import com.opl.jns.notification.api.utils.ContentType;
import com.opl.jns.notification.api.utils.NotificationType;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author - Maaz Shaikh
 * @Date - 1/16/2024
 */
@Service
@Slf4j
public class CrmServiceImpl implements CrmService {

    @Autowired
    NotificationClient notificationClient;



    @Override
    public void sendSmsNotification(List<SmsRequest> request) {
        NotificationRequest notificationRequest = new NotificationRequest();
        Map<String,Object> param = null;
        for (SmsRequest sms: request ) {
            try {
                param = new HashMap<>();
                param = MultipleJSONObjectHelper.getMapFromString(MultipleJSONObjectHelper.getStringfromObject(sms.getParameters()));
            }catch (Exception e){
                log.error("Exception while parsing the parameters : ",e);
            }
            notificationRequest.addNotification(NotificationClient.prepareRequestForSmsOrEmail(new String[]{sms.getToMobile()}, param, sms.getTemplateId(), null, NotificationType.SMS));
        }
        NotificationResponse response = notificationClient.sendNotification(notificationRequest);
        List<String> toList = request.stream().map(SmsRequest::getToMobile).collect(Collectors.toList());
        if(!OPLUtils.isObjectNullOrEmpty(response)){
            log.error("==========> Email send status :: [{}] for toList {}", response.getStatus(),toList);
        }else{
            log.error("Notification response is null while sending Email for toIds {}",toList);
        }
    }


    public String  validateEmailNotification(List<EmailRequest> request) throws IOException {
        List<String> toIdsString = new ArrayList<>();
        for (EmailRequest email: request ) {
            String[] to =  email.getTo().toArray(new String[0]);
            for (String toId: to) {
                if(!Validator.validateEmail(toId)){
                    toIdsString.add(toId);
                }
            }
        }

        // check email size
        if(!toIdsString.isEmpty()){
            return  "Invalid email ids : " + MultipleJSONObjectHelper.getStringfromObject(toIdsString);
        }

        return null;
    }

    public String  validateMobileNotification(List<SmsRequest> request) throws IOException {
        List<String> toIdsString = new ArrayList<>();
        for (SmsRequest mobile: request ) {
            if(!Validator.validateMobile(mobile.getToMobile())){
                toIdsString.add(mobile.getToMobile());
            }
        }

        // check email size
        if(!toIdsString.isEmpty()){
            return  "Invalid mobile number : " + MultipleJSONObjectHelper.getStringfromObject(toIdsString);
        }

        return null;
    }

    @Override
    public void sendEmailNotification(List<EmailRequest> request) {
        NotificationRequest notificationRequest = new NotificationRequest();
        for (EmailRequest email: request ) {
            Notification notification = new Notification(null, ContentType.CONTENT, null, email.getTo().toArray(new String[0]), NotificationType.EMAIL, null);
            notification.setSubject(email.getSubject());
            notification.setContent(email.getContent());
            notification.setTo(email.getTo().toArray(new String[0]));
            notification.setCc(email.getCc().toArray(new String[0]));

            /*SET ATTACHMENT */
            if(!OPLUtils.isObjectNullOrEmpty(email.getContentAttachments()) && !email.getContentAttachments().isEmpty()){
                List<com.opl.jns.notification.api.model.emailNotification.ContentAttachment> attachementList = new ArrayList<>(email.getContentAttachments().size());
                for (ContentAttachment reqAttachment: email.getContentAttachments()) {
                	com.opl.jns.notification.api.model.emailNotification.ContentAttachment contentAttachment = new com.opl.jns.notification.api.model.emailNotification.ContentAttachment();
                    contentAttachment.setFileName(reqAttachment.getFileName());
                    contentAttachment.setContentInByte(reqAttachment.getContentInByte());
                    attachementList.add(contentAttachment);
                }
                notification.setContentAttachments(attachementList);
            }
            notificationRequest.addNotification(notification);
        }

        List<List<String>> toList = request.stream().map(EmailRequest::getTo).collect(Collectors.toList());
        NotificationResponse response = notificationClient.sendNotification(notificationRequest);
        if(!OPLUtils.isObjectNullOrEmpty(response)){
            log.info("==========> Email send status :: [{}] for toList {}", response.getStatus(),toList);
        }else{
            log.error("Notification response is null while sending Email for toIds {}",toList);
        }
    }


}
