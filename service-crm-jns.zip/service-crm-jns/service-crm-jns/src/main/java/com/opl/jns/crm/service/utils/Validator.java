package com.opl.jns.crm.service.utils;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
    private static final String EMAIL_REGEX = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
    private static final Pattern emailPattern = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
    private static final Pattern mobilePatter = Pattern.compile("^(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[6789]\\d{9}$");


    /**
     * @param email
     * @throws
     * @author: maaz.shaikh
     * @Details If email matched or this method return false that means email id is
     * incorrect.
     * @time : 5:11:33 PM - 24-Sep-2019
     */
    public static Boolean validateEmail(String email) {
        if (!email.isEmpty()) {
            Matcher matcher = emailPattern.matcher(email.replaceAll("\\s+", ""));
            return matcher.matches();
        } else {
            return false;
        }
    }


    public static Boolean validateMobile(String mobile) {
        Matcher m = mobilePatter.matcher(mobile);
        return (m.find() && m.group().equals(mobile));
    }
}
