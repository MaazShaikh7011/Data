package com.opl.jns.crm.service.boot;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.opl.jns.auth.client.AuthClient;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.config.utils.ApplicationProperties;
import com.opl.jns.notification.client.NotificationClient;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.config.URLConfig;
import com.opl.jns.utils.config.URLMaster;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@ComponentScan(basePackages = {"com.opl"})
@EnableConfigurationProperties(ApplicationProperties.class)
@Slf4j
public class ServiceCrmJnsApplication {

    @Autowired
    private ApplicationContext applicationContext;

    public static void main(String[] args) {
        SpringApplication.run(ServiceCrmJnsApplication.class, args);
    }

    @Bean
    public NotificationClient notificationClient() {
        NotificationClient notificationClient = new NotificationClient(URLConfig.fetchURL(URLMaster.NOTIFICATION));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(notificationClient);
        return notificationClient;
    }

    @Bean
    public UsersClient usersClient() {
        UsersClient usersClient = new UsersClient(URLConfig.fetchURL(URLMaster.USERS));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(usersClient);
        return usersClient;
    }

    @Bean
    public AuthClient authClient() {
        AuthClient authClient = new AuthClient(URLConfig.fetchURL(URLMaster.AUTH));
        applicationContext.getAutowireCapableBeanFactory().autowireBean(authClient);
        return authClient;
    }

    @Bean
    public BankApiClient bankClient() {
        BankApiClient bankClient = new BankApiClient(URLConfig.fetchURL(URLMaster.BANK_API));
//        BankApiClient bankClient = new BankApiClient("http://localhost:8053/consume");
        applicationContext.getAutowireCapableBeanFactory().autowireBean(bankClient);
        return bankClient;
    }

}
