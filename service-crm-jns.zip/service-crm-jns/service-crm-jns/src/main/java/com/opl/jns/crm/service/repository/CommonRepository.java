package com.opl.jns.crm.service.repository;

/**
 * @author ravi.thummar
 * Date : 09-04-2024
 */
public interface CommonRepository {
    String callProducerWithRequest(String request, Long userId, String spName);

    String callProducerWithRequestAndDate(String request, Long userId, String fromDate, String toDate, String spName);

//    String fetchMasterData(String listKey, String whereClause, String spName);

}
