package com.opl.jns.crm.service.service.impl;

import com.opl.jns.crm.api.enums.GrievanceStatus;
import com.opl.jns.crm.service.domain.GrievanceMaster;
import com.opl.jns.crm.service.domain.GrievancePiDetails;
import com.opl.jns.crm.service.domain.GrievanceRemarks;
import com.opl.jns.crm.service.model.GrievanceDetailsProxy;
import com.opl.jns.crm.service.model.UpdateStatusGrievanceProxy;
import com.opl.jns.crm.service.repository.CommonRepository;
import com.opl.jns.crm.service.repository.GrievanceMasterRepository;
import com.opl.jns.crm.service.repository.GrievancePiDetailsRepository;
import com.opl.jns.crm.service.repository.GrievanceRemarksRepository;
import com.opl.jns.crm.service.service.DashboardService;
import com.opl.jns.users.api.model.BranchBasicDetailsRequest;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.MultipleJSONObjectHelper;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author RaviThummar
 */
@Service
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private CommonRepository commonRepository;

    @Autowired
    private GrievanceMasterRepository grievanceMasterRepository;

    @Autowired
    private GrievancePiDetailsRepository grievancePiDetailsRepository;

    @Autowired
    private GrievanceRemarksRepository grievanceRemarksRepository;

    @Autowired
    private UsersClient usersClient;

    @Override
    public CommonResponse getGrievanceDashboardCount(String request, Long userId) {
        try {
            String grievanceDashboardCount = commonRepository.callProducerWithRequest(request, userId, "grievance_dashboard_count");
            if (!OPLUtils.isObjectNullOrEmpty(grievanceDashboardCount)) {
                Map<String, Object> mapFromString = MultipleJSONObjectHelper.getMapFromString(grievanceDashboardCount);
                return new CommonResponse(mapFromString, "successfully get data", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("error is getting while getGrievanceDashboardCount  ", e);
        }
        return CommonResponse.TECHNICAL_ERROR();
    }

    @Override
    public CommonResponse getGrievanceDashboardList(String request, Long userId) {
        try {
            String grievanceDashboardList = commonRepository.callProducerWithRequest(request, userId, "grievance_dashboard_list");
            if (!OPLUtils.isObjectNullOrEmpty(grievanceDashboardList)) {
                List<Map<String, Object>> list = MultipleJSONObjectHelper.getListOfObjects(grievanceDashboardList, null, Map.class);
                return new CommonResponse(list, "successfully get data", HttpStatus.OK.value());
            }
        } catch (Exception e) {
            log.error("error is getting while getGrievanceDashboardList  ", e);
        }
        return CommonResponse.TECHNICAL_ERROR();
    }

    @Override
    public CommonResponse getGrievanceDetails(Long id, Long userId) {
        try {
            GrievanceMaster grievanceMaster = grievanceMasterRepository.findById(id).orElse(null);
            if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
                return new CommonResponse(HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.value());
            }
            GrievanceDetailsProxy grievanceDetailsProxy = new GrievanceDetailsProxy();
            setGrievanceMaster(grievanceMaster, grievanceDetailsProxy);
            setGrievancePiDetails(grievancePiDetailsRepository.findById(id).orElse(null), grievanceDetailsProxy);
            setGrievanceRemarks(grievanceRemarksRepository.findById(id).orElse(null), grievanceDetailsProxy);
            grievanceDetailsProxy.setStatusName(GrievanceStatus.fromId(grievanceMaster.getStatus()).getDisplayName());
            grievanceDetailsProxy.setSchemeName(SchemeMaster.getById(grievanceMaster.getSchemeId().longValue()).getShortName());

            if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getOrgId())) {
                String orgName = usersClient.getOrganizationName(grievanceMaster.getOrgId());
                if (!OPLUtils.isObjectNullOrEmpty(orgName))
                    grievanceDetailsProxy.setBankName(orgName);
            }

            if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getBranchId())) {
                BranchBasicDetailsRequest branch = usersClient.getBranch(grievanceMaster.getBranchId());
                if (!OPLUtils.isObjectNullOrEmpty(branch))
                    grievanceDetailsProxy.setBranchName(branch.getName());
            }

            try {
                if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getInsurerId())) {
                    String insName = usersClient.getOrganizationName(grievanceMaster.getInsurerId());
                    if (!OPLUtils.isObjectNullOrEmpty(insName))
                        grievanceDetailsProxy.setInsName(insName);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return new CommonResponse(grievanceDetailsProxy, "successfully get data", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("error is getting while getGrievanceDetails  ", e);
        }
        return CommonResponse.TECHNICAL_ERROR();
    }

    @Override
    public CommonResponse grievanceUpdateStatus(UpdateStatusGrievanceProxy updateStatusGrievanceProxy, Long userId) {
        try {
            GrievanceMaster grievanceMaster = grievanceMasterRepository.findById(updateStatusGrievanceProxy.getId()).orElse(null);
            if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
                return new CommonResponse(HttpStatus.NO_CONTENT.getReasonPhrase(), HttpStatus.NO_CONTENT.value());
            }
            if (GrievanceStatus.CLOSED.getId() == updateStatusGrievanceProxy.getStatus()) {
                saveGrievanceRemarkDetails(updateStatusGrievanceProxy);
            }
            grievanceMaster.setModifiedBy(userId);
            grievanceMaster.setModifiedDate(new Date());
            grievanceMaster.setStatus(updateStatusGrievanceProxy.getStatus());
            grievanceMasterRepository.save(grievanceMaster);
            return new CommonResponse("successfully update status", "successfully update status", HttpStatus.OK.value());
        } catch (Exception e) {
            log.error("error is getting while grievanceUpdateStatus  ", e);
        }
        return CommonResponse.TECHNICAL_ERROR();
    }

    private void setGrievanceMaster(GrievanceMaster grievanceMaster, GrievanceDetailsProxy grievanceDetailsProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster))
            BeanUtils.copyProperties(grievanceMaster, grievanceDetailsProxy);
    }

    private void setGrievancePiDetails(GrievancePiDetails grievancePiDetails, GrievanceDetailsProxy grievanceDetailsProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(grievancePiDetails))
            BeanUtils.copyProperties(grievancePiDetails, grievanceDetailsProxy);
    }

    private void setGrievanceRemarks(GrievanceRemarks grievanceRemarks, GrievanceDetailsProxy grievanceDetailsProxy) {
        if (!OPLUtils.isObjectNullOrEmpty(grievanceRemarks))
            BeanUtils.copyProperties(grievanceRemarks, grievanceDetailsProxy);
    }

    private GrievanceRemarks saveGrievanceRemarkDetails(UpdateStatusGrievanceProxy updateStatusGrievanceProxy) {
        GrievanceRemarks grievanceRemarks = grievanceRemarksRepository.findById(updateStatusGrievanceProxy.getId()).orElse(null);
        if (OPLUtils.isObjectNullOrEmpty(grievanceRemarks)) {
            grievanceRemarks = new GrievanceRemarks();
            grievanceRemarks.setId(updateStatusGrievanceProxy.getId());
        }
        grievanceRemarks.setResolvedRemarks(updateStatusGrievanceProxy.getResolvedRemarks());
        grievanceRemarks.setIsClaimReOpened(updateStatusGrievanceProxy.getIsClaimReOpened());
        return grievanceRemarksRepository.save(grievanceRemarks);
    }
}
