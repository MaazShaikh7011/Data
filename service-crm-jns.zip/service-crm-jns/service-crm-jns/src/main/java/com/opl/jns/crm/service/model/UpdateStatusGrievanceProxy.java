package com.opl.jns.crm.service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateStatusGrievanceProxy {

    private Long id;
    private Integer status;
    private Boolean isClaimReOpened;
    private Integer claimStatus;
    private Double approvedAmount;
    private String resolvedRemarks;

}
