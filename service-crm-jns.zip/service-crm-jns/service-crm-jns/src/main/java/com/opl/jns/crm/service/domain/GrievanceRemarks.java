package com.opl.jns.crm.service.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "grievance_remarks")
public class GrievanceRemarks {

    @Id
    private Long id;

    @Column(name = "is_claim_re_opened", nullable = true)
    private Boolean isClaimReOpened;

    @Column(name = "claim_status", nullable = true)
    private Integer claimStatus;

    @Column(name = "approved_amount", nullable = true)
    private Double approvedAmount;

    @Column(name = "compl_description", nullable = true)
    private String complDescription;

    @Column(name = "resolved_remarks", nullable = true)
    private String resolvedRemarks;

}
