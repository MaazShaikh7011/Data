package com.opl.jns.crm.service.service;

import com.opl.jns.crm.api.model.grienvace.AccHolderListReq;
import com.opl.jns.crm.api.model.grienvace.GrienvanceBasicDetailsReq;
import com.opl.jns.crm.api.model.grienvace.GrienvanceFromDetailsReq;
import com.opl.jns.utils.common.CommonResponse;

/***
 * 
 * @author maulik.panchal Date : 09/04/2024
 */
public interface GrienvanceService {

	public CommonResponse saveGrienvaceDetails(GrienvanceBasicDetailsReq req);
	
	public CommonResponse saveGrienvaceFormDetails(GrienvanceFromDetailsReq req);

	public CommonResponse getGrienvaceFormDetails(Long applicationId, Long schemeId,Long grienvaceId);
	
	public CommonResponse getGrienvaceViewDetails(String complaintNo);
	
	public CommonResponse checkGrienvaceFoundOrNot(String complaintNo);
	
	public CommonResponse fetchAccountHolderListGrievance(AccHolderListReq accHolderListRequest);
}
