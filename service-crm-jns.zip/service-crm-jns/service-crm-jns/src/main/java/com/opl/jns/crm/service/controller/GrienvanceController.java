package com.opl.jns.crm.service.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.config.utils.SkipInterceptor;
import com.opl.jns.crm.api.model.grienvace.AccHolderListReq;
import com.opl.jns.crm.api.model.grienvace.GrienvanceBasicDetailsReq;
import com.opl.jns.crm.api.model.grienvace.GrienvanceFromDetailsReq;
import com.opl.jns.crm.service.service.GrienvanceService;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/grienvace")
@Slf4j
public class GrienvanceController {

	@Autowired
	GrienvanceService grienvanceService;

	/**
	 * 1.1 SAVE GRIENVACE BASIC DETAILS
	 *
	 * @param req
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/saveGrienvaceDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveGrienvaceDetails(@RequestBody GrienvanceBasicDetailsReq req) {
		try {
			log.info("Enter in saveGrienvaceDetails URN OR ACCOUNT NUMBER IS -----> " + req.getUrnOrAccNo());
			return new ResponseEntity<>(grienvanceService.saveGrienvaceDetails(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saveGrienvaceDetails ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * 2.1 SAVE GRIENVACE FORM DETAILS
	 *
	 * @param req
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/saveGrienvaceFormDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> saveGrienvaceFormDetails(@RequestBody GrienvanceFromDetailsReq req) {
		try {
			log.info("Enter in saveGrienvaceFormDetails ID IS -----> " + req.getId());
			return new ResponseEntity<>(grienvanceService.saveGrienvaceFormDetails(req), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saveGrienvaceFormDetails ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

	/**
	 * 2.2 GET GRIENVACE FORM DETAILS
	 *
	 * @param req
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/getGrienvaceFormDetails/{applicationId}/{grienvaceId}/{schemeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getGrienvaceFormDetails(@PathVariable Long applicationId,
			@PathVariable Long schemeId, @PathVariable Long grienvaceId) {
		try {
			log.info(
					"Enter in getGrienvaceFormDetails APPLICATIONID IS {} -------> SCHEME ID IS {} ------> GRIENVACE ID IS {} -----> ",
					applicationId, schemeId, grienvaceId);
			return new ResponseEntity<>(grienvanceService.getGrienvaceFormDetails(applicationId, schemeId, grienvaceId),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saveGrienvaceFormDetails ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * 3.2 GET GRIENVACE VIEW DETAILS BY COMPLAINT NO
	 *
	 * @param req
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/getGrienvaceViewDetails/{complaintNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> getGrienvaceFormDetails(@PathVariable String complaintNo) {
		try {
			log.info(
					"Enter in getGrienvaceViewDetails complaintNo IS {} -----> ",complaintNo);
			return new ResponseEntity<>(grienvanceService.getGrienvaceViewDetails(complaintNo),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while getGrienvaceViewDetails ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * 3.3 GRIENVACE DETAILS FOUND OR NOT CHECKING
	 *
	 * @param req
	 * @return
	 */
	@SkipInterceptor
	@GetMapping(value = "/checkGrienvaceFoundOrNot/{complaintNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> checkGrienvaceFoundOrNot(@PathVariable String complaintNo) {
		try {
			log.info(
					"Enter in checkGrienvaceFoundOrNot complaintNo IS {} -----> ",complaintNo);
			return new ResponseEntity<>(grienvanceService.checkGrienvaceFoundOrNot(complaintNo),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while checkGrienvaceFoundOrNot ------>", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}
	
	/**
	 * GET ACCOUNT HOLDER LIST
	 * 
	 * @param accHolderListRequest
	 * @return
	 */
	@SkipInterceptor
	@PostMapping(value = "/fetchAccountHolderListGrievance", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> fetchAccountHolderListGrievance(
			@Valid @RequestBody AccHolderListReq accHolderListRequest) {
		try {
			log.info("Enter in fetchAccountHolderListGrievance ACCOUNT NO OR URN IS {} -------> ",
					accHolderListRequest.getAccountValue());
			return new ResponseEntity<>(grienvanceService.fetchAccountHolderListGrievance(accHolderListRequest),
					HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while fetchAccountHolderListGrievance :", e);
			return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
		}
	}

}
