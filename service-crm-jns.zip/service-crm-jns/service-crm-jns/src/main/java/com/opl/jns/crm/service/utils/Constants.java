package com.opl.jns.crm.service.utils;

import java.time.Year;
import java.time.YearMonth;
import java.util.Random;

import com.opl.jns.utils.enums.SchemeMaster;

public class Constants {

    public static final String SMS_REQUEST_EXAMPLE = "[{\"toMobile\":\"919904396875\",\"templateId\":4190,\"parameters\":{\"otp\":\"23451\"}},{\"toMobile\":\"919624980425\",\"templateId\":4191,\"parameters\":{\"otp\":\"23451\"}}]";
    public static final String SMS_RESPONSE_SUCCESS = "{\"message\":\"Success\",\"data\":[{\"toMobile\":\"919904396875\",\"templateId\":4190,\"remarks\":\"Notification send.\",\"status\":\"success\"},{\"toMobile\":\"919624980425\",\"templateId\":4191,\"remarks\":\"Notification send.\",\"status\":\"Fail\"}],\"status\":200,\"success\":true}";
    public static final String EMAIL_REQUEST_EXAMPLE = "[{\"to\":[\"test@onlinepsbloans.com\"],\"cc\":[\"test@onlinepsbloans.com\"],\"subject\":\"Email Subject\",\"content\":\"Email content Body\",\"templateId\":4192,\"contentAttachments\":[{\"fileName\":\"demo.jpg\",\"contentInByte\":\"lklKfdsjkfsdlfkjskdfkslflsjflskjfklsf21\"}]}]";
    public static final String EMAIL_RESPONSE_SUCCESS = "{\"message\":\"Success\",\"data\":{\"remarks\":\"Notification send.\"},\"status\":200,\"success\":true}";

    public static final String ENCRYPTED_RESPONSE_LBL = "Encrypted response";
    public static final String PLAIN_RESPONSE_400 = "{\"message\":\"It seems that request is not properly formed.\",\"status\":400}";
    public static final String PLAIN_RESPONSE_401 = "{\"message\":\"Unauthorized Request\",\"status\":401,\"success\":false,\"flag\":false}";

    public static final String PLAIN_REQUEST_LBL = "Plain Request";
    public static final String PLAIN_RESPONSE_LBL = "Plain Response";
    public static final String REQUEST_EXAMPLES_DESC = "Request examples";
    public static final String DATE_FORMAT_DESCRIPTION = "<u>Date Format should be <b>dd/MM/yyyy</b>";
    public static final String ENCRYPTED_REQUEST_LBL = "Encrypted Request";

    public static final String ENCRYPTED_REQUEST_EXAMPLE = "{\n \"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0QmlpMDlLVGtFdDVpZTZURTl3MnkrK0k1TTEwTHRhNGVYZ3hYSkJRT0pRL1kzSk1jTGNsZGVFcCtJQldvbVVLZUFhZnJCTmV5b1lCTk5qcWQ0aWwxUDE4dkl1R1Z4RkIwenlqRUIwUHVIZjN1UDFmWmxDK3lZZGgzQjBIelpqWmx4SDIrYVBqVW16SmZFZ1BqVFcrY29vNWh2N2YzNWJrMzhOaHNMMzBwTlMvRmJOTjc0OU56U29ORVZDVHpRUGpYVUp6S0dMZFFnbUczNmdlODczTit6SVNsZUJkaFlOVkVHaXZkeTVHNm5xZjhQdzV6ZVRKWEFFWlBpRVQ4aXRCRXRhNmFqTjQ1bmxZZzh1ZUtMcFNvMzZJLzJWckRHcCsycHVkcUNrY09PUjErWm1XVWZ6MDI3UURnWlc1bjhoUy9DN001eXNrRGR6OGplMG90L0FUeTZVRjNSN0Z0aHluVS9nZ0VOL0tFdlM3a0tDeG9WTEMxTkVPVkY5aTNOQWZkZHZSdmhGQjQ9OlRPdUM3QUZxOEliMHJSNDRnMkFlMVpqdVlzbjNsYjhUVzNxeCtqRVZZMFM0T1dYRks0WEtsRzNTR0gzbVZtMFRiWjFHc3BWbDlYVzQ0QlM1Q0FqUjh5eVJ2bXBMNytGZU0rZUxYVHJ3RHdjVzgvRXNWclJoUUdHQlR1U2R5cWphY21FMFUrNXRqQ1QzY09uZjYyTENpNmpvK0ZwaElteWQ2S3RUV3RvbGZIU1dHR2I4dFJ0c3NmMUFXa0tDb0R0aHh0U0k0bHpkMlpiOFQvSzlrbmhwQkFGUU0yUlJIR3oxYUtjZnFsNEt3S0F2WUttUno4Y1VyOGtOOXUzaGFieFVsZUVVOVViL3VRTkcvY2p2T2l2MDVtZ29tNkh4S3Q1bG8vVlBxVE9kZUpxcy80Q1NuRWQxUXdScGxSUXJVbllxT2lycGw4MmFoWVFGVVpTdkJ3UkJGU1ViSE5RdXdPamdyMXdkaVV5V2ZkM0p3VURsNy90Z2hBMU5xNFFZalVIekpob3hMV2tlQ2YrbzNEMzV5YlZYcUhSaE83YjMxbHN1N1czU3NPS3F3YTAvbm9SYUZyWWZyaEluL3JBcHpuTnlCZ0lBR1pueGlNTnM3TXgwUDYwdWhIa1l0cHpUUVBqR0k2S1hBRmQrWkoydVZBTFc4NHRuVXZGdWhsQ09ZNGpUZTBabUZjMy9sc1F2UVNFK3JIRS9EK2MvNGFRcXd3MWNEYzhLbVFRdm53MEZ0Kzc0c1Z5d3hiYUlJbHV1aDVBdEpjK2IzOGR\"\n}";
    public static final String ENCRYPTED_RESPONSE = "{\n\"metadata\": \"YytjVzZYc0RwNHc5M0pEYitlckdNb0hRTnRkYWVNYzFTRXRhMGV3c1psdVNUUWIwS3BmaU4wejZ3MSs0RjFXRjl1K0JOYXhNWitSVlVMTEhrcGJsR29TWm9WZUFDMUJUaGdZV0o0Um9NajllNGk4ZElWeStLOVBna1l4K0NidFp0QWhCdFlSTXpZbGN0Q0ZaS2tGNUVEOElpVEl3R0QzRm9vMDd3U1kwNzAvNkc1QVdGSG9HWnFVcmhIRVhnUWx3Z0xnT2JrVGVRdTFJdVI0enkxVFk5SkdHZEU3bVZqWnZ6elhqamlVQlRtaHFsclA0K1VEKyt3dWg5czNQUnptRkRTSWorVmZ4c29oaFlueUEyTmhMTXR4Y3k2TmhQSVlBY2l0Qmlp\"\n}";

    public static final String COMMON_DATA_MESSAGE = """
            In Response of API, HTTP status code 200 can be possible in below scenarios for which code will be set in key status :
            1. 200 - Success
            2. 500 - Internal Server Error
            3. 400 - Parameter Missing in Request (Bad Request)
            4. 400 - Invalid Application Reference Id  (Bad Request)\
            """;
    public static final String COMMON_NOT_ENCRYPTED_MESSAGE = "When encrypted request is not correctly formed";
    public static final String COMMON_UNAUTHORIZED_MESSAGE = "Unauthorised request";
    public static final String SMS_API_DESC = "This API is used to send SMS notification to Single/List of client’s mobile number by passing field values in request like mobile number, templateId and parameters";

    public static final String STR_1 = "1";
    public static final String STR_2 = "2";
	public static final String JS_GR = "JS-GR";
	public static final String CHAR_DASH = "-";
	public static final String BNK = "BNK";
	public static final String INS = "INS";

    public static final String SEND_EMAIL = "This API is used to send Email notification to Single/List of client’s email id by passing field values in request like email id, subject and content";

    public static final String SMS_ERROR_DETAILS = """
            
            
            Sms error code:
            
            1. 400  - Invalid Request
            4. 500  - Internal server error while sending OTP
            """;


    public static final String EMAIL_ERROR_DETAILS = """
            
            
            Email error code:
            
            1. 400  - Invalid Request
            4. 500  - Internal server error while sending OTP
            """;
    public static final Random rand = new Random();
    
    public static String getPolicyYearToYear() {
		int month=(YearMonth.now().getMonthValue());
		int current =Year.now().getValue();
		int nextYear=current;
		if(month > 5) {
			nextYear = current + 1;
		}else {
			current =current - 1;
		}
		return (current%100)+""+(nextYear%100);
	}

	/**
	 * GENERATE COMPLAINT NUMBER LOGIC
	 *
	 * @param schemeId
	 * @param grienvanceId
	 * @return
	 */
	public static String generateComplaintNo(Integer schemeId, Long grienvanceId,Integer type) {
		if (null == grienvanceId || null == schemeId) {
			return null;
		}
		return JS_GR.concat(CHAR_DASH)
				.concat(SchemeMaster.getById(schemeId.longValue()).getShortName().toUpperCase())
				.concat(CHAR_DASH).concat(type == 2 ? INS : BNK)
				.concat(CHAR_DASH).concat(getPolicyYearToYear()).concat(CHAR_DASH).concat("%08d".formatted(grienvanceId));
	}
	
//	public static void main(String[] args) {
//		System.out.println(generateComplaintNo(2,1l));
//	}

}