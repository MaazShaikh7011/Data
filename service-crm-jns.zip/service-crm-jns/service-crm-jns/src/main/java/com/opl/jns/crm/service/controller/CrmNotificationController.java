package com.opl.jns.crm.service.controller;

import com.opl.jns.crm.api.model.crm.*;
import com.opl.jns.crm.api.model.crm.email.req.*;
import com.opl.jns.crm.api.model.crm.sms.req.*;
import com.opl.jns.crm.api.model.crm.sms.res.*;
import com.opl.jns.crm.service.service.*;
import com.opl.jns.crm.service.utils.*;
import com.opl.jns.utils.common.*;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.*;
import jakarta.validation.*;
import java.util.*;

@RestController
@RequestMapping("/api/en/crm")
@Slf4j
@Validated
@Tag(name = "CRM Notification API Kit", description = "The API starter kit document should be read first and serves as reference for APIs integration.")
public class CrmNotificationController {

    @Autowired
    CrmService service;


    @PostMapping(value = "/sendNotification")
    @Operation(
            operationId = Constants.STR_1,
            summary = Constants.SMS_API_DESC, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC,
            content = @Content(examples = {
                    @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.SMS_REQUEST_EXAMPLE),
                    @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),})),
            responses = {
                    @ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
                            + Constants.SMS_ERROR_DETAILS, content = {
                            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = SmsResponseProxy.class), examples = {
                                    @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.SMS_RESPONSE_SUCCESS),
                                    @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)})}),
                    @ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
                            @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
                                    @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
                                    @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)}

                            )}),
                    @ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
                            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
                            )})

            })
    public ResponseEntity<SmsResponseProxy> sendSms(@Valid @RequestBody List<SmsRequest> smsReq, HttpServletRequest httpServletRequest, BindingResult result) {
        try {
            String errorMsg = service.validateMobileNotification(smsReq);
            if(!OPLUtils.isObjectNullOrEmptyOrDash(errorMsg)){
                return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.BAD_REQUEST.value(), errorMsg, false),HttpStatus.OK);
            }
            service.sendSmsNotification(smsReq);
            return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.OK.value(), "Notification sent", true), HttpStatus.OK);
        }catch (Exception e){
            log.error("Exception in sendSms : ",e);
            return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Something went wrong", false), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/sendEmailNotification")
    @Operation(
            operationId = Constants.STR_2,
            summary = Constants.SEND_EMAIL, requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(description = Constants.REQUEST_EXAMPLES_DESC, content = @Content(examples = {
            @ExampleObject(name = Constants.PLAIN_REQUEST_LBL, value = Constants.EMAIL_REQUEST_EXAMPLE, description = Constants.DATE_FORMAT_DESCRIPTION),
            @ExampleObject(name = Constants.ENCRYPTED_REQUEST_LBL, value = Constants.ENCRYPTED_REQUEST_EXAMPLE),})), responses = {
            @ApiResponse(responseCode = "200", description = Constants.COMMON_DATA_MESSAGE
                    + Constants.EMAIL_ERROR_DETAILS, content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = SmsResponseProxy.class), examples = {
                            @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.EMAIL_RESPONSE_SUCCESS),
                            @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)})}),
            @ApiResponse(responseCode = "400", description = Constants.COMMON_NOT_ENCRYPTED_MESSAGE, content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Response400.class), examples = {
                            @ExampleObject(name = Constants.PLAIN_RESPONSE_LBL, value = Constants.PLAIN_RESPONSE_400),
                            @ExampleObject(name = Constants.ENCRYPTED_RESPONSE_LBL, value = Constants.ENCRYPTED_RESPONSE)}

                    )}),
            @ApiResponse(responseCode = "401", description = Constants.COMMON_UNAUTHORIZED_MESSAGE,
                    content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Response401.class)
                    )})})
    public ResponseEntity<SmsResponseProxy> sendEMail(@Valid @RequestBody  List<EmailRequest> emailRequests, HttpServletRequest httpServletRequest) {
        try {
            String errorMsg = service.validateEmailNotification(emailRequests);
            if(!OPLUtils.isObjectNullOrEmptyOrDash(errorMsg)){
                return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.BAD_REQUEST.value(), errorMsg, false),HttpStatus.OK);
            }

            service.sendEmailNotification(emailRequests);
            return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.OK.value(), "Notification sent", true),HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(new SmsResponseProxy(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Something went wrong", false),HttpStatus.OK);
        }
    }


}
