package com.opl.jns.crm.service.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListRequest;
import com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccHolderListResponse;
import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.bank.client.BankApiClient;
import com.opl.jns.crm.api.enums.GrievancePredefinedComplaints;
import com.opl.jns.crm.api.enums.GrievanceStatus;
import com.opl.jns.crm.api.model.grienvace.AccHolderListReq;
import com.opl.jns.crm.api.model.grienvace.AccountHolderDetailsProxy;
import com.opl.jns.crm.api.model.grienvace.GrienvanceBasicDetailsReq;
import com.opl.jns.crm.api.model.grienvace.GrienvanceDocProxy;
import com.opl.jns.crm.api.model.grienvace.GrienvanceFromDetailsProxy;
import com.opl.jns.crm.api.model.grienvace.GrienvanceFromDetailsReq;
import com.opl.jns.crm.service.domain.GrievanceMaster;
import com.opl.jns.crm.service.domain.GrievancePiDetails;
import com.opl.jns.crm.service.domain.GrievanceRemarks;
import com.opl.jns.crm.service.repository.GrievanceMasterRepository;
import com.opl.jns.crm.service.repository.GrievancePiDetailsRepository;
import com.opl.jns.crm.service.repository.GrievanceRemarksRepository;
import com.opl.jns.crm.service.repository.ProductStorageRepository;
import com.opl.jns.crm.service.service.GrienvanceService;
import com.opl.jns.crm.service.utils.Constants;
import com.opl.jns.ere.domain.ClmMaster;
import com.opl.jns.ere.repo.ApplicationMasterRepositoryV3;
import com.opl.jns.ere.repo.ClmMasterRepository;
import com.opl.jns.ere.service.EreCommonService;
import com.opl.jns.ere.utils.ApplicationMasterBothSchemeProxy;
import com.opl.jns.users.client.UsersClient;
import com.opl.jns.utils.common.CommonErrorMsg;
import com.opl.jns.utils.common.CommonResponse;
import com.opl.jns.utils.common.OPLUtils;
import com.opl.jns.utils.enums.SchemeMaster;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;

/***
 * 
 * @author maulik.panchal Date : 09/04/2024
 */

@Service
@Slf4j
public class GrievanceServiceImpl implements GrienvanceService {

	@Autowired
	private GrievanceMasterRepository grievanceMasterRepository;

	@Autowired
	private GrievancePiDetailsRepository grievancePiDetailsRepository;

	@Autowired
	private GrievanceRemarksRepository grievanceRemarksRepository;

	@Autowired
	private EreCommonService ereCommonService;

	@Autowired
	private UsersClient usersClient;

	@Autowired
	private ProductStorageRepository productStorageRepository;

	@Autowired
	private ApplicationMasterRepositoryV3 applicationMasterRepo;

	@Autowired
	private BankApiClient bankApiClient;

	@Autowired
	private static Validator validator;
	
	@Autowired
	private ClmMasterRepository clmMasterRepository;

	public static final List<String> DUMMY_ACC_NO = Arrays.asList("90161910780000001", "90161910780000002",
			"90161910780000003", "90161910780000004", "90161910780000005", "90161910780000006", "90161910780000007",
			"90161910780000008", "90161910780000009", "90161910780000010","JNS-PMJJBY-23-24-00000000001-123","JNS-PMSBY-23-24-00000000002-123");

	@Override
	public CommonResponse saveGrienvaceDetails(GrienvanceBasicDetailsReq req) {
		GrievanceMaster grievanceMaster = null;
		AccHolderListResponse accHolderList = null;
		try {
			log.info("START saveGrienvaceDetails URN OR ACCOUNT NUMBER IS -----> " + req.getUrnOrAccNo());
			grievanceMaster = new GrievanceMaster();
			grievanceMaster.setStatus(GrievanceStatus.GRIEVANCE_INITIATED.getId());
			grievanceMaster.setSchemeId(req.getSchemeId());
			grievanceMaster.setOrgId(req.getOrgId());
			if (req.getUrnOrAccNo().contains("-")) {
				grievanceMaster.setUrn(req.getUrnOrAccNo());
			}
			grievanceMaster.setCreatedDate(new Date());
			grievanceMasterRepository.save(grievanceMaster);
			
			GrievancePiDetails grievancePiDetails = new GrievancePiDetails();
			grievancePiDetails.setId(grievanceMaster.getId());
			if (!req.getUrnOrAccNo().contains("-")) {
				grievancePiDetails.setAccNo(req.getUrnOrAccNo());
			}
			grievancePiDetails.setMobileNumber(req.getMobileNumber());
			grievancePiDetails.setComplName(req.getName());
			grievancePiDetails.setDob(req.getDobDateFormat());
			grievancePiDetailsRepository.save(grievancePiDetails);
			log.info("END saveGrienvaceDetails URN OR ACCOUNT NUMBER IS -----> " + req.getUrnOrAccNo());
			
			/**CHECK URN AND MOBILE NUMBER COMBINATION VALIDATION*/
			if (!OPLUtils.isNumeric(req.getAccountValue())) {
				List<Long> piDetails = grievancePiDetailsRepository.findByMobileNoAndUrnAndStatus(req.getMobileNumber(),req.getUrnOrAccNo(), GrievanceStatus.GRIEVANCE_REGISTERED.getId());
				if (!OPLUtils.isListNullOrEmpty(piDetails)) {
					return new CommonResponse("This mobile number grievance complaint already under process.",
							HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
				}
			}
			
			try {
				AccHolderListRequest accHolderListRequest = new AccHolderListRequest();
				if (!OPLUtils.isObjectNullOrEmpty(req.getAccountValue())) {
					if (OPLUtils.isNumeric(req.getAccountValue())) {
						accHolderListRequest.setAccountNumber(req.getAccountValue());
					} else {
						accHolderListRequest.setUrn(req.getAccountValue());
					}
					BeanUtils.copyProperties(req, accHolderListRequest);
				}
				try {
					AuthClientResponse authClientResponse = new AuthClientResponse();
					if (DUMMY_ACC_NO.contains(req.getAccountValue())) {
						authClientResponse.setUserId(22l);
					}
					accHolderList = bankApiClient.getAccHolderList(accHolderListRequest, authClientResponse);
				} catch (Exception e) {
					log.error("Exception while GET ACCOUNT HOLDER LIST -----> ", e);
					return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
							HttpStatus.INTERNAL_SERVER_ERROR.value());
				}

				if (!OPLUtils.isObjectNullOrEmpty(accHolderList) && !OPLUtils.isObjectNullOrEmpty(accHolderList.getStatus())
						&& accHolderList.getStatus() == HttpStatus.OK.value()
						&& accHolderList.getSuccess().equals(Boolean.TRUE)) {

					StringBuilder validateResponse = validateResponse(accHolderList);
					if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
						return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(),
								Boolean.FALSE);
					}

					List<AccountHolderDetailsProxy> holderDetailsLst = new ArrayList<>();
					List<com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccountHolderDetails> accountHolderDetails = accHolderList
							.getAccountHolderList().stream()
							.filter(a -> SchemeMaster.getByCode(a.getScheme()).getId() == req.getSchemeId().longValue())
							.collect(Collectors.toList());
					for (com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccountHolderDetails detailsProxy : accountHolderDetails) {
						/**CHECK URN AND MOBILE NUMBER COMBINATION VALIDATION*/
						List<Long> piDetails = grievancePiDetailsRepository.findByMobileNoAndUrnAndStatus(req.getMobileNumber(),detailsProxy.getUrn(), GrievanceStatus.GRIEVANCE_REGISTERED.getId());
						if (!OPLUtils.isListNullOrEmpty(piDetails)) {
							return new CommonResponse("This mobile number grievance complaint already under process.",
									HttpStatus.BAD_REQUEST.value(), Boolean.FALSE);
						}
						AccountHolderDetailsProxy holderDetailsProxy = new AccountHolderDetailsProxy();
						BeanUtils.copyProperties(detailsProxy, holderDetailsProxy);
						holderDetailsProxy.setApplicationId(
								applicationMasterRepo.findFirstByUrnAndIsActiveTrue(detailsProxy.getUrn()).getId());
						holderDetailsLst.add(holderDetailsProxy);
					}

					if (OPLUtils.isListNullOrEmpty(holderDetailsLst)) {
						return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
								HttpStatus.INTERNAL_SERVER_ERROR.value());
					}
					CommonResponse commonResponse = new CommonResponse();
					commonResponse.setId(grievanceMaster.getId());
					commonResponse.setFlag(Boolean.TRUE);
					commonResponse.setStatus(HttpStatus.OK.value());
					commonResponse.setData(holderDetailsLst);
					commonResponse.setMessage(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA);
					return commonResponse;
				}
			} catch (Exception e) {
				log.error("Exception is getting While Get account holder details ", e);
			}
			
		} catch (Exception e) {
			log.error("Exception while saveGrienvaceDetails -----> ", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
		return new CommonResponse(
				!OPLUtils.isObjectNullOrEmpty(accHolderList) ? accHolderList.getMessage()
						: CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}

	@Override
	public CommonResponse saveGrienvaceFormDetails(GrienvanceFromDetailsReq req) {
		GrievanceMaster grievanceMaster=null;
		try {
			log.info("START saveGrienvaceFormDetails ID IS -----> " + req.getId());
			grievanceMaster = grievanceMasterRepository.findById(req.getId()).orElse(null);

			if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
				log.info("GRIENVANCE MASTER DETAILS NOT FOUND ID IS -----> " + req.getId());
				return new CommonResponse("Grievance master details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}

			if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
				grievanceMaster.setComplPredefined(req.getComplPredefined());
				if (!OPLUtils.isObjectNullOrEmpty(req.getComplPredefined())) {
					GrievancePredefinedComplaints predefinedCmt = GrievancePredefinedComplaints
							.fromId(req.getComplPredefined());
					if (!OPLUtils.isObjectNullOrEmpty(predefinedCmt)) {
						grievanceMaster.setActionOwner(predefinedCmt.getType());
						grievanceMaster.setComplNo(Constants.generateComplaintNo(req.getSchemeId(),grievanceMaster.getId(),predefinedCmt.getType()));
					}
				}
				grievanceMaster.setStatus(GrievanceStatus.GRIEVANCE_REGISTERED.getId());
				grievanceMaster.setComplType(req.getComplType());
				grievanceMaster.setDocStorageId(req.getDocStorageId());
				grievanceMaster.setInsurerId(req.getInsurerOrgId());
				grievanceMaster.setUrn(req.getUrn());
				grievanceMaster.setSchemeId(req.getSchemeId());
				grievanceMaster.setBranchId(req.getBranchId());
				grievanceMasterRepository.save(grievanceMaster);
			}

			GrievancePiDetails grievancePiDetails = grievancePiDetailsRepository.findById(req.getId()).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(grievancePiDetails)) {
				log.info("GRIENVANCE PI DETAILS NOT FOUND ID IS -----> " + req.getId());
				return new CommonResponse("Grievance PI details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
				grievancePiDetails.setComplEmail(req.getComplEmail());
				grievancePiDetails.setComplName(req.getComplName());
				grievancePiDetails.setName(req.getName());
				grievancePiDetails.setClaimNo(req.getClaimId());
				grievancePiDetails.setCif(req.getCif());
				grievancePiDetails.setComplRelation(req.getComplRelation());
				grievancePiDetailsRepository.save(grievancePiDetails);

			GrievanceRemarks grievanceRemarks = new GrievanceRemarks();
			grievanceRemarks.setId(grievanceMaster.getId());
			grievanceRemarks.setComplDescription(req.getComplDesc());
			grievanceRemarksRepository.save(grievanceRemarks);

			log.info("END saveGrienvaceFormDetails ID IS -----> " + req.getId());

		} catch (Exception e) {
			log.error("Exception while saveGrienvaceFormDetails -----> ", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
		return new CommonResponse(CommonErrorMsg.Enrollment.SUCCESS,grievanceMaster.getComplNo(), HttpStatus.OK.value(), Boolean.TRUE);
	}

	@Override
	public CommonResponse getGrienvaceFormDetails(Long applicationId, Long schemeId, Long grienvaceId) {

		try {
			log.info(
					"START in getGrienvaceFormDetails APPLICATIONID IS {} -------> SCHEME ID IS {} ------> GRIENVACE ID IS {} -----> ",
					applicationId, schemeId, grienvaceId);

			GrienvanceFromDetailsProxy fromDetailsProxy = new GrienvanceFromDetailsProxy();
			ApplicationMasterBothSchemeProxy applicationMaster = ereCommonService
					.getJnsMasterDataApplicationMaster(schemeId, applicationId);
			if (OPLUtils.isObjectNullOrEmpty(applicationMaster)) {
				log.info("APPLICATION MASTER DETAILS NOT FOUND APPLICATIONID IS {} -------> SCHEME ID IS {} -----> ",
						applicationId, schemeId);
				return new CommonResponse("Application master details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			fromDetailsProxy.setSchemeName(SchemeMaster.getById(schemeId).getShortName());
			fromDetailsProxy.setSchemeId(schemeId);
			fromDetailsProxy.setOrgId(applicationMaster.getOrgId());
			fromDetailsProxy.setInsurerOrgId(applicationMaster.getInsurerOrgId());
			fromDetailsProxy.setBranchId(applicationMaster.getBranchId());
			
			ClmMaster clmMaster = clmMasterRepository.findFirstByApplicationIdAndIsActiveTrueOrderByIdDesc(applicationId);
			if(!OPLUtils.isObjectNullOrEmpty(clmMaster)) {
				fromDetailsProxy.setClaimNo(clmMaster.getId());
			}

			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getOrgId())) {
				String orgResponse = usersClient.getOrganizationName(applicationMaster.getOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
					fromDetailsProxy.setBankName(orgResponse);
				}
			}

			if (!OPLUtils.isObjectNullOrEmpty(applicationMaster.getInsurerOrgId())) {
				String orgResponse = usersClient.getOrganizationName(applicationMaster.getInsurerOrgId());
				if (!OPLUtils.isObjectNullOrEmpty(orgResponse)) {
					fromDetailsProxy.setInsurerName(orgResponse);
				}
			}
			GrievanceMaster grievanceMaster = grievanceMasterRepository.findById(grienvaceId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
				log.info("GRIENVANCE MASTER DETAILS NOT FOUND ID IS -----> " + grienvaceId);
				return new CommonResponse("Grievance master details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			fromDetailsProxy.setComplNo(grievanceMaster.getComplNo());
			fromDetailsProxy.setUrn(grievanceMaster.getUrn());
			fromDetailsProxy.setComplType(grievanceMaster.getComplType());
			fromDetailsProxy.setComplPredefined(grievanceMaster.getComplPredefined());
			fromDetailsProxy.setDocStorageId(grievanceMaster.getDocStorageId());

			if (!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getDocStorageId())) {
				fromDetailsProxy = setDocumentData(grievanceMaster.getDocStorageId(), fromDetailsProxy);
			}
			
			GrievancePiDetails grievancePiDetails = grievancePiDetailsRepository.findById(grienvaceId).orElse(null);
			if (OPLUtils.isObjectNullOrEmpty(grievancePiDetails)) {
				log.info("GRIENVANCE PI DETAILS NOT FOUND ID IS -----> " + grienvaceId);
				return new CommonResponse("Grievance PI details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			fromDetailsProxy.setComplName(grievancePiDetails.getComplName());
			fromDetailsProxy.setComplEmail(grievancePiDetails.getComplEmail());
			fromDetailsProxy.setComplRelation(grievancePiDetails.getComplRelation());
			fromDetailsProxy.setComplMobileNo(grievancePiDetails.getMobileNumber());

			GrievanceRemarks grievanceRemarks = grievanceRemarksRepository.findById(grienvaceId).orElse(null);
			if (!OPLUtils.isObjectNullOrEmpty(grievanceRemarks)) {
				fromDetailsProxy.setComplDesc(grievanceRemarks.getComplDescription());
			}
			log.info(
					"END in getGrienvaceFormDetails APPLICATIONID IS {} -------> SCHEME ID IS {} ------> GRIENVACE ID IS {} -----> ",
					applicationId, schemeId, grienvaceId);
			return new CommonResponse(CommonErrorMsg.Common.SUCCESS, fromDetailsProxy, HttpStatus.OK.value(),
					Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception while getGrienvaceFormDetails -----> ", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	private GrienvanceFromDetailsProxy setDocumentData(String storageIdStr, GrienvanceFromDetailsProxy fromDetailsProxy) {
		String[] split = storageIdStr.split(",");
		 Long[] longArray = Arrays.stream(split).map(Long::valueOf).toArray(Long[]::new);
		 List<Long> storageIdList = new ArrayList<>(Arrays.asList(longArray));
		 List<GrienvanceDocProxy> docLst = new ArrayList<>();
		 
		for(Long storageId : storageIdList) {			
			GrienvanceDocProxy docProxy = new GrienvanceDocProxy();
			productStorageRepository.findById(storageId).ifPresent(productStorage -> {
				docProxy
				.setDocName(!OPLUtils.isObjectNullOrEmpty(productStorage.getDocName()) ? productStorage.getDocName()
						: "grievance");
				docProxy.setContentType(productStorage.getOriginalFileName()
						.substring(productStorage.getOriginalFileName().lastIndexOf(".")));
				docProxy.setOriginalDocName(productStorage.getOriginalFileName());
				docProxy.setStorageId(storageId);
			});
			docLst.add(docProxy);
		}
		fromDetailsProxy.setDocProxy(docLst);
		return fromDetailsProxy;
	}

	/** common method for response JAVAX validation */
	public static <T> StringBuilder validateResponse(T object) throws ValidationException {
		validator = Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<T>> violations = validator.validate(object);

		if (!violations.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			for (ConstraintViolation<T> constraintViolation : violations) {
				if (sb.length() > 0) {
					sb.append(", " + constraintViolation.getMessage());
				} else {
					sb.append(constraintViolation.getMessage());
				}
			}
			return sb;
		}
		return null;
	}
	
	
	@Override
	public CommonResponse getGrienvaceViewDetails(String complaintNo) {
		try {
			log.info("START in getGrienvaceViewDetails complaintNo IS {} -------> ", complaintNo);

			GrienvanceFromDetailsProxy fromDetailsProxy = new GrienvanceFromDetailsProxy();

			GrievanceMaster grievanceMaster = grievanceMasterRepository.findByComplNo(complaintNo);
			if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
				log.info("GRIENVANCE MASTER DETAILS NOT FOUND complaintNo IS -----> " + complaintNo);
				return new CommonResponse("Grievance details not found.", HttpStatus.BAD_REQUEST.value(),
						Boolean.FALSE);
			}
			fromDetailsProxy.setComplNo(complaintNo);
			fromDetailsProxy.setUrn(grievanceMaster.getUrn());
			fromDetailsProxy.setId(grievanceMaster.getId());
			fromDetailsProxy.setDateOfComplaint(grievanceMaster.getCreatedDate());
			fromDetailsProxy.setDateOfClosure(grievanceMaster.getModifiedDate());//pending
			fromDetailsProxy.setSchemeName(!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getSchemeId())
					? SchemeMaster.getById(grievanceMaster.getSchemeId().longValue()).getShortName()
					: null);
			fromDetailsProxy.setStatus(!OPLUtils.isObjectNullOrEmpty(grievanceMaster.getStatus())
					? GrievanceStatus.fromId(grievanceMaster.getStatus()).getValue()
					: null);
			fromDetailsProxy.setStatusId(grievanceMaster.getStatus());
			GrievanceRemarks grievanceRemarks = grievanceRemarksRepository.findById(grievanceMaster.getId()).orElse(null);
			if (!OPLUtils.isObjectNullOrEmpty(grievanceRemarks)) {
				fromDetailsProxy.setComplDesc(grievanceRemarks.getComplDescription());
				fromDetailsProxy.setGrienvanceRemark(grievanceRemarks.getResolvedRemarks());
			}
			log.info("END in getGrienvaceViewDetails complaintNo IS {} -----> ", complaintNo);
			return new CommonResponse(CommonErrorMsg.Common.SUCCESS, fromDetailsProxy, HttpStatus.OK.value(),
					Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception while getGrienvaceViewDetails -----> ", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}

	@Override
	public CommonResponse checkGrienvaceFoundOrNot(String complaintNo) {
		try {
			log.info("START in checkGrienvaceFoundOrNot complaintNo IS {} -------> ", complaintNo);
			GrievanceMaster grievanceMaster = grievanceMasterRepository.findByComplNo(complaintNo);
			if (OPLUtils.isObjectNullOrEmpty(grievanceMaster)) {
				log.info("GRIENVANCE MASTER DETAILS NOT FOUND complaintNo IS -----> " + complaintNo);
				return new CommonResponse("Grievance details not found.",false, HttpStatus.OK.value(),
						Boolean.TRUE);
			}
			return new CommonResponse("Grievance details found.",true, HttpStatus.OK.value(),
					Boolean.TRUE);
		} catch (Exception e) {
			log.error("Exception while checkGrienvaceFoundOrNot -----> ", e);
			return new CommonResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
		}
	}
	
	@Override
	public CommonResponse fetchAccountHolderListGrievance(AccHolderListReq accHolderListReq) {
		AccHolderListResponse accHolderList = null;
		try {
			AccHolderListRequest accHolderListRequest = new AccHolderListRequest();
			if (!OPLUtils.isObjectNullOrEmpty(accHolderListReq)
					&& !OPLUtils.isObjectNullOrEmpty(accHolderListReq.getAccountValue())) {
				if (OPLUtils.isNumeric(accHolderListReq.getAccountValue())) {
					accHolderListRequest.setAccountNumber(accHolderListReq.getAccountValue());
				} else {
					accHolderListRequest.setUrn(accHolderListReq.getAccountValue());
				}
				BeanUtils.copyProperties(accHolderListReq, accHolderListRequest);
			}
			try {
				AuthClientResponse authClientResponse = new AuthClientResponse();
				if (DUMMY_ACC_NO.contains(accHolderListReq.getAccountValue())) {
					authClientResponse.setUserId(22l);
				}
				accHolderList = bankApiClient.getAccHolderList(accHolderListRequest, authClientResponse);
			} catch (Exception e) {
				log.error("Exception while GET ACCOUNT HOLDER LIST -----> ", e);
				return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}

			if (!OPLUtils.isObjectNullOrEmpty(accHolderList) && !OPLUtils.isObjectNullOrEmpty(accHolderList.getStatus())
					&& accHolderList.getStatus() == HttpStatus.OK.value()
					&& accHolderList.getSuccess().equals(Boolean.TRUE)) {

				StringBuilder validateResponse = validateResponse(accHolderList);
				if (!OPLUtils.isObjectNullOrEmpty(validateResponse)) {
					return new CommonResponse(validateResponse.toString(), HttpStatus.BAD_REQUEST.value(),
							Boolean.FALSE);
				}

				List<AccountHolderDetailsProxy> holderDetailsLst = new ArrayList<>();
				List<com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccountHolderDetails> accountHolderDetails = accHolderList
						.getAccountHolderList().stream()
						.filter(a -> SchemeMaster.getByCode(a.getScheme()).getId() == accHolderListReq.getSchemeId())
						.collect(Collectors.toList());
				for (com.opl.jns.api.proxy.banks.v3.getAccHolderList.AccountHolderDetails detailsProxy : accountHolderDetails) {
					AccountHolderDetailsProxy holderDetailsProxy = new AccountHolderDetailsProxy();
					BeanUtils.copyProperties(detailsProxy, holderDetailsProxy);
					holderDetailsProxy.setApplicationId(
							applicationMasterRepo.findFirstByUrnAndIsActiveTrue(detailsProxy.getUrn()).getId());
					holderDetailsLst.add(holderDetailsProxy);
				}

				if (OPLUtils.isListNullOrEmpty(holderDetailsLst)) {
					return new CommonResponse(CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
							HttpStatus.INTERNAL_SERVER_ERROR.value());
				}
				return new CommonResponse(CommonErrorMsg.Common.SUCCESS_FETCHED_DATA, holderDetailsLst,
						HttpStatus.OK.value(), Boolean.TRUE);
			}
		} catch (Exception e) {
			log.error("Exception is getting While Get account holder details ", e);
		}
		return new CommonResponse(
				!OPLUtils.isObjectNullOrEmpty(accHolderList) ? accHolderList.getMessage()
						: CommonErrorMsg.Enrollment.UNABLE_TO_FETCH_HOLDER_DTL,
				HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE);
	}


}