package com.opl.jns.crm.service.domain;

import com.opl.jns.utils.constant.DBNameConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "grievance_master")
public class GrievanceMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "grievance_master_seq_gen")
    @SequenceGenerator(schema = DBNameConstant.JNS_CRM, name = "grievance_master_seq_gen", sequenceName = "grievance_master_seq_gen", allocationSize = 1)
    private Long id;

    @Column(name = "urn", nullable = true)
    private String urn;

    @Column(name = "org_id", nullable = true)
    private Long orgId;

    @Column(name = "insurer_id", nullable = true)
    private Long insurerId;

    @Column(name = "scheme_id", nullable = true)
    private Integer schemeId;

    @Column(name = "compl_type", nullable = true)
    private Integer complType;

    @Column(name = "compl_predefined", nullable = true)
    private Integer complPredefined;

    @Column(name = "compl_no", nullable = true)
    private String complNo;

    @Column(name = "created_date", nullable = true)
    private Date createdDate;

    @Column(name = "modified_by", nullable = true)
    private Long modifiedBy;

    @Column(name = "modified_date", nullable = true)
    private Date modifiedDate;

    @Column(name = "status", nullable = true)
    private Integer status;

    @Column(name = "branch_id", nullable = true)
    private Long branchId;

    @Column(name = "doc_storage_id", nullable = true)
    private String docStorageId;
    
    @Column(name = "action_owner", nullable = true)
    private Integer actionOwner;

}