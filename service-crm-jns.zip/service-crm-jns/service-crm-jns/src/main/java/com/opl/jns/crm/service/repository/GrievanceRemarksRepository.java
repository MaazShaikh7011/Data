package com.opl.jns.crm.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.crm.service.domain.GrievanceRemarks;

public interface GrievanceRemarksRepository extends JpaRepository<GrievanceRemarks, Long> {
}
