package com.opl.jns.crm.service.repository.impl;

import com.opl.jns.crm.service.repository.CommonRepository;
import com.opl.jns.utils.common.OPLUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;
import java.sql.Clob;

/**
 * @author ravi.thummar
 * Date : 09-04-2024
 */
@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {

    @Autowired
    EntityManager entityManager;

    @Override
    public String callProducerWithRequest(String request, Long userId, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}", spName, request, userId);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }

    @Override
    public String callProducerWithRequestAndDate(String request, Long userId, String fromDate, String toDate, String spName) {
        try {
            log.info("spName {}, request-> {}, userId-> {}, fromDate-> {}, toDate-> {}", spName, request, userId, fromDate, toDate);
            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
            storedProcedureQuery.registerStoredProcedureParameter("filterjson", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("userid", Long.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("fromdate", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("todate", String.class, ParameterMode.IN);
            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
            storedProcedureQuery.setParameter("filterjson", request);
            storedProcedureQuery.setParameter("fromdate", fromDate);
            storedProcedureQuery.setParameter("todate", toDate);
            storedProcedureQuery.setParameter("userid", userId);
            storedProcedureQuery.execute();
            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
        } catch (Exception e) {
            log.error("Exception is getting while Call SP", e.getMessage());
        }
        return null;
    }

//    @Override
//    public String fetchMasterData(String listKey, String whereClause, String spName) {
//        try {
//            log.info("spName {}", spName);
//            StoredProcedureQuery storedProcedureQuery = entityManager.createStoredProcedureQuery(spName);
//            storedProcedureQuery.registerStoredProcedureParameter("listKey", String.class, ParameterMode.IN);
//            storedProcedureQuery.registerStoredProcedureParameter("whereClause", String.class, ParameterMode.IN);
//            storedProcedureQuery.registerStoredProcedureParameter("result", Clob.class, ParameterMode.OUT);
//            storedProcedureQuery.setParameter("listKey", listKey);
//            storedProcedureQuery.setParameter("whereClause", OPLUtils.isObjectNullOrEmpty(whereClause) ? "1" : whereClause);
//            storedProcedureQuery.execute();
//            return OPLUtils.readClob((Clob) storedProcedureQuery.getOutputParameterValue("result"));
//        } catch (Exception e) {
//            log.error("Exception is getting while Call SP", e.getMessage());
//        }
//        return null;
//    }


}
