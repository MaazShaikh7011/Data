package com.opl.jns.crm.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.opl.jns.crm.service.domain.GrievancePiDetails;

public interface GrievancePiDetailsRepository extends JpaRepository<GrievancePiDetails, Long> {

	@Query("""
		    select gm.id from GrievancePiDetails gpd \
		    inner join GrievanceMaster gm on gm.id=gpd.id \
		    where gpd.mobileNumber=:mobileNumber and gm.urn=:urn and gm.status=:status\
		    """)
    public List<Long> findByMobileNoAndUrnAndStatus(@Param("mobileNumber") String mobileNumber,@Param("urn") String urn,@Param("status") Integer status);

	
}
