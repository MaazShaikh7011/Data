package com.opl.jns.crm.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.opl.jns.crm.service.domain.GrievanceMaster;

public interface GrievanceMasterRepository extends JpaRepository<GrievanceMaster, Long> {
	
	GrievanceMaster findByComplNo(String complNo);
	
}
