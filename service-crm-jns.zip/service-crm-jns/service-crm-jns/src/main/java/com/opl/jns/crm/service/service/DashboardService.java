package com.opl.jns.crm.service.service;

import com.opl.jns.crm.service.model.UpdateStatusGrievanceProxy;
import com.opl.jns.utils.common.CommonResponse;

/***
 *
 * @author maulik.panchal Date : 09/04/2024
 */
public interface DashboardService {
    CommonResponse getGrievanceDashboardCount(String request, Long userId);

    CommonResponse getGrievanceDashboardList(String request, Long userId);

    CommonResponse getGrievanceDetails(Long id, Long userId);

    CommonResponse grievanceUpdateStatus(UpdateStatusGrievanceProxy updateStatusGrievanceProxy, Long userId);

}
