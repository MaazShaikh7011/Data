package com.opl.jns.crm.service.domain;

import com.opl.jns.utils.common.AESOracle;
import com.opl.jns.utils.common.DateEncryptorAes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "grievance_pi_details")
public class GrievancePiDetails {

    @Id
    private Long id;

    @Convert(converter = AESOracle.class)
    @Column(name = "name", nullable = true)
    private String name;

    @Convert(converter = AESOracle.class)
    @Column(name = "mobile_number", nullable = true)
    private String mobileNumber;

    @Convert(converter = AESOracle.class)
    @Column(name = "acc_no", nullable = true)
    private String accNo;
    
    @Convert(converter = DateEncryptorAes.class)
    @Column(name = "dob", nullable = true)
    private Date dob;

    @Convert(converter = AESOracle.class)
    @Column(name = "cif", nullable = true)
    private String cif;

    @Column(name = "claim_no", nullable = true)
    private Long claimNo;

    @Convert(converter = AESOracle.class)
    @Column(name = "policy_no", nullable = true)
    private String policyNo;

    @Convert(converter = AESOracle.class)
    @Column(name = "compl_name", nullable = true)
    private String complName;

    @Convert(converter = AESOracle.class)
    @Column(name = "compl_email", nullable = true)
    private String complEmail;

    @Column(name = "compl_relation", nullable = true)
    private Integer complRelation;

}
