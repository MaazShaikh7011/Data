package com.opl.jns.crm.service.controller;


import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opl.jns.auth.api.model.AuthClientResponse;
import com.opl.jns.auth.api.utils.AuthCredentialUtils;
import com.opl.jns.crm.api.enums.GrievanceStatus;
import com.opl.jns.crm.service.model.UpdateStatusGrievanceProxy;
import com.opl.jns.crm.service.service.DashboardService;
import com.opl.jns.utils.common.CommonResponse;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/dashboard")
@Slf4j
public class DashboardController {

    @Autowired
    DashboardService dashboardService;

    @PostMapping(value = "/getGrievanceDashboardCount", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getGrievanceDashboardCount(@RequestBody String request, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(dashboardService.getGrievanceDashboardCount(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while saveGrievanceDetails ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "/getGrievanceDashboardList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getGrievanceDashboardList(@RequestBody String request, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(dashboardService.getGrievanceDashboardList(request, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while saveGrievanceDetails ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @GetMapping(value = "/getGrievanceDetails/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> getGrievanceDetails(@PathVariable Long id, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            return new ResponseEntity<>(dashboardService.getGrievanceDetails(id, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while saveGrievanceDetails ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }

    @PostMapping(value = "grievanceUpdateStatus", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommonResponse> grievanceUpdateStatus(@RequestBody UpdateStatusGrievanceProxy updateStatusGrievanceProxy, @RequestAttribute(AuthCredentialUtils.SESSION_OBJ_KEY) AuthClientResponse authClientResponse) {
        try {
            if (!Arrays.asList(GrievanceStatus.OPEN.getId(), GrievanceStatus.CLOSED.getId())
                    .contains(updateStatusGrievanceProxy.getStatus())) {
                return new ResponseEntity<>(new CommonResponse(HttpStatus.BAD_REQUEST.getReasonPhrase(), HttpStatus.BAD_REQUEST.value()),
                        HttpStatus.OK);
            }
            return new ResponseEntity<>(dashboardService.grievanceUpdateStatus(updateStatusGrievanceProxy, authClientResponse.getUserId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while saveGrievanceDetails ------>", e);
            return new ResponseEntity<>(CommonResponse.TECHNICAL_ERROR(), HttpStatus.OK);
        }
    }
}
