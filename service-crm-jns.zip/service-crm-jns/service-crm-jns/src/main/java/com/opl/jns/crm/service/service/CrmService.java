package com.opl.jns.crm.service.service;

import java.io.*;
import java.util.*;

import com.opl.jns.crm.api.model.crm.email.req.*;
import com.opl.jns.crm.api.model.crm.sms.req.*;

public interface CrmService {

    public String  validateMobileNotification(List<SmsRequest> request) throws IOException;

    void sendSmsNotification(List<SmsRequest> applicationRequest);

    String  validateEmailNotification(List<EmailRequest> request) throws IOException;

    void sendEmailNotification(List<EmailRequest> request);


}
