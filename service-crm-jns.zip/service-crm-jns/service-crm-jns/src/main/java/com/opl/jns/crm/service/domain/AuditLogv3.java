package com.opl.jns.crm.service.domain;
//package com.opl.service.crm.jns.domain;
//
//import com.opl.jns.utils.common.AESOracle;
//import com.opl.jns.utils.constant.*;
//import lombok.*;
//
//import javax.persistence.*;
//import java.util.*;
//
///**
// * @author - Krunal Prajapati
// * @Date - 6/17/2023
// */
//@Data
//@EqualsAndHashCode(callSuper = false)
//@AllArgsConstructor
//@Entity
//@Table(name = "audit_log", indexes = {
//		@Index(columnList = "org_id", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_ORG_ID_IDX"),
//		@Index(columnList = "application_id", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_APP_ID_IDX"),
//		@Index(columnList = "api_id", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_API_ID_IDX"),
//		@Index(columnList = "account_number", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_ACCOUNT_NUM_IDX"),
//		@Index(columnList = "response_code", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_RES_CODE_IDX"),
//		@Index(columnList = "urn", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_URN_IDX"),
//		@Index(columnList = "reference_id", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_REF_ID_IDX"),
//		@Index(columnList = "response_time", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_RES_TIME_IDX"),
//		@Index(columnList = "created_date", name = DBNameConstant.JNS_BANK_API + "AUDIT_LOGS_CREADTED_DATE_IDX"), })
//@NoArgsConstructor
//public class AuditLogv3 {
//
//	@Id
//	@Column(name = "id")
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "audit_log_seq_gen")
//	@SequenceGenerator(schema = DBNameConstant.JNS_BANK_API, name = "audit_log_seq_gen", sequenceName = "audit_log_seq_gen", allocationSize = 1)
//	private Long id;
//
////	@Column(name = "user_id", length = 36, nullable = true)
////	private String userId;
//
//	@Column(name = "application_id", nullable = true)
//	private Long applicationId;
//
//	@Column(name = "org_id", nullable = true)
//	private Long orgId;
//
//	@Column(name = "failure_reason", length = 1000, nullable = true)
//	private String failureReason;
//
//	@Column(name = "api_id", nullable = false)
//	private Integer apiId;
//
//	@Column(name = "response_code", nullable = true)
//	private Integer responseCode;
//
////	@Column(name = "response_message", nullable = true)
////	private String responseMessage;
//
////	@Column(name = "api_status", nullable = true)
////	private Boolean apiStatus;
//
//	@Column(name = "created_date", nullable = false)
//	private Date createdDate;
//
//	@Column(name = "modified_date", nullable = true)
//	private Date modifiedDate;
//
//	@Column(name = "is_active", nullable = false)
//	private Boolean isActive;
//
////	@Column(name = "is_success", nullable = true)
////	private Boolean isSuccess;
//
//	@Column(name = "reference_id", nullable = true)
//	private String referenceId;
//
//	@Column(name = "response_time", nullable = true)
//	private Long responseTime;
//
//	@Column(name = "urn", nullable = true)
//	private String urn;
//
//	@Convert(converter = AESOracle.class)
//	@Column(name = "account_number", nullable = true)
//	private String accountNumber;
//
//}
