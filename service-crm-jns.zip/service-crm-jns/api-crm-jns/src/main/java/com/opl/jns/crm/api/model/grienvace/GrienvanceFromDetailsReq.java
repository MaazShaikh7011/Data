package com.opl.jns.crm.api.model.grienvace;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class GrienvanceFromDetailsReq {

	private Long id;
    private Integer complType;
    private Integer complPredefined;
    private String complNo;
    private String complName;
    private String complEmail;
    private Integer complRelation;
    private String complDesc;
    private String name;
    private String urn;
    private String cif;
    private String docStorageId;
    private Long insurerOrgId;
    private Integer schemeId;
    private Long claimId;
    private Long branchId;

}
