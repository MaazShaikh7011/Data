package com.opl.jns.crm.api.model.crm.sms.res;

import com.fasterxml.jackson.annotation.*;
import com.opl.jns.crm.api.model.crm.*;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SmsResponseProxy extends CrmCommonRes {

	@JsonProperty("data")
	private List<SmsResponseData> data;

	public SmsResponseProxy() {
		super();
	}

	public SmsResponseProxy(Integer status, String message, Boolean flag) {
		super(status, message, flag);
	}

}
