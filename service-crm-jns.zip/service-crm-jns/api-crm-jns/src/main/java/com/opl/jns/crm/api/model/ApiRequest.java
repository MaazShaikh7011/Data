package com.opl.jns.crm.api.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private TimeOutConfig triggerOtp;
	private TimeOutConfig verifyOtp;
	private TimeOutConfig customerDetails;
	private TimeOutConfig premiumDeduction;
	private TimeOutConfig physicalVerification;
	private TimeOutConfig checkDedupe;

}
