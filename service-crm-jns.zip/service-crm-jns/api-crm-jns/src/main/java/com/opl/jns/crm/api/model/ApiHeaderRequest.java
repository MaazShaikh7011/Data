package com.opl.jns.crm.api.model;


import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiHeaderRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("X-IB-Client-Id")
	private String clientId;

	@JsonProperty("X-IB-Client-Secret")
	private String clientSecret;

	@JsonProperty("X-Client-Certificate")
	private String clientCertificate;

	@JsonProperty("X-API-Interaction-ID")
	private String interactionId;

	@JsonProperty("Channel")
	private String channel;

	@JsonProperty("HealthCheck")
	private String healthCheck;

	@JsonProperty("HealthType")
	private String healthType;

	@JsonProperty("Content-Type")
	private String contentType;

}
