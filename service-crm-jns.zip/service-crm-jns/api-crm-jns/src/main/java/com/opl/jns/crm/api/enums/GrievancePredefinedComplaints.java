package com.opl.jns.crm.api.enums;

public enum GrievancePredefinedComplaints {
	COMPLAINT_1(1,3,"Cancelation of the Pmsby/Pmjjby policy and refund the amount"),
	COMPLAINT_2(2,2,"Pmjjby/Pmsby claim not credited in Nominee account"),
	COMPLAINT_3(3,2,"Delay in claim settlement "),
	COMPLAINT_4(4,2,"Unable to lodge the claim due to non issuance of policy"),
	COMPLAINT_5(5,2,"Claim closed/rejected without intimating the reason"),
	COMPLAINT_6(6,2,"Undue delay in reopening of claim even after sending all required documents"),
	COMPLAINT_7(7,2,"For PMSBY , Certificate of insurance can be generated only for current year on NIC portal"),
	COMPLAINT_8(8,3,"Unable to Nominee name modification in policy"),
	COMPLAINT_9(9,3,"Policy holder name/Nominee name mismatched "),
	COMPLAINT_10(10,2,"Request for deletion of Pmsby/Pmjjby policy"),
	COMPLAINT_11(11,1,"Policy issued without customer consent"),
	COMPLAINT_12(12,2,"Claim is approved but payment is not initiated "),
	COMPLAINT_13(13,2,"Policy restoration for the claim process"),
	COMPLAINT_14(14,1,"Unable to close the SB account due to death of account holder as it is covered under PMSBY"),
	COMPLAINT_15(15,1,"Unable to print the policy"),
	COMPLAINT_16(16,1,"Unable to closed the SB account, system shows error please initiate APY closer before proceeding for account closer"),
	COMPLAINT_17(17,2,"Unable to upload claim documents in SBI Life Parivartan site"),
	COMPLAINT_18(18,3,"Renewal payment failed and COI not generated, How to proceed in claim"),
	COMPLAINT_19(19,2,"While Claim lodgement An error occured while processing the request"),
	COMPLAINT_20(20,1,"unable to proceed with closure of the account with the message :- Initiate claim for APY/PMJJBY/PMSBY....."),
	COMPLAINT_21(21,2,"Death claim investigation not completed"),
	COMPLAINT_22(22,2,"Death claim not paid"),
	COMPLAINT_23(23,2,"Requirement in respect of Death Claim  not raised by Insurer"),
	COMPLAINT_24(24,2,"Complaint raised with Insurer not addressed");

	private Integer id;
	private Integer type;
	private String value;

	private GrievancePredefinedComplaints(Integer id, Integer type,String value) {
		this.id = id;
		this.type = type;
		this.value=value;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	public static GrievancePredefinedComplaints fromId(Integer v) {
		for (GrievancePredefinedComplaints c : GrievancePredefinedComplaints.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static GrievancePredefinedComplaints[] getAll() {
		return GrievancePredefinedComplaints.values();
	}
}
