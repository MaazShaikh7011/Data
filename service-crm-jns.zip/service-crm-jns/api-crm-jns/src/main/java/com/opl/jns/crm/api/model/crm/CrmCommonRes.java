package com.opl.jns.crm.api.model.crm;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonProperty;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CrmCommonRes {

	@JsonProperty("status")
	private Integer status;

	@JsonProperty("message")
	private String message;

	public CrmCommonRes() {
		super();
	}

	public CrmCommonRes(Integer status, String message, Boolean flag) {
		super();
		this.status = status;
		this.message = message;
	}

}
