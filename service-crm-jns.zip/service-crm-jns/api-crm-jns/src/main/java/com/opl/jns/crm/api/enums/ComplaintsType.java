package com.opl.jns.crm.api.enums;

public enum ComplaintsType {
	ENROLL(1, "Enroll"), CLAIM(2, "Claim");

	private Integer id;
	private String value;

	private ComplaintsType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static ComplaintsType fromId(Integer v) {
		for (ComplaintsType c : ComplaintsType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static ComplaintsType[] getAll() {
		return ComplaintsType.values();
	}
}
