package com.opl.jns.crm.api.enums;

public enum GrievanceStatus {
    GRIEVANCE_INITIATED(1, "Grievance initiated", ""),
    GRIEVANCE_REGISTERED(2, "Grievance registered", "New"),
    OPEN(3, "open", "Open"),
    CLOSED(4, "closed", "Closed");;

    private Integer id;
    private String value;
    private String displayName;

    private GrievanceStatus(Integer id, String value, String displayName) {
        this.id = id;
        this.value = value;
        this.displayName = displayName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public static GrievanceStatus fromId(Integer v) {
        for (GrievanceStatus c : GrievanceStatus.values()) {
            if (c.id.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v != null ? v.toString() : null);
    }

    public static GrievanceStatus[] getAll() {
        return GrievanceStatus.values();
    }
}
