package com.opl.jns.crm.api.model.grienvace;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class AccountHolderDetailsProxy {

	private String accountNumber;
	private String accountHolderName;
	private String cif;
	private String urn;
	private LocalDateTime policyInceptionDate;
	private String scheme;
	private Long applicationId;
}
