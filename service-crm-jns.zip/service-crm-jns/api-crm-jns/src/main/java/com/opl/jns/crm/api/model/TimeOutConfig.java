package com.opl.jns.crm.api.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TimeOutConfig implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer readTimeOut;
	private Integer conTimeOut;
}
