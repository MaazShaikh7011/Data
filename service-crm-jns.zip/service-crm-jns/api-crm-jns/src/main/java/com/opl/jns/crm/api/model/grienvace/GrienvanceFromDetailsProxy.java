package com.opl.jns.crm.api.model.grienvace;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class GrienvanceFromDetailsProxy {

	private Long id;
    private String bankName;
    private String insurerName;
    private String urn;
    private Long claimNo;
    private Integer complRelation;
    private String complName;
    private String complEmail;
    private String complMobileNo;
    private Integer complType;
    private Integer complPredefined;
    private String complNo;
    private String complDesc;
    private String docStorageId;
    private Long orgId;
    private Long insurerOrgId;
    private String schemeName;
    private Long schemeId;
    private Date dateOfComplaint;
    private Date dateOfClosure;
    private String status;
    private Integer statusId;
    private String grienvanceRemark;
    private Long branchId;
    private List<GrienvanceDocProxy> docProxy;
}
