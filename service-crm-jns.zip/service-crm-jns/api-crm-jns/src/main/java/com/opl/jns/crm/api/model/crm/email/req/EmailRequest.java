package com.opl.jns.crm.api.model.crm.email.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.*;
import java.io.*;
import java.util.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class EmailRequest implements Serializable {


    @NotNull(message = "to can not be null")
    @NotEmpty(message = "to can not be empty")
    public List<String> to;
    public List<String> cc;

    @NotNull(message = "subject can not be null")
    @NotEmpty(message = "subject can not be empty")
    public String subject;

    @NotNull(message = "content can not be null")
    @NotEmpty(message = "content can not be empty")
    public String content;
    public List<ContentAttachment> contentAttachments;
    private final static long serialVersionUID = 6986256456573375427L;

}