package com.opl.jns.crm.api.enums;

public enum GrievancePredefinedComplaintsType {
	BANK(1, "Bank"), INSURER(2, "Insurer"), BOTH(3, "Both");

	private Integer id;
	private String value;

	private GrievancePredefinedComplaintsType(Integer id, String value) {
		this.id = id;
		this.value = value;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static GrievancePredefinedComplaintsType fromId(Integer v) {
		for (GrievancePredefinedComplaintsType c : GrievancePredefinedComplaintsType.values()) {
			if (c.id.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v != null ? v.toString() : null);
	}

	public static GrievancePredefinedComplaintsType[] getAll() {
		return GrievancePredefinedComplaintsType.values();
	}
}
