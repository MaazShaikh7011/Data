package com.opl.jns.crm.api.model.crm.email.res;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.io.*;

@Setter
@Getter
public class EmailResponseData implements Serializable {

    @JsonProperty("to")
    public String to;
    @JsonProperty("remarks")
    public String remarks;

    private final static long serialVersionUID = -7382821262195569577L;

}