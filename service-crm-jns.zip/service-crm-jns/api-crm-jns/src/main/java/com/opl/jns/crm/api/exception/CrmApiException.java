package com.opl.jns.crm.api.exception;

/**
 * @author - Maaz Shaikh
 * @Date - 3/9/2023
 */
public class CrmApiException extends Exception{
    public CrmApiException(String message){
        super(message);
    }
    public CrmApiException(Exception e){
        super(e);
    }
}
