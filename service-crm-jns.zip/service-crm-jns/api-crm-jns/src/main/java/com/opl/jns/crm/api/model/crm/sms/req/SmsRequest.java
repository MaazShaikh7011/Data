package com.opl.jns.crm.api.model.crm.sms.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.*;
import java.io.*;
import java.util.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class SmsRequest implements Serializable {

    private final static long serialVersionUID = 8615106587178853864L;

    @NotNull(message = "toMobile can not be null")
    @NotEmpty(message = "toMobile can not be null")
    private String toMobile;

    @NotNull(message = "templateId can not be null")
    @Min(value = 1,message = "templateId can not be 0")
    private Long templateId;

    private Parameters parameters;

//    @NotNull(message = "referenceId can not be null")
//    @NotEmpty(message = "referenceId can not be null")
//    private String referenceId;

}