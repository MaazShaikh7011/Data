package com.opl.jns.crm.api.model.crm.email.res;

import com.fasterxml.jackson.annotation.*;
import com.opl.jns.crm.api.model.crm.*;
import com.opl.jns.crm.api.model.crm.sms.res.*;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EmailResponseProxy extends CrmCommonRes {

    @JsonProperty("data")
    private List<SmsResponseData> data;

    public EmailResponseProxy() {
        super();
    }

    public EmailResponseProxy(Integer status, String message, Boolean flag) {
        super(status, message, flag);
    }

}
