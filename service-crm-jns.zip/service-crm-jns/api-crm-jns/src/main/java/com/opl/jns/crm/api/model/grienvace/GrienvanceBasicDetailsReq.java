package com.opl.jns.crm.api.model.grienvace;

import java.time.LocalDate;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
public class GrienvanceBasicDetailsReq {

	private String name;
	private String mobileNumber;
	private Integer schemeId;
	private Long orgId;
	private String urnOrAccNo;
	private Date dobDateFormat;
	private LocalDate dob;
	private String accountValue;

}
