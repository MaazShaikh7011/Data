package com.opl.jns.crm.api.utils;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import jakarta.xml.bind.DatatypeConverter;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;

public class SymAsymEncryption {

    private static final String CHAR_ENCODING = "UTF-8";
    private static final int GCM_TAG_LENGTH = 16;
    private static String transformation ="AES/GCM/NoPadding";

    public SymAsymEncryption() {

    }

    public SymAsymEncryption(String transformation) {
        this.transformation = transformation;
    }

    public static String OPL_PRIVATE_KEY = "MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQDIM6KmlHv9s84LP4w43MVjxgqCIqnmvsrGYop8ydWDNr67f7u97EOs9JB51mooejyO7UY1GP+Za18h7u7j747k2ybza8cgM2S8rc0waTPakqaPiDVXKoC8GcYIy/uyl3fXcKddNcBK3+VnhNRdWwY8g3TlJt0+Vu5TCgWNU95QFIxLel45zlRvmDE7c/G86kyLPI7gtrAfEE21GRjny273knnkac8PRlRBaKrIuwI2C8BKckT6ECmQ8VsB1WUq97QQtb58hW6RTElwCTRs8fmUd8YIaqzVpbXeHmY5C/9ke0lp2GikM4Y63B+UkYlhWdkJTiryMD6pkFy9gDkCF5c4FPseCaD//41TvVKaNu1ffgL8qvFFE6H0675M7gBZRbOqP8H2oBb2VmPWy8xNk94sWehIeQoL5N4R68q03PzGoHxzSf+ZYCLwCUrWmnyHsGlGi0Ymgq3Xv8EoVkgMj63pDD8zrA+yu7qQGswFNqgTwp83IZIP9WuafRwsOO91TWbAlVh1um3AZDIriOdYvs0OvQDUubuzOnA7J80Lp/E1VMk+Jld5CxDIwPgbdzXQh/hl3QdcNQpdqk4YuBdy8OrAJPB7AxHs6CExyDwVBQzU6FwY0QCORq9n+EZUHFt+wGbUpYvQvuSVADKFAH6dzlj9Dc8X0mP/godl1LeNk/ekdwIDAQABAoICAQCxX44rqEJydGuI67SAbJk13LBSvANrvH5LZeLszKWuq0IxPOpJSpprEgMu7xj+483jk7UwNgW/F7Ihjl948zXW7ZOE92hkzyPhRtsUmSCn9mY7pKIdqDqGbQ9Xm+JUSH6VEeo2WvkTXWsSXE0KqSrNUmqu29AI+1wLlkV1AWll6c6i0LfK31NPy7dSxVbX2X4Xnn+3+CPyYa93U9UNCOA32D7GcDhTgCwGB4XIcmdzGtYzHyqdotQw5qWK6lXHy85tP5iVGmLruHsYGA+qtng5YiTCMEEQyNBpCuXmhQqxK8nPTTzovf2fCIeySX8+ESyJYggKq1PZR13jR0c640vFglQWN9pgjrmSLMbwpG7LZj+RRT0fRqlDUU9ftKjiUDt9gww0Tbneu/ORqYXoaa00Y0QcXZX0/Q4suVO/LwazOS3+SKSwIYxQJGirN6pSZ48bbQ2VylpDkG6DY6IZPHdctdro6zG5XAmiqteCh9KeASEpnch0Xlfd0PP5IWkzAuWHvWG20NdztqvPag/jFVmQ9EOxhMGZlfA+PZ/+p6mL/a9ARYN8+S8WM/CKMjjmLsk44zm7RgPhDVVj8nGS+zyrxj3iI6kaDqji2vWQ2oP5D1Q6S2hxY7S7Z7K2ds4bSQC70MfKFOAthV5Xtw4QzNMZIJWv/Ox9XCTdZ83gispVAQKCAQEA8Xl21jY7vz8YmRJJ8F2cc+VmXgEc915aUIrFpF6Yb+S+L6en1b6KQBlCr9N2S8aQSfHPsDY1YDrZlbIg0p08vDGp2xqUOQrgsXe8r6YLm1k23FO/XCE1A2yuSdZqO5353iCskh5hdr6qS7KUmRAJNyrImTIz4lGmVyMQKxDXxuj2Ms2mF8mmcaFmcxaNGGaOUWOxtixPdNxQn/LUljItC8mcJgPCTGoc8f58g8FMgt5VYkG2heY+0saSEzuTlJXaGIOZyyagHtJGUPS5EvHJw1UfHnNanMqsvQI3KWxf29kBS8TF3l2ytJkvKR6u0bbCUfZj/dLCmNWfl6sM+YT17wKCAQEA1D6ZiI9FTfI9Otr0cwGMWLj1uUyMQ7r9LbT4WZtxt2n8OUHHhBfAAeTv0+oWxaI8HzutDJvi2Y6mI3G0+Mg23QVW+8Fth1SB+NXIlHgN0MVFzoKmiJqKtDVZuwNjsVE3baUO8KDO2HnSh/KDB7z63iJ78MTMCArx7DDLQkXMzmhMc/7D1+iUEMKL2V0MGmM6l66/OqPszaWanXJAWONGeNj7/jGzg7HR0VgD9MgkeJVE1olpBLabWD3fom+ix0awSDP8OsMHsNEinQ12QgJoh2A9faHijmziC7p9+VVT+u8DLAzC8CRlRNhXyu8HxRlrrJ1NiB1Ka0WXD1udWLmB+QKCAQAfvg7QE+sAteOe45eSoEubtJEjVFQhdGa85bEbbU/ujYwuqYRXhaeYy3lHsa2AQobfIYliqY2Uq8fEdNj5tq+wMXsZkUHgybxFt+62zEYEUtLyXZPvIXJdk+DJVgU69wZMm9DzmEjJmkC6mKwN/tynQtmBweauHnuWQsayUpF61U7f2Ma3o8tcbpIQGOvNRFX6/vbycpqzSu7SR9KIN+pR/VuoZ6AX+W76pLBrhXJwVZe1xdufeGfTv0SegJti0dwMkugZm2c7Bfs2UyUtB1m1crAXiaRkrgPNCMiFiniDZuBTvHciRwDh2q0nY6ApczPSIGh+ikEIZDSJdHPNLRxDAoIBAEHOpwwQYAyq7xEwklqWQE3CC25IrbTSZW2mjto5uCiGVA3st0/djUsJENND4Yulob6NYjpmmw+ZiymyN8prSZd98FpevvcW3LWqk2Z1UtNIVzyQhdIVGKyHXir+AgsYg3cblmZFddzo6L3+E2Jy1dXKG2OroRddTWVOO7dwrO/SpuHQPCjVlBMePv5GO1pzKded9uzXprSchDQNGKZ20YLmxDssbdyHZebiw1dCNwysO4vJTyaG9+OES7KxqmbfJAk/FRWjIt9P+Mt5QRF2bbKLxIUPjI9ccznvuN919XP4Z6Ng0ZBjuIKAEbh6JI6YMypyG3f4nPpluVCptz+rRQECggEBAIqTYU8zyEMXE2xR6ITo0C2IwzK6kv5LCSQAcw6jCcMKQh1Q6o5mP1S49gZs3miEE+cdATR0f3/5mykYfGkGzgBVQNy8WyduFskDc3MeIp2oGvJDcYkw7cC+CyBoyGxkPRcb86MGD87qfPAVgvZob+IsKcETh2bHvOM+7fVgmexhZnXbRkTbTRygGkIm5FBAGEufYr9VGJFIMbqwt1rznXLpFWRiE4KnotNl1UPcXHvQ8AIsiSQSwIewHMfVVgbIaQ9E0XO/WsA0wOS0XQNuAG4zRrZ26HX66bQmaiURlI110Uvqk4hVHvvbNU+4ABbbziy15nbrZbc/FQidbY2knIw=";
    public static String OPL_PUBLIC_KEY = "MIIGFTCCA/2gAwIBAgIJAPSKbRMI5cvxMA0GCSqGSIb3DQEBCwUAMIGgMQswCQYDVQQGEwJJTjEQMA4GA1UECAwHZ3VqYXJhdDESMBAGA1UEBwwJYWhtZWRhYmFkMR0wGwYDVQQKDBRPbmxpbmUgcHNiIGxvYW5zIGx0ZDELMAkGA1UECwwCSVQxEDAOBgNVBAMMB2Fucy1kZXYxLTArBgkqhkiG9w0BCQEWHmt1c2hhbC5zaGFoQG9ubGluZXBzYmxvYW5zLmNvbTAeFw0yMTA3MDcxMzAzNDRaFw0zMTA3MDUxMzAzNDRaMIGgMQswCQYDVQQGEwJJTjEQMA4GA1UECAwHZ3VqYXJhdDESMBAGA1UEBwwJYWhtZWRhYmFkMR0wGwYDVQQKDBRPbmxpbmUgcHNiIGxvYW5zIGx0ZDELMAkGA1UECwwCSVQxEDAOBgNVBAMMB2Fucy1kZXYxLTArBgkqhkiG9w0BCQEWHmt1c2hhbC5zaGFoQG9ubGluZXBzYmxvYW5zLmNvbTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMgzoqaUe/2zzgs/jDjcxWPGCoIiqea+ysZiinzJ1YM2vrt/u73sQ6z0kHnWaih6PI7tRjUY/5lrXyHu7uPvjuTbJvNrxyAzZLytzTBpM9qSpo+INVcqgLwZxgjL+7KXd9dwp101wErf5WeE1F1bBjyDdOUm3T5W7lMKBY1T3lAUjEt6XjnOVG+YMTtz8bzqTIs8juC2sB8QTbUZGOfLbveSeeRpzw9GVEFoqsi7AjYLwEpyRPoQKZDxWwHVZSr3tBC1vnyFbpFMSXAJNGzx+ZR3xghqrNWltd4eZjkL/2R7SWnYaKQzhjrcH5SRiWFZ2QlOKvIwPqmQXL2AOQIXlzgU+x4JoP//jVO9Upo27V9+Avyq8UUTofTrvkzuAFlFs6o/wfagFvZWY9bLzE2T3ixZ6Eh5Cgvk3hHryrTc/MagfHNJ/5lgIvAJStaafIewaUaLRiaCrde/wShWSAyPrekMPzOsD7K7upAazAU2qBPCnzchkg/1a5p9HCw473VNZsCVWHW6bcBkMiuI51i+zQ69ANS5u7M6cDsnzQun8TVUyT4mV3kLEMjA+Bt3NdCH+GXdB1w1Cl2qThi4F3Lw6sAk8HsDEezoITHIPBUFDNToXBjRAI5Gr2f4RlQcW37AZtSli9C+5JUAMoUAfp3OWP0NzxfSY/+Ch2XUt42T96R3AgMBAAGjUDBOMB0GA1UdDgQWBBTKjVgJ8xwIv4LJXt7jZz0O9vPZLjAfBgNVHSMEGDAWgBTKjVgJ8xwIv4LJXt7jZz0O9vPZLjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4ICAQAv24N27u5t58EQO+kE4UX/OMR0FSSeXvcLzEktrQ1/I5fKzOD8umuXl1BRvoOVzDQMSBRYEpVAwmgkWIlxudK4Rob2UeB/Fb+bnfAxhF0DISSVWR9S4eXBNpReizK/YJqkcXxMEaPI6jK6r2AqO1+UpKByffhOob70UAcMGzxR1r08g/9L2644JvdVfskgfHNlIVM4nA7xdLEzjFQFdDUuLzXPbIlNR7Z5LW0m51vz9fbLUdZ2TpLdzKHAX1sC+WH/d9xmKQ5EjwzvHpn1nifWPjqUPDrkbBBeQdtb2s11PjzfFFK2iM/yMnO+ewXjJi7gAu8EV3i0kcwMeflNf5UjAZzw9Aw/r+tkXy9Y3VdlltZmprZy9i6PE1ELWQNdnJ5Ksso7ycaaeA7kVyv+fFPlLma15Mfx/n8WfHz0cgIqXXI47gMOdEiCgHrtvSZ6mv2S+2DkyRX1euwLepSDUh/74qEqSfknCtrpPJduJzrJDNMBNvefinPTx2DDAPKSv3A+37+ApI84cLq9y5m94jIZMQYEAyp2nSXeBR11QZb468Lf3Yoel3pxHBJJ42mvIz0Kew7ctzlRmRNewbOb/rq2g0mWJZuAnSWfmLYLGh0DuXvNzfuWzCfEXd9sGJgtstgyb+AQURiSEUmYva6bXmtQjksRwUTfpxlwCEXwqoHGow==";

    static {
        Security.addProvider(new BouncyCastleProvider());
    }


    private  String getEncryptHeader(String keyPlainText, String publickey) {
        try {
            byte[] keyByteArr = keyPlainText.getBytes();
            PublicKey key = getPublicKey(publickey);

            Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPADDING");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedByte = cipher.doFinal(keyByteArr);
            String encodedString = Base64.getEncoder().encodeToString(encryptedByte);
            return encodedString;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private  String signSHA256RSA(String input, String strPk) throws NoSuchAlgorithmException, InvalidKeyException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException  {

        String realPK = strPk.replace("-----END PRIVATE KEY-----", "").replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("\n", "");
        byte[] b1 = DatatypeConverter.parseBase64Binary(realPK);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
        KeyFactory kf = KeyFactory.getInstance("RSA");

        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initSign(kf.generatePrivate(spec));
        byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
        privateSignature.update(bytes);
        byte[] s = privateSignature.sign();
        return Base64.getEncoder().encodeToString(s);
    }

    private  byte[] encryptRequestBodyAES256(byte[] plaintext, byte[] key, byte[] IV) throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, NoSuchProviderException{

        Cipher cipher = Cipher.getInstance(transformation);
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);
        return cipher.doFinal(plaintext);
    }


    private static byte[] getIVFromAESKey(byte[] encoded) {
        return Arrays.copyOfRange(encoded, 0, 16);
    }

    public String encrypt(String plainText, String privateKey, String publicKey) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException, NoSuchProviderException  {

        String uuid = UUID.randomUUID().toString().replace("-","");
        byte[] iv = getIVFromAESKey(uuid.getBytes());
        byte[] encrypt = encryptRequestBodyAES256(plainText.getBytes(), uuid.getBytes(),iv);
        String encryptionRequestBody = Base64.getEncoder().encodeToString(encrypt);
        String digitalSignature = signSHA256RSA(encryptionRequestBody, privateKey);
        String keys = uuid;
        String haderKey = getEncryptHeader(keys, publicKey);
        return Base64.getEncoder().encodeToString((haderKey + ":" + encryptionRequestBody + ":" + digitalSignature).getBytes());
    }

    private  String decryptHeader(String data, String privatekey) throws NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidKeySpecException  {

        byte[] encryptedData = Base64.getDecoder().decode(data);
        PrivateKey privateKey = getPrivateKey(privatekey);
        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPADDING");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] encryptedByte = cipher.doFinal(encryptedData);

        return new String(encryptedByte);
    }

    private  PrivateKey getPrivateKey(String privateKeyStr) throws NoSuchAlgorithmException, InvalidKeySpecException {

        PrivateKey privateKey = null;
        KeyFactory keyFactory = null;

        byte[] encoded = DatatypeConverter.parseBase64Binary(privateKeyStr);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
        keyFactory = KeyFactory.getInstance("RSA");
        privateKey = keyFactory.generatePrivate(keySpec);

        return privateKey;
    }

    private String decSignSHA256RSA(String encryptionRequestBody, String digitalSignature, String strPk)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, CertificateException, IOException {

        String k = strPk.replace("\n", "").replace("\r", "");
        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initVerify(getPublicKey(k));
        byte[] bytes = encryptionRequestBody.getBytes(CHAR_ENCODING);
        privateSignature.update(bytes);
        privateSignature.verify(Base64.getDecoder().decode(digitalSignature));
        return encryptionRequestBody;
    }

    private String decryptRequestBody(byte[] cipherText, byte[] key, byte[] IV)
            throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException  {

        Cipher cipher = Cipher.getInstance(transformation);
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, IV);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
        byte[] decryptedText = cipher.doFinal(cipherText);

        return new String(decryptedText);
    }

    public String decrypt(String encText, String privatekey, String publickey)
            throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, SignatureException, InvalidAlgorithmParameterException, NoSuchProviderException, InvalidKeySpecException, CertificateException, IOException {

        String split =  new String(Base64.getDecoder().decode(encText));
        String haderKey = split.split(":")[0];
        String digitalSignature = split.split(":")[2];;
        String encryptionRequestBody = split.split(":")[1];;
        String decHeadr = decryptHeader(haderKey, privatekey);
        String decrypt = decSignSHA256RSA(encryptionRequestBody, digitalSignature, publickey);
        byte[] aesKey = decHeadr.getBytes();
        byte[] iv = getIVFromAESKey(aesKey);
        return decryptRequestBody(Base64.getDecoder().decode(decrypt), decHeadr.getBytes(), iv);
    }


    PublicKey getPublicKey(String publicKeyStr) {

        PublicKey publicKey = null;
        try {
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            BufferedReader br = new BufferedReader(new StringReader(publicKeyStr));
            String line = null;
            StringBuilder keyBuffer = new StringBuilder();

            while ((line = br.readLine()) != null) {
                if (!line.startsWith("-")) {
                    keyBuffer.append(line);
                }
            }
            Certificate certificate = certificateFactory
                    .generateCertificate(new ByteArrayInputStream(Base64.getDecoder().decode(keyBuffer.toString())));
            publicKey = certificate.getPublicKey();
        } catch (Exception var8) {
            var8.printStackTrace();
        }
        return publicKey;
    }


}