package com.opl.jns.crm.api.model.crm.sms.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.*;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class Parameters implements Serializable {

    public String param;
    public String otp;

    public String tctNo;
    private final static long serialVersionUID = -3319065799372041684L;

}