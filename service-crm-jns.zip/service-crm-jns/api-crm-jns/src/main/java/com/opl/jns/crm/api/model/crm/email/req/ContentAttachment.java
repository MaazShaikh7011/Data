package com.opl.jns.crm.api.model.crm.email.req;

import lombok.Getter;
import lombok.Setter;

import java.io.*;

@Setter
@Getter
public class ContentAttachment implements Serializable {

    public String fileName;
    public byte[] contentInByte;
    private final static long serialVersionUID = -5466932653012925837L;

}