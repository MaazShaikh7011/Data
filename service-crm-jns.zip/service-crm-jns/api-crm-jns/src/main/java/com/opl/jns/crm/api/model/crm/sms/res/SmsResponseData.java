package com.opl.jns.crm.api.model.crm.sms.res;

import com.fasterxml.jackson.annotation.*;
import lombok.Getter;
import lombok.Setter;

import java.io.*;

@Setter
@Getter
public class SmsResponseData implements Serializable {

    @JsonProperty("toMobile")
    public String toMobile;
    @JsonProperty("templateId")
    public Long templateId;
    @JsonProperty("remarks")
    public String remarks;

    private final static long serialVersionUID = -7382821262195569577L;

}