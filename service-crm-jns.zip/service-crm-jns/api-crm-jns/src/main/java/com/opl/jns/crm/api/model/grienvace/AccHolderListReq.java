package com.opl.jns.crm.api.model.grienvace;

import java.time.LocalDate;

import lombok.Data;

@Data
public class AccHolderListReq {

	private String accountValue;
	private LocalDate dob;
	private Long applicationId;
	private Long orgId;
	private Long schemeId;

}
