package com.opl.jns.crm.client;

import org.springframework.web.client.*;

public class CrmApiClient {

    private String baseUrlStr;
    private RestTemplate restTemplate;

    public CrmApiClient() {
    }

    public CrmApiClient(String baseUrlStr) {
        super();
        this.baseUrlStr = baseUrlStr;
        this.restTemplate = new RestTemplate();
    }


}
